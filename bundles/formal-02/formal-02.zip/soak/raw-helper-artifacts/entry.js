import { $ as e, A as t, G as n, J as r, K as i, L as a, M as o, N as s, Q as c, S as l, St as u, T as d, U as f, W as p, X as m, Y as h, Z as g, _, _t as v, a as y, at as b, b as x, bt as S, c as C, ct as w, dt as T, et as E, ft as D, gt as O, h as k, ht as ee, i as te, it as A, j, k as ne, lt as re, mt as ie, n as M, nt as ae, o as N, ot as oe, pt as P, q as F, r as se, rt as ce, s as I, st as L, t as R, tt as le, u as ue, ut as de, v as fe, vt as z, xt as pe, y as me, yt as B } from "./model-CpGFZXoy.js";
import { c as he, l as ge, o as _e, r as ve, s as ye, u as be } from "./presentation-CWp-ugMV.js";
import { a as xe, c as Se, d as V, f as Ce, i as we, l as Te, o as Ee, r as De, s as H, t as U, u as Oe } from "./protocol-DZd519mb.js";
//#endregion
//#region node_modules/dexie/import-wrapper-prod.mjs
var ke = /* @__PURE__ */ u((/* @__PURE__ */ pe(((e, t) => {
	((n, r) => {
		typeof e == "object" && t !== void 0 ? t.exports = r() : typeof define == "function" && define.amd ? define(r) : (n = typeof globalThis < "u" ? globalThis : n || self).Dexie = r();
	})(e, function() {
		var e = function(t, n) {
			return (e = Object.setPrototypeOf || ({ __proto__: [] } instanceof Array ? function(e, t) {
				e.__proto__ = t;
			} : function(e, t) {
				for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
			}))(t, n);
		}, t = function() {
			return (t = Object.assign || function(e) {
				for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
				return e;
			}).apply(this, arguments);
		};
		function n(e, t, n) {
			if (n || arguments.length === 2) for (var r, i = 0, a = t.length; i < a; i++) !r && i in t || ((r ||= Array.prototype.slice.call(t, 0, i))[i] = t[i]);
			return e.concat(r || Array.prototype.slice.call(t));
		}
		var r = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, i = Object.keys, a = Array.isArray;
		function o(e, t) {
			return typeof t == "object" && i(t).forEach(function(n) {
				e[n] = t[n];
			}), e;
		}
		typeof Promise > "u" || r.Promise || (r.Promise = Promise);
		var s = Object.getPrototypeOf, c = {}.hasOwnProperty;
		function l(e, t) {
			return c.call(e, t);
		}
		function u(e, t) {
			typeof t == "function" && (t = t(s(e))), (typeof Reflect > "u" ? i : Reflect.ownKeys)(t).forEach(function(n) {
				f(e, n, t[n]);
			});
		}
		var d = Object.defineProperty;
		function f(e, t, n, r) {
			d(e, t, o(n && l(n, "get") && typeof n.get == "function" ? {
				get: n.get,
				set: n.set,
				configurable: !0
			} : {
				value: n,
				configurable: !0,
				writable: !0
			}, r));
		}
		function p(e) {
			return { from: function(t) {
				return e.prototype = Object.create(t.prototype), f(e.prototype, "constructor", e), { extend: u.bind(null, e.prototype) };
			} };
		}
		var m = Object.getOwnPropertyDescriptor, h = [].slice;
		function g(e, t, n) {
			return h.call(e, t, n);
		}
		function _(e, t) {
			return t(e);
		}
		function v(e) {
			if (!e) throw Error("Assertion Failed");
		}
		function y(e) {
			r.setImmediate ? setImmediate(e) : setTimeout(e, 0);
		}
		function b(e, t) {
			if (typeof t == "string" && l(e, t)) return e[t];
			if (!t) return e;
			if (typeof t != "string") {
				for (var n = [], r = 0, i = t.length; r < i; ++r) {
					var a = b(e, t[r]);
					n.push(a);
				}
				return n;
			}
			var o, s = t.indexOf(".");
			return s === -1 || (o = e[t.substr(0, s)]) == null ? void 0 : b(o, t.substr(s + 1));
		}
		function x(e, t, n) {
			if (e && t !== void 0 && !("isFrozen" in Object && Object.isFrozen(e))) {
				if (typeof t != "string" && "length" in t) {
					v(typeof n != "string" && "length" in n);
					for (var r = 0, i = t.length; r < i; ++r) x(e, t[r], n[r]);
				} else {
					var o = t.indexOf(".");
					if (o !== -1) {
						var s = t.substr(0, o), o = t.substr(o + 1);
						if (o === "") n === void 0 ? a(e) && !isNaN(parseInt(s)) ? e.splice(s, 1) : delete e[s] : e[s] = n;
						else {
							var c = e[s];
							if (!c || !l(e, s)) {
								if (n === void 0) return;
								c = e[s] = {};
							}
							x(c, o, n);
						}
					} else n === void 0 ? a(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n;
				}
			}
		}
		function S(e) {
			var t, n = {};
			for (t in e) l(e, t) && (n[t] = e[t]);
			return n;
		}
		var C = [].concat;
		function w(e) {
			return C.apply([], e);
		}
		var T = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(w([
			8,
			16,
			32,
			64
		].map(function(e) {
			return [
				"Int",
				"Uint",
				"Float"
			].map(function(t) {
				return t + e + "Array";
			});
		}))).filter(function(e) {
			return r[e];
		}), E = new Set(T.map(function(e) {
			return r[e];
		})), D = null;
		function O(e) {
			return D = /* @__PURE__ */ new WeakMap(), e = function e(t) {
				if (!t || typeof t != "object") return t;
				var n = D.get(t);
				if (n) return n;
				if (a(t)) {
					n = [], D.set(t, n);
					for (var r = 0, i = t.length; r < i; ++r) n.push(e(t[r]));
				} else if (E.has(t.constructor)) n = t;
				else {
					var o, c = s(t);
					for (o in n = c === Object.prototype ? {} : Object.create(c), D.set(t, n), t) l(t, o) && (n[o] = e(t[o]));
				}
				return n;
			}(e), D = null, e;
		}
		var k = {}.toString;
		function ee(e) {
			return k.call(e).slice(8, -1);
		}
		var te = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", A = typeof te == "symbol" ? function(e) {
			var t;
			return e != null && (t = e[te]) && t.apply(e);
		} : function() {
			return null;
		};
		function j(e, t) {
			t = e.indexOf(t), 0 <= t && e.splice(t, 1);
		}
		var ne = {};
		function re(e) {
			var t, n, r, i;
			if (arguments.length === 1) {
				if (a(e)) return e.slice();
				if (this === ne && typeof e == "string") return [e];
				if (i = A(e)) for (n = []; !(r = i.next()).done;) n.push(r.value);
				else {
					if (e == null || typeof (t = e.length) != "number") return [e];
					for (n = Array(t); t--;) n[t] = e[t];
				}
			} else for (t = arguments.length, n = Array(t); t--;) n[t] = arguments[t];
			return n;
		}
		var ie = typeof Symbol < "u" ? function(e) {
			return e[Symbol.toStringTag] === "AsyncFunction";
		} : function() {
			return !1;
		}, T = [
			"Unknown",
			"Constraint",
			"Data",
			"TransactionInactive",
			"ReadOnly",
			"Version",
			"NotFound",
			"InvalidState",
			"InvalidAccess",
			"Abort",
			"Timeout",
			"QuotaExceeded",
			"Syntax",
			"DataClone"
		], M = [
			"Modify",
			"Bulk",
			"OpenFailed",
			"VersionChange",
			"Schema",
			"Upgrade",
			"InvalidTable",
			"MissingAPI",
			"NoSuchDatabase",
			"InvalidArgument",
			"SubTransaction",
			"Unsupported",
			"Internal",
			"DatabaseClosed",
			"PrematureCommit",
			"ForeignAwait"
		].concat(T), ae = {
			VersionChanged: "Database version changed by other database connection",
			DatabaseClosed: "Database has been closed",
			Abort: "Transaction aborted",
			TransactionInactive: "Transaction has already completed or failed",
			MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
		};
		function N(e, t) {
			this.name = e, this.message = t;
		}
		function oe(e, t) {
			return e + ". Errors: " + Object.keys(t).map(function(e) {
				return t[e].toString();
			}).filter(function(e, t, n) {
				return n.indexOf(e) === t;
			}).join("\n");
		}
		function P(e, t, n, r) {
			this.failures = t, this.failedKeys = r, this.successCount = n, this.message = oe(e, t);
		}
		function F(e, t) {
			this.name = "BulkError", this.failures = Object.keys(t).map(function(e) {
				return t[e];
			}), this.failuresByPos = t, this.message = oe(e, this.failures);
		}
		p(N).from(Error).extend({ toString: function() {
			return this.name + ": " + this.message;
		} }), p(P).from(N), p(F).from(N);
		var se = M.reduce(function(e, t) {
			return e[t] = t + "Error", e;
		}, {}), ce = N, I = M.reduce(function(e, t) {
			var n = t + "Error";
			function r(e, r) {
				this.name = n, e ? typeof e == "string" ? (this.message = `${e}${r ? "\n " + r : ""}`, this.inner = r || null) : typeof e == "object" && (this.message = `${e.name} ${e.message}`, this.inner = e) : (this.message = ae[t] || n, this.inner = null);
			}
			return p(r).from(ce), e[t] = r, e;
		}, {}), L = (I.Syntax = SyntaxError, I.Type = TypeError, I.Range = RangeError, T.reduce(function(e, t) {
			return e[t + "Error"] = I[t], e;
		}, {}));
		T = M.reduce(function(e, t) {
			return [
				"Syntax",
				"Type",
				"Range"
			].indexOf(t) === -1 && (e[t + "Error"] = I[t]), e;
		}, {});
		function R() {}
		function le(e) {
			return e;
		}
		function ue(e, t) {
			return e == null || e === le ? t : function(n) {
				return t(e(n));
			};
		}
		function de(e, t) {
			return function() {
				e.apply(this, arguments), t.apply(this, arguments);
			};
		}
		function fe(e, t) {
			return e === R ? t : function() {
				var n = e.apply(this, arguments), r = (n !== void 0 && (arguments[0] = n), this.onsuccess), i = this.onerror, a = (this.onsuccess = null, this.onerror = null, t.apply(this, arguments));
				return r && (this.onsuccess = this.onsuccess ? de(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? de(i, this.onerror) : i), a === void 0 ? n : a;
			};
		}
		function z(e, t) {
			return e === R ? t : function() {
				e.apply(this, arguments);
				var n = this.onsuccess, r = this.onerror;
				this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? de(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? de(r, this.onerror) : r);
			};
		}
		function pe(e, t) {
			return e === R ? t : function() {
				var n = e.apply(this, arguments), r = (o(arguments[0], n), this.onsuccess), i = this.onerror, a = (this.onsuccess = null, this.onerror = null, t.apply(this, arguments));
				return r && (this.onsuccess = this.onsuccess ? de(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? de(i, this.onerror) : i), n === void 0 ? a === void 0 ? void 0 : a : o(n, a);
			};
		}
		function me(e, t) {
			return e === R ? t : function() {
				return !1 !== t.apply(this, arguments) && e.apply(this, arguments);
			};
		}
		function B(e, t) {
			return e === R ? t : function() {
				var n = e.apply(this, arguments);
				if (n && typeof n.then == "function") {
					for (var r = this, i = arguments.length, a = Array(i); i--;) a[i] = arguments[i];
					return n.then(function() {
						return t.apply(r, a);
					});
				}
				return t.apply(this, arguments);
			};
		}
		T.ModifyError = P, T.DexieError = N, T.BulkError = F;
		var he = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
		function ge(e) {
			he = e;
		}
		var _e = {}, ve = 100, ye = typeof Promise > "u" ? [] : (M = Promise.resolve(), typeof crypto < "u" && crypto.subtle ? [
			ye = crypto.subtle.digest("SHA-512", new Uint8Array([0])),
			s(ye),
			M
		] : [
			M,
			s(M),
			M
		]), M = ye[0], be = ye[1], be = be && be.then, xe = M && M.constructor, Se = !!ye[2], V = function(e, t) {
			Oe.push([e, t]), we &&= (queueMicrotask(Le), !1);
		}, Ce = !0, we = !0, Te = [], Ee = [], De = le, H = {
			id: "global",
			global: !0,
			ref: 0,
			unhandleds: [],
			onunhandled: R,
			pgp: !1,
			env: {},
			finalize: R
		}, U = H, Oe = [], ke = 0, Ae = [];
		function W(e) {
			if (typeof this != "object") throw TypeError("Promises must be constructed via new");
			this._listeners = [], this._lib = !1;
			var t = this._PSD = U;
			if (typeof e != "function") {
				if (e !== _e) throw TypeError("Not a function");
				this._state = arguments[1], this._value = arguments[2], !1 === this._state && Ne(this, this._value);
			} else this._state = null, this._value = null, ++t.ref, function e(t, n) {
				try {
					n(function(n) {
						if (t._state === null) {
							if (n === t) throw TypeError("A promise cannot be resolved with itself.");
							var r = t._lib && Re();
							n && typeof n.then == "function" ? e(t, function(e, t) {
								n instanceof W ? n._then(e, t) : n.then(e, t);
							}) : (t._state = !0, t._value = n, Pe(t)), r && ze();
						}
					}, Ne.bind(null, t));
				} catch (e) {
					Ne(t, e);
				}
			}(this, e);
		}
		var je = {
			get: function() {
				var e = U, t = Ge;
				function n(n, r) {
					var i = this, a = !e.global && (e !== U || t !== Ge), o = a && !Ye(), s = new W(function(t, s) {
						Fe(i, new Me(tt(n, e, a, o), tt(r, e, a, o), t, s, e));
					});
					return this._consoleTask && (s._consoleTask = this._consoleTask), s;
				}
				return n.prototype = _e, n;
			},
			set: function(e) {
				f(this, "then", e && e.prototype === _e ? je : {
					get: function() {
						return e;
					},
					set: je.set
				});
			}
		};
		function Me(e, t, n, r, i) {
			this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = i;
		}
		function Ne(e, t) {
			var n, r;
			Ee.push(t), e._state === null && (n = e._lib && Re(), t = De(t), e._state = !1, e._value = t, r = e, Te.some(function(e) {
				return e._value === r._value;
			}) || Te.push(r), Pe(e), n) && ze();
		}
		function Pe(e) {
			var t = e._listeners;
			e._listeners = [];
			for (var n = 0, r = t.length; n < r; ++n) Fe(e, t[n]);
			var i = e._PSD;
			--i.ref || i.finalize(), ke === 0 && (++ke, V(function() {
				--ke == 0 && Be();
			}, []));
		}
		function Fe(e, t) {
			if (e._state === null) e._listeners.push(t);
			else {
				var n = e._state ? t.onFulfilled : t.onRejected;
				if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
				++t.psd.ref, ++ke, V(Ie, [
					n,
					e,
					t
				]);
			}
		}
		function Ie(e, t, n) {
			try {
				var r, i = t._value;
				!t._state && Ee.length && (Ee = []), r = he && t._consoleTask ? t._consoleTask.run(function() {
					return e(i);
				}) : e(i), t._state || Ee.indexOf(i) !== -1 || ((e) => {
					for (var t = Te.length; t;) if (Te[--t]._value === e._value) return Te.splice(t, 1);
				})(t), n.resolve(r);
			} catch (e) {
				n.reject(e);
			} finally {
				--ke == 0 && Be(), --n.psd.ref || n.psd.finalize();
			}
		}
		function Le() {
			et(H, function() {
				Re() && ze();
			});
		}
		function Re() {
			var e = Ce;
			return we = Ce = !1, e;
		}
		function ze() {
			var e, t, n;
			do
				for (; 0 < Oe.length;) for (e = Oe, Oe = [], n = e.length, t = 0; t < n; ++t) {
					var r = e[t];
					r[0].apply(null, r[1]);
				}
			while (0 < Oe.length);
			we = Ce = !0;
		}
		function Be() {
			for (var e = Te, t = (Te = [], e.forEach(function(e) {
				e._PSD.onunhandled.call(null, e._value, e);
			}), Ae.slice(0)), n = t.length; n;) t[--n]();
		}
		function Ve(e) {
			return new W(_e, !1, e);
		}
		function G(e, t) {
			var n = U;
			return function() {
				var r = Re(), i = U;
				try {
					return Qe(n, !0), e.apply(this, arguments);
				} catch (e) {
					t && t(e);
				} finally {
					Qe(i, !1), r && ze();
				}
			};
		}
		u(W.prototype, {
			then: je,
			_then: function(e, t) {
				Fe(this, new Me(null, null, e, t, U));
			},
			catch: function(e) {
				var t, n;
				return arguments.length === 1 ? this.then(null, e) : (t = e, n = arguments[1], typeof t == "function" ? this.then(null, function(e) {
					return (e instanceof t ? n : Ve)(e);
				}) : this.then(null, function(e) {
					return (e && e.name === t ? n : Ve)(e);
				}));
			},
			finally: function(e) {
				return this.then(function(t) {
					return W.resolve(e()).then(function() {
						return t;
					});
				}, function(t) {
					return W.resolve(e()).then(function() {
						return Ve(t);
					});
				});
			},
			timeout: function(e, t) {
				var n = this;
				return e < 1 / 0 ? new W(function(r, i) {
					var a = setTimeout(function() {
						return i(new I.Timeout(t));
					}, e);
					n.then(r, i).finally(clearTimeout.bind(null, a));
				}) : this;
			}
		}), typeof Symbol < "u" && Symbol.toStringTag && f(W.prototype, Symbol.toStringTag, "Dexie.Promise"), H.env = $e(), u(W, {
			all: function() {
				var e = re.apply(null, arguments).map(Xe);
				return new W(function(t, n) {
					e.length === 0 && t([]);
					var r = e.length;
					e.forEach(function(i, a) {
						return W.resolve(i).then(function(n) {
							e[a] = n, --r || t(e);
						}, n);
					});
				});
			},
			resolve: function(e) {
				return e instanceof W ? e : e && typeof e.then == "function" ? new W(function(t, n) {
					e.then(t, n);
				}) : new W(_e, !0, e);
			},
			reject: Ve,
			race: function() {
				var e = re.apply(null, arguments).map(Xe);
				return new W(function(t, n) {
					e.map(function(e) {
						return W.resolve(e).then(t, n);
					});
				});
			},
			PSD: {
				get: function() {
					return U;
				},
				set: function(e) {
					return U = e;
				}
			},
			totalEchoes: { get: function() {
				return Ge;
			} },
			newPSD: qe,
			usePSD: et,
			scheduler: {
				get: function() {
					return V;
				},
				set: function(e) {
					V = e;
				}
			},
			rejectionMapper: {
				get: function() {
					return De;
				},
				set: function(e) {
					De = e;
				}
			},
			follow: function(e, t) {
				return new W(function(n, r) {
					return qe(function(t, n) {
						var r = U;
						r.unhandleds = [], r.onunhandled = n, r.finalize = de(function() {
							var e, r = this;
							e = function() {
								r.unhandleds.length === 0 ? t() : n(r.unhandleds[0]);
							}, Ae.push(function t() {
								e(), Ae.splice(Ae.indexOf(t), 1);
							}), ++ke, V(function() {
								--ke == 0 && Be();
							}, []);
						}, r.finalize), e();
					}, t, n, r);
				});
			}
		}), xe && (xe.allSettled && f(W, "allSettled", function() {
			var e = re.apply(null, arguments).map(Xe);
			return new W(function(t) {
				e.length === 0 && t([]);
				var n = e.length, r = Array(n);
				e.forEach(function(e, i) {
					return W.resolve(e).then(function(e) {
						return r[i] = {
							status: "fulfilled",
							value: e
						};
					}, function(e) {
						return r[i] = {
							status: "rejected",
							reason: e
						};
					}).then(function() {
						return --n || t(r);
					});
				});
			});
		}), xe.any && typeof AggregateError < "u" && f(W, "any", function() {
			var e = re.apply(null, arguments).map(Xe);
			return new W(function(t, n) {
				e.length === 0 && n(/* @__PURE__ */ AggregateError([]));
				var r = e.length, i = Array(r);
				e.forEach(function(e, a) {
					return W.resolve(e).then(function(e) {
						return t(e);
					}, function(e) {
						i[a] = e, --r || n(AggregateError(i));
					});
				});
			});
		}), xe.withResolvers) && (W.withResolvers = xe.withResolvers);
		var He = {
			awaits: 0,
			echoes: 0,
			id: 0
		}, Ue = 0, K = [], We = 0, Ge = 0, Ke = 0;
		function qe(e, t, n, r) {
			var i = U, a = Object.create(i), t = (a.parent = i, a.ref = 0, a.global = !1, a.id = ++Ke, H.env, a.env = Se ? {
				Promise: W,
				PromiseProp: {
					value: W,
					configurable: !0,
					writable: !0
				},
				all: W.all,
				race: W.race,
				allSettled: W.allSettled,
				any: W.any,
				resolve: W.resolve,
				reject: W.reject
			} : {}, t && o(a, t), ++i.ref, a.finalize = function() {
				--this.parent.ref || this.parent.finalize();
			}, et(a, e, n, r));
			return a.ref === 0 && a.finalize(), t;
		}
		function Je() {
			return He.id ||= ++Ue, ++He.awaits, He.echoes += ve, He.id;
		}
		function Ye() {
			return !!He.awaits && (--He.awaits == 0 && (He.id = 0), He.echoes = He.awaits * ve, !0);
		}
		function Xe(e) {
			return He.echoes && e && e.constructor === xe ? (Je(), e.then(function(e) {
				return Ye(), e;
			}, function(e) {
				return Ye(), rt(e);
			})) : e;
		}
		function Ze() {
			var e = K[K.length - 1];
			K.pop(), Qe(e, !1);
		}
		function Qe(e, t) {
			var n, i, a = U;
			(t ? !He.echoes || We++ && e === U : !We || --We && e === U) || queueMicrotask(t ? function(e) {
				++Ge, He.echoes && --He.echoes != 0 || (He.echoes = He.awaits = He.id = 0), K.push(U), Qe(e, !0);
			}.bind(null, e) : Ze), e !== U && (U = e, a === H && (H.env = $e()), Se) && (n = H.env.Promise, i = e.env, a.global || e.global) && (Object.defineProperty(r, "Promise", i.PromiseProp), n.all = i.all, n.race = i.race, n.resolve = i.resolve, n.reject = i.reject, i.allSettled && (n.allSettled = i.allSettled), i.any) && (n.any = i.any);
		}
		function $e() {
			var e = r.Promise;
			return Se ? {
				Promise: e,
				PromiseProp: Object.getOwnPropertyDescriptor(r, "Promise"),
				all: e.all,
				race: e.race,
				allSettled: e.allSettled,
				any: e.any,
				resolve: e.resolve,
				reject: e.reject
			} : {};
		}
		function et(e, t, n, r, i) {
			var a = U;
			try {
				return Qe(e, !0), t(n, r, i);
			} finally {
				Qe(a, !1);
			}
		}
		function tt(e, t, n, r) {
			return typeof e == "function" ? function() {
				var i = U;
				n && Je(), Qe(t, !0);
				try {
					return e.apply(this, arguments);
				} finally {
					Qe(i, !1), r && queueMicrotask(Ye);
				}
			} : e;
		}
		function nt(e) {
			Promise === xe && He.echoes === 0 ? We === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0);
		}
		("" + be).indexOf("[native code]") === -1 && (Je = Ye = R);
		var rt = W.reject, it = "￿", at = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", ot = "String expected.", st = "__dbnames", ct = "readonly", lt = "readwrite";
		function ut(e, t) {
			return e ? t ? function() {
				return e.apply(this, arguments) && t.apply(this, arguments);
			} : e : t;
		}
		var dt = {
			type: 3,
			lower: -1 / 0,
			lowerOpen: !1,
			upper: [[]],
			upperOpen: !1
		};
		function ft(e) {
			return typeof e != "string" || /\./.test(e) ? function(e) {
				return e;
			} : function(t) {
				return t[e] === void 0 && e in t && delete (t = O(t))[e], t;
			};
		}
		function pt() {
			throw I.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
		}
		function q(e, t) {
			try {
				var n = mt(e), r = mt(t);
				if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r === "Date" ? -1 : NaN;
				switch (n) {
					case "number":
					case "Date":
					case "string": return t < e ? 1 : e < t ? -1 : 0;
					case "binary":
						for (var i = ht(e), a = ht(t), o = i.length, s = a.length, c = o < s ? o : s, l = 0; l < c; ++l) if (i[l] !== a[l]) return i[l] < a[l] ? -1 : 1;
						return o === s ? 0 : o < s ? -1 : 1;
					case "Array":
						for (var u = e, d = t, f = u.length, p = d.length, m = f < p ? f : p, h = 0; h < m; ++h) {
							var g = q(u[h], d[h]);
							if (g !== 0) return g;
						}
						return f === p ? 0 : f < p ? -1 : 1;
				}
			} catch {}
			return NaN;
		}
		function mt(e) {
			var t = typeof e;
			return t == "object" && (ArrayBuffer.isView(e) || (t = ee(e)) === "ArrayBuffer") ? "binary" : t;
		}
		function ht(e) {
			return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
		}
		function gt(e, t, n) {
			var r = e.schema.yProps;
			return r ? (t && 0 < n.numFailures && (t = t.filter(function(e, t) {
				return !n.failures[t];
			})), Promise.all(r.map(function(n) {
				return n = n.updatesTable, t ? e.db.table(n).where("k").anyOf(t).delete() : e.db.table(n).clear();
			})).then(function() {
				return n;
			})) : n;
		}
		vt.prototype.execute = function(e) {
			var t = this["@@propmod"];
			if (t.add !== void 0) {
				var r = t.add;
				if (a(r)) return n(n([], a(e) ? e : [], !0), r, !0).sort();
				if (typeof r == "number") return (Number(e) || 0) + r;
				if (typeof r == "bigint") try {
					return BigInt(e) + r;
				} catch {
					return BigInt(0) + r;
				}
				throw TypeError(`Invalid term ${r}`);
			}
			if (t.remove !== void 0) {
				var i = t.remove;
				if (a(i)) return a(e) ? e.filter(function(e) {
					return !i.includes(e);
				}).sort() : [];
				if (typeof i == "number") return Number(e) - i;
				if (typeof i == "bigint") try {
					return BigInt(e) - i;
				} catch {
					return BigInt(0) - i;
				}
				throw TypeError(`Invalid subtrahend ${i}`);
			}
			return r = (r = t.replacePrefix)?.[0], r && typeof e == "string" && e.startsWith(r) ? t.replacePrefix[1] + e.substring(r.length) : e;
		};
		var _t = vt;
		function vt(e) {
			this["@@propmod"] = e;
		}
		function yt(e, t) {
			for (var n = i(t), r = n.length, a = !1, o = 0; o < r; ++o) {
				var s = n[o], c = t[s], l = b(e, s);
				c instanceof _t ? (x(e, s, c.execute(l)), a = !0) : l !== c && (x(e, s, c), a = !0);
			}
			return a;
		}
		J.prototype._trans = function(e, t, n) {
			var r = this._tx || U.trans, i = this.name, a = he && typeof console < "u" && console.createTask && console.createTask(`Dexie: ${e === "readonly" ? "read" : "write"} ${this.name}`);
			function o(e, n, r) {
				if (r.schema[i]) return t(r.idbtrans, r);
				throw new I.NotFound("Table " + i + " not part of transaction");
			}
			var s = Re();
			try {
				var c = r && r.db._novip === this.db._novip ? r === U.trans ? r._promise(e, o, n) : qe(function() {
					return r._promise(e, o, n);
				}, {
					trans: r,
					transless: U.transless || U
				}) : function e(t, n, r, i) {
					if (t.idbdb && (t._state.openComplete || U.letThrough || t._vip)) {
						var a = t._createTransaction(n, r, t._dbSchema);
						try {
							a.create(), t._state.PR1398_maxLoop = 3;
						} catch (a) {
							return a.name === se.InvalidState && t.isOpen() && 0 < --t._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), t.close({ disableAutoOpen: !1 }), t.open().then(function() {
								return e(t, n, r, i);
							})) : rt(a);
						}
						return a._promise(n, function(e, t) {
							return qe(function() {
								return U.trans = a, i(e, t, a);
							});
						}).then(function(e) {
							if (n === "readwrite") try {
								a.idbtrans.commit();
							} catch {}
							return n === "readonly" ? e : a._completion.then(function() {
								return e;
							});
						});
					}
					if (t._state.openComplete) return rt(new I.DatabaseClosed(t._state.dbOpenError));
					if (!t._state.isBeingOpened) {
						if (!t._state.autoOpen) return rt(new I.DatabaseClosed());
						t.open().catch(R);
					}
					return t._state.dbReadyPromise.then(function() {
						return e(t, n, r, i);
					});
				}(this.db, e, [this.name], o);
				return a && (c._consoleTask = a, c = c.catch(function(e) {
					return console.trace(e), rt(e);
				})), c;
			} finally {
				s && ze();
			}
		}, J.prototype.get = function(e, t) {
			var n = this;
			return e && e.constructor === Object ? this.where(e).first(t) : e == null ? rt(new I.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(t) {
				return n.core.get({
					trans: t,
					key: e
				}).then(function(e) {
					return n.hook.reading.fire(e);
				});
			}).then(t);
		}, J.prototype.where = function(e) {
			if (typeof e == "string") return new this.db.WhereClause(this, e);
			if (a(e)) return new this.db.WhereClause(this, `[${e.join("+")}]`);
			var t = i(e);
			if (t.length === 1) return this.where(t[0]).equals(e[t[0]]);
			var n = this.schema.indexes.concat(this.schema.primKey).filter(function(e) {
				if (e.compound && t.every(function(t) {
					return 0 <= e.keyPath.indexOf(t);
				})) {
					for (var n = 0; n < t.length; ++n) if (t.indexOf(e.keyPath[n]) === -1) return !1;
					return !0;
				}
				return !1;
			}).sort(function(e, t) {
				return e.keyPath.length - t.keyPath.length;
			})[0];
			if (n && this.db._maxKey !== it) return s = n.keyPath.slice(0, t.length), this.where(s).equals(s.map(function(t) {
				return e[t];
			}));
			!n && he && console.warn(`The query ${JSON.stringify(e)} on ${this.name} would benefit from a compound index [${t.join("+")}]`);
			var r = this.schema.idxByName;
			function o(e, t) {
				return q(e, t) === 0;
			}
			var s = t.reduce(function(t, n) {
				var i = t[0], t = t[1], s = r[n], c = e[n];
				return [i || s, i || !s ? ut(t, s && s.multi ? function(e) {
					return e = b(e, n), a(e) && e.some(function(e) {
						return o(c, e);
					});
				} : function(e) {
					return o(c, b(e, n));
				}) : t];
			}, [null, null]), c = s[0], s = s[1];
			return c ? this.where(c.name).equals(e[c.keyPath]).filter(s) : n ? this.filter(s) : this.where(t).equals("");
		}, J.prototype.filter = function(e) {
			return this.toCollection().and(e);
		}, J.prototype.count = function(e) {
			return this.toCollection().count(e);
		}, J.prototype.offset = function(e) {
			return this.toCollection().offset(e);
		}, J.prototype.limit = function(e) {
			return this.toCollection().limit(e);
		}, J.prototype.each = function(e) {
			return this.toCollection().each(e);
		}, J.prototype.toArray = function(e) {
			return this.toCollection().toArray(e);
		}, J.prototype.toCollection = function() {
			return new this.db.Collection(new this.db.WhereClause(this));
		}, J.prototype.orderBy = function(e) {
			return new this.db.Collection(new this.db.WhereClause(this, a(e) ? `[${e.join("+")}]` : e));
		}, J.prototype.reverse = function() {
			return this.toCollection().reverse();
		}, J.prototype.mapToClass = function(t) {
			for (var n = this.db, r = this.name, i = ((this.schema.mappedClass = t).prototype instanceof pt && (t = ((t) => {
				var i = s, a = t;
				if (typeof a != "function" && a !== null) throw TypeError("Class extends value " + String(a) + " is not a constructor or null");
				function o() {
					this.constructor = i;
				}
				function s() {
					return t !== null && t.apply(this, arguments) || this;
				}
				return e(i, a), i.prototype = a === null ? Object.create(a) : (o.prototype = a.prototype, new o()), Object.defineProperty(s.prototype, "db", {
					get: function() {
						return n;
					},
					enumerable: !1,
					configurable: !0
				}), s.prototype.table = function() {
					return r;
				}, s;
			})(t)), /* @__PURE__ */ new Set()), a = t.prototype; a; a = s(a)) Object.getOwnPropertyNames(a).forEach(function(e) {
				return i.add(e);
			});
			function o(e) {
				if (!e) return e;
				var n, r = Object.create(t.prototype);
				for (n in e) if (!i.has(n)) try {
					r[n] = e[n];
				} catch {}
				return r;
			}
			return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = o, this.hook("reading", o), t;
		}, J.prototype.defineClass = function() {
			return this.mapToClass(function(e) {
				o(this, e);
			});
		}, J.prototype.add = function(e, t) {
			var n = this, r = this.schema.primKey, i = r.auto, a = r.keyPath, o = e;
			return a && i && (o = ft(a)(e)), this._trans("readwrite", function(e) {
				return n.core.mutate({
					trans: e,
					type: "add",
					keys: t == null ? null : [t],
					values: [o]
				});
			}).then(function(e) {
				return e.numFailures ? W.reject(e.failures[0]) : e.lastResult;
			}).then(function(t) {
				if (a) try {
					x(e, a, t);
				} catch {}
				return t;
			});
		}, J.prototype.upsert = function(e, t) {
			var n = this, r = this.schema.primKey.keyPath;
			return this._trans("readwrite", function(i) {
				return n.core.get({
					trans: i,
					key: e
				}).then(function(a) {
					var o = a ?? {};
					return yt(o, t), r && x(o, r, e), n.core.mutate({
						trans: i,
						type: "put",
						values: [o],
						keys: [e],
						upsert: !0,
						updates: {
							keys: [e],
							changeSpecs: [t]
						}
					}).then(function(e) {
						return e.numFailures ? W.reject(e.failures[0]) : !!a;
					});
				});
			});
		}, J.prototype.update = function(e, t) {
			return typeof e != "object" || a(e) ? this.where(":id").equals(e).modify(t) : (e = b(e, this.schema.primKey.keyPath)) === void 0 ? rt(new I.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(t);
		}, J.prototype.put = function(e, t) {
			var n = this, r = this.schema.primKey, i = r.auto, a = r.keyPath, o = e;
			return a && i && (o = ft(a)(e)), this._trans("readwrite", function(e) {
				return n.core.mutate({
					trans: e,
					type: "put",
					values: [o],
					keys: t == null ? null : [t]
				});
			}).then(function(e) {
				return e.numFailures ? W.reject(e.failures[0]) : e.lastResult;
			}).then(function(t) {
				if (a) try {
					x(e, a, t);
				} catch {}
				return t;
			});
		}, J.prototype.delete = function(e) {
			var t = this;
			return this._trans("readwrite", function(n) {
				return t.core.mutate({
					trans: n,
					type: "delete",
					keys: [e]
				}).then(function(n) {
					return gt(t, [e], n);
				}).then(function(e) {
					return e.numFailures ? W.reject(e.failures[0]) : void 0;
				});
			});
		}, J.prototype.clear = function() {
			var e = this;
			return this._trans("readwrite", function(t) {
				return e.core.mutate({
					trans: t,
					type: "deleteRange",
					range: dt
				}).then(function(t) {
					return gt(e, null, t);
				});
			}).then(function(e) {
				return e.numFailures ? W.reject(e.failures[0]) : void 0;
			});
		}, J.prototype.bulkGet = function(e) {
			var t = this;
			return this._trans("readonly", function(n) {
				return t.core.getMany({
					keys: e,
					trans: n
				}).then(function(e) {
					return e.map(function(e) {
						return t.hook.reading.fire(e);
					});
				});
			});
		}, J.prototype.bulkAdd = function(e, t, n) {
			var r = this, i = Array.isArray(t) ? t : void 0, a = (n ||= i ? void 0 : t) ? n.allKeys : void 0;
			return this._trans("readwrite", function(t) {
				var n = r.schema.primKey, o = n.auto, n = n.keyPath;
				if (n && i) throw new I.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
				if (i && i.length !== e.length) throw new I.InvalidArgument("Arguments objects and keys must have the same length");
				var s = e.length, o = n && o ? e.map(ft(n)) : e;
				return r.core.mutate({
					trans: t,
					type: "add",
					keys: i,
					values: o,
					wantResults: a
				}).then(function(e) {
					var t = e.numFailures, n = e.failures;
					if (t === 0) return a ? e.results : e.lastResult;
					throw new F(`${r.name}.bulkAdd(): ${t} of ${s} operations failed`, n);
				});
			});
		}, J.prototype.bulkPut = function(e, t, n) {
			var r = this, i = Array.isArray(t) ? t : void 0, a = (n ||= i ? void 0 : t) ? n.allKeys : void 0;
			return this._trans("readwrite", function(t) {
				var n = r.schema.primKey, o = n.auto, n = n.keyPath;
				if (n && i) throw new I.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
				if (i && i.length !== e.length) throw new I.InvalidArgument("Arguments objects and keys must have the same length");
				var s = e.length, o = n && o ? e.map(ft(n)) : e;
				return r.core.mutate({
					trans: t,
					type: "put",
					keys: i,
					values: o,
					wantResults: a
				}).then(function(e) {
					var t = e.numFailures, n = e.failures;
					if (t === 0) return a ? e.results : e.lastResult;
					throw new F(`${r.name}.bulkPut(): ${t} of ${s} operations failed`, n);
				});
			});
		}, J.prototype.bulkUpdate = function(e) {
			var t = this, n = this.core, r = e.map(function(e) {
				return e.key;
			}), i = e.map(function(e) {
				return e.changes;
			}), a = [];
			return this._trans("readwrite", function(o) {
				return n.getMany({
					trans: o,
					keys: r,
					cache: "clone"
				}).then(function(s) {
					var c = [], l = [], u = (e.forEach(function(e, n) {
						var r = e.key, i = e.changes, o = s[n];
						if (o) {
							for (var u = 0, d = Object.keys(i); u < d.length; u++) {
								var f = d[u], p = i[f];
								if (f === t.schema.primKey.keyPath) {
									if (q(p, r) !== 0) throw new I.Constraint("Cannot update primary key in bulkUpdate()");
								} else x(o, f, p);
							}
							a.push(n), c.push(r), l.push(o);
						}
					}), c.length);
					return n.mutate({
						trans: o,
						type: "put",
						keys: c,
						values: l,
						updates: {
							keys: r,
							changeSpecs: i
						}
					}).then(function(e) {
						var n = e.numFailures, r = e.failures;
						if (n === 0) return u;
						for (var i = 0, o = Object.keys(r); i < o.length; i++) {
							var s, c = o[i], l = a[Number(c)];
							l != null && (s = r[c], delete r[c], r[l] = s);
						}
						throw new F(`${t.name}.bulkUpdate(): ${n} of ${u} operations failed`, r);
					});
				});
			});
		}, J.prototype.bulkDelete = function(e) {
			var t = this, n = e.length;
			return this._trans("readwrite", function(n) {
				return t.core.mutate({
					trans: n,
					type: "delete",
					keys: e
				}).then(function(n) {
					return gt(t, e, n);
				});
			}).then(function(e) {
				var r = e.numFailures, i = e.failures;
				if (r === 0) return e.lastResult;
				throw new F(`${t.name}.bulkDelete(): ${r} of ${n} operations failed`, i);
			});
		};
		var bt = J;
		function J() {}
		function xt(e) {
			function t(t, r) {
				if (r) {
					for (var i = arguments.length, a = Array(i - 1); --i;) a[i - 1] = arguments[i];
					return n[t].subscribe.apply(null, a), e;
				}
				if (typeof t == "string") return n[t];
			}
			var n = {};
			t.addEventType = s;
			for (var r = 1, o = arguments.length; r < o; ++r) s(arguments[r]);
			return t;
			function s(e, r, o) {
				var c, l;
				if (typeof e != "object") return r ||= me, l = {
					subscribers: [],
					fire: o ||= R,
					subscribe: function(e) {
						l.subscribers.indexOf(e) === -1 && (l.subscribers.push(e), l.fire = r(l.fire, e));
					},
					unsubscribe: function(e) {
						l.subscribers = l.subscribers.filter(function(t) {
							return t !== e;
						}), l.fire = l.subscribers.reduce(r, o);
					}
				}, n[e] = t[e] = l;
				i(c = e).forEach(function(e) {
					var t = c[e];
					if (a(t)) s(e, c[e][0], c[e][1]);
					else {
						if (t !== "asap") throw new I.InvalidArgument("Invalid event config");
						var n = s(e, le, function() {
							for (var e = arguments.length, t = Array(e); e--;) t[e] = arguments[e];
							n.subscribers.forEach(function(e) {
								y(function() {
									e.apply(null, t);
								});
							});
						});
					}
				});
			}
		}
		function St(e, t) {
			return p(t).from({ prototype: e }), t;
		}
		function Ct(e, t) {
			return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter);
		}
		function wt(e, t) {
			e.filter = ut(e.filter, t);
		}
		function Tt(e, t, n) {
			var r = e.replayFilter;
			e.replayFilter = r ? function() {
				return ut(r(), t());
			} : t, e.justLimit = n && !r;
		}
		function Et(e, t) {
			if (e.isPrimKey) return t.primaryKey;
			var n = t.getIndexByKeyPath(e.index);
			if (n) return n;
			throw new I.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
		}
		function Dt(e, t, n) {
			var r = Et(e, t.schema);
			return t.openCursor({
				trans: n,
				values: !e.keysOnly,
				reverse: e.dir === "prev",
				unique: !!e.unique,
				query: {
					index: r,
					range: e.range
				}
			});
		}
		function Ot(e, t, n, r) {
			var i, a, o = e.replayFilter ? ut(e.filter, e.replayFilter()) : e.filter;
			return e.or ? (i = {}, a = function(e, n, r) {
				var a, s;
				o && !o(n, r, function(e) {
					return n.stop(e);
				}, function(e) {
					return n.fail(e);
				}) || ((s = "" + (a = n.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(a)), l(i, s)) || (i[s] = !0, t(e, n, r));
			}, Promise.all([e.or._iterate(a, n), kt(Dt(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)])) : kt(Dt(e, r, n), ut(e.algorithm, o), t, !e.keysOnly && e.valueMapper);
		}
		function kt(e, t, n, r) {
			var i = G(r ? function(e, t, i) {
				return n(r(e), t, i);
			} : n);
			return e.then(function(e) {
				if (e) return e.start(function() {
					var n = function() {
						return e.continue();
					};
					t && !t(e, function(e) {
						return n = e;
					}, function(t) {
						e.stop(t), n = R;
					}, function(t) {
						e.fail(t), n = R;
					}) || i(e.value, e, function(e) {
						return n = e;
					}), n();
				});
			});
		}
		Y.prototype._read = function(e, t) {
			var n = this._ctx;
			return n.error ? n.table._trans(null, rt.bind(null, n.error)) : n.table._trans("readonly", e).then(t);
		}, Y.prototype._write = function(e) {
			var t = this._ctx;
			return t.error ? t.table._trans(null, rt.bind(null, t.error)) : t.table._trans("readwrite", e, "locked");
		}, Y.prototype._addAlgorithm = function(e) {
			var t = this._ctx;
			t.algorithm = ut(t.algorithm, e);
		}, Y.prototype._iterate = function(e, t) {
			return Ot(this._ctx, e, t, this._ctx.table.core);
		}, Y.prototype.clone = function(e) {
			var t = Object.create(this.constructor.prototype), n = Object.create(this._ctx);
			return e && o(n, e), t._ctx = n, t;
		}, Y.prototype.raw = function() {
			return this._ctx.valueMapper = null, this;
		}, Y.prototype.each = function(e) {
			var t = this._ctx;
			return this._read(function(n) {
				return Ot(t, e, n, t.table.core);
			});
		}, Y.prototype.count = function(e) {
			var t = this;
			return this._read(function(e) {
				var n, r = t._ctx, i = r.table.core;
				return Ct(r, !0) ? i.count({
					trans: e,
					query: {
						index: Et(r, i.schema),
						range: r.range
					}
				}).then(function(e) {
					return Math.min(e, r.limit);
				}) : (n = 0, Ot(r, function() {
					return ++n, !1;
				}, e, i).then(function() {
					return n;
				}));
			}).then(e);
		}, Y.prototype.sortBy = function(e, t) {
			var n = e.split(".").reverse(), r = n[0], i = n.length - 1;
			function a(e, t) {
				return t ? a(e[n[t]], t - 1) : e[r];
			}
			var o = this._ctx.dir === "next" ? 1 : -1;
			function s(e, t) {
				return q(a(e, i), a(t, i)) * o;
			}
			return this.toArray(function(e) {
				return e.slice().sort(s);
			}).then(t);
		}, Y.prototype.toArray = function(e) {
			var t = this;
			return this._read(function(e) {
				var n, r, i, a = t._ctx;
				return Ct(a, !0) && 0 < a.limit ? (n = a.valueMapper, r = Et(a, a.table.core.schema), a.table.core.query({
					trans: e,
					limit: a.limit,
					values: !0,
					direction: a.dir === "prev" ? "prev" : void 0,
					query: {
						index: r,
						range: a.range
					}
				}).then(function(e) {
					return e = e.result, n ? e.map(n) : e;
				})) : (i = [], Ot(a, function(e) {
					return i.push(e);
				}, e, a.table.core).then(function() {
					return i;
				}));
			}, e);
		}, Y.prototype.offset = function(e) {
			var t = this._ctx;
			return e <= 0 || (t.offset += e, Ct(t) ? Tt(t, function() {
				var t = e;
				return function(e, n) {
					return t === 0 || (t === 1 ? --t : n(function() {
						e.advance(t), t = 0;
					}), !1);
				};
			}) : Tt(t, function() {
				var t = e;
				return function() {
					return --t < 0;
				};
			})), this;
		}, Y.prototype.limit = function(e) {
			return this._ctx.limit = Math.min(this._ctx.limit, e), Tt(this._ctx, function() {
				var t = e;
				return function(e, n, r) {
					return --t <= 0 && n(r), 0 <= t;
				};
			}, !0), this;
		}, Y.prototype.until = function(e, t) {
			return wt(this._ctx, function(n, r, i) {
				return !e(n.value) || (r(i), t);
			}), this;
		}, Y.prototype.first = function(e) {
			return this.limit(1).toArray(function(e) {
				return e[0];
			}).then(e);
		}, Y.prototype.last = function(e) {
			return this.reverse().first(e);
		}, Y.prototype.filter = function(e) {
			var t;
			return wt(this._ctx, function(t) {
				return e(t.value);
			}), (t = this._ctx).isMatch = ut(t.isMatch, e), this;
		}, Y.prototype.and = function(e) {
			return this.filter(e);
		}, Y.prototype.or = function(e) {
			return new this.db.WhereClause(this._ctx.table, e, this);
		}, Y.prototype.reverse = function() {
			return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
		}, Y.prototype.desc = function() {
			return this.reverse();
		}, Y.prototype.eachKey = function(e) {
			var t = this._ctx;
			return t.keysOnly = !t.isMatch, this.each(function(t, n) {
				e(n.key, n);
			});
		}, Y.prototype.eachUniqueKey = function(e) {
			return this._ctx.unique = "unique", this.eachKey(e);
		}, Y.prototype.eachPrimaryKey = function(e) {
			var t = this._ctx;
			return t.keysOnly = !t.isMatch, this.each(function(t, n) {
				e(n.primaryKey, n);
			});
		}, Y.prototype.keys = function(e) {
			var t = this._ctx, n = (t.keysOnly = !t.isMatch, []);
			return this.each(function(e, t) {
				n.push(t.key);
			}).then(function() {
				return n;
			}).then(e);
		}, Y.prototype.primaryKeys = function(e) {
			var t = this._ctx;
			if (Ct(t, !0) && 0 < t.limit) return this._read(function(e) {
				var n = Et(t, t.table.core.schema);
				return t.table.core.query({
					trans: e,
					values: !1,
					limit: t.limit,
					direction: t.dir === "prev" ? "prev" : void 0,
					query: {
						index: n,
						range: t.range
					}
				});
			}).then(function(e) {
				return e.result;
			}).then(e);
			t.keysOnly = !t.isMatch;
			var n = [];
			return this.each(function(e, t) {
				n.push(t.primaryKey);
			}).then(function() {
				return n;
			}).then(e);
		}, Y.prototype.uniqueKeys = function(e) {
			return this._ctx.unique = "unique", this.keys(e);
		}, Y.prototype.firstKey = function(e) {
			return this.limit(1).keys(function(e) {
				return e[0];
			}).then(e);
		}, Y.prototype.lastKey = function(e) {
			return this.reverse().firstKey(e);
		}, Y.prototype.distinct = function() {
			var e, t = this._ctx, t = t.index && t.table.schema.idxByName[t.index];
			return t && t.multi && (e = {}, wt(this._ctx, function(t) {
				var t = t.primaryKey.toString(), n = l(e, t);
				return e[t] = !0, !n;
			})), this;
		}, Y.prototype.modify = function(e) {
			var t = this, n = this._ctx;
			return this._write(function(r) {
				function a(e, t) {
					var n = t.failures;
					p += e - t.numFailures;
					for (var r = 0, a = i(n); r < a.length; r++) {
						var o = a[r];
						f.push(n[o]);
					}
				}
				var o = typeof e == "function" ? e : function(t) {
					return yt(t, e);
				}, s = n.table.core, c = s.schema.primaryKey, l = c.outbound, u = c.extractKey, d = 200, c = t.db._options.modifyChunkSize, f = (c && (d = typeof c == "object" ? c[s.name] || c["*"] || 200 : c), []), p = 0, m = [], h = e === jt;
				return t.clone().primaryKeys().then(function(t) {
					function i(f) {
						var p = Math.min(d, t.length - f), m = t.slice(f, f + p);
						return (h ? Promise.resolve([]) : s.getMany({
							trans: r,
							keys: m,
							cache: "immutable"
						})).then(function(g) {
							var _ = [], v = [], y = l ? [] : null, b = h ? m : [];
							if (!h) for (var x = 0; x < p; ++x) {
								var S = g[x], C = {
									value: O(S),
									primKey: t[f + x]
								};
								!1 !== o.call(C, C.value, C) && (C.value == null ? b.push(t[f + x]) : l || q(u(S), u(C.value)) === 0 ? (v.push(C.value), l && y.push(t[f + x])) : (b.push(t[f + x]), _.push(C.value)));
							}
							return Promise.resolve(0 < _.length && s.mutate({
								trans: r,
								type: "add",
								values: _
							}).then(function(e) {
								for (var t in e.failures) b.splice(parseInt(t), 1);
								a(_.length, e);
							})).then(function() {
								return (0 < v.length || c && typeof e == "object") && s.mutate({
									trans: r,
									type: "put",
									keys: y,
									values: v,
									criteria: c,
									changeSpec: typeof e != "function" && e,
									isAdditionalChunk: 0 < f
								}).then(function(e) {
									return a(v.length, e);
								});
							}).then(function() {
								return (0 < b.length || c && h) && s.mutate({
									trans: r,
									type: "delete",
									keys: b,
									criteria: c,
									isAdditionalChunk: 0 < f
								}).then(function(e) {
									return gt(n.table, b, e);
								}).then(function(e) {
									return a(b.length, e);
								});
							}).then(function() {
								return t.length > f + p && i(f + d);
							});
						});
					}
					var c = Ct(n) && n.limit === 1 / 0 && (typeof e != "function" || h) && {
						index: n.index,
						range: n.range
					};
					return i(0).then(function() {
						if (0 < f.length) throw new P("Error modifying one or more objects", f, p, m);
						return t.length;
					});
				});
			});
		}, Y.prototype.delete = function() {
			var e = this._ctx, t = e.range;
			return !Ct(e) || e.table.schema.yProps || !e.isPrimKey && t.type !== 3 ? this.modify(jt) : this._write(function(n) {
				var r = e.table.core.schema.primaryKey, i = t;
				return e.table.core.count({
					trans: n,
					query: {
						index: r,
						range: i
					}
				}).then(function(t) {
					return e.table.core.mutate({
						trans: n,
						type: "deleteRange",
						range: i
					}).then(function(e) {
						var n = e.failures, e = e.numFailures;
						if (e) throw new P("Could not delete some values", Object.keys(n).map(function(e) {
							return n[e];
						}), t - e);
						return t - e;
					});
				});
			});
		};
		var At = Y;
		function Y() {}
		var jt = function(e, t) {
			return t.value = null;
		};
		function Mt(e, t) {
			return e < t ? -1 : e === t ? 0 : 1;
		}
		function Nt(e, t) {
			return t < e ? -1 : e === t ? 0 : 1;
		}
		function Pt(e, t, n) {
			return e = e instanceof zt ? new e.Collection(e) : e, e._ctx.error = new (n || TypeError)(t), e;
		}
		function Ft(e) {
			return new e.Collection(e, function() {
				return Rt("");
			}).limit(0);
		}
		function It(e, t, n, r) {
			var i, a, o, s, c, l, u, d = n.length;
			if (!n.every(function(e) {
				return typeof e == "string";
			})) return Pt(e, ot);
			function f(e) {
				i = e === "next" ? function(e) {
					return e.toUpperCase();
				} : function(e) {
					return e.toLowerCase();
				}, a = e === "next" ? function(e) {
					return e.toLowerCase();
				} : function(e) {
					return e.toUpperCase();
				}, o = e === "next" ? Mt : Nt;
				var t = n.map(function(e) {
					return {
						lower: a(e),
						upper: i(e)
					};
				}).sort(function(e, t) {
					return o(e.lower, t.lower);
				});
				s = t.map(function(e) {
					return e.upper;
				}), c = t.map(function(e) {
					return e.lower;
				}), u = (l = e) === "next" ? "" : r;
			}
			f("next");
			var e = new e.Collection(e, function() {
				return Lt(s[0], c[d - 1] + r);
			}), p = (e._ondirectionchange = function(e) {
				f(e);
			}, 0);
			return e._addAlgorithm(function(e, n, r) {
				var i = e.key;
				if (typeof i == "string") {
					var f = a(i);
					if (t(f, c, p)) return !0;
					for (var m = null, h = p; h < d; ++h) {
						var g = ((e, t, n, r, i, a) => {
							for (var o = Math.min(e.length, r.length), s = -1, c = 0; c < o; ++c) {
								var l = t[c];
								if (l !== r[c]) return i(e[c], n[c]) < 0 ? e.substr(0, c) + n[c] + n.substr(c + 1) : i(e[c], r[c]) < 0 ? e.substr(0, c) + r[c] + n.substr(c + 1) : 0 <= s ? e.substr(0, s) + t[s] + n.substr(s + 1) : null;
								i(e[c], l) < 0 && (s = c);
							}
							return o < r.length && a === "next" ? e + n.substr(e.length) : o < e.length && a === "prev" ? e.substr(0, n.length) : s < 0 ? null : e.substr(0, s) + r[s] + n.substr(s + 1);
						})(i, f, s[h], c[h], o, l);
						g === null && m === null ? p = h + 1 : (m === null || 0 < o(m, g)) && (m = g);
					}
					n(m === null ? r : function() {
						e.continue(m + u);
					});
				}
				return !1;
			}), e;
		}
		function Lt(e, t, n, r) {
			return {
				type: 2,
				lower: e,
				upper: t,
				lowerOpen: n,
				upperOpen: r
			};
		}
		function Rt(e) {
			return {
				type: 1,
				lower: e,
				upper: e
			};
		}
		Object.defineProperty(Bt.prototype, "Collection", {
			get: function() {
				return this._ctx.table.db.Collection;
			},
			enumerable: !1,
			configurable: !0
		}), Bt.prototype.between = function(e, t, n, r) {
			n = !1 !== n, r = !0 === r;
			try {
				return 0 < this._cmp(e, t) || this._cmp(e, t) === 0 && (n || r) && (!n || !r) ? Ft(this) : new this.Collection(this, function() {
					return Lt(e, t, !n, !r);
				});
			} catch {
				return Pt(this, at);
			}
		}, Bt.prototype.equals = function(e) {
			return e == null ? Pt(this, at) : new this.Collection(this, function() {
				return Rt(e);
			});
		}, Bt.prototype.above = function(e) {
			return e == null ? Pt(this, at) : new this.Collection(this, function() {
				return Lt(e, void 0, !0);
			});
		}, Bt.prototype.aboveOrEqual = function(e) {
			return e == null ? Pt(this, at) : new this.Collection(this, function() {
				return Lt(e, void 0, !1);
			});
		}, Bt.prototype.below = function(e) {
			return e == null ? Pt(this, at) : new this.Collection(this, function() {
				return Lt(void 0, e, !1, !0);
			});
		}, Bt.prototype.belowOrEqual = function(e) {
			return e == null ? Pt(this, at) : new this.Collection(this, function() {
				return Lt(void 0, e);
			});
		}, Bt.prototype.startsWith = function(e) {
			return typeof e == "string" ? this.between(e, e + it, !0, !0) : Pt(this, ot);
		}, Bt.prototype.startsWithIgnoreCase = function(e) {
			return e === "" ? this.startsWith(e) : It(this, function(e, t) {
				return e.indexOf(t[0]) === 0;
			}, [e], it);
		}, Bt.prototype.equalsIgnoreCase = function(e) {
			return It(this, function(e, t) {
				return e === t[0];
			}, [e], "");
		}, Bt.prototype.anyOfIgnoreCase = function() {
			var e = re.apply(ne, arguments);
			return e.length === 0 ? Ft(this) : It(this, function(e, t) {
				return t.indexOf(e) !== -1;
			}, e, "");
		}, Bt.prototype.startsWithAnyOfIgnoreCase = function() {
			var e = re.apply(ne, arguments);
			return e.length === 0 ? Ft(this) : It(this, function(e, t) {
				return t.some(function(t) {
					return e.indexOf(t) === 0;
				});
			}, e, it);
		}, Bt.prototype.anyOf = function() {
			var e, t, n = this, r = re.apply(ne, arguments), i = this._cmp;
			try {
				r.sort(i);
			} catch {
				return Pt(this, at);
			}
			return r.length === 0 ? Ft(this) : ((e = new this.Collection(this, function() {
				return Lt(r[0], r[r.length - 1]);
			}))._ondirectionchange = function(e) {
				i = e === "next" ? n._ascending : n._descending, r.sort(i);
			}, t = 0, e._addAlgorithm(function(e, n, a) {
				for (var o = e.key; 0 < i(o, r[t]);) if (++t === r.length) return n(a), !1;
				return i(o, r[t]) === 0 || (n(function() {
					e.continue(r[t]);
				}), !1);
			}), e);
		}, Bt.prototype.notEqual = function(e) {
			return this.inAnyRange([[-1 / 0, e], [e, this.db._maxKey]], {
				includeLowers: !1,
				includeUppers: !1
			});
		}, Bt.prototype.noneOf = function() {
			var e = re.apply(ne, arguments);
			if (e.length === 0) return new this.Collection(this);
			try {
				e.sort(this._ascending);
			} catch {
				return Pt(this, at);
			}
			var t = e.reduce(function(e, t) {
				return e ? e.concat([[e[e.length - 1][1], t]]) : [[-1 / 0, t]];
			}, null);
			return t.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(t, {
				includeLowers: !1,
				includeUppers: !1
			});
		}, Bt.prototype.inAnyRange = function(e, t) {
			var n = this, r = this._cmp, i = this._ascending, a = this._descending, o = this._min, s = this._max;
			if (e.length === 0) return Ft(this);
			if (!e.every(function(e) {
				return e[0] !== void 0 && e[1] !== void 0 && i(e[0], e[1]) <= 0;
			})) return Pt(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", I.InvalidArgument);
			var c = !t || !1 !== t.includeLowers, l = t && !0 === t.includeUppers, u, d = i;
			function f(e, t) {
				return d(e[0], t[0]);
			}
			try {
				(u = e.reduce(function(e, t) {
					for (var n = 0, i = e.length; n < i; ++n) {
						var a = e[n];
						if (r(t[0], a[1]) < 0 && 0 < r(t[1], a[0])) {
							a[0] = o(a[0], t[0]), a[1] = s(a[1], t[1]);
							break;
						}
					}
					return n === i && e.push(t), e;
				}, [])).sort(f);
			} catch {
				return Pt(this, at);
			}
			var p = 0, m = l ? function(e) {
				return 0 < i(e, u[p][1]);
			} : function(e) {
				return 0 <= i(e, u[p][1]);
			}, h = c ? function(e) {
				return 0 < a(e, u[p][0]);
			} : function(e) {
				return 0 <= a(e, u[p][0]);
			}, g = m, t = new this.Collection(this, function() {
				return Lt(u[0][0], u[u.length - 1][1], !c, !l);
			});
			return t._ondirectionchange = function(e) {
				d = e === "next" ? (g = m, i) : (g = h, a), u.sort(f);
			}, t._addAlgorithm(function(e, t, r) {
				for (var a, o = e.key; g(o);) if (++p === u.length) return t(r), !1;
				return !m(a = o) && !h(a) || (n._cmp(o, u[p][1]) === 0 || n._cmp(o, u[p][0]) === 0 || t(function() {
					d === i ? e.continue(u[p][0]) : e.continue(u[p][1]);
				}), !1);
			}), t;
		}, Bt.prototype.startsWithAnyOf = function() {
			var e = re.apply(ne, arguments);
			return e.every(function(e) {
				return typeof e == "string";
			}) ? e.length === 0 ? Ft(this) : this.inAnyRange(e.map(function(e) {
				return [e, e + it];
			})) : Pt(this, "startsWithAnyOf() only works with strings");
		};
		var zt = Bt;
		function Bt() {}
		function Vt(e) {
			return G(function(t) {
				return Ht(t), e(t.target.error), !1;
			});
		}
		function Ht(e) {
			e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault();
		}
		var Ut = "storagemutated", Wt = "x-storagemutated-1", Gt = xt(null, Ut), Kt = (qt.prototype._lock = function() {
			return v(!U.global), ++this._reculock, this._reculock !== 1 || U.global || (U.lockOwnerFor = this), this;
		}, qt.prototype._unlock = function() {
			if (v(!U.global), --this._reculock == 0) for (U.global || (U.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked();) {
				var e = this._blockedFuncs.shift();
				try {
					et(e[1], e[0]);
				} catch {}
			}
			return this;
		}, qt.prototype._locked = function() {
			return this._reculock && U.lockOwnerFor !== this;
		}, qt.prototype.create = function(e) {
			var t = this;
			if (this.mode) {
				var n = this.db.idbdb, r = this.db._state.dbOpenError;
				if (v(!this.idbtrans), !e && !n) switch (r && r.name) {
					case "DatabaseClosedError": throw new I.DatabaseClosed(r);
					case "MissingAPIError": throw new I.MissingAPI(r.message, r);
					default: throw new I.OpenFailed(r);
				}
				if (!this.active) throw new I.TransactionInactive();
				v(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || n).transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability })).onerror = G(function(n) {
					Ht(n), t._reject(e.error);
				}), e.onabort = G(function(n) {
					Ht(n), t.active && t._reject(new I.Abort(e.error)), t.active = !1, t.on("abort").fire(n);
				}), e.oncomplete = G(function() {
					t.active = !1, t._resolve(), "mutatedParts" in e && Gt.storagemutated.fire(e.mutatedParts);
				});
			}
			return this;
		}, qt.prototype._promise = function(e, t, n) {
			var r, i = this;
			return e === "readwrite" && this.mode !== "readwrite" ? rt(new I.ReadOnly("Transaction is readonly")) : this.active ? this._locked() ? new W(function(r, a) {
				i._blockedFuncs.push([function() {
					i._promise(e, t, n).then(r, a);
				}, U]);
			}) : n ? qe(function() {
				var e = new W(function(e, n) {
					i._lock();
					var r = t(e, n, i);
					r && r.then && r.then(e, n);
				});
				return e.finally(function() {
					return i._unlock();
				}), e._lib = !0, e;
			}) : ((r = new W(function(e, n) {
				var r = t(e, n, i);
				r && r.then && r.then(e, n);
			}))._lib = !0, r) : rt(new I.TransactionInactive());
		}, qt.prototype._root = function() {
			return this.parent ? this.parent._root() : this;
		}, qt.prototype.waitFor = function(e) {
			var t, n = this._root(), r = W.resolve(e), i = (n._waitingFor ? n._waitingFor = n._waitingFor.then(function() {
				return r;
			}) : (n._waitingFor = r, n._waitingQueue = [], t = n.idbtrans.objectStore(n.storeNames[0]), function e() {
				for (++n._spinCount; n._waitingQueue.length;) n._waitingQueue.shift()();
				n._waitingFor && (t.get(-1 / 0).onsuccess = e);
			}()), n._waitingFor);
			return new W(function(e, t) {
				r.then(function(t) {
					return n._waitingQueue.push(G(e.bind(null, t)));
				}, function(e) {
					return n._waitingQueue.push(G(t.bind(null, e)));
				}).finally(function() {
					n._waitingFor === i && (n._waitingFor = null);
				});
			});
		}, qt.prototype.abort = function() {
			this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new I.Abort()));
		}, qt.prototype.table = function(e) {
			var t = this._memoizedTables ||= {};
			if (l(t, e)) return t[e];
			var n = this.schema[e];
			if (n) return (n = new this.db.Table(e, n, this)).core = this.db.core.table(e), t[e] = n;
			throw new I.NotFound("Table " + e + " not part of transaction");
		}, qt);
		function qt() {}
		function Jt(e, t, n, r, i, a, o, s) {
			return {
				name: e,
				keyPath: t,
				unique: n,
				multi: r,
				auto: i,
				compound: a,
				src: (n && !o ? "&" : "") + (r ? "*" : "") + (i ? "++" : "") + Yt(t),
				type: s
			};
		}
		function Yt(e) {
			return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : "";
		}
		function Xt(e, t, n) {
			return {
				name: e,
				primKey: t,
				indexes: n,
				mappedClass: null,
				idxByName: (r = function(e) {
					return [e.name, e];
				}, n.reduce(function(e, t, n) {
					return t = r(t, n), t && (e[t[0]] = t[1]), e;
				}, {}))
			};
			var r;
		}
		var Zt = function(e) {
			try {
				return e.only([[]]), Zt = function() {
					return [[]];
				}, [[]];
			} catch {
				return Zt = function() {
					return it;
				}, it;
			}
		};
		function Qt(e) {
			return e == null ? function() {} : typeof e == "string" ? (t = e).split(".").length === 1 ? function(e) {
				return e[t];
			} : function(e) {
				return b(e, t);
			} : function(t) {
				return b(t, e);
			};
			var t;
		}
		function $t(e) {
			return [].slice.call(e);
		}
		var en = 0;
		function tn(e) {
			return e == null ? ":id" : typeof e == "string" ? e : `[${e.join("+")}]`;
		}
		function X(e, t, n) {
			function r(e) {
				if (e.type === 3) return null;
				if (e.type === 4) throw Error("Cannot convert never type to IDBKeyRange");
				var n = e.lower, r = e.upper, i = e.lowerOpen, e = e.upperOpen;
				return n === void 0 ? r === void 0 ? null : t.upperBound(r, !!e) : r === void 0 ? t.lowerBound(n, !!i) : t.bound(n, r, !!i, !!e);
			}
			function i(e) {
				var t, n, i = e.name;
				return {
					name: i,
					schema: e,
					mutate: function(e) {
						var t = e.trans, n = e.type, a = e.keys, o = e.values, s = e.range;
						return new Promise(function(e, c) {
							e = G(e);
							var l = t.objectStore(i), u = l.keyPath == null, d = n === "put" || n === "add";
							if (!d && n !== "delete" && n !== "deleteRange") throw Error("Invalid operation type: " + n);
							var f, p = (a || o || { length: 1 }).length;
							if (a && o && a.length !== o.length) throw Error("Given keys array must have same length as given values array.");
							if (p === 0) return e({
								numFailures: 0,
								failures: {},
								results: [],
								lastResult: void 0
							});
							function m(e) {
								++_, Ht(e);
							}
							var h = [], g = [], _ = 0;
							if (n === "deleteRange") {
								if (s.type === 4) return e({
									numFailures: _,
									failures: g,
									results: [],
									lastResult: void 0
								});
								s.type === 3 ? h.push(f = l.clear()) : h.push(f = l.delete(r(s)));
							} else {
								var u = d ? u ? [o, a] : [o, null] : [a, null], v = u[0], y = u[1];
								if (d) for (var b = 0; b < p; ++b) h.push(f = y && y[b] !== void 0 ? l[n](v[b], y[b]) : l[n](v[b])), f.onerror = m;
								else for (b = 0; b < p; ++b) h.push(f = l[n](v[b])), f.onerror = m;
							}
							function x(t) {
								t = t.target.result, h.forEach(function(e, t) {
									return e.error != null && (g[t] = e.error);
								}), e({
									numFailures: _,
									failures: g,
									results: n === "delete" ? a : h.map(function(e) {
										return e.result;
									}),
									lastResult: t
								});
							}
							f.onerror = function(e) {
								m(e), x(e);
							}, f.onsuccess = x;
						});
					},
					getMany: function(e) {
						var t = e.trans, n = e.keys;
						return new Promise(function(e, r) {
							e = G(e);
							for (var a, o = t.objectStore(i), s = n.length, c = Array(s), l = 0, u = 0, d = function(t) {
								t = t.target, c[t._pos] = t.result, ++u === l && e(c);
							}, f = Vt(r), p = 0; p < s; ++p) n[p] != null && ((a = o.get(n[p]))._pos = p, a.onsuccess = d, a.onerror = f, ++l);
							l === 0 && e(c);
						});
					},
					get: function(e) {
						var t = e.trans, n = e.key;
						return new Promise(function(e, r) {
							e = G(e);
							var a = t.objectStore(i).get(n);
							a.onsuccess = function(t) {
								return e(t.target.result);
							}, a.onerror = Vt(r);
						});
					},
					query: (t = c, n = l, function(e) {
						return new Promise(function(a, o) {
							a = G(a);
							var s, c, l, u, d = e.trans, f = e.values, p = e.limit, m = e.query, h = (h = e.direction) ?? "next", g = p === 1 / 0 ? void 0 : p, _ = m.index, m = m.range, d = d.objectStore(i), d = _.isPrimaryKey ? d : d.index(_.name), _ = r(m);
							if (p === 0) return a({ result: [] });
							n ? (m = {
								query: _,
								count: g,
								direction: h
							}, (s = f ? d.getAll(m) : d.getAllKeys(m)).onsuccess = function(e) {
								return a({ result: e.target.result });
							}, s.onerror = Vt(o)) : t && h === "next" ? ((s = f ? d.getAll(_, g) : d.getAllKeys(_, g)).onsuccess = function(e) {
								return a({ result: e.target.result });
							}, s.onerror = Vt(o)) : (c = 0, l = !f && "openKeyCursor" in d ? d.openKeyCursor(_, h) : d.openCursor(_, h), u = [], l.onsuccess = function() {
								var e = l.result;
								return !e || (u.push(f ? e.value : e.primaryKey), ++c === p) ? a({ result: u }) : void e.continue();
							}, l.onerror = Vt(o));
						});
					}),
					openCursor: function(e) {
						var t = e.trans, n = e.values, a = e.query, o = e.reverse, s = e.unique;
						return new Promise(function(e, c) {
							e = G(e);
							var l = a.index, u = a.range, d = t.objectStore(i), d = l.isPrimaryKey ? d : d.index(l.name), l = o ? s ? "prevunique" : "prev" : s ? "nextunique" : "next", f = !n && "openKeyCursor" in d ? d.openKeyCursor(r(u), l) : d.openCursor(r(u), l);
							f.onerror = Vt(c), f.onsuccess = G(function(n) {
								var r, i, a, o, s = f.result;
								s ? (s.___id = ++en, s.done = !1, r = s.continue.bind(s), i = (i = s.continuePrimaryKey) && i.bind(s), a = s.advance.bind(s), o = function() {
									throw Error("Cursor not stopped");
								}, s.trans = t, s.stop = s.continue = s.continuePrimaryKey = s.advance = function() {
									throw Error("Cursor not started");
								}, s.fail = G(c), s.next = function() {
									var e = this, t = 1;
									return this.start(function() {
										return t-- ? e.continue() : e.stop();
									}).then(function() {
										return e;
									});
								}, s.start = function(e) {
									function t() {
										if (f.result) try {
											e();
										} catch (e) {
											s.fail(e);
										}
										else s.done = !0, s.start = function() {
											throw Error("Cursor behind last entry");
										}, s.stop();
									}
									var n = new Promise(function(e, t) {
										e = G(e), f.onerror = Vt(t), s.fail = t, s.stop = function(t) {
											s.stop = s.continue = s.continuePrimaryKey = s.advance = o, e(t);
										};
									});
									return f.onsuccess = G(function(e) {
										f.onsuccess = t, t();
									}), s.continue = r, s.continuePrimaryKey = i, s.advance = a, t(), n;
								}, e(s)) : e(null);
							}, c);
						});
					},
					count: function(e) {
						var t = e.query, n = e.trans, a = t.index, o = t.range;
						return new Promise(function(e, t) {
							var s = n.objectStore(i), s = a.isPrimaryKey ? s : s.index(a.name), c = r(o), c = c ? s.count(c) : s.count();
							c.onsuccess = G(function(t) {
								return e(t.target.result);
							}), c.onerror = Vt(t);
						});
					}
				};
			}
			o = n, s = $t((n = e).objectStoreNames), u = 0 < s.length ? o.objectStore(s[0]) : {};
			var o, n = {
				schema: {
					name: n.name,
					tables: s.map(function(e) {
						return o.objectStore(e);
					}).map(function(e) {
						var t = e.keyPath, n = e.autoIncrement, r = a(t), i = {}, r = {
							name: e.name,
							primaryKey: {
								name: null,
								isPrimaryKey: !0,
								outbound: t == null,
								compound: r,
								keyPath: t,
								autoIncrement: n,
								unique: !0,
								extractKey: Qt(t)
							},
							indexes: $t(e.indexNames).map(function(t) {
								return e.index(t);
							}).map(function(e) {
								var t = e.name, n = e.unique, r = e.multiEntry, e = e.keyPath, t = {
									name: t,
									compound: a(e),
									keyPath: e,
									unique: n,
									multiEntry: r,
									extractKey: Qt(e)
								};
								return i[tn(e)] = t;
							}),
							getIndexByKeyPath: function(e) {
								return i[tn(e)];
							}
						};
						return i[":id"] = r.primaryKey, t != null && (i[tn(t)] = r.primaryKey), r;
					})
				},
				hasGetAll: 0 < s.length && "getAll" in u && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604),
				hasIdb3Features: "getAllRecords" in u
			}, s = n.schema, c = n.hasGetAll, l = n.hasIdb3Features, u = s.tables.map(i), d = {};
			return u.forEach(function(e) {
				return d[e.name] = e;
			}), {
				stack: "dbcore",
				transaction: e.transaction.bind(e),
				table: function(e) {
					if (d[e]) return d[e];
					throw Error(`Table '${e}' not found`);
				},
				MIN_KEY: -1 / 0,
				MAX_KEY: Zt(t),
				schema: s
			};
		}
		function nn(e, n, r, i) {
			return r = r.IDBKeyRange, n = X(n, r, i), { dbcore: e.dbcore.reduce(function(e, n) {
				return n = n.create, t(t({}, e), n(e));
			}, n) };
		}
		function rn(e, t) {
			var n = t.db, n = nn(e._middlewares, n, e._deps, t);
			e.core = n.dbcore, e.tables.forEach(function(t) {
				var n = t.name;
				e.core.schema.tables.some(function(e) {
					return e.name === n;
				}) && (t.core = e.core.table(n), e[n] instanceof e.Table) && (e[n].core = t.core);
			});
		}
		function an(e, t, n, r) {
			n.forEach(function(n) {
				var i = r[n];
				t.forEach(function(t) {
					var r = function e(t, n) {
						return m(t, n) || (t = s(t)) && e(t, n);
					}(t, n);
					(!r || "value" in r && r.value === void 0) && (t === e.Transaction.prototype || t instanceof e.Transaction ? f(t, n, {
						get: function() {
							return this.table(n);
						},
						set: function(e) {
							d(this, n, {
								value: e,
								writable: !0,
								configurable: !0,
								enumerable: !0
							});
						}
					}) : t[n] = new e.Table(n, i));
				});
			});
		}
		function on(e, t) {
			t.forEach(function(t) {
				for (var n in t) t[n] instanceof e.Table && delete t[n];
			});
		}
		function sn(e, t) {
			return e._cfg.version - t._cfg.version;
		}
		function cn(e, t, n, r) {
			var a = e._dbSchema, o = (n.objectStoreNames.contains("$meta") && !a.$meta && (a.$meta = Xt("$meta", gn("")[0], []), e._storeNames.push("$meta")), e._createTransaction("readwrite", e._storeNames, a)), s = (o.create(n), o._completion.catch(r), o._reject.bind(o)), c = U.transless || U;
			qe(function() {
				if (U.trans = o, U.transless = c, t !== 0) return rn(e, n), l = t, ((r = o).storeNames.includes("$meta") ? r.table("$meta").get("version").then(function(e) {
					return e ?? l;
				}) : W.resolve(l)).then(function(t) {
					var r = e, a = t, s = o, c = n, l = [], t = r._versions, u = r._dbSchema = mn(0, r.idbdb, c);
					return (t = t.filter(function(e) {
						return e._cfg.version >= a;
					})).length === 0 ? W.resolve() : (t.forEach(function(e) {
						l.push(function() {
							var t, n, o, l = u, d = e._cfg.dbschema, f = (hn(r, l, c), hn(r, d, c), u = r._dbSchema = d, un(l, d)), p = (f.add.forEach(function(e) {
								dn(c, e[0], e[1].primKey, e[1].indexes);
							}), f.change.forEach(function(e) {
								if (e.recreate) throw new I.Upgrade("Not yet support for changing primary key");
								var t = c.objectStore(e.name);
								e.add.forEach(function(e) {
									return pn(t, e);
								}), e.change.forEach(function(e) {
									t.deleteIndex(e.name), pn(t, e);
								}), e.del.forEach(function(e) {
									return t.deleteIndex(e);
								});
							}), e._cfg.contentUpgrade);
							if (p && e._cfg.version > a) return rn(r, c), s._memoizedTables = {}, t = S(d), f.del.forEach(function(e) {
								t[e] = l[e];
							}), on(r, [r.Transaction.prototype]), an(r, [r.Transaction.prototype], i(t), t), s.schema = t, (n = ie(p)) && Je(), d = W.follow(function() {
								var e;
								(o = p(s)) && n && (e = Ye.bind(null, null), o.then(e, e));
							}), o && typeof o.then == "function" ? W.resolve(o) : d.then(function() {
								return o;
							});
						}), l.push(function(t) {
							var n = e._cfg.dbschema, i = t;
							[].slice.call(i.db.objectStoreNames).forEach(function(e) {
								return n[e] == null && i.db.deleteObjectStore(e);
							}), on(r, [r.Transaction.prototype]), an(r, [r.Transaction.prototype], r._storeNames, r._dbSchema), s.schema = r._dbSchema;
						}), l.push(function(t) {
							r.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(r.idbdb.version / 10) === e._cfg.version ? (r.idbdb.deleteObjectStore("$meta"), delete r._dbSchema.$meta, r._storeNames = r._storeNames.filter(function(e) {
								return e !== "$meta";
							})) : t.objectStore("$meta").put(e._cfg.version, "version"));
						});
					}), function e() {
						return l.length ? W.resolve(l.shift()(s.idbtrans)).then(e) : W.resolve();
					}().then(function() {
						fn(u, c);
					}));
				}).catch(s);
				var r, l;
				i(a).forEach(function(e) {
					dn(n, e, a[e].primKey, a[e].indexes);
				}), rn(e, n), W.follow(function() {
					return e.on.populate.fire(o);
				}).catch(s);
			});
		}
		function ln(e, t) {
			fn(e._dbSchema, t), t.db.version % 10 != 0 || t.objectStoreNames.contains("$meta") || t.db.createObjectStore("$meta").add(Math.ceil(t.db.version / 10 - 1), "version");
			var n = mn(0, e.idbdb, t);
			hn(e, e._dbSchema, t);
			for (var r = 0, i = un(n, e._dbSchema).change; r < i.length; r++) {
				var a = ((e) => {
					if (e.change.length || e.recreate) return console.warn(`Unable to patch indexes of table ${e.name} because it has changes on the type of index or primary key.`), { value: void 0 };
					var n = t.objectStore(e.name);
					e.add.forEach(function(t) {
						he && console.debug(`Dexie upgrade patch: Creating missing index ${e.name}.${t.src}`), pn(n, t);
					});
				})(i[r]);
				if (typeof a == "object") return a.value;
			}
		}
		function un(e, t) {
			var n, r = {
				del: [],
				add: [],
				change: []
			};
			for (n in e) t[n] || r.del.push(n);
			for (n in t) {
				var i = e[n], a = t[n];
				if (i) {
					var o = {
						name: n,
						def: a,
						recreate: !1,
						del: [],
						add: [],
						change: []
					};
					if ("" + (i.primKey.keyPath || "") != "" + (a.primKey.keyPath || "") || i.primKey.auto !== a.primKey.auto) o.recreate = !0, r.change.push(o);
					else {
						var s = i.idxByName, c = a.idxByName, l = void 0;
						for (l in s) c[l] || o.del.push(l);
						for (l in c) {
							var u = s[l], d = c[l];
							u ? u.src !== d.src && o.change.push(d) : o.add.push(d);
						}
						(0 < o.del.length || 0 < o.add.length || 0 < o.change.length) && r.change.push(o);
					}
				} else r.add.push([n, a]);
			}
			return r;
		}
		function dn(e, t, n, r) {
			var i = e.db.createObjectStore(t, n.keyPath ? {
				keyPath: n.keyPath,
				autoIncrement: n.auto
			} : { autoIncrement: n.auto });
			r.forEach(function(e) {
				return pn(i, e);
			});
		}
		function fn(e, t) {
			i(e).forEach(function(n) {
				t.db.objectStoreNames.contains(n) || (he && console.debug("Dexie: Creating missing table", n), dn(t, n, e[n].primKey, e[n].indexes));
			});
		}
		function pn(e, t) {
			e.createIndex(t.name, t.keyPath, {
				unique: t.unique,
				multiEntry: t.multi
			});
		}
		function mn(e, t, n) {
			var r = {};
			return g(t.objectStoreNames, 0).forEach(function(e) {
				for (var t = n.objectStore(e), i = Jt(Yt(c = t.keyPath), c || "", !0, !1, !!t.autoIncrement, c && typeof c != "string", !0), a = [], o = 0; o < t.indexNames.length; ++o) {
					var s = t.index(t.indexNames[o]), c = s.keyPath, s = Jt(s.name, c, !!s.unique, !!s.multiEntry, !1, c && typeof c != "string", !1);
					a.push(s);
				}
				r[e] = Xt(e, i, a);
			}), r;
		}
		function hn(e, t, n) {
			for (var i = n.db.objectStoreNames, a = 0; a < i.length; ++a) {
				var o = i[a], s = n.objectStore(o);
				e._hasGetAll = "getAll" in s;
				for (var c = 0; c < s.indexNames.length; ++c) {
					var l, u = s.indexNames[c], d = s.index(u).keyPath, d = typeof d == "string" ? d : "[" + g(d).join("+") + "]";
					t[o] && (l = t[o].idxByName[d]) && (l.name = u, delete t[o].idxByName[d], t[o].idxByName[u] = l);
				}
			}
			typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && r.WorkerGlobalScope && r instanceof r.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1);
		}
		function gn(e) {
			return e.split(",").map(function(e, t) {
				var n = e.split(":"), r = (r = n[1])?.trim(), n = (e = n[0].trim()).replace(/([&*]|\+\+)/g, ""), i = /^\[/.test(n) ? n.match(/^\[(.*)\]$/)[1].split("+") : n;
				return Jt(n, i || null, /\&/.test(e), /\*/.test(e), /\+\+/.test(e), a(i), t === 0, r);
			});
		}
		vn.prototype._createTableSchema = Xt, vn.prototype._parseIndexSyntax = gn, vn.prototype._parseStoresSpec = function(e, t) {
			var n = this;
			i(e).forEach(function(r) {
				if (e[r] !== null) {
					var i = n._parseIndexSyntax(e[r]), a = i.shift();
					if (!a) throw new I.Schema("Invalid schema for table " + r + ": " + e[r]);
					if (a.unique = !0, a.multi) throw new I.Schema("Primary key cannot be multiEntry*");
					i.forEach(function(e) {
						if (e.auto) throw new I.Schema("Only primary key can be marked as autoIncrement (++)");
						if (!e.keyPath) throw new I.Schema("Index must have a name and cannot be an empty string");
					}), a = n._createTableSchema(r, a, i), t[r] = a;
				}
			});
		}, vn.prototype.stores = function(e) {
			var t = this.db, e = (this._cfg.storesSource = this._cfg.storesSource ? o(this._cfg.storesSource, e) : e, t._versions), n = {}, r = {};
			return e.forEach(function(e) {
				o(n, e._cfg.storesSource), r = e._cfg.dbschema = {}, e._parseStoresSpec(n, r);
			}), t._dbSchema = r, on(t, [
				t._allTables,
				t,
				t.Transaction.prototype
			]), an(t, [
				t._allTables,
				t,
				t.Transaction.prototype,
				this._cfg.tables
			], i(r), r), t._storeNames = i(r), this;
		}, vn.prototype.upgrade = function(e) {
			return this._cfg.contentUpgrade = B(this._cfg.contentUpgrade || R, e), this;
		};
		var _n = vn;
		function vn() {}
		var yn = (() => {
			var e, t, n;
			return typeof FinalizationRegistry < "u" && typeof WeakRef < "u" ? (e = /* @__PURE__ */ new Set(), t = new FinalizationRegistry(function(t) {
				e.delete(t);
			}), {
				toArray: function() {
					return Array.from(e).map(function(e) {
						return e.deref();
					}).filter(function(e) {
						return e !== void 0;
					});
				},
				add: function(n) {
					var r = new WeakRef(n._novip);
					e.add(r), t.register(n._novip, r, r), e.size > n._options.maxConnections && (r = e.values().next().value, e.delete(r), t.unregister(r));
				},
				remove: function(n) {
					if (n) for (var r = e.values(), i = r.next(); !i.done;) {
						var a = i.value;
						if (a.deref() === n._novip) return e.delete(a), void t.unregister(a);
						i = r.next();
					}
				}
			}) : (n = [], {
				toArray: function() {
					return n;
				},
				add: function(e) {
					n.push(e._novip);
				},
				remove: function(e) {
					e && (e = n.indexOf(e._novip)) !== -1 && n.splice(e, 1);
				}
			});
		})();
		function bn(e, t) {
			var n = e._dbNamesDB;
			return n || (n = e._dbNamesDB = new ar(st, {
				addons: [],
				indexedDB: e,
				IDBKeyRange: t
			})).version(1).stores({ dbnames: "name" }), n.table("dbnames");
		}
		function xn(e) {
			return e && typeof e.databases == "function";
		}
		function Sn(e) {
			return qe(function() {
				return U.letThrough = !0, e();
			});
		}
		function Cn(e) {
			return !("from" in e);
		}
		var wn = function(e, t) {
			var n;
			if (!this) return n = new wn(), e && "d" in e && o(n, e), n;
			o(this, arguments.length ? {
				d: 1,
				from: e,
				to: 1 < arguments.length ? t : e
			} : { d: 0 });
		};
		function Tn(e, t, n) {
			var r = q(t, n);
			if (!isNaN(r)) {
				if (0 < r) throw RangeError();
				if (Cn(e)) return o(e, {
					from: t,
					to: n,
					d: 1
				});
				var r = e.l, i = e.r;
				if (q(n, e.from) < 0) return r ? Tn(r, t, n) : e.l = {
					from: t,
					to: n,
					d: 1,
					l: null,
					r: null
				}, kn(e);
				if (0 < q(t, e.to)) return i ? Tn(i, t, n) : e.r = {
					from: t,
					to: n,
					d: 1,
					l: null,
					r: null
				}, kn(e);
				q(t, e.from) < 0 && (e.from = t, e.l = null, e.d = i ? i.d + 1 : 1), 0 < q(n, e.to) && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1), t = !e.r, r && !e.l && En(e, r), i && t && En(e, i);
			}
		}
		function En(e, t) {
			Cn(t) || function e(t, n) {
				var r = n.from, i = n.l, a = n.r;
				Tn(t, r, n.to), i && e(t, i), a && e(t, a);
			}(e, t);
		}
		function Dn(e, t) {
			var n = On(t), r = n.next();
			if (!r.done) for (var i = r.value, a = On(e), o = a.next(i.from), s = o.value; !r.done && !o.done;) {
				if (q(s.from, i.to) <= 0 && 0 <= q(s.to, i.from)) return !0;
				q(i.from, s.from) < 0 ? i = (r = n.next(s.from)).value : s = (o = a.next(i.from)).value;
			}
			return !1;
		}
		function On(e) {
			var t = Cn(e) ? null : {
				s: 0,
				n: e
			};
			return { next: function(e) {
				for (var n = 0 < arguments.length; t;) switch (t.s) {
					case 0: if (t.s = 1, n) for (; t.n.l && q(e, t.n.from) < 0;) t = {
						up: t,
						n: t.n.l,
						s: 1
					};
					else for (; t.n.l;) t = {
						up: t,
						n: t.n.l,
						s: 1
					};
					case 1: if (t.s = 2, !n || q(e, t.n.to) <= 0) return {
						value: t.n,
						done: !1
					};
					case 2: if (t.n.r) {
						t.s = 3, t = {
							up: t,
							n: t.n.r,
							s: 0
						};
						continue;
					}
					case 3: t = t.up;
				}
				return { done: !0 };
			} };
		}
		function kn(e) {
			var n, r, i, a = ((a = e.r)?.d || 0) - ((a = e.l)?.d || 0), a = 1 < a ? "r" : a < -1 ? "l" : "";
			a && (n = a == "r" ? "l" : "r", r = t({}, e), i = e[a], e.from = i.from, e.to = i.to, e[a] = i[a], r[a] = i[n], (e[n] = r).d = An(r)), e.d = An(e);
		}
		function An(e) {
			var t = e.r, e = e.l;
			return (t ? e ? Math.max(t.d, e.d) : t.d : e ? e.d : 0) + 1;
		}
		function jn(e, t) {
			return i(t).forEach(function(n) {
				e[n] ? En(e[n], t[n]) : e[n] = function e(t) {
					var n, r, i = {};
					for (n in t) l(t, n) && (r = t[n], i[n] = !r || typeof r != "object" || E.has(r.constructor) ? r : e(r));
					return i;
				}(t[n]);
			}), e;
		}
		function Mn(e, t) {
			return e.all || t.all || Object.keys(e).some(function(n) {
				return t[n] && Dn(t[n], e[n]);
			});
		}
		u(wn.prototype, ((M = {
			add: function(e) {
				return En(this, e), this;
			},
			addKey: function(e) {
				return Tn(this, e, e), this;
			},
			addKeys: function(e) {
				var t = this;
				return e.forEach(function(e) {
					return Tn(t, e, e);
				}), this;
			},
			hasKey: function(e) {
				var t = On(this).next(e).value;
				return t && q(t.from, e) <= 0 && 0 <= q(t.to, e);
			}
		})[te] = function() {
			return On(this);
		}, M));
		var Nn = {}, Pn = {}, Fn = !1;
		function In(e) {
			jn(Pn, e), Fn || (Fn = !0, setTimeout(function() {
				Fn = !1, Ln(Pn, !(Pn = {}));
			}, 0));
		}
		function Ln(e, t) {
			t === void 0 && (t = !1);
			var n = /* @__PURE__ */ new Set();
			if (e.all) for (var r = 0, i = Object.values(Nn); r < i.length; r++) Rn(s = i[r], e, n, t);
			else for (var a in e) {
				var o, s, a = /^idb\:\/\/(.*)\/(.*)\//.exec(a);
				a && (o = a[1], a = a[2], s = Nn[`idb://${o}/${a}`]) && Rn(s, e, n, t);
			}
			n.forEach(function(e) {
				return e();
			});
		}
		function Rn(e, t, n, r) {
			for (var i = [], a = 0, o = Object.entries(e.queries.query); a < o.length; a++) {
				for (var s = o[a], c = s[0], l = [], u = 0, d = s[1]; u < d.length; u++) {
					var f = d[u];
					Mn(t, f.obsSet) ? f.subscribers.forEach(function(e) {
						return n.add(e);
					}) : r && l.push(f);
				}
				r && i.push([c, l]);
			}
			if (r) for (var p = 0, m = i; p < m.length; p++) {
				var h = m[p], c = h[0], l = h[1];
				e.queries.query[c] = l;
			}
		}
		function zn(e) {
			var t = e._state, n = e._deps.indexedDB;
			if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
				return t.dbOpenError ? rt(t.dbOpenError) : e;
			});
			t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
			var r = t.openCanceller, a = Math.round(10 * e.verno), o = !1;
			function s() {
				if (t.openCanceller !== r) throw new I.DatabaseClosed("db.open() was cancelled");
			}
			function c() {
				return new W(function(r, l) {
					if (s(), !n) throw new I.MissingAPI();
					var u = e.name, p = t.autoSchema || !a ? n.open(u) : n.open(u, a);
					if (!p) throw new I.MissingAPI();
					p.onerror = Vt(l), p.onblocked = G(e._fireOnBlocked), p.onupgradeneeded = G(function(r) {
						var i;
						d = p.transaction, t.autoSchema && !e._options.allowEmptyDB ? (p.onerror = Ht, d.abort(), p.result.close(), (i = n.deleteDatabase(u)).onsuccess = i.onerror = G(function() {
							l(new I.NoSuchDatabase(`Database ${u} doesnt exist`));
						})) : (d.onerror = Vt(l), i = r.oldVersion > 2 ** 62 ? 0 : r.oldVersion, f = i < 1, e.idbdb = p.result, o && ln(e, d), cn(e, i / 10, d, l));
					}, l), p.onsuccess = G(function() {
						d = null;
						var n, s, l, m, h, _, v = e.idbdb = p.result, y = g(v.objectStoreNames);
						if (0 < y.length) try {
							var b = v.transaction((h = y).length === 1 ? h[0] : h, "readonly");
							if (t.autoSchema) _ = v, m = b, (l = e).verno = _.version / 10, m = l._dbSchema = mn(0, _, m), l._storeNames = g(_.objectStoreNames, 0), an(l, [l._allTables], i(m), m);
							else if (hn(e, e._dbSchema, b), s = b, ((s = un(mn(0, (n = e).idbdb, s), n._dbSchema)).add.length || s.change.some(function(e) {
								return e.add.length || e.change.length;
							})) && !o) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), v.close(), a = v.version + 1, o = !0, r(c());
							rn(e, b);
						} catch {}
						yn.add(e), v.onversionchange = G(function(n) {
							t.vcFired = !0, e.on("versionchange").fire(n);
						}), v.onclose = G(function() {
							e.close({ disableAutoOpen: !1 });
						}), f && (y = e._deps, h = u, xn(_ = y.indexedDB) || h === st || bn(_, y.IDBKeyRange).put({ name: h }).catch(R)), r();
					}, l);
				}).catch(function(e) {
					switch (e?.name) {
						case "UnknownError":
							if (0 < t.PR1398_maxLoop) return t.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), c();
							break;
						case "VersionError": if (0 < a) return a = 0, c();
					}
					return W.reject(e);
				});
			}
			var l, u = t.dbReadyResolve, d = null, f = !1;
			return W.race([r, (typeof navigator > "u" ? W.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(e) {
				function t() {
					return indexedDB.databases().finally(e);
				}
				l = setInterval(t, 100), t();
			}).finally(function() {
				return clearInterval(l);
			}) : Promise.resolve()).then(c)]).then(function() {
				return s(), t.onReadyBeingFired = [], W.resolve(Sn(function() {
					return e.on.ready.fire(e.vip);
				})).then(function n() {
					var r;
					if (0 < t.onReadyBeingFired.length) return r = t.onReadyBeingFired.reduce(B, R), t.onReadyBeingFired = [], W.resolve(Sn(function() {
						return r(e.vip);
					})).then(n);
				});
			}).finally(function() {
				t.openCanceller === r && (t.onReadyBeingFired = null, t.isBeingOpened = !1);
			}).catch(function(n) {
				t.dbOpenError = n;
				try {
					d && d.abort();
				} catch {}
				return r === t.openCanceller && e._close(), rt(n);
			}).finally(function() {
				t.openComplete = !0, u();
			}).then(function() {
				var t;
				return f && (t = {}, e.tables.forEach(function(n) {
					n.schema.indexes.forEach(function(r) {
						r.name && (t[`idb://${e.name}/${n.name}/${r.name}`] = new wn(-1 / 0, [[[]]]));
					}), t[`idb://${e.name}/${n.name}/`] = t[`idb://${e.name}/${n.name}/:dels`] = new wn(-1 / 0, [[[]]]);
				}), Gt(Ut).fire(t), Ln(t, !0)), e;
			});
		}
		function Bn(e) {
			function t(t) {
				return e.next(t);
			}
			var n = i(t), r = i(function(t) {
				return e.throw(t);
			});
			function i(e) {
				return function(t) {
					var t = e(t), i = t.value;
					return t.done ? i : i && typeof i.then == "function" ? i.then(n, r) : a(i) ? Promise.all(i).then(n, r) : n(i);
				};
			}
			return i(t)();
		}
		function Vn(e, t, n) {
			for (var r = a(e) ? e.slice() : [e], i = 0; i < n; ++i) r.push(t);
			return r;
		}
		var Hn = {
			stack: "dbcore",
			name: "VirtualIndexMiddleware",
			level: 1,
			create: function(e) {
				return t(t({}, e), { table: function(n) {
					var r = e.table(n), n = r.schema, i = Object.create(null), a = [];
					function o(e, n, r) {
						var s = tn(e), c = i[s] = i[s] || [], l = e == null ? 0 : typeof e == "string" ? 1 : e.length, u = 0 < n, s = t(t({}, r), {
							name: u ? `${s}(virtual-from:${r.name})` : r.name,
							lowLevelIndex: r,
							isVirtual: u,
							keyTail: n,
							keyLength: l,
							extractKey: Qt(e),
							unique: !u && r.unique
						});
						return c.push(s), s.isPrimaryKey || a.push(s), 1 < l && o(l === 2 ? e[0] : e.slice(0, l - 1), n + 1, r), c.sort(function(e, t) {
							return e.keyTail - t.keyTail;
						}), s;
					}
					var s = o(n.primaryKey.keyPath, 0, n.primaryKey);
					i[":id"] = [s];
					for (var c = 0, l = n.indexes; c < l.length; c++) {
						var u = l[c];
						o(u.keyPath, 0, u);
					}
					function d(n) {
						var r, i = n.query.index;
						return i.isVirtual ? t(t({}, n), { query: {
							index: i.lowLevelIndex,
							range: (r = n.query.range, i = i.keyTail, {
								type: r.type === 1 ? 2 : r.type,
								lower: Vn(r.lower, r.lowerOpen ? e.MAX_KEY : e.MIN_KEY, i),
								lowerOpen: !0,
								upper: Vn(r.upper, r.upperOpen ? e.MIN_KEY : e.MAX_KEY, i),
								upperOpen: !0
							})
						} }) : n;
					}
					return t(t({}, r), {
						schema: t(t({}, n), {
							primaryKey: s,
							indexes: a,
							getIndexByKeyPath: function(e) {
								return (e = i[tn(e)]) && e[0];
							}
						}),
						count: function(e) {
							return r.count(d(e));
						},
						query: function(e) {
							return r.query(d(e));
						},
						openCursor: function(t) {
							var n = t.query.index, i = n.keyTail, a = n.keyLength;
							return n.isVirtual ? r.openCursor(d(t)).then(function(e) {
								return e && o(e);
							}) : r.openCursor(t);
							function o(n) {
								return Object.create(n, {
									continue: { value: function(r) {
										r == null ? t.unique ? n.continue(n.key.slice(0, a).concat(t.reverse ? e.MIN_KEY : e.MAX_KEY, i)) : n.continue() : n.continue(Vn(r, t.reverse ? e.MAX_KEY : e.MIN_KEY, i));
									} },
									continuePrimaryKey: { value: function(t, r) {
										n.continuePrimaryKey(Vn(t, e.MAX_KEY, i), r);
									} },
									primaryKey: { get: function() {
										return n.primaryKey;
									} },
									key: { get: function() {
										var e = n.key;
										return a === 1 ? e[0] : e.slice(0, a);
									} },
									value: { get: function() {
										return n.value;
									} }
								});
							}
						}
					});
				} });
			}
		};
		function Un(e, t, n, r) {
			return n ||= {}, r ||= "", i(e).forEach(function(i) {
				var a, o, s;
				l(t, i) ? (a = e[i], o = t[i], typeof a == "object" && typeof o == "object" && a && o ? (s = ee(a)) === ee(o) ? s === "Object" ? Un(a, o, n, r + i + ".") : a !== o && (n[r + i] = t[i]) : n[r + i] = t[i] : a !== o && (n[r + i] = t[i])) : n[r + i] = void 0;
			}), i(t).forEach(function(i) {
				l(e, i) || (n[r + i] = t[i]);
			}), n;
		}
		function Wn(e, t) {
			return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey);
		}
		var Gn = {
			stack: "dbcore",
			name: "HooksMiddleware",
			level: 2,
			create: function(e) {
				return t(t({}, e), { table: function(r) {
					var i = e.table(r), a = i.schema.primaryKey;
					return t(t({}, i), { mutate: function(e) {
						var o = U.trans, s = o.table(r).hook, c = s.deleting, u = s.creating, d = s.updating;
						switch (e.type) {
							case "add":
								if (u.fire === R) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "put":
								if (u.fire === R && d.fire === R) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "delete":
								if (c.fire === R) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "deleteRange":
								if (c.fire === R) break;
								return o._promise("readwrite", function() {
									return function e(n, r, o) {
										return i.query({
											trans: n,
											values: !1,
											query: {
												index: a,
												range: r
											},
											limit: o
										}).then(function(i) {
											var a = i.result;
											return f({
												type: "delete",
												keys: a,
												trans: n
											}).then(function(i) {
												return 0 < i.numFailures ? Promise.reject(i.failures[0]) : a.length < o ? {
													failures: [],
													numFailures: 0,
													lastResult: void 0
												} : e(n, t(t({}, r), {
													lower: a[a.length - 1],
													lowerOpen: !0
												}), o);
											});
										});
									}(e.trans, e.range, 1e4);
								}, !0);
						}
						return i.mutate(e);
						function f(e) {
							var r, o, s, f = U.trans, p = e.keys || Wn(a, e);
							if (p) return (e = e.type === "add" || e.type === "put" ? t(t({}, e), { keys: p }) : t({}, e)).type !== "delete" && (e.values = n([], e.values, !0)), e.keys && (e.keys = n([], e.keys, !0)), r = i, s = p, ((o = e).type === "add" ? Promise.resolve([]) : r.getMany({
								trans: o.trans,
								keys: s,
								cache: "immutable"
							})).then(function(t) {
								var n = p.map(function(n, r) {
									var i, o, s, p = t[r], m = {
										onerror: null,
										onsuccess: null
									};
									return e.type === "delete" ? c.fire.call(m, n, p, f) : e.type === "add" || p === void 0 ? (i = u.fire.call(m, n, e.values[r], f), n == null && i != null && (e.keys[r] = n = i, a.outbound || x(e.values[r], a.keyPath, n))) : (i = Un(p, e.values[r]), (o = d.fire.call(m, i, n, p, f)) && (s = e.values[r], Object.keys(o).forEach(function(e) {
										l(s, e) ? s[e] = o[e] : x(s, e, o[e]);
									}))), m;
								});
								return i.mutate(e).then(function(r) {
									for (var i = r.failures, a = r.results, o = r.numFailures, r = r.lastResult, s = 0; s < p.length; ++s) {
										var c = (a || p)[s], l = n[s];
										c == null ? l.onerror && l.onerror(i[s]) : l.onsuccess && l.onsuccess(e.type === "put" && t[s] ? e.values[s] : c);
									}
									return {
										failures: i,
										results: a,
										numFailures: o,
										lastResult: r
									};
								}).catch(function(e) {
									return n.forEach(function(t) {
										return t.onerror && t.onerror(e);
									}), Promise.reject(e);
								});
							});
							throw Error("Keys missing");
						}
					} });
				} });
			}
		};
		function Kn(e, t, n) {
			try {
				if (!t || t.keys.length < e.length) return null;
				for (var r = [], i = 0, a = 0; i < t.keys.length && a < e.length; ++i) q(t.keys[i], e[a]) === 0 && (r.push(n ? O(t.values[i]) : t.values[i]), ++a);
				return r.length === e.length ? r : null;
			} catch {
				return null;
			}
		}
		var qn = {
			stack: "dbcore",
			level: -1,
			create: function(e) {
				return { table: function(n) {
					var r = e.table(n);
					return t(t({}, r), {
						getMany: function(e) {
							var t;
							return e.cache ? (t = Kn(e.keys, e.trans._cache, e.cache === "clone")) ? W.resolve(t) : r.getMany(e).then(function(t) {
								return e.trans._cache = {
									keys: e.keys,
									values: e.cache === "clone" ? O(t) : t
								}, t;
							}) : r.getMany(e);
						},
						mutate: function(e) {
							return e.type !== "add" && (e.trans._cache = null), r.mutate(e);
						}
					});
				} };
			}
		};
		function Jn(e, t) {
			return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !t.schema.primaryKey.outbound;
		}
		function Yn(e, t) {
			switch (e) {
				case "query": return t.values && !t.unique;
				case "get":
				case "getMany":
				case "count":
				case "openCursor": return !1;
			}
		}
		var Xn = {
			stack: "dbcore",
			level: 0,
			name: "Observability",
			create: function(e) {
				var n = e.schema.name, r = new wn(e.MIN_KEY, e.MAX_KEY);
				return t(t({}, e), {
					transaction: function(t, n, r) {
						if (U.subscr && n !== "readonly") throw new I.ReadOnly(`Readwrite transaction in liveQuery context. Querier source: ${U.querier}`);
						return e.transaction(t, n, r);
					},
					table: function(o) {
						function s(t) {
							var t = t.query;
							return [t.index, new wn((t = t.range).lower ?? e.MIN_KEY, t.upper ?? e.MAX_KEY)];
						}
						var c = e.table(o), l = c.schema, u = l.primaryKey, d = l.indexes, f = u.extractKey, p = u.outbound, m = u.autoIncrement && d.filter(function(e) {
							return e.compound && e.keyPath.includes(u.keyPath);
						}), h = t(t({}, c), { mutate: function(t) {
							function i(e) {
								return e = `idb://${n}/${o}/${e}`, h[e] || (h[e] = new wn());
							}
							var s, d, f, p = t.trans, h = t.mutatedParts ||= {}, g = i(""), _ = i(":dels"), v = t.type, y = t.type === "deleteRange" ? [t.range] : t.type === "delete" ? [t.keys] : t.values.length < 50 ? [Wn(u, t).filter(function(e) {
								return e;
							}), t.values] : [], b = y[0], y = y[1], x = t.trans._cache;
							return a(b) ? (g.addKeys(b), (v = v === "delete" || b.length === y.length ? Kn(b, x) : null) || _.addKeys(b), (v || y) && (s = i, d = v, f = y, l.indexes.forEach(function(e) {
								var t = s(e.name || "");
								function n(t) {
									return t == null ? null : e.extractKey(t);
								}
								function r(n) {
									e.multiEntry && a(n) ? n.forEach(function(e) {
										return t.addKey(e);
									}) : t.addKey(n);
								}
								(d || f).forEach(function(e, t) {
									var i = d && n(d[t]), t = f && n(f[t]);
									q(i, t) !== 0 && (i != null && r(i), t != null) && r(t);
								});
							}))) : b ? (y = {
								from: (x = b.lower) ?? e.MIN_KEY,
								to: (v = b.upper) ?? e.MAX_KEY
							}, _.add(y), g.add(y)) : (g.add(r), _.add(r), l.indexes.forEach(function(e) {
								return i(e.name).add(r);
							})), c.mutate(t).then(function(e) {
								return !b || t.type !== "add" && t.type !== "put" || (g.addKeys(e.results), m && m.forEach(function(n) {
									for (var r = t.values.map(function(e) {
										return n.extractKey(e);
									}), a = n.keyPath.findIndex(function(e) {
										return e === u.keyPath;
									}), o = 0, s = e.results.length; o < s; ++o) r[o][a] = e.results[o];
									i(n.name).addKeys(r);
								})), p.mutatedParts = jn(p.mutatedParts || {}, h), e;
							});
						} }), g = {
							get: function(e) {
								return [u, new wn(e.key)];
							},
							getMany: function(e) {
								return [u, new wn().addKeys(e.keys)];
							},
							count: s,
							query: s,
							openCursor: s
						};
						return i(g).forEach(function(e) {
							h[e] = function(i) {
								var a = U.subscr, s = !!a, l = Jn(U, c) && Yn(e, i) ? i.obsSet = {} : a;
								if (s) {
									var u, a = function(e) {
										return e = `idb://${n}/${o}/${e}`, l[e] || (l[e] = new wn());
									}, d = a(""), m = a(":dels"), s = g[e](i), h = s[0], s = s[1];
									if ((e === "query" && h.isPrimaryKey && !i.values ? m : a(h.name || "")).add(s), !h.isPrimaryKey) {
										if (e !== "count") return u = e === "query" && p && i.values && c.query(t(t({}, i), { values: !1 })), c[e].apply(this, arguments).then(function(t) {
											if (e === "query") {
												if (p && i.values) return u.then(function(e) {
													return e = e.result, d.addKeys(e), t;
												});
												var n = i.values ? t.result.map(f) : t.result;
												(i.values ? d : m).addKeys(n);
											} else {
												var r, a;
												if (e === "openCursor") return a = i.values, (r = t) && Object.create(r, {
													key: { get: function() {
														return m.addKey(r.primaryKey), r.key;
													} },
													primaryKey: { get: function() {
														var e = r.primaryKey;
														return m.addKey(e), e;
													} },
													value: { get: function() {
														return a && d.addKey(r.primaryKey), r.value;
													} }
												});
											}
											return t;
										});
										m.add(r);
									}
								}
								return c[e].apply(this, arguments);
							};
						}), h;
					}
				});
			}
		};
		function Zn(e, n, r) {
			var i;
			return r.numFailures === 0 ? n : n.type === "deleteRange" || (i = n.keys ? n.keys.length : "values" in n && n.values ? n.values.length : 1, r.numFailures === i) ? null : (i = t({}, n), a(i.keys) && (i.keys = i.keys.filter(function(e, t) {
				return !(t in r.failures);
			})), "values" in i && a(i.values) && (i.values = i.values.filter(function(e, t) {
				return !(t in r.failures);
			})), i);
		}
		function Qn(e, t) {
			return n = e, ((r = t).lower === void 0 || (r.lowerOpen ? 0 < q(n, r.lower) : 0 <= q(n, r.lower))) && (n = e, (r = t).upper === void 0 || (r.upperOpen ? q(n, r.upper) < 0 : q(n, r.upper) <= 0));
			var n, r;
		}
		function $n(e, t, n, r, i, o) {
			var s, c, l, u, d, f, p;
			return !n || n.length === 0 || (s = t.query.index, c = s.multiEntry, l = t.query.range, u = r.schema.primaryKey.extractKey, d = s.extractKey, f = (s.lowLevelIndex || s).extractKey, (r = n.reduce(function(e, n) {
				var r = e, i = [];
				if (n.type === "add" || n.type === "put") for (var o = new wn(), s = n.values.length - 1; 0 <= s; --s) {
					var f, p = n.values[s], m = u(p);
					!o.hasKey(m) && (f = d(p), c && a(f) ? f.some(function(e) {
						return Qn(e, l);
					}) : Qn(f, l)) && (o.addKey(m), i.push(p));
				}
				switch (n.type) {
					case "add":
						var h = new wn().addKeys(t.values ? e.map(function(e) {
							return u(e);
						}) : e), r = e.concat(t.values ? i.filter(function(e) {
							return e = u(e), !h.hasKey(e) && (h.addKey(e), !0);
						}) : i.map(function(e) {
							return u(e);
						}).filter(function(e) {
							return !h.hasKey(e) && (h.addKey(e), !0);
						}));
						break;
					case "put":
						var g = new wn().addKeys(n.values.map(function(e) {
							return u(e);
						}));
						r = e.filter(function(e) {
							return !g.hasKey(t.values ? u(e) : e);
						}).concat(t.values ? i : i.map(function(e) {
							return u(e);
						}));
						break;
					case "delete":
						var _ = new wn().addKeys(n.keys);
						r = e.filter(function(e) {
							return !_.hasKey(t.values ? u(e) : e);
						});
						break;
					case "deleteRange":
						var v = n.range;
						r = e.filter(function(e) {
							return !Qn(u(e), v);
						});
				}
				return r;
			}, e)) === e) ? e : (p = function(e, t) {
				return q(f(e), f(t)) || q(u(e), u(t));
			}, r.sort(t.direction === "prev" || t.direction === "prevunique" ? function(e, t) {
				return p(t, e);
			} : p), t.limit && t.limit < 1 / 0 && (r.length > t.limit ? r.length = t.limit : e.length === t.limit && r.length < t.limit && (i.dirty = !0)), o ? Object.freeze(r) : r);
		}
		function er(e, t) {
			return q(e.lower, t.lower) === 0 && q(e.upper, t.upper) === 0 && !!e.lowerOpen == !!t.lowerOpen && !!e.upperOpen == !!t.upperOpen;
		}
		function tr(e, t) {
			return ((e, t, n, r) => {
				if (e === void 0) return t === void 0 ? 0 : -1;
				if (t === void 0) return 1;
				if ((e = q(e, t)) === 0) {
					if (n && r) return 0;
					if (n) return 1;
					if (r) return -1;
				}
				return e;
			})(e.lower, t.lower, e.lowerOpen, t.lowerOpen) <= 0 && 0 <= ((e, t, n, r) => {
				if (e === void 0) return t === void 0 ? 0 : 1;
				if (t === void 0) return -1;
				if ((e = q(e, t)) === 0) {
					if (n && r) return 0;
					if (n) return -1;
					if (r) return 1;
				}
				return e;
			})(e.upper, t.upper, e.upperOpen, t.upperOpen);
		}
		function nr(e, t, n, r) {
			e.subscribers.add(n), r.addEventListener("abort", function() {
				var r, i;
				e.subscribers.delete(n), e.subscribers.size === 0 && (r = e, i = t, setTimeout(function() {
					r.subscribers.size === 0 && j(i, r);
				}, 3e3));
			});
		}
		var rr = {
			stack: "dbcore",
			level: 0,
			name: "Cache",
			create: function(e) {
				var n = e.schema.name;
				return t(t({}, e), {
					transaction: function(t, r, i) {
						var a, o, s = e.transaction(t, r, i);
						return r === "readwrite" && (i = (a = new AbortController()).signal, s.addEventListener("abort", (o = function(i) {
							return function() {
								if (a.abort(), r === "readwrite") {
									for (var o = /* @__PURE__ */ new Set(), c = 0, l = t; c < l.length; c++) {
										var u = l[c], d = Nn[`idb://${n}/${u}`];
										if (d) {
											var f = e.table(u), p = d.optimisticOps.filter(function(e) {
												return e.trans === s;
											});
											if (s._explicit && i && s.mutatedParts) for (var m = 0, h = Object.values(d.queries.query); m < h.length; m++) for (var g = 0, _ = (b = h[m]).slice(); g < _.length; g++) Mn((x = _[g]).obsSet, s.mutatedParts) && (j(b, x), x.subscribers.forEach(function(e) {
												return o.add(e);
											}));
											else if (0 < p.length) {
												d.optimisticOps = d.optimisticOps.filter(function(e) {
													return e.trans !== s;
												});
												for (var v = 0, y = Object.values(d.queries.query); v < y.length; v++) for (var b, x, S, C = 0, w = (b = y[v]).slice(); C < w.length; C++) (x = w[C]).res != null && s.mutatedParts && (i && !x.dirty ? (S = Object.isFrozen(x.res), S = $n(x.res, x.req, p, f, x, S), x.dirty ? (j(b, x), x.subscribers.forEach(function(e) {
													return o.add(e);
												})) : S !== x.res && (x.res = S, x.promise = W.resolve({ result: S }))) : (x.dirty && j(b, x), x.subscribers.forEach(function(e) {
													return o.add(e);
												})));
											}
										}
									}
									o.forEach(function(e) {
										return e();
									});
								}
							};
						})(!1), { signal: i }), s.addEventListener("error", o(!1), { signal: i }), s.addEventListener("complete", o(!0), { signal: i })), s;
					},
					table: function(r) {
						var i = e.table(r), a = i.schema.primaryKey;
						return t(t({}, i), {
							mutate: function(e) {
								var o, s = U.trans;
								return !a.outbound && s.db._options.cache !== "disabled" && !s.explicit && s.idbtrans.mode === "readwrite" && (o = Nn[`idb://${n}/${r}`]) ? (s = i.mutate(e), e.type !== "add" && e.type !== "put" || !(50 <= e.values.length || Wn(a, e).some(function(e) {
									return e == null;
								})) ? (o.optimisticOps.push(e), e.mutatedParts && In(e.mutatedParts), s.then(function(t) {
									0 < t.numFailures && (j(o.optimisticOps, e), (t = Zn(0, e, t)) && o.optimisticOps.push(t), e.mutatedParts) && In(e.mutatedParts);
								}), s.catch(function() {
									j(o.optimisticOps, e), e.mutatedParts && In(e.mutatedParts);
								})) : s.then(function(n) {
									var r = Zn(0, t(t({}, e), { values: e.values.map(function(e, r) {
										var i;
										return n.failures[r] ? e : (x(i = (i = a.keyPath) != null && i.includes(".") ? O(e) : t({}, e), a.keyPath, n.results[r]), i);
									}) }), n);
									o.optimisticOps.push(r), queueMicrotask(function() {
										return e.mutatedParts && In(e.mutatedParts);
									});
								}), s) : i.mutate(e);
							},
							query: function(e) {
								var t, a, o, s, c, l, u;
								return Jn(U, i) && Yn("query", e) ? (t = (o = U.trans)?.db._options.cache === "immutable", a = (o = U).requery, o = o.signal, l = ((e, t, n, r) => {
									var i = Nn[`idb://${e}/${t}`];
									if (!i) return [];
									if (!(e = i.queries[n])) return [
										null,
										!1,
										i,
										null
									];
									var a = e[(r.query ? r.query.index.name : null) || ""];
									if (!a) return [
										null,
										!1,
										i,
										null
									];
									switch (n) {
										case "query":
											var o = (s = r.direction) ?? "next", s = a.find(function(e) {
												return e.req.limit === r.limit && e.req.values === r.values && (e.req.direction ?? "next") === o && er(e.req.query.range, r.query.range);
											});
											return s ? [
												s,
												!0,
												i,
												a
											] : [
												a.find(function(e) {
													return ("limit" in e.req ? e.req.limit : 1 / 0) >= r.limit && (e.req.direction ?? "next") === o && (!r.values || e.req.values) && tr(e.req.query.range, r.query.range);
												}),
												!1,
												i,
												a
											];
										case "count": return s = a.find(function(e) {
											return er(e.req.query.range, r.query.range);
										}), [
											s,
											!!s,
											i,
											a
										];
									}
								})(n, r, "query", e), u = l[0], s = l[2], c = l[3], u && l[1] ? u.obsSet = e.obsSet : (l = i.query(e).then(function(e) {
									var n = e.result;
									if (u && (u.res = n), t) {
										for (var r = 0, i = n.length; r < i; ++r) Object.freeze(n[r]);
										Object.freeze(n);
									}
									return e;
								}).catch(function(e) {
									return c && u && j(c, u), Promise.reject(e);
								}), u = {
									obsSet: e.obsSet,
									promise: l,
									subscribers: /* @__PURE__ */ new Set(),
									type: "query",
									req: e,
									dirty: !1
								}, c ? c.push(u) : (c = [u], (s ||= Nn[`idb://${n}/${r}`] = {
									queries: {
										query: {},
										count: {}
									},
									objs: /* @__PURE__ */ new Map(),
									optimisticOps: [],
									unsignaledParts: {}
								}).queries.query[e.query.index.name || ""] = c)), nr(u, c, a, o), u.promise.then(function(n) {
									return n = $n(n.result, e, s?.optimisticOps, i, u, t), { result: t ? n : O(n) };
								})) : i.query(e);
							}
						});
					}
				});
			}
		};
		function ir(e, t) {
			return new Proxy(e, { get: function(e, n, r) {
				return n === "db" ? t : Reflect.get(e, n, r);
			} });
		}
		or.prototype.version = function(e) {
			if (isNaN(e) || e < .1) throw new I.Type("Given version is not a positive number");
			if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new I.Schema("Cannot add version when database is open");
			this.verno = Math.max(this.verno, e);
			var t = this._versions, n = t.filter(function(t) {
				return t._cfg.version === e;
			})[0];
			return n || (n = new this.Version(e), t.push(n), t.sort(sn), n.stores({}), this._state.autoSchema = !1), n;
		}, or.prototype._whenReady = function(e) {
			var t = this;
			return this.idbdb && (this._state.openComplete || U.letThrough || this._vip) ? e() : new W(function(e, n) {
				if (t._state.openComplete) return n(new I.DatabaseClosed(t._state.dbOpenError));
				if (!t._state.isBeingOpened) {
					if (!t._state.autoOpen) return void n(new I.DatabaseClosed());
					t.open().catch(R);
				}
				t._state.dbReadyPromise.then(e, n);
			}).then(e);
		}, or.prototype.use = function(e) {
			var t = e.stack, n = e.create, r = e.level, e = e.name, i = (e && this.unuse({
				stack: t,
				name: e
			}), this._middlewares[t] || (this._middlewares[t] = []));
			return i.push({
				stack: t,
				create: n,
				level: r ?? 10,
				name: e
			}), i.sort(function(e, t) {
				return e.level - t.level;
			}), this;
		}, or.prototype.unuse = function(e) {
			var t = e.stack, n = e.name, r = e.create;
			return t && this._middlewares[t] && (this._middlewares[t] = this._middlewares[t].filter(function(e) {
				return r ? e.create !== r : !!n && e.name !== n;
			})), this;
		}, or.prototype.open = function() {
			var e = this;
			return et(H, function() {
				return zn(e);
			});
		}, or.prototype._close = function() {
			this.on.close.fire(new CustomEvent("close"));
			var e = this._state;
			if (yn.remove(this), this.idbdb) {
				try {
					this.idbdb.close();
				} catch {}
				this.idbdb = null;
			}
			e.isBeingOpened || (e.dbReadyPromise = new W(function(t) {
				e.dbReadyResolve = t;
			}), e.openCanceller = new W(function(t, n) {
				e.cancelOpen = n;
			}));
		}, or.prototype.close = function(e) {
			var e = (e === void 0 ? { disableAutoOpen: !0 } : e).disableAutoOpen, t = this._state;
			e ? (t.isBeingOpened && t.cancelOpen(new I.DatabaseClosed()), this._close(), t.autoOpen = !1, t.dbOpenError = new I.DatabaseClosed()) : (this._close(), t.autoOpen = this._options.autoOpen || t.isBeingOpened, t.openComplete = !1, t.dbOpenError = null);
		}, or.prototype.delete = function(e) {
			var t = this, n = (e === void 0 && (e = { disableAutoOpen: !0 }), 0 < arguments.length && typeof arguments[0] != "object"), r = this._state;
			return new W(function(i, a) {
				function o() {
					t.close(e);
					var n = t._deps.indexedDB.deleteDatabase(t.name);
					n.onsuccess = G(function() {
						var e = t._deps, n = t.name, r;
						xn(r = e.indexedDB) || n === st || bn(r, e.IDBKeyRange).delete(n).catch(R), i();
					}), n.onerror = Vt(a), n.onblocked = t._fireOnBlocked;
				}
				if (n) throw new I.InvalidArgument("Invalid closeOptions argument to db.delete()");
				r.isBeingOpened ? r.dbReadyPromise.then(o) : o();
			});
		}, or.prototype.backendDB = function() {
			return this.idbdb;
		}, or.prototype.isOpen = function() {
			return this.idbdb !== null;
		}, or.prototype.hasBeenClosed = function() {
			var e = this._state.dbOpenError;
			return e && e.name === "DatabaseClosed";
		}, or.prototype.hasFailed = function() {
			return this._state.dbOpenError !== null;
		}, or.prototype.dynamicallyOpened = function() {
			return this._state.autoSchema;
		}, Object.defineProperty(or.prototype, "tables", {
			get: function() {
				var e = this;
				return i(this._allTables).map(function(t) {
					return e._allTables[t];
				});
			},
			enumerable: !1,
			configurable: !0
		}), or.prototype.transaction = function() {
			var e = function(e, t, n) {
				var r = arguments.length;
				if (r < 2) throw new I.InvalidArgument("Too few arguments");
				for (var i = Array(r - 1); --r;) i[r - 1] = arguments[r];
				return n = i.pop(), [
					e,
					w(i),
					n
				];
			}.apply(this, arguments);
			return this._transaction.apply(this, e);
		}, or.prototype._transaction = function(e, t, n) {
			var r, i, a = this, o = U.trans, s = (o && o.db === this && e.indexOf("!") === -1 || (o = null), e.indexOf("?") !== -1);
			e = e.replace("!", "").replace("?", "");
			try {
				if (i = t.map(function(e) {
					if (e = e instanceof a.Table ? e.name : e, typeof e != "string") throw TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
					return e;
				}), e == "r" || e === ct) r = ct;
				else {
					if (e != "rw" && e != lt) throw new I.InvalidArgument("Invalid transaction mode: " + e);
					r = lt;
				}
				if (o) {
					if (o.mode === ct && r === lt) {
						if (!s) throw new I.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
						o = null;
					}
					o && i.forEach(function(e) {
						if (o && o.storeNames.indexOf(e) === -1) {
							if (!s) throw new I.SubTransaction("Table " + e + " not included in parent transaction.");
							o = null;
						}
					}), s && o && !o.active && (o = null);
				}
			} catch (e) {
				return o ? o._promise(null, function(t, n) {
					n(e);
				}) : rt(e);
			}
			var c = function e(t, n, r, i, a) {
				return W.resolve().then(function() {
					var o = U.transless || U, s = t._createTransaction(n, r, t._dbSchema, i), o = (s.explicit = !0, {
						trans: s,
						transless: o
					});
					if (i) s.idbtrans = i.idbtrans;
					else try {
						s.create(), s.idbtrans._explicit = !0, t._state.PR1398_maxLoop = 3;
					} catch (i) {
						return i.name === se.InvalidState && t.isOpen() && 0 < --t._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), t.close({ disableAutoOpen: !1 }), t.open().then(function() {
							return e(t, n, r, null, a);
						})) : rt(i);
					}
					var c, l = ie(a), o = (l && Je(), W.follow(function() {
						var e;
						(c = a.call(s, s)) && (l ? (e = Ye.bind(null, null), c.then(e, e)) : typeof c.next == "function" && typeof c.throw == "function" && (c = Bn(c)));
					}, o));
					return (c && typeof c.then == "function" ? W.resolve(c).then(function(e) {
						return s.active ? e : rt(new I.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
					}) : o.then(function() {
						return c;
					})).then(function(e) {
						return i && s._resolve(), s._completion.then(function() {
							return e;
						});
					}).catch(function(e) {
						return s._reject(e), rt(e);
					});
				});
			}.bind(null, this, r, i, o, n);
			return o ? o._promise(r, c, "lock") : U.trans ? et(U.transless, function() {
				return a._whenReady(c);
			}) : this._whenReady(c);
		}, or.prototype.table = function(e) {
			if (l(this._allTables, e)) return this._allTables[e];
			throw new I.InvalidTable(`Table ${e} does not exist`);
		};
		var ar = or;
		function or(e, n) {
			var r, i, a, o, s, c = this, l = (this._middlewares = {}, this.verno = 0, or.dependencies), l = (this._options = n = t({
				addons: or.addons,
				autoOpen: !0,
				indexedDB: l.indexedDB,
				IDBKeyRange: l.IDBKeyRange,
				cache: "cloned",
				maxConnections: 1e3
			}, n), this._deps = {
				indexedDB: n.indexedDB,
				IDBKeyRange: n.IDBKeyRange
			}, n.addons), u = (this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this, {
				dbOpenError: null,
				isBeingOpened: !1,
				onReadyBeingFired: null,
				openComplete: !1,
				dbReadyResolve: R,
				dbReadyPromise: null,
				cancelOpen: R,
				openCanceller: null,
				autoSchema: !0,
				PR1398_maxLoop: 3,
				autoOpen: n.autoOpen
			}), d = (u.dbReadyPromise = new W(function(e) {
				u.dbReadyResolve = e;
			}), u.openCanceller = new W(function(e, t) {
				u.cancelOpen = t;
			}), this._state = u, this.name = e, this.on = xt(this, "populate", "blocked", "versionchange", "close", { ready: [B, R] }), this.once = function(e, t) {
				var n = function() {
					var r = [...arguments];
					c.on(e).unsubscribe(n), t.apply(c, r);
				};
				return c.on(e, n);
			}, this.on.ready.subscribe = _(this.on.ready.subscribe, function(e) {
				return function(t, n) {
					or.vip(function() {
						var r, i = c._state;
						i.openComplete ? (i.dbOpenError || W.resolve().then(t), n && e(t)) : i.onReadyBeingFired ? (i.onReadyBeingFired.push(t), n && e(t)) : (e(t), r = c, n || e(function e() {
							r.on.ready.unsubscribe(t), r.on.ready.unsubscribe(e);
						}));
					});
				};
			}), this.Collection = (r = this, St(At.prototype, function(e, t) {
				this.db = r;
				var n = dt, i = null;
				if (t) try {
					n = t();
				} catch (e) {
					i = e;
				}
				var t = e._ctx, e = t.table, a = e.hook.reading.fire;
				this._ctx = {
					table: e,
					index: t.index,
					isPrimKey: !t.index || e.schema.primKey.keyPath && t.index === e.schema.primKey.name,
					range: n,
					keysOnly: !1,
					dir: "next",
					unique: "",
					algorithm: null,
					filter: null,
					replayFilter: null,
					justLimit: !0,
					isMatch: null,
					offset: 0,
					limit: 1 / 0,
					error: i,
					or: t.or,
					valueMapper: a === le ? null : a
				};
			})), this.Table = (i = this, St(bt.prototype, function(e, t, n) {
				this.db = i, this._tx = n, this.name = e, this.schema = t, this.hook = i._allTables[e] ? i._allTables[e].hook : xt(null, {
					creating: [fe, R],
					reading: [ue, le],
					updating: [pe, R],
					deleting: [z, R]
				});
			})), this.Transaction = (a = this, St(Kt.prototype, function(e, t, n, r, i) {
				var o = this;
				e !== "readonly" && t.forEach(function(e) {
					e = (e = n[e])?.yProps, e && (t = t.concat(e.map(function(e) {
						return e.updatesTable;
					})));
				}), this.db = a, this.mode = e, this.storeNames = t, this.schema = n, this.chromeTransactionDurability = r, this.idbtrans = null, this.on = xt(this, "complete", "error", "abort"), this.parent = i || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new W(function(e, t) {
					o._resolve = e, o._reject = t;
				}), this._completion.then(function() {
					o.active = !1, o.on.complete.fire();
				}, function(e) {
					var t = o.active;
					return o.active = !1, o.on.error.fire(e), o.parent ? o.parent._reject(e) : t && o.idbtrans && o.idbtrans.abort(), rt(e);
				});
			})), this.Version = (o = this, St(_n.prototype, function(e) {
				this.db = o, this._cfg = {
					version: e,
					storesSource: null,
					dbschema: {},
					tables: {},
					contentUpgrade: null
				};
			})), this.WhereClause = (s = this, St(zt.prototype, function(e, t, n) {
				if (this.db = s, this._ctx = {
					table: e,
					index: t === ":id" ? null : t,
					or: n
				}, this._cmp = this._ascending = q, this._descending = function(e, t) {
					return q(t, e);
				}, this._max = function(e, t) {
					return 0 < q(e, t) ? e : t;
				}, this._min = function(e, t) {
					return q(e, t) < 0 ? e : t;
				}, this._IDBKeyRange = s._deps.IDBKeyRange, !this._IDBKeyRange) throw new I.MissingAPI();
			})), this.on("versionchange", function(e) {
				0 < e.newVersion ? console.warn(`Another connection wants to upgrade database '${c.name}'. Closing db now to resume the upgrade.`) : console.warn(`Another connection wants to delete database '${c.name}'. Closing db now to resume the delete request.`), c.close({ disableAutoOpen: !1 });
			}), this.on("blocked", function(e) {
				!e.newVersion || e.newVersion < e.oldVersion ? console.warn(`Dexie.delete('${c.name}') was blocked`) : console.warn(`Upgrade '${c.name}' blocked by other connection holding version ${e.oldVersion / 10}`);
			}), this._maxKey = Zt(n.IDBKeyRange), this._createTransaction = function(e, t, n, r) {
				return new c.Transaction(e, t, n, c._options.chromeTransactionDurability, r);
			}, this._fireOnBlocked = function(e) {
				c.on("blocked").fire(e), yn.toArray().filter(function(e) {
					return e.name === c.name && e !== c && !e._state.vcFired;
				}).map(function(t) {
					return t.on("versionchange").fire(e);
				});
			}, this.use(qn), this.use(rr), this.use(Xn), this.use(Hn), this.use(Gn), new Proxy(this, { get: function(e, t, n) {
				var r;
				return t === "_vip" || (t === "table" ? function(e) {
					return ir(c.table(e), d);
				} : (r = Reflect.get(e, t, n)) instanceof bt ? ir(r, d) : t === "tables" ? r.map(function(e) {
					return ir(e, d);
				}) : t === "_createTransaction" ? function() {
					return ir(r.apply(this, arguments), d);
				} : r);
			} }));
			this.vip = d, l.forEach(function(e) {
				return e(c);
			});
		}
		var sr, be = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", cr = (lr.prototype.subscribe = function(e, t, n) {
			return this._subscribe(e && typeof e != "function" ? e : {
				next: e,
				error: t,
				complete: n
			});
		}, lr.prototype[be] = function() {
			return this;
		}, lr);
		function lr(e) {
			this._subscribe = e;
		}
		try {
			sr = {
				indexedDB: r.indexedDB || r.mozIndexedDB || r.webkitIndexedDB || r.msIndexedDB,
				IDBKeyRange: r.IDBKeyRange || r.webkitIDBKeyRange
			};
		} catch {
			sr = {
				indexedDB: null,
				IDBKeyRange: null
			};
		}
		function ur(e) {
			var t, n = !1, r = new cr(function(r) {
				var i = ie(e), a, o = !1, s = {}, c = {}, l = {
					get closed() {
						return o;
					},
					unsubscribe: function() {
						o || (o = !0, a && a.abort(), u && Gt.storagemutated.unsubscribe(p));
					}
				}, u = (r.start && r.start(l), !1), d = function() {
					return nt(m);
				};
				function f() {
					return Mn(c, s);
				}
				var p = function(e) {
					jn(s, e), f() && d();
				}, m = function() {
					var l, m, h;
					!o && sr.indexedDB && (s = {}, l = {}, a && a.abort(), a = new AbortController(), h = ((t) => {
						var n = Re();
						try {
							i && Je();
							var r = qe(e, t);
							return r = i ? r.finally(Ye) : r;
						} finally {
							n && ze();
						}
					})(m = {
						subscr: l,
						signal: a.signal,
						requery: d,
						querier: e,
						trans: null
					}), u ||= (Gt.storagemutated.subscribe(p), !0), Promise.resolve(h).then(function(e) {
						n = !0, t = e, o || m.signal.aborted || (f() || (c = l, f()) ? d() : (s = {}, nt(function() {
							return !o && r.next && r.next(e);
						})));
					}, function(e) {
						n = !1, ["DatabaseClosedError", "AbortError"].includes(e?.name) || o || nt(function() {
							o || r.error && r.error(e);
						});
					}));
				};
				return setTimeout(d, 0), l;
			});
			return r.hasValue = function() {
				return n;
			}, r.getValue = function() {
				return t;
			}, r;
		}
		var dr = ar;
		function fr(e) {
			var t = mr;
			try {
				mr = !0, Gt.storagemutated.fire(e), Ln(e, !0);
			} finally {
				mr = t;
			}
		}
		u(dr, t(t({}, T), {
			delete: function(e) {
				return new dr(e, { addons: [] }).delete();
			},
			exists: function(e) {
				return new dr(e, { addons: [] }).open().then(function(e) {
					return e.close(), !0;
				}).catch("NoSuchDatabaseError", function() {
					return !1;
				});
			},
			getDatabaseNames: function(e) {
				try {
					return t = dr.dependencies, n = t.indexedDB, t = t.IDBKeyRange, (xn(n) ? Promise.resolve(n.databases()).then(function(e) {
						return e.map(function(e) {
							return e.name;
						}).filter(function(e) {
							return e !== st;
						});
					}) : bn(n, t).toCollection().primaryKeys()).then(e);
				} catch {
					return rt(new I.MissingAPI());
				}
				var t, n;
			},
			defineClass: function() {
				return function(e) {
					o(this, e);
				};
			},
			ignoreTransaction: function(e) {
				return U.trans ? et(U.transless || H, e) : e();
			},
			vip: Sn,
			async: function(e) {
				return function() {
					try {
						var t = Bn(e.apply(this, arguments));
						return t && typeof t.then == "function" ? t : W.resolve(t);
					} catch (e) {
						return rt(e);
					}
				};
			},
			spawn: function(e, t, n) {
				try {
					var r = Bn(e.apply(n, t || []));
					return r && typeof r.then == "function" ? r : W.resolve(r);
				} catch (e) {
					return rt(e);
				}
			},
			currentTransaction: { get: function() {
				return U.trans || null;
			} },
			waitFor: function(e, t) {
				return e = W.resolve(typeof e == "function" ? dr.ignoreTransaction(e) : e).timeout(t || 6e4), U.trans ? U.trans.waitFor(e) : e;
			},
			Promise: W,
			debug: {
				get: function() {
					return he;
				},
				set: function(e) {
					ge(e);
				}
			},
			derive: p,
			extend: o,
			props: u,
			override: _,
			Events: xt,
			on: Gt,
			liveQuery: ur,
			extendObservabilitySet: jn,
			getByKeyPath: b,
			setByKeyPath: x,
			delByKeyPath: function(e, t) {
				typeof t == "string" ? x(e, t, void 0) : "length" in t && [].map.call(t, function(t) {
					x(e, t, void 0);
				});
			},
			shallowClone: S,
			deepClone: O,
			getObjectDiff: Un,
			cmp: q,
			asap: y,
			minKey: -1 / 0,
			addons: [],
			connections: { get: yn.toArray },
			errnames: se,
			dependencies: sr,
			cache: Nn,
			semVer: "4.4.6",
			version: "4.4.6".split(".").map(function(e) {
				return parseInt(e);
			}).reduce(function(e, t, n) {
				return e + t / 10 ** (2 * n);
			})
		})), dr.maxKey = Zt(dr.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (Gt(Ut, function(e) {
			mr ||= (e = new CustomEvent(Wt, { detail: e }), mr = !0, dispatchEvent(e), !1);
		}), addEventListener(Wt, function(e) {
			e = e.detail, mr || fr(e);
		}));
		var pr, mr = !1, hr = function() {};
		return typeof BroadcastChannel < "u" && ((hr = function() {
			(pr = new BroadcastChannel(Wt)).onmessage = function(e) {
				return e.data && fr(e.data);
			};
		})(), typeof pr.unref == "function" && pr.unref(), Gt(Ut, function(e) {
			mr || pr.postMessage(e);
		})), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
			if (!ar.disableBfCache && e.persisted) {
				he && console.debug("Dexie: handling persisted pagehide"), pr?.close();
				for (var t = 0, n = yn.toArray(); t < n.length; t++) n[t].close({ disableAutoOpen: !1 });
			}
		}), addEventListener("pageshow", function(e) {
			!ar.disableBfCache && e.persisted && (he && console.debug("Dexie: handling persisted pageshow"), hr(), fr({ all: new wn(-1 / 0, [[]]) }));
		})), W.rejectionMapper = function(e, t) {
			return !e || e instanceof N || e instanceof TypeError || e instanceof SyntaxError || !e.name || !L[e.name] ? e : (t = new L[e.name](t || e.message, e), "stack" in e && f(t, "stack", { get: function() {
				return this.inner.stack;
			} }), t);
		}, ge(he), t(ar, Object.freeze({
			__proto__: null,
			DEFAULT_MAX_CONNECTIONS: 1e3,
			Dexie: ar,
			Entity: pt,
			PropModification: _t,
			RangeSet: wn,
			add: function(e) {
				return new _t({ add: e });
			},
			cmp: q,
			default: ar,
			liveQuery: ur,
			mergeRanges: En,
			rangesOverlap: Dn,
			remove: function(e) {
				return new _t({ remove: e });
			},
			replacePrefix: function(e, t) {
				return new _t({ replacePrefix: [e, t] });
			}
		}), { default: ar }), ar;
	});
})))(), 1), Ae = Symbol.for("Dexie"), W = globalThis[Ae] || (globalThis[Ae] = ke.default);
if (ke.default.semVer !== W.semVer) throw Error(`Two different versions of Dexie loaded in the same app: ${ke.default.semVer} and ${W.semVer}`);
var { liveQuery: je, mergeRanges: Me, rangesOverlap: Ne, RangeSet: Pe, cmp: Fe, Entity: Ie, PropModification: Le, replacePrefix: Re, add: ze, remove: Be, DexieYProvider: Ve } = W, G = 8388608, He = 268435456, Ue = 4e6, K = () => {
	throw new z("SAVE_FAILED", "大きな履歴の分割記録が破損しています。既存データを保持しています。");
}, We = JSON.stringify, Ge = Object.getOwnPropertyDescriptor, Ke = Object.getPrototypeOf, qe = Object.prototype, Je = Array.prototype, Ye = Number.prototype;
function Xe() {
	return JSON.stringify === We && Ke(qe) === null && Ke(Je) === qe && Ge(qe, "toJSON") === void 0 && Ge(Je, "toJSON") === void 0 && Ge(Ye, "toJSON") === void 0;
}
var Ze = (e) => {
	let t = (e) => {
		if (e === null) return "null";
		if (typeof e == "boolean") return e ? "true" : "false";
		if (typeof e == "number") return Number.isFinite(e) ? JSON.stringify(e) : h(e);
		if (e && typeof e == "object" && !Array.isArray(e)) {
			let t = Object.keys(e), n = e;
			if (t.length === 1 && t[0] === "undefined" && Object.hasOwn(e, "undefined") && n.undefined === !0) return "{\"undefined\":true}";
			if (t.length === 1 && t[0] === "number" && Object.hasOwn(e, "number") && typeof n.number == "number" && Number.isFinite(n.number)) return "{\"number\":" + JSON.stringify(n.number) + "}";
		}
		return h(e);
	}, n = [];
	for (let r = 0; r < e.length; r++) n.push(t(e[r]));
	return "[" + n.join(",") + "]";
};
async function Qe(e, t, n, r) {
	B(n);
	let i = [], a = /* @__PURE__ */ new WeakMap(), o = /* @__PURE__ */ new WeakSet(), s = [], c = /* @__PURE__ */ new Map(), l = (e) => {
		let t = c.get(e);
		return t === void 0 && (t = s.length, s.push(e), c.set(e, t)), t;
	}, u = (e) => {
		if (e === void 0) return { undefined: !0 };
		if (typeof e == "string") return -l(e) - 1;
		if (typeof e == "number") return Number.isFinite(e) ? { number: e } : K();
		if (e === null || typeof e == "boolean") return e;
		if (!e || typeof e != "object" || !Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return K();
		let t = a.get(e);
		if (t !== void 0) return o.has(e) ? K() : t;
		let n = i.length;
		if (n >= Ue) return K();
		a.set(e, n), o.add(e);
		let s = [+!Array.isArray(e)];
		if (i.push(s), Array.isArray(e)) {
			if (Object.keys(e).length !== e.length) return K();
			if (r) for (let t = 0; t < e.length; t++) s.push(u(e[t]));
			else for (let t of e) s.push(u(t));
		} else if (r) for (let t of Object.keys(e)) s.push(l(t), u(e[t]));
		else for (let [t, n] of Object.entries(e)) s.push(l(t), u(n));
		return o.delete(e), n;
	}, d = u(e), f = [], p = 0, m = new TextEncoder(), g = r && Xe();
	for (let [e, a] of [["strings", s], ["nodes", i]]) {
		let i = [], o = 0, s = async () => {
			if (!i.length) return;
			B(n);
			let a = m.encode(`[${i.join(",")}]`);
			if (p += a.byteLength, a.byteLength > G || p > He) throw new z("LIMIT_EXCEEDED", "履歴の分割記録が端末の安全上限を超えています。");
			let s = f.length;
			f.push({
				key: `${t}:${s}`,
				scope: t,
				sequence: s,
				kind: e,
				bytes: a,
				sha256: await A(a)
			}), B(n), g = r && Xe(), i = [], o = 0;
		};
		for (let t of a) {
			let n = e === "nodes" ? g ? We(t) : Ze(t) : h(t), a = e === "nodes" ? n.length : r ? $e(n) : m.encode(n).byteLength;
			if (a > G) return K();
			i.length && o + a + i.length + 2 > G / 4 && await s(), i.push(n), o += a;
		}
		await s();
	}
	return B(n), {
		packed: {
			version: 1,
			scope: t,
			root: d,
			nodes: i.length,
			strings: s.length,
			parts: f.map((e) => ({
				key: e.key,
				kind: e.kind,
				bytes: e.bytes.byteLength,
				sha256: e.sha256
			}))
		},
		parts: f
	};
}
function $e(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		r < 128 ? t++ : r < 2048 ? t += 2 : r >= 55296 && r <= 56319 ? (t += 4, n++) : t += 3;
	}
	return t;
}
function et(e, t, n) {
	return Qe(e, t, n, !1);
}
async function tt(e, t, n) {
	if (B(n), e.version !== 1 || typeof e.scope != "string" || !Number.isSafeInteger(e.nodes) || e.nodes < 0 || e.nodes > Ue || !Number.isSafeInteger(e.strings) || e.strings < 0 || e.strings > Ue || !Array.isArray(e.parts) || e.parts.length !== t.length || new Set(t.map((e) => e.key)).size !== t.length) return K();
	let r = 0;
	for (let e of t) if (!(e.bytes instanceof Uint8Array) || e.bytes.byteLength > G || (r += e.bytes.byteLength, r > He)) return K();
	e = structuredClone(e), t = t.map((e) => ({
		...e,
		bytes: new Uint8Array(e.bytes)
	}));
	let i = [], a = [], o = new Map(t.map((e) => [e.key, e])), s = 0;
	for (let [t, r] of e.parts.entries()) {
		B(n);
		let c = o.get(r.key);
		if (!c || c.scope !== e.scope || c.sequence !== t || r.key !== `${e.scope}:${t}` || !["strings", "nodes"].includes(r.kind) || c.kind !== r.kind || !(c.bytes instanceof Uint8Array) || c.bytes.byteLength !== r.bytes || r.bytes > G || c.sha256 !== r.sha256 || !/^([a-f0-9]{64})$/.test(r.sha256) || await A(c.bytes) !== r.sha256 || (s += r.bytes, s > He)) return K();
		let l = le(c.bytes, c.key, {
			...F,
			jsonBytes: G,
			expandedBytes: He
		});
		if (!Array.isArray(l)) return K();
		if (c.kind === "strings") {
			if (a.length + l.length > e.strings || l.some((e) => typeof e != "string")) return K();
			for (let e of l) a.push(e);
		} else {
			if (i.length + l.length > e.nodes) return K();
			for (let e of l) i.push(e);
		}
	}
	if (i.length !== e.nodes || a.length !== e.strings || new Set(a).size !== a.length) return K();
	let c = /* @__PURE__ */ new Set(), l = (e) => !Number.isSafeInteger(e) || e < 0 || e >= a.length ? K() : (c.add(e), a[e]), u = (e) => {
		if (e !== null && typeof e != "boolean") {
			if (typeof e == "number") {
				if (!Number.isSafeInteger(e)) return K();
				if (e < 0) {
					l(-e - 1);
					return;
				}
				return e >= i.length ? K() : e;
			}
			if (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).length !== 1 || !("undefined" in e && e.undefined === !0) && !("number" in e && typeof e.number == "number" && Number.isFinite(e.number))) return K();
		}
	}, d = (e) => {
		if (!Array.isArray(e) || e[0] !== 0 && e[0] !== 1) return K();
		if (e[0] === 0) return e.slice(1);
		if (e.length % 2 != 1) return K();
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 1; r < e.length; r += 2) {
			let i = l(e[r]);
			if (t.has(i)) return K();
			t.add(i), n.push(e[r + 1]);
		}
		return n;
	};
	u(e.root);
	for (let e of i) for (let t of d(e)) u(t);
	let f = new Uint8Array(i.length), p = u(e.root), m = 0;
	if (p !== void 0) {
		let e = [{
			id: p,
			next: 1
		}];
		for (; e.length;) {
			let t = e.at(-1), n = i[t.id];
			if (f[t.id] || (f[t.id] = 1, m++), t.next >= n.length) {
				f[t.id] = 2, e.pop();
				continue;
			}
			let r = t.next + +(n[0] === 1);
			t.next += n[0] === 1 ? 2 : 1;
			let a = u(n[r]);
			if (a !== void 0) {
				if (f[a] === 1 || e.length > 64) return K();
				f[a] || e.push({
					id: a,
					next: 1
				});
			}
		}
	}
	if (m !== i.length || c.size !== a.length) return K();
	let h = i.map((e) => e[0] === 0 ? [] : {}), g = (e) => typeof e == "number" ? e < 0 ? l(-e - 1) : h[e] : e && typeof e == "object" ? "number" in e ? e.number : void 0 : e;
	for (let [e, t] of i.entries()) if (t[0] === 0) for (let n = 1; n < t.length; n++) h[e].push(g(t[n]));
	else for (let n = 1; n < t.length; n += 2) Object.defineProperty(h[e], l(t[n]), {
		value: g(t[n + 1]),
		enumerable: !0,
		configurable: !0,
		writable: !0
	});
	return B(n), g(e.root);
}
function nt(e, t = 8388608) {
	let n = 0, r = /* @__PURE__ */ new WeakSet(), i = [e];
	for (; i.length && n <= t;) {
		let e = i.pop();
		if (typeof e == "string") n += e.length * 2 + 16;
		else if (e && typeof e == "object") {
			if (r.has(e)) continue;
			r.add(e), n += 32;
			for (let [t, r] of Object.entries(e)) n += t.length * 2 + 16, i.push(r);
		} else n += 16;
	}
	return n > t;
}
//#endregion
//#region src/storage/workerGraph.ts
async function rt(e, t, n, r = () => !0) {
	let i = /* @__PURE__ */ new WeakMap(), a = [], o = {
		type: "graph-chunk",
		declarations: [],
		properties: []
	}, s = 0, c = (e) => {
		if (typeof e != "object" || !e) return { value: e };
		let t = i.get(e);
		return t === void 0 && (t = a.length, i.set(e, t), a.push({
			value: e,
			id: t,
			keys: Array.isArray(e) ? void 0 : Object.keys(e),
			index: 0
		}), o.declarations.push({
			id: t,
			...Array.isArray(e) ? { arrayLength: e.length } : Object.getPrototypeOf(e) === null ? { nullPrototype: !0 } : {}
		})), { reference: t };
	}, l = c(e), u = async () => {
		if (B(n), !r() || (t(o), o = {
			type: "graph-chunk",
			declarations: [],
			properties: []
		}, s = 0, await new Promise((e) => setTimeout(e, 0)), B(n), !r())) throw new z("CANCELLED", "保存の受渡しを取り消しました。");
	};
	for (let e = 0; e < a.length; e++) {
		let t = a[e], n = t.keys?.length ?? t.value.length;
		for (; t.index < n;) {
			let e = t.keys?.[t.index] ?? String(t.index), n = Object.getOwnPropertyDescriptor(t.value, e);
			if (!n || !Object.hasOwn(n, "value")) throw new z("SAVE_FAILED", "固定した保存内容が変更されています。");
			o.properties.push({
				id: t.id,
				key: e,
				value: c(n.value)
			}), s += e.length * 2 + (typeof n.value == "string" ? n.value.length * 2 : 32), t.index++, (o.properties.length >= 4096 || s >= 262144) && await u();
		}
		a[e] = void 0;
	}
	if ((o.declarations.length || o.properties.length) && await u(), B(n), !r()) throw new z("CANCELLED", "保存の受渡しを取り消しました。");
	t({
		type: "graph-end",
		root: l.reference
	});
}
var it = class {
	values = /* @__PURE__ */ new Map();
	accept(e) {
		for (let t of e.declarations) {
			if (!Number.isSafeInteger(t.id) || t.id < 0 || this.values.has(t.id) || t.arrayLength !== void 0 && (!Number.isSafeInteger(t.arrayLength) || t.arrayLength < 0)) throw new z("SAVE_FAILED", "保存の受渡し情報が不正です。");
			this.values.set(t.id, t.arrayLength === void 0 ? Object.create(t.nullPrototype ? null : Object.prototype) : Array(t.arrayLength));
		}
		for (let t of e.properties) {
			let e = this.values.get(t.id);
			if (!e || [
				"__proto__",
				"constructor",
				"prototype"
			].includes(t.key) || Object.hasOwn(e, t.key) || Array.isArray(e) && (!/^(0|[1-9]\d*)$/.test(t.key) || Number(t.key) >= e.length)) throw new z("SAVE_FAILED", "保存の受渡し項目が不正です。");
			let n = "reference" in t.value ? this.values.get(t.value.reference) : t.value.value;
			if ("reference" in t.value && n === void 0) throw new z("SAVE_FAILED", "保存の受渡し参照が不足しています。");
			Object.defineProperty(e, t.key, {
				value: n,
				enumerable: !0,
				writable: !0,
				configurable: !0
			});
		}
	}
	finish(e) {
		let t = this.values.get(e);
		if (!t) throw new z("SAVE_FAILED", "保存の受渡し内容がありません。");
		return this.values.clear(), t;
	}
}, at = 131072;
async function ot(e, t) {
	B(t);
	let n = [], r = 0;
	for (let i of e.parts) {
		let e = i.bytes;
		if (e.byteLength <= at) {
			let t = e.byteOffset === 0 && e.buffer.byteLength === e.byteLength ? e : e.slice();
			n.push({
				kind: i.kind,
				bytes: t,
				sha256: i.sha256
			}), r += t.byteLength;
			continue;
		}
		if (e[0] !== 91 || e.at(-1) !== 93) throw new z("SAVE_FAILED", "取り込む分割記録の配列が不正です。");
		let a = 1, o = 1, s = 0, c = !1, l = !1, u = (t) => {
			let o = new Uint8Array(t - a + 2);
			o[0] = 91, o.set(e.subarray(a, t), 1), o[o.length - 1] = 93, n.push({
				kind: i.kind,
				bytes: o
			}), r += o.byteLength;
		};
		for (let n = 1; n < e.length; n++) {
			n % 4096 == 0 && B(t);
			let r = e[n];
			if (c) {
				l ? l = !1 : r === 92 ? l = !0 : r === 34 && (c = !1);
				continue;
			}
			if (r === 34) {
				c = !0;
				continue;
			}
			let i = n === e.length - 1;
			if (!i && (r === 91 || r === 123)) {
				s++;
				continue;
			}
			if (!i && (r === 93 || r === 125)) {
				s--;
				continue;
			}
			(i || r === 44 && s === 0) && n - a + 2 > at && o > a && (u(o - 1), a = o), i ? u(n) : r === 44 && s === 0 && (o = n + 1);
		}
	}
	if (r > 268435456) return e;
	let i = [];
	for (let r of n) {
		B(t);
		let n = i.length, a = r.sha256 ?? await A(r.bytes);
		B(t), i.push({
			key: `${e.packed.scope}:${n}`,
			scope: e.packed.scope,
			sequence: n,
			kind: r.kind,
			bytes: r.bytes,
			sha256: a
		});
	}
	return {
		packed: {
			...e.packed,
			parts: i.map((e) => ({
				key: e.key,
				kind: e.kind,
				bytes: e.bytes.byteLength,
				sha256: e.sha256
			}))
		},
		parts: i
	};
}
//#endregion
//#region src/observability/workerProbe.ts
function st(e, t) {
	if (!de()) return;
	let n = v(t), r = O(), i = e.postMessage.bind(e), a = e.terminate.bind(e), o = (e) => r("received", e.data);
	e.addEventListener("message", o), e.postMessage = ((e, t) => {
		r("sent", e), i(e, t);
	}), e.terminate = () => (e.removeEventListener("message", o), n(), a());
}
//#endregion
//#region src/storage/recordParts.ts
function ct(e, t) {
	return B(t), new Promise((n, r) => {
		let i = new Worker(new URL(
			/* @vite-ignore */
			"/__large-history/assets/recordParts.worker-BLVJOwNC.js",
			"" + import.meta.url
		), { type: "module" }), a = !0, o;
		st(i, "worker.parts");
		let s = (e, s) => {
			a && (a = !1, o = void 0, t?.removeEventListener("abort", c), i.terminate(), e ? r(e) : n(s));
		}, c = () => s(new z("CANCELLED", "履歴の分割処理を取り消しました。既存データを保持しています。"));
		t?.addEventListener("abort", c, { once: !0 }), i.onmessage = (e) => {
			if (a) try {
				B(t);
				let n = e.data;
				if (n.type === "graph-chunk") {
					(o ??= new it()).accept(n);
					return;
				}
				if (n.type === "graph-end") {
					let e = o?.finish(n.root);
					if (!o) throw new z("SAVE_FAILED", "履歴の受渡し内容がありません。");
					s(void 0, e);
					return;
				}
				n.ok ? s(void 0, n.value) : s(new z(n.code, "大きな履歴を処理できません。既存データを保持しています。"));
			} catch (e) {
				s(e);
			}
		}, i.onerror = () => s(new z("SAVE_FAILED", "履歴の処理作業領域を開けません。"));
		try {
			B(t), i.postMessage(e);
		} catch (e) {
			s(e);
		}
	});
}
var lt = () => typeof window < "u" && typeof Worker < "u";
function ut(e, t, n) {
	return lt() ? ct({
		action: "pack",
		value: e,
		scope: t
	}, n) : et(e, t, n);
}
function dt(e, t, n) {
	return lt() ? ct({
		action: "pack-import",
		value: e,
		scope: t
	}, n) : et(e, t, n).then((e) => ot(e, n));
}
function ft(e, t, n) {
	return lt() ? ct({
		action: "unpack",
		packed: e,
		parts: t
	}, n) : tt(e, t, n);
}
//#endregion
//#region src/storage/historyMetadata.ts
var pt = "__scenarioCommandMetadata", q = /* @__PURE__ */ new WeakSet(), mt = /* @__PURE__ */ new WeakSet(), ht = () => {
	throw new z("SAVE_FAILED", "履歴の操作情報と本文の対応が破損しています。");
};
function gt() {
	let e = W.currentTransaction?.idbtrans;
	e && q.add(e);
}
var _t = (e) => q.has(e), vt = (e) => mt.has(e), yt = (e) => Object.hasOwn(e, pt), bt = (e) => !!e[pt] && typeof e[pt] == "object" && e[pt].version === 1, J = (e) => !!e && typeof e == "object" && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null);
function xt(e) {
	if (!Array.isArray(e) || Object.keys(e).length !== e.length) return !1;
	for (let t = 0; t < e.length; t++) if (!Object.hasOwn(e, t)) return !1;
	return !0;
}
function St(e) {
	let t = e.delta?.metadata ?? e.record;
	if (!t) return;
	let { before: n, after: r, ...i } = t;
	return i;
}
function Ct(e, t) {
	if (!J(e)) return !1;
	let n = [
		"operationId",
		"projectId",
		"revision",
		"baseRevision",
		"reason",
		"createdAt"
	], r = [
		"compensatesOperationId",
		"idMap",
		"importOrigin"
	];
	if (Object.keys(e).some((e) => ![
		...n,
		"targetIds",
		...r
	].includes(e)) || !n.every((t) => Object.hasOwn(e, t) && typeof e[t] == "string") || e.operationId !== t.operationId || e.projectId !== t.projectId || e.revision !== t.revision || !xt(e.targetIds) || !e.targetIds.every((e) => typeof e == "string") || Object.hasOwn(e, "compensatesOperationId") && typeof e.compensatesOperationId != "string") return !1;
	let i = (e) => J(e) && Object.values(e).every((e) => typeof e == "string");
	return !(Object.hasOwn(e, "idMap") && !i(e.idMap) || Object.hasOwn(e, "importOrigin") && (!i(e.importOrigin) || Object.keys(e.importOrigin).length !== 3 || ![
		"sourceProjectId",
		"sourceOperationId",
		"importOperationId"
	].every((t) => Object.hasOwn(e.importOrigin, t))));
}
function wt(e) {
	if (!J(e)) return !1;
	let t = e;
	if (Object.keys(t).length !== 6 || ![
		"version",
		"scope",
		"root",
		"nodes",
		"strings",
		"parts"
	].every((e) => Object.hasOwn(t, e)) || t.version !== 1 || typeof t.scope != "string" || !t.scope.startsWith("commands:") || t.root !== 0 || !Number.isSafeInteger(t.nodes) || t.nodes < 1 || t.nodes > 4e6 || !Number.isSafeInteger(t.strings) || t.strings < 1 || t.strings > 4e6 || !xt(t.parts) || !t.parts.length) return !1;
	let n = 0;
	return t.parts.every((e, r) => !J(e) || Object.keys(e).length !== 4 || ![
		"key",
		"kind",
		"bytes",
		"sha256"
	].every((t) => Object.hasOwn(e, t)) || e.key !== `${t.scope}:${r}` || !["strings", "nodes"].includes(e.kind) || !Number.isSafeInteger(e.bytes) || e.bytes < 1 || e.bytes > 8388608 || typeof e.sha256 != "string" || !/^[a-f0-9]{64}$/.test(e.sha256) ? !1 : (n += e.bytes, n <= 268435456));
}
var Tt = (e, t = !1) => {
	let n = e[pt], r = E({
		...e,
		[pt]: {
			version: n.version,
			metadata: n.metadata
		}
	});
	return t && (L("history.write.sealCalls"), L("history.write.sealBytes", r.byteLength)), A(r);
};
async function Et(e, t) {
	L("history.write.candidates");
	let n = St(e);
	if (!Ct(n, t)) return L("history.write.fallbackShape"), t;
	let r = {
		...t,
		[pt]: {
			version: 1,
			metadata: n,
			digest: "0".repeat(64)
		}
	};
	return nt(r) ? (L("history.write.fallbackSize"), t) : (r[pt].digest = await Tt(r, !0), L("history.write.canonical"), r);
}
async function Dt(e) {
	if (!bt(e)) return ht();
	let t = e[pt];
	return Object.keys(e).length !== 5 || ![
		"operationId",
		"projectId",
		"revision",
		"__scenarioRecordParts",
		pt
	].every((t) => Object.hasOwn(e, t)) || !Ct(t.metadata, e) || !wt(e.__scenarioRecordParts) || typeof t.digest != "string" || t.digest !== await Tt(e) || Object.keys(t).length !== 3 ? ht() : t.metadata;
}
async function Ot(e, t, n) {
	let r = await Dt(e), { [pt]: i, ...a } = e, o = St(t);
	if (!Ct(o, e) || !g(a, n) || !g(r, o)) return ht();
}
async function kt(e, t) {
	let n = e.__scenarioRecordParts;
	await Promise.all(n.parts.map((e) => new W.Promise((n, r) => {
		let i = t.objectStore("recordParts").getKey(e.key);
		i.onsuccess = () => {
			L("history.partKeys"), L("db.read.calls", 1, "recordParts"), L("db.read.requested", 1, "recordParts"), L("db.read.keys", i.result === void 0 ? 0 : 1, "recordParts"), i.result === e.key ? n() : r(new z("SAVE_FAILED", "履歴の分割記録が不足しています。"));
		}, i.onerror = () => r(i.error);
	})));
}
async function At(e, t) {
	return e.transaction("r", ["commands"], async () => {
		let n = {
			trans: W.currentTransaction.idbtrans,
			keys: t.slice()
		};
		mt.add(n);
		try {
			return await e.table("commands").core.getMany(n);
		} finally {
			mt.delete(n);
		}
	});
}
function Y(e) {
	L("history.metadata.rows"), D("history.metadata.payloadBytes", e);
}
//#endregion
//#region src/storage/worldClosure.ts
async function jt(e, t, n, r) {
	let i = {}, a = [], o = [], s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new WeakSet(), u = !1, d = (e, t = !1) => {
		if (!e || !Array.isArray(e.snapshots)) {
			u = !0;
			return;
		}
		let n = t ? s : c;
		n.add(e.projectId);
		for (let t of e.snapshots) t && typeof t.id == "string" ? n.add(t.id) : u = !0;
		let r = [e];
		for (; r.length;) {
			let e = r.pop();
			if (typeof e != "object" || !e || l.has(e)) continue;
			if (l.add(e), !Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) {
				u = !0;
				continue;
			}
			let t = e;
			if (Object.hasOwn(t, "worldReferences")) {
				if (!Array.isArray(t.worldReferences)) u = !0;
				else for (let e of t.worldReferences) e && typeof e == "object" && typeof e.immutableSnapshotId == "string" ? a.push(e.immutableSnapshotId) : u = !0;
			}
			try {
				let e = [];
				typeof t.kind == "string" && typeof t.projectId == "string" && t.data && typeof t.data == "object" ? Object.hasOwn(se, t.kind) ? e = N(t) : u = !0 : typeof t.relationType == "string" && typeof t.projectId == "string" && typeof t.fromId == "string" && (e = I(t));
				for (let t of e) t.scope === "snapshot" && o.push(t.id);
			} catch {
				u = !0;
			}
			for (let e of Object.values(Object.getOwnPropertyDescriptors(t))) Object.hasOwn(e, "value") ? r.push(e.value) : u = !0;
		}
	}, f = async () => {
		L("world.closure.fullFallback"), B(r);
		let e = await n();
		return B(r), e;
	};
	for (let t of e) d(t, !0);
	let p = /* @__PURE__ */ new Set();
	for (; a.length || o.length;) {
		if (B(r), u) return f();
		let e = a.length === 0, n = (e ? o : a).pop();
		if (e && s.has(n) || i[n] || p.has(n)) continue;
		p.add(n);
		let l = await t(n);
		if (B(r), !l) {
			if (e && c.has(n)) continue;
			return f();
		}
		i[l.id] = l.project, d(l.project);
	}
	return u ? f() : i;
}
//#endregion
//#region src/domain/derivedIndexes.ts
var Mt = Object.freeze({
	entries: 1e5,
	references: 75e4,
	textCodeUnits: 8388608
}), Nt = /* @__PURE__ */ new WeakMap(), Pt = (e, t = 1) => ({
	entries: t,
	references: e.references,
	textCodeUnits: e.textCodeUnits ?? 0
}), Ft = class {
	used = {
		entries: 0,
		references: 0,
		textCodeUnits: 0
	};
	limits;
	constructor(e = {}) {
		let t = {
			...Mt,
			...e
		};
		if (Object.values(t).some((e) => !Number.isSafeInteger(e) || e < 0)) throw Error("Invalid derived index budget");
		this.limits = Object.freeze(t);
	}
	snapshot() {
		return { ...this.used };
	}
	reserve(e) {
		if (Object.values(e).some((e) => !Number.isSafeInteger(e) || e < 0) || Object.keys(e).some((t) => e[t] > this.limits[t] - this.used[t])) return !1;
		for (let t of Object.keys(e)) this.used[t] += e[t];
		return !0;
	}
	release(e) {
		for (let t of Object.keys(e)) this.used[t] -= e[t];
	}
}, It = class {
	source;
	members;
	membershipCost;
	signature;
	generation = 0;
	budget;
	values = /* @__PURE__ */ new Map();
	identity;
	constructor(e, t, n) {
		this.budget = t;
		let { history: r, authorAlternatives: i, ...a } = e;
		this.source = Object.freeze({
			...a,
			history: Object.freeze([])
		}), this.identity = Object.freeze({
			...n,
			visibilityScope: "author",
			normalizationVersion: 2
		});
	}
	matches(e) {
		let t = this.source;
		if (!t) return !1;
		let n = Object.getOwnPropertyDescriptors(e), r = Reflect.ownKeys(e).filter((e) => e !== "history" && e !== "authorAlternatives"), i = Object.keys(t).filter((e) => e !== "history");
		return r.length === i.length && r.every((e) => typeof e == "string" && Object.hasOwn(t, e)) && i.every((e) => {
			let r = n[e];
			return !!r?.enumerable && Object.hasOwn(r, "value") && r.value === t[e];
		});
	}
	bind(e) {
		this.matches(e) && Nt.set(e, this);
	}
	clearValues() {
		for (let e of this.values.values()) for (let t of e.values()) this.budget.release(t.cost);
		this.values.clear(), this.generation++, L("derived.invalidated");
	}
	close() {
		this.clearValues(), this.membershipCost && this.budget.release(this.membershipCost), this.membershipCost = void 0, this.members = void 0, this.source = void 0, this.signature = void 0;
	}
	evaluate(e) {
		if (!this.matches(e)) {
			Nt.delete(e);
			return;
		}
		if (!this.budget.limits.entries) return;
		let t = ne();
		if (t === void 0) {
			this.clearValues();
			return;
		}
		t !== this.signature && (this.clearValues(), this.signature = t);
		let n = this.source;
		if (!this.members) {
			if (!s(n)) return;
			let e = Pt({ references: n.entities.length }, 0);
			if (!this.budget.reserve(e)) return;
			this.membershipCost = e, this.members = new WeakSet(n.entities);
		}
		let r = this.generation, i = () => !!this.source && r === this.generation, a = (e, t) => i() ? this.values.get(e)?.get(t)?.value : void 0, o = (e, t, n) => {
			if (!i()) return !1;
			let r = this.values.get(e);
			if (r?.has(t)) return !0;
			let a = Pt(n.cost);
			return this.budget.reserve(a) ? (r || (r = /* @__PURE__ */ new Map(), this.values.set(e, r)), r.set(t, {
				value: n.value,
				cost: a
			}), L("derived.admitted"), !0) : (L("derived.rejected"), !1);
		};
		return {
			peek: a,
			publish: o,
			get: (e, t, n) => {
				let r = i() ? this.values.get(e)?.get(t) : void 0;
				if (r) return L("derived.hit"), r.value;
				L("derived.miss");
				let a = n();
				return o(e, t, a), a.value;
			},
			ownsEntity: (e) => i() && this.members?.has(e) === !0,
			isActive: () => i() && this.matches(e),
			isCurrent: () => i() && this.matches(e) && ne() === t
		};
	}
};
//#endregion
//#region src/domain/worldSources.ts
function Lt(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of [...Object.values(t), ...e]) {
		let e = n.get(r.projectId), t = new Map(e?.snapshots.map((e) => [e.id, e]) ?? []);
		for (let e of r.snapshots) t.has(e.id) || t.set(e.id, e);
		n.set(r.projectId, {
			...r,
			snapshots: [...t.values()]
		});
	}
	return [...n.values()];
}
//#endregion
//#region src/storage/projectSummary.ts
function Rt(e) {
	return new W.Promise((t, n) => {
		let r = W.currentTransaction.idbtrans.objectStore("projects").get(e);
		r.onsuccess = () => {
			let e = r.result;
			L("db.read.calls", 1, "projects"), L("db.read.requested", 1, "projects"), L("db.read.rows", +!!e, "projects"), D("db.read.payloadBytes", e ? [e] : [], "projects"), t(e);
		}, r.onerror = () => n(r.error);
	});
}
var zt = (e) => A(E(e));
async function Bt(e, t) {
	let n = {
		version: 2,
		alternativeHeads: (e.authorAlternatives ?? []).map((e) => ({
			id: e.id,
			name: e.name,
			headVersionId: e.headVersionId,
			contentHash: e.versions.find((t) => t.id === e.headVersionId)?.contentHash ?? ""
		})),
		projectId: e.projectId,
		name: e.name,
		revision: e.revision,
		entityCount: e.entities.filter((e) => !e.deletedAt).length,
		sourceHash: t
	};
	return {
		...n,
		digest: await A(E(n))
	};
}
async function Vt(e, t, n) {
	if (!e || e.version !== 2 || !Array.isArray(e.alternativeHeads) || e.alternativeHeads.length > 100 || e.alternativeHeads.some((e) => !e || typeof e.id != "string" || typeof e.name != "string" || typeof e.headVersionId != "string" || typeof e.contentHash != "string") || e.projectId !== t || e.sourceHash !== n || typeof e.name != "string" || typeof e.revision != "string" || !/^(0|[1-9]\d*)$/.test(e.revision) || !Number.isSafeInteger(e.entityCount) || e.entityCount < 0) return !1;
	let { digest: r, ...i } = e;
	return typeof r == "string" && r === await A(new TextEncoder().encode(h(i)));
}
async function Ht(e, t) {
	let n = {
		id: e,
		projectId: t.projectId,
		name: t.name,
		revision: t.revision,
		version: 1
	};
	return {
		...n,
		digest: await A(E(n))
	};
}
async function Ut(e, t) {
	if (!e || e.id !== t || e.version !== 1 || typeof e.projectId != "string" || typeof e.name != "string" || typeof e.revision != "string" || !/^(0|[1-9]\d*)$/.test(e.revision)) return !1;
	let { digest: n, ...r } = e;
	return typeof n == "string" && n === await A(E(r));
}
//#endregion
//#region src/domain/authorAlternativeIntegrity.ts
var Wt = /^[0-9a-f]{64}$/, Gt = /^(0|[1-9][0-9]*)$/, Kt = /* @__PURE__ */ new Set([
	"active",
	"provisional",
	"needs_review",
	"rejected",
	"accepted"
]), qt = /* @__PURE__ */ new Set([
	"project",
	"entity",
	"relation",
	"presentation"
]), Jt = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), Yt = {
	alternatives: 100,
	versions: 500,
	branchBytes: 8e6,
	totalBytes: 16e6
};
function Xt(e, t = /* @__PURE__ */ new Set(), n = 0) {
	if (n > 100) throw Error("内容の階層が上限を超えています。");
	if (e === null || typeof e == "boolean" || typeof e == "string" || typeof e == "number" && Number.isFinite(e)) return JSON.stringify(e);
	if (!e || typeof e != "object" || t.has(e)) throw Error("SHA-256対象が通常のJSON値ではありません。");
	let r = Object.getPrototypeOf(e);
	if (!Array.isArray(e) && r !== Object.prototype && r !== null) throw Error("SHA-256対象に未対応の値があります。");
	t.add(e);
	let i = Array.isArray(e) ? `[${e.map((e) => Xt(e, t, n + 1)).join(",")}]` : `{${Object.keys(e).sort().map((r) => {
		if (Jt.has(r)) throw Error("JSONに未対応の項目名があります。");
		return `${JSON.stringify(r)}:${Xt(e[r], t, n + 1)}`;
	}).join(",")}}`;
	return t.delete(e), i;
}
async function Zt(e) {
	let t = new TextEncoder().encode(Xt(e)), n = await globalThis.crypto.subtle.digest("SHA-256", t);
	return Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("");
}
function Qt(e) {
	let { integrityHash: t, ...n } = e;
	return n;
}
async function $t(e) {
	let t = structuredClone(e);
	t.baseContentHash = await Zt(t.baseContent);
	for (let e of t.versions) e.contentHash = await Zt({
		content: e.content,
		structurePlan: e.structurePlan ?? null
	});
	return delete t.integrityHash, t.integrityHash = await Zt(Qt(t)), t;
}
function en(e) {
	return !!e && typeof e == "object" && !Array.isArray(e);
}
function tn(e) {
	return typeof e == "string" && Number.isFinite(Date.parse(e));
}
function X(e, t, n) {
	e.push({
		path: t,
		message: n
	});
}
function nn(e, t, n, r) {
	(typeof e.templateId != "string" || !e.templateId.trim()) && X(r, `${n}.templateId`, "構成雛形IDが必要です。"), !Array.isArray(e.beatLabels) || e.beatLabels.length > 100 || e.beatLabels.some((e) => typeof e != "string" || !e.trim()) ? X(r, `${n}.beatLabels`, "構成の役割は空でない文章を100件以内で指定してください。") : new Set(e.beatLabels).size !== e.beatLabels.length && X(r, `${n}.beatLabels`, "構成の役割名は重複できません。");
	let i = t.entities.find((t) => t.kind === "chapter" && t.id === e.chapterId && !t.deletedAt);
	if (i || X(r, `${n}.chapterId`, "構成計画の章が別案に存在しません。"), !en(e.assignments)) {
		X(r, `${n}.assignments`, "場面の割り当てが不正です。");
		return;
	}
	let a = new Set(Array.isArray(e.beatLabels) ? e.beatLabels : []), o = /* @__PURE__ */ new Set();
	for (let [s, c] of Object.entries(e.assignments)) a.has(s) || X(r, `${n}.assignments.${s}`, "定義されていない構成の役割です。"), (typeof c != "string" || o.has(c)) && X(r, `${n}.assignments.${s}`, "同じ場面を複数の役割へ割り当てられません。"), o.add(c), t.entities.some((e) => e.kind === "scene" && e.id === c && !e.deletedAt) || X(r, `${n}.assignments.${s}`, "割り当てる場面が別案に存在しません。"), i && typeof c == "string" && !i.data.sceneIds.includes(c) && X(r, `${n}.assignments.${s}`, "場面は対象の章に所属していません。");
}
function rn(e, t) {
	return t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
}
function an(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function on(e, t) {
	if (t.scope === "presentation") return an(e);
	if (t.scope === "project") return rn(e, t.path);
	let n = (t.scope === "entity" ? e.entities : e.relations).find((e) => e.id === t.itemId);
	if (n && !n.deletedAt) return t.path.length ? rn(n, t.path) : n;
}
function sn(e, t, n, r, i) {
	if (!e || typeof e != "object") {
		X(i, r, "正本採用記録が不正です。");
		return;
	}
	tn(e.createdAt) || X(i, `${r}.createdAt`, "採用日時が不正です。");
	let a = t.get(e.alternativeVersionId ?? "");
	if (a || X(i, `${r}.alternativeVersionId`, "採用元の別案版が見つかりません。"), (e.sourceSnapshotId ?? null) !== (n ?? null) && X(i, `${r}.sourceSnapshotId`, "採用記録の分岐元固定版が別案と一致しません。"), !Gt.test(e.fromCanonicalRevision) || !e.appliedRevision || !Gt.test(e.appliedRevision) ? X(i, r, "採用元と採用先の正本版番号が必要です。") : BigInt(e.appliedRevision) <= BigInt(e.fromCanonicalRevision) && X(i, `${r}.appliedRevision`, "採用先の正本版は採用元より新しくなければなりません。"), (!Array.isArray(e.selectedChangeKeys) || !e.selectedChangeKeys.length || new Set(e.selectedChangeKeys).size !== e.selectedChangeKeys.length) && X(i, `${r}.selectedChangeKeys`, "採用対象の差分キーが必要です。"), !Array.isArray(e.patches) || !e.patches.length) {
		X(i, `${r}.patches`, "採用した差分がありません。");
		return;
	}
	let o = /* @__PURE__ */ new Set();
	e.patches.forEach((e, t) => {
		let n = `${r}.patches[${t}]`;
		(!e || typeof e.key != "string" || o.has(e.key)) && X(i, `${n}.key`, "差分キーが不正または重複しています。"), o.add(e.key), (!qt.has(e.scope) || !Array.isArray(e.path) || e.path.some((e) => typeof e != "string") || typeof e.label != "string") && X(i, n, "差分の対象が不正です。"), (typeof e.before?.present != "boolean" || typeof e.after?.present != "boolean") && X(i, n, "差分の前後値の有無が不正です。");
		let s = [
			e.scope,
			e.itemId ?? "",
			...e.path ?? []
		].map((e) => encodeURIComponent(e)).join(":");
		if (e.key !== s && X(i, `${n}.key`, "差分キーが保存した範囲と一致しません。"), e.scope === "presentation" && (e.itemId || e.path?.length !== 1 || e.path[0] !== "all") && X(i, n, "提示順差分の範囲が不正です。"), (e.before?.present === !1 && Object.hasOwn(e.before, "value") || e.after?.present === !1 && Object.hasOwn(e.after, "value")) && X(i, n, "値がない差分に値を含められません。"), (e.before?.present === !0 && !Object.hasOwn(e.before, "value") || e.after?.present === !0 && !Object.hasOwn(e.after, "value")) && X(i, n, "値がある差分には値を含めてください。"), a && e.after && typeof e.after.present == "boolean") {
			let t = on(a.content, e), r = t !== void 0;
			if (e.after.present !== r) X(i, `${n}.after`, "採用後の有無が参照した別案版と一致しません。");
			else if (r) try {
				Xt(e.after.value) !== Xt(t) && X(i, `${n}.after.value`, "採用後の値が参照した別案版と一致しません。");
			} catch (e) {
				X(i, `${n}.after.value`, e instanceof Error ? e.message : "採用後の値を別案版と比較できません。");
			}
		}
	}), Array.isArray(e.selectedChangeKeys) && !cn(e.selectedChangeKeys, [...o]) && X(i, `${r}.selectedChangeKeys`, "採用対象キーと保存した差分内容が一致しません。");
}
function cn(e, t) {
	return e.length === t.length && [...e].sort().every((e, n) => e === [...t].sort()[n]);
}
async function ln(e, t, n) {
	let r = [], i = {
		alternatives: n.maxAlternatives ?? Yt.alternatives,
		versions: n.maxVersionsPerAlternative ?? Yt.versions,
		branchBytes: n.maxBytesPerAlternative ?? Yt.branchBytes,
		totalBytes: n.maxBytesTotal ?? Yt.totalBytes
	};
	if (!Array.isArray(t)) return [{
		path: "authorAlternatives",
		message: "作者別案は配列で指定してください。"
	}];
	t.length > i.alternatives && X(r, "authorAlternatives", `作者別案は${i.alternatives}件までです。`);
	let a = new Set(n.reservedIds ?? []), o = /* @__PURE__ */ new Set(), s = 0;
	for (let [c, l] of t.entries()) {
		let t = `authorAlternatives[${c}]`;
		if (!en(l)) {
			X(r, t, "作者別案の記録が不正です。");
			continue;
		}
		let u = l;
		if ((typeof u.id != "string" || o.has(u.id) || a.has(u.id)) && X(r, `${t}.id`, "別案IDが不正または重複しています。"), typeof u.id == "string" && (o.add(u.id), a.add(u.id)), u.projectId !== e && X(r, `${t}.projectId`, "別案が別の作品を参照しています。"), (typeof u.name != "string" || !u.name.trim()) && X(r, `${t}.name`, "別案名が必要です。"), Kt.has(u.status) || X(r, `${t}.status`, "別案の状態が不正です。"), (!tn(u.createdAt) || !tn(u.updatedAt)) && X(r, t, "別案の作成日時または更新日時が不正です。"), Gt.test(u.baseRevision) || X(r, `${t}.baseRevision`, "分岐元の版番号が不正です。"), u.sourceSnapshotId != null && n.snapshotIds && !n.snapshotIds.has(u.sourceSnapshotId) && X(r, `${t}.sourceSnapshotId`, "分岐元の固定版が見つかりません。"), (!en(u.baseContent) || u.baseContent.projectId !== e || u.baseContent.revision !== u.baseRevision) && X(r, `${t}.baseContent`, "分岐元の内容・作品ID・版番号が一致しません。"), en(u.baseContent) && Object.hasOwn(u.baseContent, "authorAlternatives") && X(r, `${t}.baseContent.authorAlternatives`, "別案の内容へ別案一覧を再帰保存できません。"), en(u.baseContent)) {
			if (u.sourceSnapshotId) {
				let e = n.snapshots?.find((e) => e.id === u.sourceSnapshotId);
				if (!e) X(r, `${t}.sourceSnapshotId`, "分岐元の固定版本文がありません。");
				else try {
					Xt(e.content) !== Xt(u.baseContent) && X(r, `${t}.baseContent`, "固定版から分岐した別案は、固定版本文をそのまま保持してください。");
				} catch (e) {
					X(r, `${t}.baseContent`, e instanceof Error ? e.message : "固定版本文と分岐元を比較できません。");
				}
			}
			let e = await n.validateContent(u.baseContent);
			if (e.ok || (e.issues ?? []).forEach((e) => X(r, `${t}.baseContent${e.path ? `.${e.path}` : ""}`, e.message)), Wt.test(u.baseContentHash ?? "")) try {
				await Zt(u.baseContent) !== u.baseContentHash && X(r, `${t}.baseContentHash`, "分岐元の内容SHA-256が一致しません。");
			} catch (e) {
				X(r, `${t}.baseContentHash`, e instanceof Error ? e.message : "分岐元の内容hashを確認できません。");
			}
			else X(r, `${t}.baseContentHash`, "分岐元の内容SHA-256がありません。");
		}
		if (!Array.isArray(u.versions) || !u.versions.length || u.versions.length > i.versions) {
			X(r, `${t}.versions`, `別案の版は1〜${i.versions}件で指定してください。`);
			continue;
		}
		let d = u.versions, f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map();
		for (let [i, o] of d.entries()) {
			let s = `${t}.versions[${i}]`;
			if ((!o || typeof o.id != "string" || f.has(o.id) || a.has(o.id)) && X(r, `${s}.id`, "別案版IDが不正または重複しています。"), typeof o?.id == "string" && (f.set(o.id, o), p.set(o.id, i), a.add(o.id)), (typeof o?.label != "string" || !o.label.trim() || !tn(o.createdAt)) && X(r, s, "別案版の名前または作成日時が不正です。"), !en(o?.content) || o.content.projectId !== e) {
				X(r, `${s}.content`, "別案版の作品IDが一致しません。");
				continue;
			}
			Object.hasOwn(o.content, "authorAlternatives") && X(r, `${s}.content.authorAlternatives`, "別案版へ別案一覧を再帰保存できません。");
			let c = await n.validateContent(o.content);
			c.ok || (c.issues ?? []).forEach((e) => X(r, `${s}.content${e.path ? `.${e.path}` : ""}`, e.message)), o.structurePlan && nn(o.structurePlan, o.content, `${s}.structurePlan`, r);
			try {
				let e = await Zt({
					content: o.content,
					structurePlan: o.structurePlan ?? null
				});
				(!Wt.test(o.contentHash ?? "") || o.contentHash !== e) && X(r, `${s}.contentHash`, "別案版の内容SHA-256がありません、または一致しません。");
			} catch (e) {
				X(r, `${s}.contentHash`, e instanceof Error ? e.message : "別案版の内容hashを確認できません。");
			}
		}
		let m = d.filter((e) => e.parentVersionId === null);
		if (m.length !== 1 && X(r, `${t}.versions`, "別案履歴には親のない開始版が一つ必要です。"), m[0]) try {
			Xt(m[0].content) !== Xt(u.baseContent) && X(r, `${t}.versions`, "開始版は分岐元の内容を保持してください。");
		} catch (e) {
			X(r, `${t}.versions`, e instanceof Error ? e.message : "開始版と分岐元の内容を比較できません。");
		}
		let h = -Infinity;
		for (let [e, n] of d.entries()) {
			let i = `${t}.versions[${e}]`, a = Date.parse(n.createdAt);
			if (Number.isFinite(a) && a < h && X(r, `${i}.createdAt`, "別案の版は作成順に並べてください。"), Number.isFinite(a) && (h = a), n.parentVersionId !== null) {
				let t = p.get(n.parentVersionId ?? "");
				(t === void 0 || t >= e) && X(r, `${i}.parentVersionId`, "別案版の親が存在しないか、作成順の後にあります。");
			}
		}
		let g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set(), v = (e) => {
			if (_.has(e)) {
				X(r, `${t}.versions`, "別案版の親子関係に循環があります。");
				return;
			}
			if (g.has(e)) return;
			_.add(e);
			let n = f.get(e)?.parentVersionId;
			n && v(n), _.delete(e), g.add(e);
		};
		if (f.forEach((e, t) => v(t)), u.headVersionId !== d.at(-1)?.id && X(r, `${t}.headVersionId`, "別案の現在版は履歴の最後の版でなければなりません。"), !Array.isArray(u.applyReceipts)) X(r, `${t}.applyReceipts`, "正本採用履歴が不正です.");
		else {
			let e = /* @__PURE__ */ new Set(), n = -1n;
			u.applyReceipts.forEach((i, o) => {
				let s = `${t}.applyReceipts[${o}]`;
				if ((e.has(i.id) || a.has(i.id)) && X(r, `${s}.id`, "採用記録IDが重複しています。"), e.add(i.id), a.add(i.id), sn(i, f, u.sourceSnapshotId, s, r), Gt.test(i.appliedRevision ?? "")) {
					let e = BigInt(i.appliedRevision);
					e <= n && X(r, `${s}.appliedRevision`, "正本採用履歴は版の昇順で並べてください。"), n = e;
				}
			});
		}
		try {
			let e = Qt(u);
			(!Wt.test(u.integrityHash ?? "") || await Zt(e) !== u.integrityHash) && X(r, `${t}.integrityHash`, "作者別案全体のSHA-256がありません、または一致しません。");
		} catch (e) {
			X(r, `${t}.integrityHash`, e instanceof Error ? e.message : "作者別案のhashを確認できません。");
		}
		try {
			let e = new TextEncoder().encode(Xt(u)).byteLength;
			s += e, e > i.branchBytes && X(r, t, `別案は${i.branchBytes} bytesまでです。`);
		} catch (e) {
			X(r, t, e instanceof Error ? e.message : "別案をJSON化できません。");
		}
	}
	return s > i.totalBytes && X(r, "authorAlternatives", `作者別案全体は${i.totalBytes} bytesまでです。`), r;
}
//#endregion
//#region src/domain/runtimeRecordValidation.ts
function un(e, t, r, i = "trace", o = {}) {
	try {
		e = a(e, e.snapshots);
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: i,
			message: e.message
		}];
	}
	let s = [], c = (e, t, n = "VALIDATION_FAILED") => s.push({
		code: n,
		path: `${i}.${e}`,
		message: t
	});
	if (t.mode !== "chapters") return t.readingPath && c("readingPath", "章の提示経路はmode:chaptersの記録に指定してください。"), s;
	let l = t.readingPath;
	if (!l) return c("readingPath", "章読み通し記録に提示経路がありません。"), s;
	let u = n(e, o.worldSnapshots ?? {});
	u.errors.length && c("worldReferences", u.errors[0], "REFERENCE_INVALID");
	let d = u.worlds.flatMap((e) => e.entities);
	s.push(..._e(e, t.initialExternalValues ?? {}, void 0, d).map((e) => ({
		...e,
		path: `${i}.initialExternalValues.${e.path}`
	}))), t.initialWorldTick != null && r.worldTick != null && t.initialWorldTick !== r.worldTick && c("initialWorldTick", "保存した開始時点と章経路の提示時点が一致しません。", "INTEGRITY_FAILED"), t.steps.length && c("steps", "章読み通しにフロー遷移を混在させられません。"), (t.contentVersionId !== r.contentVersionId || r.runtimeState.contentVersionId !== t.contentVersionId) && c("contentVersionId", "開始状態と読み通しの固定版が一致しません。"), (t.contentRevision !== e.revision || r.contentRevision !== e.revision) && c("contentRevision", "章読み通しには開始状態と内容版に一致する更新番号が必要です。"), (r.origin !== "partial" || r.runtimeState.presentationPosition !== null) && c("startCheckpointId", "章読み通しの開始状態はフロー位置を持たない途中開始です。"), l.occurrences.length > l.sceneIds.length && c("readingPath.occurrences", "実際の提示数が計画した場面数を超えています。");
	let f = /* @__PURE__ */ new Set(), p = r.runtimeState;
	for (let [n, a] of l.occurrences.entries()) {
		let o = `readingPath.occurrences[${n}]`;
		(!a.occurrenceId.trim() || f.has(a.occurrenceId)) && c(`${o}.occurrenceId`, "提示の識別子が空か重複しています。"), f.add(a.occurrenceId), a.entityId !== l.sceneIds[n] && c(`${o}.entityId`, "提示した場面が計画した場面の順序と一致しません。"), (a.before.contentVersionId !== t.contentVersionId || a.after.contentVersionId !== t.contentVersionId || a.before.presentationPosition !== null || a.after.presentationPosition !== null) && c(o, "提示状態の内容版またはフロー位置が不正です。"), h(a.before) !== h(p) && c(`${o}.before`, "提示状態が開始状態または直前の提示とつながりません。", "INTEGRITY_FAILED"), h(a.externalValues ?? {}) !== h(t.initialExternalValues ?? {}) && c(`${o}.externalValues`, "章読み通し中に、記録した外部入力を未記録の操作で変更できません。", "INTEGRITY_FAILED");
		let u = ve(e, a.before, {
			sceneId: a.entityId,
			worldTick: t.initialWorldTick ?? r.worldTick ?? void 0,
			previousSceneId: l.occurrences[n - 1]?.entityId,
			last: n + 1 === l.sceneIds.length,
			externalValues: a.externalValues ?? t.initialExternalValues ?? {},
			referenceEntities: d
		});
		if (u.ok) h(u.state) !== h(a.after) && c(`${o}.after`, "記録した提示後の状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED"), a.presentationState && h(u.observationState) !== h(a.presentationState) && c(`${o}.presentationState`, "提示前の観測状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED"), h(u.conditions) !== h(a.conditionResults) && c(`${o}.conditionResults`, "提示時の条件根拠が不足・重複・矛盾しています。", "INTEGRITY_FAILED");
		else for (let e of u.issues) s.push({
			...e,
			path: `${i}.${o}.${e.path}`
		});
		p = a.after;
	}
	return s;
}
//#endregion
//#region src/domain/projectRecordValidation.ts
function dn(e) {
	return {
		...e,
		history: []
	};
}
function fn(e, t) {
	return t.length >= e.length && e.every((e, n) => h(e) === h(t[n]));
}
function pn(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = (e) => {
		let t = a.get(e);
		return t || (t = [], a.set(e, t)), t;
	}, s = o("local"), c = e.history.findIndex((e) => !e.importOrigin);
	c >= 0 && s.push({
		label: `project.history[${c}].before`,
		state: e.history[c].before
	});
	for (let [t, n] of e.history.entries()) {
		let e = n.importOrigin, r = o(e ? `import:${e.importOperationId}` : "local");
		e && !r.length && r.push({
			label: `project.history[${t}].before`,
			state: n.before
		}), r.push({
			label: `project.history[${t}].after`,
			state: n.after
		});
	}
	let l = e;
	(!s.length || s.at(-1)?.state.revision !== e.revision) && s.push({
		label: "project",
		state: l
	});
	for (let e of a.values()) {
		let a = /* @__PURE__ */ new Map();
		for (let { label: o, state: s } of e) {
			let e = new Map((s.authorAlternatives ?? []).map((e) => [e.id, e]));
			for (let [n, r] of a) {
				let i = e.get(n);
				if (!i) {
					t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives`,
						message: `過去に保存した別案「${n}」が履歴から失われています。`
					});
					continue;
				}
				fn(r.versions, i.versions) || t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${n}.versions`,
					message: "別案版の履歴は削除・書換えできません。"
				}), fn(r.applyReceipts, i.applyReceipts) || t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${n}.applyReceipts`,
					message: "正本採用記録は削除・書換えできません。"
				});
			}
			for (let a of e.values()) {
				let e = h({
					projectId: a.projectId,
					baseRevision: a.baseRevision,
					sourceSnapshotId: a.sourceSnapshotId ?? null,
					baseContent: a.baseContent,
					baseContentHash: a.baseContentHash,
					createdAt: a.createdAt
				}), s = i.get(a.id);
				s !== void 0 && s !== e ? t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${a.id}`,
					message: "別案IDが異なる分岐元の内容に再利用されています。"
				}) : i.set(a.id, e);
				for (let e of a.versions) {
					let r = n.get(e.id);
					r && h(r) !== h(e) ? t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives.${a.id}.versions.${e.id}`,
						message: "不変の別案版IDが異なる内容へ再利用されています。"
					}) : n.set(e.id, e);
				}
				for (let e of a.applyReceipts) {
					let n = r.get(e.id);
					n && h(n) !== h(e) ? t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives.${a.id}.applyReceipts.${e.id}`,
						message: "不変の正本採用記録IDが異なる内容へ再利用されています。"
					}) : r.set(e.id, e);
				}
			}
			a = e;
		}
	}
	return t;
}
function mn(e) {
	let t = /* @__PURE__ */ new Set([e.projectId]);
	for (let n of [...e.entities, ...e.relations]) t.add(n.id);
	for (let n of e.snapshots) {
		t.add(n.id);
		for (let r of e.entities) r.kind === "snapshot" && r.id === n.id && t.add(r.id);
	}
	for (let n of e.history) t.add(n.operationId);
	return t;
}
async function hn(e, t, n, r) {
	let a = [], o = e.snapshots, s = await ln(e.projectId, e.authorAlternatives ?? [], {
		snapshotIds: new Set(o.map((e) => e.id)),
		snapshots: o,
		reservedIds: mn(e),
		validateContent: async (e) => {
			let a = await i(e, t.worldSnapshots ?? {}, `${n}.authorAlternatives.worldReferences`, r), s = d({
				...e,
				snapshots: o,
				history: []
			}, t);
			return s.ok && !a.length ? { ok: !0 } : {
				ok: !1,
				issues: [...a, ...s.ok ? [] : s.issues]
			};
		}
	});
	for (let e of s) a.push({
		code: "INTEGRITY_FAILED",
		path: `${n}.${e.path}`,
		message: e.message
	});
	return a;
}
async function gn(e, t, r) {
	let i = [];
	for (let [o, s] of e.entities.entries()) {
		if (s.kind !== "trace") continue;
		let c = `project.entities[${o}].data`, l = e.entities.find((e) => e.id === s.data.startCheckpointId && e.kind === "checkpoint");
		if (!l || l.kind !== "checkpoint") {
			i.push({
				code: "REFERENCE_INVALID",
				path: `${c}.startCheckpointId`,
				message: "経路の開始状態が見つかりません。"
			});
			continue;
		}
		try {
			let o = await ye(e, s.data.contentVersionId, t, r);
			if (s.data.mode === "chapters") i.push(...un(o, s.data, l.data, c, t));
			else {
				let { replaySavedTrace: r } = await import("./runtime-DLbuSnfo.js"), l = n(a(o, o.snapshots), t.worldSnapshots ?? {}), u = r(e, s.id, l.worlds.flatMap((e) => e.entities));
				u.status === "error" && i.push(...u.issues.map((e) => ({
					...e,
					path: `${c}.${e.path}`
				})));
			}
		} catch (e) {
			let t = e.issues;
			t?.length ? i.push(...t.map((e) => ({
				...e,
				path: `${c}.${e.path}`
			}))) : i.push({
				code: "INTEGRITY_FAILED",
				path: `${c}.contentVersionId`,
				message: e instanceof Error ? e.message : "章読み通しの固定版本文を確認できません。"
			});
		}
	}
	return i;
}
async function _n(e, t = {}, n = e.history.length > 0, r) {
	return yn(e, t, n, r);
}
function vn(e = {}) {
	let n = t(e), r = n.captured ? t({
		...n.value,
		relationTypes: n.value.relationTypes ?? y
	}) : n;
	if (!r.captured) return {
		validate: (t) => d(t, e),
		integrity: (t, n = t.history.length > 0) => _n(t, e, n)
	};
	let i = ue(r.value);
	return {
		validate: i,
		integrity: (e, n = e.history.length > 0) => yn(t(e).value, r.value, n, void 0, i)
	};
}
async function yn(e, t, n, r, a) {
	L("validate.integrity.calls");
	try {
		let { verifyStoredGameEvidence: n } = await import("./gameProtocol-CQT3V9qa.js");
		await n(e, t.worldSnapshots ?? {});
	} catch (e) {
		return [{
			code: "INTEGRITY_FAILED",
			path: "project.entities.handoffReceipt",
			message: e.message
		}];
	}
	let o = f(), s = {
		...t,
		worldSnapshots: p(t.worldSnapshots ?? {}, o),
		worlds: t.worlds ? structuredClone(t.worlds) : void 0
	}, c = a ? a(e) : r && !n && !e.history.length ? l(e, s, r) : d(e, s);
	if (!c.ok) return c.issues;
	let u = [], m = (e, t, n) => {
		let r = new Map(e.filter((e) => e.kind === "review" && e.data.sharedSource).map((e) => [e.id, e]));
		for (let e of t) {
			let t = r.get(e.id);
			e.kind === "review" && t?.kind === "review" && (h(t.data.sharedSource) !== h(e.data.sharedSource ?? null) && u.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.sharedSource`,
				message: "元の共有指摘・公開版・位置・引用の記録は変更できません。解決文を別に保存してください。"
			}), h([
				t.data.target,
				t.data.targetVersionId,
				t.data.quotedText ?? null
			]) !== h([
				e.data.target,
				e.data.targetVersionId,
				e.data.quotedText ?? null
			]) && u.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.target`,
				message: "元の共有指摘の私的固定版と引用は変更できません。現在稿の修正は別に保存してください。"
			}), t.data.stage === "open" && e.data.stage === "verified" && u.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.stage`,
				message: "共有指摘は修正済みを保存してから再確認してください。"
			}));
		}
	};
	r && m(r.previous.entities, e.entities, "project.entities");
	for (let [t, n] of e.history.entries()) m(n.before.entities, n.after.entities, `project.history[${t}].after.entities`);
	u.push(...await i(e, s.worldSnapshots, "project.worldReferences", o));
	for (let [t, n] of e.snapshots.entries()) u.push(...await i(n.content, s.worldSnapshots, `project.snapshots[${t}].content.worldReferences`, o));
	if (u.push(...await hn(e, s, "project", o)), u.push(...await gn(e, s, o)), u.push(...pn(e)), n) for (let [t, n] of (e.authorAlternatives ?? []).entries()) for (let [r, i] of n.applyReceipts.entries()) {
		let n = `project.authorAlternatives[${t}].applyReceipts[${r}]`, a = e.history.find((e) => e.revision === i.appliedRevision && e.before.revision === i.fromCanonicalRevision && i.patches.every((t) => {
			let n = on(e.before, t), r = on(e.after, t), i = t.before.present ? t.before.value : void 0, a = t.after.present ? t.after.value : void 0;
			return h(n ?? null) === h(i ?? null) && n === void 0 == !t.before.present && h(r ?? null) === h(a ?? null) && r === void 0 == !t.after.present;
		}));
		if (!a) {
			u.push({
				code: "INTEGRITY_FAILED",
				path: n,
				message: "正本採用記録に対応する不変の変更履歴がありません。"
			});
			continue;
		}
		for (let [e, t] of i.patches.entries()) {
			let r = on(a.before, t), i = on(a.after, t), o = t.before.present ? t.before.value : void 0, s = t.after.present ? t.after.value : void 0;
			(h(r ?? null) !== h(o ?? null) || r === void 0 != !t.before.present) && u.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.patches[${e}].before`,
				message: "採用前の正本値が対応する変更履歴と一致しません。"
			}), (h(i ?? null) !== h(s ?? null) || i === void 0 != !t.after.present) && u.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.patches[${e}].after`,
				message: "採用後の正本値が対応する変更履歴と一致しません。"
			});
		}
	}
	for (let [t, n] of e.history.entries()) for (let e of ["before", "after"]) {
		let r = n[e], a = dn(r);
		u.push(...await i(a, s.worldSnapshots, `project.history[${t}].${e}.worldReferences`, o));
		for (let [n, r] of a.snapshots.entries()) u.push(...await i(r.content, s.worldSnapshots, `project.history[${t}].${e}.snapshots[${n}].content.worldReferences`, o));
		r.authorAlternatives?.length && u.push(...await hn(a, s, `project.history[${t}].${e}`, o)), u.push(...await gn(a, s, o));
	}
	return u.slice(0, 256);
}
//#endregion
//#region src/domain/internImmutableRecords.ts
function bn() {
	let e = /* @__PURE__ */ new WeakMap(), t = /* @__PURE__ */ new Map(), n = 0, r = (e, t, n = /* @__PURE__ */ new WeakMap()) => {
		if (Object.is(e, t)) return !0;
		if (!e || !t || typeof e != "object" || typeof t != "object" || Object.getPrototypeOf(e) !== Object.getPrototypeOf(t)) return !1;
		if (n.get(e)?.has(t)) return !0;
		let i = Reflect.ownKeys(e);
		if (i.length !== Reflect.ownKeys(t).length || i.some((e) => !Object.hasOwn(t, e))) return !1;
		let a = n.get(e);
		return a || (a = /* @__PURE__ */ new WeakSet(), n.set(e, a)), a.add(t), i.every((i) => r(e[i], t[i], n));
	}, i = (a, o = 0) => {
		if (!a || typeof a != "object" || o > 128) return a;
		if (e.has(a)) return e.get(a);
		let s = a;
		if (typeof s.id == "string" && typeof s.projectId == "string" && (typeof s.kind == "string" && s.data && typeof s.data == "object" || typeof s.relationType == "string" && typeof s.fromId == "string" && typeof s.toId == "string")) {
			let i = `${s.projectId}:${s.kind ?? s.relationType}:${s.id}`, o = t.get(i)?.find((e) => r(a, e));
			return o ? (e.set(a, o), o) : (n >= 1e5 && (t.clear(), n = 0), t.has(i) ? t.get(i).unshift(a) : t.set(i, [a]), n++, e.set(a, a), a);
		}
		let c = Object.keys(a), l;
		for (let e of c) {
			let t = s[e], n = i(t, o + 1);
			Object.is(n, t) || (l ??= /* @__PURE__ */ new Map(), l.set(e, n));
		}
		if (!l) return e.set(a, a), a;
		let u = Array.isArray(a) ? Array(a.length) : Object.create(Object.getPrototypeOf(a));
		for (let e of c) Object.defineProperty(u, e, {
			value: l.has(e) ? l.get(e) : s[e],
			enumerable: !0,
			writable: !0,
			configurable: !0
		});
		return e.set(a, u), u;
	};
	return (e) => {
		let t = i(e);
		return j(t) ? t : e;
	};
}
function xn(e) {
	return s(e) ? bn()(e) : e;
}
Object.hasOwn, Array.isArray, Array.prototype.every, Array.prototype.some, Array.prototype.find, Array.prototype.unshift, Map.prototype.get, Map.prototype.set, Map.prototype.has, Map.prototype.clear, WeakMap.prototype.get, WeakMap.prototype.set, WeakMap.prototype.has, WeakSet.prototype.has, WeakSet.prototype.add;
async function Sn(e, t) {
	if (B(t), !s(e)) return e;
	let n = /* @__PURE__ */ new WeakMap(), r = /* @__PURE__ */ new Map(), i = 0, a = 0, c = performance.now() + 8, l = async () => {
		++a % 128 == 0 && performance.now() >= c && (B(t), await new Promise((e) => setTimeout(e, 0)), B(t), c = performance.now() + 8);
	}, u = async (e, t) => {
		let n = /* @__PURE__ */ new WeakMap(), r = [[e, t]];
		for (; r.length;) {
			let [e, t] = r.pop();
			if (Object.is(e, t)) continue;
			if (!e || !t || typeof e != "object" || typeof t != "object" || Object.getPrototypeOf(e) !== Object.getPrototypeOf(t)) return !1;
			if (n.get(e)?.has(t)) continue;
			let i = Reflect.ownKeys(e);
			if (i.length !== Reflect.ownKeys(t).length) return !1;
			let a = n.get(e);
			a || (a = /* @__PURE__ */ new WeakSet(), n.set(e, a)), a.add(t);
			for (let n of i) {
				if (!Object.hasOwn(t, n)) return !1;
				r.push([e[n], t[n]]), await l();
			}
			await l();
		}
		return !0;
	}, d = [], f = async (e) => {
		if (!e || typeof e != "object") return e;
		if (n.has(e)) return n.get(e);
		let t = e;
		if (typeof t.id == "string" && typeof t.projectId == "string" && (typeof t.kind == "string" && t.data && typeof t.data == "object" || typeof t.relationType == "string" && typeof t.fromId == "string" && typeof t.toId == "string")) {
			let a = `${t.projectId}:${t.kind ?? t.relationType}:${t.id}`;
			for (let t of r.get(a) ?? []) if (await u(e, t)) return n.set(e, t), t;
			return i >= 1e5 && (r.clear(), i = 0), r.has(a) ? r.get(a).unshift(e) : r.set(a, [e]), i++, n.set(e, e), e;
		}
		let a = Array.isArray(e) ? Array(e.length) : Object.create(Object.getPrototypeOf(e));
		return n.set(e, a), d.push({
			input: e,
			output: a,
			keys: Array.isArray(e) ? void 0 : Object.keys(e),
			index: 0
		}), a;
	}, p = await f(e);
	for (; d.length;) {
		let e = d.at(-1), t = e.keys?.length ?? e.input.length;
		if (e.index >= t) {
			d.pop();
			continue;
		}
		let n = e.keys?.[e.index] ?? String(e.index);
		e.index++;
		let r = await f(e.input[n]);
		Object.defineProperty(e.output, n, {
			value: r,
			enumerable: !0,
			writable: !0,
			configurable: !0
		}), await l();
	}
	return B(t), await o(p, t) ? p : e;
}
//#endregion
//#region src/sync/merge.ts
function Cn(e) {
	return e ? {
		fields: e.fields,
		tombstone: e.tombstone
	} : null;
}
function wn(e, t, n) {
	n.present && (e[t] = H(n.value));
}
function Tn(e, t, n, r) {
	return {
		targetId: t.id,
		base: H(e),
		local: H(t),
		server: H(n),
		reasons: r,
		fields: [],
		automaticFields: {}
	};
}
function En(e, t, n) {
	we(t);
	for (let r of [e, n]) if (r && (we(r), r.id !== t.id || r.projectId !== t.projectId)) throw new U("PROTOCOL_INVALID");
	if (!e) return !n || V(Cn(t), Cn(n)) ? {
		status: "merged",
		document: H(n ?? t)
	} : {
		status: "conflict",
		conflict: Tn(e, t, n, ["concurrent-create"])
	};
	if (!n) return {
		status: "conflict",
		conflict: Tn(e, t, n, ["missing-server-record"])
	};
	let r = !V(Cn(e), Cn(t)), i = !V(Cn(e), Cn(n));
	if (!r) return {
		status: "merged",
		document: H(n)
	};
	if (!i) return {
		status: "merged",
		document: H(t)
	};
	if (V(Cn(t), Cn(n))) return {
		status: "merged",
		document: H(n)
	};
	let a = t.tombstone !== null, o = n.tombstone !== null, s = !V(e.tombstone, t.tombstone), c = !V(e.tombstone, n.tombstone);
	if (a !== o && (s || c)) return {
		status: "conflict",
		conflict: Tn(e, t, n, ["delete-versus-edit"])
	};
	if (a || o) return a && o && V(t.fields, n.fields) ? {
		status: "merged",
		document: H(n)
	} : {
		status: "conflict",
		conflict: Tn(e, t, n, ["delete-versus-edit"])
	};
	let l = H(n);
	l.fields = {};
	let u = Tn(e, t, n, ["same-field"]), d = [.../* @__PURE__ */ new Set([
		...Object.keys(e.fields),
		...Object.keys(t.fields),
		...Object.keys(n.fields)
	])].sort();
	for (let r of d) {
		let i = Te(e, r), a = Te(t, r), o = Te(n, r), s;
		if (V(a, o)) s = a;
		else if (V(a, i)) s = o;
		else if (V(o, i)) s = a;
		else {
			u.fields.push({
				field: r,
				base: i,
				local: a,
				server: o
			});
			continue;
		}
		u.automaticFields[r] = H(s), wn(l.fields, r, s);
	}
	return u.fields.length ? {
		status: "conflict",
		conflict: u
	} : {
		status: "merged",
		document: l
	};
}
function Dn(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) if (![
		"id",
		"projectId",
		"revision",
		"createdAt",
		"updatedAt",
		"deletedAt",
		"deleteOperationId",
		"deletionOperationId"
	].includes(n)) {
		if (n === "$tombstone" || n.startsWith("data.")) throw new U("PROTOCOL_INVALID");
		if (n === "data" && r && typeof r == "object" && !Array.isArray(r)) for (let [e, n] of Object.entries(r)) {
			if (e.includes(".")) throw new U("PROTOCOL_INVALID");
			n !== void 0 && (t["data." + e] = H(n));
		}
		else r !== void 0 && (t[n] = H(r));
	}
	return t;
}
//#endregion
//#region src/sync/validation.ts
async function On(e, t) {
	await De(e, t);
	let n = [];
	for (let [r, i] of e.targets.entries()) {
		let e = t.documents[r], a = En(i.base, i.local, e);
		if (t.status === "applied") {
			if (a.status !== "merged" || !e || !V({
				fields: a.document.fields,
				tombstone: a.document.tombstone
			}, {
				fields: e.fields,
				tombstone: e.tombstone
			})) throw new U("PROTOCOL_INVALID");
		} else a.status === "conflict" && n.push(a.conflict);
	}
	if (t.status === "conflict" && !V(t.conflicts, n)) throw new U("PROTOCOL_INVALID");
}
//#endregion
//#region src/sync/adapter.ts
function kn(e) {
	if (e.deletedAt && !e.deletionOperationId) throw new U("PROTOCOL_INVALID");
	let t = {
		id: e.id,
		projectId: e.projectId,
		revision: e.revision,
		fields: Dn(e),
		tombstone: e.deletedAt ? {
			deletedAt: e.deletedAt,
			operationId: e.deletionOperationId
		} : null
	};
	return we(t), t;
}
//#endregion
//#region src/sync/nativeBridge.ts
function An(e, t) {
	let { entities: n, relations: r, history: i, ...a } = e;
	return [
		kn({
			...a,
			id: e.projectId,
			kind: "project",
			visibility: "private",
			revision: t,
			entityIds: n.map((e) => e.id),
			relationIds: r.map((e) => e.id)
		}),
		...n.map((e) => {
			let n = kn({
				...e,
				revision: t
			});
			return n.fields.createdAt = e.createdAt, n;
		}),
		...r.map((e) => kn({
			...e,
			revision: t
		}))
	];
}
function jn(e, t) {
	return V(e ? {
		fields: e.fields,
		tombstone: e.tombstone
	} : null, t ? {
		fields: t.fields,
		tombstone: t.tombstone
	} : null);
}
function Mn(e) {
	let t = {
		id: e.id,
		projectId: e.projectId,
		revision: e.revision
	};
	for (let [n, r] of Object.entries(e.fields)) if (n.startsWith("data.")) {
		let e = n.slice(5);
		if (!e || e.includes(".") || [
			"__proto__",
			"prototype",
			"constructor"
		].includes(e)) throw new U("PROTOCOL_INVALID");
		t.data ??= {}, t.data[e] = H(r);
	} else {
		if ([
			"id",
			"projectId",
			"revision",
			"updatedAt",
			"deletedAt",
			"deletionOperationId",
			"__proto__",
			"prototype",
			"constructor"
		].includes(n)) throw new U("PROTOCOL_INVALID");
		t[n] = H(r);
	}
	return e.tombstone && (t.deletedAt = e.tombstone.deletedAt, t.deletionOperationId = e.tombstone.operationId), t;
}
function Nn(e, t, n) {
	let r = new Map(t.map((e) => [e.id, e]));
	if (r.size !== t.length) throw new U("PROTOCOL_INVALID");
	let i = r.get(e.projectId);
	if (!i || i.fields.kind !== "project" || i.tombstone) throw new U("PROTOCOL_INVALID");
	let { id: a, kind: o, visibility: s, entityIds: c, relationIds: l, ...u } = Mn(i);
	if (!Array.isArray(c) || !Array.isArray(l) || [...c, ...l].some((e) => typeof e != "string") || (/* @__PURE__ */ new Set([
		...c,
		...l,
		i.id
	])).size !== t.length) throw new U("PROTOCOL_INVALID");
	let d = new Map([...e.entities, ...e.relations].map((e) => [e.id, e])), f = (t, i) => {
		let a = r.get(t);
		if (!a || a.projectId !== e.projectId) throw new U("PROTOCOL_INVALID");
		let o = Mn(a), s = d.get(a.id);
		if (i) {
			if (o.createdAt = o.createdAt ?? (s && "createdAt" in s ? s.createdAt : n), s && "createdAt" in s && s.createdAt !== o.createdAt) throw new U("PROTOCOL_INVALID");
			o.updatedAt = s && "updatedAt" in s ? s.updatedAt : n;
		}
		return o.revision = s?.revision ?? "0", a.tombstone || (delete o.deletedAt, delete o.deletionOperationId), o;
	};
	return {
		...u,
		projectId: e.projectId,
		revision: e.revision,
		entities: c.map((e) => f(e, !0)),
		relations: l.map((e) => f(e, !1)),
		history: e.history
	};
}
async function Pn(e, t, n, r, i) {
	e = H(e);
	let a = H(n), o = H(t), s = H(r), c = An(a, o.serverRevision), l = new Map(o.documents.map((e) => [e.id, e])), u = c.filter((e) => !jn(l.get(e.id), e)).map((e) => ({
		base: l.get(e.id) ?? null,
		local: e
	}));
	if (o.documents.some((e) => !c.some((t) => t.id === e.id))) throw new U("PROTOCOL_INVALID");
	if (!u.length) return null;
	let d = await Se({
		scope: H(e),
		baseRevision: o.serverRevision,
		operationId: _(),
		targets: u,
		reason: i
	});
	return {
		operationId: d.operationId,
		projectId: e.projectId,
		operation: d,
		localRevision: a.revision,
		localDocuments: c,
		outboxIds: s,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function Fn(e, t, n, r) {
	if (BigInt(n.serverRevision) < BigInt(t.serverRevision) || !n.confirmedDocuments) throw new U("PROTOCOL_INVALID");
	let i = new Map(n.confirmedDocuments.map((e) => [e.id, H(e)])), a = Array.isArray(r) ? r : An(r, n.serverRevision), o = new Map(e.localDocuments.map((e) => [e.id, e])), s = [], c = [];
	for (let e of a) {
		let t = i.get(e.id) ?? null, n = o.get(e.id) ?? null;
		if (!n && !t) {
			c.push(H(e));
			continue;
		}
		let r = En(n, e, t);
		r.status === "conflict" ? (s.push(r.conflict), c.push(H(e))) : c.push(r.document);
	}
	for (let e of i.values()) c.some((t) => t.id === e.id) || c.push(H(e));
	return {
		confirmed: [...i.values()],
		documents: c,
		conflicts: s
	};
}
function In(e, t, n, r) {
	let i = new Map(n.map((e) => [e.id, e])), a = new Map((Array.isArray(r) ? r : An(r, e.ack.serverRevision)).map((e) => [e.id, e]));
	if (!V(Object.keys(t).sort(), e.conflicts.map((e) => e.targetId).sort())) throw new U("PROTOCOL_INVALID");
	let o = /* @__PURE__ */ new Set([
		...e.prepared.operation.targets.map((e) => e.targetId),
		...e.conflicts.map((e) => e.targetId),
		...a.keys()
	]), s = [];
	for (let n of o) {
		let r = i.get(n) ?? null, o = a.get(n), c = e.prepared.operation.targets.find((e) => e.targetId === n), l = e.conflicts.find((e) => e.targetId === n);
		if (!o) throw new U("PROTOCOL_INVALID");
		let u = H(o);
		if (l) {
			if (!V(l.server, r)) throw new U("REVISION_CHANGED");
			let e = En(l.base, o, r), i = t[n];
			if (e.status === "merged") u = e.document;
			else if (i.strategy === "fields") {
				if (e.conflict.reasons.some((e) => e !== "same-field") || !V(Object.keys(i.choices).sort(), e.conflict.fields.map((e) => e.field).sort()) || !r) throw new U("REVISION_CHANGED");
				u = H(r), u.fields = {};
				for (let [t, n] of Object.entries(e.conflict.automaticFields)) n.present && (u.fields[t] = H(n.value));
				for (let t of e.conflict.fields) {
					let e = i.choices[t.field], n = e === "local" ? t.local : e === "server" ? t.server : e.value;
					n.present && (u.fields[t.field] = H(n.value));
				}
			} else if (e.conflict.reasons.every((e) => e === "same-field") && r) {
				u = H(r), u.fields = {};
				for (let [t, n] of Object.entries(e.conflict.automaticFields)) n.present && (u.fields[t] = H(n.value));
				for (let t of e.conflict.fields) {
					let e = i.strategy === "local" ? t.local : t.server;
					e.present && (u.fields[t.field] = H(e.value));
				}
			} else u = H(i.strategy === "local" ? o : r ?? (() => {
				throw new U("BASE_UNAVAILABLE");
			})());
		} else if (e.ack.status === "conflict" && c) {
			let e = En(c.base, o, r);
			if (e.status === "conflict") throw new U("REVISION_CHANGED");
			u = e.document;
		}
		(c || l || !jn(r, u)) && s.push({
			base: H(r),
			local: u
		});
	}
	return s;
}
//#endregion
//#region src/storage/syncRecovery.ts
function Ln(e = []) {
	return e.flatMap((e) => {
		let t = [];
		e.base && t.push(e.base.documents);
		for (let n of e.prepared) t.push(n.localDocuments);
		for (let n of e.conflicts) t.push(n.prepared.localDocuments), n.ack.confirmedDocuments && t.push(n.ack.confirmedDocuments);
		for (let n of e.acknowledgements) n.ack.confirmedDocuments && t.push(n.ack.confirmedDocuments);
		return [H(e.origin), ...t.map((t) => Nn(e.origin, t, "1970-01-01T00:00:00.000Z"))].map((e) => ({
			...e,
			history: []
		}));
	});
}
async function Rn(e, t, n) {
	if (!Array.isArray(e) || e.length > 1e5) throw new z("VALIDATION_FAILED", "同期復元証跡の形式・件数が不正です。");
	let r = H(e), i = /* @__PURE__ */ new Set();
	try {
		for (let e of r) {
			if (B(n), !e || e.format !== "scenario-sync-recovery" || e.version !== 1 || e.state !== "needs_reconnect" || !e.origin || !M.test(e.origin.projectId) || !Array.isArray(e.prepared) || !Array.isArray(e.conflicts) || !Array.isArray(e.acknowledgements) || Object.keys(e).some((e) => ![
				"format",
				"version",
				"state",
				"origin",
				"base",
				"prepared",
				"conflicts",
				"acknowledgements",
				"assetAcknowledgements",
				"contentHash"
			].includes(e))) throw new U("PROTOCOL_INVALID");
			let { contentHash: r, ...a } = e;
			if (await Ce(a) !== r || i.has(r) || (i.add(r), e.base && (!Oe(e.base.serverRevision) || !Array.isArray(e.base.documents) || e.base.documents.length > 100001 || e.base.projectId !== e.origin.projectId || await Ce(e.base.documents) !== e.base.contentHash))) throw new U("PROTOCOL_INVALID");
			if (e.base) for (let t of e.base.documents) xe(t, {
				accountId: "00000000-0000-4000-8000-000000000001",
				projectId: e.origin.projectId
			}, t.id);
			if (e.assetAcknowledgements) {
				if (!Array.isArray(e.assetAcknowledgements)) throw new U("PROTOCOL_INVALID");
				for (let t of e.assetAcknowledgements) if (t.projectId !== e.origin.projectId || t.key !== `${t.projectId}:${t.contentHash}` || !/^[0-9a-f]{64}$/.test(t.contentHash) || !Number.isSafeInteger(t.byteSize) || t.byteSize < 0 || t.byteSize > 33554432 || typeof t.mediaType != "string") throw new U("PROTOCOL_INVALID");
			}
			for (let t of [...e.prepared, ...e.conflicts.map((e) => e.prepared)]) {
				if (await Ee(t.operation), t.operationId !== t.operation.operationId || t.projectId !== e.origin.projectId || t.operation.scope.projectId !== t.projectId || !Oe(t.localRevision) || !Array.isArray(t.localDocuments) || t.localDocuments.length > 100001 || !Array.isArray(t.outboxIds) || t.outboxIds.length > 1e5 || new Set(t.outboxIds).size !== t.outboxIds.length || t.outboxIds.some((e) => !M.test(e)) || !Number.isFinite(Date.parse(t.createdAt)) || t.origin !== void 0 && !["prepared_operation", "received_image"].includes(t.origin)) throw new U("PROTOCOL_INVALID");
				for (let e of t.localDocuments) xe(e, t.operation.scope, e.id);
				for (let e of t.operation.targets) if (!V(e.local, t.localDocuments.find((t) => t.id === e.targetId))) throw new U("PROTOCOL_INVALID");
			}
			for (let t of e.conflicts) if (t.operationId !== t.prepared.operationId || t.projectId !== e.origin.projectId || (await On(t.prepared.operation, t.ack), !Array.isArray(t.conflicts) || t.conflicts.some((e) => {
				let t = En(e.base, e.local, e.server);
				return t.status !== "conflict" || !V(t.conflict, e);
			})) || t.ack.status === "conflict" && JSON.stringify(t.conflicts) !== JSON.stringify(t.ack.conflicts)) throw new U("PROTOCOL_INVALID");
			for (let t of e.acknowledgements) {
				if (t.origin !== void 0 && !["prepared_operation", "received_image"].includes(t.origin) || t.projectId !== e.origin.projectId || t.operationId !== t.operation.operationId) throw new U("PROTOCOL_INVALID");
				await Ee(t.operation), await On(t.operation, t.ack);
			}
			for (let r of Ln([e])) if (B(n), !d(r, { worldSnapshots: t }).ok || (await _n(r, { worldSnapshots: t }, !1)).length) throw new U("PROTOCOL_INVALID");
		}
	} catch {
		throw n?.aborted && B(n), new z("VALIDATION_FAILED", "同期の共通元・二案・ACK・hashの整合性を確認できません。");
	}
	return r;
}
//#endregion
//#region src/storage/recordDictionary.ts
var zn = "shared-records-v1", Bn = "shared-record-deltas-v1", Vn = "shared-calendar-records-v1", Hn = (e) => !!e && typeof e == "object" && !Array.isArray(e), Un = (e) => Hn(e) && typeof e.id == "string" && typeof e.projectId == "string" && (typeof e.kind == "string" && Hn(e.data) || typeof e.relationType == "string" && typeof e.fromId == "string" && typeof e.toId == "string" || typeof e.revision == "string" && Hn(e.fields) && Object.hasOwn(e, "tombstone")), Wn = (e) => Hn(e) && typeof e.id == "string" && (e.kind === "gregorian" || e.kind === "repeating"), Gn = "__recordBase", Kn = "__recordDelete", qn = class {
	features;
	records = [];
	arrays = [];
	ids = /* @__PURE__ */ new Map();
	identities = /* @__PURE__ */ new WeakMap();
	arrayIds = /* @__PURE__ */ new Map();
	previous = /* @__PURE__ */ new Map();
	previousRecords = /* @__PURE__ */ new Map();
	previousKinds = /* @__PURE__ */ new Map();
	usedFeatures = /* @__PURE__ */ new Set();
	constructor(e = {}) {
		this.features = e;
	}
	eligible(e) {
		return Un(e) || !!this.features.calendarRecords && Wn(e);
	}
	add(e) {
		let t = this.identities.get(e);
		if (t !== void 0) return t;
		let n = h(e), r = this.ids.get(n);
		if (r === void 0) {
			r = this.records.length;
			let t = e, i = typeof e.kind == "string" && Hn(e.data) ? "entity" : typeof e.relationType == "string" ? "relation" : Wn(e) ? "calendar" : "shadow", a = JSON.stringify([
				i,
				e.projectId ?? null,
				e.kind ?? e.relationType ?? null
			]), o = JSON.stringify([a, e.id]), s = this.previousRecords.get(o), c = this.previousKinds.get(a), l = s?.id === c?.id ? [s] : [s, c], u = n.length;
			if (this.features.recordDeltas && !Object.hasOwn(e, Gn) && !Object.hasOwn(e, Kn)) for (let n of l) {
				if (!n || Object.hasOwn(n.value, Gn) || Object.hasOwn(n.value, Kn)) continue;
				let r = { [Gn]: n.id }, i = [];
				for (let t of Object.keys(n.value)) n.value[t] !== void 0 && (!Object.hasOwn(e, t) || e[t] === void 0) && i.push(t);
				for (let t of Object.keys(e)) e[t] !== void 0 && (!Object.hasOwn(n.value, t) || n.value[t] === void 0 || h(e[t]) !== h(n.value[t])) && Object.defineProperty(r, t, {
					value: e[t],
					enumerable: !0
				});
				i.length && (r[Kn] = i);
				let a = h(r).length;
				a < u && (t = r, u = a, this.usedFeatures.add(Bn));
			}
			!Un(e) && Wn(e) && this.usedFeatures.add(Vn), this.records.push(t), this.ids.set(n, r), this.previousRecords.set(o, {
				id: r,
				value: e
			}), this.previousKinds.set(a, {
				id: r,
				value: e
			});
		}
		return this.identities.set(e, r), r;
	}
	encode(e) {
		let t = [], n = [], r = (e, i) => {
			if (Array.isArray(e)) {
				if (e.length && e.every((e) => this.eligible(e))) {
					t.push(i);
					let n = e.map((e) => this.add(e)), r = n.join(","), a = this.arrayIds.get(r);
					if (a === void 0) {
						a = this.arrays.length;
						let e = this.previous.get(n.length), t = e ? n.flatMap((t, n) => t === e.values[n] ? [] : [[n, t]]) : void 0;
						this.arrays.push(e && t && t.length * 2 < n.length ? {
							base: e.id,
							length: n.length,
							changes: t
						} : { values: n }), this.arrayIds.set(r, a);
					}
					return this.previous.set(n.length, {
						id: a,
						values: n
					}), a;
				}
				return e.map((e, t) => r(e, [...i, t]));
			}
			return Hn(e) ? this.eligible(e) ? (n.push(i), this.add(e)) : Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0).map(([e, t]) => [e, r(t, [...i, e])])) : e;
		};
		return {
			version: 1,
			value: r(e, []),
			arrays: t,
			records: n
		};
	}
}, Jn = class {
	pool;
	limits;
	references = 0;
	depths = [];
	records = [];
	arrays = [];
	arrayCache = /* @__PURE__ */ new Map();
	recordIds = /* @__PURE__ */ new Map();
	usedRecords = /* @__PURE__ */ new Set();
	recordBases = /* @__PURE__ */ new Map();
	constructor(e, t, n = {}) {
		this.pool = e, this.limits = t;
		let r = () => {
			throw new z("ARCHIVE_INVALID", "共有レコード辞書の形式が不正です。", "data/records.json");
		};
		if (!Hn(e) || Object.keys(e).some((e) => !["records", "arrays"].includes(e)) || !Array.isArray(e.records) || !Array.isArray(e.arrays) || e.records.length > t.objects || e.arrays.length > t.objects) return r();
		this.records = [];
		for (let [i, a] of e.records.entries()) {
			let e = a;
			if (!Un(a) && !(n.calendarRecords && Wn(a))) {
				if (!n.recordDeltas || !Hn(a) || !Number.isSafeInteger(a[Gn]) || Number(a[Gn]) < 0 || Number(a[Gn]) >= i) return r();
				let o = Number(a[Gn]), s = this.records[o], c = Object.create(Object.getPrototypeOf(s));
				for (let [e, t] of Object.entries(s)) Object.defineProperty(c, e, {
					value: t,
					enumerable: !0,
					writable: !0,
					configurable: !0
				});
				if (Object.hasOwn(a, Kn)) {
					let e = a[Kn];
					if (!Array.isArray(e) || new Set(e).size !== e.length) return r();
					for (let t of e) {
						if (typeof t != "string" || [Gn, Kn].includes(t) || !Object.hasOwn(c, t) || Object.hasOwn(a, t)) return r();
						delete c[t];
					}
				}
				for (let [e, t] of Object.entries(a)) [Gn, Kn].includes(e) || Object.defineProperty(c, e, {
					value: t,
					enumerable: !0,
					writable: !0,
					configurable: !0
				});
				if (e = c, this.recordBases.set(i, o), this.references++, this.references > Math.floor(t.expandedBytes / 8)) throw new z("LIMIT_EXCEEDED", "共有レコード参照の展開が安全上限を超えています。");
				if (!Un(e) && !(n.calendarRecords && Wn(e))) return r();
			}
			this.records.push(e);
		}
		this.arrays = e.arrays, this.records.forEach((e, t) => this.recordIds.set(e, t));
		let i = (e) => {
			if (!e || typeof e != "object") return 0;
			let t = 0;
			for (let n of Object.values(e)) t = Math.max(t, i(n));
			return t + 1;
		};
		this.depths = this.records.map(i);
		let a = (e) => {
			e && typeof e == "object" && !Object.isFrozen(e) && (Object.values(e).forEach(a), Object.freeze(e));
		};
		this.records.forEach((e) => {
			a(e), j(e);
		});
		for (let [e, t] of this.arrays.entries()) if (!Hn(t) || ("values" in t ? Object.keys(t).some((e) => e !== "values") || !Array.isArray(t.values) : Object.keys(t).some((e) => ![
			"base",
			"length",
			"changes"
		].includes(e)) || !Number.isSafeInteger(t.base) || t.base < 0 || t.base >= e || !Number.isSafeInteger(t.length) || t.length < 0 || !Array.isArray(t.changes))) throw new z("ARCHIVE_INVALID", "共有レコード配列の基底・形式が不正です。");
	}
	values(e) {
		let t = () => {
			throw new z("ARCHIVE_INVALID", "共有レコード配列の索引・差分が不正です。");
		};
		if (!Number.isSafeInteger(e) || Number(e) < 0 || Number(e) >= this.arrays.length) return t();
		let n = Number(e), r = this.arrayCache.get(n);
		if (r) return r;
		let i = [], a = n;
		for (; !this.arrayCache.has(a);) {
			i.push(a);
			let e = this.arrays[a];
			if ("values" in e) break;
			a = e.base;
		}
		let o = (e) => !Number.isSafeInteger(e) || Number(e) < 0 || Number(e) >= this.records.length ? t() : this.records[Number(e)];
		for (let e of i.reverse()) {
			let n = this.arrays[e], r;
			if ("values" in n) r = n.values.map(o);
			else {
				if (r = this.arrayCache.get(n.base).slice(), r.length !== n.length) return t();
				let e = /* @__PURE__ */ new Set();
				for (let i of n.changes) {
					if (!Array.isArray(i) || i.length !== 2 || !Number.isSafeInteger(i[0]) || i[0] < 0 || i[0] >= r.length || e.has(i[0])) return t();
					e.add(i[0]), r[i[0]] = o(i[1]);
				}
			}
			if (r.length > this.limits.records) return t();
			if (this.references += r.length, this.references > Math.floor(this.limits.expandedBytes / 8)) throw new z("LIMIT_EXCEEDED", "共有レコード参照の展開が安全上限を超えています。");
			Object.freeze(r), j(r), this.arrayCache.set(e, r);
		}
		return this.arrayCache.get(n);
	}
	decode(e, t) {
		let n = () => {
			throw new z("ARCHIVE_INVALID", "共有レコードの位置・索引・重複が不正です。", t);
		};
		if (!Hn(e) || e.version !== 1 || Object.keys(e).some((e) => ![
			"version",
			"value",
			"arrays",
			"records"
		].includes(e)) || !Object.hasOwn(e, "value") || !Array.isArray(e.arrays) || !Array.isArray(e.records)) return n();
		let r = [...e.arrays, ...e.records];
		if (r.length > this.limits.objects) return n();
		let i = /* @__PURE__ */ new Set(), a = [], o = e.value;
		for (let [s, c] of r.entries()) {
			if (!Array.isArray(c) || c.length > this.limits.depth || c.some((e) => !(typeof e == "string" && ![
				"__proto__",
				"prototype",
				"constructor"
			].includes(e) || Number.isSafeInteger(e) && Number(e) >= 0))) return n();
			let l = c, u = JSON.stringify(l);
			if (i.has(u)) return n();
			i.add(u);
			let d = o;
			for (let e of l.slice(0, -1)) {
				if (!d || typeof d != "object" || !Object.hasOwn(d, e)) return n();
				d = d[e];
			}
			let f = l.at(-1), p = f === void 0 ? o : d && typeof d == "object" && Object.hasOwn(d, f) ? d[f] : void 0, m = s < e.arrays.length, h = m ? this.values(p) : Number.isSafeInteger(p) && Number(p) >= 0 && Number(p) < this.records.length ? [this.records[Number(p)]] : n();
			if (!m && (this.references++, this.references > Math.floor(this.limits.expandedBytes / 8))) throw new z("LIMIT_EXCEEDED", "共有レコード参照の展開が安全上限を超えています。", t);
			for (let e of h) {
				let n = this.recordIds.get(e);
				if (l.length + this.depths[n] > this.limits.depth) throw new z("LIMIT_EXCEEDED", "共有レコードの展開深さが安全上限を超えています。", t);
				let r = n;
				for (; r !== void 0 && !this.usedRecords.has(r);) this.usedRecords.add(r), r = this.recordBases.get(r);
			}
			let g = m ? h : h[0];
			if (f === void 0) {
				if (r.length !== 1) return n();
				o = g;
			} else {
				if (!d || typeof d != "object" || Array.isArray(d) && typeof f != "number" || !Array.isArray(d) && typeof f != "string") return n();
				a.push({
					parent: d,
					key: f,
					value: g
				});
			}
		}
		for (let e of r) for (let t = 0; t < e.length; t++) if (i.has(JSON.stringify(e.slice(0, t)))) return n();
		for (let e of a) e.parent[e.key] = e.value;
		return o;
	}
	assertComplete() {
		if (this.usedRecords.size !== this.records.length || this.arrayCache.size !== this.arrays.length) throw new z("ARCHIVE_INVALID", "未使用の共有レコード・配列が含まれています。", "data/records.json");
	}
}, Yn = Uint8Array, Xn = Uint16Array, Zn = Int32Array, Qn = new Yn([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), $n = new Yn([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), er = new Yn([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), tr = function(e, t) {
	for (var n = new Xn(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new Zn(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, nr = tr(Qn, 2), rr = nr.b, ir = nr.r;
rr[28] = 258, ir[258] = 28;
for (var ar = tr($n, 0), or = ar.b, sr = ar.r, cr = new Xn(32768), lr = 0; lr < 32768; ++lr) {
	var ur = (lr & 43690) >> 1 | (lr & 21845) << 1;
	ur = (ur & 52428) >> 2 | (ur & 13107) << 2, ur = (ur & 61680) >> 4 | (ur & 3855) << 4, cr[lr] = ((ur & 65280) >> 8 | (ur & 255) << 8) >> 1;
}
for (var dr = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new Xn(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new Xn(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new Xn(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[cr[d] >> c] = l;
	} else for (s = new Xn(r), i = 0; i < r; ++i) e[i] && (s[i] = cr[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), fr = new Yn(288), lr = 0; lr < 144; ++lr) fr[lr] = 8;
for (var lr = 144; lr < 256; ++lr) fr[lr] = 9;
for (var lr = 256; lr < 280; ++lr) fr[lr] = 7;
for (var lr = 280; lr < 288; ++lr) fr[lr] = 8;
for (var pr = new Yn(32), lr = 0; lr < 32; ++lr) pr[lr] = 5;
var mr = /*#__PURE__*/ dr(fr, 9, 0), hr = /*#__PURE__*/ dr(fr, 9, 1), gr = /*#__PURE__*/ dr(pr, 5, 0), _r = /*#__PURE__*/ dr(pr, 5, 1), vr = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, yr = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, br = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, xr = function(e) {
	return (e + 7) / 8 | 0;
}, Sr = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new Yn(e.subarray(t, n));
}, Cr = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], wr = function(e, t, n) {
	var r = Error(t || Cr[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, wr), !n) throw r;
	return r;
}, Tr = function(e, t, n, r) {
	var i = e.length, a = r ? r.length : 0;
	if (!i || t.f && !t.l) return n || new Yn(0);
	var o = !n, s = o || t.i != 2, c = t.i;
	o && (n = new Yn(i * 3));
	var l = function(e) {
		var t = n.length;
		if (e > t) {
			var r = new Yn(Math.max(t * 2, e));
			r.set(n), n = r;
		}
	}, u = t.f || 0, d = t.p || 0, f = t.b || 0, p = t.l, m = t.d, h = t.m, g = t.n, _ = i * 8;
	do {
		if (!p) {
			u = yr(e, d, 1);
			var v = yr(e, d + 1, 3);
			if (d += 3, !v) {
				var y = xr(d) + 4, b = e[y - 4] | e[y - 3] << 8, x = y + b;
				if (x > i) {
					c && wr(0);
					break;
				}
				s && l(f + b), n.set(e.subarray(y, x), f), t.b = f += b, t.p = d = x * 8, t.f = u;
				continue;
			}
			if (v == 1) p = hr, m = _r, h = 9, g = 5;
			else if (v == 2) {
				var S = yr(e, d, 31) + 257, C = yr(e, d + 10, 15) + 4, w = S + yr(e, d + 5, 31) + 1;
				d += 14;
				for (var T = new Yn(w), E = new Yn(19), D = 0; D < C; ++D) E[er[D]] = yr(e, d + D * 3, 7);
				d += C * 3;
				for (var O = vr(E), k = (1 << O) - 1, ee = dr(E, O, 1), D = 0; D < w;) {
					var te = ee[yr(e, d, k)];
					d += te & 15;
					var y = te >> 4;
					if (y < 16) T[D++] = y;
					else {
						var A = 0, j = 0;
						for (y == 16 ? (j = 3 + yr(e, d, 3), d += 2, A = T[D - 1]) : y == 17 ? (j = 3 + yr(e, d, 7), d += 3) : y == 18 && (j = 11 + yr(e, d, 127), d += 7); j--;) T[D++] = A;
					}
				}
				var ne = T.subarray(0, S), re = T.subarray(S);
				h = vr(ne), g = vr(re), p = dr(ne, h, 1), m = dr(re, g, 1);
			} else wr(1);
			if (d > _) {
				c && wr(0);
				break;
			}
		}
		s && l(f + 131072);
		for (var ie = (1 << h) - 1, M = (1 << g) - 1, ae = d;; ae = d) {
			var A = p[br(e, d) & ie], N = A >> 4;
			if (d += A & 15, d > _) {
				c && wr(0);
				break;
			}
			if (A || wr(2), N < 256) n[f++] = N;
			else if (N == 256) {
				ae = d, p = null;
				break;
			} else {
				var oe = N - 254;
				if (N > 264) {
					var D = N - 257, P = Qn[D];
					oe = yr(e, d, (1 << P) - 1) + rr[D], d += P;
				}
				var F = m[br(e, d) & M], se = F >> 4;
				F || wr(3), d += F & 15;
				var re = or[se];
				if (se > 3) {
					var P = $n[se];
					re += br(e, d) & (1 << P) - 1, d += P;
				}
				if (d > _) {
					c && wr(0);
					break;
				}
				s && l(f + 131072);
				var ce = f + oe;
				if (f < re) {
					var I = a - re, L = Math.min(re, ce);
					for (I + f < 0 && wr(3); f < L; ++f) n[f] = r[I + f];
				}
				for (; f < ce; ++f) n[f] = n[f - re];
			}
		}
		t.l = p, t.p = ae, t.b = f, t.f = u, p && (u = 1, t.m = h, t.d = m, t.n = g);
	} while (!u);
	return f != n.length && o ? Sr(n, 0, f) : n.subarray(0, f);
}, Er = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8;
}, Dr = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8, e[r + 2] |= n >> 16;
}, Or = function(e, t) {
	for (var n = [], r = 0; r < e.length; ++r) e[r] && n.push({
		s: r,
		f: e[r]
	});
	var i = n.length, a = n.slice();
	if (!i) return {
		t: Fr,
		l: 0
	};
	if (i == 1) {
		var o = new Yn(n[0].s + 1);
		return o[n[0].s] = 1, {
			t: o,
			l: 1
		};
	}
	n.sort(function(e, t) {
		return e.f - t.f;
	}), n.push({
		s: -1,
		f: 25001
	});
	var s = n[0], c = n[1], l = 0, u = 1, d = 2;
	for (n[0] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	}; u != i - 1;) s = n[n[l].f < n[d].f ? l++ : d++], c = n[l != u && n[l].f < n[d].f ? l++ : d++], n[u++] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	};
	for (var f = a[0].s, r = 1; r < i; ++r) a[r].s > f && (f = a[r].s);
	var p = new Xn(f + 1), m = kr(n[u - 1], p, 0);
	if (m > t) {
		var r = 0, h = 0, g = m - t, _ = 1 << g;
		for (a.sort(function(e, t) {
			return p[t.s] - p[e.s] || e.f - t.f;
		}); r < i; ++r) {
			var v = a[r].s;
			if (p[v] > t) h += _ - (1 << m - p[v]), p[v] = t;
			else break;
		}
		for (h >>= g; h > 0;) {
			var y = a[r].s;
			p[y] < t ? h -= 1 << t - p[y]++ - 1 : ++r;
		}
		for (; r >= 0 && h; --r) {
			var b = a[r].s;
			p[b] == t && (--p[b], ++h);
		}
		m = t;
	}
	return {
		t: new Yn(p),
		l: m
	};
}, kr = function(e, t, n) {
	return e.s == -1 ? Math.max(kr(e.l, t, n + 1), kr(e.r, t, n + 1)) : t[e.s] = n;
}, Ar = function(e) {
	for (var t = e.length; t && !e[--t];);
	for (var n = new Xn(++t), r = 0, i = e[0], a = 1, o = function(e) {
		n[r++] = e;
	}, s = 1; s <= t; ++s) if (e[s] == i && s != t) ++a;
	else {
		if (!i && a > 2) {
			for (; a > 138; a -= 138) o(32754);
			a > 2 && (o(a > 10 ? a - 11 << 5 | 28690 : a - 3 << 5 | 12305), a = 0);
		} else if (a > 3) {
			for (o(i), --a; a > 6; a -= 6) o(8304);
			a > 2 && (o(a - 3 << 5 | 8208), a = 0);
		}
		for (; a--;) o(i);
		a = 1, i = e[s];
	}
	return {
		c: n.subarray(0, r),
		n: t
	};
}, jr = function(e, t) {
	for (var n = 0, r = 0; r < t.length; ++r) n += e[r] * t[r];
	return n;
}, Mr = function(e, t, n) {
	var r = n.length, i = xr(t + 2);
	e[i] = r & 255, e[i + 1] = r >> 8, e[i + 2] = e[i] ^ 255, e[i + 3] = e[i + 1] ^ 255;
	for (var a = 0; a < r; ++a) e[i + a + 4] = n[a];
	return (i + 4 + r) * 8;
}, Nr = function(e, t, n, r, i, a, o, s, c, l, u) {
	Er(t, u++, n), ++i[256];
	for (var d = Or(i, 15), f = d.t, p = d.l, m = Or(a, 15), h = m.t, g = m.l, _ = Ar(f), v = _.c, y = _.n, b = Ar(h), x = b.c, S = b.n, C = new Xn(19), w = 0; w < v.length; ++w) ++C[v[w] & 31];
	for (var w = 0; w < x.length; ++w) ++C[x[w] & 31];
	for (var T = Or(C, 7), E = T.t, D = T.l, O = 19; O > 4 && !E[er[O - 1]]; --O);
	var k = l + 5 << 3, ee = jr(i, fr) + jr(a, pr) + o, te = jr(i, f) + jr(a, h) + o + 14 + 3 * O + jr(C, E) + 2 * C[16] + 3 * C[17] + 7 * C[18];
	if (c >= 0 && k <= ee && k <= te) return Mr(t, u, e.subarray(c, c + l));
	var A, j, ne, re;
	if (Er(t, u, 1 + (te < ee)), u += 2, te < ee) {
		A = dr(f, p, 0), j = f, ne = dr(h, g, 0), re = h;
		var ie = dr(E, D, 0);
		Er(t, u, y - 257), Er(t, u + 5, S - 1), Er(t, u + 10, O - 4), u += 14;
		for (var w = 0; w < O; ++w) Er(t, u + 3 * w, E[er[w]]);
		u += 3 * O;
		for (var M = [v, x], ae = 0; ae < 2; ++ae) for (var N = M[ae], w = 0; w < N.length; ++w) {
			var oe = N[w] & 31;
			Er(t, u, ie[oe]), u += E[oe], oe > 15 && (Er(t, u, N[w] >> 5 & 127), u += N[w] >> 12);
		}
	} else A = mr, j = fr, ne = gr, re = pr;
	for (var w = 0; w < s; ++w) {
		var P = r[w];
		if (P > 255) {
			var oe = P >> 18 & 31;
			Dr(t, u, A[oe + 257]), u += j[oe + 257], oe > 7 && (Er(t, u, P >> 23 & 31), u += Qn[oe]);
			var F = P & 31;
			Dr(t, u, ne[F]), u += re[F], F > 3 && (Dr(t, u, P >> 5 & 8191), u += $n[F]);
		} else Dr(t, u, A[P]), u += j[P];
	}
	return Dr(t, u, A[256]), u + j[256];
}, Pr = /*#__PURE__*/ new Zn([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]), Fr = /*#__PURE__*/ new Yn(0), Ir = function(e, t, n, r, i, a) {
	var o = a.z || e.length, s = new Yn(r + o + 5 * (1 + Math.ceil(o / 7e3)) + i), c = s.subarray(r, s.length - i), l = a.l, u = (a.r || 0) & 7;
	if (t) {
		u && (c[0] = a.r >> 3);
		for (var d = Pr[t - 1], f = d >> 13, p = d & 8191, m = (1 << n) - 1, h = a.p || new Xn(32768), g = a.h || new Xn(m + 1), _ = Math.ceil(n / 3), v = 2 * _, y = function(t) {
			return (e[t] ^ e[t + 1] << _ ^ e[t + 2] << v) & m;
		}, b = new Zn(25e3), x = new Xn(288), S = new Xn(32), C = 0, w = 0, T = a.i || 0, E = 0, D = a.w || 0, O = 0; T + 2 < o; ++T) {
			var k = y(T), ee = T & 32767, te = g[k];
			if (h[ee] = te, g[k] = ee, D <= T) {
				var A = o - T;
				if ((C > 7e3 || E > 24576) && (A > 423 || !l)) {
					u = Nr(e, c, 0, b, x, S, w, E, O, T - O, u), E = C = w = 0, O = T;
					for (var j = 0; j < 286; ++j) x[j] = 0;
					for (var j = 0; j < 30; ++j) S[j] = 0;
				}
				var ne = 2, re = 0, ie = p, M = ee - te & 32767;
				if (A > 2 && k == y(T - M)) for (var ae = Math.min(f, A) - 1, N = Math.min(32767, T), oe = Math.min(258, A); M <= N && --ie && ee != te;) {
					if (e[T + ne] == e[T + ne - M]) {
						for (var P = 0; P < oe && e[T + P] == e[T + P - M]; ++P);
						if (P > ne) {
							if (ne = P, re = M, P > ae) break;
							for (var F = Math.min(M, P - 2), se = 0, j = 0; j < F; ++j) {
								var ce = T - M + j & 32767, I = ce - h[ce] & 32767;
								I > se && (se = I, te = ce);
							}
						}
					}
					ee = te, te = h[ee], M += ee - te & 32767;
				}
				if (re) {
					b[E++] = 268435456 | ir[ne] << 18 | sr[re];
					var L = ir[ne] & 31, R = sr[re] & 31;
					w += Qn[L] + $n[R], ++x[257 + L], ++S[R], D = T + ne, ++C;
				} else b[E++] = e[T], ++x[e[T]];
			}
		}
		for (T = Math.max(T, D); T < o; ++T) b[E++] = e[T], ++x[e[T]];
		u = Nr(e, c, l, b, x, S, w, E, O, T - O, u), l || (a.r = u & 7 | c[u / 8 | 0] << 3, u -= 7, a.h = g, a.p = h, a.i = T, a.w = D);
	} else {
		for (var T = a.w || 0; T < o + l; T += 65535) {
			var le = T + 65535;
			le >= o && (c[u / 8 | 0] = l, le = o), u = Mr(c, u + 1, e.subarray(T, le));
		}
		a.i = o;
	}
	return Sr(s, 0, r + xr(u) + i);
}, Lr = /*#__PURE__*/ (function() {
	for (var e = /* @__PURE__ */ new Int32Array(256), t = 0; t < 256; ++t) {
		for (var n = t, r = 9; --r;) n = (n & 1 && -306674912) ^ n >>> 1;
		e[t] = n;
	}
	return e;
})(), Rr = function() {
	var e = -1;
	return {
		p: function(t) {
			for (var n = e, r = 0; r < t.length; ++r) n = Lr[n & 255 ^ t[r]] ^ n >>> 8;
			e = n;
		},
		d: function() {
			return ~e;
		}
	};
}, zr = function(e, t, n, r, i) {
	if (!i && (i = { l: 1 }, t.dictionary)) {
		var a = t.dictionary.subarray(-32768), o = new Yn(a.length + e.length);
		o.set(a), o.set(e, a.length), e = o, i.w = a.length;
	}
	return Ir(e, t.level == null ? 6 : t.level, t.mem == null ? i.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5) : 20 : 12 + t.mem, n, r, i);
}, Br = function(e, t) {
	var n = {};
	for (var r in e) n[r] = e[r];
	for (var r in t) n[r] = t[r];
	return n;
}, Vr = function(e, t, n) {
	for (; n; ++t) e[t] = n, n >>>= 8;
};
function Hr(e, t) {
	return zr(e, t || {}, 0, 0);
}
var Ur = /* @__PURE__ */ function() {
	function e(e, t) {
		typeof e == "function" && (t = e, e = {}), this.ondata = t;
		var n = e && e.dictionary && e.dictionary.subarray(-32768);
		this.s = {
			i: 0,
			b: n ? n.length : 0
		}, this.o = new Yn(32768), this.p = new Yn(0), n && this.o.set(n);
	}
	return e.prototype.e = function(e) {
		if (this.ondata || wr(5), this.d && wr(4), !this.p.length) this.p = e;
		else if (e.length) {
			var t = new Yn(this.p.length + e.length);
			t.set(this.p), t.set(e, this.p.length), this.p = t;
		}
	}, e.prototype.c = function(e) {
		this.s.i = +(this.d = e || !1);
		var t = this.s.b, n = Tr(this.p, this.s, this.o);
		this.ondata(Sr(n, t, this.s.b), this.d), this.o = Sr(n, this.s.b - 32768), this.s.b = this.o.length, this.p = Sr(this.p, this.s.p / 8 | 0), this.s.p &= 7;
	}, e.prototype.push = function(e, t) {
		this.e(e), this.c(t);
	}, e;
}(), Wr = function(e, t, n, r) {
	for (var i in e) {
		var a = e[i], o = t + i, s = r;
		Array.isArray(a) && (s = Br(r, a[1]), a = a[0]), ArrayBuffer.isView(a) ? n[o] = [a, s] : (n[o += "/"] = [new Yn(0), s], Wr(a, o, n, r));
	}
}, Gr = typeof TextEncoder < "u" && /*#__PURE__*/ new TextEncoder(), Kr = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	Kr.decode(Fr, { stream: !0 });
} catch {}
function qr(e, t) {
	if (t) {
		for (var n = new Yn(e.length), r = 0; r < e.length; ++r) n[r] = e.charCodeAt(r);
		return n;
	}
	if (Gr) return Gr.encode(e);
	for (var i = e.length, a = new Yn(e.length + (e.length >> 1)), o = 0, s = function(e) {
		a[o++] = e;
	}, r = 0; r < i; ++r) {
		if (o + 5 > a.length) {
			var c = new Yn(o + 8 + (i - r << 1));
			c.set(a), a = c;
		}
		var l = e.charCodeAt(r);
		l < 128 || t ? s(l) : l < 2048 ? (s(192 | l >> 6), s(128 | l & 63)) : l > 55295 && l < 57344 ? (l = 65536 + (l & 1047552) | e.charCodeAt(++r) & 1023, s(240 | l >> 18), s(128 | l >> 12 & 63), s(128 | l >> 6 & 63), s(128 | l & 63)) : (s(224 | l >> 12), s(128 | l >> 6 & 63), s(128 | l & 63));
	}
	return Sr(a, 0, o);
}
var Jr = function(e) {
	var t = 0;
	if (e) for (var n in e) {
		var r = e[n].length;
		r > 65535 && wr(9), t += r + 4;
	}
	return t;
}, Yr = function(e, t, n, r, i, a, o, s) {
	var c = r.length, l = n.extra, u = s && s.length, d = Jr(l);
	Vr(e, t, o == null ? 67324752 : 33639248), t += 4, o != null && (e[t++] = 20, e[t++] = n.os), e[t] = 20, t += 2, e[t++] = n.flag << 1 | (a < 0 && 8), e[t++] = i && 8, e[t++] = n.compression & 255, e[t++] = n.compression >> 8;
	var f = new Date(n.mtime == null ? Date.now() : n.mtime), p = f.getFullYear() - 1980;
	if ((p < 0 || p > 119) && wr(10), Vr(e, t, p << 25 | f.getMonth() + 1 << 21 | f.getDate() << 16 | f.getHours() << 11 | f.getMinutes() << 5 | f.getSeconds() >> 1), t += 4, a != -1 && (Vr(e, t, n.crc), Vr(e, t + 4, a < 0 ? -a - 2 : a), Vr(e, t + 8, n.size)), Vr(e, t + 12, c), Vr(e, t + 14, d), t += 16, o != null && (Vr(e, t, u), Vr(e, t + 6, n.attrs), Vr(e, t + 10, o), t += 14), e.set(r, t), t += c, d) for (var m in l) {
		var h = l[m], g = h.length;
		Vr(e, t, +m), Vr(e, t + 2, g), e.set(h, t + 4), t += 4 + g;
	}
	return u && (e.set(s, t), t += u), t;
}, Xr = function(e, t, n, r, i) {
	Vr(e, t, 101010256), Vr(e, t + 8, n), Vr(e, t + 10, n), Vr(e, t + 12, r), Vr(e, t + 16, i);
};
function Zr(e, t) {
	t ||= {};
	var n = {}, r = [];
	Wr(e, "", n, t);
	var i = 0, a = 0;
	for (var o in n) {
		var s = n[o], c = s[0], l = s[1], u = l.level == 0 ? 0 : 8, d = qr(o), f = d.length, p = l.comment, m = p && qr(p), h = m && m.length, g = Jr(l.extra);
		f > 65535 && wr(11);
		var _ = u ? Hr(c, l) : c, v = _.length, y = Rr();
		y.p(c), r.push(Br(l, {
			size: c.length,
			crc: y.d(),
			c: _,
			f: d,
			m,
			u: f != o.length || m && p.length != h,
			o: i,
			compression: u
		})), i += 30 + f + g + v, a += 76 + 2 * (f + g) + (h || 0) + v;
	}
	for (var b = new Yn(a + 22), x = i, S = a - i, C = 0; C < r.length; ++C) {
		var d = r[C];
		Yr(b, d.o, d, d.f, d.u, d.c.length);
		var w = 30 + d.f.length + Jr(d.extra);
		b.set(d.c, d.o + w), Yr(b, i, d, d.f, d.u, d.c.length, d.o, d.m), i += 16 + w + (d.m ? d.m.length : 0);
	}
	return Xr(b, i, r.length, S, x), b;
}
//#endregion
//#region src/storage/sharedArrayJson.ts
function Qr() {
	let e = 67108864, t = /* @__PURE__ */ new WeakMap(), n = 0, r = 0, i = /* @__PURE__ */ new Map(), a = (a) => {
		let s = a[0], c = i.get(s);
		if (c && c.values.length === a.length && a.every((e, t) => e === c.values[t])) return i.delete(s), i.set(s, c), c.bytes;
		let l = E(a).slice(1, -1);
		if (l.byteLength <= e) {
			for (c && (i.delete(s), n -= c.bytes.byteLength), n + l.byteLength > e && r && (t = /* @__PURE__ */ new WeakMap(), n -= o, o = 0, r = 0); i.size && (n + l.byteLength > e || i.size >= 16384);) {
				let e = i.keys().next().value;
				n -= i.get(e).bytes.byteLength, i.delete(e);
			}
			i.set(s, {
				values: a,
				bytes: l
			}), n += l.byteLength;
		}
		return l;
	}, o = 0, c = new TextEncoder();
	return (l) => {
		if (!s(l)) return E(l);
		let u = [], d = (e) => u.push(c.encode(e)), f = (s) => {
			if (!s || typeof s != "object") {
				d(h(s));
				return;
			}
			if (Array.isArray(s)) {
				if (s.length >= 64) {
					if (s.every((e) => typeof e == "object" && !!e)) {
						d("[");
						for (let e = 0; e < s.length; e += 64) e && d(","), u.push(a(s.slice(e, e + 64)));
						d("]");
						return;
					}
					let c = t.get(s);
					if (!c && (c = E(s), c.byteLength <= e)) {
						if (n + c.byteLength > e || r + 1 > 128) for (t = /* @__PURE__ */ new WeakMap(), n -= o, o = 0, r = 0; i.size && n + c.byteLength > e;) {
							let e = i.keys().next().value;
							n -= i.get(e).bytes.byteLength, i.delete(e);
						}
						t.set(s, c), n += c.byteLength, o += c.byteLength, r++;
					}
					u.push(c);
					return;
				}
				d("["), s.forEach((e, t) => {
					t && d(","), f(e);
				}), d("]");
				return;
			}
			let c = s;
			d("{"), Object.keys(c).filter((e) => c[e] !== void 0).sort().forEach((e, t) => {
				t && d(","), d(JSON.stringify(e)), d(":"), f(c[e]);
			}), d("}");
		};
		f(l);
		let p = new Uint8Array(u.reduce((e, t) => e + t.byteLength, 0)), m = 0;
		for (let e of u) p.set(e, m), m += e.byteLength;
		return p;
	};
}
//#endregion
//#region src/storage/immutableCommandHash.ts
var $r = Object.getOwnPropertyDescriptor, ei = Object.getPrototypeOf, ti = Object.prototype, ni = Array.prototype, ri = Number.prototype, ii = String.prototype, ai = Function.prototype.toString, oi = () => [
	JSON.stringify,
	Object.keys,
	Object.getOwnPropertyDescriptors,
	Object.getOwnPropertyDescriptor,
	Object.getPrototypeOf,
	Object.hasOwn,
	Object.isFrozen,
	Reflect.ownKeys,
	Array.isArray,
	Array.prototype.every,
	Array.prototype.forEach,
	Array.prototype.filter,
	Array.prototype.sort,
	Array.prototype.slice,
	Array.prototype.map,
	Array.prototype.join,
	Array.prototype.push,
	TextEncoder,
	TextEncoder.prototype.encode,
	Uint8Array,
	Uint8Array.prototype.set,
	Uint8Array.prototype.slice,
	Uint8Array.prototype[Symbol.iterator],
	Number.isFinite,
	Number.prototype.toString,
	String.prototype.charCodeAt,
	String.prototype.padStart,
	crypto.subtle,
	crypto.subtle.digest,
	Map.prototype.get,
	Map.prototype.set,
	Map.prototype.has,
	Map.prototype.delete,
	Map.prototype.keys,
	WeakMap.prototype.get,
	WeakMap.prototype.set,
	WeakSet.prototype.has,
	WeakSet.prototype.add
], si = oi();
function ci() {
	let e = oi();
	if (e.length !== si.length) return !1;
	for (let t = 0; t < e.length; t++) if (e[t] !== si[t]) return !1;
	return /\[native code\]/.test(ai.call(JSON.stringify)) && ei(ti) === null && ei(ni) === ti && $r(ti, "toJSON") === void 0 && $r(ni, "toJSON") === void 0 && $r(ri, "toJSON") === void 0 && $r(ii, "toJSON") === void 0;
}
function li() {
	let e = /* @__PURE__ */ new WeakMap(), t = 0, n = Qr(), r = () => {
		e = /* @__PURE__ */ new WeakMap(), t = 0, n = Qr();
	};
	return async (i) => {
		let a = ci() && s(i);
		a || r();
		let o = a ? e.get(i) : void 0;
		if (o !== void 0) return o;
		let c = await A(n(i));
		return a && ci() ? (t >= 4096 && (e = /* @__PURE__ */ new WeakMap(), t = 0), e.set(i, c), t++) : r(), c;
	};
}
//#endregion
//#region src/storage/recovery.ts
function ui(e) {
	return e?.pending.flatMap((e) => [e.command.before, e.command.after].map((e) => ({
		...e,
		history: []
	}))) ?? [];
}
function di(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return (t === Object.prototype || t === null) && Reflect.ownKeys(e).every((t) => "value" in Object.getOwnPropertyDescriptor(e, t));
}
function fi(e) {
	if (!Array.isArray(e) || Object.getPrototypeOf(e) !== Array.prototype || Object.getOwnPropertySymbols(e).length || Object.getOwnPropertyNames(e).length !== e.length + 1) return !1;
	for (let t = 0; t < e.length; t++) {
		let n = Object.getOwnPropertyDescriptor(e, String(t));
		if (!n || !("value" in n)) return !1;
	}
	return !0;
}
function pi(e, t) {
	if (!t || !di(e) || !di(t)) return !1;
	let n = Object.getOwnPropertyDescriptor(e, "history")?.value, r = Object.getOwnPropertyDescriptor(t, "pending")?.value;
	return fi(n) && fi(r) && n.every((e) => di(e) && Object.hasOwn(e, "operationId")) && r.every((e) => di(e) && Object.hasOwn(e, "operationId") && Object.hasOwn(e, "command"));
}
function mi() {
	let t = !1, n = /* @__PURE__ */ new WeakSet(), r = /* @__PURE__ */ new WeakMap(), i = /* @__PURE__ */ new WeakMap(), a = 0, o = 0;
	function s(t, i) {
		if (t === null || typeof t == "boolean") return !0;
		if (typeof t == "string") {
			if (!e(t)) throw new z("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return !0;
		}
		if (typeof t == "number") {
			if (!Number.isFinite(t)) throw new z("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return !0;
		}
		if (typeof t != "object") throw new z("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (i.has(t)) throw new z("VALIDATION_FAILED", "循環したJSONは保存できません。");
		if (n.has(t)) return !0;
		if (Array.isArray(t) ? !fi(t) : !di(t)) return !1;
		i.add(t);
		try {
			if (Array.isArray(t)) {
				for (let e = 0; e < t.length; e++) if (!s(t[e], i)) return !1;
			} else {
				let e = t, n = Object.keys(e).filter((t) => e[t] !== void 0).sort();
				for (let t of n) if (!s(e[t], i)) return !1;
				r.set(t, n);
			}
			return n.add(t), !0;
		} finally {
			i.delete(t);
		}
	}
	function c(e, t) {
		if (e === t) return !0;
		if (e === null || t === null || typeof e != "object" || typeof t != "object" || Array.isArray(e) !== Array.isArray(t)) return !1;
		if (i.get(e)?.has(t)) return !0;
		if (Array.isArray(e)) {
			let n = t;
			if (e.length !== n.length) return !1;
			for (let t = 0; t < e.length; t++) if (!c(e[t], n[t])) return !1;
		} else {
			let n = r.get(e), i = r.get(t);
			if (n.length !== i.length) return !1;
			for (let r = 0; r < n.length; r++) {
				let a = n[r];
				if (a !== i[r] || !c(e[a], t[a])) return !1;
			}
		}
		let n = Array.isArray(e);
		if (n ? e.length >= 32 && o < 128 : Object.hasOwn(e, "id") && Object.hasOwn(e, "projectId") && a < 65408) {
			let r = i.get(e);
			r || (r = /* @__PURE__ */ new WeakSet(), i.set(e, r)), r.add(t), n ? o++ : a++;
		}
		return !0;
	}
	return (e, l) => t ? g(e, l) : !s(e, /* @__PURE__ */ new Set()) || !s(l, /* @__PURE__ */ new Set()) ? (t = !0, n = /* @__PURE__ */ new WeakSet(), r = /* @__PURE__ */ new WeakMap(), i = /* @__PURE__ */ new WeakMap(), a = 0, o = 0, g(e, l)) : c(e, l);
}
function hi(e, t) {
	let n = pi(e, t) ? mi() : g, r = new Map(e.history.map((e) => [e.operationId, e]));
	for (let e of t?.pending ?? []) {
		let t = r.get(e.operationId);
		if (t && !n(t, e.command)) throw new z("OPERATION_CONFLICT", "送信待ちの内容が保存履歴と一致しません。", e.operationId);
		r.set(e.operationId, e.command);
	}
	return {
		...e,
		history: [...r.values()]
	};
}
function gi(e) {
	return _i(e, li());
}
function _i(e, t) {
	let n = vn({ worldSnapshots: e });
	return {
		...n,
		recovery: (r, i, a) => yi(r, i, e, a, n, !1, t),
		recoveryForInspection: (r, i, a) => yi(r, i, e, a, n, !0, t)
	};
}
async function vi(e, t, n, r) {
	return yi(e, t, n, r);
}
async function yi(e, n, r, i, a, o = !1, s) {
	let c = (e, t = "data/recovery.json") => {
		throw new z("VALIDATION_FAILED", e, t);
	};
	if (!e || typeof e != "object" || Array.isArray(e)) return c("送信待ち復元情報はオブジェクトです。");
	let l = e;
	if (Object.keys(l).some((e) => ![
		"version",
		"projectId",
		"sourceRevision",
		"serverRevision",
		"pending"
	].includes(e)) || l.version !== 1 || l.projectId !== n.projectId || l.sourceRevision !== n.revision || typeof l.serverRevision != "string" || !/^(0|[1-9]\d*)$/.test(l.serverRevision) || !Array.isArray(l.pending) || l.pending.length > 1e5) return c("送信待ち復元情報の版・作品・基底版・件数が不正です。");
	let u = t(e), d = u.captured ? u.value : structuredClone(e), f = /* @__PURE__ */ new Set(), p = Qr(), m = a ?? vn({ worldSnapshots: r });
	for (let e of d.pending) {
		if (B(i), !e || typeof e != "object" || Object.keys(e).some((e) => ![
			"operationId",
			"command",
			"commandHash",
			"origin"
		].includes(e)) || !M.test(e.operationId) || f.has(e.operationId) || typeof e.commandHash != "string" || !/^[0-9a-f]{64}$/.test(e.commandHash)) return c("送信待ちの操作IDまたはhashが不正・重複しています。");
		if ("origin" in e && (!e.origin || typeof e.origin != "object" || Array.isArray(e.origin) || Object.keys(e.origin).some((e) => ![
			"projectId",
			"operationId",
			"serverRevision"
		].includes(e)) || !M.test(e.origin.projectId) || !M.test(e.origin.operationId) || !/^(0|[1-9]\d*)$/.test(e.origin.serverRevision))) return c("送信待ちの元操作の記録が不正です。");
		if (f.add(e.operationId), !e.command || e.command.operationId !== e.operationId || e.command.projectId !== n.projectId || (s ? await s(e.command) : await A(p(e.command))) !== e.commandHash) return c("送信待ち操作の内容が固定したhashと一致しません。");
		let t = {
			...e.command.after,
			history: [e.command]
		}, r = m.validate(t);
		if (!r.ok) return c(r.issues.map((e) => `${e.path}: ${e.message}`).join("\n"));
		for (let t of ui({
			...d,
			pending: [e]
		})) {
			let e = await m.integrity(t, !1);
			if (e.length) return c(e.map((e) => e.message).join("\n"));
		}
	}
	return hi(n, d), o ? d : structuredClone(d);
}
//#endregion
//#region src/domain/production.ts
function bi(e) {
	return typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? "[" + e.map(bi).join(",") + "]" : "{" + Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e < t ? -1 : +(e > t)).map(([e, t]) => JSON.stringify(e) + ":" + bi(t)).join(",") + "}";
}
async function xi(e, t) {
	let n = (t.data.cueIds ?? []).map((t) => e.entities.find((e) => e.id === t && e.kind === "cue" && !e.deletedAt));
	if (n.some((e) => !e)) throw Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
	let r = {
		text: t.data.text.map((e) => ({
			kind: e.kind,
			text: e.text,
			ruby: e.ruby ?? []
		})),
		speakerId: t.data.speakerId ?? null,
		cues: n.map((e) => e.data)
	}, i = new TextEncoder().encode(bi(r));
	return [...new Uint8Array(await crypto.subtle.digest("SHA-256", i))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
async function Si(e, t) {
	let n = new Map(e.entities.map((e) => [e.id, e])), r = new Map(t.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	for (let [e, t] of r) {
		let r = n.get(e);
		r !== t && (!r || !!r.deletedAt != !!t.deletedAt || bi(r.data) !== bi(t.data)) && a.add(e);
	}
	for (let e of n.keys()) r.has(e) || a.add(e);
	let o = (e, t) => bi({
		text: e.data.text.map((e) => ({
			kind: e.kind,
			text: e.text,
			ruby: e.ruby ?? []
		})),
		speakerId: e.data.speakerId ?? null,
		cues: (e.data.cueIds ?? []).map((e) => {
			let n = t.get(e);
			if (!n || n.kind !== "cue" || n.deletedAt) throw Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
			return n.data;
		})
	});
	for (let e of t.entities) {
		if (e.kind !== "dialogue_line" || e.deletedAt) continue;
		let t = n.get(e.id);
		(!t || t.kind !== "dialogue_line" || t.deletedAt || ["rejected", "alternate"].includes(t.status) !== ["rejected", "alternate"].includes(e.status) || (a.has(e.id) || (e.data.cueIds ?? []).some((e) => a.has(e))) && o(t, n) !== o(e, r)) && i.add(e.id);
	}
	for (let t of e.entities) if (t.kind === "dialogue_line" && !t.deletedAt) {
		let e = r.get(t.id);
		(!e || e.deletedAt || e.kind !== "dialogue_line") && i.add(t.id);
	}
	let s = /* @__PURE__ */ new Set();
	for (let e of t.entities) if (!e.deletedAt && (e.kind === "localization" || e.kind === "recording") && ["reviewed", "recorded"].includes(e.data.stage ?? "") && !i.has(e.data.sourceLineId) && a.has(e.id)) {
		let n = r.get(e.data.sourceLineId);
		(!n || n.kind !== "dialogue_line" || n.deletedAt || ["rejected", "alternate"].includes(n.status) || e.data.sourceHash !== await xi(t, n)) && s.add(e.id);
	}
	if (!a.size && !i.size && !s.size) return t;
	let c = t.entities.map((e) => e.deletedAt ? e : (e.kind === "localization" || e.kind === "recording") && (i.has(e.data.sourceLineId) || s.has(e.id)) && e.data.stage !== "needs_review" ? {
		...e,
		data: {
			...e.data,
			stage: "needs_review"
		}
	} : e.kind === "media_variant" && (e.data.sourceIds ?? []).some((e) => a.has(e)) && !e.data.needsReview ? {
		...e,
		data: {
			...e.data,
			needsReview: !0
		}
	} : e), l = (e, n) => {
		let r = e;
		for (let i of n.split(/[.\[\]]+/).filter(Boolean)) if (r && typeof r == "object") {
			let n = r, a = n.sourceVersionId ?? n.targetSnapshotId ?? (e.kind === "trace" || e.kind === "checkpoint" ? n.contentVersionId : void 0);
			if (typeof a == "string" && a !== t.projectId) return !1;
			r = n[i];
		} else return !0;
		return !0;
	}, u = /* @__PURE__ */ new Map();
	for (let e of c) if (!e.deletedAt && !["rejected", "alternate"].includes(e.status)) {
		for (let t of N(e)) if (!t.path.startsWith("data.lineage") && !t.path.startsWith("data.originLineIds") && l(e, t.path)) {
			let n = u.get(t.id);
			n ? n.push(e.id) : u.set(t.id, [e.id]);
		}
	}
	let d = new Set(a), f = /* @__PURE__ */ new Set(), p = [...d];
	for (let e = 0; e < p.length; e++) for (let t of u.get(p[e]) ?? []) f.add(t), d.has(t) || (d.add(t), p.push(t));
	return {
		...t,
		entities: c.map((e) => !d.has(e.id) || e.deletedAt || ["rejected", "alternate"].includes(e.status) ? e : e.kind === "storyboard_frame" && n.has(e.id) ? {
			...e,
			status: "needs_review"
		} : e.kind === "media_variant" && n.has(e.id) ? {
			...e,
			data: {
				...e.data,
				needsReview: !0
			}
		} : e.kind === "production_task" && n.has(e.id) && f.has(e.id) && e.data.progress === "done" ? {
			...e,
			data: {
				...e.data,
				progress: "needs_review"
			}
		} : e)
	};
}
//#endregion
//#region src/storage/importMapping.ts
var Ci = /* @__PURE__ */ "id.kind.text.audienceHolderIds.eventKey.x.y.instanceId.quantity.consumed.sourceVersionId.profileId.publicVersionId.mode.publicId.ownerId.projectId.entities.relations.views.authorAlternatives.snapshots.history.operationId.deletionOperationId.data.versions.applyReceipts.baseContent.content.before.after.pending.command".split("."), wi = Object.getOwnPropertyDescriptor, Ti = Object.getPrototypeOf, Ei = Object.hasOwn, Di = wi(Array.prototype, "forEach"), Oi = wi(Array.prototype, Symbol.iterator), ki = wi(Array.prototype, "map"), Ai = wi(Array.prototype, "every"), ji = wi(Object, "entries"), Mi = wi(Object, "values"), Ni = wi(Object, "hasOwn"), Pi = wi(Object, "getPrototypeOf"), Fi = wi(Array, "isArray"), Ii = wi(Reflect, "ownKeys"), Li = Map, Ri = Map.prototype, zi = wi(Map.prototype, "has"), Bi = wi(Map.prototype, "get"), Vi = wi(Map.prototype, "set"), Hi = wi(Map.prototype, "values"), Ui = Set, Wi = Set.prototype, Gi = wi(Set.prototype, "add"), Ki = WeakMap, qi = WeakMap.prototype, Ji = wi(WeakMap.prototype, "get"), Yi = wi(WeakMap.prototype, "set"), Xi = Ti((/* @__PURE__ */ new Map()).values()), Zi = wi(Xi, "next"), Qi = Ti(Xi), $i = wi(Qi, Symbol.iterator), ea = 1e5;
function ta(e, t, n) {
	let r = wi(e, t);
	return !!n && Ei(n, "value") && typeof n.value == "function" && !!r && Ei(r, "value") && r.value === n.value && r.enumerable === n.enumerable && r.configurable === n.configurable && r.writable === n.writable;
}
function na() {
	for (let e = 0; e < Ci.length; e++) {
		let t = Ci[e];
		if (wi(Object.prototype, t) !== void 0 || wi(Array.prototype, t) !== void 0) return !1;
	}
	return wi(Object.prototype, Symbol.iterator) !== void 0 || Map !== Li || Map.prototype !== Ri || Set !== Ui || Set.prototype !== Wi || WeakMap !== Ki || WeakMap.prototype !== qi || Ti(Object.prototype) !== null || Ti(Array.prototype) !== Object.prototype || Ti(Ri) !== Object.prototype || Ti(Wi) !== Object.prototype || Ti(qi) !== Object.prototype || Ti(Qi) !== Object.prototype ? !1 : ta(Array.prototype, "forEach", Di) && ta(Array.prototype, Symbol.iterator, Oi) && ta(Array.prototype, "map", ki) && ta(Array.prototype, "every", Ai) && ta(Object, "entries", ji) && ta(Object, "values", Mi) && ta(Object, "hasOwn", Ni) && ta(Object, "getPrototypeOf", Pi) && ta(Array, "isArray", Fi) && ta(Reflect, "ownKeys", Ii) && ta(Ri, "has", zi) && ta(Ri, "get", Bi) && ta(Ri, "set", Vi) && ta(Ri, "values", Hi) && ta(Wi, "add", Gi) && ta(qi, "get", Ji) && ta(qi, "set", Yi) && ta(Xi, "next", Zi) && wi(Xi, Symbol.iterator) === void 0 && Ti(Xi) === Qi && ta(Qi, Symbol.iterator, $i);
}
function ra(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = [], a = /* @__PURE__ */ new Set(), o, c = 0, l = !1;
	if (t) try {
		l = na() && s(e), l && (o = /* @__PURE__ */ new WeakMap());
	} catch {
		l = !1, o = void 0;
	}
	let u = (e, t, r) => {
		let i = n.get(e);
		if (i && (i.role !== t || i.ownerId !== r)) throw new z("IMPORT_CONFLICT", "同じIDが別の種別・所有者で使われています。", e);
		n.set(e, {
			id: e,
			role: t,
			...r ? { ownerId: r } : {}
		});
	}, d = (e, t, n = !1) => {
		if (Array.isArray(e)) {
			e.forEach((e) => d(e, t, n));
			return;
		}
		if (!e || typeof e != "object") return;
		let o = e;
		if (typeof o.id == "string") {
			let e = "kind" in o && "text" in o ? "block" : "audienceHolderIds" in o ? "alias" : "eventKey" in o ? "trigger" : "x" in o && "y" in o ? "map_pin" : (() => {
				throw new z("IMPORT_CONFLICT", "未対応の埋込IDです。", o.id);
			})();
			n && e === "block" ? i.push({
				id: o.id,
				ownerId: t
			}) : u(o.id, e, t);
		}
		typeof o.instanceId == "string" && "quantity" in o && "consumed" in o && a.add(o.instanceId), typeof o.sourceVersionId == "string" && typeof o.profileId == "string" && typeof o.publicVersionId == "string" && u(o.publicVersionId, "public_id"), o.mode === "anonymize" && typeof o.publicId == "string" && u(o.publicId, "public_id");
		for (let [e, i] of Object.entries(o)) {
			if (e === "publicIds" && i && typeof i == "object") for (let e of Object.values(i)) typeof e == "string" && u(e, "public_id");
			if (e === "bindings" && i && typeof i == "object" && !Array.isArray(i)) for (let e of Object.values(i)) typeof e == "string" && r.push({
				id: e,
				ownerId: t
			});
			d(i, t, n || k(e));
		}
	}, f = (e, t) => {
		if (!l || !o || !e || typeof e != "object" || typeof t != "string" || !M.test(t)) {
			d(e, t);
			return;
		}
		let n = o.get(e);
		if (n !== void 0) {
			if (n === t) return;
			d(e, t);
			return;
		}
		if (c >= ea) {
			d(e, t);
			return;
		}
		d(e, t), o.set(e, t), c++;
	}, p = (e) => {
		u(e.projectId, "project");
		for (let t of e.entities) u(t.id, t.kind === "snapshot" ? "snapshot" : `entity:${t.kind}`), t.deletionOperationId && u(t.deletionOperationId, "operation"), f(t.data, t.id);
		for (let t of e.relations) u(t.id, "relation"), t.deletionOperationId && u(t.deletionOperationId, "operation");
		for (let t of e.views) u(t.id, "view");
		if ("authorAlternatives" in e && Array.isArray(e.authorAlternatives)) for (let t of e.authorAlternatives) {
			u(t.id, "alternative", t.projectId);
			for (let e of t.versions) u(e.id, "alternative_version", t.id);
			for (let e of t.applyReceipts) u(e.id, "alternative_receipt", t.id);
			p(t.baseContent);
			for (let e of t.versions) p(e.content);
		}
		if ("snapshots" in e) for (let t of e.snapshots) u(t.id, "snapshot"), p(t.content);
	};
	p(e);
	for (let t of e.history) u(t.operationId, "operation"), p(t.before), p(t.after);
	let m = new Set([...n.values()].filter((e) => e.role === "block").map((e) => e.id));
	for (let e of i) m.has(e.id) || u(e.id, "block", e.ownerId);
	for (let e of a) n.get(e)?.role !== "entity:item" && u(e, "runtime_item");
	for (let e of r) n.has(e.id) || u(e.id, "reuse_binding", e.ownerId);
	return [...n.values()];
}
function ia(e) {
	return ra(e, !1);
}
function aa() {
	if (na()) return (e) => ra(e, !0);
}
function oa(e) {
	return Object.assign(new z("VALIDATION_FAILED", e.map((e) => `${e.path}: ${e.message}`).join("\n"), e[0]?.path), { issues: e });
}
function sa(e, t, n) {
	if (e.projectId === t.projectId) throw new z("IMPORT_CONFLICT", "同じ作品はIDを維持して統合してください。");
	let r = new Map(ia(e).map((e) => [e.id, e])), i = new Map(ia(t).map((e) => [e.id, e])), a = {}, o = /* @__PURE__ */ new Set();
	for (let e of Object.keys(n)) if (!r.has(e)) throw new z("IMPORT_CONFLICT", "対応表に作品外・未知のIDがあります。固定世界のIDは変更できません。", e);
	for (let [e, t] of r) {
		let r = Object.hasOwn(n, e) ? n[e] : void 0;
		if (!r || !M.test(r)) throw new z("IMPORT_CONFLICT", "全ローカルIDの明示対応が必要です。", e);
		if (o.has(r)) throw new z("IMPORT_CONFLICT", "複数の元IDを同じIDへ統合できません。対応を一対一にしてください。", e);
		o.add(r), a[e] = r;
		let s = i.get(r);
		if (s && s.role !== t.role) throw new z("IMPORT_CONFLICT", "対応先の種別が異なります。", e);
		if (s && (t.role === "operation" || t.role === "snapshot")) throw new z(t.role === "snapshot" ? "IMMUTABLE_SNAPSHOT" : "OPERATION_CONFLICT", "復元履歴・不変版は既存IDを上書きできません。新しい対応IDを選んでください。", e);
	}
	if (a[e.projectId] !== t.projectId) throw new z("IMPORT_CONFLICT", "元projectIdの対応先を対象作品にしてください。", e.projectId);
	for (let [e, t] of r) {
		let n = i.get(a[e]);
		if (t.ownerId && n?.ownerId && a[t.ownerId] !== n.ownerId) throw new z("IMPORT_CONFLICT", "段落・別名などの対応先が対応した所有者に属していません。", e);
	}
	return a;
}
function ca(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => ca(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	if (typeof n.id == "string" && (n.id = t[n.id] ?? n.id), typeof n.instanceId == "string" && "quantity" in n && "consumed" in n && (n.instanceId = t[n.instanceId] ?? n.instanceId), n.mode === "anonymize" && typeof n.publicId == "string" && (n.publicId = t[n.publicId] ?? n.publicId), n.publicIds && typeof n.publicIds == "object") for (let [e, r] of Object.entries(n.publicIds)) typeof r == "string" && (n.publicIds[e] = t[r] ?? r);
	Array.isArray(n.onceTriggers) && (n.onceTriggers = n.onceTriggers.map((e) => typeof e == "string" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, (e) => t[e] ?? e) : e));
	for (let e of Object.values(n)) ca(e, t);
}
function la(e, t) {
	let n = fe(e, t);
	for (let t of N(e)) if (t.scope === "identity" || t.scope === "calendar") {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean), r = e.pop();
		if (r === "$key") throw new z("IMPORT_CONFLICT", "外部参照をkeyにした未知の辞書は対応表で変換できません。", t.path);
		let i = n;
		for (let t of e) i = i[t];
		i[r] = t.id;
	}
	return n;
}
function ua(e, t, n = "", r) {
	let i = (e) => t[e] ?? e;
	if (typeof e == "string") return n === "onceTriggers" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, i) : n === "id" || n === "operationId" || /(?:Id|Ids)$/.test(n) || n === "value" && r?.type === "ref" ? i(e) : e;
	if (Array.isArray(e)) return e.map((e) => ua(e, t, n, r));
	if (!e || typeof e != "object") return e;
	let a = e;
	if ("kind" in a && "data" in a && "projectId" in a) {
		let e = la(a, t);
		return ca(e.data, t), e;
	}
	if ("relationType" in a && "fromId" in a && "toId" in a) return me(a, t);
	let o = [
		"variableValues",
		"visitCounts",
		"publicTexts",
		"publicIds",
		"byEntityId"
	].includes(n);
	return Object.fromEntries(Object.entries(a).map(([e, n]) => [o ? i(e) : e, ua(n, t, e, a)]));
}
function da(e, t) {
	return t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
}
function fa(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	if (t.length) {
		let e = t[t.length - 1];
		n === void 0 ? delete i[e] : i[e] = structuredClone(n);
	}
	return r;
}
function pa(e, t, n, r, i) {
	if (t.scope === "presentation" && e && typeof e == "object" && !Array.isArray(e)) {
		let t = structuredClone(e), n = (e) => typeof e == "string" ? i[e] ?? e : e;
		return Array.isArray(t.chapterOrder) && (t.chapterOrder = t.chapterOrder.map(n)), Array.isArray(t.chapters) && (t.chapters = t.chapters.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = e;
			return {
				...t,
				id: n(t.id),
				sceneIds: Array.isArray(t.sceneIds) ? t.sceneIds.map(n) : t.sceneIds
			};
		})), Array.isArray(t.scenes) && (t.scenes = t.scenes.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = e;
			return {
				...t,
				id: n(t.id),
				chapterId: n(t.chapterId)
			};
		})), t;
	}
	if (t.scope === "entity" && t.itemId) {
		let a = r.entities.find((e) => e.id === t.itemId) ?? n.baseContent.entities.find((e) => e.id === t.itemId);
		if (t.path.length === 0 && e && typeof e == "object" && "kind" in e && "data" in e) {
			let t = la(e, i);
			return ca(t.data, i), t;
		}
		if (a && t.path.length) {
			let n = la(fa(a, t.path, e), i);
			return ca(n.data, i), da(n, t.path);
		}
	}
	if (t.scope === "relation" && t.itemId) {
		let a = r.relations.find((e) => e.id === t.itemId) ?? n.baseContent.relations.find((e) => e.id === t.itemId);
		if (t.path.length === 0 && e && typeof e == "object" && "relationType" in e) return me(e, i);
		if (a && t.path.length) return da(me(fa(a, t.path, e), i), t.path);
	}
	return t.scope === "project" && t.path[0] === "worldReferences" ? structuredClone(e) : t.scope === "project" && t.path.length === 1 && t.path[0] === "calendarId" && typeof e == "string" ? i[e] ?? e : t.scope === "project" && t.path.length === 1 && t.path[0] === "calendars" && Array.isArray(e) ? e.map((e) => e && typeof e == "object" ? {
		...e,
		id: typeof e.id == "string" ? i[e.id] ?? e.id : e.id
	} : e) : ua(e, i, t.path.at(-1) ?? "");
}
function ma(e, t) {
	return {
		...structuredClone(e),
		chapterId: t(e.chapterId),
		templateId: t(e.templateId),
		assignments: Object.fromEntries(Object.entries(e.assignments).map(([e, n]) => [e, t(n)]))
	};
}
async function ha(e, t, n, r) {
	let i = (e) => n[e] ?? e, a = async (t) => {
		B(r);
		let o = structuredClone(t);
		o.projectId = i(t.projectId), o.entities = t.entities.map((e) => {
			let t = la(e, n);
			return t.id = i(e.id), t.projectId = i(e.projectId), ca(t.data, n), t.deletionOperationId &&= i(t.deletionOperationId), t;
		}), o.relations = t.relations.map((e) => ({
			...me(e, n),
			id: i(e.id),
			projectId: i(e.projectId),
			...e.deletionOperationId ? { deletionOperationId: i(e.deletionOperationId) } : {}
		})), o.views = t.views.map((e) => ({
			...structuredClone(e),
			id: i(e.id),
			entityIds: e.entityIds.map(i)
		}));
		for (let n = 0; n < t.entities.length; n++) {
			let r = t.entities[n], i = o.entities[n];
			if ((r.kind === "localization" || r.kind === "recording") && (i.kind === "localization" || i.kind === "recording")) {
				let n = t.entities.find((e) => e.kind === "dialogue_line" && e.id === r.data.sourceLineId), a = o.entities.find((e) => e.kind === "dialogue_line" && e.id === i.data.sourceLineId);
				n && a && r.data.sourceHash === await xi({
					...e,
					...t
				}, n) && (i.data.sourceHash = await xi({
					...e,
					...o
				}, a));
			}
		}
		let s = "authorAlternatives" in t ? t.authorAlternatives : void 0;
		return Array.isArray(s) && (o.authorAlternatives = await Promise.all(s.map(async (e) => {
			let t = structuredClone(e);
			return t.id = i(e.id), t.projectId = i(e.projectId), t.sourceSnapshotId = e.sourceSnapshotId ? i(e.sourceSnapshotId) : null, t.baseContent = await a(e.baseContent), t.versions = await Promise.all(e.versions.map(async (e) => ({
				...structuredClone(e),
				id: i(e.id),
				parentVersionId: e.parentVersionId ? i(e.parentVersionId) : null,
				content: await a(e.content),
				...e.structurePlan ? { structurePlan: ma(e.structurePlan, i) } : {}
			}))), t.headVersionId = i(e.headVersionId), t.applyReceipts = e.applyReceipts.map((t) => {
				let r = e.versions.find((e) => e.id === t.alternativeVersionId)?.content ?? e.baseContent, a = t.patches.map((t) => {
					let a = t.itemId ? i(t.itemId) : void 0, o = [...t.path], s = [
						t.scope,
						a ?? "",
						...o
					].map((e) => encodeURIComponent(e)).join(":");
					return {
						...structuredClone(t),
						key: s,
						...a ? { itemId: a } : {},
						path: o,
						before: {
							...structuredClone(t.before),
							...t.before.present ? { value: pa(t.before.value, t, e, r, n) } : {}
						},
						after: {
							...structuredClone(t.after),
							...t.after.present ? { value: pa(t.after.value, t, e, r, n) } : {}
						}
					};
				});
				return {
					...structuredClone(t),
					id: i(t.id),
					alternativeVersionId: t.alternativeVersionId ? i(t.alternativeVersionId) : void 0,
					sourceSnapshotId: t.sourceSnapshotId ? i(t.sourceSnapshotId) : null,
					patches: a,
					selectedChangeKeys: a.map((e) => e.key).sort()
				};
			}), t;
		}))), "snapshots" in o && "snapshots" in t && (o.snapshots = await Promise.all(t.snapshots.map(async (e) => ({
			...structuredClone(e),
			id: i(e.id),
			content: await a(e.content)
		})))), o;
	}, { history: o, ...s } = e, c = {
		...await a(s),
		history: await Promise.all(e.history.map(async (e) => ({
			...structuredClone(e),
			operationId: i(e.operationId),
			projectId: i(e.projectId),
			targetIds: e.targetIds.map(i),
			before: await a(e.before),
			after: await a(e.after),
			...e.compensatesOperationId ? { compensatesOperationId: i(e.compensatesOperationId) } : {},
			...e.importOrigin ? { importOrigin: {
				...e.importOrigin,
				importOperationId: i(e.importOrigin.importOperationId)
			} } : {},
			...e.idMap ? { idMap: Object.fromEntries(Object.entries(e.idMap).map(([e, t]) => [e, i(t)])) } : {}
		})))
	}, l = /* @__PURE__ */ new Map(), u = (e) => {
		let t = (n) => {
			if (e(n), "snapshots" in n) for (let e of n.snapshots) t(e.content);
			if ("authorAlternatives" in n && Array.isArray(n.authorAlternatives)) for (let e of n.authorAlternatives) {
				t(e.baseContent);
				for (let n of e.versions) t(n.content);
			}
		};
		t(c);
		for (let e of c.history) t(e.before), t(e.after);
	};
	u((e) => {
		if ("snapshots" in e) for (let t of e.snapshots) l.set(t.id, t);
	});
	let d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Set(), p = async (e) => {
		if (d.has(e.id)) return d.get(e.id);
		if (f.has(e.id)) throw new z("HASH_MISMATCH", "版の内容hashに循環参照があります。", e.id);
		f.add(e.id);
		for (let t of e.content.entities) t.kind === "snapshot" && l.has(t.id) && (t.data.contentHash = await p(l.get(t.id)));
		let t = await A(E(e.content));
		return d.set(e.id, t), f.delete(e.id), t;
	};
	for (let e of l.values()) await p(e);
	u((e) => {
		for (let t of e.entities) t.kind === "snapshot" && d.has(t.id) && (t.data.contentHash = d.get(t.id));
		if ("snapshots" in e) for (let t of e.snapshots) {
			t.contentHash = d.get(t.id);
			for (let e of t.content.entities) e.kind === "snapshot" && d.has(e.id) && (e.data.contentHash = d.get(e.id));
		}
	});
	let m = async (e) => {
		"authorAlternatives" in e && Array.isArray(e.authorAlternatives) && (e.authorAlternatives = await Promise.all(e.authorAlternatives.map($t)));
	};
	for (let e of [c, ...c.history.flatMap((e) => [e.before, e.after])]) await m(e);
	let h = new Map(t.entities.map((e) => [e.id, e]));
	return c.entities = c.entities.map((e) => h.has(e.id) ? {
		...e,
		createdAt: h.get(e.id).createdAt
	} : e), c;
}
var ga = [
	"name",
	"calendarId",
	"mainStart",
	"calendars",
	"worldReferences"
];
function _a(e, t, n) {
	let r = [], i = [], a = {
		...structuredClone({
			...e,
			history: []
		}),
		history: e.history
	};
	for (let o of ga) if (!g(e[o], t[o])) {
		let s = `project.${o}`;
		r.push({
			id: s,
			kind: "project",
			existing: e[o],
			incoming: t[o]
		});
		let c = n?.[s] === "incoming";
		c && (a[o] = structuredClone(t[o])), i.push({
			id: s,
			kind: "project",
			action: c ? "update" : "keep",
			fields: [o]
		});
	}
	for (let [o, s] of [
		["entities", "entity"],
		["relations", "relation"],
		["snapshots", "snapshot"],
		["views", "view"]
	]) {
		let c = new Map(e[o].map((e) => [e.id, e]));
		for (let e of t[o]) {
			let t = c.get(e.id), a = t && !g(t, e);
			a && r.push({
				id: e.id,
				kind: s,
				existing: t,
				incoming: e
			}), (!t || n?.[e.id] === "incoming") && c.set(e.id, structuredClone(e));
			let o = Object.keys(e).filter((n) => !t || !g(t[n] ?? null, e[n] ?? null));
			i.push({
				id: e.id,
				kind: s,
				action: t ? a && n?.[e.id] === "incoming" ? "update" : "keep" : "add",
				fields: o
			});
		}
		a[o] = [...c.values()];
	}
	let o = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e]));
	for (let e of t.authorAlternatives ?? []) {
		let t = o.get(e.id);
		if (t && !g(t, e)) {
			if (r.push({
				id: e.id,
				kind: "alternative",
				existing: t,
				incoming: e
			}), n?.[e.id] === "incoming") throw new z("IMPORT_CONFLICT", "保存済み作者別案のIDへ別の履歴を上書きできません。新しいIDへ対応してください。", e.id);
			i.push({
				id: e.id,
				kind: "alternative",
				action: "keep",
				fields: []
			});
		} else t ? i.push({
			id: e.id,
			kind: "alternative",
			action: "keep",
			fields: []
		}) : (o.set(e.id, structuredClone(e)), i.push({
			id: e.id,
			kind: "alternative",
			action: "add",
			fields: [
				"name",
				"baseContent",
				"versions",
				"applyReceipts"
			]
		}));
	}
	(o.size || "authorAlternatives" in e || "authorAlternatives" in t) && (a.authorAlternatives = [...o.values()]);
	let s = r.filter((e) => !n?.[e.id]).map((e) => e.id);
	for (let e of r) if (e.kind === "snapshot" && n?.[e.id] === "incoming") throw new z("IMMUTABLE_SNAPSHOT", "既存版を別の内容に置き換えられません。", e.id);
	return {
		conflicts: r,
		unresolved: s,
		changes: i,
		...s.length ? {} : { candidate: a }
	};
}
async function va(e, t, n) {
	B(n.signal);
	let r = { ...n.knownWorlds ?? {} };
	for (let [t, n] of Object.entries(e.worlds)) {
		if (r[t] && !g(r[t], n)) throw new z("IMMUTABLE_SNAPSHOT", "固定世界IDと内容が衝突します。", t);
		r[t] = n;
	}
	let i = za(r), a = d(e.project, { worldSnapshots: i });
	if (!a.ok) throw oa(a.issues);
	let o = d(t, { worldSnapshots: i });
	if (!o.ok) throw oa(o.issues);
	if (e.manifest.projectId !== e.project.projectId) throw new z("VALIDATION_FAILED", "manifestと作品のIDが一致しません。");
	Ba([
		e.project,
		t,
		...Object.values(r)
	], r), await Va([
		e.project,
		t,
		...Object.values(r)
	]);
	for (let [e, t] of Object.entries(n.resolutions ?? {})) if (!["existing", "incoming"].includes(t)) throw new z("IMPORT_CONFLICT", "競合の採用方法が未対応です。", e);
	let s = sa(e.project, t, n.idMap), c = await ha(e.project, t, s, n.signal), u = d(c, { worldSnapshots: i });
	if (!u.ok) throw oa(u.issues);
	await Va([c]);
	let f = /* @__PURE__ */ new Map();
	for (let t of [e.project, ...Object.values(e.worlds)]) for (let e of Pa(t)) {
		let t = f.get(e.contentHash);
		if (t && !g(t, e)) throw new z("ASSET_INVALID", "同じ素材hashのメタデータが一致しません。", e.assetPath);
		f.set(e.contentHash, e);
	}
	let p = /* @__PURE__ */ new Map();
	for (let t of e.assets) {
		B(n.signal);
		let e = f.get(t.contentHash);
		if (!e || e.assetPath !== t.path || e.mediaType !== t.mediaType) throw new z("ASSET_INVALID", "素材bytesの宣言と添付が一致しません。", t.path);
		if (wa(t.path, t.mediaType, t.bytes), t.bytes.byteLength !== e.byteSize || await A(t.bytes) !== t.contentHash) throw new z("HASH_MISMATCH", "素材bytes・サイズ・hashが一致しません。", t.path);
		if (p.has(t.contentHash)) throw new z("ASSET_INVALID", "素材bytesが重複しています。", t.path);
		p.set(t.contentHash, t.bytes);
	}
	let m = [], h = [];
	for (let [e, t] of f) if (!p.has(e)) {
		let r = await n.loadAsset?.(e);
		if (B(n.signal), !r) {
			h.push(e);
			continue;
		}
		if (wa(t.assetPath, t.mediaType, r), r.byteLength !== t.byteSize || await A(r) !== e) throw new z("HASH_MISMATCH", "端末内の素材bytesが宣言と一致しません。", t.assetPath);
		m.push(e);
	}
	if (e.manifest.assetMode === "embedded" && h.length) throw new z("ASSET_MISSING", "完全復元に必要な素材が不足しています。", h[0]);
	let _ = _a(t, c, n.resolutions), v = new Map(Object.entries(s).map(([e, t]) => [t, e]));
	for (let e of _.changes) v.has(e.id) && (e.sourceId = v.get(e.id));
	if (_.candidate) {
		let e = l(_.candidate, { worldSnapshots: i });
		if (!e.ok) throw oa(e.issues);
	}
	return B(n.signal), {
		sourceProjectId: e.project.projectId,
		targetProjectId: t.projectId,
		targetRevision: t.revision,
		sourceContentHash: await A(E(e.project)),
		idMap: s,
		mappedProject: c,
		..._,
		assets: {
			provided: [...p.keys()],
			reused: m,
			missing: h,
			byteSize: e.assets.reduce((e, t) => e + t.bytes.length, 0)
		},
		warnings: [...e.warnings]
	};
}
//#endregion
//#region src/storage/archiveData.ts
var ya = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/, ba = /^[0-9a-f]{64}$/, xa = /^(?:manifest\.json|data\/(?:project|recovery|sync-recovery|records)\.json|worlds\/[0-9a-f-]{36}\.json|assets\/[0-9a-f]{64}\.[a-z0-9]{1,8})$/, Sa = {
	"image/png": ["png"],
	"image/jpeg": ["jpg", "jpeg"],
	"image/gif": ["gif"],
	"image/webp": ["webp"],
	"audio/mpeg": ["mp3"],
	"audio/wav": ["wav"],
	"audio/x-wav": ["wav"],
	"audio/ogg": ["ogg"],
	"video/mp4": ["mp4"],
	"video/webm": ["webm"],
	"application/pdf": ["pdf"],
	"text/plain": ["txt"],
	"application/json": ["json"],
	"application/octet-stream": ["bin"]
};
function Ca(e, t = "application/octet-stream") {
	let n = Sa[t];
	if (!ba.test(e) || !n) throw new z("ASSET_INVALID", "素材のhashまたは種類が未対応です。");
	return `assets/${e}.${n[0]}`;
}
function wa(e, t, n) {
	ce(e);
	let r = /^assets\/([0-9a-f]{64})\.([a-z0-9]{1,8})$/.exec(e);
	if (!r || !Sa[t]?.includes(r[2])) throw new z("ASSET_INVALID", "素材パス・種類・拡張子が一致しません。", e);
	if (n) {
		let r = (e) => e.every((e, t) => n[t] === e), i = (e, t) => [...t].every((t, r) => n[e + r] === t.charCodeAt(0)), a = !0;
		switch (t) {
			case "image/png":
				a = r([
					137,
					80,
					78,
					71,
					13,
					10,
					26,
					10
				]);
				break;
			case "image/jpeg":
				a = r([
					255,
					216,
					255
				]);
				break;
			case "image/gif":
				a = i(0, "GIF87a") || i(0, "GIF89a");
				break;
			case "image/webp":
				a = i(0, "RIFF") && i(8, "WEBP");
				break;
			case "audio/mpeg":
				a = i(0, "ID3") || n[0] === 255 && (n[1] & 224) == 224;
				break;
			case "audio/wav":
			case "audio/x-wav":
				a = i(0, "RIFF") && i(8, "WAVE");
				break;
			case "audio/ogg":
				a = i(0, "OggS");
				break;
			case "video/mp4":
				a = i(4, "ftyp");
				break;
			case "video/webm":
				a = r([
					26,
					69,
					223,
					163
				]);
				break;
			case "application/pdf":
				a = i(0, "%PDF-");
				break;
			case "application/json":
				le(n, e);
				break;
			case "text/plain": try {
				new TextDecoder("utf-8", { fatal: !0 }).decode(n);
			} catch {
				a = !1;
			}
		}
		if (!a) throw new z("ASSET_INVALID", "素材bytesが宣言した種類と一致しません。", e);
	}
	return r[1];
}
function Ta(e, t) {
	if (e.byteLength > t.compressedBytes) throw new z("LIMIT_EXCEEDED", "圧縮ファイルが64 MiBの上限を超えています。");
	let n = new DataView(e.buffer, e.byteOffset, e.byteLength), r = (e, t) => {
		throw new z("ARCHIVE_INVALID", e, t);
	}, i = (t) => t >= 0 && t + 2 <= e.length ? n.getUint16(t, !0) : r("ZIPヘッダーが途中で切れています。"), a = (t) => t >= 0 && t + 4 <= e.length ? n.getUint32(t, !0) : r("ZIPヘッダーが途中で切れています。");
	if (e.length < 22 || a(0) !== 67324752) return r("専用ZIPコンテナーのヘッダーがありません。");
	let o = -1;
	for (let t = e.length - 22; t >= Math.max(0, e.length - 65557); t--) if (a(t) === 101010256 && t + 22 + i(t + 20) === e.length) {
		o = t;
		break;
	}
	if (o < 0) return r("ZIPの終端が不正です。");
	let s = i(o + 10), c = a(o + 12), l = a(o + 16);
	if (i(o + 4) || i(o + 6) || i(o + 8) !== s || s === 65535 || c === 4294967295 || l === 4294967295) return r("分割ZIPとZIP64は未対応です。");
	if (s > t.files) throw new z("LIMIT_EXCEEDED", "ZIPのファイル数が上限を超えています。");
	if (!s || l + c !== o) return r("ZIPの中央ディレクトリが不正です。");
	let u = l, d = 0, f = [], p = /* @__PURE__ */ new Set();
	function m(t, n) {
		if (t + n > e.length) return r("ZIPのファイル名が途中で切れています。");
		try {
			return new TextDecoder("utf-8", { fatal: !0 }).decode(e.subarray(t, t + n));
		} catch {
			return r("ZIPのファイル名がUTF-8ではありません。");
		}
	}
	function h(t, n, a) {
		let o = t + n;
		if (o > e.length) return r("ZIP追加情報が途中で切れています。", a);
		for (let e = t; e < o;) {
			if (e + 4 > o) return r("ZIP追加情報が不正です。", a);
			let t = i(e), n = i(e + 2);
			if (t === 1) return r("ZIP64は未対応です。", a);
			if (e += 4 + n, e > o) return r("ZIP追加情報の長さが不正です。", a);
		}
	}
	for (let e = 0; e < s; e++) {
		if (u + 46 > o || a(u) !== 33639248) return r("ZIPの中央ヘッダーが不正です。");
		let e = i(u + 8), n = i(u + 10), s = a(u + 16), c = a(u + 20), g = a(u + 24), _ = i(u + 28), v = i(u + 30), y = i(u + 32), b = a(u + 42), x = a(u + 38), S = m(u + 46, _);
		if (ce(S), !xa.test(S)) return r("専用形式に未定義のファイルがあります。", S);
		if (p.has(S)) return r("ZIP内のファイル名が重複しています。", S);
		if (p.add(S), e & 8257 || n !== 0 && n !== 8) return r("暗号化ZIPまたは未対応の圧縮方式です。", S);
		if ((x >>> 16 & 61440) == 40960 || x & 16) return r("symlinkとディレクトリは読み込めません。", S);
		if (i(u + 34) || c === 4294967295 || g === 4294967295 || b === 4294967295) return r("分割ZIPとZIP64は未対応です。", S);
		if (g > (S.startsWith("assets/") ? t.assetBytes : t.jsonBytes) || (d += g) > t.expandedBytes) throw new z("LIMIT_EXCEEDED", "展開サイズが安全上限を超えています。", S);
		if (h(u + 46 + _, v, S), b + 30 > l || a(b) !== 67324752) return r("ZIPのローカルヘッダーが不正です。", S);
		let C = i(b + 26), w = i(b + 28);
		if (i(b + 6) !== e || i(b + 8) !== n || m(b + 30, C) !== S) return r("ZIPのローカル/中央ヘッダーが一致しません。", S);
		h(b + 30 + C, w, S);
		let T = b + 30 + C + w, E = T + c;
		if (E > l) return r("ZIPの圧縮データが範囲外です。", S);
		if (e & 8) {
			let e = E;
			if (a(e) === 134695760 && (e += 4), a(e) !== s || a(e + 4) !== c || a(e + 8) !== g) return r("ZIPのdata descriptorが一致しません。", S);
			E = e + 12;
		} else if (a(b + 14) !== s || a(b + 18) !== c || a(b + 22) !== g) return r("ZIPのサイズ/CRC宣言が一致しません。", S);
		f.push({
			path: S,
			compressedSize: c,
			expandedSize: g,
			dataStart: T,
			method: n,
			crc: s,
			localStart: b,
			localEnd: E
		}), u += 46 + _ + v + y;
	}
	if (u !== l + c) return r("ZIPの中央ディレクトリ長が不正です。");
	let g = 0;
	for (let e of [...f].sort((e, t) => e.localStart - t.localStart)) {
		if (e.localStart !== g) return r("ZIPに未列挙データまたは重複した領域があります。", e.path);
		g = e.localEnd;
	}
	return g === l ? !p.has("manifest.json") || !p.has("data/project.json") ? r("manifestまたは作品データがありません。") : f : r("ZIPに未列挙データがあります。");
}
var Ea = Uint32Array.from({ length: 256 }, (e, t) => {
	let n = t;
	for (let e = 0; e < 8; e++) n = n & 1 ? n >>> 1 ^ 3988292384 : n >>> 1;
	return n >>> 0;
}), Da = () => new Promise((e) => setTimeout(e, 0));
async function Oa(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = 0, o = 0, s = 0;
	for (let c of t) {
		B(n.signal);
		let l = 0, u = 4294967295, d = [], f = (e) => {
			if (l += e.byteLength, a += e.byteLength, l > c.expandedSize || l > (c.path.startsWith("assets/") ? r.assetBytes : r.jsonBytes) || a > r.expandedBytes) throw new z("LIMIT_EXCEEDED", "実際の展開bytesが安全上限または宣言サイズを超えました。", c.path);
			for (let t of e) u = Ea[(u ^ t) & 255] ^ u >>> 8;
			d.push(e.slice());
		};
		try {
			if (c.method === 0) f(e.subarray(c.dataStart, c.dataStart + c.compressedSize));
			else {
				let t = new Ur(f);
				for (let r = 0; r < c.compressedSize; r += 4096) {
					B(n.signal);
					let i = Math.min(c.compressedSize, r + 4096);
					t.push(e.subarray(c.dataStart + r, c.dataStart + i), i === c.compressedSize), ++s % 32 == 0 && await Da();
				}
				c.compressedSize || t.push(/* @__PURE__ */ new Uint8Array(), !0);
			}
		} catch (e) {
			throw e instanceof z ? e : new z("ARCHIVE_INVALID", "素材またはJSONの展開に失敗しました。", c.path, { cause: e });
		}
		if (l !== c.expandedSize || (u ^ 4294967295) >>> 0 !== c.crc) throw new z("ARCHIVE_INVALID", "ZIPの実サイズまたはCRCが一致しません。", c.path);
		let p = new Uint8Array(l), m = 0;
		for (let e of d) p.set(e, m), m += e.byteLength;
		i.set(c.path, p), n.onProgress?.({
			stage: "expanding",
			completed: ++o,
			total: t.length,
			path: c.path
		}), o % 32 == 0 && await Da();
	}
	return i;
}
function ka(e, t) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw new z("ARCHIVE_INVALID", "オブジェクトが必要です。", t);
	return e;
}
function Aa(e) {
	let t = ka(e, "manifest.json");
	if (t.format !== "scenario-package" || t.formatVersion !== "1.0.0") throw new z("FORMAT_UNSUPPORTED", "この専用形式の版には対応していません。元のファイルを保持してください。", "manifest.json");
	let n = typeof t.minimumReaderVersion == "string" && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(t.minimumReaderVersion) ? t.minimumReaderVersion.split(".").map(Number) : void 0;
	if (!n || n[0] > 1 || n[0] === 1 && (n[1] > 0 || n[2] > 0)) throw new z("FORMAT_UNSUPPORTED", "読み込みに新しいアプリが必要です。", "manifest.json/minimumReaderVersion");
	if (t.requiredFeatures !== void 0 && (!Array.isArray(t.requiredFeatures) || t.requiredFeatures.some((e) => ![
		"portable-recovery-v1",
		"native-sync-recovery-v1",
		"shared-review-source-v1",
		"shared-records-v1",
		"shared-record-deltas-v1",
		"shared-calendar-records-v1"
	].includes(e)))) throw new z("FORMAT_UNSUPPORTED", "未知の必須機能が宣言されています。", "manifest.json/requiredFeatures");
	if (typeof t.projectId != "string" || !ya.test(t.projectId) || typeof t.snapshotId != "string" || !ya.test(t.snapshotId) || typeof t.exportedAt != "string" || !Number.isFinite(Date.parse(t.exportedAt)) || !t.exportedAt.endsWith("Z") || !["embedded", "metadata_only"].includes(t.assetMode) || !Array.isArray(t.files)) throw new z("ARCHIVE_INVALID", "manifestの必須項目が不正です。", "manifest.json");
	let r = /* @__PURE__ */ new Set();
	for (let [e, n] of t.files.entries()) {
		let t = ka(n, `manifest.json/files/${e}`);
		if (typeof t.path != "string") throw new z("ARCHIVE_INVALID", "manifestのpathが不正です。", `manifest.json/files/${e}`);
		if (ce(t.path), t.path === "manifest.json" || !xa.test(t.path) || r.has(t.path) || !Number.isSafeInteger(t.byteSize) || t.byteSize < 0 || typeof t.sha256 != "string" || !ba.test(t.sha256) || t.role !== (t.path === "data/project.json" ? "project" : t.path === "data/recovery.json" ? "recovery" : t.path === "data/sync-recovery.json" ? "sync_recovery" : t.path === "data/records.json" ? "record_dictionary" : t.path.startsWith("worlds/") ? "world" : "asset")) throw new z("ARCHIVE_INVALID", "manifestのファイル宣言が不正または重複しています。", t.path);
		r.add(t.path);
	}
	return t;
}
function ja(e, t, n, r = {}, i) {
	let a;
	try {
		a = i ? i.validate(e) : d(e, { worldSnapshots: r });
	} catch (e) {
		throw new z("VALIDATION_FAILED", "共通世界または作品の構造が不正です。", t, { cause: e });
	}
	if (!a.ok) throw new z("VALIDATION_FAILED", a.issues.map((e) => `${e.path}: ${e.message}`).join("\n"), t);
	let o = a.value;
	if (o.entities.length + o.relations.length > n.records) throw new z("LIMIT_EXCEEDED", "entityとrelationの件数が上限を超えています。", t);
	return Na(o, t, n), o;
}
async function Ma(e, t, n = {}, r) {
	let i = r ? await r.integrity(e, !0) : await _n(e, { worldSnapshots: n }, !0);
	if (i.length) throw new z("VALIDATION_FAILED", i.map((e) => `${e.path}: ${e.message}`).join("\n"), t);
}
function Na(e, t, n, r = /* @__PURE__ */ new WeakSet()) {
	let i = typeof e == "object" && !!e && s(e);
	if (!(i && r.has(e))) {
		if (typeof e == "string") {
			if (new TextEncoder().encode(e).byteLength > n.fieldBytes) throw new z("LIMIT_EXCEEDED", "本文フィールドが1 MiBの上限を超えています。", t);
		} else if (Array.isArray(e)) e.forEach((e, i) => Na(e, `${t}/${i}`, n, r));
		else if (e && typeof e == "object") for (let [i, a] of Object.entries(e)) Na(a, `${t}/${i}`, n, r);
		i && r.add(e);
	}
}
function Pa(e) {
	return Fa([e]);
}
function Fa(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new WeakSet(), r = n;
	function i(e) {
		if (e && typeof e == "object") {
			if (r.has(e)) return;
			r.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(i);
			return;
		}
		if (!e || typeof e != "object") return;
		let n = e;
		if (n.kind === "attachment") {
			let e = ka(n.data, "attachment/data"), r = wa(e.assetPath, e.mediaType);
			if (r !== e.contentHash || !Number.isSafeInteger(e.byteSize) || e.byteSize < 0) throw new z("ASSET_INVALID", "素材のhashまたはサイズが不正です。", e.assetPath);
			let i = t.get(r);
			if (i && (i.assetPath !== e.assetPath || i.byteSize !== e.byteSize || i.mediaType !== e.mediaType)) throw new z("ASSET_INVALID", "同じhashの素材に異なるメタデータがあります。", e.assetPath);
			t.set(r, e);
		}
		for (let e of Object.keys(n)) {
			let t = n[e];
			t && typeof t == "object" && i(t);
		}
	}
	for (let t of e) r = s(t) ? n : /* @__PURE__ */ new WeakSet(), i(t);
	return [...t.values()];
}
function Ia(e) {
	return Fa(e);
}
function La(e, t = {}) {
	let n = {}, r = [e];
	for (; r.length;) for (let e of Ra(r.splice(0), t)) {
		let i = e.immutableSnapshotId;
		if (n[i]) continue;
		let a = t[i], o = a?.snapshots.find((e) => e.id === i);
		if (!a || a.projectId !== e.projectId || o?.contentHash !== e.contentHash) throw new z("ASSET_MISSING", "素材の固定世界依存が不足または不一致です。", i);
		if (n[i] = a, Object.keys(n).length > F.records) throw new z("LIMIT_EXCEEDED", "固定世界の依存上限を超えています。");
		r.push(a);
	}
	return Ia([e, ...Object.values(n)]);
}
function Ra(e, t = {}) {
	let n = /* @__PURE__ */ new Map();
	for (let e of Object.values(t)) for (let t of e.snapshots) {
		let r = n.get(t.id);
		if (r && r.reference.contentHash !== t.contentHash) throw new z("IMMUTABLE_SNAPSHOT", "固定世界の期待hashが同じIDで異なります。", t.id);
		n.set(t.id, {
			world: e,
			reference: {
				projectId: e.projectId,
				immutableSnapshotId: t.id,
				contentHash: t.contentHash
			}
		});
	}
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new WeakSet();
	function a(e) {
		if (e && typeof e == "object") {
			if (i.has(e)) return;
			i.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(a);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		if (Array.isArray(t.worldReferences)) for (let e of t.worldReferences) {
			let t = r.get(e.immutableSnapshotId);
			if (t && (t.projectId !== e.projectId || t.contentHash !== e.contentHash)) throw new z("VALIDATION_FAILED", "同じ共通世界snapshot IDの参照内容が一致しません。", e.immutableSnapshotId);
			r.set(e.immutableSnapshotId, e);
		}
		let o = n.size ? typeof t.kind == "string" && R.includes(t.kind) && typeof t.projectId == "string" && t.data && typeof t.data == "object" ? N(t) : typeof t.relationType == "string" && typeof t.projectId == "string" && typeof t.fromId == "string" && typeof t.toId == "string" ? I(t) : [] : [];
		for (let e of o) if (e.scope === "snapshot") {
			let i = n.get(e.id);
			if (i && i.world.projectId !== t.projectId) {
				let t = r.get(e.id);
				if (t && t.contentHash !== i.reference.contentHash) throw new z("IMMUTABLE_SNAPSHOT", "引用世界の期待hashが採用版と異なります。", e.id);
				r.set(e.id, i.reference);
			}
		}
		for (let e of Object.keys(t)) {
			let n = t[e];
			n && typeof n == "object" && a(n);
		}
	}
	return e.forEach(a), [...r.values()];
}
function za(e) {
	let t = Object.create(null);
	for (let [n, r] of Object.entries(e)) {
		if (!r || typeof r != "object" || !Array.isArray(r.snapshots)) continue;
		let e = r.snapshots.find((e) => e && e.id === n);
		if (e?.content && typeof e.content == "object" && Array.isArray(e.content.entities) && Array.isArray(e.content.relations) && Array.isArray(e.content.calendars)) {
			if (t[n] && !g(t[n], e.content)) throw new z("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", n);
			t[n] = e.content;
			for (let e of r.snapshots) if (e?.content?.projectId === r.projectId) {
				if (t[e.id] && !g(t[e.id], e.content)) throw new z("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", e.id);
				t[e.id] = e.content;
			}
		}
	}
	return t;
}
function Ba(e, t) {
	for (let [e, n] of Object.entries(t)) if (!n.snapshots.some((t) => t.id === e)) throw new z("VALIDATION_FAILED", "共通世界ファイルに指定した不変snapshotがありません。", `worlds/${e}.json`);
	for (let n of Ra(e)) {
		let e = t[n.immutableSnapshotId], r = e?.snapshots.find((e) => e.id === n.immutableSnapshotId);
		if (!e || e.projectId !== n.projectId || !r || r.contentHash !== n.contentHash) throw new z("VALIDATION_FAILED", "参照した共通世界の不変snapshotが不足または不一致です。", `worlds/${n.immutableSnapshotId}.json`);
	}
}
async function Va(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new WeakSet();
	function r(e) {
		if (e && typeof e == "object" && s(e)) {
			if (n.has(e)) return;
			n.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(r);
			return;
		}
		if (!e || typeof e != "object") return;
		let i = e;
		if (Array.isArray(i.snapshots)) for (let e of i.snapshots) {
			let n = t.get(e.id);
			if (n && !g(n, e)) throw new z("IMMUTABLE_SNAPSHOT", "同じ不変snapshot IDに異なる内容があります。", e.id);
			t.set(e.id, e);
		}
		for (let e of Object.keys(i)) {
			let t = i[e];
			t && typeof t == "object" && r(t);
		}
	}
	e.forEach(r);
	for (let e of t.values()) if (await A(E(e.content)) !== e.contentHash) throw new z("HASH_MISMATCH", "不変snapshotの内容hashが一致しません。", `snapshots/${e.id}`);
}
async function Ha(e, n = {}) {
	B(n.signal);
	let r = ae(n.limits), i = Ta(e, r);
	n.onProgress?.({
		stage: "container",
		completed: i.length,
		total: i.length
	});
	let a = await Oa(e, i, n, r), o = { objects: 0 }, s = Aa(le(a.get("manifest.json"), "manifest.json", r, o));
	if (s.files.length !== a.size - 1) throw new z("ARCHIVE_INVALID", "ZIPとmanifestのファイル数が一致しません。", "manifest.json");
	let c = new Set(s.files.map((e) => e.path));
	for (let e of a.keys()) if (e !== "manifest.json" && !c.has(e)) throw new z("ARCHIVE_INVALID", "manifestに列挙されていないファイルがあります。", e);
	for (let [e, t] of s.files.entries()) {
		B(n.signal);
		let r = a.get(t.path);
		if (!r) throw new z("ARCHIVE_INVALID", "manifestで列挙したファイルがありません。", t.path);
		if (r.byteLength !== t.byteSize || await A(r) !== t.sha256) throw new z("HASH_MISMATCH", "ファイルサイズまたはSHA-256が一致しません。", t.path);
		n.onProgress?.({
			stage: "hashes",
			completed: e + 1,
			total: s.files.length,
			path: t.path
		});
	}
	let l = s.requiredFeatures?.includes("shared-records-v1") ?? !1;
	if (n.onProgress?.({
		stage: "validating",
		completed: 0,
		total: 1
	}), l !== a.has("data/records.json")) throw new z("FORMAT_UNSUPPORTED", "共有レコード辞書には対応する必須機能の宣言が必要です。");
	let u = {
		recordDeltas: s.requiredFeatures?.includes("shared-record-deltas-v1") ?? !1,
		calendarRecords: s.requiredFeatures?.includes("shared-calendar-records-v1") ?? !1
	};
	if (!l && (u.recordDeltas || u.calendarRecords)) throw new z("FORMAT_UNSUPPORTED", "辞書の必須機能には共有レコード辞書が必要です。");
	let d = l ? new Jn(le(a.get("data/records.json"), "data/records.json", r, o), r, u) : void 0, f = (e) => {
		let t = le(a.get(e), e, r, o);
		return d ? d.decode(t, e) : t;
	}, p = Object.create(null);
	for (let e of s.files.filter((e) => e.role === "world")) p[e.path.slice(7, -5)] = f(e.path);
	let m = za(p), h = gi(m), g = f("data/project.json"), _ = t(g), v = ja(_.value, "data/project.json", r, m, h);
	if (v.projectId !== s.projectId) throw new z("VALIDATION_FAILED", "manifestと作品のprojectIdが一致しません。", "data/project.json/projectId");
	let y = Object.create(null), b = Object.create(null), x = v.entities.length + v.relations.length;
	for (let e of s.files.filter((e) => e.role === "world")) {
		let n = e.path.slice(7, -5), i = t(p[n]), a = ja(i.value, e.path, r, m, h);
		if (y[n] = a, b[n] = i.captured ? p[n] : a, x += a.entities.length + a.relations.length, x > r.records) throw new z("LIMIT_EXCEEDED", "参照世界を含むentityとrelationの件数が上限を超えています。", e.path);
	}
	let S = s.requiredFeatures?.includes("portable-recovery-v1") ?? !1;
	if (S !== a.has("data/recovery.json")) throw new z("FORMAT_UNSUPPORTED", "送信待ち復元情報には対応する必須機能の宣言が必要です。");
	let C = S ? await h.recoveryForInspection(f("data/recovery.json"), v, n.signal) : void 0, w = s.requiredFeatures?.includes("native-sync-recovery-v1") ?? !1;
	if (w !== a.has("data/sync-recovery.json")) throw new z("FORMAT_UNSUPPORTED", "同期復元証跡には必須機能宣言が必要です。");
	let T = w ? await Rn(f("data/sync-recovery.json"), m, n.signal) : void 0;
	d?.assertComplete();
	let E = t([...ui(C), ...Ln(T)]).value;
	if (Wa([
		v,
		...E,
		...Object.values(y)
	]) !== (s.requiredFeatures?.includes("shared-review-source-v1") ?? !1)) throw new z("FORMAT_UNSUPPORTED", "共有指摘の出所には対応する必須機能宣言が必要です。");
	Ba([
		v,
		...E,
		...Object.values(y)
	], y), await Va([
		v,
		...E,
		...Object.values(y)
	]), await Ma(v, "data/project.json", m, h);
	for (let [e, t] of Object.entries(y)) await Ma(t, `worlds/${e}.json`, m, h);
	let D = new Map(Ia([
		v,
		...E,
		...Object.values(y)
	]).map((e) => [e.assetPath, e])), O = [];
	for (let e of s.files.filter((e) => e.role === "asset")) {
		let t = D.get(e.path), n = a.get(e.path);
		if (!t || s.assetMode === "metadata_only") throw new z("ASSET_INVALID", "未参照または軽量保存に不適切な素材ファイルです。", e.path);
		if (wa(e.path, t.mediaType, n), n.byteLength !== t.byteSize || await A(n) !== t.contentHash) throw new z("HASH_MISMATCH", "添付素材の原hashまたはサイズが一致しません。", e.path);
		O.push({
			path: e.path,
			contentHash: t.contentHash,
			mediaType: t.mediaType,
			bytes: n
		});
	}
	let k = [...D.keys()].filter((e) => !a.has(e));
	if (s.assetMode === "embedded" && k.length) throw new z("ASSET_MISSING", "完全保存に必要な添付bytesが不足しています。", k[0]);
	return B(n.signal), ia(hi(v, C)), B(n.signal), n.onProgress?.({
		stage: "validating",
		completed: 1,
		total: 1
	}), {
		manifest: s,
		project: _.captured ? g : v,
		worlds: b,
		assets: O,
		...C ? { recovery: structuredClone(C) } : {},
		...T ? { syncRecovery: T } : {},
		warnings: [...s.assetMode === "metadata_only" ? [`軽量保存です。${k.length}件の添付bytesを含まず、完全バックアップとして復元できません。`] : [], ...C?.pending.length ? [`${C.pending.length}件の送信待ち意図を保持します。接続先・権限・サーバー共通元を確認するまで自動送信しません。`] : []],
		summary: {
			name: v.name,
			entities: v.entities.length,
			relations: v.relations.length,
			assetBytes: O.reduce((e, t) => e + t.bytes.byteLength, 0),
			missingAssets: k.length,
			history: v.history.length
		}
	};
}
async function Ua(e, n = {}) {
	n = { ...n }, B(n.signal);
	let i = t({
		input: e,
		worlds: n.worlds ?? {},
		recovery: n.recovery,
		syncRecovery: n.syncRecovery
	});
	e = i.value.input, n.onProgress?.({
		stage: "validating",
		completed: 0,
		total: 1
	});
	let a = i.value.worlds, o = za(a), s = gi(o), l = ja(e, "data/project.json", F, o, s), u = n.snapshotId ? l.snapshots.find((e) => e.id === n.snapshotId) : void 0;
	if (u) {
		let { history: e, snapshots: t, authorAlternatives: r, ...i } = l;
		if (!g(i, u.content)) throw new z("OPERATION_CONFLICT", "指定した版と書き出す内容が一致しません。対象snapshotの内容を選び直してください。", n.snapshotId);
	}
	Ba([l, ...Object.values(a)], a), await Va([l, ...Object.values(a)]), await Ma(l, "data/project.json", o, s);
	for (let [e, t] of Object.entries(a)) await Ma(t, `worlds/${e}.json`, o, s);
	let d = [l, ...Object.values(a)].reduce((e, t) => e + t.entities.length + t.relations.length, 0);
	if (d > F.records) throw new z("LIMIT_EXCEEDED", "参照世界を含むentityとrelationの件数が上限を超えています。");
	let f = i.value.recovery ? await s.recovery(i.value.recovery, l, n.signal) : void 0, p = i.value.syncRecovery?.length ? await Rn(i.value.syncRecovery, o, n.signal) : void 0, m = [...ui(f), ...Ln(p)];
	j(m), Ba(m, a), await Va(m);
	let h = n.assetMode ?? "embedded", v = Ia([
		l,
		...m,
		...Object.values(a)
	]);
	n.onProgress?.({
		stage: "serializing",
		completed: 0,
		total: 1
	});
	let y = l.history.length + l.snapshots.length + (l.authorAlternatives?.length ?? 0) + (f?.pending.length ?? 0) + (p?.length ?? 0), b = d >= 5e3 && y > 0 || [
		l,
		...Object.values(a),
		f,
		p
	].some((e) => e !== void 0 && c(e, F.jsonBytes)) ? new qn({
		recordDeltas: !0,
		calendarRecords: !0
	}) : void 0, x = (e) => E(b ? b.encode(e) : e), S = {
		"data/project.json": x(l),
		...f ? { "data/recovery.json": x(f) } : {},
		...p ? { "data/sync-recovery.json": x(p) } : {}
	};
	for (let [e, t] of Object.entries(a)) {
		if (!ya.test(e)) throw new z("VALIDATION_FAILED", "共通世界snapshot IDが不正です。", e);
		S[`worlds/${e}.json`] = x(ja(t, `worlds/${e}.json`, F, o, s));
	}
	if (b && (S["data/records.json"] = E({
		records: b.records,
		arrays: b.arrays
	})), h === "embedded") for (let e of v) {
		if (B(n.signal), S[e.assetPath]) continue;
		let t = await n.loadAsset?.(e.contentHash);
		if (!t) throw new z("ASSET_MISSING", "完全保存に必要な添付bytesが取得されていません。", e.assetPath);
		if (wa(e.assetPath, e.mediaType, t), t.byteLength !== e.byteSize || await A(t) !== e.contentHash) throw new z("HASH_MISMATCH", "素材bytesと保存メタデータが一致しません。", e.assetPath);
		S[e.assetPath] = t, n.onProgress?.({
			stage: "serializing",
			completed: Object.keys(S).filter((e) => e.startsWith("assets/")).length,
			total: v.length
		});
	}
	else if (h !== "metadata_only") throw new z("FORMAT_UNSUPPORTED", "出力プロファイルが未対応です。");
	let C = 0, w = { objects: 0 }, T = [];
	for (let [e, t] of Object.entries(S)) {
		let n = e === "data/project.json" ? "project" : e === "data/recovery.json" ? "recovery" : e === "data/sync-recovery.json" ? "sync_recovery" : e === "data/records.json" ? "record_dictionary" : e.startsWith("worlds/") ? "world" : "asset";
		if (t.byteLength > (n === "asset" ? F.assetBytes : F.jsonBytes) || (C += t.byteLength) > F.expandedBytes) throw new z("LIMIT_EXCEEDED", "出力サイズが安全上限を超えています。分割や軽量出力を選んでください。", e);
		T.push({
			path: e,
			byteSize: t.byteLength,
			sha256: await A(t),
			role: n
		}), n !== "asset" && le(t, e, F, w);
	}
	let D = Wa([
		l,
		...m,
		...Object.values(a)
	]), O = {
		format: "scenario-package",
		formatVersion: r,
		projectId: l.projectId,
		snapshotId: n.snapshotId ?? _(),
		exportedAt: n.exportedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
		assetMode: h,
		files: T,
		minimumReaderVersion: r,
		...f || p || b || D ? { requiredFeatures: [
			...f ? ["portable-recovery-v1"] : [],
			...p ? ["native-sync-recovery-v1"] : [],
			...b ? [zn, ...b.usedFeatures] : [],
			...D ? ["shared-review-source-v1"] : []
		] } : {}
	};
	if (Aa(O), S["manifest.json"] = E(O), le(S["manifest.json"], "manifest.json", F, w), Object.keys(S).length > F.files || C + S["manifest.json"].length > F.expandedBytes) throw new z("LIMIT_EXCEEDED", "出力のファイル数または全bytesが上限を超えています。");
	B(n.signal), n.onProgress?.({
		stage: "compressing",
		completed: 0,
		total: 1
	});
	let k = Zr(S, { level: 6 });
	if (k.byteLength > F.compressedBytes) throw new z("LIMIT_EXCEEDED", "圧縮後の出力が64 MiBを超えています。分割や軽量出力を選んでください。");
	return k;
}
function Wa(e) {
	let t = /* @__PURE__ */ new WeakSet(), n = (e) => {
		if (!e || typeof e != "object" || t.has(e)) return !1;
		t.add(e);
		let r = e;
		return r.kind === "review" && r.data && typeof r.data == "object" && r.data.sharedSource ? !0 : Object.values(e).some(n);
	};
	return e.some(n);
}
//#endregion
//#region src/storage/clone.ts
var Ga = (e) => structuredClone(e);
function Ka(e, t = /* @__PURE__ */ new WeakSet()) {
	if (e && typeof e == "object" && !t.has(e)) {
		t.add(e);
		for (let n of Object.keys(e)) {
			let r = e[n];
			r && typeof r == "object" && Ka(r, t);
		}
		Object.freeze(e);
	}
	return e;
}
async function qa(e) {
	let t = { [e.projectId]: _() }, n = /* @__PURE__ */ new WeakSet(), r = (e) => {
		if (e && typeof e == "object" && !n.has(e)) {
			if (n.add(e), Array.isArray(e)) return e.forEach(r);
			for (let [n, i] of Object.entries(e)) {
				if ([
					"id",
					"operationId",
					"instanceId",
					"deletionOperationId"
				].includes(n) && typeof i == "string" && /^[0-9a-f-]{36}$/.test(i) && (t[i] ??= _()), n === "bindings" && i && typeof i == "object" && !Array.isArray(i)) for (let e of Object.values(i)) typeof e == "string" && /^[0-9a-f-]{36}$/.test(e) && (t[e] ??= _());
				r(i);
			}
		}
	};
	r(e);
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new WeakSet(), s = (e) => {
		if (!e || typeof e != "object" || o.has(e)) return;
		if (o.add(e), Array.isArray(e)) {
			for (let t = e.length - 1; t >= 0; t--) s(e[t]);
			return;
		}
		let t = e, n = Object.values(t);
		for (let e = n.length - 1; e >= 0; e--) s(n[e]);
		typeof t.id == "string" && "kind" in t && "data" in t && "projectId" in t && !i.has(t.id) && i.set(t.id, t), typeof t.id == "string" && "relationType" in t && "fromId" in t && "toId" in t && !a.has(t.id) && a.set(t.id, t);
	};
	s(e);
	let c = (e, t) => t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), l = (e, t, n) => {
		let r = e;
		for (let e of t.slice(0, -1)) (!r[e] || typeof r[e] != "object") && (r[e] = {}), r = r[e];
		t.length && (r[t[t.length - 1]] = structuredClone(n));
	}, u = (e) => {
		if (Array.isArray(e)) {
			e.forEach(u);
			return;
		}
		if (!e || typeof e != "object") return;
		let n = e;
		if (typeof n.id == "string" && (n.id = t[n.id] ?? n.id), typeof n.instanceId == "string" && "quantity" in n && "consumed" in n && (n.instanceId = t[n.instanceId] ?? n.instanceId), n.mode === "anonymize" && typeof n.publicId == "string" && (n.publicId = t[n.publicId] ?? n.publicId), n.publicIds && typeof n.publicIds == "object") for (let [e, r] of Object.entries(n.publicIds)) typeof r == "string" && (n.publicIds[e] = t[r] ?? r);
		for (let e of Object.values(n)) u(e);
	}, d = /* @__PURE__ */ new WeakMap(), f = (e, t = "", n) => {
		if (!e || typeof e != "object") return p(e, t, n);
		let r = t;
		Array.isArray(e) && (t === "value" && (r += n?.type === "ref" ? ":ref" : ":literal"), t === "key" && n && typeof n.scope == "string" && Array.isArray(n.path) && (r += h([
			n.scope,
			n.itemId ?? null,
			n.path
		])), t === "publicId" && (r += n && typeof n.entityId == "string" && typeof n.sourceVersionId == "string" ? ":citation" : ":local"));
		let i = d.get(e) ?? /* @__PURE__ */ new Map();
		if (i.has(r)) return i.get(r);
		let a = p(e, t, n);
		return i.set(r, a), d.set(e, i), a;
	}, p = (e, n = "", r) => {
		if (typeof e == "string") return n === "onceTriggers" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/g, (e) => t[e] ?? e) : n === "key" && r && typeof r.scope == "string" && Array.isArray(r.path) ? [
			r.scope,
			typeof r.itemId == "string" ? t[r.itemId] ?? r.itemId : "",
			...r.path.map((e) => String(e))
		].map((e) => encodeURIComponent(e)).join(":") : n === "publicId" && r && typeof r.entityId == "string" && typeof r.sourceVersionId == "string" ? e : (/(?:Id|Ids)$/.test(n) || ["id", "operationId"].includes(n) || n === "value" && r?.type === "ref") && t[e] ? t[e] : e;
		if (n === "importOrigin" && e && typeof e == "object") {
			let n = e;
			return {
				...n,
				importOperationId: t[n.importOperationId] ?? n.importOperationId
			};
		}
		if (n === "path" && Array.isArray(e)) return [...e];
		if (n === "assignments" && e && typeof e == "object" && !Array.isArray(e)) return Object.fromEntries(Object.entries(e).map(([e, n]) => [e, typeof n == "string" ? t[n] ?? n : n]));
		if (Array.isArray(e)) return e.map((e) => f(e, n, r));
		if (e && typeof e == "object") {
			let r = e;
			if ([
				"entity",
				"relation",
				"project",
				"presentation"
			].includes(String(r.scope)) && Array.isArray(r.path) && r.before && r.after && "present" in r.before && "present" in r.after) {
				let e = String(r.scope), n = r.path, o = typeof r.itemId == "string" ? r.itemId : void 0, s = o ? t[o] ?? o : void 0, d = [...n], p = (r) => {
					if (e === "entity" && o && i.has(o) && n.length) {
						let e = structuredClone(i.get(o));
						l(e, n, r);
						let a = fe(e, t);
						return a.id = t[e.id] ?? e.id, a.projectId = t[e.projectId] ?? e.projectId, a.deletionOperationId &&= t[a.deletionOperationId] ?? a.deletionOperationId, u(a.data), c(a, n);
					}
					if (e === "relation" && o && a.has(o) && n.length) {
						let e = structuredClone(a.get(o));
						l(e, n, r);
						let i = me(e, t);
						return i.id = t[e.id] ?? e.id, i.projectId = t[e.projectId] ?? e.projectId, c(i, n);
					}
					if (e === "project" && n[0] === "worldReferences") return structuredClone(r);
					if (e === "presentation" && r && typeof r == "object" && !Array.isArray(r)) {
						let e = structuredClone(r);
						return Array.isArray(e.chapterOrder) && (e.chapterOrder = e.chapterOrder.map((e) => typeof e == "string" ? t[e] ?? e : e)), f(e);
					}
					let s = n.at(-1) ?? "";
					return f(r, s);
				}, m = (e) => {
					let t = structuredClone(e);
					return t.present === !0 && (t.value = p(t.value)), t;
				}, h = {
					...r,
					...s ? { itemId: s } : {},
					path: d,
					before: m(r.before),
					after: m(r.after)
				};
				return h.key = [
					e,
					s ?? "",
					...d
				].map((e) => encodeURIComponent(e)).join(":"), h;
			}
			let o = [
				"variableValues",
				"visitCounts",
				"publicTexts",
				"publicIds",
				"byEntityId",
				"bindings"
			].includes(n), s = Object.fromEntries(Object.entries(e).map(([r, i]) => [o ? t[r] ?? r : r, ["idMap", "bindings"].includes(n) && typeof i == "string" ? t[i] ?? i : f(i, r, e)]));
			return "kind" in s && "data" in s && "projectId" in s ? fe(s, t) : "relationType" in s && "fromId" in s && "toId" in s ? me(s, t) : (Array.isArray(s.patches) && Array.isArray(s.selectedChangeKeys) && (s.selectedChangeKeys = s.patches.map((e) => e.key).sort()), s);
		}
		return e;
	}, m = f(e), g = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new WeakSet(), y = (e) => {
		if (!e || typeof e != "object" || v.has(e)) return;
		if (v.add(e), Array.isArray(e)) {
			e.forEach(y);
			return;
		}
		let t = e;
		if (typeof t.id == "string" && t.content && typeof t.content == "object" && "versionLabel" in t && "contentHash" in t) {
			let e = g.get(t.id) ?? [];
			e.push(t), g.set(t.id, e);
		}
		Object.values(t).forEach(y);
	};
	y(m);
	let b = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Set(), S = async (e) => {
		let t = b.get(e);
		if (t) return t;
		let n = g.get(e);
		if (!n?.length) throw new z("HASH_MISMATCH", "参照したsnapshotがclone後に見つかりません。", e);
		if (x.has(e)) throw new z("HASH_MISMATCH", "snapshotの内容hashに循環があります。", e);
		x.add(e);
		for (let e of n) {
			let t = e.content;
			for (let e of t.entities) e.kind === "snapshot" && g.has(e.id) && (e.data.contentHash = await S(e.id));
		}
		let r = await A(E(n[0].content));
		for (let e of n) e.contentHash = r;
		return b.set(e, r), x.delete(e), r;
	};
	for (let e of g.keys()) await S(e);
	let C = /* @__PURE__ */ new WeakSet(), w = (e) => {
		if (!e || typeof e != "object" || C.has(e)) return;
		if (C.add(e), Array.isArray(e)) {
			e.forEach(w);
			return;
		}
		let t = e;
		if (t.kind === "snapshot" && typeof t.id == "string" && t.data && typeof t.data == "object") {
			let e = b.get(t.id);
			e && (t.data.contentHash = e);
		}
		Object.values(t).forEach(w);
	};
	w(m);
	let T = /* @__PURE__ */ new Set(), D = async (e) => {
		if (!e || typeof e != "object" || T.has(e)) return;
		if (T.add(e), Array.isArray(e)) {
			for (let t of e) await D(t);
			return;
		}
		let t = e;
		Array.isArray(t.authorAlternatives) && (t.authorAlternatives = await Promise.all((t.authorAlternatives ?? []).map($t)));
		for (let e of Object.values(t)) await D(e);
	};
	await D(m);
	let { history: O, snapshots: k, authorAlternatives: ee, ...te } = m, j = {
		...m,
		...Ga(te)
	};
	Ka(j.history);
	for (let e of j.snapshots) Ka(e);
	return {
		project: j,
		idMap: t
	};
}
//#endregion
//#region src/storage/importWork.ts
var Ja = /* @__PURE__ */ new Set([
	"full_read",
	"structure",
	"integrity",
	"recovery",
	"ids",
	"hashes",
	"map_recovery",
	"rehash_recovery"
]), Ya = 1e5, Xa = 128;
function Za(e) {
	let t = e;
	return typeof t.id == "string" && typeof t.projectId == "string" && (typeof t.kind == "string" && !!t.data && typeof t.data == "object" || typeof t.relationType == "string" && typeof t.fromId == "string" && typeof t.toId == "string");
}
function Qa() {
	let e = /* @__PURE__ */ new WeakMap(), t = 0, n = 0, r = (t, n) => e.get(t)?.has(n) ?? !1, i = (r, i, a, o, s) => {
		if (o ? t >= Ya : !a || !s || n >= Xa) return;
		let c = e.get(r);
		c || (c = /* @__PURE__ */ new WeakSet(), e.set(r, c)), c.add(i), o ? t++ : a && n++;
	}, a = (e, t, n = 0, o = "other") => {
		if (Object.is(e, t)) return !0;
		if (!e || !t || typeof e != "object" || typeof t != "object" || n > 128) return !1;
		let s = Array.isArray(e);
		if (s !== Array.isArray(t) || Object.getPrototypeOf(e) !== Object.getPrototypeOf(t)) return !1;
		if (r(e, t)) return !0;
		let c = Reflect.ownKeys(e), l = Reflect.ownKeys(t);
		if (c.length !== l.length) return !1;
		for (let r = 0; r < c.length; r++) {
			let i = c[r];
			if (i !== l[r]) return !1;
			let o = Object.getOwnPropertyDescriptor(e, i), s = Object.getOwnPropertyDescriptor(t, i);
			if (!o || !s || o.enumerable !== s.enumerable || !Object.hasOwn(o, "value") || !Object.hasOwn(s, "value") || !a(o.value, s.value, n + 1, i === "entities" || i === "relations" || i === "calendars" ? i : "other")) return !1;
		}
		let u = s && (o === "entities" || o === "relations" || o === "calendars");
		return i(e, t, s, Za(e), u), !0;
	};
	return a;
}
function $a(e, t, n) {
	let r = Array.isArray(e), i = r ? Array(e.length) : Object.create(Object.getPrototypeOf(e)), a = !1;
	for (let o of Reflect.ownKeys(e)) {
		if (r && o === "length") continue;
		let s = Object.getOwnPropertyDescriptor(e, o);
		if (typeof o != "string" || !s || !Object.hasOwn(s, "value")) return;
		let c = o === t ? (a = !0, n) : s.value;
		Object.defineProperty(i, o, {
			value: c,
			enumerable: s.enumerable,
			writable: !1,
			configurable: !1
		});
	}
	if (a) return Object.freeze(i);
}
function eo(e, t, n = Qa()) {
	if (!e || typeof e != "object" || Array.isArray(e)) return;
	let r = e;
	if (!Array.isArray(r.pending)) return;
	let i = new Map(t.history.map((e) => [e.operationId, e])), a = [];
	for (let e of r.pending) {
		if (!e || typeof e != "object" || Array.isArray(e)) return;
		let t = i.get(e.operationId);
		if (!t || !n(t, e.command)) return;
		let r = $a(e, "command", t);
		if (!r) return;
		a.push(r);
	}
	return $a(r, "pending", Object.freeze(a));
}
function to(e) {
	return Ja.has(e.step) && j(e), e;
}
function no(e) {
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object") return e;
		let r = t.get(e);
		if (r) return r;
		let i = Array.isArray(e), a = i ? Array(e.length) : Object.create(Object.getPrototypeOf(e));
		t.set(e, a);
		for (let t of Reflect.ownKeys(e)) {
			if (i && t === "length") continue;
			let r = Object.getOwnPropertyDescriptor(e, t);
			if (typeof t != "string" || !r || !Object.hasOwn(r, "value")) throw TypeError("Captured plain data changed shape before mutable clone");
			Object.defineProperty(a, t, {
				value: n(r.value),
				enumerable: r.enumerable,
				writable: !0,
				configurable: !0
			});
		}
		return a;
	};
	return n(e);
}
async function ro(e, n, r, i, a, o = !1, s = xn, c) {
	B(n);
	let { project: l, worlds: u, recovery: f } = e, p = {}, m;
	switch (e.step) {
		case "full_read": {
			let r = s(t({
				project: l,
				worlds: u,
				knownWorlds: e.knownWorlds ?? {}
			}).value), i = vn({ worldSnapshots: r.worlds }), a = i.validate(r.project);
			if (!a.ok) throw Object.assign(new z("VALIDATION_FAILED", a.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: a.issues });
			b(a.value), B(n), Ba([r.project], r.knownWorlds), B(n), await Va([r.project]), B(n);
			let o = await i.integrity(r.project, r.project.history.length > 0);
			if (o.length) throw Object.assign(new z("VALIDATION_FAILED", o.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: o });
			break;
		}
		case "structure": {
			let e = t(l);
			if (e.captured) {
				let t = a?.acquire(e.value, u);
				a && !t && a.clear();
				let n = t?.validationProject ?? s(e.value), r = (t?.session() ?? vn({ worldSnapshots: u })).validate(n);
				if (!r.ok) throw Object.assign(new z("VALIDATION_FAILED", r.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: r.issues });
				b(r.value), t && (m = () => t.commit(n)), p.project = i(e.value);
			} else {
				a?.clear();
				let e = d(l, { worldSnapshots: u });
				if (!e.ok) throw Object.assign(new z("VALIDATION_FAILED", e.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: e.issues });
				b(e.value), p.project = e.value;
			}
			break;
		}
		case "worlds":
			Ba([l], e.knownWorlds ?? {});
			break;
		case "hashes":
			await Va([l]);
			break;
		case "integrity": {
			let e = t({
				project: l,
				worlds: u
			}), n;
			if (e.captured) {
				let t = a?.acquire(e.value.project, e.value.worlds);
				a && !t && a.clear();
				let r = t?.validationProject ? void 0 : s(e.value), i = t?.validationProject ?? r.project;
				n = await (t?.session(r?.worlds) ?? vn({ worldSnapshots: r.worlds })).integrity(i, i.history.length > 0), !n.length && t && (m = () => t.commit(i));
			} else a?.clear(), n = await _n(l, { worldSnapshots: u }, l.history.length > 0);
			if (n.length) throw Object.assign(new z("VALIDATION_FAILED", n.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: n });
			break;
		}
		case "recovery": {
			let e = t({
				project: l,
				recovery: f,
				worlds: u
			});
			if (e.captured) {
				let t = a?.acquire(e.value.project, e.value.worlds);
				if (a && !t && a.clear(), t?.validationProject) {
					let r = e.value.recovery ? eo(e.value.recovery, t.validationProject, t.same) : void 0;
					if (r) await t.session().recoveryForInspection(r, t.validationProject, n);
					else {
						a?.clear();
						let t = s(e.value);
						await vi(t.recovery, t.project, t.worlds, n);
					}
				} else {
					t && a?.clear();
					let r = s(e.value);
					await vi(r.recovery, r.project, r.worlds, n);
				}
				p.recovery = i(e.value.recovery);
			} else a?.clear(), p.recovery = await vi(f, l, u, n);
			break;
		}
		case "sync_recovery":
			p.syncRecovery = await Rn(e.syncRecovery, u, n);
			break;
		case "ids": {
			if (!o) {
				let e = t({
					project: l,
					recovery: f
				});
				if (e.captured) {
					let t = s(e.value);
					p.ids = ia(hi(t.project, t.recovery));
				} else p.ids = ia(hi(l, f));
				break;
			}
			let e = aa();
			if (!e) {
				let e = t({
					project: l,
					recovery: f
				});
				if (e.captured) {
					let t = s(e.value);
					p.ids = ia(hi(t.project, t.recovery));
				} else p.ids = ia(hi(l, f));
				break;
			}
			let n = t({
				project: l,
				recovery: f
			});
			if (!n.captured) {
				p.ids = ia(hi(l, f));
				break;
			}
			let r = s(n.value), i = hi(r.project, r.recovery), a = t(i);
			p.ids = a.captured ? e(a.value) : ia(i);
			break;
		}
		case "clone":
			p.cloned = await qa(hi(l, f));
			break;
		case "mapped_plan": {
			if (!e.mapped || !e.target || !e.idMap) throw new z("IMPORT_CONFLICT", "別作品の統合候補と全IDの明示対応が必要です。");
			let t = e.mapped.source;
			p.mappedPlan = await va({
				...t,
				project: hi(t.project, t.recovery)
			}, e.target, {
				idMap: e.idMap,
				resolutions: e.resolutions,
				knownWorlds: e.mapped.knownWorlds,
				loadAsset: r,
				signal: n
			});
			break;
		}
		case "merge_conflicts":
			if (!e.target) throw new z("NOT_FOUND", "統合先がありません。");
			p.conflicts = ao(e.target, l);
			break;
		case "merge":
			if (!e.target) throw new z("NOT_FOUND", "統合先がありません。");
			p.project = oo(e.target, l, e.resolutions ?? {});
			break;
		case "combine_history": {
			if (!e.target) throw new z("NOT_FOUND", "統合先がありません。");
			let t = new Map(e.target.history.map((e) => [e.operationId, e]));
			for (let e of l.history) {
				let n = t.get(e.operationId);
				if (n && !g(n, e)) throw new z("IMPORT_CONFLICT", "同じ操作IDに異なる履歴があります。", e.operationId);
				n || t.set(e.operationId, structuredClone(e));
			}
			p.history = [...t.values()];
			break;
		}
		case "map_recovery": {
			if (!f || !e.idMap) throw new z("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。");
			let r = t({
				project: l,
				recovery: f,
				idMap: e.idMap
			});
			if (r.captured) {
				let e = s(r.value), t = new Map(r.value.project.history.map((e) => [e.operationId, e])), a = new Map(e.project.history.map((e) => [e.operationId, e])), o = [], l = Qr();
				for (let e of r.value.recovery.pending) {
					B(n);
					let i = r.value.idMap[e.operationId], s = t.get(i), u = a.get(i);
					if (!i || !s || !u) throw new z("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。", e.operationId);
					o.push({
						operationId: i,
						command: s,
						commandHash: c ? await c(u) : await A(l(u)),
						origin: e.origin ?? {
							projectId: r.value.recovery.projectId,
							operationId: e.operationId,
							serverRevision: r.value.recovery.serverRevision
						}
					});
				}
				p.recovery = i({
					...r.value.recovery,
					projectId: r.value.project.projectId,
					sourceRevision: r.value.project.revision,
					pending: o
				});
			} else {
				let t = new Map(l.history.map((e) => [e.operationId, e])), r = [];
				for (let i of f.pending) {
					B(n);
					let a = e.idMap[i.operationId], o = t.get(a);
					if (!a || !o) throw new z("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。", i.operationId);
					r.push({
						operationId: a,
						command: o,
						commandHash: await A(E(o)),
						origin: i.origin ?? {
							projectId: f.projectId,
							operationId: i.operationId,
							serverRevision: f.serverRevision
						}
					});
				}
				p.recovery = {
					...f,
					projectId: l.projectId,
					sourceRevision: l.revision,
					pending: r
				};
			}
			break;
		}
		case "rehash_recovery": {
			if (!f) throw new z("VALIDATION_FAILED", "送信待ち復元情報がありません。");
			let e = t({
				project: l,
				recovery: f
			});
			if (e.captured) {
				let t = s(e.value), r = new Map(e.value.project.history.map((e) => [e.operationId, e])), a = new Map(t.project.history.map((e) => [e.operationId, e])), o = [], l = Qr();
				for (let [i, s] of e.value.recovery.pending.entries()) {
					B(n);
					let e = t.recovery.pending[i], u = r.get(s.operationId) ?? s.command, d = a.get(e.operationId) ?? e.command;
					o.push({
						...s,
						command: u,
						commandHash: c ? await c(d) : await A(l(d))
					});
				}
				p.recovery = i({
					...e.value.recovery,
					projectId: e.value.project.projectId,
					sourceRevision: e.value.project.revision,
					pending: o
				});
			} else {
				let e = new Map(l.history.map((e) => [e.operationId, e])), t = [];
				for (let r of f.pending) {
					B(n);
					let i = e.get(r.operationId) ?? r.command;
					t.push({
						...r,
						command: i,
						commandHash: await A(E(i))
					});
				}
				p.recovery = {
					...f,
					projectId: l.projectId,
					sourceRevision: l.revision,
					pending: t
				};
			}
			break;
		}
		default: throw new z("FORMAT_UNSUPPORTED", "読み込みの検査工程が未対応です。");
	}
	return B(n), m?.(), p;
}
function io(e, t, n) {
	return ro(e, t, n, no);
}
function ao(e, t) {
	let n = [];
	for (let r of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) g(e[r], t[r]) || n.push({
		id: `project.${r}`,
		kind: "project",
		existing: e[r],
		incoming: t[r]
	});
	for (let [r, i] of [
		["entities", "entity"],
		["relations", "relation"],
		["snapshots", "snapshot"],
		["views", "view"],
		["authorAlternatives", "alternative"]
	]) {
		let a = new Map((e[r] ?? []).map((e) => [e.id, e]));
		for (let e of t[r] ?? []) a.has(e.id) && !g(a.get(e.id), e) && n.push({
			id: e.id,
			kind: i,
			existing: a.get(e.id),
			incoming: e
		});
	}
	return n;
}
function oo(e, t, n) {
	let r = ao(e, t);
	for (let e of r) {
		if (!n[e.id]) throw new z("IMPORT_CONFLICT", "同じID・異なる内容の競合があります。採用する内容を選択してください。", e.id);
		if (e.kind === "snapshot" && n[e.id] !== "existing") throw new z("IMMUTABLE_SNAPSHOT", "既存snapshotは別の内容へ置き換えられません。", e.id);
		if (e.kind === "alternative" && n[e.id] !== "existing") throw new z("IMPORT_CONFLICT", "保存済み作者別案のIDへ別の履歴を上書きできません。", e.id);
	}
	let i = structuredClone(e);
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) n[`project.${e}`] === "incoming" && (i[e] = structuredClone(t[e]));
	for (let r of [
		"entities",
		"relations",
		"snapshots",
		"views",
		"authorAlternatives"
	]) {
		let a = new Map((e[r] ?? []).map((e) => [e.id, e]));
		for (let e of t[r] ?? []) (!a.has(e.id) || n[e.id] === "incoming") && a.set(e.id, structuredClone(e));
		i[r] = [...a.values()];
	}
	return i;
}
//#endregion
//#region src/observability/databaseProbe.ts
function so(e) {
	e.use({
		stack: "dbcore",
		name: "scenario-numeric-probe",
		level: -3,
		create(e) {
			let t = /* @__PURE__ */ new WeakMap();
			return {
				...e,
				table(n) {
					let r = e.table(n);
					if (!oe.includes(n)) return r;
					let i = n, a = (e, t) => {
						L("db.read.calls", 1, i), L(t ? "db.read.rows" : "db.read.keys", e.filter((e) => e !== void 0).length, i), t && D("db.read.payloadBytes", e, i);
					};
					return {
						...r,
						get(e) {
							return de() ? (L("db.read.requested", 1, i), r.get(e).then((e) => (a(e === void 0 ? [] : [e], !0), e))) : r.get(e);
						},
						getMany(e) {
							return de() ? (L("db.read.requested", e.keys.length, i), r.getMany(e).then((e) => (a(e, !0), e))) : r.getMany(e);
						},
						query(e) {
							return de() ? r.query(e).then((t) => (a(t.result, !!e.values), t)) : r.query(e);
						},
						mutate(e) {
							if (!de()) return r.mutate(e);
							let n = w(), a = e.type === "add" || e.type === "put" ? e.values.length : e.type === "delete" ? e.keys.length : 0;
							n("db.write.calls", 1, i), n("db.write.attempted", a, i), e.type === "deleteRange" && n("db.deleteRange.calls", 1, i), (e.type === "add" || e.type === "put") && D("db.write.payloadBytes", e.values, i);
							let o = t.get(e.trans);
							if (!o) {
								o = { writes: /* @__PURE__ */ new Map() }, t.set(e.trans, o);
								let r = o.writes, i = e.trans, a = ee();
								i.addEventListener("complete", () => {
									n("db.transaction.committed");
									for (let [e, t] of r) n("db.write.committed", t, e);
									a.finish();
								}, { once: !0 }), i.addEventListener("abort", () => {
									n("db.transaction.aborted");
									for (let [e, t] of r) n("db.write.aborted", t, e);
									a.finish();
								}, { once: !0 });
							}
							let s = o.writes;
							return r.mutate(e).then((e) => {
								let t = Math.max(0, a - e.numFailures);
								return n("db.write.succeeded", t, i), s.set(i, (s.get(i) ?? 0) + t), e;
							});
						}
					};
				}
			};
		}
	});
}
//#endregion
//#region src/diagnostics.ts
var co = [
	"VALIDATION_FAILED",
	"REFERENCE_INVALID",
	"LOCAL_SAVE_FAILED",
	"QUOTA_EXCEEDED",
	"SYNC_CONFLICT",
	"AUTH_REQUIRED",
	"FORBIDDEN",
	"FORMAT_UNSUPPORTED",
	"INTEGRITY_FAILED",
	"IMPORT_LIMIT",
	"ANALYSIS_LIMIT",
	"EXPORT_UNSUPPORTED",
	"UI_RENDER_FAILED"
], lo = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
function uo(e, t, n, r) {
	if (!co.includes(e)) throw Error("Unknown diagnostic code");
	if (t !== void 0 && !lo.test(t)) throw Error("Invalid operation ID");
	if (n !== void 0 && !/^(0|[1-9]\d*)$/.test(n)) throw Error("Invalid revision");
	let i = {};
	if (r) {
		for (let e of ["commit", "tree"]) typeof r[e] == "string" && /^[0-9a-f]{40}$/.test(r[e]) && (i[e] = r[e]);
		typeof r.dirty == "boolean" && (i.dirty = r.dirty), typeof r.base == "string" && /^\/[A-Za-z0-9_/-]{0,100}\/$/.test(r.base) && (i.base = r.base), [
			"Chromium",
			"Edge",
			"Firefox",
			"Safari",
			"unknown"
		].includes(r.browser ?? "") && (i.browser = r.browser), [
			"Windows",
			"macOS",
			"iOS",
			"Android",
			"Linux",
			"unknown"
		].includes(r.os ?? "") && (i.os = r.os);
		for (let e of ["browserVersion", "osVersion"]) typeof r[e] == "string" && /^\d+(?:\.\d+){0,4}$/.test(r[e]) && r[e].length <= 32 && (i[e] = r[e]);
		for (let e of ["width", "height"]) Number.isSafeInteger(r[e]) && r[e] >= 0 && r[e] <= 1e4 && (i[e] = r[e]);
		typeof r.online == "boolean" && (i.online = r.online);
	}
	return {
		schemaVersion: "1.0.0",
		code: e,
		operationId: t ?? null,
		revision: n ?? null,
		environment: "browser",
		recordedAt: (/* @__PURE__ */ new Date()).toISOString(),
		...r ? { metadata: i } : {}
	};
}
var fo = /* @__PURE__ */ new Map(), po = /* @__PURE__ */ new Set(), mo = "guest";
function ho() {
	let e = typeof navigator > "u" ? "" : navigator.userAgent, t = e.match(/Edg\/([\d.]+)/) ? "Edge" : e.match(/Firefox\/([\d.]+)/) ? "Firefox" : e.match(/(?:Chrome|Chromium)\/([\d.]+)/) ? "Chromium" : e.match(/Version\/([\d.]+).*Safari/) ? "Safari" : "unknown", n = e.match(t === "Edge" ? /Edg\/([\d.]+)/ : t === "Firefox" ? /Firefox\/([\d.]+)/ : t === "Chromium" ? /(?:Chrome|Chromium)\/([\d.]+)/ : /Version\/([\d.]+)/)?.[1], r = /iPhone|iPad|iPod/.test(e) ? "iOS" : /Android/.test(e) ? "Android" : /Windows/.test(e) ? "Windows" : /Macintosh/.test(e) ? "macOS" : /Linux/.test(e) ? "Linux" : "unknown";
	return {
		commit: void 0,
		tree: void 0,
		dirty: void 0,
		base: "/__large-history/",
		browser: t,
		browserVersion: n,
		os: r,
		osVersion: e.match(r === "iOS" ? /OS ([\d_]+)/ : r === "Android" ? /Android ([\d.]+)/ : r === "Windows" ? /Windows NT ([\d.]+)/ : /Mac OS X ([\d_]+)/)?.[1]?.replaceAll("_", "."),
		...typeof window > "u" ? {} : {
			width: window.innerWidth,
			height: window.innerHeight,
			online: navigator.onLine
		}
	};
}
function go(e, t = {}) {
	try {
		let n = e && typeof e == "object" && "code" in e ? String(e.code) : "";
		if (n === "CANCELLED" || e instanceof DOMException && e.name === "AbortError") return;
		let r = t.code ?? (co.includes(n) ? n : {
			SAVE_FAILED: "LOCAL_SAVE_FAILED",
			REVISION_CONFLICT: "SYNC_CONFLICT",
			OPERATION_CONFLICT: "SYNC_CONFLICT",
			REVISION_CHANGED: "SYNC_CONFLICT",
			ARCHIVE_INVALID: "INTEGRITY_FAILED",
			HASH_MISMATCH: "INTEGRITY_FAILED",
			UNSAFE_PATH: "INTEGRITY_FAILED",
			ASSET_MISSING: "INTEGRITY_FAILED",
			ASSET_INVALID: "INTEGRITY_FAILED",
			LIMIT_EXCEEDED: "IMPORT_LIMIT",
			PROTOCOL_INVALID: "INTEGRITY_FAILED"
		}[n] ?? "LOCAL_SAVE_FAILED"), i = t.accountId === void 0 ? mo : t.accountId ?? "guest", a = uo(r, lo.test(t.operationId ?? "") ? t.operationId : void 0, /^(0|[1-9]\d*)$/.test(t.revision ?? "") ? t.revision : void 0, ho());
		return fo.set(i, [...(fo.get(i) ?? []).slice(-19), a]), po.forEach((e) => e()), a;
	} catch {}
}
//#endregion
//#region src/storage/recordPartsDatabase.ts
var _o = "__scenarioRecordParts", vo = /* @__PURE__ */ new Set([
	"commands",
	"outbox",
	"recoveredPending",
	"restorePoints",
	"worlds",
	"snapshots",
	"syncBases",
	"preparedSync",
	"syncConflicts",
	"syncAckEvidence",
	"retainedSyncRecovery",
	"projects",
	"entities"
]), yo = (e) => !!e && typeof e == "object" && Object.hasOwn(e, _o), bo = /* @__PURE__ */ new WeakMap(), xo = /* @__PURE__ */ new WeakSet();
function So(e) {
	let t = W.currentTransaction?.idbtrans;
	t && e && bo.set(t, e);
}
function Co(e) {
	So(e);
	let t = W.currentTransaction?.idbtrans;
	t && xo.add(t);
}
function wo(e, t) {
	e.use({
		stack: "dbcore",
		name: "scenario-record-parts-v1",
		level: -2,
		create(e) {
			if (!e.schema.tables.some((e) => e.name === "recordParts")) return e;
			let n = e.table("recordParts"), r = (e, t) => new Promise((n, r) => {
				let i = e, a = !1, o, s, c = !1, l = () => {
					try {
						let e = i.objectStore("recordParts").get("__scenario_keep_alive__");
						e.onsuccess = () => {
							if (a) {
								c ? r(s) : n(o);
								return;
							}
							l();
						}, e.onerror = () => r(e.error ?? new z("SAVE_FAILED", "履歴のトランザクションを維持できません。"));
					} catch (e) {
						r(e);
					}
				};
				l();
				try {
					t().then((e) => {
						o = e, a = !0;
					}, (e) => {
						s = e, c = !0, a = !0;
					});
				} catch (e) {
					s = e, c = !0, a = !0;
				}
			});
			return {
				...e,
				transaction(t, n, r) {
					return e.transaction([.../* @__PURE__ */ new Set([...t, "recordParts"])], n, r);
				},
				table(i) {
					let a = e.table(i);
					if (!vo.has(i)) return a;
					let o = (e) => yo(e) || i === "commands" && !!e && typeof e == "object" && yt(e), s = [a.schema.primaryKey, ...a.schema.indexes], c = (e, t) => {
						let n = { [_o]: t };
						for (let t of s) {
							let r = typeof t.keyPath == "string" ? [t.keyPath] : t.keyPath ?? [];
							for (let t of r) {
								if (t.includes(".")) throw new z("SAVE_FAILED", "分割保存の索引形式に対応していません。");
								Object.hasOwn(e, t) && (n[t] = e[t]);
							}
						}
						return n;
					}, l = async (e, t, a = !1) => {
						let o = e;
						if (!yo(e)) {
							if (i === "commands" && o && yt(o)) throw new z("SAVE_FAILED", "履歴の内部表現が破損しています。");
							return i === "commands" && a && (L("history.legacy.rows", +!!e), D("history.legacy.payloadBytes", e)), e;
						}
						if (i === "commands" && a && bt(e)) {
							let n = await r(t, () => Dt(e));
							return await kt(e, t), Y(e), {
								operationId: e.operationId,
								projectId: e.projectId,
								revision: e.revision,
								delta: { metadata: n }
							};
						}
						i === "commands" && a && (L("history.legacy.rows"), D("history.legacy.payloadBytes", e));
						let s = await n.getMany({
							trans: t,
							keys: e[_o].parts.map((e) => e.key)
						});
						if (s.some((e) => !e)) throw new z("SAVE_FAILED", "履歴の分割記録が不足しています。");
						i === "commands" && (L("history.body.rows"), L("history.body.partRows", s.length), L("history.body.partBytes", s.reduce((e, t) => e + (t.bytes?.byteLength ?? 0), 0)));
						let l = P("decode"), u = await r(t, () => ft(e[_o], s, bo.get(t)));
						if (l(), L("decode.rows"), D("decode.payloadBytes", u), !u || typeof u != "object" || yo(u)) throw new z("SAVE_FAILED", "履歴の分割記録と索引が一致しません。");
						if (i === "commands" && yt(e)) await r(t, () => Ot(e, u, c(u, e[_o])));
						else if (!g(c(u, e[_o]), e)) throw new z("SAVE_FAILED", "履歴の分割記録と索引が一致しません。");
						return u;
					}, u = (e, t, n) => i === "commands" && _t(n) ? Et(e, c(e, t)) : c(e, t), d = async (e, t) => {
						let r = e.flatMap((e) => yo(e) ? e[_o].parts.map((e) => e.key) : []);
						if (r.length) {
							let e = await n.mutate({
								type: "delete",
								trans: t,
								keys: r
							});
							if (e.numFailures) throw Object.values(e.failures)[0];
						}
					};
					return {
						...a,
						async get(e) {
							return l(await a.get(e), e.trans);
						},
						async getMany(e) {
							let t = i === "commands" && vt(e), n = await a.getMany(e), r;
							for (let i = 0; i < n.length; i++) o(n[i]) ? (r ??= n.slice(), r[i] = await l(n[i], e.trans, t)) : t && n[i] !== void 0 && (L("history.legacy.rows"), D("history.legacy.payloadBytes", n[i]));
							return r ?? n;
						},
						async query(e) {
							let t = await a.query(e);
							if (e.values) {
								let n;
								for (let r = 0; r < t.result.length; r++) o(t.result[r]) && (n ??= t.result.slice(), n[r] = await l(t.result[r], e.trans));
								if (n) return {
									...t,
									result: n
								};
							}
							return t;
						},
						async openCursor(e) {
							let t = await a.openCursor(e);
							if (!t || !e.values) return t;
							let n = await l(t.value, e.trans), r = {
								get trans() {
									return t.trans;
								},
								get key() {
									return t.key;
								},
								get primaryKey() {
									return t.primaryKey;
								},
								get done() {
									return t.done;
								},
								get value() {
									return n;
								},
								continue(e) {
									t.continue(e);
								},
								continuePrimaryKey(e, n) {
									t.continuePrimaryKey(e, n);
								},
								advance(e) {
									t.advance(e);
								},
								stop(e) {
									t.stop(e);
								},
								fail(e) {
									t.fail(e);
								},
								async next() {
									return await t.next(), n = await l(t.value, e.trans), r;
								},
								start(r) {
									return t.start(() => {
										l(t.value, e.trans).then((e) => {
											n = e, r();
										}, (e) => t.fail(e));
									});
								}
							};
							return r;
						},
						async mutate(e) {
							let s = [];
							if (e.type === "put" || e.type === "delete") {
								let t = e.keys ?? (e.type === "put" ? e.values.map((e) => a.schema.primaryKey.extractKey?.(e)) : []);
								s = await a.getMany({
									trans: e.trans,
									keys: t
								});
							}
							if (e.type === "deleteRange" && (s = (await a.query({
								trans: e.trans,
								values: !0,
								query: {
									index: a.schema.primaryKey,
									range: e.range
								}
							})).result), e.type === "add" || e.type === "put") {
								let l = [], f = [], p = xo.has(e.trans) && (i === "commands" || i === "recoveredPending") ? dt : ut;
								if (xo.has(e.trans) && (i === "commands" || i === "recoveredPending") && e.values.length > 1) for (let n = 0; n < e.values.length; n += 2) {
									let a = await r(e.trans, () => Promise.allSettled(e.values.slice(n, n + 2).map(async (n) => {
										if (o(n)) throw new z("SAVE_FAILED", "内部の分割記録を入力値として保存できません。");
										if (!nt(n, t)) return {
											value: n,
											parts: []
										};
										let r = await p(n, `${i}:${_()}`, bo.get(e.trans));
										return {
											value: await u(n, r.packed, e.trans),
											parts: r.parts
										};
									})));
									for (let e of a) if (e.status === "rejected") throw e.reason;
									for (let e of a) e.status === "fulfilled" && (l.push(e.value.value), f.push(...e.value.parts));
								}
								else for (let n of e.values) {
									if (o(n)) throw new z("SAVE_FAILED", "内部の分割記録を入力値として保存できません。");
									if (nt(n, t)) {
										let t = await r(e.trans, () => p(n, `${i}:${_()}`, bo.get(e.trans)));
										l.push(i === "commands" && _t(e.trans) ? await r(e.trans, () => Et(n, c(n, t.packed))) : c(n, t.packed)), f.push(...t.parts);
									} else l.push(n);
								}
								let m = /* @__PURE__ */ new Map();
								l.forEach((t, n) => {
									let r = e.keys?.[n] ?? a.schema.primaryKey.extractKey?.(t);
									m.set(JSON.stringify(r), t);
								});
								let h = new Set([...m.values()].flatMap((e) => yo(e) ? [e[_o].scope] : [])), g = f.filter((e) => h.has(e.scope));
								if (g.length) {
									let t = await n.mutate({
										type: "add",
										trans: e.trans,
										values: g
									});
									if (t.numFailures) throw Object.values(t.failures)[0];
								}
								let v = await a.mutate({
									...e,
									values: l
								});
								return v.numFailures ? (e.trans.abort(), v) : (await d(s, e.trans), v);
							}
							let l = await a.mutate(e);
							return l.numFailures ? (e.trans.abort(), l) : (await d(s, e.trans), l);
						}
					};
				}
			};
		}
	});
}
//#endregion
//#region src/storage/readValidationCore.ts
async function To(e, t, n) {
	let r = {
		...e,
		history: []
	}, i = za(t);
	n?.("structure"), b(r), n?.("integrity");
	let a = await _n(r, { worldSnapshots: i }, !1);
	if (a.length) throw Object.assign(new z("VALIDATION_FAILED", a.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: a });
	n?.("worlds"), Ba([r], t), n?.("hashes"), await Va([r]);
}
//#endregion
//#region src/storage/readValidation.ts
async function Eo(e, t, n = {}) {
	if (B(n.signal), typeof window > "u" || typeof Worker > "u" || e.entities.length + e.relations.length < 5e3) {
		await To(e, t, n.onStage), B(n.signal);
		return;
	}
	await new Promise((r, i) => {
		let a = new Worker(new URL(
			/* @vite-ignore */
			"/__large-history/assets/readValidation.worker-DzUy_hN_.js",
			"" + import.meta.url
		), { type: "module" });
		st(a, "worker.read");
		let o = (e) => {
			a.terminate(), n.signal?.removeEventListener("abort", s), e ? i(e) : r();
		}, s = () => o(new z("CANCELLED", "作品の確認を取り消しました。保存済み内容と入力は変更していません。"));
		a.onmessage = (e) => {
			let t = e.data;
			if (t.type === "stage") n.onStage?.(t.stage);
			else if (t.type === "done") try {
				B(n.signal), o();
			} catch (e) {
				o(e);
			}
			else t.type === "error" && o(Object.assign(new z(t.code, t.message), { issues: t.issues ?? [] }));
		}, a.onerror = () => o(new z("SAVE_FAILED", "作品の確認処理を開始できませんでした。保存済み内容を保持しています。")), n.signal?.addEventListener("abort", s, { once: !0 });
		try {
			B(n.signal), a.postMessage({
				project: e,
				worlds: t
			});
		} catch (e) {
			o(e);
		}
	});
}
//#endregion
//#region src/performance.ts
function Do() {
	try {
		return sessionStorage.getItem("scenario-performance") === "measure";
	} catch {
		return !1;
	}
}
function Oo() {
	return Do() ? performance.now() : void 0;
}
function ko(e, t, n) {
	if (!(e === void 0 || !Number.isFinite(e) || e < 0 || !Do())) try {
		performance.measure("scenario-local-save", {
			start: e,
			end: performance.now(),
			detail: {
				operationId: t,
				...n ? { milliseconds: n } : {}
			}
		});
	} catch {}
}
function Ao(e, t, n) {
	if (!(e === void 0 || !Number.isFinite(e) || e < 0 || !Do())) try {
		performance.measure("scenario-local-read", {
			start: e,
			end: performance.now(),
			detail: {
				projectId: t,
				milliseconds: n
			}
		});
	} catch {}
}
//#endregion
//#region src/storage/nativeExport.ts
async function jo(e, t = {}) {
	B(t.signal), e = xn(e);
	let n = e.worlds;
	if (e.availableWorlds) {
		n = {};
		let t = [...e.pending.map((e) => e.command), ...e.retained.map((e) => e.command)].flatMap((e) => [e.before, e.after].map((e) => ({
			...e,
			history: []
		}))), r = [
			e.project,
			...t,
			...Ln(e.syncRecovery)
		];
		for (; r.length;) {
			let t = [];
			for (let i of Ra(r, e.availableWorlds)) {
				if (n[i.immutableSnapshotId]) continue;
				let r = e.availableWorlds[i.immutableSnapshotId];
				r && (n[i.immutableSnapshotId] = r, t.push(r));
			}
			r = t;
		}
	}
	let r = Qr(), i = new Map(e.retained.map((e) => [e.operationId, e]));
	for (let n of e.pending) {
		B(t.signal);
		let a = await A(r(n.command)), o = i.get(n.operationId);
		if (o && o.commandHash !== a) throw new z("OPERATION_CONFLICT", "復元した送信待ちと現在の送信待ちが同じIDで異なります。");
		i.set(n.operationId, {
			operationId: n.operationId,
			command: n.command,
			commandHash: a,
			origin: {
				projectId: e.project.projectId,
				operationId: n.operationId,
				serverRevision: n.baseRevision
			}
		}), t.onProgress?.({
			stage: "hashes",
			completed: i.size,
			total: e.pending.length
		}), await new Promise((e) => setTimeout(e, 0)), B(t.signal);
	}
	let a = i.size ? {
		version: 1,
		projectId: e.project.projectId,
		sourceRevision: e.project.revision,
		serverRevision: e.serverRevision,
		pending: [...i.values()]
	} : void 0;
	return Ua(e.project, {
		...t,
		recovery: a,
		worlds: n,
		syncRecovery: e.syncRecovery
	});
}
//#endregion
//#region src/storage/archive.ts
async function Mo(e, t = {}) {
	let n = t.signal, r = t.loadAsset;
	return B(n), typeof window > "u" || typeof Worker > "u" ? io(to(structuredClone(e)), n, r) : new Promise((t, i) => {
		let a = new Worker(new URL(
			/* @vite-ignore */
			"/__large-history/assets/archive.worker-D-2ZmHu8.js",
			"" + import.meta.url
		), { type: "module" });
		st(a, "worker.archive");
		let o = !0, s = (e, r) => {
			o && (o = !1, a.terminate(), n?.removeEventListener("abort", c), e ? i(e) : t(r));
		}, c = () => s(new z("CANCELLED", "復元の確認を取り消しました。既存作品と元ファイルは変更していません。"));
		a.onmessage = (e) => {
			let t = e.data;
			if (t.type === "done") try {
				B(n), s(void 0, t.result);
			} catch (e) {
				s(e);
			}
			else t.type === "error" ? s(Object.assign(new z(t.error.code, t.error.message, t.error.path), { issues: t.error.issues ?? [] })) : t.type === "asset" && Promise.resolve().then(() => (B(n), r?.(t.hash))).then((e) => {
				if (!o || n?.aborted) return;
				let r = e?.slice();
				a.postMessage({
					type: "import-asset",
					id: t.id,
					bytes: r
				}, r ? [r.buffer] : []);
			}).catch((e) => {
				if (!o || n?.aborted) return;
				let r = S(e);
				a.postMessage({
					type: "import-asset",
					id: t.id,
					error: {
						code: r.code,
						message: r.message,
						path: r.path,
						issues: e?.issues
					}
				});
			});
		}, a.onerror = () => s(new z("SAVE_FAILED", "復元の確認処理を完了できませんでした。既存作品と元ファイルは保持しています。")), n?.addEventListener("abort", c, { once: !0 });
		try {
			B(n), a.postMessage({
				type: "import-work",
				work: e
			});
		} catch (e) {
			s(e);
		}
	});
}
async function No(e, t = {}) {
	if (B(t.signal), typeof Worker > "u" || t.worker === !1) return Ha(e, t);
	if (e.byteLength > ae(t.limits).compressedBytes) throw new z("LIMIT_EXCEEDED", "圧縮ファイルが安全上限を超えています。");
	return new Promise((n, r) => {
		let i = new Worker(new URL(
			/* @vite-ignore */
			"/__large-history/assets/archive.worker-D-2ZmHu8.js",
			"" + import.meta.url
		), { type: "module" });
		st(i, "worker.archive");
		let a = (e) => {
			t.signal?.removeEventListener("abort", o), i.terminate(), e();
		}, o = () => a(() => r(new z("CANCELLED", "読み込みを取り消しました。既存作品は変更していません。")));
		t.signal?.addEventListener("abort", o, { once: !0 }), i.onmessage = (e) => {
			let i = e.data;
			i.type === "progress" && i.progress ? t.onProgress?.(i.progress) : i.type === "done" && i.prepared ? a(() => n(i.prepared)) : i.type === "error" && a(() => r(new z(i.error.code, i.error.message, i.error.path)));
		}, i.onerror = (e) => a(() => r(new z("ARCHIVE_INVALID", "読み込み作業領域で処理に失敗しました。", void 0, { cause: e.message })));
		let s = e.slice();
		i.postMessage({
			bytes: s,
			limits: t.limits
		}, [s.buffer]);
	});
}
async function Po(e, t = {}) {
	if (B(t.signal), t.worker === !1 || typeof window > "u" || typeof Worker > "u") return jo(e, t);
	let { loadAsset: n, signal: r, onProgress: i, ...a } = t;
	return Fo({
		native: e,
		options: a
	}, t);
}
function Fo(e, n) {
	return new Promise((r, i) => {
		let a = new Worker(new URL(
			/* @vite-ignore */
			"/__large-history/assets/archiveExport.worker-DUh5DmMU.js",
			"" + import.meta.url
		), { type: "module" }), o = !0;
		st(a, "worker.archive");
		let c = (e, t) => {
			o && (o = !1, a.terminate(), n.signal?.removeEventListener("abort", l), e ? i(e) : r(t));
		}, l = () => c(new z("CANCELLED", "保存ファイルの作成を取り消しました。端末の作品と入力は変更していません。"));
		a.onmessage = (e) => {
			let t = e.data;
			t.type === "progress" ? n.onProgress?.(t.progress) : t.type === "done" ? c(void 0, t.bytes) : t.type === "error" ? c(new z(t.code, t.message, t.path)) : t.type === "asset" && Promise.resolve().then(() => n.loadAsset?.(t.hash)).then((e) => {
				if (!o) return;
				let n = e?.slice();
				a.postMessage({
					type: "asset",
					id: t.id,
					bytes: n
				}, n ? [n.buffer] : []);
			}).catch(() => {
				o && a.postMessage({
					type: "asset",
					id: t.id
				});
			});
		}, a.onerror = () => c(new z("SAVE_FAILED", "保存ファイルを作成できませんでした。端末の作品は保持しています。")), n.signal?.addEventListener("abort", l, { once: !0 });
		try {
			if (B(n.signal), ("native" in e ? [e.native] : [
				e.input,
				e.options.worlds,
				e.options.recovery,
				e.options.syncRecovery
			].filter((e) => e !== void 0)).every(s)) {
				let r = t(e);
				r.captured ? rt(r.value, (e) => a.postMessage(e), n.signal, () => o).catch(c) : a.postMessage(e);
			} else a.postMessage(e);
		} catch (e) {
			c(e);
		}
	});
}
//#endregion
//#region src/storage/worldPins.ts
async function Io(e, t, n) {
	let r = {
		...n,
		...t.dependencies,
		[t.snapshotId]: t.world
	}, i = {}, a = [t.snapshotId];
	for (; a.length;) {
		let e = a.pop();
		if (i[e]) continue;
		let t = r[e], o = t?.snapshots.find((t) => t.id === e);
		if (!t || !o || o.content.projectId !== t.projectId) throw new z("VALIDATION_FAILED", "固定する共通世界の版が見つかりません。", e);
		let s = n[e]?.snapshots.find((t) => t.id === e);
		if (s && !g(s, o)) throw new z("IMMUTABLE_SNAPSHOT", "保存済みの共通世界版を変更できません。", e);
		let c = /* @__PURE__ */ new Map([[o.id, o]]), l = [o];
		for (; l.length;) {
			let e = l.pop(), n = [...e.content.entities.flatMap(N), ...e.content.relations.flatMap(I)];
			for (let e of n) if (e.scope === "snapshot" && e.id !== t.projectId && !c.has(e.id)) {
				let n = t.snapshots.find((t) => t.id === e.id);
				n && (c.set(n.id, n), l.push(n));
			}
		}
		let u = {
			...structuredClone(o.content),
			snapshots: structuredClone([...c.values()]),
			history: []
		};
		i[e] = u;
		for (let e of Ra([u])) a.push(e.immutableSnapshotId);
	}
	let o = i[t.snapshotId].snapshots[0];
	if (!e.worldReferences.some((e) => e.immutableSnapshotId === t.snapshotId && e.projectId === o.content.projectId && e.contentHash === o.contentHash)) throw new z("VALIDATION_FAILED", "作品の固定版参照と保存対象が一致しません。", t.snapshotId);
	let s = {
		...n,
		...i
	}, c = za(s);
	for (let e of Object.values(i)) {
		let t = d(e, { worldSnapshots: c });
		if (!t.ok) throw new z("VALIDATION_FAILED", t.issues.map((e) => e.message).join("\n"));
	}
	return Ba([e, ...Object.values(i)], s), await Va([...Object.values(n), ...Object.values(i)]), i;
}
//#endregion
//#region src/domain/text.ts
var Lo = "本文の置換・削除・段落分割が注記に重なり、元の文字を特定できません。", Ro = (e) => e.map((e) => e.text).join("\n"), zo = /* @__PURE__ */ new WeakMap();
function Bo(e, t, n) {
	let r = Array(e.length), i = 0, a = 0;
	if (n && n.start >= 0 && n.end >= n.start && n.end <= e.length) {
		let i = t.length - (e.length - (n.end - n.start));
		if (i >= 0 && e.slice(0, n.start).join("") === t.slice(0, n.start).join("") && e.slice(n.end).join("") === t.slice(n.start + i).join("")) {
			for (let e = 0; e < n.start; e++) r[e] = e;
			for (let t = n.end; t < e.length; t++) r[t] = t + i - (n.end - n.start);
			return r;
		}
	}
	for (; i < e.length && i < t.length && e[i] === t[i];) r[i] = i, i++;
	for (; a < e.length - i && a < t.length - i && e[e.length - a - 1] === t[t.length - a - 1];) r[e.length - a - 1] = t.length - a - 1, a++;
	let o = e.length - i - a, s = t.length - i - a;
	if (!o || !s || o * s > 25e4) return r;
	let c = s + 1, l = new Uint32Array((o + 1) * c);
	for (let n = o - 1; n >= 0; n--) for (let r = s - 1; r >= 0; r--) l[n * c + r] = e[i + n] === t[i + r] ? l[(n + 1) * c + r + 1] + 1 : Math.max(l[(n + 1) * c + r], l[n * c + r + 1]);
	let u = 0, d = 0;
	for (; u < o && d < s;) e[i + u] === t[i + d] ? (r[i + u] = i + d, u++, d++) : l[(u + 1) * c + d] > l[u * c + d + 1] ? u++ : d++;
	return r;
}
function Vo(e) {
	let t = 0;
	return e.map((e) => {
		let n = t;
		return t += e + 1, n;
	});
}
function Ho(e, t, n) {
	let r = Ro(e), i = Ro(t), a = Array.from(r), o = Array.from(i), s = e.map((e) => Array.from(e.text)), c = t.map((e) => Array.from(e.text).length), l = s.map((e) => e.length), u = Vo(l), d = Vo(c), f = Bo(a, o, n), p = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ new Map();
	e.forEach((e, t) => p.set(e.text, [...p.get(e.text) ?? [], t])), t.forEach((e, t) => m.set(e.text, [...m.get(e.text) ?? [], t]));
	let h = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new Set();
	e.forEach((e, r) => {
		if (!n && p.get(e.text)?.length !== m.get(e.text)?.length) return;
		let i = t.findIndex((t) => t.id === e.id && t.text === e.text);
		if (!(i < 0)) {
			h.set(r, i);
			for (let e = 0; e < l[r]; e++) g.add(d[i] + e);
		}
	});
	for (let [e, t] of p) {
		let n = m.get(e);
		n && t.length === 1 && n.length === 1 && t.forEach((e, t) => {
			if (h.has(e)) return;
			let r = n[t];
			h.set(e, r);
			for (let t = 0; t < l[e]; t++) g.add(d[r] + t);
		});
	}
	e.forEach((e, t) => {
		let r = h.get(t);
		for (let i = 0; i < l[t]; i++) {
			let a = u[t] + i;
			r === void 0 ? f[a] !== void 0 && g.has(f[a]) && (f[a] = void 0) : f[a] = d[r] + i, !n && !h.has(t) && (p.get(e.text)?.length ?? 0) > 1 && p.get(e.text)?.length !== m.get(e.text)?.length && (f[a] = void 0);
		}
	});
	let _ = /* @__PURE__ */ new Map();
	t.forEach((e, t) => {
		for (let e = 0; e < c[t]; e++) _.set(d[t] + e, {
			block: t,
			offset: e
		});
	});
	let v = new Map(e.map((e, t) => [e.id, t])), y = a.every((e, t) => f[t] !== void 0 && f[t] === f[0] + t), b = (e, t) => {
		let n = 0, r = 0;
		for (; t && (r = e.indexOf(t, r)) >= 0;) n++, r++;
		return n;
	}, x = (e) => !n && e && b(i, e) > 1 && b(r, e) !== b(i, e), S = /* @__PURE__ */ new Map();
	e.forEach((e, n) => {
		if (h.has(n)) {
			S.set(n, h.get(n));
			return;
		}
		let r = /* @__PURE__ */ new Map();
		for (let e = 0; e < l[n]; e++) {
			let t = f[u[n] + e], i = t === void 0 ? void 0 : _.get(t);
			i && r.set(i.block, (r.get(i.block) ?? 0) + 1);
		}
		let i = [...r].sort((e, t) => e[0] - t[0])[0];
		i ? S.set(n, i[0]) : t.some((t) => t.id === e.id) && S.set(n, t.findIndex((t) => t.id === e.id));
	});
	let C = (e, t) => {
		if (e < 0 || t < e || t > a.length) return;
		if (e === t) return f[e] === void 0 ? e > 0 && f[e - 1] !== void 0 ? {
			start: f[e - 1] + 1,
			end: f[e - 1] + 1
		} : void 0 : {
			start: f[e],
			end: f[e]
		};
		let n = f[e];
		if (n !== void 0) {
			for (let r = e + 1; r < t; r++) if (f[r] !== n + r - e) return;
			return {
				start: n,
				end: n + t - e
			};
		}
	};
	return {
		blocks: t,
		block: (e) => {
			let n = v.get(e), r = n === void 0 ? void 0 : S.get(n);
			return r === void 0 ? void 0 : t[r]?.id;
		},
		lineRange: (e, t) => {
			let o = a.slice(e, t).join("");
			if (!x(o) && !(!n && o && r !== i && i.indexOf(o, i.indexOf(o) + 1) >= 0 && r.indexOf(o, r.indexOf(o) + 1) < 0) && !(!n && !y && o && r.indexOf(o, r.indexOf(o) + 1) >= 0)) return C(e, t);
		},
		range: (e, a, o) => {
			let c = v.get(e);
			if (c === void 0 || o > l[c]) return;
			let f = s[c].slice(a, o).join("");
			if (!h.has(c) && x(f) || !n && !h.has(c) && f && r !== i && i.indexOf(f, i.indexOf(f) + 1) >= 0 && r.indexOf(f, r.indexOf(f) + 1) < 0 || !n && !y && !h.has(c) && f && r.indexOf(f, r.indexOf(f) + 1) >= 0) return;
			let p = C(u[c] + a, u[c] + o);
			if (!p) return;
			let m = _.get(p.start) ?? (a === o ? _.get(p.start - 1) : void 0), g = _.get(p.end - 1) ?? m;
			if (!m || !g || m.block !== g.block) return;
			let b = p.start - d[m.block];
			return {
				blockId: t[m.block].id,
				start: b,
				end: b + o - a
			};
		}
	};
}
function Uo(e, t, n, r, i) {
	if (e.entityId !== t || e.sourceVersionId && e.sourceVersionId !== i || e.positionStatus === "unresolved") return e;
	let a = n.find((t) => t.id === e.blockId);
	if (!a && e.lineId !== t) return e;
	let o = typeof e.start == "number" && typeof e.end == "number";
	if (o) {
		let t = a ? r.range(a.id, e.start, e.end) : r.lineRange(e.start, e.end);
		if (t) return t.start === e.start && t.end === e.end && (!a || "blockId" in t && t.blockId === e.blockId) ? e : {
			...e,
			...a ? t : {
				start: t.start,
				end: t.end
			}
		};
	} else if (a) {
		let t = r.block(a.id);
		if (t) return t === e.blockId ? e : {
			...e,
			blockId: t
		};
	} else return e;
	let s = {
		...e,
		positionStatus: "unresolved",
		positionReason: Lo,
		quotedText: o ? Array.from(a?.text ?? Ro(n)).slice(e.start, e.end).join("") : a?.text ?? ""
	};
	if (delete s.start, delete s.end, a) {
		let e = r.block(a.id);
		e ? s.blockId = e : delete s.blockId;
	}
	return s;
}
function Wo(e) {
	return Array.isArray(e) && e.length > 0 && e.every((e) => e && typeof e == "object" && typeof e.id == "string" && typeof e.text == "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(e.kind));
}
function Go(e, t) {
	let n = e.data, r = t.data, i = Object.entries(n).flatMap(([e, t]) => {
		let n = r[e];
		if (!Wo(t) || !Array.isArray(n) || JSON.stringify(t) === JSON.stringify(n)) return [];
		let i = [], a = n;
		for (let e = 0; e < 64; e++) {
			let e = zo.get(a);
			if (!e) break;
			if (i.unshift({
				before: e.before,
				transform: e.transform
			}), JSON.stringify(e.before) === JSON.stringify(t)) return i;
			a = e.before;
		}
		return [{
			before: t,
			transform: Ho(t, n)
		}];
	});
	if (!i.length) return;
	let a = (t) => {
		if (Array.isArray(t)) {
			let e = t.map(a);
			return e.some((e, n) => e !== t[n]) ? e : t;
		}
		if (!t || typeof t != "object") return t;
		let n = t, r = t;
		if (typeof n.entityId == "string") for (let t of i) r = Uo(r, e.id, t.before, t.transform, e.projectId);
		let o = r, s = Object.entries(o).map(([e, t]) => [e, a(t)]);
		return s.some(([e, t]) => t !== o[e]) ? Object.fromEntries(s) : r;
	};
	return a;
}
function Ko(e, t, n) {
	let r = Go(t, n);
	if (!r) return e;
	let i = Object.entries(t.data).flatMap(([e, t]) => {
		let r = n.data[e];
		return Wo(t) && Array.isArray(r) && JSON.stringify(t) !== JSON.stringify(r) ? [{
			before: t,
			transform: Ho(t, r)
		}] : [];
	});
	return e.map((e) => {
		let n = e.kind === "review" && e.data.targetVersionId !== t.projectId, a = e.data, o = n ? Object.entries(a).map(([e, t]) => [e, e === "target" ? t : r(t)]) : void 0, s = o ? o.some(([e, t]) => t !== a[e]) ? Object.fromEntries(o) : a : r(a);
		if (e.id === t.id && e.kind === "scene" && e.data.blockIds?.length) {
			let t = [...new Set(e.data.blockIds.map((t) => r({
				entityId: e.id,
				blockId: t
			}).blockId ?? t))];
			(t.some((t, n) => t !== e.data.blockIds[n]) || t.length !== e.data.blockIds.length) && (s = {
				...s,
				blockIds: t
			});
		}
		if (e.kind === "projection_profile" && (!e.data.sourceVersionId || e.data.sourceVersionId === t.projectId)) {
			let t = { ...e.data.blockSources }, n = !1;
			for (let [e, r] of Object.entries(t)) for (let a of i) if (a.before.some((e) => e.id === r)) {
				n = !0;
				let i = a.transform.block(r);
				i ? t[e] = i : delete t[e];
			}
			if (n) return {
				...e,
				status: "needs_review",
				data: {
					...s,
					blockSources: t
				}
			};
		}
		return s === a ? e : {
			...e,
			data: s
		};
	});
}
function qo(e, t, n) {
	let r = Go(t, n);
	return r ? e.map((e) => {
		let t = r(e.validity);
		return t === e.validity ? e : {
			...e,
			validity: t
		};
	}) : e;
}
//#endregion
//#region src/domain/changeReviews.ts
var Jo = "changeReview.generatedBy", Yo = "changeReview.key", Xo = "changeReview.sourceIds", Zo = "changeReview.sourceRevisions", Qo = "changeReview.projectRevision", $o = "changeReview.paths", es = "semantic-change-review/v1", ts = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]), ns = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]), rs = /* @__PURE__ */ new Set(["reference"]);
function is(e) {
	try {
		return (BigInt(e) + 1n).toString();
	} catch {
		return e;
	}
}
function as(e) {
	return typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? `[${e.map(as).join(",")}]` : `{${Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${JSON.stringify(e)}:${as(t)}`).join(",")}}`;
}
function os(e, t) {
	if (ts.has(e.kind) || e.kind === "group" && e.data.groupType === "category") return;
	let n = { ...e.data };
	return (e.kind === "character" || e.kind === "place" || e.kind === "lore") && (delete n.reading, delete n.aliases), (e.kind === "localization" || e.kind === "recording") && (delete n.stage, delete n.reviewedBy), e.kind === "media_variant" && delete n.needsReview, e.kind === "attachment" && (delete n.displayName, delete n.licenseNote, delete n.byteSize), e.kind === "source" && delete n.accessedAt, as({
		deleted: t,
		data: n,
		customValues: e.customValues
	});
}
function ss(e, t) {
	let n = new Map(t.entities.map((e) => [e.id, e])), r = [];
	for (let t of e.entities) {
		let e = n.get(t.id);
		if (t.deletedAt && (!e || e.deletedAt) || e === t || e && e.kind !== t.kind) continue;
		let i = os(t, !!t.deletedAt), a = e ? os(e, !!e.deletedAt) : os(t, !0);
		i && a && i !== a && r.push({
			source: e ?? t,
			sourceRevision: is(t.revision)
		});
	}
	return r;
}
function cs(e) {
	return e.deletedAt || ns.has(e.kind) ? !1 : e.kind !== "group" || e.data.groupType !== "category";
}
function ls(e, t, n = "data") {
	if (!e || typeof e != "object") return [];
	if (Array.isArray(e)) return e.flatMap((e, r) => ls(e, t, `${n}[${r}]`));
	let r = e;
	return typeof r.entityId == "string" && typeof r.sourceVersionId == "string" && r.sourceVersionId !== t ? [n] : Object.entries(r).flatMap(([e, r]) => ls(r, t, `${n}.${e}`));
}
function us(e, t) {
	return as({
		targetId: e,
		sources: t.map((e) => ({
			id: e.source.id,
			revision: e.sourceRevision,
			directPaths: [...new Set(e.directPaths)].sort(),
			relationLabels: [...new Set(e.relationLabels)].sort()
		})).sort((e, t) => e.id.localeCompare(t.id))
	});
}
function ds(e) {
	let { source: t, sourceRevision: n, directPaths: r, relationLabels: i } = e, a = [];
	return r.length && a.push(`IDで直接参照しています（${[...new Set(r)].sort().join("、")}）`), i.length && a.push(`作者が設定した関係「${[...new Set(i)].sort().join("・")}」でつながっています`), `変更元: ${se[t.kind]}「${t.name || "無題"}」 (${t.id})。改訂 ${t.revision} → ${n}。${a.join("。")}`;
}
function fs(e) {
	return new Set(e.entities.flatMap((e) => e.kind === "review" && !e.deletedAt && e.customValues[Jo] === es && typeof e.customValues[Yo] == "string" ? [e.customValues[Yo]] : []));
}
function ps(e, t) {
	if (e.projectId !== t.projectId) return t;
	let n = ss(e, t);
	if (!n.length) return t;
	let r = t.entities.filter(cs), i = new Map(r.map((e) => [e.id, e])), a = /* @__PURE__ */ new Map(), o = new Map(n.map((e) => [e.source.id, e]));
	for (let e of r) {
		let n = /* @__PURE__ */ new Map(), r = ls(e.data, t.projectId);
		for (let t of N(e)) {
			if (r.some((e) => t.path === e || t.path.startsWith(e + "."))) continue;
			let i = o.get(t.id);
			if (!i || e.id === i.source.id) continue;
			let a = n.get(t.id) ?? /* @__PURE__ */ new Set();
			a.add(t.path), n.set(t.id, a);
		}
		if (!n.size) continue;
		let i = a.get(e.id) ?? /* @__PURE__ */ new Map();
		for (let [e, t] of n) {
			let n = o.get(e);
			i.set(e, {
				...n,
				directPaths: [...t],
				relationLabels: []
			});
		}
		a.set(e.id, i);
	}
	for (let e of t.relations) if (!(e.deletedAt || e.status === "rejected" || rs.has(e.relationType))) for (let t of new Set([e.fromId, e.toId].filter((e) => o.has(e)))) {
		let n = e.fromId === t ? e.toId : e.fromId, r = i.get(n), s = o.get(t);
		if (!r || !s || r.id === t) continue;
		let c = a.get(r.id) ?? /* @__PURE__ */ new Map(), l = c.get(t) ?? {
			...s,
			directPaths: [],
			relationLabels: []
		};
		l.relationLabels.push(te[e.relationType] ?? e.relationType), c.set(t, l), a.set(r.id, c);
	}
	let s = fs(t), c = is(t.revision), l = [];
	for (let [e, n] of a) {
		let r = i.get(e);
		if (!r) continue;
		let a = [...n.values()].sort((e, t) => e.source.id.localeCompare(t.source.id)), o = us(r.id, a);
		if (s.has(o)) continue;
		s.add(o);
		let u = a.map(ds), d = [
			`「${r.name || se[r.kind]}」に関係する情報が変更されました。内容への影響を確認してください。`,
			...u,
			`確認対象の作品改訂: ${t.revision} → ${c}。候補は人による確認用です。本文や設定は自動変更していません。`
		].join("\n"), f = C(t.projectId, "review", `変更確認: ${r.name || se[r.kind]}`, {
			target: r.id,
			targetVersionId: t.projectId,
			body: x(d),
			stage: "open",
			quotedText: null,
			resolution: []
		});
		f.status = "needs_review", f.visibility = "private", f.customValues = {
			...f.customValues,
			[Jo]: es,
			[Yo]: o,
			[Xo]: JSON.stringify(a.map((e) => e.source.id)),
			[Zo]: JSON.stringify(Object.fromEntries(a.map((e) => [e.source.id, e.sourceRevision]))),
			[Qo]: c,
			[$o]: JSON.stringify(Object.fromEntries(a.map((e) => [e.source.id, {
				directPaths: [...new Set(e.directPaths)].sort(),
				relationLabels: [...new Set(e.relationLabels)].sort()
			}])))
		}, l.push(f);
	}
	return l.length ? {
		...t,
		entities: [...t.entities, ...l]
	} : t;
}
//#endregion
//#region src/storage/importWorkSession.ts
function ms() {
	let e, t = !1, n = 0, r, i = () => new z("CANCELLED", "復元の確認を取り消しました。既存作品と元ファイルは変更していません。"), a = () => {
		t || (t = !0, e?.terminate(), r?.finish(i()));
	};
	return {
		run: async (o, s = {}) => {
			let { signal: c, loadAsset: l } = s;
			if (B(c), t) throw i();
			if (r) throw new z("SAVE_FAILED", "復元の確認処理が既に実行中です。");
			if (typeof window > "u" || typeof Worker > "u") return io(to(structuredClone(o)), c, l);
			e ??= new Worker(new URL(
				/* @vite-ignore */
				"/__large-history/assets/archive.worker-D-2ZmHu8.js",
				"" + import.meta.url
			), { type: "module" });
			let u = e, d = ++n;
			return new Promise((e, n) => {
				let s = !0, f = (t, i) => {
					s && (s = !1, c?.removeEventListener("abort", p), r?.id === d && (r = void 0), t ? (a(), n(t)) : e(i));
				}, p = () => f(i());
				r = {
					id: d,
					finish: f
				}, u.onmessage = (e) => {
					let n = e.data;
					if (s && !t && n.requestId === d) {
						if (n.type === "done") try {
							B(c), f(void 0, n.result);
						} catch (e) {
							f(e);
						}
						else n.type === "error" ? f(Object.assign(new z(n.error.code, n.error.message, n.error.path), { issues: n.error.issues ?? [] })) : n.type === "asset" && Promise.resolve().then(() => (B(c), l?.(n.hash))).then((e) => {
							if (!s || t || c?.aborted) return;
							let r = e?.slice();
							u.postMessage({
								type: "import-asset",
								id: n.id,
								bytes: r
							}, r ? [r.buffer] : []);
						}).catch((e) => {
							if (!s || t || c?.aborted) return;
							let r = S(e);
							u.postMessage({
								type: "import-asset",
								id: n.id,
								error: {
									code: r.code,
									message: r.message,
									path: r.path,
									issues: e?.issues
								}
							});
						});
					}
				}, u.onerror = () => f(new z("SAVE_FAILED", "復元の確認処理を完了できませんでした。既存作品と元ファイルは保持しています。")), c?.addEventListener("abort", p, { once: !0 });
				try {
					B(c), u.postMessage({
						type: "import-work",
						requestId: d,
						work: o
					});
				} catch (e) {
					f(e);
				}
			});
		},
		dispose: a
	};
}
//#endregion
//#region src/storage/newImportSession.ts
function hs(e, t, n) {
	B(n);
	let r = new Worker(new URL(
		/* @vite-ignore */
		"/__large-history/assets/archive.worker-D-2ZmHu8.js",
		"" + import.meta.url
	), { type: "module" });
	return new Promise((i, a) => {
		let o = !0, s = () => new z("CANCELLED", "復元の確認を取り消しました。既存作品と元ファイルは変更していません。"), c = (e, t) => {
			o && (o = !1, n?.removeEventListener("abort", l), r.terminate(), e ? a(e) : i(t));
		}, l = () => c(s());
		r.onmessage = (e) => {
			let i = e.data;
			if (o && i.requestId === 1) {
				if (i.type === "done") try {
					B(n), c(void 0, i.result);
				} catch (e) {
					c(e);
				}
				else i.type === "error" ? c(Object.assign(new z(i.error.code, i.error.message, i.error.path), { issues: i.error.issues ?? [] })) : i.type === "new-import-callback" && Promise.resolve().then(async () => {
					switch (B(n), i.action) {
						case "stage": return t.stage(i.input);
						case "preview": return t.preview();
						case "assets": return t.assets();
						case "finalize": return t.finalize(i.input);
						default: throw new z("FORMAT_UNSUPPORTED", "読み込みの確認工程が未対応です。");
					}
				}).then((e) => {
					o && (B(n), r.postMessage({
						type: "new-import-callback-result",
						requestId: 1,
						id: i.id,
						result: e
					}));
				}).catch((e) => {
					if (!o) return;
					let t = S(e);
					c(Object.assign(t, { issues: e?.issues ?? [] }));
				});
			}
		}, r.onerror = () => c(new z("SAVE_FAILED", "復元の確認処理を完了できませんでした。既存作品と元ファイルは保持しています。")), n?.addEventListener("abort", l, { once: !0 });
		try {
			B(n), r.postMessage({
				type: "new-import",
				requestId: 1,
				input: e
			});
		} catch (e) {
			c(e);
		}
	});
}
//#endregion
//#region src/storage/store.ts
var gs = Object.freeze({ present: !1 }), _s = 4, vs = class extends W {
	sharedSnapshots;
	projects;
	projectSummaries;
	worldSources;
	entities;
	relations;
	blocks;
	snapshots;
	commands;
	outbox;
	assets;
	views;
	viewStates;
	syncMetadata;
	acks;
	restorePoints;
	worlds;
	importLogs;
	importDrafts;
	authorToolDrafts;
	workspaceInputs;
	recoveredPending;
	retainedSyncRecovery;
	syncAssetAcks;
	syncBases;
	preparedSync;
	syncConflicts;
	syncAckEvidence;
	constructor(e) {
		super(e), this.version(1).stores({
			projects: "projectId,name",
			entities: "[projectId+id],projectId,[projectId+kind]",
			relations: "[projectId+id],projectId,[projectId+fromId],[projectId+toId]",
			blocks: "[projectId+id],projectId,[projectId+entityId]",
			snapshots: "[projectId+id],projectId",
			commands: "operationId,projectId,[projectId+revision]",
			outbox: "operationId,projectId,accountId",
			assets: "contentHash",
			views: "[projectId+id],projectId",
			viewStates: "key,projectId",
			syncMetadata: "projectId",
			acks: "operationId,projectId",
			restorePoints: "id,projectId,createdAt",
			worlds: "id",
			importLogs: "operationId,projectId"
		}), this.version(2).stores({ importDrafts: "key" }), this.version(3).stores({ recoveredPending: "key,projectId" }), this.version(4).stores({ authorToolDrafts: "key,projectId" }), this.version(5).stores({
			syncBases: "projectId",
			preparedSync: "operationId,projectId",
			syncConflicts: "operationId,projectId",
			syncAckEvidence: "operationId,projectId",
			retainedSyncRecovery: "key,projectId",
			syncAssetAcks: "key,projectId",
			sharedSnapshots: "id,createdAt"
		}), this.version(6).stores({ workspaceInputs: "key" }), this.version(7).stores({ recordParts: "key,scope" }), this.version(8).stores({
			projectSummaries: "projectId",
			worldSources: "id,projectId"
		}), wo(this), so(this);
	}
}, Z = (e) => (L("copy.calls"), D("copy.payloadBytes", e), ie("copy", () => structuredClone(e))), Q = (e, t) => e === t || g(e ?? null, t ?? null), ys = /* @__PURE__ */ new WeakSet(), bs = m((e) => ys.has(e)), xs = (e) => E(e, bs);
function Ss(e) {
	if (e && typeof e == "object" && !ys.has(e)) {
		for (let t of Object.keys(e)) {
			let n = e[t];
			n && typeof n == "object" && Ss(n);
		}
		Object.freeze(e), ys.add(e);
	}
	return e;
}
function Cs(e) {
	return {
		...Z(ks(e)),
		history: e.history
	};
}
function ws(e) {
	L("capture.calls"), D("capture.payloadBytes", ks(e));
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object") return typeof e == "function" ? Z(e) : e;
		if (ys.has(e)) return e;
		if (t.has(e)) return t.get(e);
		if (!Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return Z(e);
		let r = Array.isArray(e) ? Array(e.length) : {};
		t.set(e, r);
		for (let t of Object.keys(e)) Object.defineProperty(r, t, {
			value: n(e[t]),
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		return r;
	};
	return {
		...n(ks(e)),
		history: e.history
	};
}
function Ts(e, t) {
	L("contentDelta.rows", e.entities.length + e.relations.length + t.entities.length + t.relations.length);
	let n = (e, t) => {
		let n = new Map(e.map((e) => [e.id, e])), r = new Map(t.map((e) => [e.id, e]));
		return [.../* @__PURE__ */ new Set([...n.keys(), ...r.keys()])].flatMap((e) => Q(n.get(e) ?? null, r.get(e) ?? null) ? [] : [{
			id: e,
			record: r.get(e) ?? null
		}]);
	}, r = Hs(e), i = Hs(t), a = {};
	for (let e of Object.keys(i)) e !== "id" && e !== "kind" && !Q(r[e], i[e]) && (a[e] = i[e]);
	let o = (e, t) => e.length === t.length && e.every((e, n) => e.id === t[n].id) ? void 0 : t.map((e) => e.id);
	return {
		header: a,
		entities: n(e.entities, t.entities),
		relations: n(e.relations, t.relations),
		entityIds: o(e.entities, t.entities),
		relationIds: o(e.relations, t.relations)
	};
}
function Es(e, t) {
	let n = (e, t, n) => {
		if (!t.length && !n) return e;
		let r = new Map(e.map((e) => [e.id, e]));
		for (let e of t) e.record ? r.set(e.id, e.record) : r.delete(e.id);
		return (n ?? [...r.keys()]).map((e) => {
			let t = r.get(e);
			if (!t) throw new z("SAVE_FAILED", "履歴の差分に必要な情報が不足しています。", e);
			return t;
		});
	};
	return {
		...e,
		...t.header,
		entities: n(e.entities, t.entities, t.entityIds),
		relations: n(e.relations, t.relations, t.relationIds)
	};
}
async function Ds(e, t) {
	B(t);
	let n = Z(e), r = [], i = await o(n, t), a = Qa(), s;
	for (let [e, o] of n.entries()) {
		B(t);
		let n = {
			operationId: o.operationId,
			projectId: o.projectId,
			revision: o.revision
		}, c = {
			...n,
			record: o
		};
		if (i && o.before.projectId === o.projectId && o.after.projectId === o.projectId && o.before.revision === o.baseRevision && o.after.revision === o.revision) {
			let t = Object.fromEntries(Object.entries(o).map(([e, t]) => [e, e === "before" || e === "after" ? void 0 : t])), r = Ts(o.before, o.after), i = Es(o.before, r);
			if (Object.freeze(i.entities), Object.freeze(i.relations), Object.freeze(i), a(o, Object.freeze({
				...t,
				before: o.before,
				after: i
			}))) {
				let i = e % 64 != 0 && s && a(s.after, o.before) ? s.operationId : void 0;
				c = {
					...n,
					delta: {
						metadata: t,
						...i ? { parentOperationId: i } : { checkpoint: o.before },
						patch: r
					}
				};
			}
		}
		r.push({
			record: o,
			stored: c
		}), s = o, await new Promise((e) => setTimeout(e, 0));
	}
	return B(t), r;
}
var Os = (e) => (BigInt(e) + 1n).toString(), ks = ({ history: e, ...t }) => t, As = (e) => {
	let t = {
		...ks(e),
		entities: [],
		relations: [],
		snapshots: [],
		views: [],
		revision: "0"
	};
	return e.authorAlternatives?.length ? t.authorAlternatives = [] : delete t.authorAlternatives, t;
};
function js(e, t = {}) {
	let n = d(e, { worldSnapshots: t });
	if (!n.ok) throw Object.assign(new z("VALIDATION_FAILED", n.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: n.issues });
	return b(n.value), n.value;
}
function Ms(e, t, n, r = /* @__PURE__ */ new WeakMap()) {
	let i = ie("validate.current", () => l(e, { worldSnapshots: t }, n ? {
		previous: n,
		references: r
	} : void 0));
	if (!i.ok) {
		let e = new z("VALIDATION_FAILED", i.issues.map((e) => `${e.path}: ${e.message}`).join("\n"));
		throw Object.assign(e, { issues: i.issues }), e;
	}
	return e;
}
async function Ns(e, t = {}, n = e.history.length > 0, r) {
	let i = await _n(e, { worldSnapshots: t }, n, r);
	if (i.length) throw Object.assign(new z("VALIDATION_FAILED", i.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: i });
}
function Ps(e) {
	return Object.fromEntries(Object.entries(e).filter(([e]) => !["revision", "updatedAt"].includes(e)));
}
function Fs(e, t, n, r) {
	L("normalize.rows", e.length + t.length);
	let i = new Map(e.map((e) => [e.id, e])), a = t.map((e) => {
		let t = i.get(e.id);
		if (t && "kind" in t && "kind" in e && t.kind !== e.kind) throw new z("OPERATION_CONFLICT", "既存IDを別の種類へ再利用できません。", e.id);
		if (!t) return Z(e);
		if ("createdAt" in t && "createdAt" in e && t.createdAt !== e.createdAt) throw new z("OPERATION_CONFLICT", "既存IDの作成日時は変更できません。", e.id);
		return Q(t, e) || Q(Ps(t), Ps(e)) ? t : {
			...Z(e),
			revision: Os(t.revision),
			..."updatedAt" in e ? { updatedAt: r } : {}
		};
	}), o = new Set(t.map((e) => e.id));
	for (let t of e) o.has(t.id) || a.push(t.deletedAt ? t : {
		...Z(t),
		deletedAt: r,
		deletionOperationId: n,
		revision: Os(t.revision),
		..."updatedAt" in t ? { updatedAt: r } : {}
	});
	return a;
}
function Is(e, t) {
	for (let n of e.snapshots) {
		let e = t.snapshots.find((e) => e.id === n.id);
		if (!e || !g(n, e)) throw new z("IMMUTABLE_SNAPSHOT", "公開済み・保存済みの不変snapshotは変更や削除ができません。", n.id);
	}
	for (let n of e.entities.filter((e) => e.kind === "snapshot")) {
		let e = t.entities.find((e) => e.id === n.id);
		if (!e || !g(n, e)) throw new z("IMMUTABLE_SNAPSHOT", "不変snapshotは変更や削除ができません。", n.id);
	}
}
function Ls(e, t, n) {
	let r = Math.min(e.length, t.length);
	for (let i = 0; i < r; i++) if (!Q(e[i], t[i])) throw new z("VALIDATION_FAILED", `${n}の既存記録は変更できません。`);
	return t.length < e.length;
}
async function Rs(e, t) {
	let n = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e])), r = new Map((t.authorAlternatives ?? []).map((e) => [e.id, e])), i = [];
	for (let e of n.values()) {
		let t = r.get(e.id);
		if (!t) {
			i.push(await $t({
				...Z(e),
				status: "rejected",
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			}));
			continue;
		}
		if (t.projectId !== e.projectId || t.baseRevision !== e.baseRevision || (t.sourceSnapshotId ?? null) !== (e.sourceSnapshotId ?? null) || t.createdAt !== e.createdAt || !Q(t.baseContent, e.baseContent) || t.baseContentHash !== e.baseContentHash) throw new z("VALIDATION_FAILED", "別案の分岐元と識別情報は変更できません。", e.id);
		let n = Ls(e.versions, t.versions, "別案の版"), a = Ls(e.applyReceipts, t.applyReceipts, "正本採用履歴"), o = t.versions.find((e) => e.id === t.headVersionId);
		if (!o) throw new z("VALIDATION_FAILED", "別案の現在版が見つかりません。", e.id);
		if (!(n || a || t.headVersionId !== t.versions.at(-1)?.id)) {
			i.push(t);
			continue;
		}
		let s = {
			...Z(t),
			versions: Z(n ? e.versions : t.versions),
			applyReceipts: Z(a ? e.applyReceipts : t.applyReceipts)
		};
		if (n || s.headVersionId !== s.versions.at(-1)?.id) {
			let e = o.content, t = o.structurePlan, n = Date.parse(s.versions.at(-1)?.createdAt ?? ""), r = new Date(Math.max(Date.now(), Number.isFinite(n) ? n + 1 : 0)).toISOString();
			s = he(s, e, `「${o.label}」から復元`, r, _(), t);
		}
		i.push(await $t(s));
	}
	for (let e of r.values()) n.has(e.id) || i.push(e);
	t.authorAlternatives = i;
}
function zs(e, t) {
	let n = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e])), r = [];
	for (let e of t.authorAlternatives ?? []) {
		let t = n.get(e.id), i = new Set(t?.applyReceipts.map((e) => e.id) ?? []);
		for (let t of e.applyReceipts) i.has(t.id) || r.push({
			alternativeId: e.id,
			receipt: t
		});
	}
	if (!r.length) return;
	if (r.length !== 1) throw new z("VALIDATION_FAILED", "一回の保存では一件の作者別案採用を記録してください。");
	let { alternativeId: i, receipt: a } = r[0], o = n.get(i);
	if (!o || a.alternativeVersionId !== o.headVersionId || a.fromCanonicalRevision !== e.revision || a.appliedRevision !== Os(e.revision)) throw new z("VALIDATION_FAILED", "採用記録の正本版または別案版が保存元と一致しません。", i);
	let s;
	try {
		s = ge(e, o, [], new Set(a.selectedChangeKeys ?? []), a.createdAt, a.id);
	} catch (e) {
		throw new z("VALIDATION_FAILED", e instanceof Error ? e.message : "採用差分を再計算できません。", i);
	}
	let { appliedRevision: c, ...l } = a;
	if (!Q(l, s.receipt)) throw new z("VALIDATION_FAILED", "作者別案の採用差分が現在の正本・選択元版と一致しません。", i);
	let u = (e) => e.kind === "review" && e.customValues["changeReview.generatedBy"] === "semantic-change-review/v1" && typeof e.customValues["changeReview.key"] == "string" ? e.customValues["changeReview.key"] : void 0, d = new Set(e.entities.flatMap((e) => u(e) ?? [])), f = ps(e, s.project), p = (e) => e.entities.filter((e) => {
		let t = u(e);
		return t !== void 0 && !d.has(t);
	}), m = (e) => {
		let t = Z(e);
		if (delete t.id, delete t.createdAt, delete t.updatedAt, t.kind === "review") {
			let e = t.data;
			Array.isArray(e.body) && (e.body = e.body.map((e) => {
				let t = { ...e };
				return delete t.id, t;
			}));
		}
		return t;
	}, h = p(f).sort((e, t) => (u(e) ?? "").localeCompare(u(t) ?? "")), g = p(t).sort((e, t) => (u(e) ?? "").localeCompare(u(t) ?? "")), _ = (e, t) => {
		let n = new Set(t.map((e) => e.id));
		return {
			...be(e),
			entities: e.entities.filter((e) => !n.has(e.id))
		};
	}, v = Q(_(f, h), _(t, g)), y = h.length === g.length && h.every((e, t) => Q(m(e), m(g[t])));
	if (!v || !y) throw new z("VALIDATION_FAILED", "作者別案の採用差分が現在の正本・選択元版と一致しません。", i);
}
function Bs(e) {
	let t = [], n = (r) => {
		if (Array.isArray(r)) {
			if (r.length && r.every((e) => e && typeof e == "object" && "id" in e && "text" in e && [
				"paragraph",
				"heading",
				"list_item",
				"quote"
			].includes(e.kind))) {
				for (let n of r) t.push({
					id: n.id,
					projectId: e.projectId,
					entityId: e.id,
					block: Z(n)
				});
				return { __scenarioRichText: r.map((e) => e.id) };
			}
			return r.map(n);
		}
		return r && typeof r == "object" ? Object.fromEntries(Object.entries(r).map(([e, t]) => [e, k(e) ? Z(t) : n(t)])) : r;
	};
	return {
		record: n(e),
		blocks: t
	};
}
function Vs(e, t, n) {
	let r = (e) => {
		if (Array.isArray(e)) {
			let t;
			for (let n = 0; n < e.length; n++) {
				let i = r(e[n]);
				i !== e[n] && (t ??= e.slice(), t[n] = i);
			}
			return t ?? e;
		}
		if (e && typeof e == "object") {
			let i = e;
			if (Array.isArray(i.__scenarioRichText)) return i.__scenarioRichText.map((e) => {
				let r = t.get(e);
				if (!r) throw new z("SAVE_FAILED", "本文blockが不足しています。完全保存ファイルから復元してください。", e);
				return n.has(e) ? Z(r) : (n.add(e), r);
			});
			let a;
			for (let e of Object.keys(i)) {
				let t = r(i[e]);
				t !== i[e] && (a ??= { ...i }, a[e] = t);
			}
			return a ?? e;
		}
		return e;
	};
	return r(e);
}
function Hs(e) {
	let { entities: t, relations: n, ...r } = e;
	return {
		...r,
		id: e.projectId,
		kind: "project"
	};
}
async function Us(e, t, n = !1) {
	L("targetChanges.rows", e.entities.length + e.relations.length + t.entities.length + t.relations.length);
	let r = new Map([
		...e.entities,
		...e.relations,
		...n ? [] : [Hs(e)]
	].map((e) => [e.id, e])), i = new Map([
		...t.entities,
		...t.relations,
		Hs(t)
	].map((e) => [e.id, e])), a = [], o;
	for (let e of /* @__PURE__ */ new Set([...r.keys(), ...i.keys()])) {
		let n = r.get(e) ?? null, s = i.get(e) ?? null;
		if (e !== t.projectId && (n === s || Q(n ? Ps(n) : null, s ? Ps(s) : null))) continue;
		let c = [];
		for (let e of /* @__PURE__ */ new Set([...Object.keys(n ?? {}), ...Object.keys(s ?? {})])) {
			if (["revision", "updatedAt"].includes(e)) continue;
			let t = n && e in n ? {
				present: !0,
				value: n[e]
			} : gs, r = s && e in s ? {
				present: !0,
				value: s[e]
			} : gs;
			t.present && r.present && t.value === r.value || Q(t, r) || c.push({
				field: e,
				oldValueHash: t.present ? await A(xs(t)) : o ??= await A(xs(t)),
				before: t,
				after: r
			});
		}
		a.push({
			targetId: e,
			before: n,
			after: s,
			fields: c
		});
	}
	return a;
}
var Ws = class {
	derivedBudget;
	derivedOwners = /* @__PURE__ */ new Map();
	derivedIndexRetention() {
		return {
			owners: this.derivedOwners.size,
			...this.derivedBudget.snapshot()
		};
	}
	authorAccess = null;
	accessGeneration = 0;
	setAuthorAccess(e) {
		this.authorAccess = e ? new Map(Object.entries(e)) : null, this.accessGeneration++;
		for (let e of this.cacheEpochs.keys()) this.invalidateProjectCache(e);
	}
	async refreshAuthorAccess(e, t = {}) {
		let n = this.accessGeneration, r = this.cacheLifetime, { signal: i, isCurrent: a } = t;
		B(i);
		let o = await e();
		if (B(i), n !== this.accessGeneration || r !== this.cacheLifetime || a && !a()) throw new z("CANCELLED", "権限の確認中に読み込み先または権限が変わりました。");
		if (!o || Array.isArray(o) || Object.entries(o).some(([e, t]) => !M.test(e) || !["owner", "editor"].includes(t))) throw new U("PROTOCOL_INVALID");
		this.setAuthorAccess(o);
	}
	db;
	activeOperations = 0;
	get pendingOperations() {
		return this.activeOperations;
	}
	accountId;
	faultInjector;
	onSaveMetrics;
	cachedProjects = /* @__PURE__ */ new Map();
	contentHeads = /* @__PURE__ */ new Map();
	cachedHistoryIds = /* @__PURE__ */ new Map();
	completeHistories = /* @__PURE__ */ new Set();
	cacheEpochs = /* @__PURE__ */ new Map();
	cacheLifetime = 0;
	cachedEditorSources = /* @__PURE__ */ new WeakMap();
	editorSources = /* @__PURE__ */ new WeakMap();
	editingHistories = /* @__PURE__ */ new WeakMap();
	readBaselines = /* @__PURE__ */ new WeakMap();
	validationReferences = /* @__PURE__ */ new WeakMap();
	constructor(e = {}) {
		this.derivedBudget = new Ft(e.derivedIndexes === !1 ? { entries: 0 } : e.derivedIndexes), this.accountId = e.accountId ?? null, this.faultInjector = e.faultInjector, this.onSaveMetrics = e.onSaveMetrics, this.db = new vs(e.databaseName ?? (this.accountId ? `scenario-manager-account-${encodeURIComponent(this.accountId)}` : "scenario-manager-local-v1"));
		for (let e of [
			"saveProject",
			"importScenario",
			"putAsset",
			"commitPreparedAck",
			"confirmSyncResolution",
			"bindBootstrapBase",
			"bindConfirmedProject",
			"saveAuthorToolDraft",
			"saveImportDraft",
			"applyReceivedImage",
			"saveWorkspaceInputs",
			"restoreAuthorInputs",
			"restoreAuthorToolDrafts"
		]) {
			let t = this[e].bind(this);
			Object.defineProperty(this, e, {
				configurable: !0,
				writable: !0,
				value: async (...e) => {
					this.activeOperations++;
					try {
						return await t(...e);
					} finally {
						this.activeOperations--;
					}
				}
			});
		}
		for (let [e, t] of Object.entries({
			listProjectSummaries: "store.list",
			loadEditor: "store.read",
			listProjectsForEditing: "store.list",
			getProjectForEditing: "store.read",
			getProject: "store.fullRead",
			saveProject: "store.save",
			historyPage: "store.history",
			exportProject: "store.export",
			importScenario: "store.import",
			writeContent: "writeContent"
		})) {
			let n = this[e].bind(this);
			Object.defineProperty(this, e, {
				configurable: !0,
				writable: !0,
				value: (...e) => {
					if (!de()) return n(...e);
					let r = P(t);
					try {
						return n(...e).then((e) => (r(), e), (e) => {
							throw r("error"), e;
						});
					} catch (e) {
						throw r("error"), e;
					}
				}
			});
		}
	}
	get writeTables() {
		return [
			"projects",
			"projectSummaries",
			"worldSources",
			"entities",
			"relations",
			"blocks",
			"snapshots",
			"commands",
			"outbox",
			"assets",
			"views",
			"syncMetadata",
			"restorePoints",
			"worlds",
			"importLogs",
			"recoveredPending",
			"syncBases",
			"preparedSync",
			"syncConflicts",
			"syncAckEvidence",
			"retainedSyncRecovery",
			"syncAssetAcks"
		];
	}
	async guardWorldRegistry(e) {
		let t = /* @__PURE__ */ new Map();
		for (let n of [...(await this.db.worlds.toArray()).map((e) => e.project), ...e]) for (let e of n.snapshots) {
			let n = t.get(e.id);
			if (n && !Q(n, e)) throw new z("IMMUTABLE_SNAPSHOT", "固定版IDが別の保存済み内容と衝突しています。", e.id);
			t.set(e.id, e);
		}
	}
	close() {
		this.cacheLifetime++;
		for (let e of this.cacheEpochs.keys()) this.invalidateProjectCache(e);
		this.db.close(), this.measureCache();
	}
	async reopen() {
		await this.db.open();
	}
	async deleteDatabase() {
		this.close(), await this.db.delete();
	}
	invalidateProjectCache(e) {
		this.derivedOwners.get(e)?.close(), this.derivedOwners.delete(e), L("cache.invalidated"), this.cacheEpochs.delete(e), this.cachedProjects.delete(e), this.contentHeads.delete(e), this.cachedHistoryIds.delete(e), this.completeHistories.delete(e), this.measureCache();
	}
	captureCache(e, t = !1) {
		let n = this.cacheEpochs.get(e);
		return n || (n = { version: 0 }, this.cacheEpochs.set(e, n)), {
			project: n,
			...t ? {} : { version: n.version },
			lifetime: this.cacheLifetime,
			access: this.accessGeneration
		};
	}
	releaseCacheCapture(e, t) {
		!this.cachedProjects.has(e) && this.cacheEpochs.get(e) === t.project && this.cacheEpochs.delete(e), this.measureCache();
	}
	touchProject(e) {
		this.cachedProjects.get(e.projectId) === e && (this.cachedProjects.delete(e.projectId), this.cachedProjects.set(e.projectId, e));
	}
	measureCache() {
		if (de()) {
			T("cache.projects", this.cachedProjects.size), T("cache.heads", this.contentHeads.size), T("cache.histories", this.cachedHistoryIds.size), T("cache.completeHistories", this.completeHistories.size), T("cache.epochs", this.cacheEpochs.size), T("cache.records", [...this.cachedProjects.values()].reduce((e, t) => e + t.entities.length + t.relations.length, 0)), T("cache.payloadBytes", 0);
			for (let e of this.cachedProjects.values()) D("cache.payloadBytes", e);
		}
	}
	rememberProject(e, t, n = e.history.map((e) => e.operationId), r) {
		let i = this.cachedProjects.get(e.projectId), a = this.cacheEpochs.get(e.projectId);
		if (r && (r.project !== a || r.version !== void 0 && r.version !== a?.version || r.lifetime !== this.cacheLifetime || r.access !== this.accessGeneration) || i && BigInt(i.revision) > BigInt(e.revision)) return e;
		this.derivedOwners.get(e.projectId)?.close(), this.derivedOwners.delete(e.projectId);
		let o = Ss({
			...ks(e),
			history: Ss(e.history.map((e) => Ss(e)))
		});
		this.cachedProjects.delete(e.projectId), this.cachedProjects.set(e.projectId, o), this.contentHeads.set(e.projectId, t), this.cachedHistoryIds.set(e.projectId, n), Q(n, e.history.map((e) => e.operationId)) ? this.completeHistories.add(e.projectId) : this.completeHistories.delete(e.projectId);
		let s = a ?? { version: 0 };
		for (s.version++, this.cacheEpochs.set(e.projectId, s); this.cachedProjects.size > _s;) this.invalidateProjectCache(this.cachedProjects.keys().next().value);
		return this.measureCache(), o;
	}
	editingCopy(e, t = e.history.map((e) => e.operationId), n = !1) {
		let r = Ss([]);
		this.editingHistories.set(r, {
			projectId: e.projectId,
			revision: e.revision,
			historyIds: t
		});
		let i = {
			...n ? ks(e) : Z(ks(e)),
			history: r
		}, a = this.cachedProjects.get(e.projectId);
		if (n && a && this.derivedBudget.limits.entries) {
			let t = this.derivedOwners.get(e.projectId);
			t || (t = new It(a, this.derivedBudget, {
				accountId: this.accountId,
				roleGeneration: this.accessGeneration
			}), this.derivedOwners.set(e.projectId, t)), t.bind(i);
		}
		return i;
	}
	getHistoryCount(e) {
		return this.editingHistories.get(e.history)?.historyIds.length ?? e.history.length;
	}
	async materializeCommand(e, t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = !0) {
		let a = n.get(e.operationId);
		if (a) return a;
		if (e.record) return n.set(e.operationId, e.record), e.record;
		let o = e.delta;
		if (!o || r.has(e.operationId)) throw new z("SAVE_FAILED", "履歴の差分または復元点が破損しています。", e.operationId);
		r.add(e.operationId);
		let s = o.checkpoint;
		if (!s && o.parentOperationId) {
			let a = t.get(o.parentOperationId) ?? (i ? await this.db.commands.get(o.parentOperationId) : void 0);
			if (!a || a.projectId !== e.projectId) throw new z("SAVE_FAILED", "履歴の元の版が不足しています。", o.parentOperationId);
			s = (await this.materializeCommand(a, t, n, r, i)).after;
		}
		if (!s || s.projectId !== e.projectId || s.revision !== o.metadata.baseRevision) throw new z("SAVE_FAILED", "履歴の復元点と元の版が一致しません。", e.operationId);
		let c = {
			...o.metadata,
			before: s,
			after: Es(s, o.patch)
		};
		if (c.operationId !== e.operationId || c.projectId !== e.projectId || c.after.revision !== e.revision) throw new z("SAVE_FAILED", "履歴の差分と操作情報が一致しません。", e.operationId);
		return r.delete(e.operationId), n.set(e.operationId, c), c;
	}
	async readProject(e, t = !0, n, r, i) {
		let a = (e, t) => {
			if (!n) return t();
			let r = performance.now();
			return t().then((t) => (n[`database.${e}`] = performance.now() - r, t));
		}, o = r ?? await this.db.projects.get(e);
		if (!o) return;
		if (o.projectId !== e) throw new z("SAVE_FAILED", "作品の保存情報が別の作品を指しています。", e);
		let { entityIds: s, relationIds: c, snapshotIds: l, historyIds: u, viewIds: d, contentHeadOperationId: f, ...p } = o, m = async (t) => {
			let n = [], r = 8192, a;
			for (;;) {
				B(i);
				let o = await t.where("[projectId+id]").between([e, a ?? W.minKey], [e, W.maxKey], a === void 0, !0).limit(r).toArray();
				B(i);
				for (let e of o) n.push(e);
				if (o.length < r) return n;
				let s = o[o.length - 1].id;
				if (typeof s != "string" || !s || a !== void 0 && s <= a) throw new z("SAVE_FAILED", "作品の保存索引を順に読み取れません。保存済みデータを保持しています。", e);
				a = s;
			}
		}, [h, g, _, v, y, b] = await Promise.all([
			a("entities", () => m(this.db.entities)),
			a("relations", () => m(this.db.relations)),
			a("snapshots", () => m(this.db.snapshots)),
			t ? this.db.commands.bulkGet(u) : Promise.resolve([]),
			m(this.db.views),
			a("blocks", () => m(this.db.blocks))
		]), x = (e, t) => {
			let n = /* @__PURE__ */ new Map();
			for (let e of t) n.set(e.id, e);
			return e.map((e) => n.get(e));
		}, S = x(s, h), C = x(c, g), w = x(l, _), T = x(d, y);
		if ([
			S,
			C,
			w,
			v,
			T
		].some((e) => e.some((e) => !e))) throw new z("SAVE_FAILED", "作品の保存情報が不足しています。完全保存ファイルから復元してください。", e);
		let E = /* @__PURE__ */ new Map();
		for (let e of b) {
			if (!e.block || typeof e.block != "object" || e.block.id !== e.id) throw new z("SAVE_FAILED", "本文の保存索引と段落IDが一致しません。保存済みデータを保持しています。", e.id);
			E.set(e.id, e.block);
		}
		let D = new Map(v.map((e) => [e.operationId, e])), O = /* @__PURE__ */ new Map(), k = [];
		v.length && await W.waitFor((async () => {
			for (let e of v) B(i), k.push(await this.materializeCommand(e, D, O));
		})());
		let ee = n ? performance.now() : void 0, te = /* @__PURE__ */ new Set(), A = P("hydrate");
		L("hydrate.rows", S.length);
		let j = S.map((t) => {
			let n = t.record;
			if (!n || typeof n != "object" || Array.isArray(n) || n.id !== t.id || n.kind !== t.kind) throw new z("SAVE_FAILED", "情報の保存索引と本文のID・種別が一致しません。保存済みデータを保持しています。", t.id);
			if (n.projectId !== e) throw new z("VALIDATION_FAILED", "情報の本文が別の作品を指しています。保存済みデータを保持しています。", t.id);
			return Vs(n, E, te);
		});
		return A(), ee !== void 0 && (n["database.hydrate"] = performance.now() - ee), {
			historyIds: u,
			contentHeadOperationId: f,
			project: {
				...p,
				entities: j,
				relations: C,
				snapshots: w.map((e) => {
					let { projectId: t, ...n } = e;
					return n;
				}),
				history: k,
				views: T.map((e) => {
					let { projectId: t, ...n } = e;
					return n;
				})
			}
		};
	}
	async getProject(e, t = {}) {
		let n = t.signal, r = this.captureCache(e);
		try {
			B(n);
			let t = await this.db.transaction("r", this.writeTables, async () => {
				So(n), B(n);
				let t = await this.db.projects.get(e), r = this.cachedProjects.get(e);
				if (t) return r?.revision === t.revision && this.completeHistories.has(e) && Q(this.cachedHistoryIds.get(e), t.historyIds) ? {
					project: r,
					historyIds: t.historyIds,
					contentHeadOperationId: t.contentHeadOperationId
				} : this.readProject(e, !0, void 0, t, n);
			});
			if (B(n), !t) return;
			let { project: i } = t;
			if (i !== this.cachedProjects.get(e)) {
				let e = await this.validationWorlds({}, [i], n), a = za(e);
				await Mo({
					step: "full_read",
					project: i,
					worlds: a,
					knownWorlds: e
				}, { signal: n }), B(n), i = this.rememberProject(i, t.contentHeadOperationId, t.historyIds, r);
			}
			B(n), this.touchProject(i);
			let a = Cs(i);
			return this.readBaselines.set(a, {
				historyIds: t.historyIds,
				contentHeadOperationId: t.contentHeadOperationId
			}), a;
		} catch (e) {
			throw B(n), S(e);
		} finally {
			this.releaseCacheCapture(e, r);
		}
	}
	async getProjectForEditing(e, t = {}) {
		return this.readEditingProject(e, t, !1);
	}
	async readEditingProject(e, t, n) {
		let { signal: r, onStage: i, immutableView: a } = t, o = this.accessGeneration, s = this.cacheLifetime, c = () => {
			if (B(r), o !== this.accessGeneration || s !== this.cacheLifetime) throw new z("CANCELLED", "作品の閲覧権限または読み込み先が変わりました。");
		};
		c();
		let l, u = Oo(), d = {}, f = u, p = (e) => {
			if (f === void 0) return;
			let t = performance.now();
			d[e] = (d[e] ?? 0) + t - f, f = t;
		}, m = this.authorAccess && await this.db.syncBases.get(e) && this.authorAccess.get(e) !== "owner";
		if (B(r), m) return;
		let h = this.captureCache(e);
		try {
			let t = await this.db.transaction("r", this.writeTables, async () => {
				So(r), B(r);
				let t = u === void 0 ? void 0 : performance.now();
				if (n) {
					let t = await Rt(e);
					l = t ? await W.waitFor(zt(t)) : void 0;
				}
				let i = await this.db.projects.get(e), a = this.cachedProjects.get(e);
				if (t !== void 0 && (d["database.header"] = performance.now() - t), i) return a?.revision === i.revision && Q(this.cachedHistoryIds.get(e), i.historyIds) && (!n || a && this.cachedEditorSources.get(a) === l) ? {
					project: a,
					historyIds: i.historyIds,
					contentHeadOperationId: i.contentHeadOperationId
				} : this.readProject(e, !1, u === void 0 ? void 0 : d, i, r);
			});
			if (B(r), !t) return;
			p("database");
			let { project: f } = t;
			if (f !== this.cachedProjects.get(e)) {
				let e = n ? await this.editorWorlds(f, r) : await this.validationWorlds({}, [f], r);
				p("dependencies");
				let a = "transfer";
				await Eo(f, e, {
					signal: r,
					onStage: (e) => {
						p(a), a = `validation.${e}`, i?.(e);
					}
				}), p(a), B(r), c(), f = this.rememberProject(f, t.contentHeadOperationId, t.historyIds, h), p("immutable");
			}
			B(r), c(), l && this.cachedProjects.get(e) === f && this.cachedEditorSources.set(f, l), this.touchProject(f);
			let m = this.editingCopy(f, t.historyIds, a);
			return this.readBaselines.set(m, {
				historyIds: t.historyIds,
				contentHeadOperationId: t.contentHeadOperationId
			}), l && this.editorSources.set(m, {
				projectId: e,
				revision: f.revision,
				sourceHash: l,
				access: o,
				lifetime: s
			}), p("view"), Ao(u, f.projectId, d), m;
		} catch (e) {
			throw B(r), S(e);
		} finally {
			this.releaseCacheCapture(e, h);
		}
	}
	async listProjectSummaries(e = {}) {
		let { signal: t, onProgress: n } = e, r = this.accessGeneration, i = this.cacheLifetime, a = () => {
			if (B(t), r !== this.accessGeneration || i !== this.cacheLifetime) throw new z("CANCELLED", "作品一覧の読み込み先または権限が変わりました。");
		};
		a();
		let o = await this.db.projects.toCollection().primaryKeys(), s = [];
		n?.(0, o.length);
		for (let [e, r] of o.entries()) {
			a();
			let i = r, c = "0", l = {
				localSaved: !0,
				pendingCount: null,
				recoveredPendingCount: null,
				pendingAssetCount: "unloaded",
				serverRevision: null,
				syncState: "unloaded"
			};
			try {
				let e = await this.db.transaction("r", [
					"projects",
					"projectSummaries",
					"syncBases",
					"syncMetadata",
					"outbox",
					"recoveredPending"
				], async () => {
					if (this.authorAccess && await this.db.syncBases.where("projectId").equals(r).count() && this.authorAccess.get(r) !== "owner") return;
					let e = await Rt(r);
					if (!e) return;
					let t = await W.waitFor(zt(e)), n = await this.db.projectSummaries.get(r);
					i = typeof e.name == "string" ? e.name : r, c = typeof e.revision == "string" ? e.revision : "0";
					let a = await W.waitFor(Vt(n, r, t)), [o, s, l] = await Promise.all([
						this.db.outbox.where("projectId").equals(r).count(),
						this.db.recoveredPending.where("projectId").equals(r).count(),
						this.db.syncMetadata.get(r)
					]);
					return {
						sourceHash: t,
						row: a ? n : void 0,
						saveState: {
							localSaved: !0,
							pendingCount: o,
							recoveredPendingCount: s,
							pendingAssetCount: "unloaded",
							serverRevision: l?.serverRevision ?? "0",
							syncState: l?.state === "conflict" ? "conflict" : o || s || l?.state === "pending" ? "pending" : "unloaded"
						}
					};
				});
				if (a(), e) {
					l = e.saveState;
					let n = e.row;
					if (!n) {
						this.invalidateProjectCache(r);
						let i = await this.loadEditor(r, {
							signal: t,
							immutableView: !0
						});
						if (a(), !i) continue;
						n = await Bt(i, e.sourceHash), await this.db.transaction("rw", ["projects", "projectSummaries"], async () => {
							a();
							let t = await Rt(r);
							if (!t || await W.waitFor(zt(t)) !== e.sourceHash) throw new z("REVISION_CONFLICT", "一覧の確認中に作品が更新されました。再試行してください。");
							await this.db.projectSummaries.put(n), a(), this.faultInjector?.("before-commit");
						}), this.cachedProjects.get(r)?.revision === i.revision && this.invalidateProjectCache(r);
					}
					s.push({
						projectId: r,
						name: n.name,
						revision: n.revision,
						entityCount: n.entityCount,
						alternativeHeads: n.alternativeHeads,
						contentState: "unloaded",
						saveState: e.saveState
					});
				}
			} catch (e) {
				a();
				let t = S(e);
				s.push({
					projectId: r,
					name: i,
					revision: c,
					entityCount: null,
					contentState: "error",
					error: t.message,
					saveState: l
				});
			}
			a(), n?.(e + 1, o.length);
		}
		return a(), s;
	}
	async loadEditor(e, t = {}) {
		let { signal: n, expectedRevision: r, immutableView: i, onStage: a } = t, o = this.accessGeneration, s = this.cacheLifetime, c = () => {
			if (B(n), o !== this.accessGeneration || s !== this.cacheLifetime) throw new z("CANCELLED", "作品の読み込み先または権限が変わりました。");
		};
		if (c(), this.authorAccess && await this.db.syncBases.where("projectId").equals(e).count() && this.authorAccess.get(e) !== "owner") throw new z("CANCELLED", "この作品を編集する権限がありません。");
		c();
		let l = await this.readEditingProject(e, {
			signal: n,
			immutableView: i,
			onStage: a
		}, !0);
		if (c(), l) return await this.db.transaction("r", ["projects", "syncBases"], async () => {
			if (So(n), c(), this.authorAccess && await this.db.syncBases.get(e) && this.authorAccess.get(e) !== "owner") throw new z("CANCELLED", "作品の閲覧権限が変わりました。");
			let t = await Rt(e), i = this.editorSources.get(l), a = t ? await W.waitFor(zt(t)) : void 0;
			if (c(), !i || i.sourceHash !== a || r !== void 0 && r !== l.revision) throw BigInt(this.cachedProjects.get(e)?.revision ?? "0") <= BigInt(l.revision) && this.invalidateProjectCache(e), new z("REVISION_CONFLICT", "読み込み中に作品が更新されました。入力を保持して再試行してください。");
		}), c(), l;
	}
	releaseEditor(e) {
		this.invalidateProjectCache(e);
	}
	async listProjectsForEditing(e = {}) {
		let { signal: t, onProgress: n, onStage: r, immutableView: i } = e, a = {
			signal: t,
			onStage: r,
			immutableView: i
		};
		B(t);
		let o = await this.db.projects.toCollection().primaryKeys();
		B(t);
		let s = [];
		n?.(0, o.length);
		for (let [e, r] of o.entries()) {
			B(t);
			let i = await this.getProjectForEditing(r, a);
			B(t), i && s.push(i), n?.(e + 1, o.length);
		}
		return B(t), s;
	}
	async listProjects() {
		try {
			let e = await this.db.projects.toArray();
			return (await Promise.all(e.map((e) => this.getProject(e.projectId)))).filter((e) => !!e);
		} catch (e) {
			throw S(e);
		}
	}
	async listHistory(e) {
		return (await this.getProject(e))?.history ?? [];
	}
	async historyPage(e, t = {}) {
		let n = (t.query ?? "").normalize("NFKC").toLocaleLowerCase(), r = t.page ?? 0, i = t.size ?? 30;
		if (!Number.isSafeInteger(r) || r < 0 || !Number.isSafeInteger(i) || i < 1 || i > 60) throw new z("VALIDATION_FAILED", "履歴のページは0以上、ページ件数は1〜60です。");
		return this.db.transaction("r", ["projects", "commands"], async () => {
			let t = await this.db.projects.get(e);
			if (!t) throw new z("NOT_FOUND", "作品が見つかりません。");
			D("history.header.payloadBytes", t);
			let a = (await At(this.db, t.historyIds)).map((n, r) => {
				let i = n?.delta?.metadata ?? n?.record;
				if (!i || i.projectId !== e || i.operationId !== t.historyIds[r]) throw new z("SAVE_FAILED", "履歴の操作情報が不足しています。", t.historyIds[r]);
				let { before: a, after: o, ...s } = i;
				return s;
			}).reverse().filter((e) => !n || [
				e.reason,
				e.revision,
				e.baseRevision,
				e.operationId,
				e.createdAt,
				...e.targetIds
			].some((e) => e.normalize("NFKC").toLocaleLowerCase().includes(n))), o = Math.max(0, Math.ceil(a.length / i) - 1), s = Math.min(r, o);
			return {
				entries: a.slice(s * i, (s + 1) * i),
				page: s,
				maximum: o,
				total: a.length,
				size: i
			};
		});
	}
	async historyCommand(e, t) {
		let n = await this.db.projects.get(e), r = await this.db.commands.get(t);
		if (!n?.historyIds.includes(t) || !r || r.projectId !== e) throw new z("NOT_FOUND", "この作品の履歴操作が見つかりません。", t);
		return Z(await this.materializeCommand(r));
	}
	async validationWorlds(e = {}, t, n) {
		if (t) return this.dependencyWorlds(t, n);
		let r = await this.db.worlds.toArray(), i = Object.fromEntries(r.map((e) => [e.id, e.project]));
		for (let [t, n] of Object.entries(e)) i[t] = n;
		return i;
	}
	async listWorldSourceSummaries(e = {}) {
		let { signal: t } = e, n = this.accessGeneration, r = this.cacheLifetime, i = () => {
			if (B(t), n !== this.accessGeneration || r !== this.cacheLifetime) throw new z("CANCELLED", "共通世界一覧の読み込み先が変わりました。");
		};
		i();
		let a = await this.db.worlds.toCollection().primaryKeys(), o = /* @__PURE__ */ new Map(), s = [];
		for (let e of a) {
			let n;
			i();
			try {
				let r = await this.db.worldSources.get(e);
				if (!await Ut(r, e)) {
					let a = await this.db.transaction("r", ["worlds"], async () => (So(t), this.db.worlds.get(e)));
					if (i(), !a) continue;
					typeof a.project?.projectId == "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(a.project.projectId) && (n = a.project.projectId);
					let o = {
						...await this.editorWorlds(a.project, t),
						[e]: a.project
					};
					await Eo(a.project, o, { signal: t }), i(), r = await Ht(e, a.project), await this.db.transaction("rw", ["worlds", "worldSources"], async () => {
						So(t), i();
						let n = await this.db.worlds.get(e);
						if (!n || !Q(n, a)) throw new z("REVISION_CONFLICT", "共通世界の保存情報が変わりました。");
						await this.db.worldSources.put(r), i(), this.faultInjector?.("before-commit");
					});
				}
				o.set(r.projectId, {
					projectId: r.projectId,
					name: r.name,
					revision: r.revision,
					registryOnly: !0,
					contentState: "unloaded",
					sourceIdentity: "identified"
				});
			} catch (t) {
				i(), s.push({
					projectId: n ?? e,
					name: `固定世界 ${e}`,
					revision: "0",
					registryOnly: !0,
					contentState: "error",
					sourceIdentity: n ? "identified" : "unknown",
					error: S(t).message
				});
			}
		}
		return i(), [...o.values(), ...s];
	}
	async loadWorldSource(e, t = {}) {
		let { signal: n } = t, r = this.accessGeneration, i = this.cacheLifetime, a = () => {
			if (B(n), r !== this.accessGeneration || i !== this.cacheLifetime) throw new z("CANCELLED", "共通世界の読み込み先または権限が変わりました。");
		};
		a();
		let o = await this.listWorldSourceSummaries({ signal: n });
		if (a(), o.some((t) => t.contentState === "error" && (t.projectId === e || t.sourceIdentity === "unknown"))) throw new z("VALIDATION_FAILED", "選択した共通世界の保存情報を確認できません。");
		if (!o.some((t) => t.projectId === e && t.contentState === "unloaded")) return;
		let s = await this.db.worldSources.where("projectId").equals(e).toArray(), c = {};
		await this.db.transaction("r", ["worlds"], async () => {
			So(n);
			for (let t of s) {
				a();
				let n = await this.db.worlds.get(t.id);
				if (!n || n.project.projectId !== e) throw new z("VALIDATION_FAILED", "共通世界の索引と保存情報が一致しません。");
				c[t.id] = n.project;
			}
		});
		let l = { ...c };
		for (let e of Object.values(c)) Object.assign(l, await this.editorWorlds(e, n));
		for (let e of Object.values(c)) a(), await Eo(e, l, { signal: n });
		let u = Lt([], c)[0];
		return a(), u ? {
			world: u,
			worlds: l
		} : void 0;
	}
	async editorWorlds(e, t) {
		return this.dependencyWorlds([e], t);
	}
	async dependencyWorlds(e, t) {
		return this.db.transaction("r", ["worlds"], async () => {
			So(t), B(t);
			let n = await this.db.worlds.count();
			return L("db.count.calls", 1, "worlds"), L("db.count.result", n, "worlds"), n === 0 ? (B(t), {}) : jt(e, (e) => this.db.worlds.get(e), () => this.validationWorlds(), t);
		});
	}
	async listEditorWorldSnapshots(e, t = {}) {
		let { signal: n } = t, r = this.accessGeneration, i = this.cacheLifetime, a = await this.editorWorlds(e, n);
		if (B(n), await this.db.transaction("r", ["projects", "syncBases"], async () => {
			if (So(n), B(n), r !== this.accessGeneration || i !== this.cacheLifetime || this.authorAccess && await this.db.syncBases.where("projectId").equals(e.projectId).count() && this.authorAccess.get(e.projectId) !== "owner") throw new z("CANCELLED", "作品の読み込み先または権限が変わりました。");
			let t = this.editorSources.get(e), a = !1;
			if (t && t.projectId === e.projectId && t.revision === e.revision && t.access === r && t.lifetime === i) {
				let n = await Rt(e.projectId);
				a = !!n && t.sourceHash === await W.waitFor(zt(n));
			} else {
				let t = await this.db.projects.get(e.projectId);
				a = !!t && t.revision === e.revision;
			}
			if (!a) throw new z("REVISION_CONFLICT", "共通世界の確認中に作品が更新されました。入力を保持して再試行してください。");
		}), B(n), r !== this.accessGeneration || i !== this.cacheLifetime) throw new z("CANCELLED", "作品の読み込み先が変わりました。");
		return a;
	}
	async listWorldSnapshots() {
		return Z(await this.validationWorlds());
	}
	async getProjectAtRevision(e, t) {
		if (!/^(?:0|[1-9]\d*)$/.test(t)) throw new z("VALIDATION_FAILED", "revisionは正規の10進整数文字列で指定してください。");
		let n = await this.getProject(e);
		if (!n) return;
		let r = n.history.filter((e) => e.revision === t);
		if (r.length > 1 && r.some((e) => !g(e.after, r[0].after))) throw new z("RESTORE_CONFLICT", "同じrevisionに複数の履歴があります。操作IDまたは不変snapshotで対象版を選んでください。");
		if (n.revision === t) {
			if (r.some((e) => !g(e.after, ks(n)))) throw new z("RESTORE_CONFLICT", "現在版と同じrevisionに別の履歴があります。操作IDまたは不変snapshotで対象版を選んでください。");
			return n;
		}
		let i = r[0];
		if (i) return {
			...Z(i.after),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(t))
		};
		let a = n.history.find((e) => e.baseRevision === t);
		return a ? {
			...Z(a.before),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(t))
		} : void 0;
	}
	async getProjectAtSnapshot(e, t) {
		let n = await this.getProject(e), r = n?.snapshots.find((e) => e.id === t);
		return r ? {
			...Z(r.content),
			snapshots: Z(n.snapshots),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(r.content.revision))
		} : void 0;
	}
	async writeContent(e, t, n, r = e.history.map((e) => e.operationId)) {
		L("writeContent.rows", (t?.entities.length ?? 0) + (t?.relations.length ?? 0) + e.entities.length + e.relations.length);
		let { entities: i, relations: a, snapshots: o, history: s, views: c, ...l } = e, u = (t, n) => {
			let r = new Map(t.map((e) => [e.id, e])), i = new Set(n.map((e) => e.id));
			return {
				put: n.filter((e) => !Q(r.get(e.id), e)),
				remove: t.filter((e) => !i.has(e.id)).map((t) => [e.projectId, t.id])
			};
		}, d = u(t?.entities ?? [], i), f = u(t?.relations ?? [], a), p = u(t?.snapshots ?? [], o), m = u(t?.views ?? [], c), h = d.put.map((e) => ({
			entity: e,
			...Bs(e)
		})), g = /* @__PURE__ */ new Set([...d.put.map((e) => e.id), ...d.remove.map((e) => e[1])]), _ = (t?.entities ?? []).filter((e) => g.has(e.id)).flatMap((e) => Bs(e).blocks), v = h.flatMap((e) => e.blocks), y = [.../* @__PURE__ */ new Set([..._.map((e) => e.id), ...v.map((e) => e.id)])], b = u((y.length ? await this.db.blocks.bulkGet(y.map((t) => [e.projectId, t])) : []).filter((e) => !!e), v);
		await Promise.all([
			this.db.entities.bulkDelete(d.remove),
			this.db.relations.bulkDelete(f.remove),
			this.db.blocks.bulkDelete(b.remove),
			this.db.snapshots.bulkDelete(p.remove),
			this.db.views.bulkDelete(m.remove)
		]), await this.db.projects.put({
			...l,
			entityIds: i.map((e) => e.id),
			relationIds: a.map((e) => e.id),
			snapshotIds: o.map((e) => e.id),
			historyIds: r,
			viewIds: c.map((e) => e.id),
			...n ? { contentHeadOperationId: n } : {}
		});
		let x = await W.waitFor(zt(await Rt(e.projectId)));
		return await this.db.projectSummaries.put(await W.waitFor(Bt(e, x))), await Promise.all([
			this.db.entities.bulkPut(h.map((t) => ({
				id: t.entity.id,
				projectId: e.projectId,
				kind: t.entity.kind,
				record: t.record
			}))),
			this.db.relations.bulkPut(f.put),
			this.db.blocks.bulkPut(b.put),
			this.db.snapshots.bulkPut(p.put.map((t) => ({
				...t,
				projectId: e.projectId
			}))),
			this.db.views.bulkPut(m.put.map((t) => ({
				...t,
				projectId: e.projectId
			})))
		]), {
			entities: d.put.length + d.remove.length,
			relations: f.put.length + f.remove.length,
			blocks: b.put.length + b.remove.length,
			snapshots: p.put.length + p.remove.length,
			views: m.put.length + m.remove.length,
			commands: 1,
			outbox: 1
		};
	}
	async checkedAssets(e = []) {
		let t = [];
		for (let n of e) {
			let e = n.bytes.slice(), r = n.assetPath ?? Ca(n.contentHash, n.mediaType), i = wa(r, n.mediaType, e);
			if (e.byteLength > 33554432) throw new z("LIMIT_EXCEEDED", "一つの添付は32 MiB以下にしてください。", r);
			if (i !== n.contentHash || await A(e) !== i) throw new z("HASH_MISMATCH", "添付bytesのhashが一致しません。", r);
			t.push({
				contentHash: i,
				mediaType: n.mediaType,
				path: r,
				bytes: e
			});
		}
		return t;
	}
	async writeAssets(e, t, n) {
		for (let t of e) {
			let e = await this.db.assets.get(t.contentHash);
			if (e && !Gs(e.bytes, t.bytes)) throw new z("HASH_MISMATCH", "既存hashの素材bytesが異なります。", t.path);
			await this.db.assets.put(t);
		}
		for (let e of Pa(t)) {
			let t = await this.db.assets.get(e.contentHash);
			if (t && t.bytes.byteLength !== e.byteSize) throw new z("ASSET_INVALID", "添付bytesとメタデータのサイズが一致しません。", e.assetPath);
			if (n && !t) throw new z("ASSET_MISSING", "完全復元に必要な添付bytesがありません。", e.assetPath);
		}
	}
	async saveProject(e, t) {
		let n = performance.now(), r = t.operationId ?? _(), i = t.signal, a = n, o = {
			prepare: 0,
			hash: 0,
			read: 0,
			reconcile: 0,
			validate: 0,
			diff: 0,
			database: 0,
			total: 0
		}, s = (e) => {
			let t = performance.now();
			o[e] += t - a, e !== "total" && re(`save.${e}`, t - a), a = t;
		}, c, l;
		try {
			B(i);
			let a = ws(e), u = r, d = (/* @__PURE__ */ new Date()).toISOString();
			if (l = a.projectId, c = this.captureCache(a.projectId, !0), this.authorAccess && await this.db.syncBases.get(a.projectId) && this.authorAccess.get(a.projectId) !== "owner") throw new U("FORBIDDEN");
			let f = await this.checkedAssets(t.assets);
			s("prepare");
			let p = await this.db.commands.get(u), m = this.editingHistories.get(a.history);
			if (m && (m.projectId !== a.projectId || m.revision !== a.revision)) throw new z("OPERATION_CONFLICT", "履歴の読込元と編集中の作品・版が一致しません。");
			let h = this.cachedProjects.get(a.projectId), g = h ? {
				historyIds: this.cachedHistoryIds.get(a.projectId) ?? [],
				contentHeadOperationId: this.contentHeads.get(a.projectId)
			} : void 0, _ = this.completeHistories.has(a.projectId), v = await this.db.projects.get(a.projectId), y = v ? h : void 0;
			v && (h?.revision !== v.revision || !Q(g?.historyIds, v.historyIds) || g?.contentHeadOperationId !== v.contentHeadOperationId || !m && !_) && (y = m ? await this.getProjectForEditing(a.projectId, {
				signal: i,
				immutableView: !0
			}) : await this.getProject(a.projectId, { signal: i }), g = y ? this.readBaselines.get(y) : void 0);
			let b = t.worldPin ? await this.validationWorlds() : await this.validationWorlds({}, [a, ...y ? [y] : []], i), x = t.worldPin ? await Io(a, t.worldPin, b) : {}, S = {
				...b,
				...x
			}, C = za(S);
			if (s("read"), !p && (y && y.revision !== a.revision || !y && a.revision !== "0")) throw new z("REVISION_CONFLICT", "別の編集が先に保存されています。現在版を読み直して変更を比較してください。", a.projectId);
			let w = g?.historyIds ?? v?.historyIds ?? [], T = p ? w.slice(0, w.indexOf(u)) : w, E = m?.historyIds ?? a.history.map((e) => e.operationId), D = p ? y?.history.slice(0, y.history.findIndex((e) => e.operationId === u)) ?? [] : y?.history ?? [];
			if (!Q(T, E) || !m && (D.length !== a.history.length || D.some((e, t) => !Q(e, a.history[t])))) throw new z("OPERATION_CONFLICT", "履歴は保存コマンドからのみ追加できます。");
			let O = await A(xs({
				draft: p && !p.requestHashVersion ? a : ks(a),
				...p && !p.requestHashVersion ? {} : { historyIds: E },
				reason: t.reason,
				assets: (t.assets ?? []).map((e) => ({
					contentHash: e.contentHash,
					mediaType: e.mediaType,
					path: e.assetPath ?? null
				})),
				compensatesOperationId: t.compensatesOperationId ?? null,
				...t.worldPin ? { worldPins: x } : {}
			}));
			if (s("hash"), p) return this.duplicateResult(p, O, a.projectId, i);
			if (!y && a.history.length) throw new z("OPERATION_CONFLICT", "既存履歴の復元には専用読み込みを使用してください。");
			if (!M.test(u) || t.compensatesOperationId && !M.test(t.compensatesOperationId)) throw new z("VALIDATION_FAILED", "操作IDは安定したUUIDで指定してください。");
			if (typeof t.reason != "string" || !t.reason.trim() || new TextEncoder().encode(t.reason).byteLength > 1048576) throw new z("VALIDATION_FAILED", "変更の理由を1 MiB以内で指定してください。");
			y && zs(y, a);
			let k = {
				...a,
				entities: Fs(y?.entities ?? [], a.entities, u, d),
				relations: Fs(y?.relations ?? [], a.relations, u, d),
				revision: Os(a.revision)
			};
			if (y) {
				Is(y, k), await Rs(y, k);
				let e = new Map(y.snapshots.map((e) => [e.id, e]));
				k.snapshots = k.snapshots.map((t) => e.get(t.id) ?? t), k = await Si(y, k), k.entities = Fs(y.entities, k.entities, u, d);
			}
			if (new Set(k.snapshots.map((e) => e.id)).size !== k.snapshots.length) throw new z("VALIDATION_FAILED", "公開版IDが重複しています。");
			s("reconcile"), k = Ms(k, C, y, this.validationReferences);
			let ee = new Set(y?.snapshots.map((e) => e.id) ?? []), te = k.snapshots.filter((e) => !ee.has(e.id));
			te.length && (js({
				...k,
				history: []
			}, C), await Va([{
				...k,
				history: [],
				snapshots: te
			}])), Ba([{
				...k,
				history: []
			}], S), s("validate");
			let j = y ? ks(y) : As(a), ne = ks(k), re = await Us(j, ne, !y), ie = {
				operationId: u,
				projectId: k.projectId,
				baseRevision: a.revision,
				revision: k.revision,
				targetIds: re.map((e) => e.targetId),
				reason: t.reason,
				createdAt: d,
				before: j,
				after: ne,
				...t.compensatesOperationId ? { compensatesOperationId: t.compensatesOperationId } : {}
			};
			Ss(ie), k.history = Ss(m ? [] : [...y?.history ?? [], ie]), await Ns(k, C, !m, y ? {
				previous: y,
				references: this.validationReferences
			} : void 0);
			let ae = [...w, u], N = g?.contentHeadOperationId, oe = !N || w.length % 64 == 0, { before: P, after: F, ...se } = ie, ce = {
				operationId: u,
				projectId: k.projectId,
				revision: k.revision,
				requestHash: O,
				requestHashVersion: 2,
				delta: {
					metadata: se,
					...oe ? { checkpoint: j } : { parentOperationId: N },
					patch: Ts(j, ne)
				}
			}, I = {
				entities: 0,
				relations: 0,
				blocks: 0,
				snapshots: 0,
				views: 0,
				commands: 1,
				outbox: 1
			};
			s("diff");
			let L = await this.db.transaction("rw", this.writeTables, async () => {
				if (So(i), B(i), this.authorAccess && await this.db.syncBases.get(k.projectId) && this.authorAccess.get(k.projectId) !== "owner") throw new U("FORBIDDEN");
				let e = await this.db.commands.get(u);
				if (e) return {
					kind: "replay",
					command: e
				};
				let t = await this.db.projects.get(k.projectId);
				if (y ? !t || t.revision !== y.revision : t) throw new z("REVISION_CONFLICT", "保存中に現在版が変わりました。変更を比較して再試行してください。", k.projectId);
				(Object.keys(x).length || te.length) && await this.guardWorldRegistry([k, ...Object.values(x)]);
				for (let [e, t] of Object.entries(x)) {
					let n = await this.db.worlds.get(e), r = n?.project.snapshots.find((t) => t.id === e);
					if (n && !Q(r, t.snapshots[0])) throw new z("IMMUTABLE_SNAPSHOT", "保存中に共通世界の固定版が変わりました。", e);
					await this.writeAssets([], t, !1), n || await this.db.worlds.add({
						id: e,
						project: t
					}), await this.db.worldSources.put(await W.waitFor(Ht(e, n?.project ?? t)));
				}
				await this.writeAssets(f, k, !1), I = await this.writeContent(k, y, u, ae), this.faultInjector?.("after-content"), gt(), await this.db.commands.add(ce), this.faultInjector?.("after-history");
				let n = await this.db.syncMetadata.get(k.projectId);
				return await this.db.outbox.add({
					operationId: u,
					projectId: k.projectId,
					accountId: this.accountId,
					baseRevision: n?.serverRevision ?? "0",
					localRevision: k.revision,
					createdAt: d,
					targetIds: ie.targetIds,
					changes: re.map(({ before: e, after: t, ...n }) => ({
						...n,
						...e === null ? { before: null } : {},
						...t === null ? { after: null } : {}
					})),
					commandOperationId: u
				}), await this.db.syncMetadata.put({
					projectId: k.projectId,
					serverRevision: n?.serverRevision ?? "0",
					state: "pending"
				}), this.faultInjector?.("after-outbox"), B(i), this.faultInjector?.("before-commit"), {
					kind: "saved",
					result: {
						project: k,
						operationId: u,
						localSaved: !0,
						pendingSync: !0
					}
				};
			}), R = L.kind === "replay" ? await this.duplicateResult(L.command, O, k.projectId, i) : L.result;
			s("database"), o.total = performance.now() - n, ko(t.measurementStartedAt, u, o), R.project === k && !i?.aborted && this.rememberProject(k, u, ae, c);
			try {
				this.onSaveMetrics?.({
					operationId: u,
					projectId: k.projectId,
					milliseconds: o,
					written: I,
					historyRead: y === h ? 0 : y?.history.length ?? 0
				});
			} catch {}
			if (m && t.includeHistory === !0) {
				let e = await this.db.commands.bulkGet(ae), t = new Map(e.filter((e) => !!e).map((e) => [e.operationId, e])), n = /* @__PURE__ */ new Map();
				if (e.some((e) => !e)) throw new z("SAVE_FAILED", "保存した対象版の履歴を読み込めません。");
				let r = [];
				for (let i of e) r.push(await this.materializeCommand(i, t, n));
				return {
					...R,
					project: {
						...Cs(R.project),
						history: r
					}
				};
			}
			return {
				...R,
				project: m || t.includeHistory === !1 ? this.editingCopy(R.project, R.project === k ? ae : R.project.history.map((e) => e.operationId), t.immutableView) : Cs(R.project)
			};
		} catch (t) {
			let n = S(t);
			throw go(n, {
				accountId: this.accountId,
				operationId: r,
				revision: e.revision
			}), n;
		} finally {
			l && c && this.releaseCacheCapture(l, c);
		}
	}
	async duplicateResult(e, t, n, r) {
		if (e.projectId !== n || e.requestHash !== t) throw new z("OPERATION_CONFLICT", "同じ操作IDが異なる変更に使われています。", e.operationId);
		let i = await this.getProject(n, { signal: r });
		if (!i) throw new z("NOT_FOUND", "作品が見つかりません。", n);
		return {
			project: {
				...Z((i.history.find((t) => t.operationId === e.operationId) ?? await this.materializeCommand(e)).after),
				history: i.history.filter((t) => BigInt(t.revision) <= BigInt(e.revision))
			},
			operationId: e.operationId,
			localSaved: !0,
			pendingSync: !!await this.db.outbox.get(e.operationId)
		};
	}
	async undo(e, t) {
		let n = await this.getProject(e);
		if (!n) throw new z("NOT_FOUND", "作品が見つかりません。", e);
		let r = t ? n.history.find((e) => e.operationId === t) : n.history.at(-1);
		if (!r) throw new z("NOT_FOUND", "取り消せる履歴がありません。");
		let i = Js(n, r);
		return this.saveProject(i, {
			reason: `取り消し: ${r.reason}`,
			compensatesOperationId: r.operationId
		});
	}
	async previewRestoreEntity(e, t, n, r = "after") {
		let i = await this.getProjectForEditing(e), a = await this.historyCommand(e, t), o = a[r].entities.find((e) => e.id === n);
		if (!i || !a || !o) throw new z("NOT_FOUND", "指定した版の情報が見つかりません。", n);
		let s = i.entities.filter((e) => e.id !== n && N(e).some((e) => e.id === n)).map((e) => e.id);
		return {
			project: i,
			source: Z(o),
			referrers: s,
			warnings: s.length ? [`${s.length}件の参照があります。翻訳・音声・媒体版は内容の変更に応じて確認待ちになります。`] : []
		};
	}
	async restoreEntity(e, t, n, r = "after", i) {
		let a = await this.previewRestoreEntity(e, t, n, r), o = a.project;
		if (i !== void 0 && o.revision !== i) throw new z("REVISION_CONFLICT", "復元の影響確認後に作品が更新されました。選択を保持して再確認してください。");
		let s = o.entities.find((e) => e.id === n);
		return o.entities = o.entities.some((e) => e.id === n) ? o.entities.map((e) => e.id === n ? a.source : e) : [...o.entities, a.source], s && (o.entities = Ko(o.entities, s, a.source), o.relations = qo(o.relations, s, a.source)), this.saveProject(o, {
			reason: `履歴から単体復元: ${a.source.name}`,
			compensatesOperationId: t,
			includeHistory: !0
		});
	}
	async restoreRelation(e, t, n, r = "after", i) {
		let a = await this.getProjectForEditing(e), o = (await this.historyCommand(e, t))?.[r].relations.find((e) => e.id === n);
		if (!a || !o) throw new z("NOT_FOUND", "指定した版の関係が見つかりません。", n);
		if (i !== void 0 && a.revision !== i) throw new z("REVISION_CONFLICT", "復元の影響確認後に作品が更新されました。選択を保持して再確認してください。");
		return a.relations = a.relations.some((e) => e.id === n) ? a.relations.map((e) => e.id === n ? Z(o) : e) : [...a.relations, Z(o)], this.saveProject(a, {
			reason: "履歴から関係を単体復元",
			compensatesOperationId: t,
			includeHistory: !0
		});
	}
	async previewRestoreVersion(e, t, n = "after") {
		let r = await this.getProjectForEditing(e), i = await this.historyCommand(e, t);
		if (!r) throw new z("NOT_FOUND", "復元先の作品が見つかりません。");
		let a = i[n], o = qs({
			...Z(a),
			revision: r.revision,
			history: r.history
		}, r), s = await Us(ks(r), ks(o)), c = {
			projectId: e,
			historyOperationId: t,
			side: n,
			baseRevision: r.revision,
			sourceRevision: a.revision,
			changes: s.map((e) => ({
				id: e.targetId,
				fields: e.fields.map((e) => e.field)
			}))
		};
		return {
			...c,
			confirmationHash: await A(xs(c))
		};
	}
	async restoreHistoryVersion(e, t) {
		let n = Z(t), r = await this.previewRestoreVersion(e, n.historyOperationId, n.side), { confirmationHash: i, ...a } = n;
		if (await A(xs(a)) !== i || e !== n.projectId || r.baseRevision !== n.baseRevision || r.confirmationHash !== n.confirmationHash) throw new z("REVISION_CONFLICT", "作品全体の復元差分が変わりました。対象操作と差分を再確認してください。");
		let o = await this.getProjectForEditing(e), s = await this.historyCommand(e, n.historyOperationId);
		if (!o || o.revision !== n.baseRevision) throw new z("REVISION_CONFLICT", "復元の確定前に作品が更新されました。");
		let c = qs({
			...Z(s[n.side]),
			revision: o.revision,
			history: o.history
		}, o);
		return this.saveProject(c, {
			reason: `作品全体を操作 ${n.historyOperationId} の${n.side === "before" ? "変更前" : "変更後"}（版 ${n.sourceRevision}）へ復元`,
			compensatesOperationId: n.historyOperationId,
			includeHistory: !0
		});
	}
	async restoreRevision(e, t) {
		let [n, r] = await Promise.all([this.getProject(e), this.getProjectAtRevision(e, t)]);
		if (!n || !r) throw new z("NOT_FOUND", "復元する版が見つかりません。");
		let i = qs({
			...r,
			revision: n.revision,
			history: n.history
		}, n);
		return this.saveProject(i, { reason: `作品全体をrevision ${t}から復元` });
	}
	async putAsset(e, t, n = "application/octet-stream") {
		let r = await this.checkedAssets([{
			contentHash: e,
			bytes: t,
			mediaType: n
		}]);
		try {
			await this.db.transaction("rw", this.db.assets, async () => {
				let t = await this.db.assets.get(e);
				if (t && !Gs(t.bytes, r[0].bytes)) throw new z("HASH_MISMATCH", "既存hashの素材bytesが異なります。");
				await this.db.assets.put(r[0]);
			});
		} catch (e) {
			throw S(e);
		}
	}
	async getAsset(e) {
		return (await this.db.assets.get(e))?.bytes.slice();
	}
	async availableAssetHashes() {
		return new Set(await this.db.assets.toCollection().primaryKeys());
	}
	async materializeOutbox(e, t, n = /* @__PURE__ */ new Map()) {
		e = [...e].sort((e, t) => BigInt(e.localRevision) < BigInt(t.localRevision) ? -1 : BigInt(e.localRevision) > BigInt(t.localRevision) ? 1 : e.createdAt.localeCompare(t.createdAt));
		let r = [], i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new WeakMap(), o = (e, t) => {
			let n = i.get(e);
			if (n) return n.get(t) ?? null;
			let r = a.get(e);
			if (r || (r = /* @__PURE__ */ new Map(), a.set(e, r)), r.has(t)) return r.get(t);
			let o;
			if (e.length < 32 || r.size < 16) {
				o = null;
				for (let n = e.length - 1; n >= 0; n--) if (e[n].id === t) {
					o = e[n];
					break;
				}
			} else {
				let n = new Map(e.map((e) => [e.id, e]));
				i.size >= 4 && i.delete(i.keys().next().value), i.set(e, n), o = n.get(t) ?? null;
			}
			return r.size < 32 && r.set(t, o), o;
		}, s = (e, t) => t === e.projectId ? Hs(e) : o(e.relations, t) ?? o(e.entities, t);
		for (let i of e) {
			let e = i.commandOperationId ? t.get(i.commandOperationId) : void 0, a = i.command ?? (e ? await this.materializeCommand(e, t, n, /* @__PURE__ */ new Set(), !1) : void 0);
			if (!a || a.projectId !== i.projectId) throw new z("SAVE_FAILED", "送信待ちに必要な履歴が不足しています。", i.operationId);
			let { commandOperationId: o, ...c } = i;
			r.push({
				...c,
				command: a,
				changes: i.changes.map((e) => ({
					...e,
					before: Object.hasOwn(e, "before") ? e.before : s(a.before, e.targetId),
					after: Object.hasOwn(e, "after") ? e.after : s(a.after, e.targetId)
				}))
			});
		}
		return r;
	}
	async listOutbox(e) {
		let t = await this.db.transaction("r", ["outbox", "commands"], async () => ({
			rows: await this.db.outbox.where("projectId").equals(e).toArray(),
			commands: await this.db.commands.where("projectId").equals(e).toArray()
		}));
		return this.materializeOutbox(t.rows, new Map(t.commands.map((e) => [e.operationId, e])));
	}
	async getSaveState(e) {
		return this.db.transaction("r", this.writeTables, async () => {
			let [t, n, r, i, a] = await Promise.all([
				(async () => {
					let t = await this.db.projects.get(e), n = this.cachedProjects.get(e);
					if (t) {
						if (t.projectId !== e) throw new z("SAVE_FAILED", "作品の保存情報が別の作品を指しています。", e);
						return n?.revision === t.revision && Q(this.cachedHistoryIds.get(e), t.historyIds) ? { project: {
							...n,
							history: []
						} } : this.readProject(e, !1, void 0, t);
					}
				})(),
				this.db.syncMetadata.get(e),
				this.db.outbox.where("projectId").equals(e).count(),
				this.db.recoveredPending.where("projectId").equals(e).count(),
				this.db.syncAssetAcks.where("projectId").equals(e).toArray()
			]), o = t ? La(t.project, await this.validationWorlds()).filter((e) => !a.some((t) => t.contentHash === e.contentHash && t.byteSize === e.byteSize && t.mediaType === e.mediaType)).length : 0;
			return {
				localSaved: !!t,
				pendingCount: r,
				recoveredPendingCount: i,
				pendingAssetCount: o,
				serverRevision: n?.serverRevision ?? "0",
				syncState: n?.state === "conflict" ? "conflict" : r || o ? "pending" : n?.state ?? "pending"
			};
		});
	}
	async getAssetSyncAck(e, t) {
		return Z(await this.db.syncAssetAcks.get(`${e}:${t}`));
	}
	async confirmAssetUpload(e, t) {
		this.syncScope(e);
		let n = Z(t), r = await this.getAsset(n.contentHash);
		if (!r || r.byteLength !== n.bytes || await A(r) !== n.contentHash) throw new U("PROTOCOL_INVALID");
		let i = {
			key: `${e}:${n.contentHash}`,
			projectId: e,
			contentHash: n.contentHash,
			byteSize: n.bytes,
			mediaType: n.mediaType
		};
		await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.syncAssetAcks.get(i.key);
			if (e && !V(e, i)) throw new U("PROTOCOL_INVALID");
			await this.db.syncAssetAcks.put(i), this.faultInjector?.("before-commit");
		});
	}
	async listRetainedSyncRecovery(e) {
		return Z(await this.db.retainedSyncRecovery.where("projectId").equals(e).toArray());
	}
	async listAuthorToolDrafts() {
		return Z(await this.db.authorToolDrafts.toArray());
	}
	async saveSharedSnapshot(e) {
		let { validateSharedSnapshot: t } = await import("./publicShare-Dn0tCvf1.js"), n = await t(Z(e)), r = await this.db.sharedSnapshots.get(n.id);
		if (r && r.contentHash !== n.contentHash) throw new U("PROTOCOL_INVALID");
		await this.db.sharedSnapshots.put(n);
	}
	async listSharedSnapshots() {
		return Z(await this.db.sharedSnapshots.toArray());
	}
	async discardSharedSnapshot(e) {
		await this.db.sharedSnapshots.delete(e);
	}
	async listRecoveredPending(e) {
		return Z((await this.db.recoveredPending.where("projectId").equals(e).toArray()).sort((e, t) => e.sequence - t.sequence));
	}
	async commitAck(e, t) {
		if (t.projectId !== e || !/^(?:0|[1-9]\d*)$/.test(t.serverRevision) || !["applied", "conflict"].includes(t.status)) throw new z("VALIDATION_FAILED", "同期ackの作品・revision・結果が不正です。");
		try {
			await this.db.transaction("rw", [
				"outbox",
				"acks",
				"syncMetadata"
			], async () => {
				let n = await this.db.acks.get(t.operationId);
				if (n) {
					if (!g(n, t)) throw new z("OPERATION_CONFLICT", "同じ操作に異なるackが届きました。");
					return;
				}
				let r = await this.db.outbox.get(t.operationId), i = await this.db.syncMetadata.get(e);
				if (!r || r.projectId !== e || r.accountId !== this.accountId) throw new z("NOT_FOUND", "この領域の送信待ち操作が見つかりません。");
				if (i && BigInt(t.serverRevision) < BigInt(i.serverRevision)) throw new z("REVISION_CONFLICT", "古いサーバーrevisionのackです。");
				await this.db.acks.add(Z(t)), t.status === "applied" && await this.db.outbox.delete(t.operationId);
				let a = await this.db.outbox.where("projectId").equals(e).count();
				await this.db.syncMetadata.put({
					projectId: e,
					serverRevision: t.serverRevision,
					state: t.status === "conflict" ? "conflict" : a ? "pending" : "synced"
				});
			});
		} catch (e) {
			throw S(e);
		}
	}
	syncScope(e) {
		if (!this.accountId || this.accountId === "guest") throw new U("AUTH_REQUIRED");
		return {
			accountId: this.accountId,
			projectId: e
		};
	}
	async bindConfirmedProject(e) {
		let t = Z(e), n = this.syncScope(t.projectId);
		if (!/^(0|[1-9]\d*)$/.test(t.serverRevision) || !t.documents.length || t.documents.length > 100001) throw new U("PROTOCOL_INVALID");
		let r = /* @__PURE__ */ new Set();
		for (let e of t.documents) {
			if (xe(e, n, e.id), r.has(e.id) || BigInt(e.revision) > BigInt(t.serverRevision)) throw new U("PROTOCOL_INVALID");
			r.add(e.id);
		}
		if (await Ce(t.documents) !== t.contentHash) throw new U("PROTOCOL_INVALID");
		let i = await this.getProject(t.projectId);
		if (!i || i.revision !== t.localRevision) throw new U("REVISION_CHANGED");
		let a = Nn(i, t.documents, (/* @__PURE__ */ new Date()).toISOString()), o = await this.validationWorlds();
		if (js(a, za(o)), await Va([a]), await Ns(a, za(o)), !V(An(i, t.serverRevision).map(({ revision: e, ...t }) => t), t.documents.map(({ revision: e, ...t }) => t))) throw new U("REVISION_CHANGED");
		await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.projects.get(t.projectId);
			if (!e || e.revision !== t.localRevision || await this.db.preparedSync.where("projectId").equals(t.projectId).count() || await this.db.syncConflicts.where("projectId").equals(t.projectId).count()) throw new U("REVISION_CHANGED");
			for (let e of t.outboxIds) {
				let n = await this.db.outbox.get(e);
				if (!n || n.projectId !== t.projectId || n.accountId !== this.accountId || BigInt(n.localRevision) > BigInt(t.localRevision)) throw new U("PROTOCOL_INVALID");
			}
			await this.db.syncBases.put({
				projectId: t.projectId,
				serverRevision: t.serverRevision,
				documents: t.documents,
				contentHash: t.contentHash
			}), await this.db.outbox.bulkDelete(t.outboxIds), await this.db.syncMetadata.put({
				projectId: t.projectId,
				serverRevision: t.serverRevision,
				state: await this.db.outbox.where("projectId").equals(t.projectId).count() ? "pending" : "synced"
			}), this.faultInjector?.("before-commit");
		});
	}
	async getConfirmedSyncBase(e) {
		return this.syncScope(e), Z(await this.db.syncBases.get(e));
	}
	async bindBootstrapBase(e, t) {
		let n = Z(e), r = Z(t), i = this.syncScope(n.projectId), a = An(n, r.serverRevision);
		if (!V(a, r.documents) || await Ce(a) !== r.contentHash) throw new U("PROTOCOL_INVALID");
		let o = await this.validationWorlds();
		js(n, za(o)), await Va([n]), await Ns(n, za(o)), await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.projects.get(i.projectId);
			if (!e || BigInt(e.revision) < BigInt(n.revision) || await this.db.syncBases.get(i.projectId) || await this.db.preparedSync.where("projectId").equals(i.projectId).count()) throw new U("REVISION_CHANGED");
			for (let e of r.outboxIds) {
				let t = await this.db.outbox.get(e);
				if (!t || t.accountId !== this.accountId || t.projectId !== i.projectId || BigInt(t.localRevision) > BigInt(n.revision)) throw new U("PROTOCOL_INVALID");
			}
			await this.db.syncBases.put({
				projectId: i.projectId,
				serverRevision: r.serverRevision,
				documents: a,
				contentHash: r.contentHash
			}), await this.db.outbox.bulkDelete(r.outboxIds), await this.db.syncMetadata.put({
				projectId: i.projectId,
				serverRevision: r.serverRevision,
				state: await this.db.outbox.where("projectId").equals(i.projectId).count() ? "pending" : "synced"
			}), this.faultInjector?.("before-commit");
		});
	}
	async applyReceivedImage(e, t) {
		let n = Z(t), r = this.syncScope(e), [i, a, o, s] = await Promise.all([
			this.db.syncBases.get(e),
			this.getProject(e),
			this.listPreparedOperations(e),
			this.listPreparedConflicts(e)
		]);
		if (!i || !a) throw new U("BASE_UNAVAILABLE");
		if (o.length || s.length) throw new U("REVISION_CHANGED");
		if (BigInt(n.serverRevision) < BigInt(i.serverRevision) || await Ce(n.documents) !== n.contentHash) throw new U("PROTOCOL_INVALID");
		let c = new Map(i.documents.map((e) => [e.id, e])), l = n.documents.filter((e) => !jn(c.get(e.id), e)).map((e) => ({
			base: c.get(e.id) ?? null,
			local: c.get(e.id) ?? e
		}));
		if (!l.length) {
			let t = i.documents.find((t) => t.id === e);
			if (!t) throw new U("PROTOCOL_INVALID");
			l.push({
				base: t,
				local: t
			});
		}
		let u = await Se({
			scope: r,
			baseRevision: i.serverRevision,
			operationId: _(),
			targets: l,
			reason: "認証した接続先の確定版を取得して端末の後発編集を保持"
		}), d = {
			schemaVersion: 1,
			operationId: u.operationId,
			scope: r,
			operationHash: await Ce(u),
			status: "applied",
			serverRevision: n.serverRevision,
			documents: l.map((e) => n.documents.find((t) => t.id === e.local.id)),
			confirmedDocuments: n.documents,
			conflicts: []
		};
		await On(u, d), await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.projects.get(e), n = await this.db.syncBases.get(e);
			if (t?.revision !== a.revision || !V(n, i) || await this.db.preparedSync.where("projectId").equals(e).count() || await this.db.syncConflicts.where("projectId").equals(e).count()) throw new U("REVISION_CHANGED");
			await this.db.preparedSync.add({
				operationId: u.operationId,
				projectId: e,
				operation: u,
				localRevision: a.revision,
				localDocuments: i.documents,
				outboxIds: [],
				origin: "received_image",
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			});
		}), await this.commitPreparedAck(e, d, n.worlds);
	}
	async prepareSavedOperations(e, t = "端末の保存待ちを確定共通元から準備") {
		let n = this.syncScope(e), r = await this.db.transaction("r", this.writeTables, async () => ({
			base: await this.db.syncBases.get(e),
			current: await this.readProject(e, !1),
			pending: await this.db.preparedSync.where("projectId").equals(e).toArray(),
			conflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray(),
			outbox: await this.db.outbox.where("projectId").equals(e).toArray()
		}));
		if (r.pending.length) return Z(r.pending[0].operation);
		if (r.conflicts.length) throw new U("REVISION_CHANGED");
		if (!r.base || !r.current) throw new U("BASE_UNAVAILABLE");
		let i = await Pn(n, r.base, r.current.project, r.outbox.map((e) => e.operationId), t);
		return await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.projects.get(e), n = await this.db.syncBases.get(e);
			if (t?.revision !== r.current.project.revision || n?.contentHash !== r.base.contentHash || n?.serverRevision !== r.base.serverRevision || await this.db.preparedSync.where("projectId").equals(e).count() || await this.db.syncConflicts.where("projectId").equals(e).count()) throw new U("REVISION_CHANGED");
			i ? await this.db.preparedSync.add(i) : (await this.db.outbox.bulkDelete(r.outbox.map((e) => e.operationId)), await this.db.syncMetadata.put({
				projectId: e,
				serverRevision: r.base.serverRevision,
				state: "synced"
			})), this.faultInjector?.("before-commit");
		}), i ? Z(i.operation) : null;
	}
	async listPreparedOperations(e) {
		return this.syncScope(e), Z((await this.db.preparedSync.where("projectId").equals(e).toArray()).map((e) => e.operation));
	}
	async listPreparedConflicts(e) {
		return this.syncScope(e), Z((await this.db.syncConflicts.where("projectId").equals(e).toArray()).map((e) => ({
			operationId: e.operationId,
			conflicts: e.conflicts
		})));
	}
	async listSyncConflictAlternatives(e) {
		return this.syncScope(e), Z(await this.db.syncConflicts.where("projectId").equals(e).toArray());
	}
	async listSyncAckEvidence(e) {
		return this.syncScope(e), Z(await this.db.syncAckEvidence.where("projectId").equals(e).toArray());
	}
	async commitPreparedAck(e, t, n = {}) {
		let r = Z(n);
		await this.guardWorldRegistry(Object.values(r)), await Va(Object.values(r));
		let i = this.syncScope(e), a = Z(t);
		if (!V(i, a.scope)) throw new U("PROTOCOL_INVALID");
		let o = await this.db.transaction("r", this.writeTables, async () => ({
			prepared: await this.db.preparedSync.get(a.operationId),
			previousAck: await this.db.syncAckEvidence.get(a.operationId),
			base: await this.db.syncBases.get(e),
			current: await this.readProject(e),
			conflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray()
		}));
		if (o.previousAck) {
			if (!V(o.previousAck.ack, a)) throw new U("OPERATION_REUSED");
			return;
		}
		if (!o.prepared || o.prepared.projectId !== e || !o.base || !o.current || o.base.serverRevision !== o.prepared.operation.baseRevision) throw new U("BASE_UNAVAILABLE");
		await On(o.prepared.operation, a);
		let s = o.current.project, c = (/* @__PURE__ */ new Date()).toISOString(), l = s, u, d, f;
		if (a.status === "applied") {
			let t = Fn(o.prepared, o.base, a, s);
			d = {
				projectId: e,
				serverRevision: a.serverRevision,
				documents: t.confirmed,
				contentHash: await Ce(t.confirmed)
			};
			let n = Nn(s, t.documents, c);
			if (Is(s, n), await Rs(s, n), n = await Si(s, n), n = ps(s, n), n.entities = Fs(s.entities, n.entities, a.operationId, c), n.relations = Fs(s.relations, n.relations, a.operationId, c), !Q(ks(n), ks(s))) {
				n.revision = Os(s.revision);
				let t = ks(s), r = ks(n), i = await Us(t, r), o = _(), d = {
					operationId: o,
					projectId: e,
					baseRevision: s.revision,
					revision: n.revision,
					targetIds: i.map((e) => e.targetId),
					reason: `同期ackを端末確定: ${a.operationId}`,
					createdAt: c,
					before: t,
					after: r
				};
				n.history = [...s.history, d], u = {
					operationId: o,
					projectId: e,
					revision: n.revision,
					record: d
				}, l = n;
			}
			let i = await this.validationWorlds(r);
			js(l, za(i)), Ba([l], i), await Va([l]), await Ns(l, za(i)), t.conflicts.length && (f = {
				operationId: a.operationId,
				projectId: e,
				prepared: o.prepared,
				ack: a,
				conflicts: t.conflicts,
				createdAt: c
			});
		}
		await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.syncAckEvidence.get(a.operationId);
			if (t) {
				if (!V(t.ack, a)) throw new U("OPERATION_REUSED");
				return;
			}
			let n = await this.db.projects.get(e), i = await this.db.syncBases.get(e), p = await this.db.preparedSync.get(a.operationId);
			if (n?.revision !== s.revision || i?.contentHash !== o.base.contentHash || i?.serverRevision !== o.base.serverRevision || !V(p, o.prepared)) throw new U("REVISION_CHANGED");
			if (a.status === "conflict") await this.db.syncConflicts.put({
				operationId: a.operationId,
				projectId: e,
				prepared: o.prepared,
				ack: a,
				conflicts: a.conflicts,
				createdAt: c
			});
			else {
				Object.keys(r).length && await this.guardWorldRegistry(Object.values(r));
				for (let [e, t] of Object.entries(r)) {
					let n = await this.db.worlds.get(e);
					if (n && !g(n.project, t)) throw new z("IMMUTABLE_SNAPSHOT", "固定世界の取得内容が保存済み版と異なります。");
					await this.db.worlds.put({
						id: e,
						project: t
					}), await this.db.worldSources.put(await W.waitFor(Ht(e, t)));
				}
				if (u && (await this.writeContent(l, s, u.operationId), this.faultInjector?.("after-content"), gt(), await this.db.commands.add(u), this.faultInjector?.("after-history")), await this.db.syncBases.put(d), await this.db.outbox.bulkDelete(o.prepared.outboxIds), o.prepared.operation.resolvesOperationId) {
					let e = await this.db.syncConflicts.get(o.prepared.operation.resolvesOperationId);
					if (!e || [...e.prepared.operation.targets.map((e) => e.targetId), ...e.conflicts.map((e) => e.targetId)].some((e) => !o.prepared.operation.targets.some((t) => t.targetId === e))) throw new U("PROTOCOL_INVALID");
					await this.db.syncConflicts.delete(e.operationId);
				}
				f && await this.db.syncConflicts.put(f);
			}
			await this.db.syncAckEvidence.add({
				operationId: a.operationId,
				projectId: e,
				operation: o.prepared.operation,
				ack: a,
				origin: o.prepared.origin ?? "prepared_operation",
				createdAt: c
			}), await this.db.preparedSync.delete(a.operationId), await this.db.syncMetadata.put({
				projectId: e,
				serverRevision: d?.serverRevision ?? o.base.serverRevision,
				state: await this.db.syncConflicts.where("projectId").equals(e).count() ? "conflict" : await this.db.outbox.where("projectId").equals(e).count() ? "pending" : "synced"
			}), this.faultInjector?.("after-outbox"), this.faultInjector?.("before-commit");
		}), this.invalidateProjectCache(e);
	}
	async previewSyncResolution(e, t, n) {
		let r = Z(n), i = this.syncScope(e), [a, o, s] = await Promise.all([
			this.db.syncConflicts.get(t),
			this.db.syncBases.get(e),
			this.getProject(e)
		]);
		if (!a || a.projectId !== e || !o || !s) throw new U("BASE_UNAVAILABLE");
		let c = Z(a.ack.confirmedDocuments);
		if (!c) throw new U("PROTOCOL_INVALID");
		for (let e of a.ack.documents) if (e) {
			let t = c.findIndex((t) => t.id === e.id);
			t >= 0 ? c[t] = Z(e) : c.push(Z(e));
		}
		let l = In(a, r, c, s), u = await Se({
			scope: i,
			baseRevision: a.ack.serverRevision,
			operationId: _(),
			targets: l,
			reason: "共通元・二案と参照への影響を確認して競合解決",
			resolvesOperationId: t
		}), d = new Map(c.map((e) => [e.id, e]));
		for (let e of l) d.set(e.local.id, e.local);
		let f = Nn(s, [...d.values()], (/* @__PURE__ */ new Date()).toISOString()), p = await this.validationWorlds();
		js(f, za(p)), await Va([f]), await Ns(f, za(p));
		let m = {
			projectId: e,
			operationId: t,
			localRevision: s.revision,
			serverRevision: a.ack.serverRevision,
			baseHash: o.contentHash,
			conflictHash: await Ce(a),
			choices: r,
			operation: u,
			candidate: f
		};
		return {
			...m,
			confirmationHash: await Ce(m)
		};
	}
	async confirmSyncResolution(e) {
		let t = Z(e), { confirmationHash: n, ...r } = t;
		if (this.syncScope(t.projectId), await Ce(r) !== n) throw new U("PROTOCOL_INVALID");
		let i = await this.previewSyncResolution(t.projectId, t.operationId, t.choices);
		if (i.localRevision !== t.localRevision || i.baseHash !== t.baseHash || i.conflictHash !== t.conflictHash || i.serverRevision !== t.serverRevision) throw new U("REVISION_CHANGED");
		if (!V({
			...i.operation,
			operationId: t.operation.operationId
		}, t.operation) || !V(i.candidate, t.candidate)) throw new U("PROTOCOL_INVALID");
		let [a, o, s] = await Promise.all([
			this.getProject(t.projectId),
			this.db.syncBases.get(t.projectId),
			this.db.syncConflicts.get(t.operationId)
		]);
		if (!a || !o || !s) throw new U("BASE_UNAVAILABLE");
		let c = Z(s.ack.confirmedDocuments);
		if (!c) throw new U("PROTOCOL_INVALID");
		let l = {
			projectId: t.projectId,
			serverRevision: t.serverRevision,
			documents: c,
			contentHash: await Ce(c)
		}, u = (/* @__PURE__ */ new Date()).toISOString(), d = _(), f = {
			...t.candidate,
			revision: Os(a.revision)
		};
		Is(a, f), await Rs(a, f), f = await Si(a, f), f = ps(a, f), f.entities = Fs(a.entities, f.entities, d, u), f.relations = Fs(a.relations, f.relations, d, u);
		let p = await this.validationWorlds();
		js(f, za(p)), await Va([f]), await Ns(f, za(p));
		let m = await Us(ks(a), ks(f)), h = {
			operationId: d,
			projectId: t.projectId,
			baseRevision: a.revision,
			revision: f.revision,
			targetIds: m.map((e) => e.targetId),
			reason: `競合の共通元・二案から明示選択: ${t.operationId}`,
			createdAt: u,
			before: ks(a),
			after: ks(f)
		};
		return f.history = [...a.history, h], await this.db.transaction("rw", this.writeTables, async () => {
			let [e, n, r] = await Promise.all([
				this.db.projects.get(t.projectId),
				this.db.syncBases.get(t.projectId),
				this.db.syncConflicts.get(t.operationId)
			]);
			if (e?.revision !== t.localRevision || !V(n, o) || !V(r, s) || await this.db.preparedSync.where("projectId").equals(t.projectId).count()) throw new U("REVISION_CHANGED");
			await this.writeContent(f, a, d), gt(), await this.db.commands.add({
				operationId: d,
				projectId: t.projectId,
				revision: f.revision,
				record: h
			}), await this.db.outbox.add({
				operationId: d,
				projectId: t.projectId,
				accountId: this.accountId,
				baseRevision: t.serverRevision,
				localRevision: f.revision,
				targetIds: h.targetIds,
				changes: m,
				command: h,
				createdAt: u
			}), await this.db.syncBases.put(l);
			let i = (await this.db.outbox.where("projectId").equals(t.projectId).toArray()).map((e) => e.operationId);
			await this.db.preparedSync.add({
				operationId: t.operation.operationId,
				projectId: t.projectId,
				operation: t.operation,
				localRevision: f.revision,
				localDocuments: An(f, t.serverRevision),
				outboxIds: i,
				createdAt: u
			}), this.faultInjector?.("before-commit");
		}), this.invalidateProjectCache(t.projectId), Z(t.operation);
	}
	async getViewState(e, t, n, r) {
		let i = await this.db.viewStates.get(h([
			e,
			t,
			n,
			r
		]));
		if (!i) return;
		let { key: a, projectId: o, ...s } = i;
		return s;
	}
	async saveViewState(e, t) {
		await this.db.viewStates.put({
			...Z(t),
			projectId: e,
			key: h([
				e,
				t.userId,
				t.deviceClass,
				t.viewId
			])
		});
	}
	async createRestorePoint(e, t) {
		return this.db.transaction("rw", this.writeTables, async () => {
			let n = (await this.readProject(e))?.project;
			if (!n) throw new z("NOT_FOUND", "復元点を作る作品が見つかりません。");
			await W.waitFor(this.writeAssets([], n, !0));
			let r = {
				id: _(),
				projectId: e,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				reason: t,
				project: n,
				assetHashes: Pa(n).map((e) => e.contentHash)
			};
			return await this.db.restorePoints.add(r), r;
		});
	}
	async listRestorePoints(e) {
		return this.db.restorePoints.where("projectId").equals(e).reverse().toArray();
	}
	async restorePointPage(e, t = 0, n = 30) {
		n = Math.max(1, Math.min(60, Number.isSafeInteger(n) ? n : 30));
		let r = await this.db.restorePoints.where("projectId").equals(e).count(), i = Math.max(0, Math.ceil(r / n) - 1);
		return t = Math.max(0, Math.min(i, Number.isSafeInteger(t) ? t : 0)), {
			entries: (await this.db.restorePoints.where("projectId").equals(e).offset(t * n).limit(n).toArray()).map(({ id: e, createdAt: t, reason: n, project: r, assetHashes: i }) => ({
				id: e,
				createdAt: t,
				reason: n,
				revision: r.revision,
				assetCount: i.length
			})),
			total: r,
			page: t,
			maximum: i,
			size: n
		};
	}
	async previewRestorePoint(e, t) {
		let [n, r] = await Promise.all([this.db.restorePoints.get(t), this.getProjectForEditing(e)]);
		if (!n || n.projectId !== e || !r) throw new z("NOT_FOUND", "この作品の復元点が見つかりません。");
		let i = qs({
			...Z(n.project),
			revision: r.revision,
			history: r.history
		}, r), a = await Us(ks(r), ks(i)), o = {
			projectId: e,
			restorePointId: t,
			baseRevision: r.revision,
			sourceRevision: n.project.revision,
			pointHash: await A(xs(n.project)),
			changes: a.map((e) => ({
				id: e.targetId,
				fields: e.fields.map((e) => e.field)
			}))
		};
		return {
			...o,
			confirmationHash: await A(xs(o))
		};
	}
	async restorePoint(e, t, n) {
		if (n) {
			let { confirmationHash: r, ...i } = Z(n), a = await this.previewRestorePoint(e, t);
			if (i.projectId !== e || i.restorePointId !== t || await A(xs(i)) !== r || a.confirmationHash !== r) throw new z("REVISION_CONFLICT", "復元点の影響確認後に作品または差分が更新されました。選択を保持して再確認してください。");
		}
		let [r, i] = await Promise.all([this.db.restorePoints.get(t), this.getProject(e)]);
		if (!r || r.projectId !== e || !i) throw new z("NOT_FOUND", "この作品の復元点が見つかりません。");
		if (n && i.revision !== n.baseRevision) throw new z("REVISION_CONFLICT", "復元点の確定前に作品が更新されました。");
		let a = qs({
			...Z(r.project),
			revision: i.revision,
			history: i.history
		}, i);
		return this.saveProject(a, { reason: `復元点から作品全体を復元: ${r.reason}` });
	}
	async migrateProject(e, t) {
		let n = await this.createRestorePoint(e, "形式移行前の復元点"), r = await this.validationWorlds(), i = js(await t(Z(n.project)), za(r));
		if (i.projectId !== e) throw new z("VALIDATION_FAILED", "移行で作品IDを変更できません。");
		return i.revision = n.project.revision, i.history = n.project.history, this.saveProject(i, { reason: "検証済みの形式移行" });
	}
	async exportProject(e, t = {}) {
		t = { ...t }, B(t.signal);
		let n = await this.db.transaction("r", this.writeTables, async () => {
			So(t.signal), B(t.signal);
			let n = W.currentTransaction, r = () => n?.abort();
			t.signal?.addEventListener("abort", r, { once: !0 });
			try {
				return B(t.signal), {
					current: await this.readProject(e, !1, void 0, void 0, t.signal),
					commands: await this.db.commands.where("projectId").equals(e).toArray(),
					rows: await this.db.outbox.where("projectId").equals(e).toArray(),
					retained: await this.listRecoveredPending(e),
					metadata: await this.db.syncMetadata.get(e),
					syncBase: await this.db.syncBases.get(e),
					syncPrepared: await this.db.preparedSync.where("projectId").equals(e).toArray(),
					syncConflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray(),
					syncAcks: await this.db.syncAckEvidence.where("projectId").equals(e).toArray(),
					syncAssetAcks: await this.db.syncAssetAcks.where("projectId").equals(e).toArray(),
					syncRetained: await this.db.retainedSyncRecovery.where("projectId").equals(e).toArray(),
					registry: await this.validationWorlds()
				};
			} finally {
				t.signal?.removeEventListener("abort", r);
			}
		}).catch((e) => {
			throw B(t.signal), e;
		});
		if (B(t.signal), !n.current) throw new z("NOT_FOUND", "書き出す作品が見つかりません。");
		let r = new Map(n.commands.map((e) => [e.operationId, e])), i = /* @__PURE__ */ new Map(), a = [];
		for (let e of n.current.historyIds) {
			B(t.signal);
			let n = r.get(e);
			if (!n) throw new z("SAVE_FAILED", "完全保存に必要な履歴が不足しています。", e);
			a.push(await this.materializeCommand(n, r, i, /* @__PURE__ */ new Set(), !1)), await new Promise((e) => setTimeout(e, 0)), B(t.signal);
		}
		let s = {
			...n.current.project,
			history: a
		}, c = await this.materializeOutbox(n.rows, r, i), l = t.snapshotId ? s.snapshots.find((e) => e.id === t.snapshotId) : void 0;
		if (t.snapshotId && !l) throw new z("NOT_FOUND", "書き出す固定版が見つかりません。");
		let u = l ? {
			...Z(l.content),
			snapshots: s.snapshots,
			history: s.history.filter((e) => BigInt(e.revision) <= BigInt(l.content.revision))
		} : s, d = t.snapshotId ? [] : c, f = t.snapshotId ? [] : n.retained;
		await o({
			project: u,
			pending: d,
			retained: f
		}, t.signal);
		let p = d.map((e) => ({
			operationId: e.operationId,
			command: e.command,
			baseRevision: e.baseRevision
		})), m = f.map((e) => e.operation), h = t.snapshotId ? [] : n.syncRetained.map((e) => e.evidence);
		if (!t.snapshotId && (n.syncBase || n.syncPrepared.length || n.syncConflicts.length || n.syncAcks.length)) {
			let e = {
				format: "scenario-sync-recovery",
				version: 1,
				state: "needs_reconnect",
				origin: {
					...u,
					history: []
				},
				...n.syncBase ? { base: n.syncBase } : {},
				prepared: n.syncPrepared,
				conflicts: n.syncConflicts,
				acknowledgements: n.syncAcks,
				assetAcknowledgements: n.syncAssetAcks
			}, t = {
				...e,
				contentHash: await Ce(e)
			};
			h.some((e) => e.contentHash === t.contentHash) || h.push(t);
		}
		let g = {
			project: u,
			pending: p,
			retained: m,
			serverRevision: n.metadata?.serverRevision ?? "0",
			worlds: {},
			availableWorlds: n.registry,
			syncRecovery: h
		};
		return await o(g, t.signal), Po(await Sn(g, t.signal), {
			...t,
			loadAsset: (e) => this.getAsset(e)
		});
	}
	async previewImport(e, t) {
		let n = Z(e), r = {
			...t,
			idMap: t.idMap ? Z(t.idMap) : void 0,
			resolutions: t.resolutions ? Z(t.resolutions) : void 0
		};
		B(r.signal);
		let i = n.project, a = r.targetProjectId ?? i.projectId, o = await this.getProject(a, { signal: r.signal }), s = o ? (await this.listOutbox(a)).length : 0;
		if (B(r.signal), r.mode === "new") return {
			conflicts: o ? [{
				id: a,
				kind: "project",
				existing: o,
				incoming: i
			}] : [],
			pendingChanges: s,
			target: o,
			additions: i.entities.length + i.relations.length
		};
		if (r.mode === "clone") return {
			conflicts: [],
			pendingChanges: 0,
			additions: i.entities.length + i.relations.length
		};
		if (!o) throw new z("NOT_FOUND", "置換・統合する既存作品が見つかりません。", a);
		if (r.mode === "mapped_merge") {
			if (!r.idMap) throw new z("IMPORT_CONFLICT", "別作品の統合には全IDの明示対応表が必要です。");
			let e = (await Mo({
				step: "mapped_plan",
				project: i,
				worlds: {},
				target: o,
				idMap: r.idMap,
				resolutions: r.resolutions,
				mapped: {
					source: n,
					knownWorlds: await this.validationWorlds(n.worlds)
				}
			}, {
				signal: r.signal,
				loadAsset: (e) => this.getAsset(e)
			})).mappedPlan, t = n.recovery ? await Ks(n.recovery, e.mappedProject, e.idMap, r.signal) : void 0, c = new Set(n.project.history.map((t) => e.idMap[t.operationId]));
			e.mappedProject.history = e.mappedProject.history.filter((e) => c.has(e.operationId));
			let l = await A(xs({
				sourceContentHash: e.sourceContentHash,
				manifest: n.manifest,
				targetId: a,
				targetRevision: o.revision,
				idMap: e.idMap,
				resolutions: r.resolutions ?? {},
				changes: e.changes,
				assets: e.assets
			}));
			return {
				conflicts: e.conflicts,
				pendingChanges: s,
				target: o,
				additions: e.changes.filter((e) => e.action === "add").length,
				mappedPlan: e,
				mappedRecovery: t,
				confirmationHash: l
			};
		}
		if (a !== i.projectId) throw new z("IMPORT_CONFLICT", "置換・統合は同じprojectIdが必要です。別の作品には複製して追加してください。", a);
		let c = (await Mo({
			step: "merge_conflicts",
			project: i,
			worlds: {},
			target: o
		}, { signal: r.signal })).conflicts, l = new Set([...o.entities, ...o.relations].map((e) => e.id));
		return {
			conflicts: c,
			pendingChanges: s,
			target: o,
			additions: [...i.entities, ...i.relations].filter((e) => !l.has(e.id)).length
		};
	}
	async saveImportDraft(e) {
		if (!e.key || e.bytes && e.bytes.byteLength > 67108864) throw new z("LIMIT_EXCEEDED", "復元入力の一時保存上限を超えています。");
		let t = Z(e);
		if (t.bytes && await A(t.bytes) !== t.sourceHash) throw new z("HASH_MISMATCH", "復元入力の元ファイルが変わっています。");
		try {
			await this.db.transaction("rw", this.db.importDrafts, async () => {
				let e = await this.db.importDrafts.get(t.key);
				!t.bytes && e && e.sourceHash === t.sourceHash && (t.bytes = e.bytes), await this.db.importDrafts.put(t);
			});
		} catch (e) {
			throw S(e);
		}
	}
	async getImportDraft(e) {
		let t = await this.db.importDrafts.get(e);
		return t ? Z(t) : void 0;
	}
	async clearImportDraft(e) {
		await this.db.importDrafts.delete(e);
	}
	async saveAuthorToolDraft(e) {
		let t = Z(e);
		if (!t.key || !M.test(t.projectId) || !/^\d+$/.test(t.baseRevision) || xs(t.fields).byteLength > 1048576 || t.asset && t.asset.bytes.byteLength > 33554432) throw new z("LIMIT_EXCEEDED", "制作入力の一時保存上限または作品識別が不正です。");
		if (t.asset && await A(t.asset.bytes) !== t.asset.contentHash) throw new z("HASH_MISMATCH", "制作入力の素材bytesが変わっています。");
		try {
			await this.db.authorToolDrafts.put(t);
		} catch (e) {
			throw S(e);
		}
	}
	async restoreAuthorToolDrafts(e, t) {
		let n = Z(e), r = Z(t);
		if (new Set(n.map((e) => e.key)).size !== n.length) throw new z("VALIDATION_FAILED", "入力IDが重複しています。");
		for (let e of n) if (!this.accountId || !e.key.startsWith(this.accountId + ":") || !M.test(e.projectId) || !/^\d+$/.test(e.baseRevision) || xs(e.fields).byteLength > 1048576 || e.asset && (e.asset.bytes.byteLength > 33554432 || await A(e.asset.bytes) !== e.asset.contentHash)) throw new z("VALIDATION_FAILED", "入力の領域・hash・上限が不正です。");
		await this.db.transaction("rw", this.db.authorToolDrafts, async () => {
			if (!Q((await this.db.authorToolDrafts.toArray()).map((e) => ({
				...e,
				asset: e.asset ? {
					contentHash: e.asset.contentHash,
					byteSize: e.asset.bytes.byteLength
				} : null
			})), r.map((e) => ({
				...e,
				asset: e.asset ? {
					contentHash: e.asset.contentHash,
					byteSize: e.asset.bytes.byteLength
				} : null
			})))) throw new z("REVISION_CONFLICT", "確認後に未保存入力が変わりました。");
			await this.db.authorToolDrafts.bulkPut(n), this.faultInjector?.("before-commit");
		});
	}
	async getWorkspaceInputs() {
		let e = await this.db.workspaceInputs.get("workspace");
		return e ? Z(e.value) : void 0;
	}
	checkedWorkspaceInputs(e) {
		let t = Z(e);
		if (!t || Object.keys(t).some((e) => ![
			"drafts",
			"jsonBuffers",
			"settingsDrafts",
			"alternativeDrafts"
		].includes(e)) || [
			"drafts",
			"jsonBuffers",
			"settingsDrafts",
			"alternativeDrafts"
		].some((e) => {
			let n = t[e];
			return !n || typeof n != "object" || Array.isArray(n);
		}) || xs(t).byteLength > 67108864) throw new z("VALIDATION_FAILED", "作品入力の構造または保持上限が不正です。");
		return t;
	}
	async saveWorkspaceInputs(e, t) {
		let n = this.checkedWorkspaceInputs(e), r = Z(t);
		try {
			await this.db.transaction("rw", this.db.workspaceInputs, async () => {
				if (!Q((await this.db.workspaceInputs.get("workspace"))?.value, r)) throw new z("REVISION_CONFLICT", "別画面で作品入力が変わりました。入力を持ち出して再確認してください。");
				await this.db.workspaceInputs.put({
					key: "workspace",
					value: n
				});
			});
		} catch (e) {
			throw S(e);
		}
	}
	async restoreAuthorInputs(e, t) {
		let n = Z(e.tools), r = this.checkedWorkspaceInputs(e.workspace), i = Z(t);
		if (new Set(n.map((e) => e.key)).size !== n.length) throw new z("VALIDATION_FAILED", "入力IDが重複しています。");
		for (let e of n) if (!this.accountId || !e.key.startsWith(this.accountId + ":") || !M.test(e.projectId) || !/^(0|[1-9]\d*)$/.test(e.baseRevision) || !e.fields || typeof e.fields != "object" || Array.isArray(e.fields) || xs(e.fields).byteLength > 1048576 || e.asset && (e.asset.bytes.byteLength > 33554432 || await A(e.asset.bytes) !== e.asset.contentHash)) throw new z("VALIDATION_FAILED", "入力の領域・hash・上限が不正です。");
		let a = (e) => e.map((e) => ({
			...e,
			asset: e.asset ? {
				contentHash: e.asset.contentHash,
				byteSize: e.asset.bytes.byteLength
			} : null
		})).sort((e, t) => e.key.localeCompare(t.key));
		try {
			await this.db.transaction("rw", this.db.authorToolDrafts, this.db.workspaceInputs, async () => {
				let e = await this.db.authorToolDrafts.toArray(), t = await this.db.workspaceInputs.get("workspace");
				if (!Q(a(e), a(i.tools)) || !Q(t?.value, i.workspace)) throw new z("REVISION_CONFLICT", "確認後に未保存入力が変わりました。");
				await this.db.authorToolDrafts.bulkPut(n), await this.db.workspaceInputs.put({
					key: "workspace",
					value: r
				}), this.faultInjector?.("before-commit");
			});
		} catch (e) {
			throw S(e);
		}
	}
	async getAuthorToolDraft(e) {
		let t = await this.db.authorToolDrafts.get(e);
		return t ? Z(t) : void 0;
	}
	async clearAuthorToolDraft(e) {
		await this.db.authorToolDrafts.delete(e);
	}
	async importScenario(e, t) {
		let n = {
			...t,
			idMap: t.idMap ? Z(t.idMap) : void 0,
			resolutions: t.resolutions ? Z(t.resolutions) : void 0
		}, r = ms();
		try {
			if (B(n.signal), ![
				"new",
				"clone",
				"replace",
				"merge",
				"mapped_merge"
			].includes(n.mode)) throw new z("FORMAT_UNSUPPORTED", "読み込みモードが未対応です。");
			let t = Z(e), i = n.operationId ?? _(), a = await this.validationWorlds(t.worlds), o = za(a), s, c, l, u = {
				conflicts: [],
				pendingChanges: 0,
				additions: 0
			}, d = [], f = [], p, m, h, v;
			if ((n.mode === "new" || n.mode === "clone") && typeof window < "u" && typeof Worker < "u") {
				let e = await hs({
					project: t.project,
					recovery: t.recovery,
					syncRecovery: t.syncRecovery,
					worlds: t.worlds,
					knownWorlds: a,
					manifestProjectId: t.manifest.projectId,
					mode: n.mode
				}, {
					stage: (e) => n.onStage?.(e),
					preview: async () => {
						if (u = await this.previewImport(t, n), n.mode === "new" && u.target) throw new z("IMPORT_CONFLICT", "同じ作品IDが既にあります。複製・置換・統合を選んでください。");
					},
					assets: async () => {
						d = await this.checkedAssets(t.assets.map((e) => ({
							contentHash: e.contentHash,
							bytes: e.bytes,
							mediaType: e.mediaType,
							assetPath: e.path
						})));
					},
					finalize: async (e) => (h = await Us(e.before, e.after, !0), m = {
						operationId: i,
						projectId: e.after.projectId,
						baseRevision: "0",
						revision: e.after.revision,
						targetIds: h.map((e) => e.targetId),
						createdAt: e.now,
						reason: `専用ファイルを${n.mode}で復元`,
						before: Z(e.before),
						after: Z(e.after),
						...e.idMap ? { idMap: e.idMap } : {}
					}, m)
				}, n.signal);
				({project: s, recovery: c, idMap: l, worlds: f, now: p, syncRecovery: v} = e);
			} else {
				let e = (e, t, i = {}) => (n.onStage?.(e), r.run({
					step: e,
					project: t,
					worlds: o,
					...i
				}, { signal: n.signal }));
				if (t.project = (await e("structure", t.project)).project, t.recovery &&= (await e("recovery", t.project, { recovery: t.recovery })).recovery, await e("ids", t.project, { recovery: t.recovery }), Ba([t.project, ...Object.values(t.worlds)], a), t.manifest.projectId !== t.project.projectId) throw new z("VALIDATION_FAILED", "読み込み候補とmanifestの作品IDが一致しません。");
				if (u = await this.previewImport(t, n), n.mode === "new" && u.target) throw new z("IMPORT_CONFLICT", "同じ作品IDが既にあります。複製・置換・統合を選んでください。");
				if (n.mode === "replace" && u.pendingChanges) throw new z("PENDING_CHANGES", "未送信の変更があります。同期・競合解決を済ませるか、複製して復元してください。");
				if (u.target && n.baseRevision !== u.target.revision) throw new z("REVISION_CONFLICT", "確認した対象版と現在版が一致しません。読み込みの影響を確認し直してください。");
				if (s = t.project, c = t.recovery, n.mode === "mapped_merge") {
					if (!u.mappedPlan?.candidate || u.mappedPlan.unresolved.length) throw new z("IMPORT_CONFLICT", "全IDの対応とすべての採用差分を確認してください。");
					if (!n.confirmationHash || n.confirmationHash !== u.confirmationHash) throw new z("REVISION_CONFLICT", "確認したID対応・採用差分・素材が変わりました。入力を保持して再確認してください。");
					s = u.mappedPlan.candidate, l = u.mappedPlan.idMap, c = u.mappedRecovery;
				}
				if (n.mode === "clone") {
					let t = (await e("clone", s, { recovery: c })).cloned;
					l = t.idMap, c = c ? (await r.run({
						step: "map_recovery",
						project: t.project,
						worlds: {},
						recovery: c,
						idMap: l
					}, { signal: n.signal })).recovery : void 0;
					let i = new Set(s.history.map((e) => l[e.operationId]));
					s = {
						...t.project,
						history: t.project.history.filter((e) => i.has(e.operationId))
					};
				}
				if (n.mode === "merge" && (s = (await e("merge", s, {
					target: u.target,
					resolutions: n.resolutions
				})).project), n.mode === "replace") {
					let e = new Map(s.snapshots.map((e) => [e.id, e]));
					for (let t of u.target.snapshots) {
						let n = e.get(t.id);
						if (n && !g(t, n)) throw new z("IMMUTABLE_SNAPSHOT", "同じsnapshot IDに異なる内容があります。", t.id);
						e.set(t.id, t);
					}
					s.snapshots = [...e.values()];
					let t = new Set(s.entities.map((e) => e.id));
					s.entities.push(...u.target.entities.filter((e) => e.kind === "snapshot" && !t.has(e.id)));
				}
				let _ = t.assets.map((e) => ({
					contentHash: e.contentHash,
					bytes: e.bytes,
					mediaType: e.mediaType,
					assetPath: e.path
				}));
				d = await this.checkedAssets(_), await e("hashes", s), await e("integrity", s), f = [];
				for (let [n, r] of Object.entries(t.worlds)) f.push({
					id: n,
					project: (await e("structure", r)).project
				});
				p = (/* @__PURE__ */ new Date()).toISOString();
				let y = u.target ? ks(u.target) : As(s);
				if (u.target) {
					let r = (u.mappedPlan?.mappedProject.history ?? t.project.history).map((e, r) => n.mode === "mapped_merge" ? {
						...e,
						importOrigin: e.importOrigin ?? {
							sourceProjectId: t.project.projectId,
							sourceOperationId: t.project.history[r].operationId,
							importOperationId: i
						}
					} : e), a = (await e("combine_history", {
						...s,
						history: r
					}, { target: u.target })).history;
					s = {
						...s,
						revision: Os(u.target.revision),
						history: a
					}, s.entities = Fs(u.target.entities, s.entities, i, p), s.relations = Fs(u.target.relations, s.relations, i, p), Is(u.target, s), s = await Si(u.target, s), s.entities = Fs(u.target.entities, s.entities, i, p);
				} else n.mode === "clone" && (s = {
					...s,
					revision: Os(s.revision)
				});
				s = (await e("structure", s)).project, h = await Us(y, ks(s), !u.target), m = {
					operationId: i,
					projectId: s.projectId,
					baseRevision: u.target?.revision ?? "0",
					revision: s.revision,
					targetIds: h.map((e) => e.targetId),
					createdAt: p,
					reason: `専用ファイルを${n.mode}で復元`,
					before: Z(y),
					after: Z(ks(s)),
					...l ? { idMap: l } : {}
				}, (u.target || n.mode === "clone") && (s.history = [...s.history, m]), c &&= (await e("rehash_recovery", s, { recovery: c })).recovery, s = (await e("structure", s)).project, await e("integrity", s), c &&= (await e("recovery", s, { recovery: {
					...c,
					projectId: s.projectId,
					sourceRevision: s.revision
				} })).recovery, v = t.syncRecovery ? (await e("sync_recovery", s, { syncRecovery: t.syncRecovery })).syncRecovery : [];
			}
			if (n.mode === "clone") {
				Ss(s.history);
				for (let e of s.snapshots) Ss(e);
			}
			let y = u.target ? {
				id: _(),
				projectId: u.target.projectId,
				createdAt: p,
				reason: `専用ファイル${n.mode}の前の復元点`,
				project: u.target,
				assetHashes: Pa(u.target).map((e) => e.contentHash)
			} : void 0, b = await Ds(s.history, n.signal);
			n.onStage?.("commit");
			let x = await this.db.transaction("rw", this.writeTables, async () => {
				if (Co(n.signal), gt(), B(n.signal), await this.db.importLogs.get(i) || await this.db.outbox.get(i) || await this.db.commands.get(i)) throw new z("OPERATION_CONFLICT", "この読み込み操作IDは既に使われています。");
				let e = await this.db.projects.get(s.projectId);
				if (u.target ? !e || e.revision !== u.target.revision : e) throw new z("REVISION_CONFLICT", "読み込みの確定前に対象作品が変わりました。");
				if (n.mode === "replace" && await this.db.outbox.where("projectId").equals(s.projectId).count()) throw new z("PENDING_CHANGES", "確定前に未送信の変更が増えました。");
				await this.guardWorldRegistry([s, ...f.map((e) => e.project)]), y && (await this.writeAssets([], y.project, !0), await this.db.restorePoints.add(y)), await this.writeAssets(d, s, t.manifest.assetMode === "embedded");
				for (let e of f) {
					let t = await this.db.worlds.get(e.id);
					if (t && !g(t.project, e.project)) throw new z("IMMUTABLE_SNAPSHOT", "既存の共通世界snapshotと内容が異なります。", e.id);
					await this.db.worlds.put(e), await this.db.worldSources.put(await W.waitFor(Ht(e.id, e.project)));
				}
				await this.writeContent(s, u.target), this.faultInjector?.("after-content");
				let r = [], a = /* @__PURE__ */ new Set();
				for (let [e, t] of s.history.entries()) {
					let n = await this.db.commands.get(t.operationId);
					if (n && !Q(await this.materializeCommand(n), t)) throw new z("OPERATION_CONFLICT", "読み込む履歴の操作IDが既存履歴と衝突しています。", t.operationId);
					if (!n) {
						let n = b[e], i = n.stored.delta;
						r.push(i?.parentOperationId && !a.has(i.parentOperationId) ? {
							...n.stored,
							delta: {
								metadata: i.metadata,
								checkpoint: n.record.before,
								patch: i.patch
							}
						} : n.stored), a.add(t.operationId);
					}
					r.length === 2 && (await this.db.commands.bulkAdd(r), r = []);
				}
				r.length && await this.db.commands.bulkAdd(r), this.faultInjector?.("after-history");
				let o = await this.db.syncMetadata.get(s.projectId);
				await this.db.outbox.add({
					operationId: i,
					projectId: s.projectId,
					accountId: this.accountId,
					baseRevision: o?.serverRevision ?? "0",
					localRevision: s.revision,
					createdAt: p,
					targetIds: m.targetIds,
					changes: h,
					command: m
				});
				let _ = (await this.listRecoveredPending(s.projectId)).reduce((e, t) => Math.max(e, t.sequence), -1) + 1, x = [];
				for (let e of c?.pending ?? []) {
					let t = {
						key: `${s.projectId}:${e.operationId}`,
						projectId: s.projectId,
						importOperationId: i,
						sequence: _++,
						operation: e,
						status: "needs_reconnect"
					}, n = await this.db.recoveredPending.get(t.key);
					if (n && !g(n.operation, e)) throw new z("OPERATION_CONFLICT", "同じ送信待ち操作の復元内容が異なります。");
					n || x.push(t), x.length === 2 && (await this.db.recoveredPending.bulkAdd(x), x = []);
				}
				x.length && await this.db.recoveredPending.bulkAdd(x);
				for (let e of v) await this.db.retainedSyncRecovery.put({
					key: `${s.projectId}:${e.contentHash}`,
					projectId: s.projectId,
					evidence: e,
					status: "needs_reconnect"
				});
				return await this.db.syncMetadata.put({
					projectId: s.projectId,
					serverRevision: o?.serverRevision ?? "0",
					state: "pending"
				}), await this.db.importLogs.add({
					operationId: i,
					projectId: s.projectId,
					mode: n.mode,
					createdAt: p,
					...l ? { idMap: l } : {}
				}), this.faultInjector?.("after-outbox"), B(n.signal), this.faultInjector?.("before-commit"), {
					project: s,
					operationId: i,
					localSaved: !0,
					pendingSync: !0,
					mode: n.mode,
					...l ? { idMap: l } : {},
					...y ? { restorePointId: y.id } : {},
					warnings: t.warnings
				};
			});
			return this.invalidateProjectCache(s.projectId), x;
		} catch (e) {
			throw S(e);
		} finally {
			r.dispose();
		}
	}
};
function Gs(e, t) {
	return e.byteLength === t.byteLength && e.every((e, n) => e === t[n]);
}
async function Ks(e, t, n, r) {
	return (await Mo({
		step: "map_recovery",
		project: t,
		worlds: {},
		recovery: e,
		idMap: n
	}, { signal: r })).recovery;
}
function qs(e, t) {
	let n = new Map(e.snapshots.map((e) => [e.id, e]));
	for (let e of t.snapshots) n.set(e.id, Z(e));
	e.snapshots = [...n.values()], t.authorAlternatives && (e.authorAlternatives = Z(t.authorAlternatives));
	let r = new Map(t.entities.filter((e) => e.kind === "snapshot").map((e) => [e.id, e]));
	e.entities = e.entities.map((e) => Z(r.get(e.id) ?? e));
	let i = new Set(e.entities.map((e) => e.id));
	for (let [t, n] of r) i.has(t) || e.entities.push(Z(n));
	return e;
}
function Js(e, t) {
	let n = Z(e), r = (e, t, n) => {
		let r = new Map(e.map((e) => [e.id, e])), i = new Map(t.map((e) => [e.id, e])), a = new Map(n.map((e) => [e.id, e]));
		for (let e of /* @__PURE__ */ new Set([...r.keys(), ...i.keys()])) {
			let t = r.get(e), n = i.get(e);
			if (g(t ?? null, n ?? null)) continue;
			let o = a.get(e);
			if (!g(o ? Ps(o) : null, n ? Ps(n) : null)) throw new z("RESTORE_CONFLICT", "取り消し対象がその後に変更されています。履歴の単体復元で内容を比較してください。", e);
			t ? a.set(e, Z(t)) : a.delete(e);
		}
		return [...a.values()];
	};
	n.entities = r(t.before.entities, t.after.entities, e.entities), n.relations = r(t.before.relations, t.after.relations, e.relations);
	for (let r of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences",
		"snapshots",
		"views"
	]) if (!g(t.before[r], t.after[r])) {
		if (!g(e[r], t.after[r])) throw new z("RESTORE_CONFLICT", "取り消す項目がその後に変更されています。", r);
		n[r] = Z(t.before[r]);
	}
	return n;
}
new Ws();
//#endregion
//#region scripts/large-history-verification-entry.mjs
var $ = (e, t) => {
	if (!e) throw Error(t);
}, Ys = (e) => A(E(e)), Xs = (e) => Ys({
	...e,
	history: []
}), Zs = /* @__PURE__ */ new Set([
	"variableValues",
	"visitCounts",
	"publicTexts",
	"publicIds",
	"byEntityId",
	"bindings"
]);
globalThis.inspectExpected = async ({ firstName: e, checkpoints: t, initial: n, sourceHistory: r, soakChecks: i }) => {
	let a = await No(new Uint8Array(await (await fetch("/actual-complete.scenario")).arrayBuffer()), { worker: !1 }), o = a.recovery?.pending ?? [];
	$(a.project.history.length === 113 && o.length === 113, "Actual file must retain all 113 commands and pending intents"), $(r?.length === 113, "All 113 source-native commands and pending hashes must have been observed before export");
	let s = new Map(o.map((e, t) => [e.operationId, {
		...e,
		sequence: t
	}]));
	$(s.size === 113, "Pending operation IDs must be unique");
	let c = a.project.entities[0].id, l = [], u = /* @__PURE__ */ new Map(), d;
	for (let [t, n] of a.project.history.entries()) {
		let i = s.get(n.operationId);
		$(i, "Historical operation is missing from actual portable pending");
		let a = await Ys(n), o = r[t];
		$(o.sequence === t && o.operationId === n.operationId && o.revision === n.revision && o.baseRevision === n.baseRevision && o.commandHash === a && o.pendingHash === a, "Complete file historical command or order differs from the actual source native command/pending"), $(a === i.commandHash && await Ys(i.command) === a, "Every actual file command must match its portable pending digest");
		let f = await Xs(n.before), p = await Xs(n.after);
		if (t > 0) {
			$(f === d, "Consecutive full historical images must remain continuous");
			let r = n.before.entities.find((e) => e.id === c), i = n.after.entities.find((e) => e.id === c);
			$(r?.name === (t === 1 ? e : "継続編集" + (t - 2)), "Historical before name differs from the actual normal editing sequence"), $(i?.name === "継続編集" + (t - 1), "Historical after name differs from the actual normal editing sequence");
		}
		$(n.after.entities.length + n.after.relations.length === 88003, "Every after image must retain the full Large record set"), d = p, u.set(n.revision, p), l.push({
			operationId: n.operationId,
			revision: n.revision,
			baseRevision: n.baseRevision,
			hash: a,
			beforeHash: f,
			afterHash: p,
			sequence: i.sequence,
			origin: i.origin ?? null
		});
	}
	i !== void 0 && $(i.length === 112, "All 112 actual soak full-image/material checks are required");
	let f = [...n ? [n] : [], ...i ?? t];
	$(t.length === 14, "All 14 actual source checkpoints are required");
	for (let e of f) $(u.get(e.revision) === e.contentHash, "A full image differs from an actual source checkpoint: " + e.revision);
	let p = ia(hi(a.project, a.recovery)), m = new Set(p.map((e) => e.id));
	$(m.size === p.length && m.has(a.project.projectId), "Complete typed ownership enumeration is inconsistent");
	for (let e of [a.project, ...a.project.history.flatMap((e) => [e.before, e.after])]) {
		for (let t of e.entities) $(m.has(t.id), "Declared entity missing from clone ownership");
		for (let t of e.relations) $(m.has(t.id), "Declared relation missing from clone ownership");
		for (let t of e.views) $(m.has(t.id), "Declared saved view missing from clone ownership");
		for (let t of e.snapshots) $(m.has(t.id), "Declared snapshot missing from clone ownership");
	}
	for (let e of l) $(m.has(e.operationId), "Historical operation missing from clone ownership");
	let h = [];
	for (let e of a.assets) {
		let t = await A(e.bytes);
		$(t === e.contentHash, "Actual file material byte SHA is invalid"), h.push({
			hash: e.contentHash,
			bytes: e.bytes.length,
			actualHash: t
		});
	}
	return {
		projectId: a.project.projectId,
		revision: a.project.revision,
		serverRevision: a.recovery.serverRevision,
		currentHash: await Xs(a.project),
		history: l,
		owned: p,
		assetHashes: h,
		sourceCheckpointCount: f.length,
		sourceCheckpointScope: "Actual initial/checkpoint images only; other original native images were not independently observed before export. All file image continuity and native/file equality are separate checks."
	};
};
async function Qs(e, t) {
	let n = await new Promise((n, r) => {
		let i = e.transaction(["recoveredPending", "recordParts"], "readonly"), a, o = [];
		i.oncomplete = () => n({
			envelope: a,
			parts: o
		}), i.onerror = () => r(i.error ?? Error("Native pending read failed")), i.onabort = () => r(i.error ?? Error("Native pending read aborted"));
		let s = i.objectStore("recoveredPending").get(t);
		s.onerror = () => r(s.error), s.onsuccess = () => {
			if (a = s.result, !a?.__scenarioRecordParts) return;
			let e = a.__scenarioRecordParts.parts;
			$(Array.isArray(e), "Native parts descriptor is missing"), o = Array(e.length);
			for (let [t, n] of e.entries()) {
				let e = i.objectStore("recordParts").get(n.key);
				e.onerror = () => r(e.error), e.onsuccess = () => {
					o[t] = e.result;
				};
			}
		};
	});
	$(n.envelope, "A native recovered pending row is missing");
	let r = n.envelope.__scenarioRecordParts;
	if (!r) return {
		row: n.envelope,
		parts: []
	};
	$(r.scope.startsWith("recoveredPending:") && n.parts.every(Boolean), "Native pending parts scope or payload is invalid");
	let i = await tt(r, n.parts);
	return $(i && typeof i == "object" && !Object.hasOwn(i, "__scenarioRecordParts"), "Nested native marker cannot be a complete operation"), $(i.key === n.envelope.key && i.projectId === n.envelope.projectId, "Native index/header differs from decoded pending"), $(Object.keys(n.envelope).sort().join("|") === "__scenarioRecordParts|key|projectId", "Native pending header has unknown fields"), {
		row: i,
		parts: n.parts.map((e) => ({
			key: e.key,
			scope: e.scope,
			sequence: e.sequence,
			kind: e.kind,
			bytes: e.bytes.length,
			sha256: e.sha256
		}))
	};
}
globalThis.inspectNative = async (e, t) => {
	let n = new Ws();
	try {
		let r = await n.listProjectsForEditing();
		$(r.length === 1, "Restoration must start in an empty environment and retain only one project");
		let i = r[0].projectId, a = await n.getProject(i), o = await n.db.importLogs.where("projectId").equals(i).toArray();
		$(o.length === 1 && o[0].mode === t && o[0].projectId === i, "Native import audit is missing or inconsistent");
		let s = o[0].idMap ?? {}, c = new Set(e.owned.map((e) => e.id));
		if (t === "clone") {
			$(Object.keys(s).length === c.size && Object.keys(s).every((e) => c.has(e)), "Clone mapping must cover exactly every owned source ID");
			let t = Object.values(s);
			$(new Set(t).size === t.length && t.every((e) => typeof e == "string" && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(e) && !c.has(e)), "Clone mapping must be bijective with fresh valid IDs"), $(s[e.projectId] === i && i !== e.projectId, "Clone project correspondence is invalid");
			let n = new Map(ia(a).map((e) => [e.id, e]));
			for (let t of e.owned) {
				let e = n.get(s[t.id]);
				$(e?.role === t.role && e.ownerId === (t.ownerId ? s[t.ownerId] : void 0), "Clone typed declaration or owner correspondence is missing");
			}
			$(n.size === e.owned.length + 1 && n.get(o[0].operationId)?.role === "operation", "Only the new clone import operation may add an owned ID");
		} else $(i === e.projectId && Object.keys(s).length === 0, "New restore must preserve all source IDs"), $(await Ys(ia(a)) === await Ys(e.owned), "New restore typed ownership differs");
		let l = Object.fromEntries(Object.entries(s).map(([e, t]) => [t, e])), u = (e, t = "") => typeof e == "string" ? /(?:Id|Ids)$/.test(t) || t === "id" || t === "operationId" || t === "bindings" || t === "idMap" ? l[e] ?? e : e : Array.isArray(e) ? e.map((e) => u(e, t)) : e && typeof e == "object" ? Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0).map(([e, n]) => [Zs.has(t) ? l[e] ?? e : e, u(n, t === "bindings" || t === "idMap" ? t : e)])) : e, d = e.history.map((e) => t === "clone" ? s[e.operationId] : e.operationId);
		$(JSON.stringify(a.history.slice(0, d.length).map((e) => e.operationId)) === JSON.stringify(d), "Every original historical operation must retain its exact order after cold restoration");
		let f = [];
		for (let n of e.history) {
			let e = t === "clone" ? s[n.operationId] : n.operationId, r = a.history.find((t) => t.operationId === e);
			$(r, "A complete original historical operation is missing");
			let i = await Ys(t === "clone" ? u(r) : r);
			$(i === n.hash, "Complete historical command differs: " + n.revision), f.push({
				operationId: e,
				revision: r.revision,
				actualHash: i,
				sourceHash: n.hash
			});
		}
		if ($(a.history.length === (t === "new" ? 113 : 114), "Native history count is inconsistent"), t === "clone") {
			let t = a.history.at(-1);
			$(t.operationId === o[0].operationId && t.reason === "専用ファイルをcloneで復元" && t.projectId === i && a.revision === String(BigInt(e.revision) + 1n) && t.revision === a.revision, "Clone import operation is inconsistent");
		}
		let p = t === "clone" ? u({
			...a,
			history: []
		}) : {
			...a,
			history: []
		};
		t === "clone" && (p.revision = e.revision);
		let m = await Ys(p);
		$(m === e.currentHash, "Full native current content differs from the actual file");
		let h = n.db.backendDB(), g = await new Promise((e, t) => {
			let n = h.transaction("recoveredPending", "readonly").objectStore("recoveredPending").getAllKeys();
			n.onsuccess = () => e(n.result), n.onerror = () => t(n.error);
		});
		$(g.length === 113, "Every retained pending intent is required");
		let _ = new Map(e.history.map((e) => [e.operationId, e])), v = /* @__PURE__ */ new Set(), y = [];
		for (let n of g) {
			let r = await Qs(h, n), a = r.row, s = a.operation, c = t === "clone" ? l[s.operationId] : s.operationId, d = _.get(c);
			$(d && !v.has(c) && a.key === i + ":" + s.operationId && a.projectId === i && a.importOperationId === o[0].operationId && a.status === "needs_reconnect" && a.sequence === d.sequence, "Native pending ID, key, sequence, import audit or state differs");
			let f = await Ys(s.command);
			$(f === s.commandHash, "Native full pending command SHA differs");
			let p = t === "clone" ? await Ys(u(s.command)) : f;
			$(p === d.hash, "Native full pending command differs from its actual source file"), t === "new" ? $(await Ys(s.origin ?? null) === await Ys(d.origin), "New pending origin changed") : $(await Ys(s.origin ?? null) === await Ys(d.origin ?? {
				projectId: e.projectId,
				operationId: c,
				serverRevision: e.serverRevision
			}), "Clone pending provenance lost its original source or server revision"), v.add(c), y.push({
				sequence: a.sequence,
				operationId: s.operationId,
				commandHash: s.commandHash,
				actualHash: f,
				sourceHash: p,
				origin: s.origin ?? null,
				nativeParts: r.parts
			});
		}
		$(v.size === 113, "A pending operation was silently omitted");
		let b = [];
		for (let t of e.assetHashes) {
			let e = await n.getAsset(t.hash), r = e ? await A(e) : null;
			$(r === t.hash && e.length === t.bytes, "Native material bytes are missing or differ"), b.push({
				...t,
				actualHash: r
			});
		}
		let x = await n.getSaveState(i);
		return $(x.pendingCount === 1 && x.recoveredPendingCount === 113, "Local import and recovered pending counts differ"), {
			projectId: i,
			revision: a.revision,
			records: a.entities.length + a.relations.length,
			currentHash: m,
			history: f,
			pending: y,
			assets: b,
			saveState: x,
			importLog: {
				operationId: o[0].operationId,
				mode: o[0].mode,
				idMap: s
			}
		};
	} finally {
		n.close();
	}
}, globalThis.seedLargeHistory = async (e = !1) => {
	let { createMaterialPerformanceFixture: t } = await import("./performanceFixture-D_Tj3WCp.js"), n = await t("large-material-rb10-v1");
	$(n.counts.totalRecords === 88003 && n.assetBytes === 75497472, "Original Large fixture changed");
	let r = new Ws();
	try {
		$((await r.listProjectsForEditing()).length === 0, "Source environment must be empty");
		let t = (await r.saveProject(n.project, {
			reason: "測定fixture初期化",
			includeHistory: !1,
			assets: n.assets
		})).project, i;
		if (e) {
			let { createProject: e, createEntity: t } = await import("./model-CpGFZXoy.js").then((e) => e.g), n = e("継続試読の補助作品"), a = t(n.projectId, "flow_node", "補助試読入口", { nodeType: "entry" }), o = t(n.projectId, "flow_node", "補助試読終端", {
				nodeType: "terminal",
				terminalReason: "補助試読終了"
			}), s = t(n.projectId, "flow_edge", "補助進行", {
				fromId: a.id,
				toId: o.id,
				label: "終端へ進む"
			}), c = t(n.projectId, "flow_graph", "補助試読図", {
				nodeIds: [a.id, o.id],
				entryIds: [a.id],
				exitIds: [o.id],
				edgeIds: [s.id]
			});
			n.entities.push(a, o, s, c), n.entities.forEach((e) => e.status = "confirmed");
			let l = (await r.saveProject(n, {
				reason: "別作品の補助試読fixture",
				includeHistory: !1
			})).project;
			i = {
				projectId: l.projectId,
				title: l.name,
				records: 4,
				sha256: await Ys(n),
				purpose: "Separate explicit auxiliary trial workload; original Large record/asset counts unchanged"
			};
		}
		return localStorage.setItem("scenario-last-project:guest", t.projectId), localStorage.setItem("scenario-local-view-user", "measurement"), localStorage.setItem("scenario-workspace-view:v1:measurement:" + t.projectId + ":desktop", JSON.stringify({
			filters: {
				"workspace.page": "materials",
				"workspace.kind": "character"
			},
			lastOpenedId: null
		})), sessionStorage.setItem("scenario-performance", "measure"), {
			projectId: t.projectId,
			name: t.name,
			firstName: t.entities[0].name,
			records: 88003,
			assetBytes: n.assetBytes,
			assetHashes: n.assets.map((e) => ({
				hash: e.contentHash,
				bytes: e.bytes.length
			})),
			...i ? { trial: i } : {}
		};
	} finally {
		r.close();
	}
}, globalThis.sourceCheckpoint = async (e) => {
	let t = new Ws();
	try {
		let n = await t.getProjectForEditing(e.projectId), r = await t.historyPage(e.projectId, { size: 1 }), i = await t.getSaveState(e.projectId), a = [];
		for (let n of e.assetHashes) {
			let e = await t.getAsset(n.hash);
			$(e && e.length === n.bytes && await A(e) === n.hash, "Source actual asset bytes differ"), a.push(n);
		}
		let o = n.entities.length + n.relations.length;
		return $(o === 88003 && a.reduce((e, t) => e + t.bytes, 0) === 75497472, "Source original records or assets changed"), {
			revision: n.revision,
			contentHash: await Xs(n),
			records: o,
			historyCount: r.total,
			pendingCount: i.pendingCount,
			recoveredPendingCount: i.recoveredPendingCount,
			assets: a
		};
	} finally {
		t.close();
	}
}, globalThis.inspectSourceHistory = async (e) => {
	let t = new Ws();
	try {
		let n = await t.getProject(e.projectId), r = await t.listOutbox(e.projectId);
		$(n.history.length === 113 && r.length === 113, "All original source-native history and pending intents are required"), $(j({
			project: n,
			pending: r
		}), "Source verification needs its own private plain-data capture");
		let i = Qr(), a = Qr(), o = [], s = /* @__PURE__ */ new Set();
		for (let [e, t] of n.history.entries()) {
			let n = r[e];
			$(n && n.operationId === t.operationId && !s.has(n.operationId), "Source-native pending order or operation differs"), s.add(n.operationId);
			let c = i(t), l = await A(c), u = await A(a(n.command));
			$(l === u, "Source-native full historical and pending commands differ"), o.push({
				sequence: e,
				operationId: t.operationId,
				revision: t.revision,
				baseRevision: t.baseRevision,
				commandBytes: c.length,
				commandHash: l,
				pendingHash: u
			});
		}
		return o;
	} finally {
		t.close();
	}
};
//#endregion
