//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, n) => {
	let r = {};
	for (var i in e) t(r, i, {
		get: e[i],
		enumerable: !0
	});
	return n || t(r, Symbol.toStringTag, { value: "Module" }), r;
}, c = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, l = (n, r, o) => (o = n == null ? {} : e(i(n)), c(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n)), u = class extends Error {
	code;
	path;
	constructor(e, t, n, r) {
		super(t, r), this.name = "StorageError", this.code = e, this.path = n;
	}
};
function d(e) {
	if (e?.aborted) throw new u("CANCELLED", "処理を取り消しました。既存の作品は変更していません。");
}
function f(e) {
	if (e instanceof u) return e;
	let t = e instanceof Error && /quota/i.test(e.name + e.message);
	return new u(t ? "QUOTA_EXCEEDED" : "SAVE_FAILED", t ? "保存容量が不足しています。入力を保持して完全ファイルへ書き出すか、容量を確保して再試行してください。" : "端末内への保存に失敗しました。入力を保持して再試行してください。", void 0, { cause: e });
}
//#endregion
//#region src/observability/probe.ts
var p = /* @__PURE__ */ "store.list,store.read,store.fullRead,store.save,store.history,store.export,store.import,save.prepare,save.read,save.hash,save.reconcile,save.validate,save.diff,save.database,copy,capture,normalize,targetChanges,contentDelta,writeContent,hydrate,decode,validate.current,validate.integrity,validate.full,query.filter,query.index,query.positions,reference.choices,ui.filter,ui.indices,worker.read,worker.parts,worker.archive,ui.startup,ui.save".split(","), m = /* @__PURE__ */ "history.write.candidates,history.write.fallbackShape,history.write.fallbackSize,history.write.canonical,history.write.sealCalls,history.write.sealBytes,history.metadata.rows,history.metadata.payloadBytes,history.legacy.rows,history.legacy.payloadBytes,history.header.payloadBytes,history.partKeys,history.body.rows,history.body.partRows,history.body.partBytes,db.count.calls,db.count.result,db.read.calls,db.read.rows,db.read.keys,db.read.payloadBytes,db.read.requested,db.write.calls,db.write.attempted,db.write.succeeded,db.write.committed,db.write.aborted,db.write.payloadBytes,db.deleteRange.calls,db.transaction.committed,db.transaction.aborted,hash.calls,hash.bytes,json.calls,json.bytes,copy.calls,copy.payloadBytes,capture.calls,capture.payloadBytes,normalize.rows,targetChanges.rows,contentDelta.rows,writeContent.rows,hydrate.rows,decode.rows,decode.payloadBytes,validate.current.calls,validate.integrity.calls,validate.full.calls,query.index.builds,query.index.rows,query.text.rows,query.filter.rows,query.positions.rows,query.positions.blocks,query.positions.matches,query.positions.traceBuilds,query.positions.traceHits,derived.hit,derived.miss,derived.admitted,derived.rejected,derived.invalidated,collection.order.rows,collection.page.requested,collection.page.rows,collection.selected.requested,collection.selected.rows,collection.index.builds,collection.index.rows,reference.choices.rows,reference.index.builds,reference.index.rows,ui.filter.rows,ui.indices.rows,worker.started,worker.terminated,worker.sent.messages,worker.sent.payloadBytes,worker.received.messages,worker.received.payloadBytes,cache.projects,cache.records,cache.payloadBytes,cache.invalidated,cache.heads,cache.histories,cache.completeHistories,cache.epochs,world.closure.fullFallback,ui.worldRegistry.entries,ui.worldRegistry.projects,ui.worldRegistry.records,ui.worldRegistry.payloadBytes,memo.hit,memo.miss,probe.size.unknown,probe.size.milliseconds".split(","), h = /* @__PURE__ */ "projects.projectSummaries.worldSources.entities.relations.blocks.snapshots.commands.outbox.assets.views.viewStates.syncMetadata.acks.restorePoints.worlds.importLogs.importDrafts.authorToolDrafts.workspaceInputs.recoveredPending.retainedSyncRecovery.syncAssetAcks.syncBases.preparedSync.syncConflicts.syncAckEvidence.sharedSnapshots.recordParts".split("."), ee;
new Set(p);
var te = new Set(m), g = new Set(h), ne = () => !1;
function re() {
	let e = ae(), t;
	return new Promise((e) => {
		t = e;
	}), {
		count: e,
		finish() {
			t?.();
		}
	};
}
function ie(e, t, n, r) {
	if (!e || !te.has(t) || r !== void 0 && !g.has(r) || !Number.isFinite(n) || n < 0) return;
	let i = r === void 0 ? t : `${t}.${r}`, a = (e.counters[i] ?? 0) + n;
	Number.isFinite(a) && (e.counters[i] = a);
}
function _(e, t = 1, n) {
	ie(ee, e, t, n);
}
function v(e, t) {}
function ae() {
	let e = ee;
	return (t, n = 1, r) => ie(e, t, n, r);
}
function oe(e, t, n = "ok") {}
function se(e) {
	return (e) => {};
}
function ce(e, t) {
	return t();
}
function le(e, t, n) {}
function ue(e) {
	let t = se(e), n = ae();
	n("worker.started");
	let r = !1;
	return () => {
		r || (r = !0, n("worker.terminated"), t());
	};
}
function de() {
	return (e, t) => {};
}
//#endregion
//#region src/storage/json.ts
var fe = "1.0.0", pe = Object.freeze({
	compressedBytes: 67108864,
	expandedBytes: 268435456,
	jsonBytes: 67108864,
	assetBytes: 33554432,
	files: 5e3,
	records: 1e5,
	depth: 32,
	objects: 5e5,
	conditionDepth: 16,
	conditionNodes: 256,
	fieldBytes: 1048576
});
function me(e = {}) {
	let t = { ...pe };
	for (let [n, r] of Object.entries(e)) {
		if (!(n in t) || !Number.isSafeInteger(r) || r < 1 || r > t[n]) throw new u("LIMIT_EXCEEDED", "v1の安全上限は引き上げられません。", n);
		t[n] = r;
	}
	return t;
}
var he = /[\uD800-\uDFFF]/u;
function y(e) {
	return !he.test(e);
}
function ge(e, t, n = pe, r = { objects: 0 }) {
	if (e.byteLength > n.jsonBytes) throw new u("LIMIT_EXCEEDED", "JSONファイルが上限を超えています。", t);
	if (e[0] === 239 && e[1] === 187 && e[2] === 191) throw new u("ARCHIVE_INVALID", "JSONのBOMは使用できません。", t);
	let i;
	try {
		i = new TextDecoder("utf-8", { fatal: !0 }).decode(e);
	} catch (e) {
		throw new u("ARCHIVE_INVALID", "JSONは有効なUTF-8である必要があります。", t, { cause: e });
	}
	let a = 0, o = (e) => {
		throw new u("ARCHIVE_INVALID", `${e}（位置 ${a}）`, t);
	}, s = () => {
		for (; /[ \t\n\r]/.test(i[a] ?? "") && a < i.length;) a++;
	};
	function c() {
		let e = a++;
		for (; a < i.length;) {
			let t = i[a++];
			if (t === "\"") {
				let t;
				try {
					t = JSON.parse(i.slice(e, a));
				} catch {
					return o("文字列が不正です。");
				}
				return y(t) ? t : o("Unicodeのサロゲートが不正です。");
			}
			t === "\\" && a++;
		}
		return o("文字列が閉じられていません。");
	}
	function l(e) {
		s();
		let d = i[a];
		if (d === "\"") return c();
		if (d === "{" || d === "[") {
			if (e > n.depth || ++r.objects > n.objects) throw new u("LIMIT_EXCEEDED", "JSONの構造が安全上限を超えています。", t);
			let f = d === "{";
			a++, s();
			let p = f ? "}" : "]", m = f ? Object.create(null) : [], h = /* @__PURE__ */ new Set();
			if (i[a] === p) return a++, m;
			for (; a < i.length;) {
				if (s(), f) {
					if (i[a] !== "\"") return o("オブジェクトのkeyが不正です。");
					let t = c();
					if (h.has(t)) return o(`key「${t}」が重複しています。`);
					if (h.add(t), s(), i[a++] !== ":") return o("keyの後にコロンが必要です。");
					m[t] = l(e + 1);
				} else m.push(l(e + 1));
				s();
				let t = i[a++];
				if (t === p) return m;
				if (t !== ",") return o("区切り文字が不正です。");
			}
			return o("JSONが閉じられていません。");
		}
		for (let [e, t] of [
			["true", !0],
			["false", !1],
			["null", null]
		]) if (i.startsWith(e, a)) return a += e.length, t;
		let f = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(i.slice(a));
		if (!f) return o("値が不正です。");
		a += f[0].length;
		let p = Number(f[0]);
		return Number.isFinite(p) ? p : o("有限でない数値は保存できません。");
	}
	let d = l(1);
	return s(), a !== i.length && o("JSONの末尾に余分なデータがあります。"), d;
}
function _e(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new WeakSet();
	function r(e) {
		if (e !== null && typeof e != "boolean") {
			if (typeof e == "string") {
				if (!y(e)) throw new u("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
				return;
			}
			if (typeof e == "number") {
				if (!Number.isFinite(e)) throw new u("VALIDATION_FAILED", "有限でない数値は保存できません。");
				return;
			}
			if (typeof e != "object") throw new u("VALIDATION_FAILED", "JSONに保存できない値があります。");
			if (t.has(e)) throw new u("VALIDATION_FAILED", "循環したJSONは保存できません。");
			if (!n.has(e)) {
				if (t.add(e), Array.isArray(e)) e.forEach(r);
				else for (let t of Object.keys(e)) {
					let n = e[t];
					n !== void 0 && r(n);
				}
				t.delete(e), n.add(e);
			}
		}
	}
	r(e);
}
function ve(e) {
	let t = /* @__PURE__ */ new WeakMap(), n = 0, r = 0;
	return {
		get: (e) => t.get(e),
		set(i, a) {
			if (!e(i) || Array.isArray(i)) return;
			let o = Object.getPrototypeOf(i);
			if (o !== Object.prototype && o !== null) return;
			let s = Object.getOwnPropertyDescriptors(i);
			if (typeof s.id?.value != "string" || typeof s.kind?.value != "string" || Object.values(s).some((e) => !("value" in e))) return;
			let c = a.length * 2;
			c > 65536 || ((r + 1 > 16384 || n + c > 33554432) && (t = /* @__PURE__ */ new WeakMap(), n = 0, r = 0), t.set(i, a), n += c, r++);
		}
	};
}
function b(e, t) {
	let n = /* @__PURE__ */ new Set();
	function r(e) {
		if (e === null) return "null";
		if (typeof e == "string") {
			if (!y(e)) throw new u("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return JSON.stringify(e);
		}
		if (typeof e == "boolean") return String(e);
		if (typeof e == "number") {
			if (!Number.isFinite(e)) throw new u("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return JSON.stringify(e);
		}
		if (typeof e != "object") throw new u("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (n.has(e)) throw new u("VALIDATION_FAILED", "循環したJSONは保存できません。");
		let i = t?.get(e);
		if (i !== void 0) return i;
		n.add(e);
		let a = Array.isArray(e) ? `[${e.map(r).join(",")}]` : `{${Object.keys(e).filter((t) => e[t] !== void 0).sort().map((t) => `${JSON.stringify(t)}:${r(e[t])}`).join(",")}}`;
		return n.delete(e), t?.set(e, a), a;
	}
	return r(e);
}
var ye = (e, t) => {
	let n = new TextEncoder().encode(b(e, t));
	return _("json.calls"), _("json.bytes", n.byteLength), n;
}, be = (e, t) => b(e) === b(t);
function xe(e, t) {
	let n = /* @__PURE__ */ new WeakMap(), r = /* @__PURE__ */ new Set(), i = (e) => new TextEncoder().encode(b(e)).byteLength, a = (e) => {
		if (!e || typeof e != "object") return Math.min(t + 1, i(e));
		if (r.has(e)) throw new u("VALIDATION_FAILED", "循環したJSONは保存できません。");
		let o = n.get(e);
		if (o !== void 0) return o;
		r.add(e);
		let s = 2;
		if (Array.isArray(e)) {
			s += Math.max(0, e.length - 1);
			for (let n = 0; n < e.length && s <= t; n++) Object.hasOwn(e, n) && (s += a(e[n]));
		} else {
			let n = !0;
			for (let r of Object.keys(e)) {
				let i = e[r];
				if (i !== void 0 && (s += +!n + new TextEncoder().encode(JSON.stringify(r)).byteLength + 1 + a(i), n = !1, s > t)) break;
			}
		}
		return r.delete(e), s = Math.min(s, t + 1), n.set(e, s), s;
	};
	return a(e) > t;
}
async function Se(e) {
	_("hash.calls"), _("hash.bytes", e.byteLength);
	let t = await crypto.subtle.digest("SHA-256", e.slice().buffer);
	return [...new Uint8Array(t)].map((e) => e.toString(16).padStart(2, "0")).join("");
}
function Ce(e) {
	if (!e || e.includes("\0") || e.includes("\\") || e.startsWith("/") || /^[a-z]:/i.test(e) || e.split("/").some((e) => !e || e === "." || e === "..") || !y(e)) throw new u("UNSAFE_PATH", "危険なファイルパスです。", e);
}
//#endregion
//#region src/domain/pinnedWorlds.ts
function we() {
	return {
		hashes: /* @__PURE__ */ new WeakMap(),
		registryClones: /* @__PURE__ */ new WeakMap(),
		stableRegistries: /* @__PURE__ */ new WeakSet()
	};
}
function Te(e, t) {
	let n = t.registryClones.get(e);
	if (n) return n;
	let r = structuredClone(e);
	return t.registryClones.set(e, r), t.stableRegistries.add(r), r;
}
function Ee(e, t) {
	let n = [], r = [], i = [], a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = [...e.worldReferences].reverse().map((e) => ({ reference: e })), u = 0;
	for (; l.length;) {
		if (++u > 2e5) {
			i.push("共通世界の依存数が安全上限を超えています。");
			break;
		}
		let e = l.pop();
		if ("exit" in e) {
			o.delete(e.exit);
			continue;
		}
		let d = e.reference, f = d.immutableSnapshotId;
		if (o.has(f)) {
			i.push("共通世界の固定版参照が循環しています。");
			continue;
		}
		let p = c.get(f);
		if (p && p !== d.contentHash) {
			i.push("同じ共通世界の固定版に異なる内容ハッシュが指定されています。");
			continue;
		}
		c.set(f, d.contentHash);
		let m = s.get(d.projectId);
		if (m && m !== f) {
			i.push("同じ共通世界の異なる版が同時に参照されています。");
			continue;
		}
		if (s.set(d.projectId, f), a.has(f)) continue;
		let h = t[f];
		if (!h || h.projectId !== d.projectId) {
			i.push("参照した共通世界の固定版がありません。");
			continue;
		}
		if (a.add(f), o.add(f), r.push(d), n.push(h), l.push({ exit: f }), !Array.isArray(h.worldReferences)) {
			i.push("共通世界の依存参照が不正です。");
			continue;
		}
		for (let e of [...h.worldReferences].reverse()) l.push({ reference: e });
	}
	return {
		worlds: n,
		references: r,
		errors: i
	};
}
async function De(e, t, n = "worldReferences", r) {
	let i = Ee(e, t), a = i.errors.map((e) => ({
		code: "REFERENCE_INVALID",
		path: n,
		message: e
	}));
	for (let e of i.references) {
		let i = t[e.immutableSnapshotId];
		if (!i) continue;
		let o = `${e.immutableSnapshotId}\0${e.contentHash}`, s = r?.hashes.get(i);
		r && !s && (s = /* @__PURE__ */ new Map(), r.hashes.set(i, s));
		let c = s?.get(o);
		c || (c = Se(ye(i)), s?.set(o, c)), await c !== e.contentHash && a.push({
			code: "INTEGRITY_FAILED",
			path: `${n}.${e.projectId}.${e.immutableSnapshotId}.contentHash`,
			message: "共通世界の固定版内容ハッシュが一致しません。"
		});
	}
	return a;
}
//#endregion
//#region src/domain/adoption.ts
function Oe(e) {
	return !e.deletedAt && e.status !== "rejected" && e.status !== "alternate";
}
//#endregion
//#region src/domain/reuse.ts
var ke = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), je = /* @__PURE__ */ new WeakMap(), Me = (e, t) => ke.get(e)?.get(t), Ne = (e) => Ae.get(e) ?? e, Pe = (e) => e.kind === "scene" || e.kind === "flow_node";
function Fe(e, t) {
	let n = e;
	for (let e of t.replace(/\[(\d+)\]/g, ".$1").split(".")) {
		if (!n || typeof n != "object") return;
		if ("sourceVersionId" in n && typeof n.sourceVersionId == "string") return n.sourceVersionId;
		n = n[e];
	}
}
function x(e) {
	throw Object.assign(/* @__PURE__ */ Error(`REFERENCE_INVALID: ${e}`), { issues: [{
		code: "REFERENCE_INVALID",
		path: "reuse",
		message: e
	}] });
}
function Ie(e) {
	if (Array.isArray(e)) return e.flatMap(Ie);
	if (!e || typeof e != "object") return [];
	let t = e;
	return [...typeof t.id == "string" && ("text" in t && "kind" in t || "audienceHolderIds" in t || "eventKey" in t || "x" in t && "y" in t) ? [t.id] : [], ...Object.values(t).flatMap(Ie)];
}
function Le(e, t, n) {
	let r = new Map(e.entities.filter(Oe).map((e) => [e.id, e])), i = new Map(e.entities.flatMap((e) => Ie(e.data).map((t) => [t, e.id]))), a = /* @__PURE__ */ new Map();
	for (let e of r.values()) e.kind === "disclosure" && a.set(e.data.anchor.entityId, [...a.get(e.data.anchor.entityId) ?? [], e]);
	let o = [t], s = /* @__PURE__ */ new Set(), c = [];
	for (let e = 0; e < o.length; e++) {
		let t = o[e];
		if (s.has(t)) continue;
		s.add(t);
		let n = r.get(t);
		n || x("共通元の依存情報が存在しないか、不採用です。"), c.push(n);
		for (let e of a.get(t) ?? []) o.push(e.id);
		for (let e of Jn(n)) {
			if (n.kind === "scene" && e.path === "data.chapterId" || Fe(n, e.path) || ![
				"entity",
				"record",
				"presentation",
				"block"
			].includes(e.scope)) continue;
			let t = r.has(e.id) ? e.id : i.get(e.id);
			t && o.push(t);
		}
		c.length > 1e5 && x("共通元の依存情報が100,000件を超えています。");
	}
	return c;
}
var Re = (e) => [...new Set(e.flatMap((e) => [e.id, ...Ie(e.data)]))], ze = (e, t) => b(e) === b(t);
function Be(e, t, n) {
	return !!t && [
		"variable",
		"item",
		"character",
		"place",
		"group",
		"assertion",
		"external_contract"
	].includes(e.kind) && t.kind === e.kind && Oe(t) && e.status === t.status && e.name === t.name && ze(Qn(e, n).data, t.data);
}
function Ve(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => Ve(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	typeof n.id == "string" && ("text" in n && "kind" in n || "audienceHolderIds" in n || "eventKey" in n || "x" in n && "y" in n) && (n.id = t[n.id] ?? n.id), Object.values(n).forEach((e) => Ve(e, t));
}
function He(e, t, n, r) {
	let i = Qn(e, t);
	i.id = t[e.id] ?? e.id, i.projectId = n, Ve(i.data, t);
	for (let t of Jn(e)) if (Fe(e, t.path)) {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split("."), n = i;
		for (let t of e.slice(0, -1)) n = n[t];
		n[e.at(-1)] = t.id;
	}
	return i;
}
function Ue(e, t, n = []) {
	if (ke.has(e) || !e.entities.some((e) => Oe(e) && Pe(e) && e.data.reuse && e.data.reuse.mode !== "clone")) return e;
	let r = new Map(e.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set([
		...e.entities.flatMap((e) => [e.id, ...Ie(e.data)]),
		...e.relations.map((e) => e.id),
		...e.views.map((e) => e.id),
		e.projectId
	]), s = new Map(e.worldReferences.map((e) => [e.projectId, e]));
	for (let c of e.entities) {
		if (!Oe(c) || !Pe(c) || !c.data.reuse || c.data.reuse.mode === "clone") continue;
		let l = c.data.reuse, u = t.find((e) => e.id === l.pinnedSnapshotId);
		(!u || u.content.projectId !== e.projectId) && x("共通元の固定版がありません。"), (n.includes(u.id) || n.length >= 32) && x("共通元の固定参照が循環しているか、32段を超えています。");
		let d = Ue(u.content, t, [...n, u.id]), f = d.entities.find((e) => e.id === l.sourceId && Oe(e));
		(!f || f.kind !== c.kind || !Pe(f)) && x("共通元の種類が一致しないか、固定版で不採用です。");
		let p = Le(d, f.id, u.id), m = Re(p), h = l.bindings;
		(!h || h[f.id] !== c.id || m.length !== Object.keys(h).length || m.some((e) => !h[e]) || new Set(Object.values(h)).size !== m.length) && x("共通元のID対応が欠落・重複しています。対象版を確認して再設定してください。");
		for (let [e, t] of Object.entries(h)) if (t !== c.id && o.has(t)) {
			let n = p.find((t) => t.id === e);
			(e !== t || !n || !Be(n, r.get(t), h)) && x("共通元の実行用IDが現在稿のレコード・段落・関係と衝突しています。ID対応を確認し直してください。");
		}
		let ee = new Set(Object.keys(f.data).filter((e) => !["reuse", "chapterId"].includes(e)));
		(l.mode === "reference" && l.overrideFields.length || l.overrideFields.some((e) => !ee.has(e))) && x("上書き対象が不正です。宣言したフィールドだけを上書きしてください。");
		for (let e of d.worldReferences) {
			let t = s.get(e.projectId);
			t && !ze(t, e) && x("共通元と使用先が同じ世界の異なる固定版を要求しています。適用する版を明示して揃えてください。"), s.set(e.projectId, e);
		}
		let te = d.entities.find((e) => e.kind === "flow_graph" && f.kind === "flow_node" && e.data.nodeIds.includes(f.id)), g = f.kind === "scene" ? f : d.entities.find((e) => f.kind === "flow_node" && e.id === f.data.sceneId && e.kind === "scene");
		for (let t of p) {
			let n = He(t, h, e.projectId, u.id), o = n.id, s = r.get(o);
			if (o !== c.id && s) {
				(t.id !== o || !Be(t, s, h)) && x("共通元の実行用IDが現在稿と衝突しています。対応を再確認してください。");
				continue;
			}
			let f = Me(d, t.id), p = f ? Object.fromEntries(Object.entries(f.bindings).flatMap(([e, t]) => h[t] ? [[e, h[t]]] : [])) : h;
			i.set(o, {
				entityId: f?.entityId ?? t.id,
				sourceVersionId: f?.sourceVersionId ?? u.id,
				ownerId: c.id,
				bindings: p,
				graphId: te ? h[te.id] ?? te.id : void 0,
				chapterId: g?.kind === "scene" && g.data.chapterId ? h[g.data.chapterId] ?? g.data.chapterId : void 0
			});
			let m = /* @__PURE__ */ new Map();
			for (let [e, n] of je.get(d)?.get(t.id) ?? []) {
				let r = n ? Object.fromEntries(Object.entries(n.bindings).flatMap(([e, t]) => h[t] ? [[e, h[t]]] : [])) : h;
				m.set(e, {
					entityId: n?.entityId ?? t.id,
					sourceVersionId: n?.sourceVersionId ?? u.id,
					ownerId: c.id,
					bindings: r
				});
			}
			if (o === c.id) {
				for (let e of l.overrideFields) m.set(e, null);
				c.kind === "scene" && m.set("chapterId", null);
			}
			if (m.size && a.set(o, m), o === c.id) {
				let e = { ...n.data };
				delete e.reuse;
				for (let t of l.overrideFields) Object.hasOwn(c.data, t) ? e[t] = structuredClone(c.data[t]) : delete e[t];
				c.kind === "scene" && (e.chapterId = c.data.chapterId ?? null), r.set(o, {
					...c,
					data: e
				});
			} else r.set(o, n);
		}
		r.size > 1e5 && x("再利用を解決した実行情報が100,000件を超えています。");
	}
	let c = /* @__PURE__ */ new Set();
	for (let t of [...r.values()].flatMap((e) => [e.id, ...Ie(e.data)]).concat(e.relations.map((e) => e.id), e.views.map((e) => e.id))) c.has(t) && x("再利用先どうしでレコード・段落等のIDが衝突しています。ID対応を確認し直してください。"), c.add(t);
	let l = {
		...e,
		entities: [...r.values()],
		worldReferences: [...s.values()]
	};
	return ke.set(l, i), je.set(l, a), Ae.set(l, e), l;
}
function We(e, t) {
	return Object.fromEntries([...ke.get(e) ?? []].map(([e, n]) => [e, {
		...t,
		graphId: t.graphId ? n.bindings[t.graphId] ?? t.graphId : void 0,
		chapterId: t.chapterId ? n.bindings[t.chapterId] ?? t.chapterId : void 0,
		sourceVersionId: n.sourceVersionId,
		anchorBindings: n.bindings
	}]));
}
function Ge(e, t, n) {
	let r = Me(e, n);
	return !r || t.sourceVersionId !== r.sourceVersionId ? t : {
		...t,
		entityId: r.bindings[t.entityId] ?? t.entityId,
		...t.blockId ? { blockId: r.bindings[t.blockId] ?? t.blockId } : {},
		...t.lineId ? { lineId: r.bindings[t.lineId] ?? t.lineId } : {}
	};
}
function Ke(e, t, n) {
	if (!e.entities.some((e) => Pe(e) && e.data.reuse?.bindings)) return [];
	try {
		return Ue(e, t), [];
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: `${n}.reuse`,
			message: e.message
		}];
	}
}
//#endregion
//#region src/domain/types.ts
var qe = "1.0.0", Je = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/, Ye = 10n ** 38n - 1n, Xe = {
	id: "proleptic-gregorian-second",
	name: "先発グレゴリオ暦",
	kind: "gregorian",
	originLabel: "0000-01-01 00:00:00",
	ticksPerDay: "86400"
};
function Ze(e) {
	return typeof e == "string" && Je.test(e);
}
function S(e) {
	if (!Ze(e)) throw RangeError("tickは38桁以内の正規整数文字列で指定してください。");
	return BigInt(e);
}
function Qe(e) {
	if (e < -Ye || e > Ye) throw RangeError("tickが38桁の範囲を超えています。");
	return e.toString();
}
function $e(e, t) {
	return Qe(S(e) + S(t));
}
function C(e, t) {
	let n = S(e), r = S(t);
	return n < r ? -1 : +(n > r);
}
function et(e, t = "calendar") {
	let n = (e, n = t) => ({
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: n,
			message: e
		}]
	});
	if (!e || typeof e != "object" || Array.isArray(e)) return n("暦はオブジェクトです。");
	let r = e, i = r.kind === "repeating" ? [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay",
		"years"
	] : [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay"
	];
	if (Object.keys(r).some((e) => !i.includes(e))) return n("暦に未知の項目があります。");
	if (typeof r.id != "string" || !r.id || typeof r.name != "string" || !r.name || typeof r.originLabel != "string") return n("暦のID・名称・原点ラベルが必要です。");
	if (!Ze(r.ticksPerDay) || S(r.ticksPerDay) <= 0n) return n("1日のtick数は正の整数です。", `${t}.ticksPerDay`);
	if (r.kind === "gregorian") return r.ticksPerDay === "86400" ? {
		ok: !0,
		value: e
	} : n("標準暦は1日86400tickです。", `${t}.ticksPerDay`);
	if (r.kind !== "repeating" || !Array.isArray(r.years) || r.years.length < 1 || r.years.length > 400) return n("繰返し暦は1〜400年の周期が必要です。");
	for (let e = 0; e < r.years.length; e++) {
		let i = r.years[e];
		if (!i || typeof i != "object" || Object.keys(i).some((e) => e !== "months") || !Array.isArray(i.months) || i.months.length < 1 || i.months.length > 24) return n("1年の月数は1〜24です。", `${t}.years[${e}]`);
		for (let r = 0; r < i.months.length; r++) {
			let a = i.months[r];
			if (!a || typeof a != "object" || Object.keys(a).some((e) => !["name", "days"].includes(e)) || typeof a.name != "string" || !a.name || !Number.isInteger(a.days) || a.days < 1 || a.days > 400) return n("月名と1〜400の日数が必要です。", `${t}.years[${e}].months[${r}]`);
		}
	}
	return {
		ok: !0,
		value: e
	};
}
function tt(e, t) {
	try {
		return e.mode === "unknown" ? {
			status: "unknown",
			reason: e.reason || "日時が未定です。",
			path: t
		} : e.mode === "instant" ? (S(e.at), {
			status: "resolved",
			earliest: e.at,
			latest: e.at,
			endEarliest: e.at,
			endLatest: e.at,
			calendarId: e.calendarId,
			mode: e.mode
		}) : e.mode === "interval" ? C(e.start, e.end) >= 0 ? {
			status: "conflict",
			reason: "期間は開始より後に終了してください。",
			path: t
		} : {
			status: "resolved",
			earliest: e.start,
			latest: e.start,
			endEarliest: e.end,
			endLatest: e.end,
			calendarId: e.calendarId,
			mode: e.mode
		} : C(e.earliest, e.latest) > 0 ? {
			status: "conflict",
			reason: "概算範囲が逆転しています。",
			path: t
		} : {
			status: "resolved",
			earliest: e.earliest,
			latest: e.latest,
			endEarliest: e.earliest,
			endLatest: e.latest,
			calendarId: e.calendarId,
			mode: e.mode
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: t
		};
	}
}
function nt(e, t, n, r) {
	try {
		if (C(e.minOffset, e.maxOffset) > 0) return {
			status: "conflict",
			reason: "相対日時の範囲が逆転しています。",
			path: n()
		};
		if (t.status !== "resolved") return r ? {
			...t,
			path: [...n(), ...t.path].slice(0, 64)
		} : t;
		let i = $e(e.anchorPoint === "start" ? t.earliest : t.endEarliest, e.minOffset), a = $e(e.anchorPoint === "start" ? t.latest : t.endLatest, e.maxOffset);
		return {
			status: "resolved",
			earliest: i,
			latest: a,
			endEarliest: i,
			endLatest: a,
			calendarId: t.calendarId,
			mode: "relative"
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: n()
		};
	}
}
function rt(e, t, n = []) {
	return nt(e, t, () => n, !0);
}
function it(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) !n.deletedAt && !t.has(n.id) && t.set(n.id, n);
	return t;
}
function at(e, t = [], n = []) {
	if (e.mode !== "relative") return tt(e, n);
	let r = it(t), i = [...n], a = new Set(n), o = [], s = e;
	for (; s.mode === "relative";) {
		if (a.has(s.anchorEventId)) return {
			status: "conflict",
			reason: "相対日時の参照が循環しています。",
			path: [...i, s.anchorEventId]
		};
		try {
			if (C(s.minOffset, s.maxOffset) > 0) return {
				status: "conflict",
				reason: "相対日時の範囲が逆転しています。",
				path: [...i]
			};
		} catch (e) {
			return {
				status: "conflict",
				reason: e instanceof Error ? e.message : "日時を解決できません。",
				path: [...i]
			};
		}
		let e = r.get(s.anchorEventId);
		if (!e) return {
			status: "unknown",
			reason: "基準となる出来事がありません。",
			path: [...i, s.anchorEventId]
		};
		o.push({
			time: s,
			pathLength: i.length
		}), a.add(e.id), i.push(e.id), s = e.data.time;
	}
	let c = tt(s, i);
	for (let e = o.length - 1; e >= 0 && c.status === "resolved"; e--) {
		let t = o[e];
		c = nt(t.time, c, () => i.slice(0, t.pathLength), !1);
	}
	return c;
}
function ot(e) {
	let t = it(e), n = /* @__PURE__ */ new Map();
	for (let e of t.values()) {
		if (n.has(e.id)) continue;
		let r = [], i = /* @__PURE__ */ new Map(), a = e.id;
		for (; !n.has(a);) {
			let e = t.get(a);
			if (!e) {
				n.set(a, {
					status: "unknown",
					reason: "基準となる出来事がありません。",
					path: [a]
				});
				break;
			}
			let o = i.get(a);
			if (o !== void 0) {
				let e = r.slice(o);
				for (let t = 0; t < e.length; t++) n.set(e[t], {
					status: "conflict",
					reason: "相対日時の参照が循環しています。",
					path: Array.from({ length: Math.min(e.length + 1, 64) }, (n, r) => e[(t + r) % e.length])
				});
				break;
			}
			if (e.data.time.mode !== "relative") {
				n.set(a, tt(e.data.time, [a]));
				break;
			}
			let s = e.data.time;
			if (!i.has(s.anchorEventId) && s.anchorEventId !== a) try {
				if (C(s.minOffset, s.maxOffset) > 0) {
					n.set(a, {
						status: "conflict",
						reason: "相対日時の範囲が逆転しています。",
						path: [a]
					});
					break;
				}
			} catch (e) {
				n.set(a, {
					status: "conflict",
					reason: e instanceof Error ? e.message : "日時を解決できません。",
					path: [a]
				});
				break;
			}
			i.set(a, r.length), r.push(a), a = s.anchorEventId;
		}
		for (let e = r.length - 1; e >= 0; e--) {
			let i = r[e], a = t.get(i);
			!n.has(i) && a.data.time.mode === "relative" && n.set(i, rt(a.data.time, n.get(a.data.time.anchorEventId), [i]));
		}
	}
	return n;
}
function st(e) {
	let t = [], n = it(e), r = ot(e);
	for (let e of n.values()) {
		let i = r.get(e.id);
		i.status === "conflict" && t.push({
			code: "TIME_CONSTRAINT_CONFLICT",
			path: `entities.${e.id}.data.time`,
			message: i.reason
		});
		for (let a of e.data.constraints ?? []) {
			let o = n.get(a.targetEventId);
			if (!o || i.status !== "resolved") continue;
			let s = r.get(o.id);
			if (s.status !== "resolved") continue;
			let c = i.calendarId !== s.calendarId;
			if (a.type === "before") c ||= i.mode === "interval" ? C(i.endEarliest, s.latest) > 0 : C(i.endEarliest, s.latest) >= 0;
			else if (a.type === "same_start") c ||= C(i.earliest, s.latest) > 0 || C(s.earliest, i.latest) > 0;
			else {
				let e = S(s.earliest) - S(i.endLatest), t = S(s.latest) - S(i.endEarliest);
				c ||= t < S(a.minimumTicks) || e > S(a.maximumTicks);
			}
			c && t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "指定した出来事の日時制約と矛盾しています。"
			});
		}
	}
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
	for (let e of n.values()) a.set(e.id, (e.data.constraints ?? []).map((e) => e.targetEventId));
	for (let e of n.values()) e.data.time.mode === "relative" && n.has(e.data.time.anchorEventId) && a.get(e.data.time.anchorEventId).push(e.id);
	for (let e of n.values()) {
		if (i.get(e.id)) continue;
		let r = [{
			id: e.id,
			targets: a.get(e.id),
			cursor: 0
		}];
		for (i.set(e.id, 1); r.length;) {
			let e = r[r.length - 1];
			if (e.cursor === e.targets.length) {
				i.set(e.id, 2), r.pop();
				continue;
			}
			let o = e.targets[e.cursor++], s = n.get(o);
			s && (i.get(o) === 1 ? t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "日時制約の依存が循環しています。"
			}) : i.has(o) || (i.set(o, 1), r.push({
				id: o,
				targets: a.get(s.id),
				cursor: 0
			})));
		}
	}
	return t;
}
function ct(e, t) {
	return e.id !== t.id || e.kind !== t.kind || e.name !== t.name || e.originLabel !== t.originLabel || e.ticksPerDay !== t.ticksPerDay ? !1 : e.kind === "gregorian" || t.kind === "gregorian" ? e.kind === t.kind : e.years.length === t.years.length && e.years.every((e, n) => e.months.length === t.years[n].months.length && e.months.every((e, r) => e.name === t.years[n].months[r].name && e.days === t.years[n].months[r].days));
}
//#endregion
//#region src/domain/templates.ts
var w = (e, t, n = "VALIDATION_FAILED") => ({
	path: e,
	message: t,
	code: n
}), lt = [
	"id",
	"projectId",
	"kind",
	"revision",
	"name",
	"status",
	"visibility",
	"retainIfUnreferenced",
	"projectionProfileId",
	"templateId",
	"createdAt",
	"updatedAt",
	"deletedAt",
	"deletionOperationId",
	"customValues",
	"data"
], ut = [
	"__proto__",
	"prototype",
	"constructor"
], dt = [
	"text",
	"number",
	"boolean",
	"enum",
	"date",
	"ref"
];
function ft(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = e;
	return typeof t.key == "string" && typeof t.label == "string" && dt.includes(t.type) && typeof t.required == "boolean" && typeof t.nullable == "boolean" && (t.help == null || typeof t.help == "string") && (t.allowedValues == null || Array.isArray(t.allowedValues) && t.allowedValues.every((e) => typeof e == "string")) && (t.targetKinds == null || Array.isArray(t.targetKinds) && t.targetKinds.every((e) => Object.hasOwn(yn, e)));
}
function pt(e) {
	let t = yn[e];
	return [...lt, ...t?.type === "object" ? Object.keys(t.fields) : []];
}
function mt(e, t, n, r) {
	if (t === void 0) return e.required ? [w(n, `「${e.label}」は必須項目です。`)] : [];
	if (t === null) return e.nullable ? [] : [w(n, `「${e.label}」は空欄を許可していません。`)];
	let i = !1;
	if (e.type === "text" && (i = typeof t == "string" && (!e.required || t.trim().length > 0)), e.type === "number" && (i = typeof t == "number" && Number.isFinite(t)), e.type === "boolean" && (i = typeof t == "boolean"), e.type === "enum" && (i = typeof t == "string" && !!e.allowedValues?.includes(t)), e.type === "date" || e.type === "ref") {
		let a = t && typeof t == "object" && !Array.isArray(t) ? t : void 0;
		if (i = a?.type === e.type && typeof a.value == "string", i && e.type === "date") {
			let e = a.value, t = /^\d{4}-\d{2}-\d{2}$/.test(e) ? /* @__PURE__ */ new Date(`${e}T00:00:00.000Z`) : /* @__PURE__ */ new Date(NaN);
			i = Number.isFinite(t.getTime()) && t.toISOString().slice(0, 10) === e;
		}
		if (i && e.type === "ref") {
			let t = a.value;
			if (!Pt.test(t)) i = !1;
			else if (r) {
				let i = "get" in r ? r.get(t) : r.find((e) => e.id === t);
				if (!i || i.deletedAt || e.targetKinds?.length && !e.targetKinds.includes(i.kind)) return [w(n, `「${e.label}」の参照先が存在しないか、許可された種類ではありません。`, "REFERENCE_INVALID")];
			}
		}
	}
	return i ? [] : [w(n, `「${e.label}」の値が宣言した${e.type}型または選択候補と一致しません。`)];
}
function ht(e, t = "data", n) {
	let r = [];
	if (!e || !Array.isArray(e.fields)) return [w(`${t}.fields`, "項目定義は配列で入力してください。")];
	Object.hasOwn(yn, e.targetKind) || r.push(w(`${t}.targetKind`, "対象の情報の種類を選んでください。")), e.defaults != null && (typeof e.defaults != "object" || Array.isArray(e.defaults)) && r.push(w(`${t}.defaults`, "初期値は項目キーごとの辞書で指定してください。"));
	let i = /* @__PURE__ */ new Set(), a = new Set(pt(e.targetKind));
	for (let [o, s] of e.fields.entries()) {
		let e = `${t}.fields[${o}]`;
		if (!ft(s)) {
			r.push(w(e, "項目定義のキー・表示名・型・必須・空欄・説明・候補・参照先の形式を確認してください。"));
			continue;
		}
		(!s.key.trim() || i.has(s.key) || a.has(s.key) || ut.includes(s.key)) && r.push(w(`${e}.key`, "キーが空欄・重複・予約済み、または標準項目と衝突しています。")), i.add(s.key), s.type === "enum" && (!Array.isArray(s.allowedValues) || !s.allowedValues.length || s.allowedValues.some((e) => typeof e != "string" || !e.trim()) || new Set(s.allowedValues).size !== s.allowedValues.length) && r.push(w(`${e}.allowedValues`, "選択型には空欄と重複のない候補を指定してください。")), s.type !== "enum" && s.allowedValues?.length && r.push(w(`${e}.allowedValues`, "選択候補はenum型だけに設定できます。")), s.type !== "ref" && s.targetKinds?.length && r.push(w(`${e}.targetKinds`, "参照先の種類はref型だけに設定できます。")), Object.hasOwn(s, "default") ? r.push(...mt(s, s.default, `${e}.default`, n)) : r.push(w(`${e}.default`, "項目の初期値を指定してください。"));
	}
	let o = e.fields.filter(ft), s = e.defaults && typeof e.defaults == "object" && !Array.isArray(e.defaults) ? e.defaults : {};
	for (let [e, i] of Object.entries(s)) {
		let a = o.find((t) => t.key === e);
		a ? r.push(...mt(a, i, `${t}.defaults.${e}`, n)) : r.push(w(`${t}.defaults.${e}`, "初期値のキーを項目定義へ追加してください。"));
	}
	return r;
}
function gt(e, t = "project", n = e.entities) {
	let r = new Map(n.filter((e) => e.kind === "template").map((e) => [e.id, e])), i = [], a = new Map(n.map((e) => [e.id, e]));
	return e.entities.forEach((e, n) => {
		let o = e;
		if (e.deletedAt || !o.templateId) return;
		let s = `${t}.entities[${n}]`, c = r.get(o.templateId);
		if (!c || c.deletedAt || c.status === "rejected" || c.data.targetKind !== e.kind) {
			i.push(w(`${s}.templateId`, "適用した雛形が存在しない・不採用・削除済み、または対象の種類が異なります。", "REFERENCE_INVALID"));
			return;
		}
		for (let t of c.data.fields) i.push(...mt(t, e.customValues[t.key], `${s}.customValues.${t.key}`, a));
	}), i;
}
//#endregion
//#region src/domain/textMetrics.ts
var _t = 512, vt = 4096, yt = 1048576, bt = /* @__PURE__ */ new Map(), xt = 0;
function St(e) {
	let t = bt.get(e);
	if (t) return t;
	let n = 0, r = 0, i = !0;
	for (let t = 0; t < e.length; t++, n++) {
		let n = e.charCodeAt(t);
		if (n < 128) r++;
		else if (n < 2048) r += 2;
		else if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			n >= 56320 && n <= 57343 ? (r += 4, t++) : (r += 3, i = !1);
		} else r += 3, n >= 56320 && n <= 57343 && (i = !1);
	}
	let a = Object.freeze({
		codePoints: n,
		utf8Bytes: r,
		validUnicode: i
	});
	if (e.length <= vt) {
		let t = e.length * 2;
		for (; bt.size >= _t || xt + t > yt;) {
			let e = bt.keys().next().value;
			xt -= e.length * 2, bt.delete(e);
		}
		bt.set(e, a), xt += t;
	}
	return a;
}
//#endregion
//#region src/domain/immutablePlainData.ts
var T = /* @__PURE__ */ new WeakSet();
function Ct(e, t, n = /* @__PURE__ */ new WeakSet(), r = /* @__PURE__ */ new WeakSet(), i = 0) {
	if (i > 128) return !1;
	if (typeof e != "object" || !e) return ![
		"function",
		"symbol",
		"bigint"
	].includes(typeof e);
	if (T.has(e)) return !0;
	if (n.has(e)) return !1;
	if (r.has(e)) return !0;
	let a = Array.isArray(e), o = Object.getPrototypeOf(e);
	if ((a ? o !== Array.prototype : o !== Object.prototype && o !== null) || t && !Object.isFrozen(e)) return !1;
	let s = Object.getOwnPropertyDescriptors(e), c = Reflect.ownKeys(e);
	if (c.some((e) => typeof e != "string" || [
		"__proto__",
		"constructor",
		"prototype"
	].includes(e)) || a && (c.length !== e.length + 1 || c.some((t) => t !== "length" && (!/^(0|[1-9]\d*)$/.test(String(t)) || Number(t) >= e.length)))) return !1;
	n.add(e);
	for (let o of c) {
		if (a && o === "length") continue;
		let c = s[o];
		if (!c.enumerable || !Object.hasOwn(c, "value") || !Ct(c.value, t, n, r, i + 1)) return n.delete(e), !1;
	}
	return n.delete(e), r.add(e), t && T.add(e), !0;
}
function wt(e) {
	return Ct(e, !0);
}
function Tt(e) {
	let t = /* @__PURE__ */ new WeakSet(), n = /* @__PURE__ */ new WeakSet(), r = [], i = [], a = (e, i) => {
		if (i > 128) return !1;
		if (typeof e != "object" || !e) return ![
			"function",
			"symbol",
			"bigint"
		].includes(typeof e);
		if (T.has(e)) return !0;
		if (t.has(e)) return !1;
		if (n.has(e)) return !0;
		let a = Array.isArray(e), o = Object.getPrototypeOf(e);
		if (a ? o !== Array.prototype : o !== Object.prototype && o !== null) return !1;
		let s = Reflect.ownKeys(e);
		return a && s.length !== e.length + 1 ? !1 : (t.add(e), r.push({
			value: e,
			keys: s,
			index: 0,
			depth: i,
			array: a
		}), !0);
	};
	if (!a(e, 0)) return !1;
	for (; r.length;) {
		let e = r.at(-1);
		if (e.index === e.keys.length) r.pop(), t.delete(e.value), n.add(e.value), i.push(e.value);
		else {
			let t = e.keys[e.index++];
			if (typeof t != "string" || [
				"__proto__",
				"constructor",
				"prototype"
			].includes(t)) return !1;
			if (e.array && t === "length") continue;
			if (e.array && (!/^(0|[1-9]\d*)$/.test(t) || Number(t) >= e.value.length)) return !1;
			let n = Object.getOwnPropertyDescriptor(e.value, t);
			if (!n?.enumerable || !Object.hasOwn(n, "value") || !a(n.value, e.depth + 1)) return !1;
		}
	}
	for (let e of i) Object.freeze(e), T.add(e);
	return !0;
}
async function Et(e, t) {
	let n = /* @__PURE__ */ new WeakSet(), r = /* @__PURE__ */ new WeakSet(), i = [], a = [], o = performance.now() + 16, s = 0, c = () => ++s % 128 == 0 && performance.now() >= o, l = async () => {
		d(t), await new Promise((e) => setTimeout(e, 0)), d(t), o = performance.now() + 16;
	}, u = (e, t) => {
		if (t > 128) return !1;
		if (typeof e != "object" || !e) return ![
			"function",
			"symbol",
			"bigint"
		].includes(typeof e);
		if (T.has(e)) return !0;
		if (n.has(e)) return !1;
		if (r.has(e)) return !0;
		let a = Array.isArray(e), o = Object.getPrototypeOf(e);
		if (a ? o !== Array.prototype : o !== Object.prototype && o !== null) return !1;
		let s = Reflect.ownKeys(e);
		return a && s.length !== e.length + 1 ? !1 : (n.add(e), i.push({
			value: e,
			keys: s,
			index: 0,
			depth: t,
			array: a
		}), !0);
	};
	if (d(t), !u(e, 0)) return !1;
	for (; i.length;) {
		let e = i.at(-1);
		if (e.index === e.keys.length) i.pop(), n.delete(e.value), r.add(e.value), a.push(e.value);
		else {
			let t = e.keys[e.index++];
			if (typeof t != "string" || [
				"__proto__",
				"constructor",
				"prototype"
			].includes(t)) return !1;
			if (e.array && t === "length") continue;
			if (e.array && (!/^(0|[1-9]\d*)$/.test(t) || Number(t) >= e.value.length)) return !1;
			let n = Object.getOwnPropertyDescriptor(e.value, t);
			if (!n?.enumerable || !Object.hasOwn(n, "value") || !u(n.value, e.depth + 1)) return !1;
		}
		c() && await l();
	}
	d(t);
	for (let e of a) Object.freeze(e), T.add(e), c() && await l();
	return d(t), !0;
}
function E(e) {
	if (wt(e)) return {
		value: e,
		captured: !0
	};
	if (!Ct(e, !1)) return {
		value: e,
		captured: !1
	};
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object" || T.has(e)) return e;
		let r = t.get(e);
		if (r) return r;
		let i = Array.isArray(e) ? Array(e.length) : Object.create(Object.getPrototypeOf(e));
		t.set(e, i);
		for (let [t, r] of Object.entries(Object.getOwnPropertyDescriptors(e))) Array.isArray(e) && t === "length" || Object.defineProperty(i, t, {
			value: n(r.value),
			enumerable: !0
		});
		return Object.freeze(i), T.add(i), i;
	};
	return {
		value: n(e),
		captured: !0
	};
}
//#endregion
//#region src/domain/contentValidationMemo.ts
function Dt(e, t, n) {
	if (!wt(e)) return;
	let r = E(t);
	if (!r.captured) return;
	let i = E({
		...r.value,
		relationTypes: r.value.relationTypes ?? n
	});
	if (!i.captured) return;
	let a = [], o = /* @__PURE__ */ new WeakMap(), s = 0, c = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), u = 0, d = (e, t, n) => {
		if (!wt(e)) return;
		let r = E(t);
		r.captured && (u >= 1e5 && (c = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), u = 0), n ? c.set(e, r.value) : l.set(e, r.value), u++);
	}, f = (e, t) => e.length === t.length && e.every((e, n) => e === t[n]), p = (e, t, n, r) => {
		let i = e.content;
		return i.projectId === t.projectId && i.formatVersion === t.formatVersion && i.calendarId === t.calendarId && i.mainStart === t.mainStart && i.entities === t.entities && i.relations === t.relations && i.calendars === t.calendars && f(i.views, t.views) && f(i.worldReferences, t.worldReferences) && e.ids.size === n.size && [...n].every((t) => e.ids.has(t)) && e.versions.size === r.size && [...r].every(([t, n]) => e.versions.get(t) === n);
	}, m = (e, t, n, r) => {
		let i = e.content;
		return i.projectId === t.projectId && i.formatVersion === t.formatVersion && i.calendarId === t.calendarId && i.mainStart === t.mainStart && f(i.calendars, t.calendars) && f(i.worldReferences, t.worldReferences) && f(i.views, t.views) && e.ids.size === n.size && [...n].every((t) => e.ids.has(t)) && e.versions.size === r.size && [...r].every(([t, n]) => e.versions.get(t) === n);
	};
	return {
		options: i.value,
		memo: {
			contentIds: (e) => o.get(e),
			rememberContentIds(e, t) {
				wt(e) && (s >= 1e5 && (o = /* @__PURE__ */ new WeakMap(), s = 0), o.set(e, t), s++);
			},
			entityReferences: (e) => c.get(e),
			relationReferences: (e) => l.get(e),
			rememberEntity: (e, t) => d(e, t, !0),
			rememberRelation: (e, t) => d(e, t, !1),
			has: (e, t, n) => {
				let r = a.some((r) => p(r, e, t, n));
				return _(r ? "memo.hit" : "memo.miss"), r;
			},
			previousContent(e, t, n) {
				for (let r = a.length - 1; r >= 0; r--) {
					let i = a[r];
					if (m(i, e, t, n)) return i.content;
				}
			},
			remember(e, t, n) {
				let r = E(e);
				r.captured && (a.length >= 256 && (a = []), a.push({
					content: r.value,
					ids: new Set(t),
					versions: new Map(n)
				}));
			}
		}
	};
}
//#endregion
//#region src/domain/model.ts
var Ot = /* @__PURE__ */ s({
	ENTITY_KINDS: () => D,
	ENTITY_SCHEMAS: () => yn,
	ID_PATTERN: () => Pt,
	KIND_LABELS: () => kt,
	RELATION_LABELS: () => Nt,
	RELATION_TYPES: () => Mt,
	REVISION_PATTERN: () => Ft,
	SCOPES: () => jt,
	STATUSES: () => At,
	collectReferences: () => Jn,
	collectRelationReferences: () => Yn,
	createEntity: () => Ut,
	createProject: () => Wt,
	createProjectValidator: () => _r,
	defaultData: () => Ht,
	emptyRuntimeState: () => Gt,
	emptyValidity: () => It,
	getEntitiesByKind: () => Vt,
	getEntity: () => Bt,
	isContentCopyField: () => cr,
	newId: () => Lt,
	rewriteEntityReferences: () => Qn,
	rewriteRelationReferences: () => $n,
	richTextToPlainText: () => zt,
	textToRichText: () => Rt,
	validateCondition: () => Bn,
	validateCurrentProject: () => yr,
	validateEffectData: () => Wn,
	validateInitialPresentationResults: () => Un,
	validateProject: () => hr,
	validateRuntimeState: () => Hn,
	validateTypedValue: () => Vn,
	validateVariableValue: () => $,
	validationSchemaSignature: () => gr
}), kt = {
	character: "人物",
	group: "グループ",
	event: "出来事",
	place: "場所",
	item: "物品",
	note: "メモ",
	chapter: "章",
	scene: "場面",
	goal: "目標",
	flow_node: "進行ノード",
	flow_edge: "進行線",
	flow_graph: "分岐図",
	dialogue_line: "台詞",
	quest: "クエスト",
	lore: "設定",
	variable: "状態変数",
	effect: "効果",
	assertion: "事実・認識",
	foreshadow: "伏線",
	disclosure: "手掛かり・回収",
	checkpoint: "途中開始点",
	trace: "試読記録",
	attachment: "添付素材",
	source: "資料・出所",
	cue: "演出",
	storyboard_frame: "絵コンテ",
	localization: "翻訳",
	recording: "収録",
	terminology: "用語",
	map: "地図",
	travel_route: "移動経路",
	template: "雛形",
	collection: "一覧",
	review: "レビュー",
	creative_brief: "企画",
	decision: "制作判断",
	gameplay_spec: "ゲーム仕様",
	production_task: "制作タスク",
	media_variant: "媒体版",
	voice_rule: "口調",
	external_contract: "外部契約",
	snapshot: "公開版",
	projection_profile: "公開投影"
}, D = Object.keys(kt), At = [
	"confirmed",
	"provisional",
	"needs_review",
	"rejected",
	"alternate"
], jt = [
	"scene",
	"chapter",
	"character",
	"run",
	"across_runs"
], Mt = [
	{
		key: "trust",
		label: "信頼",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "causes",
		label: "因果",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "requires",
		label: "前提",
		fromKinds: D,
		toKinds: D,
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "foreshadow_payoff",
		label: "手掛かり→回収",
		fromKinds: ["disclosure"],
		toKinds: ["disclosure"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "parent_of",
		label: "親子",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_foreshadow",
		label: "出来事の予告",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_payoff",
		label: "出来事の回収",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "mentor_of",
		label: "師弟",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "bloodline",
		label: "血統",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "related",
		label: "関連",
		fromKinds: D,
		toKinds: D,
		allowSelf: !1,
		allowSymmetric: !0
	},
	{
		key: "reference",
		label: "参照",
		fromKinds: D,
		toKinds: D,
		allowSelf: !0,
		allowSymmetric: !1
	}
], Nt = Object.fromEntries(Mt.map((e) => [e.key, e.label])), Pt = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, Ft = /^(?:0|[1-9][0-9]*)$/, It = () => ({
	worldRange: null,
	routeCondition: null,
	presentationAnchor: null
}), Lt = () => crypto.randomUUID();
function Rt(e) {
	return e === "" ? [] : e.split("\n").map((e) => ({
		id: Lt(),
		kind: "paragraph",
		text: e
	}));
}
function zt(e) {
	return (e ?? []).map((e) => e.text).join("\n");
}
function Bt(e, t) {
	return e.entities.find((e) => e.id === t && !e.deletedAt);
}
function Vt(e, t) {
	return e.entities.filter((e) => e.kind === t && !e.deletedAt);
}
function Ht(e) {
	let t = {
		type: "unknown",
		value: null,
		reason: "未入力"
	}, n = {
		character: {
			reading: "",
			aliases: [],
			summary: [],
			body: [],
			authorNotes: [],
			goals: [],
			voiceRules: []
		},
		group: {
			groupType: "display",
			members: [],
			parentId: null,
			summary: []
		},
		event: {
			summary: [],
			time: {
				mode: "unknown",
				reason: ""
			},
			laneRole: "common",
			participants: [],
			locationId: null,
			itemIds: [],
			authorNotes: [],
			constraints: []
		},
		place: {
			parentId: null,
			reading: "",
			aliases: [],
			body: [],
			mapIds: [],
			changes: []
		},
		item: {
			itemMode: "type",
			typeId: null,
			body: [],
			properties: null,
			changes: []
		},
		note: {
			body: [],
			attachmentIds: [],
			convertedToIds: [],
			originNoteId: null
		},
		chapter: {
			sceneIds: [],
			summary: [],
			authorNotes: [],
			structureRole: ""
		},
		scene: {
			summary: [],
			body: [],
			authorNotes: [],
			eventIds: [],
			chapterId: null,
			threadIds: [],
			povId: null,
			goals: [],
			conflicts: [],
			results: [],
			newInformation: [],
			tension: null,
			importance: null,
			blockIds: []
		},
		goal: {
			ownerId: null,
			description: [],
			changes: [],
			evidenceSceneIds: [],
			validity: It()
		},
		flow_node: {
			nodeType: "choice",
			sceneId: null,
			childGraphId: null,
			terminalReason: "",
			gate: {
				op: "constant",
				value: !0
			},
			executionPolicy: "manual_choice",
			fallbackId: null
		},
		flow_edge: {
			fromId: null,
			toId: { unresolved: {
				label: "",
				reason: "未完成"
			} },
			edgeType: "choice",
			label: "",
			condition: {
				op: "constant",
				value: !0
			},
			effectIds: [],
			priority: 0,
			choiceLineId: null
		},
		flow_graph: {
			nodeIds: [],
			edgeIds: [],
			entryIds: [],
			exitIds: [],
			parentGraphId: null,
			parameters: []
		},
		dialogue_line: {
			text: [],
			speakerId: null,
			choiceEdgeId: null,
			cueIds: [],
			originLineIds: []
		},
		quest: {
			key: "",
			stateVariableId: null,
			description: [],
			flowIds: [],
			transitionRules: [],
			gameplaySpecIds: []
		},
		lore: {
			body: [],
			assertionIds: [],
			sourceIds: [],
			reading: "",
			aliases: []
		},
		variable: {
			key: "",
			valueType: "boolean",
			scope: "run",
			initial: t,
			allowed: { values: [!1, !0] },
			description: [],
			ownerId: null,
			externalContractId: null,
			resetRules: [],
			transitionRules: [],
			externalUseDeclared: !1
		},
		effect: {
			operation: "set",
			targetId: null,
			value: t,
			condition: {
				op: "constant",
				value: !0
			},
			instanceId: null,
			reason: ""
		},
		assertion: {
			subjectId: null,
			predicate: "",
			value: t,
			truthKind: "author_truth",
			holderId: null,
			sourceIds: [],
			evidenceLocation: null,
			validity: It(),
			reason: ""
		},
		foreshadow: {
			question: [],
			intent: [],
			resolutionPolicy: "undecided",
			truthAssertionIds: [],
			clueIds: [],
			payoffIds: [],
			requiredInfo: [],
			deadline: null,
			exceptions: []
		},
		disclosure: {
			foreshadowId: null,
			anchor: { entityId: null },
			stage: "hint",
			role: "clue",
			condition: {
				op: "constant",
				value: !0
			},
			knowledgeEffects: [],
			targetScope: null
		},
		checkpoint: {
			contentVersionId: null,
			runtimeState: Gt(""),
			origin: "partial",
			traceId: null
		},
		trace: {
			contentVersionId: null,
			startCheckpointId: null,
			steps: [],
			seed: "",
			engineVersion: "1.0.0",
			externalMode: "stub"
		},
		attachment: {
			mediaType: "",
			contentHash: "",
			byteSize: 0,
			assetPath: "",
			displayName: "",
			stage: "reference",
			revisionHistory: []
		},
		source: {
			sourceType: "web",
			locator: "",
			accessedAt: null,
			excerptLocation: "",
			interpretation: [],
			attachmentId: null,
			redistributionAllowed: !1
		},
		cue: {
			anchor: { entityId: null },
			cueType: "",
			attachmentId: null,
			speakerId: null,
			expression: "",
			waitMs: null,
			camera: null,
			mediaTime: null,
			stage: ""
		},
		storyboard_frame: {
			anchor: { entityId: null },
			mediaStartMs: 0,
			mediaEndMs: null,
			referenceAssetId: null,
			finalAssetId: null,
			cueIds: [],
			caption: []
		},
		localization: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			text: [],
			stage: "draft",
			reviewedBy: null,
			recordingIds: []
		},
		recording: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			translationId: null,
			attachmentId: null,
			notes: [],
			stage: "planned",
			reviewedBy: null
		},
		terminology: {
			canonical: "",
			reading: "",
			variants: [],
			language: null,
			usageNotes: [],
			validity: It(),
			exceptions: [],
			voiceOwnerId: null
		},
		map: {
			placeId: null,
			coordinateSystem: "normalized",
			attachmentId: null,
			parentMapId: null,
			pins: []
		},
		travel_route: {
			fromPlaceId: null,
			toPlaceId: null,
			direction: "one_way",
			method: "",
			minimumTicks: null,
			maximumTicks: null,
			evidence: [],
			validity: It()
		},
		template: {
			targetKind: "character",
			fields: [],
			description: "",
			version: "0",
			defaults: {}
		},
		collection: {
			mode: "fixed",
			memberIds: [],
			query: null,
			sort: {
				field: "name",
				direction: "asc"
			}
		},
		review: {
			target: null,
			targetVersionId: null,
			body: [],
			stage: "open",
			assigneeId: null,
			quotedText: "",
			resolution: []
		},
		creative_brief: {
			targetAudience: [],
			experience: [],
			theme: [],
			tone: [],
			scope: [],
			deliverableIds: [],
			decisionIds: []
		},
		decision: {
			subject: "",
			reason: [],
			targetVersionId: null,
			outcome: "deferred",
			priority: "",
			requirementIds: [],
			reviewIds: []
		},
		gameplay_spec: {
			sceneId: null,
			action: [],
			mechanic: "",
			tutorial: [],
			reward: null,
			questId: null,
			taskIds: [],
			intentionalDifference: ""
		},
		production_task: {
			targetIds: [],
			stage: "writing",
			progress: "todo",
			assigneeId: null,
			deadline: null,
			dependsOn: [],
			estimate: null,
			blockingReason: ""
		},
		media_variant: {
			medium: "novel",
			baseSnapshotId: null,
			body: [],
			releaseAt: null,
			projectionProfileId: null,
			sourceIds: [],
			needsReview: !1
		},
		voice_rule: {
			characterId: null,
			validity: It(),
			firstPerson: "",
			addressing: "",
			phrasing: "",
			examples: [],
			exceptions: []
		},
		external_contract: {
			key: "",
			owner: "tool",
			inputType: "boolean",
			outputType: "boolean",
			missingPolicy: "unknown",
			description: [],
			stubValues: [],
			adapterProfileIds: [],
			version: "1.0.0"
		},
		snapshot: {
			versionLabel: "",
			contentHash: "",
			immutable: !0,
			parentVersionIds: [],
			releasedAt: null,
			referencedWorldVersionIds: []
		},
		projection_profile: {
			audience: "",
			includedIds: [],
			namePolicy: { mode: "exclude" },
			allowedKinds: [],
			excludedFields: ["authorNotes"],
			routeScope: null,
			includeAuthorNotes: !1,
			publicTitle: "",
			publicTexts: {},
			allowedRelationIds: [],
			idPolicy: "remap"
		}
	};
	if (!(e in n)) throw RangeError("未対応の情報種別です。");
	return n[e];
}
function Ut(e, t, n = "", r) {
	let i = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: Lt(),
		projectId: e,
		kind: t,
		revision: "0",
		name: n,
		status: "provisional",
		visibility: "private",
		createdAt: i,
		updatedAt: i,
		customValues: {},
		data: {
			...Ht(t),
			...r
		}
	};
}
function Wt(e = "新しい作品") {
	return {
		projectId: Lt(),
		name: e,
		formatVersion: qe,
		revision: "0",
		calendarId: Xe.id,
		mainStart: "0",
		calendars: [structuredClone(Xe)],
		worldReferences: [],
		entities: [],
		relations: [],
		snapshots: [],
		history: [],
		views: []
	};
}
function Gt(e) {
	return {
		contentVersionId: e,
		variableValues: {},
		itemInstances: [],
		assertions: [],
		seenIds: [],
		visitCounts: {},
		onceTriggers: [],
		rngSeed: "scenario-1",
		rngPosition: 0,
		callStack: [],
		presentationPosition: null,
		loopNumber: 0,
		provenance: "full_play"
	};
}
var O = (e = 0, t) => ({
	type: "text",
	min: e,
	max: t,
	maxBytes: 1048576
}), k = O(0, 128), A = O(1, 128), j = (e, t, n = !1) => ({
	type: "number",
	min: e,
	max: t,
	integer: n
}), M = { type: "boolean" }, N = { type: "id" }, P = { type: "tick" }, F = { type: "typed" }, I = (...e) => ({
	type: "enum",
	values: e
}), L = (...e) => ({
	type: "ref",
	kinds: e.length ? e : void 0,
	scope: "entity"
}), R = (e) => ({
	type: "ref",
	scope: e
}), z = (e, t = !1, n, r) => ({
	type: "array",
	item: e,
	unique: t,
	min: n,
	max: r
}), B = (...e) => z(L(...e), !0), V = (e) => ({
	type: "object",
	fields: e
}), H = (e) => ({
	schema: e,
	required: !0
}), U = (e) => ({
	schema: e,
	nullable: !0
}), Kt = (e) => ({
	schema: e,
	nullable: !1
}), W = { type: "richtext" }, qt = {
	type: "richtext",
	max: 2048
}, G = { type: "condition" }, Jt = { type: "time" }, K = (e, t) => ({
	type: "record",
	value: e,
	key: t
}), q = (...e) => ({
	type: "union",
	choices: e
}), J = V({
	entityId: H(L()),
	blockId: U(R("block")),
	lineId: U(L("dialogue_line")),
	start: U(j(0, void 0, !0)),
	end: U(j(0, void 0, !0)),
	sourceVersionId: U(R("snapshot")),
	positionStatus: U(I("unresolved")),
	positionReason: U(O(1)),
	quotedText: U(O())
}), Yt = q(V({
	kind: H(I("ruby")),
	originalText: H(O()),
	reason: H(O(1)),
	reading: H(O())
}), V({
	kind: H(I("link")),
	originalText: H(O()),
	reason: H(O(1)),
	target: H(J)
})), Xt = V({
	worldRange: {
		schema: V({
			start: {
				schema: P,
				required: !0,
				nullable: !0
			},
			end: {
				schema: P,
				required: !0,
				nullable: !0
			}
		}),
		required: !0,
		nullable: !0
	},
	routeCondition: {
		schema: G,
		required: !0,
		nullable: !0
	},
	presentationAnchor: {
		schema: J,
		required: !0,
		nullable: !0
	}
}), Zt = V({
	projectId: H(R("project")),
	graphId: U(L("flow_graph")),
	chapterId: U(L("chapter")),
	routeCondition: U(G),
	targetSnapshotId: U(R("snapshot"))
}), Qt = V({
	id: H(N),
	text: H(O(1, 128)),
	reading: H(k),
	validity: H(Xt),
	audienceHolderIds: H(B("character")),
	isPublicDefault: H(M)
}), $t = V({
	reason: H(O(1)),
	targetScope: H(Zt),
	validity: H(Xt),
	evidenceIds: H(B())
}), en = V({
	from: H(F),
	to: H(F),
	reason: U(O()),
	exception: U(M),
	exceptionDetails: U($t)
}), tn = V({
	on: H(I("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
	value: H(F),
	reason: U(O())
}), nn = V({
	min: U(j(void 0, void 0, !0)),
	max: U(j(void 0, void 0, !0)),
	values: U(z(q(O(), M), !0))
}), rn = V({
	id: U(N),
	event: H(I("enter", "talk", "battle_result", "manual", "custom")),
	eventKey: H(O()),
	repeat: H(I("once", "repeatable")),
	scope: U(I(...jt)),
	deadline: U(Jt)
}), an = V({
	mode: H(I("reference", "clone", "override")),
	sourceId: H(L()),
	pinnedSnapshotId: H(R("snapshot")),
	overrideFields: H(z(O(1), !0)),
	bindings: U(K(N, N))
}), on = V({ unresolved: H(V({
	label: H(O()),
	reason: H(O(1))
})) }), sn = V({
	instanceId: H(N),
	typeId: H(L("item")),
	quantity: H(j(0, void 0, !0)),
	ownerId: U(L("character", "group")),
	locationId: U(L("place")),
	consumed: H(M),
	reason: U(O())
}), cn = V({
	assertionId: H(L("assertion")),
	holderId: U(L("character")),
	truth: H(I("true", "false", "unknown")),
	sourceEffectId: U(L("effect"))
}), ln = V({
	targetId: H(L("flow_node", "flow_edge", "disclosure")),
	value: H(I("true", "false", "unknown")),
	reasons: H(z(O()))
}), un = V({
	graphId: H(L("flow_graph")),
	returnNodeId: H(L("flow_node")),
	parameters: H(K(F, A))
}), Y = V({
	contentVersionId: H(R("snapshot")),
	variableValues: H(K(F, L("variable"))),
	itemInstances: H(z(sn)),
	assertions: H(z(cn)),
	seenIds: H(z(R("presentation"), !0)),
	visitCounts: H(K(j(0, void 0, !0), L())),
	onceTriggers: H(z(O(1), !0)),
	rngSeed: H(O(1)),
	rngPosition: H(j(0, void 0, !0)),
	callStack: H(z(un)),
	presentationPosition: U(L("flow_node")),
	loopNumber: H(j(0, void 0, !0)),
	provenance: H(I("full_play", "partial", "imported", "stub")),
	resetCauses: U(z(V({
		variableId: H(L("variable")),
		on: H(I("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
		before: H(F),
		after: H(F),
		reason: H(O())
	})))
}), dn = V({
	entityId: H(L("scene")),
	occurrenceId: H(O(1, 256)),
	before: H(Y),
	after: H(Y),
	presentationState: U(Y),
	conditionResults: H(z(ln)),
	externalValues: U(K(F, L("external_contract"))),
	worldTick: U(P)
}), fn = V({
	chapterIds: H(B("chapter")),
	sceneIds: H(z(L("scene"))),
	selection: U(I("chapters", "scenes")),
	occurrences: H(z(dn))
}), pn = V({
	checked: H(j(0, void 0, !0)),
	total: H(j(0, void 0, !0))
}), mn = V({
	byProvenance: U(K(pn, I("full_play", "partial", "imported", "stub"))),
	byExternalMode: U(K(pn, I("internal", "stub", "actual", "mixed"))),
	checked: H(j(0, void 0, !0)),
	total: H(j(0, void 0, !0)),
	excluded: U(j(0, void 0, !0)),
	unknown: U(j(0, void 0, !0))
}), hn = V(Object.fromEntries([
	"scenes",
	"dialogue",
	"choices",
	"conditionTrue",
	"conditionFalse",
	"declaredTests"
].map((e) => [e, H(mn)]))), gn = V({
	key: H(A),
	label: H(O(1, 128)),
	type: H(I("text", "number", "boolean", "enum", "date", "ref")),
	required: H(M),
	nullable: H(M),
	default: {
		schema: { type: "custom" },
		required: !0,
		nullable: !0
	},
	allowedValues: U(z(O(), !0)),
	targetKinds: U(z(I(...D), !0)),
	help: U(O())
}), _n = V({
	value: U(j(0)),
	range: U(V({
		min: H(j(0)),
		max: H(j(0))
	})),
	unit: H(O(1)),
	assumptions: H(z(O())),
	scope: H(Zt),
	unknownCount: H(j(0, void 0, !0)),
	source: H(O()),
	speed: U(j(Number.MIN_VALUE))
}), vn = V({
	...Object.fromEntries([
		"summary",
		"body",
		"text",
		"description",
		"question",
		"intent",
		"caption",
		"usageNotes",
		"interpretation",
		"examples",
		"action",
		"tutorial"
	].map((e) => [e, U(W)])),
	...Object.fromEntries((/* @__PURE__ */ "label.reading.terminalReason.reason.key.canonical.language.locale.sourceHash.expression.method.locator.predicate.cueType.precision.displayName.relationType.eventKey.resetReason.exclusionReason.exceptionReason.camera.parameters.variants.estimateAssumptions.estimateSource.blockingReason.mechanic.intentionalDifference.excerptLocation.estimateUnit.firstPerson.addressing.phrasing".split(".")).map((e) => [e, U(O())]))
}), yn = {
	character: V({
		reading: U(k),
		aliases: U(z(Qt)),
		summary: U(qt),
		body: U(W),
		authorNotes: U(W),
		birth: U(Jt),
		death: U(Jt),
		goals: U(B("goal")),
		voiceRules: U(B("voice_rule"))
	}),
	group: V({
		groupType: H(I("display", "faction", "plot_thread", "category")),
		members: U(B()),
		parentId: U(L("group")),
		summary: U(qt)
	}),
	event: V({
		summary: H(qt),
		time: H(Jt),
		laneRole: H(I("common", "participants", "both")),
		participants: U(z(V({
			characterId: H(L("character")),
			role: H(I("actor", "witness", "mentioned", "informed", "custom")),
			evidenceIds: U(B()),
			knowledgeEffectIds: U(B("effect"))
		}))),
		locationId: U(L("place")),
		itemIds: U(B("item")),
		authorNotes: U(W),
		constraints: U(z(q(V({
			type: H(I("before", "same_start")),
			targetEventId: H(L("event"))
		}), V({
			type: H(I("end_gap")),
			targetEventId: H(L("event")),
			minimumTicks: H(P),
			maximumTicks: H(P)
		}))))
	}),
	place: V({
		parentId: U(L("place")),
		reading: U(k),
		aliases: U(z(Qt)),
		body: U(W),
		mapIds: U(B("map")),
		changes: U(B("assertion"))
	}),
	item: V({
		itemMode: H(I("type", "instance")),
		typeId: U(L("item")),
		body: U(W),
		properties: U({ type: "custom" }),
		changes: U(B("assertion"))
	}),
	note: V({
		handoffReceipt: U(V({
			approval: H(V({
				entityId: H(R("entity")),
				sourceVersionId: H(R("snapshot"))
			})),
			sourceVersionId: H(R("snapshot")),
			verificationVersionId: H(R("snapshot")),
			profileVersionId: H(R("snapshot")),
			sourceRevision: H({ type: "revision" }),
			profileId: H(L("projection_profile")),
			packageHash: H({ type: "hash" }),
			receiptHash: H({ type: "hash" }),
			mode: H(I("stub", "actual", "mixed")),
			rawJson: H(O(1, 1048576)),
			idMappings: H(z(V({
				entityId: H(R("record")),
				sourceVersionId: H(R("snapshot")),
				publicId: H(O(1, 256))
			}))),
			projectionBindings: H(z(V({
				entityId: H(R("projection_record")),
				sourceVersionId: H(R("snapshot")),
				editionVersionId: H(R("snapshot")),
				publicId: H(O(1, 256))
			}))),
			citationBindings: H(z(V({
				sourceVersionId: H(R("snapshot")),
				publicVersionId: H(O(1, 256))
			}))),
			worldVersions: H(z(V({
				sourceVersionId: H(R("snapshot")),
				contentHash: H({ type: "hash" })
			})))
		})),
		body: H(W),
		attachmentIds: U(B("attachment")),
		convertedToIds: U(B()),
		originNoteId: U(L("note"))
	}),
	chapter: V({
		sceneIds: H(B("scene")),
		summary: U(qt),
		authorNotes: U(W),
		structureRole: U(k)
	}),
	scene: V({
		summary: H(qt),
		body: H(W),
		authorNotes: H(W),
		eventIds: H(B("event")),
		dialogueLineIds: U(B("dialogue_line")),
		chapterId: U(L("chapter")),
		threadIds: U(B("group")),
		povId: U(L("character")),
		goals: U(W),
		conflicts: U(W),
		results: U(W),
		newInformation: U(W),
		tension: U(j(0, 10)),
		importance: U(j(0, 10)),
		blockIds: U(z(R("block"), !0)),
		reuse: U(an)
	}),
	goal: V({
		ownerId: H(L("character", "group")),
		description: H(W),
		changes: U(B("assertion")),
		evidenceSceneIds: U(B("scene")),
		validity: U(Xt)
	}),
	flow_node: V({
		nodeType: H(I("scene", "choice", "automatic", "call", "entry", "exit", "terminal")),
		sceneId: U(L("scene")),
		childGraphId: U(L("flow_graph")),
		terminalReason: U(O()),
		trigger: U(rn),
		gate: U(G),
		executionPolicy: U(I("manual_choice", "first_match", "all_match")),
		fallbackId: U(L("flow_node")),
		reuse: U(an)
	}),
	flow_edge: V({
		fromId: H(L("flow_node")),
		toId: H(q(L("flow_node"), on)),
		edgeType: H(I("choice", "automatic", "call_return")),
		label: U(O()),
		condition: U(G),
		effectIds: U(B("effect")),
		priority: U(j(void 0, void 0, !0)),
		choiceLineId: U(L("dialogue_line"))
	}),
	flow_graph: V({
		nodeIds: H(B("flow_node")),
		edgeIds: H(B("flow_edge")),
		entryIds: H(B("flow_node")),
		exitIds: H(B("flow_node")),
		parentGraphId: U(L("flow_graph")),
		parameters: U(z(V({
			key: H(A),
			type: H(I("boolean", "integer", "enum")),
			default: U(F)
		})))
	}),
	dialogue_line: V({
		text: H(W),
		speakerId: U(L("character")),
		choiceEdgeId: U(L("flow_edge")),
		cueIds: U(B("cue")),
		originLineIds: U(B("dialogue_line")),
		replacedByLineIds: U(B("dialogue_line")),
		lineage: U(V({
			mode: H(I("split", "merge", "copy")),
			baseRevision: H({ type: "revision" }),
			reason: H(O(1)),
			segments: H(z(V({
				source: H(J),
				target: H(J)
			}), !1, 1))
		})),
		claimAssertionIds: U(B("assertion")),
		assertionIntent: U(I("statement", "lie", "misunderstanding", "quotation")),
		assertionReason: U(O())
	}),
	quest: V({
		key: H(A),
		stateVariableId: H(L("variable")),
		description: U(W),
		flowIds: U(B("flow_graph")),
		transitionRules: U(z(en)),
		gameplaySpecIds: U(B("gameplay_spec"))
	}),
	lore: V({
		body: H(W),
		assertionIds: U(B("assertion")),
		sourceIds: U(B("source")),
		reading: U(k),
		aliases: U(z(Qt))
	}),
	variable: V({
		key: H(A),
		valueType: H(I("boolean", "integer", "enum")),
		scope: H(I(...jt)),
		initial: H(F),
		allowed: H(nn),
		description: U(W),
		ownerId: U(L("character")),
		derived: U({ type: "expression" }),
		externalContractId: U(L("external_contract")),
		resetRules: U(z(tn)),
		transitionRules: U(z(en)),
		exclusions: U(z(V({
			variableId: H(L("variable")),
			value: H(F),
			otherValue: H(F),
			reason: H(O(1)),
			exceptions: U(z($t))
		}))),
		externalUseDeclared: U(M)
	}),
	effect: V({
		operation: H(I("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset")),
		targetId: H(L()),
		value: U(F),
		condition: U(G),
		instanceId: U(L("item")),
		reason: U(O()),
		exceptionDetails: U($t)
	}),
	assertion: V({
		subjectId: H(L()),
		predicate: H(O(1, 128)),
		value: H(q(F, L())),
		truthKind: H(I("author_truth", "testimony", "belief", "hypothesis")),
		holderId: U(L("character")),
		sourceIds: U(B("source", "assertion", "event", "scene", "dialogue_line")),
		evidenceLocation: U(J),
		validity: U(Xt),
		reason: U(O())
	}),
	foreshadow: V({
		question: H(W),
		intent: H(W),
		resolutionPolicy: H(I("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
		truthAssertionIds: U(B("assertion")),
		clueIds: U(B("disclosure")),
		payoffIds: U(B("disclosure")),
		requiredInfo: U(B("disclosure", "assertion")),
		alternativeInfo: U(K(B("disclosure", "assertion"), L("disclosure", "assertion"))),
		deadline: U(Zt),
		presentationDeadline: U(J),
		exceptions: U(z($t))
	}),
	disclosure: V({
		foreshadowId: H(L("foreshadow")),
		anchor: H(J),
		stage: H(I("hint", "suspicion", "reinforce", "reveal", "alternative")),
		role: H(I("clue", "payoff")),
		condition: U(G),
		knowledgeEffects: U(B("effect")),
		targetScope: U(Zt)
	}),
	checkpoint: V({
		worldTick: U(P),
		contentVersionId: H(R("snapshot")),
		runtimeState: H(Y),
		presentationState: U(Y),
		presentationResults: U(z(ln)),
		contentRevision: U({ type: "revision" }),
		origin: U(I("full_play", "partial", "imported")),
		traceId: U(L("trace")),
		migration: U(V({
			sourceCheckpointId: H(L("checkpoint")),
			sourceVersionId: H(R("snapshot")),
			baseRevision: H({ type: "revision" }),
			method: H(I("migrate", "recreate"))
		}))
	}),
	trace: V({
		contentVersionId: H(R("snapshot")),
		startCheckpointId: H(L("checkpoint")),
		steps: H(z(V({
			nodeId: H(L("flow_node")),
			edgeIds: H(B("flow_edge")),
			before: H(Y),
			after: H(Y),
			presentationState: U(Y),
			conditionResults: U(z(ln)),
			operation: U(I("advance", "stub")),
			occurrenceId: U(O()),
			worldTick: U(P),
			externalMode: U(I("stub", "actual", "mixed")),
			externalValues: U(K(F, L("external_contract")))
		}))),
		contentRevision: U({ type: "revision" }),
		initialExternalValues: U(K(F, L("external_contract"))),
		initialStubBaseState: U(Y),
		initialStubValues: U(V({
			variables: U(K(F, L("variable"))),
			external: U(K(F, L("external_contract")))
		})),
		initialWorldTick: U(P),
		seed: U(O()),
		engineVersion: U(O()),
		externalMode: U(I("stub", "actual", "mixed")),
		coverage: U(hn),
		regressionDeclarations: U(V({
			projectRevision: H({ type: "revision" }),
			traceIds: H(B("trace"))
		})),
		reconfirmation: U(V({
			sourceTraceId: H(L("trace")),
			sourceVersionId: H(R("snapshot")),
			baseRevision: H({ type: "revision" }),
			startCheckpointId: U(L("checkpoint"))
		})),
		mode: U(I("flow", "chapters", null)),
		readingPath: U(q(fn, I(null)))
	}),
	attachment: V({
		mediaType: H(O(1, 128)),
		contentHash: H({ type: "hash" }),
		byteSize: H(j(0, 33554432, !0)),
		assetPath: H({ type: "safe_path" }),
		displayName: U(O()),
		provenanceId: U(L("source")),
		licenseNote: U(O()),
		stage: U(I("reference", "temporary", "final")),
		revisionHistory: U(B("attachment"))
	}),
	source: V({
		sourceType: H(I("web", "file", "book", "observation")),
		locator: H(O(1)),
		accessedAt: U({ type: "datetime" }),
		excerptLocation: U(O()),
		interpretation: U(W),
		attachmentId: U(L("attachment")),
		redistributionAllowed: U(M)
	}),
	cue: V({
		anchor: H(J),
		cueType: H(O(1, 128)),
		attachmentId: U(L("attachment")),
		speakerId: U(L("character")),
		expression: U(O()),
		waitMs: U(j(0, void 0, !0)),
		camera: U({ type: "custom" }),
		mediaTime: U(j(0, void 0, !0)),
		stage: U(k)
	}),
	storyboard_frame: V({
		anchor: H(J),
		mediaStartMs: H(j(0, void 0, !0)),
		mediaEndMs: U(j(0, void 0, !0)),
		referenceAssetId: U(L("attachment")),
		finalAssetId: U(L("attachment")),
		cueIds: U(B("cue")),
		caption: U(W)
	}),
	localization: V({
		sourceLineId: H(L("dialogue_line")),
		language: H(O(1, 128)),
		sourceHash: H({ type: "hash" }),
		text: H(W),
		stage: U(I("draft", "reviewed", "needs_review")),
		reviewedBy: U(R("identity")),
		recordingIds: U(B("recording"))
	}),
	recording: V({
		sourceLineId: H(L("dialogue_line")),
		language: H(O(1, 128)),
		sourceHash: H({ type: "hash" }),
		translationId: U(L("localization")),
		attachmentId: U(L("attachment")),
		notes: U(W),
		stage: U(I("planned", "recorded", "reviewed", "needs_review")),
		reviewedBy: U(R("identity"))
	}),
	terminology: V({
		canonical: H(O(1, 128)),
		reading: H(k),
		variants: U(z(k, !0)),
		language: U(k),
		usageNotes: U(W),
		validity: U(Xt),
		exceptions: U(z($t)),
		voiceOwnerId: U(L("character"))
	}),
	map: V({
		placeId: H(L("place")),
		coordinateSystem: H(I("normalized")),
		attachmentId: U(L("attachment")),
		parentMapId: U(L("map")),
		pins: U(z(V({
			id: H(N),
			placeId: H(L("place")),
			x: H(j(0, 1)),
			y: H(j(0, 1)),
			label: U(O())
		})))
	}),
	travel_route: V({
		fromPlaceId: H(L("place")),
		toPlaceId: H(L("place")),
		direction: H(I("one_way", "two_way")),
		method: U(O()),
		minimumTicks: U(P),
		maximumTicks: U(P),
		evidence: U(B()),
		validity: U(Xt)
	}),
	template: V({
		targetKind: H(I(...D)),
		fields: H(z(gn)),
		description: U(O()),
		version: U({ type: "revision" }),
		defaults: U(K({ type: "custom" }, A))
	}),
	collection: V({
		purpose: U(I("regression")),
		mode: H(I("dynamic", "fixed")),
		query: U({ type: "query" }),
		memberIds: U(B()),
		sort: U(V({
			field: H(I("name", "createdAt", "updatedAt", "kind")),
			direction: H(I("asc", "desc"))
		}))
	}),
	review: V({
		target: H(q(J, L())),
		targetVersionId: H(R("snapshot")),
		body: H(W),
		stage: H(I("open", "fixed", "verified")),
		assigneeId: U(R("identity")),
		quotedText: U(O()),
		resolution: U(W),
		sharedSource: U(V({
			connection: H(O(1)),
			sharedSnapshot: H(O(1)),
			comment: H(O(1)),
			publicVersion: H(O(1)),
			publicEntity: U(O(1)),
			publicRelation: U(O(1)),
			publicBlock: U(O(1)),
			startCp: U(j(0, void 0, !0)),
			endCp: U(j(0, void 0, !0)),
			projectionHash: H(O(64, 64)),
			commentBodyHash: H(O(64, 64)),
			quotedText: H(O()),
			observedStage: H(I("open", "fixed", "verified"))
		}))
	}),
	creative_brief: V({
		targetAudience: H(W),
		experience: H(W),
		theme: H(W),
		tone: H(W),
		scope: H(W),
		deliverableIds: U(B()),
		decisionIds: U(B("decision"))
	}),
	decision: V({
		subject: H(O(1)),
		reason: H(W),
		targetVersionId: H(R("snapshot")),
		outcome: H(I("accepted", "rejected", "deferred")),
		priority: U(k),
		requirementIds: U(z(k, !0)),
		reviewIds: U(B("review"))
	}),
	gameplay_spec: V({
		sceneId: H(L("scene")),
		action: H(W),
		mechanic: U(O()),
		tutorial: U(W),
		reward: U(F),
		questId: U(L("quest")),
		taskIds: U(B("production_task")),
		intentionalDifference: U(O())
	}),
	production_task: V({
		targetIds: H(B()),
		stage: H(I("writing", "review", "implementation", "translation", "recording", "verification", "publication")),
		progress: H(I("todo", "doing", "done", "needs_review")),
		assigneeId: U(R("identity")),
		deadline: U(V({
			date: H({ type: "date" }),
			timeZone: H(O(1, 128))
		})),
		dependsOn: U(B("production_task")),
		estimate: U(_n),
		blockingReason: U(O())
	}),
	media_variant: V({
		previousVariantId: U(L("media_variant")),
		confirmationRecipientIds: U(z(R("identity"), !0)),
		medium: H(I("game", "novel", "video", "audio", "promotion", "custom")),
		baseSnapshotId: H(R("snapshot")),
		body: U(W),
		releaseAt: U({ type: "datetime" }),
		projectionProfileId: U(L("projection_profile")),
		sourceIds: U(B()),
		needsReview: U(M)
	}),
	voice_rule: V({
		characterId: H(L("character")),
		validity: H(Xt),
		firstPerson: U(k),
		addressing: U(O()),
		phrasing: U(O()),
		examples: U(W),
		exceptions: U(z($t))
	}),
	external_contract: V({
		key: H(A),
		owner: H(I("tool", "game")),
		inputType: H(O(1, 128)),
		outputType: H(O(1, 128)),
		missingPolicy: H(I("unknown", "block")),
		description: U(W),
		stubValues: U(z(F)),
		adapterProfileIds: U(B("projection_profile")),
		version: U(k)
	}),
	snapshot: V({
		versionLabel: H(O(1, 128)),
		contentHash: H({ type: "hash" }),
		immutable: H(I(!0)),
		parentVersionIds: U(z(R("snapshot"), !0)),
		releasedAt: U({ type: "datetime" }),
		referencedWorldVersionIds: U(z(R("snapshot"), !0))
	}),
	projection_profile: V({
		blockSources: U(K(R("block"), R("projection_record"))),
		citedVersions: U(z(V({
			sourceVersionId: H(R("snapshot")),
			profileId: H(L("projection_profile")),
			publicVersionId: H(N)
		}))),
		audience: H(O(1, 128)),
		includedIds: H(B()),
		namePolicy: H({ type: "name_policy" }),
		allowedKinds: U(z(I(...D), !0)),
		excludedFields: U(z(O(1), !0)),
		routeScope: U(Zt),
		includeAuthorNotes: U(M),
		publicTitle: U(O()),
		publicTexts: U(K(vn, R("record"))),
		allowedFields: U(K(z(O(1), !0), I(...D))),
		allowedRelationIds: U(z(R("relation"), !0)),
		idPolicy: U(I("remap", "preserve")),
		publicIds: U(K(N, R("projection_record"))),
		sourceVersionId: U(R("snapshot")),
		publicValues: U(K(K(O(), O()), L("variable", "external_contract", "assertion"))),
		includedStatuses: U(z(I(...At), !0)),
		publicVersionLabel: U(O()),
		approvedAttachmentIds: U(B("attachment"))
	})
}, X = (e) => !!e && typeof e == "object" && !Array.isArray(e) && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null), bn = (e) => St(e).utf8Bytes, xn = (e) => St(e).codePoints, Sn = (e) => St(e).validUnicode;
function Z(e, t, n, r = "VALIDATION_FAILED") {
	e.length < 256 && e.push({
		code: r,
		path: t,
		message: n
	});
}
function Cn(e) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(e)) return !1;
	let t = wn.get(e);
	if (t !== void 0) return t;
	let n = /* @__PURE__ */ new Date(`${e}T00:00:00Z`), r = Number.isFinite(n.getTime()) && n.toISOString().slice(0, 10) === e;
	return wn.size >= 512 && wn.delete(wn.keys().next().value), wn.set(e, r), r;
}
var wn = /* @__PURE__ */ new Map(), Tn = /* @__PURE__ */ new Map(), En = /^\d{4}-\d{2}-\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.\d+)?(?:Z|\+00:00)$/;
function Dn(e) {
	let t = e.length <= 64;
	if (t) {
		let t = Tn.get(e);
		if (t !== void 0) return t;
	}
	let n = En.test(e) && Number.isFinite(Date.parse(e)) && Cn(e.slice(0, 10));
	return t && (Tn.size >= 512 && Tn.delete(Tn.keys().next().value), Tn.set(e, n)), n;
}
function On(e) {
	switch (e.op) {
		case "constant": return V({
			op: H(I("constant")),
			value: H(M)
		});
		case "all":
		case "any": return V({
			op: H(I("all", "any")),
			children: H(z(G, !1, 1, 256))
		});
		case "not": return V({
			op: H(I("not")),
			child: H(G)
		});
		case "compare": return V({
			op: H(I("compare")),
			variableId: H(L("variable")),
			comparator: H(I("eq", "ne", "lt", "le", "gt", "ge", "in")),
			value: H(e.comparator === "in" ? z(F, !1, 1, 256) : F)
		});
		case "item": return V({
			op: H(I("item")),
			itemId: H(L("item")),
			quantity: H(j(1, void 0, !0))
		});
		case "known": return V({
			op: H(I("known")),
			assertionId: H(L("assertion")),
			holderId: H(L("character"))
		});
		case "visited": return V({
			op: H(I("visited")),
			entityId: H(L()),
			count: H(j(1, void 0, !0))
		});
		case "external": return V({
			op: H(I("external")),
			contractId: H(L("external_contract"))
		});
		default: return;
	}
}
function kn(e) {
	let t = { type: "expression" };
	switch (e.op) {
		case "value": return V({
			op: H(I("value")),
			value: H(F)
		});
		case "variable": return V({
			op: H(I("variable")),
			variableId: H(L("variable"))
		});
		case "add":
		case "subtract":
		case "multiply": return V({
			op: H(I("add", "subtract", "multiply")),
			left: H(t),
			right: H(t)
		});
		case "if": return V({
			op: H(I("if")),
			condition: H(G),
			then: H(t),
			else: H(t)
		});
		default: return On(e);
	}
}
function An(e) {
	let t = H(R("calendar"));
	switch (e.mode) {
		case "instant": return V({
			mode: H(I("instant")),
			at: H(P),
			calendarId: t
		});
		case "interval": return V({
			mode: H(I("interval")),
			start: H(P),
			end: H(P),
			calendarId: t
		});
		case "uncertain": return V({
			mode: H(I("uncertain")),
			earliest: H(P),
			latest: H(P),
			calendarId: t,
			precision: H(O())
		});
		case "relative": return V({
			mode: H(I("relative")),
			anchorEventId: H(L("event")),
			anchorPoint: H(I("start", "end")),
			minOffset: H(P),
			maxOffset: H(P)
		});
		case "unknown": return V({
			mode: H(I("unknown")),
			reason: H(O())
		});
		default: return;
	}
}
function jn(e) {
	switch (e.op) {
		case "all":
		case "any": return V({
			op: H(I("all", "any")),
			children: H(z({ type: "query" }, !1, 1, 256))
		});
		case "kind": return V({
			op: H(I("kind")),
			value: H(I(...D))
		});
		case "text": return V({
			op: H(I("text")),
			value: H(O())
		});
		case "status": return V({
			op: H(I("status")),
			value: H(I(...At))
		});
		case "participant": return V({
			op: H(I("participant")),
			characterId: H(L("character"))
		});
		case "production": return V({
			op: H(I("production")),
			value: H(I("todo", "doing", "done", "needs_review"))
		});
		case "chapter": return V({
			op: H(I("chapter")),
			chapterId: H(L("chapter"))
		});
		case "foreshadow": return V({
			op: H(I("foreshadow")),
			foreshadowId: Kt(L("foreshadow")),
			resolutionPolicy: Kt(I("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
			role: Kt(I("clue", "payoff")),
			stage: Kt(I("hint", "suspicion", "reinforce", "reveal", "alternative"))
		});
		default: return;
	}
}
function Mn(e) {
	if (!("mode" in e)) {
		let e = q(...[
			"alias",
			"replace",
			"exclude",
			"anonymize"
		].map((e) => Mn({ mode: e })));
		return V({
			defaultPolicy: U(e),
			byEntityId: U(K(e, L()))
		});
	}
	switch (e.mode) {
		case "alias": return V({
			mode: H(I("alias")),
			aliasId: H(R("alias"))
		});
		case "replace": return V({
			mode: H(I("replace")),
			replacement: H(O(1, 128))
		});
		case "exclude": return V({ mode: H(I("exclude")) });
		case "anonymize": return V({
			mode: H(I("anonymize")),
			publicId: H(N),
			publicName: H(O(1, 128))
		});
		default: return;
	}
}
var Nn = {
	start: H(j(0, void 0, !0)),
	end: H(j(0, void 0, !0))
}, Pn = z(V({
	id: H(N),
	kind: H(I("paragraph", "heading", "list_item", "quote")),
	text: H(O()),
	ruby: U(z(V({
		...Nn,
		text: H(O())
	}))),
	links: U(z(V({
		...Nn,
		target: H(J)
	}))),
	unresolvedAnnotations: U(z(Yt))
}));
function Q(e, t, n, r, i, a = 0, o) {
	if (r.length >= 256) return;
	if (a > 32) {
		Z(r, n, "構造の深さが上限32を超えています。", "IMPORT_LIMIT");
		return;
	}
	let s = (e) => Z(r, n, e);
	switch (e.type) {
		case "json": {
			let e = (t, n, i, a) => {
				if (i > 100) {
					Z(r, n, "JSON階層の上限を超えています。", "IMPORT_LIMIT");
					return;
				}
				if (t !== null && typeof t != "string" && typeof t != "boolean" && !(typeof t == "number" && Number.isFinite(t))) {
					if (!t || typeof t != "object" || a.has(t)) {
						Z(r, n, "通常のJSON値を指定してください。");
						return;
					}
					if (a.add(t), Array.isArray(t)) t.forEach((t, r) => e(t, `${n}[${r}]`, i + 1, a));
					else if (Object.getPrototypeOf(t) === Object.prototype || Object.getPrototypeOf(t) === null) for (let [o, s] of Object.entries(t)) [
						"__proto__",
						"prototype",
						"constructor"
					].includes(o) ? Z(r, `${n}.${o}`, "予約済みのキーは使えません。") : e(s, `${n}.${o}`, i + 1, a);
					else Z(r, n, "通常のJSONオブジェクトを指定してください。");
					a.delete(t);
				}
			};
			e(t, n, 0, /* @__PURE__ */ new Set());
			return;
		}
		case "text": {
			if (typeof t != "string") {
				s("文字列を入力してください。");
				return;
			}
			Sn(t) || s("文字列に不正なUnicodeがあります。");
			let n = xn(t);
			e.min !== void 0 && n < e.min && s(`${e.min}文字以上で入力してください。`), e.max !== void 0 && n > e.max && s(`${e.max}文字以内で入力してください。`), e.maxBytes !== void 0 && bn(t) > e.maxBytes && s("本文が1 MiBの上限を超えています。");
			return;
		}
		case "number":
			typeof t != "number" || !Number.isFinite(t) || e.integer && !Number.isSafeInteger(t) ? s(e.integer ? "安全な範囲の整数を入力してください。" : "有限の数値を入力してください。") : (e.min !== void 0 && t < e.min || e.max !== void 0 && t > e.max) && s("数値が許容範囲外です。");
			return;
		case "boolean":
			typeof t != "boolean" && s("真偽値を指定してください。");
			return;
		case "enum":
			e.values.includes(t) || s("宣言された値を選んでください。");
			return;
		case "id":
			(typeof t != "string" || !Pt.test(t)) && s("小文字のUUIDを指定してください。");
			return;
		case "ref":
			typeof t == "string" && (e.scope === "calendar" ? t.length > 0 : Pt.test(t)) || s(e.scope === "calendar" ? "暦IDが必要です。" : "参照先は小文字UUIDです。"), typeof t == "string" && i.push({
				id: t,
				path: n,
				kinds: e.kinds,
				scope: e.scope ?? "entity"
			});
			return;
		case "tick":
			Ze(t) || s("tickは38桁以内の正規整数文字列です。");
			return;
		case "revision":
			(typeof t != "string" || !Ft.test(t)) && s("revisionは0以上の整数文字列です。");
			return;
		case "datetime":
			(typeof t != "string" || !Dn(t)) && s("UTCのRFC 3339日時を指定してください。");
			return;
		case "date":
			(typeof t != "string" || !Cn(t)) && s("実在するYYYY-MM-DD形式の日付を指定してください。");
			return;
		case "hash":
			(typeof t != "string" || !/^[0-9a-f]{64}$/.test(t)) && s("SHA-256は小文字16進数64文字です。");
			return;
		case "safe_path":
			(typeof t != "string" || !t || t.startsWith("/") || t.includes("\\") || t.includes("\0") || /^[a-zA-Z]:/.test(t) || t.split("/").some((e) => !e || e === "." || e === "..") || /[\u0000-\u001f\u007f]/.test(t)) && s("安全な相対パスを指定してください。");
			return;
		case "array":
			if (!Array.isArray(t)) {
				s("配列を指定してください。");
				return;
			}
			if (t.length > (e.max ?? 1e5) || e.min !== void 0 && t.length < e.min) {
				s("配列の件数が許容範囲外です。");
				return;
			}
			e.unique && new Set(t.map((e) => typeof e == "object" ? JSON.stringify(e) : e)).size !== t.length && s("同じ値を集合内で重複保存できません。"), t.forEach((t, s) => Q(e.item, t, `${n}[${s}]`, r, i, a + 1, o));
			return;
		case "object":
			if (!X(t)) {
				s("オブジェクトを指定してください。");
				return;
			}
			for (let i of Object.keys(t)) Object.hasOwn(e.fields, i) || Z(r, `${n}.${i}`, "未知の項目は保存できません。");
			for (let s of Object.keys(e.fields)) {
				let c = e.fields[s], l = t[s], u = `${n}.${s}`;
				if (l === void 0) {
					c.required && Z(r, u, "必須項目です。");
					continue;
				}
				l === null && c.nullable || Q(c.schema, l, u, r, i, a + 1, o);
			}
			return;
		case "record":
			if (!X(t)) {
				s("項目の辞書を指定してください。");
				return;
			}
			for (let [s, c] of Object.entries(t)) {
				if ([
					"__proto__",
					"prototype",
					"constructor"
				].includes(s)) {
					Z(r, `${n}.${s}`, "予約済みのキーは使えません。");
					continue;
				}
				e.key && Q(e.key, s, `${n}.${s}.$key`, r, i, a + 1, o), Q(e.value, c, `${n}.${s}`, r, i, a + 1, o);
			}
			return;
		case "union": {
			let s;
			for (let r of e.choices) {
				let e = [], c = [];
				if (Q(r, t, n, e, c, a + 1, o), !e.length) {
					i.push(...c);
					return;
				}
				(!s || e.length < s.length) && (s = e);
			}
			r.push(...s ?? [{
				code: "VALIDATION_FAILED",
				path: n,
				message: "対応する型ではありません。"
			}]);
			return;
		}
		case "typed": {
			if (!X(t)) {
				s("型と値を指定してください。");
				return;
			}
			let e;
			switch (t.type) {
				case "boolean":
					e = M;
					break;
				case "integer":
					e = j(void 0, void 0, !0);
					break;
				case "enum":
				case "text":
					e = O();
					break;
				case "ref":
					e = L();
					break;
				case "unknown":
					Q(V({
						type: H(I("unknown")),
						value: {
							schema: O(),
							required: !0,
							nullable: !0
						},
						reason: H(O())
					}), t, n, r, i, a + 1, o), t.value !== null && s("未定値のvalueはnullです。");
					return;
				default:
					s("未知の値型です。");
					return;
			}
			Q(V({
				type: H(I(t.type)),
				value: H(e)
			}), t, n, r, i, a + 1, o);
			return;
		}
		case "custom":
			if (t === null) return;
			if (typeof t == "string") Q(O(), t, n, r, i, a, o);
			else if (typeof t == "number") Q(j(), t, n, r, i, a, o);
			else if (typeof t == "boolean") return;
			else X(t) && t.type === "ref" ? Q(V({
				type: H(I("ref")),
				value: H(L())
			}), t, n, r, i, a + 1, o) : X(t) && t.type === "date" ? Q(V({
				type: H(I("date")),
				value: H({ type: "date" })
			}), t, n, r, i, a + 1, o) : s("カスタム値は文字列・数値・真偽・日付・参照またはnullです。");
			return;
		case "richtext": {
			if (Q(Pn, t, n, r, i, a + 1, o), !Array.isArray(t)) return;
			let c = 0, l = 0, u = /* @__PURE__ */ new Set();
			t.forEach((e, t) => {
				if (!X(e) || typeof e.text != "string") return;
				let i = xn(e.text);
				if (c += bn(e.text), l += i, typeof e.id == "string" && (u.has(e.id) && Z(r, `${n}[${t}].id`, "段落IDが重複しています。"), u.add(e.id)), Array.isArray(e.unresolvedAnnotations)) {
					for (let t of e.unresolvedAnnotations) if (X(t)) for (let e of [
						"originalText",
						"reason",
						"reading"
					]) typeof t[e] == "string" && (c += bn(t[e]));
				}
				for (let a of ["ruby", "links"]) Array.isArray(e[a]) && e[a].forEach((e, o) => {
					X(e) && (typeof e.start == "number" && typeof e.end == "number" && (e.start >= e.end || e.end > i) && Z(r, `${n}[${t}].${a}[${o}]`, "文字範囲はコードポイントで数え、本文内の半開区間を指定してください。"), typeof e.text == "string" && (c += bn(e.text)));
				});
			}), c > 1048576 && s("本文フィールドが1 MiBを超えています。"), e.max !== void 0 && l > e.max && s(`要約は${e.max}文字以内です。`);
			return;
		}
		case "condition":
		case "expression": {
			let a = o ?? {
				counter: { count: 0 },
				depth: 0
			};
			if (a.counter.count++, a.counter.count > 256 || a.depth >= 16) {
				s("条件・式は深さ16、ノード256までです。");
				return;
			}
			if (!X(t)) {
				s("条件・式は型付きASTで指定してください。");
				return;
			}
			let c = e.type === "condition" ? On(t) : kn(t);
			if (!c) {
				s("未知の条件・式opです。");
				return;
			}
			Q(c, t, n, r, i, 0, {
				counter: a.counter,
				depth: a.depth + 1
			});
			return;
		}
		case "time": {
			if (!X(t)) {
				s("日時はTimeSpecで指定してください。");
				return;
			}
			let e = An(t);
			if (!e) {
				s("未知の日時modeです。");
				return;
			}
			let c = r.length;
			Q(e, t, n, r, i, a + 1, o), r.length === c && (t.mode === "interval" && C(t.start, t.end) >= 0 && s("期間はstart < endの半開区間です。"), t.mode === "uncertain" && C(t.earliest, t.latest) > 0 && s("earliestはlatest以下です。"), t.mode === "relative" && C(t.minOffset, t.maxOffset) > 0 && s("minOffsetはmaxOffset以下です。"));
			return;
		}
		case "query":
		case "name_policy": {
			if (!X(t)) {
				s("型付きのオブジェクトを指定してください。");
				return;
			}
			let c = e.type === "query" ? jn(t) : Mn(t);
			if (!c) {
				s("未知の規則です。");
				return;
			}
			let l = r.length;
			Q(c, t, n, r, i, a + 1, o), e.type === "query" && t.op === "foreshadow" && r.length === l && ![
				"foreshadowId",
				"resolutionPolicy",
				"role",
				"stage"
			].some((e) => t[e] !== void 0 && t[e] !== null) && Z(r, n, "伏線検索には対象・回収方針・開示役割・段階のいずれかを指定してください。");
			return;
		}
	}
}
var Fn = {
	id: H(N),
	projectId: H(R("project")),
	kind: H(I(...D)),
	revision: H({ type: "revision" }),
	name: H(k),
	status: H(I(...At)),
	visibility: H(I("private", "team", "projection")),
	retainIfUnreferenced: U(M),
	projectionProfileId: U(L("projection_profile")),
	templateId: U(L("template")),
	createdAt: H({ type: "datetime" }),
	updatedAt: H({ type: "datetime" }),
	deletedAt: U({ type: "datetime" }),
	deletionOperationId: U(N),
	customValues: H(K({ type: "custom" }, A))
}, In = V({
	id: H(N),
	projectId: H(R("project")),
	revision: H({ type: "revision" }),
	fromId: H(L()),
	toId: H(L()),
	relationType: H(O(1, 128)),
	direction: H(I("forward", "symmetric")),
	validity: H(Xt),
	evidenceIds: H(B()),
	status: H(I(...At)),
	visibility: H(I("private", "team", "projection")),
	projectionProfileId: U(L("projection_profile")),
	deletedAt: U({ type: "datetime" }),
	deletionOperationId: U(N)
}), Ln = /* @__PURE__ */ new Map();
function Rn(e) {
	let t = yn[e], n = Ln.get(e);
	if (n?.data === t) return n.record;
	let r = V({
		...Fn,
		kind: H(I(e)),
		data: H(t)
	});
	return Ln.set(e, {
		data: t,
		record: r
	}), r;
}
function zn(e, t, n, r = []) {
	let i = [];
	return Q(e, t, n, i, r), i.length ? {
		ok: !1,
		issues: i
	} : {
		ok: !0,
		value: t
	};
}
function Bn(e, t = "condition") {
	return zn(G, e, t);
}
function Vn(e, t = "value") {
	return zn(F, e, t);
}
function Hn(e, t = "runtimeState") {
	let n = zn(Y, e, t);
	if (!n.ok) return n;
	let r = [], i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	return n.value.itemInstances.forEach((e, n) => {
		i.has(e.instanceId) && Z(r, `${t}.itemInstances[${n}].instanceId`, "物品個体のIDが重複しています。"), i.add(e.instanceId), (e.ownerId && e.locationId || e.consumed && e.quantity !== 0 || !e.consumed && e.quantity < 1) && Z(r, `${t}.itemInstances[${n}]`, "物品の所在・所有・消費状態・数量が不整合です。");
	}), n.value.assertions.forEach((e, n) => {
		let i = `${e.assertionId}/${e.holderId}`;
		a.has(i) && Z(r, `${t}.assertions[${n}]`, "同じ人物・事実の認識が重複しています。"), a.add(i);
	}), r.length ? {
		ok: !1,
		issues: r
	} : n;
}
function Un(e, t, n, r = "presentationResults") {
	let i = zn(z(ln), t, r);
	if (!i.ok) return i.issues;
	let a = [], o = new Set(e.seenIds), s = /* @__PURE__ */ new Set(), c = n.find((t) => t.kind === "flow_node" && t.id === e.presentationPosition && !t.deletedAt && t.status !== "rejected"), l = n.filter((e) => {
		if (e.kind !== "disclosure" || e.deletedAt || e.status === "rejected" || !c || !o.has(c.id)) return !1;
		let t = e.data.anchor;
		return t.positionStatus !== "unresolved" && (t.entityId === c.id || t.entityId === c.data.sceneId) && (!t.blockId || o.has(t.blockId)) && (!t.lineId || o.has(t.lineId));
	}), u = new Set(l.map((e) => e.id));
	i.value.forEach((t, n) => {
		let i = `${r}[${n}]`;
		s.has(t.targetId) && Z(a, `${i}.targetId`, "初期提示の条件結果が重複しています。"), s.add(t.targetId), u.has(t.targetId) || Z(a, `${i}.targetId`, "初期提示の対象ではない開示の条件結果です。", "REFERENCE_INVALID"), t.value === "unknown" && Z(a, `${i}.value`, "未確認の開示条件では初期提示を完了できません。"), t.value === "true" && !o.has(t.targetId) && Z(a, `${i}.value`, "提示した条件結果と既読の証跡が一致しません。"), t.value === "false" && o.has(t.targetId) && e.provenance === "full_play" && Z(a, `${i}.value`, "提示済みの開示を初期条件のfalseで取り消すことはできません。");
	});
	for (let e of l) s.has(e.id) || Z(a, r, "初期提示の開示条件結果が不足しています。");
	return a;
}
function Wn(e, t = "effect") {
	return zn(yn.effect, e, t);
}
function Gn(e, t, n) {
	if (!X(e) || !D.includes(e.kind)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: `${t}.kind`,
			message: "未対応の情報種別です。"
		}]
	};
	let r = zn(Rn(e.kind), e, t, n);
	if (!r.ok) return r;
	let i = [];
	return Kn(r.value, t, i), i.length ? {
		ok: !1,
		issues: i
	} : r;
}
function $(e, t, n = "value", r = !0) {
	let i = [], a = e.data;
	if (t.type === "unknown") return r || Z(i, n, "未定の値はこの操作で使えません。", "CONDITION_UNKNOWN"), i;
	if (t.type !== a.valueType) return Z(i, n, "状態変数の宣言型と値の型が一致しません。"), i;
	if (t.type === "integer") {
		let e = a.allowed.min ?? -2147483647, r = a.allowed.max ?? 2147483647;
		(!Number.isSafeInteger(t.value) || t.value < e || t.value > r) && Z(i, n, "状態変数の値が宣言した整数範囲外です。");
	}
	return (t.type === "enum" || t.type === "boolean") && a.allowed.values && !a.allowed.values.includes(t.value) && Z(i, n, "状態変数の値が許容集合にありません。"), i;
}
function Kn(e, t, n) {
	let r = (e, r) => Z(n, `${t}.${e}`, r);
	![
		"dialogue_line",
		"effect",
		"assertion",
		"disclosure",
		"cue",
		"storyboard_frame",
		"localization",
		"recording",
		"checkpoint",
		"trace"
	].includes(e.kind) && !e.name.trim() && (e.kind === "event" ? zt(e.data.summary).trim() || r("data.summary", "名称または要約を入力してください。") : r("name", "名称を入力してください。")), e.visibility === "projection" && !e.projectionProfileId && r("projectionProfileId", "公開投影の対象プロファイルを指定してください。"), e.deletedAt && !e.deletionOperationId && r("deletionOperationId", "削除には削除操作IDが必要です。"), !e.deletedAt && e.deletionOperationId && r("deletionOperationId", "削除されていない情報に削除操作IDは保存できません。");
	for (let t of Object.keys(e.customValues)) {
		let n = yn[e.kind];
		(Object.hasOwn(Fn, t) || n.type === "object" && Object.hasOwn(n.fields, t)) && r(`customValues.${t}`, "標準項目とカスタム項目のキーが衝突しています。");
	}
	switch (e.kind) {
		case "event":
			for (let [t, n] of (e.data.constraints ?? []).entries()) n.type === "end_gap" && C(n.minimumTicks, n.maximumTicks) > 0 && r(`data.constraints[${t}]`, "日時差の最小値は最大値以下です。");
			break;
		case "item":
			e.data.itemMode === "instance" && !e.data.typeId && r("data.typeId", "物品の個体には種類への参照が必要です。");
			break;
		case "flow_node":
			e.data.nodeType === "terminal" && !e.data.terminalReason?.trim() && r("data.terminalReason", "意図した終端には終了理由が必要です。"), e.data.nodeType === "call" && !e.data.childGraphId && r("data.childGraphId", "呼出ノードには子分岐図が必要です。");
			break;
		case "variable": {
			let i = e.data;
			i.scope === "character" && !i.ownerId && r("data.ownerId", "人物scopeには所有人物が必要です。"), i.valueType === "integer" ? (i.allowed.values && r("data.allowed.values", "整数には集合ではなくmin/maxを指定してください。"), (i.allowed.min ?? -2147483647) > (i.allowed.max ?? 2147483647) && r("data.allowed", "整数の最小値は最大値以下です。")) : ((i.allowed.min != null || i.allowed.max != null) && r("data.allowed", "この型に数値範囲は設定できません。"), i.valueType === "enum" && (!i.allowed.values?.length || i.allowed.values.some((e) => typeof e != "string" || !e)) && r("data.allowed.values", "enumには空でない文字列の候補集合が必要です。"), i.valueType === "boolean" && i.allowed.values?.some((e) => typeof e != "boolean") && r("data.allowed.values", "booleanの候補は真偽値です。")), n.push(...$(e, i.initial, `${t}.data.initial`));
			for (let [r, a] of (i.resetRules ?? []).entries()) n.push(...$(e, a.value, `${t}.data.resetRules[${r}].value`));
			new Set((i.resetRules ?? []).map((e) => e.on)).size !== (i.resetRules ?? []).length && r("data.resetRules", "同じ終了時点の初期化規則は一つにしてください。");
			for (let [a, o] of (i.transitionRules ?? []).entries()) n.push(...$(e, o.from, `${t}.data.transitionRules[${a}].from`, !1), ...$(e, o.to, `${t}.data.transitionRules[${a}].to`, !1)), o.exception && !o.reason?.trim() && r(`data.transitionRules[${a}].reason`, "例外遷移には理由が必要です。");
			for (let [a, o] of (i.exclusions ?? []).entries()) n.push(...$(e, o.value, `${t}.data.exclusions[${a}].value`, !1)), o.reason.trim() || r(`data.exclusions[${a}].reason`, "相互排他には理由が必要です。");
			break;
		}
		case "effect":
			[
				"set",
				"add",
				"move"
			].includes(e.data.operation) && (!e.data.value || e.data.value.type === "unknown") && r("data.value", "この効果には既知の入力値が必要です。"), e.data.operation === "add" && e.data.value?.type !== "integer" && r("data.value", "addはinteger値だけを使えます。"), e.data.operation === "move" && e.data.value?.type !== "ref" && r("data.value", "moveには所在・所有先のref値が必要です。"), e.data.operation === "consume" && !e.data.reason?.trim() && r("data.reason", "消費・破壊には理由が必要です。"), ["grant", "consume"].includes(e.data.operation) && e.data.value != null && (e.data.value.type !== "integer" || e.data.value.value < 1) && r("data.value", "物品数量は正のintegerです。"), e.data.operation === "assert" && e.data.value != null && e.data.value.type !== "boolean" && r("data.value", "assertの真偽入力はbooleanです。");
			break;
		case "assertion":
			e.data.truthKind === "belief" && !e.data.holderId && r("data.holderId", "beliefには認識を持つ人物が必要です。"), e.data.truthKind === "testimony" && !e.data.sourceIds?.length && r("data.sourceIds", "testimonyには出所が必要です。");
			break;
		case "storyboard_frame":
			e.data.mediaEndMs != null && e.data.mediaEndMs < e.data.mediaStartMs && r("data.mediaEndMs", "演出の終了は開始以上です。");
			break;
		case "travel_route":
			(e.data.minimumTicks != null && S(e.data.minimumTicks) < 0n || e.data.maximumTicks != null && S(e.data.maximumTicks) < 0n) && r("data", "移動所要時間は0以上です。"), e.data.minimumTicks != null && e.data.maximumTicks != null && C(e.data.minimumTicks, e.data.maximumTicks) > 0 && r("data.maximumTicks", "最大所要時間は最小以上です。");
			break;
		case "collection":
			e.data.purpose === "regression" && e.data.mode !== "fixed" && r("data.mode", "回帰経路集合は宣言した固定経路の集合です。"), e.data.mode === "dynamic" && !e.data.query && r("data.query", "動的一覧には型付き検索条件が必要です。"), e.data.mode === "fixed" && !Array.isArray(e.data.memberIds) && r("data.memberIds", "固定一覧にはID配列が必要です。");
			break;
		case "template":
			n.push(...ht(e.data, `${t}.data`));
			break;
		case "production_task":
			if (e.data.deadline) try {
				new Intl.DateTimeFormat("ja", { timeZone: e.data.deadline.timeZone });
			} catch {
				r("data.deadline.timeZone", "有効なタイムゾーンを指定してください。");
			}
			if (e.data.estimate) {
				let t = e.data.estimate;
				t.value == null == (t.range == null) && r("data.estimate", "見積もりはvalueまたはrangeの一つです。"), t.range && t.range.min > t.range.max && r("data.estimate.range", "見積範囲が逆転しています。"), ["reading_minutes", "playing_minutes"].includes(t.unit) && !t.speed && r("data.estimate.speed", "本文量からの時間見積もりには速度が必要です。");
			}
			break;
		case "review": {
			let t = e.data.sharedSource;
			if (!t) break;
			try {
				let e = new URL(t.connection);
				(e.origin !== t.connection || e.username || e.password || !["https:", "http:"].includes(e.protocol) || e.protocol === "http:" && ![
					"localhost",
					"127.0.0.1",
					"[::1]"
				].includes(e.hostname)) && r("data.sharedSource.connection", "指摘の専用接続先のoriginを確認してください。");
			} catch {
				r("data.sharedSource.connection", "指摘の接続先が不正です。");
			}
			(!Pt.test(t.sharedSnapshot) || !Pt.test(t.comment) || !t.publicVersion || !/^([a-f0-9]{64})$/.test(t.projectionHash) || !/^([a-f0-9]{64})$/.test(t.commentBodyHash)) && r("data.sharedSource", "元の公開版・指摘・hashが不正です。"), (!!t.publicEntity == !!t.publicRelation || t.publicRelation && (t.publicBlock !== void 0 || t.startCp !== void 0 || t.endCp !== void 0) || t.publicBlock !== void 0 && (t.startCp === void 0 || t.endCp === void 0 || t.endCp <= t.startCp) || t.publicBlock === void 0 && (t.startCp !== void 0 || t.endCp !== void 0)) && r("data.sharedSource", "元指摘の対象とUnicode位置の組合せを確認してください。");
			break;
		}
		case "localization":
		case "recording": /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(e.data.language) || r("data.language", "言語コードを指定してください（例: ja、en-US）。");
	}
	qn(e.data, `${t}.data`, n);
}
function qn(e, t, n, r = 0) {
	if (r > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, i) => qn(e, `${t}[${i}]`, n, r + 1));
		return;
	}
	let i = e;
	if ("worldRange" in i && X(i.worldRange)) {
		let e = i.worldRange;
		Ze(e.start) && Ze(e.end) && C(e.start, e.end) >= 0 && Z(n, `${t}.worldRange`, "有効期間はstart < endの半開区間です。");
	}
	"entityId" in i && typeof i.start == "number" && typeof i.end == "number" && i.start >= i.end && Z(n, t, "位置の文字範囲はstart < endです。");
	for (let e of Object.keys(i)) {
		let a = i[e];
		a && typeof a == "object" && qn(a, `${t}.${e}`, n, r + 1);
	}
}
function Jn(e) {
	let t = [];
	return Q(Rn(e.kind), e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function Yn(e) {
	let t = [];
	return Q(In, e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function Xn(e) {
	return e.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
}
function Zn(e, t, n) {
	let r = structuredClone(e), i = (e) => n instanceof Map ? n.get(e) : Object.hasOwn(n, e) ? n[e] : void 0, a = [...t].sort((e, t) => {
		let n = e.path.endsWith(".$key"), r = t.path.endsWith(".$key");
		return Number(n) - Number(r) || (n ? Xn(t.path).length - Xn(e.path).length : 0);
	});
	for (let e of a) {
		let t = i(e.id);
		if (!t) continue;
		let n = Xn(e.path), a = n.at(-1) === "$key";
		a && n.pop();
		let o = n.pop();
		if (!o) continue;
		let s = r;
		for (let e of n) s = s[e];
		if (a) {
			if (t === o) continue;
			if (Object.hasOwn(s, t)) throw Error("REFERENCE_INVALID: 参照の統合で辞書キーが衝突します。保持する内容を選んでください。");
			s[t] = s[o], delete s[o];
		} else s[o] = t;
	}
	return r;
}
function Qn(e, t) {
	let n = Zn(e, Jn(e), t), r = (e) => (t instanceof Map ? t.get(e) : t[e]) ?? e;
	return (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings && (n.kind === "scene" || n.kind === "flow_node") && n.data.reuse && (n.data.reuse.bindings = Object.fromEntries(Object.entries(e.data.reuse.bindings).map(([e, t]) => [r(e), r(t)]))), n;
}
function $n(e, t) {
	return Zn(e, Yn(e), t);
}
var er = V({
	projectId: H(N),
	immutableSnapshotId: H(N),
	contentHash: H({ type: "hash" })
}), tr = V({
	id: H(N),
	name: H(O(1, 128)),
	view: H(O(1)),
	entityIds: H(B()),
	settings: H(K(q(O(), j(), M, I(null)), A))
}), nr = {
	projectId: H(N),
	name: H(O(1, 128)),
	formatVersion: H(I(qe)),
	revision: H({ type: "revision" }),
	calendarId: H(O(1)),
	mainStart: H(P),
	worldReferences: H(z(er))
}, rr = [
	...Object.keys(nr),
	"calendars",
	"entities",
	"relations",
	"views"
], ir = [...rr, "authorAlternatives"], ar = z({ type: "json" }, !1, 0, 100);
function or(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set([e.projectId]), o = /* @__PURE__ */ new Set();
	e.worldReferences.forEach((e, t) => {
		i.has(e.projectId) && Z(r, `${n}.worldReferences[${t}]`, "同じ世界の複数の版を同時に参照すると、IDの参照先が曖昧になります。一つの固定版を選んでください。", "REFERENCE_INVALID"), i.add(e.projectId);
	});
	let s = [{
		content: e,
		location: n
	}, ...t.map((t) => ({
		content: t,
		location: `${n}.worldReferences[${e.worldReferences.findIndex((e) => e.projectId === t.projectId)}]`
	}))], c = /* @__PURE__ */ new Map();
	for (let [e, { content: t, location: n }] of s.entries()) {
		e > 0 && (a.has(t.projectId) && Z(r, n, "同じ作品・世界の複数の内容が現在の参照範囲に含まれています。固定版を一つにしてください。", "REFERENCE_INVALID"), a.add(t.projectId));
		for (let [e, i] of t.calendars.entries()) {
			let t = c.get(i.id);
			t && !ct(t, i) && Z(r, `${n}.calendars[${e}].id`, "同じ暦IDに異なる定義があります。固定版の日時を読み替えず、暦IDを明示して対応付けてください。", "REFERENCE_INVALID"), c.set(i.id, i);
		}
		for (let [e, i] of [["entities", t.entities], ["relations", t.relations]]) i.forEach((i, a) => {
			let s = `${n}.${e}[${a}]`;
			o.has(i.id) && Z(r, `${s}.id`, "現在の作品と参照中の共通世界でentity・relationのIDが衝突しています。曖昧な参照は保存できません。", "REFERENCE_INVALID"), o.add(i.id), i.projectId !== t.projectId && Z(r, `${s}.projectId`, "参照範囲のレコードが所属する作品・世界と一致しません。", "REFERENCE_INVALID");
		});
	}
}
function sr(e, t, n, r, i = /* @__PURE__ */ new Map(), a, o) {
	let s = [];
	if (!X(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: t,
			message: "作品はオブジェクトです。"
		}]
	};
	for (let n of Object.keys(e)) rr.includes(n) || Z(s, `${t}.${n}`, "作品に未知の項目があります。");
	let c = Object.fromEntries(Object.keys(nr).filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]]));
	Q(V(nr), c, t, s, []), e.formatVersion !== "1.0.0" && Z(s, `${t}.formatVersion`, "対応していない形式版です。", "FORMAT_UNSUPPORTED");
	for (let n of [
		"entities",
		"relations",
		"calendars",
		"views"
	]) Array.isArray(e[n]) || Z(s, `${t}.${n}`, "必須の配列です。");
	if (s.length) return {
		ok: !1,
		issues: s
	};
	let l = e.entities, u = e.relations, d = e.calendars;
	if (l.length + u.length > 1e5) return {
		ok: !1,
		issues: [{
			code: "IMPORT_LIMIT",
			path: t,
			message: "entityとrelationの合計は100,000件までです。"
		}]
	};
	if (o?.has(e, r, i)) return {
		ok: !0,
		value: e
	};
	if (!a) {
		let t = o?.previousContent(e, r, i);
		t && (a = {
			previous: t,
			references: /* @__PURE__ */ new WeakMap()
		});
	}
	let f = new Map(a?.previous.entities.map((e) => [e.id, e])), p = new Map(a?.previous.relations.map((e) => [e.id, e])), m = /* @__PURE__ */ new WeakMap(), h = /* @__PURE__ */ new WeakMap(), ee = (e, t) => e.map((e) => ({
		...e,
		path: e.path.slice(t.length + 1)
	}));
	l.forEach((e, n) => {
		let r = X(e) ? o?.entityReferences(e) : void 0;
		if (r) {
			m.set(e, r);
			return;
		}
		if (a && X(e) && f.get(e.id) === e) return;
		let i = `${t}.entities[${n}]`, c = [], l = Gn(e, i, c);
		if (!l.ok) s.push(...l.issues);
		else {
			let e = ee(c, i);
			m.set(l.value, e), o?.rememberEntity(l.value, e);
		}
	}), u.forEach((e, n) => {
		let r = X(e) ? o?.relationReferences(e) : void 0;
		if (r) {
			h.set(e, r);
			return;
		}
		if (a && X(e) && Object.is(p.get(e.id), e)) return;
		let i = `${t}.relations[${n}]`, c = [], l = zn(In, e, i, c);
		if (!l.ok) s.push(...l.issues);
		else {
			let e = ee(c, i);
			h.set(l.value, e), o?.rememberRelation(l.value, e);
		}
	}), d.forEach((e, n) => {
		let r = et(e, `${t}.calendars[${n}]`);
		r.ok || s.push(...r.issues);
	});
	let te = [];
	if (Q(z(tr), e.views, `${t}.views`, s, te), s.length) return {
		ok: !1,
		issues: s.slice(0, 256)
	};
	let g = e, ne = [...i].map(([e, t]) => ({
		id: e,
		content: t,
		contentHash: "",
		createdAt: "",
		versionLabel: ""
	}));
	if (s.push(...Ke(g, ne, t)), s.length) return {
		ok: !1,
		issues: s.slice(0, 256)
	};
	let re = g.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) ? Ue(g, ne) : g, ie = new Set(re.worldReferences.map((e) => e.projectId)), _ = n.worldSnapshots ? Ee(re, n.worldSnapshots) : void 0;
	if (_) for (let e of _.errors) Z(s, `${t}.worldReferences`, e, "REFERENCE_INVALID");
	let v = _?.worlds ?? (n.worlds ?? []).filter((e) => ie.has(e.projectId));
	if (l.length + u.length + v.reduce((e, t) => e + t.entities.length + t.relations.length, 0) > 1e5 && Z(s, t, "参照世界を含むレコード数が100,000件を超えています。", "IMPORT_LIMIT"), or(g, v, t, s), re !== g && or(re, v, `${t}.reuse`, s), s.length) return {
		ok: !1,
		issues: s.slice(0, 256)
	};
	let ae = [...re.entities, ...v.flatMap((e) => e.entities)], oe = new Map(ae.map((e) => [e.id, e])), se = new Map([...g.relations, ...v.flatMap((e) => e.relations)].map((e) => [e.id, e])), ce = new Set([...g.calendars, ...v.flatMap((e) => e.calendars)].map((e) => e.id)), le = /* @__PURE__ */ new Set();
	for (let [e, n] of [["entities", g.entities], ["relations", g.relations]]) n.forEach((n, r) => {
		le.has(n.id) && Z(s, `${t}.${e}[${r}].id`, "entityとrelationのIDは作品内で一意です。"), le.add(n.id), n.projectId !== g.projectId && Z(s, `${t}.${e}[${r}].projectId`, "レコードが別の作品に属しています。", "REFERENCE_INVALID");
	});
	let ue = g.calendars.map((e) => e.id);
	new Set(ue).size !== ue.length && Z(s, `${t}.calendars`, "暦IDが重複しています。"), ue.includes(g.calendarId) || Z(s, `${t}.calendarId`, "作品の暦が定義されていません。", "REFERENCE_INVALID");
	let de = g.worldReferences.map((e) => `${e.projectId}/${e.immutableSnapshotId}`);
	(new Set(de).size !== de.length || g.worldReferences.some((e) => e.projectId === g.projectId)) && Z(s, `${t}.worldReferences`, "共通世界参照の重複または自己参照があります。");
	let fe = /* @__PURE__ */ new Map(), pe = /* @__PURE__ */ new Map();
	for (let e of ae) lr(e.data, e.id, fe, pe, s, `${t}.entities.${e.id}.data`, 0, o);
	let me = /* @__PURE__ */ new Set([
		...oe.keys(),
		...se.keys(),
		...fe.keys()
	]);
	for (let e of ae) if (e.kind === "flow_node" && e.data.trigger?.id && me.add(e.data.trigger.id), e.kind === "projection_profile") {
		for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) X(t) && typeof t.id == "string" && me.add(t.id);
	}
	let he = v.flatMap((e) => [...e.entities.flatMap(Jn), ...e.relations.flatMap(Yn)]).filter((e) => e.scope === "snapshot" && n.worldSnapshots?.[e.id] && v.some((t) => t.projectId === n.worldSnapshots?.[e.id].projectId)).map((e) => e.id), y = /* @__PURE__ */ new Set([
		...r,
		...he,
		g.projectId,
		...ae.filter((e) => e.kind === "snapshot").map((e) => e.id),
		...(_?.references ?? re.worldReferences).map((e) => e.immutableSnapshotId)
	]), ge = {
		entities: oe,
		relations: se,
		blocks: fe,
		calendars: ce,
		projects: /* @__PURE__ */ new Set([g.projectId, ...(_?.references ?? re.worldReferences).map((e) => e.projectId)]),
		projectionIds: me
	}, _e = /* @__PURE__ */ new Map();
	function ve(e) {
		if (e === g.projectId && !g.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings)) return ge;
		let r = _e.get(e);
		if (r) return r;
		let a = e === g.projectId ? g : i.get(e) ?? n.worldSnapshots?.[e];
		if (!a) return;
		let c = a;
		try {
			c.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) && (c = Ue(c, ne));
		} catch {
			return;
		}
		let l = n.worldSnapshots ? Ee(c, n.worldSnapshots) : void 0;
		if (l) for (let n of l.errors) Z(s, `${t}.versions.${e}.worldReferences`, n, "REFERENCE_INVALID");
		let u = l?.worlds ?? (n.worlds ?? []).filter((e) => c.worldReferences.some((t) => t.projectId === e.projectId)), d = s.length;
		if (or(c, u, `${t}.versions.${e}`, s), s.length !== d) return;
		let f = [...c.entities, ...u.flatMap((e) => e.entities)], p = /* @__PURE__ */ new Map();
		for (let e of f) X(e) && lr(e.data, e.id, p, /* @__PURE__ */ new Map(), [], "version", 0, o);
		let m = /* @__PURE__ */ new Set([
			...f.map((e) => e.id),
			...c.relations.map((e) => e.id),
			...u.flatMap((e) => e.relations.map((e) => e.id)),
			...p.keys()
		]);
		for (let e of f) if (e.kind === "flow_node" && e.data.trigger?.id && m.add(e.data.trigger.id), e.kind === "projection_profile") {
			for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) X(t) && typeof t.id == "string" && m.add(t.id);
		}
		let h = {
			entities: new Map(f.filter((e) => X(e)).map((e) => [e.id, e])),
			relations: new Map([...c.relations, ...u.flatMap((e) => e.relations)].filter((e) => X(e)).map((e) => [e.id, e])),
			blocks: p,
			calendars: new Set([...c.calendars, ...u.flatMap((e) => e.calendars)].map((e) => e.id)),
			projects: /* @__PURE__ */ new Set([c.projectId, ...u.map((e) => e.projectId)]),
			projectionIds: m
		};
		return _e.set(e, h), h;
	}
	function b(e, t = "", r = ge) {
		let i = t ? `${t}.${e.path}` : e.path, a = !0;
		if (e.scope === "entity") {
			let t = r.entities.get(e.id);
			a = !!t, t && e.kinds && !e.kinds.includes(t.kind) && Z(s, i, `参照先の種類は${e.kinds.map((e) => kt[e]).join(" / ")}です。`, "REFERENCE_INVALID"), t && n.runtime && t.deletedAt && Z(s, i, "削除済み情報は実行用出力で参照できません。", "REFERENCE_INVALID");
		} else e.scope === "relation" ? a = r.relations.has(e.id) : e.scope === "record" ? a = r.entities.has(e.id) || r.relations.has(e.id) : e.scope === "projection_record" ? a = r.projectionIds.has(e.id) : e.scope === "presentation" ? a = r.entities.has(e.id) || r.blocks.has(e.id) : e.scope === "calendar" ? a = r.calendars.has(e.id) : e.scope === "project" ? a = r.projects.has(e.id) : e.scope === "snapshot" ? a = y.has(e.id) : e.scope === "block" ? a = r.blocks.has(e.id) : e.scope === "alias" && (a = pe.has(e.id));
		a || Z(s, i, "参照先が存在しないか、指定した作品・共通世界の範囲外です。", "REFERENCE_INVALID");
	}
	let ye = (e) => {
		let t = m.get(e);
		if (t) return t;
		if (!a || f.get(e.id) !== e) return Jn(e);
		let n = a.references.get(e);
		if (n) return n;
		let r = Jn(e);
		return a.references.set(e, r), r;
	};
	g.entities.forEach((e, n) => {
		let r = `${t}.entities[${n}]`;
		for (let t of ye(e)) {
			let n = Xn(t.path), i = n.slice(0, -1).reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), a = (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse && t.path === "data.reuse.sourceId" ? e.data.reuse.pinnedSnapshotId : void 0, o = e.kind === "projection_profile" && e.data.sourceVersionId && /^data\.(?:includedIds|publicTexts|blockSources|publicIds|publicValues|namePolicy|allowedRelationIds|approvedAttachmentIds)(?:\.|\[)/.test(t.path) ? e.data.sourceVersionId : void 0, c = (e.kind === "note" && t.path === "data.handoffReceipt.profileId" ? e.data.handoffReceipt?.profileVersionId : void 0) ?? a ?? (X(i) && typeof i.entityId == "string" && typeof i.sourceVersionId == "string" ? i.sourceVersionId : e.kind === "review" && t.path.startsWith("data.target.") ? e.data.targetVersionId : o);
			if (e.kind === "projection_profile" && t.scope === "projection_record" && t.path.endsWith(".$key") && Object.values(e.data.publicTexts ?? {}).some((e) => Object.values(e).some((e) => Array.isArray(e) && e.some((e) => e.id === t.id)))) {
				b(t, r);
				continue;
			}
			let l = e.kind === "checkpoint" && (t.path.startsWith("data.runtimeState.") || t.path.startsWith("data.presentationState.") || t.path.startsWith("data.presentationResults[")) || e.kind === "trace" && (t.path.startsWith("data.steps[") || t.path.startsWith("data.initialExternalValues.") || t.path.startsWith("data.initialStubValues.") || t.path.startsWith("data.initialStubBaseState.") || t.path.startsWith("data.readingPath."));
			if (c || l && (e.kind === "checkpoint" || e.kind === "trace")) {
				let i = ve(c ?? (e.kind === "checkpoint" || e.kind === "trace" ? e.data.contentVersionId : g.projectId));
				if (!i) {
					Z(s, c ? e.kind === "review" ? `${r}.data.targetVersionId` : `${r}.${n.slice(0, -1).join(".")}.sourceVersionId` : `${r}.data.contentVersionId`, "参照する固定版の本文がありません。", "REFERENCE_INVALID");
					continue;
				}
				b(t, r, i);
			} else b(t, r);
		}
	}), g.relations.forEach((e, n) => (h.get(e) ?? Yn(e)).forEach((e) => b(e, `${t}.relations[${n}]`))), te.forEach((e) => b(e));
	let be = n.relationTypes ?? Mt;
	g.relations.forEach((e, n) => {
		let r = `${t}.relations[${n}]`, i = be.find((t) => t.key === e.relationType), a = oe.get(e.fromId), o = oe.get(e.toId);
		i ? (a && !i.fromKinds.includes(a.kind) && Z(s, `${r}.fromId`, "この関係で許されない始点種類です。", "REFERENCE_INVALID"), o && !i.toKinds.includes(o.kind) && Z(s, `${r}.toId`, "この関係で許されない終点種類です。", "REFERENCE_INVALID"), e.fromId === e.toId && !i.allowSelf && Z(s, r, "この関係は自己関係を許しません。"), e.direction === "symmetric" && !i.allowSymmetric && Z(s, `${r}.direction`, "この関係は対称ではありません。")) : Z(s, `${r}.relationType`, "関係の種類が辞書に定義されていません。"), e.deletedAt && !e.deletionOperationId && Z(s, `${r}.deletionOperationId`, "削除には操作IDが必要です。"), qn(e.validity, `${r}.validity`, s);
	});
	let xe;
	if (a && JSON.stringify(g.worldReferences) === JSON.stringify(a.previous.worldReferences) && JSON.stringify(g.calendars) === JSON.stringify(a.previous.calendars)) {
		xe = /* @__PURE__ */ new Set([...g.entities.filter((e) => f.get(e.id) !== e).map((e) => e.id), ...g.relations.filter((e) => p.get(e.id) !== e).map((e) => e.id)]);
		for (let e of f.keys()) oe.has(e) || xe.add(e);
		for (let e of p.keys()) se.has(e) || xe.add(e);
	}
	return dr(g, oe, pe, y, fe, s, t, n, ve, xe && !s.length ? (e) => f.get(e.id) !== e || ye(e).some((e) => xe.has(e.id)) : void 0), s.length || o?.remember(g, r, i), s.length ? {
		ok: !1,
		issues: s.slice(0, 256)
	} : {
		ok: !0,
		value: g
	};
}
function cr(e) {
	return e === "runtimeState" || e === "before" || e === "after" || e === "publicTexts";
}
function lr(e, t, n, r, i, a, o = 0, s) {
	if (o > 32 || !e || typeof e != "object") return;
	if (!s) {
		if (Array.isArray(e)) {
			e.forEach((e, s) => lr(e, t, n, r, i, `${a}[${s}]`, o + 1));
			return;
		}
		let s = e;
		typeof s.id == "string" && typeof s.text == "string" && [
			"paragraph",
			"heading",
			"list_item",
			"quote"
		].includes(s.kind) && (n.has(s.id) && Z(i, `${a}.id`, "本文ブロックIDが重複しています。"), n.set(s.id, {
			entityId: t,
			text: s.text
		})), typeof s.id == "string" && "isPublicDefault" in s && (r.has(s.id) && Z(i, `${a}.id`, "別名IDが重複しています。"), r.set(s.id, {
			entityId: t,
			alias: s
		}));
		for (let e of Object.keys(s)) {
			if (cr(e)) continue;
			let c = s[e];
			c && typeof c == "object" && lr(c, t, n, r, i, `${a}.${e}`, o + 1);
		}
		return;
	}
	let c = o === 0 ? s?.contentIds(e) : void 0;
	if (!c) {
		c = [];
		let t = (e, n, r) => {
			if (r > 32 || !e || typeof e != "object") return;
			if (Array.isArray(e)) {
				e.forEach((e, i) => t(e, `${n}[${i}]`, r + 1));
				return;
			}
			let i = e;
			typeof i.id == "string" && typeof i.text == "string" && [
				"paragraph",
				"heading",
				"list_item",
				"quote"
			].includes(i.kind) && c.push({
				kind: "block",
				id: i.id,
				text: i.text,
				path: n
			}), typeof i.id == "string" && "isPublicDefault" in i && c.push({
				kind: "alias",
				id: i.id,
				alias: i,
				path: n
			});
			for (let e of Object.keys(i)) {
				if (cr(e)) continue;
				let a = i[e];
				a && typeof a == "object" && t(a, `${n}.${e}`, r + 1);
			}
		};
		t(e, "", o), o === 0 && s?.rememberContentIds(e, c);
	}
	for (let e of c) {
		let o = a + e.path;
		e.kind === "block" ? (n.has(e.id) && Z(i, `${o}.id`, "本文ブロックIDが重複しています。"), n.set(e.id, {
			entityId: t,
			text: e.text
		})) : (r.has(e.id) && Z(i, `${o}.id`, "別名IDが重複しています。"), r.set(e.id, {
			entityId: t,
			alias: e.alias
		}));
	}
}
function ur(e, t, n, r, i) {
	let a = new Map(e.map((e) => [e.id, e])), o = /* @__PURE__ */ new Map();
	for (let s of e) {
		if (o.get(s.id)) continue;
		let e = [{
			id: s.id,
			ids: t(s),
			cursor: 0
		}];
		for (o.set(s.id, 1); e.length;) {
			let s = e[e.length - 1];
			if (s.cursor >= s.ids.length) {
				o.set(s.id, 2), e.pop();
				continue;
			}
			let c = s.ids[s.cursor++], l = a.get(c);
			if (l) {
				if (o.get(c) === 1) {
					Z(n, `${r}.entities.${s.id}.data`, `${i}に循環があります。`);
					continue;
				}
				o.get(c) || (o.set(c, 1), e.push({
					id: c,
					ids: t(l),
					cursor: 0
				}));
			}
		}
	}
}
function dr(e, t, n, r, i, a, o, s, c, l) {
	let u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set();
	e.entities.some((e) => !!e.templateId && !e.deletedAt) && a.push(...gt(e, o, [...t.values()])), e.entities.forEach((e, f) => {
		let p = `${o}.entities[${f}]`;
		if (!e.deletedAt) {
			if (e.kind === "variable" || e.kind === "quest" || e.kind === "external_contract") {
				let t = `${e.kind}/${e.kind === "variable" ? `${e.data.scope}/${e.data.ownerId ?? ""}/` : ""}${e.data.key}`;
				u.has(t) && Z(a, `${p}.data.key`, "同じスコープでキーが重複しています。"), u.set(t, e.id);
			}
			if (e.kind === "localization") {
				let t = `${e.data.sourceLineId}/${e.data.language}/${e.data.sourceHash}`;
				d.has(t) && Z(a, p, "同じ台詞・言語・原文版の翻訳が重複しています。"), d.add(t);
			}
			if (!l || l(e) || e.kind === "checkpoint" || e.kind === "trace") {
				if (e.kind === "template" && a.push(...ht(e.data, `${p}.data`, t)), e.kind === "item" && e.data.itemMode === "instance") {
					let n = e.data.typeId ? t.get(e.data.typeId) : void 0;
					n?.kind === "item" && n.data.itemMode !== "type" && Z(a, `${p}.data.typeId`, "個体のtypeIdは物品種類を参照してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "quest") {
					let n = t.get(e.data.stateVariableId);
					if (n?.kind === "variable") for (let [t, r] of (e.data.transitionRules ?? []).entries()) a.push(...$(n, r.from, `${p}.data.transitionRules[${t}].from`, !1), ...$(n, r.to, `${p}.data.transitionRules[${t}].to`, !1));
				}
				if (e.kind === "variable") for (let [n, r] of (e.data.exclusions ?? []).entries()) {
					let e = t.get(r.variableId);
					e?.kind === "variable" && a.push(...$(e, r.otherValue, `${p}.data.exclusions[${n}].otherValue`, !1));
				}
				if (e.kind === "collection" && e.data.purpose === "regression") for (let [n, r] of (e.data.memberIds ?? []).entries()) {
					let e = t.get(r);
					e && e.kind !== "trace" && Z(a, `${p}.data.memberIds[${n}]`, "回帰経路集合には保存した試読記録を指定してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "effect") {
					let n = t.get(e.data.targetId), r = e.data.operation;
					if (n && [
						"set",
						"add",
						"reset"
					].includes(r) && (n.kind === "variable" ? (n.data.derived && Z(a, `${p}.data.targetId`, "算出状態へ直接代入できません。"), r === "add" && n.data.valueType !== "integer" && Z(a, `${p}.data.targetId`, "addはinteger状態だけです。"), e.data.value && r !== "add" && a.push(...$(n, e.data.value, `${p}.data.value`))) : Z(a, `${p}.data.targetId`, "状態更新効果は状態変数を参照してください。", "REFERENCE_INVALID")), n && [
						"grant",
						"consume",
						"move"
					].includes(r) && n.kind !== "item" && Z(a, `${p}.data.targetId`, "物品効果は物品を参照してください。", "REFERENCE_INVALID"), n?.kind === "item" && [
						"grant",
						"consume",
						"move"
					].includes(r) && e.data.instanceId) {
						let r = t.get(e.data.instanceId);
						r?.kind === "item" && (r.data.itemMode !== "instance" || (n.data.itemMode === "type" ? r.data.typeId !== n.id : r.id !== n.id)) && Z(a, `${p}.data.instanceId`, "指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
					}
					if (n && r === "assert" && n.kind !== "assertion" && Z(a, `${p}.data.targetId`, "認識効果は事実・認識を参照してください。", "REFERENCE_INVALID"), r === "move" && e.data.value?.type === "ref") {
						let n = t.get(e.data.value.value);
						n && ![
							"character",
							"group",
							"place"
						].includes(n.kind) && Z(a, `${p}.data.value`, "物品の移動先は人物・グループ・場所です。", "REFERENCE_INVALID");
					}
				}
				if (e.kind === "flow_graph") {
					for (let t of [...e.data.entryIds, ...e.data.exitIds]) e.data.nodeIds.includes(t) || Z(a, `${p}.data`, "入口・出口はその分岐図のノード集合に含めてください。");
					for (let n of e.data.edgeIds) {
						let r = t.get(n);
						r?.kind === "flow_edge" && (!e.data.nodeIds.includes(r.data.fromId) || typeof r.data.toId == "string" && !e.data.nodeIds.includes(r.data.toId)) && Z(a, `${p}.data.edgeIds`, "進行線の始点・終点は同じ分岐図内に置いてください。");
					}
					let n = (e.data.parameters ?? []).map((e) => e.key);
					new Set(n).size !== n.length && Z(a, `${p}.data.parameters`, "引数のキーが重複しています。");
				}
				if (e.kind === "flow_edge" && s.runtime && typeof e.data.toId != "string" && Z(a, `${p}.data.toId`, "未完成の分岐先は実行用出力できません。", "EXPORT_UNSUPPORTED"), e.kind === "variable" && s.runtime && e.data.initial.type === "unknown" && !e.data.derived && Z(a, `${p}.data.initial`, "初期値が未定です。", "CONDITION_UNKNOWN"), pr(e.data, p, t, a), e.kind === "review" && typeof e.data.target == "object" ? (mr(e.data.target, `${p}.data.target`, t, i, a, 0, c, e.data.targetVersionId), mr({
					...e.data,
					target: null
				}, `${p}.data`, t, i, a, 0, c)) : mr(e.data, `${p}.data`, t, i, a, 0, c), e.kind === "projection_profile") {
					let t = e.data.namePolicy;
					if ("mode" in t && t.mode === "alias") {
						let r = n.get(t.aliasId);
						r && !e.data.includedIds.includes(r.entityId) && Z(a, `${p}.data.namePolicy`, "別名は投影対象の本体に属している必要があります。");
					} else if (!("mode" in t)) for (let [e, r] of Object.entries(t.byEntityId ?? {})) r.mode === "alias" && n.get(r.aliasId)?.entityId !== e && Z(a, `${p}.data.namePolicy.byEntityId.${e}`, "別名が指定した本体に属していません。");
				}
				if (e.kind === "checkpoint" && (!r.has(e.data.runtimeState.contentVersionId) || e.data.runtimeState.contentVersionId !== e.data.contentVersionId) && Z(a, `${p}.data.runtimeState.contentVersionId`, "途中開始の状態と対象版が一致しません。"), e.kind === "checkpoint") {
					let t = Hn(e.data.runtimeState, `${p}.data.runtimeState`);
					if (t.ok || a.push(...t.issues), e.data.presentationState && (e.data.presentationState.contentVersionId !== e.data.contentVersionId || e.data.presentationState.presentationPosition !== e.data.runtimeState.presentationPosition || e.data.presentationState.provenance !== e.data.runtimeState.provenance) && Z(a, `${p}.data.presentationState`, "提示前の観測状態と開始点・対象版・由来が一致しません。"), e.data.presentationResults != null) {
						let t = c(e.data.contentVersionId);
						t && a.push(...Un({
							...e.data.runtimeState,
							provenance: e.data.origin ?? "partial"
						}, e.data.presentationResults, [...t.entities.values()], `${p}.data.presentationResults`));
					}
				}
				if (e.kind === "trace") {
					let t = e.data;
					t.initialStubBaseState && !t.initialStubValues && Z(a, `${p}.data.initialStubBaseState`, "stub前の個別状態には初期stub入力の記録が必要です。"), t.mode === "chapters" ? ((t.initialStubValues || t.initialStubBaseState) && Z(a, `${p}.data.initialStubValues`, "章経路の個別開始はcheckpointへ、外部仮値はinitialExternalValuesへ記録してください。"), t.readingPath || Z(a, `${p}.data.readingPath`, "章読み通しには提示経路が必要です。"), t.steps.length && Z(a, `${p}.data.steps`, "章読み通しとフロー遷移を混在させられません。")) : t.readingPath != null && Z(a, `${p}.data.readingPath`, "提示経路はmode:chaptersの記録に指定してください。"), t.steps.forEach((e, n) => {
						for (let [t, r] of [["before", e.before], ["after", e.after]]) {
							let e = Hn(r, `${p}.data.steps[${n}].${t}`);
							e.ok || a.push(...e.issues);
						}
						e.presentationState && (e.presentationState.contentVersionId !== t.contentVersionId || e.presentationState.presentationPosition !== e.after.presentationPosition || e.presentationState.provenance !== e.after.provenance) && Z(a, `${p}.data.steps[${n}].presentationState`, "提示前の観測状態と提示先・対象版・由来が一致しません。");
					}), t.readingPath?.occurrences.forEach((e, t) => {
						for (let [n, r] of [["before", e.before], ["after", e.after]]) {
							let e = Hn(r, `${p}.data.readingPath.occurrences[${t}].${n}`);
							e.ok || a.push(...e.issues);
						}
					});
				}
			}
		}
	});
	for (let t of [
		"place",
		"group",
		"flow_graph",
		"map"
	]) ur(e.entities.filter((e) => e.kind === t && !e.deletedAt), (e) => e.kind === "place" || e.kind === "group" ? e.data.parentId ? [e.data.parentId] : [] : e.kind === "flow_graph" ? e.data.parentGraphId ? [e.data.parentGraphId] : [] : e.kind === "map" && e.data.parentMapId ? [e.data.parentMapId] : [], a, o, `${kt[t]}の階層`);
	ur(e.entities.filter((e) => e.kind === "production_task" && !e.deletedAt), (e) => e.kind === "production_task" ? e.data.dependsOn ?? [] : [], a, o, "制作依存"), ur(e.entities.filter((e) => e.kind === "variable" && !e.deletedAt), (e) => e.kind === "variable" && e.data.derived ? fr(e.data.derived) : [], a, o, "算出状態"), ur(e.entities.filter((e) => e.kind === "flow_graph" && !e.deletedAt), (e) => e.kind === "flow_graph" ? e.data.nodeIds.flatMap((e) => {
		let n = t.get(e);
		return n?.kind === "flow_node" && n.data.childGraphId ? [n.data.childGraphId] : [];
	}) : [], a, o, "分岐図の呼出階層"), a.push(...st([...t.values()].filter((e) => e.kind === "event" && !e.deletedAt)));
	let f = /* @__PURE__ */ new Map();
	for (let t of e.entities) if (t.kind === "flow_edge" && t.data.edgeType === "automatic" && !t.deletedAt) {
		let e = `${t.data.fromId}/${t.data.priority ?? 0}`;
		f.has(e) && Z(a, `${o}.entities.${t.id}.data.priority`, "同じ始点の自動候補で優先順位が重複しています。"), f.set(e, t.id);
	}
}
function fr(e) {
	let t = [];
	return Q({ type: "expression" }, e, "", [], t), t.filter((e) => e.kinds?.includes("variable")).map((e) => e.id);
}
function pr(e, t, n, r, i = 0) {
	if (i > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, a) => pr(e, `${t}[${a}]`, n, r, i + 1));
		return;
	}
	let a = e;
	if (a.op === "compare") {
		let e = n.get(a.variableId);
		if (e?.kind === "variable") {
			let n = a.comparator, i = Array.isArray(a.value) ? a.value : [a.value];
			[
				"lt",
				"le",
				"gt",
				"ge"
			].includes(n) && e.data.valueType !== "integer" && Z(r, `${t}.comparator`, "順序比較はintegerにだけ使えます。"), i.forEach((n, a) => {
				n.type !== "unknown" && n.type !== e.data.valueType && Z(r, `${t}.value${i.length > 1 ? `[${a}]` : ""}`, "比較値の型が状態変数と一致しません。");
			});
		}
	}
	for (let e of Object.keys(a)) {
		let o = a[e];
		o && typeof o == "object" && pr(o, `${t}.${e}`, n, r, i + 1);
	}
}
function mr(e, t, n, r, i, a = 0, o, s) {
	if (a > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, c) => mr(e, `${t}[${c}]`, n, r, i, a + 1, o, s));
		return;
	}
	let c = e;
	if (typeof c.entityId == "string") {
		c.positionStatus === "unresolved" && (!c.positionReason || c.start != null || c.end != null) && Z(i, t, "位置不明には理由を付け、確定した文字範囲を外してください。"), c.positionStatus !== "unresolved" && (c.positionReason != null || c.quotedText != null) && Z(i, t, "位置不明の理由・引用は位置不明状態と一緒に保存してください。");
		let e = typeof c.sourceVersionId == "string" ? c.sourceVersionId : s, a = e && o ? o(e) : void 0, l = a?.entities ?? n, u = a?.blocks ?? r, d;
		if (typeof c.blockId == "string") {
			let e = u.get(c.blockId);
			e && e.entityId !== c.entityId && Z(i, `${t}.blockId`, "段落は指定した情報に属していません。", "REFERENCE_INVALID"), d = e?.text;
		}
		if (typeof c.lineId == "string") {
			let e = l.get(c.lineId);
			e?.kind === "dialogue_line" && (d = zt(e.data.text));
		}
		(typeof c.start == "number" || typeof c.end == "number") && ((typeof c.start != "number" || typeof c.end != "number") && Z(i, t, "文字範囲はstart/endを対で指定してください。"), d === void 0 ? Z(i, t, "文字範囲には本文ブロックまたは台詞への参照が必要です。") : typeof c.end == "number" && c.end > xn(d) && Z(i, `${t}.end`, "文字範囲が参照元の本文を超えています。"));
	}
	for (let e of Object.keys(c)) {
		let s = c[e];
		s && typeof s == "object" && ![
			"publicTexts",
			"before",
			"after",
			"runtimeState"
		].includes(e) && mr(s, `${t}.${e}`, n, r, i, a + 1, o);
	}
}
function hr(e, t = {}) {
	if (!X(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	let n = gr() === void 0 ? void 0 : Dt(e, t, Mt), r = n?.memo;
	return t = n?.options ?? t, vr(e, t, r);
}
function gr() {
	let e = /* @__PURE__ */ new Map(), t = /* @__PURE__ */ new Set(), n = [], r = (i, a) => {
		if (a > 128) throw Error("Unsupported schema depth");
		if (i === void 0) return ["undefined"];
		if (typeof i == "string" && !y(i) || typeof i == "number" && !Number.isFinite(i)) throw Error("Unsupported schema scalar");
		if (i === null || [
			"string",
			"boolean",
			"number"
		].includes(typeof i)) return ["value", i];
		if (typeof i != "object" || t.has(i)) throw Error("Unsupported schema value");
		let o = i, s = e.get(o);
		if (s !== void 0) return ["reference", s];
		let c = Array.isArray(o), l = Object.getPrototypeOf(o);
		if (c ? l !== Array.prototype : l !== Object.prototype && l !== null) throw Error("Unsupported schema prototype");
		let u = Reflect.ownKeys(o);
		if (u.some((e) => typeof e != "string" || !y(e) || [
			"__proto__",
			"constructor",
			"prototype"
		].includes(e))) throw Error("Unsupported schema key");
		if (c && (u.length !== o.length + 1 || u.some((e) => e !== "length" && (!/^(0|[1-9]\d*)$/.test(String(e)) || Number(e) >= o.length)))) throw Error("Unsupported schema array");
		let d = n.length, f = [];
		e.set(o, d), t.add(o), n.push([c ? "array" : "object", f]);
		for (let e of u.sort()) {
			if (c && e === "length") continue;
			let t = Object.getOwnPropertyDescriptor(o, e);
			if (!t?.enumerable || !Object.hasOwn(t, "value")) throw Error("Unsupported schema descriptor");
			f.push([e, r(t.value, a + 1)]);
		}
		return t.delete(o), ["reference", d];
	};
	try {
		let e = r({
			schemas: yn,
			kinds: D,
			statuses: At,
			scopes: jt
		}, 0);
		return JSON.stringify({
			root: e,
			nodes: n
		});
	} catch {
		return;
	}
}
function _r(e = {}) {
	let t = E(e);
	if (!t.captured) return (t) => hr(t, e);
	let n = E({
		...t.value,
		relationTypes: t.value.relationTypes ?? Mt
	});
	if (!n.captured) return (t) => hr(t, e);
	let r, i;
	return (e) => {
		let t = gr();
		if (t === void 0) return hr(e, n.value);
		t !== i && (r = void 0, i = t);
		let a = E(e);
		return !a.captured || !wt(a.value) ? hr(e, n.value) : (r ??= Dt(a.value, n.value, Mt), vr(a.value, r?.options ?? n.value, r?.memo));
	};
}
function vr(e, t, n) {
	if (_("validate.full.calls"), !X(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	let r = [];
	for (let t of Object.keys(e)) [
		...ir,
		"snapshots",
		"history"
	].includes(t) || Z(r, `project.${t}`, "作品に未知の項目があります。");
	Array.isArray(e.snapshots) || Z(r, "project.snapshots", "必須の配列です。"), Array.isArray(e.history) || Z(r, "project.history", "必須の配列です。");
	let i = new Set((Array.isArray(e.snapshots) ? e.snapshots : []).flatMap((e) => X(e) && typeof e.id == "string" ? [e.id] : []));
	Object.hasOwn(e, "authorAlternatives") && Q(ar, e.authorAlternatives, "project.authorAlternatives", r, []);
	let a = sr(Object.fromEntries(rr.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, i, xr(e.snapshots), void 0, n);
	if (a.ok || r.push(...a.issues), r.length) return {
		ok: !1,
		issues: r.slice(0, 256)
	};
	let o = e;
	br(o.snapshots, "project.snapshots", o.projectId, t, r, n);
	let s = /* @__PURE__ */ new Set();
	return o.history.forEach((e, i) => {
		let a = `project.history[${i}]`, c = e;
		if (!X(c)) {
			Z(r, a, "履歴はコマンドです。");
			return;
		}
		let l = V({
			operationId: H(N),
			projectId: H(N),
			baseRevision: H({ type: "revision" }),
			revision: H({ type: "revision" }),
			targetIds: H(z(N, !0)),
			reason: H(O()),
			createdAt: H({ type: "datetime" }),
			compensatesOperationId: U(N),
			idMap: U(K(N, N)),
			importOrigin: U(V({
				sourceProjectId: H(N),
				sourceOperationId: H(N),
				importOperationId: H(N)
			}))
		});
		for (let e of Object.keys(c)) e !== "before" && e !== "after" && l.type === "object" && !Object.hasOwn(l.fields, e) && Z(r, `${a}.${e}`, "コマンドに未知の項目があります。");
		Q(l, Object.fromEntries(Object.entries(c).filter(([e]) => e !== "before" && e !== "after")), a, r, []), s.has(e.operationId) && Z(r, `${a}.operationId`, "履歴の操作IDが重複しています。"), s.add(e.operationId), e.projectId !== o.projectId && Z(r, `${a}.projectId`, "履歴が別の作品に属しています。");
		for (let e of ["before", "after"]) {
			if (!X(c[e])) {
				Z(r, `${a}.${e}`, "変更前後の内容を保持してください。");
				continue;
			}
			let i = c[e];
			Array.isArray(i.snapshots) || Z(r, `${a}.${e}.snapshots`, "復元に必要な公開版配列が必要です。"), Object.hasOwn(i, "authorAlternatives") && Q(ar, i.authorAlternatives, `${a}.${e}.authorAlternatives`, r, []);
			let s = Object.fromEntries(Object.entries(i).filter(([e]) => e !== "snapshots" && e !== "authorAlternatives")), l = new Set((Array.isArray(i.snapshots) ? i.snapshots : []).flatMap((e) => X(e) && typeof e.id == "string" ? [e.id] : [])), u = sr(s, `${a}.${e}`, t, l, xr(i.snapshots), void 0, n);
			u.ok ? u.value.projectId !== o.projectId && Z(r, `${a}.${e}.projectId`, "履歴の内容が別の作品に属しています。") : r.push(...u.issues), Array.isArray(i.snapshots) && br(i.snapshots, `${a}.${e}.snapshots`, o.projectId, t, r, n);
		}
	}), r.length ? {
		ok: !1,
		issues: r.slice(0, 256)
	} : {
		ok: !0,
		value: o
	};
}
function yr(e, t = {}, n) {
	_("validate.current.calls");
	let r = [];
	for (let t of Object.keys(e)) [
		...ir,
		"snapshots",
		"history"
	].includes(t) || Z(r, `project.${t}`, "作品に未知の項目があります。");
	if ((!Array.isArray(e.snapshots) || !Array.isArray(e.history)) && Z(r, "project", "公開版と履歴の配列が必要です。"), Object.hasOwn(e, "authorAlternatives") && Q(ar, e.authorAlternatives, "project.authorAlternatives", r, []), r.length) return {
		ok: !1,
		issues: r
	};
	let i = new Set(e.snapshots.map((e) => e.id)), a = sr(Object.fromEntries(rr.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, i, xr(e.snapshots), n);
	return a.ok ? {
		ok: !0,
		value: e
	} : a;
}
function br(e, t, n, r, i, a) {
	let o = new Set(e.flatMap((e) => X(e) && typeof e.id == "string" ? [e.id] : [])), s = /* @__PURE__ */ new Set(), c = xr(e);
	e.forEach((e, l) => {
		let u = `${t}[${l}]`;
		if (!X(e)) {
			Z(i, u, "公開版はオブジェクトです。");
			return;
		}
		let d = V({
			id: H(N),
			versionLabel: H(O(1, 128)),
			contentHash: H({ type: "hash" }),
			createdAt: H({ type: "datetime" })
		});
		for (let t of Object.keys(e)) [
			"id",
			"versionLabel",
			"contentHash",
			"createdAt",
			"content"
		].includes(t) || Z(i, `${u}.${t}`, "公開版に未知の項目があります。");
		Q(d, Object.fromEntries(Object.entries(e).filter(([e]) => e !== "content")), u, i, []), typeof e.id == "string" && (s.has(e.id) && Z(i, `${u}.id`, "公開版のIDが重複しています。"), s.add(e.id), e.id === n && Z(i, `${u}.id`, "公開版IDは作品IDと別にしてください。"));
		let f = sr(e.content, `${u}.content`, r, o, c, void 0, a);
		f.ok ? f.value.projectId !== n && Z(i, `${u}.content.projectId`, "公開版が別の作品に属しています。") : i.push(...f.issues);
	});
}
function xr(e) {
	return Array.isArray(e) ? new Map(e.flatMap((e) => X(e) && typeof e.id == "string" && X(e.content) && [
		"entities",
		"relations",
		"calendars",
		"worldReferences"
	].every((t) => Array.isArray(e.content[t]) && e.content[t].every(X)) ? [[e.id, e.content]] : [])) : /* @__PURE__ */ new Map();
}
//#endregion
export { y as $, E as A, Me as B, Wn as C, Vn as D, Hn as E, Ze as F, Ee as G, Oe as H, at as I, fe as J, De as K, Ue as L, Et as M, wt as N, $ as O, C as P, xe as Q, Ne as R, yr as S, l as St, hr as T, we as U, We as V, Te as W, ve as X, b as Y, be as Z, Lt as _, ue as _t, Mt as a, _e as at, Rt as b, f as bt, Ut as c, ae as ct, Gt as d, v as dt, ye as et, It as f, le as ft, Ot as g, de as gt, cr as h, re as ht, Nt as i, Se as it, Tt as j, gr as k, Wt as l, oe as lt, Bt as m, ce as mt, Pt as n, me as nt, Jn as o, h as ot, Vt as p, se as pt, pe as q, kt as r, Ce as rt, Yn as s, _ as st, D as t, ge as tt, _r as u, ne as ut, Qn as v, u as vt, Un as w, Bn as x, o as xt, $n as y, d as yt, Ge as z };
