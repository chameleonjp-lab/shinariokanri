import { E as e, F as t, H as n, I as r, L as i, O as a, R as o, V as s, d as c, m as l, p as u, w as d } from "./model-CpGFZXoy.js";
import { a as f, d as p, f as m, h, i as g, m as _, n as v, p as y } from "./presentation-CWp-ugMV.js";
//#region src/domain/runtime.ts
var b = (e) => structuredClone(e);
function x(e) {
	if (e === void 0) return "undefined";
	if (typeof e != "object" || !e) return JSON.stringify(e);
	if (Array.isArray(e)) return `[${e.map(x).join(",")}]`;
	let t = e;
	return `{${Object.keys(t).filter((e) => t[e] !== void 0).sort().map((e) => `${JSON.stringify(e)}:${x(t[e])}`).join(",")}}`;
}
var S = (e, t) => x(e) === x(t), C = (e, t, n = "runtime") => ({
	code: e,
	message: t,
	path: n
}), w = (e) => e.filter(n), T = /* @__PURE__ */ new WeakMap(), E = /* @__PURE__ */ new WeakMap(), D = (e) => [...e.entities, ...E.get(e) ?? []], O = (e, t) => {
	let n = T.get(e);
	return n ? n.activeByKind.get(t) ?? [] : w(u(e, t));
}, k = (e, t) => {
	let n = T.get(e);
	return n ? n.byId.get(t) : l(e, t);
}, A = (e) => O(e, "flow_node"), j = (e) => O(e, "flow_edge"), M = (e) => O(e, "variable"), N = (e) => O(e, "flow_graph");
function P(e, t) {
	if (t === e.projectId) return e;
	let n = e.snapshots.find((e) => e.id === t);
	return n ? {
		...n.content,
		snapshots: e.snapshots,
		history: []
	} : void 0;
}
function F(e, t = []) {
	let { authorAlternatives: r, ...a } = e, o = {
		...b({
			...a,
			history: [],
			snapshots: []
		}),
		snapshots: e.snapshots
	}, s = i(o, e.snapshots), c = {
		byId: /* @__PURE__ */ new Map(),
		activeByKind: /* @__PURE__ */ new Map(),
		edgesFrom: /* @__PURE__ */ new Map()
	};
	E.set(s, v(t));
	for (let e of [...s.entities, ...E.get(s) ?? []]) {
		if (e.deletedAt || (c.byId.set(e.id, e), !n(e))) continue;
		let t = c.activeByKind.get(e.kind) ?? [];
		if (t.push(e), c.activeByKind.set(e.kind, t), e.kind === "flow_edge") {
			let t = c.edgesFrom.get(e.data.fromId) ?? [];
			t.push(e), c.edgesFrom.set(e.data.fromId, t);
		}
	}
	return T.set(s, c), s;
}
function I(e, t) {
	return t.content ?? P(e, t.state.contentVersionId) ?? e;
}
var L = (e, t) => {
	let n = t === null ? void 0 : k(e, t);
	return n?.kind === "flow_node" && n.status !== "rejected" ? n : void 0;
}, R = (e, t) => {
	let n = T.get(e);
	return n ? n.edgesFrom.get(t) ?? [] : j(e).filter((e) => e.data.fromId === t);
}, z = (e, t, n, r) => m(n ?? {
	op: "constant",
	value: !0
}, {
	state: t,
	variables: M(e),
	entities: D(e),
	externalValues: r
}), B = (e, t, n) => ({
	...e,
	nodeId: e.state.presentationPosition,
	status: t,
	issues: n
});
function V(e) {
	return e?.data.reuse && e.data.reuse.mode !== "clone" ? C("VALIDATION_FAILED", "共通元を固定版から解決する参照・上書き試読は未対応です。実行を停止しています。", `${e.id}.reuse`) : void 0;
}
function H(e) {
	return e && typeof e == "object" && "issues" in e && Array.isArray(e.issues) ? e.issues : [C("VALIDATION_FAILED", e instanceof Error ? e.message : "試読の入力を検証できません。")];
}
function U(e) {
	e = o(e);
	let t = N(e).filter((t) => t.projectId === e.projectId && !t.data.parentGraphId);
	return t.length > 0 ? [...new Set(t.flatMap((e) => e.data.entryIds))] : A(e).filter((t) => t.projectId === e.projectId && t.data.nodeType === "entry").map((e) => e.id);
}
function W(e) {
	let t = U(e);
	return t.length === 1 ? t[0] : void 0;
}
function G(e, t, n, r, i) {
	return g(e, t, {
		nodeId: n,
		externalValues: r,
		referenceEntities: E.get(e),
		worldTick: i
	});
}
function ee(e, t) {
	try {
		return K(e, t);
	} catch {
		return [];
	}
}
function K(e, t) {
	let n = t.content ?? P(e, t.state.contentVersionId);
	if (!n) return [];
	e = n;
	let r = L(e, t.nodeId);
	if (!r || r.data.nodeType === "terminal") return [];
	let i = z(e, t.state, r.data.gate, t.externalValues);
	return R(e, r.id).map((n) => {
		let r = z(e, t.state, n.data.condition, t.externalValues), a = i.value === "false" || r.value === "false" ? "false" : i.value === "unknown" || r.value === "unknown" ? "unknown" : "true";
		return {
			edgeId: n.id,
			label: n.data.label || n.name || "次へ",
			toId: typeof n.data.toId == "string" ? n.data.toId : null,
			result: a,
			reasons: [...i.reasons, ...r.reasons],
			priority: n.data.priority ?? 0
		};
	}).sort((e, t) => e.priority - t.priority);
}
function q(e, t) {
	let n = L(e, t.nodeId);
	if (!n) return B(t, "error", [C("REFERENCE_INVALID", "現在の分岐が存在しません。")]);
	let r = V(n);
	if (r) return B(t, "error", [r]);
	if (n.data.nodeType === "terminal") return n.data.terminalReason?.trim() ? B(t, "terminal", []) : B(t, "error", [C("VALIDATION_FAILED", "終端には終了理由が必要です。", `${n.id}.terminalReason`)]);
	let i = z(e, t.state, n.data.gate, t.externalValues);
	if (i.value === "unknown") return B(t, "unknown", [C("CONDITION_UNKNOWN", i.reasons.join("、") || "発火条件の値が不足しています。", `${n.id}.gate`)]);
	if (i.value === "false") return n.data.fallbackId ? B(t, "ready", []) : B(t, "blocked", [C("TRANSITION_BLOCKED", "発火条件を満たさず、代替の進行先もありません。", `${n.id}.gate`)]);
	if (n.data.nodeType === "call" || n.data.nodeType === "exit" && t.state.callStack.length > 0) return B(t, "ready", []);
	let a = n.data.executionPolicy ?? (n.data.nodeType === "automatic" ? "first_match" : "manual_choice"), o = K(e, t);
	if (o.some((e) => !Number.isSafeInteger(e.priority))) return B(t, "error", [C("VALIDATION_FAILED", "優先値には安全な整数が必要です。", `${n.id}.priority`)]);
	if (a !== "manual_choice" && new Set(o.map((e) => e.priority)).size !== o.length) return B(t, "error", [C("VALIDATION_FAILED", "自動分岐の優先値が重複しています。", `${n.id}.priority`)]);
	let s = o.filter((e) => e.result === "unknown"), c = o.filter((e) => e.result === "true");
	return s.length > 0 && (a !== "manual_choice" || c.length === 0) ? B(t, "unknown", [C("CONDITION_UNKNOWN", "未確認の条件があり、進行先を確定できません。", n.id)]) : c.length === 0 && !n.data.fallbackId ? B(t, "blocked", [C("TRANSITION_BLOCKED", "有効な選択肢がありません。意図した終端とは別の行き止まりです。", n.id)]) : B(t, "ready", []);
}
function J(e, t = {}) {
	try {
		return Y(e, t);
	} catch (n) {
		let r = t.state ? b(t.state) : c(t.contentVersionId ?? e.projectId);
		return {
			content: e,
			state: r,
			nodeId: r.presentationPosition,
			contentRevision: e.revision,
			startState: b(r),
			startConditionResults: [],
			status: "error",
			history: [],
			trace: [],
			issues: H(n),
			lastDiff: [],
			externalValues: {},
			startExternalValues: {}
		};
	}
}
function Y(r, i = {}, o = !1) {
	let c = r, l = i.checkpointId ? c.entities.find((e) => e.id === i.checkpointId && e.kind === "checkpoint") : void 0;
	i.worldTick === void 0 && l?.data.worldTick != null && (i = {
		...i,
		worldTick: l.data.worldTick
	});
	let u = i.contentVersionId ?? r.projectId, p = o ? r : P(r, u);
	p && (r = p), o || (r = F(r, i.referenceEntities));
	let m = y(r, u, i.referenceEntities, i.externalValues), g = b(i.presentationResults ?? []), x = i.presentationState ? b(i.presentationState) : void 0, w, T, O, A = p && (!r.worldReferences.length || i.referenceEntities) ? void 0 : C("REFERENCE_INVALID", "指定した不変作品版が見つかりません。", "contentVersionId");
	for (let [e, t] of Object.entries(i.externalValues ?? {})) {
		let i = r.entities.find((t) => t.id === e && t.kind === "external_contract" && n(t));
		(!i || i.kind !== "external_contract" || t.type !== i.data.outputType || t.type === "integer" && !Number.isSafeInteger(t.value) || t.type === "enum" && typeof t.value != "string" || t.type === "boolean" && typeof t.value != "boolean") && (A = C("VALIDATION_FAILED", "外部管理値の契約・型・範囲が不正です。", e));
	}
	if (i.worldTick !== void 0 && !t(i.worldTick) && (A = C("VALIDATION_FAILED", "提示時点には整数の世界内tickを入力してください。", "worldTick")), i.checkpointId) {
		let e = k(c, i.checkpointId);
		!e || e.kind !== "checkpoint" || e.deletedAt ? A = C("REFERENCE_INVALID", "指定した途中開始の記録が存在しません。", "checkpointId") : e.data.contentVersionId !== u || e.data.runtimeState.contentVersionId !== u || e.data.contentRevision != null && e.data.contentRevision !== r.revision ? A = C("VALIDATION_FAILED", "開始状態と作品版が違います。移行または再作成が必要です。", `${e.id}.contentVersionId`) : (m = b(e.data.runtimeState), g = b(e.data.presentationResults ?? []), x = e.data.presentationState ? b(e.data.presentationState) : void 0, m.provenance = m.provenance === "stub" ? "stub" : m.provenance === "imported" || e.data.origin === "imported" ? "imported" : m.provenance === "partial" || e.data.origin !== "full_play" ? "partial" : "full_play", w = e.id, e.data.presentationResults != null && (A = d(m, e.data.presentationResults, D(r), `${e.id}.presentationResults`)[0]));
	} else i.state && (i.state.contentVersionId === u ? (m = b(i.state), i.presentationResults != null && (A = d(m, i.presentationResults, D(r))[0]), m.provenance === "full_play" && (m.provenance = "partial")) : A = C("VALIDATION_FAILED", "指定した開始状態と作品版が違います。", "state.contentVersionId"));
	i.seed !== void 0 && (m.rngSeed = i.seed);
	let j = i.entryId ?? m.presentationPosition ?? W(r);
	if (!A) {
		let t = e(m);
		t.ok || (A = t.issues[0]);
		for (let [e, t] of Object.entries(m.variableValues)) {
			let n = M(r).find((t) => t.id === e), i = n ? a(n, t, `${e}.value`) : [C("REFERENCE_INVALID", "開始状態に対象版の宣言がない状態値があります。", e)];
			if (i.length) {
				A = i[0];
				break;
			}
		}
		let n = f(r, {
			referenceEntities: E.get(r),
			nodeId: j ?? void 0,
			worldTick: i.worldTick
		});
		A ||= h({
			state: m,
			variables: M(r),
			entities: D(r),
			externalValues: i.externalValues,
			ruleContext: n,
			ruleContexts: s(r, n)
		})[0];
	}
	if (w && m.provenance === "full_play") {
		let e = j && U(r).includes(j) ? Y(c, {
			contentVersionId: u,
			entryId: j,
			seed: m.rngSeed,
			externalValues: i.externalValues,
			worldTick: i.worldTick,
			referenceEntities: E.get(r)
		}) : void 0;
		(!e || e.status === "error" || !S(e.startState, m)) && (m.provenance = "partial");
	}
	if (i.entryId && !U(r).includes(i.entryId) && !w && (m.provenance = "partial"), !A && !j && (A = C("VALIDATION_FAILED", "開始点が一つに決まりません。入口を指定してください。", "entryId")), !A && !L(r, j ?? null) && (A = C("REFERENCE_INVALID", "指定した開始点が存在しません。", "entryId")), A ||= V(L(r, j ?? null)), !A && j) {
		if ((w || i.state) && m.presentationPosition && j !== m.presentationPosition && m.provenance !== "stub" && (m.provenance = "partial"), !(w || i.state) || j !== m.presentationPosition || (m.visitCounts[j] ?? 0) === 0 && !m.seenIds.includes(j)) {
			let e = G(r, m, j, i.externalValues, i.worldTick);
			if (e.ok) {
				m = e.state, g = e.conditions, x = e.observationState;
				let t = L(r, j);
				if (t?.data.nodeType === "terminal") {
					let e = _(m, [
						...t.data.sceneId ? ["scene_end"] : [],
						...f(r, {
							referenceEntities: E.get(r),
							nodeId: j
						}).chapterId ? ["chapter_end"] : [],
						"run_end"
					], {
						state: m,
						variables: M(r),
						entities: D(r),
						ruleContext: f(r, {
							referenceEntities: E.get(r),
							nodeId: j,
							worldTick: i.worldTick
						}),
						ruleContexts: s(r, f(r, {
							referenceEntities: E.get(r),
							nodeId: j,
							worldTick: i.worldTick
						}))
					});
					e.ok ? m = e.state : T = e.issues;
				}
			} else T = e.issues, O = j, m = {
				...m,
				presentationPosition: j
			};
		} else m.presentationPosition = j;
		i.entryId && !U(r).includes(i.entryId) && !w && (m.provenance = "partial");
	}
	x && (x.provenance = m.provenance);
	let N = {
		content: r,
		referenceEntities: v(E.get(r) ?? []),
		initialWorldTick: i.worldTick,
		declarationProject: b({
			...c,
			history: [],
			snapshots: [],
			authorAlternatives: void 0,
			entities: c.entities.filter((e) => [
				"collection",
				"trace",
				"checkpoint"
			].includes(e.kind))
		}),
		state: m,
		nodeId: m.presentationPosition,
		contentRevision: r.revision,
		startState: b(m),
		startConditionResults: g,
		startPresentationState: x,
		startCheckpointId: w,
		status: "ready",
		history: [],
		trace: [],
		issues: [],
		lastDiff: [],
		externalValues: b(i.externalValues ?? {}),
		startExternalValues: b(i.externalValues ?? {}),
		pendingPresentation: O
	};
	if (A) return B(N, A.code === "CONDITION_UNKNOWN" ? "unknown" : "error", [A]);
	if (i.stub) {
		let e = $(r, N, i.stub), t = e.trace.at(-1)?.presentationState ?? x;
		return {
			...e,
			history: [],
			trace: [],
			startState: b(e.state),
			startStubValues: b(i.stub),
			...i.state || i.checkpointId ? { startStubBaseState: b(N.state) } : {},
			startPresentationState: t ? {
				...b(t),
				provenance: e.state.provenance
			} : void 0,
			startConditionResults: e.trace.at(-1)?.conditionResults.length ? b(e.trace.at(-1).conditionResults) : g,
			startExternalValues: b(e.externalValues)
		};
	}
	return T ? B(N, T.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", T) : q(r, N);
}
function X(e, t) {
	let n = [];
	for (let r of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) {
		let i = e[r], a = t[r];
		if (!S(i, a)) {
			if ((r === "variableValues" || r === "visitCounts") && i && a) {
				let e = i, t = a;
				for (let i of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) S(e[i], t[i]) || n.push({
					path: `${r}.${i}`,
					before: b(e[i]),
					after: b(t[i])
				});
			} else n.push({
				path: r,
				before: b(i),
				after: b(a)
			});
		}
	}
	return n;
}
function te(e, t) {
	if (!Number.isSafeInteger(t) || t <= 0) throw RangeError("抽選候補は1件以上必要です。");
	if (!Number.isSafeInteger(e.rngPosition) || e.rngPosition < 0 || !Number.isSafeInteger(e.rngPosition + 1)) throw RangeError("抽選位置が許容範囲を超えます。");
	let n = 2166136261, r = `${e.rngSeed}\u0000${e.rngPosition}`;
	for (let e = 0; e < r.length; e++) n = Math.imul(n ^ r.charCodeAt(e), 16777619) >>> 0;
	return n ^= n >>> 16, n = Math.imul(n, 2246822507) >>> 0, n ^= n >>> 13, {
		index: (n >>> 0) % t,
		state: {
			...b(e),
			rngPosition: e.rngPosition + 1
		}
	};
}
function Z(e, t, n) {
	let r = e.data.trigger;
	if (!r) return {
		once: void 0,
		occurrence: void 0
	};
	let i = r.id ?? e.id, a = r.scope ?? "run", o = a === "across_runs" ? a : `${a}:${t.loopNumber}`;
	return {
		once: r.repeat === "once" ? `trigger:${o}:${i}` : void 0,
		occurrence: n.event ? `occurrence:${o}:${i}:${n.event.occurrenceId}` : void 0
	};
}
function ne(e, n, i, a) {
	let o = n.data.trigger;
	if (!o) return;
	let s = Z(n, i, a);
	if (s.once && i.onceTriggers.includes(s.once)) return C("TRANSITION_BLOCKED", "この一回限りの発火は実行済みです。", `${n.id}.trigger`);
	if (!a.event || a.event.event !== o.event || a.event.eventKey !== o.eventKey || a.event.triggerId && a.event.triggerId !== (o.id ?? n.id)) return C("TRANSITION_BLOCKED", "宣言したきっかけの入力が必要です。条件の成立だけでは実行しません。", `${n.id}.trigger`);
	if (o.deadline) {
		let i = r(o.deadline, O(e, "event"));
		if (i.status === "conflict") return C("TIME_CONSTRAINT_CONFLICT", i.reason, `${n.id}.trigger.deadline`);
		if (i.status !== "resolved" || !t(a.worldTick) || i.calendarId !== e.calendarId) return C("CONDITION_UNKNOWN", "期限または現在の世界時点を確定できません。", `${n.id}.trigger.deadline`);
		let s = BigInt(a.worldTick), c = BigInt(i.endEarliest), l = BigInt(i.endLatest);
		if (s > l || o.deadline.mode === "interval" && s === l) return C("TRANSITION_BLOCKED", "発火期限を過ぎています。", `${n.id}.trigger.deadline`);
		if (s > c) return C("CONDITION_UNKNOWN", "期限の範囲内に現在時点があり、期限切れか確定できません。", `${n.id}.trigger.deadline`);
	}
}
function re(e, t, n) {
	let r = [];
	n.data.gate && r.push({
		targetId: n.id,
		...z(e, t.state, n.data.gate, t.externalValues)
	});
	for (let i of R(e, n.id)) i.data.condition && r.push({
		targetId: i.id,
		...z(e, t.state, i.data.condition, t.externalValues)
	});
	return r;
}
function ie(e, t, n, r, i, a, o) {
	let c = L(e, t.nodeId), l = L(e, r), u = f(e, {
		referenceEntities: E.get(e),
		nodeId: c?.id
	}), d = f(e, {
		referenceEntities: E.get(e),
		nodeId: r
	}), p = [];
	c?.data.sceneId && c.data.sceneId !== l?.data.sceneId && p.push("scene_end"), u.chapterId && u.chapterId !== d.chapterId && p.push("chapter_end");
	let m = _({
		...n,
		...n.resetCauses ? { resetCauses: [] } : {}
	}, p, {
		state: n,
		variables: M(e),
		entities: D(e),
		externalValues: t.externalValues,
		ruleContext: f(e, {
			referenceEntities: E.get(e),
			nodeId: c?.id,
			worldTick: a.worldTick
		}),
		ruleContexts: s(e, f(e, {
			referenceEntities: E.get(e),
			nodeId: c?.id,
			worldTick: a.worldTick
		}))
	});
	if (!m.ok) return B(t, "error", m.issues);
	let h = G(e, m.state, r, t.externalValues, a.worldTick);
	if (!h.ok) return B(t, h.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", h.issues);
	let g = [];
	l?.data.nodeType === "terminal" && (l.data.sceneId && g.push("scene_end"), d.chapterId && g.push("chapter_end"), g.push("run_end"));
	let v = _(h.state, g, {
		state: h.state,
		variables: M(e),
		entities: D(e),
		externalValues: t.externalValues,
		ruleContext: f(e, {
			referenceEntities: E.get(e),
			nodeId: r,
			worldTick: a.worldTick
		}),
		ruleContexts: s(e, f(e, {
			referenceEntities: E.get(e),
			nodeId: r,
			worldTick: a.worldTick
		}))
	});
	if (!v.ok) return B(t, "error", v.issues);
	let y = v.state;
	l?.data.nodeType === "terminal" && (m.state.resetCauses || v.state.resetCauses) && (y.resetCauses = [...m.state.resetCauses ?? [], ...v.state.resetCauses ?? []]), o = [...o, ...h.conditions];
	let x = X(t.state, y).map((e) => ({
		...e,
		edgeIds: i
	})), S = {
		fromId: t.nodeId,
		toId: r,
		edgeIds: i,
		before: b(t.state),
		after: b(y),
		changes: x,
		request: b(a),
		conditionResults: o,
		presentationState: h.observationState,
		triggerId: L(e, t.nodeId)?.data.trigger?.id ?? (L(e, t.nodeId)?.data.trigger ? t.nodeId : void 0),
		externalValuesBefore: b(t.externalValues),
		externalValuesAfter: b(t.externalValues)
	};
	return q(e, {
		...t,
		state: y,
		nodeId: r,
		status: "ready",
		issues: [],
		lastDiff: x,
		history: [...t.history, {
			state: b(t.state),
			status: t.status,
			issues: b(t.issues),
			lastDiff: b(t.lastDiff),
			traceLength: t.trace.length,
			externalValues: b(t.externalValues),
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, S]
	});
}
function Q(e, t, n = {}) {
	if (t.status === "error" && t.nodeId === null) return t;
	try {
		return ae(e, t, n);
	} catch (e) {
		return B(t, "error", H(e));
	}
}
function ae(e, t, n = {}) {
	if (n.stub) return $(e, t, n.stub);
	let r = P(e, t.state.contentVersionId);
	if (!r) return B(t, "error", [C("REFERENCE_INVALID", "固定した作品版が存在しません。", "contentVersionId")]);
	if (e = r, t.contentRevision !== e.revision) return B(t, "error", [C("VALIDATION_FAILED", "作品が変更されました。この記録は再確認待ちです。試読を開始し直してください。", "contentRevision")]);
	if (e = t.content, t.pendingPresentation) return B(t, "unknown", t.issues.length ? t.issues : [C("CONDITION_UNKNOWN", "場面の提示条件を先に確認してください。", t.pendingPresentation)]);
	if (t.state.contentVersionId !== t.startState.contentVersionId) return B(t, "error", [C("VALIDATION_FAILED", "試読中に作品版が変わりました。", "contentVersionId")]);
	let i = n.event?.triggerId ?? L(e, t.nodeId)?.data.trigger?.id ?? (L(e, t.nodeId)?.data.trigger ? t.nodeId : void 0);
	if (n.event && i && t.trace.some((e) => e.triggerId === i && e.request.event?.occurrenceId === n.event?.occurrenceId)) return t;
	let a = L(e, t.nodeId);
	if (a && n.event) {
		let e = Z(a, t.state, n).occurrence;
		if (e && t.state.onceTriggers.includes(e)) return t;
	}
	let o = q(e, t);
	if (o.status !== "ready") return o;
	let c = L(e, t.nodeId), l = ne(e, c, t.state, n);
	if (l) return B(t, l.code === "CONDITION_UNKNOWN" ? "unknown" : l.code === "TIME_CONSTRAINT_CONFLICT" ? "error" : "blocked", [l]);
	let u = z(e, t.state, c.data.gate, t.externalValues), d = re(e, t, c), m = b(t.state), h = [], g;
	if (u.value === "false") g = c.data.fallbackId ?? void 0;
	else if (c.data.nodeType === "exit" && m.callStack.length > 0) {
		let n = k(e, m.callStack.at(-1).graphId);
		if (!n || n.kind !== "flow_graph" || !n.data.exitIds.includes(c.id)) return B(t, "error", [C("REFERENCE_INVALID", "現在の出口が呼出中グラフの宣言した出口に含まれていません。", c.id)]);
		g = m.callStack.pop().returnNodeId;
	} else if (c.data.nodeType === "call") {
		let n = c.data.childGraphId ? k(e, c.data.childGraphId) : void 0;
		if (!n || n.kind !== "flow_graph" || n.data.entryIds.length !== 1) return B(t, "error", [C("REFERENCE_INVALID", "呼出先に一つの入口を持つ子グラフが必要です。", `${c.id}.childGraphId`)]);
		let r = R(e, c.id).filter((e) => e.data.edgeType === "call_return");
		if (r.length !== 1 || typeof r[0].data.toId != "string") return B(t, "error", [C("REFERENCE_INVALID", "呼出には一つの確定した戻り先が必要です。", c.id)]);
		let i = z(e, t.state, r[0].data.condition, t.externalValues);
		if (i.value === "unknown") return B(t, "unknown", [C("CONDITION_UNKNOWN", i.reasons.join("、") || "呼出の戻り先条件が未確認です。", r[0].id)]);
		if (i.value === "false") {
			if (!c.data.fallbackId) return B(t, "blocked", [C("TRANSITION_BLOCKED", "呼出の戻り先条件を満たしていません。", r[0].id)]);
			g = c.data.fallbackId;
		} else {
			h = r, g = n.data.entryIds[0];
			let e = {};
			for (let t of n.data.parameters ?? []) e[t.key] = b(t.default ?? {
				type: "unknown",
				value: null,
				reason: "呼出引数が未設定です。"
			});
			m.callStack.push({
				graphId: n.id,
				returnNodeId: r[0].data.toId,
				parameters: e
			});
		}
	} else {
		let r = c.data.executionPolicy ?? (c.data.nodeType === "automatic" ? "first_match" : "manual_choice"), i = ee(e, t), a = i.filter((e) => e.result === "true");
		if (a.length === 0) g = c.data.fallbackId ?? void 0;
		else if (r === "manual_choice") {
			let r;
			if (n.random) {
				if (i.some((e) => e.result === "unknown")) return B(t, "unknown", [C("CONDITION_UNKNOWN", "未確認の抽選候補が残っています。", c.id)]);
				let e;
				try {
					e = te(m, a.length);
				} catch {
					return B(t, "error", [C("TRANSITION_BLOCKED", "抽選位置が許容範囲を超えます。", "rngPosition")]);
				}
				m = e.state, r = a[e.index];
			} else r = i.find((e) => e.edgeId === n.edgeId);
			if (!r) return B(t, "blocked", [C("TRANSITION_BLOCKED", "進む選択肢を指定してください。", c.id)]);
			if (r.result !== "true") return B(t, r.result === "unknown" ? "unknown" : "blocked", [C(r.result === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED", r.reasons.join("、") || "この選択肢の条件は成立していません。", r.edgeId)]);
			h = R(e, c.id).filter((e) => e.id === r.edgeId);
		} else h = (r === "first_match" ? a.slice(0, 1) : a).map((e) => e.edgeId).map((t) => R(e, c.id).find((e) => e.id === t));
		if (h.length > 0) {
			if (new Set(h.map((e) => typeof e.data.toId == "string" ? e.data.toId : null)).size !== 1) return B(t, "error", [C("VALIDATION_FAILED", "all_matchの進行先が異なります。同じ進行先を指定してください。", c.id)]);
			let e = h[0].data.toId;
			typeof e == "string" && (g = e);
		}
	}
	if (!g || !L(e, g)) return B(t, "error", [C("REFERENCE_INVALID", "進行先が未完成、または存在しません。", c.id)]);
	let _ = V(L(e, g));
	if (_) return B(t, "error", [_]);
	let v = [];
	for (let n of h) for (let r of n.data.effectIds ?? []) {
		let i = k(e, r);
		if (!i || i.kind !== "effect" || i.deletedAt || i.status === "rejected") return B(t, "error", [C("REFERENCE_INVALID", i?.status === "rejected" ? "分岐に不採用の効果が指定されています。" : "分岐に指定した効果が存在しないか、削除済みです。", `${n.id}.effectIds`)]);
		v.push(i);
	}
	let y = p(m, v, {
		state: m,
		variables: M(e),
		entities: D(e),
		externalValues: t.externalValues,
		ruleContext: f(e, {
			referenceEntities: E.get(e),
			nodeId: c.id,
			worldTick: n.worldTick
		}),
		ruleContexts: s(e, f(e, {
			referenceEntities: E.get(e),
			nodeId: c.id,
			worldTick: n.worldTick
		}))
	});
	if (!y.ok) return B(t, y.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", y.issues);
	m = y.state;
	let x = Z(c, t.state, n);
	return m.onceTriggers = [.../* @__PURE__ */ new Set([...m.onceTriggers, ...[x.once, x.occurrence].filter((e) => e !== void 0)])], ie(e, o, m, g, h.map((e) => e.id), n, d);
}
function $(e, t, n) {
	try {
		return oe(e, t, n);
	} catch (e) {
		return B(t, "error", H(e));
	}
}
function oe(e, t, n) {
	let r = P(e, t.state.contentVersionId);
	if (!r || r.revision !== t.contentRevision) return B(t, "error", [C("VALIDATION_FAILED", "作品版が変わりました。仮値を適用する前に開始し直してください。", "contentRevision")]);
	e = t.content;
	let i = b(t.externalValues);
	for (let [r, a] of Object.entries(n.external ?? {})) {
		let n = k(e, r);
		if (!n || n.kind !== "external_contract") return B(t, "error", [C("REFERENCE_INVALID", "仮の外部値には宣言した外部契約が必要です。", r)]);
		if (n.data.outputType !== a.type && a.type !== "unknown") return B(t, "error", [C("VALIDATION_FAILED", "仮の外部値と宣言した出力型が違います。", r)]);
		i[r] = b(a);
	}
	let a = Object.entries(n.variables ?? {}).map(([e, t]) => ({
		operation: "set",
		targetId: e,
		value: t
	})), o = p(t.state, a, {
		state: t.state,
		variables: M(e),
		entities: D(e),
		externalValues: i
	});
	if (!o.ok) return B(t, o.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", o.issues);
	let s = {
		...o.state,
		provenance: "stub"
	}, c = t.pendingPresentation, l = [], u;
	if (c) {
		let n = G(e, s, c, i, t.initialWorldTick);
		if (!n.ok) return B(t, n.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", n.issues);
		s = {
			...n.state,
			provenance: "stub"
		}, l = n.conditions, u = n.observationState, c = void 0;
	}
	let d = X(t.state, s);
	for (let e of /* @__PURE__ */ new Set([...Object.keys(t.externalValues), ...Object.keys(i)])) S(t.externalValues[e], i[e]) || d.push({
		path: `externalValues.${e}`,
		before: b(t.externalValues[e]),
		after: b(i[e])
	});
	let f = {
		...t,
		state: s,
		externalValues: i,
		issues: [],
		lastDiff: d,
		pendingPresentation: c,
		history: [...t.history, {
			state: b(t.state),
			externalValues: b(t.externalValues),
			status: t.status,
			issues: b(t.issues),
			lastDiff: b(t.lastDiff),
			traceLength: t.trace.length,
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, {
			fromId: t.nodeId,
			toId: t.nodeId,
			edgeIds: [],
			before: b(t.state),
			after: b(s),
			conditionResults: l,
			...u ? { presentationState: u } : {},
			changes: d,
			request: { stub: b(n) },
			externalValuesBefore: b(t.externalValues),
			externalValuesAfter: b(i)
		}]
	};
	return q(e, f);
}
function se(e, t, n) {
	let r = k(e, t);
	if (!r || r.kind !== "trace") return B(J(e), "error", [C("REFERENCE_INVALID", "保存した経路記録が存在しません。", t)]);
	let i = J(e, {
		checkpointId: r.data.startCheckpointId,
		contentVersionId: r.data.contentVersionId,
		referenceEntities: n,
		worldTick: r.data.initialWorldTick ?? void 0
	}), a = I(e, i);
	if (r.data.contentRevision != null && r.data.contentRevision !== a.revision) return B(i, "error", [C("VALIDATION_FAILED", "経路記録の作品版が変更されました。再確認が必要です。", `${t}.contentRevision`)]);
	if (i.status === "error") return i;
	let o = e.entities.find((e) => e.id === r.data.startCheckpointId && e.kind === "checkpoint");
	if (r.data.initialWorldTick != null && o?.data.worldTick != null && r.data.initialWorldTick !== o.data.worldTick) return B(i, "error", [C("INTEGRITY_FAILED", "保存した開始時点と経路の初期提示時点が一致しません。", `${t}.initialWorldTick`)]);
	if (r.data.initialStubValues) {
		let a = J(e, {
			...r.data.initialStubBaseState ? { state: b(r.data.initialStubBaseState) } : {},
			entryId: i.startState.presentationPosition ?? void 0,
			contentVersionId: r.data.contentVersionId,
			referenceEntities: n,
			seed: i.startState.rngSeed,
			worldTick: r.data.initialWorldTick ?? o?.data.worldTick ?? void 0,
			stub: b(r.data.initialStubValues)
		});
		if (a.status === "error" || !S(a.startState, i.startState) || !S(a.startExternalValues, r.data.initialExternalValues ?? {})) return B(i, "error", [C("INTEGRITY_FAILED", "保存した初期stub入力と固定版の開始状態が一致しません。", `${t}.initialStubValues`)]);
	}
	i.externalValues = b(r.data.initialExternalValues ?? {}), i.startExternalValues = b(i.externalValues), i.startStubValues = r.data.initialStubValues ? b(r.data.initialStubValues) : void 0, i.startStubBaseState = r.data.initialStubBaseState ? b(r.data.initialStubBaseState) : void 0;
	for (let [n, o] of r.data.steps.entries()) {
		if (!S(i.state, o.before)) return B(i, "error", [C("VALIDATION_FAILED", "保存した開始状態と経路の直前状態が一致しません。", `${t}.steps[${n}].before`)]);
		let r = {};
		if (o.operation === "stub" || o.operation === void 0 && o.edgeIds.length === 0 && o.before.presentationPosition === o.after.presentationPosition && S(o.before.visitCounts, o.after.visitCounts) && o.after.provenance === "stub") {
			let e = {};
			for (let t of M(a)) !t.data.derived && !S(o.before.variableValues[t.id], o.after.variableValues[t.id]) && (e[t.id] = b(o.after.variableValues[t.id]));
			r = { stub: {
				variables: e,
				external: o.externalValues ?? i.externalValues
			} };
		} else {
			i.externalValues = b(o.externalValues ?? i.externalValues);
			let e = L(a, i.nodeId);
			r.edgeId = o.edgeIds[0], o.after.rngPosition === o.before.rngPosition + 1 && (r.random = !0), e?.data.trigger && (r.event = {
				triggerId: e.data.trigger.id ?? e.id,
				event: e.data.trigger.event,
				eventKey: e.data.trigger.eventKey,
				occurrenceId: o.occurrenceId ?? `replay:${n}`
			}), r.worldTick = o.worldTick;
		}
		if (i = Q(e, i, r), i.status === "error") return i;
		if (o.conditionResults && !S(i.trace.at(-1)?.conditionResults, o.conditionResults)) return B(i, "error", [C("VALIDATION_FAILED", "保存した提示時の条件結果と再実行が一致しません。", `${t}.steps[${n}].conditionResults`)]);
		if (o.presentationState && !S(o.presentationState, i.trace.at(-1)?.presentationState)) return B(i, "error", [C("INTEGRITY_FAILED", "保存した提示前の観測状態と再実行が一致しません。", `${t}.steps[${n}].presentationState`)]);
		if (!S(i.state, o.after)) return B(i, "error", [C("VALIDATION_FAILED", "保存した経路と再実行の状態が一致しません。", `${t}.steps[${n}].after`)]);
	}
	return i;
}
//#endregion
export { se as replaySavedTrace, J as startTrial, Q as stepTrial };
