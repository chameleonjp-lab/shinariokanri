import { B as e, C as t, D as n, E as r, F as i, G as a, H as o, K as s, L as c, O as l, P as u, T as d, V as f, W as p, d as m, et as h, it as g, x as _, z as v } from "./model-CpGFZXoy.js";
//#region src/domain/stateRules.ts
function y(e, t) {
	let n = t.ruleContext;
	if (!n) return {
		value: "unknown",
		reasons: ["対象作品・章・経路の実行情報がありません。"]
	};
	if (e.projectId !== n.projectId || e.targetSnapshotId && ![
		n.projectId,
		t.state.contentVersionId,
		n.sourceVersionId
	].includes(e.targetSnapshotId)) return {
		value: "false",
		reasons: ["対象作品版の範囲外です。"]
	};
	if (e.graphId && n.graphId && e.graphId !== n.graphId || e.chapterId && n.chapterId && e.chapterId !== n.chapterId) return {
		value: "false",
		reasons: ["対象グラフまたは章の範囲外です。"]
	};
	let r = j(e.routeCondition, t);
	return r.value === "false" ? r : e.graphId && !n.graphId || e.chapterId && !n.chapterId ? {
		value: "unknown",
		reasons: ["対象グラフまたは章を確認できません。", ...r.reasons]
	} : r;
}
function b(e, t) {
	let n = (e, t) => ({
		value: e,
		reasons: [t]
	});
	if (!e.reason.trim() || !e.evidenceIds.length) return n("false", "例外には理由と根拠が必要です。");
	let r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (e.evidenceIds.some((e) => !r.some((t) => t.id === e && !t.deletedAt && t.status === "confirmed"))) return n("unknown", "例外の根拠が存在しないか、採用確定していません。");
	let a = y(e.targetScope, t);
	if (a.value !== "true") return a;
	let o = e.validity.worldRange, s = t.ruleContext?.worldTick;
	if (!o || o.end === null) return n("unknown", "例外の有効期限を指定してください。");
	if (!i(s)) return n("unknown", "例外の期限を評価する現在の世界時点がありません。");
	if (o.start !== null && u(s, o.start) < 0 || u(s, o.end) >= 0) return n("false", "例外の有効期間外です。");
	let c = j(e.validity.routeCondition, t);
	if (c.value !== "true") return c;
	let l = e.validity.presentationAnchor, d = t.ruleContext?.anchorBindings, f = l && d && l.sourceVersionId === t.ruleContext?.sourceVersionId ? {
		...l,
		entityId: d[l.entityId] ?? l.entityId,
		...l.blockId ? { blockId: d[l.blockId] ?? l.blockId } : {},
		...l.lineId ? { lineId: d[l.lineId] ?? l.lineId } : {}
	} : l;
	return f && (f.positionStatus === "unresolved" || f.sourceVersionId && ![
		t.ruleContext.projectId,
		t.state.contentVersionId,
		t.ruleContext.sourceVersionId
	].includes(f.sourceVersionId)) ? n("unknown", "例外の提示位置または版を確認できません。") : f && ![
		f.entityId,
		f.blockId,
		f.lineId
	].filter(Boolean).every((e) => t.state.seenIds.includes(e)) ? n("false", "例外の提示位置に到達していません。") : {
		value: "true",
		reasons: []
	};
}
function x(e, t) {
	if (!e.data.holderId) return;
	if (typeof e.data.value != "string" && e.data.value.type === "unknown") return {
		code: "CONDITION_UNKNOWN",
		message: "人物が取得する認識の内容が未確定です。"
	};
	let n = e.data.sourceIds ?? [], r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (!n.length || n.some((e) => !r.some((t) => t.id === e && o(t)))) return {
		code: "REFERENCE_INVALID",
		message: "人物の認識取得には採用中の出所が必要です。"
	};
	let a = e.data.validity, s = e.data.evidenceLocation ?? a?.presentationAnchor, c = t.ruleContexts?.[e.id] ?? t.ruleContext, l = c?.anchorBindings, d = s && l && s.sourceVersionId === c?.sourceVersionId ? {
		...s,
		entityId: l[s.entityId] ?? s.entityId,
		...s.blockId ? { blockId: l[s.blockId] ?? s.blockId } : {},
		...s.lineId ? { lineId: l[s.lineId] ?? s.lineId } : {}
	} : s, f = a?.worldRange;
	if (!d && (!f || f.start === null)) return {
		code: "CONDITION_UNKNOWN",
		message: "人物の認識取得には本文位置または世界内の取得時点が必要です。"
	};
	if (d) {
		if (d.positionStatus === "unresolved" || d.sourceVersionId && ![
			c?.projectId,
			c?.sourceVersionId,
			t.state.contentVersionId
		].includes(d.sourceVersionId)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置または固定版が未確認です。"
		};
		if (![
			d.entityId,
			d.blockId,
			d.lineId
		].filter(Boolean).every((e) => t.state.seenIds.includes(e))) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置へ到達していません。"
		};
		let e = t.currentPresentation;
		if (e) {
			let t = d.entityId === e.anchor.entityId && d.blockId === e.anchor.blockId && d.lineId === e.anchor.lineId && d.start === e.anchor.start, n = Q(e.project, d, e.anchor, e.target);
			if (!t && n !== !0) return {
				code: n === !1 ? "TRANSITION_BLOCKED" : "CONDITION_UNKNOWN",
				message: "認識取得の位置が、この効果の提示位置より後か、順序を確認できません。"
			};
		}
	}
	if (f) {
		if (!i(c?.worldTick)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識の取得時点を照合する世界内tickが未入力です。"
		};
		if (f.start !== null && u(c.worldTick, f.start) < 0 || f.end !== null && u(c.worldTick, f.end) >= 0) return {
			code: "TRANSITION_BLOCKED",
			message: "認識の取得時点が宣言した有効期間外です。"
		};
	}
	let p = j(a?.routeCondition, {
		...t,
		ruleContext: c
	});
	if (p.value !== "true") return {
		code: p.value === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED",
		message: "認識を取得する経路条件が成立していません。"
	};
}
//#endregion
//#region src/domain/conditions.ts
var S = class extends Error {
	issues;
	constructor(e) {
		super(e.map((e) => e.message).join("、")), this.name = "DomainValidationError", this.issues = e;
	}
}, C = (e, t = "condition", n = "VALIDATION_FAILED") => ({
	code: n,
	path: t,
	message: e
}), w = (e) => ({
	type: "unknown",
	value: null,
	reason: e
}), T = (e, t = []) => ({
	value: e,
	reasons: [...new Set(t)]
}), E = (e) => [...e.entities ?? [], ...e.referenceEntities ?? []].filter(o), D = (e) => (e.variables ?? [...e.entities ?? [], ...e.referenceEntities ?? []].filter((e) => e.kind === "variable")).filter(o);
function O(e, t, r) {
	let i = D(t).find((t) => t.id === e);
	if (!i) {
		if (t.variables || t.entities) return w("状態変数が定義されていません。");
		let r = t.state.variableValues[e];
		if (!r) return w("状態変数の値がありません。");
		let i = n(r);
		if (!i.ok) throw new S(i.issues);
		return r;
	}
	if (i.data.derived) {
		if (r.includes(e)) throw new S([C("算出状態の参照が循環しています。", `variables.${e}.derived`)]);
		let n = M(i.data.derived, t, [...r, e]), a = l(i, n, `variables.${e}.derived`);
		if (a.length) throw new S(a);
		return n;
	}
	if (i.data.externalContractId) {
		let e = t.externalValues?.[i.data.externalContractId];
		if (!e) return w("宣言した外部値をまだ取得していません。");
		let r = n(e);
		if (!r.ok) throw new S(r.issues);
		let a = l(i, e);
		if (a.length) throw new S(a);
		return e;
	}
	let a = t.state.variableValues[e];
	if (!a) return w("状態変数の値がありません。");
	let o = n(a);
	if (!o.ok) throw new S(o.issues);
	let s = l(i, a);
	if (s.length) throw new S(s);
	return a;
}
function k(e, t, n) {
	if (e.type === "unknown" || t.type === "unknown") return T("unknown", [e.type === "unknown" ? e.reason : "", t.type === "unknown" ? t.reason : ""].filter(Boolean));
	if (e.type !== t.type) throw new S([C("比較する値の型が一致しません。")]);
	if (![
		"eq",
		"ne",
		"lt",
		"le",
		"gt",
		"ge"
	].includes(n)) throw new S([C("未知の比較演算です。")]);
	if (n === "eq" || n === "ne") return T((n === "eq" ? e.value === t.value : e.value !== t.value) ? "true" : "false");
	if (e.type !== "integer" || t.type !== "integer") throw new S([C("順序比較はintegerにだけ使えます。")]);
	return T((n === "lt" ? e.value < t.value : n === "le" ? e.value <= t.value : n === "gt" ? e.value > t.value : e.value >= t.value) ? "true" : "false");
}
function A(e, t, r) {
	switch (e.op) {
		case "constant": return T(e.value ? "true" : "false");
		case "all":
		case "any": {
			let n = e.children.map((e) => A(e, t, r)), i = n.flatMap((e) => e.reasons);
			return e.op === "all" ? T(n.some((e) => e.value === "false") ? "false" : n.every((e) => e.value === "true") ? "true" : "unknown", i) : T(n.some((e) => e.value === "true") ? "true" : n.every((e) => e.value === "false") ? "false" : "unknown", i);
		}
		case "not": {
			let n = A(e.child, t, r);
			return T(n.value === "unknown" ? "unknown" : n.value === "true" ? "false" : "true", n.reasons);
		}
		case "compare": {
			let n = O(e.variableId, t, r);
			if (e.comparator !== "in") return k(n, e.value, e.comparator);
			let i = e.value.map((e) => k(n, e, "eq"));
			return T(i.some((e) => e.value === "true") ? "true" : i.some((e) => e.value === "unknown") ? "unknown" : "false", i.flatMap((e) => e.reasons));
		}
		case "item": return t.entities && !E(t).some((t) => t.id === e.itemId && t.kind === "item") ? T("unknown", ["指定した物品が定義されていません。"]) : T(t.state.itemInstances.filter((t) => !t.consumed && (t.instanceId === e.itemId || t.typeId === e.itemId)).reduce((e, t) => e + t.quantity, 0) >= e.quantity ? "true" : "false");
		case "known": {
			if (t.entities && (!E(t).some((t) => t.id === e.assertionId && t.kind === "assertion") || !E(t).some((t) => t.id === e.holderId && t.kind === "character"))) return T("unknown", ["認識の対象または人物が定義されていません。"]);
			let n = t.state.assertions.find((t) => t.assertionId === e.assertionId && t.holderId === e.holderId);
			return n ? T(n.truth, n.truth === "unknown" ? ["人物の認識が未確定です。"] : []) : T("false");
		}
		case "visited": return t.entities && !E(t).some((t) => t.id === e.entityId) ? T("unknown", ["訪問先が定義されていません。"]) : T((t.state.visitCounts[e.entityId] ?? 0) >= e.count ? "true" : "false");
		case "external": {
			if (t.entities && !E(t).some((t) => t.id === e.contractId && t.kind === "external_contract")) return T("unknown", ["外部契約が定義されていません。"]);
			let r = t.externalValues?.[e.contractId];
			if (!r) return T("unknown", ["外部値をまだ取得していません。"]);
			let i = n(r);
			if (!i.ok) throw new S(i.issues);
			if (r.type === "unknown") return T("unknown", [r.reason]);
			if (r.type !== "boolean") throw new S([C("外部条件はbooleanの結果が必要です。")]);
			return T(r.value ? "true" : "false");
		}
	}
}
function j(e, t) {
	let n = _(e ?? {
		op: "constant",
		value: !0
	});
	if (!n.ok) throw new S(n.issues);
	return A(n.value, t, []);
}
function M(e, t, n) {
	switch (e.op) {
		case "value": return e.value;
		case "variable": return O(e.variableId, t, n);
		case "if": {
			let r = A(e.condition, t, n);
			return r.value === "unknown" ? w(r.reasons.join("、") || "分岐条件が未定です。") : M(r.value === "true" ? e.then : e.else, t, n);
		}
		case "add":
		case "subtract":
		case "multiply": {
			let r = M(e.left, t, n), i = M(e.right, t, n);
			if (r.type === "unknown" || i.type === "unknown") return w([r.type === "unknown" ? r.reason : "", i.type === "unknown" ? i.reason : ""].filter(Boolean).join("、"));
			if (r.type !== "integer" || i.type !== "integer") throw new S([C("算術の入力はintegerです。", "expression")]);
			let a = e.op === "add" ? r.value + i.value : e.op === "subtract" ? r.value - i.value : r.value * i.value;
			if (!Number.isSafeInteger(a)) throw new S([C("算術結果が安全な整数の範囲を超えています。", "expression")]);
			return {
				type: "integer",
				value: a
			};
		}
		default: {
			let r = A(e, t, n);
			return r.value === "unknown" ? w(r.reasons.join("、")) : {
				type: "boolean",
				value: r.value === "true"
			};
		}
	}
}
function ee(e, t = e.projectId, n = [], r = {}) {
	let i = m(t), a = [...e.entities, ...n].filter((e) => e.kind === "variable" && o(e));
	for (let e of a) i.variableValues[e.id] = structuredClone(e.data.initial);
	for (let t of a) (t.data.derived || t.data.externalContractId && r[t.data.externalContractId]) && (i.variableValues[t.id] = O(t.id, {
		state: i,
		variables: a,
		entities: e.entities,
		referenceEntities: n,
		externalValues: r
	}, []));
	return i;
}
function N(e) {
	let t = [];
	for (let n of D(e)) for (let [r, i] of (n.data.exclusions ?? []).entries()) {
		let a = j({
			op: "all",
			children: [{
				op: "compare",
				variableId: n.id,
				comparator: "eq",
				value: i.value
			}, {
				op: "compare",
				variableId: i.variableId,
				comparator: "eq",
				value: i.otherValue
			}]
		}, e);
		if (a.value === "false") continue;
		let o = (i.exceptions ?? []).map((t) => b(t, {
			...e,
			ruleContext: e.ruleContexts?.[n.id] ?? e.ruleContext
		}));
		if (a.value === "true" && o.some((e) => e.value === "true")) continue;
		let s = a.value === "unknown" || o.some((e) => e.value === "unknown");
		t.push(C(s ? `相互排他を評価できません。${i.reason}` : `相互排他に反する状態です。${i.reason}`, `${n.id}.exclusions[${r}]`, s ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED"));
	}
	return t;
}
function P(e, t) {
	return e.type === t.type && e.value === t.value;
}
function te(e, t, n, r, i) {
	if (r.operation === "reset" || P(t, n)) return;
	let a = E(i).filter((t) => t.kind === "quest" && t.data.stateVariableId === e.id), o = [...(e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})), ...a.flatMap((e) => (e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})))];
	if (!o.length && !a.length) return;
	if (t.type === "unknown") throw new S([C("遷移前の状態が未定です。", `variables.${e.id}`, "CONDITION_UNKNOWN")]);
	let s = o.filter(({ rule: e }) => P(e.from, t) && P(e.to, n));
	if (s.some(({ rule: e }) => !e.exception && !e.exceptionDetails)) return;
	let c = [...s.flatMap(({ rule: e, ownerId: t }) => e.exceptionDetails ? [b(e.exceptionDetails, {
		...i,
		ruleContext: i.ruleContexts?.[t] ?? i.ruleContext
	})] : []), ...r.exceptionDetails ? [b(r.exceptionDetails, i)] : []];
	if (!c.some((e) => e.value === "true")) throw new S([C(c.flatMap((e) => e.reasons).join("、") || "許容遷移表にない状態更新です。明示resetまたは対象・期限・根拠付きの例外が必要です。", `variables.${e.id}`, c.some((e) => e.value === "unknown") ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED")]);
}
function ne(e, t, n) {
	return e.itemInstances.filter((e) => n ? e.instanceId === n : e.instanceId === t || e.typeId === t);
}
function re(e, t, n, r) {
	let i = D(n), a = [...n.entities ?? [], ...n.referenceEntities ?? []].find((e) => e.id === t.targetId && o(e)), s = (e, n = "TRANSITION_BLOCKED") => {
		throw new S([C(e, `effects.${r ?? t.targetId}`, n)]);
	};
	if ([
		"set",
		"add",
		"reset"
	].includes(t.operation)) {
		let a = i.find((e) => e.id === t.targetId);
		a || s("更新先の状態変数がありません。", "REFERENCE_INVALID"), a.data.derived && s("算出状態へ直接代入できません。", "VALIDATION_FAILED");
		let o = O(a.id, {
			...n,
			state: e
		}, []), c = t.operation === "reset" ? structuredClone(t.value ?? a.data.initial) : t.value;
		c || s("状態更新の入力値がありません。", "VALIDATION_FAILED"), t.operation === "add" && (o.type === "unknown" && s(o.reason || "加算元の状態が未定です。", "CONDITION_UNKNOWN"), (o.type !== "integer" || c.type !== "integer" || a.data.valueType !== "integer") && s("addはinteger状態とinteger入力だけを使えます。", "VALIDATION_FAILED"), c = {
			type: "integer",
			value: o.value + c.value
		});
		let u = l(a, c, `effects.${r ?? t.targetId}.value`, t.operation === "reset");
		if (u.length) throw new S(u.map((e) => ({
			...e,
			code: e.code === "CONDITION_UNKNOWN" ? e.code : "TRANSITION_BLOCKED"
		})));
		te(a, o, c, t, n), e.variableValues[a.id] = structuredClone(c);
		return;
	}
	if (t.operation === "mark_seen") {
		n.entities && !a && s("既読対象が定義されていません。", "REFERENCE_INVALID"), e.seenIds.includes(t.targetId) || e.seenIds.push(t.targetId);
		return;
	}
	if (t.operation === "assert") {
		(!a || a.kind !== "assertion") && s("認識効果の対象には事実・認識が必要です。", "REFERENCE_INVALID"), t.value && t.value.type !== "boolean" && s("認識効果の入力はbooleanです。", "VALIDATION_FAILED");
		let i = t.value?.type === "boolean" && !t.value.value ? "false" : "true", o = a.data.holderId ?? null;
		if (i === "true") {
			let e = x(a, n);
			e && s(e.message, e.code);
		}
		let c = e.assertions.find((e) => e.assertionId === a.id && e.holderId === o);
		c ? (c.truth = i, r && (c.sourceEffectId = r)) : e.assertions.push({
			assertionId: a.id,
			holderId: o,
			truth: i,
			...r ? { sourceEffectId: r } : {}
		});
		return;
	}
	if ((!a || a.kind !== "item") && s("物品効果の対象には宣言済みの物品が必要です。", "REFERENCE_INVALID"), t.instanceId) {
		let e = E(n).find((e) => e.id === t.instanceId);
		(!e || e.kind !== "item" || e.data.itemMode !== "instance") && s("指定した物品個体が定義されていません。", "REFERENCE_INVALID"), (a.data.itemMode === "type" && e.data.typeId !== a.id || a.data.itemMode === "instance" && e.id !== a.id) && s("指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
	}
	let c = t.value?.type === "integer" ? t.value.value : 1;
	if (t.operation === "grant") {
		t.value && t.value.type !== "integer" && s("取得数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(c) || c < 1) && s("取得数量は正の安全な整数です。", "VALIDATION_FAILED");
		let r = a.data.itemMode === "instance" ? a : t.instanceId ? E(n).find((e) => e.id === t.instanceId && e.kind === "item" && e.data.itemMode === "instance") : void 0;
		if (t.instanceId && !r && s("指定した物品個体がありません。", "REFERENCE_INVALID"), r) {
			c !== 1 && s("物品個体の数量は1です。"), a.data.itemMode === "type" && r.data.typeId !== a.id && s("個体が指定した物品種類に属していません。", "REFERENCE_INVALID"), e.itemInstances.some((e) => e.instanceId === r.id) && s("同じ物品個体を二重取得・復活させられません。");
			let t = r.data.typeId;
			t || s("物品個体の種類が未定義です。", "REFERENCE_INVALID"), e.itemInstances.push({
				instanceId: r.id,
				typeId: t,
				quantity: 1,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		} else {
			let t = e.itemInstances.find((e) => e.instanceId === a.id && e.typeId === a.id);
			t ? (Number.isSafeInteger(t.quantity + c) || s("物品数量が安全な整数範囲を超えています。"), t.quantity += c, t.consumed = !1) : e.itemInstances.push({
				instanceId: a.id,
				typeId: a.id,
				quantity: c,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		}
		return;
	}
	let u = ne(e, t.targetId, t.instanceId).filter((e) => !e.consumed && e.quantity > 0);
	if (u.some((e) => a.data.itemMode === "type" ? e.typeId !== a.id : e.instanceId !== a.id || e.typeId !== a.data.typeId) && s("実行状態の個体と効果の対象物品が一致しません。", "REFERENCE_INVALID"), t.operation === "consume") {
		t.reason?.trim() || s("消費・破壊の理由を記録してください。", "VALIDATION_FAILED"), t.value && t.value.type !== "integer" && s("消費数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(c) || c < 1 || u.reduce((e, t) => e + t.quantity, 0) < c) && s("物品が不足しています。");
		let e = c;
		for (let n of u) {
			let r = Math.min(n.quantity, e);
			if (n.quantity -= r, e -= r, n.reason = t.reason, n.consumed = n.quantity === 0, e === 0) break;
		}
		return;
	}
	if (t.operation === "move") {
		t.value?.type !== "ref" && s("移動先には人物・グループ・場所のrefが必要です。", "VALIDATION_FAILED");
		let e = E(n).find((e) => e.id === t.value?.value);
		(!e || ![
			"character",
			"group",
			"place"
		].includes(e.kind)) && s("物品の移動先がありません。", "REFERENCE_INVALID"), u.length !== 1 && s("移動する現存物品を一個体に特定してください。");
		let r = u[0];
		r.ownerId = e.kind === "place" ? null : e.id, r.locationId = e.kind === "place" ? e.id : null;
		return;
	}
	s("未対応の物品操作です。", "VALIDATION_FAILED");
}
function F(e, n, i = { state: e }) {
	let a = r(e);
	if (!a.ok) return {
		ok: !1,
		state: e,
		issues: a.issues
	};
	let s = structuredClone(e);
	try {
		for (let [e, r] of n.entries()) {
			if ("data" in r && !o(r)) throw new S([C("削除・不採用・別案の効果は実行できません。", `effects[${e}]`, "REFERENCE_INVALID")]);
			let n = "data" in r ? r.data : r, i = t(n, `effects[${e}]`);
			if (!i.ok) throw new S(i.issues);
		}
		for (let [e, t] of n.entries()) {
			let n = "data" in t ? t.data : t, r = "id" in t ? t.id : void 0, a = {
				...i,
				currentPresentation: i.effectPresentations?.[e] ?? i.currentPresentation,
				state: s,
				ruleContext: r && i.ruleContexts?.[r] || i.ruleContext
			}, o = j(n.condition, a);
			if (o.value === "unknown") throw new S([C(o.reasons.join("、") || "効果の条件が未定です。", `effects[${e}].condition`, "CONDITION_UNKNOWN")]);
			o.value !== "false" && re(s, n, a, r);
		}
		let e = /* @__PURE__ */ new Set();
		for (let t of s.itemInstances) {
			if (e.has(t.instanceId) || t.ownerId && t.locationId || t.consumed && t.quantity !== 0 || !t.consumed && t.quantity < 1) throw new S([C("物品の個体ID・所在・数量が不整合です。", "itemInstances", "TRANSITION_BLOCKED")]);
			e.add(t.instanceId);
		}
		for (let e of D(i)) e.data.derived && (s.variableValues[e.id] = O(e.id, {
			...i,
			state: s
		}, []));
		let r = N({
			...i,
			state: s
		});
		if (r.length) throw new S(r);
		return {
			ok: !0,
			state: s
		};
	} catch (t) {
		return {
			ok: !1,
			state: e,
			issues: t instanceof S ? t.issues : [C(t instanceof Error ? t.message : "効果を適用できません。", "effects")]
		};
	}
}
function I(e, t, n) {
	if (!t.length) return {
		ok: !0,
		state: structuredClone(e)
	};
	let r = structuredClone(e), i = [], a = [];
	for (let e of t) for (let t of D(n)) {
		if (t.data.derived || t.data.externalContractId) continue;
		let n = t.data.resetRules?.find((t) => t.on === e), o = e === "full_reset" || e === "new_loop" && [
			"scene",
			"chapter",
			"run"
		].includes(t.data.scope);
		if (!n && !o) continue;
		let s = n?.value ?? t.data.initial;
		i.push({
			operation: "reset",
			targetId: t.id,
			value: s
		}), a.push({
			variableId: t.id,
			on: e,
			before: structuredClone(r.variableValues[t.id] ?? {
				type: "unknown",
				value: null,
				reason: "途中開始時の値が未指定です。"
			}),
			after: structuredClone(s),
			reason: n?.reason || (n ? "宣言した初期化規則" : `有効範囲 ${t.data.scope} の初期化`)
		}), r.variableValues[t.id] = structuredClone(s);
	}
	let o = F(e, i, n);
	return o.ok && t.length && (a.length || e.resetCauses) && (o.state.resetCauses = a), o;
}
//#endregion
//#region src/domain/writingWorkspace.ts
function L(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function R(e) {
	let { history: t, snapshots: n, ...r } = e, i = structuredClone(r);
	return delete i.authorAlternatives, i;
}
function ie(e) {
	let t = e.versions.find((t) => t.id === e.headVersionId);
	if (!t) throw Error("別案の現在版が見つかりません。");
	return structuredClone(t.content);
}
function ae(e, t, n = "別案の編集", r = (/* @__PURE__ */ new Date()).toISOString(), i = globalThis.crypto.randomUUID(), a) {
	let o = R(t);
	if (o.projectId !== e.projectId) throw Error("別の作品の内容をこの別案へ保存できません。");
	if (!e.versions.some((t) => t.id === e.headVersionId)) throw Error("別案の現在版が見つかりません。");
	let s = {
		id: i,
		parentVersionId: e.headVersionId,
		label: n.trim() || "別案の編集",
		createdAt: r,
		content: o,
		...a ? { structurePlan: structuredClone(a) } : {}
	};
	return {
		...structuredClone(e),
		versions: [...e.versions, s],
		headVersionId: s.id,
		updatedAt: r
	};
}
function z(e, t) {
	return JSON.stringify(e) === JSON.stringify(t);
}
function B(e, t, n) {
	return [
		e,
		t ?? "",
		...n
	].map((e) => encodeURIComponent(e)).join(":");
}
function oe(e, t, n, r) {
	if (e === "presentation") return L(t);
	if (e === "project") return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, t);
	let i = (e === "entity" ? t.entities : t.relations).find((e) => e.id === n);
	if (i) return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, i);
}
function V(e, t, n, r, i, a, o, s) {
	if (z(a, s) || z(o, s)) return;
	let c = a === void 0 ? "add" : s === void 0 ? "remove" : "replace";
	e.push({
		key: B(t, n, r),
		scope: t,
		...n ? { itemId: n } : {},
		path: r,
		label: i,
		kind: c,
		baseValue: structuredClone(a),
		canonicalValue: structuredClone(o),
		alternativeValue: structuredClone(s),
		conflict: !z(o, a) && !z(o, s)
	});
}
function H(e) {
	return new Map(e.entities.map((e) => [e.id, e]));
}
function se(e, t) {
	if (t.projectId !== e.projectId) throw Error("別の作品とは比較できません。");
	let n = e.baseContent, r = ie(e), i = R(t), a = [];
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) V(a, "project", void 0, [e], {
		name: "作品名",
		calendarId: "標準暦",
		mainStart: "本編開始時点",
		calendars: "暦の定義",
		worldReferences: "参照する世界版"
	}[e], n[e], i[e], r[e]);
	let o = H(n), s = H(r), c = H(i), l = /* @__PURE__ */ new Set([
		"id",
		"projectId",
		"kind",
		"revision",
		"createdAt",
		"updatedAt"
	]);
	for (let e of /* @__PURE__ */ new Set([...o.keys(), ...s.keys()])) {
		let t = o.get(e), n = s.get(e), r = c.get(e);
		if (!t || !n) {
			V(a, "entity", e, [], `${t?.name ?? n?.name ?? "情報"} · 情報全体`, t, r, n);
			continue;
		}
		let i = /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)]);
		for (let o of i) {
			if (l.has(o) || o === "data" || o === "customValues") continue;
			let i = t[o], s = n[o], c = r && r[o];
			V(a, "entity", e, [o], `${n.name} · ${o}`, i, c, s);
		}
		let u = t.data, d = n.data, f = r?.data;
		for (let r of /* @__PURE__ */ new Set([...Object.keys(u), ...Object.keys(d)])) t.kind === "chapter" && r === "sceneIds" || t.kind === "scene" && r === "chapterId" || V(a, "entity", e, ["data", r], `${n.name} · ${r}`, u[r], f?.[r], d[r]);
		let p = t.customValues, m = n.customValues, h = r?.customValues;
		for (let t of /* @__PURE__ */ new Set([...Object.keys(p), ...Object.keys(m)])) V(a, "entity", e, ["customValues", t], `${n.name} · 独自項目 ${t}`, p[t], h?.[t], m[t]);
	}
	let u = new Map(n.relations.map((e) => [e.id, e])), d = new Map(r.relations.map((e) => [e.id, e])), f = new Map(i.relations.map((e) => [e.id, e]));
	for (let e of /* @__PURE__ */ new Set([...u.keys(), ...d.keys()])) {
		let t = u.get(e), n = d.get(e), r = f.get(e);
		if (!t || !n) {
			V(a, "relation", e, [], "関係 · 全体", t, r, n);
			continue;
		}
		for (let i of /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)])) {
			if ([
				"id",
				"projectId",
				"revision"
			].includes(i)) continue;
			let o = t[i], s = n[i], c = r && r[i];
			V(a, "relation", e, [i], `関係 ${t.fromId.slice(-6)} → ${t.toId.slice(-6)} · ${i}`, o, c, s);
		}
	}
	let p = L(n), m = L(r), h = L(i);
	return !z(p, m) && !z(h, m) && a.push({
		key: B("presentation", void 0, ["all"]),
		scope: "presentation",
		path: ["all"],
		label: "章と場面の提示順",
		kind: "replace",
		baseValue: p,
		canonicalValue: h,
		alternativeValue: m,
		conflict: !z(h, p)
	}), a.sort((e, t) => e.label.localeCompare(t.label) || e.key.localeCompare(t.key));
}
function U(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	return t.length && (n === void 0 ? delete i[t[t.length - 1]] : i[t[t.length - 1]] = structuredClone(n)), r;
}
function ce(e, t) {
	let n = structuredClone(e), r = new Map(n.entities.filter((e) => e.kind === "chapter").map((e) => [e.id, e]));
	for (let e of r.values()) e.data.sceneIds = t.chapters.find((t) => t.id === e.id)?.sceneIds.filter((e) => n.entities.some((t) => t.kind === "scene" && t.id === e)) ?? [];
	for (let e of n.entities) e.kind === "scene" && (e.data.chapterId = t.scenes.find((t) => t.id === e.id)?.chapterId ?? null);
	let i = t.chapterOrder.flatMap((e) => {
		let t = r.get(e);
		return t ? [t] : [];
	});
	return n.entities.flatMap((e, t) => e.kind === "chapter" && !e.deletedAt ? [t] : []).forEach((e, t) => {
		i[t] && (n.entities[e] = i[t]);
	}), n;
}
function le(e, t, n) {
	if (t.scope === "presentation") return ce(e, n);
	if (t.scope === "project") return U(e, t.path, n);
	let r = t.scope === "entity" ? "entities" : "relations", i = [...e[r]], a = i.findIndex((e) => e.id === t.itemId);
	if (!t.path.length) n === void 0 ? a >= 0 && i.splice(a, 1) : a < 0 ? i.push(structuredClone(n)) : i[a] = structuredClone(n);
	else if (a >= 0) i[a] = U(i[a], t.path, n);
	else if (n !== void 0) throw Error(`差分の対象が見つかりません: ${t.itemId}`);
	return {
		...e,
		[r]: i
	};
}
function ue(e, t, n, r, i = (/* @__PURE__ */ new Date()).toISOString(), a = globalThis.crypto.randomUUID()) {
	let o = se(t, e);
	if ([...r].some((e) => !o.some((t) => t.key === e))) throw Error("選択した差分は現在の別案・正本から確認できません。内容を比較し直してください。");
	let s = o.filter((e) => r.has(e.key));
	if (!s.length) throw Error("採用する変更を選んでください。");
	if (s.some((e) => e.conflict)) throw Error("分岐元の後に正本が更新された項目があります。競合を確認し、別案の最新内容へ取り込んでください。");
	let c = R(e), l = [];
	for (let e of [...s].sort((e, t) => +(e.scope === "presentation") - (t.scope === "presentation"))) {
		let t = oe(e.scope, c, e.itemId, e.path), n = e.alternativeValue;
		l.push({
			key: e.key,
			scope: e.scope,
			...e.itemId ? { itemId: e.itemId } : {},
			path: [...e.path],
			label: e.label,
			before: t === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(t)
			},
			after: n === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(n)
			}
		}), c = le(c, e, e.alternativeValue);
	}
	if (c.projectId !== e.projectId) throw Error("別案のprojectIdは変更できません。");
	let { history: u, ...d } = e;
	return {
		project: {
			...structuredClone(d),
			...c,
			snapshots: e.snapshots,
			history: e.history
		},
		receipt: {
			id: a,
			createdAt: i,
			alternativeVersionId: t.headVersionId,
			sourceSnapshotId: t.sourceSnapshotId ?? null,
			selectedChangeKeys: [...r].sort(),
			fromCanonicalRevision: e.revision,
			patches: l
		}
	};
}
//#endregion
//#region src/domain/runtimeVersions.ts
async function de(e, t = e.projectId, n = {}, r) {
	let i = t === e.projectId ? e : e.snapshots.find((e) => e.id === t);
	if (!i) throw new S([{
		code: "REFERENCE_INVALID",
		path: "contentVersionId",
		message: "実行する固定版がありません。"
	}]);
	let a = n.worldSnapshots ? r?.stableRegistries.has(n.worldSnapshots) ? n.worldSnapshots : r ? p(n.worldSnapshots, r) : structuredClone(n.worldSnapshots) : {}, o = n.worlds ? structuredClone(n.worlds) : void 0, l = {
		...n,
		worldSnapshots: a,
		worlds: o
	}, u = "content" in i, f = structuredClone(u ? i.content : i), m = u ? i.contentHash : void 0, _ = "content" in i ? i.id : e.projectId, v = structuredClone(e.snapshots), { authorAlternatives: y, snapshots: b, history: x, ...C } = f, w = {
		...C,
		snapshots: v,
		history: []
	};
	if (m && await g(h(C)) !== m) throw new S([{
		code: "INTEGRITY_FAILED",
		path: `snapshots.${_}.contentHash`,
		message: "固定版の内容ハッシュが一致しません。実行を停止しました。"
	}]);
	let T = /* @__PURE__ */ new Set(), E = [w];
	for (let e = 0; e < E.length; e++) for (let t of E[e].entities) if ((t.kind === "scene" || t.kind === "flow_node") && t.data.reuse && t.data.reuse.mode !== "clone") {
		let e = t.data.reuse.pinnedSnapshotId;
		if (T.has(e)) continue;
		T.add(e);
		let n = v.find((t) => t.id === e);
		if (!n || await g(h(n.content)) !== n.contentHash) throw new S([{
			code: "INTEGRITY_FAILED",
			path: `snapshots.${e}`,
			message: "共通元の固定版がないか、内容hashが一致しません。"
		}]);
		E.push({
			...n.content,
			snapshots: v,
			history: []
		});
	}
	let D = await s(c(w, v), a, "worldReferences", r);
	if (D.length) throw new S(D);
	let O = d(w, l);
	if (!O.ok) throw new S(O.issues);
	return w;
}
//#endregion
//#region src/domain/externalInputs.ts
function W(e, t, r, i = []) {
	let a = [], s = [...e.entities, ...i].filter(o);
	r && (r.mode !== "actual" || !/^[0-9a-f]{64}$/.test(r.receiptHash)) && a.push({
		code: "INTEGRITY_FAILED",
		path: "receiptHash",
		message: "実際の外部入力には検証済み受信記録のSHA-256が必要です。"
	});
	for (let [e, r] of Object.entries(t)) {
		let t = `externalValues.${e}`, i = s.find((t) => t.id === e && t.kind === "external_contract");
		if (!i) {
			a.push({
				code: "REFERENCE_INVALID",
				path: t,
				message: "入力先の外部契約が存在しないか、削除・不採用です。"
			});
			continue;
		}
		let o = n(r);
		if (!o.ok) {
			a.push(...o.issues.map((e) => ({
				...e,
				path: t
			})));
			continue;
		}
		if (r.type !== "unknown" && r.type !== i.data.outputType) {
			a.push({
				code: "VALIDATION_FAILED",
				path: t,
				message: "実際の外部値と契約の出力型が違います。"
			});
			continue;
		}
		r.type === "unknown" && i.data.missingPolicy === "block" && a.push({
			code: "CONDITION_UNKNOWN",
			path: t,
			message: r.reason || "この外部契約は未確認値で進められません。"
		});
		for (let n of s) n.kind === "variable" && n.data.externalContractId === e && a.push(...l(n, r, t, !0));
	}
	return a;
}
structuredClone;
//#endregion
//#region src/domain/presentation.ts
var G = (e, t, n = []) => [...e.entities, ...n].filter((e) => e.kind === t && o(e)), K = (e, t, n = "REFERENCE_INVALID") => ({
	ok: !1,
	issues: [{
		code: n,
		path: e,
		message: t
	}]
}), q = /* @__PURE__ */ new WeakMap();
function J(e) {
	let t = [e], n = /* @__PURE__ */ new WeakSet();
	for (; t.length;) {
		let e = t.pop();
		if (e && typeof e == "object" && !n.has(e)) {
			n.add(e);
			for (let n of Object.values(e)) t.push(n);
			Object.freeze(e);
		}
	}
	return e;
}
function fe(e) {
	let t = structuredClone(e), n = q.get(e);
	return n && (J(t), q.set(t, new Map(n))), t;
}
async function pe(e, t, n) {
	let r = { worldReferences: structuredClone(e.worldReferences) }, i = n?.stableRegistries.has(t) ? t : n ? p(t, n) : structuredClone(t), o = await s(r, i, "worldReferences", n);
	if (o.length) throw new S(o);
	let c = a(r, i), l = structuredClone(c.worlds.flatMap((e) => e.entities)), u = /* @__PURE__ */ new Map();
	for (let e of c.references) for (let t of i[e.immutableSnapshotId].entities) u.set(t.id, e.immutableSnapshotId);
	return J(l), q.set(l, u), l;
}
function Y(t, n, r, i, a) {
	if (!r.sourceVersionId) return "match";
	if (i.referenceEntities?.some((e) => e.id === r.entityId)) {
		let e = q.get(i.referenceEntities)?.get(r.entityId);
		return e ? r.sourceVersionId === e ? "match" : "other_version" : "unknown";
	}
	let o = a ? e(t, a) : void 0;
	return [
		t.projectId,
		n.contentVersionId,
		e(t, r.entityId)?.sourceVersionId,
		o?.sourceVersionId
	].includes(r.sourceVersionId) ? "match" : "other_version";
}
function X(e, t) {
	let n = G(e, "flow_node", t.referenceEntities).find((e) => e.id === t.nodeId), r = G(e, "scene", t.referenceEntities).find((e) => e.id === (t.sceneId ?? n?.data.sceneId));
	return {
		projectId: e.projectId,
		worldTick: t.worldTick,
		graphId: n ? G(e, "flow_graph", t.referenceEntities).find((e) => e.data.nodeIds.includes(n.id))?.id : void 0,
		chapterId: r?.data.chapterId ?? (r ? G(e, "chapter", t.referenceEntities).find((e) => e.data.sceneIds.includes(r.id))?.id : void 0)
	};
}
function Z(e, t) {
	let n = G(e, "flow_node", t.referenceEntities).find((e) => e.id === t.nodeId), r = G(e, "scene", t.referenceEntities).find((e) => e.id === (t.sceneId ?? n?.data.sceneId)), i = n?.data.executionPolicy ?? (n?.data.nodeType === "automatic" ? "first_match" : "manual_choice");
	return [.../* @__PURE__ */ new Set([...r?.data.dialogueLineIds ?? [], ...n && i === "manual_choice" ? G(e, "flow_edge", t.referenceEntities).filter((e) => e.data.fromId === n.id).flatMap((e) => e.data.choiceLineId ? [e.data.choiceLineId] : []) : []])];
}
function me(e, t, n, r, i) {
	if (n.positionStatus === "unresolved" || Y(e, t, n, r, i) !== "match") return !1;
	let a = G(e, "flow_node", r.referenceEntities).find((e) => e.id === r.nodeId), o = r.sceneId ?? a?.data.sceneId;
	G(e, "scene", r.referenceEntities).find((e) => e.id === o);
	let s = Z(e, r);
	return [
		r.nodeId,
		o,
		...s
	].includes(n.entityId) ? [
		n.entityId,
		n.blockId,
		n.lineId
	].filter((e) => !!e).every((e) => t.seenIds.includes(e)) : !1;
}
function Q(e, t, n, r) {
	if (t.positionStatus === "unresolved" || n.positionStatus === "unresolved") return;
	let i = G(e, "flow_node", r.referenceEntities).find((e) => e.id === r.nodeId), a = G(e, "scene", r.referenceEntities).find((e) => e.id === (r.sceneId ?? i?.data.sceneId)), o = Z(e, r), s = [...(a?.data.body ?? []).map((e) => e.id)];
	for (let t of o) s.push(t, ...(G(e, "dialogue_line", r.referenceEntities).find((e) => e.id === t)?.data.text ?? []).map((e) => e.id));
	let c = t.blockId ?? t.lineId ?? (o.includes(t.entityId) ? t.entityId : void 0), l = n.blockId ?? n.lineId ?? (o.includes(n.entityId) ? n.entityId : void 0), u = s.indexOf(c ?? ""), d = s.indexOf(l ?? "");
	if (u >= 0 && d >= 0 && u !== d) return u < d;
	if (c === l && t.entityId === n.entityId && t.start != null && n.start != null && t.start !== n.start && !(t.start < n.start && t.end != null && t.end > n.start || n.start < t.start && n.end != null && n.end > t.start)) return t.start < n.start;
}
function $(e, t, n) {
	let i = r(t);
	if (!i.ok) return {
		ok: !1,
		issues: i.issues
	};
	let a = W(e, n.externalValues ?? {}, void 0, n.referenceEntities);
	if (a.length) return {
		ok: !1,
		issues: a
	};
	try {
		let r = n.nodeId ? G(e, "flow_node", n.referenceEntities).find((e) => e.id === n.nodeId) : void 0;
		if (n.nodeId && !r) return K("presentation.nodeId", "提示する分岐が存在しないか、削除・不採用です。");
		let i = n.sceneId ?? r?.data.sceneId ?? void 0;
		if (!r && !i) return K("presentation", "提示する場面または分岐を指定してください。");
		let a = i ? G(e, "scene", n.referenceEntities).find((e) => e.id === i) : void 0;
		if (i && !a) return K("presentation.sceneId", "提示する場面が存在しないか、削除・不採用です。");
		let s = X(e, {
			...n,
			sceneId: i
		}), c = N({
			state: t,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: s,
			ruleContexts: f(e, s)
		});
		if (c.length) return {
			ok: !1,
			issues: c
		};
		let l = {
			...n,
			sceneId: i
		}, u = structuredClone(t), d = new Set(u.seenIds);
		if (r && (u.presentationPosition = r.id, u.visitCounts[r.id] = (u.visitCounts[r.id] ?? 0) + 1, d.add(r.id)), a) {
			d.add(a.id), u.visitCounts[a.id] = (u.visitCounts[a.id] ?? 0) + 1;
			for (let e of a.data.blockIds ?? []) d.add(e);
			for (let e of a.data.body) d.add(e.id);
		}
		for (let t of Z(e, l)) {
			let i = G(e, "dialogue_line", n.referenceEntities).find((e) => e.id === t);
			if (!i) return K(`${r?.id ?? a?.id}.dialogueLineIds`, "提示する台詞が存在しないか、削除・不採用です。");
			d.add(i.id), u.visitCounts[i.id] = (u.visitCounts[i.id] ?? 0) + 1;
			for (let e of i.data.text) d.add(e.id);
		}
		u.seenIds = [...d];
		let p = G(e, "variable", n.referenceEntities), m = X(e, l), h = {
			state: u,
			variables: p,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: m,
			ruleContexts: f(e, m)
		}, g = [], _ = [];
		for (let i of G(e, "disclosure", n.referenceEntities)) {
			let n = v(e, i.data.anchor, i.id), o = i.data.targetScope, s = {
				...h,
				ruleContext: h.ruleContexts[i.id] ?? h.ruleContext
			}, c = o ? y(o, s) : { value: "true" };
			if (c.value === "false") continue;
			let d = Z(e, l);
			if (![
				r?.id,
				a?.id,
				...d
			].includes(n.entityId)) continue;
			let f = Y(e, t, n, l, i.id);
			if (f === "unknown") return K(`${i.id}.anchor.sourceVersionId`, "借用した提示位置の固定世界版を確認できません。", "CONDITION_UNKNOWN");
			if (f === "other_version") continue;
			if (c.value === "unknown") return K(`${i.id}.targetScope`, "開示の対象範囲・経路を確認できません。", "CONDITION_UNKNOWN");
			if (n.positionStatus === "unresolved" && [
				r?.id,
				a?.id,
				...d
			].includes(n.entityId)) return K(`${i.id}.anchor`, n.positionReason || "提示位置が不明です。本文へ再リンクしてください。", "CONDITION_UNKNOWN");
			if (!me(e, u, n, l, i.id)) continue;
			let p = j({
				op: "all",
				children: [i.data.condition ?? {
					op: "constant",
					value: !0
				}, o?.routeCondition ?? {
					op: "constant",
					value: !0
				}]
			}, s);
			if (g.push({
				targetId: i.id,
				...p
			}), p.value === "unknown") return K(`${i.id}.condition`, p.reasons.join("、") || "この場面の開示条件が未確認です。", "CONDITION_UNKNOWN");
			p.value === "true" && _.push(i);
		}
		let b = _.filter((e) => (e.data.knowledgeEffects?.length ?? 0) > 0);
		for (let t = 0; t < b.length; t++) for (let n = t + 1; n < b.length; n++) if (Q(e, v(e, b[t].data.anchor, b[t].id), v(e, b[n].data.anchor, b[n].id), l) === void 0) return K(`${r?.id ?? a?.id}.disclosures`, "複数の開示効果の提示順が確定していません。段落と文字位置を指定してください。", "CONDITION_UNKNOWN");
		b.sort((t, n) => Q(e, v(e, t.data.anchor, t.id), v(e, n.data.anchor, n.id), l) ? -1 : 1);
		let x = [], S = [];
		for (let t of b) for (let r of t.data.knowledgeEffects ?? []) {
			let i = [...e.entities, ...n.referenceEntities ?? []].find((e) => e.kind === "effect" && e.id === r && o(e));
			if (!i) return K(`${t.id}.knowledgeEffects`, "開示に指定した効果が存在しないか、削除・不採用です。");
			x.push(i), S.push({
				project: e,
				target: l,
				anchor: v(e, t.data.anchor, t.id)
			});
		}
		let C = F(u, x, {
			...h,
			effectPresentations: S
		});
		return C.ok ? (C.state.seenIds = [.../* @__PURE__ */ new Set([...C.state.seenIds, ..._.map((e) => e.id)])], {
			ok: !0,
			state: C.state,
			observationState: structuredClone(u),
			conditions: g
		}) : C;
	} catch (e) {
		return {
			ok: !1,
			issues: e instanceof S ? e.issues : [{
				code: "VALIDATION_FAILED",
				path: "presentation",
				message: e instanceof Error ? e.message : "提示を検証できません。"
			}]
		};
	}
}
function he(e, t, n) {
	let { sceneId: r, previousSceneId: i } = n, a = X(e, {
		sceneId: i,
		referenceEntities: n.referenceEntities
	}), o = X(e, {
		sceneId: r,
		referenceEntities: n.referenceEntities
	}), s = i && i !== r ? ["scene_end"] : [];
	a.chapterId && a.chapterId !== o.chapterId && s.push("chapter_end");
	let c = I({
		...t,
		...t.resetCauses ? { resetCauses: [] } : {}
	}, s, {
		state: t,
		entities: e.entities,
		referenceEntities: n.referenceEntities,
		externalValues: n.externalValues,
		ruleContext: X(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick,
			referenceEntities: n.referenceEntities
		}),
		ruleContexts: f(e, X(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick,
			referenceEntities: n.referenceEntities
		}))
	});
	if (!c.ok) return c;
	let l = $(e, c.state, n);
	if (!l.ok) return l;
	if (n.last) {
		let t = I(l.state, [
			"scene_end",
			"chapter_end",
			"run_end"
		], {
			state: l.state,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: X(e, n),
			ruleContexts: f(e, X(e, n))
		});
		if (!t.ok) return t;
		l.state = t.state, (c.state.resetCauses || t.state.resetCauses) && (l.state.resetCauses = [...c.state.resetCauses ?? [], ...t.state.resetCauses ?? []]);
	}
	return l;
}
//#endregion
export { X as a, ae as c, F as d, j as f, N as h, $ as i, ue as l, I as m, fe as n, W as o, ee as p, he as r, de as s, pe as t, R as u };
