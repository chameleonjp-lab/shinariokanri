import { c as e, et as t, f as n, it as r, l as i } from "./model-CpGFZXoy.js";
//#region src/testing/performanceFixture.ts
async function a(t, r = "standard") {
	let a = 2166136261;
	for (let e of t) a = Math.imul(a ^ e.charCodeAt(0), 16777619) >>> 0;
	let o = a.toString(16).padStart(8, "0"), s = 1, c = () => `${o}-0000-4000-8000-${(s++).toString(16).padStart(12, "0")}`, l = i("性能固定データ");
	l.projectId = c();
	let u = r === "large" ? 10 : 1, d = [
		"アオ",
		"門番",
		"記録係",
		"旅人",
		"語り手"
	], f = Array.from("霧の町で古い記録を調べる。鍵はまだ見つからず、新しい手掛かりを探した。"), p = (e) => Array.from({ length: e }, (e, t) => f[t % f.length]).join(""), m = (e) => [{
		id: c(),
		kind: "paragraph",
		text: p(e)
	}], h = (t, n, r) => {
		let i = e(l.projectId, t, n, r);
		return i.id = c(), i.createdAt = i.updatedAt = "2026-10-05T00:00:00Z", l.entities.push(i), i;
	}, g = [];
	for (let e = 0; e < 100 * u; e++) g.push(h("character", `${d[e % d.length]}${e}`, {
		reading: `あお${e}`,
		body: m(300),
		aliases: [{
			id: c(),
			text: `記録名${e}`,
			reading: `きろくめい${e}`,
			validity: n(),
			audienceHolderIds: [],
			isPublicDefault: !0
		}]
	}));
	let _ = [];
	for (let e = 0; e < 100 * u; e++) _.push(h("variable", `状態${e}`, {
		key: `flag_${e}`,
		valueType: "boolean",
		scope: "run",
		initial: {
			type: "boolean",
			value: !1
		},
		allowed: { values: [!1, !0] }
	}));
	let v = [];
	for (let e = 0; e < 1e3 * u; e++) v.push(h("event", `出来事${e}`, {
		summary: m(80),
		time: e % 7 == 0 ? {
			mode: "unknown",
			reason: "未確定"
		} : e % 3 == 0 ? {
			mode: "interval",
			start: String(e * 86400 - 5e5),
			end: String(e * 86400 - 5e5 + 3600),
			calendarId: l.calendarId
		} : {
			mode: "instant",
			at: String(e * 86400 - 5e5),
			calendarId: l.calendarId
		},
		laneRole: e % 4 == 0 ? "common" : "participants",
		participants: e % 4 == 0 ? [] : [{
			characterId: g[e % g.length].id,
			role: "actor"
		}]
	}));
	let y = [];
	for (let e = 0; e < 500 * u; e++) {
		let t = m(300), n = g[e % g.length];
		t[0].links = [{
			start: 0,
			end: 1,
			target: {
				entityId: n.id,
				blockId: n.data.body[0].id
			}
		}], y.push(h("scene", `場面${e}`, {
			summary: m(80),
			body: t,
			eventIds: [v[e % v.length].id],
			povId: n.id
		}));
	}
	for (let e = 0; e < 5e3 * u; e++) {
		let t = m(40);
		e % (r === "large" ? 12 : 3) == 0 && (t[0].ruby = [{
			start: 0,
			end: 1,
			text: "きり"
		}]), h("dialogue_line", `台詞${e}`, {
			text: t,
			speakerId: g[e % g.length].id
		});
	}
	for (let e = 0; e < 100 * u; e++) h("foreshadow", `伏線${e}`, {
		question: m(80),
		intent: m(80),
		resolutionPolicy: "undecided"
	});
	for (let e = 0; e < 2e3 * u; e++) l.relations.push({
		id: c(),
		projectId: l.projectId,
		revision: "0",
		fromId: g[e % g.length].id,
		toId: g[(e + 1) % g.length].id,
		relationType: "trust",
		direction: "forward",
		validity: {
			worldRange: null,
			routeCondition: e % 2 == 0 ? {
				op: "compare",
				variableId: _[e % _.length].id,
				comparator: "eq",
				value: {
					type: "boolean",
					value: !0
				}
			} : null,
			presentationAnchor: null
		},
		evidenceIds: [v[e % v.length].id],
		status: "provisional",
		visibility: "private"
	});
	let b = {
		character: g.length,
		event: v.length,
		scene: y.length,
		dialogue_line: 5e3 * u,
		relation: l.relations.length,
		variable: _.length,
		foreshadow: 100 * u,
		totalRecords: l.entities.length + l.relations.length
	}, x = new TextEncoder().encode(JSON.stringify(l));
	return {
		project: l,
		seed: t,
		size: r,
		counts: b,
		sha256: [...new Uint8Array(await crypto.subtle.digest("SHA-256", x))].map((e) => e.toString(16).padStart(2, "0")).join(""),
		assetBytes: 0
	};
}
async function o(n) {
	let i = await a(n, "large"), o = [], s = {
		scene: [
			"summary",
			"body",
			"authorNotes",
			"eventIds"
		],
		dialogue_line: ["text"],
		foreshadow: ["question", "intent"],
		event: ["summary"],
		variable: ["initial", "allowed"],
		character: []
	};
	for (let e of i.project.entities) for (let [t, n] of Object.entries(e.data)) Array.isArray(n) && !n.length && !s[e.kind]?.includes(t) && delete e.data[t];
	for (let t = 0; t < 3; t++) {
		let n = /* @__PURE__ */ new Uint8Array(25165824);
		for (let e = 0; e < n.length; e++) n[e] = (e * 17 + t * 61) % 251;
		let a = await r(n), s = e(i.project.projectId, "attachment", `性能素材${t + 1}`, {
			mediaType: "application/octet-stream",
			contentHash: a,
			byteSize: n.length,
			assetPath: `assets/${a}.bin`
		});
		s.id = i.project.projectId.slice(0, 24) + `f0000000000${t}`, s.createdAt = s.updatedAt = "2026-10-05T00:00:00Z", i.project.entities.push(s), o.push({
			contentHash: a,
			bytes: n,
			mediaType: "application/octet-stream"
		});
	}
	return {
		...i,
		coreRecords: i.counts.totalRecords,
		counts: {
			...i.counts,
			attachment: 3,
			totalRecords: i.counts.totalRecords + 3
		},
		assets: o,
		assetBytes: o.reduce((e, t) => e + t.bytes.length, 0),
		sha256: await r(t(i.project))
	};
}
//#endregion
export { o as createMaterialPerformanceFixture };
