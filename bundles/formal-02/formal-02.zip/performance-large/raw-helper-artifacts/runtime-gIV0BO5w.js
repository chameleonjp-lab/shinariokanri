import { E as e, G as t, I as n, J as r, K as i, O as a, R as o, X as s, Z as c, a as l, d as u, f as d, h as f, i as p, k as m, m as h, n as g, p as _, q as v, z as y } from "./presentation-BdFLV6xH.js";
//#region src/domain/runtime.ts
var b = (e) => structuredClone(e);
function x(e) {
	if (e === void 0) return "undefined";
	if (typeof e != "object" || !e) return JSON.stringify(e);
	if (Array.isArray(e)) return `[${e.map(x).join(",")}]`;
	let t = e;
	return `{${Object.keys(t).filter((e) => t[e] !== void 0).sort().map((e) => `${JSON.stringify(e)}:${x(t[e])}`).join(",")}}`;
}
var S = (e, t) => x(e) === x(t), C = (e, t, n = "runtime") => ({
	code: e,
	message: t,
	path: n
}), w = (e) => e.filter(c), T = /* @__PURE__ */ new WeakMap(), E = /* @__PURE__ */ new WeakMap(), D = (e) => [...e.entities, ...E.get(e) ?? []], O = (e, t) => {
	let n = T.get(e);
	return n ? n.activeByKind.get(t) ?? [] : w(a(e, t));
}, k = (e, t) => {
	let n = T.get(e);
	return n ? n.byId.get(t) : m(e, t);
}, A = (e) => O(e, "flow_node"), j = (e) => O(e, "flow_edge"), M = (e) => O(e, "variable"), N = (e) => O(e, "flow_graph");
function P(e, t) {
	if (t === e.projectId) return e;
	let n = e.snapshots.find((e) => e.id === t);
	return n ? {
		...n.content,
		snapshots: e.snapshots,
		history: []
	} : void 0;
}
function F(e, t = []) {
	let { authorAlternatives: n, ...r } = e, i = {
		...b({
			...r,
			history: [],
			snapshots: []
		}),
		snapshots: e.snapshots
	}, a = v(i, e.snapshots), o = {
		byId: /* @__PURE__ */ new Map(),
		activeByKind: /* @__PURE__ */ new Map(),
		edgesFrom: /* @__PURE__ */ new Map()
	};
	E.set(a, g(t));
	for (let e of [...a.entities, ...E.get(a) ?? []]) {
		if (e.deletedAt || (o.byId.set(e.id, e), !c(e))) continue;
		let t = o.activeByKind.get(e.kind) ?? [];
		if (t.push(e), o.activeByKind.set(e.kind, t), e.kind === "flow_edge") {
			let t = o.edgesFrom.get(e.data.fromId) ?? [];
			t.push(e), o.edgesFrom.set(e.data.fromId, t);
		}
	}
	return T.set(a, o), a;
}
function I(e, t) {
	return t.content ?? P(e, t.state.contentVersionId) ?? e;
}
var L = (e, t) => {
	let n = t === null ? void 0 : k(e, t);
	return n?.kind === "flow_node" && n.status !== "rejected" ? n : void 0;
}, R = (e, t) => {
	let n = T.get(e);
	return n ? n.edgesFrom.get(t) ?? [] : j(e).filter((e) => e.data.fromId === t);
}, z = (e, t, n, r) => d(n ?? {
	op: "constant",
	value: !0
}, {
	state: t,
	variables: M(e),
	entities: D(e),
	externalValues: r
}), B = (e, t, n) => ({
	...e,
	nodeId: e.state.presentationPosition,
	status: t,
	issues: n
});
function V(e) {
	return e?.data.reuse && e.data.reuse.mode !== "clone" ? C("VALIDATION_FAILED", "共通元を固定版から解決する参照・上書き試読は未対応です。実行を停止しています。", `${e.id}.reuse`) : void 0;
}
function H(e) {
	return e && typeof e == "object" && "issues" in e && Array.isArray(e.issues) ? e.issues : [C("VALIDATION_FAILED", e instanceof Error ? e.message : "試読の入力を検証できません。")];
}
function U(e) {
	e = r(e);
	let t = N(e).filter((t) => t.projectId === e.projectId && !t.data.parentGraphId);
	return t.length > 0 ? [...new Set(t.flatMap((e) => e.data.entryIds))] : A(e).filter((t) => t.projectId === e.projectId && t.data.nodeType === "entry").map((e) => e.id);
}
function W(e) {
	let t = U(e);
	return t.length === 1 ? t[0] : void 0;
}
function G(e, t, n, r, i) {
	return p(e, t, {
		nodeId: n,
		externalValues: r,
		referenceEntities: E.get(e),
		worldTick: i
	});
}
function ee(e, t) {
	try {
		return K(e, t);
	} catch {
		return [];
	}
}
function K(e, t) {
	let n = t.content ?? P(e, t.state.contentVersionId);
	if (!n) return [];
	e = n;
	let r = L(e, t.nodeId);
	if (!r || r.data.nodeType === "terminal") return [];
	let i = z(e, t.state, r.data.gate, t.externalValues);
	return R(e, r.id).map((n) => {
		let r = z(e, t.state, n.data.condition, t.externalValues), a = i.value === "false" || r.value === "false" ? "false" : i.value === "unknown" || r.value === "unknown" ? "unknown" : "true";
		return {
			edgeId: n.id,
			label: n.data.label || n.name || "次へ",
			toId: typeof n.data.toId == "string" ? n.data.toId : null,
			result: a,
			reasons: [...i.reasons, ...r.reasons],
			priority: n.data.priority ?? 0
		};
	}).sort((e, t) => e.priority - t.priority);
}
function q(e, t) {
	let n = L(e, t.nodeId);
	if (!n) return B(t, "error", [C("REFERENCE_INVALID", "現在の分岐が存在しません。")]);
	let r = V(n);
	if (r) return B(t, "error", [r]);
	if (n.data.nodeType === "terminal") return n.data.terminalReason?.trim() ? B(t, "terminal", []) : B(t, "error", [C("VALIDATION_FAILED", "終端には終了理由が必要です。", `${n.id}.terminalReason`)]);
	let i = z(e, t.state, n.data.gate, t.externalValues);
	if (i.value === "unknown") return B(t, "unknown", [C("CONDITION_UNKNOWN", i.reasons.join("、") || "発火条件の値が不足しています。", `${n.id}.gate`)]);
	if (i.value === "false") return n.data.fallbackId ? B(t, "ready", []) : B(t, "blocked", [C("TRANSITION_BLOCKED", "発火条件を満たさず、代替の進行先もありません。", `${n.id}.gate`)]);
	if (n.data.nodeType === "call" || n.data.nodeType === "exit" && t.state.callStack.length > 0) return B(t, "ready", []);
	let a = n.data.executionPolicy ?? (n.data.nodeType === "automatic" ? "first_match" : "manual_choice"), o = K(e, t);
	if (o.some((e) => !Number.isSafeInteger(e.priority))) return B(t, "error", [C("VALIDATION_FAILED", "優先値には安全な整数が必要です。", `${n.id}.priority`)]);
	if (a !== "manual_choice" && new Set(o.map((e) => e.priority)).size !== o.length) return B(t, "error", [C("VALIDATION_FAILED", "自動分岐の優先値が重複しています。", `${n.id}.priority`)]);
	let s = o.filter((e) => e.result === "unknown"), c = o.filter((e) => e.result === "true");
	return s.length > 0 && (a !== "manual_choice" || c.length === 0) ? B(t, "unknown", [C("CONDITION_UNKNOWN", "未確認の条件があり、進行先を確定できません。", n.id)]) : c.length === 0 && !n.data.fallbackId ? B(t, "blocked", [C("TRANSITION_BLOCKED", "有効な選択肢がありません。意図した終端とは別の行き止まりです。", n.id)]) : B(t, "ready", []);
}
function J(t, n = {}) {
	try {
		return Y(t, n);
	} catch (r) {
		let i = n.state ? b(n.state) : e(n.contentVersionId ?? t.projectId);
		return {
			content: t,
			state: i,
			nodeId: i.presentationPosition,
			contentRevision: t.revision,
			startState: b(i),
			startConditionResults: [],
			status: "error",
			history: [],
			trace: [],
			issues: H(r),
			lastDiff: [],
			externalValues: {},
			startExternalValues: {}
		};
	}
}
function Y(e, r = {}, i = !1) {
	let a = e, u = r.checkpointId ? a.entities.find((e) => e.id === r.checkpointId && e.kind === "checkpoint") : void 0;
	r.worldTick === void 0 && u?.data.worldTick != null && (r = {
		...r,
		worldTick: u.data.worldTick
	});
	let d = r.contentVersionId ?? e.projectId, p = i ? e : P(e, d);
	p && (e = p), i || (e = F(e, r.referenceEntities));
	let m = _(e, d, r.referenceEntities, r.externalValues), v = b(r.presentationResults ?? []), x = r.presentationState ? b(r.presentationState) : void 0, w, T, O, A = p && (!e.worldReferences.length || r.referenceEntities) ? void 0 : C("REFERENCE_INVALID", "指定した不変作品版が見つかりません。", "contentVersionId");
	for (let [t, n] of Object.entries(r.externalValues ?? {})) {
		let r = e.entities.find((e) => e.id === t && e.kind === "external_contract" && c(e));
		(!r || r.kind !== "external_contract" || n.type !== r.data.outputType || n.type === "integer" && !Number.isSafeInteger(n.value) || n.type === "enum" && typeof n.value != "string" || n.type === "boolean" && typeof n.value != "boolean") && (A = C("VALIDATION_FAILED", "外部管理値の契約・型・範囲が不正です。", t));
	}
	if (r.worldTick !== void 0 && !t(r.worldTick) && (A = C("VALIDATION_FAILED", "提示時点には整数の世界内tickを入力してください。", "worldTick")), r.checkpointId) {
		let t = k(a, r.checkpointId);
		!t || t.kind !== "checkpoint" || t.deletedAt ? A = C("REFERENCE_INVALID", "指定した途中開始の記録が存在しません。", "checkpointId") : t.data.contentVersionId !== d || t.data.runtimeState.contentVersionId !== d || t.data.contentRevision != null && t.data.contentRevision !== e.revision ? A = C("VALIDATION_FAILED", "開始状態と作品版が違います。移行または再作成が必要です。", `${t.id}.contentVersionId`) : (m = b(t.data.runtimeState), v = b(t.data.presentationResults ?? []), x = t.data.presentationState ? b(t.data.presentationState) : void 0, m.provenance = m.provenance === "stub" ? "stub" : m.provenance === "imported" || t.data.origin === "imported" ? "imported" : m.provenance === "partial" || t.data.origin !== "full_play" ? "partial" : "full_play", w = t.id, t.data.presentationResults != null && (A = n(m, t.data.presentationResults, D(e), `${t.id}.presentationResults`)[0]));
	} else r.state && (r.state.contentVersionId === d ? (m = b(r.state), r.presentationResults != null && (A = n(m, r.presentationResults, D(e))[0]), m.provenance === "full_play" && (m.provenance = "partial")) : A = C("VALIDATION_FAILED", "指定した開始状態と作品版が違います。", "state.contentVersionId"));
	r.seed !== void 0 && (m.rngSeed = r.seed);
	let j = r.entryId ?? m.presentationPosition ?? W(e);
	if (!A) {
		let t = o(m);
		t.ok || (A = t.issues[0]);
		for (let [t, n] of Object.entries(m.variableValues)) {
			let r = M(e).find((e) => e.id === t), i = r ? y(r, n, `${t}.value`) : [C("REFERENCE_INVALID", "開始状態に対象版の宣言がない状態値があります。", t)];
			if (i.length) {
				A = i[0];
				break;
			}
		}
		let n = l(e, {
			referenceEntities: E.get(e),
			nodeId: j ?? void 0,
			worldTick: r.worldTick
		});
		A ||= f({
			state: m,
			variables: M(e),
			entities: D(e),
			externalValues: r.externalValues,
			ruleContext: n,
			ruleContexts: s(e, n)
		})[0];
	}
	if (w && m.provenance === "full_play") {
		let t = j && U(e).includes(j) ? Y(a, {
			contentVersionId: d,
			entryId: j,
			seed: m.rngSeed,
			externalValues: r.externalValues,
			worldTick: r.worldTick,
			referenceEntities: E.get(e)
		}) : void 0;
		(!t || t.status === "error" || !S(t.startState, m)) && (m.provenance = "partial");
	}
	if (r.entryId && !U(e).includes(r.entryId) && !w && (m.provenance = "partial"), !A && !j && (A = C("VALIDATION_FAILED", "開始点が一つに決まりません。入口を指定してください。", "entryId")), !A && !L(e, j ?? null) && (A = C("REFERENCE_INVALID", "指定した開始点が存在しません。", "entryId")), A ||= V(L(e, j ?? null)), !A && j) {
		if ((w || r.state) && m.presentationPosition && j !== m.presentationPosition && m.provenance !== "stub" && (m.provenance = "partial"), !(w || r.state) || j !== m.presentationPosition || (m.visitCounts[j] ?? 0) === 0 && !m.seenIds.includes(j)) {
			let t = G(e, m, j, r.externalValues, r.worldTick);
			if (t.ok) {
				m = t.state, v = t.conditions, x = t.observationState;
				let n = L(e, j);
				if (n?.data.nodeType === "terminal") {
					let t = h(m, [
						...n.data.sceneId ? ["scene_end"] : [],
						...l(e, {
							referenceEntities: E.get(e),
							nodeId: j
						}).chapterId ? ["chapter_end"] : [],
						"run_end"
					], {
						state: m,
						variables: M(e),
						entities: D(e),
						ruleContext: l(e, {
							referenceEntities: E.get(e),
							nodeId: j,
							worldTick: r.worldTick
						}),
						ruleContexts: s(e, l(e, {
							referenceEntities: E.get(e),
							nodeId: j,
							worldTick: r.worldTick
						}))
					});
					t.ok ? m = t.state : T = t.issues;
				}
			} else T = t.issues, O = j, m = {
				...m,
				presentationPosition: j
			};
		} else m.presentationPosition = j;
		r.entryId && !U(e).includes(r.entryId) && !w && (m.provenance = "partial");
	}
	x && (x.provenance = m.provenance);
	let N = {
		content: e,
		referenceEntities: g(E.get(e) ?? []),
		initialWorldTick: r.worldTick,
		declarationProject: b({
			...a,
			history: [],
			snapshots: [],
			authorAlternatives: void 0,
			entities: a.entities.filter((e) => [
				"collection",
				"trace",
				"checkpoint"
			].includes(e.kind))
		}),
		state: m,
		nodeId: m.presentationPosition,
		contentRevision: e.revision,
		startState: b(m),
		startConditionResults: v,
		startPresentationState: x,
		startCheckpointId: w,
		status: "ready",
		history: [],
		trace: [],
		issues: [],
		lastDiff: [],
		externalValues: b(r.externalValues ?? {}),
		startExternalValues: b(r.externalValues ?? {}),
		pendingPresentation: O
	};
	if (A) return B(N, A.code === "CONDITION_UNKNOWN" ? "unknown" : "error", [A]);
	if (r.stub) {
		let t = $(e, N, r.stub), n = t.trace.at(-1)?.presentationState ?? x;
		return {
			...t,
			history: [],
			trace: [],
			startState: b(t.state),
			startStubValues: b(r.stub),
			...r.state || r.checkpointId ? { startStubBaseState: b(N.state) } : {},
			startPresentationState: n ? {
				...b(n),
				provenance: t.state.provenance
			} : void 0,
			startConditionResults: t.trace.at(-1)?.conditionResults.length ? b(t.trace.at(-1).conditionResults) : v,
			startExternalValues: b(t.externalValues)
		};
	}
	return T ? B(N, T.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", T) : q(e, N);
}
function X(e, t) {
	let n = [];
	for (let r of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) {
		let i = e[r], a = t[r];
		if (!S(i, a)) {
			if ((r === "variableValues" || r === "visitCounts") && i && a) {
				let e = i, t = a;
				for (let i of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) S(e[i], t[i]) || n.push({
					path: `${r}.${i}`,
					before: b(e[i]),
					after: b(t[i])
				});
			} else n.push({
				path: r,
				before: b(i),
				after: b(a)
			});
		}
	}
	return n;
}
function te(e, t) {
	if (!Number.isSafeInteger(t) || t <= 0) throw RangeError("抽選候補は1件以上必要です。");
	if (!Number.isSafeInteger(e.rngPosition) || e.rngPosition < 0 || !Number.isSafeInteger(e.rngPosition + 1)) throw RangeError("抽選位置が許容範囲を超えます。");
	let n = 2166136261, r = `${e.rngSeed}\u0000${e.rngPosition}`;
	for (let e = 0; e < r.length; e++) n = Math.imul(n ^ r.charCodeAt(e), 16777619) >>> 0;
	return n ^= n >>> 16, n = Math.imul(n, 2246822507) >>> 0, n ^= n >>> 13, {
		index: (n >>> 0) % t,
		state: {
			...b(e),
			rngPosition: e.rngPosition + 1
		}
	};
}
function Z(e, t, n) {
	let r = e.data.trigger;
	if (!r) return {
		once: void 0,
		occurrence: void 0
	};
	let i = r.id ?? e.id, a = r.scope ?? "run", o = a === "across_runs" ? a : `${a}:${t.loopNumber}`;
	return {
		once: r.repeat === "once" ? `trigger:${o}:${i}` : void 0,
		occurrence: n.event ? `occurrence:${o}:${i}:${n.event.occurrenceId}` : void 0
	};
}
function ne(e, n, r, a) {
	let o = n.data.trigger;
	if (!o) return;
	let s = Z(n, r, a);
	if (s.once && r.onceTriggers.includes(s.once)) return C("TRANSITION_BLOCKED", "この一回限りの発火は実行済みです。", `${n.id}.trigger`);
	if (!a.event || a.event.event !== o.event || a.event.eventKey !== o.eventKey || a.event.triggerId && a.event.triggerId !== (o.id ?? n.id)) return C("TRANSITION_BLOCKED", "宣言したきっかけの入力が必要です。条件の成立だけでは実行しません。", `${n.id}.trigger`);
	if (o.deadline) {
		let r = i(o.deadline, O(e, "event"));
		if (r.status === "conflict") return C("TIME_CONSTRAINT_CONFLICT", r.reason, `${n.id}.trigger.deadline`);
		if (r.status !== "resolved" || !t(a.worldTick) || r.calendarId !== e.calendarId) return C("CONDITION_UNKNOWN", "期限または現在の世界時点を確定できません。", `${n.id}.trigger.deadline`);
		let s = BigInt(a.worldTick), c = BigInt(r.endEarliest), l = BigInt(r.endLatest);
		if (s > l || o.deadline.mode === "interval" && s === l) return C("TRANSITION_BLOCKED", "発火期限を過ぎています。", `${n.id}.trigger.deadline`);
		if (s > c) return C("CONDITION_UNKNOWN", "期限の範囲内に現在時点があり、期限切れか確定できません。", `${n.id}.trigger.deadline`);
	}
}
function re(e, t, n) {
	let r = [];
	n.data.gate && r.push({
		targetId: n.id,
		...z(e, t.state, n.data.gate, t.externalValues)
	});
	for (let i of R(e, n.id)) i.data.condition && r.push({
		targetId: i.id,
		...z(e, t.state, i.data.condition, t.externalValues)
	});
	return r;
}
function ie(e, t, n, r, i, a, o) {
	let c = L(e, t.nodeId), u = L(e, r), d = l(e, {
		referenceEntities: E.get(e),
		nodeId: c?.id
	}), f = l(e, {
		referenceEntities: E.get(e),
		nodeId: r
	}), p = [];
	c?.data.sceneId && c.data.sceneId !== u?.data.sceneId && p.push("scene_end"), d.chapterId && d.chapterId !== f.chapterId && p.push("chapter_end");
	let m = h({
		...n,
		...n.resetCauses ? { resetCauses: [] } : {}
	}, p, {
		state: n,
		variables: M(e),
		entities: D(e),
		externalValues: t.externalValues,
		ruleContext: l(e, {
			referenceEntities: E.get(e),
			nodeId: c?.id,
			worldTick: a.worldTick
		}),
		ruleContexts: s(e, l(e, {
			referenceEntities: E.get(e),
			nodeId: c?.id,
			worldTick: a.worldTick
		}))
	});
	if (!m.ok) return B(t, "error", m.issues);
	let g = G(e, m.state, r, t.externalValues, a.worldTick);
	if (!g.ok) return B(t, g.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", g.issues);
	let _ = [];
	u?.data.nodeType === "terminal" && (u.data.sceneId && _.push("scene_end"), f.chapterId && _.push("chapter_end"), _.push("run_end"));
	let v = h(g.state, _, {
		state: g.state,
		variables: M(e),
		entities: D(e),
		externalValues: t.externalValues,
		ruleContext: l(e, {
			referenceEntities: E.get(e),
			nodeId: r,
			worldTick: a.worldTick
		}),
		ruleContexts: s(e, l(e, {
			referenceEntities: E.get(e),
			nodeId: r,
			worldTick: a.worldTick
		}))
	});
	if (!v.ok) return B(t, "error", v.issues);
	let y = v.state;
	u?.data.nodeType === "terminal" && (m.state.resetCauses || v.state.resetCauses) && (y.resetCauses = [...m.state.resetCauses ?? [], ...v.state.resetCauses ?? []]), o = [...o, ...g.conditions];
	let x = X(t.state, y).map((e) => ({
		...e,
		edgeIds: i
	})), S = {
		fromId: t.nodeId,
		toId: r,
		edgeIds: i,
		before: b(t.state),
		after: b(y),
		changes: x,
		request: b(a),
		conditionResults: o,
		presentationState: g.observationState,
		triggerId: L(e, t.nodeId)?.data.trigger?.id ?? (L(e, t.nodeId)?.data.trigger ? t.nodeId : void 0),
		externalValuesBefore: b(t.externalValues),
		externalValuesAfter: b(t.externalValues)
	};
	return q(e, {
		...t,
		state: y,
		nodeId: r,
		status: "ready",
		issues: [],
		lastDiff: x,
		history: [...t.history, {
			state: b(t.state),
			status: t.status,
			issues: b(t.issues),
			lastDiff: b(t.lastDiff),
			traceLength: t.trace.length,
			externalValues: b(t.externalValues),
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, S]
	});
}
function Q(e, t, n = {}) {
	if (t.status === "error" && t.nodeId === null) return t;
	try {
		return ae(e, t, n);
	} catch (e) {
		return B(t, "error", H(e));
	}
}
function ae(e, t, n = {}) {
	if (n.stub) return $(e, t, n.stub);
	let r = P(e, t.state.contentVersionId);
	if (!r) return B(t, "error", [C("REFERENCE_INVALID", "固定した作品版が存在しません。", "contentVersionId")]);
	if (e = r, t.contentRevision !== e.revision) return B(t, "error", [C("VALIDATION_FAILED", "作品が変更されました。この記録は再確認待ちです。試読を開始し直してください。", "contentRevision")]);
	if (e = t.content, t.pendingPresentation) return B(t, "unknown", t.issues.length ? t.issues : [C("CONDITION_UNKNOWN", "場面の提示条件を先に確認してください。", t.pendingPresentation)]);
	if (t.state.contentVersionId !== t.startState.contentVersionId) return B(t, "error", [C("VALIDATION_FAILED", "試読中に作品版が変わりました。", "contentVersionId")]);
	let i = n.event?.triggerId ?? L(e, t.nodeId)?.data.trigger?.id ?? (L(e, t.nodeId)?.data.trigger ? t.nodeId : void 0);
	if (n.event && i && t.trace.some((e) => e.triggerId === i && e.request.event?.occurrenceId === n.event?.occurrenceId)) return t;
	let a = L(e, t.nodeId);
	if (a && n.event) {
		let e = Z(a, t.state, n).occurrence;
		if (e && t.state.onceTriggers.includes(e)) return t;
	}
	let o = q(e, t);
	if (o.status !== "ready") return o;
	let c = L(e, t.nodeId), d = ne(e, c, t.state, n);
	if (d) return B(t, d.code === "CONDITION_UNKNOWN" ? "unknown" : d.code === "TIME_CONSTRAINT_CONFLICT" ? "error" : "blocked", [d]);
	let f = z(e, t.state, c.data.gate, t.externalValues), p = re(e, t, c), m = b(t.state), h = [], g;
	if (f.value === "false") g = c.data.fallbackId ?? void 0;
	else if (c.data.nodeType === "exit" && m.callStack.length > 0) {
		let n = k(e, m.callStack.at(-1).graphId);
		if (!n || n.kind !== "flow_graph" || !n.data.exitIds.includes(c.id)) return B(t, "error", [C("REFERENCE_INVALID", "現在の出口が呼出中グラフの宣言した出口に含まれていません。", c.id)]);
		g = m.callStack.pop().returnNodeId;
	} else if (c.data.nodeType === "call") {
		let n = c.data.childGraphId ? k(e, c.data.childGraphId) : void 0;
		if (!n || n.kind !== "flow_graph" || n.data.entryIds.length !== 1) return B(t, "error", [C("REFERENCE_INVALID", "呼出先に一つの入口を持つ子グラフが必要です。", `${c.id}.childGraphId`)]);
		let r = R(e, c.id).filter((e) => e.data.edgeType === "call_return");
		if (r.length !== 1 || typeof r[0].data.toId != "string") return B(t, "error", [C("REFERENCE_INVALID", "呼出には一つの確定した戻り先が必要です。", c.id)]);
		let i = z(e, t.state, r[0].data.condition, t.externalValues);
		if (i.value === "unknown") return B(t, "unknown", [C("CONDITION_UNKNOWN", i.reasons.join("、") || "呼出の戻り先条件が未確認です。", r[0].id)]);
		if (i.value === "false") {
			if (!c.data.fallbackId) return B(t, "blocked", [C("TRANSITION_BLOCKED", "呼出の戻り先条件を満たしていません。", r[0].id)]);
			g = c.data.fallbackId;
		} else {
			h = r, g = n.data.entryIds[0];
			let e = {};
			for (let t of n.data.parameters ?? []) e[t.key] = b(t.default ?? {
				type: "unknown",
				value: null,
				reason: "呼出引数が未設定です。"
			});
			m.callStack.push({
				graphId: n.id,
				returnNodeId: r[0].data.toId,
				parameters: e
			});
		}
	} else {
		let r = c.data.executionPolicy ?? (c.data.nodeType === "automatic" ? "first_match" : "manual_choice"), i = ee(e, t), a = i.filter((e) => e.result === "true");
		if (a.length === 0) g = c.data.fallbackId ?? void 0;
		else if (r === "manual_choice") {
			let r;
			if (n.random) {
				if (i.some((e) => e.result === "unknown")) return B(t, "unknown", [C("CONDITION_UNKNOWN", "未確認の抽選候補が残っています。", c.id)]);
				let e;
				try {
					e = te(m, a.length);
				} catch {
					return B(t, "error", [C("TRANSITION_BLOCKED", "抽選位置が許容範囲を超えます。", "rngPosition")]);
				}
				m = e.state, r = a[e.index];
			} else r = i.find((e) => e.edgeId === n.edgeId);
			if (!r) return B(t, "blocked", [C("TRANSITION_BLOCKED", "進む選択肢を指定してください。", c.id)]);
			if (r.result !== "true") return B(t, r.result === "unknown" ? "unknown" : "blocked", [C(r.result === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED", r.reasons.join("、") || "この選択肢の条件は成立していません。", r.edgeId)]);
			h = R(e, c.id).filter((e) => e.id === r.edgeId);
		} else h = (r === "first_match" ? a.slice(0, 1) : a).map((e) => e.edgeId).map((t) => R(e, c.id).find((e) => e.id === t));
		if (h.length > 0) {
			if (new Set(h.map((e) => typeof e.data.toId == "string" ? e.data.toId : null)).size !== 1) return B(t, "error", [C("VALIDATION_FAILED", "all_matchの進行先が異なります。同じ進行先を指定してください。", c.id)]);
			let e = h[0].data.toId;
			typeof e == "string" && (g = e);
		}
	}
	if (!g || !L(e, g)) return B(t, "error", [C("REFERENCE_INVALID", "進行先が未完成、または存在しません。", c.id)]);
	let _ = V(L(e, g));
	if (_) return B(t, "error", [_]);
	let v = [];
	for (let n of h) for (let r of n.data.effectIds ?? []) {
		let i = k(e, r);
		if (!i || i.kind !== "effect" || i.deletedAt || i.status === "rejected") return B(t, "error", [C("REFERENCE_INVALID", i?.status === "rejected" ? "分岐に不採用の効果が指定されています。" : "分岐に指定した効果が存在しないか、削除済みです。", `${n.id}.effectIds`)]);
		v.push(i);
	}
	let y = u(m, v, {
		state: m,
		variables: M(e),
		entities: D(e),
		externalValues: t.externalValues,
		ruleContext: l(e, {
			referenceEntities: E.get(e),
			nodeId: c.id,
			worldTick: n.worldTick
		}),
		ruleContexts: s(e, l(e, {
			referenceEntities: E.get(e),
			nodeId: c.id,
			worldTick: n.worldTick
		}))
	});
	if (!y.ok) return B(t, y.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", y.issues);
	m = y.state;
	let x = Z(c, t.state, n);
	return m.onceTriggers = [.../* @__PURE__ */ new Set([...m.onceTriggers, ...[x.once, x.occurrence].filter((e) => e !== void 0)])], ie(e, o, m, g, h.map((e) => e.id), n, p);
}
function $(e, t, n) {
	try {
		return oe(e, t, n);
	} catch (e) {
		return B(t, "error", H(e));
	}
}
function oe(e, t, n) {
	let r = P(e, t.state.contentVersionId);
	if (!r || r.revision !== t.contentRevision) return B(t, "error", [C("VALIDATION_FAILED", "作品版が変わりました。仮値を適用する前に開始し直してください。", "contentRevision")]);
	e = t.content;
	let i = b(t.externalValues);
	for (let [r, a] of Object.entries(n.external ?? {})) {
		let n = k(e, r);
		if (!n || n.kind !== "external_contract") return B(t, "error", [C("REFERENCE_INVALID", "仮の外部値には宣言した外部契約が必要です。", r)]);
		if (n.data.outputType !== a.type && a.type !== "unknown") return B(t, "error", [C("VALIDATION_FAILED", "仮の外部値と宣言した出力型が違います。", r)]);
		i[r] = b(a);
	}
	let a = Object.entries(n.variables ?? {}).map(([e, t]) => ({
		operation: "set",
		targetId: e,
		value: t
	})), o = u(t.state, a, {
		state: t.state,
		variables: M(e),
		entities: D(e),
		externalValues: i
	});
	if (!o.ok) return B(t, o.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", o.issues);
	let s = {
		...o.state,
		provenance: "stub"
	}, c = t.pendingPresentation, l = [], d;
	if (c) {
		let n = G(e, s, c, i, t.initialWorldTick);
		if (!n.ok) return B(t, n.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", n.issues);
		s = {
			...n.state,
			provenance: "stub"
		}, l = n.conditions, d = n.observationState, c = void 0;
	}
	let f = X(t.state, s);
	for (let e of /* @__PURE__ */ new Set([...Object.keys(t.externalValues), ...Object.keys(i)])) S(t.externalValues[e], i[e]) || f.push({
		path: `externalValues.${e}`,
		before: b(t.externalValues[e]),
		after: b(i[e])
	});
	let p = {
		...t,
		state: s,
		externalValues: i,
		issues: [],
		lastDiff: f,
		pendingPresentation: c,
		history: [...t.history, {
			state: b(t.state),
			externalValues: b(t.externalValues),
			status: t.status,
			issues: b(t.issues),
			lastDiff: b(t.lastDiff),
			traceLength: t.trace.length,
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, {
			fromId: t.nodeId,
			toId: t.nodeId,
			edgeIds: [],
			before: b(t.state),
			after: b(s),
			conditionResults: l,
			...d ? { presentationState: d } : {},
			changes: f,
			request: { stub: b(n) },
			externalValuesBefore: b(t.externalValues),
			externalValuesAfter: b(i)
		}]
	};
	return q(e, p);
}
function se(e, t, n) {
	let r = k(e, t);
	if (!r || r.kind !== "trace") return B(J(e), "error", [C("REFERENCE_INVALID", "保存した経路記録が存在しません。", t)]);
	let i = J(e, {
		checkpointId: r.data.startCheckpointId,
		contentVersionId: r.data.contentVersionId,
		referenceEntities: n,
		worldTick: r.data.initialWorldTick ?? void 0
	}), a = I(e, i);
	if (r.data.contentRevision != null && r.data.contentRevision !== a.revision) return B(i, "error", [C("VALIDATION_FAILED", "経路記録の作品版が変更されました。再確認が必要です。", `${t}.contentRevision`)]);
	if (i.status === "error") return i;
	let o = e.entities.find((e) => e.id === r.data.startCheckpointId && e.kind === "checkpoint");
	if (r.data.initialWorldTick != null && o?.data.worldTick != null && r.data.initialWorldTick !== o.data.worldTick) return B(i, "error", [C("INTEGRITY_FAILED", "保存した開始時点と経路の初期提示時点が一致しません。", `${t}.initialWorldTick`)]);
	if (r.data.initialStubValues) {
		let a = J(e, {
			...r.data.initialStubBaseState ? { state: b(r.data.initialStubBaseState) } : {},
			entryId: i.startState.presentationPosition ?? void 0,
			contentVersionId: r.data.contentVersionId,
			referenceEntities: n,
			seed: i.startState.rngSeed,
			worldTick: r.data.initialWorldTick ?? o?.data.worldTick ?? void 0,
			stub: b(r.data.initialStubValues)
		});
		if (a.status === "error" || !S(a.startState, i.startState) || !S(a.startExternalValues, r.data.initialExternalValues ?? {})) return B(i, "error", [C("INTEGRITY_FAILED", "保存した初期stub入力と固定版の開始状態が一致しません。", `${t}.initialStubValues`)]);
	}
	i.externalValues = b(r.data.initialExternalValues ?? {}), i.startExternalValues = b(i.externalValues), i.startStubValues = r.data.initialStubValues ? b(r.data.initialStubValues) : void 0, i.startStubBaseState = r.data.initialStubBaseState ? b(r.data.initialStubBaseState) : void 0;
	for (let [n, o] of r.data.steps.entries()) {
		if (!S(i.state, o.before)) return B(i, "error", [C("VALIDATION_FAILED", "保存した開始状態と経路の直前状態が一致しません。", `${t}.steps[${n}].before`)]);
		let r = {};
		if (o.operation === "stub" || o.operation === void 0 && o.edgeIds.length === 0 && o.before.presentationPosition === o.after.presentationPosition && S(o.before.visitCounts, o.after.visitCounts) && o.after.provenance === "stub") {
			let e = {};
			for (let t of M(a)) !t.data.derived && !S(o.before.variableValues[t.id], o.after.variableValues[t.id]) && (e[t.id] = b(o.after.variableValues[t.id]));
			r = { stub: {
				variables: e,
				external: o.externalValues ?? i.externalValues
			} };
		} else {
			i.externalValues = b(o.externalValues ?? i.externalValues);
			let e = L(a, i.nodeId);
			r.edgeId = o.edgeIds[0], o.after.rngPosition === o.before.rngPosition + 1 && (r.random = !0), e?.data.trigger && (r.event = {
				triggerId: e.data.trigger.id ?? e.id,
				event: e.data.trigger.event,
				eventKey: e.data.trigger.eventKey,
				occurrenceId: o.occurrenceId ?? `replay:${n}`
			}), r.worldTick = o.worldTick;
		}
		if (i = Q(e, i, r), i.status === "error") return i;
		if (o.conditionResults && !S(i.trace.at(-1)?.conditionResults, o.conditionResults)) return B(i, "error", [C("VALIDATION_FAILED", "保存した提示時の条件結果と再実行が一致しません。", `${t}.steps[${n}].conditionResults`)]);
		if (o.presentationState && !S(o.presentationState, i.trace.at(-1)?.presentationState)) return B(i, "error", [C("INTEGRITY_FAILED", "保存した提示前の観測状態と再実行が一致しません。", `${t}.steps[${n}].presentationState`)]);
		if (!S(i.state, o.after)) return B(i, "error", [C("VALIDATION_FAILED", "保存した経路と再実行の状態が一致しません。", `${t}.steps[${n}].after`)]);
	}
	return i;
}
//#endregion
export { se as replaySavedTrace, J as startTrial, Q as stepTrial };
