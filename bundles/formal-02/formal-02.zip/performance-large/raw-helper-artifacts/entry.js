import { $ as e, A as t, B as n, C as r, Ct as i, D as a, Dt as o, Et as s, F as c, H as l, L as u, M as d, N as f, Ot as p, P as m, Q as h, S as g, St as _, T as v, Tt as y, U as b, V as x, W as S, _ as C, _t as w, at as T, b as ee, bt as E, c as te, ct as ne, dt as re, et as ie, ft as D, g as O, gt as ae, ht as k, it as A, j, l as oe, lt as M, mt as se, nt as N, o as ce, ot as P, pt as le, q as F, r as ue, rt as I, s as de, st as fe, tt as pe, u as me, ut as he, v as ge, vt as _e, w as ve, wt as ye, x as be, xt as xe, y as Se, yt as Ce } from "./presentation-BdFLV6xH.js";
import { a as we, c as Te, d as L, f as Ee, i as De, l as Oe, o as ke, r as Ae, s as R, t as z, u as B } from "./protocol-DZd519mb.js";
//#region \0rolldown/runtime.js
var je = Object.create, Me = Object.defineProperty, Ne = Object.getOwnPropertyDescriptor, V = Object.getOwnPropertyNames, Pe = Object.getPrototypeOf, Fe = Object.prototype.hasOwnProperty, Ie = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), Le = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = V(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !Fe.call(e, s) && s !== n && Me(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = Ne(t, s)) || r.enumerable
	});
	return e;
}, Re = /* @__PURE__ */ ((e, t, n) => (n = e == null ? {} : je(Pe(e)), Le(t || !e || !e.__esModule || !Fe.call(e, "default") ? Me(n, "default", {
	value: e,
	enumerable: !0
}) : n, e)))((/* @__PURE__ */ Ie(((e, t) => {
	((n, r) => {
		typeof e == "object" && t !== void 0 ? t.exports = r() : typeof define == "function" && define.amd ? define(r) : (n = typeof globalThis < "u" ? globalThis : n || self).Dexie = r();
	})(e, function() {
		var e = function(t, n) {
			return (e = Object.setPrototypeOf || ({ __proto__: [] } instanceof Array ? function(e, t) {
				e.__proto__ = t;
			} : function(e, t) {
				for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
			}))(t, n);
		}, t = function() {
			return (t = Object.assign || function(e) {
				for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
				return e;
			}).apply(this, arguments);
		};
		function n(e, t, n) {
			if (n || arguments.length === 2) for (var r, i = 0, a = t.length; i < a; i++) !r && i in t || ((r ||= Array.prototype.slice.call(t, 0, i))[i] = t[i]);
			return e.concat(r || Array.prototype.slice.call(t));
		}
		var r = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, i = Object.keys, a = Array.isArray;
		function o(e, t) {
			return typeof t == "object" && i(t).forEach(function(n) {
				e[n] = t[n];
			}), e;
		}
		typeof Promise > "u" || r.Promise || (r.Promise = Promise);
		var s = Object.getPrototypeOf, c = {}.hasOwnProperty;
		function l(e, t) {
			return c.call(e, t);
		}
		function u(e, t) {
			typeof t == "function" && (t = t(s(e))), (typeof Reflect > "u" ? i : Reflect.ownKeys)(t).forEach(function(n) {
				f(e, n, t[n]);
			});
		}
		var d = Object.defineProperty;
		function f(e, t, n, r) {
			d(e, t, o(n && l(n, "get") && typeof n.get == "function" ? {
				get: n.get,
				set: n.set,
				configurable: !0
			} : {
				value: n,
				configurable: !0,
				writable: !0
			}, r));
		}
		function p(e) {
			return { from: function(t) {
				return e.prototype = Object.create(t.prototype), f(e.prototype, "constructor", e), { extend: u.bind(null, e.prototype) };
			} };
		}
		var m = Object.getOwnPropertyDescriptor, h = [].slice;
		function g(e, t, n) {
			return h.call(e, t, n);
		}
		function _(e, t) {
			return t(e);
		}
		function v(e) {
			if (!e) throw Error("Assertion Failed");
		}
		function y(e) {
			r.setImmediate ? setImmediate(e) : setTimeout(e, 0);
		}
		function b(e, t) {
			if (typeof t == "string" && l(e, t)) return e[t];
			if (!t) return e;
			if (typeof t != "string") {
				for (var n = [], r = 0, i = t.length; r < i; ++r) {
					var a = b(e, t[r]);
					n.push(a);
				}
				return n;
			}
			var o, s = t.indexOf(".");
			return s === -1 || (o = e[t.substr(0, s)]) == null ? void 0 : b(o, t.substr(s + 1));
		}
		function x(e, t, n) {
			if (e && t !== void 0 && !("isFrozen" in Object && Object.isFrozen(e))) {
				if (typeof t != "string" && "length" in t) {
					v(typeof n != "string" && "length" in n);
					for (var r = 0, i = t.length; r < i; ++r) x(e, t[r], n[r]);
				} else {
					var o = t.indexOf(".");
					if (o !== -1) {
						var s = t.substr(0, o), o = t.substr(o + 1);
						if (o === "") n === void 0 ? a(e) && !isNaN(parseInt(s)) ? e.splice(s, 1) : delete e[s] : e[s] = n;
						else {
							var c = e[s];
							if (!c || !l(e, s)) {
								if (n === void 0) return;
								c = e[s] = {};
							}
							x(c, o, n);
						}
					} else n === void 0 ? a(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n;
				}
			}
		}
		function S(e) {
			var t, n = {};
			for (t in e) l(e, t) && (n[t] = e[t]);
			return n;
		}
		var C = [].concat;
		function w(e) {
			return C.apply([], e);
		}
		var T = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(w([
			8,
			16,
			32,
			64
		].map(function(e) {
			return [
				"Int",
				"Uint",
				"Float"
			].map(function(t) {
				return t + e + "Array";
			});
		}))).filter(function(e) {
			return r[e];
		}), ee = new Set(T.map(function(e) {
			return r[e];
		})), E = null;
		function te(e) {
			return E = /* @__PURE__ */ new WeakMap(), e = function e(t) {
				if (!t || typeof t != "object") return t;
				var n = E.get(t);
				if (n) return n;
				if (a(t)) {
					n = [], E.set(t, n);
					for (var r = 0, i = t.length; r < i; ++r) n.push(e(t[r]));
				} else if (ee.has(t.constructor)) n = t;
				else {
					var o, c = s(t);
					for (o in n = c === Object.prototype ? {} : Object.create(c), E.set(t, n), t) l(t, o) && (n[o] = e(t[o]));
				}
				return n;
			}(e), E = null, e;
		}
		var ne = {}.toString;
		function re(e) {
			return ne.call(e).slice(8, -1);
		}
		var ie = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", D = typeof ie == "symbol" ? function(e) {
			var t;
			return e != null && (t = e[ie]) && t.apply(e);
		} : function() {
			return null;
		};
		function O(e, t) {
			t = e.indexOf(t), 0 <= t && e.splice(t, 1);
		}
		var ae = {};
		function k(e) {
			var t, n, r, i;
			if (arguments.length === 1) {
				if (a(e)) return e.slice();
				if (this === ae && typeof e == "string") return [e];
				if (i = D(e)) for (n = []; !(r = i.next()).done;) n.push(r.value);
				else {
					if (e == null || typeof (t = e.length) != "number") return [e];
					for (n = Array(t); t--;) n[t] = e[t];
				}
			} else for (t = arguments.length, n = Array(t); t--;) n[t] = arguments[t];
			return n;
		}
		var A = typeof Symbol < "u" ? function(e) {
			return e[Symbol.toStringTag] === "AsyncFunction";
		} : function() {
			return !1;
		}, T = [
			"Unknown",
			"Constraint",
			"Data",
			"TransactionInactive",
			"ReadOnly",
			"Version",
			"NotFound",
			"InvalidState",
			"InvalidAccess",
			"Abort",
			"Timeout",
			"QuotaExceeded",
			"Syntax",
			"DataClone"
		], j = [
			"Modify",
			"Bulk",
			"OpenFailed",
			"VersionChange",
			"Schema",
			"Upgrade",
			"InvalidTable",
			"MissingAPI",
			"NoSuchDatabase",
			"InvalidArgument",
			"SubTransaction",
			"Unsupported",
			"Internal",
			"DatabaseClosed",
			"PrematureCommit",
			"ForeignAwait"
		].concat(T), oe = {
			VersionChanged: "Database version changed by other database connection",
			DatabaseClosed: "Database has been closed",
			Abort: "Transaction aborted",
			TransactionInactive: "Transaction has already completed or failed",
			MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
		};
		function M(e, t) {
			this.name = e, this.message = t;
		}
		function se(e, t) {
			return e + ". Errors: " + Object.keys(t).map(function(e) {
				return t[e].toString();
			}).filter(function(e, t, n) {
				return n.indexOf(e) === t;
			}).join("\n");
		}
		function N(e, t, n, r) {
			this.failures = t, this.failedKeys = r, this.successCount = n, this.message = se(e, t);
		}
		function ce(e, t) {
			this.name = "BulkError", this.failures = Object.keys(t).map(function(e) {
				return t[e];
			}), this.failuresByPos = t, this.message = se(e, this.failures);
		}
		p(M).from(Error).extend({ toString: function() {
			return this.name + ": " + this.message;
		} }), p(N).from(M), p(ce).from(M);
		var P = j.reduce(function(e, t) {
			return e[t] = t + "Error", e;
		}, {}), le = M, F = j.reduce(function(e, t) {
			var n = t + "Error";
			function r(e, r) {
				this.name = n, e ? typeof e == "string" ? (this.message = `${e}${r ? "\n " + r : ""}`, this.inner = r || null) : typeof e == "object" && (this.message = `${e.name} ${e.message}`, this.inner = e) : (this.message = oe[t] || n, this.inner = null);
			}
			return p(r).from(le), e[t] = r, e;
		}, {}), ue = (F.Syntax = SyntaxError, F.Type = TypeError, F.Range = RangeError, T.reduce(function(e, t) {
			return e[t + "Error"] = F[t], e;
		}, {}));
		T = j.reduce(function(e, t) {
			return [
				"Syntax",
				"Type",
				"Range"
			].indexOf(t) === -1 && (e[t + "Error"] = F[t]), e;
		}, {});
		function I() {}
		function de(e) {
			return e;
		}
		function fe(e, t) {
			return e == null || e === de ? t : function(n) {
				return t(e(n));
			};
		}
		function pe(e, t) {
			return function() {
				e.apply(this, arguments), t.apply(this, arguments);
			};
		}
		function me(e, t) {
			return e === I ? t : function() {
				var n = e.apply(this, arguments), r = (n !== void 0 && (arguments[0] = n), this.onsuccess), i = this.onerror, a = (this.onsuccess = null, this.onerror = null, t.apply(this, arguments));
				return r && (this.onsuccess = this.onsuccess ? pe(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? pe(i, this.onerror) : i), a === void 0 ? n : a;
			};
		}
		function he(e, t) {
			return e === I ? t : function() {
				e.apply(this, arguments);
				var n = this.onsuccess, r = this.onerror;
				this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? pe(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? pe(r, this.onerror) : r);
			};
		}
		function ge(e, t) {
			return e === I ? t : function() {
				var n = e.apply(this, arguments), r = (o(arguments[0], n), this.onsuccess), i = this.onerror, a = (this.onsuccess = null, this.onerror = null, t.apply(this, arguments));
				return r && (this.onsuccess = this.onsuccess ? pe(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? pe(i, this.onerror) : i), n === void 0 ? a === void 0 ? void 0 : a : o(n, a);
			};
		}
		function _e(e, t) {
			return e === I ? t : function() {
				return !1 !== t.apply(this, arguments) && e.apply(this, arguments);
			};
		}
		function ve(e, t) {
			return e === I ? t : function() {
				var n = e.apply(this, arguments);
				if (n && typeof n.then == "function") {
					for (var r = this, i = arguments.length, a = Array(i); i--;) a[i] = arguments[i];
					return n.then(function() {
						return t.apply(r, a);
					});
				}
				return t.apply(this, arguments);
			};
		}
		T.ModifyError = N, T.DexieError = M, T.BulkError = ce;
		var ye = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
		function be(e) {
			ye = e;
		}
		var xe = {}, Se = 100, Ce = typeof Promise > "u" ? [] : (j = Promise.resolve(), typeof crypto < "u" && crypto.subtle ? [
			Ce = crypto.subtle.digest("SHA-512", new Uint8Array([0])),
			s(Ce),
			j
		] : [
			j,
			s(j),
			j
		]), j = Ce[0], we = Ce[1], we = we && we.then, Te = j && j.constructor, L = !!Ce[2], Ee = function(e, t) {
			je.push([e, t]), Oe &&= (queueMicrotask(H), !1);
		}, De = !0, Oe = !0, ke = [], Ae = [], R = de, z = {
			id: "global",
			global: !0,
			ref: 0,
			unhandleds: [],
			onunhandled: I,
			pgp: !1,
			env: {},
			finalize: I
		}, B = z, je = [], Me = 0, Ne = [];
		function V(e) {
			if (typeof this != "object") throw TypeError("Promises must be constructed via new");
			this._listeners = [], this._lib = !1;
			var t = this._PSD = B;
			if (typeof e != "function") {
				if (e !== xe) throw TypeError("Not a function");
				this._state = arguments[1], this._value = arguments[2], !1 === this._state && Ie(this, this._value);
			} else this._state = null, this._value = null, ++t.ref, function e(t, n) {
				try {
					n(function(n) {
						if (t._state === null) {
							if (n === t) throw TypeError("A promise cannot be resolved with itself.");
							var r = t._lib && Be();
							n && typeof n.then == "function" ? e(t, function(e, t) {
								n instanceof V ? n._then(e, t) : n.then(e, t);
							}) : (t._state = !0, t._value = n, Le(t)), r && Ve();
						}
					}, Ie.bind(null, t));
				} catch (e) {
					Ie(t, e);
				}
			}(this, e);
		}
		var Pe = {
			get: function() {
				var e = B, t = Je;
				function n(n, r) {
					var i = this, a = !e.global && (e !== B || t !== Je), o = a && !Qe(), s = new V(function(t, s) {
						Re(i, new Fe(rt(n, e, a, o), rt(r, e, a, o), t, s, e));
					});
					return this._consoleTask && (s._consoleTask = this._consoleTask), s;
				}
				return n.prototype = xe, n;
			},
			set: function(e) {
				f(this, "then", e && e.prototype === xe ? Pe : {
					get: function() {
						return e;
					},
					set: Pe.set
				});
			}
		};
		function Fe(e, t, n, r, i) {
			this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = i;
		}
		function Ie(e, t) {
			var n, r;
			Ae.push(t), e._state === null && (n = e._lib && Be(), t = R(t), e._state = !1, e._value = t, r = e, ke.some(function(e) {
				return e._value === r._value;
			}) || ke.push(r), Le(e), n) && Ve();
		}
		function Le(e) {
			var t = e._listeners;
			e._listeners = [];
			for (var n = 0, r = t.length; n < r; ++n) Re(e, t[n]);
			var i = e._PSD;
			--i.ref || i.finalize(), Me === 0 && (++Me, Ee(function() {
				--Me == 0 && He();
			}, []));
		}
		function Re(e, t) {
			if (e._state === null) e._listeners.push(t);
			else {
				var n = e._state ? t.onFulfilled : t.onRejected;
				if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
				++t.psd.ref, ++Me, Ee(ze, [
					n,
					e,
					t
				]);
			}
		}
		function ze(e, t, n) {
			try {
				var r, i = t._value;
				!t._state && Ae.length && (Ae = []), r = ye && t._consoleTask ? t._consoleTask.run(function() {
					return e(i);
				}) : e(i), t._state || Ae.indexOf(i) !== -1 || ((e) => {
					for (var t = ke.length; t;) if (ke[--t]._value === e._value) return ke.splice(t, 1);
				})(t), n.resolve(r);
			} catch (e) {
				n.reject(e);
			} finally {
				--Me == 0 && He(), --n.psd.ref || n.psd.finalize();
			}
		}
		function H() {
			nt(z, function() {
				Be() && Ve();
			});
		}
		function Be() {
			var e = De;
			return Oe = De = !1, e;
		}
		function Ve() {
			var e, t, n;
			do
				for (; 0 < je.length;) for (e = je, je = [], n = e.length, t = 0; t < n; ++t) {
					var r = e[t];
					r[0].apply(null, r[1]);
				}
			while (0 < je.length);
			Oe = De = !0;
		}
		function He() {
			for (var e = ke, t = (ke = [], e.forEach(function(e) {
				e._PSD.onunhandled.call(null, e._value, e);
			}), Ne.slice(0)), n = t.length; n;) t[--n]();
		}
		function Ue(e) {
			return new V(xe, !1, e);
		}
		function U(e, t) {
			var n = B;
			return function() {
				var r = Be(), i = B;
				try {
					return et(n, !0), e.apply(this, arguments);
				} catch (e) {
					t && t(e);
				} finally {
					et(i, !1), r && Ve();
				}
			};
		}
		u(V.prototype, {
			then: Pe,
			_then: function(e, t) {
				Re(this, new Fe(null, null, e, t, B));
			},
			catch: function(e) {
				var t, n;
				return arguments.length === 1 ? this.then(null, e) : (t = e, n = arguments[1], typeof t == "function" ? this.then(null, function(e) {
					return (e instanceof t ? n : Ue)(e);
				}) : this.then(null, function(e) {
					return (e && e.name === t ? n : Ue)(e);
				}));
			},
			finally: function(e) {
				return this.then(function(t) {
					return V.resolve(e()).then(function() {
						return t;
					});
				}, function(t) {
					return V.resolve(e()).then(function() {
						return Ue(t);
					});
				});
			},
			timeout: function(e, t) {
				var n = this;
				return e < 1 / 0 ? new V(function(r, i) {
					var a = setTimeout(function() {
						return i(new F.Timeout(t));
					}, e);
					n.then(r, i).finally(clearTimeout.bind(null, a));
				}) : this;
			}
		}), typeof Symbol < "u" && Symbol.toStringTag && f(V.prototype, Symbol.toStringTag, "Dexie.Promise"), z.env = tt(), u(V, {
			all: function() {
				var e = k.apply(null, arguments).map(W);
				return new V(function(t, n) {
					e.length === 0 && t([]);
					var r = e.length;
					e.forEach(function(i, a) {
						return V.resolve(i).then(function(n) {
							e[a] = n, --r || t(e);
						}, n);
					});
				});
			},
			resolve: function(e) {
				return e instanceof V ? e : e && typeof e.then == "function" ? new V(function(t, n) {
					e.then(t, n);
				}) : new V(xe, !0, e);
			},
			reject: Ue,
			race: function() {
				var e = k.apply(null, arguments).map(W);
				return new V(function(t, n) {
					e.map(function(e) {
						return V.resolve(e).then(t, n);
					});
				});
			},
			PSD: {
				get: function() {
					return B;
				},
				set: function(e) {
					return B = e;
				}
			},
			totalEchoes: { get: function() {
				return Je;
			} },
			newPSD: Xe,
			usePSD: nt,
			scheduler: {
				get: function() {
					return Ee;
				},
				set: function(e) {
					Ee = e;
				}
			},
			rejectionMapper: {
				get: function() {
					return R;
				},
				set: function(e) {
					R = e;
				}
			},
			follow: function(e, t) {
				return new V(function(n, r) {
					return Xe(function(t, n) {
						var r = B;
						r.unhandleds = [], r.onunhandled = n, r.finalize = pe(function() {
							var e, r = this;
							e = function() {
								r.unhandleds.length === 0 ? t() : n(r.unhandleds[0]);
							}, Ne.push(function t() {
								e(), Ne.splice(Ne.indexOf(t), 1);
							}), ++Me, Ee(function() {
								--Me == 0 && He();
							}, []);
						}, r.finalize), e();
					}, t, n, r);
				});
			}
		}), Te && (Te.allSettled && f(V, "allSettled", function() {
			var e = k.apply(null, arguments).map(W);
			return new V(function(t) {
				e.length === 0 && t([]);
				var n = e.length, r = Array(n);
				e.forEach(function(e, i) {
					return V.resolve(e).then(function(e) {
						return r[i] = {
							status: "fulfilled",
							value: e
						};
					}, function(e) {
						return r[i] = {
							status: "rejected",
							reason: e
						};
					}).then(function() {
						return --n || t(r);
					});
				});
			});
		}), Te.any && typeof AggregateError < "u" && f(V, "any", function() {
			var e = k.apply(null, arguments).map(W);
			return new V(function(t, n) {
				e.length === 0 && n(/* @__PURE__ */ AggregateError([]));
				var r = e.length, i = Array(r);
				e.forEach(function(e, a) {
					return V.resolve(e).then(function(e) {
						return t(e);
					}, function(e) {
						i[a] = e, --r || n(AggregateError(i));
					});
				});
			});
		}), Te.withResolvers) && (V.withResolvers = Te.withResolvers);
		var We = {
			awaits: 0,
			echoes: 0,
			id: 0
		}, Ge = 0, Ke = [], qe = 0, Je = 0, Ye = 0;
		function Xe(e, t, n, r) {
			var i = B, a = Object.create(i), t = (a.parent = i, a.ref = 0, a.global = !1, a.id = ++Ye, z.env, a.env = L ? {
				Promise: V,
				PromiseProp: {
					value: V,
					configurable: !0,
					writable: !0
				},
				all: V.all,
				race: V.race,
				allSettled: V.allSettled,
				any: V.any,
				resolve: V.resolve,
				reject: V.reject
			} : {}, t && o(a, t), ++i.ref, a.finalize = function() {
				--this.parent.ref || this.parent.finalize();
			}, nt(a, e, n, r));
			return a.ref === 0 && a.finalize(), t;
		}
		function Ze() {
			return We.id ||= ++Ge, ++We.awaits, We.echoes += Se, We.id;
		}
		function Qe() {
			return !!We.awaits && (--We.awaits == 0 && (We.id = 0), We.echoes = We.awaits * Se, !0);
		}
		function W(e) {
			return We.echoes && e && e.constructor === Te ? (Ze(), e.then(function(e) {
				return Qe(), e;
			}, function(e) {
				return Qe(), at(e);
			})) : e;
		}
		function $e() {
			var e = Ke[Ke.length - 1];
			Ke.pop(), et(e, !1);
		}
		function et(e, t) {
			var n, i, a = B;
			(t ? !We.echoes || qe++ && e === B : !qe || --qe && e === B) || queueMicrotask(t ? function(e) {
				++Je, We.echoes && --We.echoes != 0 || (We.echoes = We.awaits = We.id = 0), Ke.push(B), et(e, !0);
			}.bind(null, e) : $e), e !== B && (B = e, a === z && (z.env = tt()), L) && (n = z.env.Promise, i = e.env, a.global || e.global) && (Object.defineProperty(r, "Promise", i.PromiseProp), n.all = i.all, n.race = i.race, n.resolve = i.resolve, n.reject = i.reject, i.allSettled && (n.allSettled = i.allSettled), i.any) && (n.any = i.any);
		}
		function tt() {
			var e = r.Promise;
			return L ? {
				Promise: e,
				PromiseProp: Object.getOwnPropertyDescriptor(r, "Promise"),
				all: e.all,
				race: e.race,
				allSettled: e.allSettled,
				any: e.any,
				resolve: e.resolve,
				reject: e.reject
			} : {};
		}
		function nt(e, t, n, r, i) {
			var a = B;
			try {
				return et(e, !0), t(n, r, i);
			} finally {
				et(a, !1);
			}
		}
		function rt(e, t, n, r) {
			return typeof e == "function" ? function() {
				var i = B;
				n && Ze(), et(t, !0);
				try {
					return e.apply(this, arguments);
				} finally {
					et(i, !1), r && queueMicrotask(Qe);
				}
			} : e;
		}
		function it(e) {
			Promise === Te && We.echoes === 0 ? qe === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0);
		}
		("" + we).indexOf("[native code]") === -1 && (Ze = Qe = I);
		var at = V.reject, ot = "￿", st = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", ct = "String expected.", lt = "__dbnames", ut = "readonly", dt = "readwrite";
		function ft(e, t) {
			return e ? t ? function() {
				return e.apply(this, arguments) && t.apply(this, arguments);
			} : e : t;
		}
		var pt = {
			type: 3,
			lower: -1 / 0,
			lowerOpen: !1,
			upper: [[]],
			upperOpen: !1
		};
		function mt(e) {
			return typeof e != "string" || /\./.test(e) ? function(e) {
				return e;
			} : function(t) {
				return t[e] === void 0 && e in t && delete (t = te(t))[e], t;
			};
		}
		function ht() {
			throw F.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
		}
		function G(e, t) {
			try {
				var n = gt(e), r = gt(t);
				if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r === "Date" ? -1 : NaN;
				switch (n) {
					case "number":
					case "Date":
					case "string": return t < e ? 1 : e < t ? -1 : 0;
					case "binary":
						for (var i = _t(e), a = _t(t), o = i.length, s = a.length, c = o < s ? o : s, l = 0; l < c; ++l) if (i[l] !== a[l]) return i[l] < a[l] ? -1 : 1;
						return o === s ? 0 : o < s ? -1 : 1;
					case "Array":
						for (var u = e, d = t, f = u.length, p = d.length, m = f < p ? f : p, h = 0; h < m; ++h) {
							var g = G(u[h], d[h]);
							if (g !== 0) return g;
						}
						return f === p ? 0 : f < p ? -1 : 1;
				}
			} catch {}
			return NaN;
		}
		function gt(e) {
			var t = typeof e;
			return t == "object" && (ArrayBuffer.isView(e) || (t = re(e)) === "ArrayBuffer") ? "binary" : t;
		}
		function _t(e) {
			return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
		}
		function vt(e, t, n) {
			var r = e.schema.yProps;
			return r ? (t && 0 < n.numFailures && (t = t.filter(function(e, t) {
				return !n.failures[t];
			})), Promise.all(r.map(function(n) {
				return n = n.updatesTable, t ? e.db.table(n).where("k").anyOf(t).delete() : e.db.table(n).clear();
			})).then(function() {
				return n;
			})) : n;
		}
		bt.prototype.execute = function(e) {
			var t = this["@@propmod"];
			if (t.add !== void 0) {
				var r = t.add;
				if (a(r)) return n(n([], a(e) ? e : [], !0), r, !0).sort();
				if (typeof r == "number") return (Number(e) || 0) + r;
				if (typeof r == "bigint") try {
					return BigInt(e) + r;
				} catch {
					return BigInt(0) + r;
				}
				throw TypeError(`Invalid term ${r}`);
			}
			if (t.remove !== void 0) {
				var i = t.remove;
				if (a(i)) return a(e) ? e.filter(function(e) {
					return !i.includes(e);
				}).sort() : [];
				if (typeof i == "number") return Number(e) - i;
				if (typeof i == "bigint") try {
					return BigInt(e) - i;
				} catch {
					return BigInt(0) - i;
				}
				throw TypeError(`Invalid subtrahend ${i}`);
			}
			return r = (r = t.replacePrefix)?.[0], r && typeof e == "string" && e.startsWith(r) ? t.replacePrefix[1] + e.substring(r.length) : e;
		};
		var yt = bt;
		function bt(e) {
			this["@@propmod"] = e;
		}
		function xt(e, t) {
			for (var n = i(t), r = n.length, a = !1, o = 0; o < r; ++o) {
				var s = n[o], c = t[s], l = b(e, s);
				c instanceof yt ? (x(e, s, c.execute(l)), a = !0) : l !== c && (x(e, s, c), a = !0);
			}
			return a;
		}
		K.prototype._trans = function(e, t, n) {
			var r = this._tx || B.trans, i = this.name, a = ye && typeof console < "u" && console.createTask && console.createTask(`Dexie: ${e === "readonly" ? "read" : "write"} ${this.name}`);
			function o(e, n, r) {
				if (r.schema[i]) return t(r.idbtrans, r);
				throw new F.NotFound("Table " + i + " not part of transaction");
			}
			var s = Be();
			try {
				var c = r && r.db._novip === this.db._novip ? r === B.trans ? r._promise(e, o, n) : Xe(function() {
					return r._promise(e, o, n);
				}, {
					trans: r,
					transless: B.transless || B
				}) : function e(t, n, r, i) {
					if (t.idbdb && (t._state.openComplete || B.letThrough || t._vip)) {
						var a = t._createTransaction(n, r, t._dbSchema);
						try {
							a.create(), t._state.PR1398_maxLoop = 3;
						} catch (a) {
							return a.name === P.InvalidState && t.isOpen() && 0 < --t._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), t.close({ disableAutoOpen: !1 }), t.open().then(function() {
								return e(t, n, r, i);
							})) : at(a);
						}
						return a._promise(n, function(e, t) {
							return Xe(function() {
								return B.trans = a, i(e, t, a);
							});
						}).then(function(e) {
							if (n === "readwrite") try {
								a.idbtrans.commit();
							} catch {}
							return n === "readonly" ? e : a._completion.then(function() {
								return e;
							});
						});
					}
					if (t._state.openComplete) return at(new F.DatabaseClosed(t._state.dbOpenError));
					if (!t._state.isBeingOpened) {
						if (!t._state.autoOpen) return at(new F.DatabaseClosed());
						t.open().catch(I);
					}
					return t._state.dbReadyPromise.then(function() {
						return e(t, n, r, i);
					});
				}(this.db, e, [this.name], o);
				return a && (c._consoleTask = a, c = c.catch(function(e) {
					return console.trace(e), at(e);
				})), c;
			} finally {
				s && Ve();
			}
		}, K.prototype.get = function(e, t) {
			var n = this;
			return e && e.constructor === Object ? this.where(e).first(t) : e == null ? at(new F.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(t) {
				return n.core.get({
					trans: t,
					key: e
				}).then(function(e) {
					return n.hook.reading.fire(e);
				});
			}).then(t);
		}, K.prototype.where = function(e) {
			if (typeof e == "string") return new this.db.WhereClause(this, e);
			if (a(e)) return new this.db.WhereClause(this, `[${e.join("+")}]`);
			var t = i(e);
			if (t.length === 1) return this.where(t[0]).equals(e[t[0]]);
			var n = this.schema.indexes.concat(this.schema.primKey).filter(function(e) {
				if (e.compound && t.every(function(t) {
					return 0 <= e.keyPath.indexOf(t);
				})) {
					for (var n = 0; n < t.length; ++n) if (t.indexOf(e.keyPath[n]) === -1) return !1;
					return !0;
				}
				return !1;
			}).sort(function(e, t) {
				return e.keyPath.length - t.keyPath.length;
			})[0];
			if (n && this.db._maxKey !== ot) return s = n.keyPath.slice(0, t.length), this.where(s).equals(s.map(function(t) {
				return e[t];
			}));
			!n && ye && console.warn(`The query ${JSON.stringify(e)} on ${this.name} would benefit from a compound index [${t.join("+")}]`);
			var r = this.schema.idxByName;
			function o(e, t) {
				return G(e, t) === 0;
			}
			var s = t.reduce(function(t, n) {
				var i = t[0], t = t[1], s = r[n], c = e[n];
				return [i || s, i || !s ? ft(t, s && s.multi ? function(e) {
					return e = b(e, n), a(e) && e.some(function(e) {
						return o(c, e);
					});
				} : function(e) {
					return o(c, b(e, n));
				}) : t];
			}, [null, null]), c = s[0], s = s[1];
			return c ? this.where(c.name).equals(e[c.keyPath]).filter(s) : n ? this.filter(s) : this.where(t).equals("");
		}, K.prototype.filter = function(e) {
			return this.toCollection().and(e);
		}, K.prototype.count = function(e) {
			return this.toCollection().count(e);
		}, K.prototype.offset = function(e) {
			return this.toCollection().offset(e);
		}, K.prototype.limit = function(e) {
			return this.toCollection().limit(e);
		}, K.prototype.each = function(e) {
			return this.toCollection().each(e);
		}, K.prototype.toArray = function(e) {
			return this.toCollection().toArray(e);
		}, K.prototype.toCollection = function() {
			return new this.db.Collection(new this.db.WhereClause(this));
		}, K.prototype.orderBy = function(e) {
			return new this.db.Collection(new this.db.WhereClause(this, a(e) ? `[${e.join("+")}]` : e));
		}, K.prototype.reverse = function() {
			return this.toCollection().reverse();
		}, K.prototype.mapToClass = function(t) {
			for (var n = this.db, r = this.name, i = ((this.schema.mappedClass = t).prototype instanceof ht && (t = ((t) => {
				var i = s, a = t;
				if (typeof a != "function" && a !== null) throw TypeError("Class extends value " + String(a) + " is not a constructor or null");
				function o() {
					this.constructor = i;
				}
				function s() {
					return t !== null && t.apply(this, arguments) || this;
				}
				return e(i, a), i.prototype = a === null ? Object.create(a) : (o.prototype = a.prototype, new o()), Object.defineProperty(s.prototype, "db", {
					get: function() {
						return n;
					},
					enumerable: !1,
					configurable: !0
				}), s.prototype.table = function() {
					return r;
				}, s;
			})(t)), /* @__PURE__ */ new Set()), a = t.prototype; a; a = s(a)) Object.getOwnPropertyNames(a).forEach(function(e) {
				return i.add(e);
			});
			function o(e) {
				if (!e) return e;
				var n, r = Object.create(t.prototype);
				for (n in e) if (!i.has(n)) try {
					r[n] = e[n];
				} catch {}
				return r;
			}
			return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = o, this.hook("reading", o), t;
		}, K.prototype.defineClass = function() {
			return this.mapToClass(function(e) {
				o(this, e);
			});
		}, K.prototype.add = function(e, t) {
			var n = this, r = this.schema.primKey, i = r.auto, a = r.keyPath, o = e;
			return a && i && (o = mt(a)(e)), this._trans("readwrite", function(e) {
				return n.core.mutate({
					trans: e,
					type: "add",
					keys: t == null ? null : [t],
					values: [o]
				});
			}).then(function(e) {
				return e.numFailures ? V.reject(e.failures[0]) : e.lastResult;
			}).then(function(t) {
				if (a) try {
					x(e, a, t);
				} catch {}
				return t;
			});
		}, K.prototype.upsert = function(e, t) {
			var n = this, r = this.schema.primKey.keyPath;
			return this._trans("readwrite", function(i) {
				return n.core.get({
					trans: i,
					key: e
				}).then(function(a) {
					var o = a ?? {};
					return xt(o, t), r && x(o, r, e), n.core.mutate({
						trans: i,
						type: "put",
						values: [o],
						keys: [e],
						upsert: !0,
						updates: {
							keys: [e],
							changeSpecs: [t]
						}
					}).then(function(e) {
						return e.numFailures ? V.reject(e.failures[0]) : !!a;
					});
				});
			});
		}, K.prototype.update = function(e, t) {
			return typeof e != "object" || a(e) ? this.where(":id").equals(e).modify(t) : (e = b(e, this.schema.primKey.keyPath)) === void 0 ? at(new F.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(t);
		}, K.prototype.put = function(e, t) {
			var n = this, r = this.schema.primKey, i = r.auto, a = r.keyPath, o = e;
			return a && i && (o = mt(a)(e)), this._trans("readwrite", function(e) {
				return n.core.mutate({
					trans: e,
					type: "put",
					values: [o],
					keys: t == null ? null : [t]
				});
			}).then(function(e) {
				return e.numFailures ? V.reject(e.failures[0]) : e.lastResult;
			}).then(function(t) {
				if (a) try {
					x(e, a, t);
				} catch {}
				return t;
			});
		}, K.prototype.delete = function(e) {
			var t = this;
			return this._trans("readwrite", function(n) {
				return t.core.mutate({
					trans: n,
					type: "delete",
					keys: [e]
				}).then(function(n) {
					return vt(t, [e], n);
				}).then(function(e) {
					return e.numFailures ? V.reject(e.failures[0]) : void 0;
				});
			});
		}, K.prototype.clear = function() {
			var e = this;
			return this._trans("readwrite", function(t) {
				return e.core.mutate({
					trans: t,
					type: "deleteRange",
					range: pt
				}).then(function(t) {
					return vt(e, null, t);
				});
			}).then(function(e) {
				return e.numFailures ? V.reject(e.failures[0]) : void 0;
			});
		}, K.prototype.bulkGet = function(e) {
			var t = this;
			return this._trans("readonly", function(n) {
				return t.core.getMany({
					keys: e,
					trans: n
				}).then(function(e) {
					return e.map(function(e) {
						return t.hook.reading.fire(e);
					});
				});
			});
		}, K.prototype.bulkAdd = function(e, t, n) {
			var r = this, i = Array.isArray(t) ? t : void 0, a = (n ||= i ? void 0 : t) ? n.allKeys : void 0;
			return this._trans("readwrite", function(t) {
				var n = r.schema.primKey, o = n.auto, n = n.keyPath;
				if (n && i) throw new F.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
				if (i && i.length !== e.length) throw new F.InvalidArgument("Arguments objects and keys must have the same length");
				var s = e.length, o = n && o ? e.map(mt(n)) : e;
				return r.core.mutate({
					trans: t,
					type: "add",
					keys: i,
					values: o,
					wantResults: a
				}).then(function(e) {
					var t = e.numFailures, n = e.failures;
					if (t === 0) return a ? e.results : e.lastResult;
					throw new ce(`${r.name}.bulkAdd(): ${t} of ${s} operations failed`, n);
				});
			});
		}, K.prototype.bulkPut = function(e, t, n) {
			var r = this, i = Array.isArray(t) ? t : void 0, a = (n ||= i ? void 0 : t) ? n.allKeys : void 0;
			return this._trans("readwrite", function(t) {
				var n = r.schema.primKey, o = n.auto, n = n.keyPath;
				if (n && i) throw new F.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
				if (i && i.length !== e.length) throw new F.InvalidArgument("Arguments objects and keys must have the same length");
				var s = e.length, o = n && o ? e.map(mt(n)) : e;
				return r.core.mutate({
					trans: t,
					type: "put",
					keys: i,
					values: o,
					wantResults: a
				}).then(function(e) {
					var t = e.numFailures, n = e.failures;
					if (t === 0) return a ? e.results : e.lastResult;
					throw new ce(`${r.name}.bulkPut(): ${t} of ${s} operations failed`, n);
				});
			});
		}, K.prototype.bulkUpdate = function(e) {
			var t = this, n = this.core, r = e.map(function(e) {
				return e.key;
			}), i = e.map(function(e) {
				return e.changes;
			}), a = [];
			return this._trans("readwrite", function(o) {
				return n.getMany({
					trans: o,
					keys: r,
					cache: "clone"
				}).then(function(s) {
					var c = [], l = [], u = (e.forEach(function(e, n) {
						var r = e.key, i = e.changes, o = s[n];
						if (o) {
							for (var u = 0, d = Object.keys(i); u < d.length; u++) {
								var f = d[u], p = i[f];
								if (f === t.schema.primKey.keyPath) {
									if (G(p, r) !== 0) throw new F.Constraint("Cannot update primary key in bulkUpdate()");
								} else x(o, f, p);
							}
							a.push(n), c.push(r), l.push(o);
						}
					}), c.length);
					return n.mutate({
						trans: o,
						type: "put",
						keys: c,
						values: l,
						updates: {
							keys: r,
							changeSpecs: i
						}
					}).then(function(e) {
						var n = e.numFailures, r = e.failures;
						if (n === 0) return u;
						for (var i = 0, o = Object.keys(r); i < o.length; i++) {
							var s, c = o[i], l = a[Number(c)];
							l != null && (s = r[c], delete r[c], r[l] = s);
						}
						throw new ce(`${t.name}.bulkUpdate(): ${n} of ${u} operations failed`, r);
					});
				});
			});
		}, K.prototype.bulkDelete = function(e) {
			var t = this, n = e.length;
			return this._trans("readwrite", function(n) {
				return t.core.mutate({
					trans: n,
					type: "delete",
					keys: e
				}).then(function(n) {
					return vt(t, e, n);
				});
			}).then(function(e) {
				var r = e.numFailures, i = e.failures;
				if (r === 0) return e.lastResult;
				throw new ce(`${t.name}.bulkDelete(): ${r} of ${n} operations failed`, i);
			});
		};
		var St = K;
		function K() {}
		function Ct(e) {
			function t(t, r) {
				if (r) {
					for (var i = arguments.length, a = Array(i - 1); --i;) a[i - 1] = arguments[i];
					return n[t].subscribe.apply(null, a), e;
				}
				if (typeof t == "string") return n[t];
			}
			var n = {};
			t.addEventType = s;
			for (var r = 1, o = arguments.length; r < o; ++r) s(arguments[r]);
			return t;
			function s(e, r, o) {
				var c, l;
				if (typeof e != "object") return r ||= _e, l = {
					subscribers: [],
					fire: o ||= I,
					subscribe: function(e) {
						l.subscribers.indexOf(e) === -1 && (l.subscribers.push(e), l.fire = r(l.fire, e));
					},
					unsubscribe: function(e) {
						l.subscribers = l.subscribers.filter(function(t) {
							return t !== e;
						}), l.fire = l.subscribers.reduce(r, o);
					}
				}, n[e] = t[e] = l;
				i(c = e).forEach(function(e) {
					var t = c[e];
					if (a(t)) s(e, c[e][0], c[e][1]);
					else {
						if (t !== "asap") throw new F.InvalidArgument("Invalid event config");
						var n = s(e, de, function() {
							for (var e = arguments.length, t = Array(e); e--;) t[e] = arguments[e];
							n.subscribers.forEach(function(e) {
								y(function() {
									e.apply(null, t);
								});
							});
						});
					}
				});
			}
		}
		function wt(e, t) {
			return p(t).from({ prototype: e }), t;
		}
		function Tt(e, t) {
			return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter);
		}
		function Et(e, t) {
			e.filter = ft(e.filter, t);
		}
		function Dt(e, t, n) {
			var r = e.replayFilter;
			e.replayFilter = r ? function() {
				return ft(r(), t());
			} : t, e.justLimit = n && !r;
		}
		function Ot(e, t) {
			if (e.isPrimKey) return t.primaryKey;
			var n = t.getIndexByKeyPath(e.index);
			if (n) return n;
			throw new F.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
		}
		function kt(e, t, n) {
			var r = Ot(e, t.schema);
			return t.openCursor({
				trans: n,
				values: !e.keysOnly,
				reverse: e.dir === "prev",
				unique: !!e.unique,
				query: {
					index: r,
					range: e.range
				}
			});
		}
		function At(e, t, n, r) {
			var i, a, o = e.replayFilter ? ft(e.filter, e.replayFilter()) : e.filter;
			return e.or ? (i = {}, a = function(e, n, r) {
				var a, s;
				o && !o(n, r, function(e) {
					return n.stop(e);
				}, function(e) {
					return n.fail(e);
				}) || ((s = "" + (a = n.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(a)), l(i, s)) || (i[s] = !0, t(e, n, r));
			}, Promise.all([e.or._iterate(a, n), jt(kt(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)])) : jt(kt(e, r, n), ft(e.algorithm, o), t, !e.keysOnly && e.valueMapper);
		}
		function jt(e, t, n, r) {
			var i = U(r ? function(e, t, i) {
				return n(r(e), t, i);
			} : n);
			return e.then(function(e) {
				if (e) return e.start(function() {
					var n = function() {
						return e.continue();
					};
					t && !t(e, function(e) {
						return n = e;
					}, function(t) {
						e.stop(t), n = I;
					}, function(t) {
						e.fail(t), n = I;
					}) || i(e.value, e, function(e) {
						return n = e;
					}), n();
				});
			});
		}
		q.prototype._read = function(e, t) {
			var n = this._ctx;
			return n.error ? n.table._trans(null, at.bind(null, n.error)) : n.table._trans("readonly", e).then(t);
		}, q.prototype._write = function(e) {
			var t = this._ctx;
			return t.error ? t.table._trans(null, at.bind(null, t.error)) : t.table._trans("readwrite", e, "locked");
		}, q.prototype._addAlgorithm = function(e) {
			var t = this._ctx;
			t.algorithm = ft(t.algorithm, e);
		}, q.prototype._iterate = function(e, t) {
			return At(this._ctx, e, t, this._ctx.table.core);
		}, q.prototype.clone = function(e) {
			var t = Object.create(this.constructor.prototype), n = Object.create(this._ctx);
			return e && o(n, e), t._ctx = n, t;
		}, q.prototype.raw = function() {
			return this._ctx.valueMapper = null, this;
		}, q.prototype.each = function(e) {
			var t = this._ctx;
			return this._read(function(n) {
				return At(t, e, n, t.table.core);
			});
		}, q.prototype.count = function(e) {
			var t = this;
			return this._read(function(e) {
				var n, r = t._ctx, i = r.table.core;
				return Tt(r, !0) ? i.count({
					trans: e,
					query: {
						index: Ot(r, i.schema),
						range: r.range
					}
				}).then(function(e) {
					return Math.min(e, r.limit);
				}) : (n = 0, At(r, function() {
					return ++n, !1;
				}, e, i).then(function() {
					return n;
				}));
			}).then(e);
		}, q.prototype.sortBy = function(e, t) {
			var n = e.split(".").reverse(), r = n[0], i = n.length - 1;
			function a(e, t) {
				return t ? a(e[n[t]], t - 1) : e[r];
			}
			var o = this._ctx.dir === "next" ? 1 : -1;
			function s(e, t) {
				return G(a(e, i), a(t, i)) * o;
			}
			return this.toArray(function(e) {
				return e.slice().sort(s);
			}).then(t);
		}, q.prototype.toArray = function(e) {
			var t = this;
			return this._read(function(e) {
				var n, r, i, a = t._ctx;
				return Tt(a, !0) && 0 < a.limit ? (n = a.valueMapper, r = Ot(a, a.table.core.schema), a.table.core.query({
					trans: e,
					limit: a.limit,
					values: !0,
					direction: a.dir === "prev" ? "prev" : void 0,
					query: {
						index: r,
						range: a.range
					}
				}).then(function(e) {
					return e = e.result, n ? e.map(n) : e;
				})) : (i = [], At(a, function(e) {
					return i.push(e);
				}, e, a.table.core).then(function() {
					return i;
				}));
			}, e);
		}, q.prototype.offset = function(e) {
			var t = this._ctx;
			return e <= 0 || (t.offset += e, Tt(t) ? Dt(t, function() {
				var t = e;
				return function(e, n) {
					return t === 0 || (t === 1 ? --t : n(function() {
						e.advance(t), t = 0;
					}), !1);
				};
			}) : Dt(t, function() {
				var t = e;
				return function() {
					return --t < 0;
				};
			})), this;
		}, q.prototype.limit = function(e) {
			return this._ctx.limit = Math.min(this._ctx.limit, e), Dt(this._ctx, function() {
				var t = e;
				return function(e, n, r) {
					return --t <= 0 && n(r), 0 <= t;
				};
			}, !0), this;
		}, q.prototype.until = function(e, t) {
			return Et(this._ctx, function(n, r, i) {
				return !e(n.value) || (r(i), t);
			}), this;
		}, q.prototype.first = function(e) {
			return this.limit(1).toArray(function(e) {
				return e[0];
			}).then(e);
		}, q.prototype.last = function(e) {
			return this.reverse().first(e);
		}, q.prototype.filter = function(e) {
			var t;
			return Et(this._ctx, function(t) {
				return e(t.value);
			}), (t = this._ctx).isMatch = ft(t.isMatch, e), this;
		}, q.prototype.and = function(e) {
			return this.filter(e);
		}, q.prototype.or = function(e) {
			return new this.db.WhereClause(this._ctx.table, e, this);
		}, q.prototype.reverse = function() {
			return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
		}, q.prototype.desc = function() {
			return this.reverse();
		}, q.prototype.eachKey = function(e) {
			var t = this._ctx;
			return t.keysOnly = !t.isMatch, this.each(function(t, n) {
				e(n.key, n);
			});
		}, q.prototype.eachUniqueKey = function(e) {
			return this._ctx.unique = "unique", this.eachKey(e);
		}, q.prototype.eachPrimaryKey = function(e) {
			var t = this._ctx;
			return t.keysOnly = !t.isMatch, this.each(function(t, n) {
				e(n.primaryKey, n);
			});
		}, q.prototype.keys = function(e) {
			var t = this._ctx, n = (t.keysOnly = !t.isMatch, []);
			return this.each(function(e, t) {
				n.push(t.key);
			}).then(function() {
				return n;
			}).then(e);
		}, q.prototype.primaryKeys = function(e) {
			var t = this._ctx;
			if (Tt(t, !0) && 0 < t.limit) return this._read(function(e) {
				var n = Ot(t, t.table.core.schema);
				return t.table.core.query({
					trans: e,
					values: !1,
					limit: t.limit,
					direction: t.dir === "prev" ? "prev" : void 0,
					query: {
						index: n,
						range: t.range
					}
				});
			}).then(function(e) {
				return e.result;
			}).then(e);
			t.keysOnly = !t.isMatch;
			var n = [];
			return this.each(function(e, t) {
				n.push(t.primaryKey);
			}).then(function() {
				return n;
			}).then(e);
		}, q.prototype.uniqueKeys = function(e) {
			return this._ctx.unique = "unique", this.keys(e);
		}, q.prototype.firstKey = function(e) {
			return this.limit(1).keys(function(e) {
				return e[0];
			}).then(e);
		}, q.prototype.lastKey = function(e) {
			return this.reverse().firstKey(e);
		}, q.prototype.distinct = function() {
			var e, t = this._ctx, t = t.index && t.table.schema.idxByName[t.index];
			return t && t.multi && (e = {}, Et(this._ctx, function(t) {
				var t = t.primaryKey.toString(), n = l(e, t);
				return e[t] = !0, !n;
			})), this;
		}, q.prototype.modify = function(e) {
			var t = this, n = this._ctx;
			return this._write(function(r) {
				function a(e, t) {
					var n = t.failures;
					p += e - t.numFailures;
					for (var r = 0, a = i(n); r < a.length; r++) {
						var o = a[r];
						f.push(n[o]);
					}
				}
				var o = typeof e == "function" ? e : function(t) {
					return xt(t, e);
				}, s = n.table.core, c = s.schema.primaryKey, l = c.outbound, u = c.extractKey, d = 200, c = t.db._options.modifyChunkSize, f = (c && (d = typeof c == "object" ? c[s.name] || c["*"] || 200 : c), []), p = 0, m = [], h = e === Nt;
				return t.clone().primaryKeys().then(function(t) {
					function i(f) {
						var p = Math.min(d, t.length - f), m = t.slice(f, f + p);
						return (h ? Promise.resolve([]) : s.getMany({
							trans: r,
							keys: m,
							cache: "immutable"
						})).then(function(g) {
							var _ = [], v = [], y = l ? [] : null, b = h ? m : [];
							if (!h) for (var x = 0; x < p; ++x) {
								var S = g[x], C = {
									value: te(S),
									primKey: t[f + x]
								};
								!1 !== o.call(C, C.value, C) && (C.value == null ? b.push(t[f + x]) : l || G(u(S), u(C.value)) === 0 ? (v.push(C.value), l && y.push(t[f + x])) : (b.push(t[f + x]), _.push(C.value)));
							}
							return Promise.resolve(0 < _.length && s.mutate({
								trans: r,
								type: "add",
								values: _
							}).then(function(e) {
								for (var t in e.failures) b.splice(parseInt(t), 1);
								a(_.length, e);
							})).then(function() {
								return (0 < v.length || c && typeof e == "object") && s.mutate({
									trans: r,
									type: "put",
									keys: y,
									values: v,
									criteria: c,
									changeSpec: typeof e != "function" && e,
									isAdditionalChunk: 0 < f
								}).then(function(e) {
									return a(v.length, e);
								});
							}).then(function() {
								return (0 < b.length || c && h) && s.mutate({
									trans: r,
									type: "delete",
									keys: b,
									criteria: c,
									isAdditionalChunk: 0 < f
								}).then(function(e) {
									return vt(n.table, b, e);
								}).then(function(e) {
									return a(b.length, e);
								});
							}).then(function() {
								return t.length > f + p && i(f + d);
							});
						});
					}
					var c = Tt(n) && n.limit === 1 / 0 && (typeof e != "function" || h) && {
						index: n.index,
						range: n.range
					};
					return i(0).then(function() {
						if (0 < f.length) throw new N("Error modifying one or more objects", f, p, m);
						return t.length;
					});
				});
			});
		}, q.prototype.delete = function() {
			var e = this._ctx, t = e.range;
			return !Tt(e) || e.table.schema.yProps || !e.isPrimKey && t.type !== 3 ? this.modify(Nt) : this._write(function(n) {
				var r = e.table.core.schema.primaryKey, i = t;
				return e.table.core.count({
					trans: n,
					query: {
						index: r,
						range: i
					}
				}).then(function(t) {
					return e.table.core.mutate({
						trans: n,
						type: "deleteRange",
						range: i
					}).then(function(e) {
						var n = e.failures, e = e.numFailures;
						if (e) throw new N("Could not delete some values", Object.keys(n).map(function(e) {
							return n[e];
						}), t - e);
						return t - e;
					});
				});
			});
		};
		var Mt = q;
		function q() {}
		var Nt = function(e, t) {
			return t.value = null;
		};
		function Pt(e, t) {
			return e < t ? -1 : e === t ? 0 : 1;
		}
		function Ft(e, t) {
			return t < e ? -1 : e === t ? 0 : 1;
		}
		function It(e, t, n) {
			return e = e instanceof Vt ? new e.Collection(e) : e, e._ctx.error = new (n || TypeError)(t), e;
		}
		function Lt(e) {
			return new e.Collection(e, function() {
				return Bt("");
			}).limit(0);
		}
		function Rt(e, t, n, r) {
			var i, a, o, s, c, l, u, d = n.length;
			if (!n.every(function(e) {
				return typeof e == "string";
			})) return It(e, ct);
			function f(e) {
				i = e === "next" ? function(e) {
					return e.toUpperCase();
				} : function(e) {
					return e.toLowerCase();
				}, a = e === "next" ? function(e) {
					return e.toLowerCase();
				} : function(e) {
					return e.toUpperCase();
				}, o = e === "next" ? Pt : Ft;
				var t = n.map(function(e) {
					return {
						lower: a(e),
						upper: i(e)
					};
				}).sort(function(e, t) {
					return o(e.lower, t.lower);
				});
				s = t.map(function(e) {
					return e.upper;
				}), c = t.map(function(e) {
					return e.lower;
				}), u = (l = e) === "next" ? "" : r;
			}
			f("next");
			var e = new e.Collection(e, function() {
				return zt(s[0], c[d - 1] + r);
			}), p = (e._ondirectionchange = function(e) {
				f(e);
			}, 0);
			return e._addAlgorithm(function(e, n, r) {
				var i = e.key;
				if (typeof i == "string") {
					var f = a(i);
					if (t(f, c, p)) return !0;
					for (var m = null, h = p; h < d; ++h) {
						var g = ((e, t, n, r, i, a) => {
							for (var o = Math.min(e.length, r.length), s = -1, c = 0; c < o; ++c) {
								var l = t[c];
								if (l !== r[c]) return i(e[c], n[c]) < 0 ? e.substr(0, c) + n[c] + n.substr(c + 1) : i(e[c], r[c]) < 0 ? e.substr(0, c) + r[c] + n.substr(c + 1) : 0 <= s ? e.substr(0, s) + t[s] + n.substr(s + 1) : null;
								i(e[c], l) < 0 && (s = c);
							}
							return o < r.length && a === "next" ? e + n.substr(e.length) : o < e.length && a === "prev" ? e.substr(0, n.length) : s < 0 ? null : e.substr(0, s) + r[s] + n.substr(s + 1);
						})(i, f, s[h], c[h], o, l);
						g === null && m === null ? p = h + 1 : (m === null || 0 < o(m, g)) && (m = g);
					}
					n(m === null ? r : function() {
						e.continue(m + u);
					});
				}
				return !1;
			}), e;
		}
		function zt(e, t, n, r) {
			return {
				type: 2,
				lower: e,
				upper: t,
				lowerOpen: n,
				upperOpen: r
			};
		}
		function Bt(e) {
			return {
				type: 1,
				lower: e,
				upper: e
			};
		}
		Object.defineProperty(Ht.prototype, "Collection", {
			get: function() {
				return this._ctx.table.db.Collection;
			},
			enumerable: !1,
			configurable: !0
		}), Ht.prototype.between = function(e, t, n, r) {
			n = !1 !== n, r = !0 === r;
			try {
				return 0 < this._cmp(e, t) || this._cmp(e, t) === 0 && (n || r) && (!n || !r) ? Lt(this) : new this.Collection(this, function() {
					return zt(e, t, !n, !r);
				});
			} catch {
				return It(this, st);
			}
		}, Ht.prototype.equals = function(e) {
			return e == null ? It(this, st) : new this.Collection(this, function() {
				return Bt(e);
			});
		}, Ht.prototype.above = function(e) {
			return e == null ? It(this, st) : new this.Collection(this, function() {
				return zt(e, void 0, !0);
			});
		}, Ht.prototype.aboveOrEqual = function(e) {
			return e == null ? It(this, st) : new this.Collection(this, function() {
				return zt(e, void 0, !1);
			});
		}, Ht.prototype.below = function(e) {
			return e == null ? It(this, st) : new this.Collection(this, function() {
				return zt(void 0, e, !1, !0);
			});
		}, Ht.prototype.belowOrEqual = function(e) {
			return e == null ? It(this, st) : new this.Collection(this, function() {
				return zt(void 0, e);
			});
		}, Ht.prototype.startsWith = function(e) {
			return typeof e == "string" ? this.between(e, e + ot, !0, !0) : It(this, ct);
		}, Ht.prototype.startsWithIgnoreCase = function(e) {
			return e === "" ? this.startsWith(e) : Rt(this, function(e, t) {
				return e.indexOf(t[0]) === 0;
			}, [e], ot);
		}, Ht.prototype.equalsIgnoreCase = function(e) {
			return Rt(this, function(e, t) {
				return e === t[0];
			}, [e], "");
		}, Ht.prototype.anyOfIgnoreCase = function() {
			var e = k.apply(ae, arguments);
			return e.length === 0 ? Lt(this) : Rt(this, function(e, t) {
				return t.indexOf(e) !== -1;
			}, e, "");
		}, Ht.prototype.startsWithAnyOfIgnoreCase = function() {
			var e = k.apply(ae, arguments);
			return e.length === 0 ? Lt(this) : Rt(this, function(e, t) {
				return t.some(function(t) {
					return e.indexOf(t) === 0;
				});
			}, e, ot);
		}, Ht.prototype.anyOf = function() {
			var e, t, n = this, r = k.apply(ae, arguments), i = this._cmp;
			try {
				r.sort(i);
			} catch {
				return It(this, st);
			}
			return r.length === 0 ? Lt(this) : ((e = new this.Collection(this, function() {
				return zt(r[0], r[r.length - 1]);
			}))._ondirectionchange = function(e) {
				i = e === "next" ? n._ascending : n._descending, r.sort(i);
			}, t = 0, e._addAlgorithm(function(e, n, a) {
				for (var o = e.key; 0 < i(o, r[t]);) if (++t === r.length) return n(a), !1;
				return i(o, r[t]) === 0 || (n(function() {
					e.continue(r[t]);
				}), !1);
			}), e);
		}, Ht.prototype.notEqual = function(e) {
			return this.inAnyRange([[-1 / 0, e], [e, this.db._maxKey]], {
				includeLowers: !1,
				includeUppers: !1
			});
		}, Ht.prototype.noneOf = function() {
			var e = k.apply(ae, arguments);
			if (e.length === 0) return new this.Collection(this);
			try {
				e.sort(this._ascending);
			} catch {
				return It(this, st);
			}
			var t = e.reduce(function(e, t) {
				return e ? e.concat([[e[e.length - 1][1], t]]) : [[-1 / 0, t]];
			}, null);
			return t.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(t, {
				includeLowers: !1,
				includeUppers: !1
			});
		}, Ht.prototype.inAnyRange = function(e, t) {
			var n = this, r = this._cmp, i = this._ascending, a = this._descending, o = this._min, s = this._max;
			if (e.length === 0) return Lt(this);
			if (!e.every(function(e) {
				return e[0] !== void 0 && e[1] !== void 0 && i(e[0], e[1]) <= 0;
			})) return It(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", F.InvalidArgument);
			var c = !t || !1 !== t.includeLowers, l = t && !0 === t.includeUppers, u, d = i;
			function f(e, t) {
				return d(e[0], t[0]);
			}
			try {
				(u = e.reduce(function(e, t) {
					for (var n = 0, i = e.length; n < i; ++n) {
						var a = e[n];
						if (r(t[0], a[1]) < 0 && 0 < r(t[1], a[0])) {
							a[0] = o(a[0], t[0]), a[1] = s(a[1], t[1]);
							break;
						}
					}
					return n === i && e.push(t), e;
				}, [])).sort(f);
			} catch {
				return It(this, st);
			}
			var p = 0, m = l ? function(e) {
				return 0 < i(e, u[p][1]);
			} : function(e) {
				return 0 <= i(e, u[p][1]);
			}, h = c ? function(e) {
				return 0 < a(e, u[p][0]);
			} : function(e) {
				return 0 <= a(e, u[p][0]);
			}, g = m, t = new this.Collection(this, function() {
				return zt(u[0][0], u[u.length - 1][1], !c, !l);
			});
			return t._ondirectionchange = function(e) {
				d = e === "next" ? (g = m, i) : (g = h, a), u.sort(f);
			}, t._addAlgorithm(function(e, t, r) {
				for (var a, o = e.key; g(o);) if (++p === u.length) return t(r), !1;
				return !m(a = o) && !h(a) || (n._cmp(o, u[p][1]) === 0 || n._cmp(o, u[p][0]) === 0 || t(function() {
					d === i ? e.continue(u[p][0]) : e.continue(u[p][1]);
				}), !1);
			}), t;
		}, Ht.prototype.startsWithAnyOf = function() {
			var e = k.apply(ae, arguments);
			return e.every(function(e) {
				return typeof e == "string";
			}) ? e.length === 0 ? Lt(this) : this.inAnyRange(e.map(function(e) {
				return [e, e + ot];
			})) : It(this, "startsWithAnyOf() only works with strings");
		};
		var Vt = Ht;
		function Ht() {}
		function Ut(e) {
			return U(function(t) {
				return Wt(t), e(t.target.error), !1;
			});
		}
		function Wt(e) {
			e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault();
		}
		var Gt = "storagemutated", Kt = "x-storagemutated-1", qt = Ct(null, Gt), Jt = (Yt.prototype._lock = function() {
			return v(!B.global), ++this._reculock, this._reculock !== 1 || B.global || (B.lockOwnerFor = this), this;
		}, Yt.prototype._unlock = function() {
			if (v(!B.global), --this._reculock == 0) for (B.global || (B.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked();) {
				var e = this._blockedFuncs.shift();
				try {
					nt(e[1], e[0]);
				} catch {}
			}
			return this;
		}, Yt.prototype._locked = function() {
			return this._reculock && B.lockOwnerFor !== this;
		}, Yt.prototype.create = function(e) {
			var t = this;
			if (this.mode) {
				var n = this.db.idbdb, r = this.db._state.dbOpenError;
				if (v(!this.idbtrans), !e && !n) switch (r && r.name) {
					case "DatabaseClosedError": throw new F.DatabaseClosed(r);
					case "MissingAPIError": throw new F.MissingAPI(r.message, r);
					default: throw new F.OpenFailed(r);
				}
				if (!this.active) throw new F.TransactionInactive();
				v(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || n).transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability })).onerror = U(function(n) {
					Wt(n), t._reject(e.error);
				}), e.onabort = U(function(n) {
					Wt(n), t.active && t._reject(new F.Abort(e.error)), t.active = !1, t.on("abort").fire(n);
				}), e.oncomplete = U(function() {
					t.active = !1, t._resolve(), "mutatedParts" in e && qt.storagemutated.fire(e.mutatedParts);
				});
			}
			return this;
		}, Yt.prototype._promise = function(e, t, n) {
			var r, i = this;
			return e === "readwrite" && this.mode !== "readwrite" ? at(new F.ReadOnly("Transaction is readonly")) : this.active ? this._locked() ? new V(function(r, a) {
				i._blockedFuncs.push([function() {
					i._promise(e, t, n).then(r, a);
				}, B]);
			}) : n ? Xe(function() {
				var e = new V(function(e, n) {
					i._lock();
					var r = t(e, n, i);
					r && r.then && r.then(e, n);
				});
				return e.finally(function() {
					return i._unlock();
				}), e._lib = !0, e;
			}) : ((r = new V(function(e, n) {
				var r = t(e, n, i);
				r && r.then && r.then(e, n);
			}))._lib = !0, r) : at(new F.TransactionInactive());
		}, Yt.prototype._root = function() {
			return this.parent ? this.parent._root() : this;
		}, Yt.prototype.waitFor = function(e) {
			var t, n = this._root(), r = V.resolve(e), i = (n._waitingFor ? n._waitingFor = n._waitingFor.then(function() {
				return r;
			}) : (n._waitingFor = r, n._waitingQueue = [], t = n.idbtrans.objectStore(n.storeNames[0]), function e() {
				for (++n._spinCount; n._waitingQueue.length;) n._waitingQueue.shift()();
				n._waitingFor && (t.get(-1 / 0).onsuccess = e);
			}()), n._waitingFor);
			return new V(function(e, t) {
				r.then(function(t) {
					return n._waitingQueue.push(U(e.bind(null, t)));
				}, function(e) {
					return n._waitingQueue.push(U(t.bind(null, e)));
				}).finally(function() {
					n._waitingFor === i && (n._waitingFor = null);
				});
			});
		}, Yt.prototype.abort = function() {
			this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new F.Abort()));
		}, Yt.prototype.table = function(e) {
			var t = this._memoizedTables ||= {};
			if (l(t, e)) return t[e];
			var n = this.schema[e];
			if (n) return (n = new this.db.Table(e, n, this)).core = this.db.core.table(e), t[e] = n;
			throw new F.NotFound("Table " + e + " not part of transaction");
		}, Yt);
		function Yt() {}
		function Xt(e, t, n, r, i, a, o, s) {
			return {
				name: e,
				keyPath: t,
				unique: n,
				multi: r,
				auto: i,
				compound: a,
				src: (n && !o ? "&" : "") + (r ? "*" : "") + (i ? "++" : "") + Zt(t),
				type: s
			};
		}
		function Zt(e) {
			return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : "";
		}
		function Qt(e, t, n) {
			return {
				name: e,
				primKey: t,
				indexes: n,
				mappedClass: null,
				idxByName: (r = function(e) {
					return [e.name, e];
				}, n.reduce(function(e, t, n) {
					return t = r(t, n), t && (e[t[0]] = t[1]), e;
				}, {}))
			};
			var r;
		}
		var $t = function(e) {
			try {
				return e.only([[]]), $t = function() {
					return [[]];
				}, [[]];
			} catch {
				return $t = function() {
					return ot;
				}, ot;
			}
		};
		function en(e) {
			return e == null ? function() {} : typeof e == "string" ? (t = e).split(".").length === 1 ? function(e) {
				return e[t];
			} : function(e) {
				return b(e, t);
			} : function(t) {
				return b(t, e);
			};
			var t;
		}
		function tn(e) {
			return [].slice.call(e);
		}
		var nn = 0;
		function rn(e) {
			return e == null ? ":id" : typeof e == "string" ? e : `[${e.join("+")}]`;
		}
		function an(e, t, n) {
			function r(e) {
				if (e.type === 3) return null;
				if (e.type === 4) throw Error("Cannot convert never type to IDBKeyRange");
				var n = e.lower, r = e.upper, i = e.lowerOpen, e = e.upperOpen;
				return n === void 0 ? r === void 0 ? null : t.upperBound(r, !!e) : r === void 0 ? t.lowerBound(n, !!i) : t.bound(n, r, !!i, !!e);
			}
			function i(e) {
				var t, n, i = e.name;
				return {
					name: i,
					schema: e,
					mutate: function(e) {
						var t = e.trans, n = e.type, a = e.keys, o = e.values, s = e.range;
						return new Promise(function(e, c) {
							e = U(e);
							var l = t.objectStore(i), u = l.keyPath == null, d = n === "put" || n === "add";
							if (!d && n !== "delete" && n !== "deleteRange") throw Error("Invalid operation type: " + n);
							var f, p = (a || o || { length: 1 }).length;
							if (a && o && a.length !== o.length) throw Error("Given keys array must have same length as given values array.");
							if (p === 0) return e({
								numFailures: 0,
								failures: {},
								results: [],
								lastResult: void 0
							});
							function m(e) {
								++_, Wt(e);
							}
							var h = [], g = [], _ = 0;
							if (n === "deleteRange") {
								if (s.type === 4) return e({
									numFailures: _,
									failures: g,
									results: [],
									lastResult: void 0
								});
								s.type === 3 ? h.push(f = l.clear()) : h.push(f = l.delete(r(s)));
							} else {
								var u = d ? u ? [o, a] : [o, null] : [a, null], v = u[0], y = u[1];
								if (d) for (var b = 0; b < p; ++b) h.push(f = y && y[b] !== void 0 ? l[n](v[b], y[b]) : l[n](v[b])), f.onerror = m;
								else for (b = 0; b < p; ++b) h.push(f = l[n](v[b])), f.onerror = m;
							}
							function x(t) {
								t = t.target.result, h.forEach(function(e, t) {
									return e.error != null && (g[t] = e.error);
								}), e({
									numFailures: _,
									failures: g,
									results: n === "delete" ? a : h.map(function(e) {
										return e.result;
									}),
									lastResult: t
								});
							}
							f.onerror = function(e) {
								m(e), x(e);
							}, f.onsuccess = x;
						});
					},
					getMany: function(e) {
						var t = e.trans, n = e.keys;
						return new Promise(function(e, r) {
							e = U(e);
							for (var a, o = t.objectStore(i), s = n.length, c = Array(s), l = 0, u = 0, d = function(t) {
								t = t.target, c[t._pos] = t.result, ++u === l && e(c);
							}, f = Ut(r), p = 0; p < s; ++p) n[p] != null && ((a = o.get(n[p]))._pos = p, a.onsuccess = d, a.onerror = f, ++l);
							l === 0 && e(c);
						});
					},
					get: function(e) {
						var t = e.trans, n = e.key;
						return new Promise(function(e, r) {
							e = U(e);
							var a = t.objectStore(i).get(n);
							a.onsuccess = function(t) {
								return e(t.target.result);
							}, a.onerror = Ut(r);
						});
					},
					query: (t = c, n = l, function(e) {
						return new Promise(function(a, o) {
							a = U(a);
							var s, c, l, u, d = e.trans, f = e.values, p = e.limit, m = e.query, h = (h = e.direction) ?? "next", g = p === 1 / 0 ? void 0 : p, _ = m.index, m = m.range, d = d.objectStore(i), d = _.isPrimaryKey ? d : d.index(_.name), _ = r(m);
							if (p === 0) return a({ result: [] });
							n ? (m = {
								query: _,
								count: g,
								direction: h
							}, (s = f ? d.getAll(m) : d.getAllKeys(m)).onsuccess = function(e) {
								return a({ result: e.target.result });
							}, s.onerror = Ut(o)) : t && h === "next" ? ((s = f ? d.getAll(_, g) : d.getAllKeys(_, g)).onsuccess = function(e) {
								return a({ result: e.target.result });
							}, s.onerror = Ut(o)) : (c = 0, l = !f && "openKeyCursor" in d ? d.openKeyCursor(_, h) : d.openCursor(_, h), u = [], l.onsuccess = function() {
								var e = l.result;
								return !e || (u.push(f ? e.value : e.primaryKey), ++c === p) ? a({ result: u }) : void e.continue();
							}, l.onerror = Ut(o));
						});
					}),
					openCursor: function(e) {
						var t = e.trans, n = e.values, a = e.query, o = e.reverse, s = e.unique;
						return new Promise(function(e, c) {
							e = U(e);
							var l = a.index, u = a.range, d = t.objectStore(i), d = l.isPrimaryKey ? d : d.index(l.name), l = o ? s ? "prevunique" : "prev" : s ? "nextunique" : "next", f = !n && "openKeyCursor" in d ? d.openKeyCursor(r(u), l) : d.openCursor(r(u), l);
							f.onerror = Ut(c), f.onsuccess = U(function(n) {
								var r, i, a, o, s = f.result;
								s ? (s.___id = ++nn, s.done = !1, r = s.continue.bind(s), i = (i = s.continuePrimaryKey) && i.bind(s), a = s.advance.bind(s), o = function() {
									throw Error("Cursor not stopped");
								}, s.trans = t, s.stop = s.continue = s.continuePrimaryKey = s.advance = function() {
									throw Error("Cursor not started");
								}, s.fail = U(c), s.next = function() {
									var e = this, t = 1;
									return this.start(function() {
										return t-- ? e.continue() : e.stop();
									}).then(function() {
										return e;
									});
								}, s.start = function(e) {
									function t() {
										if (f.result) try {
											e();
										} catch (e) {
											s.fail(e);
										}
										else s.done = !0, s.start = function() {
											throw Error("Cursor behind last entry");
										}, s.stop();
									}
									var n = new Promise(function(e, t) {
										e = U(e), f.onerror = Ut(t), s.fail = t, s.stop = function(t) {
											s.stop = s.continue = s.continuePrimaryKey = s.advance = o, e(t);
										};
									});
									return f.onsuccess = U(function(e) {
										f.onsuccess = t, t();
									}), s.continue = r, s.continuePrimaryKey = i, s.advance = a, t(), n;
								}, e(s)) : e(null);
							}, c);
						});
					},
					count: function(e) {
						var t = e.query, n = e.trans, a = t.index, o = t.range;
						return new Promise(function(e, t) {
							var s = n.objectStore(i), s = a.isPrimaryKey ? s : s.index(a.name), c = r(o), c = c ? s.count(c) : s.count();
							c.onsuccess = U(function(t) {
								return e(t.target.result);
							}), c.onerror = Ut(t);
						});
					}
				};
			}
			o = n, s = tn((n = e).objectStoreNames), u = 0 < s.length ? o.objectStore(s[0]) : {};
			var o, n = {
				schema: {
					name: n.name,
					tables: s.map(function(e) {
						return o.objectStore(e);
					}).map(function(e) {
						var t = e.keyPath, n = e.autoIncrement, r = a(t), i = {}, r = {
							name: e.name,
							primaryKey: {
								name: null,
								isPrimaryKey: !0,
								outbound: t == null,
								compound: r,
								keyPath: t,
								autoIncrement: n,
								unique: !0,
								extractKey: en(t)
							},
							indexes: tn(e.indexNames).map(function(t) {
								return e.index(t);
							}).map(function(e) {
								var t = e.name, n = e.unique, r = e.multiEntry, e = e.keyPath, t = {
									name: t,
									compound: a(e),
									keyPath: e,
									unique: n,
									multiEntry: r,
									extractKey: en(e)
								};
								return i[rn(e)] = t;
							}),
							getIndexByKeyPath: function(e) {
								return i[rn(e)];
							}
						};
						return i[":id"] = r.primaryKey, t != null && (i[rn(t)] = r.primaryKey), r;
					})
				},
				hasGetAll: 0 < s.length && "getAll" in u && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604),
				hasIdb3Features: "getAllRecords" in u
			}, s = n.schema, c = n.hasGetAll, l = n.hasIdb3Features, u = s.tables.map(i), d = {};
			return u.forEach(function(e) {
				return d[e.name] = e;
			}), {
				stack: "dbcore",
				transaction: e.transaction.bind(e),
				table: function(e) {
					if (d[e]) return d[e];
					throw Error(`Table '${e}' not found`);
				},
				MIN_KEY: -1 / 0,
				MAX_KEY: $t(t),
				schema: s
			};
		}
		function on(e, n, r, i) {
			return r = r.IDBKeyRange, n = an(n, r, i), { dbcore: e.dbcore.reduce(function(e, n) {
				return n = n.create, t(t({}, e), n(e));
			}, n) };
		}
		function sn(e, t) {
			var n = t.db, n = on(e._middlewares, n, e._deps, t);
			e.core = n.dbcore, e.tables.forEach(function(t) {
				var n = t.name;
				e.core.schema.tables.some(function(e) {
					return e.name === n;
				}) && (t.core = e.core.table(n), e[n] instanceof e.Table) && (e[n].core = t.core);
			});
		}
		function cn(e, t, n, r) {
			n.forEach(function(n) {
				var i = r[n];
				t.forEach(function(t) {
					var r = function e(t, n) {
						return m(t, n) || (t = s(t)) && e(t, n);
					}(t, n);
					(!r || "value" in r && r.value === void 0) && (t === e.Transaction.prototype || t instanceof e.Transaction ? f(t, n, {
						get: function() {
							return this.table(n);
						},
						set: function(e) {
							d(this, n, {
								value: e,
								writable: !0,
								configurable: !0,
								enumerable: !0
							});
						}
					}) : t[n] = new e.Table(n, i));
				});
			});
		}
		function ln(e, t) {
			t.forEach(function(t) {
				for (var n in t) t[n] instanceof e.Table && delete t[n];
			});
		}
		function un(e, t) {
			return e._cfg.version - t._cfg.version;
		}
		function dn(e, t, n, r) {
			var a = e._dbSchema, o = (n.objectStoreNames.contains("$meta") && !a.$meta && (a.$meta = Qt("$meta", vn("")[0], []), e._storeNames.push("$meta")), e._createTransaction("readwrite", e._storeNames, a)), s = (o.create(n), o._completion.catch(r), o._reject.bind(o)), c = B.transless || B;
			Xe(function() {
				if (B.trans = o, B.transless = c, t !== 0) return sn(e, n), l = t, ((r = o).storeNames.includes("$meta") ? r.table("$meta").get("version").then(function(e) {
					return e ?? l;
				}) : V.resolve(l)).then(function(t) {
					var r = e, a = t, s = o, c = n, l = [], t = r._versions, u = r._dbSchema = gn(0, r.idbdb, c);
					return (t = t.filter(function(e) {
						return e._cfg.version >= a;
					})).length === 0 ? V.resolve() : (t.forEach(function(e) {
						l.push(function() {
							var t, n, o, l = u, d = e._cfg.dbschema, f = (_n(r, l, c), _n(r, d, c), u = r._dbSchema = d, fn(l, d)), p = (f.add.forEach(function(e) {
								pn(c, e[0], e[1].primKey, e[1].indexes);
							}), f.change.forEach(function(e) {
								if (e.recreate) throw new F.Upgrade("Not yet support for changing primary key");
								var t = c.objectStore(e.name);
								e.add.forEach(function(e) {
									return hn(t, e);
								}), e.change.forEach(function(e) {
									t.deleteIndex(e.name), hn(t, e);
								}), e.del.forEach(function(e) {
									return t.deleteIndex(e);
								});
							}), e._cfg.contentUpgrade);
							if (p && e._cfg.version > a) return sn(r, c), s._memoizedTables = {}, t = S(d), f.del.forEach(function(e) {
								t[e] = l[e];
							}), ln(r, [r.Transaction.prototype]), cn(r, [r.Transaction.prototype], i(t), t), s.schema = t, (n = A(p)) && Ze(), d = V.follow(function() {
								var e;
								(o = p(s)) && n && (e = Qe.bind(null, null), o.then(e, e));
							}), o && typeof o.then == "function" ? V.resolve(o) : d.then(function() {
								return o;
							});
						}), l.push(function(t) {
							var n = e._cfg.dbschema, i = t;
							[].slice.call(i.db.objectStoreNames).forEach(function(e) {
								return n[e] == null && i.db.deleteObjectStore(e);
							}), ln(r, [r.Transaction.prototype]), cn(r, [r.Transaction.prototype], r._storeNames, r._dbSchema), s.schema = r._dbSchema;
						}), l.push(function(t) {
							r.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(r.idbdb.version / 10) === e._cfg.version ? (r.idbdb.deleteObjectStore("$meta"), delete r._dbSchema.$meta, r._storeNames = r._storeNames.filter(function(e) {
								return e !== "$meta";
							})) : t.objectStore("$meta").put(e._cfg.version, "version"));
						});
					}), function e() {
						return l.length ? V.resolve(l.shift()(s.idbtrans)).then(e) : V.resolve();
					}().then(function() {
						mn(u, c);
					}));
				}).catch(s);
				var r, l;
				i(a).forEach(function(e) {
					pn(n, e, a[e].primKey, a[e].indexes);
				}), sn(e, n), V.follow(function() {
					return e.on.populate.fire(o);
				}).catch(s);
			});
		}
		function J(e, t) {
			mn(e._dbSchema, t), t.db.version % 10 != 0 || t.objectStoreNames.contains("$meta") || t.db.createObjectStore("$meta").add(Math.ceil(t.db.version / 10 - 1), "version");
			var n = gn(0, e.idbdb, t);
			_n(e, e._dbSchema, t);
			for (var r = 0, i = fn(n, e._dbSchema).change; r < i.length; r++) {
				var a = ((e) => {
					if (e.change.length || e.recreate) return console.warn(`Unable to patch indexes of table ${e.name} because it has changes on the type of index or primary key.`), { value: void 0 };
					var n = t.objectStore(e.name);
					e.add.forEach(function(t) {
						ye && console.debug(`Dexie upgrade patch: Creating missing index ${e.name}.${t.src}`), hn(n, t);
					});
				})(i[r]);
				if (typeof a == "object") return a.value;
			}
		}
		function fn(e, t) {
			var n, r = {
				del: [],
				add: [],
				change: []
			};
			for (n in e) t[n] || r.del.push(n);
			for (n in t) {
				var i = e[n], a = t[n];
				if (i) {
					var o = {
						name: n,
						def: a,
						recreate: !1,
						del: [],
						add: [],
						change: []
					};
					if ("" + (i.primKey.keyPath || "") != "" + (a.primKey.keyPath || "") || i.primKey.auto !== a.primKey.auto) o.recreate = !0, r.change.push(o);
					else {
						var s = i.idxByName, c = a.idxByName, l = void 0;
						for (l in s) c[l] || o.del.push(l);
						for (l in c) {
							var u = s[l], d = c[l];
							u ? u.src !== d.src && o.change.push(d) : o.add.push(d);
						}
						(0 < o.del.length || 0 < o.add.length || 0 < o.change.length) && r.change.push(o);
					}
				} else r.add.push([n, a]);
			}
			return r;
		}
		function pn(e, t, n, r) {
			var i = e.db.createObjectStore(t, n.keyPath ? {
				keyPath: n.keyPath,
				autoIncrement: n.auto
			} : { autoIncrement: n.auto });
			r.forEach(function(e) {
				return hn(i, e);
			});
		}
		function mn(e, t) {
			i(e).forEach(function(n) {
				t.db.objectStoreNames.contains(n) || (ye && console.debug("Dexie: Creating missing table", n), pn(t, n, e[n].primKey, e[n].indexes));
			});
		}
		function hn(e, t) {
			e.createIndex(t.name, t.keyPath, {
				unique: t.unique,
				multiEntry: t.multi
			});
		}
		function gn(e, t, n) {
			var r = {};
			return g(t.objectStoreNames, 0).forEach(function(e) {
				for (var t = n.objectStore(e), i = Xt(Zt(c = t.keyPath), c || "", !0, !1, !!t.autoIncrement, c && typeof c != "string", !0), a = [], o = 0; o < t.indexNames.length; ++o) {
					var s = t.index(t.indexNames[o]), c = s.keyPath, s = Xt(s.name, c, !!s.unique, !!s.multiEntry, !1, c && typeof c != "string", !1);
					a.push(s);
				}
				r[e] = Qt(e, i, a);
			}), r;
		}
		function _n(e, t, n) {
			for (var i = n.db.objectStoreNames, a = 0; a < i.length; ++a) {
				var o = i[a], s = n.objectStore(o);
				e._hasGetAll = "getAll" in s;
				for (var c = 0; c < s.indexNames.length; ++c) {
					var l, u = s.indexNames[c], d = s.index(u).keyPath, d = typeof d == "string" ? d : "[" + g(d).join("+") + "]";
					t[o] && (l = t[o].idxByName[d]) && (l.name = u, delete t[o].idxByName[d], t[o].idxByName[u] = l);
				}
			}
			typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && r.WorkerGlobalScope && r instanceof r.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1);
		}
		function vn(e) {
			return e.split(",").map(function(e, t) {
				var n = e.split(":"), r = (r = n[1])?.trim(), n = (e = n[0].trim()).replace(/([&*]|\+\+)/g, ""), i = /^\[/.test(n) ? n.match(/^\[(.*)\]$/)[1].split("+") : n;
				return Xt(n, i || null, /\&/.test(e), /\*/.test(e), /\+\+/.test(e), a(i), t === 0, r);
			});
		}
		bn.prototype._createTableSchema = Qt, bn.prototype._parseIndexSyntax = vn, bn.prototype._parseStoresSpec = function(e, t) {
			var n = this;
			i(e).forEach(function(r) {
				if (e[r] !== null) {
					var i = n._parseIndexSyntax(e[r]), a = i.shift();
					if (!a) throw new F.Schema("Invalid schema for table " + r + ": " + e[r]);
					if (a.unique = !0, a.multi) throw new F.Schema("Primary key cannot be multiEntry*");
					i.forEach(function(e) {
						if (e.auto) throw new F.Schema("Only primary key can be marked as autoIncrement (++)");
						if (!e.keyPath) throw new F.Schema("Index must have a name and cannot be an empty string");
					}), a = n._createTableSchema(r, a, i), t[r] = a;
				}
			});
		}, bn.prototype.stores = function(e) {
			var t = this.db, e = (this._cfg.storesSource = this._cfg.storesSource ? o(this._cfg.storesSource, e) : e, t._versions), n = {}, r = {};
			return e.forEach(function(e) {
				o(n, e._cfg.storesSource), r = e._cfg.dbschema = {}, e._parseStoresSpec(n, r);
			}), t._dbSchema = r, ln(t, [
				t._allTables,
				t,
				t.Transaction.prototype
			]), cn(t, [
				t._allTables,
				t,
				t.Transaction.prototype,
				this._cfg.tables
			], i(r), r), t._storeNames = i(r), this;
		}, bn.prototype.upgrade = function(e) {
			return this._cfg.contentUpgrade = ve(this._cfg.contentUpgrade || I, e), this;
		};
		var yn = bn;
		function bn() {}
		var xn = (() => {
			var e, t, n;
			return typeof FinalizationRegistry < "u" && typeof WeakRef < "u" ? (e = /* @__PURE__ */ new Set(), t = new FinalizationRegistry(function(t) {
				e.delete(t);
			}), {
				toArray: function() {
					return Array.from(e).map(function(e) {
						return e.deref();
					}).filter(function(e) {
						return e !== void 0;
					});
				},
				add: function(n) {
					var r = new WeakRef(n._novip);
					e.add(r), t.register(n._novip, r, r), e.size > n._options.maxConnections && (r = e.values().next().value, e.delete(r), t.unregister(r));
				},
				remove: function(n) {
					if (n) for (var r = e.values(), i = r.next(); !i.done;) {
						var a = i.value;
						if (a.deref() === n._novip) return e.delete(a), void t.unregister(a);
						i = r.next();
					}
				}
			}) : (n = [], {
				toArray: function() {
					return n;
				},
				add: function(e) {
					n.push(e._novip);
				},
				remove: function(e) {
					e && (e = n.indexOf(e._novip)) !== -1 && n.splice(e, 1);
				}
			});
		})();
		function Sn(e, t) {
			var n = e._dbNamesDB;
			return n || (n = e._dbNamesDB = new sr(lt, {
				addons: [],
				indexedDB: e,
				IDBKeyRange: t
			})).version(1).stores({ dbnames: "name" }), n.table("dbnames");
		}
		function Cn(e) {
			return e && typeof e.databases == "function";
		}
		function wn(e) {
			return Xe(function() {
				return B.letThrough = !0, e();
			});
		}
		function Tn(e) {
			return !("from" in e);
		}
		var En = function(e, t) {
			var n;
			if (!this) return n = new En(), e && "d" in e && o(n, e), n;
			o(this, arguments.length ? {
				d: 1,
				from: e,
				to: 1 < arguments.length ? t : e
			} : { d: 0 });
		};
		function Dn(e, t, n) {
			var r = G(t, n);
			if (!isNaN(r)) {
				if (0 < r) throw RangeError();
				if (Tn(e)) return o(e, {
					from: t,
					to: n,
					d: 1
				});
				var r = e.l, i = e.r;
				if (G(n, e.from) < 0) return r ? Dn(r, t, n) : e.l = {
					from: t,
					to: n,
					d: 1,
					l: null,
					r: null
				}, jn(e);
				if (0 < G(t, e.to)) return i ? Dn(i, t, n) : e.r = {
					from: t,
					to: n,
					d: 1,
					l: null,
					r: null
				}, jn(e);
				G(t, e.from) < 0 && (e.from = t, e.l = null, e.d = i ? i.d + 1 : 1), 0 < G(n, e.to) && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1), t = !e.r, r && !e.l && On(e, r), i && t && On(e, i);
			}
		}
		function On(e, t) {
			Tn(t) || function e(t, n) {
				var r = n.from, i = n.l, a = n.r;
				Dn(t, r, n.to), i && e(t, i), a && e(t, a);
			}(e, t);
		}
		function kn(e, t) {
			var n = An(t), r = n.next();
			if (!r.done) for (var i = r.value, a = An(e), o = a.next(i.from), s = o.value; !r.done && !o.done;) {
				if (G(s.from, i.to) <= 0 && 0 <= G(s.to, i.from)) return !0;
				G(i.from, s.from) < 0 ? i = (r = n.next(s.from)).value : s = (o = a.next(i.from)).value;
			}
			return !1;
		}
		function An(e) {
			var t = Tn(e) ? null : {
				s: 0,
				n: e
			};
			return { next: function(e) {
				for (var n = 0 < arguments.length; t;) switch (t.s) {
					case 0: if (t.s = 1, n) for (; t.n.l && G(e, t.n.from) < 0;) t = {
						up: t,
						n: t.n.l,
						s: 1
					};
					else for (; t.n.l;) t = {
						up: t,
						n: t.n.l,
						s: 1
					};
					case 1: if (t.s = 2, !n || G(e, t.n.to) <= 0) return {
						value: t.n,
						done: !1
					};
					case 2: if (t.n.r) {
						t.s = 3, t = {
							up: t,
							n: t.n.r,
							s: 0
						};
						continue;
					}
					case 3: t = t.up;
				}
				return { done: !0 };
			} };
		}
		function jn(e) {
			var n, r, i, a = ((a = e.r)?.d || 0) - ((a = e.l)?.d || 0), a = 1 < a ? "r" : a < -1 ? "l" : "";
			a && (n = a == "r" ? "l" : "r", r = t({}, e), i = e[a], e.from = i.from, e.to = i.to, e[a] = i[a], r[a] = i[n], (e[n] = r).d = Mn(r)), e.d = Mn(e);
		}
		function Mn(e) {
			var t = e.r, e = e.l;
			return (t ? e ? Math.max(t.d, e.d) : t.d : e ? e.d : 0) + 1;
		}
		function Nn(e, t) {
			return i(t).forEach(function(n) {
				e[n] ? On(e[n], t[n]) : e[n] = function e(t) {
					var n, r, i = {};
					for (n in t) l(t, n) && (r = t[n], i[n] = !r || typeof r != "object" || ee.has(r.constructor) ? r : e(r));
					return i;
				}(t[n]);
			}), e;
		}
		function Pn(e, t) {
			return e.all || t.all || Object.keys(e).some(function(n) {
				return t[n] && kn(t[n], e[n]);
			});
		}
		u(En.prototype, ((j = {
			add: function(e) {
				return On(this, e), this;
			},
			addKey: function(e) {
				return Dn(this, e, e), this;
			},
			addKeys: function(e) {
				var t = this;
				return e.forEach(function(e) {
					return Dn(t, e, e);
				}), this;
			},
			hasKey: function(e) {
				var t = An(this).next(e).value;
				return t && G(t.from, e) <= 0 && 0 <= G(t.to, e);
			}
		})[ie] = function() {
			return An(this);
		}, j));
		var Fn = {}, In = {}, Ln = !1;
		function Rn(e) {
			Nn(In, e), Ln || (Ln = !0, setTimeout(function() {
				Ln = !1, zn(In, !(In = {}));
			}, 0));
		}
		function zn(e, t) {
			t === void 0 && (t = !1);
			var n = /* @__PURE__ */ new Set();
			if (e.all) for (var r = 0, i = Object.values(Fn); r < i.length; r++) Bn(s = i[r], e, n, t);
			else for (var a in e) {
				var o, s, a = /^idb\:\/\/(.*)\/(.*)\//.exec(a);
				a && (o = a[1], a = a[2], s = Fn[`idb://${o}/${a}`]) && Bn(s, e, n, t);
			}
			n.forEach(function(e) {
				return e();
			});
		}
		function Bn(e, t, n, r) {
			for (var i = [], a = 0, o = Object.entries(e.queries.query); a < o.length; a++) {
				for (var s = o[a], c = s[0], l = [], u = 0, d = s[1]; u < d.length; u++) {
					var f = d[u];
					Pn(t, f.obsSet) ? f.subscribers.forEach(function(e) {
						return n.add(e);
					}) : r && l.push(f);
				}
				r && i.push([c, l]);
			}
			if (r) for (var p = 0, m = i; p < m.length; p++) {
				var h = m[p], c = h[0], l = h[1];
				e.queries.query[c] = l;
			}
		}
		function Vn(e) {
			var t = e._state, n = e._deps.indexedDB;
			if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
				return t.dbOpenError ? at(t.dbOpenError) : e;
			});
			t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
			var r = t.openCanceller, a = Math.round(10 * e.verno), o = !1;
			function s() {
				if (t.openCanceller !== r) throw new F.DatabaseClosed("db.open() was cancelled");
			}
			function c() {
				return new V(function(r, l) {
					if (s(), !n) throw new F.MissingAPI();
					var u = e.name, p = t.autoSchema || !a ? n.open(u) : n.open(u, a);
					if (!p) throw new F.MissingAPI();
					p.onerror = Ut(l), p.onblocked = U(e._fireOnBlocked), p.onupgradeneeded = U(function(r) {
						var i;
						d = p.transaction, t.autoSchema && !e._options.allowEmptyDB ? (p.onerror = Wt, d.abort(), p.result.close(), (i = n.deleteDatabase(u)).onsuccess = i.onerror = U(function() {
							l(new F.NoSuchDatabase(`Database ${u} doesnt exist`));
						})) : (d.onerror = Ut(l), i = r.oldVersion > 2 ** 62 ? 0 : r.oldVersion, f = i < 1, e.idbdb = p.result, o && J(e, d), dn(e, i / 10, d, l));
					}, l), p.onsuccess = U(function() {
						d = null;
						var n, s, l, m, h, _, v = e.idbdb = p.result, y = g(v.objectStoreNames);
						if (0 < y.length) try {
							var b = v.transaction((h = y).length === 1 ? h[0] : h, "readonly");
							if (t.autoSchema) _ = v, m = b, (l = e).verno = _.version / 10, m = l._dbSchema = gn(0, _, m), l._storeNames = g(_.objectStoreNames, 0), cn(l, [l._allTables], i(m), m);
							else if (_n(e, e._dbSchema, b), s = b, ((s = fn(gn(0, (n = e).idbdb, s), n._dbSchema)).add.length || s.change.some(function(e) {
								return e.add.length || e.change.length;
							})) && !o) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), v.close(), a = v.version + 1, o = !0, r(c());
							sn(e, b);
						} catch {}
						xn.add(e), v.onversionchange = U(function(n) {
							t.vcFired = !0, e.on("versionchange").fire(n);
						}), v.onclose = U(function() {
							e.close({ disableAutoOpen: !1 });
						}), f && (y = e._deps, h = u, Cn(_ = y.indexedDB) || h === lt || Sn(_, y.IDBKeyRange).put({ name: h }).catch(I)), r();
					}, l);
				}).catch(function(e) {
					switch (e?.name) {
						case "UnknownError":
							if (0 < t.PR1398_maxLoop) return t.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), c();
							break;
						case "VersionError": if (0 < a) return a = 0, c();
					}
					return V.reject(e);
				});
			}
			var l, u = t.dbReadyResolve, d = null, f = !1;
			return V.race([r, (typeof navigator > "u" ? V.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(e) {
				function t() {
					return indexedDB.databases().finally(e);
				}
				l = setInterval(t, 100), t();
			}).finally(function() {
				return clearInterval(l);
			}) : Promise.resolve()).then(c)]).then(function() {
				return s(), t.onReadyBeingFired = [], V.resolve(wn(function() {
					return e.on.ready.fire(e.vip);
				})).then(function n() {
					var r;
					if (0 < t.onReadyBeingFired.length) return r = t.onReadyBeingFired.reduce(ve, I), t.onReadyBeingFired = [], V.resolve(wn(function() {
						return r(e.vip);
					})).then(n);
				});
			}).finally(function() {
				t.openCanceller === r && (t.onReadyBeingFired = null, t.isBeingOpened = !1);
			}).catch(function(n) {
				t.dbOpenError = n;
				try {
					d && d.abort();
				} catch {}
				return r === t.openCanceller && e._close(), at(n);
			}).finally(function() {
				t.openComplete = !0, u();
			}).then(function() {
				var t;
				return f && (t = {}, e.tables.forEach(function(n) {
					n.schema.indexes.forEach(function(r) {
						r.name && (t[`idb://${e.name}/${n.name}/${r.name}`] = new En(-1 / 0, [[[]]]));
					}), t[`idb://${e.name}/${n.name}/`] = t[`idb://${e.name}/${n.name}/:dels`] = new En(-1 / 0, [[[]]]);
				}), qt(Gt).fire(t), zn(t, !0)), e;
			});
		}
		function Hn(e) {
			function t(t) {
				return e.next(t);
			}
			var n = i(t), r = i(function(t) {
				return e.throw(t);
			});
			function i(e) {
				return function(t) {
					var t = e(t), i = t.value;
					return t.done ? i : i && typeof i.then == "function" ? i.then(n, r) : a(i) ? Promise.all(i).then(n, r) : n(i);
				};
			}
			return i(t)();
		}
		function Un(e, t, n) {
			for (var r = a(e) ? e.slice() : [e], i = 0; i < n; ++i) r.push(t);
			return r;
		}
		var Wn = {
			stack: "dbcore",
			name: "VirtualIndexMiddleware",
			level: 1,
			create: function(e) {
				return t(t({}, e), { table: function(n) {
					var r = e.table(n), n = r.schema, i = Object.create(null), a = [];
					function o(e, n, r) {
						var s = rn(e), c = i[s] = i[s] || [], l = e == null ? 0 : typeof e == "string" ? 1 : e.length, u = 0 < n, s = t(t({}, r), {
							name: u ? `${s}(virtual-from:${r.name})` : r.name,
							lowLevelIndex: r,
							isVirtual: u,
							keyTail: n,
							keyLength: l,
							extractKey: en(e),
							unique: !u && r.unique
						});
						return c.push(s), s.isPrimaryKey || a.push(s), 1 < l && o(l === 2 ? e[0] : e.slice(0, l - 1), n + 1, r), c.sort(function(e, t) {
							return e.keyTail - t.keyTail;
						}), s;
					}
					var s = o(n.primaryKey.keyPath, 0, n.primaryKey);
					i[":id"] = [s];
					for (var c = 0, l = n.indexes; c < l.length; c++) {
						var u = l[c];
						o(u.keyPath, 0, u);
					}
					function d(n) {
						var r, i = n.query.index;
						return i.isVirtual ? t(t({}, n), { query: {
							index: i.lowLevelIndex,
							range: (r = n.query.range, i = i.keyTail, {
								type: r.type === 1 ? 2 : r.type,
								lower: Un(r.lower, r.lowerOpen ? e.MAX_KEY : e.MIN_KEY, i),
								lowerOpen: !0,
								upper: Un(r.upper, r.upperOpen ? e.MIN_KEY : e.MAX_KEY, i),
								upperOpen: !0
							})
						} }) : n;
					}
					return t(t({}, r), {
						schema: t(t({}, n), {
							primaryKey: s,
							indexes: a,
							getIndexByKeyPath: function(e) {
								return (e = i[rn(e)]) && e[0];
							}
						}),
						count: function(e) {
							return r.count(d(e));
						},
						query: function(e) {
							return r.query(d(e));
						},
						openCursor: function(t) {
							var n = t.query.index, i = n.keyTail, a = n.keyLength;
							return n.isVirtual ? r.openCursor(d(t)).then(function(e) {
								return e && o(e);
							}) : r.openCursor(t);
							function o(n) {
								return Object.create(n, {
									continue: { value: function(r) {
										r == null ? t.unique ? n.continue(n.key.slice(0, a).concat(t.reverse ? e.MIN_KEY : e.MAX_KEY, i)) : n.continue() : n.continue(Un(r, t.reverse ? e.MAX_KEY : e.MIN_KEY, i));
									} },
									continuePrimaryKey: { value: function(t, r) {
										n.continuePrimaryKey(Un(t, e.MAX_KEY, i), r);
									} },
									primaryKey: { get: function() {
										return n.primaryKey;
									} },
									key: { get: function() {
										var e = n.key;
										return a === 1 ? e[0] : e.slice(0, a);
									} },
									value: { get: function() {
										return n.value;
									} }
								});
							}
						}
					});
				} });
			}
		};
		function Gn(e, t, n, r) {
			return n ||= {}, r ||= "", i(e).forEach(function(i) {
				var a, o, s;
				l(t, i) ? (a = e[i], o = t[i], typeof a == "object" && typeof o == "object" && a && o ? (s = re(a)) === re(o) ? s === "Object" ? Gn(a, o, n, r + i + ".") : a !== o && (n[r + i] = t[i]) : n[r + i] = t[i] : a !== o && (n[r + i] = t[i])) : n[r + i] = void 0;
			}), i(t).forEach(function(i) {
				l(e, i) || (n[r + i] = t[i]);
			}), n;
		}
		function Kn(e, t) {
			return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey);
		}
		var qn = {
			stack: "dbcore",
			name: "HooksMiddleware",
			level: 2,
			create: function(e) {
				return t(t({}, e), { table: function(r) {
					var i = e.table(r), a = i.schema.primaryKey;
					return t(t({}, i), { mutate: function(e) {
						var o = B.trans, s = o.table(r).hook, c = s.deleting, u = s.creating, d = s.updating;
						switch (e.type) {
							case "add":
								if (u.fire === I) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "put":
								if (u.fire === I && d.fire === I) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "delete":
								if (c.fire === I) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "deleteRange":
								if (c.fire === I) break;
								return o._promise("readwrite", function() {
									return function e(n, r, o) {
										return i.query({
											trans: n,
											values: !1,
											query: {
												index: a,
												range: r
											},
											limit: o
										}).then(function(i) {
											var a = i.result;
											return f({
												type: "delete",
												keys: a,
												trans: n
											}).then(function(i) {
												return 0 < i.numFailures ? Promise.reject(i.failures[0]) : a.length < o ? {
													failures: [],
													numFailures: 0,
													lastResult: void 0
												} : e(n, t(t({}, r), {
													lower: a[a.length - 1],
													lowerOpen: !0
												}), o);
											});
										});
									}(e.trans, e.range, 1e4);
								}, !0);
						}
						return i.mutate(e);
						function f(e) {
							var r, o, s, f = B.trans, p = e.keys || Kn(a, e);
							if (p) return (e = e.type === "add" || e.type === "put" ? t(t({}, e), { keys: p }) : t({}, e)).type !== "delete" && (e.values = n([], e.values, !0)), e.keys && (e.keys = n([], e.keys, !0)), r = i, s = p, ((o = e).type === "add" ? Promise.resolve([]) : r.getMany({
								trans: o.trans,
								keys: s,
								cache: "immutable"
							})).then(function(t) {
								var n = p.map(function(n, r) {
									var i, o, s, p = t[r], m = {
										onerror: null,
										onsuccess: null
									};
									return e.type === "delete" ? c.fire.call(m, n, p, f) : e.type === "add" || p === void 0 ? (i = u.fire.call(m, n, e.values[r], f), n == null && i != null && (e.keys[r] = n = i, a.outbound || x(e.values[r], a.keyPath, n))) : (i = Gn(p, e.values[r]), (o = d.fire.call(m, i, n, p, f)) && (s = e.values[r], Object.keys(o).forEach(function(e) {
										l(s, e) ? s[e] = o[e] : x(s, e, o[e]);
									}))), m;
								});
								return i.mutate(e).then(function(r) {
									for (var i = r.failures, a = r.results, o = r.numFailures, r = r.lastResult, s = 0; s < p.length; ++s) {
										var c = (a || p)[s], l = n[s];
										c == null ? l.onerror && l.onerror(i[s]) : l.onsuccess && l.onsuccess(e.type === "put" && t[s] ? e.values[s] : c);
									}
									return {
										failures: i,
										results: a,
										numFailures: o,
										lastResult: r
									};
								}).catch(function(e) {
									return n.forEach(function(t) {
										return t.onerror && t.onerror(e);
									}), Promise.reject(e);
								});
							});
							throw Error("Keys missing");
						}
					} });
				} });
			}
		};
		function Jn(e, t, n) {
			try {
				if (!t || t.keys.length < e.length) return null;
				for (var r = [], i = 0, a = 0; i < t.keys.length && a < e.length; ++i) G(t.keys[i], e[a]) === 0 && (r.push(n ? te(t.values[i]) : t.values[i]), ++a);
				return r.length === e.length ? r : null;
			} catch {
				return null;
			}
		}
		var Yn = {
			stack: "dbcore",
			level: -1,
			create: function(e) {
				return { table: function(n) {
					var r = e.table(n);
					return t(t({}, r), {
						getMany: function(e) {
							var t;
							return e.cache ? (t = Jn(e.keys, e.trans._cache, e.cache === "clone")) ? V.resolve(t) : r.getMany(e).then(function(t) {
								return e.trans._cache = {
									keys: e.keys,
									values: e.cache === "clone" ? te(t) : t
								}, t;
							}) : r.getMany(e);
						},
						mutate: function(e) {
							return e.type !== "add" && (e.trans._cache = null), r.mutate(e);
						}
					});
				} };
			}
		};
		function Xn(e, t) {
			return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !t.schema.primaryKey.outbound;
		}
		function Zn(e, t) {
			switch (e) {
				case "query": return t.values && !t.unique;
				case "get":
				case "getMany":
				case "count":
				case "openCursor": return !1;
			}
		}
		var Qn = {
			stack: "dbcore",
			level: 0,
			name: "Observability",
			create: function(e) {
				var n = e.schema.name, r = new En(e.MIN_KEY, e.MAX_KEY);
				return t(t({}, e), {
					transaction: function(t, n, r) {
						if (B.subscr && n !== "readonly") throw new F.ReadOnly(`Readwrite transaction in liveQuery context. Querier source: ${B.querier}`);
						return e.transaction(t, n, r);
					},
					table: function(o) {
						function s(t) {
							var t = t.query;
							return [t.index, new En((t = t.range).lower ?? e.MIN_KEY, t.upper ?? e.MAX_KEY)];
						}
						var c = e.table(o), l = c.schema, u = l.primaryKey, d = l.indexes, f = u.extractKey, p = u.outbound, m = u.autoIncrement && d.filter(function(e) {
							return e.compound && e.keyPath.includes(u.keyPath);
						}), h = t(t({}, c), { mutate: function(t) {
							function i(e) {
								return e = `idb://${n}/${o}/${e}`, h[e] || (h[e] = new En());
							}
							var s, d, f, p = t.trans, h = t.mutatedParts ||= {}, g = i(""), _ = i(":dels"), v = t.type, y = t.type === "deleteRange" ? [t.range] : t.type === "delete" ? [t.keys] : t.values.length < 50 ? [Kn(u, t).filter(function(e) {
								return e;
							}), t.values] : [], b = y[0], y = y[1], x = t.trans._cache;
							return a(b) ? (g.addKeys(b), (v = v === "delete" || b.length === y.length ? Jn(b, x) : null) || _.addKeys(b), (v || y) && (s = i, d = v, f = y, l.indexes.forEach(function(e) {
								var t = s(e.name || "");
								function n(t) {
									return t == null ? null : e.extractKey(t);
								}
								function r(n) {
									e.multiEntry && a(n) ? n.forEach(function(e) {
										return t.addKey(e);
									}) : t.addKey(n);
								}
								(d || f).forEach(function(e, t) {
									var i = d && n(d[t]), t = f && n(f[t]);
									G(i, t) !== 0 && (i != null && r(i), t != null) && r(t);
								});
							}))) : b ? (y = {
								from: (x = b.lower) ?? e.MIN_KEY,
								to: (v = b.upper) ?? e.MAX_KEY
							}, _.add(y), g.add(y)) : (g.add(r), _.add(r), l.indexes.forEach(function(e) {
								return i(e.name).add(r);
							})), c.mutate(t).then(function(e) {
								return !b || t.type !== "add" && t.type !== "put" || (g.addKeys(e.results), m && m.forEach(function(n) {
									for (var r = t.values.map(function(e) {
										return n.extractKey(e);
									}), a = n.keyPath.findIndex(function(e) {
										return e === u.keyPath;
									}), o = 0, s = e.results.length; o < s; ++o) r[o][a] = e.results[o];
									i(n.name).addKeys(r);
								})), p.mutatedParts = Nn(p.mutatedParts || {}, h), e;
							});
						} }), g = {
							get: function(e) {
								return [u, new En(e.key)];
							},
							getMany: function(e) {
								return [u, new En().addKeys(e.keys)];
							},
							count: s,
							query: s,
							openCursor: s
						};
						return i(g).forEach(function(e) {
							h[e] = function(i) {
								var a = B.subscr, s = !!a, l = Xn(B, c) && Zn(e, i) ? i.obsSet = {} : a;
								if (s) {
									var u, a = function(e) {
										return e = `idb://${n}/${o}/${e}`, l[e] || (l[e] = new En());
									}, d = a(""), m = a(":dels"), s = g[e](i), h = s[0], s = s[1];
									if ((e === "query" && h.isPrimaryKey && !i.values ? m : a(h.name || "")).add(s), !h.isPrimaryKey) {
										if (e !== "count") return u = e === "query" && p && i.values && c.query(t(t({}, i), { values: !1 })), c[e].apply(this, arguments).then(function(t) {
											if (e === "query") {
												if (p && i.values) return u.then(function(e) {
													return e = e.result, d.addKeys(e), t;
												});
												var n = i.values ? t.result.map(f) : t.result;
												(i.values ? d : m).addKeys(n);
											} else {
												var r, a;
												if (e === "openCursor") return a = i.values, (r = t) && Object.create(r, {
													key: { get: function() {
														return m.addKey(r.primaryKey), r.key;
													} },
													primaryKey: { get: function() {
														var e = r.primaryKey;
														return m.addKey(e), e;
													} },
													value: { get: function() {
														return a && d.addKey(r.primaryKey), r.value;
													} }
												});
											}
											return t;
										});
										m.add(r);
									}
								}
								return c[e].apply(this, arguments);
							};
						}), h;
					}
				});
			}
		};
		function $n(e, n, r) {
			var i;
			return r.numFailures === 0 ? n : n.type === "deleteRange" || (i = n.keys ? n.keys.length : "values" in n && n.values ? n.values.length : 1, r.numFailures === i) ? null : (i = t({}, n), a(i.keys) && (i.keys = i.keys.filter(function(e, t) {
				return !(t in r.failures);
			})), "values" in i && a(i.values) && (i.values = i.values.filter(function(e, t) {
				return !(t in r.failures);
			})), i);
		}
		function er(e, t) {
			return n = e, ((r = t).lower === void 0 || (r.lowerOpen ? 0 < G(n, r.lower) : 0 <= G(n, r.lower))) && (n = e, (r = t).upper === void 0 || (r.upperOpen ? G(n, r.upper) < 0 : G(n, r.upper) <= 0));
			var n, r;
		}
		function tr(e, t, n, r, i, o) {
			var s, c, l, u, d, f, p;
			return !n || n.length === 0 || (s = t.query.index, c = s.multiEntry, l = t.query.range, u = r.schema.primaryKey.extractKey, d = s.extractKey, f = (s.lowLevelIndex || s).extractKey, (r = n.reduce(function(e, n) {
				var r = e, i = [];
				if (n.type === "add" || n.type === "put") for (var o = new En(), s = n.values.length - 1; 0 <= s; --s) {
					var f, p = n.values[s], m = u(p);
					!o.hasKey(m) && (f = d(p), c && a(f) ? f.some(function(e) {
						return er(e, l);
					}) : er(f, l)) && (o.addKey(m), i.push(p));
				}
				switch (n.type) {
					case "add":
						var h = new En().addKeys(t.values ? e.map(function(e) {
							return u(e);
						}) : e), r = e.concat(t.values ? i.filter(function(e) {
							return e = u(e), !h.hasKey(e) && (h.addKey(e), !0);
						}) : i.map(function(e) {
							return u(e);
						}).filter(function(e) {
							return !h.hasKey(e) && (h.addKey(e), !0);
						}));
						break;
					case "put":
						var g = new En().addKeys(n.values.map(function(e) {
							return u(e);
						}));
						r = e.filter(function(e) {
							return !g.hasKey(t.values ? u(e) : e);
						}).concat(t.values ? i : i.map(function(e) {
							return u(e);
						}));
						break;
					case "delete":
						var _ = new En().addKeys(n.keys);
						r = e.filter(function(e) {
							return !_.hasKey(t.values ? u(e) : e);
						});
						break;
					case "deleteRange":
						var v = n.range;
						r = e.filter(function(e) {
							return !er(u(e), v);
						});
				}
				return r;
			}, e)) === e) ? e : (p = function(e, t) {
				return G(f(e), f(t)) || G(u(e), u(t));
			}, r.sort(t.direction === "prev" || t.direction === "prevunique" ? function(e, t) {
				return p(t, e);
			} : p), t.limit && t.limit < 1 / 0 && (r.length > t.limit ? r.length = t.limit : e.length === t.limit && r.length < t.limit && (i.dirty = !0)), o ? Object.freeze(r) : r);
		}
		function nr(e, t) {
			return G(e.lower, t.lower) === 0 && G(e.upper, t.upper) === 0 && !!e.lowerOpen == !!t.lowerOpen && !!e.upperOpen == !!t.upperOpen;
		}
		function rr(e, t) {
			return ((e, t, n, r) => {
				if (e === void 0) return t === void 0 ? 0 : -1;
				if (t === void 0) return 1;
				if ((e = G(e, t)) === 0) {
					if (n && r) return 0;
					if (n) return 1;
					if (r) return -1;
				}
				return e;
			})(e.lower, t.lower, e.lowerOpen, t.lowerOpen) <= 0 && 0 <= ((e, t, n, r) => {
				if (e === void 0) return t === void 0 ? 0 : 1;
				if (t === void 0) return -1;
				if ((e = G(e, t)) === 0) {
					if (n && r) return 0;
					if (n) return -1;
					if (r) return 1;
				}
				return e;
			})(e.upper, t.upper, e.upperOpen, t.upperOpen);
		}
		function ir(e, t, n, r) {
			e.subscribers.add(n), r.addEventListener("abort", function() {
				var r, i;
				e.subscribers.delete(n), e.subscribers.size === 0 && (r = e, i = t, setTimeout(function() {
					r.subscribers.size === 0 && O(i, r);
				}, 3e3));
			});
		}
		var ar = {
			stack: "dbcore",
			level: 0,
			name: "Cache",
			create: function(e) {
				var n = e.schema.name;
				return t(t({}, e), {
					transaction: function(t, r, i) {
						var a, o, s = e.transaction(t, r, i);
						return r === "readwrite" && (i = (a = new AbortController()).signal, s.addEventListener("abort", (o = function(i) {
							return function() {
								if (a.abort(), r === "readwrite") {
									for (var o = /* @__PURE__ */ new Set(), c = 0, l = t; c < l.length; c++) {
										var u = l[c], d = Fn[`idb://${n}/${u}`];
										if (d) {
											var f = e.table(u), p = d.optimisticOps.filter(function(e) {
												return e.trans === s;
											});
											if (s._explicit && i && s.mutatedParts) for (var m = 0, h = Object.values(d.queries.query); m < h.length; m++) for (var g = 0, _ = (b = h[m]).slice(); g < _.length; g++) Pn((x = _[g]).obsSet, s.mutatedParts) && (O(b, x), x.subscribers.forEach(function(e) {
												return o.add(e);
											}));
											else if (0 < p.length) {
												d.optimisticOps = d.optimisticOps.filter(function(e) {
													return e.trans !== s;
												});
												for (var v = 0, y = Object.values(d.queries.query); v < y.length; v++) for (var b, x, S, C = 0, w = (b = y[v]).slice(); C < w.length; C++) (x = w[C]).res != null && s.mutatedParts && (i && !x.dirty ? (S = Object.isFrozen(x.res), S = tr(x.res, x.req, p, f, x, S), x.dirty ? (O(b, x), x.subscribers.forEach(function(e) {
													return o.add(e);
												})) : S !== x.res && (x.res = S, x.promise = V.resolve({ result: S }))) : (x.dirty && O(b, x), x.subscribers.forEach(function(e) {
													return o.add(e);
												})));
											}
										}
									}
									o.forEach(function(e) {
										return e();
									});
								}
							};
						})(!1), { signal: i }), s.addEventListener("error", o(!1), { signal: i }), s.addEventListener("complete", o(!0), { signal: i })), s;
					},
					table: function(r) {
						var i = e.table(r), a = i.schema.primaryKey;
						return t(t({}, i), {
							mutate: function(e) {
								var o, s = B.trans;
								return !a.outbound && s.db._options.cache !== "disabled" && !s.explicit && s.idbtrans.mode === "readwrite" && (o = Fn[`idb://${n}/${r}`]) ? (s = i.mutate(e), e.type !== "add" && e.type !== "put" || !(50 <= e.values.length || Kn(a, e).some(function(e) {
									return e == null;
								})) ? (o.optimisticOps.push(e), e.mutatedParts && Rn(e.mutatedParts), s.then(function(t) {
									0 < t.numFailures && (O(o.optimisticOps, e), (t = $n(0, e, t)) && o.optimisticOps.push(t), e.mutatedParts) && Rn(e.mutatedParts);
								}), s.catch(function() {
									O(o.optimisticOps, e), e.mutatedParts && Rn(e.mutatedParts);
								})) : s.then(function(n) {
									var r = $n(0, t(t({}, e), { values: e.values.map(function(e, r) {
										var i;
										return n.failures[r] ? e : (x(i = (i = a.keyPath) != null && i.includes(".") ? te(e) : t({}, e), a.keyPath, n.results[r]), i);
									}) }), n);
									o.optimisticOps.push(r), queueMicrotask(function() {
										return e.mutatedParts && Rn(e.mutatedParts);
									});
								}), s) : i.mutate(e);
							},
							query: function(e) {
								var t, a, o, s, c, l, u;
								return Xn(B, i) && Zn("query", e) ? (t = (o = B.trans)?.db._options.cache === "immutable", a = (o = B).requery, o = o.signal, l = ((e, t, n, r) => {
									var i = Fn[`idb://${e}/${t}`];
									if (!i) return [];
									if (!(e = i.queries[n])) return [
										null,
										!1,
										i,
										null
									];
									var a = e[(r.query ? r.query.index.name : null) || ""];
									if (!a) return [
										null,
										!1,
										i,
										null
									];
									switch (n) {
										case "query":
											var o = (s = r.direction) ?? "next", s = a.find(function(e) {
												return e.req.limit === r.limit && e.req.values === r.values && (e.req.direction ?? "next") === o && nr(e.req.query.range, r.query.range);
											});
											return s ? [
												s,
												!0,
												i,
												a
											] : [
												a.find(function(e) {
													return ("limit" in e.req ? e.req.limit : 1 / 0) >= r.limit && (e.req.direction ?? "next") === o && (!r.values || e.req.values) && rr(e.req.query.range, r.query.range);
												}),
												!1,
												i,
												a
											];
										case "count": return s = a.find(function(e) {
											return nr(e.req.query.range, r.query.range);
										}), [
											s,
											!!s,
											i,
											a
										];
									}
								})(n, r, "query", e), u = l[0], s = l[2], c = l[3], u && l[1] ? u.obsSet = e.obsSet : (l = i.query(e).then(function(e) {
									var n = e.result;
									if (u && (u.res = n), t) {
										for (var r = 0, i = n.length; r < i; ++r) Object.freeze(n[r]);
										Object.freeze(n);
									}
									return e;
								}).catch(function(e) {
									return c && u && O(c, u), Promise.reject(e);
								}), u = {
									obsSet: e.obsSet,
									promise: l,
									subscribers: /* @__PURE__ */ new Set(),
									type: "query",
									req: e,
									dirty: !1
								}, c ? c.push(u) : (c = [u], (s ||= Fn[`idb://${n}/${r}`] = {
									queries: {
										query: {},
										count: {}
									},
									objs: /* @__PURE__ */ new Map(),
									optimisticOps: [],
									unsignaledParts: {}
								}).queries.query[e.query.index.name || ""] = c)), ir(u, c, a, o), u.promise.then(function(n) {
									return n = tr(n.result, e, s?.optimisticOps, i, u, t), { result: t ? n : te(n) };
								})) : i.query(e);
							}
						});
					}
				});
			}
		};
		function or(e, t) {
			return new Proxy(e, { get: function(e, n, r) {
				return n === "db" ? t : Reflect.get(e, n, r);
			} });
		}
		cr.prototype.version = function(e) {
			if (isNaN(e) || e < .1) throw new F.Type("Given version is not a positive number");
			if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new F.Schema("Cannot add version when database is open");
			this.verno = Math.max(this.verno, e);
			var t = this._versions, n = t.filter(function(t) {
				return t._cfg.version === e;
			})[0];
			return n || (n = new this.Version(e), t.push(n), t.sort(un), n.stores({}), this._state.autoSchema = !1), n;
		}, cr.prototype._whenReady = function(e) {
			var t = this;
			return this.idbdb && (this._state.openComplete || B.letThrough || this._vip) ? e() : new V(function(e, n) {
				if (t._state.openComplete) return n(new F.DatabaseClosed(t._state.dbOpenError));
				if (!t._state.isBeingOpened) {
					if (!t._state.autoOpen) return void n(new F.DatabaseClosed());
					t.open().catch(I);
				}
				t._state.dbReadyPromise.then(e, n);
			}).then(e);
		}, cr.prototype.use = function(e) {
			var t = e.stack, n = e.create, r = e.level, e = e.name, i = (e && this.unuse({
				stack: t,
				name: e
			}), this._middlewares[t] || (this._middlewares[t] = []));
			return i.push({
				stack: t,
				create: n,
				level: r ?? 10,
				name: e
			}), i.sort(function(e, t) {
				return e.level - t.level;
			}), this;
		}, cr.prototype.unuse = function(e) {
			var t = e.stack, n = e.name, r = e.create;
			return t && this._middlewares[t] && (this._middlewares[t] = this._middlewares[t].filter(function(e) {
				return r ? e.create !== r : !!n && e.name !== n;
			})), this;
		}, cr.prototype.open = function() {
			var e = this;
			return nt(z, function() {
				return Vn(e);
			});
		}, cr.prototype._close = function() {
			this.on.close.fire(new CustomEvent("close"));
			var e = this._state;
			if (xn.remove(this), this.idbdb) {
				try {
					this.idbdb.close();
				} catch {}
				this.idbdb = null;
			}
			e.isBeingOpened || (e.dbReadyPromise = new V(function(t) {
				e.dbReadyResolve = t;
			}), e.openCanceller = new V(function(t, n) {
				e.cancelOpen = n;
			}));
		}, cr.prototype.close = function(e) {
			var e = (e === void 0 ? { disableAutoOpen: !0 } : e).disableAutoOpen, t = this._state;
			e ? (t.isBeingOpened && t.cancelOpen(new F.DatabaseClosed()), this._close(), t.autoOpen = !1, t.dbOpenError = new F.DatabaseClosed()) : (this._close(), t.autoOpen = this._options.autoOpen || t.isBeingOpened, t.openComplete = !1, t.dbOpenError = null);
		}, cr.prototype.delete = function(e) {
			var t = this, n = (e === void 0 && (e = { disableAutoOpen: !0 }), 0 < arguments.length && typeof arguments[0] != "object"), r = this._state;
			return new V(function(i, a) {
				function o() {
					t.close(e);
					var n = t._deps.indexedDB.deleteDatabase(t.name);
					n.onsuccess = U(function() {
						var e = t._deps, n = t.name, r;
						Cn(r = e.indexedDB) || n === lt || Sn(r, e.IDBKeyRange).delete(n).catch(I), i();
					}), n.onerror = Ut(a), n.onblocked = t._fireOnBlocked;
				}
				if (n) throw new F.InvalidArgument("Invalid closeOptions argument to db.delete()");
				r.isBeingOpened ? r.dbReadyPromise.then(o) : o();
			});
		}, cr.prototype.backendDB = function() {
			return this.idbdb;
		}, cr.prototype.isOpen = function() {
			return this.idbdb !== null;
		}, cr.prototype.hasBeenClosed = function() {
			var e = this._state.dbOpenError;
			return e && e.name === "DatabaseClosed";
		}, cr.prototype.hasFailed = function() {
			return this._state.dbOpenError !== null;
		}, cr.prototype.dynamicallyOpened = function() {
			return this._state.autoSchema;
		}, Object.defineProperty(cr.prototype, "tables", {
			get: function() {
				var e = this;
				return i(this._allTables).map(function(t) {
					return e._allTables[t];
				});
			},
			enumerable: !1,
			configurable: !0
		}), cr.prototype.transaction = function() {
			var e = function(e, t, n) {
				var r = arguments.length;
				if (r < 2) throw new F.InvalidArgument("Too few arguments");
				for (var i = Array(r - 1); --r;) i[r - 1] = arguments[r];
				return n = i.pop(), [
					e,
					w(i),
					n
				];
			}.apply(this, arguments);
			return this._transaction.apply(this, e);
		}, cr.prototype._transaction = function(e, t, n) {
			var r, i, a = this, o = B.trans, s = (o && o.db === this && e.indexOf("!") === -1 || (o = null), e.indexOf("?") !== -1);
			e = e.replace("!", "").replace("?", "");
			try {
				if (i = t.map(function(e) {
					if (e = e instanceof a.Table ? e.name : e, typeof e != "string") throw TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
					return e;
				}), e == "r" || e === ut) r = ut;
				else {
					if (e != "rw" && e != dt) throw new F.InvalidArgument("Invalid transaction mode: " + e);
					r = dt;
				}
				if (o) {
					if (o.mode === ut && r === dt) {
						if (!s) throw new F.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
						o = null;
					}
					o && i.forEach(function(e) {
						if (o && o.storeNames.indexOf(e) === -1) {
							if (!s) throw new F.SubTransaction("Table " + e + " not included in parent transaction.");
							o = null;
						}
					}), s && o && !o.active && (o = null);
				}
			} catch (e) {
				return o ? o._promise(null, function(t, n) {
					n(e);
				}) : at(e);
			}
			var c = function e(t, n, r, i, a) {
				return V.resolve().then(function() {
					var o = B.transless || B, s = t._createTransaction(n, r, t._dbSchema, i), o = (s.explicit = !0, {
						trans: s,
						transless: o
					});
					if (i) s.idbtrans = i.idbtrans;
					else try {
						s.create(), s.idbtrans._explicit = !0, t._state.PR1398_maxLoop = 3;
					} catch (i) {
						return i.name === P.InvalidState && t.isOpen() && 0 < --t._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), t.close({ disableAutoOpen: !1 }), t.open().then(function() {
							return e(t, n, r, null, a);
						})) : at(i);
					}
					var c, l = A(a), o = (l && Ze(), V.follow(function() {
						var e;
						(c = a.call(s, s)) && (l ? (e = Qe.bind(null, null), c.then(e, e)) : typeof c.next == "function" && typeof c.throw == "function" && (c = Hn(c)));
					}, o));
					return (c && typeof c.then == "function" ? V.resolve(c).then(function(e) {
						return s.active ? e : at(new F.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
					}) : o.then(function() {
						return c;
					})).then(function(e) {
						return i && s._resolve(), s._completion.then(function() {
							return e;
						});
					}).catch(function(e) {
						return s._reject(e), at(e);
					});
				});
			}.bind(null, this, r, i, o, n);
			return o ? o._promise(r, c, "lock") : B.trans ? nt(B.transless, function() {
				return a._whenReady(c);
			}) : this._whenReady(c);
		}, cr.prototype.table = function(e) {
			if (l(this._allTables, e)) return this._allTables[e];
			throw new F.InvalidTable(`Table ${e} does not exist`);
		};
		var sr = cr;
		function cr(e, n) {
			var r, i, a, o, s, c = this, l = (this._middlewares = {}, this.verno = 0, cr.dependencies), l = (this._options = n = t({
				addons: cr.addons,
				autoOpen: !0,
				indexedDB: l.indexedDB,
				IDBKeyRange: l.IDBKeyRange,
				cache: "cloned",
				maxConnections: 1e3
			}, n), this._deps = {
				indexedDB: n.indexedDB,
				IDBKeyRange: n.IDBKeyRange
			}, n.addons), u = (this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this, {
				dbOpenError: null,
				isBeingOpened: !1,
				onReadyBeingFired: null,
				openComplete: !1,
				dbReadyResolve: I,
				dbReadyPromise: null,
				cancelOpen: I,
				openCanceller: null,
				autoSchema: !0,
				PR1398_maxLoop: 3,
				autoOpen: n.autoOpen
			}), d = (u.dbReadyPromise = new V(function(e) {
				u.dbReadyResolve = e;
			}), u.openCanceller = new V(function(e, t) {
				u.cancelOpen = t;
			}), this._state = u, this.name = e, this.on = Ct(this, "populate", "blocked", "versionchange", "close", { ready: [ve, I] }), this.once = function(e, t) {
				var n = function() {
					var r = [...arguments];
					c.on(e).unsubscribe(n), t.apply(c, r);
				};
				return c.on(e, n);
			}, this.on.ready.subscribe = _(this.on.ready.subscribe, function(e) {
				return function(t, n) {
					cr.vip(function() {
						var r, i = c._state;
						i.openComplete ? (i.dbOpenError || V.resolve().then(t), n && e(t)) : i.onReadyBeingFired ? (i.onReadyBeingFired.push(t), n && e(t)) : (e(t), r = c, n || e(function e() {
							r.on.ready.unsubscribe(t), r.on.ready.unsubscribe(e);
						}));
					});
				};
			}), this.Collection = (r = this, wt(Mt.prototype, function(e, t) {
				this.db = r;
				var n = pt, i = null;
				if (t) try {
					n = t();
				} catch (e) {
					i = e;
				}
				var t = e._ctx, e = t.table, a = e.hook.reading.fire;
				this._ctx = {
					table: e,
					index: t.index,
					isPrimKey: !t.index || e.schema.primKey.keyPath && t.index === e.schema.primKey.name,
					range: n,
					keysOnly: !1,
					dir: "next",
					unique: "",
					algorithm: null,
					filter: null,
					replayFilter: null,
					justLimit: !0,
					isMatch: null,
					offset: 0,
					limit: 1 / 0,
					error: i,
					or: t.or,
					valueMapper: a === de ? null : a
				};
			})), this.Table = (i = this, wt(St.prototype, function(e, t, n) {
				this.db = i, this._tx = n, this.name = e, this.schema = t, this.hook = i._allTables[e] ? i._allTables[e].hook : Ct(null, {
					creating: [me, I],
					reading: [fe, de],
					updating: [ge, I],
					deleting: [he, I]
				});
			})), this.Transaction = (a = this, wt(Jt.prototype, function(e, t, n, r, i) {
				var o = this;
				e !== "readonly" && t.forEach(function(e) {
					e = (e = n[e])?.yProps, e && (t = t.concat(e.map(function(e) {
						return e.updatesTable;
					})));
				}), this.db = a, this.mode = e, this.storeNames = t, this.schema = n, this.chromeTransactionDurability = r, this.idbtrans = null, this.on = Ct(this, "complete", "error", "abort"), this.parent = i || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new V(function(e, t) {
					o._resolve = e, o._reject = t;
				}), this._completion.then(function() {
					o.active = !1, o.on.complete.fire();
				}, function(e) {
					var t = o.active;
					return o.active = !1, o.on.error.fire(e), o.parent ? o.parent._reject(e) : t && o.idbtrans && o.idbtrans.abort(), at(e);
				});
			})), this.Version = (o = this, wt(yn.prototype, function(e) {
				this.db = o, this._cfg = {
					version: e,
					storesSource: null,
					dbschema: {},
					tables: {},
					contentUpgrade: null
				};
			})), this.WhereClause = (s = this, wt(Vt.prototype, function(e, t, n) {
				if (this.db = s, this._ctx = {
					table: e,
					index: t === ":id" ? null : t,
					or: n
				}, this._cmp = this._ascending = G, this._descending = function(e, t) {
					return G(t, e);
				}, this._max = function(e, t) {
					return 0 < G(e, t) ? e : t;
				}, this._min = function(e, t) {
					return G(e, t) < 0 ? e : t;
				}, this._IDBKeyRange = s._deps.IDBKeyRange, !this._IDBKeyRange) throw new F.MissingAPI();
			})), this.on("versionchange", function(e) {
				0 < e.newVersion ? console.warn(`Another connection wants to upgrade database '${c.name}'. Closing db now to resume the upgrade.`) : console.warn(`Another connection wants to delete database '${c.name}'. Closing db now to resume the delete request.`), c.close({ disableAutoOpen: !1 });
			}), this.on("blocked", function(e) {
				!e.newVersion || e.newVersion < e.oldVersion ? console.warn(`Dexie.delete('${c.name}') was blocked`) : console.warn(`Upgrade '${c.name}' blocked by other connection holding version ${e.oldVersion / 10}`);
			}), this._maxKey = $t(n.IDBKeyRange), this._createTransaction = function(e, t, n, r) {
				return new c.Transaction(e, t, n, c._options.chromeTransactionDurability, r);
			}, this._fireOnBlocked = function(e) {
				c.on("blocked").fire(e), xn.toArray().filter(function(e) {
					return e.name === c.name && e !== c && !e._state.vcFired;
				}).map(function(t) {
					return t.on("versionchange").fire(e);
				});
			}, this.use(Yn), this.use(ar), this.use(Qn), this.use(Wn), this.use(qn), new Proxy(this, { get: function(e, t, n) {
				var r;
				return t === "_vip" || (t === "table" ? function(e) {
					return or(c.table(e), d);
				} : (r = Reflect.get(e, t, n)) instanceof St ? or(r, d) : t === "tables" ? r.map(function(e) {
					return or(e, d);
				}) : t === "_createTransaction" ? function() {
					return or(r.apply(this, arguments), d);
				} : r);
			} }));
			this.vip = d, l.forEach(function(e) {
				return e(c);
			});
		}
		var lr, we = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", ur = (dr.prototype.subscribe = function(e, t, n) {
			return this._subscribe(e && typeof e != "function" ? e : {
				next: e,
				error: t,
				complete: n
			});
		}, dr.prototype[we] = function() {
			return this;
		}, dr);
		function dr(e) {
			this._subscribe = e;
		}
		try {
			lr = {
				indexedDB: r.indexedDB || r.mozIndexedDB || r.webkitIndexedDB || r.msIndexedDB,
				IDBKeyRange: r.IDBKeyRange || r.webkitIDBKeyRange
			};
		} catch {
			lr = {
				indexedDB: null,
				IDBKeyRange: null
			};
		}
		function fr(e) {
			var t, n = !1, r = new ur(function(r) {
				var i = A(e), a, o = !1, s = {}, c = {}, l = {
					get closed() {
						return o;
					},
					unsubscribe: function() {
						o || (o = !0, a && a.abort(), u && qt.storagemutated.unsubscribe(p));
					}
				}, u = (r.start && r.start(l), !1), d = function() {
					return it(m);
				};
				function f() {
					return Pn(c, s);
				}
				var p = function(e) {
					Nn(s, e), f() && d();
				}, m = function() {
					var l, m, h;
					!o && lr.indexedDB && (s = {}, l = {}, a && a.abort(), a = new AbortController(), h = ((t) => {
						var n = Be();
						try {
							i && Ze();
							var r = Xe(e, t);
							return r = i ? r.finally(Qe) : r;
						} finally {
							n && Ve();
						}
					})(m = {
						subscr: l,
						signal: a.signal,
						requery: d,
						querier: e,
						trans: null
					}), u ||= (qt.storagemutated.subscribe(p), !0), Promise.resolve(h).then(function(e) {
						n = !0, t = e, o || m.signal.aborted || (f() || (c = l, f()) ? d() : (s = {}, it(function() {
							return !o && r.next && r.next(e);
						})));
					}, function(e) {
						n = !1, ["DatabaseClosedError", "AbortError"].includes(e?.name) || o || it(function() {
							o || r.error && r.error(e);
						});
					}));
				};
				return setTimeout(d, 0), l;
			});
			return r.hasValue = function() {
				return n;
			}, r.getValue = function() {
				return t;
			}, r;
		}
		var pr = sr;
		function mr(e) {
			var t = Y;
			try {
				Y = !0, qt.storagemutated.fire(e), zn(e, !0);
			} finally {
				Y = t;
			}
		}
		u(pr, t(t({}, T), {
			delete: function(e) {
				return new pr(e, { addons: [] }).delete();
			},
			exists: function(e) {
				return new pr(e, { addons: [] }).open().then(function(e) {
					return e.close(), !0;
				}).catch("NoSuchDatabaseError", function() {
					return !1;
				});
			},
			getDatabaseNames: function(e) {
				try {
					return t = pr.dependencies, n = t.indexedDB, t = t.IDBKeyRange, (Cn(n) ? Promise.resolve(n.databases()).then(function(e) {
						return e.map(function(e) {
							return e.name;
						}).filter(function(e) {
							return e !== lt;
						});
					}) : Sn(n, t).toCollection().primaryKeys()).then(e);
				} catch {
					return at(new F.MissingAPI());
				}
				var t, n;
			},
			defineClass: function() {
				return function(e) {
					o(this, e);
				};
			},
			ignoreTransaction: function(e) {
				return B.trans ? nt(B.transless || z, e) : e();
			},
			vip: wn,
			async: function(e) {
				return function() {
					try {
						var t = Hn(e.apply(this, arguments));
						return t && typeof t.then == "function" ? t : V.resolve(t);
					} catch (e) {
						return at(e);
					}
				};
			},
			spawn: function(e, t, n) {
				try {
					var r = Hn(e.apply(n, t || []));
					return r && typeof r.then == "function" ? r : V.resolve(r);
				} catch (e) {
					return at(e);
				}
			},
			currentTransaction: { get: function() {
				return B.trans || null;
			} },
			waitFor: function(e, t) {
				return e = V.resolve(typeof e == "function" ? pr.ignoreTransaction(e) : e).timeout(t || 6e4), B.trans ? B.trans.waitFor(e) : e;
			},
			Promise: V,
			debug: {
				get: function() {
					return ye;
				},
				set: function(e) {
					be(e);
				}
			},
			derive: p,
			extend: o,
			props: u,
			override: _,
			Events: Ct,
			on: qt,
			liveQuery: fr,
			extendObservabilitySet: Nn,
			getByKeyPath: b,
			setByKeyPath: x,
			delByKeyPath: function(e, t) {
				typeof t == "string" ? x(e, t, void 0) : "length" in t && [].map.call(t, function(t) {
					x(e, t, void 0);
				});
			},
			shallowClone: S,
			deepClone: te,
			getObjectDiff: Gn,
			cmp: G,
			asap: y,
			minKey: -1 / 0,
			addons: [],
			connections: { get: xn.toArray },
			errnames: P,
			dependencies: lr,
			cache: Fn,
			semVer: "4.4.6",
			version: "4.4.6".split(".").map(function(e) {
				return parseInt(e);
			}).reduce(function(e, t, n) {
				return e + t / 10 ** (2 * n);
			})
		})), pr.maxKey = $t(pr.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (qt(Gt, function(e) {
			Y ||= (e = new CustomEvent(Kt, { detail: e }), Y = !0, dispatchEvent(e), !1);
		}), addEventListener(Kt, function(e) {
			e = e.detail, Y || mr(e);
		}));
		var hr, Y = !1, gr = function() {};
		return typeof BroadcastChannel < "u" && ((gr = function() {
			(hr = new BroadcastChannel(Kt)).onmessage = function(e) {
				return e.data && mr(e.data);
			};
		})(), typeof hr.unref == "function" && hr.unref(), qt(Gt, function(e) {
			Y || hr.postMessage(e);
		})), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
			if (!sr.disableBfCache && e.persisted) {
				ye && console.debug("Dexie: handling persisted pagehide"), hr?.close();
				for (var t = 0, n = xn.toArray(); t < n.length; t++) n[t].close({ disableAutoOpen: !1 });
			}
		}), addEventListener("pageshow", function(e) {
			!sr.disableBfCache && e.persisted && (ye && console.debug("Dexie: handling persisted pageshow"), gr(), mr({ all: new En(-1 / 0, [[]]) }));
		})), V.rejectionMapper = function(e, t) {
			return !e || e instanceof M || e instanceof TypeError || e instanceof SyntaxError || !e.name || !ue[e.name] ? e : (t = new ue[e.name](t || e.message, e), "stack" in e && f(t, "stack", { get: function() {
				return this.inner.stack;
			} }), t);
		}, be(ye), t(sr, Object.freeze({
			__proto__: null,
			DEFAULT_MAX_CONNECTIONS: 1e3,
			Dexie: sr,
			Entity: ht,
			PropModification: yt,
			RangeSet: En,
			add: function(e) {
				return new yt({ add: e });
			},
			cmp: G,
			default: sr,
			liveQuery: fr,
			mergeRanges: On,
			rangesOverlap: kn,
			remove: function(e) {
				return new yt({ remove: e });
			},
			replacePrefix: function(e, t) {
				return new yt({ replacePrefix: [e, t] });
			}
		}), { default: sr }), sr;
	});
})))(), 1), ze = Symbol.for("Dexie"), H = globalThis[ze] || (globalThis[ze] = Re.default);
if (Re.default.semVer !== H.semVer) throw Error(`Two different versions of Dexie loaded in the same app: ${Re.default.semVer} and ${H.semVer}`);
var { liveQuery: Be, mergeRanges: Ve, rangesOverlap: He, RangeSet: Ue, cmp: U, Entity: We, PropModification: Ge, replacePrefix: Ke, add: qe, remove: Je, DexieYProvider: Ye } = H, Xe = 8388608, Ze = 268435456, Qe = 4e6, W = () => {
	throw new s("SAVE_FAILED", "大きな履歴の分割記録が破損しています。既存データを保持しています。");
}, $e = JSON.stringify, et = Object.getOwnPropertyDescriptor, tt = Object.getPrototypeOf, nt = Object.prototype, rt = Array.prototype, it = Number.prototype;
function at() {
	return JSON.stringify === $e && tt(nt) === null && tt(rt) === nt && et(nt, "toJSON") === void 0 && et(rt, "toJSON") === void 0 && et(it, "toJSON") === void 0;
}
var ot = (e) => {
	let t = (e) => {
		if (e === null) return "null";
		if (typeof e == "boolean") return e ? "true" : "false";
		if (typeof e == "number") return Number.isFinite(e) ? JSON.stringify(e) : A(e);
		if (e && typeof e == "object" && !Array.isArray(e)) {
			let t = Object.keys(e), n = e;
			if (t.length === 1 && t[0] === "undefined" && Object.hasOwn(e, "undefined") && n.undefined === !0) return "{\"undefined\":true}";
			if (t.length === 1 && t[0] === "number" && Object.hasOwn(e, "number") && typeof n.number == "number" && Number.isFinite(n.number)) return "{\"number\":" + JSON.stringify(n.number) + "}";
		}
		return A(e);
	}, n = [];
	for (let r = 0; r < e.length; r++) n.push(t(e[r]));
	return "[" + n.join(",") + "]";
};
async function st(e, t, n, r) {
	o(n);
	let i = [], a = /* @__PURE__ */ new WeakMap(), c = /* @__PURE__ */ new WeakSet(), l = [], u = /* @__PURE__ */ new Map(), d = (e) => {
		let t = u.get(e);
		return t === void 0 && (t = l.length, l.push(e), u.set(e, t)), t;
	}, f = (e) => {
		if (e === void 0) return { undefined: !0 };
		if (typeof e == "string") return -d(e) - 1;
		if (typeof e == "number") return Number.isFinite(e) ? { number: e } : W();
		if (e === null || typeof e == "boolean") return e;
		if (!e || typeof e != "object" || !Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return W();
		let t = a.get(e);
		if (t !== void 0) return c.has(e) ? W() : t;
		let n = i.length;
		if (n >= Qe) return W();
		a.set(e, n), c.add(e);
		let o = [+!Array.isArray(e)];
		if (i.push(o), Array.isArray(e)) {
			if (Object.keys(e).length !== e.length) return W();
			if (r) for (let t = 0; t < e.length; t++) o.push(f(e[t]));
			else for (let t of e) o.push(f(t));
		} else if (r) for (let t of Object.keys(e)) o.push(d(t), f(e[t]));
		else for (let [t, n] of Object.entries(e)) o.push(d(t), f(n));
		return c.delete(e), n;
	}, p = f(e), m = [], h = 0, g = new TextEncoder(), _ = r && at();
	for (let [e, a] of [["strings", l], ["nodes", i]]) {
		let i = [], c = 0, l = async () => {
			if (!i.length) return;
			o(n);
			let a = g.encode(`[${i.join(",")}]`);
			if (h += a.byteLength, a.byteLength > Xe || h > Ze) throw new s("LIMIT_EXCEEDED", "履歴の分割記録が端末の安全上限を超えています。");
			let l = m.length;
			m.push({
				key: `${t}:${l}`,
				scope: t,
				sequence: l,
				kind: e,
				bytes: a,
				sha256: await D(a)
			}), o(n), _ = r && at(), i = [], c = 0;
		};
		for (let t of a) {
			let n = e === "nodes" ? _ ? $e(t) : ot(t) : A(t), a = e === "nodes" ? n.length : r ? ct(n) : g.encode(n).byteLength;
			if (a > Xe) return W();
			i.length && c + a + i.length + 2 > Xe / 4 && await l(), i.push(n), c += a;
		}
		await l();
	}
	return o(n), {
		packed: {
			version: 1,
			scope: t,
			root: p,
			nodes: i.length,
			strings: l.length,
			parts: m.map((e) => ({
				key: e.key,
				kind: e.kind,
				bytes: e.bytes.byteLength,
				sha256: e.sha256
			}))
		},
		parts: m
	};
}
function ct(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		r < 128 ? t++ : r < 2048 ? t += 2 : r >= 55296 && r <= 56319 ? (t += 4, n++) : t += 3;
	}
	return t;
}
function lt(e, t, n) {
	return st(e, t, n, !1);
}
async function ut(e, t, n) {
	if (o(n), e.version !== 1 || typeof e.scope != "string" || !Number.isSafeInteger(e.nodes) || e.nodes < 0 || e.nodes > Qe || !Number.isSafeInteger(e.strings) || e.strings < 0 || e.strings > Qe || !Array.isArray(e.parts) || e.parts.length !== t.length || new Set(t.map((e) => e.key)).size !== t.length) return W();
	let r = 0;
	for (let e of t) if (!(e.bytes instanceof Uint8Array) || e.bytes.byteLength > Xe || (r += e.bytes.byteLength, r > Ze)) return W();
	e = structuredClone(e), t = t.map((e) => ({
		...e,
		bytes: new Uint8Array(e.bytes)
	}));
	let i = [], a = [], s = new Map(t.map((e) => [e.key, e])), c = 0;
	for (let [t, r] of e.parts.entries()) {
		o(n);
		let l = s.get(r.key);
		if (!l || l.scope !== e.scope || l.sequence !== t || r.key !== `${e.scope}:${t}` || !["strings", "nodes"].includes(r.kind) || l.kind !== r.kind || !(l.bytes instanceof Uint8Array) || l.bytes.byteLength !== r.bytes || r.bytes > Xe || l.sha256 !== r.sha256 || !/^([a-f0-9]{64})$/.test(r.sha256) || await D(l.bytes) !== r.sha256 || (c += r.bytes, c > Ze)) return W();
		let u = he(l.bytes, l.key, {
			...N,
			jsonBytes: Xe,
			expandedBytes: Ze
		});
		if (!Array.isArray(u)) return W();
		if (l.kind === "strings") {
			if (a.length + u.length > e.strings || u.some((e) => typeof e != "string")) return W();
			for (let e of u) a.push(e);
		} else {
			if (i.length + u.length > e.nodes) return W();
			for (let e of u) i.push(e);
		}
	}
	if (i.length !== e.nodes || a.length !== e.strings || new Set(a).size !== a.length) return W();
	let l = /* @__PURE__ */ new Set(), u = (e) => !Number.isSafeInteger(e) || e < 0 || e >= a.length ? W() : (l.add(e), a[e]), d = (e) => {
		if (e !== null && typeof e != "boolean") {
			if (typeof e == "number") {
				if (!Number.isSafeInteger(e)) return W();
				if (e < 0) {
					u(-e - 1);
					return;
				}
				return e >= i.length ? W() : e;
			}
			if (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).length !== 1 || !("undefined" in e && e.undefined === !0) && !("number" in e && typeof e.number == "number" && Number.isFinite(e.number))) return W();
		}
	}, f = (e) => {
		if (!Array.isArray(e) || e[0] !== 0 && e[0] !== 1) return W();
		if (e[0] === 0) return e.slice(1);
		if (e.length % 2 != 1) return W();
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 1; r < e.length; r += 2) {
			let i = u(e[r]);
			if (t.has(i)) return W();
			t.add(i), n.push(e[r + 1]);
		}
		return n;
	};
	d(e.root);
	for (let e of i) for (let t of f(e)) d(t);
	let p = new Uint8Array(i.length), m = d(e.root), h = 0;
	if (m !== void 0) {
		let e = [{
			id: m,
			next: 1
		}];
		for (; e.length;) {
			let t = e.at(-1), n = i[t.id];
			if (p[t.id] || (p[t.id] = 1, h++), t.next >= n.length) {
				p[t.id] = 2, e.pop();
				continue;
			}
			let r = t.next + +(n[0] === 1);
			t.next += n[0] === 1 ? 2 : 1;
			let a = d(n[r]);
			if (a !== void 0) {
				if (p[a] === 1 || e.length > 64) return W();
				p[a] || e.push({
					id: a,
					next: 1
				});
			}
		}
	}
	if (h !== i.length || l.size !== a.length) return W();
	let g = i.map((e) => e[0] === 0 ? [] : {}), _ = (e) => typeof e == "number" ? e < 0 ? u(-e - 1) : g[e] : e && typeof e == "object" ? "number" in e ? e.number : void 0 : e;
	for (let [e, t] of i.entries()) if (t[0] === 0) for (let n = 1; n < t.length; n++) g[e].push(_(t[n]));
	else for (let n = 1; n < t.length; n += 2) Object.defineProperty(g[e], u(t[n]), {
		value: _(t[n + 1]),
		enumerable: !0,
		configurable: !0,
		writable: !0
	});
	return o(n), _(e.root);
}
function dt(e, t = 8388608) {
	let n = 0, r = /* @__PURE__ */ new WeakSet(), i = [e];
	for (; i.length && n <= t;) {
		let e = i.pop();
		if (typeof e == "string") n += e.length * 2 + 16;
		else if (e && typeof e == "object") {
			if (r.has(e)) continue;
			r.add(e), n += 32;
			for (let [t, r] of Object.entries(e)) n += t.length * 2 + 16, i.push(r);
		} else n += 16;
	}
	return n > t;
}
//#endregion
//#region src/storage/workerGraph.ts
async function ft(e, t, n, r = () => !0) {
	let i = /* @__PURE__ */ new WeakMap(), a = [], c = {
		type: "graph-chunk",
		declarations: [],
		properties: []
	}, l = 0, u = (e) => {
		if (typeof e != "object" || !e) return { value: e };
		let t = i.get(e);
		return t === void 0 && (t = a.length, i.set(e, t), a.push({
			value: e,
			id: t,
			keys: Array.isArray(e) ? void 0 : Object.keys(e),
			index: 0
		}), c.declarations.push({
			id: t,
			...Array.isArray(e) ? { arrayLength: e.length } : Object.getPrototypeOf(e) === null ? { nullPrototype: !0 } : {}
		})), { reference: t };
	}, d = u(e), f = async () => {
		if (o(n), !r() || (t(c), c = {
			type: "graph-chunk",
			declarations: [],
			properties: []
		}, l = 0, await new Promise((e) => setTimeout(e, 0)), o(n), !r())) throw new s("CANCELLED", "保存の受渡しを取り消しました。");
	};
	for (let e = 0; e < a.length; e++) {
		let t = a[e], n = t.keys?.length ?? t.value.length;
		for (; t.index < n;) {
			let e = t.keys?.[t.index] ?? String(t.index), n = Object.getOwnPropertyDescriptor(t.value, e);
			if (!n || !Object.hasOwn(n, "value")) throw new s("SAVE_FAILED", "固定した保存内容が変更されています。");
			c.properties.push({
				id: t.id,
				key: e,
				value: u(n.value)
			}), l += e.length * 2 + (typeof n.value == "string" ? n.value.length * 2 : 32), t.index++, (c.properties.length >= 4096 || l >= 262144) && await f();
		}
		a[e] = void 0;
	}
	if ((c.declarations.length || c.properties.length) && await f(), o(n), !r()) throw new s("CANCELLED", "保存の受渡しを取り消しました。");
	t({
		type: "graph-end",
		root: d.reference
	});
}
var pt = class {
	values = /* @__PURE__ */ new Map();
	accept(e) {
		for (let t of e.declarations) {
			if (!Number.isSafeInteger(t.id) || t.id < 0 || this.values.has(t.id) || t.arrayLength !== void 0 && (!Number.isSafeInteger(t.arrayLength) || t.arrayLength < 0)) throw new s("SAVE_FAILED", "保存の受渡し情報が不正です。");
			this.values.set(t.id, t.arrayLength === void 0 ? Object.create(t.nullPrototype ? null : Object.prototype) : Array(t.arrayLength));
		}
		for (let t of e.properties) {
			let e = this.values.get(t.id);
			if (!e || [
				"__proto__",
				"constructor",
				"prototype"
			].includes(t.key) || Object.hasOwn(e, t.key) || Array.isArray(e) && (!/^(0|[1-9]\d*)$/.test(t.key) || Number(t.key) >= e.length)) throw new s("SAVE_FAILED", "保存の受渡し項目が不正です。");
			let n = "reference" in t.value ? this.values.get(t.value.reference) : t.value.value;
			if ("reference" in t.value && n === void 0) throw new s("SAVE_FAILED", "保存の受渡し参照が不足しています。");
			Object.defineProperty(e, t.key, {
				value: n,
				enumerable: !0,
				writable: !0,
				configurable: !0
			});
		}
	}
	finish(e) {
		let t = this.values.get(e);
		if (!t) throw new s("SAVE_FAILED", "保存の受渡し内容がありません。");
		return this.values.clear(), t;
	}
}, mt = 131072;
async function ht(e, t) {
	o(t);
	let n = [], r = 0;
	for (let i of e.parts) {
		let e = i.bytes;
		if (e.byteLength <= mt) {
			let t = e.byteOffset === 0 && e.buffer.byteLength === e.byteLength ? e : e.slice();
			n.push({
				kind: i.kind,
				bytes: t,
				sha256: i.sha256
			}), r += t.byteLength;
			continue;
		}
		if (e[0] !== 91 || e.at(-1) !== 93) throw new s("SAVE_FAILED", "取り込む分割記録の配列が不正です。");
		let a = 1, c = 1, l = 0, u = !1, d = !1, f = (t) => {
			let o = new Uint8Array(t - a + 2);
			o[0] = 91, o.set(e.subarray(a, t), 1), o[o.length - 1] = 93, n.push({
				kind: i.kind,
				bytes: o
			}), r += o.byteLength;
		};
		for (let n = 1; n < e.length; n++) {
			n % 4096 == 0 && o(t);
			let r = e[n];
			if (u) {
				d ? d = !1 : r === 92 ? d = !0 : r === 34 && (u = !1);
				continue;
			}
			if (r === 34) {
				u = !0;
				continue;
			}
			let i = n === e.length - 1;
			if (!i && (r === 91 || r === 123)) {
				l++;
				continue;
			}
			if (!i && (r === 93 || r === 125)) {
				l--;
				continue;
			}
			(i || r === 44 && l === 0) && n - a + 2 > mt && c > a && (f(c - 1), a = c), i ? f(n) : r === 44 && l === 0 && (c = n + 1);
		}
	}
	if (r > 268435456) return e;
	let i = [];
	for (let r of n) {
		o(t);
		let n = i.length, a = r.sha256 ?? await D(r.bytes);
		o(t), i.push({
			key: `${e.packed.scope}:${n}`,
			scope: e.packed.scope,
			sequence: n,
			kind: r.kind,
			bytes: r.bytes,
			sha256: a
		});
	}
	return {
		packed: {
			...e.packed,
			parts: i.map((e) => ({
				key: e.key,
				kind: e.kind,
				bytes: e.bytes.byteLength,
				sha256: e.sha256
			}))
		},
		parts: i
	};
}
//#endregion
//#region src/observability/workerProbe.ts
function G(e, t) {
	if (!_e()) return;
	let n = y(t), r = ye(), i = e.postMessage.bind(e), a = e.terminate.bind(e), o = (e) => r("received", e.data);
	e.addEventListener("message", o), e.postMessage = ((e, t) => {
		r("sent", e), i(e, t);
	}), e.terminate = () => (e.removeEventListener("message", o), n(), a());
}
//#endregion
//#region src/storage/recordParts.ts
function gt(e, t) {
	return o(t), new Promise((n, r) => {
		let i = new Worker(new URL(
			/* @vite-ignore */
			"/__measurement/assets/recordParts.worker-BLVJOwNC.js",
			"" + import.meta.url
		), { type: "module" }), a = !0, c;
		G(i, "worker.parts");
		let l = (e, o) => {
			a && (a = !1, c = void 0, t?.removeEventListener("abort", u), i.terminate(), e ? r(e) : n(o));
		}, u = () => l(new s("CANCELLED", "履歴の分割処理を取り消しました。既存データを保持しています。"));
		t?.addEventListener("abort", u, { once: !0 }), i.onmessage = (e) => {
			if (a) try {
				o(t);
				let n = e.data;
				if (n.type === "graph-chunk") {
					(c ??= new pt()).accept(n);
					return;
				}
				if (n.type === "graph-end") {
					let e = c?.finish(n.root);
					if (!c) throw new s("SAVE_FAILED", "履歴の受渡し内容がありません。");
					l(void 0, e);
					return;
				}
				n.ok ? l(void 0, n.value) : l(new s(n.code, "大きな履歴を処理できません。既存データを保持しています。"));
			} catch (e) {
				l(e);
			}
		}, i.onerror = () => l(new s("SAVE_FAILED", "履歴の処理作業領域を開けません。"));
		try {
			o(t), i.postMessage(e);
		} catch (e) {
			l(e);
		}
	});
}
var _t = () => typeof window < "u" && typeof Worker < "u";
function vt(e, t, n) {
	return _t() ? gt({
		action: "pack",
		value: e,
		scope: t
	}, n) : lt(e, t, n);
}
function yt(e, t, n) {
	return _t() ? gt({
		action: "pack-import",
		value: e,
		scope: t
	}, n) : lt(e, t, n).then((e) => ht(e, n));
}
function bt(e, t, n) {
	return _t() ? gt({
		action: "unpack",
		packed: e,
		parts: t
	}, n) : ut(e, t, n);
}
//#endregion
//#region src/storage/historyMetadata.ts
var xt = "__scenarioCommandMetadata", St = /* @__PURE__ */ new WeakSet(), K = /* @__PURE__ */ new WeakSet(), Ct = () => {
	throw new s("SAVE_FAILED", "履歴の操作情報と本文の対応が破損しています。");
};
function wt() {
	let e = H.currentTransaction?.idbtrans;
	e && St.add(e);
}
var Tt = (e) => St.has(e), Et = (e) => K.has(e), Dt = (e) => Object.hasOwn(e, xt), Ot = (e) => !!e[xt] && typeof e[xt] == "object" && e[xt].version === 1, kt = (e) => !!e && typeof e == "object" && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null);
function At(e) {
	if (!Array.isArray(e) || Object.keys(e).length !== e.length) return !1;
	for (let t = 0; t < e.length; t++) if (!Object.hasOwn(e, t)) return !1;
	return !0;
}
function jt(e) {
	let t = e.delta?.metadata ?? e.record;
	if (!t) return;
	let { before: n, after: r, ...i } = t;
	return i;
}
function Mt(e, t) {
	if (!kt(e)) return !1;
	let n = [
		"operationId",
		"projectId",
		"revision",
		"baseRevision",
		"reason",
		"createdAt"
	], r = [
		"compensatesOperationId",
		"idMap",
		"importOrigin"
	];
	if (Object.keys(e).some((e) => ![
		...n,
		"targetIds",
		...r
	].includes(e)) || !n.every((t) => Object.hasOwn(e, t) && typeof e[t] == "string") || e.operationId !== t.operationId || e.projectId !== t.projectId || e.revision !== t.revision || !At(e.targetIds) || !e.targetIds.every((e) => typeof e == "string") || Object.hasOwn(e, "compensatesOperationId") && typeof e.compensatesOperationId != "string") return !1;
	let i = (e) => kt(e) && Object.values(e).every((e) => typeof e == "string");
	return !(Object.hasOwn(e, "idMap") && !i(e.idMap) || Object.hasOwn(e, "importOrigin") && (!i(e.importOrigin) || Object.keys(e.importOrigin).length !== 3 || ![
		"sourceProjectId",
		"sourceOperationId",
		"importOperationId"
	].every((t) => Object.hasOwn(e.importOrigin, t))));
}
function q(e) {
	if (!kt(e)) return !1;
	let t = e;
	if (Object.keys(t).length !== 6 || ![
		"version",
		"scope",
		"root",
		"nodes",
		"strings",
		"parts"
	].every((e) => Object.hasOwn(t, e)) || t.version !== 1 || typeof t.scope != "string" || !t.scope.startsWith("commands:") || t.root !== 0 || !Number.isSafeInteger(t.nodes) || t.nodes < 1 || t.nodes > 4e6 || !Number.isSafeInteger(t.strings) || t.strings < 1 || t.strings > 4e6 || !At(t.parts) || !t.parts.length) return !1;
	let n = 0;
	return t.parts.every((e, r) => !kt(e) || Object.keys(e).length !== 4 || ![
		"key",
		"kind",
		"bytes",
		"sha256"
	].every((t) => Object.hasOwn(e, t)) || e.key !== `${t.scope}:${r}` || !["strings", "nodes"].includes(e.kind) || !Number.isSafeInteger(e.bytes) || e.bytes < 1 || e.bytes > 8388608 || typeof e.sha256 != "string" || !/^[a-f0-9]{64}$/.test(e.sha256) ? !1 : (n += e.bytes, n <= 268435456));
}
var Nt = (e, t = !1) => {
	let n = e[xt], r = M({
		...e,
		[xt]: {
			version: n.version,
			metadata: n.metadata
		}
	});
	return t && (k("history.write.sealCalls"), k("history.write.sealBytes", r.byteLength)), D(r);
};
async function Pt(e, t) {
	k("history.write.candidates");
	let n = jt(e);
	if (!Mt(n, t)) return k("history.write.fallbackShape"), t;
	let r = {
		...t,
		[xt]: {
			version: 1,
			metadata: n,
			digest: "0".repeat(64)
		}
	};
	return dt(r) ? (k("history.write.fallbackSize"), t) : (r[xt].digest = await Nt(r, !0), k("history.write.canonical"), r);
}
async function Ft(e) {
	if (!Ot(e)) return Ct();
	let t = e[xt];
	return Object.keys(e).length !== 5 || ![
		"operationId",
		"projectId",
		"revision",
		"__scenarioRecordParts",
		xt
	].every((t) => Object.hasOwn(e, t)) || !Mt(t.metadata, e) || !q(e.__scenarioRecordParts) || typeof t.digest != "string" || t.digest !== await Nt(e) || Object.keys(t).length !== 3 ? Ct() : t.metadata;
}
async function It(e, t, n) {
	let r = await Ft(e), { [xt]: i, ...a } = e, o = jt(t);
	if (!Mt(o, e) || !P(a, n) || !P(r, o)) return Ct();
}
async function Lt(e, t) {
	let n = e.__scenarioRecordParts;
	await Promise.all(n.parts.map((e) => new H.Promise((n, r) => {
		let i = t.objectStore("recordParts").getKey(e.key);
		i.onsuccess = () => {
			k("history.partKeys"), k("db.read.calls", 1, "recordParts"), k("db.read.requested", 1, "recordParts"), k("db.read.keys", i.result === void 0 ? 0 : 1, "recordParts"), i.result === e.key ? n() : r(new s("SAVE_FAILED", "履歴の分割記録が不足しています。"));
		}, i.onerror = () => r(i.error);
	})));
}
async function Rt(e, t) {
	return e.transaction("r", ["commands"], async () => {
		let n = {
			trans: H.currentTransaction.idbtrans,
			keys: t.slice()
		};
		K.add(n);
		try {
			return await e.table("commands").core.getMany(n);
		} finally {
			K.delete(n);
		}
	});
}
function zt(e) {
	k("history.metadata.rows"), E("history.metadata.payloadBytes", e);
}
//#endregion
//#region src/storage/worldClosure.ts
async function Bt(e, t, n, r) {
	let i = {}, a = [], s = [], c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new WeakSet(), d = !1, f = (e, t = !1) => {
		if (!e || !Array.isArray(e.snapshots)) {
			d = !0;
			return;
		}
		let n = t ? c : l;
		n.add(e.projectId);
		for (let t of e.snapshots) t && typeof t.id == "string" ? n.add(t.id) : d = !0;
		let r = [e];
		for (; r.length;) {
			let e = r.pop();
			if (typeof e != "object" || !e || u.has(e)) continue;
			if (u.add(e), !Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) {
				d = !0;
				continue;
			}
			let t = e;
			if (Object.hasOwn(t, "worldReferences")) {
				if (!Array.isArray(t.worldReferences)) d = !0;
				else for (let e of t.worldReferences) e && typeof e == "object" && typeof e.immutableSnapshotId == "string" ? a.push(e.immutableSnapshotId) : d = !0;
			}
			try {
				let e = [];
				typeof t.kind == "string" && typeof t.projectId == "string" && t.data && typeof t.data == "object" ? Object.hasOwn(ge, t.kind) ? e = be(t) : d = !0 : typeof t.relationType == "string" && typeof t.projectId == "string" && typeof t.fromId == "string" && (e = g(t));
				for (let t of e) t.scope === "snapshot" && s.push(t.id);
			} catch {
				d = !0;
			}
			for (let e of Object.values(Object.getOwnPropertyDescriptors(t))) Object.hasOwn(e, "value") ? r.push(e.value) : d = !0;
		}
	}, p = async () => {
		k("world.closure.fullFallback"), o(r);
		let e = await n();
		return o(r), e;
	};
	for (let t of e) f(t, !0);
	let m = /* @__PURE__ */ new Set();
	for (; a.length || s.length;) {
		if (o(r), d) return p();
		let e = a.length === 0, n = (e ? s : a).pop();
		if (e && c.has(n) || i[n] || m.has(n)) continue;
		m.add(n);
		let u = await t(n);
		if (o(r), !u) {
			if (e && l.has(n)) continue;
			return p();
		}
		i[u.id] = u.project, f(u.project);
	}
	return d ? p() : i;
}
//#endregion
//#region src/domain/derivedIndexes.ts
var Vt = Object.freeze({
	entries: 1e5,
	references: 75e4,
	textCodeUnits: 8388608
}), Ht = /* @__PURE__ */ new WeakMap(), Ut = (e, t = 1) => ({
	entries: t,
	references: e.references,
	textCodeUnits: e.textCodeUnits ?? 0
}), Wt = class {
	used = {
		entries: 0,
		references: 0,
		textCodeUnits: 0
	};
	limits;
	constructor(e = {}) {
		let t = {
			...Vt,
			...e
		};
		if (Object.values(t).some((e) => !Number.isSafeInteger(e) || e < 0)) throw Error("Invalid derived index budget");
		this.limits = Object.freeze(t);
	}
	snapshot() {
		return { ...this.used };
	}
	reserve(e) {
		if (Object.values(e).some((e) => !Number.isSafeInteger(e) || e < 0) || Object.keys(e).some((t) => e[t] > this.limits[t] - this.used[t])) return !1;
		for (let t of Object.keys(e)) this.used[t] += e[t];
		return !0;
	}
	release(e) {
		for (let t of Object.keys(e)) this.used[t] -= e[t];
	}
}, Gt = class {
	source;
	members;
	membershipCost;
	signature;
	generation = 0;
	budget;
	values = /* @__PURE__ */ new Map();
	identity;
	constructor(e, t, n) {
		this.budget = t;
		let { history: r, authorAlternatives: i, ...a } = e;
		this.source = Object.freeze({
			...a,
			history: Object.freeze([])
		}), this.identity = Object.freeze({
			...n,
			visibilityScope: "author",
			normalizationVersion: 2
		});
	}
	matches(e) {
		let t = this.source;
		if (!t) return !1;
		let n = Object.getOwnPropertyDescriptors(e), r = Reflect.ownKeys(e).filter((e) => e !== "history" && e !== "authorAlternatives"), i = Object.keys(t).filter((e) => e !== "history");
		return r.length === i.length && r.every((e) => typeof e == "string" && Object.hasOwn(t, e)) && i.every((e) => {
			let r = n[e];
			return !!r?.enumerable && Object.hasOwn(r, "value") && r.value === t[e];
		});
	}
	bind(e) {
		this.matches(e) && Ht.set(e, this);
	}
	clearValues() {
		for (let e of this.values.values()) for (let t of e.values()) this.budget.release(t.cost);
		this.values.clear(), this.generation++, k("derived.invalidated");
	}
	close() {
		this.clearValues(), this.membershipCost && this.budget.release(this.membershipCost), this.membershipCost = void 0, this.members = void 0, this.source = void 0, this.signature = void 0;
	}
	evaluate(e) {
		if (!this.matches(e)) {
			Ht.delete(e);
			return;
		}
		if (!this.budget.limits.entries) return;
		let t = n();
		if (t === void 0) {
			this.clearValues();
			return;
		}
		t !== this.signature && (this.clearValues(), this.signature = t);
		let r = this.source;
		if (!this.members) {
			if (!S(r)) return;
			let e = Ut({ references: r.entities.length }, 0);
			if (!this.budget.reserve(e)) return;
			this.membershipCost = e, this.members = new WeakSet(r.entities);
		}
		let i = this.generation, a = () => !!this.source && i === this.generation, o = (e, t) => a() ? this.values.get(e)?.get(t)?.value : void 0, s = (e, t, n) => {
			if (!a()) return !1;
			let r = this.values.get(e);
			if (r?.has(t)) return !0;
			let i = Ut(n.cost);
			return this.budget.reserve(i) ? (r || (r = /* @__PURE__ */ new Map(), this.values.set(e, r)), r.set(t, {
				value: n.value,
				cost: i
			}), k("derived.admitted"), !0) : (k("derived.rejected"), !1);
		};
		return {
			peek: o,
			publish: s,
			get: (e, t, n) => {
				let r = a() ? this.values.get(e)?.get(t) : void 0;
				if (r) return k("derived.hit"), r.value;
				k("derived.miss");
				let i = n();
				return s(e, t, i), i.value;
			},
			ownsEntity: (e) => a() && this.members?.has(e) === !0,
			isActive: () => a() && this.matches(e),
			isCurrent: () => a() && this.matches(e) && n() === t
		};
	}
};
//#endregion
//#region src/domain/worldSources.ts
function Kt(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of [...Object.values(t), ...e]) {
		let e = n.get(r.projectId), t = new Map(e?.snapshots.map((e) => [e.id, e]) ?? []);
		for (let e of r.snapshots) t.has(e.id) || t.set(e.id, e);
		n.set(r.projectId, {
			...r,
			snapshots: [...t.values()]
		});
	}
	return [...n.values()];
}
//#endregion
//#region src/storage/projectSummary.ts
function qt(e) {
	return new H.Promise((t, n) => {
		let r = H.currentTransaction.idbtrans.objectStore("projects").get(e);
		r.onsuccess = () => {
			let e = r.result;
			k("db.read.calls", 1, "projects"), k("db.read.requested", 1, "projects"), k("db.read.rows", +!!e, "projects"), E("db.read.payloadBytes", e ? [e] : [], "projects"), t(e);
		}, r.onerror = () => n(r.error);
	});
}
var Jt = (e) => D(M(e));
async function Yt(e, t) {
	let n = {
		version: 2,
		alternativeHeads: (e.authorAlternatives ?? []).map((e) => ({
			id: e.id,
			name: e.name,
			headVersionId: e.headVersionId,
			contentHash: e.versions.find((t) => t.id === e.headVersionId)?.contentHash ?? ""
		})),
		projectId: e.projectId,
		name: e.name,
		revision: e.revision,
		entityCount: e.entities.filter((e) => !e.deletedAt).length,
		sourceHash: t
	};
	return {
		...n,
		digest: await D(M(n))
	};
}
async function Xt(e, t, n) {
	if (!e || e.version !== 2 || !Array.isArray(e.alternativeHeads) || e.alternativeHeads.length > 100 || e.alternativeHeads.some((e) => !e || typeof e.id != "string" || typeof e.name != "string" || typeof e.headVersionId != "string" || typeof e.contentHash != "string") || e.projectId !== t || e.sourceHash !== n || typeof e.name != "string" || typeof e.revision != "string" || !/^(0|[1-9]\d*)$/.test(e.revision) || !Number.isSafeInteger(e.entityCount) || e.entityCount < 0) return !1;
	let { digest: r, ...i } = e;
	return typeof r == "string" && r === await D(new TextEncoder().encode(A(i)));
}
async function Zt(e, t) {
	let n = {
		id: e,
		projectId: t.projectId,
		name: t.name,
		revision: t.revision,
		version: 1
	};
	return {
		...n,
		digest: await D(M(n))
	};
}
async function Qt(e, t) {
	if (!e || e.id !== t || e.version !== 1 || typeof e.projectId != "string" || typeof e.name != "string" || typeof e.revision != "string" || !/^(0|[1-9]\d*)$/.test(e.revision)) return !1;
	let { digest: n, ...r } = e;
	return typeof n == "string" && n === await D(M(r));
}
//#endregion
//#region src/domain/authorAlternativeIntegrity.ts
var $t = /^[0-9a-f]{64}$/, en = /^(0|[1-9][0-9]*)$/, tn = /* @__PURE__ */ new Set([
	"active",
	"provisional",
	"needs_review",
	"rejected",
	"accepted"
]), nn = /* @__PURE__ */ new Set([
	"project",
	"entity",
	"relation",
	"presentation"
]), rn = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), an = {
	alternatives: 100,
	versions: 500,
	branchBytes: 8e6,
	totalBytes: 16e6
};
function on(e, t = /* @__PURE__ */ new Set(), n = 0) {
	if (n > 100) throw Error("内容の階層が上限を超えています。");
	if (e === null || typeof e == "boolean" || typeof e == "string" || typeof e == "number" && Number.isFinite(e)) return JSON.stringify(e);
	if (!e || typeof e != "object" || t.has(e)) throw Error("SHA-256対象が通常のJSON値ではありません。");
	let r = Object.getPrototypeOf(e);
	if (!Array.isArray(e) && r !== Object.prototype && r !== null) throw Error("SHA-256対象に未対応の値があります。");
	t.add(e);
	let i = Array.isArray(e) ? `[${e.map((e) => on(e, t, n + 1)).join(",")}]` : `{${Object.keys(e).sort().map((r) => {
		if (rn.has(r)) throw Error("JSONに未対応の項目名があります。");
		return `${JSON.stringify(r)}:${on(e[r], t, n + 1)}`;
	}).join(",")}}`;
	return t.delete(e), i;
}
async function sn(e) {
	let t = new TextEncoder().encode(on(e)), n = await globalThis.crypto.subtle.digest("SHA-256", t);
	return Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("");
}
function cn(e) {
	let { integrityHash: t, ...n } = e;
	return n;
}
async function ln(e) {
	let t = structuredClone(e);
	t.baseContentHash = await sn(t.baseContent);
	for (let e of t.versions) e.contentHash = await sn({
		content: e.content,
		structurePlan: e.structurePlan ?? null
	});
	return delete t.integrityHash, t.integrityHash = await sn(cn(t)), t;
}
function un(e) {
	return !!e && typeof e == "object" && !Array.isArray(e);
}
function dn(e) {
	return typeof e == "string" && Number.isFinite(Date.parse(e));
}
function J(e, t, n) {
	e.push({
		path: t,
		message: n
	});
}
function fn(e, t, n, r) {
	(typeof e.templateId != "string" || !e.templateId.trim()) && J(r, `${n}.templateId`, "構成雛形IDが必要です。"), !Array.isArray(e.beatLabels) || e.beatLabels.length > 100 || e.beatLabels.some((e) => typeof e != "string" || !e.trim()) ? J(r, `${n}.beatLabels`, "構成の役割は空でない文章を100件以内で指定してください。") : new Set(e.beatLabels).size !== e.beatLabels.length && J(r, `${n}.beatLabels`, "構成の役割名は重複できません。");
	let i = t.entities.find((t) => t.kind === "chapter" && t.id === e.chapterId && !t.deletedAt);
	if (i || J(r, `${n}.chapterId`, "構成計画の章が別案に存在しません。"), !un(e.assignments)) {
		J(r, `${n}.assignments`, "場面の割り当てが不正です。");
		return;
	}
	let a = new Set(Array.isArray(e.beatLabels) ? e.beatLabels : []), o = /* @__PURE__ */ new Set();
	for (let [s, c] of Object.entries(e.assignments)) a.has(s) || J(r, `${n}.assignments.${s}`, "定義されていない構成の役割です。"), (typeof c != "string" || o.has(c)) && J(r, `${n}.assignments.${s}`, "同じ場面を複数の役割へ割り当てられません。"), o.add(c), t.entities.some((e) => e.kind === "scene" && e.id === c && !e.deletedAt) || J(r, `${n}.assignments.${s}`, "割り当てる場面が別案に存在しません。"), i && typeof c == "string" && !i.data.sceneIds.includes(c) && J(r, `${n}.assignments.${s}`, "場面は対象の章に所属していません。");
}
function pn(e, t) {
	return t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
}
function mn(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function hn(e, t) {
	if (t.scope === "presentation") return mn(e);
	if (t.scope === "project") return pn(e, t.path);
	let n = (t.scope === "entity" ? e.entities : e.relations).find((e) => e.id === t.itemId);
	if (n && !n.deletedAt) return t.path.length ? pn(n, t.path) : n;
}
function gn(e, t, n, r, i) {
	if (!e || typeof e != "object") {
		J(i, r, "正本採用記録が不正です。");
		return;
	}
	dn(e.createdAt) || J(i, `${r}.createdAt`, "採用日時が不正です。");
	let a = t.get(e.alternativeVersionId ?? "");
	if (a || J(i, `${r}.alternativeVersionId`, "採用元の別案版が見つかりません。"), (e.sourceSnapshotId ?? null) !== (n ?? null) && J(i, `${r}.sourceSnapshotId`, "採用記録の分岐元固定版が別案と一致しません。"), !en.test(e.fromCanonicalRevision) || !e.appliedRevision || !en.test(e.appliedRevision) ? J(i, r, "採用元と採用先の正本版番号が必要です。") : BigInt(e.appliedRevision) <= BigInt(e.fromCanonicalRevision) && J(i, `${r}.appliedRevision`, "採用先の正本版は採用元より新しくなければなりません。"), (!Array.isArray(e.selectedChangeKeys) || !e.selectedChangeKeys.length || new Set(e.selectedChangeKeys).size !== e.selectedChangeKeys.length) && J(i, `${r}.selectedChangeKeys`, "採用対象の差分キーが必要です。"), !Array.isArray(e.patches) || !e.patches.length) {
		J(i, `${r}.patches`, "採用した差分がありません。");
		return;
	}
	let o = /* @__PURE__ */ new Set();
	e.patches.forEach((e, t) => {
		let n = `${r}.patches[${t}]`;
		(!e || typeof e.key != "string" || o.has(e.key)) && J(i, `${n}.key`, "差分キーが不正または重複しています。"), o.add(e.key), (!nn.has(e.scope) || !Array.isArray(e.path) || e.path.some((e) => typeof e != "string") || typeof e.label != "string") && J(i, n, "差分の対象が不正です。"), (typeof e.before?.present != "boolean" || typeof e.after?.present != "boolean") && J(i, n, "差分の前後値の有無が不正です。");
		let s = [
			e.scope,
			e.itemId ?? "",
			...e.path ?? []
		].map((e) => encodeURIComponent(e)).join(":");
		if (e.key !== s && J(i, `${n}.key`, "差分キーが保存した範囲と一致しません。"), e.scope === "presentation" && (e.itemId || e.path?.length !== 1 || e.path[0] !== "all") && J(i, n, "提示順差分の範囲が不正です。"), (e.before?.present === !1 && Object.hasOwn(e.before, "value") || e.after?.present === !1 && Object.hasOwn(e.after, "value")) && J(i, n, "値がない差分に値を含められません。"), (e.before?.present === !0 && !Object.hasOwn(e.before, "value") || e.after?.present === !0 && !Object.hasOwn(e.after, "value")) && J(i, n, "値がある差分には値を含めてください。"), a && e.after && typeof e.after.present == "boolean") {
			let t = hn(a.content, e), r = t !== void 0;
			if (e.after.present !== r) J(i, `${n}.after`, "採用後の有無が参照した別案版と一致しません。");
			else if (r) try {
				on(e.after.value) !== on(t) && J(i, `${n}.after.value`, "採用後の値が参照した別案版と一致しません。");
			} catch (e) {
				J(i, `${n}.after.value`, e instanceof Error ? e.message : "採用後の値を別案版と比較できません。");
			}
		}
	}), Array.isArray(e.selectedChangeKeys) && !_n(e.selectedChangeKeys, [...o]) && J(i, `${r}.selectedChangeKeys`, "採用対象キーと保存した差分内容が一致しません。");
}
function _n(e, t) {
	return e.length === t.length && [...e].sort().every((e, n) => e === [...t].sort()[n]);
}
async function vn(e, t, n) {
	let r = [], i = {
		alternatives: n.maxAlternatives ?? an.alternatives,
		versions: n.maxVersionsPerAlternative ?? an.versions,
		branchBytes: n.maxBytesPerAlternative ?? an.branchBytes,
		totalBytes: n.maxBytesTotal ?? an.totalBytes
	};
	if (!Array.isArray(t)) return [{
		path: "authorAlternatives",
		message: "作者別案は配列で指定してください。"
	}];
	t.length > i.alternatives && J(r, "authorAlternatives", `作者別案は${i.alternatives}件までです。`);
	let a = new Set(n.reservedIds ?? []), o = /* @__PURE__ */ new Set(), s = 0;
	for (let [c, l] of t.entries()) {
		let t = `authorAlternatives[${c}]`;
		if (!un(l)) {
			J(r, t, "作者別案の記録が不正です。");
			continue;
		}
		let u = l;
		if ((typeof u.id != "string" || o.has(u.id) || a.has(u.id)) && J(r, `${t}.id`, "別案IDが不正または重複しています。"), typeof u.id == "string" && (o.add(u.id), a.add(u.id)), u.projectId !== e && J(r, `${t}.projectId`, "別案が別の作品を参照しています。"), (typeof u.name != "string" || !u.name.trim()) && J(r, `${t}.name`, "別案名が必要です。"), tn.has(u.status) || J(r, `${t}.status`, "別案の状態が不正です。"), (!dn(u.createdAt) || !dn(u.updatedAt)) && J(r, t, "別案の作成日時または更新日時が不正です。"), en.test(u.baseRevision) || J(r, `${t}.baseRevision`, "分岐元の版番号が不正です。"), u.sourceSnapshotId != null && n.snapshotIds && !n.snapshotIds.has(u.sourceSnapshotId) && J(r, `${t}.sourceSnapshotId`, "分岐元の固定版が見つかりません。"), (!un(u.baseContent) || u.baseContent.projectId !== e || u.baseContent.revision !== u.baseRevision) && J(r, `${t}.baseContent`, "分岐元の内容・作品ID・版番号が一致しません。"), un(u.baseContent) && Object.hasOwn(u.baseContent, "authorAlternatives") && J(r, `${t}.baseContent.authorAlternatives`, "別案の内容へ別案一覧を再帰保存できません。"), un(u.baseContent)) {
			if (u.sourceSnapshotId) {
				let e = n.snapshots?.find((e) => e.id === u.sourceSnapshotId);
				if (!e) J(r, `${t}.sourceSnapshotId`, "分岐元の固定版本文がありません。");
				else try {
					on(e.content) !== on(u.baseContent) && J(r, `${t}.baseContent`, "固定版から分岐した別案は、固定版本文をそのまま保持してください。");
				} catch (e) {
					J(r, `${t}.baseContent`, e instanceof Error ? e.message : "固定版本文と分岐元を比較できません。");
				}
			}
			let e = await n.validateContent(u.baseContent);
			if (e.ok || (e.issues ?? []).forEach((e) => J(r, `${t}.baseContent${e.path ? `.${e.path}` : ""}`, e.message)), $t.test(u.baseContentHash ?? "")) try {
				await sn(u.baseContent) !== u.baseContentHash && J(r, `${t}.baseContentHash`, "分岐元の内容SHA-256が一致しません。");
			} catch (e) {
				J(r, `${t}.baseContentHash`, e instanceof Error ? e.message : "分岐元の内容hashを確認できません。");
			}
			else J(r, `${t}.baseContentHash`, "分岐元の内容SHA-256がありません。");
		}
		if (!Array.isArray(u.versions) || !u.versions.length || u.versions.length > i.versions) {
			J(r, `${t}.versions`, `別案の版は1〜${i.versions}件で指定してください。`);
			continue;
		}
		let d = u.versions, f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map();
		for (let [i, o] of d.entries()) {
			let s = `${t}.versions[${i}]`;
			if ((!o || typeof o.id != "string" || f.has(o.id) || a.has(o.id)) && J(r, `${s}.id`, "別案版IDが不正または重複しています。"), typeof o?.id == "string" && (f.set(o.id, o), p.set(o.id, i), a.add(o.id)), (typeof o?.label != "string" || !o.label.trim() || !dn(o.createdAt)) && J(r, s, "別案版の名前または作成日時が不正です。"), !un(o?.content) || o.content.projectId !== e) {
				J(r, `${s}.content`, "別案版の作品IDが一致しません。");
				continue;
			}
			Object.hasOwn(o.content, "authorAlternatives") && J(r, `${s}.content.authorAlternatives`, "別案版へ別案一覧を再帰保存できません。");
			let c = await n.validateContent(o.content);
			c.ok || (c.issues ?? []).forEach((e) => J(r, `${s}.content${e.path ? `.${e.path}` : ""}`, e.message)), o.structurePlan && fn(o.structurePlan, o.content, `${s}.structurePlan`, r);
			try {
				let e = await sn({
					content: o.content,
					structurePlan: o.structurePlan ?? null
				});
				(!$t.test(o.contentHash ?? "") || o.contentHash !== e) && J(r, `${s}.contentHash`, "別案版の内容SHA-256がありません、または一致しません。");
			} catch (e) {
				J(r, `${s}.contentHash`, e instanceof Error ? e.message : "別案版の内容hashを確認できません。");
			}
		}
		let m = d.filter((e) => e.parentVersionId === null);
		if (m.length !== 1 && J(r, `${t}.versions`, "別案履歴には親のない開始版が一つ必要です。"), m[0]) try {
			on(m[0].content) !== on(u.baseContent) && J(r, `${t}.versions`, "開始版は分岐元の内容を保持してください。");
		} catch (e) {
			J(r, `${t}.versions`, e instanceof Error ? e.message : "開始版と分岐元の内容を比較できません。");
		}
		let h = -Infinity;
		for (let [e, n] of d.entries()) {
			let i = `${t}.versions[${e}]`, a = Date.parse(n.createdAt);
			if (Number.isFinite(a) && a < h && J(r, `${i}.createdAt`, "別案の版は作成順に並べてください。"), Number.isFinite(a) && (h = a), n.parentVersionId !== null) {
				let t = p.get(n.parentVersionId ?? "");
				(t === void 0 || t >= e) && J(r, `${i}.parentVersionId`, "別案版の親が存在しないか、作成順の後にあります。");
			}
		}
		let g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set(), v = (e) => {
			if (_.has(e)) {
				J(r, `${t}.versions`, "別案版の親子関係に循環があります。");
				return;
			}
			if (g.has(e)) return;
			_.add(e);
			let n = f.get(e)?.parentVersionId;
			n && v(n), _.delete(e), g.add(e);
		};
		if (f.forEach((e, t) => v(t)), u.headVersionId !== d.at(-1)?.id && J(r, `${t}.headVersionId`, "別案の現在版は履歴の最後の版でなければなりません。"), !Array.isArray(u.applyReceipts)) J(r, `${t}.applyReceipts`, "正本採用履歴が不正です.");
		else {
			let e = /* @__PURE__ */ new Set(), n = -1n;
			u.applyReceipts.forEach((i, o) => {
				let s = `${t}.applyReceipts[${o}]`;
				if ((e.has(i.id) || a.has(i.id)) && J(r, `${s}.id`, "採用記録IDが重複しています。"), e.add(i.id), a.add(i.id), gn(i, f, u.sourceSnapshotId, s, r), en.test(i.appliedRevision ?? "")) {
					let e = BigInt(i.appliedRevision);
					e <= n && J(r, `${s}.appliedRevision`, "正本採用履歴は版の昇順で並べてください。"), n = e;
				}
			});
		}
		try {
			let e = cn(u);
			(!$t.test(u.integrityHash ?? "") || await sn(e) !== u.integrityHash) && J(r, `${t}.integrityHash`, "作者別案全体のSHA-256がありません、または一致しません。");
		} catch (e) {
			J(r, `${t}.integrityHash`, e instanceof Error ? e.message : "作者別案のhashを確認できません。");
		}
		try {
			let e = new TextEncoder().encode(on(u)).byteLength;
			s += e, e > i.branchBytes && J(r, t, `別案は${i.branchBytes} bytesまでです。`);
		} catch (e) {
			J(r, t, e instanceof Error ? e.message : "別案をJSON化できません。");
		}
	}
	return s > i.totalBytes && J(r, "authorAlternatives", `作者別案全体は${i.totalBytes} bytesまでです。`), r;
}
//#endregion
//#region src/domain/runtimeRecordValidation.ts
function yn(e, t, n, r = "trace", i = {}) {
	try {
		e = F(e, e.snapshots);
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: r,
			message: e.message
		}];
	}
	let a = [], o = (e, t, n = "VALIDATION_FAILED") => a.push({
		code: n,
		path: `${r}.${e}`,
		message: t
	});
	if (t.mode !== "chapters") return t.readingPath && o("readingPath", "章の提示経路はmode:chaptersの記録に指定してください。"), a;
	let s = t.readingPath;
	if (!s) return o("readingPath", "章読み通し記録に提示経路がありません。"), a;
	let c = ie(e, i.worldSnapshots ?? {});
	c.errors.length && o("worldReferences", c.errors[0], "REFERENCE_INVALID");
	let l = c.worlds.flatMap((e) => e.entities);
	a.push(...ce(e, t.initialExternalValues ?? {}, void 0, l).map((e) => ({
		...e,
		path: `${r}.initialExternalValues.${e.path}`
	}))), t.initialWorldTick != null && n.worldTick != null && t.initialWorldTick !== n.worldTick && o("initialWorldTick", "保存した開始時点と章経路の提示時点が一致しません。", "INTEGRITY_FAILED"), t.steps.length && o("steps", "章読み通しにフロー遷移を混在させられません。"), (t.contentVersionId !== n.contentVersionId || n.runtimeState.contentVersionId !== t.contentVersionId) && o("contentVersionId", "開始状態と読み通しの固定版が一致しません。"), (t.contentRevision !== e.revision || n.contentRevision !== e.revision) && o("contentRevision", "章読み通しには開始状態と内容版に一致する更新番号が必要です。"), (n.origin !== "partial" || n.runtimeState.presentationPosition !== null) && o("startCheckpointId", "章読み通しの開始状態はフロー位置を持たない途中開始です。"), s.occurrences.length > s.sceneIds.length && o("readingPath.occurrences", "実際の提示数が計画した場面数を超えています。");
	let u = /* @__PURE__ */ new Set(), d = n.runtimeState;
	for (let [i, c] of s.occurrences.entries()) {
		let f = `readingPath.occurrences[${i}]`;
		(!c.occurrenceId.trim() || u.has(c.occurrenceId)) && o(`${f}.occurrenceId`, "提示の識別子が空か重複しています。"), u.add(c.occurrenceId), c.entityId !== s.sceneIds[i] && o(`${f}.entityId`, "提示した場面が計画した場面の順序と一致しません。"), (c.before.contentVersionId !== t.contentVersionId || c.after.contentVersionId !== t.contentVersionId || c.before.presentationPosition !== null || c.after.presentationPosition !== null) && o(f, "提示状態の内容版またはフロー位置が不正です。"), A(c.before) !== A(d) && o(`${f}.before`, "提示状態が開始状態または直前の提示とつながりません。", "INTEGRITY_FAILED"), A(c.externalValues ?? {}) !== A(t.initialExternalValues ?? {}) && o(`${f}.externalValues`, "章読み通し中に、記録した外部入力を未記録の操作で変更できません。", "INTEGRITY_FAILED");
		let p = ue(e, c.before, {
			sceneId: c.entityId,
			worldTick: t.initialWorldTick ?? n.worldTick ?? void 0,
			previousSceneId: s.occurrences[i - 1]?.entityId,
			last: i + 1 === s.sceneIds.length,
			externalValues: c.externalValues ?? t.initialExternalValues ?? {},
			referenceEntities: l
		});
		if (p.ok) A(p.state) !== A(c.after) && o(`${f}.after`, "記録した提示後の状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED"), c.presentationState && A(p.observationState) !== A(c.presentationState) && o(`${f}.presentationState`, "提示前の観測状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED"), A(p.conditions) !== A(c.conditionResults) && o(`${f}.conditionResults`, "提示時の条件根拠が不足・重複・矛盾しています。", "INTEGRITY_FAILED");
		else for (let e of p.issues) a.push({
			...e,
			path: `${r}.${f}.${e.path}`
		});
		d = c.after;
	}
	return a;
}
//#endregion
//#region src/domain/projectRecordValidation.ts
function bn(e) {
	return {
		...e,
		history: []
	};
}
function xn(e, t) {
	return t.length >= e.length && e.every((e, n) => A(e) === A(t[n]));
}
function Sn(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = (e) => {
		let t = a.get(e);
		return t || (t = [], a.set(e, t)), t;
	}, s = o("local"), c = e.history.findIndex((e) => !e.importOrigin);
	c >= 0 && s.push({
		label: `project.history[${c}].before`,
		state: e.history[c].before
	});
	for (let [t, n] of e.history.entries()) {
		let e = n.importOrigin, r = o(e ? `import:${e.importOperationId}` : "local");
		e && !r.length && r.push({
			label: `project.history[${t}].before`,
			state: n.before
		}), r.push({
			label: `project.history[${t}].after`,
			state: n.after
		});
	}
	let l = e;
	(!s.length || s.at(-1)?.state.revision !== e.revision) && s.push({
		label: "project",
		state: l
	});
	for (let e of a.values()) {
		let a = /* @__PURE__ */ new Map();
		for (let { label: o, state: s } of e) {
			let e = new Map((s.authorAlternatives ?? []).map((e) => [e.id, e]));
			for (let [n, r] of a) {
				let i = e.get(n);
				if (!i) {
					t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives`,
						message: `過去に保存した別案「${n}」が履歴から失われています。`
					});
					continue;
				}
				xn(r.versions, i.versions) || t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${n}.versions`,
					message: "別案版の履歴は削除・書換えできません。"
				}), xn(r.applyReceipts, i.applyReceipts) || t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${n}.applyReceipts`,
					message: "正本採用記録は削除・書換えできません。"
				});
			}
			for (let a of e.values()) {
				let e = A({
					projectId: a.projectId,
					baseRevision: a.baseRevision,
					sourceSnapshotId: a.sourceSnapshotId ?? null,
					baseContent: a.baseContent,
					baseContentHash: a.baseContentHash,
					createdAt: a.createdAt
				}), s = i.get(a.id);
				s !== void 0 && s !== e ? t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${a.id}`,
					message: "別案IDが異なる分岐元の内容に再利用されています。"
				}) : i.set(a.id, e);
				for (let e of a.versions) {
					let r = n.get(e.id);
					r && A(r) !== A(e) ? t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives.${a.id}.versions.${e.id}`,
						message: "不変の別案版IDが異なる内容へ再利用されています。"
					}) : n.set(e.id, e);
				}
				for (let e of a.applyReceipts) {
					let n = r.get(e.id);
					n && A(n) !== A(e) ? t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives.${a.id}.applyReceipts.${e.id}`,
						message: "不変の正本採用記録IDが異なる内容へ再利用されています。"
					}) : r.set(e.id, e);
				}
			}
			a = e;
		}
	}
	return t;
}
function Cn(e) {
	let t = /* @__PURE__ */ new Set([e.projectId]);
	for (let n of [...e.entities, ...e.relations]) t.add(n.id);
	for (let n of e.snapshots) {
		t.add(n.id);
		for (let r of e.entities) r.kind === "snapshot" && r.id === n.id && t.add(r.id);
	}
	for (let n of e.history) t.add(n.operationId);
	return t;
}
async function wn(e, t, n, r) {
	let i = [], a = e.snapshots, o = await vn(e.projectId, e.authorAlternatives ?? [], {
		snapshotIds: new Set(a.map((e) => e.id)),
		snapshots: a,
		reservedIds: Cn(e),
		validateContent: async (e) => {
			let i = await pe(e, t.worldSnapshots ?? {}, `${n}.authorAlternatives.worldReferences`, r), o = u({
				...e,
				snapshots: a,
				history: []
			}, t);
			return o.ok && !i.length ? { ok: !0 } : {
				ok: !1,
				issues: [...i, ...o.ok ? [] : o.issues]
			};
		}
	});
	for (let e of o) i.push({
		code: "INTEGRITY_FAILED",
		path: `${n}.${e.path}`,
		message: e.message
	});
	return i;
}
async function Tn(e, t, n) {
	let r = [];
	for (let [i, a] of e.entities.entries()) {
		if (a.kind !== "trace") continue;
		let o = `project.entities[${i}].data`, s = e.entities.find((e) => e.id === a.data.startCheckpointId && e.kind === "checkpoint");
		if (!s || s.kind !== "checkpoint") {
			r.push({
				code: "REFERENCE_INVALID",
				path: `${o}.startCheckpointId`,
				message: "経路の開始状態が見つかりません。"
			});
			continue;
		}
		try {
			let i = await de(e, a.data.contentVersionId, t, n);
			if (a.data.mode === "chapters") r.push(...yn(i, a.data, s.data, o, t));
			else {
				let { replaySavedTrace: n } = await import("./runtime-gIV0BO5w.js"), s = ie(F(i, i.snapshots), t.worldSnapshots ?? {}), c = n(e, a.id, s.worlds.flatMap((e) => e.entities));
				c.status === "error" && r.push(...c.issues.map((e) => ({
					...e,
					path: `${o}.${e.path}`
				})));
			}
		} catch (e) {
			let t = e.issues;
			t?.length ? r.push(...t.map((e) => ({
				...e,
				path: `${o}.${e.path}`
			}))) : r.push({
				code: "INTEGRITY_FAILED",
				path: `${o}.contentVersionId`,
				message: e instanceof Error ? e.message : "章読み通しの固定版本文を確認できません。"
			});
		}
	}
	return r;
}
async function En(e, t = {}, n = e.history.length > 0, r) {
	return On(e, t, n, r);
}
function Dn(e = {}) {
	let t = x(e), n = t.captured ? x({
		...t.value,
		relationTypes: t.value.relationTypes ?? ee
	}) : t;
	if (!n.captured) return {
		validate: (t) => u(t, e),
		integrity: (t, n = t.history.length > 0) => En(t, e, n)
	};
	let r = v(n.value);
	return {
		validate: r,
		integrity: (e, t = e.history.length > 0) => On(x(e).value, n.value, t, void 0, r)
	};
}
async function On(t, n, r, i, a) {
	k("validate.integrity.calls");
	try {
		let { verifyStoredGameEvidence: e } = await import("./gameProtocol-Bgp9BlM5.js");
		await e(t, n.worldSnapshots ?? {});
	} catch (e) {
		return [{
			code: "INTEGRITY_FAILED",
			path: "project.entities.handoffReceipt",
			message: e.message
		}];
	}
	let o = h(), s = {
		...n,
		worldSnapshots: e(n.worldSnapshots ?? {}, o),
		worlds: n.worlds ? structuredClone(n.worlds) : void 0
	}, l = a ? a(t) : i && !r && !t.history.length ? c(t, s, i) : u(t, s);
	if (!l.ok) return l.issues;
	let d = [], f = (e, t, n) => {
		let r = new Map(e.filter((e) => e.kind === "review" && e.data.sharedSource).map((e) => [e.id, e]));
		for (let e of t) {
			let t = r.get(e.id);
			e.kind === "review" && t?.kind === "review" && (A(t.data.sharedSource) !== A(e.data.sharedSource ?? null) && d.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.sharedSource`,
				message: "元の共有指摘・公開版・位置・引用の記録は変更できません。解決文を別に保存してください。"
			}), A([
				t.data.target,
				t.data.targetVersionId,
				t.data.quotedText ?? null
			]) !== A([
				e.data.target,
				e.data.targetVersionId,
				e.data.quotedText ?? null
			]) && d.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.target`,
				message: "元の共有指摘の私的固定版と引用は変更できません。現在稿の修正は別に保存してください。"
			}), t.data.stage === "open" && e.data.stage === "verified" && d.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.stage`,
				message: "共有指摘は修正済みを保存してから再確認してください。"
			}));
		}
	};
	i && f(i.previous.entities, t.entities, "project.entities");
	for (let [e, n] of t.history.entries()) f(n.before.entities, n.after.entities, `project.history[${e}].after.entities`);
	d.push(...await pe(t, s.worldSnapshots, "project.worldReferences", o));
	for (let [e, n] of t.snapshots.entries()) d.push(...await pe(n.content, s.worldSnapshots, `project.snapshots[${e}].content.worldReferences`, o));
	if (d.push(...await wn(t, s, "project", o)), d.push(...await Tn(t, s, o)), d.push(...Sn(t)), r) for (let [e, n] of (t.authorAlternatives ?? []).entries()) for (let [r, i] of n.applyReceipts.entries()) {
		let n = `project.authorAlternatives[${e}].applyReceipts[${r}]`, a = t.history.find((e) => e.revision === i.appliedRevision && e.before.revision === i.fromCanonicalRevision && i.patches.every((t) => {
			let n = hn(e.before, t), r = hn(e.after, t), i = t.before.present ? t.before.value : void 0, a = t.after.present ? t.after.value : void 0;
			return A(n ?? null) === A(i ?? null) && n === void 0 == !t.before.present && A(r ?? null) === A(a ?? null) && r === void 0 == !t.after.present;
		}));
		if (!a) {
			d.push({
				code: "INTEGRITY_FAILED",
				path: n,
				message: "正本採用記録に対応する不変の変更履歴がありません。"
			});
			continue;
		}
		for (let [e, t] of i.patches.entries()) {
			let r = hn(a.before, t), i = hn(a.after, t), o = t.before.present ? t.before.value : void 0, s = t.after.present ? t.after.value : void 0;
			(A(r ?? null) !== A(o ?? null) || r === void 0 != !t.before.present) && d.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.patches[${e}].before`,
				message: "採用前の正本値が対応する変更履歴と一致しません。"
			}), (A(i ?? null) !== A(s ?? null) || i === void 0 != !t.after.present) && d.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.patches[${e}].after`,
				message: "採用後の正本値が対応する変更履歴と一致しません。"
			});
		}
	}
	for (let [e, n] of t.history.entries()) for (let t of ["before", "after"]) {
		let r = n[t], i = bn(r);
		d.push(...await pe(i, s.worldSnapshots, `project.history[${e}].${t}.worldReferences`, o));
		for (let [n, r] of i.snapshots.entries()) d.push(...await pe(r.content, s.worldSnapshots, `project.history[${e}].${t}.snapshots[${n}].content.worldReferences`, o));
		r.authorAlternatives?.length && d.push(...await wn(i, s, `project.history[${e}].${t}`, o)), d.push(...await Tn(i, s, o));
	}
	return d.slice(0, 256);
}
//#endregion
//#region src/domain/internImmutableRecords.ts
function kn() {
	let e = /* @__PURE__ */ new WeakMap(), t = /* @__PURE__ */ new Map(), n = 0, r = (e, t, n = /* @__PURE__ */ new WeakMap()) => {
		if (Object.is(e, t)) return !0;
		if (!e || !t || typeof e != "object" || typeof t != "object" || Object.getPrototypeOf(e) !== Object.getPrototypeOf(t)) return !1;
		if (n.get(e)?.has(t)) return !0;
		let i = Reflect.ownKeys(e);
		if (i.length !== Reflect.ownKeys(t).length || i.some((e) => !Object.hasOwn(t, e))) return !1;
		let a = n.get(e);
		return a || (a = /* @__PURE__ */ new WeakSet(), n.set(e, a)), a.add(t), i.every((i) => r(e[i], t[i], n));
	}, i = (a, o = 0) => {
		if (!a || typeof a != "object" || o > 128) return a;
		if (e.has(a)) return e.get(a);
		let s = a;
		if (typeof s.id == "string" && typeof s.projectId == "string" && (typeof s.kind == "string" && s.data && typeof s.data == "object" || typeof s.relationType == "string" && typeof s.fromId == "string" && typeof s.toId == "string")) {
			let i = `${s.projectId}:${s.kind ?? s.relationType}:${s.id}`, o = t.get(i)?.find((e) => r(a, e));
			return o ? (e.set(a, o), o) : (n >= 1e5 && (t.clear(), n = 0), t.has(i) ? t.get(i).unshift(a) : t.set(i, [a]), n++, e.set(a, a), a);
		}
		let c = Object.keys(a), l;
		for (let e of c) {
			let t = s[e], n = i(t, o + 1);
			Object.is(n, t) || (l ??= /* @__PURE__ */ new Map(), l.set(e, n));
		}
		if (!l) return e.set(a, a), a;
		let u = Array.isArray(a) ? Array(a.length) : Object.create(Object.getPrototypeOf(a));
		for (let e of c) Object.defineProperty(u, e, {
			value: l.has(e) ? l.get(e) : s[e],
			enumerable: !0,
			writable: !0,
			configurable: !0
		});
		return e.set(a, u), u;
	};
	return (e) => {
		let t = i(e);
		return l(t) ? t : e;
	};
}
function An(e) {
	return S(e) ? kn()(e) : e;
}
Object.hasOwn, Array.isArray, Array.prototype.every, Array.prototype.some, Array.prototype.find, Array.prototype.unshift, Map.prototype.get, Map.prototype.set, Map.prototype.has, Map.prototype.clear, WeakMap.prototype.get, WeakMap.prototype.set, WeakMap.prototype.has, WeakSet.prototype.has, WeakSet.prototype.add;
async function jn(e, t) {
	if (o(t), !S(e)) return e;
	let n = /* @__PURE__ */ new WeakMap(), r = /* @__PURE__ */ new Map(), i = 0, a = 0, s = performance.now() + 8, c = async () => {
		++a % 128 == 0 && performance.now() >= s && (o(t), await new Promise((e) => setTimeout(e, 0)), o(t), s = performance.now() + 8);
	}, l = async (e, t) => {
		let n = /* @__PURE__ */ new WeakMap(), r = [[e, t]];
		for (; r.length;) {
			let [e, t] = r.pop();
			if (Object.is(e, t)) continue;
			if (!e || !t || typeof e != "object" || typeof t != "object" || Object.getPrototypeOf(e) !== Object.getPrototypeOf(t)) return !1;
			if (n.get(e)?.has(t)) continue;
			let i = Reflect.ownKeys(e);
			if (i.length !== Reflect.ownKeys(t).length) return !1;
			let a = n.get(e);
			a || (a = /* @__PURE__ */ new WeakSet(), n.set(e, a)), a.add(t);
			for (let n of i) {
				if (!Object.hasOwn(t, n)) return !1;
				r.push([e[n], t[n]]), await c();
			}
			await c();
		}
		return !0;
	}, u = [], d = async (e) => {
		if (!e || typeof e != "object") return e;
		if (n.has(e)) return n.get(e);
		let t = e;
		if (typeof t.id == "string" && typeof t.projectId == "string" && (typeof t.kind == "string" && t.data && typeof t.data == "object" || typeof t.relationType == "string" && typeof t.fromId == "string" && typeof t.toId == "string")) {
			let a = `${t.projectId}:${t.kind ?? t.relationType}:${t.id}`;
			for (let t of r.get(a) ?? []) if (await l(e, t)) return n.set(e, t), t;
			return i >= 1e5 && (r.clear(), i = 0), r.has(a) ? r.get(a).unshift(e) : r.set(a, [e]), i++, n.set(e, e), e;
		}
		let a = Array.isArray(e) ? Array(e.length) : Object.create(Object.getPrototypeOf(e));
		return n.set(e, a), u.push({
			input: e,
			output: a,
			keys: Array.isArray(e) ? void 0 : Object.keys(e),
			index: 0
		}), a;
	}, f = await d(e);
	for (; u.length;) {
		let e = u.at(-1), t = e.keys?.length ?? e.input.length;
		if (e.index >= t) {
			u.pop();
			continue;
		}
		let n = e.keys?.[e.index] ?? String(e.index);
		e.index++;
		let r = await d(e.input[n]);
		Object.defineProperty(e.output, n, {
			value: r,
			enumerable: !0,
			writable: !0,
			configurable: !0
		}), await c();
	}
	return o(t), await b(f, t) ? f : e;
}
//#endregion
//#region src/sync/merge.ts
function Mn(e) {
	return e ? {
		fields: e.fields,
		tombstone: e.tombstone
	} : null;
}
function Nn(e, t, n) {
	n.present && (e[t] = R(n.value));
}
function Pn(e, t, n, r) {
	return {
		targetId: t.id,
		base: R(e),
		local: R(t),
		server: R(n),
		reasons: r,
		fields: [],
		automaticFields: {}
	};
}
function Fn(e, t, n) {
	De(t);
	for (let r of [e, n]) if (r && (De(r), r.id !== t.id || r.projectId !== t.projectId)) throw new z("PROTOCOL_INVALID");
	if (!e) return !n || L(Mn(t), Mn(n)) ? {
		status: "merged",
		document: R(n ?? t)
	} : {
		status: "conflict",
		conflict: Pn(e, t, n, ["concurrent-create"])
	};
	if (!n) return {
		status: "conflict",
		conflict: Pn(e, t, n, ["missing-server-record"])
	};
	let r = !L(Mn(e), Mn(t)), i = !L(Mn(e), Mn(n));
	if (!r) return {
		status: "merged",
		document: R(n)
	};
	if (!i) return {
		status: "merged",
		document: R(t)
	};
	if (L(Mn(t), Mn(n))) return {
		status: "merged",
		document: R(n)
	};
	let a = t.tombstone !== null, o = n.tombstone !== null, s = !L(e.tombstone, t.tombstone), c = !L(e.tombstone, n.tombstone);
	if (a !== o && (s || c)) return {
		status: "conflict",
		conflict: Pn(e, t, n, ["delete-versus-edit"])
	};
	if (a || o) return a && o && L(t.fields, n.fields) ? {
		status: "merged",
		document: R(n)
	} : {
		status: "conflict",
		conflict: Pn(e, t, n, ["delete-versus-edit"])
	};
	let l = R(n);
	l.fields = {};
	let u = Pn(e, t, n, ["same-field"]), d = [.../* @__PURE__ */ new Set([
		...Object.keys(e.fields),
		...Object.keys(t.fields),
		...Object.keys(n.fields)
	])].sort();
	for (let r of d) {
		let i = Oe(e, r), a = Oe(t, r), o = Oe(n, r), s;
		if (L(a, o)) s = a;
		else if (L(a, i)) s = o;
		else if (L(o, i)) s = a;
		else {
			u.fields.push({
				field: r,
				base: i,
				local: a,
				server: o
			});
			continue;
		}
		u.automaticFields[r] = R(s), Nn(l.fields, r, s);
	}
	return u.fields.length ? {
		status: "conflict",
		conflict: u
	} : {
		status: "merged",
		document: l
	};
}
function In(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) if (![
		"id",
		"projectId",
		"revision",
		"createdAt",
		"updatedAt",
		"deletedAt",
		"deleteOperationId",
		"deletionOperationId"
	].includes(n)) {
		if (n === "$tombstone" || n.startsWith("data.")) throw new z("PROTOCOL_INVALID");
		if (n === "data" && r && typeof r == "object" && !Array.isArray(r)) for (let [e, n] of Object.entries(r)) {
			if (e.includes(".")) throw new z("PROTOCOL_INVALID");
			n !== void 0 && (t["data." + e] = R(n));
		}
		else r !== void 0 && (t[n] = R(r));
	}
	return t;
}
//#endregion
//#region src/sync/validation.ts
async function Ln(e, t) {
	await Ae(e, t);
	let n = [];
	for (let [r, i] of e.targets.entries()) {
		let e = t.documents[r], a = Fn(i.base, i.local, e);
		if (t.status === "applied") {
			if (a.status !== "merged" || !e || !L({
				fields: a.document.fields,
				tombstone: a.document.tombstone
			}, {
				fields: e.fields,
				tombstone: e.tombstone
			})) throw new z("PROTOCOL_INVALID");
		} else a.status === "conflict" && n.push(a.conflict);
	}
	if (t.status === "conflict" && !L(t.conflicts, n)) throw new z("PROTOCOL_INVALID");
}
//#endregion
//#region src/sync/adapter.ts
function Rn(e) {
	if (e.deletedAt && !e.deletionOperationId) throw new z("PROTOCOL_INVALID");
	let t = {
		id: e.id,
		projectId: e.projectId,
		revision: e.revision,
		fields: In(e),
		tombstone: e.deletedAt ? {
			deletedAt: e.deletedAt,
			operationId: e.deletionOperationId
		} : null
	};
	return De(t), t;
}
//#endregion
//#region src/sync/nativeBridge.ts
function zn(e, t) {
	let { entities: n, relations: r, history: i, ...a } = e;
	return [
		Rn({
			...a,
			id: e.projectId,
			kind: "project",
			visibility: "private",
			revision: t,
			entityIds: n.map((e) => e.id),
			relationIds: r.map((e) => e.id)
		}),
		...n.map((e) => {
			let n = Rn({
				...e,
				revision: t
			});
			return n.fields.createdAt = e.createdAt, n;
		}),
		...r.map((e) => Rn({
			...e,
			revision: t
		}))
	];
}
function Bn(e, t) {
	return L(e ? {
		fields: e.fields,
		tombstone: e.tombstone
	} : null, t ? {
		fields: t.fields,
		tombstone: t.tombstone
	} : null);
}
function Vn(e) {
	let t = {
		id: e.id,
		projectId: e.projectId,
		revision: e.revision
	};
	for (let [n, r] of Object.entries(e.fields)) if (n.startsWith("data.")) {
		let e = n.slice(5);
		if (!e || e.includes(".") || [
			"__proto__",
			"prototype",
			"constructor"
		].includes(e)) throw new z("PROTOCOL_INVALID");
		t.data ??= {}, t.data[e] = R(r);
	} else {
		if ([
			"id",
			"projectId",
			"revision",
			"updatedAt",
			"deletedAt",
			"deletionOperationId",
			"__proto__",
			"prototype",
			"constructor"
		].includes(n)) throw new z("PROTOCOL_INVALID");
		t[n] = R(r);
	}
	return e.tombstone && (t.deletedAt = e.tombstone.deletedAt, t.deletionOperationId = e.tombstone.operationId), t;
}
function Hn(e, t, n) {
	let r = new Map(t.map((e) => [e.id, e]));
	if (r.size !== t.length) throw new z("PROTOCOL_INVALID");
	let i = r.get(e.projectId);
	if (!i || i.fields.kind !== "project" || i.tombstone) throw new z("PROTOCOL_INVALID");
	let { id: a, kind: o, visibility: s, entityIds: c, relationIds: l, ...u } = Vn(i);
	if (!Array.isArray(c) || !Array.isArray(l) || [...c, ...l].some((e) => typeof e != "string") || (/* @__PURE__ */ new Set([
		...c,
		...l,
		i.id
	])).size !== t.length) throw new z("PROTOCOL_INVALID");
	let d = new Map([...e.entities, ...e.relations].map((e) => [e.id, e])), f = (t, i) => {
		let a = r.get(t);
		if (!a || a.projectId !== e.projectId) throw new z("PROTOCOL_INVALID");
		let o = Vn(a), s = d.get(a.id);
		if (i) {
			if (o.createdAt = o.createdAt ?? (s && "createdAt" in s ? s.createdAt : n), s && "createdAt" in s && s.createdAt !== o.createdAt) throw new z("PROTOCOL_INVALID");
			o.updatedAt = s && "updatedAt" in s ? s.updatedAt : n;
		}
		return o.revision = s?.revision ?? "0", a.tombstone || (delete o.deletedAt, delete o.deletionOperationId), o;
	};
	return {
		...u,
		projectId: e.projectId,
		revision: e.revision,
		entities: c.map((e) => f(e, !0)),
		relations: l.map((e) => f(e, !1)),
		history: e.history
	};
}
async function Un(e, t, n, r, i) {
	e = R(e);
	let a = R(n), o = R(t), s = R(r), c = zn(a, o.serverRevision), l = new Map(o.documents.map((e) => [e.id, e])), u = c.filter((e) => !Bn(l.get(e.id), e)).map((e) => ({
		base: l.get(e.id) ?? null,
		local: e
	}));
	if (o.documents.some((e) => !c.some((t) => t.id === e.id))) throw new z("PROTOCOL_INVALID");
	if (!u.length) return null;
	let d = await Te({
		scope: R(e),
		baseRevision: o.serverRevision,
		operationId: j(),
		targets: u,
		reason: i
	});
	return {
		operationId: d.operationId,
		projectId: e.projectId,
		operation: d,
		localRevision: a.revision,
		localDocuments: c,
		outboxIds: s,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function Wn(e, t, n, r) {
	if (BigInt(n.serverRevision) < BigInt(t.serverRevision) || !n.confirmedDocuments) throw new z("PROTOCOL_INVALID");
	let i = new Map(n.confirmedDocuments.map((e) => [e.id, R(e)])), a = Array.isArray(r) ? r : zn(r, n.serverRevision), o = new Map(e.localDocuments.map((e) => [e.id, e])), s = [], c = [];
	for (let e of a) {
		let t = i.get(e.id) ?? null, n = o.get(e.id) ?? null;
		if (!n && !t) {
			c.push(R(e));
			continue;
		}
		let r = Fn(n, e, t);
		r.status === "conflict" ? (s.push(r.conflict), c.push(R(e))) : c.push(r.document);
	}
	for (let e of i.values()) c.some((t) => t.id === e.id) || c.push(R(e));
	return {
		confirmed: [...i.values()],
		documents: c,
		conflicts: s
	};
}
function Gn(e, t, n, r) {
	let i = new Map(n.map((e) => [e.id, e])), a = new Map((Array.isArray(r) ? r : zn(r, e.ack.serverRevision)).map((e) => [e.id, e]));
	if (!L(Object.keys(t).sort(), e.conflicts.map((e) => e.targetId).sort())) throw new z("PROTOCOL_INVALID");
	let o = /* @__PURE__ */ new Set([
		...e.prepared.operation.targets.map((e) => e.targetId),
		...e.conflicts.map((e) => e.targetId),
		...a.keys()
	]), s = [];
	for (let n of o) {
		let r = i.get(n) ?? null, o = a.get(n), c = e.prepared.operation.targets.find((e) => e.targetId === n), l = e.conflicts.find((e) => e.targetId === n);
		if (!o) throw new z("PROTOCOL_INVALID");
		let u = R(o);
		if (l) {
			if (!L(l.server, r)) throw new z("REVISION_CHANGED");
			let e = Fn(l.base, o, r), i = t[n];
			if (e.status === "merged") u = e.document;
			else if (i.strategy === "fields") {
				if (e.conflict.reasons.some((e) => e !== "same-field") || !L(Object.keys(i.choices).sort(), e.conflict.fields.map((e) => e.field).sort()) || !r) throw new z("REVISION_CHANGED");
				u = R(r), u.fields = {};
				for (let [t, n] of Object.entries(e.conflict.automaticFields)) n.present && (u.fields[t] = R(n.value));
				for (let t of e.conflict.fields) {
					let e = i.choices[t.field], n = e === "local" ? t.local : e === "server" ? t.server : e.value;
					n.present && (u.fields[t.field] = R(n.value));
				}
			} else if (e.conflict.reasons.every((e) => e === "same-field") && r) {
				u = R(r), u.fields = {};
				for (let [t, n] of Object.entries(e.conflict.automaticFields)) n.present && (u.fields[t] = R(n.value));
				for (let t of e.conflict.fields) {
					let e = i.strategy === "local" ? t.local : t.server;
					e.present && (u.fields[t.field] = R(e.value));
				}
			} else u = R(i.strategy === "local" ? o : r ?? (() => {
				throw new z("BASE_UNAVAILABLE");
			})());
		} else if (e.ack.status === "conflict" && c) {
			let e = Fn(c.base, o, r);
			if (e.status === "conflict") throw new z("REVISION_CHANGED");
			u = e.document;
		}
		(c || l || !Bn(r, u)) && s.push({
			base: R(r),
			local: u
		});
	}
	return s;
}
//#endregion
//#region src/storage/syncRecovery.ts
function Kn(e = []) {
	return e.flatMap((e) => {
		let t = [];
		e.base && t.push(e.base.documents);
		for (let n of e.prepared) t.push(n.localDocuments);
		for (let n of e.conflicts) t.push(n.prepared.localDocuments), n.ack.confirmedDocuments && t.push(n.ack.confirmedDocuments);
		for (let n of e.acknowledgements) n.ack.confirmedDocuments && t.push(n.ack.confirmedDocuments);
		return [R(e.origin), ...t.map((t) => Hn(e.origin, t, "1970-01-01T00:00:00.000Z"))].map((e) => ({
			...e,
			history: []
		}));
	});
}
async function qn(e, t, n) {
	if (!Array.isArray(e) || e.length > 1e5) throw new s("VALIDATION_FAILED", "同期復元証跡の形式・件数が不正です。");
	let r = R(e), i = /* @__PURE__ */ new Set();
	try {
		for (let e of r) {
			if (o(n), !e || e.format !== "scenario-sync-recovery" || e.version !== 1 || e.state !== "needs_reconnect" || !e.origin || !C.test(e.origin.projectId) || !Array.isArray(e.prepared) || !Array.isArray(e.conflicts) || !Array.isArray(e.acknowledgements) || Object.keys(e).some((e) => ![
				"format",
				"version",
				"state",
				"origin",
				"base",
				"prepared",
				"conflicts",
				"acknowledgements",
				"assetAcknowledgements",
				"contentHash"
			].includes(e))) throw new z("PROTOCOL_INVALID");
			let { contentHash: r, ...a } = e;
			if (await Ee(a) !== r || i.has(r) || (i.add(r), e.base && (!B(e.base.serverRevision) || !Array.isArray(e.base.documents) || e.base.documents.length > 100001 || e.base.projectId !== e.origin.projectId || await Ee(e.base.documents) !== e.base.contentHash))) throw new z("PROTOCOL_INVALID");
			if (e.base) for (let t of e.base.documents) we(t, {
				accountId: "00000000-0000-4000-8000-000000000001",
				projectId: e.origin.projectId
			}, t.id);
			if (e.assetAcknowledgements) {
				if (!Array.isArray(e.assetAcknowledgements)) throw new z("PROTOCOL_INVALID");
				for (let t of e.assetAcknowledgements) if (t.projectId !== e.origin.projectId || t.key !== `${t.projectId}:${t.contentHash}` || !/^[0-9a-f]{64}$/.test(t.contentHash) || !Number.isSafeInteger(t.byteSize) || t.byteSize < 0 || t.byteSize > 33554432 || typeof t.mediaType != "string") throw new z("PROTOCOL_INVALID");
			}
			for (let t of [...e.prepared, ...e.conflicts.map((e) => e.prepared)]) {
				if (await ke(t.operation), t.operationId !== t.operation.operationId || t.projectId !== e.origin.projectId || t.operation.scope.projectId !== t.projectId || !B(t.localRevision) || !Array.isArray(t.localDocuments) || t.localDocuments.length > 100001 || !Array.isArray(t.outboxIds) || t.outboxIds.length > 1e5 || new Set(t.outboxIds).size !== t.outboxIds.length || t.outboxIds.some((e) => !C.test(e)) || !Number.isFinite(Date.parse(t.createdAt)) || t.origin !== void 0 && !["prepared_operation", "received_image"].includes(t.origin)) throw new z("PROTOCOL_INVALID");
				for (let e of t.localDocuments) we(e, t.operation.scope, e.id);
				for (let e of t.operation.targets) if (!L(e.local, t.localDocuments.find((t) => t.id === e.targetId))) throw new z("PROTOCOL_INVALID");
			}
			for (let t of e.conflicts) if (t.operationId !== t.prepared.operationId || t.projectId !== e.origin.projectId || (await Ln(t.prepared.operation, t.ack), !Array.isArray(t.conflicts) || t.conflicts.some((e) => {
				let t = Fn(e.base, e.local, e.server);
				return t.status !== "conflict" || !L(t.conflict, e);
			})) || t.ack.status === "conflict" && JSON.stringify(t.conflicts) !== JSON.stringify(t.ack.conflicts)) throw new z("PROTOCOL_INVALID");
			for (let t of e.acknowledgements) {
				if (t.origin !== void 0 && !["prepared_operation", "received_image"].includes(t.origin) || t.projectId !== e.origin.projectId || t.operationId !== t.operation.operationId) throw new z("PROTOCOL_INVALID");
				await ke(t.operation), await Ln(t.operation, t.ack);
			}
			for (let r of Kn([e])) if (o(n), !u(r, { worldSnapshots: t }).ok || (await En(r, { worldSnapshots: t }, !1)).length) throw new z("PROTOCOL_INVALID");
		}
	} catch {
		throw n?.aborted && o(n), new s("VALIDATION_FAILED", "同期の共通元・二案・ACK・hashの整合性を確認できません。");
	}
	return r;
}
//#endregion
//#region src/storage/recordDictionary.ts
var Jn = "shared-records-v1", Yn = "shared-record-deltas-v1", Xn = "shared-calendar-records-v1", Zn = (e) => !!e && typeof e == "object" && !Array.isArray(e), Qn = (e) => Zn(e) && typeof e.id == "string" && typeof e.projectId == "string" && (typeof e.kind == "string" && Zn(e.data) || typeof e.relationType == "string" && typeof e.fromId == "string" && typeof e.toId == "string" || typeof e.revision == "string" && Zn(e.fields) && Object.hasOwn(e, "tombstone")), $n = (e) => Zn(e) && typeof e.id == "string" && (e.kind === "gregorian" || e.kind === "repeating"), er = "__recordBase", tr = "__recordDelete", nr = class {
	features;
	records = [];
	arrays = [];
	ids = /* @__PURE__ */ new Map();
	identities = /* @__PURE__ */ new WeakMap();
	arrayIds = /* @__PURE__ */ new Map();
	previous = /* @__PURE__ */ new Map();
	previousRecords = /* @__PURE__ */ new Map();
	previousKinds = /* @__PURE__ */ new Map();
	usedFeatures = /* @__PURE__ */ new Set();
	constructor(e = {}) {
		this.features = e;
	}
	eligible(e) {
		return Qn(e) || !!this.features.calendarRecords && $n(e);
	}
	add(e) {
		let t = this.identities.get(e);
		if (t !== void 0) return t;
		let n = A(e), r = this.ids.get(n);
		if (r === void 0) {
			r = this.records.length;
			let t = e, i = typeof e.kind == "string" && Zn(e.data) ? "entity" : typeof e.relationType == "string" ? "relation" : $n(e) ? "calendar" : "shadow", a = JSON.stringify([
				i,
				e.projectId ?? null,
				e.kind ?? e.relationType ?? null
			]), o = JSON.stringify([a, e.id]), s = this.previousRecords.get(o), c = this.previousKinds.get(a), l = s?.id === c?.id ? [s] : [s, c], u = n.length;
			if (this.features.recordDeltas && !Object.hasOwn(e, er) && !Object.hasOwn(e, tr)) for (let n of l) {
				if (!n || Object.hasOwn(n.value, er) || Object.hasOwn(n.value, tr)) continue;
				let r = { [er]: n.id }, i = [];
				for (let t of Object.keys(n.value)) n.value[t] !== void 0 && (!Object.hasOwn(e, t) || e[t] === void 0) && i.push(t);
				for (let t of Object.keys(e)) e[t] !== void 0 && (!Object.hasOwn(n.value, t) || n.value[t] === void 0 || A(e[t]) !== A(n.value[t])) && Object.defineProperty(r, t, {
					value: e[t],
					enumerable: !0
				});
				i.length && (r[tr] = i);
				let a = A(r).length;
				a < u && (t = r, u = a, this.usedFeatures.add(Yn));
			}
			!Qn(e) && $n(e) && this.usedFeatures.add(Xn), this.records.push(t), this.ids.set(n, r), this.previousRecords.set(o, {
				id: r,
				value: e
			}), this.previousKinds.set(a, {
				id: r,
				value: e
			});
		}
		return this.identities.set(e, r), r;
	}
	encode(e) {
		let t = [], n = [], r = (e, i) => {
			if (Array.isArray(e)) {
				if (e.length && e.every((e) => this.eligible(e))) {
					t.push(i);
					let n = e.map((e) => this.add(e)), r = n.join(","), a = this.arrayIds.get(r);
					if (a === void 0) {
						a = this.arrays.length;
						let e = this.previous.get(n.length), t = e ? n.flatMap((t, n) => t === e.values[n] ? [] : [[n, t]]) : void 0;
						this.arrays.push(e && t && t.length * 2 < n.length ? {
							base: e.id,
							length: n.length,
							changes: t
						} : { values: n }), this.arrayIds.set(r, a);
					}
					return this.previous.set(n.length, {
						id: a,
						values: n
					}), a;
				}
				return e.map((e, t) => r(e, [...i, t]));
			}
			return Zn(e) ? this.eligible(e) ? (n.push(i), this.add(e)) : Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0).map(([e, t]) => [e, r(t, [...i, e])])) : e;
		};
		return {
			version: 1,
			value: r(e, []),
			arrays: t,
			records: n
		};
	}
}, rr = Uint8Array, ir = Uint16Array, ar = Int32Array, or = new rr([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), sr = new rr([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), cr = new rr([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), lr = function(e, t) {
	for (var n = new ir(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new ar(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, ur = lr(or, 2), dr = ur.b, fr = ur.r;
dr[28] = 258, fr[258] = 28;
var pr = lr(sr, 0);
pr.b;
for (var mr = pr.r, hr = new ir(32768), Y = 0; Y < 32768; ++Y) {
	var gr = (Y & 43690) >> 1 | (Y & 21845) << 1;
	gr = (gr & 52428) >> 2 | (gr & 13107) << 2, gr = (gr & 61680) >> 4 | (gr & 3855) << 4, hr[Y] = ((gr & 65280) >> 8 | (gr & 255) << 8) >> 1;
}
for (var _r = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new ir(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new ir(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new ir(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[hr[d] >> c] = l;
	} else for (s = new ir(r), i = 0; i < r; ++i) e[i] && (s[i] = hr[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), vr = new rr(288), Y = 0; Y < 144; ++Y) vr[Y] = 8;
for (var Y = 144; Y < 256; ++Y) vr[Y] = 9;
for (var Y = 256; Y < 280; ++Y) vr[Y] = 7;
for (var Y = 280; Y < 288; ++Y) vr[Y] = 8;
for (var yr = new rr(32), Y = 0; Y < 32; ++Y) yr[Y] = 5;
var br = /*#__PURE__*/ _r(vr, 9, 0), xr = /*#__PURE__*/ _r(yr, 5, 0), Sr = function(e) {
	return (e + 7) / 8 | 0;
}, Cr = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new rr(e.subarray(t, n));
}, wr = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], Tr = function(e, t, n) {
	var r = Error(t || wr[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, Tr), !n) throw r;
	return r;
}, Er = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8;
}, Dr = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8, e[r + 2] |= n >> 16;
}, Or = function(e, t) {
	for (var n = [], r = 0; r < e.length; ++r) e[r] && n.push({
		s: r,
		f: e[r]
	});
	var i = n.length, a = n.slice();
	if (!i) return {
		t: Fr,
		l: 0
	};
	if (i == 1) {
		var o = new rr(n[0].s + 1);
		return o[n[0].s] = 1, {
			t: o,
			l: 1
		};
	}
	n.sort(function(e, t) {
		return e.f - t.f;
	}), n.push({
		s: -1,
		f: 25001
	});
	var s = n[0], c = n[1], l = 0, u = 1, d = 2;
	for (n[0] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	}; u != i - 1;) s = n[n[l].f < n[d].f ? l++ : d++], c = n[l != u && n[l].f < n[d].f ? l++ : d++], n[u++] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	};
	for (var f = a[0].s, r = 1; r < i; ++r) a[r].s > f && (f = a[r].s);
	var p = new ir(f + 1), m = kr(n[u - 1], p, 0);
	if (m > t) {
		var r = 0, h = 0, g = m - t, _ = 1 << g;
		for (a.sort(function(e, t) {
			return p[t.s] - p[e.s] || e.f - t.f;
		}); r < i; ++r) {
			var v = a[r].s;
			if (p[v] > t) h += _ - (1 << m - p[v]), p[v] = t;
			else break;
		}
		for (h >>= g; h > 0;) {
			var y = a[r].s;
			p[y] < t ? h -= 1 << t - p[y]++ - 1 : ++r;
		}
		for (; r >= 0 && h; --r) {
			var b = a[r].s;
			p[b] == t && (--p[b], ++h);
		}
		m = t;
	}
	return {
		t: new rr(p),
		l: m
	};
}, kr = function(e, t, n) {
	return e.s == -1 ? Math.max(kr(e.l, t, n + 1), kr(e.r, t, n + 1)) : t[e.s] = n;
}, Ar = function(e) {
	for (var t = e.length; t && !e[--t];);
	for (var n = new ir(++t), r = 0, i = e[0], a = 1, o = function(e) {
		n[r++] = e;
	}, s = 1; s <= t; ++s) if (e[s] == i && s != t) ++a;
	else {
		if (!i && a > 2) {
			for (; a > 138; a -= 138) o(32754);
			a > 2 && (o(a > 10 ? a - 11 << 5 | 28690 : a - 3 << 5 | 12305), a = 0);
		} else if (a > 3) {
			for (o(i), --a; a > 6; a -= 6) o(8304);
			a > 2 && (o(a - 3 << 5 | 8208), a = 0);
		}
		for (; a--;) o(i);
		a = 1, i = e[s];
	}
	return {
		c: n.subarray(0, r),
		n: t
	};
}, jr = function(e, t) {
	for (var n = 0, r = 0; r < t.length; ++r) n += e[r] * t[r];
	return n;
}, Mr = function(e, t, n) {
	var r = n.length, i = Sr(t + 2);
	e[i] = r & 255, e[i + 1] = r >> 8, e[i + 2] = e[i] ^ 255, e[i + 3] = e[i + 1] ^ 255;
	for (var a = 0; a < r; ++a) e[i + a + 4] = n[a];
	return (i + 4 + r) * 8;
}, Nr = function(e, t, n, r, i, a, o, s, c, l, u) {
	Er(t, u++, n), ++i[256];
	for (var d = Or(i, 15), f = d.t, p = d.l, m = Or(a, 15), h = m.t, g = m.l, _ = Ar(f), v = _.c, y = _.n, b = Ar(h), x = b.c, S = b.n, C = new ir(19), w = 0; w < v.length; ++w) ++C[v[w] & 31];
	for (var w = 0; w < x.length; ++w) ++C[x[w] & 31];
	for (var T = Or(C, 7), ee = T.t, E = T.l, te = 19; te > 4 && !ee[cr[te - 1]]; --te);
	var ne = l + 5 << 3, re = jr(i, vr) + jr(a, yr) + o, ie = jr(i, f) + jr(a, h) + o + 14 + 3 * te + jr(C, ee) + 2 * C[16] + 3 * C[17] + 7 * C[18];
	if (c >= 0 && ne <= re && ne <= ie) return Mr(t, u, e.subarray(c, c + l));
	var D, O, ae, k;
	if (Er(t, u, 1 + (ie < re)), u += 2, ie < re) {
		D = _r(f, p, 0), O = f, ae = _r(h, g, 0), k = h;
		var A = _r(ee, E, 0);
		Er(t, u, y - 257), Er(t, u + 5, S - 1), Er(t, u + 10, te - 4), u += 14;
		for (var w = 0; w < te; ++w) Er(t, u + 3 * w, ee[cr[w]]);
		u += 3 * te;
		for (var j = [v, x], oe = 0; oe < 2; ++oe) for (var M = j[oe], w = 0; w < M.length; ++w) {
			var se = M[w] & 31;
			Er(t, u, A[se]), u += ee[se], se > 15 && (Er(t, u, M[w] >> 5 & 127), u += M[w] >> 12);
		}
	} else D = br, O = vr, ae = xr, k = yr;
	for (var w = 0; w < s; ++w) {
		var N = r[w];
		if (N > 255) {
			var se = N >> 18 & 31;
			Dr(t, u, D[se + 257]), u += O[se + 257], se > 7 && (Er(t, u, N >> 23 & 31), u += or[se]);
			var ce = N & 31;
			Dr(t, u, ae[ce]), u += k[ce], ce > 3 && (Dr(t, u, N >> 5 & 8191), u += sr[ce]);
		} else Dr(t, u, D[N]), u += O[N];
	}
	return Dr(t, u, D[256]), u + O[256];
}, Pr = /*#__PURE__*/ new ar([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]), Fr = /*#__PURE__*/ new rr(0), Ir = function(e, t, n, r, i, a) {
	var o = a.z || e.length, s = new rr(r + o + 5 * (1 + Math.ceil(o / 7e3)) + i), c = s.subarray(r, s.length - i), l = a.l, u = (a.r || 0) & 7;
	if (t) {
		u && (c[0] = a.r >> 3);
		for (var d = Pr[t - 1], f = d >> 13, p = d & 8191, m = (1 << n) - 1, h = a.p || new ir(32768), g = a.h || new ir(m + 1), _ = Math.ceil(n / 3), v = 2 * _, y = function(t) {
			return (e[t] ^ e[t + 1] << _ ^ e[t + 2] << v) & m;
		}, b = new ar(25e3), x = new ir(288), S = new ir(32), C = 0, w = 0, T = a.i || 0, ee = 0, E = a.w || 0, te = 0; T + 2 < o; ++T) {
			var ne = y(T), re = T & 32767, ie = g[ne];
			if (h[re] = ie, g[ne] = re, E <= T) {
				var D = o - T;
				if ((C > 7e3 || ee > 24576) && (D > 423 || !l)) {
					u = Nr(e, c, 0, b, x, S, w, ee, te, T - te, u), ee = C = w = 0, te = T;
					for (var O = 0; O < 286; ++O) x[O] = 0;
					for (var O = 0; O < 30; ++O) S[O] = 0;
				}
				var ae = 2, k = 0, A = p, j = re - ie & 32767;
				if (D > 2 && ne == y(T - j)) for (var oe = Math.min(f, D) - 1, M = Math.min(32767, T), se = Math.min(258, D); j <= M && --A && re != ie;) {
					if (e[T + ae] == e[T + ae - j]) {
						for (var N = 0; N < se && e[T + N] == e[T + N - j]; ++N);
						if (N > ae) {
							if (ae = N, k = j, N > oe) break;
							for (var ce = Math.min(j, N - 2), P = 0, O = 0; O < ce; ++O) {
								var le = T - j + O & 32767, F = le - h[le] & 32767;
								F > P && (P = F, ie = le);
							}
						}
					}
					re = ie, ie = h[re], j += re - ie & 32767;
				}
				if (k) {
					b[ee++] = 268435456 | fr[ae] << 18 | mr[k];
					var ue = fr[ae] & 31, I = mr[k] & 31;
					w += or[ue] + sr[I], ++x[257 + ue], ++S[I], E = T + ae, ++C;
				} else b[ee++] = e[T], ++x[e[T]];
			}
		}
		for (T = Math.max(T, E); T < o; ++T) b[ee++] = e[T], ++x[e[T]];
		u = Nr(e, c, l, b, x, S, w, ee, te, T - te, u), l || (a.r = u & 7 | c[u / 8 | 0] << 3, u -= 7, a.h = g, a.p = h, a.i = T, a.w = E);
	} else {
		for (var T = a.w || 0; T < o + l; T += 65535) {
			var de = T + 65535;
			de >= o && (c[u / 8 | 0] = l, de = o), u = Mr(c, u + 1, e.subarray(T, de));
		}
		a.i = o;
	}
	return Cr(s, 0, r + Sr(u) + i);
}, Lr = /*#__PURE__*/ (function() {
	for (var e = /* @__PURE__ */ new Int32Array(256), t = 0; t < 256; ++t) {
		for (var n = t, r = 9; --r;) n = (n & 1 && -306674912) ^ n >>> 1;
		e[t] = n;
	}
	return e;
})(), Rr = function() {
	var e = -1;
	return {
		p: function(t) {
			for (var n = e, r = 0; r < t.length; ++r) n = Lr[n & 255 ^ t[r]] ^ n >>> 8;
			e = n;
		},
		d: function() {
			return ~e;
		}
	};
}, zr = function(e, t, n, r, i) {
	if (!i && (i = { l: 1 }, t.dictionary)) {
		var a = t.dictionary.subarray(-32768), o = new rr(a.length + e.length);
		o.set(a), o.set(e, a.length), e = o, i.w = a.length;
	}
	return Ir(e, t.level == null ? 6 : t.level, t.mem == null ? i.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5) : 20 : 12 + t.mem, n, r, i);
}, Br = function(e, t) {
	var n = {};
	for (var r in e) n[r] = e[r];
	for (var r in t) n[r] = t[r];
	return n;
}, Vr = function(e, t, n) {
	for (; n; ++t) e[t] = n, n >>>= 8;
};
function Hr(e, t) {
	return zr(e, t || {}, 0, 0);
}
var Ur = function(e, t, n, r) {
	for (var i in e) {
		var a = e[i], o = t + i, s = r;
		Array.isArray(a) && (s = Br(r, a[1]), a = a[0]), ArrayBuffer.isView(a) ? n[o] = [a, s] : (n[o += "/"] = [new rr(0), s], Ur(a, o, n, r));
	}
}, Wr = typeof TextEncoder < "u" && /*#__PURE__*/ new TextEncoder(), Gr = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	Gr.decode(Fr, { stream: !0 });
} catch {}
function Kr(e, t) {
	if (t) {
		for (var n = new rr(e.length), r = 0; r < e.length; ++r) n[r] = e.charCodeAt(r);
		return n;
	}
	if (Wr) return Wr.encode(e);
	for (var i = e.length, a = new rr(e.length + (e.length >> 1)), o = 0, s = function(e) {
		a[o++] = e;
	}, r = 0; r < i; ++r) {
		if (o + 5 > a.length) {
			var c = new rr(o + 8 + (i - r << 1));
			c.set(a), a = c;
		}
		var l = e.charCodeAt(r);
		l < 128 || t ? s(l) : l < 2048 ? (s(192 | l >> 6), s(128 | l & 63)) : l > 55295 && l < 57344 ? (l = 65536 + (l & 1047552) | e.charCodeAt(++r) & 1023, s(240 | l >> 18), s(128 | l >> 12 & 63), s(128 | l >> 6 & 63), s(128 | l & 63)) : (s(224 | l >> 12), s(128 | l >> 6 & 63), s(128 | l & 63));
	}
	return Cr(a, 0, o);
}
var qr = function(e) {
	var t = 0;
	if (e) for (var n in e) {
		var r = e[n].length;
		r > 65535 && Tr(9), t += r + 4;
	}
	return t;
}, Jr = function(e, t, n, r, i, a, o, s) {
	var c = r.length, l = n.extra, u = s && s.length, d = qr(l);
	Vr(e, t, o == null ? 67324752 : 33639248), t += 4, o != null && (e[t++] = 20, e[t++] = n.os), e[t] = 20, t += 2, e[t++] = n.flag << 1 | (a < 0 && 8), e[t++] = i && 8, e[t++] = n.compression & 255, e[t++] = n.compression >> 8;
	var f = new Date(n.mtime == null ? Date.now() : n.mtime), p = f.getFullYear() - 1980;
	if ((p < 0 || p > 119) && Tr(10), Vr(e, t, p << 25 | f.getMonth() + 1 << 21 | f.getDate() << 16 | f.getHours() << 11 | f.getMinutes() << 5 | f.getSeconds() >> 1), t += 4, a != -1 && (Vr(e, t, n.crc), Vr(e, t + 4, a < 0 ? -a - 2 : a), Vr(e, t + 8, n.size)), Vr(e, t + 12, c), Vr(e, t + 14, d), t += 16, o != null && (Vr(e, t, u), Vr(e, t + 6, n.attrs), Vr(e, t + 10, o), t += 14), e.set(r, t), t += c, d) for (var m in l) {
		var h = l[m], g = h.length;
		Vr(e, t, +m), Vr(e, t + 2, g), e.set(h, t + 4), t += 4 + g;
	}
	return u && (e.set(s, t), t += u), t;
}, Yr = function(e, t, n, r, i) {
	Vr(e, t, 101010256), Vr(e, t + 8, n), Vr(e, t + 10, n), Vr(e, t + 12, r), Vr(e, t + 16, i);
};
function Xr(e, t) {
	t ||= {};
	var n = {}, r = [];
	Ur(e, "", n, t);
	var i = 0, a = 0;
	for (var o in n) {
		var s = n[o], c = s[0], l = s[1], u = l.level == 0 ? 0 : 8, d = Kr(o), f = d.length, p = l.comment, m = p && Kr(p), h = m && m.length, g = qr(l.extra);
		f > 65535 && Tr(11);
		var _ = u ? Hr(c, l) : c, v = _.length, y = Rr();
		y.p(c), r.push(Br(l, {
			size: c.length,
			crc: y.d(),
			c: _,
			f: d,
			m,
			u: f != o.length || m && p.length != h,
			o: i,
			compression: u
		})), i += 30 + f + g + v, a += 76 + 2 * (f + g) + (h || 0) + v;
	}
	for (var b = new rr(a + 22), x = i, S = a - i, C = 0; C < r.length; ++C) {
		var d = r[C];
		Jr(b, d.o, d, d.f, d.u, d.c.length);
		var w = 30 + d.f.length + qr(d.extra);
		b.set(d.c, d.o + w), Jr(b, i, d, d.f, d.u, d.c.length, d.o, d.m), i += 16 + w + (d.m ? d.m.length : 0);
	}
	return Yr(b, i, r.length, S, x), b;
}
//#endregion
//#region src/storage/sharedArrayJson.ts
function Zr() {
	let e = 67108864, t = /* @__PURE__ */ new WeakMap(), n = 0, r = 0, i = /* @__PURE__ */ new Map(), a = (a) => {
		let s = a[0], c = i.get(s);
		if (c && c.values.length === a.length && a.every((e, t) => e === c.values[t])) return i.delete(s), i.set(s, c), c.bytes;
		let l = M(a).slice(1, -1);
		if (l.byteLength <= e) {
			for (c && (i.delete(s), n -= c.bytes.byteLength), n + l.byteLength > e && r && (t = /* @__PURE__ */ new WeakMap(), n -= o, o = 0, r = 0); i.size && (n + l.byteLength > e || i.size >= 16384);) {
				let e = i.keys().next().value;
				n -= i.get(e).bytes.byteLength, i.delete(e);
			}
			i.set(s, {
				values: a,
				bytes: l
			}), n += l.byteLength;
		}
		return l;
	}, o = 0, s = new TextEncoder();
	return (c) => {
		if (!S(c)) return M(c);
		let l = [], u = (e) => l.push(s.encode(e)), d = (s) => {
			if (!s || typeof s != "object") {
				u(A(s));
				return;
			}
			if (Array.isArray(s)) {
				if (s.length >= 64) {
					if (s.every((e) => typeof e == "object" && !!e)) {
						u("[");
						for (let e = 0; e < s.length; e += 64) e && u(","), l.push(a(s.slice(e, e + 64)));
						u("]");
						return;
					}
					let c = t.get(s);
					if (!c && (c = M(s), c.byteLength <= e)) {
						if (n + c.byteLength > e || r + 1 > 128) for (t = /* @__PURE__ */ new WeakMap(), n -= o, o = 0, r = 0; i.size && n + c.byteLength > e;) {
							let e = i.keys().next().value;
							n -= i.get(e).bytes.byteLength, i.delete(e);
						}
						t.set(s, c), n += c.byteLength, o += c.byteLength, r++;
					}
					l.push(c);
					return;
				}
				u("["), s.forEach((e, t) => {
					t && u(","), d(e);
				}), u("]");
				return;
			}
			let c = s;
			u("{"), Object.keys(c).filter((e) => c[e] !== void 0).sort().forEach((e, t) => {
				t && u(","), u(JSON.stringify(e)), u(":"), d(c[e]);
			}), u("}");
		};
		d(c);
		let f = new Uint8Array(l.reduce((e, t) => e + t.byteLength, 0)), p = 0;
		for (let e of l) f.set(e, p), p += e.byteLength;
		return f;
	};
}
//#endregion
//#region src/storage/immutableCommandHash.ts
var Qr = Object.getOwnPropertyDescriptor, $r = Object.getPrototypeOf, ei = Object.prototype, ti = Array.prototype, ni = Number.prototype, ri = String.prototype, ii = Function.prototype.toString, ai = () => [
	JSON.stringify,
	Object.keys,
	Object.getOwnPropertyDescriptors,
	Object.getOwnPropertyDescriptor,
	Object.getPrototypeOf,
	Object.hasOwn,
	Object.isFrozen,
	Reflect.ownKeys,
	Array.isArray,
	Array.prototype.every,
	Array.prototype.forEach,
	Array.prototype.filter,
	Array.prototype.sort,
	Array.prototype.slice,
	Array.prototype.map,
	Array.prototype.join,
	Array.prototype.push,
	TextEncoder,
	TextEncoder.prototype.encode,
	Uint8Array,
	Uint8Array.prototype.set,
	Uint8Array.prototype.slice,
	Uint8Array.prototype[Symbol.iterator],
	Number.isFinite,
	Number.prototype.toString,
	String.prototype.charCodeAt,
	String.prototype.padStart,
	crypto.subtle,
	crypto.subtle.digest,
	Map.prototype.get,
	Map.prototype.set,
	Map.prototype.has,
	Map.prototype.delete,
	Map.prototype.keys,
	WeakMap.prototype.get,
	WeakMap.prototype.set,
	WeakSet.prototype.has,
	WeakSet.prototype.add
], oi = ai();
function si() {
	let e = ai();
	if (e.length !== oi.length) return !1;
	for (let t = 0; t < e.length; t++) if (e[t] !== oi[t]) return !1;
	return /\[native code\]/.test(ii.call(JSON.stringify)) && $r(ei) === null && $r(ti) === ei && Qr(ei, "toJSON") === void 0 && Qr(ti, "toJSON") === void 0 && Qr(ni, "toJSON") === void 0 && Qr(ri, "toJSON") === void 0;
}
function ci() {
	let e = /* @__PURE__ */ new WeakMap(), t = 0, n = Zr(), r = () => {
		e = /* @__PURE__ */ new WeakMap(), t = 0, n = Zr();
	};
	return async (i) => {
		let a = si() && S(i);
		a || r();
		let o = a ? e.get(i) : void 0;
		if (o !== void 0) return o;
		let s = await D(n(i));
		return a && si() ? (t >= 4096 && (e = /* @__PURE__ */ new WeakMap(), t = 0), e.set(i, s), t++) : r(), s;
	};
}
//#endregion
//#region src/storage/recovery.ts
function li(e) {
	return e?.pending.flatMap((e) => [e.command.before, e.command.after].map((e) => ({
		...e,
		history: []
	}))) ?? [];
}
function ui(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return (t === Object.prototype || t === null) && Reflect.ownKeys(e).every((t) => "value" in Object.getOwnPropertyDescriptor(e, t));
}
function di(e) {
	if (!Array.isArray(e) || Object.getPrototypeOf(e) !== Array.prototype || Object.getOwnPropertySymbols(e).length || Object.getOwnPropertyNames(e).length !== e.length + 1) return !1;
	for (let t = 0; t < e.length; t++) {
		let n = Object.getOwnPropertyDescriptor(e, String(t));
		if (!n || !("value" in n)) return !1;
	}
	return !0;
}
function fi(e, t) {
	if (!t || !ui(e) || !ui(t)) return !1;
	let n = Object.getOwnPropertyDescriptor(e, "history")?.value, r = Object.getOwnPropertyDescriptor(t, "pending")?.value;
	return di(n) && di(r) && n.every((e) => ui(e) && Object.hasOwn(e, "operationId")) && r.every((e) => ui(e) && Object.hasOwn(e, "operationId") && Object.hasOwn(e, "command"));
}
function pi() {
	let e = !1, t = /* @__PURE__ */ new WeakSet(), n = /* @__PURE__ */ new WeakMap(), r = /* @__PURE__ */ new WeakMap(), i = 0, a = 0;
	function o(e, r) {
		if (e === null || typeof e == "boolean") return !0;
		if (typeof e == "string") {
			if (!ne(e)) throw new s("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return !0;
		}
		if (typeof e == "number") {
			if (!Number.isFinite(e)) throw new s("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return !0;
		}
		if (typeof e != "object") throw new s("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (r.has(e)) throw new s("VALIDATION_FAILED", "循環したJSONは保存できません。");
		if (t.has(e)) return !0;
		if (Array.isArray(e) ? !di(e) : !ui(e)) return !1;
		r.add(e);
		try {
			if (Array.isArray(e)) {
				for (let t = 0; t < e.length; t++) if (!o(e[t], r)) return !1;
			} else {
				let t = e, i = Object.keys(t).filter((e) => t[e] !== void 0).sort();
				for (let e of i) if (!o(t[e], r)) return !1;
				n.set(e, i);
			}
			return t.add(e), !0;
		} finally {
			r.delete(e);
		}
	}
	function c(e, t) {
		if (e === t) return !0;
		if (e === null || t === null || typeof e != "object" || typeof t != "object" || Array.isArray(e) !== Array.isArray(t)) return !1;
		if (r.get(e)?.has(t)) return !0;
		if (Array.isArray(e)) {
			let n = t;
			if (e.length !== n.length) return !1;
			for (let t = 0; t < e.length; t++) if (!c(e[t], n[t])) return !1;
		} else {
			let r = n.get(e), i = n.get(t);
			if (r.length !== i.length) return !1;
			for (let n = 0; n < r.length; n++) {
				let a = r[n];
				if (a !== i[n] || !c(e[a], t[a])) return !1;
			}
		}
		let o = Array.isArray(e);
		if (o ? e.length >= 32 && a < 128 : Object.hasOwn(e, "id") && Object.hasOwn(e, "projectId") && i < 65408) {
			let n = r.get(e);
			n || (n = /* @__PURE__ */ new WeakSet(), r.set(e, n)), n.add(t), o ? a++ : i++;
		}
		return !0;
	}
	return (s, l) => e ? P(s, l) : !o(s, /* @__PURE__ */ new Set()) || !o(l, /* @__PURE__ */ new Set()) ? (e = !0, t = /* @__PURE__ */ new WeakSet(), n = /* @__PURE__ */ new WeakMap(), r = /* @__PURE__ */ new WeakMap(), i = 0, a = 0, P(s, l)) : c(s, l);
}
function mi(e, t) {
	let n = fi(e, t) ? pi() : P, r = new Map(e.history.map((e) => [e.operationId, e]));
	for (let e of t?.pending ?? []) {
		let t = r.get(e.operationId);
		if (t && !n(t, e.command)) throw new s("OPERATION_CONFLICT", "送信待ちの内容が保存履歴と一致しません。", e.operationId);
		r.set(e.operationId, e.command);
	}
	return {
		...e,
		history: [...r.values()]
	};
}
function hi(e) {
	return gi(e, ci());
}
function gi(e, t) {
	let n = Dn({ worldSnapshots: e });
	return {
		...n,
		recovery: (r, i, a) => vi(r, i, e, a, n, !1, t),
		recoveryForInspection: (r, i, a) => vi(r, i, e, a, n, !0, t)
	};
}
async function _i(e, t, n, r) {
	return vi(e, t, n, r);
}
async function vi(e, t, n, r, i, a = !1, c) {
	let l = (e, t = "data/recovery.json") => {
		throw new s("VALIDATION_FAILED", e, t);
	};
	if (!e || typeof e != "object" || Array.isArray(e)) return l("送信待ち復元情報はオブジェクトです。");
	let u = e;
	if (Object.keys(u).some((e) => ![
		"version",
		"projectId",
		"sourceRevision",
		"serverRevision",
		"pending"
	].includes(e)) || u.version !== 1 || u.projectId !== t.projectId || u.sourceRevision !== t.revision || typeof u.serverRevision != "string" || !/^(0|[1-9]\d*)$/.test(u.serverRevision) || !Array.isArray(u.pending) || u.pending.length > 1e5) return l("送信待ち復元情報の版・作品・基底版・件数が不正です。");
	let d = x(e), f = d.captured ? d.value : structuredClone(e), p = /* @__PURE__ */ new Set(), m = Zr(), h = i ?? Dn({ worldSnapshots: n });
	for (let e of f.pending) {
		if (o(r), !e || typeof e != "object" || Object.keys(e).some((e) => ![
			"operationId",
			"command",
			"commandHash",
			"origin"
		].includes(e)) || !C.test(e.operationId) || p.has(e.operationId) || typeof e.commandHash != "string" || !/^[0-9a-f]{64}$/.test(e.commandHash)) return l("送信待ちの操作IDまたはhashが不正・重複しています。");
		if ("origin" in e && (!e.origin || typeof e.origin != "object" || Array.isArray(e.origin) || Object.keys(e.origin).some((e) => ![
			"projectId",
			"operationId",
			"serverRevision"
		].includes(e)) || !C.test(e.origin.projectId) || !C.test(e.origin.operationId) || !/^(0|[1-9]\d*)$/.test(e.origin.serverRevision))) return l("送信待ちの元操作の記録が不正です。");
		if (p.add(e.operationId), !e.command || e.command.operationId !== e.operationId || e.command.projectId !== t.projectId || (c ? await c(e.command) : await D(m(e.command))) !== e.commandHash) return l("送信待ち操作の内容が固定したhashと一致しません。");
		let n = {
			...e.command.after,
			history: [e.command]
		}, i = h.validate(n);
		if (!i.ok) return l(i.issues.map((e) => `${e.path}: ${e.message}`).join("\n"));
		for (let t of li({
			...f,
			pending: [e]
		})) {
			let e = await h.integrity(t, !1);
			if (e.length) return l(e.map((e) => e.message).join("\n"));
		}
	}
	return mi(t, f), a ? f : structuredClone(f);
}
//#endregion
//#region src/domain/production.ts
function yi(e) {
	return typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? "[" + e.map(yi).join(",") + "]" : "{" + Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e < t ? -1 : +(e > t)).map(([e, t]) => JSON.stringify(e) + ":" + yi(t)).join(",") + "}";
}
async function bi(e, t) {
	let n = (t.data.cueIds ?? []).map((t) => e.entities.find((e) => e.id === t && e.kind === "cue" && !e.deletedAt));
	if (n.some((e) => !e)) throw Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
	let r = {
		text: t.data.text.map((e) => ({
			kind: e.kind,
			text: e.text,
			ruby: e.ruby ?? []
		})),
		speakerId: t.data.speakerId ?? null,
		cues: n.map((e) => e.data)
	}, i = new TextEncoder().encode(yi(r));
	return [...new Uint8Array(await crypto.subtle.digest("SHA-256", i))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
async function xi(e, t) {
	let n = new Map(e.entities.map((e) => [e.id, e])), r = new Map(t.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	for (let [e, t] of r) {
		let r = n.get(e);
		r !== t && (!r || !!r.deletedAt != !!t.deletedAt || yi(r.data) !== yi(t.data)) && a.add(e);
	}
	for (let e of n.keys()) r.has(e) || a.add(e);
	let o = (e, t) => yi({
		text: e.data.text.map((e) => ({
			kind: e.kind,
			text: e.text,
			ruby: e.ruby ?? []
		})),
		speakerId: e.data.speakerId ?? null,
		cues: (e.data.cueIds ?? []).map((e) => {
			let n = t.get(e);
			if (!n || n.kind !== "cue" || n.deletedAt) throw Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
			return n.data;
		})
	});
	for (let e of t.entities) {
		if (e.kind !== "dialogue_line" || e.deletedAt) continue;
		let t = n.get(e.id);
		(!t || t.kind !== "dialogue_line" || t.deletedAt || ["rejected", "alternate"].includes(t.status) !== ["rejected", "alternate"].includes(e.status) || (a.has(e.id) || (e.data.cueIds ?? []).some((e) => a.has(e))) && o(t, n) !== o(e, r)) && i.add(e.id);
	}
	for (let t of e.entities) if (t.kind === "dialogue_line" && !t.deletedAt) {
		let e = r.get(t.id);
		(!e || e.deletedAt || e.kind !== "dialogue_line") && i.add(t.id);
	}
	let s = /* @__PURE__ */ new Set();
	for (let e of t.entities) if (!e.deletedAt && (e.kind === "localization" || e.kind === "recording") && ["reviewed", "recorded"].includes(e.data.stage ?? "") && !i.has(e.data.sourceLineId) && a.has(e.id)) {
		let n = r.get(e.data.sourceLineId);
		(!n || n.kind !== "dialogue_line" || n.deletedAt || ["rejected", "alternate"].includes(n.status) || e.data.sourceHash !== await bi(t, n)) && s.add(e.id);
	}
	if (!a.size && !i.size && !s.size) return t;
	let c = t.entities.map((e) => e.deletedAt ? e : (e.kind === "localization" || e.kind === "recording") && (i.has(e.data.sourceLineId) || s.has(e.id)) && e.data.stage !== "needs_review" ? {
		...e,
		data: {
			...e.data,
			stage: "needs_review"
		}
	} : e.kind === "media_variant" && (e.data.sourceIds ?? []).some((e) => a.has(e)) && !e.data.needsReview ? {
		...e,
		data: {
			...e.data,
			needsReview: !0
		}
	} : e), l = (e, n) => {
		let r = e;
		for (let i of n.split(/[.\[\]]+/).filter(Boolean)) if (r && typeof r == "object") {
			let n = r, a = n.sourceVersionId ?? n.targetSnapshotId ?? (e.kind === "trace" || e.kind === "checkpoint" ? n.contentVersionId : void 0);
			if (typeof a == "string" && a !== t.projectId) return !1;
			r = n[i];
		} else return !0;
		return !0;
	}, u = /* @__PURE__ */ new Map();
	for (let e of c) if (!e.deletedAt && !["rejected", "alternate"].includes(e.status)) {
		for (let t of be(e)) if (!t.path.startsWith("data.lineage") && !t.path.startsWith("data.originLineIds") && l(e, t.path)) {
			let n = u.get(t.id);
			n ? n.push(e.id) : u.set(t.id, [e.id]);
		}
	}
	let d = new Set(a), f = /* @__PURE__ */ new Set(), p = [...d];
	for (let e = 0; e < p.length; e++) for (let t of u.get(p[e]) ?? []) f.add(t), d.has(t) || (d.add(t), p.push(t));
	return {
		...t,
		entities: c.map((e) => !d.has(e.id) || e.deletedAt || ["rejected", "alternate"].includes(e.status) ? e : e.kind === "storyboard_frame" && n.has(e.id) ? {
			...e,
			status: "needs_review"
		} : e.kind === "media_variant" && n.has(e.id) ? {
			...e,
			data: {
				...e.data,
				needsReview: !0
			}
		} : e.kind === "production_task" && n.has(e.id) && f.has(e.id) && e.data.progress === "done" ? {
			...e,
			data: {
				...e.data,
				progress: "needs_review"
			}
		} : e)
	};
}
//#endregion
//#region src/storage/importMapping.ts
var Si = /* @__PURE__ */ "id.kind.text.audienceHolderIds.eventKey.x.y.instanceId.quantity.consumed.sourceVersionId.profileId.publicVersionId.mode.publicId.ownerId.projectId.entities.relations.views.authorAlternatives.snapshots.history.operationId.deletionOperationId.data.versions.applyReceipts.baseContent.content.before.after.pending.command".split("."), X = Object.getOwnPropertyDescriptor, Ci = Object.getPrototypeOf, wi = Object.hasOwn, Ti = X(Array.prototype, "forEach"), Ei = X(Array.prototype, Symbol.iterator), Di = X(Array.prototype, "map"), Oi = X(Array.prototype, "every"), ki = X(Object, "entries"), Ai = X(Object, "values"), ji = X(Object, "hasOwn"), Mi = X(Object, "getPrototypeOf"), Ni = X(Array, "isArray"), Pi = X(Reflect, "ownKeys"), Fi = Map, Ii = Map.prototype, Li = X(Map.prototype, "has"), Ri = X(Map.prototype, "get"), zi = X(Map.prototype, "set"), Bi = X(Map.prototype, "values"), Vi = Set, Hi = Set.prototype, Ui = X(Set.prototype, "add"), Wi = WeakMap, Gi = WeakMap.prototype, Ki = X(WeakMap.prototype, "get"), qi = X(WeakMap.prototype, "set"), Ji = Ci((/* @__PURE__ */ new Map()).values()), Yi = X(Ji, "next"), Xi = Ci(Ji), Zi = X(Xi, Symbol.iterator), Qi = 1e5;
function $i(e, t, n) {
	let r = X(e, t);
	return !!n && wi(n, "value") && typeof n.value == "function" && !!r && wi(r, "value") && r.value === n.value && r.enumerable === n.enumerable && r.configurable === n.configurable && r.writable === n.writable;
}
function ea() {
	for (let e = 0; e < Si.length; e++) {
		let t = Si[e];
		if (X(Object.prototype, t) !== void 0 || X(Array.prototype, t) !== void 0) return !1;
	}
	return X(Object.prototype, Symbol.iterator) !== void 0 || Map !== Fi || Map.prototype !== Ii || Set !== Vi || Set.prototype !== Hi || WeakMap !== Wi || WeakMap.prototype !== Gi || Ci(Object.prototype) !== null || Ci(Array.prototype) !== Object.prototype || Ci(Ii) !== Object.prototype || Ci(Hi) !== Object.prototype || Ci(Gi) !== Object.prototype || Ci(Xi) !== Object.prototype ? !1 : $i(Array.prototype, "forEach", Ti) && $i(Array.prototype, Symbol.iterator, Ei) && $i(Array.prototype, "map", Di) && $i(Array.prototype, "every", Oi) && $i(Object, "entries", ki) && $i(Object, "values", Ai) && $i(Object, "hasOwn", ji) && $i(Object, "getPrototypeOf", Mi) && $i(Array, "isArray", Ni) && $i(Reflect, "ownKeys", Pi) && $i(Ii, "has", Li) && $i(Ii, "get", Ri) && $i(Ii, "set", zi) && $i(Ii, "values", Bi) && $i(Hi, "add", Ui) && $i(Gi, "get", Ki) && $i(Gi, "set", qi) && $i(Ji, "next", Yi) && X(Ji, Symbol.iterator) === void 0 && Ci(Ji) === Xi && $i(Xi, Symbol.iterator, Zi);
}
function ta(e, n) {
	let r = /* @__PURE__ */ new Map(), i = [], a = [], o = /* @__PURE__ */ new Set(), c, l = 0, u = !1;
	if (n) try {
		u = ea() && S(e), u && (c = /* @__PURE__ */ new WeakMap());
	} catch {
		u = !1, c = void 0;
	}
	let d = (e, t, n) => {
		let i = r.get(e);
		if (i && (i.role !== t || i.ownerId !== n)) throw new s("IMPORT_CONFLICT", "同じIDが別の種別・所有者で使われています。", e);
		r.set(e, {
			id: e,
			role: t,
			...n ? { ownerId: n } : {}
		});
	}, f = (e, n, r = !1) => {
		if (Array.isArray(e)) {
			e.forEach((e) => f(e, n, r));
			return;
		}
		if (!e || typeof e != "object") return;
		let c = e;
		if (typeof c.id == "string") {
			let e = "kind" in c && "text" in c ? "block" : "audienceHolderIds" in c ? "alias" : "eventKey" in c ? "trigger" : "x" in c && "y" in c ? "map_pin" : (() => {
				throw new s("IMPORT_CONFLICT", "未対応の埋込IDです。", c.id);
			})();
			r && e === "block" ? a.push({
				id: c.id,
				ownerId: n
			}) : d(c.id, e, n);
		}
		typeof c.instanceId == "string" && "quantity" in c && "consumed" in c && o.add(c.instanceId), typeof c.sourceVersionId == "string" && typeof c.profileId == "string" && typeof c.publicVersionId == "string" && d(c.publicVersionId, "public_id"), c.mode === "anonymize" && typeof c.publicId == "string" && d(c.publicId, "public_id");
		for (let [e, a] of Object.entries(c)) {
			if (e === "publicIds" && a && typeof a == "object") for (let e of Object.values(a)) typeof e == "string" && d(e, "public_id");
			if (e === "bindings" && a && typeof a == "object" && !Array.isArray(a)) for (let e of Object.values(a)) typeof e == "string" && i.push({
				id: e,
				ownerId: n
			});
			f(a, n, r || t(e));
		}
	}, p = (e, t) => {
		if (!u || !c || !e || typeof e != "object" || typeof t != "string" || !C.test(t)) {
			f(e, t);
			return;
		}
		let n = c.get(e);
		if (n !== void 0) {
			if (n === t) return;
			f(e, t);
			return;
		}
		if (l >= Qi) {
			f(e, t);
			return;
		}
		f(e, t), c.set(e, t), l++;
	}, m = (e) => {
		d(e.projectId, "project");
		for (let t of e.entities) d(t.id, t.kind === "snapshot" ? "snapshot" : `entity:${t.kind}`), t.deletionOperationId && d(t.deletionOperationId, "operation"), p(t.data, t.id);
		for (let t of e.relations) d(t.id, "relation"), t.deletionOperationId && d(t.deletionOperationId, "operation");
		for (let t of e.views) d(t.id, "view");
		if ("authorAlternatives" in e && Array.isArray(e.authorAlternatives)) for (let t of e.authorAlternatives) {
			d(t.id, "alternative", t.projectId);
			for (let e of t.versions) d(e.id, "alternative_version", t.id);
			for (let e of t.applyReceipts) d(e.id, "alternative_receipt", t.id);
			m(t.baseContent);
			for (let e of t.versions) m(e.content);
		}
		if ("snapshots" in e) for (let t of e.snapshots) d(t.id, "snapshot"), m(t.content);
	};
	m(e);
	for (let t of e.history) d(t.operationId, "operation"), m(t.before), m(t.after);
	let h = new Set([...r.values()].filter((e) => e.role === "block").map((e) => e.id));
	for (let e of a) h.has(e.id) || d(e.id, "block", e.ownerId);
	for (let e of o) r.get(e)?.role !== "entity:item" && d(e, "runtime_item");
	for (let e of i) r.has(e.id) || d(e.id, "reuse_binding", e.ownerId);
	return [...r.values()];
}
function na(e) {
	return ta(e, !1);
}
function ra() {
	if (ea()) return (e) => ta(e, !0);
}
function ia(e) {
	return Object.assign(new s("VALIDATION_FAILED", e.map((e) => `${e.path}: ${e.message}`).join("\n"), e[0]?.path), { issues: e });
}
function aa(e, t, n) {
	if (e.projectId === t.projectId) throw new s("IMPORT_CONFLICT", "同じ作品はIDを維持して統合してください。");
	let r = new Map(na(e).map((e) => [e.id, e])), i = new Map(na(t).map((e) => [e.id, e])), a = {}, o = /* @__PURE__ */ new Set();
	for (let e of Object.keys(n)) if (!r.has(e)) throw new s("IMPORT_CONFLICT", "対応表に作品外・未知のIDがあります。固定世界のIDは変更できません。", e);
	for (let [e, t] of r) {
		let r = Object.hasOwn(n, e) ? n[e] : void 0;
		if (!r || !C.test(r)) throw new s("IMPORT_CONFLICT", "全ローカルIDの明示対応が必要です。", e);
		if (o.has(r)) throw new s("IMPORT_CONFLICT", "複数の元IDを同じIDへ統合できません。対応を一対一にしてください。", e);
		o.add(r), a[e] = r;
		let c = i.get(r);
		if (c && c.role !== t.role) throw new s("IMPORT_CONFLICT", "対応先の種別が異なります。", e);
		if (c && (t.role === "operation" || t.role === "snapshot")) throw new s(t.role === "snapshot" ? "IMMUTABLE_SNAPSHOT" : "OPERATION_CONFLICT", "復元履歴・不変版は既存IDを上書きできません。新しい対応IDを選んでください。", e);
	}
	if (a[e.projectId] !== t.projectId) throw new s("IMPORT_CONFLICT", "元projectIdの対応先を対象作品にしてください。", e.projectId);
	for (let [e, t] of r) {
		let n = i.get(a[e]);
		if (t.ownerId && n?.ownerId && a[t.ownerId] !== n.ownerId) throw new s("IMPORT_CONFLICT", "段落・別名などの対応先が対応した所有者に属していません。", e);
	}
	return a;
}
function oa(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => oa(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	if (typeof n.id == "string" && (n.id = t[n.id] ?? n.id), typeof n.instanceId == "string" && "quantity" in n && "consumed" in n && (n.instanceId = t[n.instanceId] ?? n.instanceId), n.mode === "anonymize" && typeof n.publicId == "string" && (n.publicId = t[n.publicId] ?? n.publicId), n.publicIds && typeof n.publicIds == "object") for (let [e, r] of Object.entries(n.publicIds)) typeof r == "string" && (n.publicIds[e] = t[r] ?? r);
	Array.isArray(n.onceTriggers) && (n.onceTriggers = n.onceTriggers.map((e) => typeof e == "string" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, (e) => t[e] ?? e) : e));
	for (let e of Object.values(n)) oa(e, t);
}
function sa(e, t) {
	let n = d(e, t);
	for (let t of be(e)) if (t.scope === "identity" || t.scope === "calendar") {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean), r = e.pop();
		if (r === "$key") throw new s("IMPORT_CONFLICT", "外部参照をkeyにした未知の辞書は対応表で変換できません。", t.path);
		let i = n;
		for (let t of e) i = i[t];
		i[r] = t.id;
	}
	return n;
}
function ca(e, t, n = "", r) {
	let i = (e) => t[e] ?? e;
	if (typeof e == "string") return n === "onceTriggers" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, i) : n === "id" || n === "operationId" || /(?:Id|Ids)$/.test(n) || n === "value" && r?.type === "ref" ? i(e) : e;
	if (Array.isArray(e)) return e.map((e) => ca(e, t, n, r));
	if (!e || typeof e != "object") return e;
	let a = e;
	if ("kind" in a && "data" in a && "projectId" in a) {
		let e = sa(a, t);
		return oa(e.data, t), e;
	}
	if ("relationType" in a && "fromId" in a && "toId" in a) return f(a, t);
	let o = [
		"variableValues",
		"visitCounts",
		"publicTexts",
		"publicIds",
		"byEntityId"
	].includes(n);
	return Object.fromEntries(Object.entries(a).map(([e, n]) => [o ? i(e) : e, ca(n, t, e, a)]));
}
function la(e, t) {
	return t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
}
function ua(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	if (t.length) {
		let e = t[t.length - 1];
		n === void 0 ? delete i[e] : i[e] = structuredClone(n);
	}
	return r;
}
function da(e, t, n, r, i) {
	if (t.scope === "presentation" && e && typeof e == "object" && !Array.isArray(e)) {
		let t = structuredClone(e), n = (e) => typeof e == "string" ? i[e] ?? e : e;
		return Array.isArray(t.chapterOrder) && (t.chapterOrder = t.chapterOrder.map(n)), Array.isArray(t.chapters) && (t.chapters = t.chapters.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = e;
			return {
				...t,
				id: n(t.id),
				sceneIds: Array.isArray(t.sceneIds) ? t.sceneIds.map(n) : t.sceneIds
			};
		})), Array.isArray(t.scenes) && (t.scenes = t.scenes.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = e;
			return {
				...t,
				id: n(t.id),
				chapterId: n(t.chapterId)
			};
		})), t;
	}
	if (t.scope === "entity" && t.itemId) {
		let a = r.entities.find((e) => e.id === t.itemId) ?? n.baseContent.entities.find((e) => e.id === t.itemId);
		if (t.path.length === 0 && e && typeof e == "object" && "kind" in e && "data" in e) {
			let t = sa(e, i);
			return oa(t.data, i), t;
		}
		if (a && t.path.length) {
			let n = sa(ua(a, t.path, e), i);
			return oa(n.data, i), la(n, t.path);
		}
	}
	if (t.scope === "relation" && t.itemId) {
		let a = r.relations.find((e) => e.id === t.itemId) ?? n.baseContent.relations.find((e) => e.id === t.itemId);
		if (t.path.length === 0 && e && typeof e == "object" && "relationType" in e) return f(e, i);
		if (a && t.path.length) return la(f(ua(a, t.path, e), i), t.path);
	}
	return t.scope === "project" && t.path[0] === "worldReferences" ? structuredClone(e) : t.scope === "project" && t.path.length === 1 && t.path[0] === "calendarId" && typeof e == "string" ? i[e] ?? e : t.scope === "project" && t.path.length === 1 && t.path[0] === "calendars" && Array.isArray(e) ? e.map((e) => e && typeof e == "object" ? {
		...e,
		id: typeof e.id == "string" ? i[e.id] ?? e.id : e.id
	} : e) : ca(e, i, t.path.at(-1) ?? "");
}
function fa(e, t) {
	return {
		...structuredClone(e),
		chapterId: t(e.chapterId),
		templateId: t(e.templateId),
		assignments: Object.fromEntries(Object.entries(e.assignments).map(([e, n]) => [e, t(n)]))
	};
}
async function pa(e, t, n, r) {
	let i = (e) => n[e] ?? e, a = async (t) => {
		o(r);
		let s = structuredClone(t);
		s.projectId = i(t.projectId), s.entities = t.entities.map((e) => {
			let t = sa(e, n);
			return t.id = i(e.id), t.projectId = i(e.projectId), oa(t.data, n), t.deletionOperationId &&= i(t.deletionOperationId), t;
		}), s.relations = t.relations.map((e) => ({
			...f(e, n),
			id: i(e.id),
			projectId: i(e.projectId),
			...e.deletionOperationId ? { deletionOperationId: i(e.deletionOperationId) } : {}
		})), s.views = t.views.map((e) => ({
			...structuredClone(e),
			id: i(e.id),
			entityIds: e.entityIds.map(i)
		}));
		for (let n = 0; n < t.entities.length; n++) {
			let r = t.entities[n], i = s.entities[n];
			if ((r.kind === "localization" || r.kind === "recording") && (i.kind === "localization" || i.kind === "recording")) {
				let n = t.entities.find((e) => e.kind === "dialogue_line" && e.id === r.data.sourceLineId), a = s.entities.find((e) => e.kind === "dialogue_line" && e.id === i.data.sourceLineId);
				n && a && r.data.sourceHash === await bi({
					...e,
					...t
				}, n) && (i.data.sourceHash = await bi({
					...e,
					...s
				}, a));
			}
		}
		let c = "authorAlternatives" in t ? t.authorAlternatives : void 0;
		return Array.isArray(c) && (s.authorAlternatives = await Promise.all(c.map(async (e) => {
			let t = structuredClone(e);
			return t.id = i(e.id), t.projectId = i(e.projectId), t.sourceSnapshotId = e.sourceSnapshotId ? i(e.sourceSnapshotId) : null, t.baseContent = await a(e.baseContent), t.versions = await Promise.all(e.versions.map(async (e) => ({
				...structuredClone(e),
				id: i(e.id),
				parentVersionId: e.parentVersionId ? i(e.parentVersionId) : null,
				content: await a(e.content),
				...e.structurePlan ? { structurePlan: fa(e.structurePlan, i) } : {}
			}))), t.headVersionId = i(e.headVersionId), t.applyReceipts = e.applyReceipts.map((t) => {
				let r = e.versions.find((e) => e.id === t.alternativeVersionId)?.content ?? e.baseContent, a = t.patches.map((t) => {
					let a = t.itemId ? i(t.itemId) : void 0, o = [...t.path], s = [
						t.scope,
						a ?? "",
						...o
					].map((e) => encodeURIComponent(e)).join(":");
					return {
						...structuredClone(t),
						key: s,
						...a ? { itemId: a } : {},
						path: o,
						before: {
							...structuredClone(t.before),
							...t.before.present ? { value: da(t.before.value, t, e, r, n) } : {}
						},
						after: {
							...structuredClone(t.after),
							...t.after.present ? { value: da(t.after.value, t, e, r, n) } : {}
						}
					};
				});
				return {
					...structuredClone(t),
					id: i(t.id),
					alternativeVersionId: t.alternativeVersionId ? i(t.alternativeVersionId) : void 0,
					sourceSnapshotId: t.sourceSnapshotId ? i(t.sourceSnapshotId) : null,
					patches: a,
					selectedChangeKeys: a.map((e) => e.key).sort()
				};
			}), t;
		}))), "snapshots" in s && "snapshots" in t && (s.snapshots = await Promise.all(t.snapshots.map(async (e) => ({
			...structuredClone(e),
			id: i(e.id),
			content: await a(e.content)
		})))), s;
	}, { history: c, ...l } = e, u = {
		...await a(l),
		history: await Promise.all(e.history.map(async (e) => ({
			...structuredClone(e),
			operationId: i(e.operationId),
			projectId: i(e.projectId),
			targetIds: e.targetIds.map(i),
			before: await a(e.before),
			after: await a(e.after),
			...e.compensatesOperationId ? { compensatesOperationId: i(e.compensatesOperationId) } : {},
			...e.importOrigin ? { importOrigin: {
				...e.importOrigin,
				importOperationId: i(e.importOrigin.importOperationId)
			} } : {},
			...e.idMap ? { idMap: Object.fromEntries(Object.entries(e.idMap).map(([e, t]) => [e, i(t)])) } : {}
		})))
	}, d = /* @__PURE__ */ new Map(), p = (e) => {
		let t = (n) => {
			if (e(n), "snapshots" in n) for (let e of n.snapshots) t(e.content);
			if ("authorAlternatives" in n && Array.isArray(n.authorAlternatives)) for (let e of n.authorAlternatives) {
				t(e.baseContent);
				for (let n of e.versions) t(n.content);
			}
		};
		t(u);
		for (let e of u.history) t(e.before), t(e.after);
	};
	p((e) => {
		if ("snapshots" in e) for (let t of e.snapshots) d.set(t.id, t);
	});
	let m = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new Set(), g = async (e) => {
		if (m.has(e.id)) return m.get(e.id);
		if (h.has(e.id)) throw new s("HASH_MISMATCH", "版の内容hashに循環参照があります。", e.id);
		h.add(e.id);
		for (let t of e.content.entities) t.kind === "snapshot" && d.has(t.id) && (t.data.contentHash = await g(d.get(t.id)));
		let t = await D(M(e.content));
		return m.set(e.id, t), h.delete(e.id), t;
	};
	for (let e of d.values()) await g(e);
	p((e) => {
		for (let t of e.entities) t.kind === "snapshot" && m.has(t.id) && (t.data.contentHash = m.get(t.id));
		if ("snapshots" in e) for (let t of e.snapshots) {
			t.contentHash = m.get(t.id);
			for (let e of t.content.entities) e.kind === "snapshot" && m.has(e.id) && (e.data.contentHash = m.get(e.id));
		}
	});
	let _ = async (e) => {
		"authorAlternatives" in e && Array.isArray(e.authorAlternatives) && (e.authorAlternatives = await Promise.all(e.authorAlternatives.map(ln)));
	};
	for (let e of [u, ...u.history.flatMap((e) => [e.before, e.after])]) await _(e);
	let v = new Map(t.entities.map((e) => [e.id, e]));
	return u.entities = u.entities.map((e) => v.has(e.id) ? {
		...e,
		createdAt: v.get(e.id).createdAt
	} : e), u;
}
var ma = [
	"name",
	"calendarId",
	"mainStart",
	"calendars",
	"worldReferences"
];
function ha(e, t, n) {
	let r = [], i = [], a = {
		...structuredClone({
			...e,
			history: []
		}),
		history: e.history
	};
	for (let o of ma) if (!P(e[o], t[o])) {
		let s = `project.${o}`;
		r.push({
			id: s,
			kind: "project",
			existing: e[o],
			incoming: t[o]
		});
		let c = n?.[s] === "incoming";
		c && (a[o] = structuredClone(t[o])), i.push({
			id: s,
			kind: "project",
			action: c ? "update" : "keep",
			fields: [o]
		});
	}
	for (let [o, s] of [
		["entities", "entity"],
		["relations", "relation"],
		["snapshots", "snapshot"],
		["views", "view"]
	]) {
		let c = new Map(e[o].map((e) => [e.id, e]));
		for (let e of t[o]) {
			let t = c.get(e.id), a = t && !P(t, e);
			a && r.push({
				id: e.id,
				kind: s,
				existing: t,
				incoming: e
			}), (!t || n?.[e.id] === "incoming") && c.set(e.id, structuredClone(e));
			let o = Object.keys(e).filter((n) => !t || !P(t[n] ?? null, e[n] ?? null));
			i.push({
				id: e.id,
				kind: s,
				action: t ? a && n?.[e.id] === "incoming" ? "update" : "keep" : "add",
				fields: o
			});
		}
		a[o] = [...c.values()];
	}
	let o = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e]));
	for (let e of t.authorAlternatives ?? []) {
		let t = o.get(e.id);
		if (t && !P(t, e)) {
			if (r.push({
				id: e.id,
				kind: "alternative",
				existing: t,
				incoming: e
			}), n?.[e.id] === "incoming") throw new s("IMPORT_CONFLICT", "保存済み作者別案のIDへ別の履歴を上書きできません。新しいIDへ対応してください。", e.id);
			i.push({
				id: e.id,
				kind: "alternative",
				action: "keep",
				fields: []
			});
		} else t ? i.push({
			id: e.id,
			kind: "alternative",
			action: "keep",
			fields: []
		}) : (o.set(e.id, structuredClone(e)), i.push({
			id: e.id,
			kind: "alternative",
			action: "add",
			fields: [
				"name",
				"baseContent",
				"versions",
				"applyReceipts"
			]
		}));
	}
	(o.size || "authorAlternatives" in e || "authorAlternatives" in t) && (a.authorAlternatives = [...o.values()]);
	let c = r.filter((e) => !n?.[e.id]).map((e) => e.id);
	for (let e of r) if (e.kind === "snapshot" && n?.[e.id] === "incoming") throw new s("IMMUTABLE_SNAPSHOT", "既存版を別の内容に置き換えられません。", e.id);
	return {
		conflicts: r,
		unresolved: c,
		changes: i,
		...c.length ? {} : { candidate: a }
	};
}
async function ga(e, t, n) {
	o(n.signal);
	let r = { ...n.knownWorlds ?? {} };
	for (let [t, n] of Object.entries(e.worlds)) {
		if (r[t] && !P(r[t], n)) throw new s("IMMUTABLE_SNAPSHOT", "固定世界IDと内容が衝突します。", t);
		r[t] = n;
	}
	let i = Na(r), a = u(e.project, { worldSnapshots: i });
	if (!a.ok) throw ia(a.issues);
	let l = u(t, { worldSnapshots: i });
	if (!l.ok) throw ia(l.issues);
	if (e.manifest.projectId !== e.project.projectId) throw new s("VALIDATION_FAILED", "manifestと作品のIDが一致しません。");
	Pa([
		e.project,
		t,
		...Object.values(r)
	], r), await Fa([
		e.project,
		t,
		...Object.values(r)
	]);
	for (let [e, t] of Object.entries(n.resolutions ?? {})) if (!["existing", "incoming"].includes(t)) throw new s("IMPORT_CONFLICT", "競合の採用方法が未対応です。", e);
	let d = aa(e.project, t, n.idMap), f = await pa(e.project, t, d, n.signal), p = u(f, { worldSnapshots: i });
	if (!p.ok) throw ia(p.issues);
	await Fa([f]);
	let m = /* @__PURE__ */ new Map();
	for (let t of [e.project, ...Object.values(e.worlds)]) for (let e of Oa(t)) {
		let t = m.get(e.contentHash);
		if (t && !P(t, e)) throw new s("ASSET_INVALID", "同じ素材hashのメタデータが一致しません。", e.assetPath);
		m.set(e.contentHash, e);
	}
	let h = /* @__PURE__ */ new Map();
	for (let t of e.assets) {
		o(n.signal);
		let e = m.get(t.contentHash);
		if (!e || e.assetPath !== t.path || e.mediaType !== t.mediaType) throw new s("ASSET_INVALID", "素材bytesの宣言と添付が一致しません。", t.path);
		if (Sa(t.path, t.mediaType, t.bytes), t.bytes.byteLength !== e.byteSize || await D(t.bytes) !== t.contentHash) throw new s("HASH_MISMATCH", "素材bytes・サイズ・hashが一致しません。", t.path);
		if (h.has(t.contentHash)) throw new s("ASSET_INVALID", "素材bytesが重複しています。", t.path);
		h.set(t.contentHash, t.bytes);
	}
	let g = [], _ = [];
	for (let [e, t] of m) if (!h.has(e)) {
		let r = await n.loadAsset?.(e);
		if (o(n.signal), !r) {
			_.push(e);
			continue;
		}
		if (Sa(t.assetPath, t.mediaType, r), r.byteLength !== t.byteSize || await D(r) !== e) throw new s("HASH_MISMATCH", "端末内の素材bytesが宣言と一致しません。", t.assetPath);
		g.push(e);
	}
	if (e.manifest.assetMode === "embedded" && _.length) throw new s("ASSET_MISSING", "完全復元に必要な素材が不足しています。", _[0]);
	let v = ha(t, f, n.resolutions), y = new Map(Object.entries(d).map(([e, t]) => [t, e]));
	for (let e of v.changes) y.has(e.id) && (e.sourceId = y.get(e.id));
	if (v.candidate) {
		let e = c(v.candidate, { worldSnapshots: i });
		if (!e.ok) throw ia(e.issues);
	}
	return o(n.signal), {
		sourceProjectId: e.project.projectId,
		targetProjectId: t.projectId,
		targetRevision: t.revision,
		sourceContentHash: await D(M(e.project)),
		idMap: d,
		mappedProject: f,
		...v,
		assets: {
			provided: [...h.keys()],
			reused: g,
			missing: _,
			byteSize: e.assets.reduce((e, t) => e + t.bytes.length, 0)
		},
		warnings: [...e.warnings]
	};
}
//#endregion
//#region src/storage/archiveData.ts
var _a = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/, va = /^[0-9a-f]{64}$/, ya = /^(?:manifest\.json|data\/(?:project|recovery|sync-recovery|records)\.json|worlds\/[0-9a-f-]{36}\.json|assets\/[0-9a-f]{64}\.[a-z0-9]{1,8})$/, ba = {
	"image/png": ["png"],
	"image/jpeg": ["jpg", "jpeg"],
	"image/gif": ["gif"],
	"image/webp": ["webp"],
	"audio/mpeg": ["mp3"],
	"audio/wav": ["wav"],
	"audio/x-wav": ["wav"],
	"audio/ogg": ["ogg"],
	"video/mp4": ["mp4"],
	"video/webm": ["webm"],
	"application/pdf": ["pdf"],
	"text/plain": ["txt"],
	"application/json": ["json"],
	"application/octet-stream": ["bin"]
};
function xa(e, t = "application/octet-stream") {
	let n = ba[t];
	if (!va.test(e) || !n) throw new s("ASSET_INVALID", "素材のhashまたは種類が未対応です。");
	return `assets/${e}.${n[0]}`;
}
function Sa(e, t, n) {
	re(e);
	let r = /^assets\/([0-9a-f]{64})\.([a-z0-9]{1,8})$/.exec(e);
	if (!r || !ba[t]?.includes(r[2])) throw new s("ASSET_INVALID", "素材パス・種類・拡張子が一致しません。", e);
	if (n) {
		let r = (e) => e.every((e, t) => n[t] === e), i = (e, t) => [...t].every((t, r) => n[e + r] === t.charCodeAt(0)), a = !0;
		switch (t) {
			case "image/png":
				a = r([
					137,
					80,
					78,
					71,
					13,
					10,
					26,
					10
				]);
				break;
			case "image/jpeg":
				a = r([
					255,
					216,
					255
				]);
				break;
			case "image/gif":
				a = i(0, "GIF87a") || i(0, "GIF89a");
				break;
			case "image/webp":
				a = i(0, "RIFF") && i(8, "WEBP");
				break;
			case "audio/mpeg":
				a = i(0, "ID3") || n[0] === 255 && (n[1] & 224) == 224;
				break;
			case "audio/wav":
			case "audio/x-wav":
				a = i(0, "RIFF") && i(8, "WAVE");
				break;
			case "audio/ogg":
				a = i(0, "OggS");
				break;
			case "video/mp4":
				a = i(4, "ftyp");
				break;
			case "video/webm":
				a = r([
					26,
					69,
					223,
					163
				]);
				break;
			case "application/pdf":
				a = i(0, "%PDF-");
				break;
			case "application/json":
				he(n, e);
				break;
			case "text/plain": try {
				new TextDecoder("utf-8", { fatal: !0 }).decode(n);
			} catch {
				a = !1;
			}
		}
		if (!a) throw new s("ASSET_INVALID", "素材bytesが宣言した種類と一致しません。", e);
	}
	return r[1];
}
Uint32Array.from({ length: 256 }, (e, t) => {
	let n = t;
	for (let e = 0; e < 8; e++) n = n & 1 ? n >>> 1 ^ 3988292384 : n >>> 1;
	return n >>> 0;
});
function Ca(e, t) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw new s("ARCHIVE_INVALID", "オブジェクトが必要です。", t);
	return e;
}
function wa(e) {
	let t = Ca(e, "manifest.json");
	if (t.format !== "scenario-package" || t.formatVersion !== "1.0.0") throw new s("FORMAT_UNSUPPORTED", "この専用形式の版には対応していません。元のファイルを保持してください。", "manifest.json");
	let n = typeof t.minimumReaderVersion == "string" && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(t.minimumReaderVersion) ? t.minimumReaderVersion.split(".").map(Number) : void 0;
	if (!n || n[0] > 1 || n[0] === 1 && (n[1] > 0 || n[2] > 0)) throw new s("FORMAT_UNSUPPORTED", "読み込みに新しいアプリが必要です。", "manifest.json/minimumReaderVersion");
	if (t.requiredFeatures !== void 0 && (!Array.isArray(t.requiredFeatures) || t.requiredFeatures.some((e) => ![
		"portable-recovery-v1",
		"native-sync-recovery-v1",
		"shared-review-source-v1",
		"shared-records-v1",
		"shared-record-deltas-v1",
		"shared-calendar-records-v1"
	].includes(e)))) throw new s("FORMAT_UNSUPPORTED", "未知の必須機能が宣言されています。", "manifest.json/requiredFeatures");
	if (typeof t.projectId != "string" || !_a.test(t.projectId) || typeof t.snapshotId != "string" || !_a.test(t.snapshotId) || typeof t.exportedAt != "string" || !Number.isFinite(Date.parse(t.exportedAt)) || !t.exportedAt.endsWith("Z") || !["embedded", "metadata_only"].includes(t.assetMode) || !Array.isArray(t.files)) throw new s("ARCHIVE_INVALID", "manifestの必須項目が不正です。", "manifest.json");
	let r = /* @__PURE__ */ new Set();
	for (let [e, n] of t.files.entries()) {
		let t = Ca(n, `manifest.json/files/${e}`);
		if (typeof t.path != "string") throw new s("ARCHIVE_INVALID", "manifestのpathが不正です。", `manifest.json/files/${e}`);
		if (re(t.path), t.path === "manifest.json" || !ya.test(t.path) || r.has(t.path) || !Number.isSafeInteger(t.byteSize) || t.byteSize < 0 || typeof t.sha256 != "string" || !va.test(t.sha256) || t.role !== (t.path === "data/project.json" ? "project" : t.path === "data/recovery.json" ? "recovery" : t.path === "data/sync-recovery.json" ? "sync_recovery" : t.path === "data/records.json" ? "record_dictionary" : t.path.startsWith("worlds/") ? "world" : "asset")) throw new s("ARCHIVE_INVALID", "manifestのファイル宣言が不正または重複しています。", t.path);
		r.add(t.path);
	}
	return t;
}
function Ta(e, t, n, r = {}, i) {
	let a;
	try {
		a = i ? i.validate(e) : u(e, { worldSnapshots: r });
	} catch (e) {
		throw new s("VALIDATION_FAILED", "共通世界または作品の構造が不正です。", t, { cause: e });
	}
	if (!a.ok) throw new s("VALIDATION_FAILED", a.issues.map((e) => `${e.path}: ${e.message}`).join("\n"), t);
	let o = a.value;
	if (o.entities.length + o.relations.length > n.records) throw new s("LIMIT_EXCEEDED", "entityとrelationの件数が上限を超えています。", t);
	return Da(o, t, n), o;
}
async function Ea(e, t, n = {}, r) {
	let i = r ? await r.integrity(e, !0) : await En(e, { worldSnapshots: n }, !0);
	if (i.length) throw new s("VALIDATION_FAILED", i.map((e) => `${e.path}: ${e.message}`).join("\n"), t);
}
function Da(e, t, n, r = /* @__PURE__ */ new WeakSet()) {
	let i = typeof e == "object" && !!e && S(e);
	if (!(i && r.has(e))) {
		if (typeof e == "string") {
			if (new TextEncoder().encode(e).byteLength > n.fieldBytes) throw new s("LIMIT_EXCEEDED", "本文フィールドが1 MiBの上限を超えています。", t);
		} else if (Array.isArray(e)) e.forEach((e, i) => Da(e, `${t}/${i}`, n, r));
		else if (e && typeof e == "object") for (let [i, a] of Object.entries(e)) Da(a, `${t}/${i}`, n, r);
		i && r.add(e);
	}
}
function Oa(e) {
	return ka([e]);
}
function ka(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new WeakSet(), r = n;
	function i(e) {
		if (e && typeof e == "object") {
			if (r.has(e)) return;
			r.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(i);
			return;
		}
		if (!e || typeof e != "object") return;
		let n = e;
		if (n.kind === "attachment") {
			let e = Ca(n.data, "attachment/data"), r = Sa(e.assetPath, e.mediaType);
			if (r !== e.contentHash || !Number.isSafeInteger(e.byteSize) || e.byteSize < 0) throw new s("ASSET_INVALID", "素材のhashまたはサイズが不正です。", e.assetPath);
			let i = t.get(r);
			if (i && (i.assetPath !== e.assetPath || i.byteSize !== e.byteSize || i.mediaType !== e.mediaType)) throw new s("ASSET_INVALID", "同じhashの素材に異なるメタデータがあります。", e.assetPath);
			t.set(r, e);
		}
		for (let e of Object.keys(n)) {
			let t = n[e];
			t && typeof t == "object" && i(t);
		}
	}
	for (let t of e) r = S(t) ? n : /* @__PURE__ */ new WeakSet(), i(t);
	return [...t.values()];
}
function Aa(e) {
	return ka(e);
}
function ja(e, t = {}) {
	let n = {}, r = [e];
	for (; r.length;) for (let e of Ma(r.splice(0), t)) {
		let i = e.immutableSnapshotId;
		if (n[i]) continue;
		let a = t[i], o = a?.snapshots.find((e) => e.id === i);
		if (!a || a.projectId !== e.projectId || o?.contentHash !== e.contentHash) throw new s("ASSET_MISSING", "素材の固定世界依存が不足または不一致です。", i);
		if (n[i] = a, Object.keys(n).length > N.records) throw new s("LIMIT_EXCEEDED", "固定世界の依存上限を超えています。");
		r.push(a);
	}
	return Aa([e, ...Object.values(n)]);
}
function Ma(e, t = {}) {
	let n = /* @__PURE__ */ new Map();
	for (let e of Object.values(t)) for (let t of e.snapshots) {
		let r = n.get(t.id);
		if (r && r.reference.contentHash !== t.contentHash) throw new s("IMMUTABLE_SNAPSHOT", "固定世界の期待hashが同じIDで異なります。", t.id);
		n.set(t.id, {
			world: e,
			reference: {
				projectId: e.projectId,
				immutableSnapshotId: t.id,
				contentHash: t.contentHash
			}
		});
	}
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new WeakSet();
	function a(e) {
		if (e && typeof e == "object") {
			if (i.has(e)) return;
			i.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(a);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		if (Array.isArray(t.worldReferences)) for (let e of t.worldReferences) {
			let t = r.get(e.immutableSnapshotId);
			if (t && (t.projectId !== e.projectId || t.contentHash !== e.contentHash)) throw new s("VALIDATION_FAILED", "同じ共通世界snapshot IDの参照内容が一致しません。", e.immutableSnapshotId);
			r.set(e.immutableSnapshotId, e);
		}
		let o = n.size ? typeof t.kind == "string" && O.includes(t.kind) && typeof t.projectId == "string" && t.data && typeof t.data == "object" ? be(t) : typeof t.relationType == "string" && typeof t.projectId == "string" && typeof t.fromId == "string" && typeof t.toId == "string" ? g(t) : [] : [];
		for (let e of o) if (e.scope === "snapshot") {
			let i = n.get(e.id);
			if (i && i.world.projectId !== t.projectId) {
				let t = r.get(e.id);
				if (t && t.contentHash !== i.reference.contentHash) throw new s("IMMUTABLE_SNAPSHOT", "引用世界の期待hashが採用版と異なります。", e.id);
				r.set(e.id, i.reference);
			}
		}
		for (let e of Object.keys(t)) {
			let n = t[e];
			n && typeof n == "object" && a(n);
		}
	}
	return e.forEach(a), [...r.values()];
}
function Na(e) {
	let t = Object.create(null);
	for (let [n, r] of Object.entries(e)) {
		if (!r || typeof r != "object" || !Array.isArray(r.snapshots)) continue;
		let e = r.snapshots.find((e) => e && e.id === n);
		if (e?.content && typeof e.content == "object" && Array.isArray(e.content.entities) && Array.isArray(e.content.relations) && Array.isArray(e.content.calendars)) {
			if (t[n] && !P(t[n], e.content)) throw new s("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", n);
			t[n] = e.content;
			for (let e of r.snapshots) if (e?.content?.projectId === r.projectId) {
				if (t[e.id] && !P(t[e.id], e.content)) throw new s("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", e.id);
				t[e.id] = e.content;
			}
		}
	}
	return t;
}
function Pa(e, t) {
	for (let [e, n] of Object.entries(t)) if (!n.snapshots.some((t) => t.id === e)) throw new s("VALIDATION_FAILED", "共通世界ファイルに指定した不変snapshotがありません。", `worlds/${e}.json`);
	for (let n of Ma(e)) {
		let e = t[n.immutableSnapshotId], r = e?.snapshots.find((e) => e.id === n.immutableSnapshotId);
		if (!e || e.projectId !== n.projectId || !r || r.contentHash !== n.contentHash) throw new s("VALIDATION_FAILED", "参照した共通世界の不変snapshotが不足または不一致です。", `worlds/${n.immutableSnapshotId}.json`);
	}
}
async function Fa(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new WeakSet();
	function r(e) {
		if (e && typeof e == "object" && S(e)) {
			if (n.has(e)) return;
			n.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(r);
			return;
		}
		if (!e || typeof e != "object") return;
		let i = e;
		if (Array.isArray(i.snapshots)) for (let e of i.snapshots) {
			let n = t.get(e.id);
			if (n && !P(n, e)) throw new s("IMMUTABLE_SNAPSHOT", "同じ不変snapshot IDに異なる内容があります。", e.id);
			t.set(e.id, e);
		}
		for (let e of Object.keys(i)) {
			let t = i[e];
			t && typeof t == "object" && r(t);
		}
	}
	e.forEach(r);
	for (let e of t.values()) if (await D(M(e.content)) !== e.contentHash) throw new s("HASH_MISMATCH", "不変snapshotの内容hashが一致しません。", `snapshots/${e.id}`);
}
async function Ia(e, t = {}) {
	t = { ...t }, o(t.signal);
	let n = x({
		input: e,
		worlds: t.worlds ?? {},
		recovery: t.recovery,
		syncRecovery: t.syncRecovery
	});
	e = n.value.input, t.onProgress?.({
		stage: "validating",
		completed: 0,
		total: 1
	});
	let r = n.value.worlds, i = Na(r), a = hi(i), c = Ta(e, "data/project.json", N, i, a), u = t.snapshotId ? c.snapshots.find((e) => e.id === t.snapshotId) : void 0;
	if (u) {
		let { history: e, snapshots: n, authorAlternatives: r, ...i } = c;
		if (!P(i, u.content)) throw new s("OPERATION_CONFLICT", "指定した版と書き出す内容が一致しません。対象snapshotの内容を選び直してください。", t.snapshotId);
	}
	Pa([c, ...Object.values(r)], r), await Fa([c, ...Object.values(r)]), await Ea(c, "data/project.json", i, a);
	for (let [e, t] of Object.entries(r)) await Ea(t, `worlds/${e}.json`, i, a);
	let d = [c, ...Object.values(r)].reduce((e, t) => e + t.entities.length + t.relations.length, 0);
	if (d > N.records) throw new s("LIMIT_EXCEEDED", "参照世界を含むentityとrelationの件数が上限を超えています。");
	let f = n.value.recovery ? await a.recovery(n.value.recovery, c, t.signal) : void 0, p = n.value.syncRecovery?.length ? await qn(n.value.syncRecovery, i, t.signal) : void 0, m = [...li(f), ...Kn(p)];
	l(m), Pa(m, r), await Fa(m);
	let h = t.assetMode ?? "embedded", g = Aa([
		c,
		...m,
		...Object.values(r)
	]);
	t.onProgress?.({
		stage: "serializing",
		completed: 0,
		total: 1
	});
	let _ = c.history.length + c.snapshots.length + (c.authorAlternatives?.length ?? 0) + (f?.pending.length ?? 0) + (p?.length ?? 0), v = d >= 5e3 && _ > 0 || [
		c,
		...Object.values(r),
		f,
		p
	].some((e) => e !== void 0 && fe(e, N.jsonBytes)) ? new nr({
		recordDeltas: !0,
		calendarRecords: !0
	}) : void 0, y = (e) => M(v ? v.encode(e) : e), b = {
		"data/project.json": y(c),
		...f ? { "data/recovery.json": y(f) } : {},
		...p ? { "data/sync-recovery.json": y(p) } : {}
	};
	for (let [e, t] of Object.entries(r)) {
		if (!_a.test(e)) throw new s("VALIDATION_FAILED", "共通世界snapshot IDが不正です。", e);
		b[`worlds/${e}.json`] = y(Ta(t, `worlds/${e}.json`, N, i, a));
	}
	if (v && (b["data/records.json"] = M({
		records: v.records,
		arrays: v.arrays
	})), h === "embedded") for (let e of g) {
		if (o(t.signal), b[e.assetPath]) continue;
		let n = await t.loadAsset?.(e.contentHash);
		if (!n) throw new s("ASSET_MISSING", "完全保存に必要な添付bytesが取得されていません。", e.assetPath);
		if (Sa(e.assetPath, e.mediaType, n), n.byteLength !== e.byteSize || await D(n) !== e.contentHash) throw new s("HASH_MISMATCH", "素材bytesと保存メタデータが一致しません。", e.assetPath);
		b[e.assetPath] = n, t.onProgress?.({
			stage: "serializing",
			completed: Object.keys(b).filter((e) => e.startsWith("assets/")).length,
			total: g.length
		});
	}
	else if (h !== "metadata_only") throw new s("FORMAT_UNSUPPORTED", "出力プロファイルが未対応です。");
	let S = 0, C = { objects: 0 }, w = [];
	for (let [e, t] of Object.entries(b)) {
		let n = e === "data/project.json" ? "project" : e === "data/recovery.json" ? "recovery" : e === "data/sync-recovery.json" ? "sync_recovery" : e === "data/records.json" ? "record_dictionary" : e.startsWith("worlds/") ? "world" : "asset";
		if (t.byteLength > (n === "asset" ? N.assetBytes : N.jsonBytes) || (S += t.byteLength) > N.expandedBytes) throw new s("LIMIT_EXCEEDED", "出力サイズが安全上限を超えています。分割や軽量出力を選んでください。", e);
		w.push({
			path: e,
			byteSize: t.byteLength,
			sha256: await D(t),
			role: n
		}), n !== "asset" && he(t, e, N, C);
	}
	let T = La([
		c,
		...m,
		...Object.values(r)
	]), ee = {
		format: "scenario-package",
		formatVersion: I,
		projectId: c.projectId,
		snapshotId: t.snapshotId ?? j(),
		exportedAt: t.exportedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
		assetMode: h,
		files: w,
		minimumReaderVersion: I,
		...f || p || v || T ? { requiredFeatures: [
			...f ? ["portable-recovery-v1"] : [],
			...p ? ["native-sync-recovery-v1"] : [],
			...v ? [Jn, ...v.usedFeatures] : [],
			...T ? ["shared-review-source-v1"] : []
		] } : {}
	};
	if (wa(ee), b["manifest.json"] = M(ee), he(b["manifest.json"], "manifest.json", N, C), Object.keys(b).length > N.files || S + b["manifest.json"].length > N.expandedBytes) throw new s("LIMIT_EXCEEDED", "出力のファイル数または全bytesが上限を超えています。");
	o(t.signal), t.onProgress?.({
		stage: "compressing",
		completed: 0,
		total: 1
	});
	let E = Xr(b, { level: 6 });
	if (E.byteLength > N.compressedBytes) throw new s("LIMIT_EXCEEDED", "圧縮後の出力が64 MiBを超えています。分割や軽量出力を選んでください。");
	return E;
}
function La(e) {
	let t = /* @__PURE__ */ new WeakSet(), n = (e) => {
		if (!e || typeof e != "object" || t.has(e)) return !1;
		t.add(e);
		let r = e;
		return r.kind === "review" && r.data && typeof r.data == "object" && r.data.sharedSource ? !0 : Object.values(e).some(n);
	};
	return e.some(n);
}
//#endregion
//#region src/storage/clone.ts
var Ra = (e) => structuredClone(e);
function za(e, t = /* @__PURE__ */ new WeakSet()) {
	if (e && typeof e == "object" && !t.has(e)) {
		t.add(e);
		for (let n of Object.keys(e)) {
			let r = e[n];
			r && typeof r == "object" && za(r, t);
		}
		Object.freeze(e);
	}
	return e;
}
async function Ba(e) {
	let t = { [e.projectId]: j() }, n = /* @__PURE__ */ new WeakSet(), r = (e) => {
		if (e && typeof e == "object" && !n.has(e)) {
			if (n.add(e), Array.isArray(e)) return e.forEach(r);
			for (let [n, i] of Object.entries(e)) {
				if ([
					"id",
					"operationId",
					"instanceId",
					"deletionOperationId"
				].includes(n) && typeof i == "string" && /^[0-9a-f-]{36}$/.test(i) && (t[i] ??= j()), n === "bindings" && i && typeof i == "object" && !Array.isArray(i)) for (let e of Object.values(i)) typeof e == "string" && /^[0-9a-f-]{36}$/.test(e) && (t[e] ??= j());
				r(i);
			}
		}
	};
	r(e);
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new WeakSet(), c = (e) => {
		if (!e || typeof e != "object" || o.has(e)) return;
		if (o.add(e), Array.isArray(e)) {
			for (let t = e.length - 1; t >= 0; t--) c(e[t]);
			return;
		}
		let t = e, n = Object.values(t);
		for (let e = n.length - 1; e >= 0; e--) c(n[e]);
		typeof t.id == "string" && "kind" in t && "data" in t && "projectId" in t && !i.has(t.id) && i.set(t.id, t), typeof t.id == "string" && "relationType" in t && "fromId" in t && "toId" in t && !a.has(t.id) && a.set(t.id, t);
	};
	c(e);
	let l = (e, t) => t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), u = (e, t, n) => {
		let r = e;
		for (let e of t.slice(0, -1)) (!r[e] || typeof r[e] != "object") && (r[e] = {}), r = r[e];
		t.length && (r[t[t.length - 1]] = structuredClone(n));
	}, p = (e) => {
		if (Array.isArray(e)) {
			e.forEach(p);
			return;
		}
		if (!e || typeof e != "object") return;
		let n = e;
		if (typeof n.id == "string" && (n.id = t[n.id] ?? n.id), typeof n.instanceId == "string" && "quantity" in n && "consumed" in n && (n.instanceId = t[n.instanceId] ?? n.instanceId), n.mode === "anonymize" && typeof n.publicId == "string" && (n.publicId = t[n.publicId] ?? n.publicId), n.publicIds && typeof n.publicIds == "object") for (let [e, r] of Object.entries(n.publicIds)) typeof r == "string" && (n.publicIds[e] = t[r] ?? r);
		for (let e of Object.values(n)) p(e);
	}, m = /* @__PURE__ */ new WeakMap(), h = (e, t = "", n) => {
		if (!e || typeof e != "object") return g(e, t, n);
		let r = t;
		Array.isArray(e) && (t === "value" && (r += n?.type === "ref" ? ":ref" : ":literal"), t === "key" && n && typeof n.scope == "string" && Array.isArray(n.path) && (r += A([
			n.scope,
			n.itemId ?? null,
			n.path
		])), t === "publicId" && (r += n && typeof n.entityId == "string" && typeof n.sourceVersionId == "string" ? ":citation" : ":local"));
		let i = m.get(e) ?? /* @__PURE__ */ new Map();
		if (i.has(r)) return i.get(r);
		let a = g(e, t, n);
		return i.set(r, a), m.set(e, i), a;
	}, g = (e, n = "", r) => {
		if (typeof e == "string") return n === "onceTriggers" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/g, (e) => t[e] ?? e) : n === "key" && r && typeof r.scope == "string" && Array.isArray(r.path) ? [
			r.scope,
			typeof r.itemId == "string" ? t[r.itemId] ?? r.itemId : "",
			...r.path.map((e) => String(e))
		].map((e) => encodeURIComponent(e)).join(":") : n === "publicId" && r && typeof r.entityId == "string" && typeof r.sourceVersionId == "string" ? e : (/(?:Id|Ids)$/.test(n) || ["id", "operationId"].includes(n) || n === "value" && r?.type === "ref") && t[e] ? t[e] : e;
		if (n === "importOrigin" && e && typeof e == "object") {
			let n = e;
			return {
				...n,
				importOperationId: t[n.importOperationId] ?? n.importOperationId
			};
		}
		if (n === "path" && Array.isArray(e)) return [...e];
		if (n === "assignments" && e && typeof e == "object" && !Array.isArray(e)) return Object.fromEntries(Object.entries(e).map(([e, n]) => [e, typeof n == "string" ? t[n] ?? n : n]));
		if (Array.isArray(e)) return e.map((e) => h(e, n, r));
		if (e && typeof e == "object") {
			let r = e;
			if ([
				"entity",
				"relation",
				"project",
				"presentation"
			].includes(String(r.scope)) && Array.isArray(r.path) && r.before && r.after && "present" in r.before && "present" in r.after) {
				let e = String(r.scope), n = r.path, o = typeof r.itemId == "string" ? r.itemId : void 0, s = o ? t[o] ?? o : void 0, c = [...n], m = (r) => {
					if (e === "entity" && o && i.has(o) && n.length) {
						let e = structuredClone(i.get(o));
						u(e, n, r);
						let a = d(e, t);
						return a.id = t[e.id] ?? e.id, a.projectId = t[e.projectId] ?? e.projectId, a.deletionOperationId &&= t[a.deletionOperationId] ?? a.deletionOperationId, p(a.data), l(a, n);
					}
					if (e === "relation" && o && a.has(o) && n.length) {
						let e = structuredClone(a.get(o));
						u(e, n, r);
						let i = f(e, t);
						return i.id = t[e.id] ?? e.id, i.projectId = t[e.projectId] ?? e.projectId, l(i, n);
					}
					if (e === "project" && n[0] === "worldReferences") return structuredClone(r);
					if (e === "presentation" && r && typeof r == "object" && !Array.isArray(r)) {
						let e = structuredClone(r);
						return Array.isArray(e.chapterOrder) && (e.chapterOrder = e.chapterOrder.map((e) => typeof e == "string" ? t[e] ?? e : e)), h(e);
					}
					let s = n.at(-1) ?? "";
					return h(r, s);
				}, g = (e) => {
					let t = structuredClone(e);
					return t.present === !0 && (t.value = m(t.value)), t;
				}, _ = {
					...r,
					...s ? { itemId: s } : {},
					path: c,
					before: g(r.before),
					after: g(r.after)
				};
				return _.key = [
					e,
					s ?? "",
					...c
				].map((e) => encodeURIComponent(e)).join(":"), _;
			}
			let o = [
				"variableValues",
				"visitCounts",
				"publicTexts",
				"publicIds",
				"byEntityId",
				"bindings"
			].includes(n), s = Object.fromEntries(Object.entries(e).map(([r, i]) => [o ? t[r] ?? r : r, ["idMap", "bindings"].includes(n) && typeof i == "string" ? t[i] ?? i : h(i, r, e)]));
			return "kind" in s && "data" in s && "projectId" in s ? d(s, t) : "relationType" in s && "fromId" in s && "toId" in s ? f(s, t) : (Array.isArray(s.patches) && Array.isArray(s.selectedChangeKeys) && (s.selectedChangeKeys = s.patches.map((e) => e.key).sort()), s);
		}
		return e;
	}, _ = h(e), v = /* @__PURE__ */ new Map(), y = /* @__PURE__ */ new WeakSet(), b = (e) => {
		if (!e || typeof e != "object" || y.has(e)) return;
		if (y.add(e), Array.isArray(e)) {
			e.forEach(b);
			return;
		}
		let t = e;
		if (typeof t.id == "string" && t.content && typeof t.content == "object" && "versionLabel" in t && "contentHash" in t) {
			let e = v.get(t.id) ?? [];
			e.push(t), v.set(t.id, e);
		}
		Object.values(t).forEach(b);
	};
	b(_);
	let x = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ new Set(), C = async (e) => {
		let t = x.get(e);
		if (t) return t;
		let n = v.get(e);
		if (!n?.length) throw new s("HASH_MISMATCH", "参照したsnapshotがclone後に見つかりません。", e);
		if (S.has(e)) throw new s("HASH_MISMATCH", "snapshotの内容hashに循環があります。", e);
		S.add(e);
		for (let e of n) {
			let t = e.content;
			for (let e of t.entities) e.kind === "snapshot" && v.has(e.id) && (e.data.contentHash = await C(e.id));
		}
		let r = await D(M(n[0].content));
		for (let e of n) e.contentHash = r;
		return x.set(e, r), S.delete(e), r;
	};
	for (let e of v.keys()) await C(e);
	let w = /* @__PURE__ */ new WeakSet(), T = (e) => {
		if (!e || typeof e != "object" || w.has(e)) return;
		if (w.add(e), Array.isArray(e)) {
			e.forEach(T);
			return;
		}
		let t = e;
		if (t.kind === "snapshot" && typeof t.id == "string" && t.data && typeof t.data == "object") {
			let e = x.get(t.id);
			e && (t.data.contentHash = e);
		}
		Object.values(t).forEach(T);
	};
	T(_);
	let ee = /* @__PURE__ */ new Set(), E = async (e) => {
		if (!e || typeof e != "object" || ee.has(e)) return;
		if (ee.add(e), Array.isArray(e)) {
			for (let t of e) await E(t);
			return;
		}
		let t = e;
		Array.isArray(t.authorAlternatives) && (t.authorAlternatives = await Promise.all((t.authorAlternatives ?? []).map(ln)));
		for (let e of Object.values(t)) await E(e);
	};
	await E(_);
	let { history: te, snapshots: ne, authorAlternatives: re, ...ie } = _, O = {
		..._,
		...Ra(ie)
	};
	za(O.history);
	for (let e of O.snapshots) za(e);
	return {
		project: O,
		idMap: t
	};
}
//#endregion
//#region src/storage/importWork.ts
var Va = /* @__PURE__ */ new Set([
	"full_read",
	"structure",
	"integrity",
	"recovery",
	"ids",
	"hashes",
	"map_recovery",
	"rehash_recovery"
]), Ha = 1e5, Ua = 128;
function Wa(e) {
	let t = e;
	return typeof t.id == "string" && typeof t.projectId == "string" && (typeof t.kind == "string" && !!t.data && typeof t.data == "object" || typeof t.relationType == "string" && typeof t.fromId == "string" && typeof t.toId == "string");
}
function Ga() {
	let e = /* @__PURE__ */ new WeakMap(), t = 0, n = 0, r = (t, n) => e.get(t)?.has(n) ?? !1, i = (r, i, a, o, s) => {
		if (o ? t >= Ha : !a || !s || n >= Ua) return;
		let c = e.get(r);
		c || (c = /* @__PURE__ */ new WeakSet(), e.set(r, c)), c.add(i), o ? t++ : a && n++;
	}, a = (e, t, n = 0, o = "other") => {
		if (Object.is(e, t)) return !0;
		if (!e || !t || typeof e != "object" || typeof t != "object" || n > 128) return !1;
		let s = Array.isArray(e);
		if (s !== Array.isArray(t) || Object.getPrototypeOf(e) !== Object.getPrototypeOf(t)) return !1;
		if (r(e, t)) return !0;
		let c = Reflect.ownKeys(e), l = Reflect.ownKeys(t);
		if (c.length !== l.length) return !1;
		for (let r = 0; r < c.length; r++) {
			let i = c[r];
			if (i !== l[r]) return !1;
			let o = Object.getOwnPropertyDescriptor(e, i), s = Object.getOwnPropertyDescriptor(t, i);
			if (!o || !s || o.enumerable !== s.enumerable || !Object.hasOwn(o, "value") || !Object.hasOwn(s, "value") || !a(o.value, s.value, n + 1, i === "entities" || i === "relations" || i === "calendars" ? i : "other")) return !1;
		}
		let u = s && (o === "entities" || o === "relations" || o === "calendars");
		return i(e, t, s, Wa(e), u), !0;
	};
	return a;
}
function Ka(e, t, n) {
	let r = Array.isArray(e), i = r ? Array(e.length) : Object.create(Object.getPrototypeOf(e)), a = !1;
	for (let o of Reflect.ownKeys(e)) {
		if (r && o === "length") continue;
		let s = Object.getOwnPropertyDescriptor(e, o);
		if (typeof o != "string" || !s || !Object.hasOwn(s, "value")) return;
		let c = o === t ? (a = !0, n) : s.value;
		Object.defineProperty(i, o, {
			value: c,
			enumerable: s.enumerable,
			writable: !1,
			configurable: !1
		});
	}
	if (a) return Object.freeze(i);
}
function qa(e, t, n = Ga()) {
	if (!e || typeof e != "object" || Array.isArray(e)) return;
	let r = e;
	if (!Array.isArray(r.pending)) return;
	let i = new Map(t.history.map((e) => [e.operationId, e])), a = [];
	for (let e of r.pending) {
		if (!e || typeof e != "object" || Array.isArray(e)) return;
		let t = i.get(e.operationId);
		if (!t || !n(t, e.command)) return;
		let r = Ka(e, "command", t);
		if (!r) return;
		a.push(r);
	}
	return Ka(r, "pending", Object.freeze(a));
}
function Ja(e) {
	return Va.has(e.step) && l(e), e;
}
function Ya(e) {
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object") return e;
		let r = t.get(e);
		if (r) return r;
		let i = Array.isArray(e), a = i ? Array(e.length) : Object.create(Object.getPrototypeOf(e));
		t.set(e, a);
		for (let t of Reflect.ownKeys(e)) {
			if (i && t === "length") continue;
			let r = Object.getOwnPropertyDescriptor(e, t);
			if (typeof t != "string" || !r || !Object.hasOwn(r, "value")) throw TypeError("Captured plain data changed shape before mutable clone");
			Object.defineProperty(a, t, {
				value: n(r.value),
				enumerable: r.enumerable,
				writable: !0,
				configurable: !0
			});
		}
		return a;
	};
	return n(e);
}
async function Xa(e, t, n, r, i, a = !1, c = An, l) {
	o(t);
	let { project: d, worlds: f, recovery: p } = e, m = {}, h;
	switch (e.step) {
		case "full_read": {
			let n = c(x({
				project: d,
				worlds: f,
				knownWorlds: e.knownWorlds ?? {}
			}).value), r = Dn({ worldSnapshots: n.worlds }), i = r.validate(n.project);
			if (!i.ok) throw Object.assign(new s("VALIDATION_FAILED", i.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: i.issues });
			le(i.value), o(t), Pa([n.project], n.knownWorlds), o(t), await Fa([n.project]), o(t);
			let a = await r.integrity(n.project, n.project.history.length > 0);
			if (a.length) throw Object.assign(new s("VALIDATION_FAILED", a.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: a });
			break;
		}
		case "structure": {
			let e = x(d);
			if (e.captured) {
				let t = i?.acquire(e.value, f);
				i && !t && i.clear();
				let n = t?.validationProject ?? c(e.value), a = (t?.session() ?? Dn({ worldSnapshots: f })).validate(n);
				if (!a.ok) throw Object.assign(new s("VALIDATION_FAILED", a.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: a.issues });
				le(a.value), t && (h = () => t.commit(n)), m.project = r(e.value);
			} else {
				i?.clear();
				let e = u(d, { worldSnapshots: f });
				if (!e.ok) throw Object.assign(new s("VALIDATION_FAILED", e.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: e.issues });
				le(e.value), m.project = e.value;
			}
			break;
		}
		case "worlds":
			Pa([d], e.knownWorlds ?? {});
			break;
		case "hashes":
			await Fa([d]);
			break;
		case "integrity": {
			let e = x({
				project: d,
				worlds: f
			}), t;
			if (e.captured) {
				let n = i?.acquire(e.value.project, e.value.worlds);
				i && !n && i.clear();
				let r = n?.validationProject ? void 0 : c(e.value), a = n?.validationProject ?? r.project;
				t = await (n?.session(r?.worlds) ?? Dn({ worldSnapshots: r.worlds })).integrity(a, a.history.length > 0), !t.length && n && (h = () => n.commit(a));
			} else i?.clear(), t = await En(d, { worldSnapshots: f }, d.history.length > 0);
			if (t.length) throw Object.assign(new s("VALIDATION_FAILED", t.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: t });
			break;
		}
		case "recovery": {
			let e = x({
				project: d,
				recovery: p,
				worlds: f
			});
			if (e.captured) {
				let n = i?.acquire(e.value.project, e.value.worlds);
				if (i && !n && i.clear(), n?.validationProject) {
					let r = e.value.recovery ? qa(e.value.recovery, n.validationProject, n.same) : void 0;
					if (r) await n.session().recoveryForInspection(r, n.validationProject, t);
					else {
						i?.clear();
						let n = c(e.value);
						await _i(n.recovery, n.project, n.worlds, t);
					}
				} else {
					n && i?.clear();
					let r = c(e.value);
					await _i(r.recovery, r.project, r.worlds, t);
				}
				m.recovery = r(e.value.recovery);
			} else i?.clear(), m.recovery = await _i(p, d, f, t);
			break;
		}
		case "sync_recovery":
			m.syncRecovery = await qn(e.syncRecovery, f, t);
			break;
		case "ids": {
			if (!a) {
				let e = x({
					project: d,
					recovery: p
				});
				if (e.captured) {
					let t = c(e.value);
					m.ids = na(mi(t.project, t.recovery));
				} else m.ids = na(mi(d, p));
				break;
			}
			let e = ra();
			if (!e) {
				let e = x({
					project: d,
					recovery: p
				});
				if (e.captured) {
					let t = c(e.value);
					m.ids = na(mi(t.project, t.recovery));
				} else m.ids = na(mi(d, p));
				break;
			}
			let t = x({
				project: d,
				recovery: p
			});
			if (!t.captured) {
				m.ids = na(mi(d, p));
				break;
			}
			let n = c(t.value), r = mi(n.project, n.recovery), i = x(r);
			m.ids = i.captured ? e(i.value) : na(r);
			break;
		}
		case "clone":
			m.cloned = await Ba(mi(d, p));
			break;
		case "mapped_plan": {
			if (!e.mapped || !e.target || !e.idMap) throw new s("IMPORT_CONFLICT", "別作品の統合候補と全IDの明示対応が必要です。");
			let r = e.mapped.source;
			m.mappedPlan = await ga({
				...r,
				project: mi(r.project, r.recovery)
			}, e.target, {
				idMap: e.idMap,
				resolutions: e.resolutions,
				knownWorlds: e.mapped.knownWorlds,
				loadAsset: n,
				signal: t
			});
			break;
		}
		case "merge_conflicts":
			if (!e.target) throw new s("NOT_FOUND", "統合先がありません。");
			m.conflicts = Qa(e.target, d);
			break;
		case "merge":
			if (!e.target) throw new s("NOT_FOUND", "統合先がありません。");
			m.project = $a(e.target, d, e.resolutions ?? {});
			break;
		case "combine_history": {
			if (!e.target) throw new s("NOT_FOUND", "統合先がありません。");
			let t = new Map(e.target.history.map((e) => [e.operationId, e]));
			for (let e of d.history) {
				let n = t.get(e.operationId);
				if (n && !P(n, e)) throw new s("IMPORT_CONFLICT", "同じ操作IDに異なる履歴があります。", e.operationId);
				n || t.set(e.operationId, structuredClone(e));
			}
			m.history = [...t.values()];
			break;
		}
		case "map_recovery": {
			if (!p || !e.idMap) throw new s("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。");
			let n = x({
				project: d,
				recovery: p,
				idMap: e.idMap
			});
			if (n.captured) {
				let e = c(n.value), i = new Map(n.value.project.history.map((e) => [e.operationId, e])), a = new Map(e.project.history.map((e) => [e.operationId, e])), u = [], d = Zr();
				for (let e of n.value.recovery.pending) {
					o(t);
					let r = n.value.idMap[e.operationId], c = i.get(r), f = a.get(r);
					if (!r || !c || !f) throw new s("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。", e.operationId);
					u.push({
						operationId: r,
						command: c,
						commandHash: l ? await l(f) : await D(d(f)),
						origin: e.origin ?? {
							projectId: n.value.recovery.projectId,
							operationId: e.operationId,
							serverRevision: n.value.recovery.serverRevision
						}
					});
				}
				m.recovery = r({
					...n.value.recovery,
					projectId: n.value.project.projectId,
					sourceRevision: n.value.project.revision,
					pending: u
				});
			} else {
				let n = new Map(d.history.map((e) => [e.operationId, e])), r = [];
				for (let i of p.pending) {
					o(t);
					let a = e.idMap[i.operationId], c = n.get(a);
					if (!a || !c) throw new s("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。", i.operationId);
					r.push({
						operationId: a,
						command: c,
						commandHash: await D(M(c)),
						origin: i.origin ?? {
							projectId: p.projectId,
							operationId: i.operationId,
							serverRevision: p.serverRevision
						}
					});
				}
				m.recovery = {
					...p,
					projectId: d.projectId,
					sourceRevision: d.revision,
					pending: r
				};
			}
			break;
		}
		case "rehash_recovery": {
			if (!p) throw new s("VALIDATION_FAILED", "送信待ち復元情報がありません。");
			let e = x({
				project: d,
				recovery: p
			});
			if (e.captured) {
				let n = c(e.value), i = new Map(e.value.project.history.map((e) => [e.operationId, e])), a = new Map(n.project.history.map((e) => [e.operationId, e])), s = [], u = Zr();
				for (let [r, c] of e.value.recovery.pending.entries()) {
					o(t);
					let e = n.recovery.pending[r], d = i.get(c.operationId) ?? c.command, f = a.get(e.operationId) ?? e.command;
					s.push({
						...c,
						command: d,
						commandHash: l ? await l(f) : await D(u(f))
					});
				}
				m.recovery = r({
					...e.value.recovery,
					projectId: e.value.project.projectId,
					sourceRevision: e.value.project.revision,
					pending: s
				});
			} else {
				let e = new Map(d.history.map((e) => [e.operationId, e])), n = [];
				for (let r of p.pending) {
					o(t);
					let i = e.get(r.operationId) ?? r.command;
					n.push({
						...r,
						command: i,
						commandHash: await D(M(i))
					});
				}
				m.recovery = {
					...p,
					projectId: d.projectId,
					sourceRevision: d.revision,
					pending: n
				};
			}
			break;
		}
		default: throw new s("FORMAT_UNSUPPORTED", "読み込みの検査工程が未対応です。");
	}
	return o(t), h?.(), m;
}
function Za(e, t, n) {
	return Xa(e, t, n, Ya);
}
function Qa(e, t) {
	let n = [];
	for (let r of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) P(e[r], t[r]) || n.push({
		id: `project.${r}`,
		kind: "project",
		existing: e[r],
		incoming: t[r]
	});
	for (let [r, i] of [
		["entities", "entity"],
		["relations", "relation"],
		["snapshots", "snapshot"],
		["views", "view"],
		["authorAlternatives", "alternative"]
	]) {
		let a = new Map((e[r] ?? []).map((e) => [e.id, e]));
		for (let e of t[r] ?? []) a.has(e.id) && !P(a.get(e.id), e) && n.push({
			id: e.id,
			kind: i,
			existing: a.get(e.id),
			incoming: e
		});
	}
	return n;
}
function $a(e, t, n) {
	let r = Qa(e, t);
	for (let e of r) {
		if (!n[e.id]) throw new s("IMPORT_CONFLICT", "同じID・異なる内容の競合があります。採用する内容を選択してください。", e.id);
		if (e.kind === "snapshot" && n[e.id] !== "existing") throw new s("IMMUTABLE_SNAPSHOT", "既存snapshotは別の内容へ置き換えられません。", e.id);
		if (e.kind === "alternative" && n[e.id] !== "existing") throw new s("IMPORT_CONFLICT", "保存済み作者別案のIDへ別の履歴を上書きできません。", e.id);
	}
	let i = structuredClone(e);
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) n[`project.${e}`] === "incoming" && (i[e] = structuredClone(t[e]));
	for (let r of [
		"entities",
		"relations",
		"snapshots",
		"views",
		"authorAlternatives"
	]) {
		let a = new Map((e[r] ?? []).map((e) => [e.id, e]));
		for (let e of t[r] ?? []) (!a.has(e.id) || n[e.id] === "incoming") && a.set(e.id, structuredClone(e));
		i[r] = [...a.values()];
	}
	return i;
}
//#endregion
//#region src/observability/databaseProbe.ts
function eo(e) {
	e.use({
		stack: "dbcore",
		name: "scenario-numeric-probe",
		level: -3,
		create(e) {
			let t = /* @__PURE__ */ new WeakMap();
			return {
				...e,
				table(n) {
					let r = e.table(n);
					if (!se.includes(n)) return r;
					let a = n, o = (e, t) => {
						k("db.read.calls", 1, a), k(t ? "db.read.rows" : "db.read.keys", e.filter((e) => e !== void 0).length, a), t && E("db.read.payloadBytes", e, a);
					};
					return {
						...r,
						get(e) {
							return _e() ? (k("db.read.requested", 1, a), r.get(e).then((e) => (o(e === void 0 ? [] : [e], !0), e))) : r.get(e);
						},
						getMany(e) {
							return _e() ? (k("db.read.requested", e.keys.length, a), r.getMany(e).then((e) => (o(e, !0), e))) : r.getMany(e);
						},
						query(e) {
							return _e() ? r.query(e).then((t) => (o(t.result, !!e.values), t)) : r.query(e);
						},
						mutate(e) {
							if (!_e()) return r.mutate(e);
							let n = ae(), o = e.type === "add" || e.type === "put" ? e.values.length : e.type === "delete" ? e.keys.length : 0;
							n("db.write.calls", 1, a), n("db.write.attempted", o, a), e.type === "deleteRange" && n("db.deleteRange.calls", 1, a), (e.type === "add" || e.type === "put") && E("db.write.payloadBytes", e.values, a);
							let s = t.get(e.trans);
							if (!s) {
								s = { writes: /* @__PURE__ */ new Map() }, t.set(e.trans, s);
								let r = s.writes, a = e.trans, o = i();
								a.addEventListener("complete", () => {
									n("db.transaction.committed");
									for (let [e, t] of r) n("db.write.committed", t, e);
									o.finish();
								}, { once: !0 }), a.addEventListener("abort", () => {
									n("db.transaction.aborted");
									for (let [e, t] of r) n("db.write.aborted", t, e);
									o.finish();
								}, { once: !0 });
							}
							let c = s.writes;
							return r.mutate(e).then((e) => {
								let t = Math.max(0, o - e.numFailures);
								return n("db.write.succeeded", t, a), c.set(a, (c.get(a) ?? 0) + t), e;
							});
						}
					};
				}
			};
		}
	});
}
//#endregion
//#region src/diagnostics.ts
var to = [
	"VALIDATION_FAILED",
	"REFERENCE_INVALID",
	"LOCAL_SAVE_FAILED",
	"QUOTA_EXCEEDED",
	"SYNC_CONFLICT",
	"AUTH_REQUIRED",
	"FORBIDDEN",
	"FORMAT_UNSUPPORTED",
	"INTEGRITY_FAILED",
	"IMPORT_LIMIT",
	"ANALYSIS_LIMIT",
	"EXPORT_UNSUPPORTED",
	"UI_RENDER_FAILED"
], no = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
function ro(e, t, n, r) {
	if (!to.includes(e)) throw Error("Unknown diagnostic code");
	if (t !== void 0 && !no.test(t)) throw Error("Invalid operation ID");
	if (n !== void 0 && !/^(0|[1-9]\d*)$/.test(n)) throw Error("Invalid revision");
	let i = {};
	if (r) {
		for (let e of ["commit", "tree"]) typeof r[e] == "string" && /^[0-9a-f]{40}$/.test(r[e]) && (i[e] = r[e]);
		typeof r.dirty == "boolean" && (i.dirty = r.dirty), typeof r.base == "string" && /^\/[A-Za-z0-9_/-]{0,100}\/$/.test(r.base) && (i.base = r.base), [
			"Chromium",
			"Edge",
			"Firefox",
			"Safari",
			"unknown"
		].includes(r.browser ?? "") && (i.browser = r.browser), [
			"Windows",
			"macOS",
			"iOS",
			"Android",
			"Linux",
			"unknown"
		].includes(r.os ?? "") && (i.os = r.os);
		for (let e of ["browserVersion", "osVersion"]) typeof r[e] == "string" && /^\d+(?:\.\d+){0,4}$/.test(r[e]) && r[e].length <= 32 && (i[e] = r[e]);
		for (let e of ["width", "height"]) Number.isSafeInteger(r[e]) && r[e] >= 0 && r[e] <= 1e4 && (i[e] = r[e]);
		typeof r.online == "boolean" && (i.online = r.online);
	}
	return {
		schemaVersion: "1.0.0",
		code: e,
		operationId: t ?? null,
		revision: n ?? null,
		environment: "browser",
		recordedAt: (/* @__PURE__ */ new Date()).toISOString(),
		...r ? { metadata: i } : {}
	};
}
var io = /* @__PURE__ */ new Map(), ao = /* @__PURE__ */ new Set(), oo = "guest";
function so() {
	let e = typeof navigator > "u" ? "" : navigator.userAgent, t = e.match(/Edg\/([\d.]+)/) ? "Edge" : e.match(/Firefox\/([\d.]+)/) ? "Firefox" : e.match(/(?:Chrome|Chromium)\/([\d.]+)/) ? "Chromium" : e.match(/Version\/([\d.]+).*Safari/) ? "Safari" : "unknown", n = e.match(t === "Edge" ? /Edg\/([\d.]+)/ : t === "Firefox" ? /Firefox\/([\d.]+)/ : t === "Chromium" ? /(?:Chrome|Chromium)\/([\d.]+)/ : /Version\/([\d.]+)/)?.[1], r = /iPhone|iPad|iPod/.test(e) ? "iOS" : /Android/.test(e) ? "Android" : /Windows/.test(e) ? "Windows" : /Macintosh/.test(e) ? "macOS" : /Linux/.test(e) ? "Linux" : "unknown";
	return {
		commit: void 0,
		tree: void 0,
		dirty: void 0,
		base: "/__measurement/",
		browser: t,
		browserVersion: n,
		os: r,
		osVersion: e.match(r === "iOS" ? /OS ([\d_]+)/ : r === "Android" ? /Android ([\d.]+)/ : r === "Windows" ? /Windows NT ([\d.]+)/ : /Mac OS X ([\d_]+)/)?.[1]?.replaceAll("_", "."),
		...typeof window > "u" ? {} : {
			width: window.innerWidth,
			height: window.innerHeight,
			online: navigator.onLine
		}
	};
}
function co(e, t = {}) {
	try {
		let n = e && typeof e == "object" && "code" in e ? String(e.code) : "";
		if (n === "CANCELLED" || e instanceof DOMException && e.name === "AbortError") return;
		let r = t.code ?? (to.includes(n) ? n : {
			SAVE_FAILED: "LOCAL_SAVE_FAILED",
			REVISION_CONFLICT: "SYNC_CONFLICT",
			OPERATION_CONFLICT: "SYNC_CONFLICT",
			REVISION_CHANGED: "SYNC_CONFLICT",
			ARCHIVE_INVALID: "INTEGRITY_FAILED",
			HASH_MISMATCH: "INTEGRITY_FAILED",
			UNSAFE_PATH: "INTEGRITY_FAILED",
			ASSET_MISSING: "INTEGRITY_FAILED",
			ASSET_INVALID: "INTEGRITY_FAILED",
			LIMIT_EXCEEDED: "IMPORT_LIMIT",
			PROTOCOL_INVALID: "INTEGRITY_FAILED"
		}[n] ?? "LOCAL_SAVE_FAILED"), i = t.accountId === void 0 ? oo : t.accountId ?? "guest", a = ro(r, no.test(t.operationId ?? "") ? t.operationId : void 0, /^(0|[1-9]\d*)$/.test(t.revision ?? "") ? t.revision : void 0, so());
		return io.set(i, [...(io.get(i) ?? []).slice(-19), a]), ao.forEach((e) => e()), a;
	} catch {}
}
//#endregion
//#region src/storage/recordPartsDatabase.ts
var lo = "__scenarioRecordParts", uo = /* @__PURE__ */ new Set([
	"commands",
	"outbox",
	"recoveredPending",
	"restorePoints",
	"worlds",
	"snapshots",
	"syncBases",
	"preparedSync",
	"syncConflicts",
	"syncAckEvidence",
	"retainedSyncRecovery",
	"projects",
	"entities"
]), fo = (e) => !!e && typeof e == "object" && Object.hasOwn(e, lo), po = /* @__PURE__ */ new WeakMap(), mo = /* @__PURE__ */ new WeakSet();
function ho(e) {
	let t = H.currentTransaction?.idbtrans;
	t && e && po.set(t, e);
}
function go(e) {
	ho(e);
	let t = H.currentTransaction?.idbtrans;
	t && mo.add(t);
}
function _o(e, t) {
	e.use({
		stack: "dbcore",
		name: "scenario-record-parts-v1",
		level: -2,
		create(e) {
			if (!e.schema.tables.some((e) => e.name === "recordParts")) return e;
			let n = e.table("recordParts"), r = (e, t) => new Promise((n, r) => {
				let i = e, a = !1, o, c, l = !1, u = () => {
					try {
						let e = i.objectStore("recordParts").get("__scenario_keep_alive__");
						e.onsuccess = () => {
							if (a) {
								l ? r(c) : n(o);
								return;
							}
							u();
						}, e.onerror = () => r(e.error ?? new s("SAVE_FAILED", "履歴のトランザクションを維持できません。"));
					} catch (e) {
						r(e);
					}
				};
				u();
				try {
					t().then((e) => {
						o = e, a = !0;
					}, (e) => {
						c = e, l = !0, a = !0;
					});
				} catch (e) {
					c = e, l = !0, a = !0;
				}
			});
			return {
				...e,
				transaction(t, n, r) {
					return e.transaction([.../* @__PURE__ */ new Set([...t, "recordParts"])], n, r);
				},
				table(i) {
					let a = e.table(i);
					if (!uo.has(i)) return a;
					let o = (e) => fo(e) || i === "commands" && !!e && typeof e == "object" && Dt(e), c = [a.schema.primaryKey, ...a.schema.indexes], l = (e, t) => {
						let n = { [lo]: t };
						for (let t of c) {
							let r = typeof t.keyPath == "string" ? [t.keyPath] : t.keyPath ?? [];
							for (let t of r) {
								if (t.includes(".")) throw new s("SAVE_FAILED", "分割保存の索引形式に対応していません。");
								Object.hasOwn(e, t) && (n[t] = e[t]);
							}
						}
						return n;
					}, u = async (e, t, a = !1) => {
						let o = e;
						if (!fo(e)) {
							if (i === "commands" && o && Dt(o)) throw new s("SAVE_FAILED", "履歴の内部表現が破損しています。");
							return i === "commands" && a && (k("history.legacy.rows", +!!e), E("history.legacy.payloadBytes", e)), e;
						}
						if (i === "commands" && a && Ot(e)) {
							let n = await r(t, () => Ft(e));
							return await Lt(e, t), zt(e), {
								operationId: e.operationId,
								projectId: e.projectId,
								revision: e.revision,
								delta: { metadata: n }
							};
						}
						i === "commands" && a && (k("history.legacy.rows"), E("history.legacy.payloadBytes", e));
						let c = await n.getMany({
							trans: t,
							keys: e[lo].parts.map((e) => e.key)
						});
						if (c.some((e) => !e)) throw new s("SAVE_FAILED", "履歴の分割記録が不足しています。");
						i === "commands" && (k("history.body.rows"), k("history.body.partRows", c.length), k("history.body.partBytes", c.reduce((e, t) => e + (t.bytes?.byteLength ?? 0), 0)));
						let u = xe("decode"), d = await r(t, () => bt(e[lo], c, po.get(t)));
						if (u(), k("decode.rows"), E("decode.payloadBytes", d), !d || typeof d != "object" || fo(d)) throw new s("SAVE_FAILED", "履歴の分割記録と索引が一致しません。");
						if (i === "commands" && Dt(e)) await r(t, () => It(e, d, l(d, e[lo])));
						else if (!P(l(d, e[lo]), e)) throw new s("SAVE_FAILED", "履歴の分割記録と索引が一致しません。");
						return d;
					}, d = (e, t, n) => i === "commands" && Tt(n) ? Pt(e, l(e, t)) : l(e, t), f = async (e, t) => {
						let r = e.flatMap((e) => fo(e) ? e[lo].parts.map((e) => e.key) : []);
						if (r.length) {
							let e = await n.mutate({
								type: "delete",
								trans: t,
								keys: r
							});
							if (e.numFailures) throw Object.values(e.failures)[0];
						}
					};
					return {
						...a,
						async get(e) {
							return u(await a.get(e), e.trans);
						},
						async getMany(e) {
							let t = i === "commands" && Et(e), n = await a.getMany(e), r;
							for (let i = 0; i < n.length; i++) o(n[i]) ? (r ??= n.slice(), r[i] = await u(n[i], e.trans, t)) : t && n[i] !== void 0 && (k("history.legacy.rows"), E("history.legacy.payloadBytes", n[i]));
							return r ?? n;
						},
						async query(e) {
							let t = await a.query(e);
							if (e.values) {
								let n;
								for (let r = 0; r < t.result.length; r++) o(t.result[r]) && (n ??= t.result.slice(), n[r] = await u(t.result[r], e.trans));
								if (n) return {
									...t,
									result: n
								};
							}
							return t;
						},
						async openCursor(e) {
							let t = await a.openCursor(e);
							if (!t || !e.values) return t;
							let n = await u(t.value, e.trans), r = {
								get trans() {
									return t.trans;
								},
								get key() {
									return t.key;
								},
								get primaryKey() {
									return t.primaryKey;
								},
								get done() {
									return t.done;
								},
								get value() {
									return n;
								},
								continue(e) {
									t.continue(e);
								},
								continuePrimaryKey(e, n) {
									t.continuePrimaryKey(e, n);
								},
								advance(e) {
									t.advance(e);
								},
								stop(e) {
									t.stop(e);
								},
								fail(e) {
									t.fail(e);
								},
								async next() {
									return await t.next(), n = await u(t.value, e.trans), r;
								},
								start(r) {
									return t.start(() => {
										u(t.value, e.trans).then((e) => {
											n = e, r();
										}, (e) => t.fail(e));
									});
								}
							};
							return r;
						},
						async mutate(e) {
							let c = [];
							if (e.type === "put" || e.type === "delete") {
								let t = e.keys ?? (e.type === "put" ? e.values.map((e) => a.schema.primaryKey.extractKey?.(e)) : []);
								c = await a.getMany({
									trans: e.trans,
									keys: t
								});
							}
							if (e.type === "deleteRange" && (c = (await a.query({
								trans: e.trans,
								values: !0,
								query: {
									index: a.schema.primaryKey,
									range: e.range
								}
							})).result), e.type === "add" || e.type === "put") {
								let u = [], p = [], m = mo.has(e.trans) && (i === "commands" || i === "recoveredPending") ? yt : vt;
								if (mo.has(e.trans) && (i === "commands" || i === "recoveredPending") && e.values.length > 1) for (let n = 0; n < e.values.length; n += 2) {
									let a = await r(e.trans, () => Promise.allSettled(e.values.slice(n, n + 2).map(async (n) => {
										if (o(n)) throw new s("SAVE_FAILED", "内部の分割記録を入力値として保存できません。");
										if (!dt(n, t)) return {
											value: n,
											parts: []
										};
										let r = await m(n, `${i}:${j()}`, po.get(e.trans));
										return {
											value: await d(n, r.packed, e.trans),
											parts: r.parts
										};
									})));
									for (let e of a) if (e.status === "rejected") throw e.reason;
									for (let e of a) e.status === "fulfilled" && (u.push(e.value.value), p.push(...e.value.parts));
								}
								else for (let n of e.values) {
									if (o(n)) throw new s("SAVE_FAILED", "内部の分割記録を入力値として保存できません。");
									if (dt(n, t)) {
										let t = await r(e.trans, () => m(n, `${i}:${j()}`, po.get(e.trans)));
										u.push(i === "commands" && Tt(e.trans) ? await r(e.trans, () => Pt(n, l(n, t.packed))) : l(n, t.packed)), p.push(...t.parts);
									} else u.push(n);
								}
								let h = /* @__PURE__ */ new Map();
								u.forEach((t, n) => {
									let r = e.keys?.[n] ?? a.schema.primaryKey.extractKey?.(t);
									h.set(JSON.stringify(r), t);
								});
								let g = new Set([...h.values()].flatMap((e) => fo(e) ? [e[lo].scope] : [])), _ = p.filter((e) => g.has(e.scope));
								if (_.length) {
									let t = await n.mutate({
										type: "add",
										trans: e.trans,
										values: _
									});
									if (t.numFailures) throw Object.values(t.failures)[0];
								}
								let v = await a.mutate({
									...e,
									values: u
								});
								return v.numFailures ? (e.trans.abort(), v) : (await f(c, e.trans), v);
							}
							let u = await a.mutate(e);
							return u.numFailures ? (e.trans.abort(), u) : (await f(c, e.trans), u);
						}
					};
				}
			};
		}
	});
}
//#endregion
//#region src/storage/readValidationCore.ts
async function vo(e, t, n) {
	let r = {
		...e,
		history: []
	}, i = Na(t);
	n?.("structure"), le(r), n?.("integrity");
	let a = await En(r, { worldSnapshots: i }, !1);
	if (a.length) throw Object.assign(new s("VALIDATION_FAILED", a.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: a });
	n?.("worlds"), Pa([r], t), n?.("hashes"), await Fa([r]);
}
//#endregion
//#region src/storage/readValidation.ts
async function yo(e, t, n = {}) {
	if (o(n.signal), typeof window > "u" || typeof Worker > "u" || e.entities.length + e.relations.length < 5e3) {
		await vo(e, t, n.onStage), o(n.signal);
		return;
	}
	await new Promise((r, i) => {
		let a = new Worker(new URL(
			/* @vite-ignore */
			"/__measurement/assets/readValidation.worker-DzUy_hN_.js",
			"" + import.meta.url
		), { type: "module" });
		G(a, "worker.read");
		let c = (e) => {
			a.terminate(), n.signal?.removeEventListener("abort", l), e ? i(e) : r();
		}, l = () => c(new s("CANCELLED", "作品の確認を取り消しました。保存済み内容と入力は変更していません。"));
		a.onmessage = (e) => {
			let t = e.data;
			if (t.type === "stage") n.onStage?.(t.stage);
			else if (t.type === "done") try {
				o(n.signal), c();
			} catch (e) {
				c(e);
			}
			else t.type === "error" && c(Object.assign(new s(t.code, t.message), { issues: t.issues ?? [] }));
		}, a.onerror = () => c(new s("SAVE_FAILED", "作品の確認処理を開始できませんでした。保存済み内容を保持しています。")), n.signal?.addEventListener("abort", l, { once: !0 });
		try {
			o(n.signal), a.postMessage({
				project: e,
				worlds: t
			});
		} catch (e) {
			c(e);
		}
	});
}
//#endregion
//#region src/performance.ts
function bo() {
	try {
		return sessionStorage.getItem("scenario-performance") === "measure";
	} catch {
		return !1;
	}
}
function xo() {
	return bo() ? performance.now() : void 0;
}
function So(e, t, n) {
	if (!(e === void 0 || !Number.isFinite(e) || e < 0 || !bo())) try {
		performance.measure("scenario-local-save", {
			start: e,
			end: performance.now(),
			detail: {
				operationId: t,
				...n ? { milliseconds: n } : {}
			}
		});
	} catch {}
}
function Co(e, t, n) {
	if (!(e === void 0 || !Number.isFinite(e) || e < 0 || !bo())) try {
		performance.measure("scenario-local-read", {
			start: e,
			end: performance.now(),
			detail: {
				projectId: t,
				milliseconds: n
			}
		});
	} catch {}
}
//#endregion
//#region src/storage/nativeExport.ts
async function wo(e, t = {}) {
	o(t.signal), e = An(e);
	let n = e.worlds;
	if (e.availableWorlds) {
		n = {};
		let t = [...e.pending.map((e) => e.command), ...e.retained.map((e) => e.command)].flatMap((e) => [e.before, e.after].map((e) => ({
			...e,
			history: []
		}))), r = [
			e.project,
			...t,
			...Kn(e.syncRecovery)
		];
		for (; r.length;) {
			let t = [];
			for (let i of Ma(r, e.availableWorlds)) {
				if (n[i.immutableSnapshotId]) continue;
				let r = e.availableWorlds[i.immutableSnapshotId];
				r && (n[i.immutableSnapshotId] = r, t.push(r));
			}
			r = t;
		}
	}
	let r = Zr(), i = new Map(e.retained.map((e) => [e.operationId, e]));
	for (let n of e.pending) {
		o(t.signal);
		let a = await D(r(n.command)), c = i.get(n.operationId);
		if (c && c.commandHash !== a) throw new s("OPERATION_CONFLICT", "復元した送信待ちと現在の送信待ちが同じIDで異なります。");
		i.set(n.operationId, {
			operationId: n.operationId,
			command: n.command,
			commandHash: a,
			origin: {
				projectId: e.project.projectId,
				operationId: n.operationId,
				serverRevision: n.baseRevision
			}
		}), t.onProgress?.({
			stage: "hashes",
			completed: i.size,
			total: e.pending.length
		}), await new Promise((e) => setTimeout(e, 0)), o(t.signal);
	}
	let a = i.size ? {
		version: 1,
		projectId: e.project.projectId,
		sourceRevision: e.project.revision,
		serverRevision: e.serverRevision,
		pending: [...i.values()]
	} : void 0;
	return Ia(e.project, {
		...t,
		recovery: a,
		worlds: n,
		syncRecovery: e.syncRecovery
	});
}
//#endregion
//#region src/storage/archive.ts
async function To(e, t = {}) {
	let n = t.signal, r = t.loadAsset;
	return o(n), typeof window > "u" || typeof Worker > "u" ? Za(Ja(structuredClone(e)), n, r) : new Promise((t, i) => {
		let a = new Worker(new URL(
			/* @vite-ignore */
			"/__measurement/assets/archive.worker-D-2ZmHu8.js",
			"" + import.meta.url
		), { type: "module" });
		G(a, "worker.archive");
		let c = !0, l = (e, r) => {
			c && (c = !1, a.terminate(), n?.removeEventListener("abort", u), e ? i(e) : t(r));
		}, u = () => l(new s("CANCELLED", "復元の確認を取り消しました。既存作品と元ファイルは変更していません。"));
		a.onmessage = (e) => {
			let t = e.data;
			if (t.type === "done") try {
				o(n), l(void 0, t.result);
			} catch (e) {
				l(e);
			}
			else t.type === "error" ? l(Object.assign(new s(t.error.code, t.error.message, t.error.path), { issues: t.error.issues ?? [] })) : t.type === "asset" && Promise.resolve().then(() => (o(n), r?.(t.hash))).then((e) => {
				if (!c || n?.aborted) return;
				let r = e?.slice();
				a.postMessage({
					type: "import-asset",
					id: t.id,
					bytes: r
				}, r ? [r.buffer] : []);
			}).catch((e) => {
				if (!c || n?.aborted) return;
				let r = p(e);
				a.postMessage({
					type: "import-asset",
					id: t.id,
					error: {
						code: r.code,
						message: r.message,
						path: r.path,
						issues: e?.issues
					}
				});
			});
		}, a.onerror = () => l(new s("SAVE_FAILED", "復元の確認処理を完了できませんでした。既存作品と元ファイルは保持しています。")), n?.addEventListener("abort", u, { once: !0 });
		try {
			o(n), a.postMessage({
				type: "import-work",
				work: e
			});
		} catch (e) {
			l(e);
		}
	});
}
async function Eo(e, t = {}) {
	if (o(t.signal), t.worker === !1 || typeof window > "u" || typeof Worker > "u") return wo(e, t);
	let { loadAsset: n, signal: r, onProgress: i, ...a } = t;
	return Do({
		native: e,
		options: a
	}, t);
}
function Do(e, t) {
	return new Promise((n, r) => {
		let i = new Worker(new URL(
			/* @vite-ignore */
			"/__measurement/assets/archiveExport.worker-DUh5DmMU.js",
			"" + import.meta.url
		), { type: "module" }), a = !0;
		G(i, "worker.archive");
		let c = (e, o) => {
			a && (a = !1, i.terminate(), t.signal?.removeEventListener("abort", l), e ? r(e) : n(o));
		}, l = () => c(new s("CANCELLED", "保存ファイルの作成を取り消しました。端末の作品と入力は変更していません。"));
		i.onmessage = (e) => {
			let n = e.data;
			n.type === "progress" ? t.onProgress?.(n.progress) : n.type === "done" ? c(void 0, n.bytes) : n.type === "error" ? c(new s(n.code, n.message, n.path)) : n.type === "asset" && Promise.resolve().then(() => t.loadAsset?.(n.hash)).then((e) => {
				if (!a) return;
				let t = e?.slice();
				i.postMessage({
					type: "asset",
					id: n.id,
					bytes: t
				}, t ? [t.buffer] : []);
			}).catch(() => {
				a && i.postMessage({
					type: "asset",
					id: n.id
				});
			});
		}, i.onerror = () => c(new s("SAVE_FAILED", "保存ファイルを作成できませんでした。端末の作品は保持しています。")), t.signal?.addEventListener("abort", l, { once: !0 });
		try {
			if (o(t.signal), ("native" in e ? [e.native] : [
				e.input,
				e.options.worlds,
				e.options.recovery,
				e.options.syncRecovery
			].filter((e) => e !== void 0)).every(S)) {
				let n = x(e);
				n.captured ? ft(n.value, (e) => i.postMessage(e), t.signal, () => a).catch(c) : i.postMessage(e);
			} else i.postMessage(e);
		} catch (e) {
			c(e);
		}
	});
}
//#endregion
//#region src/storage/worldPins.ts
async function Oo(e, t, n) {
	let r = {
		...n,
		...t.dependencies,
		[t.snapshotId]: t.world
	}, i = {}, a = [t.snapshotId];
	for (; a.length;) {
		let e = a.pop();
		if (i[e]) continue;
		let t = r[e], o = t?.snapshots.find((t) => t.id === e);
		if (!t || !o || o.content.projectId !== t.projectId) throw new s("VALIDATION_FAILED", "固定する共通世界の版が見つかりません。", e);
		let c = n[e]?.snapshots.find((t) => t.id === e);
		if (c && !P(c, o)) throw new s("IMMUTABLE_SNAPSHOT", "保存済みの共通世界版を変更できません。", e);
		let l = /* @__PURE__ */ new Map([[o.id, o]]), u = [o];
		for (; u.length;) {
			let e = u.pop(), n = [...e.content.entities.flatMap(be), ...e.content.relations.flatMap(g)];
			for (let e of n) if (e.scope === "snapshot" && e.id !== t.projectId && !l.has(e.id)) {
				let n = t.snapshots.find((t) => t.id === e.id);
				n && (l.set(n.id, n), u.push(n));
			}
		}
		let d = {
			...structuredClone(o.content),
			snapshots: structuredClone([...l.values()]),
			history: []
		};
		i[e] = d;
		for (let e of Ma([d])) a.push(e.immutableSnapshotId);
	}
	let o = i[t.snapshotId].snapshots[0];
	if (!e.worldReferences.some((e) => e.immutableSnapshotId === t.snapshotId && e.projectId === o.content.projectId && e.contentHash === o.contentHash)) throw new s("VALIDATION_FAILED", "作品の固定版参照と保存対象が一致しません。", t.snapshotId);
	let c = {
		...n,
		...i
	}, l = Na(c);
	for (let e of Object.values(i)) {
		let t = u(e, { worldSnapshots: l });
		if (!t.ok) throw new s("VALIDATION_FAILED", t.issues.map((e) => e.message).join("\n"));
	}
	return Pa([e, ...Object.values(i)], c), await Fa([...Object.values(n), ...Object.values(i)]), i;
}
//#endregion
//#region src/domain/text.ts
var ko = "本文の置換・削除・段落分割が注記に重なり、元の文字を特定できません。", Ao = (e) => e.map((e) => e.text).join("\n"), jo = /* @__PURE__ */ new WeakMap();
function Mo(e, t, n) {
	let r = Array(e.length), i = 0, a = 0;
	if (n && n.start >= 0 && n.end >= n.start && n.end <= e.length) {
		let i = t.length - (e.length - (n.end - n.start));
		if (i >= 0 && e.slice(0, n.start).join("") === t.slice(0, n.start).join("") && e.slice(n.end).join("") === t.slice(n.start + i).join("")) {
			for (let e = 0; e < n.start; e++) r[e] = e;
			for (let t = n.end; t < e.length; t++) r[t] = t + i - (n.end - n.start);
			return r;
		}
	}
	for (; i < e.length && i < t.length && e[i] === t[i];) r[i] = i, i++;
	for (; a < e.length - i && a < t.length - i && e[e.length - a - 1] === t[t.length - a - 1];) r[e.length - a - 1] = t.length - a - 1, a++;
	let o = e.length - i - a, s = t.length - i - a;
	if (!o || !s || o * s > 25e4) return r;
	let c = s + 1, l = new Uint32Array((o + 1) * c);
	for (let n = o - 1; n >= 0; n--) for (let r = s - 1; r >= 0; r--) l[n * c + r] = e[i + n] === t[i + r] ? l[(n + 1) * c + r + 1] + 1 : Math.max(l[(n + 1) * c + r], l[n * c + r + 1]);
	let u = 0, d = 0;
	for (; u < o && d < s;) e[i + u] === t[i + d] ? (r[i + u] = i + d, u++, d++) : l[(u + 1) * c + d] > l[u * c + d + 1] ? u++ : d++;
	return r;
}
function No(e) {
	let t = 0;
	return e.map((e) => {
		let n = t;
		return t += e + 1, n;
	});
}
function Po(e, t, n) {
	let r = Ao(e), i = Ao(t), a = Array.from(r), o = Array.from(i), s = e.map((e) => Array.from(e.text)), c = t.map((e) => Array.from(e.text).length), l = s.map((e) => e.length), u = No(l), d = No(c), f = Mo(a, o, n), p = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ new Map();
	e.forEach((e, t) => p.set(e.text, [...p.get(e.text) ?? [], t])), t.forEach((e, t) => m.set(e.text, [...m.get(e.text) ?? [], t]));
	let h = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new Set();
	e.forEach((e, r) => {
		if (!n && p.get(e.text)?.length !== m.get(e.text)?.length) return;
		let i = t.findIndex((t) => t.id === e.id && t.text === e.text);
		if (!(i < 0)) {
			h.set(r, i);
			for (let e = 0; e < l[r]; e++) g.add(d[i] + e);
		}
	});
	for (let [e, t] of p) {
		let n = m.get(e);
		n && t.length === 1 && n.length === 1 && t.forEach((e, t) => {
			if (h.has(e)) return;
			let r = n[t];
			h.set(e, r);
			for (let t = 0; t < l[e]; t++) g.add(d[r] + t);
		});
	}
	e.forEach((e, t) => {
		let r = h.get(t);
		for (let i = 0; i < l[t]; i++) {
			let a = u[t] + i;
			r === void 0 ? f[a] !== void 0 && g.has(f[a]) && (f[a] = void 0) : f[a] = d[r] + i, !n && !h.has(t) && (p.get(e.text)?.length ?? 0) > 1 && p.get(e.text)?.length !== m.get(e.text)?.length && (f[a] = void 0);
		}
	});
	let _ = /* @__PURE__ */ new Map();
	t.forEach((e, t) => {
		for (let e = 0; e < c[t]; e++) _.set(d[t] + e, {
			block: t,
			offset: e
		});
	});
	let v = new Map(e.map((e, t) => [e.id, t])), y = a.every((e, t) => f[t] !== void 0 && f[t] === f[0] + t), b = (e, t) => {
		let n = 0, r = 0;
		for (; t && (r = e.indexOf(t, r)) >= 0;) n++, r++;
		return n;
	}, x = (e) => !n && e && b(i, e) > 1 && b(r, e) !== b(i, e), S = /* @__PURE__ */ new Map();
	e.forEach((e, n) => {
		if (h.has(n)) {
			S.set(n, h.get(n));
			return;
		}
		let r = /* @__PURE__ */ new Map();
		for (let e = 0; e < l[n]; e++) {
			let t = f[u[n] + e], i = t === void 0 ? void 0 : _.get(t);
			i && r.set(i.block, (r.get(i.block) ?? 0) + 1);
		}
		let i = [...r].sort((e, t) => e[0] - t[0])[0];
		i ? S.set(n, i[0]) : t.some((t) => t.id === e.id) && S.set(n, t.findIndex((t) => t.id === e.id));
	});
	let C = (e, t) => {
		if (e < 0 || t < e || t > a.length) return;
		if (e === t) return f[e] === void 0 ? e > 0 && f[e - 1] !== void 0 ? {
			start: f[e - 1] + 1,
			end: f[e - 1] + 1
		} : void 0 : {
			start: f[e],
			end: f[e]
		};
		let n = f[e];
		if (n !== void 0) {
			for (let r = e + 1; r < t; r++) if (f[r] !== n + r - e) return;
			return {
				start: n,
				end: n + t - e
			};
		}
	};
	return {
		blocks: t,
		block: (e) => {
			let n = v.get(e), r = n === void 0 ? void 0 : S.get(n);
			return r === void 0 ? void 0 : t[r]?.id;
		},
		lineRange: (e, t) => {
			let o = a.slice(e, t).join("");
			if (!x(o) && !(!n && o && r !== i && i.indexOf(o, i.indexOf(o) + 1) >= 0 && r.indexOf(o, r.indexOf(o) + 1) < 0) && !(!n && !y && o && r.indexOf(o, r.indexOf(o) + 1) >= 0)) return C(e, t);
		},
		range: (e, a, o) => {
			let c = v.get(e);
			if (c === void 0 || o > l[c]) return;
			let f = s[c].slice(a, o).join("");
			if (!h.has(c) && x(f) || !n && !h.has(c) && f && r !== i && i.indexOf(f, i.indexOf(f) + 1) >= 0 && r.indexOf(f, r.indexOf(f) + 1) < 0 || !n && !y && !h.has(c) && f && r.indexOf(f, r.indexOf(f) + 1) >= 0) return;
			let p = C(u[c] + a, u[c] + o);
			if (!p) return;
			let m = _.get(p.start) ?? (a === o ? _.get(p.start - 1) : void 0), g = _.get(p.end - 1) ?? m;
			if (!m || !g || m.block !== g.block) return;
			let b = p.start - d[m.block];
			return {
				blockId: t[m.block].id,
				start: b,
				end: b + o - a
			};
		}
	};
}
function Fo(e, t, n, r, i) {
	if (e.entityId !== t || e.sourceVersionId && e.sourceVersionId !== i || e.positionStatus === "unresolved") return e;
	let a = n.find((t) => t.id === e.blockId);
	if (!a && e.lineId !== t) return e;
	let o = typeof e.start == "number" && typeof e.end == "number";
	if (o) {
		let t = a ? r.range(a.id, e.start, e.end) : r.lineRange(e.start, e.end);
		if (t) return t.start === e.start && t.end === e.end && (!a || "blockId" in t && t.blockId === e.blockId) ? e : {
			...e,
			...a ? t : {
				start: t.start,
				end: t.end
			}
		};
	} else if (a) {
		let t = r.block(a.id);
		if (t) return t === e.blockId ? e : {
			...e,
			blockId: t
		};
	} else return e;
	let s = {
		...e,
		positionStatus: "unresolved",
		positionReason: ko,
		quotedText: o ? Array.from(a?.text ?? Ao(n)).slice(e.start, e.end).join("") : a?.text ?? ""
	};
	if (delete s.start, delete s.end, a) {
		let e = r.block(a.id);
		e ? s.blockId = e : delete s.blockId;
	}
	return s;
}
function Io(e) {
	return Array.isArray(e) && e.length > 0 && e.every((e) => e && typeof e == "object" && typeof e.id == "string" && typeof e.text == "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(e.kind));
}
function Lo(e, t) {
	let n = e.data, r = t.data, i = Object.entries(n).flatMap(([e, t]) => {
		let n = r[e];
		if (!Io(t) || !Array.isArray(n) || JSON.stringify(t) === JSON.stringify(n)) return [];
		let i = [], a = n;
		for (let e = 0; e < 64; e++) {
			let e = jo.get(a);
			if (!e) break;
			if (i.unshift({
				before: e.before,
				transform: e.transform
			}), JSON.stringify(e.before) === JSON.stringify(t)) return i;
			a = e.before;
		}
		return [{
			before: t,
			transform: Po(t, n)
		}];
	});
	if (!i.length) return;
	let a = (t) => {
		if (Array.isArray(t)) {
			let e = t.map(a);
			return e.some((e, n) => e !== t[n]) ? e : t;
		}
		if (!t || typeof t != "object") return t;
		let n = t, r = t;
		if (typeof n.entityId == "string") for (let t of i) r = Fo(r, e.id, t.before, t.transform, e.projectId);
		let o = r, s = Object.entries(o).map(([e, t]) => [e, a(t)]);
		return s.some(([e, t]) => t !== o[e]) ? Object.fromEntries(s) : r;
	};
	return a;
}
function Ro(e, t, n) {
	let r = Lo(t, n);
	if (!r) return e;
	let i = Object.entries(t.data).flatMap(([e, t]) => {
		let r = n.data[e];
		return Io(t) && Array.isArray(r) && JSON.stringify(t) !== JSON.stringify(r) ? [{
			before: t,
			transform: Po(t, r)
		}] : [];
	});
	return e.map((e) => {
		let n = e.kind === "review" && e.data.targetVersionId !== t.projectId, a = e.data, o = n ? Object.entries(a).map(([e, t]) => [e, e === "target" ? t : r(t)]) : void 0, s = o ? o.some(([e, t]) => t !== a[e]) ? Object.fromEntries(o) : a : r(a);
		if (e.id === t.id && e.kind === "scene" && e.data.blockIds?.length) {
			let t = [...new Set(e.data.blockIds.map((t) => r({
				entityId: e.id,
				blockId: t
			}).blockId ?? t))];
			(t.some((t, n) => t !== e.data.blockIds[n]) || t.length !== e.data.blockIds.length) && (s = {
				...s,
				blockIds: t
			});
		}
		if (e.kind === "projection_profile" && (!e.data.sourceVersionId || e.data.sourceVersionId === t.projectId)) {
			let t = { ...e.data.blockSources }, n = !1;
			for (let [e, r] of Object.entries(t)) for (let a of i) if (a.before.some((e) => e.id === r)) {
				n = !0;
				let i = a.transform.block(r);
				i ? t[e] = i : delete t[e];
			}
			if (n) return {
				...e,
				status: "needs_review",
				data: {
					...s,
					blockSources: t
				}
			};
		}
		return s === a ? e : {
			...e,
			data: s
		};
	});
}
function zo(e, t, n) {
	let r = Lo(t, n);
	return r ? e.map((e) => {
		let t = r(e.validity);
		return t === e.validity ? e : {
			...e,
			validity: t
		};
	}) : e;
}
//#endregion
//#region src/domain/changeReviews.ts
var Bo = "changeReview.generatedBy", Vo = "changeReview.key", Ho = "changeReview.sourceIds", Uo = "changeReview.sourceRevisions", Wo = "changeReview.projectRevision", Go = "changeReview.paths", Ko = "semantic-change-review/v1", qo = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]), Jo = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]), Yo = /* @__PURE__ */ new Set(["reference"]);
function Xo(e) {
	try {
		return (BigInt(e) + 1n).toString();
	} catch {
		return e;
	}
}
function Zo(e) {
	return typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? `[${e.map(Zo).join(",")}]` : `{${Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${JSON.stringify(e)}:${Zo(t)}`).join(",")}}`;
}
function Qo(e, t) {
	if (qo.has(e.kind) || e.kind === "group" && e.data.groupType === "category") return;
	let n = { ...e.data };
	return (e.kind === "character" || e.kind === "place" || e.kind === "lore") && (delete n.reading, delete n.aliases), (e.kind === "localization" || e.kind === "recording") && (delete n.stage, delete n.reviewedBy), e.kind === "media_variant" && delete n.needsReview, e.kind === "attachment" && (delete n.displayName, delete n.licenseNote, delete n.byteSize), e.kind === "source" && delete n.accessedAt, Zo({
		deleted: t,
		data: n,
		customValues: e.customValues
	});
}
function $o(e, t) {
	let n = new Map(t.entities.map((e) => [e.id, e])), r = [];
	for (let t of e.entities) {
		let e = n.get(t.id);
		if (t.deletedAt && (!e || e.deletedAt) || e === t || e && e.kind !== t.kind) continue;
		let i = Qo(t, !!t.deletedAt), a = e ? Qo(e, !!e.deletedAt) : Qo(t, !0);
		i && a && i !== a && r.push({
			source: e ?? t,
			sourceRevision: Xo(t.revision)
		});
	}
	return r;
}
function es(e) {
	return e.deletedAt || Jo.has(e.kind) ? !1 : e.kind !== "group" || e.data.groupType !== "category";
}
function ts(e, t, n = "data") {
	if (!e || typeof e != "object") return [];
	if (Array.isArray(e)) return e.flatMap((e, r) => ts(e, t, `${n}[${r}]`));
	let r = e;
	return typeof r.entityId == "string" && typeof r.sourceVersionId == "string" && r.sourceVersionId !== t ? [n] : Object.entries(r).flatMap(([e, r]) => ts(r, t, `${n}.${e}`));
}
function ns(e, t) {
	return Zo({
		targetId: e,
		sources: t.map((e) => ({
			id: e.source.id,
			revision: e.sourceRevision,
			directPaths: [...new Set(e.directPaths)].sort(),
			relationLabels: [...new Set(e.relationLabels)].sort()
		})).sort((e, t) => e.id.localeCompare(t.id))
	});
}
function rs(e) {
	let { source: t, sourceRevision: n, directPaths: r, relationLabels: i } = e, a = [];
	return r.length && a.push(`IDで直接参照しています（${[...new Set(r)].sort().join("、")}）`), i.length && a.push(`作者が設定した関係「${[...new Set(i)].sort().join("・")}」でつながっています`), `変更元: ${ge[t.kind]}「${t.name || "無題"}」 (${t.id})。改訂 ${t.revision} → ${n}。${a.join("。")}`;
}
function is(e) {
	return new Set(e.entities.flatMap((e) => e.kind === "review" && !e.deletedAt && e.customValues[Bo] === Ko && typeof e.customValues[Vo] == "string" ? [e.customValues[Vo]] : []));
}
function as(e, t) {
	if (e.projectId !== t.projectId) return t;
	let n = $o(e, t);
	if (!n.length) return t;
	let i = t.entities.filter(es), a = new Map(i.map((e) => [e.id, e])), o = /* @__PURE__ */ new Map(), s = new Map(n.map((e) => [e.source.id, e]));
	for (let e of i) {
		let n = /* @__PURE__ */ new Map(), r = ts(e.data, t.projectId);
		for (let t of be(e)) {
			if (r.some((e) => t.path === e || t.path.startsWith(e + "."))) continue;
			let i = s.get(t.id);
			if (!i || e.id === i.source.id) continue;
			let a = n.get(t.id) ?? /* @__PURE__ */ new Set();
			a.add(t.path), n.set(t.id, a);
		}
		if (!n.size) continue;
		let i = o.get(e.id) ?? /* @__PURE__ */ new Map();
		for (let [e, t] of n) {
			let n = s.get(e);
			i.set(e, {
				...n,
				directPaths: [...t],
				relationLabels: []
			});
		}
		o.set(e.id, i);
	}
	for (let e of t.relations) if (!(e.deletedAt || e.status === "rejected" || Yo.has(e.relationType))) for (let t of new Set([e.fromId, e.toId].filter((e) => s.has(e)))) {
		let n = e.fromId === t ? e.toId : e.fromId, r = a.get(n), i = s.get(t);
		if (!r || !i || r.id === t) continue;
		let c = o.get(r.id) ?? /* @__PURE__ */ new Map(), l = c.get(t) ?? {
			...i,
			directPaths: [],
			relationLabels: []
		};
		l.relationLabels.push(Se[e.relationType] ?? e.relationType), c.set(t, l), o.set(r.id, c);
	}
	let c = is(t), l = Xo(t.revision), u = [];
	for (let [e, n] of o) {
		let i = a.get(e);
		if (!i) continue;
		let o = [...n.values()].sort((e, t) => e.source.id.localeCompare(t.source.id)), s = ns(i.id, o);
		if (c.has(s)) continue;
		c.add(s);
		let d = o.map(rs), f = [
			`「${i.name || ge[i.kind]}」に関係する情報が変更されました。内容への影響を確認してください。`,
			...d,
			`確認対象の作品改訂: ${t.revision} → ${l}。候補は人による確認用です。本文や設定は自動変更していません。`
		].join("\n"), p = r(t.projectId, "review", `変更確認: ${i.name || ge[i.kind]}`, {
			target: i.id,
			targetVersionId: t.projectId,
			body: m(f),
			stage: "open",
			quotedText: null,
			resolution: []
		});
		p.status = "needs_review", p.visibility = "private", p.customValues = {
			...p.customValues,
			[Bo]: Ko,
			[Vo]: s,
			[Ho]: JSON.stringify(o.map((e) => e.source.id)),
			[Uo]: JSON.stringify(Object.fromEntries(o.map((e) => [e.source.id, e.sourceRevision]))),
			[Wo]: l,
			[Go]: JSON.stringify(Object.fromEntries(o.map((e) => [e.source.id, {
				directPaths: [...new Set(e.directPaths)].sort(),
				relationLabels: [...new Set(e.relationLabels)].sort()
			}])))
		}, u.push(p);
	}
	return u.length ? {
		...t,
		entities: [...t.entities, ...u]
	} : t;
}
//#endregion
//#region src/storage/importWorkSession.ts
function os() {
	let e, t = !1, n = 0, r, i = () => new s("CANCELLED", "復元の確認を取り消しました。既存作品と元ファイルは変更していません。"), a = () => {
		t || (t = !0, e?.terminate(), r?.finish(i()));
	};
	return {
		run: async (c, l = {}) => {
			let { signal: u, loadAsset: d } = l;
			if (o(u), t) throw i();
			if (r) throw new s("SAVE_FAILED", "復元の確認処理が既に実行中です。");
			if (typeof window > "u" || typeof Worker > "u") return Za(Ja(structuredClone(c)), u, d);
			e ??= new Worker(new URL(
				/* @vite-ignore */
				"/__measurement/assets/archive.worker-D-2ZmHu8.js",
				"" + import.meta.url
			), { type: "module" });
			let f = e, m = ++n;
			return new Promise((e, n) => {
				let l = !0, h = (t, i) => {
					l && (l = !1, u?.removeEventListener("abort", g), r?.id === m && (r = void 0), t ? (a(), n(t)) : e(i));
				}, g = () => h(i());
				r = {
					id: m,
					finish: h
				}, f.onmessage = (e) => {
					let n = e.data;
					if (l && !t && n.requestId === m) {
						if (n.type === "done") try {
							o(u), h(void 0, n.result);
						} catch (e) {
							h(e);
						}
						else n.type === "error" ? h(Object.assign(new s(n.error.code, n.error.message, n.error.path), { issues: n.error.issues ?? [] })) : n.type === "asset" && Promise.resolve().then(() => (o(u), d?.(n.hash))).then((e) => {
							if (!l || t || u?.aborted) return;
							let r = e?.slice();
							f.postMessage({
								type: "import-asset",
								id: n.id,
								bytes: r
							}, r ? [r.buffer] : []);
						}).catch((e) => {
							if (!l || t || u?.aborted) return;
							let r = p(e);
							f.postMessage({
								type: "import-asset",
								id: n.id,
								error: {
									code: r.code,
									message: r.message,
									path: r.path,
									issues: e?.issues
								}
							});
						});
					}
				}, f.onerror = () => h(new s("SAVE_FAILED", "復元の確認処理を完了できませんでした。既存作品と元ファイルは保持しています。")), u?.addEventListener("abort", g, { once: !0 });
				try {
					o(u), f.postMessage({
						type: "import-work",
						requestId: m,
						work: c
					});
				} catch (e) {
					h(e);
				}
			});
		},
		dispose: a
	};
}
//#endregion
//#region src/storage/newImportSession.ts
function ss(e, t, n) {
	o(n);
	let r = new Worker(new URL(
		/* @vite-ignore */
		"/__measurement/assets/archive.worker-D-2ZmHu8.js",
		"" + import.meta.url
	), { type: "module" });
	return new Promise((i, a) => {
		let c = !0, l = () => new s("CANCELLED", "復元の確認を取り消しました。既存作品と元ファイルは変更していません。"), u = (e, t) => {
			c && (c = !1, n?.removeEventListener("abort", d), r.terminate(), e ? a(e) : i(t));
		}, d = () => u(l());
		r.onmessage = (e) => {
			let i = e.data;
			if (c && i.requestId === 1) {
				if (i.type === "done") try {
					o(n), u(void 0, i.result);
				} catch (e) {
					u(e);
				}
				else i.type === "error" ? u(Object.assign(new s(i.error.code, i.error.message, i.error.path), { issues: i.error.issues ?? [] })) : i.type === "new-import-callback" && Promise.resolve().then(async () => {
					switch (o(n), i.action) {
						case "stage": return t.stage(i.input);
						case "preview": return t.preview();
						case "assets": return t.assets();
						case "finalize": return t.finalize(i.input);
						default: throw new s("FORMAT_UNSUPPORTED", "読み込みの確認工程が未対応です。");
					}
				}).then((e) => {
					c && (o(n), r.postMessage({
						type: "new-import-callback-result",
						requestId: 1,
						id: i.id,
						result: e
					}));
				}).catch((e) => {
					if (!c) return;
					let t = p(e);
					u(Object.assign(t, { issues: e?.issues ?? [] }));
				});
			}
		}, r.onerror = () => u(new s("SAVE_FAILED", "復元の確認処理を完了できませんでした。既存作品と元ファイルは保持しています。")), n?.addEventListener("abort", d, { once: !0 });
		try {
			o(n), r.postMessage({
				type: "new-import",
				requestId: 1,
				input: e
			});
		} catch (e) {
			u(e);
		}
	});
}
//#endregion
//#region src/storage/store.ts
var cs = Object.freeze({ present: !1 }), ls = 4, us = class extends H {
	sharedSnapshots;
	projects;
	projectSummaries;
	worldSources;
	entities;
	relations;
	blocks;
	snapshots;
	commands;
	outbox;
	assets;
	views;
	viewStates;
	syncMetadata;
	acks;
	restorePoints;
	worlds;
	importLogs;
	importDrafts;
	authorToolDrafts;
	workspaceInputs;
	recoveredPending;
	retainedSyncRecovery;
	syncAssetAcks;
	syncBases;
	preparedSync;
	syncConflicts;
	syncAckEvidence;
	constructor(e) {
		super(e), this.version(1).stores({
			projects: "projectId,name",
			entities: "[projectId+id],projectId,[projectId+kind]",
			relations: "[projectId+id],projectId,[projectId+fromId],[projectId+toId]",
			blocks: "[projectId+id],projectId,[projectId+entityId]",
			snapshots: "[projectId+id],projectId",
			commands: "operationId,projectId,[projectId+revision]",
			outbox: "operationId,projectId,accountId",
			assets: "contentHash",
			views: "[projectId+id],projectId",
			viewStates: "key,projectId",
			syncMetadata: "projectId",
			acks: "operationId,projectId",
			restorePoints: "id,projectId,createdAt",
			worlds: "id",
			importLogs: "operationId,projectId"
		}), this.version(2).stores({ importDrafts: "key" }), this.version(3).stores({ recoveredPending: "key,projectId" }), this.version(4).stores({ authorToolDrafts: "key,projectId" }), this.version(5).stores({
			syncBases: "projectId",
			preparedSync: "operationId,projectId",
			syncConflicts: "operationId,projectId",
			syncAckEvidence: "operationId,projectId",
			retainedSyncRecovery: "key,projectId",
			syncAssetAcks: "key,projectId",
			sharedSnapshots: "id,createdAt"
		}), this.version(6).stores({ workspaceInputs: "key" }), this.version(7).stores({ recordParts: "key,scope" }), this.version(8).stores({
			projectSummaries: "projectId",
			worldSources: "id,projectId"
		}), _o(this), eo(this);
	}
}, Z = (e) => (k("copy.calls"), E("copy.payloadBytes", e), _("copy", () => structuredClone(e))), Q = (e, t) => e === t || P(e ?? null, t ?? null), ds = /* @__PURE__ */ new WeakSet(), fs = T((e) => ds.has(e)), ps = (e) => M(e, fs);
function ms(e) {
	if (e && typeof e == "object" && !ds.has(e)) {
		for (let t of Object.keys(e)) {
			let n = e[t];
			n && typeof n == "object" && ms(n);
		}
		Object.freeze(e), ds.add(e);
	}
	return e;
}
function hs(e) {
	return {
		...Z($(e)),
		history: e.history
	};
}
function gs(e) {
	k("capture.calls"), E("capture.payloadBytes", $(e));
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object") return typeof e == "function" ? Z(e) : e;
		if (ds.has(e)) return e;
		if (t.has(e)) return t.get(e);
		if (!Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return Z(e);
		let r = Array.isArray(e) ? Array(e.length) : {};
		t.set(e, r);
		for (let t of Object.keys(e)) Object.defineProperty(r, t, {
			value: n(e[t]),
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		return r;
	};
	return {
		...n($(e)),
		history: e.history
	};
}
function _s(e, t) {
	k("contentDelta.rows", e.entities.length + e.relations.length + t.entities.length + t.relations.length);
	let n = (e, t) => {
		let n = new Map(e.map((e) => [e.id, e])), r = new Map(t.map((e) => [e.id, e]));
		return [.../* @__PURE__ */ new Set([...n.keys(), ...r.keys()])].flatMap((e) => Q(n.get(e) ?? null, r.get(e) ?? null) ? [] : [{
			id: e,
			record: r.get(e) ?? null
		}]);
	}, r = Ns(e), i = Ns(t), a = {};
	for (let e of Object.keys(i)) e !== "id" && e !== "kind" && !Q(r[e], i[e]) && (a[e] = i[e]);
	let o = (e, t) => e.length === t.length && e.every((e, n) => e.id === t[n].id) ? void 0 : t.map((e) => e.id);
	return {
		header: a,
		entities: n(e.entities, t.entities),
		relations: n(e.relations, t.relations),
		entityIds: o(e.entities, t.entities),
		relationIds: o(e.relations, t.relations)
	};
}
function vs(e, t) {
	let n = (e, t, n) => {
		if (!t.length && !n) return e;
		let r = new Map(e.map((e) => [e.id, e]));
		for (let e of t) e.record ? r.set(e.id, e.record) : r.delete(e.id);
		return (n ?? [...r.keys()]).map((e) => {
			let t = r.get(e);
			if (!t) throw new s("SAVE_FAILED", "履歴の差分に必要な情報が不足しています。", e);
			return t;
		});
	};
	return {
		...e,
		...t.header,
		entities: n(e.entities, t.entities, t.entityIds),
		relations: n(e.relations, t.relations, t.relationIds)
	};
}
async function ys(e, t) {
	o(t);
	let n = Z(e), r = [], i = await b(n, t), a = Ga(), s;
	for (let [e, c] of n.entries()) {
		o(t);
		let n = {
			operationId: c.operationId,
			projectId: c.projectId,
			revision: c.revision
		}, l = {
			...n,
			record: c
		};
		if (i && c.before.projectId === c.projectId && c.after.projectId === c.projectId && c.before.revision === c.baseRevision && c.after.revision === c.revision) {
			let t = Object.fromEntries(Object.entries(c).map(([e, t]) => [e, e === "before" || e === "after" ? void 0 : t])), r = _s(c.before, c.after), i = vs(c.before, r);
			if (Object.freeze(i.entities), Object.freeze(i.relations), Object.freeze(i), a(c, Object.freeze({
				...t,
				before: c.before,
				after: i
			}))) {
				let i = e % 64 != 0 && s && a(s.after, c.before) ? s.operationId : void 0;
				l = {
					...n,
					delta: {
						metadata: t,
						...i ? { parentOperationId: i } : { checkpoint: c.before },
						patch: r
					}
				};
			}
		}
		r.push({
			record: c,
			stored: l
		}), s = c, await new Promise((e) => setTimeout(e, 0));
	}
	return o(t), r;
}
var bs = (e) => (BigInt(e) + 1n).toString(), $ = ({ history: e, ...t }) => t, xs = (e) => {
	let t = {
		...$(e),
		entities: [],
		relations: [],
		snapshots: [],
		views: [],
		revision: "0"
	};
	return e.authorAlternatives?.length ? t.authorAlternatives = [] : delete t.authorAlternatives, t;
};
function Ss(e, t = {}) {
	let n = u(e, { worldSnapshots: t });
	if (!n.ok) throw Object.assign(new s("VALIDATION_FAILED", n.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: n.issues });
	return le(n.value), n.value;
}
function Cs(e, t, n, r = /* @__PURE__ */ new WeakMap()) {
	let i = _("validate.current", () => c(e, { worldSnapshots: t }, n ? {
		previous: n,
		references: r
	} : void 0));
	if (!i.ok) {
		let e = new s("VALIDATION_FAILED", i.issues.map((e) => `${e.path}: ${e.message}`).join("\n"));
		throw Object.assign(e, { issues: i.issues }), e;
	}
	return e;
}
async function ws(e, t = {}, n = e.history.length > 0, r) {
	let i = await En(e, { worldSnapshots: t }, n, r);
	if (i.length) throw Object.assign(new s("VALIDATION_FAILED", i.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: i });
}
function Ts(e) {
	return Object.fromEntries(Object.entries(e).filter(([e]) => !["revision", "updatedAt"].includes(e)));
}
function Es(e, t, n, r) {
	k("normalize.rows", e.length + t.length);
	let i = new Map(e.map((e) => [e.id, e])), a = t.map((e) => {
		let t = i.get(e.id);
		if (t && "kind" in t && "kind" in e && t.kind !== e.kind) throw new s("OPERATION_CONFLICT", "既存IDを別の種類へ再利用できません。", e.id);
		if (!t) return Z(e);
		if ("createdAt" in t && "createdAt" in e && t.createdAt !== e.createdAt) throw new s("OPERATION_CONFLICT", "既存IDの作成日時は変更できません。", e.id);
		return Q(t, e) || Q(Ts(t), Ts(e)) ? t : {
			...Z(e),
			revision: bs(t.revision),
			..."updatedAt" in e ? { updatedAt: r } : {}
		};
	}), o = new Set(t.map((e) => e.id));
	for (let t of e) o.has(t.id) || a.push(t.deletedAt ? t : {
		...Z(t),
		deletedAt: r,
		deletionOperationId: n,
		revision: bs(t.revision),
		..."updatedAt" in t ? { updatedAt: r } : {}
	});
	return a;
}
function Ds(e, t) {
	for (let n of e.snapshots) {
		let e = t.snapshots.find((e) => e.id === n.id);
		if (!e || !P(n, e)) throw new s("IMMUTABLE_SNAPSHOT", "公開済み・保存済みの不変snapshotは変更や削除ができません。", n.id);
	}
	for (let n of e.entities.filter((e) => e.kind === "snapshot")) {
		let e = t.entities.find((e) => e.id === n.id);
		if (!e || !P(n, e)) throw new s("IMMUTABLE_SNAPSHOT", "不変snapshotは変更や削除ができません。", n.id);
	}
}
function Os(e, t, n) {
	let r = Math.min(e.length, t.length);
	for (let i = 0; i < r; i++) if (!Q(e[i], t[i])) throw new s("VALIDATION_FAILED", `${n}の既存記録は変更できません。`);
	return t.length < e.length;
}
async function ks(e, t) {
	let n = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e])), r = new Map((t.authorAlternatives ?? []).map((e) => [e.id, e])), i = [];
	for (let e of n.values()) {
		let t = r.get(e.id);
		if (!t) {
			i.push(await ln({
				...Z(e),
				status: "rejected",
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			}));
			continue;
		}
		if (t.projectId !== e.projectId || t.baseRevision !== e.baseRevision || (t.sourceSnapshotId ?? null) !== (e.sourceSnapshotId ?? null) || t.createdAt !== e.createdAt || !Q(t.baseContent, e.baseContent) || t.baseContentHash !== e.baseContentHash) throw new s("VALIDATION_FAILED", "別案の分岐元と識別情報は変更できません。", e.id);
		let n = Os(e.versions, t.versions, "別案の版"), a = Os(e.applyReceipts, t.applyReceipts, "正本採用履歴"), o = t.versions.find((e) => e.id === t.headVersionId);
		if (!o) throw new s("VALIDATION_FAILED", "別案の現在版が見つかりません。", e.id);
		if (!(n || a || t.headVersionId !== t.versions.at(-1)?.id)) {
			i.push(t);
			continue;
		}
		let c = {
			...Z(t),
			versions: Z(n ? e.versions : t.versions),
			applyReceipts: Z(a ? e.applyReceipts : t.applyReceipts)
		};
		if (n || c.headVersionId !== c.versions.at(-1)?.id) {
			let e = o.content, t = o.structurePlan, n = Date.parse(c.versions.at(-1)?.createdAt ?? ""), r = new Date(Math.max(Date.now(), Number.isFinite(n) ? n + 1 : 0)).toISOString();
			c = te(c, e, `「${o.label}」から復元`, r, j(), t);
		}
		i.push(await ln(c));
	}
	for (let e of r.values()) n.has(e.id) || i.push(e);
	t.authorAlternatives = i;
}
function As(e, t) {
	let n = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e])), r = [];
	for (let e of t.authorAlternatives ?? []) {
		let t = n.get(e.id), i = new Set(t?.applyReceipts.map((e) => e.id) ?? []);
		for (let t of e.applyReceipts) i.has(t.id) || r.push({
			alternativeId: e.id,
			receipt: t
		});
	}
	if (!r.length) return;
	if (r.length !== 1) throw new s("VALIDATION_FAILED", "一回の保存では一件の作者別案採用を記録してください。");
	let { alternativeId: i, receipt: a } = r[0], o = n.get(i);
	if (!o || a.alternativeVersionId !== o.headVersionId || a.fromCanonicalRevision !== e.revision || a.appliedRevision !== bs(e.revision)) throw new s("VALIDATION_FAILED", "採用記録の正本版または別案版が保存元と一致しません。", i);
	let c;
	try {
		c = oe(e, o, [], new Set(a.selectedChangeKeys ?? []), a.createdAt, a.id);
	} catch (e) {
		throw new s("VALIDATION_FAILED", e instanceof Error ? e.message : "採用差分を再計算できません。", i);
	}
	let { appliedRevision: l, ...u } = a;
	if (!Q(u, c.receipt)) throw new s("VALIDATION_FAILED", "作者別案の採用差分が現在の正本・選択元版と一致しません。", i);
	let d = (e) => e.kind === "review" && e.customValues["changeReview.generatedBy"] === "semantic-change-review/v1" && typeof e.customValues["changeReview.key"] == "string" ? e.customValues["changeReview.key"] : void 0, f = new Set(e.entities.flatMap((e) => d(e) ?? [])), p = as(e, c.project), m = (e) => e.entities.filter((e) => {
		let t = d(e);
		return t !== void 0 && !f.has(t);
	}), h = (e) => {
		let t = Z(e);
		if (delete t.id, delete t.createdAt, delete t.updatedAt, t.kind === "review") {
			let e = t.data;
			Array.isArray(e.body) && (e.body = e.body.map((e) => {
				let t = { ...e };
				return delete t.id, t;
			}));
		}
		return t;
	}, g = m(p).sort((e, t) => (d(e) ?? "").localeCompare(d(t) ?? "")), _ = m(t).sort((e, t) => (d(e) ?? "").localeCompare(d(t) ?? "")), v = (e, t) => {
		let n = new Set(t.map((e) => e.id));
		return {
			...me(e),
			entities: e.entities.filter((e) => !n.has(e.id))
		};
	}, y = Q(v(p, g), v(t, _)), b = g.length === _.length && g.every((e, t) => Q(h(e), h(_[t])));
	if (!y || !b) throw new s("VALIDATION_FAILED", "作者別案の採用差分が現在の正本・選択元版と一致しません。", i);
}
function js(e) {
	let n = [], r = (i) => {
		if (Array.isArray(i)) {
			if (i.length && i.every((e) => e && typeof e == "object" && "id" in e && "text" in e && [
				"paragraph",
				"heading",
				"list_item",
				"quote"
			].includes(e.kind))) {
				for (let t of i) n.push({
					id: t.id,
					projectId: e.projectId,
					entityId: e.id,
					block: Z(t)
				});
				return { __scenarioRichText: i.map((e) => e.id) };
			}
			return i.map(r);
		}
		return i && typeof i == "object" ? Object.fromEntries(Object.entries(i).map(([e, n]) => [e, t(e) ? Z(n) : r(n)])) : i;
	};
	return {
		record: r(e),
		blocks: n
	};
}
function Ms(e, t, n) {
	let r = (e) => {
		if (Array.isArray(e)) {
			let t;
			for (let n = 0; n < e.length; n++) {
				let i = r(e[n]);
				i !== e[n] && (t ??= e.slice(), t[n] = i);
			}
			return t ?? e;
		}
		if (e && typeof e == "object") {
			let i = e;
			if (Array.isArray(i.__scenarioRichText)) return i.__scenarioRichText.map((e) => {
				let r = t.get(e);
				if (!r) throw new s("SAVE_FAILED", "本文blockが不足しています。完全保存ファイルから復元してください。", e);
				return n.has(e) ? Z(r) : (n.add(e), r);
			});
			let a;
			for (let e of Object.keys(i)) {
				let t = r(i[e]);
				t !== i[e] && (a ??= { ...i }, a[e] = t);
			}
			return a ?? e;
		}
		return e;
	};
	return r(e);
}
function Ns(e) {
	let { entities: t, relations: n, ...r } = e;
	return {
		...r,
		id: e.projectId,
		kind: "project"
	};
}
async function Ps(e, t, n = !1) {
	k("targetChanges.rows", e.entities.length + e.relations.length + t.entities.length + t.relations.length);
	let r = new Map([
		...e.entities,
		...e.relations,
		...n ? [] : [Ns(e)]
	].map((e) => [e.id, e])), i = new Map([
		...t.entities,
		...t.relations,
		Ns(t)
	].map((e) => [e.id, e])), a = [], o;
	for (let e of /* @__PURE__ */ new Set([...r.keys(), ...i.keys()])) {
		let n = r.get(e) ?? null, s = i.get(e) ?? null;
		if (e !== t.projectId && (n === s || Q(n ? Ts(n) : null, s ? Ts(s) : null))) continue;
		let c = [];
		for (let e of /* @__PURE__ */ new Set([...Object.keys(n ?? {}), ...Object.keys(s ?? {})])) {
			if (["revision", "updatedAt"].includes(e)) continue;
			let t = n && e in n ? {
				present: !0,
				value: n[e]
			} : cs, r = s && e in s ? {
				present: !0,
				value: s[e]
			} : cs;
			t.present && r.present && t.value === r.value || Q(t, r) || c.push({
				field: e,
				oldValueHash: t.present ? await D(ps(t)) : o ??= await D(ps(t)),
				before: t,
				after: r
			});
		}
		a.push({
			targetId: e,
			before: n,
			after: s,
			fields: c
		});
	}
	return a;
}
var Fs = class {
	derivedBudget;
	derivedOwners = /* @__PURE__ */ new Map();
	derivedIndexRetention() {
		return {
			owners: this.derivedOwners.size,
			...this.derivedBudget.snapshot()
		};
	}
	authorAccess = null;
	accessGeneration = 0;
	setAuthorAccess(e) {
		this.authorAccess = e ? new Map(Object.entries(e)) : null, this.accessGeneration++;
		for (let e of this.cacheEpochs.keys()) this.invalidateProjectCache(e);
	}
	async refreshAuthorAccess(e, t = {}) {
		let n = this.accessGeneration, r = this.cacheLifetime, { signal: i, isCurrent: a } = t;
		o(i);
		let c = await e();
		if (o(i), n !== this.accessGeneration || r !== this.cacheLifetime || a && !a()) throw new s("CANCELLED", "権限の確認中に読み込み先または権限が変わりました。");
		if (!c || Array.isArray(c) || Object.entries(c).some(([e, t]) => !C.test(e) || !["owner", "editor"].includes(t))) throw new z("PROTOCOL_INVALID");
		this.setAuthorAccess(c);
	}
	db;
	activeOperations = 0;
	get pendingOperations() {
		return this.activeOperations;
	}
	accountId;
	faultInjector;
	onSaveMetrics;
	cachedProjects = /* @__PURE__ */ new Map();
	contentHeads = /* @__PURE__ */ new Map();
	cachedHistoryIds = /* @__PURE__ */ new Map();
	completeHistories = /* @__PURE__ */ new Set();
	cacheEpochs = /* @__PURE__ */ new Map();
	cacheLifetime = 0;
	cachedEditorSources = /* @__PURE__ */ new WeakMap();
	editorSources = /* @__PURE__ */ new WeakMap();
	editingHistories = /* @__PURE__ */ new WeakMap();
	readBaselines = /* @__PURE__ */ new WeakMap();
	validationReferences = /* @__PURE__ */ new WeakMap();
	constructor(e = {}) {
		this.derivedBudget = new Wt(e.derivedIndexes === !1 ? { entries: 0 } : e.derivedIndexes), this.accountId = e.accountId ?? null, this.faultInjector = e.faultInjector, this.onSaveMetrics = e.onSaveMetrics, this.db = new us(e.databaseName ?? (this.accountId ? `scenario-manager-account-${encodeURIComponent(this.accountId)}` : "scenario-manager-local-v1"));
		for (let e of [
			"saveProject",
			"importScenario",
			"putAsset",
			"commitPreparedAck",
			"confirmSyncResolution",
			"bindBootstrapBase",
			"bindConfirmedProject",
			"saveAuthorToolDraft",
			"saveImportDraft",
			"applyReceivedImage",
			"saveWorkspaceInputs",
			"restoreAuthorInputs",
			"restoreAuthorToolDrafts"
		]) {
			let t = this[e].bind(this);
			Object.defineProperty(this, e, {
				configurable: !0,
				writable: !0,
				value: async (...e) => {
					this.activeOperations++;
					try {
						return await t(...e);
					} finally {
						this.activeOperations--;
					}
				}
			});
		}
		for (let [e, t] of Object.entries({
			listProjectSummaries: "store.list",
			loadEditor: "store.read",
			listProjectsForEditing: "store.list",
			getProjectForEditing: "store.read",
			getProject: "store.fullRead",
			saveProject: "store.save",
			historyPage: "store.history",
			exportProject: "store.export",
			importScenario: "store.import",
			writeContent: "writeContent"
		})) {
			let n = this[e].bind(this);
			Object.defineProperty(this, e, {
				configurable: !0,
				writable: !0,
				value: (...e) => {
					if (!_e()) return n(...e);
					let r = xe(t);
					try {
						return n(...e).then((e) => (r(), e), (e) => {
							throw r("error"), e;
						});
					} catch (e) {
						throw r("error"), e;
					}
				}
			});
		}
	}
	get writeTables() {
		return [
			"projects",
			"projectSummaries",
			"worldSources",
			"entities",
			"relations",
			"blocks",
			"snapshots",
			"commands",
			"outbox",
			"assets",
			"views",
			"syncMetadata",
			"restorePoints",
			"worlds",
			"importLogs",
			"recoveredPending",
			"syncBases",
			"preparedSync",
			"syncConflicts",
			"syncAckEvidence",
			"retainedSyncRecovery",
			"syncAssetAcks"
		];
	}
	async guardWorldRegistry(e) {
		let t = /* @__PURE__ */ new Map();
		for (let n of [...(await this.db.worlds.toArray()).map((e) => e.project), ...e]) for (let e of n.snapshots) {
			let n = t.get(e.id);
			if (n && !Q(n, e)) throw new s("IMMUTABLE_SNAPSHOT", "固定版IDが別の保存済み内容と衝突しています。", e.id);
			t.set(e.id, e);
		}
	}
	close() {
		this.cacheLifetime++;
		for (let e of this.cacheEpochs.keys()) this.invalidateProjectCache(e);
		this.db.close(), this.measureCache();
	}
	async reopen() {
		await this.db.open();
	}
	async deleteDatabase() {
		this.close(), await this.db.delete();
	}
	invalidateProjectCache(e) {
		this.derivedOwners.get(e)?.close(), this.derivedOwners.delete(e), k("cache.invalidated"), this.cacheEpochs.delete(e), this.cachedProjects.delete(e), this.contentHeads.delete(e), this.cachedHistoryIds.delete(e), this.completeHistories.delete(e), this.measureCache();
	}
	captureCache(e, t = !1) {
		let n = this.cacheEpochs.get(e);
		return n || (n = { version: 0 }, this.cacheEpochs.set(e, n)), {
			project: n,
			...t ? {} : { version: n.version },
			lifetime: this.cacheLifetime,
			access: this.accessGeneration
		};
	}
	releaseCacheCapture(e, t) {
		!this.cachedProjects.has(e) && this.cacheEpochs.get(e) === t.project && this.cacheEpochs.delete(e), this.measureCache();
	}
	touchProject(e) {
		this.cachedProjects.get(e.projectId) === e && (this.cachedProjects.delete(e.projectId), this.cachedProjects.set(e.projectId, e));
	}
	measureCache() {
		if (_e()) {
			Ce("cache.projects", this.cachedProjects.size), Ce("cache.heads", this.contentHeads.size), Ce("cache.histories", this.cachedHistoryIds.size), Ce("cache.completeHistories", this.completeHistories.size), Ce("cache.epochs", this.cacheEpochs.size), Ce("cache.records", [...this.cachedProjects.values()].reduce((e, t) => e + t.entities.length + t.relations.length, 0)), Ce("cache.payloadBytes", 0);
			for (let e of this.cachedProjects.values()) E("cache.payloadBytes", e);
		}
	}
	rememberProject(e, t, n = e.history.map((e) => e.operationId), r) {
		let i = this.cachedProjects.get(e.projectId), a = this.cacheEpochs.get(e.projectId);
		if (r && (r.project !== a || r.version !== void 0 && r.version !== a?.version || r.lifetime !== this.cacheLifetime || r.access !== this.accessGeneration) || i && BigInt(i.revision) > BigInt(e.revision)) return e;
		this.derivedOwners.get(e.projectId)?.close(), this.derivedOwners.delete(e.projectId);
		let o = ms({
			...$(e),
			history: ms(e.history.map((e) => ms(e)))
		});
		this.cachedProjects.delete(e.projectId), this.cachedProjects.set(e.projectId, o), this.contentHeads.set(e.projectId, t), this.cachedHistoryIds.set(e.projectId, n), Q(n, e.history.map((e) => e.operationId)) ? this.completeHistories.add(e.projectId) : this.completeHistories.delete(e.projectId);
		let s = a ?? { version: 0 };
		for (s.version++, this.cacheEpochs.set(e.projectId, s); this.cachedProjects.size > ls;) this.invalidateProjectCache(this.cachedProjects.keys().next().value);
		return this.measureCache(), o;
	}
	editingCopy(e, t = e.history.map((e) => e.operationId), n = !1) {
		let r = ms([]);
		this.editingHistories.set(r, {
			projectId: e.projectId,
			revision: e.revision,
			historyIds: t
		});
		let i = {
			...n ? $(e) : Z($(e)),
			history: r
		}, a = this.cachedProjects.get(e.projectId);
		if (n && a && this.derivedBudget.limits.entries) {
			let t = this.derivedOwners.get(e.projectId);
			t || (t = new Gt(a, this.derivedBudget, {
				accountId: this.accountId,
				roleGeneration: this.accessGeneration
			}), this.derivedOwners.set(e.projectId, t)), t.bind(i);
		}
		return i;
	}
	getHistoryCount(e) {
		return this.editingHistories.get(e.history)?.historyIds.length ?? e.history.length;
	}
	async materializeCommand(e, t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = !0) {
		let a = n.get(e.operationId);
		if (a) return a;
		if (e.record) return n.set(e.operationId, e.record), e.record;
		let o = e.delta;
		if (!o || r.has(e.operationId)) throw new s("SAVE_FAILED", "履歴の差分または復元点が破損しています。", e.operationId);
		r.add(e.operationId);
		let c = o.checkpoint;
		if (!c && o.parentOperationId) {
			let a = t.get(o.parentOperationId) ?? (i ? await this.db.commands.get(o.parentOperationId) : void 0);
			if (!a || a.projectId !== e.projectId) throw new s("SAVE_FAILED", "履歴の元の版が不足しています。", o.parentOperationId);
			c = (await this.materializeCommand(a, t, n, r, i)).after;
		}
		if (!c || c.projectId !== e.projectId || c.revision !== o.metadata.baseRevision) throw new s("SAVE_FAILED", "履歴の復元点と元の版が一致しません。", e.operationId);
		let l = {
			...o.metadata,
			before: c,
			after: vs(c, o.patch)
		};
		if (l.operationId !== e.operationId || l.projectId !== e.projectId || l.after.revision !== e.revision) throw new s("SAVE_FAILED", "履歴の差分と操作情報が一致しません。", e.operationId);
		return r.delete(e.operationId), n.set(e.operationId, l), l;
	}
	async readProject(e, t = !0, n, r, i) {
		let a = (e, t) => {
			if (!n) return t();
			let r = performance.now();
			return t().then((t) => (n[`database.${e}`] = performance.now() - r, t));
		}, c = r ?? await this.db.projects.get(e);
		if (!c) return;
		if (c.projectId !== e) throw new s("SAVE_FAILED", "作品の保存情報が別の作品を指しています。", e);
		let { entityIds: l, relationIds: u, snapshotIds: d, historyIds: f, viewIds: p, contentHeadOperationId: m, ...h } = c, g = async (t) => {
			let n = [], r = 8192, a;
			for (;;) {
				o(i);
				let c = await t.where("[projectId+id]").between([e, a ?? H.minKey], [e, H.maxKey], a === void 0, !0).limit(r).toArray();
				o(i);
				for (let e of c) n.push(e);
				if (c.length < r) return n;
				let l = c[c.length - 1].id;
				if (typeof l != "string" || !l || a !== void 0 && l <= a) throw new s("SAVE_FAILED", "作品の保存索引を順に読み取れません。保存済みデータを保持しています。", e);
				a = l;
			}
		}, [_, v, y, b, x, S] = await Promise.all([
			a("entities", () => g(this.db.entities)),
			a("relations", () => g(this.db.relations)),
			a("snapshots", () => g(this.db.snapshots)),
			t ? this.db.commands.bulkGet(f) : Promise.resolve([]),
			g(this.db.views),
			a("blocks", () => g(this.db.blocks))
		]), C = (e, t) => {
			let n = /* @__PURE__ */ new Map();
			for (let e of t) n.set(e.id, e);
			return e.map((e) => n.get(e));
		}, w = C(l, _), T = C(u, v), ee = C(d, y), E = C(p, x);
		if ([
			w,
			T,
			ee,
			b,
			E
		].some((e) => e.some((e) => !e))) throw new s("SAVE_FAILED", "作品の保存情報が不足しています。完全保存ファイルから復元してください。", e);
		let te = /* @__PURE__ */ new Map();
		for (let e of S) {
			if (!e.block || typeof e.block != "object" || e.block.id !== e.id) throw new s("SAVE_FAILED", "本文の保存索引と段落IDが一致しません。保存済みデータを保持しています。", e.id);
			te.set(e.id, e.block);
		}
		let ne = new Map(b.map((e) => [e.operationId, e])), re = /* @__PURE__ */ new Map(), ie = [];
		b.length && await H.waitFor((async () => {
			for (let e of b) o(i), ie.push(await this.materializeCommand(e, ne, re));
		})());
		let D = n ? performance.now() : void 0, O = /* @__PURE__ */ new Set(), ae = xe("hydrate");
		k("hydrate.rows", w.length);
		let A = w.map((t) => {
			let n = t.record;
			if (!n || typeof n != "object" || Array.isArray(n) || n.id !== t.id || n.kind !== t.kind) throw new s("SAVE_FAILED", "情報の保存索引と本文のID・種別が一致しません。保存済みデータを保持しています。", t.id);
			if (n.projectId !== e) throw new s("VALIDATION_FAILED", "情報の本文が別の作品を指しています。保存済みデータを保持しています。", t.id);
			return Ms(n, te, O);
		});
		return ae(), D !== void 0 && (n["database.hydrate"] = performance.now() - D), {
			historyIds: f,
			contentHeadOperationId: m,
			project: {
				...h,
				entities: A,
				relations: T,
				snapshots: ee.map((e) => {
					let { projectId: t, ...n } = e;
					return n;
				}),
				history: ie,
				views: E.map((e) => {
					let { projectId: t, ...n } = e;
					return n;
				})
			}
		};
	}
	async getProject(e, t = {}) {
		let n = t.signal, r = this.captureCache(e);
		try {
			o(n);
			let t = await this.db.transaction("r", this.writeTables, async () => {
				ho(n), o(n);
				let t = await this.db.projects.get(e), r = this.cachedProjects.get(e);
				if (t) return r?.revision === t.revision && this.completeHistories.has(e) && Q(this.cachedHistoryIds.get(e), t.historyIds) ? {
					project: r,
					historyIds: t.historyIds,
					contentHeadOperationId: t.contentHeadOperationId
				} : this.readProject(e, !0, void 0, t, n);
			});
			if (o(n), !t) return;
			let { project: i } = t;
			if (i !== this.cachedProjects.get(e)) {
				let e = await this.validationWorlds({}, [i], n), a = Na(e);
				await To({
					step: "full_read",
					project: i,
					worlds: a,
					knownWorlds: e
				}, { signal: n }), o(n), i = this.rememberProject(i, t.contentHeadOperationId, t.historyIds, r);
			}
			o(n), this.touchProject(i);
			let a = hs(i);
			return this.readBaselines.set(a, {
				historyIds: t.historyIds,
				contentHeadOperationId: t.contentHeadOperationId
			}), a;
		} catch (e) {
			throw o(n), p(e);
		} finally {
			this.releaseCacheCapture(e, r);
		}
	}
	async getProjectForEditing(e, t = {}) {
		return this.readEditingProject(e, t, !1);
	}
	async readEditingProject(e, t, n) {
		let { signal: r, onStage: i, immutableView: a } = t, c = this.accessGeneration, l = this.cacheLifetime, u = () => {
			if (o(r), c !== this.accessGeneration || l !== this.cacheLifetime) throw new s("CANCELLED", "作品の閲覧権限または読み込み先が変わりました。");
		};
		u();
		let d, f = xo(), m = {}, h = f, g = (e) => {
			if (h === void 0) return;
			let t = performance.now();
			m[e] = (m[e] ?? 0) + t - h, h = t;
		}, _ = this.authorAccess && await this.db.syncBases.get(e) && this.authorAccess.get(e) !== "owner";
		if (o(r), _) return;
		let v = this.captureCache(e);
		try {
			let t = await this.db.transaction("r", this.writeTables, async () => {
				ho(r), o(r);
				let t = f === void 0 ? void 0 : performance.now();
				if (n) {
					let t = await qt(e);
					d = t ? await H.waitFor(Jt(t)) : void 0;
				}
				let i = await this.db.projects.get(e), a = this.cachedProjects.get(e);
				if (t !== void 0 && (m["database.header"] = performance.now() - t), i) return a?.revision === i.revision && Q(this.cachedHistoryIds.get(e), i.historyIds) && (!n || a && this.cachedEditorSources.get(a) === d) ? {
					project: a,
					historyIds: i.historyIds,
					contentHeadOperationId: i.contentHeadOperationId
				} : this.readProject(e, !1, f === void 0 ? void 0 : m, i, r);
			});
			if (o(r), !t) return;
			g("database");
			let { project: s } = t;
			if (s !== this.cachedProjects.get(e)) {
				let e = n ? await this.editorWorlds(s, r) : await this.validationWorlds({}, [s], r);
				g("dependencies");
				let a = "transfer";
				await yo(s, e, {
					signal: r,
					onStage: (e) => {
						g(a), a = `validation.${e}`, i?.(e);
					}
				}), g(a), o(r), u(), s = this.rememberProject(s, t.contentHeadOperationId, t.historyIds, v), g("immutable");
			}
			o(r), u(), d && this.cachedProjects.get(e) === s && this.cachedEditorSources.set(s, d), this.touchProject(s);
			let p = this.editingCopy(s, t.historyIds, a);
			return this.readBaselines.set(p, {
				historyIds: t.historyIds,
				contentHeadOperationId: t.contentHeadOperationId
			}), d && this.editorSources.set(p, {
				projectId: e,
				revision: s.revision,
				sourceHash: d,
				access: c,
				lifetime: l
			}), g("view"), Co(f, s.projectId, m), p;
		} catch (e) {
			throw o(r), p(e);
		} finally {
			this.releaseCacheCapture(e, v);
		}
	}
	async listProjectSummaries(e = {}) {
		let { signal: t, onProgress: n } = e, r = this.accessGeneration, i = this.cacheLifetime, a = () => {
			if (o(t), r !== this.accessGeneration || i !== this.cacheLifetime) throw new s("CANCELLED", "作品一覧の読み込み先または権限が変わりました。");
		};
		a();
		let c = await this.db.projects.toCollection().primaryKeys(), l = [];
		n?.(0, c.length);
		for (let [e, r] of c.entries()) {
			a();
			let i = r, o = "0", u = {
				localSaved: !0,
				pendingCount: null,
				recoveredPendingCount: null,
				pendingAssetCount: "unloaded",
				serverRevision: null,
				syncState: "unloaded"
			};
			try {
				let e = await this.db.transaction("r", [
					"projects",
					"projectSummaries",
					"syncBases",
					"syncMetadata",
					"outbox",
					"recoveredPending"
				], async () => {
					if (this.authorAccess && await this.db.syncBases.where("projectId").equals(r).count() && this.authorAccess.get(r) !== "owner") return;
					let e = await qt(r);
					if (!e) return;
					let t = await H.waitFor(Jt(e)), n = await this.db.projectSummaries.get(r);
					i = typeof e.name == "string" ? e.name : r, o = typeof e.revision == "string" ? e.revision : "0";
					let a = await H.waitFor(Xt(n, r, t)), [s, c, l] = await Promise.all([
						this.db.outbox.where("projectId").equals(r).count(),
						this.db.recoveredPending.where("projectId").equals(r).count(),
						this.db.syncMetadata.get(r)
					]);
					return {
						sourceHash: t,
						row: a ? n : void 0,
						saveState: {
							localSaved: !0,
							pendingCount: s,
							recoveredPendingCount: c,
							pendingAssetCount: "unloaded",
							serverRevision: l?.serverRevision ?? "0",
							syncState: l?.state === "conflict" ? "conflict" : s || c || l?.state === "pending" ? "pending" : "unloaded"
						}
					};
				});
				if (a(), e) {
					u = e.saveState;
					let n = e.row;
					if (!n) {
						this.invalidateProjectCache(r);
						let i = await this.loadEditor(r, {
							signal: t,
							immutableView: !0
						});
						if (a(), !i) continue;
						n = await Yt(i, e.sourceHash), await this.db.transaction("rw", ["projects", "projectSummaries"], async () => {
							a();
							let t = await qt(r);
							if (!t || await H.waitFor(Jt(t)) !== e.sourceHash) throw new s("REVISION_CONFLICT", "一覧の確認中に作品が更新されました。再試行してください。");
							await this.db.projectSummaries.put(n), a(), this.faultInjector?.("before-commit");
						}), this.cachedProjects.get(r)?.revision === i.revision && this.invalidateProjectCache(r);
					}
					l.push({
						projectId: r,
						name: n.name,
						revision: n.revision,
						entityCount: n.entityCount,
						alternativeHeads: n.alternativeHeads,
						contentState: "unloaded",
						saveState: e.saveState
					});
				}
			} catch (e) {
				a();
				let t = p(e);
				l.push({
					projectId: r,
					name: i,
					revision: o,
					entityCount: null,
					contentState: "error",
					error: t.message,
					saveState: u
				});
			}
			a(), n?.(e + 1, c.length);
		}
		return a(), l;
	}
	async loadEditor(e, t = {}) {
		let { signal: n, expectedRevision: r, immutableView: i, onStage: a } = t, c = this.accessGeneration, l = this.cacheLifetime, u = () => {
			if (o(n), c !== this.accessGeneration || l !== this.cacheLifetime) throw new s("CANCELLED", "作品の読み込み先または権限が変わりました。");
		};
		if (u(), this.authorAccess && await this.db.syncBases.where("projectId").equals(e).count() && this.authorAccess.get(e) !== "owner") throw new s("CANCELLED", "この作品を編集する権限がありません。");
		u();
		let d = await this.readEditingProject(e, {
			signal: n,
			immutableView: i,
			onStage: a
		}, !0);
		if (u(), d) return await this.db.transaction("r", ["projects", "syncBases"], async () => {
			if (ho(n), u(), this.authorAccess && await this.db.syncBases.get(e) && this.authorAccess.get(e) !== "owner") throw new s("CANCELLED", "作品の閲覧権限が変わりました。");
			let t = await qt(e), i = this.editorSources.get(d), a = t ? await H.waitFor(Jt(t)) : void 0;
			if (u(), !i || i.sourceHash !== a || r !== void 0 && r !== d.revision) throw BigInt(this.cachedProjects.get(e)?.revision ?? "0") <= BigInt(d.revision) && this.invalidateProjectCache(e), new s("REVISION_CONFLICT", "読み込み中に作品が更新されました。入力を保持して再試行してください。");
		}), u(), d;
	}
	releaseEditor(e) {
		this.invalidateProjectCache(e);
	}
	async listProjectsForEditing(e = {}) {
		let { signal: t, onProgress: n, onStage: r, immutableView: i } = e, a = {
			signal: t,
			onStage: r,
			immutableView: i
		};
		o(t);
		let s = await this.db.projects.toCollection().primaryKeys();
		o(t);
		let c = [];
		n?.(0, s.length);
		for (let [e, r] of s.entries()) {
			o(t);
			let i = await this.getProjectForEditing(r, a);
			o(t), i && c.push(i), n?.(e + 1, s.length);
		}
		return o(t), c;
	}
	async listProjects() {
		try {
			let e = await this.db.projects.toArray();
			return (await Promise.all(e.map((e) => this.getProject(e.projectId)))).filter((e) => !!e);
		} catch (e) {
			throw p(e);
		}
	}
	async listHistory(e) {
		return (await this.getProject(e))?.history ?? [];
	}
	async historyPage(e, t = {}) {
		let n = (t.query ?? "").normalize("NFKC").toLocaleLowerCase(), r = t.page ?? 0, i = t.size ?? 30;
		if (!Number.isSafeInteger(r) || r < 0 || !Number.isSafeInteger(i) || i < 1 || i > 60) throw new s("VALIDATION_FAILED", "履歴のページは0以上、ページ件数は1〜60です。");
		return this.db.transaction("r", ["projects", "commands"], async () => {
			let t = await this.db.projects.get(e);
			if (!t) throw new s("NOT_FOUND", "作品が見つかりません。");
			E("history.header.payloadBytes", t);
			let a = (await Rt(this.db, t.historyIds)).map((n, r) => {
				let i = n?.delta?.metadata ?? n?.record;
				if (!i || i.projectId !== e || i.operationId !== t.historyIds[r]) throw new s("SAVE_FAILED", "履歴の操作情報が不足しています。", t.historyIds[r]);
				let { before: a, after: o, ...c } = i;
				return c;
			}).reverse().filter((e) => !n || [
				e.reason,
				e.revision,
				e.baseRevision,
				e.operationId,
				e.createdAt,
				...e.targetIds
			].some((e) => e.normalize("NFKC").toLocaleLowerCase().includes(n))), o = Math.max(0, Math.ceil(a.length / i) - 1), c = Math.min(r, o);
			return {
				entries: a.slice(c * i, (c + 1) * i),
				page: c,
				maximum: o,
				total: a.length,
				size: i
			};
		});
	}
	async historyCommand(e, t) {
		let n = await this.db.projects.get(e), r = await this.db.commands.get(t);
		if (!n?.historyIds.includes(t) || !r || r.projectId !== e) throw new s("NOT_FOUND", "この作品の履歴操作が見つかりません。", t);
		return Z(await this.materializeCommand(r));
	}
	async validationWorlds(e = {}, t, n) {
		if (t) return this.dependencyWorlds(t, n);
		let r = await this.db.worlds.toArray(), i = Object.fromEntries(r.map((e) => [e.id, e.project]));
		for (let [t, n] of Object.entries(e)) i[t] = n;
		return i;
	}
	async listWorldSourceSummaries(e = {}) {
		let { signal: t } = e, n = this.accessGeneration, r = this.cacheLifetime, i = () => {
			if (o(t), n !== this.accessGeneration || r !== this.cacheLifetime) throw new s("CANCELLED", "共通世界一覧の読み込み先が変わりました。");
		};
		i();
		let a = await this.db.worlds.toCollection().primaryKeys(), c = /* @__PURE__ */ new Map(), l = [];
		for (let e of a) {
			let n;
			i();
			try {
				let r = await this.db.worldSources.get(e);
				if (!await Qt(r, e)) {
					let a = await this.db.transaction("r", ["worlds"], async () => (ho(t), this.db.worlds.get(e)));
					if (i(), !a) continue;
					typeof a.project?.projectId == "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(a.project.projectId) && (n = a.project.projectId);
					let o = {
						...await this.editorWorlds(a.project, t),
						[e]: a.project
					};
					await yo(a.project, o, { signal: t }), i(), r = await Zt(e, a.project), await this.db.transaction("rw", ["worlds", "worldSources"], async () => {
						ho(t), i();
						let n = await this.db.worlds.get(e);
						if (!n || !Q(n, a)) throw new s("REVISION_CONFLICT", "共通世界の保存情報が変わりました。");
						await this.db.worldSources.put(r), i(), this.faultInjector?.("before-commit");
					});
				}
				c.set(r.projectId, {
					projectId: r.projectId,
					name: r.name,
					revision: r.revision,
					registryOnly: !0,
					contentState: "unloaded",
					sourceIdentity: "identified"
				});
			} catch (t) {
				i(), l.push({
					projectId: n ?? e,
					name: `固定世界 ${e}`,
					revision: "0",
					registryOnly: !0,
					contentState: "error",
					sourceIdentity: n ? "identified" : "unknown",
					error: p(t).message
				});
			}
		}
		return i(), [...c.values(), ...l];
	}
	async loadWorldSource(e, t = {}) {
		let { signal: n } = t, r = this.accessGeneration, i = this.cacheLifetime, a = () => {
			if (o(n), r !== this.accessGeneration || i !== this.cacheLifetime) throw new s("CANCELLED", "共通世界の読み込み先または権限が変わりました。");
		};
		a();
		let c = await this.listWorldSourceSummaries({ signal: n });
		if (a(), c.some((t) => t.contentState === "error" && (t.projectId === e || t.sourceIdentity === "unknown"))) throw new s("VALIDATION_FAILED", "選択した共通世界の保存情報を確認できません。");
		if (!c.some((t) => t.projectId === e && t.contentState === "unloaded")) return;
		let l = await this.db.worldSources.where("projectId").equals(e).toArray(), u = {};
		await this.db.transaction("r", ["worlds"], async () => {
			ho(n);
			for (let t of l) {
				a();
				let n = await this.db.worlds.get(t.id);
				if (!n || n.project.projectId !== e) throw new s("VALIDATION_FAILED", "共通世界の索引と保存情報が一致しません。");
				u[t.id] = n.project;
			}
		});
		let d = { ...u };
		for (let e of Object.values(u)) Object.assign(d, await this.editorWorlds(e, n));
		for (let e of Object.values(u)) a(), await yo(e, d, { signal: n });
		let f = Kt([], u)[0];
		return a(), f ? {
			world: f,
			worlds: d
		} : void 0;
	}
	async editorWorlds(e, t) {
		return this.dependencyWorlds([e], t);
	}
	async dependencyWorlds(e, t) {
		return this.db.transaction("r", ["worlds"], async () => {
			ho(t), o(t);
			let n = await this.db.worlds.count();
			return k("db.count.calls", 1, "worlds"), k("db.count.result", n, "worlds"), n === 0 ? (o(t), {}) : Bt(e, (e) => this.db.worlds.get(e), () => this.validationWorlds(), t);
		});
	}
	async listEditorWorldSnapshots(e, t = {}) {
		let { signal: n } = t, r = this.accessGeneration, i = this.cacheLifetime, a = await this.editorWorlds(e, n);
		if (o(n), await this.db.transaction("r", ["projects", "syncBases"], async () => {
			if (ho(n), o(n), r !== this.accessGeneration || i !== this.cacheLifetime || this.authorAccess && await this.db.syncBases.where("projectId").equals(e.projectId).count() && this.authorAccess.get(e.projectId) !== "owner") throw new s("CANCELLED", "作品の読み込み先または権限が変わりました。");
			let t = this.editorSources.get(e), a = !1;
			if (t && t.projectId === e.projectId && t.revision === e.revision && t.access === r && t.lifetime === i) {
				let n = await qt(e.projectId);
				a = !!n && t.sourceHash === await H.waitFor(Jt(n));
			} else {
				let t = await this.db.projects.get(e.projectId);
				a = !!t && t.revision === e.revision;
			}
			if (!a) throw new s("REVISION_CONFLICT", "共通世界の確認中に作品が更新されました。入力を保持して再試行してください。");
		}), o(n), r !== this.accessGeneration || i !== this.cacheLifetime) throw new s("CANCELLED", "作品の読み込み先が変わりました。");
		return a;
	}
	async listWorldSnapshots() {
		return Z(await this.validationWorlds());
	}
	async getProjectAtRevision(e, t) {
		if (!/^(?:0|[1-9]\d*)$/.test(t)) throw new s("VALIDATION_FAILED", "revisionは正規の10進整数文字列で指定してください。");
		let n = await this.getProject(e);
		if (!n) return;
		let r = n.history.filter((e) => e.revision === t);
		if (r.length > 1 && r.some((e) => !P(e.after, r[0].after))) throw new s("RESTORE_CONFLICT", "同じrevisionに複数の履歴があります。操作IDまたは不変snapshotで対象版を選んでください。");
		if (n.revision === t) {
			if (r.some((e) => !P(e.after, $(n)))) throw new s("RESTORE_CONFLICT", "現在版と同じrevisionに別の履歴があります。操作IDまたは不変snapshotで対象版を選んでください。");
			return n;
		}
		let i = r[0];
		if (i) return {
			...Z(i.after),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(t))
		};
		let a = n.history.find((e) => e.baseRevision === t);
		return a ? {
			...Z(a.before),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(t))
		} : void 0;
	}
	async getProjectAtSnapshot(e, t) {
		let n = await this.getProject(e), r = n?.snapshots.find((e) => e.id === t);
		return r ? {
			...Z(r.content),
			snapshots: Z(n.snapshots),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(r.content.revision))
		} : void 0;
	}
	async writeContent(e, t, n, r = e.history.map((e) => e.operationId)) {
		k("writeContent.rows", (t?.entities.length ?? 0) + (t?.relations.length ?? 0) + e.entities.length + e.relations.length);
		let { entities: i, relations: a, snapshots: o, history: s, views: c, ...l } = e, u = (t, n) => {
			let r = new Map(t.map((e) => [e.id, e])), i = new Set(n.map((e) => e.id));
			return {
				put: n.filter((e) => !Q(r.get(e.id), e)),
				remove: t.filter((e) => !i.has(e.id)).map((t) => [e.projectId, t.id])
			};
		}, d = u(t?.entities ?? [], i), f = u(t?.relations ?? [], a), p = u(t?.snapshots ?? [], o), m = u(t?.views ?? [], c), h = d.put.map((e) => ({
			entity: e,
			...js(e)
		})), g = /* @__PURE__ */ new Set([...d.put.map((e) => e.id), ...d.remove.map((e) => e[1])]), _ = (t?.entities ?? []).filter((e) => g.has(e.id)).flatMap((e) => js(e).blocks), v = h.flatMap((e) => e.blocks), y = [.../* @__PURE__ */ new Set([..._.map((e) => e.id), ...v.map((e) => e.id)])], b = u((y.length ? await this.db.blocks.bulkGet(y.map((t) => [e.projectId, t])) : []).filter((e) => !!e), v);
		await Promise.all([
			this.db.entities.bulkDelete(d.remove),
			this.db.relations.bulkDelete(f.remove),
			this.db.blocks.bulkDelete(b.remove),
			this.db.snapshots.bulkDelete(p.remove),
			this.db.views.bulkDelete(m.remove)
		]), await this.db.projects.put({
			...l,
			entityIds: i.map((e) => e.id),
			relationIds: a.map((e) => e.id),
			snapshotIds: o.map((e) => e.id),
			historyIds: r,
			viewIds: c.map((e) => e.id),
			...n ? { contentHeadOperationId: n } : {}
		});
		let x = await H.waitFor(Jt(await qt(e.projectId)));
		return await this.db.projectSummaries.put(await H.waitFor(Yt(e, x))), await Promise.all([
			this.db.entities.bulkPut(h.map((t) => ({
				id: t.entity.id,
				projectId: e.projectId,
				kind: t.entity.kind,
				record: t.record
			}))),
			this.db.relations.bulkPut(f.put),
			this.db.blocks.bulkPut(b.put),
			this.db.snapshots.bulkPut(p.put.map((t) => ({
				...t,
				projectId: e.projectId
			}))),
			this.db.views.bulkPut(m.put.map((t) => ({
				...t,
				projectId: e.projectId
			})))
		]), {
			entities: d.put.length + d.remove.length,
			relations: f.put.length + f.remove.length,
			blocks: b.put.length + b.remove.length,
			snapshots: p.put.length + p.remove.length,
			views: m.put.length + m.remove.length,
			commands: 1,
			outbox: 1
		};
	}
	async checkedAssets(e = []) {
		let t = [];
		for (let n of e) {
			let e = n.bytes.slice(), r = n.assetPath ?? xa(n.contentHash, n.mediaType), i = Sa(r, n.mediaType, e);
			if (e.byteLength > 33554432) throw new s("LIMIT_EXCEEDED", "一つの添付は32 MiB以下にしてください。", r);
			if (i !== n.contentHash || await D(e) !== i) throw new s("HASH_MISMATCH", "添付bytesのhashが一致しません。", r);
			t.push({
				contentHash: i,
				mediaType: n.mediaType,
				path: r,
				bytes: e
			});
		}
		return t;
	}
	async writeAssets(e, t, n) {
		for (let t of e) {
			let e = await this.db.assets.get(t.contentHash);
			if (e && !Is(e.bytes, t.bytes)) throw new s("HASH_MISMATCH", "既存hashの素材bytesが異なります。", t.path);
			await this.db.assets.put(t);
		}
		for (let e of Oa(t)) {
			let t = await this.db.assets.get(e.contentHash);
			if (t && t.bytes.byteLength !== e.byteSize) throw new s("ASSET_INVALID", "添付bytesとメタデータのサイズが一致しません。", e.assetPath);
			if (n && !t) throw new s("ASSET_MISSING", "完全復元に必要な添付bytesがありません。", e.assetPath);
		}
	}
	async saveProject(e, t) {
		let n = performance.now(), r = t.operationId ?? j(), i = t.signal, a = n, c = {
			prepare: 0,
			hash: 0,
			read: 0,
			reconcile: 0,
			validate: 0,
			diff: 0,
			database: 0,
			total: 0
		}, l = (e) => {
			let t = performance.now();
			c[e] += t - a, e !== "total" && w(`save.${e}`, t - a), a = t;
		}, u, d;
		try {
			o(i);
			let a = gs(e), f = r, p = (/* @__PURE__ */ new Date()).toISOString();
			if (d = a.projectId, u = this.captureCache(a.projectId, !0), this.authorAccess && await this.db.syncBases.get(a.projectId) && this.authorAccess.get(a.projectId) !== "owner") throw new z("FORBIDDEN");
			let m = await this.checkedAssets(t.assets);
			l("prepare");
			let h = await this.db.commands.get(f), g = this.editingHistories.get(a.history);
			if (g && (g.projectId !== a.projectId || g.revision !== a.revision)) throw new s("OPERATION_CONFLICT", "履歴の読込元と編集中の作品・版が一致しません。");
			let _ = this.cachedProjects.get(a.projectId), v = _ ? {
				historyIds: this.cachedHistoryIds.get(a.projectId) ?? [],
				contentHeadOperationId: this.contentHeads.get(a.projectId)
			} : void 0, y = this.completeHistories.has(a.projectId), b = await this.db.projects.get(a.projectId), x = b ? _ : void 0;
			b && (_?.revision !== b.revision || !Q(v?.historyIds, b.historyIds) || v?.contentHeadOperationId !== b.contentHeadOperationId || !g && !y) && (x = g ? await this.getProjectForEditing(a.projectId, {
				signal: i,
				immutableView: !0
			}) : await this.getProject(a.projectId, { signal: i }), v = x ? this.readBaselines.get(x) : void 0);
			let S = t.worldPin ? await this.validationWorlds() : await this.validationWorlds({}, [a, ...x ? [x] : []], i), w = t.worldPin ? await Oo(a, t.worldPin, S) : {}, T = {
				...S,
				...w
			}, ee = Na(T);
			if (l("read"), !h && (x && x.revision !== a.revision || !x && a.revision !== "0")) throw new s("REVISION_CONFLICT", "別の編集が先に保存されています。現在版を読み直して変更を比較してください。", a.projectId);
			let E = v?.historyIds ?? b?.historyIds ?? [], te = h ? E.slice(0, E.indexOf(f)) : E, ne = g?.historyIds ?? a.history.map((e) => e.operationId), re = h ? x?.history.slice(0, x.history.findIndex((e) => e.operationId === f)) ?? [] : x?.history ?? [];
			if (!Q(te, ne) || !g && (re.length !== a.history.length || re.some((e, t) => !Q(e, a.history[t])))) throw new s("OPERATION_CONFLICT", "履歴は保存コマンドからのみ追加できます。");
			let ie = await D(ps({
				draft: h && !h.requestHashVersion ? a : $(a),
				...h && !h.requestHashVersion ? {} : { historyIds: ne },
				reason: t.reason,
				assets: (t.assets ?? []).map((e) => ({
					contentHash: e.contentHash,
					mediaType: e.mediaType,
					path: e.assetPath ?? null
				})),
				compensatesOperationId: t.compensatesOperationId ?? null,
				...t.worldPin ? { worldPins: w } : {}
			}));
			if (l("hash"), h) return this.duplicateResult(h, ie, a.projectId, i);
			if (!x && a.history.length) throw new s("OPERATION_CONFLICT", "既存履歴の復元には専用読み込みを使用してください。");
			if (!C.test(f) || t.compensatesOperationId && !C.test(t.compensatesOperationId)) throw new s("VALIDATION_FAILED", "操作IDは安定したUUIDで指定してください。");
			if (typeof t.reason != "string" || !t.reason.trim() || new TextEncoder().encode(t.reason).byteLength > 1048576) throw new s("VALIDATION_FAILED", "変更の理由を1 MiB以内で指定してください。");
			x && As(x, a);
			let O = {
				...a,
				entities: Es(x?.entities ?? [], a.entities, f, p),
				relations: Es(x?.relations ?? [], a.relations, f, p),
				revision: bs(a.revision)
			};
			if (x) {
				Ds(x, O), await ks(x, O);
				let e = new Map(x.snapshots.map((e) => [e.id, e]));
				O.snapshots = O.snapshots.map((t) => e.get(t.id) ?? t), O = await xi(x, O), O.entities = Es(x.entities, O.entities, f, p);
			}
			if (new Set(O.snapshots.map((e) => e.id)).size !== O.snapshots.length) throw new s("VALIDATION_FAILED", "公開版IDが重複しています。");
			l("reconcile"), O = Cs(O, ee, x, this.validationReferences);
			let ae = new Set(x?.snapshots.map((e) => e.id) ?? []), k = O.snapshots.filter((e) => !ae.has(e.id));
			k.length && (Ss({
				...O,
				history: []
			}, ee), await Fa([{
				...O,
				history: [],
				snapshots: k
			}])), Pa([{
				...O,
				history: []
			}], T), l("validate");
			let A = x ? $(x) : xs(a), j = $(O), oe = await Ps(A, j, !x), M = {
				operationId: f,
				projectId: O.projectId,
				baseRevision: a.revision,
				revision: O.revision,
				targetIds: oe.map((e) => e.targetId),
				reason: t.reason,
				createdAt: p,
				before: A,
				after: j,
				...t.compensatesOperationId ? { compensatesOperationId: t.compensatesOperationId } : {}
			};
			ms(M), O.history = ms(g ? [] : [...x?.history ?? [], M]), await ws(O, ee, !g, x ? {
				previous: x,
				references: this.validationReferences
			} : void 0);
			let se = [...E, f], N = v?.contentHeadOperationId, ce = !N || E.length % 64 == 0, { before: P, after: le, ...F } = M, ue = {
				operationId: f,
				projectId: O.projectId,
				revision: O.revision,
				requestHash: ie,
				requestHashVersion: 2,
				delta: {
					metadata: F,
					...ce ? { checkpoint: A } : { parentOperationId: N },
					patch: _s(A, j)
				}
			}, I = {
				entities: 0,
				relations: 0,
				blocks: 0,
				snapshots: 0,
				views: 0,
				commands: 1,
				outbox: 1
			};
			l("diff");
			let de = await this.db.transaction("rw", this.writeTables, async () => {
				if (ho(i), o(i), this.authorAccess && await this.db.syncBases.get(O.projectId) && this.authorAccess.get(O.projectId) !== "owner") throw new z("FORBIDDEN");
				let e = await this.db.commands.get(f);
				if (e) return {
					kind: "replay",
					command: e
				};
				let t = await this.db.projects.get(O.projectId);
				if (x ? !t || t.revision !== x.revision : t) throw new s("REVISION_CONFLICT", "保存中に現在版が変わりました。変更を比較して再試行してください。", O.projectId);
				(Object.keys(w).length || k.length) && await this.guardWorldRegistry([O, ...Object.values(w)]);
				for (let [e, t] of Object.entries(w)) {
					let n = await this.db.worlds.get(e), r = n?.project.snapshots.find((t) => t.id === e);
					if (n && !Q(r, t.snapshots[0])) throw new s("IMMUTABLE_SNAPSHOT", "保存中に共通世界の固定版が変わりました。", e);
					await this.writeAssets([], t, !1), n || await this.db.worlds.add({
						id: e,
						project: t
					}), await this.db.worldSources.put(await H.waitFor(Zt(e, n?.project ?? t)));
				}
				await this.writeAssets(m, O, !1), I = await this.writeContent(O, x, f, se), this.faultInjector?.("after-content"), wt(), await this.db.commands.add(ue), this.faultInjector?.("after-history");
				let n = await this.db.syncMetadata.get(O.projectId);
				return await this.db.outbox.add({
					operationId: f,
					projectId: O.projectId,
					accountId: this.accountId,
					baseRevision: n?.serverRevision ?? "0",
					localRevision: O.revision,
					createdAt: p,
					targetIds: M.targetIds,
					changes: oe.map(({ before: e, after: t, ...n }) => ({
						...n,
						...e === null ? { before: null } : {},
						...t === null ? { after: null } : {}
					})),
					commandOperationId: f
				}), await this.db.syncMetadata.put({
					projectId: O.projectId,
					serverRevision: n?.serverRevision ?? "0",
					state: "pending"
				}), this.faultInjector?.("after-outbox"), o(i), this.faultInjector?.("before-commit"), {
					kind: "saved",
					result: {
						project: O,
						operationId: f,
						localSaved: !0,
						pendingSync: !0
					}
				};
			}), fe = de.kind === "replay" ? await this.duplicateResult(de.command, ie, O.projectId, i) : de.result;
			l("database"), c.total = performance.now() - n, So(t.measurementStartedAt, f, c), fe.project === O && !i?.aborted && this.rememberProject(O, f, se, u);
			try {
				this.onSaveMetrics?.({
					operationId: f,
					projectId: O.projectId,
					milliseconds: c,
					written: I,
					historyRead: x === _ ? 0 : x?.history.length ?? 0
				});
			} catch {}
			if (g && t.includeHistory === !0) {
				let e = await this.db.commands.bulkGet(se), t = new Map(e.filter((e) => !!e).map((e) => [e.operationId, e])), n = /* @__PURE__ */ new Map();
				if (e.some((e) => !e)) throw new s("SAVE_FAILED", "保存した対象版の履歴を読み込めません。");
				let r = [];
				for (let i of e) r.push(await this.materializeCommand(i, t, n));
				return {
					...fe,
					project: {
						...hs(fe.project),
						history: r
					}
				};
			}
			return {
				...fe,
				project: g || t.includeHistory === !1 ? this.editingCopy(fe.project, fe.project === O ? se : fe.project.history.map((e) => e.operationId), t.immutableView) : hs(fe.project)
			};
		} catch (t) {
			let n = p(t);
			throw co(n, {
				accountId: this.accountId,
				operationId: r,
				revision: e.revision
			}), n;
		} finally {
			d && u && this.releaseCacheCapture(d, u);
		}
	}
	async duplicateResult(e, t, n, r) {
		if (e.projectId !== n || e.requestHash !== t) throw new s("OPERATION_CONFLICT", "同じ操作IDが異なる変更に使われています。", e.operationId);
		let i = await this.getProject(n, { signal: r });
		if (!i) throw new s("NOT_FOUND", "作品が見つかりません。", n);
		return {
			project: {
				...Z((i.history.find((t) => t.operationId === e.operationId) ?? await this.materializeCommand(e)).after),
				history: i.history.filter((t) => BigInt(t.revision) <= BigInt(e.revision))
			},
			operationId: e.operationId,
			localSaved: !0,
			pendingSync: !!await this.db.outbox.get(e.operationId)
		};
	}
	async undo(e, t) {
		let n = await this.getProject(e);
		if (!n) throw new s("NOT_FOUND", "作品が見つかりません。", e);
		let r = t ? n.history.find((e) => e.operationId === t) : n.history.at(-1);
		if (!r) throw new s("NOT_FOUND", "取り消せる履歴がありません。");
		let i = zs(n, r);
		return this.saveProject(i, {
			reason: `取り消し: ${r.reason}`,
			compensatesOperationId: r.operationId
		});
	}
	async previewRestoreEntity(e, t, n, r = "after") {
		let i = await this.getProjectForEditing(e), a = await this.historyCommand(e, t), o = a[r].entities.find((e) => e.id === n);
		if (!i || !a || !o) throw new s("NOT_FOUND", "指定した版の情報が見つかりません。", n);
		let c = i.entities.filter((e) => e.id !== n && be(e).some((e) => e.id === n)).map((e) => e.id);
		return {
			project: i,
			source: Z(o),
			referrers: c,
			warnings: c.length ? [`${c.length}件の参照があります。翻訳・音声・媒体版は内容の変更に応じて確認待ちになります。`] : []
		};
	}
	async restoreEntity(e, t, n, r = "after", i) {
		let a = await this.previewRestoreEntity(e, t, n, r), o = a.project;
		if (i !== void 0 && o.revision !== i) throw new s("REVISION_CONFLICT", "復元の影響確認後に作品が更新されました。選択を保持して再確認してください。");
		let c = o.entities.find((e) => e.id === n);
		return o.entities = o.entities.some((e) => e.id === n) ? o.entities.map((e) => e.id === n ? a.source : e) : [...o.entities, a.source], c && (o.entities = Ro(o.entities, c, a.source), o.relations = zo(o.relations, c, a.source)), this.saveProject(o, {
			reason: `履歴から単体復元: ${a.source.name}`,
			compensatesOperationId: t,
			includeHistory: !0
		});
	}
	async restoreRelation(e, t, n, r = "after", i) {
		let a = await this.getProjectForEditing(e), o = (await this.historyCommand(e, t))?.[r].relations.find((e) => e.id === n);
		if (!a || !o) throw new s("NOT_FOUND", "指定した版の関係が見つかりません。", n);
		if (i !== void 0 && a.revision !== i) throw new s("REVISION_CONFLICT", "復元の影響確認後に作品が更新されました。選択を保持して再確認してください。");
		return a.relations = a.relations.some((e) => e.id === n) ? a.relations.map((e) => e.id === n ? Z(o) : e) : [...a.relations, Z(o)], this.saveProject(a, {
			reason: "履歴から関係を単体復元",
			compensatesOperationId: t,
			includeHistory: !0
		});
	}
	async previewRestoreVersion(e, t, n = "after") {
		let r = await this.getProjectForEditing(e), i = await this.historyCommand(e, t);
		if (!r) throw new s("NOT_FOUND", "復元先の作品が見つかりません。");
		let a = i[n], o = Rs({
			...Z(a),
			revision: r.revision,
			history: r.history
		}, r), c = await Ps($(r), $(o)), l = {
			projectId: e,
			historyOperationId: t,
			side: n,
			baseRevision: r.revision,
			sourceRevision: a.revision,
			changes: c.map((e) => ({
				id: e.targetId,
				fields: e.fields.map((e) => e.field)
			}))
		};
		return {
			...l,
			confirmationHash: await D(ps(l))
		};
	}
	async restoreHistoryVersion(e, t) {
		let n = Z(t), r = await this.previewRestoreVersion(e, n.historyOperationId, n.side), { confirmationHash: i, ...a } = n;
		if (await D(ps(a)) !== i || e !== n.projectId || r.baseRevision !== n.baseRevision || r.confirmationHash !== n.confirmationHash) throw new s("REVISION_CONFLICT", "作品全体の復元差分が変わりました。対象操作と差分を再確認してください。");
		let o = await this.getProjectForEditing(e), c = await this.historyCommand(e, n.historyOperationId);
		if (!o || o.revision !== n.baseRevision) throw new s("REVISION_CONFLICT", "復元の確定前に作品が更新されました。");
		let l = Rs({
			...Z(c[n.side]),
			revision: o.revision,
			history: o.history
		}, o);
		return this.saveProject(l, {
			reason: `作品全体を操作 ${n.historyOperationId} の${n.side === "before" ? "変更前" : "変更後"}（版 ${n.sourceRevision}）へ復元`,
			compensatesOperationId: n.historyOperationId,
			includeHistory: !0
		});
	}
	async restoreRevision(e, t) {
		let [n, r] = await Promise.all([this.getProject(e), this.getProjectAtRevision(e, t)]);
		if (!n || !r) throw new s("NOT_FOUND", "復元する版が見つかりません。");
		let i = Rs({
			...r,
			revision: n.revision,
			history: n.history
		}, n);
		return this.saveProject(i, { reason: `作品全体をrevision ${t}から復元` });
	}
	async putAsset(e, t, n = "application/octet-stream") {
		let r = await this.checkedAssets([{
			contentHash: e,
			bytes: t,
			mediaType: n
		}]);
		try {
			await this.db.transaction("rw", this.db.assets, async () => {
				let t = await this.db.assets.get(e);
				if (t && !Is(t.bytes, r[0].bytes)) throw new s("HASH_MISMATCH", "既存hashの素材bytesが異なります。");
				await this.db.assets.put(r[0]);
			});
		} catch (e) {
			throw p(e);
		}
	}
	async getAsset(e) {
		return (await this.db.assets.get(e))?.bytes.slice();
	}
	async availableAssetHashes() {
		return new Set(await this.db.assets.toCollection().primaryKeys());
	}
	async materializeOutbox(e, t, n = /* @__PURE__ */ new Map()) {
		e = [...e].sort((e, t) => BigInt(e.localRevision) < BigInt(t.localRevision) ? -1 : BigInt(e.localRevision) > BigInt(t.localRevision) ? 1 : e.createdAt.localeCompare(t.createdAt));
		let r = [], i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new WeakMap(), o = (e, t) => {
			let n = i.get(e);
			if (n) return n.get(t) ?? null;
			let r = a.get(e);
			if (r || (r = /* @__PURE__ */ new Map(), a.set(e, r)), r.has(t)) return r.get(t);
			let o;
			if (e.length < 32 || r.size < 16) {
				o = null;
				for (let n = e.length - 1; n >= 0; n--) if (e[n].id === t) {
					o = e[n];
					break;
				}
			} else {
				let n = new Map(e.map((e) => [e.id, e]));
				i.size >= 4 && i.delete(i.keys().next().value), i.set(e, n), o = n.get(t) ?? null;
			}
			return r.size < 32 && r.set(t, o), o;
		}, c = (e, t) => t === e.projectId ? Ns(e) : o(e.relations, t) ?? o(e.entities, t);
		for (let i of e) {
			let e = i.commandOperationId ? t.get(i.commandOperationId) : void 0, a = i.command ?? (e ? await this.materializeCommand(e, t, n, /* @__PURE__ */ new Set(), !1) : void 0);
			if (!a || a.projectId !== i.projectId) throw new s("SAVE_FAILED", "送信待ちに必要な履歴が不足しています。", i.operationId);
			let { commandOperationId: o, ...l } = i;
			r.push({
				...l,
				command: a,
				changes: i.changes.map((e) => ({
					...e,
					before: Object.hasOwn(e, "before") ? e.before : c(a.before, e.targetId),
					after: Object.hasOwn(e, "after") ? e.after : c(a.after, e.targetId)
				}))
			});
		}
		return r;
	}
	async listOutbox(e) {
		let t = await this.db.transaction("r", ["outbox", "commands"], async () => ({
			rows: await this.db.outbox.where("projectId").equals(e).toArray(),
			commands: await this.db.commands.where("projectId").equals(e).toArray()
		}));
		return this.materializeOutbox(t.rows, new Map(t.commands.map((e) => [e.operationId, e])));
	}
	async getSaveState(e) {
		return this.db.transaction("r", this.writeTables, async () => {
			let [t, n, r, i, a] = await Promise.all([
				(async () => {
					let t = await this.db.projects.get(e), n = this.cachedProjects.get(e);
					if (t) {
						if (t.projectId !== e) throw new s("SAVE_FAILED", "作品の保存情報が別の作品を指しています。", e);
						return n?.revision === t.revision && Q(this.cachedHistoryIds.get(e), t.historyIds) ? { project: {
							...n,
							history: []
						} } : this.readProject(e, !1, void 0, t);
					}
				})(),
				this.db.syncMetadata.get(e),
				this.db.outbox.where("projectId").equals(e).count(),
				this.db.recoveredPending.where("projectId").equals(e).count(),
				this.db.syncAssetAcks.where("projectId").equals(e).toArray()
			]), o = t ? ja(t.project, await this.validationWorlds()).filter((e) => !a.some((t) => t.contentHash === e.contentHash && t.byteSize === e.byteSize && t.mediaType === e.mediaType)).length : 0;
			return {
				localSaved: !!t,
				pendingCount: r,
				recoveredPendingCount: i,
				pendingAssetCount: o,
				serverRevision: n?.serverRevision ?? "0",
				syncState: n?.state === "conflict" ? "conflict" : r || o ? "pending" : n?.state ?? "pending"
			};
		});
	}
	async getAssetSyncAck(e, t) {
		return Z(await this.db.syncAssetAcks.get(`${e}:${t}`));
	}
	async confirmAssetUpload(e, t) {
		this.syncScope(e);
		let n = Z(t), r = await this.getAsset(n.contentHash);
		if (!r || r.byteLength !== n.bytes || await D(r) !== n.contentHash) throw new z("PROTOCOL_INVALID");
		let i = {
			key: `${e}:${n.contentHash}`,
			projectId: e,
			contentHash: n.contentHash,
			byteSize: n.bytes,
			mediaType: n.mediaType
		};
		await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.syncAssetAcks.get(i.key);
			if (e && !L(e, i)) throw new z("PROTOCOL_INVALID");
			await this.db.syncAssetAcks.put(i), this.faultInjector?.("before-commit");
		});
	}
	async listRetainedSyncRecovery(e) {
		return Z(await this.db.retainedSyncRecovery.where("projectId").equals(e).toArray());
	}
	async listAuthorToolDrafts() {
		return Z(await this.db.authorToolDrafts.toArray());
	}
	async saveSharedSnapshot(e) {
		let { validateSharedSnapshot: t } = await import("./publicShare-DXmMxZ5a.js"), n = await t(Z(e)), r = await this.db.sharedSnapshots.get(n.id);
		if (r && r.contentHash !== n.contentHash) throw new z("PROTOCOL_INVALID");
		await this.db.sharedSnapshots.put(n);
	}
	async listSharedSnapshots() {
		return Z(await this.db.sharedSnapshots.toArray());
	}
	async discardSharedSnapshot(e) {
		await this.db.sharedSnapshots.delete(e);
	}
	async listRecoveredPending(e) {
		return Z((await this.db.recoveredPending.where("projectId").equals(e).toArray()).sort((e, t) => e.sequence - t.sequence));
	}
	async commitAck(e, t) {
		if (t.projectId !== e || !/^(?:0|[1-9]\d*)$/.test(t.serverRevision) || !["applied", "conflict"].includes(t.status)) throw new s("VALIDATION_FAILED", "同期ackの作品・revision・結果が不正です。");
		try {
			await this.db.transaction("rw", [
				"outbox",
				"acks",
				"syncMetadata"
			], async () => {
				let n = await this.db.acks.get(t.operationId);
				if (n) {
					if (!P(n, t)) throw new s("OPERATION_CONFLICT", "同じ操作に異なるackが届きました。");
					return;
				}
				let r = await this.db.outbox.get(t.operationId), i = await this.db.syncMetadata.get(e);
				if (!r || r.projectId !== e || r.accountId !== this.accountId) throw new s("NOT_FOUND", "この領域の送信待ち操作が見つかりません。");
				if (i && BigInt(t.serverRevision) < BigInt(i.serverRevision)) throw new s("REVISION_CONFLICT", "古いサーバーrevisionのackです。");
				await this.db.acks.add(Z(t)), t.status === "applied" && await this.db.outbox.delete(t.operationId);
				let a = await this.db.outbox.where("projectId").equals(e).count();
				await this.db.syncMetadata.put({
					projectId: e,
					serverRevision: t.serverRevision,
					state: t.status === "conflict" ? "conflict" : a ? "pending" : "synced"
				});
			});
		} catch (e) {
			throw p(e);
		}
	}
	syncScope(e) {
		if (!this.accountId || this.accountId === "guest") throw new z("AUTH_REQUIRED");
		return {
			accountId: this.accountId,
			projectId: e
		};
	}
	async bindConfirmedProject(e) {
		let t = Z(e), n = this.syncScope(t.projectId);
		if (!/^(0|[1-9]\d*)$/.test(t.serverRevision) || !t.documents.length || t.documents.length > 100001) throw new z("PROTOCOL_INVALID");
		let r = /* @__PURE__ */ new Set();
		for (let e of t.documents) {
			if (we(e, n, e.id), r.has(e.id) || BigInt(e.revision) > BigInt(t.serverRevision)) throw new z("PROTOCOL_INVALID");
			r.add(e.id);
		}
		if (await Ee(t.documents) !== t.contentHash) throw new z("PROTOCOL_INVALID");
		let i = await this.getProject(t.projectId);
		if (!i || i.revision !== t.localRevision) throw new z("REVISION_CHANGED");
		let a = Hn(i, t.documents, (/* @__PURE__ */ new Date()).toISOString()), o = await this.validationWorlds();
		if (Ss(a, Na(o)), await Fa([a]), await ws(a, Na(o)), !L(zn(i, t.serverRevision).map(({ revision: e, ...t }) => t), t.documents.map(({ revision: e, ...t }) => t))) throw new z("REVISION_CHANGED");
		await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.projects.get(t.projectId);
			if (!e || e.revision !== t.localRevision || await this.db.preparedSync.where("projectId").equals(t.projectId).count() || await this.db.syncConflicts.where("projectId").equals(t.projectId).count()) throw new z("REVISION_CHANGED");
			for (let e of t.outboxIds) {
				let n = await this.db.outbox.get(e);
				if (!n || n.projectId !== t.projectId || n.accountId !== this.accountId || BigInt(n.localRevision) > BigInt(t.localRevision)) throw new z("PROTOCOL_INVALID");
			}
			await this.db.syncBases.put({
				projectId: t.projectId,
				serverRevision: t.serverRevision,
				documents: t.documents,
				contentHash: t.contentHash
			}), await this.db.outbox.bulkDelete(t.outboxIds), await this.db.syncMetadata.put({
				projectId: t.projectId,
				serverRevision: t.serverRevision,
				state: await this.db.outbox.where("projectId").equals(t.projectId).count() ? "pending" : "synced"
			}), this.faultInjector?.("before-commit");
		});
	}
	async getConfirmedSyncBase(e) {
		return this.syncScope(e), Z(await this.db.syncBases.get(e));
	}
	async bindBootstrapBase(e, t) {
		let n = Z(e), r = Z(t), i = this.syncScope(n.projectId), a = zn(n, r.serverRevision);
		if (!L(a, r.documents) || await Ee(a) !== r.contentHash) throw new z("PROTOCOL_INVALID");
		let o = await this.validationWorlds();
		Ss(n, Na(o)), await Fa([n]), await ws(n, Na(o)), await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.projects.get(i.projectId);
			if (!e || BigInt(e.revision) < BigInt(n.revision) || await this.db.syncBases.get(i.projectId) || await this.db.preparedSync.where("projectId").equals(i.projectId).count()) throw new z("REVISION_CHANGED");
			for (let e of r.outboxIds) {
				let t = await this.db.outbox.get(e);
				if (!t || t.accountId !== this.accountId || t.projectId !== i.projectId || BigInt(t.localRevision) > BigInt(n.revision)) throw new z("PROTOCOL_INVALID");
			}
			await this.db.syncBases.put({
				projectId: i.projectId,
				serverRevision: r.serverRevision,
				documents: a,
				contentHash: r.contentHash
			}), await this.db.outbox.bulkDelete(r.outboxIds), await this.db.syncMetadata.put({
				projectId: i.projectId,
				serverRevision: r.serverRevision,
				state: await this.db.outbox.where("projectId").equals(i.projectId).count() ? "pending" : "synced"
			}), this.faultInjector?.("before-commit");
		});
	}
	async applyReceivedImage(e, t) {
		let n = Z(t), r = this.syncScope(e), [i, a, o, s] = await Promise.all([
			this.db.syncBases.get(e),
			this.getProject(e),
			this.listPreparedOperations(e),
			this.listPreparedConflicts(e)
		]);
		if (!i || !a) throw new z("BASE_UNAVAILABLE");
		if (o.length || s.length) throw new z("REVISION_CHANGED");
		if (BigInt(n.serverRevision) < BigInt(i.serverRevision) || await Ee(n.documents) !== n.contentHash) throw new z("PROTOCOL_INVALID");
		let c = new Map(i.documents.map((e) => [e.id, e])), l = n.documents.filter((e) => !Bn(c.get(e.id), e)).map((e) => ({
			base: c.get(e.id) ?? null,
			local: c.get(e.id) ?? e
		}));
		if (!l.length) {
			let t = i.documents.find((t) => t.id === e);
			if (!t) throw new z("PROTOCOL_INVALID");
			l.push({
				base: t,
				local: t
			});
		}
		let u = await Te({
			scope: r,
			baseRevision: i.serverRevision,
			operationId: j(),
			targets: l,
			reason: "認証した接続先の確定版を取得して端末の後発編集を保持"
		}), d = {
			schemaVersion: 1,
			operationId: u.operationId,
			scope: r,
			operationHash: await Ee(u),
			status: "applied",
			serverRevision: n.serverRevision,
			documents: l.map((e) => n.documents.find((t) => t.id === e.local.id)),
			confirmedDocuments: n.documents,
			conflicts: []
		};
		await Ln(u, d), await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.projects.get(e), n = await this.db.syncBases.get(e);
			if (t?.revision !== a.revision || !L(n, i) || await this.db.preparedSync.where("projectId").equals(e).count() || await this.db.syncConflicts.where("projectId").equals(e).count()) throw new z("REVISION_CHANGED");
			await this.db.preparedSync.add({
				operationId: u.operationId,
				projectId: e,
				operation: u,
				localRevision: a.revision,
				localDocuments: i.documents,
				outboxIds: [],
				origin: "received_image",
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			});
		}), await this.commitPreparedAck(e, d, n.worlds);
	}
	async prepareSavedOperations(e, t = "端末の保存待ちを確定共通元から準備") {
		let n = this.syncScope(e), r = await this.db.transaction("r", this.writeTables, async () => ({
			base: await this.db.syncBases.get(e),
			current: await this.readProject(e, !1),
			pending: await this.db.preparedSync.where("projectId").equals(e).toArray(),
			conflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray(),
			outbox: await this.db.outbox.where("projectId").equals(e).toArray()
		}));
		if (r.pending.length) return Z(r.pending[0].operation);
		if (r.conflicts.length) throw new z("REVISION_CHANGED");
		if (!r.base || !r.current) throw new z("BASE_UNAVAILABLE");
		let i = await Un(n, r.base, r.current.project, r.outbox.map((e) => e.operationId), t);
		return await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.projects.get(e), n = await this.db.syncBases.get(e);
			if (t?.revision !== r.current.project.revision || n?.contentHash !== r.base.contentHash || n?.serverRevision !== r.base.serverRevision || await this.db.preparedSync.where("projectId").equals(e).count() || await this.db.syncConflicts.where("projectId").equals(e).count()) throw new z("REVISION_CHANGED");
			i ? await this.db.preparedSync.add(i) : (await this.db.outbox.bulkDelete(r.outbox.map((e) => e.operationId)), await this.db.syncMetadata.put({
				projectId: e,
				serverRevision: r.base.serverRevision,
				state: "synced"
			})), this.faultInjector?.("before-commit");
		}), i ? Z(i.operation) : null;
	}
	async listPreparedOperations(e) {
		return this.syncScope(e), Z((await this.db.preparedSync.where("projectId").equals(e).toArray()).map((e) => e.operation));
	}
	async listPreparedConflicts(e) {
		return this.syncScope(e), Z((await this.db.syncConflicts.where("projectId").equals(e).toArray()).map((e) => ({
			operationId: e.operationId,
			conflicts: e.conflicts
		})));
	}
	async listSyncConflictAlternatives(e) {
		return this.syncScope(e), Z(await this.db.syncConflicts.where("projectId").equals(e).toArray());
	}
	async listSyncAckEvidence(e) {
		return this.syncScope(e), Z(await this.db.syncAckEvidence.where("projectId").equals(e).toArray());
	}
	async commitPreparedAck(e, t, n = {}) {
		let r = Z(n);
		await this.guardWorldRegistry(Object.values(r)), await Fa(Object.values(r));
		let i = this.syncScope(e), a = Z(t);
		if (!L(i, a.scope)) throw new z("PROTOCOL_INVALID");
		let o = await this.db.transaction("r", this.writeTables, async () => ({
			prepared: await this.db.preparedSync.get(a.operationId),
			previousAck: await this.db.syncAckEvidence.get(a.operationId),
			base: await this.db.syncBases.get(e),
			current: await this.readProject(e),
			conflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray()
		}));
		if (o.previousAck) {
			if (!L(o.previousAck.ack, a)) throw new z("OPERATION_REUSED");
			return;
		}
		if (!o.prepared || o.prepared.projectId !== e || !o.base || !o.current || o.base.serverRevision !== o.prepared.operation.baseRevision) throw new z("BASE_UNAVAILABLE");
		await Ln(o.prepared.operation, a);
		let c = o.current.project, l = (/* @__PURE__ */ new Date()).toISOString(), u = c, d, f, p;
		if (a.status === "applied") {
			let t = Wn(o.prepared, o.base, a, c);
			f = {
				projectId: e,
				serverRevision: a.serverRevision,
				documents: t.confirmed,
				contentHash: await Ee(t.confirmed)
			};
			let n = Hn(c, t.documents, l);
			if (Ds(c, n), await ks(c, n), n = await xi(c, n), n = as(c, n), n.entities = Es(c.entities, n.entities, a.operationId, l), n.relations = Es(c.relations, n.relations, a.operationId, l), !Q($(n), $(c))) {
				n.revision = bs(c.revision);
				let t = $(c), r = $(n), i = await Ps(t, r), o = j(), s = {
					operationId: o,
					projectId: e,
					baseRevision: c.revision,
					revision: n.revision,
					targetIds: i.map((e) => e.targetId),
					reason: `同期ackを端末確定: ${a.operationId}`,
					createdAt: l,
					before: t,
					after: r
				};
				n.history = [...c.history, s], d = {
					operationId: o,
					projectId: e,
					revision: n.revision,
					record: s
				}, u = n;
			}
			let i = await this.validationWorlds(r);
			Ss(u, Na(i)), Pa([u], i), await Fa([u]), await ws(u, Na(i)), t.conflicts.length && (p = {
				operationId: a.operationId,
				projectId: e,
				prepared: o.prepared,
				ack: a,
				conflicts: t.conflicts,
				createdAt: l
			});
		}
		await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.syncAckEvidence.get(a.operationId);
			if (t) {
				if (!L(t.ack, a)) throw new z("OPERATION_REUSED");
				return;
			}
			let n = await this.db.projects.get(e), i = await this.db.syncBases.get(e), m = await this.db.preparedSync.get(a.operationId);
			if (n?.revision !== c.revision || i?.contentHash !== o.base.contentHash || i?.serverRevision !== o.base.serverRevision || !L(m, o.prepared)) throw new z("REVISION_CHANGED");
			if (a.status === "conflict") await this.db.syncConflicts.put({
				operationId: a.operationId,
				projectId: e,
				prepared: o.prepared,
				ack: a,
				conflicts: a.conflicts,
				createdAt: l
			});
			else {
				Object.keys(r).length && await this.guardWorldRegistry(Object.values(r));
				for (let [e, t] of Object.entries(r)) {
					let n = await this.db.worlds.get(e);
					if (n && !P(n.project, t)) throw new s("IMMUTABLE_SNAPSHOT", "固定世界の取得内容が保存済み版と異なります。");
					await this.db.worlds.put({
						id: e,
						project: t
					}), await this.db.worldSources.put(await H.waitFor(Zt(e, t)));
				}
				if (d && (await this.writeContent(u, c, d.operationId), this.faultInjector?.("after-content"), wt(), await this.db.commands.add(d), this.faultInjector?.("after-history")), await this.db.syncBases.put(f), await this.db.outbox.bulkDelete(o.prepared.outboxIds), o.prepared.operation.resolvesOperationId) {
					let e = await this.db.syncConflicts.get(o.prepared.operation.resolvesOperationId);
					if (!e || [...e.prepared.operation.targets.map((e) => e.targetId), ...e.conflicts.map((e) => e.targetId)].some((e) => !o.prepared.operation.targets.some((t) => t.targetId === e))) throw new z("PROTOCOL_INVALID");
					await this.db.syncConflicts.delete(e.operationId);
				}
				p && await this.db.syncConflicts.put(p);
			}
			await this.db.syncAckEvidence.add({
				operationId: a.operationId,
				projectId: e,
				operation: o.prepared.operation,
				ack: a,
				origin: o.prepared.origin ?? "prepared_operation",
				createdAt: l
			}), await this.db.preparedSync.delete(a.operationId), await this.db.syncMetadata.put({
				projectId: e,
				serverRevision: f?.serverRevision ?? o.base.serverRevision,
				state: await this.db.syncConflicts.where("projectId").equals(e).count() ? "conflict" : await this.db.outbox.where("projectId").equals(e).count() ? "pending" : "synced"
			}), this.faultInjector?.("after-outbox"), this.faultInjector?.("before-commit");
		}), this.invalidateProjectCache(e);
	}
	async previewSyncResolution(e, t, n) {
		let r = Z(n), i = this.syncScope(e), [a, o, s] = await Promise.all([
			this.db.syncConflicts.get(t),
			this.db.syncBases.get(e),
			this.getProject(e)
		]);
		if (!a || a.projectId !== e || !o || !s) throw new z("BASE_UNAVAILABLE");
		let c = Z(a.ack.confirmedDocuments);
		if (!c) throw new z("PROTOCOL_INVALID");
		for (let e of a.ack.documents) if (e) {
			let t = c.findIndex((t) => t.id === e.id);
			t >= 0 ? c[t] = Z(e) : c.push(Z(e));
		}
		let l = Gn(a, r, c, s), u = await Te({
			scope: i,
			baseRevision: a.ack.serverRevision,
			operationId: j(),
			targets: l,
			reason: "共通元・二案と参照への影響を確認して競合解決",
			resolvesOperationId: t
		}), d = new Map(c.map((e) => [e.id, e]));
		for (let e of l) d.set(e.local.id, e.local);
		let f = Hn(s, [...d.values()], (/* @__PURE__ */ new Date()).toISOString()), p = await this.validationWorlds();
		Ss(f, Na(p)), await Fa([f]), await ws(f, Na(p));
		let m = {
			projectId: e,
			operationId: t,
			localRevision: s.revision,
			serverRevision: a.ack.serverRevision,
			baseHash: o.contentHash,
			conflictHash: await Ee(a),
			choices: r,
			operation: u,
			candidate: f
		};
		return {
			...m,
			confirmationHash: await Ee(m)
		};
	}
	async confirmSyncResolution(e) {
		let t = Z(e), { confirmationHash: n, ...r } = t;
		if (this.syncScope(t.projectId), await Ee(r) !== n) throw new z("PROTOCOL_INVALID");
		let i = await this.previewSyncResolution(t.projectId, t.operationId, t.choices);
		if (i.localRevision !== t.localRevision || i.baseHash !== t.baseHash || i.conflictHash !== t.conflictHash || i.serverRevision !== t.serverRevision) throw new z("REVISION_CHANGED");
		if (!L({
			...i.operation,
			operationId: t.operation.operationId
		}, t.operation) || !L(i.candidate, t.candidate)) throw new z("PROTOCOL_INVALID");
		let [a, o, s] = await Promise.all([
			this.getProject(t.projectId),
			this.db.syncBases.get(t.projectId),
			this.db.syncConflicts.get(t.operationId)
		]);
		if (!a || !o || !s) throw new z("BASE_UNAVAILABLE");
		let c = Z(s.ack.confirmedDocuments);
		if (!c) throw new z("PROTOCOL_INVALID");
		let l = {
			projectId: t.projectId,
			serverRevision: t.serverRevision,
			documents: c,
			contentHash: await Ee(c)
		}, u = (/* @__PURE__ */ new Date()).toISOString(), d = j(), f = {
			...t.candidate,
			revision: bs(a.revision)
		};
		Ds(a, f), await ks(a, f), f = await xi(a, f), f = as(a, f), f.entities = Es(a.entities, f.entities, d, u), f.relations = Es(a.relations, f.relations, d, u);
		let p = await this.validationWorlds();
		Ss(f, Na(p)), await Fa([f]), await ws(f, Na(p));
		let m = await Ps($(a), $(f)), h = {
			operationId: d,
			projectId: t.projectId,
			baseRevision: a.revision,
			revision: f.revision,
			targetIds: m.map((e) => e.targetId),
			reason: `競合の共通元・二案から明示選択: ${t.operationId}`,
			createdAt: u,
			before: $(a),
			after: $(f)
		};
		return f.history = [...a.history, h], await this.db.transaction("rw", this.writeTables, async () => {
			let [e, n, r] = await Promise.all([
				this.db.projects.get(t.projectId),
				this.db.syncBases.get(t.projectId),
				this.db.syncConflicts.get(t.operationId)
			]);
			if (e?.revision !== t.localRevision || !L(n, o) || !L(r, s) || await this.db.preparedSync.where("projectId").equals(t.projectId).count()) throw new z("REVISION_CHANGED");
			await this.writeContent(f, a, d), wt(), await this.db.commands.add({
				operationId: d,
				projectId: t.projectId,
				revision: f.revision,
				record: h
			}), await this.db.outbox.add({
				operationId: d,
				projectId: t.projectId,
				accountId: this.accountId,
				baseRevision: t.serverRevision,
				localRevision: f.revision,
				targetIds: h.targetIds,
				changes: m,
				command: h,
				createdAt: u
			}), await this.db.syncBases.put(l);
			let i = (await this.db.outbox.where("projectId").equals(t.projectId).toArray()).map((e) => e.operationId);
			await this.db.preparedSync.add({
				operationId: t.operation.operationId,
				projectId: t.projectId,
				operation: t.operation,
				localRevision: f.revision,
				localDocuments: zn(f, t.serverRevision),
				outboxIds: i,
				createdAt: u
			}), this.faultInjector?.("before-commit");
		}), this.invalidateProjectCache(t.projectId), Z(t.operation);
	}
	async getViewState(e, t, n, r) {
		let i = await this.db.viewStates.get(A([
			e,
			t,
			n,
			r
		]));
		if (!i) return;
		let { key: a, projectId: o, ...s } = i;
		return s;
	}
	async saveViewState(e, t) {
		await this.db.viewStates.put({
			...Z(t),
			projectId: e,
			key: A([
				e,
				t.userId,
				t.deviceClass,
				t.viewId
			])
		});
	}
	async createRestorePoint(e, t) {
		return this.db.transaction("rw", this.writeTables, async () => {
			let n = (await this.readProject(e))?.project;
			if (!n) throw new s("NOT_FOUND", "復元点を作る作品が見つかりません。");
			await H.waitFor(this.writeAssets([], n, !0));
			let r = {
				id: j(),
				projectId: e,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				reason: t,
				project: n,
				assetHashes: Oa(n).map((e) => e.contentHash)
			};
			return await this.db.restorePoints.add(r), r;
		});
	}
	async listRestorePoints(e) {
		return this.db.restorePoints.where("projectId").equals(e).reverse().toArray();
	}
	async restorePointPage(e, t = 0, n = 30) {
		n = Math.max(1, Math.min(60, Number.isSafeInteger(n) ? n : 30));
		let r = await this.db.restorePoints.where("projectId").equals(e).count(), i = Math.max(0, Math.ceil(r / n) - 1);
		return t = Math.max(0, Math.min(i, Number.isSafeInteger(t) ? t : 0)), {
			entries: (await this.db.restorePoints.where("projectId").equals(e).offset(t * n).limit(n).toArray()).map(({ id: e, createdAt: t, reason: n, project: r, assetHashes: i }) => ({
				id: e,
				createdAt: t,
				reason: n,
				revision: r.revision,
				assetCount: i.length
			})),
			total: r,
			page: t,
			maximum: i,
			size: n
		};
	}
	async previewRestorePoint(e, t) {
		let [n, r] = await Promise.all([this.db.restorePoints.get(t), this.getProjectForEditing(e)]);
		if (!n || n.projectId !== e || !r) throw new s("NOT_FOUND", "この作品の復元点が見つかりません。");
		let i = Rs({
			...Z(n.project),
			revision: r.revision,
			history: r.history
		}, r), a = await Ps($(r), $(i)), o = {
			projectId: e,
			restorePointId: t,
			baseRevision: r.revision,
			sourceRevision: n.project.revision,
			pointHash: await D(ps(n.project)),
			changes: a.map((e) => ({
				id: e.targetId,
				fields: e.fields.map((e) => e.field)
			}))
		};
		return {
			...o,
			confirmationHash: await D(ps(o))
		};
	}
	async restorePoint(e, t, n) {
		if (n) {
			let { confirmationHash: r, ...i } = Z(n), a = await this.previewRestorePoint(e, t);
			if (i.projectId !== e || i.restorePointId !== t || await D(ps(i)) !== r || a.confirmationHash !== r) throw new s("REVISION_CONFLICT", "復元点の影響確認後に作品または差分が更新されました。選択を保持して再確認してください。");
		}
		let [r, i] = await Promise.all([this.db.restorePoints.get(t), this.getProject(e)]);
		if (!r || r.projectId !== e || !i) throw new s("NOT_FOUND", "この作品の復元点が見つかりません。");
		if (n && i.revision !== n.baseRevision) throw new s("REVISION_CONFLICT", "復元点の確定前に作品が更新されました。");
		let a = Rs({
			...Z(r.project),
			revision: i.revision,
			history: i.history
		}, i);
		return this.saveProject(a, { reason: `復元点から作品全体を復元: ${r.reason}` });
	}
	async migrateProject(e, t) {
		let n = await this.createRestorePoint(e, "形式移行前の復元点"), r = await this.validationWorlds(), i = Ss(await t(Z(n.project)), Na(r));
		if (i.projectId !== e) throw new s("VALIDATION_FAILED", "移行で作品IDを変更できません。");
		return i.revision = n.project.revision, i.history = n.project.history, this.saveProject(i, { reason: "検証済みの形式移行" });
	}
	async exportProject(e, t = {}) {
		t = { ...t }, o(t.signal);
		let n = await this.db.transaction("r", this.writeTables, async () => {
			ho(t.signal), o(t.signal);
			let n = H.currentTransaction, r = () => n?.abort();
			t.signal?.addEventListener("abort", r, { once: !0 });
			try {
				return o(t.signal), {
					current: await this.readProject(e, !1, void 0, void 0, t.signal),
					commands: await this.db.commands.where("projectId").equals(e).toArray(),
					rows: await this.db.outbox.where("projectId").equals(e).toArray(),
					retained: await this.listRecoveredPending(e),
					metadata: await this.db.syncMetadata.get(e),
					syncBase: await this.db.syncBases.get(e),
					syncPrepared: await this.db.preparedSync.where("projectId").equals(e).toArray(),
					syncConflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray(),
					syncAcks: await this.db.syncAckEvidence.where("projectId").equals(e).toArray(),
					syncAssetAcks: await this.db.syncAssetAcks.where("projectId").equals(e).toArray(),
					syncRetained: await this.db.retainedSyncRecovery.where("projectId").equals(e).toArray(),
					registry: await this.validationWorlds()
				};
			} finally {
				t.signal?.removeEventListener("abort", r);
			}
		}).catch((e) => {
			throw o(t.signal), e;
		});
		if (o(t.signal), !n.current) throw new s("NOT_FOUND", "書き出す作品が見つかりません。");
		let r = new Map(n.commands.map((e) => [e.operationId, e])), i = /* @__PURE__ */ new Map(), a = [];
		for (let e of n.current.historyIds) {
			o(t.signal);
			let n = r.get(e);
			if (!n) throw new s("SAVE_FAILED", "完全保存に必要な履歴が不足しています。", e);
			a.push(await this.materializeCommand(n, r, i, /* @__PURE__ */ new Set(), !1)), await new Promise((e) => setTimeout(e, 0)), o(t.signal);
		}
		let c = {
			...n.current.project,
			history: a
		}, l = await this.materializeOutbox(n.rows, r, i), u = t.snapshotId ? c.snapshots.find((e) => e.id === t.snapshotId) : void 0;
		if (t.snapshotId && !u) throw new s("NOT_FOUND", "書き出す固定版が見つかりません。");
		let d = u ? {
			...Z(u.content),
			snapshots: c.snapshots,
			history: c.history.filter((e) => BigInt(e.revision) <= BigInt(u.content.revision))
		} : c, f = t.snapshotId ? [] : l, p = t.snapshotId ? [] : n.retained;
		await b({
			project: d,
			pending: f,
			retained: p
		}, t.signal);
		let m = f.map((e) => ({
			operationId: e.operationId,
			command: e.command,
			baseRevision: e.baseRevision
		})), h = p.map((e) => e.operation), g = t.snapshotId ? [] : n.syncRetained.map((e) => e.evidence);
		if (!t.snapshotId && (n.syncBase || n.syncPrepared.length || n.syncConflicts.length || n.syncAcks.length)) {
			let e = {
				format: "scenario-sync-recovery",
				version: 1,
				state: "needs_reconnect",
				origin: {
					...d,
					history: []
				},
				...n.syncBase ? { base: n.syncBase } : {},
				prepared: n.syncPrepared,
				conflicts: n.syncConflicts,
				acknowledgements: n.syncAcks,
				assetAcknowledgements: n.syncAssetAcks
			}, t = {
				...e,
				contentHash: await Ee(e)
			};
			g.some((e) => e.contentHash === t.contentHash) || g.push(t);
		}
		let _ = {
			project: d,
			pending: m,
			retained: h,
			serverRevision: n.metadata?.serverRevision ?? "0",
			worlds: {},
			availableWorlds: n.registry,
			syncRecovery: g
		};
		return await b(_, t.signal), Eo(await jn(_, t.signal), {
			...t,
			loadAsset: (e) => this.getAsset(e)
		});
	}
	async previewImport(e, t) {
		let n = Z(e), r = {
			...t,
			idMap: t.idMap ? Z(t.idMap) : void 0,
			resolutions: t.resolutions ? Z(t.resolutions) : void 0
		};
		o(r.signal);
		let i = n.project, a = r.targetProjectId ?? i.projectId, c = await this.getProject(a, { signal: r.signal }), l = c ? (await this.listOutbox(a)).length : 0;
		if (o(r.signal), r.mode === "new") return {
			conflicts: c ? [{
				id: a,
				kind: "project",
				existing: c,
				incoming: i
			}] : [],
			pendingChanges: l,
			target: c,
			additions: i.entities.length + i.relations.length
		};
		if (r.mode === "clone") return {
			conflicts: [],
			pendingChanges: 0,
			additions: i.entities.length + i.relations.length
		};
		if (!c) throw new s("NOT_FOUND", "置換・統合する既存作品が見つかりません。", a);
		if (r.mode === "mapped_merge") {
			if (!r.idMap) throw new s("IMPORT_CONFLICT", "別作品の統合には全IDの明示対応表が必要です。");
			let e = (await To({
				step: "mapped_plan",
				project: i,
				worlds: {},
				target: c,
				idMap: r.idMap,
				resolutions: r.resolutions,
				mapped: {
					source: n,
					knownWorlds: await this.validationWorlds(n.worlds)
				}
			}, {
				signal: r.signal,
				loadAsset: (e) => this.getAsset(e)
			})).mappedPlan, t = n.recovery ? await Ls(n.recovery, e.mappedProject, e.idMap, r.signal) : void 0, o = new Set(n.project.history.map((t) => e.idMap[t.operationId]));
			e.mappedProject.history = e.mappedProject.history.filter((e) => o.has(e.operationId));
			let u = await D(ps({
				sourceContentHash: e.sourceContentHash,
				manifest: n.manifest,
				targetId: a,
				targetRevision: c.revision,
				idMap: e.idMap,
				resolutions: r.resolutions ?? {},
				changes: e.changes,
				assets: e.assets
			}));
			return {
				conflicts: e.conflicts,
				pendingChanges: l,
				target: c,
				additions: e.changes.filter((e) => e.action === "add").length,
				mappedPlan: e,
				mappedRecovery: t,
				confirmationHash: u
			};
		}
		if (a !== i.projectId) throw new s("IMPORT_CONFLICT", "置換・統合は同じprojectIdが必要です。別の作品には複製して追加してください。", a);
		let u = (await To({
			step: "merge_conflicts",
			project: i,
			worlds: {},
			target: c
		}, { signal: r.signal })).conflicts, d = new Set([...c.entities, ...c.relations].map((e) => e.id));
		return {
			conflicts: u,
			pendingChanges: l,
			target: c,
			additions: [...i.entities, ...i.relations].filter((e) => !d.has(e.id)).length
		};
	}
	async saveImportDraft(e) {
		if (!e.key || e.bytes && e.bytes.byteLength > 67108864) throw new s("LIMIT_EXCEEDED", "復元入力の一時保存上限を超えています。");
		let t = Z(e);
		if (t.bytes && await D(t.bytes) !== t.sourceHash) throw new s("HASH_MISMATCH", "復元入力の元ファイルが変わっています。");
		try {
			await this.db.transaction("rw", this.db.importDrafts, async () => {
				let e = await this.db.importDrafts.get(t.key);
				!t.bytes && e && e.sourceHash === t.sourceHash && (t.bytes = e.bytes), await this.db.importDrafts.put(t);
			});
		} catch (e) {
			throw p(e);
		}
	}
	async getImportDraft(e) {
		let t = await this.db.importDrafts.get(e);
		return t ? Z(t) : void 0;
	}
	async clearImportDraft(e) {
		await this.db.importDrafts.delete(e);
	}
	async saveAuthorToolDraft(e) {
		let t = Z(e);
		if (!t.key || !C.test(t.projectId) || !/^\d+$/.test(t.baseRevision) || ps(t.fields).byteLength > 1048576 || t.asset && t.asset.bytes.byteLength > 33554432) throw new s("LIMIT_EXCEEDED", "制作入力の一時保存上限または作品識別が不正です。");
		if (t.asset && await D(t.asset.bytes) !== t.asset.contentHash) throw new s("HASH_MISMATCH", "制作入力の素材bytesが変わっています。");
		try {
			await this.db.authorToolDrafts.put(t);
		} catch (e) {
			throw p(e);
		}
	}
	async restoreAuthorToolDrafts(e, t) {
		let n = Z(e), r = Z(t);
		if (new Set(n.map((e) => e.key)).size !== n.length) throw new s("VALIDATION_FAILED", "入力IDが重複しています。");
		for (let e of n) if (!this.accountId || !e.key.startsWith(this.accountId + ":") || !C.test(e.projectId) || !/^\d+$/.test(e.baseRevision) || ps(e.fields).byteLength > 1048576 || e.asset && (e.asset.bytes.byteLength > 33554432 || await D(e.asset.bytes) !== e.asset.contentHash)) throw new s("VALIDATION_FAILED", "入力の領域・hash・上限が不正です。");
		await this.db.transaction("rw", this.db.authorToolDrafts, async () => {
			if (!Q((await this.db.authorToolDrafts.toArray()).map((e) => ({
				...e,
				asset: e.asset ? {
					contentHash: e.asset.contentHash,
					byteSize: e.asset.bytes.byteLength
				} : null
			})), r.map((e) => ({
				...e,
				asset: e.asset ? {
					contentHash: e.asset.contentHash,
					byteSize: e.asset.bytes.byteLength
				} : null
			})))) throw new s("REVISION_CONFLICT", "確認後に未保存入力が変わりました。");
			await this.db.authorToolDrafts.bulkPut(n), this.faultInjector?.("before-commit");
		});
	}
	async getWorkspaceInputs() {
		let e = await this.db.workspaceInputs.get("workspace");
		return e ? Z(e.value) : void 0;
	}
	checkedWorkspaceInputs(e) {
		let t = Z(e);
		if (!t || Object.keys(t).some((e) => ![
			"drafts",
			"jsonBuffers",
			"settingsDrafts",
			"alternativeDrafts"
		].includes(e)) || [
			"drafts",
			"jsonBuffers",
			"settingsDrafts",
			"alternativeDrafts"
		].some((e) => {
			let n = t[e];
			return !n || typeof n != "object" || Array.isArray(n);
		}) || ps(t).byteLength > 67108864) throw new s("VALIDATION_FAILED", "作品入力の構造または保持上限が不正です。");
		return t;
	}
	async saveWorkspaceInputs(e, t) {
		let n = this.checkedWorkspaceInputs(e), r = Z(t);
		try {
			await this.db.transaction("rw", this.db.workspaceInputs, async () => {
				if (!Q((await this.db.workspaceInputs.get("workspace"))?.value, r)) throw new s("REVISION_CONFLICT", "別画面で作品入力が変わりました。入力を持ち出して再確認してください。");
				await this.db.workspaceInputs.put({
					key: "workspace",
					value: n
				});
			});
		} catch (e) {
			throw p(e);
		}
	}
	async restoreAuthorInputs(e, t) {
		let n = Z(e.tools), r = this.checkedWorkspaceInputs(e.workspace), i = Z(t);
		if (new Set(n.map((e) => e.key)).size !== n.length) throw new s("VALIDATION_FAILED", "入力IDが重複しています。");
		for (let e of n) if (!this.accountId || !e.key.startsWith(this.accountId + ":") || !C.test(e.projectId) || !/^(0|[1-9]\d*)$/.test(e.baseRevision) || !e.fields || typeof e.fields != "object" || Array.isArray(e.fields) || ps(e.fields).byteLength > 1048576 || e.asset && (e.asset.bytes.byteLength > 33554432 || await D(e.asset.bytes) !== e.asset.contentHash)) throw new s("VALIDATION_FAILED", "入力の領域・hash・上限が不正です。");
		let a = (e) => e.map((e) => ({
			...e,
			asset: e.asset ? {
				contentHash: e.asset.contentHash,
				byteSize: e.asset.bytes.byteLength
			} : null
		})).sort((e, t) => e.key.localeCompare(t.key));
		try {
			await this.db.transaction("rw", this.db.authorToolDrafts, this.db.workspaceInputs, async () => {
				let e = await this.db.authorToolDrafts.toArray(), t = await this.db.workspaceInputs.get("workspace");
				if (!Q(a(e), a(i.tools)) || !Q(t?.value, i.workspace)) throw new s("REVISION_CONFLICT", "確認後に未保存入力が変わりました。");
				await this.db.authorToolDrafts.bulkPut(n), await this.db.workspaceInputs.put({
					key: "workspace",
					value: r
				}), this.faultInjector?.("before-commit");
			});
		} catch (e) {
			throw p(e);
		}
	}
	async getAuthorToolDraft(e) {
		let t = await this.db.authorToolDrafts.get(e);
		return t ? Z(t) : void 0;
	}
	async clearAuthorToolDraft(e) {
		await this.db.authorToolDrafts.delete(e);
	}
	async importScenario(e, t) {
		let n = {
			...t,
			idMap: t.idMap ? Z(t.idMap) : void 0,
			resolutions: t.resolutions ? Z(t.resolutions) : void 0
		}, r = os();
		try {
			if (o(n.signal), ![
				"new",
				"clone",
				"replace",
				"merge",
				"mapped_merge"
			].includes(n.mode)) throw new s("FORMAT_UNSUPPORTED", "読み込みモードが未対応です。");
			let t = Z(e), i = n.operationId ?? j(), a = await this.validationWorlds(t.worlds), c = Na(a), l, u, d, f = {
				conflicts: [],
				pendingChanges: 0,
				additions: 0
			}, p = [], m = [], h, g, _, v;
			if ((n.mode === "new" || n.mode === "clone") && typeof window < "u" && typeof Worker < "u") {
				let e = await ss({
					project: t.project,
					recovery: t.recovery,
					syncRecovery: t.syncRecovery,
					worlds: t.worlds,
					knownWorlds: a,
					manifestProjectId: t.manifest.projectId,
					mode: n.mode
				}, {
					stage: (e) => n.onStage?.(e),
					preview: async () => {
						if (f = await this.previewImport(t, n), n.mode === "new" && f.target) throw new s("IMPORT_CONFLICT", "同じ作品IDが既にあります。複製・置換・統合を選んでください。");
					},
					assets: async () => {
						p = await this.checkedAssets(t.assets.map((e) => ({
							contentHash: e.contentHash,
							bytes: e.bytes,
							mediaType: e.mediaType,
							assetPath: e.path
						})));
					},
					finalize: async (e) => (_ = await Ps(e.before, e.after, !0), g = {
						operationId: i,
						projectId: e.after.projectId,
						baseRevision: "0",
						revision: e.after.revision,
						targetIds: _.map((e) => e.targetId),
						createdAt: e.now,
						reason: `専用ファイルを${n.mode}で復元`,
						before: Z(e.before),
						after: Z(e.after),
						...e.idMap ? { idMap: e.idMap } : {}
					}, g)
				}, n.signal);
				({project: l, recovery: u, idMap: d, worlds: m, now: h, syncRecovery: v} = e);
			} else {
				let e = (e, t, i = {}) => (n.onStage?.(e), r.run({
					step: e,
					project: t,
					worlds: c,
					...i
				}, { signal: n.signal }));
				if (t.project = (await e("structure", t.project)).project, t.recovery &&= (await e("recovery", t.project, { recovery: t.recovery })).recovery, await e("ids", t.project, { recovery: t.recovery }), Pa([t.project, ...Object.values(t.worlds)], a), t.manifest.projectId !== t.project.projectId) throw new s("VALIDATION_FAILED", "読み込み候補とmanifestの作品IDが一致しません。");
				if (f = await this.previewImport(t, n), n.mode === "new" && f.target) throw new s("IMPORT_CONFLICT", "同じ作品IDが既にあります。複製・置換・統合を選んでください。");
				if (n.mode === "replace" && f.pendingChanges) throw new s("PENDING_CHANGES", "未送信の変更があります。同期・競合解決を済ませるか、複製して復元してください。");
				if (f.target && n.baseRevision !== f.target.revision) throw new s("REVISION_CONFLICT", "確認した対象版と現在版が一致しません。読み込みの影響を確認し直してください。");
				if (l = t.project, u = t.recovery, n.mode === "mapped_merge") {
					if (!f.mappedPlan?.candidate || f.mappedPlan.unresolved.length) throw new s("IMPORT_CONFLICT", "全IDの対応とすべての採用差分を確認してください。");
					if (!n.confirmationHash || n.confirmationHash !== f.confirmationHash) throw new s("REVISION_CONFLICT", "確認したID対応・採用差分・素材が変わりました。入力を保持して再確認してください。");
					l = f.mappedPlan.candidate, d = f.mappedPlan.idMap, u = f.mappedRecovery;
				}
				if (n.mode === "clone") {
					let t = (await e("clone", l, { recovery: u })).cloned;
					d = t.idMap, u = u ? (await r.run({
						step: "map_recovery",
						project: t.project,
						worlds: {},
						recovery: u,
						idMap: d
					}, { signal: n.signal })).recovery : void 0;
					let i = new Set(l.history.map((e) => d[e.operationId]));
					l = {
						...t.project,
						history: t.project.history.filter((e) => i.has(e.operationId))
					};
				}
				if (n.mode === "merge" && (l = (await e("merge", l, {
					target: f.target,
					resolutions: n.resolutions
				})).project), n.mode === "replace") {
					let e = new Map(l.snapshots.map((e) => [e.id, e]));
					for (let t of f.target.snapshots) {
						let n = e.get(t.id);
						if (n && !P(t, n)) throw new s("IMMUTABLE_SNAPSHOT", "同じsnapshot IDに異なる内容があります。", t.id);
						e.set(t.id, t);
					}
					l.snapshots = [...e.values()];
					let t = new Set(l.entities.map((e) => e.id));
					l.entities.push(...f.target.entities.filter((e) => e.kind === "snapshot" && !t.has(e.id)));
				}
				let o = t.assets.map((e) => ({
					contentHash: e.contentHash,
					bytes: e.bytes,
					mediaType: e.mediaType,
					assetPath: e.path
				}));
				p = await this.checkedAssets(o), await e("hashes", l), await e("integrity", l), m = [];
				for (let [n, r] of Object.entries(t.worlds)) m.push({
					id: n,
					project: (await e("structure", r)).project
				});
				h = (/* @__PURE__ */ new Date()).toISOString();
				let y = f.target ? $(f.target) : xs(l);
				if (f.target) {
					let r = (f.mappedPlan?.mappedProject.history ?? t.project.history).map((e, r) => n.mode === "mapped_merge" ? {
						...e,
						importOrigin: e.importOrigin ?? {
							sourceProjectId: t.project.projectId,
							sourceOperationId: t.project.history[r].operationId,
							importOperationId: i
						}
					} : e), a = (await e("combine_history", {
						...l,
						history: r
					}, { target: f.target })).history;
					l = {
						...l,
						revision: bs(f.target.revision),
						history: a
					}, l.entities = Es(f.target.entities, l.entities, i, h), l.relations = Es(f.target.relations, l.relations, i, h), Ds(f.target, l), l = await xi(f.target, l), l.entities = Es(f.target.entities, l.entities, i, h);
				} else n.mode === "clone" && (l = {
					...l,
					revision: bs(l.revision)
				});
				l = (await e("structure", l)).project, _ = await Ps(y, $(l), !f.target), g = {
					operationId: i,
					projectId: l.projectId,
					baseRevision: f.target?.revision ?? "0",
					revision: l.revision,
					targetIds: _.map((e) => e.targetId),
					createdAt: h,
					reason: `専用ファイルを${n.mode}で復元`,
					before: Z(y),
					after: Z($(l)),
					...d ? { idMap: d } : {}
				}, (f.target || n.mode === "clone") && (l.history = [...l.history, g]), u &&= (await e("rehash_recovery", l, { recovery: u })).recovery, l = (await e("structure", l)).project, await e("integrity", l), u &&= (await e("recovery", l, { recovery: {
					...u,
					projectId: l.projectId,
					sourceRevision: l.revision
				} })).recovery, v = t.syncRecovery ? (await e("sync_recovery", l, { syncRecovery: t.syncRecovery })).syncRecovery : [];
			}
			if (n.mode === "clone") {
				ms(l.history);
				for (let e of l.snapshots) ms(e);
			}
			let y = f.target ? {
				id: j(),
				projectId: f.target.projectId,
				createdAt: h,
				reason: `専用ファイル${n.mode}の前の復元点`,
				project: f.target,
				assetHashes: Oa(f.target).map((e) => e.contentHash)
			} : void 0, b = await ys(l.history, n.signal);
			n.onStage?.("commit");
			let x = await this.db.transaction("rw", this.writeTables, async () => {
				if (go(n.signal), wt(), o(n.signal), await this.db.importLogs.get(i) || await this.db.outbox.get(i) || await this.db.commands.get(i)) throw new s("OPERATION_CONFLICT", "この読み込み操作IDは既に使われています。");
				let e = await this.db.projects.get(l.projectId);
				if (f.target ? !e || e.revision !== f.target.revision : e) throw new s("REVISION_CONFLICT", "読み込みの確定前に対象作品が変わりました。");
				if (n.mode === "replace" && await this.db.outbox.where("projectId").equals(l.projectId).count()) throw new s("PENDING_CHANGES", "確定前に未送信の変更が増えました。");
				await this.guardWorldRegistry([l, ...m.map((e) => e.project)]), y && (await this.writeAssets([], y.project, !0), await this.db.restorePoints.add(y)), await this.writeAssets(p, l, t.manifest.assetMode === "embedded");
				for (let e of m) {
					let t = await this.db.worlds.get(e.id);
					if (t && !P(t.project, e.project)) throw new s("IMMUTABLE_SNAPSHOT", "既存の共通世界snapshotと内容が異なります。", e.id);
					await this.db.worlds.put(e), await this.db.worldSources.put(await H.waitFor(Zt(e.id, e.project)));
				}
				await this.writeContent(l, f.target), this.faultInjector?.("after-content");
				let r = [], a = /* @__PURE__ */ new Set();
				for (let [e, t] of l.history.entries()) {
					let n = await this.db.commands.get(t.operationId);
					if (n && !Q(await this.materializeCommand(n), t)) throw new s("OPERATION_CONFLICT", "読み込む履歴の操作IDが既存履歴と衝突しています。", t.operationId);
					if (!n) {
						let n = b[e], i = n.stored.delta;
						r.push(i?.parentOperationId && !a.has(i.parentOperationId) ? {
							...n.stored,
							delta: {
								metadata: i.metadata,
								checkpoint: n.record.before,
								patch: i.patch
							}
						} : n.stored), a.add(t.operationId);
					}
					r.length === 2 && (await this.db.commands.bulkAdd(r), r = []);
				}
				r.length && await this.db.commands.bulkAdd(r), this.faultInjector?.("after-history");
				let c = await this.db.syncMetadata.get(l.projectId);
				await this.db.outbox.add({
					operationId: i,
					projectId: l.projectId,
					accountId: this.accountId,
					baseRevision: c?.serverRevision ?? "0",
					localRevision: l.revision,
					createdAt: h,
					targetIds: g.targetIds,
					changes: _,
					command: g
				});
				let x = (await this.listRecoveredPending(l.projectId)).reduce((e, t) => Math.max(e, t.sequence), -1) + 1, S = [];
				for (let e of u?.pending ?? []) {
					let t = {
						key: `${l.projectId}:${e.operationId}`,
						projectId: l.projectId,
						importOperationId: i,
						sequence: x++,
						operation: e,
						status: "needs_reconnect"
					}, n = await this.db.recoveredPending.get(t.key);
					if (n && !P(n.operation, e)) throw new s("OPERATION_CONFLICT", "同じ送信待ち操作の復元内容が異なります。");
					n || S.push(t), S.length === 2 && (await this.db.recoveredPending.bulkAdd(S), S = []);
				}
				S.length && await this.db.recoveredPending.bulkAdd(S);
				for (let e of v) await this.db.retainedSyncRecovery.put({
					key: `${l.projectId}:${e.contentHash}`,
					projectId: l.projectId,
					evidence: e,
					status: "needs_reconnect"
				});
				return await this.db.syncMetadata.put({
					projectId: l.projectId,
					serverRevision: c?.serverRevision ?? "0",
					state: "pending"
				}), await this.db.importLogs.add({
					operationId: i,
					projectId: l.projectId,
					mode: n.mode,
					createdAt: h,
					...d ? { idMap: d } : {}
				}), this.faultInjector?.("after-outbox"), o(n.signal), this.faultInjector?.("before-commit"), {
					project: l,
					operationId: i,
					localSaved: !0,
					pendingSync: !0,
					mode: n.mode,
					...d ? { idMap: d } : {},
					...y ? { restorePointId: y.id } : {},
					warnings: t.warnings
				};
			});
			return this.invalidateProjectCache(l.projectId), x;
		} catch (e) {
			throw p(e);
		} finally {
			r.dispose();
		}
	}
};
function Is(e, t) {
	return e.byteLength === t.byteLength && e.every((e, n) => e === t[n]);
}
async function Ls(e, t, n, r) {
	return (await To({
		step: "map_recovery",
		project: t,
		worlds: {},
		recovery: e,
		idMap: n
	}, { signal: r })).recovery;
}
function Rs(e, t) {
	let n = new Map(e.snapshots.map((e) => [e.id, e]));
	for (let e of t.snapshots) n.set(e.id, Z(e));
	e.snapshots = [...n.values()], t.authorAlternatives && (e.authorAlternatives = Z(t.authorAlternatives));
	let r = new Map(t.entities.filter((e) => e.kind === "snapshot").map((e) => [e.id, e]));
	e.entities = e.entities.map((e) => Z(r.get(e.id) ?? e));
	let i = new Set(e.entities.map((e) => e.id));
	for (let [t, n] of r) i.has(t) || e.entities.push(Z(n));
	return e;
}
function zs(e, t) {
	let n = Z(e), r = (e, t, n) => {
		let r = new Map(e.map((e) => [e.id, e])), i = new Map(t.map((e) => [e.id, e])), a = new Map(n.map((e) => [e.id, e]));
		for (let e of /* @__PURE__ */ new Set([...r.keys(), ...i.keys()])) {
			let t = r.get(e), n = i.get(e);
			if (P(t ?? null, n ?? null)) continue;
			let o = a.get(e);
			if (!P(o ? Ts(o) : null, n ? Ts(n) : null)) throw new s("RESTORE_CONFLICT", "取り消し対象がその後に変更されています。履歴の単体復元で内容を比較してください。", e);
			t ? a.set(e, Z(t)) : a.delete(e);
		}
		return [...a.values()];
	};
	n.entities = r(t.before.entities, t.after.entities, e.entities), n.relations = r(t.before.relations, t.after.relations, e.relations);
	for (let r of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences",
		"snapshots",
		"views"
	]) if (!P(t.before[r], t.after[r])) {
		if (!P(e[r], t.after[r])) throw new s("RESTORE_CONFLICT", "取り消す項目がその後に変更されています。", r);
		n[r] = Z(t.before[r]);
	}
	return n;
}
new Fs();
//#endregion
//#region src/testing/performanceFixture.ts
async function Bs(e, t = "standard") {
	let n = 2166136261;
	for (let t of e) n = Math.imul(n ^ t.charCodeAt(0), 16777619) >>> 0;
	let i = n.toString(16).padStart(8, "0"), o = 1, s = () => `${i}-0000-4000-8000-${(o++).toString(16).padStart(12, "0")}`, c = ve("性能固定データ");
	c.projectId = s();
	let l = t === "large" ? 10 : 1, u = [
		"アオ",
		"門番",
		"記録係",
		"旅人",
		"語り手"
	], d = Array.from("霧の町で古い記録を調べる。鍵はまだ見つからず、新しい手掛かりを探した。"), f = (e) => Array.from({ length: e }, (e, t) => d[t % d.length]).join(""), p = (e) => [{
		id: s(),
		kind: "paragraph",
		text: f(e)
	}], m = (e, t, n) => {
		let i = r(c.projectId, e, t, n);
		return i.id = s(), i.createdAt = i.updatedAt = "2026-10-05T00:00:00Z", c.entities.push(i), i;
	}, h = [];
	for (let e = 0; e < 100 * l; e++) h.push(m("character", `${u[e % u.length]}${e}`, {
		reading: `あお${e}`,
		body: p(300),
		aliases: [{
			id: s(),
			text: `記録名${e}`,
			reading: `きろくめい${e}`,
			validity: a(),
			audienceHolderIds: [],
			isPublicDefault: !0
		}]
	}));
	let g = [];
	for (let e = 0; e < 100 * l; e++) g.push(m("variable", `状態${e}`, {
		key: `flag_${e}`,
		valueType: "boolean",
		scope: "run",
		initial: {
			type: "boolean",
			value: !1
		},
		allowed: { values: [!1, !0] }
	}));
	let _ = [];
	for (let e = 0; e < 1e3 * l; e++) _.push(m("event", `出来事${e}`, {
		summary: p(80),
		time: e % 7 == 0 ? {
			mode: "unknown",
			reason: "未確定"
		} : e % 3 == 0 ? {
			mode: "interval",
			start: String(e * 86400 - 5e5),
			end: String(e * 86400 - 5e5 + 3600),
			calendarId: c.calendarId
		} : {
			mode: "instant",
			at: String(e * 86400 - 5e5),
			calendarId: c.calendarId
		},
		laneRole: e % 4 == 0 ? "common" : "participants",
		participants: e % 4 == 0 ? [] : [{
			characterId: h[e % h.length].id,
			role: "actor"
		}]
	}));
	let v = [];
	for (let e = 0; e < 500 * l; e++) {
		let t = p(300), n = h[e % h.length];
		t[0].links = [{
			start: 0,
			end: 1,
			target: {
				entityId: n.id,
				blockId: n.data.body[0].id
			}
		}], v.push(m("scene", `場面${e}`, {
			summary: p(80),
			body: t,
			eventIds: [_[e % _.length].id],
			povId: n.id
		}));
	}
	for (let e = 0; e < 5e3 * l; e++) {
		let n = p(40);
		e % (t === "large" ? 12 : 3) == 0 && (n[0].ruby = [{
			start: 0,
			end: 1,
			text: "きり"
		}]), m("dialogue_line", `台詞${e}`, {
			text: n,
			speakerId: h[e % h.length].id
		});
	}
	for (let e = 0; e < 100 * l; e++) m("foreshadow", `伏線${e}`, {
		question: p(80),
		intent: p(80),
		resolutionPolicy: "undecided"
	});
	for (let e = 0; e < 2e3 * l; e++) c.relations.push({
		id: s(),
		projectId: c.projectId,
		revision: "0",
		fromId: h[e % h.length].id,
		toId: h[(e + 1) % h.length].id,
		relationType: "trust",
		direction: "forward",
		validity: {
			worldRange: null,
			routeCondition: e % 2 == 0 ? {
				op: "compare",
				variableId: g[e % g.length].id,
				comparator: "eq",
				value: {
					type: "boolean",
					value: !0
				}
			} : null,
			presentationAnchor: null
		},
		evidenceIds: [_[e % _.length].id],
		status: "provisional",
		visibility: "private"
	});
	let y = {
		character: h.length,
		event: _.length,
		scene: v.length,
		dialogue_line: 5e3 * l,
		relation: c.relations.length,
		variable: g.length,
		foreshadow: 100 * l,
		totalRecords: c.entities.length + c.relations.length
	}, b = new TextEncoder().encode(JSON.stringify(c));
	return {
		project: c,
		seed: e,
		size: t,
		counts: y,
		sha256: [...new Uint8Array(await crypto.subtle.digest("SHA-256", b))].map((e) => e.toString(16).padStart(2, "0")).join(""),
		assetBytes: 0
	};
}
async function Vs(e) {
	let t = await Bs(e, "large"), n = [], i = {
		scene: [
			"summary",
			"body",
			"authorNotes",
			"eventIds"
		],
		dialogue_line: ["text"],
		foreshadow: ["question", "intent"],
		event: ["summary"],
		variable: ["initial", "allowed"],
		character: []
	};
	for (let e of t.project.entities) for (let [t, n] of Object.entries(e.data)) Array.isArray(n) && !n.length && !i[e.kind]?.includes(t) && delete e.data[t];
	for (let e = 0; e < 3; e++) {
		let i = /* @__PURE__ */ new Uint8Array(25165824);
		for (let t = 0; t < i.length; t++) i[t] = (t * 17 + e * 61) % 251;
		let a = await D(i), o = r(t.project.projectId, "attachment", `性能素材${e + 1}`, {
			mediaType: "application/octet-stream",
			contentHash: a,
			byteSize: i.length,
			assetPath: `assets/${a}.bin`
		});
		o.id = t.project.projectId.slice(0, 24) + `f0000000000${e}`, o.createdAt = o.updatedAt = "2026-10-05T00:00:00Z", t.project.entities.push(o), n.push({
			contentHash: a,
			bytes: i,
			mediaType: "application/octet-stream"
		});
	}
	return {
		...t,
		coreRecords: t.counts.totalRecords,
		counts: {
			...t.counts,
			attachment: 3,
			totalRecords: t.counts.totalRecords + 3
		},
		assets: n,
		assetBytes: n.reduce((e, t) => e + t.bytes.length, 0),
		sha256: await D(M(t.project))
	};
}
globalThis.seedMeasurement = async (e, t) => {
	let n = e === "large" ? await Vs("large-material-rb10-v1") : await Bs("standard-r06-v1"), i = new Fs();
	if ((await i.listProjectsForEditing()).length) throw Error("measurement database must be empty");
	let a = (await i.saveProject(n.project, {
		reason: "測定fixture初期化",
		includeHistory: !1,
		assets: n.assets ?? []
	})).project;
	localStorage.setItem("scenario-last-project:guest", a.projectId), localStorage.setItem("scenario-local-view-user", "measurement"), localStorage.setItem("scenario-workspace-view:v1:measurement:" + a.projectId + ":desktop", JSON.stringify({
		filters: {
			"workspace.page": "materials",
			"workspace.kind": "character"
		},
		lastOpenedId: null
	})), sessionStorage.setItem("scenario-performance", "measure");
	let o;
	if (t) {
		let e = ve("継続試読の補助作品"), t = r(e.projectId, "flow_node", "補助試読入口", { nodeType: "entry" }), n = r(e.projectId, "flow_node", "補助試読終端", {
			nodeType: "terminal",
			terminalReason: "補助試読終了"
		}), a = r(e.projectId, "flow_edge", "補助進行", {
			fromId: t.id,
			toId: n.id,
			label: "終端へ進む"
		}), s = r(e.projectId, "flow_graph", "補助試読図", {
			nodeIds: [t.id, n.id],
			entryIds: [t.id],
			exitIds: [n.id],
			edgeIds: [a.id]
		});
		e.entities.push(t, n, a, s), e.entities.forEach((e) => e.status = "confirmed");
		let c = (await i.saveProject(e, {
			reason: "別作品の補助試読fixture",
			includeHistory: !1
		})).project;
		o = {
			projectId: c.projectId,
			title: c.name,
			records: 4,
			sha256: await D(M(e)),
			purpose: "Trial in a separate explicit auxiliary project; Large record and asset counts unchanged"
		};
	}
	return i.close(), {
		title: a.name,
		trial: o,
		seed: n.seed,
		counts: n.counts,
		sha256: n.sha256,
		assetBytes: n.assetBytes,
		projectId: a.projectId,
		assetHashes: (n.assets ?? []).map((e) => ({
			hash: e.contentHash,
			bytes: e.bytes.length
		}))
	};
}, globalThis.verifyMeasurement = async (e, t) => {
	let n = new Fs(), r = await n.getProjectForEditing(e), i = [];
	for (let e of t) {
		let t = await n.getAsset(e.hash);
		i.push({
			hash: e.hash,
			bytes: t?.length,
			verified: !!t && t.length === e.bytes && await D(t) === e.hash
		});
	}
	let a = await n.historyPage(e, { size: 1 }), o = await n.getSaveState(e);
	return n.close(), {
		contentHash: await D(M({
			...r,
			history: []
		})),
		revision: r.revision,
		records: r.entities.length + r.relations.length,
		historyCount: a.total,
		outboxCount: o.pendingCount,
		recoveredPendingCount: o.recoveredPendingCount,
		assets: i,
		verificationScope: "current image hash, full material byte hashes, history/pending counts; full historical images are verified by the complete-file reader and separate lossless round-trip tests"
	};
}, globalThis.verifyMeasurementForOnlyProject = async (e) => {
	let t = new Fs(), n = await t.listProjectsForEditing();
	if (t.close(), n.length !== 1) throw Error("Restoration must use an empty area");
	return verifyMeasurement(n[0].projectId, e);
};
//#endregion
