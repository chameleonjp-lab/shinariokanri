# 1B 実装報告（統合担当の実行・CIへ引継ぎ）

状態: 所有2ファイルの実装完了・編集停止。commit/push/PR/mergeは実施していない。統合担当の指示によりcommitは統合担当が行う。2026-10-19の途中親commitは `d291579f6d4620f86588096739d3e720f41d6563`。その後のESM package-context最小修正は親へ通知済み。現候補の正式30/180・heap・116/464・実機・実Authは未取得／範囲外であり、本補助結果で合格にしない。

## 所有実装とAPI

- `scripts/acceptance/capture_n05_downloads.mjs`。CLI `node … --repository PATH --binding FILE --output NEW_DIRECTORY`。追加必須引数なし。outputは未作成必須。元N05のtracked spec/config/fixtureを編集せず、spec先頭importのみ一時bridgeへ変換し、残り本文のbyte一致を確認する。元timeout 1,200,000ms、assert、fixtureを維持する。元spec/config/metadataのSHAも固定した。
- `scripts/acceptance/verify_supplements.py`。CLI `python3 … --repository PATH --binding FILE --historical PATH --output SUPPLEMENTS_DIRECTORY`。追加必須引数なし。成功時に `assessment.json` を保存しexit0。不足・置換・失敗・別候補は例外で非0。formalAcceptanceは常に `not_assessed`。

N05保存物: `capture.json`、`events.json`、`results.json`、`downloads/1.json`、`downloads/2.json`、`executed-original.spec.ts`、`executed-driver.mjs`、`staging/{capture-original.spec.ts,capture-bridge.ts,playwright.config.ts,package.json}`、`execution/{command.json,exit.json,stdout-stderr.log,executed-wrapper.py}`。staging/node_modulesリンクは実子終了後に除去する。

provenance共通項は `format=phase3-n05-downloads/1`、新規trial UUID、bindingSHA256、candidate、tree、build（全build_info）、originalSHA256、packageSHA256、fixture（metadataSHA256/archive/bytes/sha256）。captureに実argv・stage/bridge/config SHA・実子returncode、eventsに実testId/project/retry、各eventに序数・suggested filename・URL・保存先・bytes/SHA・completedを保持する。同じevents JSON bytesを成功reportへattachする。

bridgeはpageの別々のdownloadオブジェクトを観測し、failure=nullを待ち、各 `download.saveAs` 完了後の実bytesだけを保存する。非同期saveの全完了後にdescriptorを出す。JSONから原本を生成しない。2原本のbytesが等しいこと自体は正常であり、複製event/別trial/build・片側欠損・非通常file・symlink/hardlink aliasを拒否する。元N05のJSON添付から全29表前後fingerprintを読み、再計算実装はしない。元未保存入力のassertと元本文の固定hashで入力保持まで結合する。

## runner統合の最小差分／受け渡し契約

共通runner/CI test/manifest/handoffは親だけが編集した。

1. 両RGの元 `executed-inputs/package.json` を元inputs列の**末尾**に加える。verifierの期待順はRG01=`rg01.spec.ts,rebound-original-seed.ts,package.json`、RG02/03=`same-given.spec.ts,original-fixtures.ts,original-runtime-regressions.test.ts,package.json`。
2. N05 output directoryをrunnerで作らず、driverへ渡す。外側argvは `node ABS_DRIVER --repository ABS_REPO --binding ABS_BINDING --output OUTPUT/n05`。外側execute receiptは `OUTPUT/n05-capture-execution`、driverの実Playwright receiptは `OUTPUT/n05/execution`。
3. sequence n05 rowは `step,argv,originalSHA256,driverSHA256,status,returncode`。verifierは3番目rowと外側receiptも検査する。
4. `sequence.status=completed` 保存後、現verifierを `OUTPUT/executed-verifier.py` に保存し、verifier CLIを別execute receiptで実行する。assessment追記はstepsを増やさない。
5. driverのESM package contextはroot/package.json元bytesをstageへcopyし、provenanceとverifierで結合済み。

## 原本・固定値

回収当初はpromisor proxy未接続でrecover_historical両CLIがexit1。統合担当が許可されたnetwork readで回収し、その後この担当もimmutable manifest/全archive/member/展開bytesをverifier経由で照合した。

原commitは `d5e132ef6f4db6a0f3fbe888228ffd1007d653f9`。回収root=`/workspace/task-integration/1b/historical`。

| label | manifest SHA256 | archive bytes / SHA256 | members |
|---|---|---|---|
| unaffected-local-3ab6 | 94638ab2ed3ac407b0a70a60d90d0f2a9ed81ce2e7967c02f5aebe4da67d8de1 | 2632983 / d8b79a50c306cba3b683b629c4d88f211b051833faf6d5f4a1cce34951057f81 | 83 |
| additional-original-regressions-1fcadcca | 1cf01c9b9798d03dc641d0422663cd76192cf24dea813458d36df9ab6c6de07f | 141085 / 03ac2e112120ceccbcff59faa0beb9e44b5474fb74aa3b606f1e37cf3047e932 | 37 |

上記各manifestは `docs/quality/pr49-followup-2026-10-15/evidence/bundles/LABEL.manifest.json`。各archiveは回収rootのLABEL.tar.gz、実inputs/添付はLABEL配下。recovery.jsonだけを信用せずimmutable Git blobの上記SHAと実archiveを読む。

N05原spec SHA=`4b8eff5530a2925557a4491c6bdb22061bc16e33d239bc8cb003578dab66456e`、原config SHA=`325086179677c1f7a0b39031415e7c54f9fc8cc466aec281961627ff84cb3c0f`、原metadata SHA=`4bce4331003c6c00ead1565a5c79965beda13ddd714e1c877729e67a5c2d3158`。原archive bytes=1914098、SHA=`1ca2b19dcf4c8464c68a24a1bbe02cd1b1c4be20187ed2cee99d4e541822d0d0`。固定原archiveから宣言entry ID `b4196e71-6a2a-4d82-a71e-1795db4a9640` / `ff88d0be-3cec-497c-a916-c8984c444605` を確認し独立期待としてpinした。

## RGの原条件との対応

04a7未commit checker/11反例のコードは回収不能。このverifierと反例は**新規再構成**であり、古い11成功記述を今回の結果にしていない。補助namespace RG01/02/03と原6群RG-R01〜06は別。元driverのtest titleにRG-R02/03が含まれるため原titleをそのまま照合するが、全原6群の合格を意味しない。

- RG01: `original-prefix-and-cold / front-deletion / paragraph-split / paragraph-move / move-compensation-undo / paragraph-merge / overlapping-replacement / overlap-cold` の原8 checkpointを順序ごと固定。summaryと各実attachmentと実complete ZIPを結び、原文字列・Unicode位置・ruby/link・block ID/order・補償operationId・未解決annotationとanchor・cold保持・30,000msを原値で検査する。
- RG02: changes=false/true × route=skip/via/initialの原6条件。原given author model全体を原歴史givenへ照合し、元traceの全state（before/after/presentation）、conditionResults、全trace項目・findings・finalStateを照合する。動的UUIDを一貫してalpha renameし、createdAt/updatedAtだけ除外する。その他の値を件数に置換しない。実complete ZIP全bytes SHA、内部manifest、実build-info SHAも結合する。
- RG03: manual_choice/first_match/all_match × mixed=false/trueの原6条件。原given全体、policy/mixed/REFERENCE_INVALID不採用応答と前後UI値を照合し、前後実complete ZIPからauthor project全体・assetsの等値を検査する。self-reported unchangedだけで合格にしない。
- 原manifest→許可したcheckout/output pathと2個のcommit/version限定変換→実spec/config/packageのbytes/SHA→実execute.pyのargv/cwd/selectors/wrapper/real exit/log→成功1attemptの元test inventory→実添付を照合する。例外的な任意文字列置換を許さない。

## 実argv・exit・RED/GREEN

初期RED: 実装前に `/workspace/task-integration/1b/test_check_phase3_supplements.py` を作成し実行。まだ存在しないverify_supplements.pyのFileNotFoundErrorでPython実exit1。ログ=`red.log`。当時は最初の2検査であり、後から増やした全17件を実装前に実行したとは記録しない。

現在のCI提案は同名外部fileに保持（親が `scripts/test_check_phase3_supplements.py` にcopyする）。ROOTは最終配置のparents[1]のみで解決し、検査無効化env/fallbackを含まない。外部配置のままの実検査はscratch launcherで未来の__file__位置だけを与えた。

- `python /workspace/task-integration/1b/run_test_proposal.py` → exit0、17 tests。`green.log`。11指定反例と、正常2実event/原条件6+6、限定変換、outer n05 argv/hash/exit、実failed receipt、symlink/hardlinkを検査。これはhermetic synthetic unit入力であり、実原本11反例と区別する。
- `python -m py_compile scripts/acceptance/verify_supplements.py` → exit0。
- `node --check scripts/acceptance/capture_n05_downloads.mjs` → exit0。
- `node /workspace/task-integration/1b/test_capture_mock.mjs` → exit0。実生成bridgeをNodeのTS stripで実行し、page/download APIだけをmock。別々の2event・異なるsaveAs bytes・未完了時descriptor不在・片側不足・download failure拒否を検査。実browser downloadを取得したとはしない。
- `git diff --check` → exit0。

実原本に対する反例probe:

`python /workspace/task-integration/1b/probe_actual_supplements.py --repository /workspace/shinariokanri-1b --historical /workspace/task-integration/1b/historical --output /workspace/task-integration/1b/actual-rg-probe` → exit0、原RG01/02/03 positive通過後、下記7件すべて期待した理由のValueErrorで拒否。`actual-rg-probe/probe.json` と各変更attachment原bytes/SHAを保持。元実ファイルは編集せずメモリ複製だけを変えた。このprobeはESM/package/UUID-pin最小修正前のverifier SHAも記録しており、親の最終candidate実行後に同じCLIを新outputへ再実行できる。

| case | 元given／変更 | 実拒否理由 |
|---|---|---|
| RG-05 | 実8checkpointのmoveをsplit複製へ、件数8保持 | original eight checkpoint inventory differs |
| RG-06 | 実front-deletion anchor.startを0→1、summaryと個別attachment両方置換 | actual complete file differs |
| RG-07 | 実RG02の1条件titleを置換、件数6保持 | exact six plus six conditions differ |
| RG-08 | 実trace before.rngPositionを0→1、実ZIP内部manifest/SHA/descriptor/observed SHAも再結合 | original full trace states/conditions differ |
| RG-09 | 実RG02 complete attachmentのみ除去 | Missing attachment |
| RG-10 | 実all_match mixed=true観測をmixed=falseへ | policy/mixed/rejection observation differs |
| RG-11 | 実product.versionのみ別build、passed report維持 | actual build differs |

現候補N05実原本がまだ入力されていないため、probeは `N05-01片側欠損 / N05-02 JSON複製に第二eventなし / N05-03別trial / N05-04別build` をBLOCKEDと明記した。親の2実download取得後、同probeへ `--n05 ABS_SUPPLEMENTS/n05 --binding ABS_BINDING` を加えて新outputに実行すれば、full N05 positive provenanceを確認後、実原本descriptorに対する4反例を加えた全11件を出す。syntheticの成功を実原本11件成功と呼ばない。

## 未実行・失敗保持・次の一操作

統合担当の最初の現候補試行は、原RGのESM package contextがstageに欠けたmodule-loadで実exit1（原assert開始前）。失敗試行とそのbindingは統合担当が保持し、元package.jsonを追加する修正後は新候補で全RG/N05を最初から実行する。旧試行を合格に変更しない。

この担当はheavy build/browser/性能測定を独自に実行していない。現在のcandidate/tree/build/fixture/原実2download/元手順終了/実CIを結合した最終実証は統合担当の実行待ち。次の一操作は親が最新17件testをcopy→clean commit/build/seal→全supplement run→verifier→N05付実原本11probe→原全CIである。

最新所有file SHA（ESM修正後）:
- capture_n05_downloads.mjs: `a985325f3d56a05b2df602db4f15b6fa6971345afcb663bfbf654e90894e7fa6`
- verify_supplements.py: `17d154c15b8f283a3ee758a06b093600753250933dfdd1471b92ca1504991c6b`
