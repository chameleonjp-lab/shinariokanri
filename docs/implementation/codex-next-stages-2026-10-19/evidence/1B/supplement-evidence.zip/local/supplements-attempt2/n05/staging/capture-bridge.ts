import {test as base,expect,type Page} from '@playwright/test';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
export {expect}; export type {Page};
const provenance={"format":"phase3-n05-downloads/1","trial":"a59a7ac2-4739-45c6-b60f-1291cccbf224","bindingSHA256":"bd62c6dd439fcf049e96f94f0701b9fd8af155596421a19a876de9c11a75ab74","candidate":"db2874852e958e63261876d0cb5477ee4cc5a6d4","tree":"f7f24d96f84765f0a664396b350dac2c202997d7","build":{"commit":"db2874852e958e63261876d0cb5477ee4cc5a6d4","tree":"f7f24d96f84765f0a664396b350dac2c202997d7","dirty":false,"base":"/shinariokanri/","builtAt":"2026-10-19T06:54:22.211Z","versionHashScope":"sorted paths and bytes plus build info before version","version":"16a47445cc54b018cf19"},"originalSHA256":"4b8eff5530a2925557a4491c6bdb22061bc16e33d239bc8cb003578dab66456e","packageSHA256":"50d595ce28644f79cedcd4435dce6f03422997a9562c995280da6a2462547487","fixture":{"metadataSHA256":"4bce4331003c6c00ead1565a5c79965beda13ddd714e1c877729e67a5c2d3158","archive":"original-large-long-branch.scenario","bytes":1914098,"sha256":"1ca2b19dcf4c8464c68a24a1bbe02cd1b1c4be20187ed2cee99d4e541822d0d0"}},directory="/workspace/task-integration/1b/supplements-attempt2/n05";
export const test=base.extend<{captureN05:void}>({captureN05:[async({page},use,info)=>{
 const pending:Promise<void>[]=[],events:any[]=[],failures:any[]=[],seen=new WeakSet();
 const listener=(download:any)=>{
  if(seen.has(download))throw new Error('Repeated download object');seen.add(download);
  const event= pending.length+1;
  pending.push((async()=>{
   const failure=await download.failure();if(failure!==null)throw new Error('Download failed: '+failure);
   const savedPath=directory+'/downloads/'+event+'.json';
   await download.saveAs(savedPath);
   const bytes=await readFile(savedPath);
   events.push({...provenance,event,filename:download.suggestedFilename(),url:download.url(),savedPath,
    path:'downloads/'+event+'.json',bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),completed:true});
  })().catch(error=>{failures.push(error);}));
 };
 page.on('download',listener);
 try{await use();}finally{
  page.off('download',listener);await Promise.all(pending);if(failures.length)throw failures[0];events.sort((a,b)=>a.event-b.event);
  const descriptor={...provenance,testId:info.testId,project:info.project.name,retry:info.retry,events};
  const body=Buffer.from(JSON.stringify(descriptor,null,2)+'\n');
  await writeFile(directory+'/events.json',body,{flag:'wx'});
  await info.attach('n05-download-events',{body,contentType:'application/json'});
  if(events.length!==2)throw new Error('Expected exactly two actual download events');
 }
 },{auto:true}]});
