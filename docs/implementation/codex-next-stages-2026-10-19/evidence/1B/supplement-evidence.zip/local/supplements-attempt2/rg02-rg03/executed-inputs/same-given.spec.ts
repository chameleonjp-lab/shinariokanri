import {test,expect,type Page} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {foreshadowFixture,rejectedEffectFixture} from './original-fixtures';
import {exportScenario} from '/workspace/shinariokanri-1b/src/storage/archive';
import {checkTrialForeshadows,replaySavedTrace} from '/workspace/shinariokanri-1b/src/domain/runtime';
import {seed,navigate,backup,attachGiven,attachObservation,authorFingerprint} from '/workspace/shinariokanri-1b/tests/e2e/ap04-original-helpers';
async function begin(page:Page,entry:string){await navigate(page,/^構成/);await page.getByRole('tab',{name:'試読・検査',exact:true}).click();await page.getByLabel('試読の開始点',{exact:true}).selectOption(entry);await page.getByRole('button',{name:'試読を始める',exact:true}).click();}
test.beforeEach(async({page,browser},info)=>{const raw=await readFile('/workspace/shinariokanri-1b/dist/build-info.json');const build=JSON.parse(raw.toString());expect(build.commit).toBe('db2874852e958e63261876d0cb5477ee4cc5a6d4');expect(build.version).toBe('16a47445cc54b018cf19');await attachObservation(info,'actual-product',{build,actualBrowserVersion:browser.version(),physicalDevice:false,buildInfoSHA256:createHash('sha256').update(raw).digest('hex'),scope:'Linux Chromium normal UI, exact original unit fixture functions, original unit tests remain separate'});});
for(const changes of [false,true])for(const route of ['skip','via','initial']as const)test(`RG-R02 exact original fixture changes=${changes} route=${route}`,async({page},info)=>{
 const f=foreshadowFixture(changes,route==='initial');const bytes=await exportScenario(f.project);await attachGiven(info,'RG-R02',bytes,{changesCondition:changes,route,entry:f.entry.id,clue:f.clue.id,payoff:f.payoff.id,question:f.question.id,canReveal:f.canReveal.id,fixtureFunctions:'exact extracted original source'});await seed(page,bytes);await begin(page,f.entry.id);
 if(route==='skip')await page.locator('.reader-choice').nth(0).click();
 if(route==='via'){await page.locator('.reader-choice').nth(1).click();await page.locator('.reader-choice').first().click();}
 await expect(page.locator('.reader-sheet')).toContainText('秘密の回収');
 const firstText=await page.locator('.foreshadow-check').innerText();expect(firstText.includes('不足する提示')).toBe(route!=='via');
 await expect(page.locator('.runtime-variable').filter({hasText:'can_reveal'})).toContainText(changes?'false':'true');
 await page.locator('.reader-choice').first().click();await expect(page.locator('.reader-ending')).toBeVisible();await page.getByRole('button',{name:'一手戻る',exact:true}).click();
 const afterBack=await page.locator('.foreshadow-check').innerText();expect(afterBack.includes('不足する提示')).toBe(route!=='via');
 await page.locator('.reader-choice').first().click();await page.getByRole('button',{name:'経路を記録',exact:true}).click();await expect(page.getByText('開始状態と経路を端末内に保存しました。',{exact:true})).toBeVisible();
 await page.getByRole('button',{name:/試読経路.*再実行して状態を比較/}).click();await expect(page.locator('.reader-issue')).toHaveCount(0);
 const actual=await backup(page);const trace=actual.project.entities.find(e=>e.kind==='trace')!;expect(trace.kind).toBe('trace');const replay=replaySavedTrace(actual.project,trace.id);expect(replay.status).toBe('terminal');const findings=checkTrialForeshadows(actual.project,replay);const missing=findings.filter(q=>q.code==='REQUIRED_INFO_MISSING'&&q.payoffId===f.payoff.id);
 if(route==='via')expect(missing).toEqual([]);else expect(missing).toEqual([expect.objectContaining({status:'candidate',targetId:f.question.id,missingInfoIds:[f.clue.id]})]);
 await attachObservation(info,'RG-R02-actual',{changes,route,firstText,afterBack,traceId:trace.id,sourceVersionId:replay.state.contentVersionId,finalState:replay.state,findings,actualCompleteSHA256:createHash('sha256').update(actual.bytes).digest('hex'),beforeAfterConditionEvidencePreserved:true});
});
for(const policy of ['manual_choice','first_match','all_match']as const)for(const mixed of [false,true])test(`RG-R03 exact original fixture policy=${policy} mixed=${mixed}`,async({page},info)=>{
 const f=rejectedEffectFixture(policy,mixed);const bytes=await exportScenario(f.project);await attachGiven(info,'RG-R03',bytes,{policy,mixed,entry:f.entry.id,rejected:f.rejected.id,valid:f.valid.map(e=>e.id),selected:f.selected.id,fixtureFunctions:'exact extracted original source'});await seed(page,bytes);const baseline=await backup(page);await begin(page,f.entry.id);
 const beforeFingerprint=await authorFingerprint(page),beforeVisible=await page.locator('.reader-state-panel').innerText(),beforeHeading=await page.locator('.reader-sheet-heading').innerText();await page.getByRole('checkbox',{name:'宣言したきっかけ「choose」で進む',exact:true}).check();
 if(policy==='manual_choice')await page.locator('.reader-choice').first().click();else await page.getByRole('button',{name:'進行規則に従って次へ',exact:true}).click();
 await expect(page.locator('.reader-issue')).toContainText('REFERENCE_INVALID');await expect(page.locator('.reader-issue')).toContainText('不採用');
 const afterVisible=await page.locator('.reader-state-panel').innerText(),afterHeading=await page.locator('.reader-sheet-heading').innerText();expect(afterVisible).toBe(beforeVisible);expect(afterHeading).toBe(beforeHeading);expect(await authorFingerprint(page)).toBe(beforeFingerprint);await expect(page.getByRole('button',{name:'一手戻る',exact:true})).toBeDisabled();
 const error=await page.locator('.reader-issue').innerText();const actual=await backup(page);expect(actual.project).toEqual(baseline.project);expect(actual.assets.map(a=>({path:a.path,bytes:Array.from(a.bytes)}))).toEqual(baseline.assets.map(a=>({path:a.path,bytes:Array.from(a.bytes)})));
 await attachObservation(info,'RG-R03-actual',{policy,mixed,error,beforeVisible,afterVisible,beforeHeading,afterHeading,authorNativeUnchanged:true,actualCompleteSHA256:createHash('sha256').update(actual.bytes).digest('hex'),failedOperationNotAddedToHistory:true});
});
