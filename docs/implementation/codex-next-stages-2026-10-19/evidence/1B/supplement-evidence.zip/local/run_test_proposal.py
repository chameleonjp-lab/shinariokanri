"""Load the CI proposal with its future repository-relative __file__ location."""
from pathlib import Path
proposal=Path('/workspace/task-integration/1b/test_check_phase3_supplements.py')
source=proposal.read_bytes()
__file__='/workspace/shinariokanri-1b/scripts/test_check_phase3_supplements.py'
exec(compile(source,str(proposal),'exec'),globals())
