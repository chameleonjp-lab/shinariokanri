import { expect, test, type Page } from '@playwright/test';
import { createEntity, createProject, newId, validateProject } from '/workspace/pr49-measure-source/src/domain/model';
import { exportScenario as exportSourceScenario } from '/workspace/pr49-measure-source/src/storage/archive';
import {writeFile} from 'node:fs/promises';
const exportScenario=async(...args:Parameters<typeof exportSourceScenario>)=>{const bytes=await exportSourceScenario(...args);await writeFile(process.env.RG01_OUTPUT_DIR+'/actual-given.scenario',bytes);return bytes;};
async function navigate(page: Page, name: RegExp) {
  const menu = page.getByRole('button', { name: 'メニューを開く' });
  if (page.viewportSize()!.width < 1200) { await expect(menu).toBeVisible(); await menu.click(); await expect(page.locator('.sidebar')).toHaveClass(/sidebar-open/); }
  await page.locator('.sidebar').getByRole('button', { name }).first().click();
}

async function seed(page: Page) {
  const project = createProject('本文と条件の回帰検査');
  const character = createEntity(project.projectId, 'character', 'アオ');
  const scene = createEntity(project.projectId, 'scene', '注記付き本文', { body: [{ id: newId(), kind: 'paragraph', text: 'アオが歩く。', ruby: [{ start: 0, end: 2, text: 'あお' }], links: [{ start: 0, end: 2, target: { entityId: character.id } }] }] });
  const foreshadow = createEntity(project.projectId, 'foreshadow', '歩く理由');
  const disclosure = createEntity(project.projectId, 'disclosure', '本文の提示位置', { foreshadowId: foreshadow.id, anchor: { entityId: scene.id, blockId: scene.data.body[0].id, start: 0, end: 2 } });
  const entry = createEntity(project.projectId, 'flow_node', '入口', { nodeType: 'entry' });
  const end = createEntity(project.projectId, 'flow_node', '終端', { nodeType: 'terminal', terminalReason: '完了' });
  const variables = [
    createEntity(project.projectId, 'variable', '真偽状態', { key: 'boolean', valueType: 'boolean', initial: { type: 'boolean', value: true }, allowed: { values: [false, true] } }),
    createEntity(project.projectId, 'variable', '整数状態', { key: 'integer', valueType: 'integer', initial: { type: 'integer', value: 7 }, allowed: { min: 0, max: 10 } }),
    createEntity(project.projectId, 'variable', '列挙状態', { key: 'enum', valueType: 'enum', initial: { type: 'enum', value: 'open' }, allowed: { values: ['open', 'closed'] } }),
  ];
  const edges = variables.map((variable, index) => createEntity(project.projectId, 'flow_edge', `${variable.data.valueType}比較条件`, { fromId: entry.id, toId: end.id, label: `${variable.name}の道`, priority: index, condition: { op: 'compare', variableId: variable.id, comparator: 'eq', value: variable.data.initial } }));
  const graph = createEntity(project.projectId, 'flow_graph', '条件付き進行', { nodeIds: [entry.id, end.id], edgeIds: edges.map(edge => edge.id), entryIds: [entry.id], exitIds: [] });
  project.entities = [character, scene, foreshadow, disclosure, entry, end, ...variables, ...edges, graph];
  project.entities.forEach(entity => { entity.status = 'confirmed'; });
  const valid = validateProject(project); if (!valid.ok) throw new Error(JSON.stringify(valid.issues));
  await page.goto('./');
  await page.getByRole('button', { name: '保存ファイルを読み込む', exact: true }).click();
  await page.locator('input[type=file]').setInputFiles({ name: 'regressions.scenario', mimeType: 'application/octet-stream', buffer: Buffer.from(await exportScenario(project)) });
  await expect(page.getByRole('heading', { name: '検査済みの作品' })).toBeVisible();
  await page.getByLabel('復元方法と対象への影響を確認しました').check();
  await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click();
  await expect(page.getByRole('button', { name: '作品・保存' })).toBeAttached();
}

async function openByName(page: Page, name: string) {
  await navigate(page, /^検索/);
  await page.getByLabel('作品内を検索').fill(name);
  await page.locator('.entity-card').filter({ hasText: name }).first().click();
  return page.locator('.detail-panel');
}


export {seed,openByName,navigate};
