"""Compare actual measured files with the sealed Git objects and retained bytes."""
import argparse, hashlib, io, json, subprocess
from datetime import datetime, timezone
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--sealed',type=Path,required=True)
p.add_argument('--supplemental-binding',type=Path,required=True)
p.add_argument('--raw',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();assert not a.output.exists()
b=json.loads((a.sealed/'binding.json').read_text());extra=json.loads(a.supplemental_binding.read_text())
git=lambda *args:subprocess.check_output(['git',*args],cwd=a.repo,text=True).strip()
assert git('rev-parse','HEAD')==b['product']['commit'] and git('rev-parse','HEAD^{tree}')==b['product']['tree']
assert git('status','--porcelain')==''
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert json.loads((a.repo/'dist/build-info.json').read_text())==b['product']
source=b['sourceFiles'];request=''.join(b['product']['commit']+':'+r['path']+'\n' for r in source).encode()
stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=a.repo,input=request))
for row in source:
 header=stream.readline().decode().strip().split();assert len(header)==3 and header[1]=='blob'
 git_bytes=stream.read(int(header[2]));assert stream.read(1)==b'\n'
 actual=(a.repo/row['path']).read_bytes();retained=(a.sealed/'source-snapshot'/row['path']).read_bytes()
 assert header[0]==row['gitBlob'] and len(actual)==row['bytes'] and sha(actual)==row['sha256']
 assert actual==retained==git_bytes,row['path']
assert stream.read()==b''
assert sorted(str(x.relative_to(a.repo/'dist')) for x in (a.repo/'dist').rglob('*') if x.is_file())==sorted(r['path'] for r in b['distFiles'])
for row in b['distFiles']:
 actual=(a.repo/'dist'/row['path']).read_bytes();assert len(actual)==row['bytes'] and sha(actual)==row['sha256'] and actual==(a.sealed/'dist'/row['path']).read_bytes(),row['path']
for row in [*extra['original_documents'],extra['generated_runtime']]:
 raw=(a.repo/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
probe=a.repo/'docs/quality/current-review/evidence/rb10-candidate/candidate-8/measure-editable-performance.mjs'
assert sha(probe.read_bytes())=='ae0845d9856e3932013af73901e0f77d58e84d82370fd1e16bdeb186533640ae'
raw=a.raw.read_bytes();parsed=json.loads(raw)
raw_status=parsed.get('status',parsed.get('result','playwright_report' if 'stats' in parsed else 'finished' if parsed.get('finishedAt') else 'running'))
out={'recordedAt':datetime.now(timezone.utc).isoformat(),'product':b['product'],'sourceFiles':len(source),'distFiles':len(b['distFiles']),'actualSourceEqualsGitBlobAndSealedBytes':True,'actualDistEqualsSealedBytes':True,'original26DocumentsUnchanged':True,'generatedRuntimeUnchanged':True,'originalEditableProbeUnchanged':True,'raw':{'path':str(a.raw),'bytes':len(raw),'sha256':sha(raw)},'rawStatus':raw_status,'rawStats':parsed.get('stats'),'acceptanceInference':False}
a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
