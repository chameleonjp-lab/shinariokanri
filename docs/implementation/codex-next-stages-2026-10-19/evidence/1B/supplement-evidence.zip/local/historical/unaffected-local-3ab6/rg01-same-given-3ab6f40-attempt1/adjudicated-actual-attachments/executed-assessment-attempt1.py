"""Retain and assess actual supplemental RG01 observations without certifying real IME."""
import argparse, base64, gzip, hashlib, io, json, zipfile
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--report', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
a.output.mkdir(exist_ok=False)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report_bytes = a.report.read_bytes()
d = json.loads(report_bytes)
assert d['stats']['expected'] == 1 and not any(d['stats'][k] for k in ['skipped', 'unexpected', 'flaky'])
def attachments(value):
    if isinstance(value, dict):
        yield from value.get('attachments', [])
        for key, child in value.items():
            if key != 'attachments': yield from attachments(child)
    elif isinstance(value, list):
        for child in value: yield from attachments(child)
items = list(attachments(d))
retained = []
for item in items:
    if 'body' not in item: continue
    raw = base64.b64decode(item['body'])
    path = a.output / (item['name'] + '.gz')
    path.write_bytes(gzip.compress(raw, mtime=0))
    retained.append({'name': item['name'], 'path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                     'gzipBytes': path.stat().st_size, 'gzipSha256': sha(path.read_bytes())})
archives = [v for v in retained if v['name'].endswith('.scenario')]
assert len(archives) == 8
for row in archives:
    metadata = json.loads(base64.b64decode(next(v['body'] for v in items if v['name'] == row['name'] + '.json')))
    assert metadata['bytes'] == row['bytes'] and metadata['sha256'] == row['sha256']
    with zipfile.ZipFile(io.BytesIO(gzip.decompress(Path(row['path']).read_bytes()))) as z:
        assert z.testzip() is None
summary_raw = base64.b64decode(next(v['body'] for v in items if v['name'] == 'supplemental-original-RG01-summary.json'))
s = json.loads(summary_raw)
assert s['originalAssertionsExecutedUnchanged'] is True and s['wholeOriginalRegressionAcceptance'] is False
assert s['physicalDevice'] == 'not_run' and s['OSJapaneseComposition'].startswith('not_run')
rows = s['procedures']
assert [r['label'] for r in rows] == ['original-prefix-and-cold', 'front-deletion', 'paragraph-split',
    'paragraph-move', 'move-compensation-undo', 'paragraph-merge', 'overlapping-replacement', 'overlap-cold']
for row in rows[:6]:
    body = row['body']
    linked = [(block, link) for block in body for link in block.get('links', [])]
    ruby = [(block, mark) for block in body for mark in block.get('ruby', [])]
    assert len(linked) == len(ruby) == 1
    assert all(block['text'][v['start']:v['end']] == 'アオ' for block, v in linked + ruby)
    assert ruby[0][1]['text'] == 'あお'
    anchor = row['anchor']
    block = next(block for block in body if block['id'] == anchor['blockId'])
    assert block['text'][anchor['start']:anchor['end']] == 'アオ'
assert rows[4]['latestCommand']['compensatesOperationId'] == rows[3]['latestCommand']['operationId']
assert rows[2]['body'][0]['id'] == rows[3]['body'][1]['id'] == rows[4]['body'][0]['id'] == rows[5]['body'][0]['id']
for row in rows[6:]:
    block = row['body'][0]
    assert not block.get('links') and not block.get('ruby')
    unresolved = block['unresolvedAnnotations']
    assert len(unresolved) == 2 and {v['kind'] for v in unresolved} == {'link', 'ruby'}
    assert all(v['originalText'] == 'アオ' and v['reason'] for v in unresolved)
    assert row['anchor']['positionStatus'] == 'unresolved' and 'start' not in row['anchor'] and 'end' not in row['anchor']
assert rows[6]['body'] == rows[7]['body'] and rows[6]['anchor'] == rows[7]['anchor']
out = {'scope': 'Actual original-given RG01 supplemental execution on clean3ab6; not reassigned to a later product. Graph-only source impact can carry unaffected text-editing observations. Actual OS Japanese composition and physical-device acceptance stay not_run.',
       'report': {'path': str(a.report), 'bytes': len(report_bytes), 'sha256': sha(report_bytes)},
       'result': 'passed_local_original_given_supplement', 'checkpoints': [r['label'] for r in rows],
       'actualCompleteFiles': archives, 'retainedAttachments': retained,
       'physicalDevice': 'not_run', 'OSJapaneseComposition': s['OSJapaneseComposition'],
       'wholeOriginalRegressionAcceptance': False}
(a.output / 'ADJUDICATION.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'result': out['result'], 'checkpoints': len(rows), 'actualCompleteFiles': len(archives),
                  'wholeOriginalRegressionAcceptance': False}))
