import {createEntity,createProject,newId} from '/workspace/pr49-graph-measure-source/src/domain/model';
import type {EntityDataMap,EntityKind,ID,Policy} from '/workspace/pr49-graph-measure-source/src/domain/types';
import type {TrialRequest} from '/workspace/pr49-graph-measure-source/src/domain/runtime';
function fixture() {
  const project = createProject('RB01 試読の回帰');
  const add = <K extends EntityKind>(kind: K, data: Partial<EntityDataMap[K]> = {}) => {
    const entity = createEntity(project.projectId, kind, kind, kind === 'flow_node' ? { gate: null, ...data } as Partial<EntityDataMap[K]> : data);
    entity.status = 'confirmed';
    project.entities.push(entity);
    return entity;
  };
  const entry = add('flow_node', { nodeType: 'entry' });
  const end = add('flow_node', { nodeType: 'terminal', terminalReason: '作者が意図した終わり' });
  const graph = add('flow_graph', { nodeIds: [entry.id, end.id], edgeIds: [], entryIds: [entry.id], exitIds: [end.id] });
  const node = (data: Partial<EntityDataMap['flow_node']>) => {
    const created = add('flow_node', data);
    graph.data.nodeIds.push(created.id);
    return created;
  };
  const edge = (fromId: ID, toId: ID, data: Partial<EntityDataMap['flow_edge']> = {}) => {
    const created = add('flow_edge', { fromId, toId, ...data });
    graph.data.edgeIds.push(created.id);
    return created;
  };
  return { project, add, entry, end, graph, node, edge };
}


function foreshadowFixture(changesCondition: boolean, initial = false) {
  const base = fixture();
  const { add, entry, end, node, edge } = base;
  const canReveal = add('variable', { key: 'can_reveal', valueType: 'boolean', initial: { type: 'boolean', value: true } });
  const closeReveal = add('effect', { operation: 'set', targetId: canReveal.id, value: { type: 'boolean', value: false } });
  const clueScene = add('scene', { body: [{ id: newId(), kind: 'paragraph', text: '必須の手掛かり' }] });
  const payoffScene = add('scene', { body: [{ id: newId(), kind: 'paragraph', text: '秘密の回収' }] });
  const clueNode = node({ nodeType: 'scene', sceneId: clueScene.id });
  const payoffNode = initial ? entry : node({ nodeType: 'scene', sceneId: payoffScene.id });
  if (initial) entry.data.sceneId = payoffScene.id;
  const question = add('foreshadow', { resolutionPolicy: 'this_work' });
  const clue = add('disclosure', { foreshadowId: question.id, anchor: { entityId: clueScene.id }, role: 'clue', stage: 'hint' });
  const payoff = add('disclosure', {
    foreshadowId: question.id, anchor: { entityId: payoffScene.id }, role: 'payoff', stage: 'reveal',
    condition: { op: 'compare', variableId: canReveal.id, comparator: 'eq', value: { type: 'boolean', value: true } },
    knowledgeEffects: changesCondition ? [closeReveal.id] : [],
  });
  question.data.requiredInfo = [clue.id];
  const skip = initial ? undefined : edge(entry.id, payoffNode.id);
  const viaClue = initial ? undefined : edge(entry.id, clueNode.id);
  const continueEdge = initial ? undefined : edge(clueNode.id, payoffNode.id);
  const finish = edge(payoffNode.id, end.id);
  return { ...base, canReveal, closeReveal, clue, payoff, question, payoffNode, clueNode, skip, viaClue, continueEdge, finish };
}


function rejectedEffectFixture(policy: Policy, mixed: boolean) {
  const f = fixture();
  f.entry.data.executionPolicy = policy;
  f.entry.data.trigger = { event: 'manual', eventKey: 'choose', repeat: 'once' };
  const key = f.add('variable', { key: 'key', valueType: 'boolean', initial: { type: 'boolean', value: false } });
  const item = f.add('item', { itemMode: 'type' });
  const holder = f.add('character');
    const acquisitionSource = f.add('source', { sourceType: 'observation', locator: '入口で示した情報' });
  const fact = f.add('assertion', { subjectId: holder.id, holderId: holder.id, predicate: '秘密', value: { type: 'boolean', value: true }, truthKind: 'belief', sourceIds: [acquisitionSource.id], evidenceLocation: { entityId: f.entry.id } });
  const seen = f.add('note');
  const valid = [
    f.add('effect', { operation: 'set', targetId: key.id, value: { type: 'boolean', value: true } }),
    f.add('effect', { operation: 'grant', targetId: item.id, value: { type: 'integer', value: 1 } }),
    f.add('effect', { operation: 'assert', targetId: fact.id, value: { type: 'boolean', value: true } }),
    f.add('effect', { operation: 'mark_seen', targetId: seen.id }),
  ];
  const rejected = f.add('effect', { operation: 'set', targetId: key.id, value: { type: 'boolean', value: true } });
  rejected.status = 'rejected';
  const selected = f.edge(f.entry.id, f.end.id, { effectIds: policy === 'all_match' && mixed ? valid.map(effect => effect.id) : [...(mixed ? valid.map(effect => effect.id) : []), rejected.id], priority: 1 });
  if (policy === 'all_match' && mixed) f.edge(f.entry.id, f.end.id, { effectIds: [rejected.id], priority: 2 });
  const request: TrialRequest = { random: policy === 'manual_choice', edgeId: selected.id, event: { event: 'manual', eventKey: 'choose', occurrenceId: 'choose-1' } };
  return { ...f, key, valid, rejected, selected, request };
}


export {foreshadowFixture,rejectedEffectFixture};
