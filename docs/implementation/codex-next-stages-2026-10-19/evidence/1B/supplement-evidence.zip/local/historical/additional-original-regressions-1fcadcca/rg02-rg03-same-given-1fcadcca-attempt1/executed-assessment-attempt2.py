"""Assess retained original-given UI reports, actual attached archive bytes and real process exit."""
import argparse,json,hashlib,base64,zipfile,io
from pathlib import Path
from datetime import datetime,timezone
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--attempt',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert not a.output.exists();sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
exit=read(a.attempt/'execution/exit.json');assert exit['returncode']==0 and exit['executedWrapperBytesUnchanged']
closure=read(a.attempt/'closure.json');assert closure['sourceFiles']==513 and closure['distFiles']==13 and closure['actualSourceEqualsGitBlobAndSealedBytes'] and closure['actualDistEqualsSealedBytes'] and closure['original26DocumentsUnchanged'] and closure['generatedRuntimeUnchanged'] and closure['originalEditableProbeUnchanged']
raw=(a.attempt/'results.json').read_bytes();report=json.loads(raw)
assert report['stats']['expected']==12 and all(report['stats'][k]==0 for k in ['unexpected','flaky','skipped'])
original=(a.attempt/'executed-inputs/original-runtime-regressions.test.ts').read_bytes();prep=read(a.attempt/'executed-inputs/PREPARATION.json');assert sha(original)==prep['originalSource']['sha256']
assert len(original)==prep['originalSource']['bytes']==20734
src=original.decode();chunks=[src[src.index('function fixture()'):src.index('function foreshadowFixture')],src[src.index('function foreshadowFixture'):src.index('async function savePinned')],src[src.index('function rejectedEffectFixture'):src.index("describe('RG-R03")]]
module=(a.attempt/'executed-inputs/original-fixtures.ts').read_text()
for c,m in zip(chunks,prep['functions']):assert c in module and len(c.encode())==m['bytes'] and sha(c.encode())==m['sha256']
rows=[];files=[];archives=0

def tests(s):
 for spec in s.get('specs',[]):
  for t in spec['tests']:yield spec,t
 for child in s.get('suites',[]):yield from tests(child)
for suite in report['suites']:
 for spec,t in tests(suite):
  assert len(t['results'])==1;result=t['results'][0];assert result['status']=='passed' and result['retry']==0 and not result.get('errors')
  bodies={};zips=[]
  for f in result['attachments']:
   if 'body' in f:payload=base64.b64decode(f['body'])
   else:
    path=Path(f['path']);assert path.is_relative_to(a.attempt.resolve());payload=path.read_bytes()
   ident={'testId':spec['id'],'name':f['name'],'bytes':len(payload),'sha256':sha(payload)};files.append(ident)
   if f['contentType']=='application/json':bodies[f['name']]=json.loads(payload)
   if f['contentType']=='application/zip' and f['name'].endswith('.scenario'):
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
     assert z.testzip() is None;assert 'data/project.json' in z.namelist();data=json.loads(z.read('data/project.json'))
    zips.append((f['name'],payload,data));archives+=1
  build=bodies['actual-product.json']['build'];assert build['commit']=='1fcadcca703863873a57d297e83b1b184e63e778' and build['tree']=='8ac6e33a98455204aa265be5ce86ee5be168a97b' and build['dirty'] is False and build['version']=='8ec3a03810bb0cf1b1b4'
  if spec['title'].startswith('RG-R02'):
   observed=bodies['RG-R02-actual.json'];given=bodies['RG-R02-given.json'];facts=given['facts'];assert len(zips)==2
   assert observed['route']==facts['route'] and observed['changes']==facts['changesCondition']
   assert observed['finalState']['variableValues'][facts['canReveal']]=={'type':'boolean','value':not observed['changes']}
   missing=[f for f in observed['findings'] if f['code']=='REQUIRED_INFO_MISSING' and f.get('payoffId')==facts['payoff']]
   if observed['route']=='via':assert not missing
   else:assert len(missing)==1 and missing[0]['status']=='candidate' and missing[0]['targetId']==facts['question'] and missing[0]['missingInfoIds']==[facts['clue']]
  else:
   observed=bodies['RG-R03-actual.json'];given=bodies['RG-R03-given.json'];assert len(zips)==3
   assert observed['beforeVisible']==observed['afterVisible'] and observed['beforeHeading']==observed['afterHeading']
   assert 'REFERENCE_INVALID' in observed['error'] and '不採用' in observed['error']
   assert observed['authorNativeUnchanged'] and observed['failedOperationNotAddedToHistory']
   assert zips[1][2]==zips[2][2]
  givenzip=next(b for n,b,d in zips if n.endswith('-given.scenario'))
  assert len(givenzip)==given['fixtureBytes'] and sha(givenzip)==given['fixtureSha256']
  rows.append({'title':spec['title'],'testId':spec['id'],'status':'passed','actualObservation':observed,'given':given})
assert len(rows)==12 and archives==30
out={'recordedAt':datetime.now(timezone.utc).isoformat(),'result':'passed_original_given_normal_UI_R02_R03','scope':'Additional Chromium normal UI evidence on exact original unchanged fixture functions, composed with the existing original unit/3-engine CI proof. Does not replace any original test or certify physical environments.','product':rows[0]['given'].get('product',{'commit':'1fcadcca703863873a57d297e83b1b184e63e778','build':'8ec3a03810bb0cf1b1b4'}),'raw':{'path':str(a.attempt/'results.json'),'bytes':len(raw),'sha256':sha(raw)},'actualChildExitCode':0,'originalFixtureFunctionsUnmodified':True,'passed':12,'actualArchives':30,'retainedAttachments':files,'observations':rows,'closure':{'path':str(a.attempt/'closure.json'),'bytes':(a.attempt/'closure.json').stat().st_size,'sha256':sha((a.attempt/'closure.json').read_bytes())}}
a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':12,'actualArchives':30,'result':out['result']}))
