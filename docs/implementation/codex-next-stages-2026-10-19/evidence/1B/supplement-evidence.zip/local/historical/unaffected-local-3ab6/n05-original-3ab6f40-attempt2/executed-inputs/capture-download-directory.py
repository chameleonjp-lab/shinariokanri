"""Passively retain actual downloads using hard links in a dedicated test directory."""
import argparse, ctypes, hashlib, json, os, re, select, struct, subprocess
from datetime import datetime, timezone
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--downloads',type=Path,required=True)
p.add_argument('--retained',type=Path,required=True)
p.add_argument('--manifest',type=Path,required=True)
p.add_argument('command',nargs=argparse.REMAINDER)
a=p.parse_args();command=a.command[1:] if a.command and a.command[0]=='--' else a.command
assert command and not a.manifest.exists()
a.downloads.mkdir(parents=True,exist_ok=False);a.retained.mkdir(parents=True,exist_ok=False)
libc=ctypes.CDLL(None,use_errno=True)
libc.inotify_init1.argtypes=[ctypes.c_int];libc.inotify_init1.restype=ctypes.c_int
libc.inotify_add_watch.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_uint32];libc.inotify_add_watch.restype=ctypes.c_int
fd=libc.inotify_init1(os.O_NONBLOCK|os.O_CLOEXEC);assert fd>=0
assert libc.inotify_add_watch(fd,os.fsencode(a.downloads),0x8|0x80)>=0
events=[];errors=[];linked={}
def drain():
 while True:
  try:data=os.read(fd,65536)
  except BlockingIOError:return
  offset=0
  while offset<len(data):
   _,mask,_,length=struct.unpack_from('iIII',data,offset);offset+=16
   name=os.fsdecode(data[offset:offset+length].split(b'\0',1)[0]);offset+=length
   if not re.fullmatch('[a-f0-9-]{20,64}',name) or name in linked:continue
   source=a.downloads/name;target=a.retained/(name+'.raw')
   try:
    if source.is_symlink() or not source.is_file():continue
    os.link(source,target)
    assert source.stat().st_ino==target.stat().st_ino
    row={'capturedAt':datetime.now(timezone.utc).isoformat(),'source':str(source),'retained':str(target),'eventMask':mask,'sameActualInodeAtCapture':True}
    linked[name]=row;events.append(row)
   except FileNotFoundError:errors.append({'name':name,'error':'source disappeared before capture'})
child=subprocess.Popen(command)
try:
 while child.poll() is None:
  if select.select([fd],[],[],1)[0]:drain()
 drain();code=child.wait()
 for row in events:
  raw=Path(row['retained']).read_bytes();row['bytes']=len(raw);row['sha256']=hashlib.sha256(raw).hexdigest();row['sourceExistsAfterChild']=Path(row['source']).exists()
  try:
   value=json.loads(raw);row['parsedJSONStatus']=value.get('status') if isinstance(value,dict) else None
  except (ValueError,UnicodeDecodeError):row['parsedJSONStatus']=None
 complete=code==0 and len(events)>=2 and all(row['parsedJSONStatus']=='unknown' for row in events) and not errors
 result={'scope':'Actual download inodes passively hard-linked after complete-name close/move events, read after child exit. No test source, browser API, bytes, fixture, assertions or time limits changed. Dedicated downloadsPath is the only browser binding change.','childReturncode':code,'events':events,'errors':errors,'result':'retained_actual_downloads' if complete else 'capture_requires_review'}
 a.manifest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'captureResult':result['result'],'files':len(events),'childReturncode':code}),flush=True)
finally:os.close(fd)
raise SystemExit(0 if complete else code or 1)
