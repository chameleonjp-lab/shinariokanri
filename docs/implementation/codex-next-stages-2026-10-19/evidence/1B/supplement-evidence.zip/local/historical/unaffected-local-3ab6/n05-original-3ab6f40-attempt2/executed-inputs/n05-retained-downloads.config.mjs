import original from '/workspace/pr49-measure-source/tests/rb10/playwright.config.ts';
if(!process.env.N05_DOWNLOADS_PATH)throw Error('Dedicated actual downloads path required');
export default {...original,testDir:'/workspace/pr49-measure-source/tests/rb10',webServer:{...original.webServer,cwd:'/workspace/pr49-measure-source'},projects:original.projects.map(project=>({...project,use:{...project.use,launchOptions:{...project.use.launchOptions,downloadsPath:process.env.N05_DOWNLOADS_PATH}}}))};
