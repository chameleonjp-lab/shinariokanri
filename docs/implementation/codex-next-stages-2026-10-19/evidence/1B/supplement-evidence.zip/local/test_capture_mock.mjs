import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {EventEmitter} from 'node:events';
import {stripTypeScriptTypes} from 'node:module';
import {bridgeSource,stageSource,ORIGINAL_IMPORT} from '/workspace/shinariokanri-1b/scripts/acceptance/capture_n05_downloads.mjs';
const dir=await mkdtemp(join(tmpdir(),'capture-mock-'));
const body='\n// literal body and timeout must be retained\n';
assert.equal(stageSource(ORIGINAL_IMPORT+body).slice((stageSource(ORIGINAL_IMPORT+body)).indexOf('\n')),body);
assert.throws(()=>stageSource('other import\n'));
async function trial(name,run,expectedError){
 const output=join(dir,name);await mkdir(output);await mkdir(join(output,'downloads'));
 let fixture;
 globalThis.__captureBase={extend:definitions=>{fixture=definitions.captureN05[0];return {};}};
 const source=bridgeSource({trial:name,candidate:'candidate',build:{version:'v'}},output)
  .replace("import {test as base,expect,type Page} from '@playwright/test';",'const base=globalThis.__captureBase,expect={};');
 const javascript=stripTypeScriptTypes(source,{mode:'strip'});
 await import('data:text/javascript;base64,'+Buffer.from(javascript).toString('base64'));
 const page=new EventEmitter(),attached=[];
 const promise=fixture({page},()=>run(page,output),{testId:'actual-test',project:{name:'chromium'},retry:0,attach:async(name,value)=>attached.push({name,...value})});
 if(expectedError){await assert.rejects(promise,expectedError);return;}
 await promise;
 const descriptor=JSON.parse(await readFile(join(output,'events.json')));
 assert.deepEqual(descriptor.events.map(x=>x.event),[1,2]);
 assert.equal(attached.length,1);assert.deepEqual(JSON.parse(attached[0].body),descriptor);
 assert.equal(descriptor.events[0].filename,'download-1.json');
 assert.equal(descriptor.events[1].filename,'download-2.json');
 assert.equal(await readFile(join(output,'downloads/1.json'),'utf8'),'{"actual":1}');
 assert.equal(await readFile(join(output,'downloads/2.json'),'utf8'),'{ "actual":1 }');
}
function download(index, options={}){
 return {failure:async()=>options.failure??null,suggestedFilename:()=>`download-${index}.json`,url:()=>`blob:event-${index}`,saveAs:async path=>{
  await options.pending;
  await writeFile(path,index===1?'{"actual":1}':'{ "actual":1 }',{flag:'wx'});
 }};
}
try{
 await trial('two-events-complete-before-descriptor',async(page,output)=>{
  let finish;const pending=new Promise(resolve=>finish=resolve);
  page.emit('download',download(1));page.emit('download',download(2,{pending}));
  await assert.rejects(readFile(join(output,'events.json')),/ENOENT/);
  finish();
 });
 await trial('one-event',async page=>{page.emit('download',download(1));},/exactly two/);
 await trial('download-failure',async page=>{page.emit('download',download(1,{failure:'aborted'}));},/Download failed/);
 console.log('capture mock: two actual events, completion barrier, distinct bytes, one-event and failed-download rejection passed');
}finally{delete globalThis.__captureBase;await rm(dir,{recursive:true,force:true});}
