"""Mutate copies of actual retained attachments, never their immutable originals.

Seven actual historical RG probes are runnable immediately. Add --n05 and
--binding after the current candidate produces two real downloads for all eleven.
"""
import argparse
import base64
import copy
import importlib.util
import json
from pathlib import Path
import traceback

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repository',type=Path,required=True)
p.add_argument('--historical',type=Path,required=True)
p.add_argument('--n05',type=Path)
p.add_argument('--binding',type=Path)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();repo=a.repository.resolve();historical=a.historical.resolve()
spec=importlib.util.spec_from_file_location('actual_supplements',repo/'scripts/acceptance/verify_supplements.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
output=a.output.resolve();output.mkdir(exist_ok=False)
manifest={'format':'phase3-supplement-actual-counterexamples/1','reconstruction':'New probes from original given/rejection conditions; not recovered uncommitted 04a7 code','repository':str(repo),'verifierSHA256':v.sha((repo/'scripts/acceptance/verify_supplements.py').read_bytes()),'cases':[],'positives':[]}

def describe(path):
 raw=Path(path).read_bytes();return dict(path=str(path),bytes=len(raw),sha256=v.sha(raw))

def put(e,name,value):
 raw=json.dumps(value,ensure_ascii=False,indent=2).encode()
 e.rows[name]={'name':name,'body':base64.b64encode(raw).decode(),'contentType':'application/json'}

def put_raw(e,name,raw):
 e.rows[name]={'name':name,'body':base64.b64encode(raw).decode(),'contentType':'application/zip'}

def save_changes(case,changes):
 folder=output/case;folder.mkdir()
 rows=[]
 for index,(name,raw) in enumerate(changes):
  path=folder/(str(index+1)+'-'+Path(name).name)
  path.write_bytes(raw);rows.append(describe(path))
 return rows

def reject(case,given,condition,call,changes):
 row=dict(id=case,given=given,expectedRejection=condition,changedInputs=save_changes(case,changes))
 try:
  call()
 except Exception as error:
  row.update(actual='rejected',exception=type(error).__name__,message=str(error))
  if isinstance(error,ValueError) and condition in str(error):row['passed']=True
  else:row.update(passed=False,traceback=traceback.format_exc())
 else:row.update(actual='accepted',passed=False)
 manifest['cases'].append(row)
 print(case,row['actual'],row.get('message',''),flush=True)

for label in v.HISTORICAL:
 v.historical_files(repo,historical,label)
rg01=historical/'unaffected-local-3ab6/rg01-same-given-3ab6f40-attempt1'
rg23=historical/'additional-original-regressions-1fcadcca/rg02-rg03-same-given-1fcadcca-attempt1'
manifest['originalInputs']=[describe(rg01/'results.json'),describe(rg01/'actual-given.scenario'),describe(rg23/'results.json')]
original01=next(iter(v.reports(rg01/'results.json').values()))
given01=v.scenario((rg01/'actual-given.scenario').read_bytes())[0]
original23=v.reports(rg23/'results.json')
product=next(iter(original23.values())).json('actual-product.json')
build,buildhash=product['build'],product['buildInfoSHA256']
v.assess_rg01(original01,given01);manifest['positives'].append('historical RG01 original 8 checkpoints passed')
v.assess_rg23(original23,original23,build,buildhash);manifest['positives'].append('historical RG02/RG03 original six conditions each passed')

# RG01 count alone cannot identify its original eight operations.
e=copy.deepcopy(original01);name='supplemental-original-RG01-summary.json';j=e.json(name);j['procedures'][3]=copy.deepcopy(j['procedures'][2]);put(e,name,j)
reject('RG-05-eight-checkpoint-substitution','Actual original RG01 eight checkpoints; substitute move with split while keeping count=8','eight checkpoint',lambda:v.assess_rg01(e,given01),[(name,e.raw(name))])

# Change both self-reported copies, leaving the actual complete file unchanged.
e=copy.deepcopy(original01);summary=e.json(name);summary['procedures'][1]['anchor']['start']=1;put(e,name,summary)
checkpoint='actual-front-deletion.json';j=e.json(checkpoint);j['anchor']['start']=1;put(e,checkpoint,j)
reject('RG-06-actual-anchor-substitution','Original front deletion anchor start=0; self-report start=1 in summary and checkpoint','actual complete file differs',lambda:v.assess_rg01(e,given01),[(name,e.raw(name)),(checkpoint,e.raw(checkpoint))])

current=copy.deepcopy(original23);title=next(t for t in current if 'changes=false route=skip' in t);current[title+' substituted']=current.pop(title)
reject('RG-07-six-condition-substitution','Original RG02 six changes/route combinations; replace one title while keeping six','six plus six',lambda:v.assess_rg23(current,original23,build,buildhash),[('test-inventory.json',json.dumps(list(current)).encode())])

current=copy.deepcopy(original23);e=current[next(t for t in current if 'changes=false route=skip' in t)];raw,project=v.complete(e,1)
project['entities'][next(i for i,x in enumerate(project['entities']) if x['kind']=='trace')]['data']['steps'][0]['before']['rngPosition']=1
# Repack a genuine original archive and update its internal manifest and output hashes,
# so rejection must examine original full trace values rather than a stale digest.
import io,zipfile
old_zip=zipfile.ZipFile(io.BytesIO(raw));data=json.dumps(project,ensure_ascii=False,separators=(',',':')).encode()
internal=json.loads(old_zip.read('manifest.json'))
for row in internal['files']:
 if row['path']=='data/project.json':row.update(byteSize=len(data),sha256=v.sha(data))
new=io.BytesIO()
with zipfile.ZipFile(new,'w') as z:
 for name1 in old_zip.namelist():z.writestr(name1,data if name1=='data/project.json' else json.dumps(internal).encode() if name1=='manifest.json' else old_zip.read(name1))
raw=new.getvalue();backup_name='complete-backup-001.scenario';put_raw(e,backup_name,raw)
j=e.json(backup_name+'.json');j.update(fileBytes=len(raw),fileSHA256=v.sha(raw));put(e,backup_name+'.json',j)
j=e.json('RG-R02-actual.json');j['actualCompleteSHA256']=v.sha(raw);put(e,'RG-R02-actual.json',j)
reject('RG-08-full-trace-state-substitution','Original actual RG02 trace initial rngPosition=0; mutate before state to 1, reseal full ZIP and observed output SHA','full trace',lambda:v.assess_rg23(current,original23,build,buildhash),[(backup_name,raw),(backup_name+'.json',e.raw(backup_name+'.json')),('RG-R02-actual.json',e.raw('RG-R02-actual.json'))])

current=copy.deepcopy(original23);e=current[next(t for t in current if 'changes=false route=skip' in t)];del e.rows['complete-backup-001.scenario']
reject('RG-09-missing-actual-attachment','Original RG02 actual complete output removed; all observations stay present','Missing attachment',lambda:v.assess_rg23(current,original23,build,buildhash),[('removed-attachment.json',json.dumps({'removed':'complete-backup-001.scenario'}).encode())])

current=copy.deepcopy(original23);e=current[next(t for t in current if 'policy=all_match mixed=true' in t)];j=e.json('RG-R03-actual.json');j['mixed']=False;put(e,'RG-R03-actual.json',j)
reject('RG-10-policy-mixed-substitution','Original actual RG03 all_match mixed=true; substitute mixed=false observation','policy/mixed',lambda:v.assess_rg23(current,original23,build,buildhash),[('RG-R03-actual.json',e.raw('RG-R03-actual.json'))])

current=copy.deepcopy(original23);e=current[next(iter(current))];j=e.json('actual-product.json');j['build']['version']='other-build';put(e,'actual-product.json',j)
reject('RG-11-other-build','Original actual RG02/03 product version replaced while report remains passed','actual build',lambda:v.assess_rg23(current,original23,build,buildhash),[('actual-product.json',e.raw('actual-product.json'))])

if a.n05:
 if not a.binding:raise ValueError('--binding required with --n05')
 n05=a.n05.resolve();binding_path=a.binding.resolve();binding=v.load(binding_path)
 v.verify_n05(repo,binding_path,binding,n05);manifest['positives'].append('current candidate N05 real two-download full provenance passed')
 manifest['n05Inputs']=[describe(n05/n) for n in ('capture.json','events.json','results.json','downloads/1.json','downloads/2.json')]
 descriptor=v.load(n05/'events.json');events=descriptor['events'];provenance={k:descriptor[k] for k in ('format','trial','bindingSHA256','candidate','tree','build','originalSHA256','packageSHA256','fixture')}
 for case,given,condition,mutate in [
  ('N05-01-one-missing','Two actual completed N05 downloads; drop second event','missing/sequenced',lambda rows:rows.pop()),
  ('N05-02-json-copy','Copy actual first event descriptor as second output; no second event','missing/sequenced',lambda rows:rows.__setitem__(1,copy.deepcopy(rows[0]))),
  ('N05-03-other-trial','Use actual second original with another trial UUID','mixed event',lambda rows:rows[1].__setitem__('trial','other-trial')),
  ('N05-04-other-build','Use actual second original with another build','mixed event',lambda rows:rows[1].__setitem__('build',{'version':'other-build'})),
 ]:
  rows=copy.deepcopy(events);mutate(rows)
  reject(case,given,condition,lambda:v.download_payloads(n05,rows,provenance),[('events.json',json.dumps(rows,ensure_ascii=False,indent=2).encode())])
else:
 manifest['blocked']=['N05-01-one-missing','N05-02-json-copy','N05-03-other-trial','N05-04-other-build']
manifest['passed']=all(row['passed'] for row in manifest['cases'])
manifest['scope']='Historical positive/rejection probes do not certify the current candidate RG execution; N05 remains blocked until real current originals are supplied.' if not a.n05 else 'Actual retained input rejection probes; independent supplement assessment remains separate from formal acceptance.'
(output/'probe.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if manifest['passed'] else 1)
