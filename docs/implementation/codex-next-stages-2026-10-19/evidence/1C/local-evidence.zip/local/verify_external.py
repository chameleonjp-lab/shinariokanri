from pathlib import Path
import re,json,collections,hashlib
r=Path('/workspace/shinariokanri-1c');s=(r/'docs/acceptance/phase3/VERIFICATION.md').read_text()
a=(r/'docs/quality/pr49-followup-2026-10-15/EXTERNAL_CASES.md').read_text()
ids=re.findall(r'^## (AT-[A-Z]\d+)\s*$',s,re.M); original=re.findall(r'^\| (AT-[A-Z]\d+) \|',a,re.M)
assert len(ids)==len(set(ids))==22 and set(ids)==set(original)
cases={x['id']:x for x in json.loads((r/'docs/data/acceptance_cases.json').read_text())};counts=collections.Counter()
for case in ids:
 section=s.split('## '+case+'\n',1)[1].split('\n## ',1)[0]
 counts[re.search(r'分類: (.*?)。',section)[1]]+=1
 for key in ['given','when','then','negative_or_edge']:
  assert f'| {key} | {cases[case][key]} |' in section,(case,key)
 for label in ['必要環境・人:', '隔離入力・成果物:', '実施・記録手順:', '次の一操作:', '安全な空の記録様式', 'PREPARED', 'BLOCKED / 未実行']:
  assert label in section,(case,label)
 form=json.loads(re.search(r'```json\n(.*?)\n```',section,re.S)[1]);assert form['case_id']==case and form['result']=='not_run'
 assert set(form['clauses'])=={'given','when','then','negative_or_edge'}
 for c in form['clauses'].values():assert c=={'observed':'','raw_path':'','raw_sha256':'','status':'not_run'}
assert counts=={'実機':9,'実機＋実サービス':6,'実Auth':4,'ゲーム':2,'契約/費用':1}
fixture=s.split('## 既存入力・生成手順の原本対応（22件）',1)[1].split('\n## ',1)[0]
assert set(re.findall(r'^\| (AT-[A-Z]\d+) \|',fixture,re.M))==set(ids)
refs=re.findall(r'\[([^\]]+)\]\(\.\./\.\./\.\./[^)]+\)<br>`([a-f0-9]{64})`',fixture)
for path,sha in refs: assert hashlib.sha256((r/path).read_bytes()).hexdigest()==sha,path
for gate in ['realDevices','accessibilityManual','performance','restoreDrill','syncLive','rlsLive','independentReview','hostingCosts','directLinks']: assert f'`{gate}`' in s
print('PASS 22 exact unique IDs; 88 verbatim clauses; 22 blank JSON; groups',dict(counts),';',len(refs),'fixture/source SHA references; 9 gates')
