# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-authoring-continuity.spec.ts >> phase3: 空作品の通常制作から参照・試読・履歴・秘密出力・完全復元・offline再編集までつながる
- Location: tests/e2e/phase3-authoring-continuity.spec.ts:10:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: locator('.entity-card h3')
Expected: "霧の門"
Error: strict mode violation: locator('.entity-card h3') resolved to 3 elements:
    1) <h3>霧の門</h3> aka getByRole('button', { name: '01' })
    2) <h3>変更確認: 第一章</h3> aka getByRole('button', { name: '変更確認: 第一章 確認待ち 「第一章」に関係する情報が変更されました。内容への影響を確認してください。 変更元: 場面「霧の門」 (e23ad641-' })
    3) <h3>変更確認: 霧の門</h3> aka getByRole('button', { name: '変更確認: 霧の門 確認待ち 「霧の門」に関係する情報が変更されました。内容への影響を確認してください。 変更元: 章「第一章」 (f7c8c441-2e97' })

Call log:
  - Expect "toHaveText" locator('.entity-card h3') with timeout 5000ms
  - waiting for locator('.entity-card h3')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - button "アカウント・専用同期" [ref=e6] [cursor=pointer]
      - generic [ref=e7]: この端末の作品
    - group "任意持出し診断" [ref=e8]:
      - generic "この作業の診断を確認・持出し" [ref=e9]
  - generic [ref=e11]:
    - link "本文へ移動" [ref=e12] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "主要ナビゲーション" [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]: S
        - generic [ref=e16]: シナリオ管理
      - button "第3段階の連続制作 作品一覧へ ⌄" [ref=e17] [cursor=pointer]:
        - generic [ref=e19]:
          - strong [ref=e20]: 第3段階の連続制作
          - generic [ref=e21]: 作品一覧へ
        - generic [ref=e22]: ⌄
      - generic [ref=e23]: WORKSPACE
      - navigation [ref=e24]:
        - button "年表" [ref=e25] [cursor=pointer]
        - button "構成" [ref=e26] [cursor=pointer]
        - button "資料 1" [ref=e27] [cursor=pointer]:
          - text: 資料
          - generic [ref=e28]: "1"
        - button "検索" [ref=e29] [cursor=pointer]
      - generic [ref=e30]:
        - generic [ref=e31]: QUICK NOTE
        - button "アイデアを残す" [ref=e32] [cursor=pointer]
      - generic [ref=e34]:
        - button "作品・保存" [ref=e35] [cursor=pointer]
        - generic [ref=e38]:
          - strong [ref=e39]: この端末に保存
          - generic [ref=e40]: 同期接続先は未設定
        - button "暗い配色にする" [ref=e41] [cursor=pointer]
    - generic [ref=e42]:
      - banner [ref=e43]:
        - generic [ref=e44]:
          - generic "第3段階の連続制作" [ref=e45]
          - generic [ref=e46]: /
          - generic [ref=e47]: 検索
        - status [ref=e48]:
          - generic [ref=e50]: 端末内保存済み
          - generic [ref=e51]: LOCAL
      - main [ref=e52]:
        - generic [ref=e53]:
          - generic [ref=e54]:
            - generic [ref=e55]: FIND IN YOUR STORY
            - heading "検索" [level=1] [ref=e56]
            - paragraph [ref=e57]: 本文も、設定も。作品の中から見つける。
          - button "追加" [ref=e58] [cursor=pointer]
        - group [ref=e59]:
          - generic "最近開いた情報・お気に入り" [ref=e60] [cursor=pointer]
        - generic [ref=e63]:
          - tablist "検索と整理" [ref=e64]:
            - tab "複合検索・一覧" [selected] [ref=e65] [cursor=pointer]
            - tab "五十音・分類索引" [ref=e66] [cursor=pointer]
            - tab "見直しと統合" [ref=e67] [cursor=pointer]
          - generic [ref=e68]:
            - generic [ref=e69]: 作品内を検索
            - textbox "作品内を検索" [ref=e70]:
              - /placeholder: 名前・読み・別名・本文
              - text: 霧の門
          - generic [ref=e71]:
            - combobox "情報の種類" [ref=e72]:
              - option "すべての種類" [selected]
              - option "人物"
              - option "グループ"
              - option "場所"
              - option "物品"
              - option "設定"
              - option "メモ"
              - option "目標"
              - option "地図"
              - option "移動経路"
              - option "口調"
              - option "用語"
              - option "章"
              - option "場面"
              - option "台詞"
              - option "出来事"
              - option "分岐図"
              - option "進行ノード"
              - option "進行線"
              - option "クエスト"
              - option "状態変数"
              - option "効果"
              - option "事実・認識"
              - option "伏線"
              - option "手掛かり・回収"
              - option "途中開始点"
              - option "試読記録"
              - option "外部契約"
              - option "制作タスク"
              - option "企画"
              - option "制作判断"
              - option "ゲーム仕様"
              - option "媒体版"
              - option "資料・出所"
              - option "添付素材"
              - option "演出"
              - option "絵コンテ"
              - option "翻訳"
              - option "収録"
              - option "レビュー"
              - option "一覧"
              - option "雛形"
              - option "公開版"
              - option "公開投影"
            - combobox "情報の状態で絞り込む" [ref=e73]:
              - option "すべての状態" [selected]
              - option "確定"
              - option "下書き"
              - option "確認待ち"
              - option "不採用"
              - option "別案"
            - generic [ref=e75]:
              - text: 参加人物で絞り込む
              - combobox "参加人物で絞り込む" [ref=e76]:
                - option "すべての参加人物" [selected]
                - option "𠮷野"
            - combobox "制作進捗で絞り込む" [ref=e77]:
              - option "すべての制作進捗" [selected]
              - option "未着手"
              - option "作業中"
              - option "完了"
              - option "確認待ち"
            - generic [ref=e79]:
              - text: 章で絞り込む
              - combobox "章で絞り込む" [ref=e80]:
                - option "すべての章" [selected]
                - option "第一章"
            - generic [ref=e82]:
              - text: 伏線で絞り込む
              - combobox "伏線で絞り込む" [ref=e83]:
                - option "すべての伏線" [selected]
            - combobox "伏線の回収方針" [ref=e84]:
              - option "すべての回収方針" [selected]
              - option "本作で回収"
              - option "続編で回収"
              - option "意図的に未回収"
              - option "ミスリード"
              - option "未決定"
              - option "不採用"
            - combobox "手掛かり・回収の役割" [ref=e85]:
              - option "すべての役割" [selected]
              - option "手掛かり"
              - option "回収"
            - combobox "提示段階で絞り込む" [ref=e86]:
              - option "すべての提示段階" [selected]
              - option "示唆"
              - option "疑念"
              - option "補強"
              - option "開示"
              - option "別案"
          - generic [ref=e88]:
            - text: 保存した一覧を再表示
            - combobox "保存した一覧を再表示" [ref=e89]:
              - option "現在の検索条件" [selected]
          - generic [ref=e90]:
            - generic [ref=e91]:
              - generic [ref=e92]: 一覧の名前
              - textbox "一覧の名前" [ref=e93]
            - generic [ref=e94]:
              - generic [ref=e95]: 保存する内容
              - combobox "保存する内容" [ref=e96]:
                - option "条件に合わせて変わる一覧" [selected]
                - option "今の結果を固定した一覧"
          - button "一覧を保存" [disabled] [ref=e97]
          - generic [ref=e98]:
            - heading "検索結果" [level=2] [ref=e99]
            - generic [ref=e100]: 3件
          - group [ref=e101]:
            - generic "結果をまとめて編集" [ref=e102]
            - option "確定"
            - option "下書き"
            - option "確認待ち" [selected]
            - option "不採用"
            - option "別案"
          - region "本文の検索位置" [ref=e103]:
            - heading "一致した文章の位置 · 3件" [level=3] [ref=e104]
            - button "霧の門 · 本文 霧の門で𠮷野が😀約束を守る。" [ref=e105] [cursor=pointer]:
              - strong [ref=e106]: 霧の門
              - text: · 本文
              - generic [ref=e107]: 霧の門で𠮷野が😀約束を守る。
            - 'button "変更確認: 第一章 · 指摘 変更元: 場面「霧の門」 (e23ad641-de5d-4104-bc" [ref=e108] [cursor=pointer]':
              - strong [ref=e109]: "変更確認: 第一章"
              - text: · 指摘
              - generic [ref=e110]: "変更元: 場面「霧の門」 (e23ad641-de5d-4104-bc"
            - 'button "変更確認: 霧の門 · 指摘 「霧の門」に関係する情報が変更されました。内容への影響を" [ref=e111] [cursor=pointer]':
              - strong [ref=e112]: "変更確認: 霧の門"
              - text: · 指摘
              - generic [ref=e113]: 「霧の門」に関係する情報が変更されました。内容への影響を
          - generic "検索結果の表示" [ref=e114]:
            - button "カード" [pressed] [ref=e115] [cursor=pointer]
            - button "表" [ref=e116] [cursor=pointer]
            - button "図" [ref=e117] [cursor=pointer]
            - button "年表" [ref=e118] [cursor=pointer]
          - generic [ref=e119]:
            - button "01 霧の門 確定 霧の門で𠮷野が😀約束を守る。 次の段落でも同じ人物を参照する。 場面 ·視点 · 𠮷野" [ref=e120] [cursor=pointer]:
              - generic [ref=e121]: "01"
              - generic [ref=e123]:
                - generic [ref=e124]:
                  - heading "霧の門" [level=3] [ref=e125]
                  - generic [ref=e126]: 確定
                - paragraph [ref=e127]: 霧の門で𠮷野が😀約束を守る。 次の段落でも同じ人物を参照する。
                - generic [ref=e128]:
                  - generic [ref=e129]: 場面
                  - generic [ref=e130]: ·視点 · 𠮷野
            - 'button "変更確認: 第一章 確認待ち 「第一章」に関係する情報が変更されました。内容への影響を確認してください。 変更元: 場面「霧の門」 (e23ad641-de5d-4104-bc58-2fdf6e64f6c5)。改訂 0 → 1。IDで直接参照しています（data.sceneIds[0]） 確認対象の作品改訂: 6 → 7。候補は人による確認用です。本文や設定は自動変更していません。 レビュー" [ref=e132] [cursor=pointer]':
              - generic [ref=e134]:
                - generic [ref=e135]:
                  - 'heading "変更確認: 第一章" [level=3] [ref=e136]'
                  - generic [ref=e137]: 確認待ち
                - paragraph [ref=e138]: "「第一章」に関係する情報が変更されました。内容への影響を確認してください。 変更元: 場面「霧の門」 (e23ad641-de5d-4104-bc58-2fdf6e64f6c5)。改訂 0 → 1。IDで直接参照しています（data.sceneIds[0]） 確認対象の作品改訂: 6 → 7。候補は人による確認用です。本文や設定は自動変更していません。"
                - generic [ref=e139]: レビュー
            - 'button "変更確認: 霧の門 確認待ち 「霧の門」に関係する情報が変更されました。内容への影響を確認してください。 変更元: 章「第一章」 (f7c8c441-2e97-4ded-abbc-9fbabf62962a)。改訂 1 → 2。IDで直接参照しています（data.chapterId） 確認対象の作品改訂: 6 → 7。候補は人による確認用です。本文や設定は自動変更していません。 レビュー" [ref=e142] [cursor=pointer]':
              - generic [ref=e144]:
                - generic [ref=e145]:
                  - 'heading "変更確認: 霧の門" [level=3] [ref=e146]'
                  - generic [ref=e147]: 確認待ち
                - paragraph [ref=e148]: "「霧の門」に関係する情報が変更されました。内容への影響を確認してください。 変更元: 章「第一章」 (f7c8c441-2e97-4ded-abbc-9fbabf62962a)。改訂 1 → 2。IDで直接参照しています（data.chapterId） 確認対象の作品改訂: 6 → 7。候補は人による確認用です。本文や設定は自動変更していません。"
                - generic [ref=e149]: レビュー
      - contentinfo [ref=e152]:
        - generic [ref=e153]: 端末内の作品 · 版 7
        - generic [ref=e154]: 5件の情報 · 0件の関係
```

# Test source

```ts
  1   | import {expect, test, type Page} from '@playwright/test';
  2   | import {readFile} from 'node:fs/promises';
  3   | import {createHash} from 'node:crypto';
  4   | import {backup, navigate, openEntity, seed, retainGeneratedOutput, authorFingerprint} from './ap04-original-helpers';
  5   | 
  6   | import {connectPersonaHandoffs, assertPersonaHandoffs, rejectNextProjectWrite} from './phase3-persona-handoff';
  7   | 
  8   | // Additional composition proof. Original persona-specific cases remain separate.
  9   | // Unicode and narrow viewports are automated observations, never real IME/device evidence.
  10  | test('phase3: 空作品の通常制作から参照・試読・履歴・秘密出力・完全復元・offline再編集までつながる', async ({page, browser}, info) => {
  11  |   test.setTimeout(180_000);
  12  |   const body = '霧の門で𠮷野が😀約束を守る。\n次の段落でも同じ人物を参照する。';
  13  |   const secret = 'PHASE3_PRIVATE_作者だけの結末';
  14  |   const observations: string[] = [];
  15  |   page.on('pageerror', error => observations.push(error.message));
  16  |   async function add(kind: string, label: string, name: string) {
  17  |     await navigate(page, /^資料/);
  18  |     await page.locator('.materials-filter').getByLabel('情報の種類', {exact:true}).selectOption(kind);
  19  |     await page.getByRole('button', {name: `${label}を追加`, exact:true}).first().click();
  20  |     const dialog = page.getByRole('dialog');
  21  |     await dialog.getByLabel('名前', {exact:true}).fill(name);
  22  |     await dialog.getByRole('button', {name:'編集を始める', exact:true}).click();
  23  |     await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
  24  |   }
  25  |   async function save(target: Page) {
  26  |     await target.locator('.editor-footer').getByRole('button', {name:/^(保存する|保存を再試行)$/}).click();
  27  |     await expect(target.locator('.editor-save-state')).toContainText('端末内保存済み');
  28  |   }
  29  |   await page.goto('./');
  30  |   await page.getByLabel('作品名', {exact:true}).fill('第3段階の連続制作');
  31  |   await page.getByRole('button', {name:'作品を作成', exact:true}).click();
  32  |   expect((await backup(page)).project.entities).toHaveLength(0);
  33  |   await add('character', '人物', '𠮷野');
  34  |   await page.locator('.detail-panel').getByLabel('情報の状態', {exact:true}).selectOption('confirmed');
  35  |   await save(page);
  36  |   await add('chapter', '章', '第一章');
  37  |   await page.locator('.detail-panel').getByLabel('情報の状態', {exact:true}).selectOption('confirmed');
  38  |   await save(page);
  39  |   await add('scene', '場面', '霧の門');
  40  |   const registered = await backup(page);
  41  |   const person = registered.project.entities.find(e => e.kind === 'character')!;
  42  |   const chapter = registered.project.entities.find(e => e.kind === 'chapter')!;
  43  |   const scene = registered.project.entities.find(e => e.kind === 'scene')!;
  44  |   await openEntity(page, 'scene', scene.name);
  45  |   const editor = page.locator('.detail-panel');
  46  |   await editor.getByLabel('情報の状態', {exact:true}).selectOption('confirmed');
  47  |   await editor.getByRole('tab', {name:'詳細', exact:true}).click();
  48  |   await editor.getByLabel('章', {exact:true}).selectOption(chapter.id);
  49  |   await editor.getByLabel('視点人物', {exact:true}).selectOption(person.id);
  50  |   await editor.getByRole('tab', {name:'本文', exact:true}).click();
  51  |   const beforeDraft = await authorFingerprint(page);
  52  |   await editor.getByRole('textbox', {name:'本文', exact:true}).fill(body);
  53  |   await rejectNextProjectWrite(page);
  54  |   await editor.locator('.editor-footer').getByRole('button', {name:'保存する', exact:true}).click();
  55  |   await expect(editor.locator('.editor-save-state')).toContainText('未保存');
  56  |   expect(await authorFingerprint(page)).toBe(beforeDraft);
  57  |   // The interrupted save must retain the draft and the route back to this ID.
  58  |   await navigate(page, /^検索/);
  59  |   await page.getByLabel('作品内を検索', {exact:true}).fill(scene.name);
  60  |   await page.locator('.entity-card').filter({has:page.getByRole('heading', {name:scene.name, exact:true})}).click();
  61  |   await editor.getByRole('tab', {name:'本文', exact:true}).click();
  62  |   await expect(editor.getByRole('textbox', {name:'本文', exact:true})).toHaveValue(body);
  63  |   await save(page);
  64  |   await editor.getByRole('button', {name:'詳細を閉じる', exact:true}).click();
  65  |   await expect(page.getByLabel('作品内を検索', {exact:true})).toHaveValue(scene.name);
> 66  |   await expect(page.locator('.entity-card h3')).toHaveText(scene.name);
      |                                                 ^ Error: expect(locator).toHaveText(expected) failed
  67  |   await page.locator('.entity-card').click();
  68  |   await editor.getByRole('tab', {name:'作者メモ', exact:true}).click();
  69  |   await editor.getByRole('textbox', {name:'作者メモ', exact:true}).fill(secret);
  70  |   await save(page);
  71  |   await navigate(page, /^検索/);
  72  |   await page.getByLabel('作品内を検索', {exact:true}).fill('約束を守る');
  73  |   await expect(page.locator('.entity-card h3')).toHaveText(scene.name);
  74  |   await page.locator('.entity-card').click();
  75  |   await editor.getByRole('tab', {name:'本文', exact:true}).click();
  76  |   await expect(editor.getByRole('textbox', {name:'本文', exact:true})).toHaveValue(body);
  77  |   await editor.getByRole('button', {name:'詳細を閉じる', exact:true}).click();
  78  |   await navigate(page, /^構成/);
  79  |   await page.getByRole('tab', {name:'章の試読', exact:true}).click();
  80  |   await page.getByRole('button', {name:'記録付き読書を始める', exact:true}).click();
  81  |   await page.getByRole('button', {name:'次の場面を提示', exact:true}).click();
  82  |   await expect(page.locator('.chapter-reading-presented')).toContainText('約束を守る');
  83  |   await navigate(page, /^作品・保存/);
  84  |   await page.getByRole('tab', {name:'変更履歴', exact:true}).click();
  85  |   await expect(page.locator('.history-list .reference-link').first()).toBeVisible();
  86  |   await page.getByRole('tab', {name:'作品の設定', exact:true}).click();
  87  |   await page.getByLabel('確定版の名称', {exact:true}).fill('復元前の固定版');
  88  |   await page.getByRole('button', {name:'現在の内容を確定版として保存', exact:true}).click();
  89  |   await expect(page.getByRole('status').filter({hasText:'本文と設定の確定版'})).toBeVisible();
  90  |   await page.getByRole('tab', {name:'目的別出力', exact:true}).click();
  91  |   await page.getByRole('button', {name:'公開範囲を作成', exact:true}).click();
  92  |   const dialog = page.getByRole('dialog', {name:'公開する範囲を作成', exact:true});
  93  |   await dialog.getByLabel('公開用の作品名', {exact:true}).fill('公開する門の話');
  94  |   for (const id of [person.id, chapter.id, scene.id]) await dialog.getByLabel('追加する対象', {exact:true}).selectOption(id);
  95  |   await dialog.getByLabel('選んだ対象の本文・表記を公開文へコピーする', {exact:true}).check();
  96  |   await dialog.getByRole('button', {name:'範囲を作成して内容を確認', exact:true}).click();
  97  |   await page.getByRole('button', {name:'内容を検査・プレビュー', exact:true}).click();
  98  |   // Creating a policy is not approval: the original export boundary must refuse it.
  99  |   await expect(page.locator('.export-result')).toContainText('引用固定版の公開範囲が未確認');
  100 |   await expect(page.locator('.export-result .export-artifact')).toHaveCount(0);
  101 |   await editor.getByLabel('情報の状態', {exact:true}).selectOption('confirmed');
  102 |   await save(page);
  103 |   await editor.getByRole('button', {name:'詳細を閉じる', exact:true}).click();
  104 |   await page.getByRole('button', {name:'内容を検査・プレビュー', exact:true}).click();
  105 |   const artifact = page.locator('.export-result .export-artifact');
  106 |   await expect(artifact).toHaveCount(1);
  107 |   const pending = page.waitForEvent('download');
  108 |   await artifact.getByRole('button', {name:'この内容を保存', exact:true}).click();
  109 |   const download = await pending, publicBytes = await readFile((await download.path())!);
  110 |   await retainGeneratedOutput(publicBytes, download.suggestedFilename(), 'text/markdown');
  111 |   expect(publicBytes.toString()).toContain('約束を守る');
  112 |   expect(publicBytes.toString()).not.toContain(secret);
  113 |   const shared = await backup(page);
  114 |   expect(shared.project.snapshots).toHaveLength(1);
  115 |   const handoffs = await connectPersonaHandoffs(page, shared.project, {sceneId:scene.id, personId:person.id, secret});
  116 |   const complete = await backup(page);
  117 |   await assertPersonaHandoffs(complete, handoffs);
  118 |   expect(complete.project.entities.find(e => e.id === scene.id)).toMatchObject({data:{chapterId:chapter.id, povId:person.id}});
  119 |   expect(JSON.stringify(complete.project.entities.find(e => e.id === scene.id))).toContain(secret);
  120 |   const fresh = await browser.newContext({viewport:{width:390, height:844}});
  121 |   try {
  122 |     const restored = await fresh.newPage();
  123 |     await seed(restored, complete.bytes);
  124 |     await restored.reload();
  125 |     const cold = await backup(restored);
  126 |     expect(cold.project).toEqual(complete.project);
  127 |     await assertPersonaHandoffs(cold, handoffs);
  128 |     expect(cold.recovery).toBeDefined();
  129 |     expect(complete.recovery).toBeDefined();
  130 |     const originalPending = complete.recovery!.pending;
  131 |     expect(cold.recovery!.pending.filter(row => originalPending.some(old => old.operationId === row.operationId))).toEqual(originalPending);
  132 |     const restoreAudit = cold.recovery!.pending.filter(row => !originalPending.some(old => old.operationId === row.operationId));
  133 |     expect(restoreAudit).toHaveLength(1);
  134 |     expect(restoreAudit[0]!.command.reason).toContain('専用ファイルをnewで復元');
  135 |     expect(cold.recovery!.projectId).toBe(complete.recovery!.projectId);
  136 |     await fresh.setOffline(true);
  137 |     await restored.reload();
  138 |     await openEntity(restored, 'scene', scene.name);
  139 |     const name = restored.locator('.detail-panel').getByLabel('名前', {exact:true});
  140 |     await name.fill('復元後も同じ場面');
  141 |     await save(restored);
  142 |     const changed = await backup(restored);
  143 |     expect(changed.project.entities.find(e => e.id === scene.id)).toMatchObject({name:'復元後も同じ場面', data:{chapterId:chapter.id, povId:person.id}});
  144 |     await assertPersonaHandoffs(changed, handoffs);
  145 |     expect(changed.project.history.length).toBe(cold.project.history.length+1);
  146 |     expect(changed.project.snapshots).toEqual(complete.project.snapshots);
  147 |     expect(changed.project.entities.filter(e => e.kind === 'scene')).toHaveLength(1);
  148 |   } finally { await fresh.close(); }
  149 |   expect(observations).toEqual([]);
  150 |   await info.attach('phase3-continuity.json', {body:JSON.stringify({scope:'Additional automated UI continuity, not physical/IME/Auth acceptance',
  151 |     engine:info.project.name, startedFromEmpty:true, typedReferences:{person:person.id, chapter:chapter.id, scene:scene.id},
  152 |     publicSHA256:createHash('sha256').update(publicBytes).digest('hex'), completeSHA256:createHash('sha256').update(complete.bytes).digest('hex'),
  153 |     handoffs, interruptedSaveRetainedDraftAndSearchReturn:true, privateAuthorNotesExcluded:true, coldFullCorrespondence:true, offlineReeditAndImmutablePin:true}), contentType:'application/json'});
  154 | });
  155 | 
```