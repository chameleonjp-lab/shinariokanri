# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-authoring-continuity.spec.ts >> phase3: 空作品の通常制作から参照・試読・履歴・秘密出力・完全復元・offline再編集までつながる
- Location: tests/e2e/phase3-authoring-continuity.spec.ts:10:1

# Error details

```
Error: browserType.launch: 
╔══════════════════════════════════════════════════════╗
║ Host system is missing dependencies to run browsers. ║
║ Missing libraries:                                   ║
║     libgtk-4.so.1                                    ║
║     libgraphene-1.0.so.0                             ║
║     libharfbuzz-icu.so.0                             ║
║     libmanette-0.2.so.0                              ║
║     libhyphen.so.0                                   ║
║     libGLESv2.so.2                                   ║
╚══════════════════════════════════════════════════════╝
```