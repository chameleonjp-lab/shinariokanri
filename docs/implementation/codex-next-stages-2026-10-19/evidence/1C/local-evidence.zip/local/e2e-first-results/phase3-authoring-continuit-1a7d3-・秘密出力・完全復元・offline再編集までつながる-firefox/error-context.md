# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-authoring-continuity.spec.ts >> phase3: 空作品の通常制作から参照・試読・履歴・秘密出力・完全復元・offline再編集までつながる
- Location: tests/e2e/phase3-authoring-continuity.spec.ts:10:1

# Error details

```
Error: browserType.launch: Failed to launch the browser process.
Browser logs:

<launching> /workspace/task-integration/playwright-browsers/firefox-1555/firefox/firefox -no-remote -headless -profile /tmp/playwright_firefoxdev_profile-CxEzRt -juggler-pipe -silent
<launched> pid=3114
[pid=3114][err] *** You are running in headless mode.
[pid=3114][err] Could not find profile folder.
[pid=3114] <process did exit: exitCode=1, signal=null>
[pid=3114] starting temporary directories cleanup
Call log:
  - <launching> /workspace/task-integration/playwright-browsers/firefox-1555/firefox/firefox -no-remote -headless -profile /tmp/playwright_firefoxdev_profile-CxEzRt -juggler-pipe -silent
  - <launched> pid=3114
  - [pid=3114][err] *** You are running in headless mode.
  - [pid=3114][err] Could not find profile folder.
  - [pid=3114] <process did exit: exitCode=1, signal=null>
  - [pid=3114] starting temporary directories cleanup
  - [pid=3114] <gracefully close start>
  - [pid=3114] <kill>
  - [pid=3114] <skipped force kill spawnedProcess.killed=false processClosed=true>
  - [pid=3114] finished temporary directories cleanup
  - [pid=3114] <gracefully close end>

```