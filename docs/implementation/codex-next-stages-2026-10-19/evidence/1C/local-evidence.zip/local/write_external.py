import json,hashlib
from pathlib import Path
root=Path('/workspace/shinariokanri-1c')
rows={r['id']:r for r in json.loads((root/'docs/data/acceptance_cases.json').read_text())}
# Each tuple fixes environment/roles, isolated input, execution+negative evidence, next action.
plans={
'AT-B24':('実機','iPhone 17 Pro Safari、iPad Pro 2018 Safari。作者1名、実タッチのみ。二端末同期/ゲーム/費用は不要。','人物2名・関係線・括弧付き条件と根拠不足の候補を持つ隔離作品。','絞込条件を記録→関係線と条件をタッチ編集→保存して再度開く。根拠不足の候補を確定不具合にしない表示、色以外のラベルを画面記録する。','担当者が実タッチ端末の機種/OS/Safari版を記入する。'),
'AT-F01':('実機＋実サービス','iPhone 17 Pro Safari/Chrome＋実PC Chrome/Edge。作者owner/editor、専用同期tenant、録音許可と拒否。二実端末必須。ゲーム/費用試験は不要。','隔離作品に原メモ「塔の鍵は鳥が持つ」、PNG1枚、実録音1件。原メモと素材bytesを完全保存する。','スマートフォンでメモ/画像/音声を保存→実同期→PCで場面へ変換→両端末で元/先を開く。録音拒否でも文章を保存し、元と先のID連結/元非削除を照合する。','管理者がこのアプリ専用の隔離同期tenantと実二端末を指定する。'),
'AT-F29':('実Auth','実PCまたは実iPhoneのHTTPS候補、owner/editorと実reviewerの資格。実Auth必須、二端末同期/ゲーム/費用は不要。','台詞L版1と段落/引用範囲、reviewerが通常ログインして作成する指摘。トークンは台帳外で受渡す。','reviewer指摘→editor改訂→段落削除→修正済み→reviewer再確認済み→元引用を開く。元版/引用範囲、削除後の最新位置不明と指摘残存を記録する。','管理者が隔離Authの実reviewer/editor役割を指定する。'),
'AT-F30':('実Auth','専用HTTPS/Auth/DataAPI/private Storage。owner/editor/reviewer/chapter限定reader/nonmemberの5実役割。実PCの独立セッション。二端末同期/ゲーム/費用は不要。','秘密の本名/関係/添付とchapter限定投影を持つ隔離作品。期待allowlistと拒否対象の合成IDを先に固定。','各役割の本文/検索/図/リンク/素材/直接APIと更新を実施。許可投影だけの応答を検査し、秘密本文/名称/ID/件数/素材メタデータをサーバーと出力双方で拒否する。秘密値を証跡へ複写せず拒否対象ラベルと応答hashを残す。','管理者が専用private bucketと5役割の安全な資格受渡し先を指定する。'),
'AT-F31':('実機','iPhone 17 Pro Safari、iPad Pro 2018 Safari（実Split View）、実PC。作者1名。二端末同期/ゲーム/費用は不要。','人物/条件/関係線/専用ファイルと未保存入力。幅320/390/768/1024/1440、縦横/分割の対応表。','各幅で実配置を記録→狭幅だけで編集と読込→縦横/分割/ソフトキーボードで確定へ到達。未保存文を前後比較し、PCに切り替えず完了を記録する。','担当者がiPhone/iPad/PCと実幅・OS・browserの割当を記入する。'),
'AT-F33':('実機','実PC Chrome/Edgeと実iPhone Safariの二実端末。作者1名。内容受渡しは完全ファイル（実同期合格へは転記しない）。ゲーム/費用は不要。','同一作品、PC拡大率/図位置とスマートフォン別表示設定、名前付き検索/お気に入り、削除済み再開リンク。','PC設定保存→スマートフォンで同場面を開く→名前付き検索/お気に入りから再開→削除済みリンク。内容ID一致と端末設定非強制、履歴/復元案内と白画面無しを記録する。','担当者が二実端末と同じ完全ファイルのSHAを指定する。'),
'AT-F34':('実機＋実サービス','専用実Authと同期、同baseRevisionを取得した二実端末（iPhone＋PC）。作者owner/editor。ゲーム/費用は不要。','同じ本文の共通元、A/B別案、削除対編集、重複/順逆送信表。元完全ファイル保持。','OS機内モードでA/B変更→順逆同期→共通元/双方を比較し選択→再送→削除対編集。各操作ID・baseRevision・端末内保存/同期表示を比較し黙示上書きを拒否する。','管理者が隔離同期環境と二実端末の同baseRevisionを指定する。'),
'AT-F42':('ゲーム','対象ゲームの名称/engine/version/adapterと実行担当、作者とゲーム確認者。実対象が必須。実Auth/二端末同期/費用は対象ゲームが要求する場合だけ別途指定。','管理元gameの戦闘結果enum契約、型/欠損方針/版、stub勝利、未登録actual。packageとline/flow ID対応。','stub経路の実出力を保持→対象ゲームで戦闘→actual receiptとhash/ID対応を取込→差分比較。仮/実を別証跡にし、欠損/型不一致を拒否する。','ゲーム担当者が対象ゲーム名/engine/version/adapterを記入する。'),
'AT-N02':('実機','UI_UX端末表のiPhone 17 Pro Safari/Chrome、iPad Pro 2018 Safari、Windows/macOS Chrome/Edge/Firefox、macOS Safari。作者。二端末同期/ゲーム/費用は不要。','同一総合fixtureの完全ファイルと対象build。端末ごとの元ID/内容を固定。','対象表の各実環境で保存→cold再読込→実ファイル往復→タッチ操作。OS/browser/版とID/bytes/結果を別行で記録し自動3engine結果を転記しない。','担当者がUI_UX表の実機ごとの実施者とOS/browser版を割り当てる。'),
'AT-N03':('実機','実iPhone/macOS VoiceOverまたは実Windows NVDA＋キーボード。作者と支援技術確認者。二端末同期/ゲーム/費用は不要。','空作品から人物/場面/本文/不正入力/出力まで。図の一覧代替と取消モーダル。','作成→保存→試読→出力をキーボード/実読上げで操作し、焦点順/見える焦点/読上げ/エラー/完了通知を逐次記録。図強制や拡大無効を検出する。','担当者が実VoiceOverまたはNVDAと確認者を指定する。'),
'AT-N04':('実機','原性能手順の実測対象端末と指定OS/browser。測定担当。二端末同期/ゲーム/費用は不要。','元Standard/Large生成物と各SHA、操作一覧/元上限表を固定。Linux過去値を入力しない。','指定操作を各30回、raw全標本とp95算出法・条件を保存→原目標値と比較。超過も記録し要件や標本を削らない。','測定担当が原指定端末・電源/負荷条件と対象buildを記入する。'),
'AT-N07':('実機＋実サービス','実オフライン二端末、専用実Auth/同期、owner/editor。ゲーム/費用は不要。','同本文/共通revision、A/B変更、送信順AB/BAと同一operation再送表。','各実端末を機内モード→同本文別案保存→順逆同期→二案/共通元比較→解決→重複再送。効果一回と両案保持をoperation IDで確認し端末時計に依存しない。','管理者が実二端末と隔離同期接続を指定する。'),
'AT-N08':('実Auth','専用Auth/DataAPI/private Storage、実nonmemberと限定reader、owner準備者。実PC独立セッション。二端末同期/ゲーム/費用は不要。','許可投影と非公開本文/名称/ID/メタデータ/素材、別作品の合成ID。','各実役割で検索/直接API/private素材取得→別project ID差替え。拒否とallowlistの応答を記録しUI非表示だけで判定しない。公開bundleにsecretキーを含めない。','管理者が専用環境の実nonmember/限定readerを指定する。'),
'AT-N11':('実機＋実サービス','取得済みPWAの実iPhone/PC、OS機内モード、専用remote素材サービス（未cache対照を保持）、owner。二端末同期/ゲーム/費用は不要。','取得済み作品/素材、初回未取得作品と未cache remote素材の対照。元完全保存。','OS機内モード→編集/保存→アプリを閉じcold再開→実Filesへ完全出力。端末内保存と未送信を区別し、未取得作品/素材は成功表示しない。remote未cacheをDB削除だけで代用しない。','担当者がキャッシュ済み実端末と未cache remote素材の隔離先を指定する。'),
'AT-N13':('実機','実iPhone/macOS/Windows日本語OS IME、対象キーボード。作者。二端末同期/ゲーム/費用は不要。','日本語の変換途中の文と負の巨大tick文字列（例 -900719925474099312345）、元ID/原文を完全ファイルに保持。','未確定変換中に操作キー/保存/検索/出力/読戻し→原文・ID・tickの文字列完全一致。IME途中破壊と浮動小数丸めを検出し実キーと変換状態を記録する。','担当者が実OS IMEの名称/版と操作キーボードを記入する。'),
'AT-N17':('契約/費用','許可された専用HTTPS検証URLと実構成/tier/region/使用量/残量/費用の読取り権限。管理者/費用確認者。二端末/ゲームは不要。','対象commit/tree/build/base、実契約見積と計測時刻。一般料金表は参考別欄。既存本番/別用途projectは触らない。','サブパス/直リンク/更新/再読込を実URLで確認→build-infoとcommit一致→実tier/region/使用量/残枠/費用・通貨/期間/税込別を記録。文書作成だけで公開済/費用0にしない。','管理者が変更不要の専用検証URLと実契約の読取り資料を指定する。'),
'AT-E01':('実機','iPhone 17 Pro Safari縦画面だけ、作者。PC補助なし。実Files/回転/ソフトキーボード。二端末同期/ゲーム/費用は不要。','空作品→人物2名、共通/個人出来事、場所、線、括弧付き条件を実入力。','iPhoneだけで全登録→専用ファイル実Files保存→OS保存先取消/再試行→空領域new復元→ID/内容比較→再編集。横画面/入力中キーボード/取消の未保存保持を記録する。','担当者がiPhoneと実Filesの空検証領域を指定する。'),
'AT-E05':('実Auth','専用実Auth/DataAPI/private Storage、owner/editor/reviewer/限定reader/nonmember。HTTPS実セッション。二端末同期/ゲーム/費用は不要。','本名/家系/添付を非公開にした限定共有snapshotと公開別名、他作品合成ID。','閲覧者で本文/検索/索引/図/リンク/素材/直接APIを検査→ID/project_id差替え→ownerが隔離権限撤回→新規取得拒否。名前/ID/関係/件数/ファイル名全項目の拒否を照合する。','管理者が隔離snapshotと各実役割、限定した撤回操作の担当を指定する。'),
'AT-E06':('実機＋実サービス','同revisionの実二端末、専用実Auth/同期/容量制限用隔離先。owner/editorと管理者。ゲーム/費用は不要。','共通元/両本文案、片方削除、重複/順逆送信、容量不足/認証失効の試行表。','両端末機内モード→同本文変更/片側削除→重複/順逆送信→双方/共通元比較→解決→結果一致。容量不足/実認証失効時の未送信保持と同期済でない表示、二重効果/復活無しを記録する。','管理者が実二端末と失効/容量拒否を行える専用隔離先を指定する。'),
'AT-E10':('ゲーム','対象ゲーム名称/engine/version/adapterと実担当。解析は固定build。実Auth/二端末同期/費用は対象ゲームに必要なら別途指定。','抽選seed、無制限ループ、外部戦闘契約/仮値を同じ作品/版/IDで固定。','同記録再実行→原探索上限まで解析→分母/未確認範囲保存→対象ゲームactual結果を別記録→対象版改訂して再確認待ち。打切りを到達不能にせずstub/actualとID対応を比較する。','ゲーム担当者が実対象のengine/version/adapterと実結果記録方法を指定する。'),
'AT-E11':('実機','UI_UX実端末表、実VoiceOver/NVDA、日本語OS IME、OS文字200%と狭幅。作者/支援技術/性能担当。二端末同期/ゲーム/費用は不要。','原Standard/Large・図の一覧代替・原性能目標。各入力SHAを固定。','キーボード/実VoiceOver/OS200%/狭幅で全操作→表代替→指定性能raw取得。色依存/ドラッグ専用/焦点喪失/IME破壊/全件DOMを検出し全項目を環境別記録する。','担当者が実端末表へ支援技術と性能実施者を割り当てる。'),
'AT-E12':('実機＋実サービス','実旧アプリbuild＋更新候補の許可済専用HTTPS、実端末機内モード/実Files、専用実Auth/同期/remote未取得素材/容量制限。owner/管理者。二端末は復帰比較に使う場合のみ。ゲーム/費用は不要。','キャッシュ済み旧build、未送信作品、初回未取得/未取得素材対照、完全ファイル、旧build/新build SHA。','機内モード→実容量拒否→途中更新の安全地点確認→移行失敗/再試行→実Files保存先取消/再試行→専用file復元。失敗/未保存/未送信と素材未取得を保持し、cache ID変更やプログラム取消を実旧更新/OS取消へ転記しない。','管理者が実旧buildと新buildを保持した専用更新URLを指定する。')}
expected=[('実機',9),('実機＋実サービス',6),('実Auth',4),('ゲーム',2),('契約/費用',1)]
assert len(plans)==22
assert [(k,sum(v[0]==k for v in plans.values())) for k,n in expected]==expected
sha=hashlib.sha256((root/'docs/data/acceptance_cases.json').read_bytes()).hexdigest()
text=f'''# 外部受入の独立準備台帳

2026-10-19。準備は各caseの入力・手順・空の記録欄・次操作が定義済みという意味。全22件の実受入は **BLOCKED / 未実行**。実機・実Auth・専用サービス・対象ゲーム・実契約はまだ提供されていない。この台帳作成時に接続・認証・課金・公開設定は変更していない。

原本は [acceptance_cases.json](../../data/acceptance_cases.json)（SHA-256 `{sha}`）のgiven/when/then/negative_or_edgeを以下に逐語保持する。[原外部表](../../quality/pr49-followup-2026-10-15/EXTERNAL_CASES.md)の22IDと一致。原116件を増減しない。[実機手順](../../quality/pr49-followup-2026-10-15/MANUAL_REVIEW.md)にある旧候補のcommit/build/404は過去値であり、今回の実行値へ転記しない。

| 独立分類 | 件数 | 原ID |
| --- | --- | --- |
'''
for group,n in expected:
 text+=f"| {group} | {n} | {', '.join(k for k,v in plans.items() if v[0]==group)} |\n"
text+='''
各caseの記録欄は空であり、認証秘密・実名・実作品・URL内tokenを入力しない。実行者は匿名役割ラベル、資格情報は承認済みの別経路で渡す。実施時にtarget commit/tree/build/base、fixture path/bytes/SHA、実OS/browser/端末、実操作時刻、四条項それぞれの期待と実結果、raw path/bytes/SHA、判定を埋める。未記入の欄は成功ではない。実二端末はA/Bの機種/OS/browser、同baseRevision、各operation IDと送信順も記録する。

実機計画の端末表は [UI_UX](../../spec/UI_UX.md) を保持する。タッチ/OS IME/VoiceOver/NVDA/Files/旧アプリ更新をLinux自動WebKit、Unicode fill、browser offline、cache ID変更、プログラム取消で置換しない。mock Auth・汎用receiver・一般料金表は原実条件の成功にしない。実行開始前に許可済み隔離対象と担当を明示し、既存本番・別用途Supabaseには接続しない。
'''
for id,(group,env,fixture,procedure,next_action) in plans.items():
 c=rows[id]
 text+=f'\n## {id}\n\n分類: {group}。準備: **PREPARED**。実受入: **BLOCKED / 未実行**。\n\n'
 text+='| 原条項 | 原文 |\n| --- | --- |\n'
 for k in ['given','when','then','negative_or_edge']: text+=f'| {k} | {c[k]} |\n'
 text+=f'\n必要環境・人: {env}\n\n隔離入力・成果物: {fixture}\n\n実施・記録手順: {procedure}\n\n安全な空の記録様式（このcase専用）:\n\n```json\n'+json.dumps({'case_id':id,'operator_role':'','target':{'commit':'','tree':'','build':'','base':''},'environment':{'device_A':'','device_B':'','OS_browser_IME_assistive_versions':'','service_role_labels':'','game_engine_adapter':'','actual_contract_cost_period':''},'fixture':{'path':'','bytes':None,'sha256':'','project_id':'','revision':'','version_id':'','entity_ids':[]},'clauses':{k:{'observed':'','raw_path':'','raw_sha256':'','status':'not_run'} for k in ['given','when','then','negative_or_edge']},'started_at':'','finished_at':'','result':'not_run','blocker':'','next_action':''},ensure_ascii=False,indent=2)+'\n```\n\n'
 text+=f'次の一操作: {next_action}\n'
text+='''
## 元22件とは別の残条件（3欄を独立保持）

| 条件 | 準備 | 実受入・原本取得 | 記録欄（空） | 次の一操作 |
| --- | --- | --- | --- | --- |
| AC-G02-N/E・CP04 実2アカウント | 同一作品/本文、一般語の候補、確定済リンク、個別除外/解除の手順を準備 | BLOCKED / 実2account未指定 | account A役割: ／account B役割: ／project/revision/SHA: ／A除外→cold: ／通常logout/切替→B: ／A解除/再保存/再読込: ／確定リンク保持: ／raw/SHA/時刻: | 管理者が同じ隔離作品を使える実2accountの役割を指定する |
| 旧C29・AC-G07・CP10 | 37part/MANIFESTの全bytes/hash/順序/空領域展開と旧不足18宣言の個別照合欄を準備 | BLOCKED / 旧37part＋MANIFESTと旧18宣言の実bytes未取得 | 元保管先: ／37part件数・bytes・SHA: ／MANIFEST path/SHA: ／各member検証結果: ／旧18宣言別path/SHA/取得状況: ／空領域検証argv/exit/raw: | 原証拠管理者が旧C29の原MANIFESTと37partの取得可能な保管先を指定する |
| CP15 独立確認者・結果 | 原四条項/原本hash/未実行/9gateを照合する独立受入手順を準備 | BLOCKED / 確認者・結果未取得 | 確認者（著者と別）: ／確認日時: ／対象commit/tree/build: ／使用MANIFEST SHA: ／条項別結果/raw: ／指摘: ／判定: | ユーザーが独立確認者を指定し、既存INDEPENDENT_REVIEWの原手順を渡す |

旧C29の37part/MANIFESTと旧18宣言は同じ残条件欄内で別々に照合し、新しい候補の出力で旧原本を再生成したとは扱わない。CP15の確認者と結果は別欄のまま未記入。fresh agentのコードレビューは原CP15の独立ユーザー受入に代えない。

## 9 release gates

`realDevices`、`accessibilityManual`、`performance`、`restoreDrill`、`syncLive`、`rlsLive`、`independentReview`、`hostingCosts`、`directLinks`を維持する。元 [check_release.py](../../../scripts/check_release.py) と証拠schemaは変更しない。台帳PREPARED・自動3engine成功・新しい完全ファイルだけではgateをpassedにしない。公開・配備・mergeはこの依頼で実行しない。

## 今回の自動接続検査

[制作接続表](AUDIT_AND_DESIGN.md)のNP04節と `phase3-authoring-continuity.spec.ts` / `phase3-persona-handoff.ts` を参照。各engineの実argv/exit・build・添付は統合担当が本候補に結合する。正式全CI、現行30/180・heap、原外部実受入はそれぞれ独立であり、この文書に未取得値を成功として補完しない。
'''
(root/'docs/acceptance/phase3/VERIFICATION.md').write_text(text)
