from pathlib import Path
import hashlib
r=Path('/workspace/shinariokanri-1c')
M={
'AT-B24': [('tests/e2e/ap04-original-f31-same-work-helper.ts','exerciseF31SameWorkの人物/条件/線/関係の同一作品生成手順。タッチ端末というgivenは未充足')],
'AT-F01':[('tests/e2e/catalog-notes.spec.ts','AT-F01のメモ「塔の鍵は鳥が持つ」/PNG生成/変換元先ID fixture生成手順'),('tests/fixtures/media/fixture-tone.wav','再利用できる合成WAV原本。スマートフォン実録音ではない')],
'AT-F29':[('src/testing/sharedReviewFixture.ts','sharedReviewFixtureの固定版台詞/引用と公開出所'),('tests/e2e/ap04-original-f-source-schema.spec.ts','AT-F29の版1/改訂/削除/指摘stage手順。reviewer UUIDは実Authでない')],
'AT-F30':[('tests/fixtures/sync/browser/shared.json','限定共有snapshotの局所投影入力。実役割/Auth未充足'),('tests/fixtures/sync/postgres-auth-storage-fixture.sql','隔離用認証/storageデータ手順の参照原本。未適用/実接続なし')],
'AT-F31':[('tests/e2e/ap04-original-f31-same-work-helper.ts','人物/条件/関係線/専用ファイルと未保存入力の生成。実回転/SplitView/OS keyboard未充足')],
'AT-F33':[('tests/e2e/ap04-original-f-resume-recovery.spec.ts','AT-F33の表示class別設定/お気に入り/削除済み再開リンク生成手順。実PC/スマートフォン受渡し未充足'),('tests/fixtures/rb06-history.scenario','削除前/旧完全file比較用の元native入力')],
'AT-F34':[('tests/fixtures/sync/browser/editor-base.json','共通baseRevisionの局所編集入力。実二端末/実Auth未充足'),('tests/fixtures/sync/browser/remote-native.json','順逆/競合の対照入力。実同期でない')],
'AT-F42':[('tests/e2e/ap04-original-e-f37-42-state.spec.ts','AT-F42の戦闘enum/stub/ID対応生成手順。実対象ゲーム/adapter/戦闘結果未取得')],
'AT-N02':[('docs/spec/UI_UX.md','givenの対象端末表原本'),('tests/e2e/ap04-original-f31-same-work-helper.ts','総合試験の作品/完全file準備手順。実端末表実施は未実行')],
'AT-N03':[('tests/e2e/phase3-authoring-continuity.spec.ts','空作品→作成/本文/試読/出力の操作手順。実VoiceOver/NVDA/キーボード操作未実行')],
'AT-N04':[('src/testing/performanceFixture.ts','createPerformanceFixture(seed, standard/large)の標準/大規模原生成手順。source SHAと生成物SHAを区別'),('scripts/acceptance/run_formal.py','正式受入の入口。対象実端末30回は未実行')],
'AT-N07':[('tests/fixtures/sync/browser/editor-base.json','同本文/共通元の局所入力'),('tests/fixtures/sync/browser/remote-native.json','別案比較用入力。実二端末/機内モード/実同期未充足')],
'AT-N08':[('tests/fixtures/sync/browser/shared.json','限定投影と秘密の対照入力'),('tests/fixtures/sync/rls-contract.sql','直接API/RLS期待の既存SQL原本。非メンバー/限定reader実Auth未実行/未適用')],
'AT-N11':[('tests/e2e/ap04-original-n-mobile-offline.spec.ts','AT-N11の取得済み作品/未cache素材の局所対照生成手順'),('tests/fixtures/media/fixture-tone.wav','取得済み素材の実bytes対照。実remote未cache/OS機内モードは未充足')],
'AT-N13':[('tests/e2e/review-runtime.spec.ts','負の巨大tick -9007199254740993を設定/再開する既存生成手順'),('tests/e2e/phase3-authoring-continuity.spec.ts','日本語/Unicode本文とID/実file読戻し。実OS変換途中IMEというgivenは未充足')],
'AT-N17':[('scripts/build/service-worker.mjs','配信版/build情報の既存生成手順。実構成/見積表/契約/検証URLのgivenは未取得')],
'AT-E01':[('tests/e2e/phase3-authoring-continuity.spec.ts','空作品開始の通常UI手順'),('tests/e2e/ap04-original-f31-same-work-helper.ts','条件/線/専用ファイルの生成手順。実iPhone空環境/OS Files/人物2名等の原全操作は未実行')],
'AT-E05':[('tests/fixtures/sync/browser/shared.json','限定共有snapshotの局所入力'),('src/testing/sharedReviewFixture.ts','秘密/公開投影の固定版準備。実Auth/直接API/撤回後の拒否は未実行')],
'AT-E06':[('tests/fixtures/sync/browser/editor-base.json','共通revisionの元入力'),('tests/fixtures/sync/browser/remote-native.json','競合比較入力。実二端末/削除対編集/実失効/容量拒否は未実行')],
'AT-E10':[('tests/e2e/ap04-original-e10-exploration.spec.ts','抽選/無制限ループ/外部戦闘同作品の生成手順と解析上限。対象ゲーム実結果未取得')],
'AT-E11':[('src/testing/performanceFixture.ts','標準/大規模原生成手順'),('docs/spec/UI_UX.md','対象実端末表。実VoiceOver/OS200%/IME/原性能測定未実行')],
'AT-E12':[('docs/quality/current-review/evidence/legacy/3099c9d-flow-trace.scenario','既存未送信作品のnative入力'),('tests/e2e/ap04-original-e12-continuity.spec.ts','waiting worker/移行retry/容量拒否の局所手順。実旧アプリbuild/実OS/実サービス/Files取消は未充足')],
}
p=r/'docs/acceptance/phase3/VERIFICATION.md';s=p.read_text()
section='''\n## 既存入力・生成手順の原本対応（22件）\n\n以下の実pathとSHAは今回再利用できる入力原本または既存生成手順sourceの識別であり、これら専門E2Eを今回実行した結果ではない。生成手順のSHAを実生成fixtureのSHAへ置換しない。UUID等を生成する手順は実施時に添付するgiven scenarioのbytes/SHAも採取する。生成コマンドは既存configの `BROWSER_ENGINES=all npm run test:e2e -- tests/e2e/<対象spec>` で、指定caseのgiven添付と実完全fileを保持する。実機用の入力を取り出す前に統合担当が原全CI/版結合を確認する。helperは呼出元specから実行する。`run_formal.py` は原正式手順専用で、この依頼では起動しない。\n\nPREPAREDは台帳・空様式・既存入力への参照準備に限る。実録音、二実端末の同base取得、実Auth指摘、実旧build、実ゲーム結果、実契約見積は未取得であり、合成WAV/固定UUID/局所receiverをそれらの入力完成と呼ばない。必要環境が提供された後、各caseのgivenを実環境で成立させた記録を別途残す。\n\n| 原ID | 今ある入力・生成手順の実path / SHA-256 | givenとの対応と未充足部分 |\n| --- | --- | --- |\n'''
for case,refs in M.items():
 links=[]; meanings=[]
 for path,meaning in refs:
  f=r/path;assert f.is_file(),path
  sha=hashlib.sha256(f.read_bytes()).hexdigest()
  links.append(f'[{path}](../../../{path})<br>`{sha}`')
  meanings.append(meaning)
 section+=f"| {case} | {'<br>'.join(links)} | {'。'.join(meanings)} |\n"
s=s.replace('\n## 元22件とは別の残条件',section+'\n## 元22件とは別の残条件')
p.write_text(s)
