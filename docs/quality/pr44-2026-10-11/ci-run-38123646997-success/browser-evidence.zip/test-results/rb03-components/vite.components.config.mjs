import config from "/home/runner/work/shinariokanri/shinariokanri/vite.config.ts";
export default { ...config, cacheDir: "/home/runner/work/shinariokanri/shinariokanri/test-results/rb03-components/.vite" };
