# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rb06-recovery.spec.ts >> 50件より古い版を通常検索し、単体復元と作品全体復元を区別して保存失敗・再入・cold再生する
- Location: tests/e2e/rb06-recovery.spec.ts:11:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.sidebar')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.sidebar') with timeout 5000ms
  - waiting for locator('.sidebar')

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- banner:
  - link "本文へ移動":
    - /url: "#main-content"
  - text: S シナリオ管理
  - button "配色を切り替え"
- main:
  - text: YOUR STORY, CONNECTED.
  - heading "物語をつなぐ。 次の一行へ。" [level=1]
  - paragraph: 人物、出来事、本文、分岐。 作品のすべてを、ひとつのノートに。
  - heading "新しい作品をはじめる" [level=2]
  - paragraph: まずはタイトルだけ。詳細はあとから。
  - text: 作品名
  - textbox "作品名":
    - /placeholder: あなたの物語のタイトル
  - button "作品を作成" [disabled]
  - button "サンプルで試す"
  - button "保存ファイルを読み込む"
  - heading "あなたの作品" [level=2]
  - text: "0"
  - paragraph: はじめての作品が、ここに並びます。
  - text: 作成した作品はこのブラウザーの端末内に保存されます。 作品はこのブラウザーに保存されます 端末内の作品 · 同期はアカウント欄から設定できます
- dialog "作品ファイルを読み込む":
  - heading "作品ファイルを読み込む" [level=2]
  - button "閉じる"
  - heading "ファイルから復元" [level=3]
  - paragraph: 元ファイルと対応の入力を端末内に保持し、影響を確認してから復元します。
  - text: 保存ファイルを選ぶ
  - button "保存ファイルを選ぶ" [disabled]
  - status:
    - text: 確認した内容を原子保存中…
    - button "中止"
  - heading "検査済みの作品 · 確認後の変更" [level=3]
  - paragraph: 2件の情報 · 74件の履歴 · 0 bytesの素材
  - paragraph: 74件の送信待ち意図を保持します。接続先・権限・サーバー共通元を確認するまで自動送信しません。
  - text: 復元方法
  - combobox "復元方法" [disabled]:
    - option "保存IDを維持して新規復元" [selected]
    - option "新しいIDへ複製して追加"
    - option "同じ作品を置換"
    - option "同じ作品へ統合"
    - option "別作品へ明示ID対応で統合"
  - button "復元の影響を確認" [disabled]
  - paragraph: 確認した対象版 新規 · 追加 2件 · 差分 0件
  - checkbox "復元方法と対象への影響を確認しました" [checked] [disabled]
  - text: 復元方法と対象への影響を確認しました
  - button "中止" [disabled]
  - button "この内容で復元する" [disabled]
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { readFile } from 'node:fs/promises';
  3  | import { createEntity, createProject, textToRichText } from '../../src/domain/model';
  4  | import { exportScenario, inspectScenario } from '../../src/storage/archive';
  5  | async function navigate(page: Page, name: RegExp) { const menu = page.getByRole('button', { name: 'メニューを開く' }); if (await menu.isVisible()) await menu.click(); await page.locator('.sidebar').getByRole('button', { name }).first().click(); }
  6  | async function work(page: Page, tab: string) { await navigate(page, /^作品・保存/); await page.getByRole('tab', { name: tab, exact: true }).click(); }
> 7  | async function seed(page: Page, bytes: Uint8Array) { await page.goto('./'); await page.getByRole('button', { name: '保存ファイルを読み込む', exact: true }).click(); await page.locator('input[type=file]').setInputFiles({ name: 'recovery.scenario', mimeType: 'application/zip', buffer: Buffer.from(bytes) }); await page.getByLabel('復元方法と対象への影響を確認しました').check(); await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click(); await expect(page.locator('.sidebar')).toBeVisible(); }
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ^ Error: expect(locator).toBeVisible() failed
  8  | async function backup(page: Page) { await work(page, '完全保存・復元'); const pending = page.waitForEvent('download'); await page.getByRole('button', { name: '完全保存ファイルを作成', exact: true }).click(); const download = await pending; return inspectScenario(new Uint8Array(await readFile((await download.path())!)), { worker: false }); }
  9  | async function oldHistory() { const bytes = new Uint8Array(await readFile('tests/fixtures/rb06-history.scenario')), prepared = await inspectScenario(bytes, { worker: false }), p = prepared.project, first = p.history[0], scene = first.after.entities[0]; return { bytes, p, operation: first.operationId, scene }; }
  10 | 
  11 | test('50件より古い版を通常検索し、単体復元と作品全体復元を区別して保存失敗・再入・cold再生する', async ({ page }) => {
  12 |   const f = await oldHistory(); await seed(page, f.bytes); await work(page, '変更履歴'); const panel = page.locator('.history-page'); expect(await panel.locator('.history-list > li').count()).toBeLessThanOrEqual(30); await panel.getByLabel('履歴を検索', { exact: true }).fill(f.operation); await panel.getByRole('button', { name: /原作品を保存 · 版 1/ }).click(); await panel.getByLabel('単体復元する対象', { exact: true }).selectOption(f.scene.id); await panel.getByRole('button', { name: 'この情報だけの復元を確認', exact: true }).click();
  13 |   await page.evaluate(() => { const original = IDBObjectStore.prototype.put; (window as any).__rb06Fail = true; IDBObjectStore.prototype.put = function (...args: Parameters<IDBObjectStore['put']>) { if ((window as any).__rb06Fail && this.name === 'projects') { (window as any).__rb06Fail = false; throw new DOMException('fixture full', 'QuotaExceededError'); } return original.apply(this, args); }; });
  14 |   await panel.getByRole('button', { name: 'この内容へ復元する', exact: true }).click(); await expect(panel.getByRole('alert')).toContainText('容量'); await expect(panel.getByRole('region', { name: '確認した復元差分' })).toContainText('原場面'); await navigate(page, /^資料/); await work(page, '変更履歴'); await expect(panel.getByRole('region', { name: '確認した復元差分' })).toBeVisible(); await panel.getByRole('button', { name: 'この内容へ復元する', exact: true }).click(); await expect(panel.getByRole('status').filter({ hasText: '保存した版を確認' })).toBeVisible();
  15 |   await page.reload(); await work(page, '変更履歴'); await expect(panel.getByLabel('履歴を検索', { exact: true })).toHaveValue(f.operation); await expect(panel.getByLabel('単体復元する対象', { exact: true })).toHaveValue(f.scene.id); let inspected = await backup(page); expect(inspected.project.name).toBe(f.p.name); expect(inspected.project.entities.find(e => e.id === f.scene.id)!.name).toBe('原場面'); expect(inspected.project.snapshots).toEqual(f.p.snapshots);
  16 |   await work(page, '変更履歴'); await panel.getByRole('button', { name: '作品全体の復元差分を確認', exact: true }).click(); await panel.getByRole('button', { name: '確認した作品全体へ復元', exact: true }).click(); await expect(panel.getByRole('status').filter({ hasText: '保存した版を確認' })).toBeVisible(); inspected = await backup(page); expect(inspected.project.name).toBe('復元元'); expect(inspected.project.history.length).toBe(f.p.history.length + 2); expect(inspected.project.snapshots).toEqual(f.p.snapshots); expect(inspected.recovery!.pending.length).toBeGreaterThanOrEqual(f.p.history.length);
  17 | });
  18 | 
  19 | test('別作品の全ID対応を画面移動・cold再起動から再開し、失敗後に原子統合して元履歴・段落を完全保存する', async ({ page }) => {
  20 |   const destination = createProject('統合先'), own = createEntity(destination.projectId, 'note', '残す元メモ', { body: textToRichText('保持する') }); destination.entities.push(own); await seed(page, await exportScenario(destination)); await work(page, '完全保存・復元'); const source = createProject('別の復元元'), scene = createEntity(source.projectId, 'scene', '取り込む場面', { body: textToRichText('別作品😀の段落') }); source.entities.push(scene);
  21 |   await page.locator('input[type=file]').setInputFiles({ name: 'other.scenario', mimeType: 'application/zip', buffer: Buffer.from(await exportScenario(source)) }); await page.getByLabel('復元方法', { exact: true }).selectOption('mapped_merge'); await page.getByLabel('復元する対象作品', { exact: true }).selectOption(destination.projectId); await page.getByRole('button', { name: '全IDへ新しい対応先を用意', exact: true }).click(); await page.getByRole('button', { name: '復元の影響を確認', exact: true }).click(); await page.locator('.import-preview details summary').first().click(); const selector = page.locator('select[aria-label$="の統合方法"]').first(); await selector.selectOption('existing'); await page.getByRole('button', { name: '復元の影響を確認', exact: true }).click(); await expect(page.getByLabel('復元方法と対象への影響を確認しました')).toBeEnabled();
  22 |   await navigate(page, /^資料/); await work(page, '完全保存・復元'); await expect(page.getByLabel('復元方法', { exact: true })).toHaveValue('mapped_merge'); await page.reload(); await work(page, '完全保存・復元'); await expect(page.getByText('元ファイルとID対応の入力を再開しました。対象版の影響を再確認してください。')).toBeVisible(); await expect(page.getByLabel('復元方法と対象への影響を確認しました')).not.toBeChecked(); await page.getByRole('button', { name: '復元の影響を確認', exact: true }).click(); await page.getByLabel('復元方法と対象への影響を確認しました').check();
  23 |   await page.evaluate(() => { const original = IDBObjectStore.prototype.put; (window as any).__rb06Fail = true; IDBObjectStore.prototype.put = function (...args: Parameters<IDBObjectStore['put']>) { if ((window as any).__rb06Fail && this.name === 'projects') { (window as any).__rb06Fail = false; throw new DOMException('fixture quota', 'QuotaExceededError'); } return original.apply(this, args); }; }); await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click(); await expect(page.locator('.backup-page').getByRole('alert')).toContainText('容量'); await expect(page.getByLabel('復元方法', { exact: true })).toHaveValue('mapped_merge'); await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click(); await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。')).toBeVisible();
  24 |   const restored = await backup(page); expect(restored.project.projectId).toBe(destination.projectId); expect(restored.project.name).toBe(destination.name); expect(restored.project.entities.find(e => e.id === own.id)).toBeTruthy(); const mapped = restored.project.entities.find(e => e.kind === 'scene')!; expect(mapped.id).not.toBe(scene.id); expect(mapped.kind === 'scene' && mapped.data.body[0].id).not.toBe(scene.data.body[0].id); expect(mapped.kind === 'scene' && mapped.data.body[0].text).toBe('別作品😀の段落'); await page.reload(); await work(page, '変更履歴'); await page.getByRole('button', { name: /専用ファイルをmapped_mergeで復元/ }).first().click(); await expect(page.getByRole('region', { name: '移行・読み込み前の復元点' })).toContainText('前の復元点');
  25 | });
  26 | 
  27 | test('復元保存待ちの後に選んだ資料と作品を保持し、新規復元だけを一覧へ追加する', async ({ page }) => {
  28 |   const original=createProject('復元後も続ける作品A');original.entities.push(createEntity(original.projectId,'note','続ける資料'));await seed(page,await exportScenario(original));await work(page,'完全保存・復元');
  29 |   const incoming=createProject('待機中に復元する作品C');await page.locator('input[type=file]').setInputFiles({name:'later.scenario',mimeType:'application/zip',buffer:Buffer.from(await exportScenario(incoming))});await page.getByLabel('復元方法と対象への影響を確認しました').check();
  30 |   await page.evaluate(()=>{const digest=crypto.subtle.digest.bind(crypto.subtle);let hold=true;crypto.subtle.digest=async(...args:Parameters<SubtleCrypto['digest']>)=>{if(hold){hold=false;(window as any).__rb06ImportHeld=true;await new Promise<void>(resolve=>{(window as any).__releaseRb06Import=resolve;});}return digest(...args);};});
  31 |   await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).__rb06ImportHeld)).toBe(true);await navigate(page,/^資料/);await expect(page.locator('.workspace-heading h1')).toHaveText('資料');await page.evaluate(()=>(window as any).__releaseRb06Import());
  32 |   await expect.poll(()=>page.evaluate(async id=>{const databases=await indexedDB.databases();for(const item of databases){if(!item.name)continue;const db=await new Promise<IDBDatabase>((resolve,reject)=>{const request=indexedDB.open(item.name!);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});try{if(db.objectStoreNames.contains('projects')){const found=await new Promise<boolean>((resolve,reject)=>{const request=db.transaction('projects').objectStore('projects').get(id);request.onsuccess=()=>resolve(!!request.result);request.onerror=()=>reject(request.error);});if(found)return true;}}finally{db.close();}}return false;},incoming.projectId)).toBe(true);await expect(page.locator('.workspace-heading h1')).toHaveText('資料');await expect(page.locator('.project-switch strong')).toHaveText(original.name);await page.reload();await expect(page.locator('.project-switch strong')).toHaveText(original.name);await expect(page.locator('.workspace-heading h1')).toHaveText('資料');
  33 | });
  34 | 
  35 | test('native保存ack待ちに届いた後続ファイルを保持し、先の新規復元が確認画面を開き直さない',async({page})=>{
  36 |  const original=createProject('後続選択を続ける作品A');await seed(page,await exportScenario(original));await work(page,'完全保存・復元');const first=createProject('先に保存する作品C'),later=createProject('後から確認する作品D');
  37 |  await page.locator('input[type=file]').setInputFiles({name:'first.scenario',mimeType:'application/zip',buffer:Buffer.from(await exportScenario(first))});await page.getByLabel('復元方法と対象への影響を確認しました').check();
  38 |  await page.evaluate(id=>{const descriptor=Object.getOwnPropertyDescriptor(IDBTransaction.prototype,'oncomplete')!,put=IDBObjectStore.prototype.put;let held:IDBTransaction|undefined;IDBObjectStore.prototype.put=function(...args:Parameters<IDBObjectStore['put']>){if(this.name==='projects'&&(args[0] as any).projectId===id)held=this.transaction;return put.apply(this,args);};Object.defineProperty(IDBTransaction.prototype,'oncomplete',{...descriptor,set(handler){descriptor.set!.call(this,function(this:IDBTransaction,event:Event){if(this===held){(window as any).__rb06AckWaiting=true;(window as any).__rb06ReleaseAck=()=>handler.call(this,event);}else handler.call(this,event);});}});},first.projectId);
  39 |  await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).__rb06AckWaiting)).toBe(true);
  40 |  const bytes=Array.from(await exportScenario(later));await page.locator('input[type=file]').evaluate((input,values)=>{const transfer=new DataTransfer();transfer.items.add(new File([new Uint8Array(values)],'later.scenario',{type:'application/zip'}));(input as HTMLInputElement).files=transfer.files;input.dispatchEvent(new Event('change',{bubbles:true}));},bytes);await page.evaluate(()=>(window as any).__rb06ReleaseAck());
  41 |  await expect(page.locator('.project-switch strong')).toHaveText(original.name);await expect(page.locator('.import-preview h3')).toContainText(later.name);await page.reload();await work(page,'完全保存・復元');await expect(page.locator('.import-preview h3')).toContainText(later.name);await expect(page.getByLabel('復元方法と対象への影響を確認しました')).not.toBeChecked();
  42 | });
  43 | 
```