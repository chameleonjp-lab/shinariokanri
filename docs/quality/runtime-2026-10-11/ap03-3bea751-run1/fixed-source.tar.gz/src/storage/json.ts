import { StorageError } from './errors';

export const FORMAT_VERSION = '1.0.0' as const;
export const ARCHIVE_LIMITS = Object.freeze({
  compressedBytes: 64 * 1024 * 1024,
  expandedBytes: 256 * 1024 * 1024,
  jsonBytes: 64 * 1024 * 1024,
  assetBytes: 32 * 1024 * 1024,
  files: 5_000,
  records: 100_000,
  depth: 32,
  objects: 500_000,
  conditionDepth: 16,
  conditionNodes: 256,
  fieldBytes: 1024 * 1024,
});
export type ArchiveLimits = Record<keyof typeof ARCHIVE_LIMITS, number>;
export type LimitOverrides = Partial<Record<keyof ArchiveLimits, number>>;

/** Tests may lower limits; callers cannot silently raise the v1 safety contract. */
export function resolveLimits(overrides: LimitOverrides = {}): ArchiveLimits {
  const result = { ...ARCHIVE_LIMITS } as Record<keyof ArchiveLimits, number>;
  for (const [key, value] of Object.entries(overrides)) {
    if (!(key in result) || !Number.isSafeInteger(value) || value! < 1 || value! > result[key as keyof ArchiveLimits]) {
      throw new StorageError('LIMIT_EXCEEDED', 'v1の安全上限は引き上げられません。', key);
    }
    result[key as keyof ArchiveLimits] = value!;
  }
  return result as ArchiveLimits;
}

// Unicode mode consumes valid pairs as supplementary code points. Only an
// isolated surrogate can match this class; no global state survives a check.
const isolatedSurrogate = /[\uD800-\uDFFF]/u;
export function isValidUnicode(value: string): boolean {
  return !isolatedSurrogate.test(value);
}

/** Parse while checking duplicate keys and structural quotas, before building an unchecked object graph. */
export interface JsonBudget { objects: number }
export function parseStrictJson(bytes: Uint8Array, path: string, limits: ArchiveLimits = ARCHIVE_LIMITS, budget: JsonBudget = { objects: 0 }): unknown {
  if (bytes.byteLength > limits.jsonBytes) throw new StorageError('LIMIT_EXCEEDED', 'JSONファイルが上限を超えています。', path);
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) throw new StorageError('ARCHIVE_INVALID', 'JSONのBOMは使用できません。', path);
  let source: string;
  try { source = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
  catch (error) { throw new StorageError('ARCHIVE_INVALID', 'JSONは有効なUTF-8である必要があります。', path, { cause: error }); }
  let offset = 0;
  const invalid = (message: string): never => { throw new StorageError('ARCHIVE_INVALID', `${message}（位置 ${offset}）`, path); };
  const whitespace = () => { while (/[ \t\n\r]/.test(source[offset] ?? '') && offset < source.length) offset++; };
  function string(): string {
    const begin = offset++;
    while (offset < source.length) {
      const char = source[offset++];
      if (char === '"') {
        let value: string;
        try { value = JSON.parse(source.slice(begin, offset)) as string; }
        catch { return invalid('文字列が不正です。'); }
        if (!isValidUnicode(value)) return invalid('Unicodeのサロゲートが不正です。');
        return value;
      }
      if (char === '\\') offset++;
    }
    return invalid('文字列が閉じられていません。');
  }
  function value(depth: number): unknown {
    whitespace();
    const char = source[offset];
    if (char === '"') return string();
    if (char === '{' || char === '[') {
      if (depth > limits.depth || ++budget.objects > limits.objects) throw new StorageError('LIMIT_EXCEEDED', 'JSONの構造が安全上限を超えています。', path);
      const object = char === '{';
      offset++; whitespace();
      const end = object ? '}' : ']';
      const result: Record<string, unknown> | unknown[] = object ? Object.create(null) as Record<string, unknown> : [];
      const keys = new Set<string>();
      if (source[offset] === end) { offset++; return result; }
      while (offset < source.length) {
        whitespace();
        if (object) {
          if (source[offset] !== '"') return invalid('オブジェクトのkeyが不正です。');
          const key = string();
          if (keys.has(key)) return invalid(`key「${key}」が重複しています。`);
          keys.add(key); whitespace();
          if (source[offset++] !== ':') return invalid('keyの後にコロンが必要です。');
          (result as Record<string, unknown>)[key] = value(depth + 1);
        } else (result as unknown[]).push(value(depth + 1));
        whitespace();
        const delimiter = source[offset++];
        if (delimiter === end) return result;
        if (delimiter !== ',') return invalid('区切り文字が不正です。');
      }
      return invalid('JSONが閉じられていません。');
    }
    for (const [token, literal] of [['true', true], ['false', false], ['null', null]] as const) {
      if (source.startsWith(token, offset)) { offset += token.length; return literal; }
    }
    const token = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(source.slice(offset));
    if (!token) return invalid('値が不正です。');
    offset += token[0].length;
    const number = Number(token[0]);
    if (!Number.isFinite(number)) return invalid('有限でない数値は保存できません。');
    return number;
  }
  const result = value(1); whitespace();
  if (offset !== source.length) invalid('JSONの末尾に余分なデータがあります。');
  return result;
}

/** Check the canonical JSON value contract without constructing an unused
 * encoded string. Object fields with undefined remain omitted; array values
 * must be serializable. Shared values are allowed, active cycles are not. */
export function validateJsonValue(value: unknown): void {
  const active = new Set<object>();
  const complete = new WeakSet<object>();
  function visit(input: unknown): void {
    if (input === null || typeof input === 'boolean') return;
    if (typeof input === 'string') {
      if (!isValidUnicode(input)) throw new StorageError('VALIDATION_FAILED', 'Unicodeのサロゲートが不正です。');
      return;
    }
    if (typeof input === 'number') {
      if (!Number.isFinite(input)) throw new StorageError('VALIDATION_FAILED', '有限でない数値は保存できません。');
      return;
    }
    if (typeof input !== 'object') throw new StorageError('VALIDATION_FAILED', 'JSONに保存できない値があります。');
    if (active.has(input)) throw new StorageError('VALIDATION_FAILED', '循環したJSONは保存できません。');
    if (complete.has(input)) return;
    active.add(input);
    if (Array.isArray(input)) input.forEach(visit);
    else for (const key of Object.keys(input)) {
      const child = (input as Record<string, unknown>)[key];
      if (child !== undefined) visit(child);
    }
    active.delete(input);
    complete.add(input);
  }
  visit(value);
}

/** Keys are canonicalized, but all arrays retain their semantic order. */
/** Reuse only small record encodings whose entire value is known immutable.
 * The caller must use its own recursively frozen plain-data registry; a
 * shallow Object.freeze is insufficient. Successful canonical encodings
 * retain every original byte. Both count and UTF-16 storage are bounded. */
export interface CanonicalJsonCache {
  get(value: object): string | undefined;
  set(value: object, encoded: string): void;
}

export function createCanonicalJsonCache(isImmutable: (value: object) => boolean): CanonicalJsonCache {
  const maximumEntryBytes = 64 * 1024;
  const maximumTotalBytes = 32 * 1024 * 1024;
  const maximumEntries = 16_384;
  let values = new WeakMap<object, string>(), bytes = 0, entries = 0;
  return {
    get: value => values.get(value),
    set(value, encoded) {
      if (!isImmutable(value) || Array.isArray(value)) return;
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Object.prototype && prototype !== null) return;
      const descriptors = Object.getOwnPropertyDescriptors(value);
      if (typeof descriptors.id?.value !== 'string' || typeof descriptors.kind?.value !== 'string'
        || Object.values(descriptors).some(property => !('value' in property))) return;
      const encodedBytes = encoded.length * 2;
      if (encodedBytes > maximumEntryBytes) return;
      if (entries + 1 > maximumEntries || bytes + encodedBytes > maximumTotalBytes) {
        values = new WeakMap<object, string>(); bytes = 0; entries = 0;
      }
      values.set(value, encoded); bytes += encodedBytes; entries++;
    },
  };
}

export function canonicalJson(value: unknown, cache?: CanonicalJsonCache): string {
  const active = new Set<object>();
  function encode(input: unknown): string {
    if (input === null) return 'null';
    if (typeof input === 'string') {
      if (!isValidUnicode(input)) throw new StorageError('VALIDATION_FAILED', 'Unicodeのサロゲートが不正です。');
      return JSON.stringify(input);
    }
    if (typeof input === 'boolean') return String(input);
    if (typeof input === 'number') {
      if (!Number.isFinite(input)) throw new StorageError('VALIDATION_FAILED', '有限でない数値は保存できません。');
      return JSON.stringify(input);
    }
    if (typeof input !== 'object') throw new StorageError('VALIDATION_FAILED', 'JSONに保存できない値があります。');
    if (active.has(input)) throw new StorageError('VALIDATION_FAILED', '循環したJSONは保存できません。');
    const cached = cache?.get(input);
    if (cached !== undefined) return cached;
    active.add(input);
    const encoded = Array.isArray(input)
      ? `[${input.map(encode).join(',')}]`
      : `{${Object.keys(input).filter(key => (input as Record<string, unknown>)[key] !== undefined).sort()
        .map(key => `${JSON.stringify(key)}:${encode((input as Record<string, unknown>)[key])}`).join(',')}}`;
    active.delete(input);
    cache?.set(input, encoded);
    return encoded;
  }
  return encode(value);
}

export const jsonBytes = (value: unknown, cache?: CanonicalJsonCache): Uint8Array => new TextEncoder().encode(canonicalJson(value, cache));
export const equalJson = (left: unknown, right: unknown): boolean => canonicalJson(left) === canonicalJson(right);

/** Decide whether to use the lossless dictionary before allocating a flat
 * JSON string. This is a size decision, not a replacement for validation. */
export function exceedsJsonBytes(value: unknown, limit: number): boolean {
  const sizes = new WeakMap<object, number>(), active = new Set<object>();
  const text = (value: unknown) => new TextEncoder().encode(canonicalJson(value)).byteLength;
  const size = (input: unknown): number => {
    if (!input || typeof input !== 'object') return Math.min(limit + 1, text(input));
    if (active.has(input)) throw new StorageError('VALIDATION_FAILED', '循環したJSONは保存できません。');
    const prior = sizes.get(input);
    if (prior !== undefined) return prior;
    active.add(input);
    let bytes = 2;
    if (Array.isArray(input)) {
      bytes += Math.max(0, input.length - 1);
      for (let index = 0; index < input.length && bytes <= limit; index++) if (Object.hasOwn(input, index)) bytes += size(input[index]);
    } else {
      let first = true;
      for (const key of Object.keys(input)) {
        const child = (input as Record<string, unknown>)[key];
        if (child === undefined) continue;
        bytes += (first ? 0 : 1) + new TextEncoder().encode(JSON.stringify(key)).byteLength + 1 + size(child);
        first = false;
        if (bytes > limit) break;
      }
    }
    active.delete(input);
    bytes = Math.min(bytes, limit + 1);
    sizes.set(input, bytes);
    return bytes;
  };
  return size(value) > limit;
}

export async function sha256(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', bytes.slice().buffer);
  return [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
}

export function safeArchivePath(path: string): void {
  if (!path || path.includes('\0') || path.includes('\\') || path.startsWith('/') || /^[a-z]:/i.test(path)
    || path.split('/').some(part => !part || part === '.' || part === '..') || !isValidUnicode(path)) {
    throw new StorageError('UNSAFE_PATH', '危険なファイルパスです。', path);
  }
}
