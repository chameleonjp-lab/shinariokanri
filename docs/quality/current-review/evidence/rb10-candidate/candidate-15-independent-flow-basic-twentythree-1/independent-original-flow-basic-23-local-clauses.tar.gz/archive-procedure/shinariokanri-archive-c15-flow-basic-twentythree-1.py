import pathlib,json,datetime
template=pathlib.Path('/tmp/shinariokanri-archive-c15-completed-local-1.py').read_text();ns={};exec(template[:template.index("\n\nCOMMIT='6ed5654")],ns)
ns['COMMIT']='6ed5654ca6226061a48651dd317ce1a922c5d07b';ns['TREE']='2e1650180b7769e8a2e59a6a01510c8d64bdac8b'
manifest=pathlib.Path('/tmp/shinariokanri-independent-c15-flow-basic-closure-1/MANIFEST.json');d=ns['read'](manifest)
assert ns['sha'](manifest)=='6f2055d36454398fab4ed7c75751a1537a87a7f6e5b0c09e4401f02fc254341e'
assert d['fileCount']==926 and d['totalBytes']==72678745 and d['wholeLocalCount']==23 and d['whole116Passed'] is False and d['C16SuccessesInferred']==0
pairs=[]
for row in d['files']:
 p=pathlib.Path(row['path']);assert p.stat().st_size==row['bytes'] and ns['sha'](p)==row['sha256'];pairs.append((p,pathlib.PurePosixPath('actual-independent-c15-flow-basic-closure')/row['member']))
pairs.append((manifest,pathlib.PurePosixPath('closed-original-manifest')/manifest.name));pairs.append((pathlib.Path(__file__),pathlib.PurePosixPath('archive-procedure')/pathlib.Path(__file__).name))
out=pathlib.Path('/workspace/shinariokanri-rb10-final-candidate-evidence/docs/quality/current-review/evidence/rb10-candidate/candidate-15-independent-flow-basic-twentythree-1');assert not out.exists();out.mkdir()
r=ns['bundle'](out,'independent-original-flow-basic-23-local-clauses',pairs,'Historical C15 only: cumulative23 original cases locally adjudicated across all literal four clauses. Flow7 four cases pass and F19 exact cancel-label matcher procedure failure preserved; corrected type13 and actual basic8 pass all8 including independent ref/clone/cancel/cold. B07 DOM boundary injection is explicitly separate from natural file picker. Original F39 known failure and actual physical/live unknown remain. No C16 pass or whole116/release completion inferred.')
(out/'SUMMARY.json').write_text(json.dumps({'candidate':'C15','commit':ns['COMMIT'],'tree':ns['TREE'],'build':'d0fc32b97242aa86b09f','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalClosureSHA256':ns['sha'](manifest),'wholeLocalCount':23,'caseCounts':d['caseCounts'],'whole116Passed':False,'physical':'not_run','actualAuth':'not_run','C16SuccessesInferred':False,'archive':r},ensure_ascii=False,indent=2)+'\n')
(out/'MANIFEST.json').write_text(json.dumps({'candidate':'C15','allArchiveMembersByteVerified':True,'files':[ns['descriptor'](p,p.name) for p in sorted(out.iterdir()) if p.is_file()]},ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
