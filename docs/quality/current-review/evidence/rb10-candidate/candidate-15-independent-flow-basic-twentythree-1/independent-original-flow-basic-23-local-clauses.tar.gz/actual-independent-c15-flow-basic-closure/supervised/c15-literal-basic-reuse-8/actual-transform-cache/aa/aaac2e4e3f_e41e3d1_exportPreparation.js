// 08492db03b4ae2c6567af9371e422f98728bf3f2
import { captureRuntimeContent } from './runtimeVersions';
import { resolveReuseContent, reuseOrigin } from './reuse';
import { resolvePinnedWorlds } from './pinnedWorlds';
import { sha256, jsonBytes } from '../storage/json';
import { collectReferences, validateProject } from './model';
import { createProjection } from './projection';
const revisionPattern = /^(?:0|[1-9][0-9]*)$/;
const hash = value => sha256(jsonBytes(value));
function blocks(value) {
  return Array.isArray(value) ? value : [];
}
function entityDocuments(entity) {
  return ['body', 'text', 'summary', 'description', 'usageNotes', 'caption', 'action', 'tutorial', 'interpretation', 'targetAudience', 'experience', 'theme', 'tone', 'scope'].filter(field => blocks(entity.data[field]).length).map(field => [field, blocks(entity.data[field])]);
}
export async function selectExportSource(project, options) {
  if (options.targetRevision === undefined === (options.targetVersionId === undefined)) return {
    ok: false,
    issues: [{
      code: 'VALIDATION_FAILED',
      message: '出力する正本の版を一つ指定してください。'
    }]
  };
  if (options.targetRevision !== undefined) {
    if (!revisionPattern.test(options.targetRevision) || options.targetRevision !== project.revision) return {
      ok: false,
      issues: [{
        code: 'VALIDATION_FAILED',
        message: '選択した版と出力元の版が一致しません。対象版を読み直してください。'
      }]
    };
    return {
      ok: true,
      project
    };
  }
  const snapshot = project.snapshots.find(snapshot => snapshot.id === options.targetVersionId);
  if (!snapshot || snapshot.content.projectId !== project.projectId) return {
    ok: false,
    issues: [{
      code: 'REFERENCE_INVALID',
      message: '選択した公開版の保存内容が見つかりません。',
      entityId: options.targetVersionId
    }]
  };
  // Private checkpoints, reviews and anchors can reference another pinned version.
  // Keep only that immutable dependency closure for validation, never live content.
  const dependencies = [];
  const pending = [snapshot],
    visited = new Set();
  while (pending.length) {
    const dependency = pending.pop();
    if (visited.has(dependency.id)) continue;
    visited.add(dependency.id);
    if (project.snapshots.filter(candidate => candidate.id === dependency.id).length !== 1 || dependency.content.projectId !== project.projectId) return {
      ok: false,
      issues: [{
        code: 'REFERENCE_INVALID',
        message: '保存版の依存内容を一意に確認できません。',
        entityId: dependency.id
      }]
    };
    if ((await hash(dependency.content)) !== dependency.contentHash) return {
      ok: false,
      issues: [{
        code: 'VALIDATION_FAILED',
        message: '保存版の内容hashが一致しないため出力を停止しました。',
        entityId: dependency.id
      }]
    };
    dependencies.push(dependency);
    for (const entity of dependency.content.entities) for (const reference of collectReferences(entity)) if (reference.scope === 'snapshot') {
      const target = project.snapshots.find(candidate => candidate.id === reference.id);
      if (target && !visited.has(target.id)) pending.push(target);
    }
  }
  return {
    ok: true,
    project: {
      ...structuredClone(snapshot.content),
      snapshots: dependencies,
      history: []
    }
  };
}

/** Resolve fixed pins in an output view, without copying borrowed data into the author's canonical document. */
export async function executionExportView(captured, selected, options) {
  var _options$targetVersio, _options$worldSnapsho, _options$worldSnapsho2;
  const edition = await captureRuntimeContent(captured, (_options$targetVersio = options.targetVersionId) !== null && _options$targetVersio !== void 0 ? _options$targetVersio : captured.projectId, {
      worldSnapshots: (_options$worldSnapsho = options.worldSnapshots) !== null && _options$worldSnapsho !== void 0 ? _options$worldSnapsho : {}
    }),
    view = resolveReuseContent(edition, edition.snapshots);
  function normalize(value, entityId, path = []) {
    var _options$targetVersio2;
    const origin = reuseOrigin(view, entityId);
    if (Array.isArray(value)) return value.map((item, index) => normalize(item, entityId, [...path, String(index)]));
    if (!value || typeof value !== 'object') return value;
    const object = value,
      editionId = (_options$targetVersio2 = options.targetVersionId) !== null && _options$targetVersio2 !== void 0 ? _options$targetVersio2 : view.projectId;
    // An explicit rich-text citation retains the original edition and its original IDs.
    if (path.includes('links') && path.at(-1) === 'target' && typeof object.sourceVersionId === 'string') return structuredClone(object);
    const mapped = Object.fromEntries(Object.entries(object).filter(([key]) => key !== 'reuse').map(([key, item]) => [key, origin && ['sourceVersionId', 'targetSnapshotId'].includes(key) && item === origin.sourceVersionId ? editionId : normalize(item, entityId, [...path, key])]));
    if (origin && typeof object.entityId === 'string' && object.sourceVersionId === origin.sourceVersionId) for (const key of ['entityId', 'blockId', 'lineId']) {
      var _origin$bindings;
      if (typeof object[key] === 'string') mapped[key] = (_origin$bindings = origin.bindings[object[key]]) !== null && _origin$bindings !== void 0 ? _origin$bindings : object[key];
    }
    return mapped;
  }
  const worlds = resolvePinnedWorlds(view, (_options$worldSnapsho2 = options.worldSnapshots) !== null && _options$worldSnapsho2 !== void 0 ? _options$worldSnapsho2 : {}).worlds,
    entities = view.entities.map(entity => ({
      ...entity,
      data: normalize(entity.data, entity.id)
    })),
    ids = new Set(entities.map(e => e.id)),
    relations = [...view.relations],
    relationIds = new Set(relations.map(r => r.id)),
    calendars = [...view.calendars];
  for (const world of worlds) {
    for (const entity of world.entities) {
      if (ids.has(entity.id)) throw Error('REFERENCE_INVALID: 固定世界と出力元のIDが衝突しています。');
      ids.add(entity.id);
      entities.push({
        ...structuredClone(entity),
        projectId: view.projectId
      });
    }
    for (const relation of world.relations) {
      if (relationIds.has(relation.id)) throw Error('REFERENCE_INVALID: 固定世界の関係IDが衝突しています。');
      relationIds.add(relation.id);
      relations.push({
        ...structuredClone(relation),
        projectId: view.projectId
      });
    }
    for (const calendar of world.calendars) if (!calendars.some(c => c.id === calendar.id)) calendars.push(structuredClone(calendar));
  }
  const policy = entities.find(e => e.id === options.projectionProfileId);
  if (!policy && options.targetVersionId) {
    const approved = captured.entities.find(e => e.id === options.projectionProfileId && e.kind === 'projection_profile' && e.data.sourceVersionId === options.targetVersionId);
    if (approved) entities.push(structuredClone(approved));
  }
  return {
    ...selected,
    entities,
    relations,
    calendars
  };
}
export function validatePublicPositions(projection) {
  var _projection$versions;
  const editions = new Map([['public-project', projection], ...((_projection$versions = projection.versions) !== null && _projection$versions !== void 0 ? _projection$versions : []).map(version => [version.id, version.projection])]),
    issues = [];
  for (const [version, edition] of editions) {
    const inspect = value => {
      var _object$entityId;
      if (Array.isArray(value)) {
        value.forEach(inspect);
        return;
      }
      if (!value || typeof value !== 'object') return;
      const object = value,
        entityId = (_object$entityId = object.entityId) !== null && _object$entityId !== void 0 ? _object$entityId : object.targetId,
        start = object.targetId ? object.targetStart : object.start,
        end = object.targetId ? object.targetEnd : object.end;
      if (typeof entityId === 'string' && (object.blockId != null || object.lineId != null || start != null || end != null)) {
        var _block$text;
        const target = editions.get(typeof object.sourceVersionId === 'string' ? object.sourceVersionId : version),
          record = target === null || target === void 0 ? void 0 : target.entities.find(entity => entity.id === entityId),
          line = typeof object.lineId === 'string' ? target === null || target === void 0 ? void 0 : target.entities.find(entity => entity.id === object.lineId && entity.kind === 'dialogue_line') : undefined,
          block = typeof object.blockId === 'string' ? record && entityDocuments(record).flatMap(([, document]) => document).find(block => block.id === object.blockId) : undefined,
          text = (_block$text = block === null || block === void 0 ? void 0 : block.text) !== null && _block$text !== void 0 ? _block$text : line ? blocks(line.data.text).map(block => block.text).join('\n') : undefined;
        const missing = !record || object.blockId != null && !block || object.lineId != null && !line,
          hasRange = start != null || end != null,
          invalidRange = hasRange && (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || Number(start) < 0 || Number(end) < Number(start) || text === undefined || Number(end) > [...text].length);
        if (missing || invalidRange) issues.push({
          code: 'REFERENCE_INVALID',
          message: '公開した固定版の本文位置を確認できません。公開文と文字範囲を再確認してください。',
          entityId
        });
      }
      Object.values(object).forEach(inspect);
    };
    edition.entities.forEach(entity => inspect(entity.data));
  }
  return issues;
}
/** Each historical citation has its own approved policy and immutable bytes. */
export async function prepareExportCitations(captured, selected, options, strictReferences) {
  const targets = {},
    versions = [],
    sources = [],
    active = new Set(),
    owners = new Map(),
    publicOwners = new Map();
  async function visit(edition, profileId, depth) {
    if (depth > 64) throw Error('IMPORT_LIMIT: 引用固定版の依存が64段階を超えています。');
    const policy = edition.entities.find(entity => entity.id === profileId && entity.kind === 'projection_profile' && entity.status === 'confirmed' && !entity.deletedAt);
    if (!policy) throw Error('REFERENCE_INVALID: 引用固定版の公開範囲が未確認です。');
    for (const declaration of (_policy$data$citedVer = policy.data.citedVersions) !== null && _policy$data$citedVer !== void 0 ? _policy$data$citedVer : []) {
      var _policy$data$citedVer, _options$worldPins, _options$worldSnapsho3, _options$worldPins2;
      const id = declaration.sourceVersionId,
        prior = targets[id];
      if (active.has(id)) throw Error('REFERENCE_INVALID: 引用固定版の公開依存が循環しています。');
      if (prior) {
        if (prior.publicVersionId !== declaration.publicVersionId || owners.get(id) !== declaration.profileId) throw Error('REFERENCE_INVALID: 同じ引用版に異なる公開範囲が指定されています。');
        continue;
      }
      if (versions.length + active.size >= 128 || publicOwners.has(declaration.publicVersionId) || !declaration.publicVersionId) throw Error('IMPORT_LIMIT: 引用固定版の上限または公開版IDが不正です。');
      publicOwners.set(declaration.publicVersionId, id);
      active.add(id);
      const own = captured.snapshots.find(pin => pin.id === id),
        world = ((_options$worldPins = options.worldPins) !== null && _options$worldPins !== void 0 ? _options$worldPins : []).find(pin => pin.id === id),
        pin = own !== null && own !== void 0 ? own : world,
        registry = (_options$worldSnapsho3 = options.worldSnapshots) !== null && _options$worldSnapsho3 !== void 0 ? _options$worldSnapsho3 : {};
      if (!pin || (await sha256(jsonBytes(pin.content))) !== pin.contentHash || world && (!registry[id] || (await sha256(jsonBytes(registry[id]))) !== pin.contentHash)) throw Error('INTEGRITY_FAILED: 引用版の期待hashまたは内容が一致しません。');
      const library = pin.content.projectId === captured.projectId ? captured.snapshots : [...((_options$worldPins2 = options.worldPins) !== null && _options$worldPins2 !== void 0 ? _options$worldPins2 : []).filter(item => item.content.projectId === pin.content.projectId).map(item => ({
        ...item,
        createdAt: '1970-01-01T00:00:00.000Z',
        versionLabel: '引用する固定世界'
      }))];
      const original = {
          ...structuredClone(pin.content),
          snapshots: structuredClone(library),
          history: []
        },
        inside = original.entities.find(entity => entity.id === declaration.profileId && entity.kind === 'projection_profile'),
        outside = captured.entities.find(entity => entity.id === declaration.profileId && entity.kind === 'projection_profile' && entity.data.sourceVersionId === id);
      if (!inside && !outside) throw Error('REFERENCE_INVALID: 引用対象版の公開文を確認した範囲がありません。');
      const view = await executionExportView(original, original, {
        ...options,
        projectionProfileId: declaration.profileId,
        targetVersionId: id,
        targetRevision: undefined
      });
      if (!inside && outside) view.entities.push({
        ...structuredClone(outside),
        projectId: view.projectId
      });
      await visit(view, declaration.profileId, depth + 1);
      const result = createProjection(view, declaration.profileId, {
        strictReferences,
        confirmedOnly: true,
        targetVersionId: id,
        versionTargets: targets
      });
      if (!result.ok) throw Object.assign(Error('EXPORT_UNSUPPORTED: 引用版の公開名・本文・必要参照が未確認です。'), {
        issues: result.issues
      });
      targets[id] = {
        publicVersionId: declaration.publicVersionId,
        idMap: result.idMap
      };
      owners.set(id, declaration.profileId);
      versions.push({
        id: declaration.publicVersionId,
        projection: result.projection
      });
      sources.push({
        publicVersionId: declaration.publicVersionId,
        profileId: declaration.profileId,
        project: view,
        projection: result.projection,
        idMap: result.idMap
      });
      active.delete(id);
    }
  }
  await visit(selected, options.projectionProfileId, 0);
  return {
    targets,
    versions,
    sources
  };
}

/** Shared preparation contains no browser bundle or asset bytes. Stored evidence reuses the exact publication rules. */
export async function preparePublicExecution(input, inputOptions) {
  var _options$worldSnapsho4;
  const captured = structuredClone(input),
    options = structuredClone(inputOptions),
    selected = await selectExportSource(captured, options);
  if (!selected.ok) throw Object.assign(Error('REFERENCE_INVALID: 出力対象版を確認できません。'), {
    issues: selected.issues
  });
  const checked = validateProject(selected.project, {
    worldSnapshots: (_options$worldSnapsho4 = options.worldSnapshots) !== null && _options$worldSnapsho4 !== void 0 ? _options$worldSnapsho4 : {}
  });
  if (!checked.ok) throw Object.assign(Error('REFERENCE_INVALID: 出力対象版の参照が不正です。'), {
    issues: checked.issues
  });
  const project = await executionExportView(captured, selected.project, options),
    citations = await prepareExportCitations(captured, project, options, true),
    result = createProjection(project, options.projectionProfileId, {
      strictReferences: true,
      confirmedOnly: true,
      targetVersionId: options.targetVersionId,
      versionTargets: citations.targets
    });
  if (!result.ok) throw Object.assign(Error('EXPORT_UNSUPPORTED: 固定した公開範囲を再構成できません。'), {
    issues: result.issues
  });
  if (citations.versions.length) result.projection.versions = citations.versions;
  const positions = validatePublicPositions(result.projection);
  if (positions.length) throw Object.assign(Error('REFERENCE_INVALID: 固定した公開本文位置が不正です。'), {
    issues: positions
  });
  return {
    project,
    projection: result.projection,
    idMap: result.idMap,
    citations
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjYXB0dXJlUnVudGltZUNvbnRlbnQiLCJyZXNvbHZlUmV1c2VDb250ZW50IiwicmV1c2VPcmlnaW4iLCJyZXNvbHZlUGlubmVkV29ybGRzIiwic2hhMjU2IiwianNvbkJ5dGVzIiwiY29sbGVjdFJlZmVyZW5jZXMiLCJ2YWxpZGF0ZVByb2plY3QiLCJjcmVhdGVQcm9qZWN0aW9uIiwicmV2aXNpb25QYXR0ZXJuIiwiaGFzaCIsInZhbHVlIiwiYmxvY2tzIiwiQXJyYXkiLCJpc0FycmF5IiwiZW50aXR5RG9jdW1lbnRzIiwiZW50aXR5IiwiZmlsdGVyIiwiZmllbGQiLCJkYXRhIiwibGVuZ3RoIiwibWFwIiwic2VsZWN0RXhwb3J0U291cmNlIiwicHJvamVjdCIsIm9wdGlvbnMiLCJ0YXJnZXRSZXZpc2lvbiIsInVuZGVmaW5lZCIsInRhcmdldFZlcnNpb25JZCIsIm9rIiwiaXNzdWVzIiwiY29kZSIsIm1lc3NhZ2UiLCJ0ZXN0IiwicmV2aXNpb24iLCJzbmFwc2hvdCIsInNuYXBzaG90cyIsImZpbmQiLCJpZCIsImNvbnRlbnQiLCJwcm9qZWN0SWQiLCJlbnRpdHlJZCIsImRlcGVuZGVuY2llcyIsInBlbmRpbmciLCJ2aXNpdGVkIiwiU2V0IiwiZGVwZW5kZW5jeSIsInBvcCIsImhhcyIsImFkZCIsImNhbmRpZGF0ZSIsImNvbnRlbnRIYXNoIiwicHVzaCIsImVudGl0aWVzIiwicmVmZXJlbmNlIiwic2NvcGUiLCJ0YXJnZXQiLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJoaXN0b3J5IiwiZXhlY3V0aW9uRXhwb3J0VmlldyIsImNhcHR1cmVkIiwic2VsZWN0ZWQiLCJfb3B0aW9ucyR0YXJnZXRWZXJzaW8iLCJfb3B0aW9ucyR3b3JsZFNuYXBzaG8iLCJfb3B0aW9ucyR3b3JsZFNuYXBzaG8yIiwiZWRpdGlvbiIsIndvcmxkU25hcHNob3RzIiwidmlldyIsIm5vcm1hbGl6ZSIsInBhdGgiLCJfb3B0aW9ucyR0YXJnZXRWZXJzaW8yIiwib3JpZ2luIiwiaXRlbSIsImluZGV4IiwiU3RyaW5nIiwib2JqZWN0IiwiZWRpdGlvbklkIiwiaW5jbHVkZXMiLCJhdCIsInNvdXJjZVZlcnNpb25JZCIsIm1hcHBlZCIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwiZW50cmllcyIsImtleSIsIl9vcmlnaW4kYmluZGluZ3MiLCJiaW5kaW5ncyIsIndvcmxkcyIsImlkcyIsImUiLCJyZWxhdGlvbnMiLCJyZWxhdGlvbklkcyIsInIiLCJjYWxlbmRhcnMiLCJ3b3JsZCIsIkVycm9yIiwicmVsYXRpb24iLCJjYWxlbmRhciIsInNvbWUiLCJjIiwicG9saWN5IiwicHJvamVjdGlvblByb2ZpbGVJZCIsImFwcHJvdmVkIiwia2luZCIsInZhbGlkYXRlUHVibGljUG9zaXRpb25zIiwicHJvamVjdGlvbiIsIl9wcm9qZWN0aW9uJHZlcnNpb25zIiwiZWRpdGlvbnMiLCJNYXAiLCJ2ZXJzaW9ucyIsInZlcnNpb24iLCJpbnNwZWN0IiwiX29iamVjdCRlbnRpdHlJZCIsImZvckVhY2giLCJ0YXJnZXRJZCIsInN0YXJ0IiwidGFyZ2V0U3RhcnQiLCJlbmQiLCJ0YXJnZXRFbmQiLCJibG9ja0lkIiwibGluZUlkIiwiX2Jsb2NrJHRleHQiLCJnZXQiLCJyZWNvcmQiLCJsaW5lIiwiYmxvY2siLCJmbGF0TWFwIiwiZG9jdW1lbnQiLCJ0ZXh0Iiwiam9pbiIsIm1pc3NpbmciLCJoYXNSYW5nZSIsImludmFsaWRSYW5nZSIsIk51bWJlciIsImlzU2FmZUludGVnZXIiLCJ2YWx1ZXMiLCJwcmVwYXJlRXhwb3J0Q2l0YXRpb25zIiwic3RyaWN0UmVmZXJlbmNlcyIsInRhcmdldHMiLCJzb3VyY2VzIiwiYWN0aXZlIiwib3duZXJzIiwicHVibGljT3duZXJzIiwidmlzaXQiLCJwcm9maWxlSWQiLCJkZXB0aCIsInN0YXR1cyIsImRlbGV0ZWRBdCIsImRlY2xhcmF0aW9uIiwiX3BvbGljeSRkYXRhJGNpdGVkVmVyIiwiY2l0ZWRWZXJzaW9ucyIsIl9vcHRpb25zJHdvcmxkUGlucyIsIl9vcHRpb25zJHdvcmxkU25hcHNobzMiLCJfb3B0aW9ucyR3b3JsZFBpbnMyIiwicHJpb3IiLCJwdWJsaWNWZXJzaW9uSWQiLCJzaXplIiwic2V0Iiwib3duIiwicGluIiwid29ybGRQaW5zIiwicmVnaXN0cnkiLCJsaWJyYXJ5IiwiY3JlYXRlZEF0IiwidmVyc2lvbkxhYmVsIiwib3JpZ2luYWwiLCJpbnNpZGUiLCJvdXRzaWRlIiwicmVzdWx0IiwiY29uZmlybWVkT25seSIsInZlcnNpb25UYXJnZXRzIiwiYXNzaWduIiwiaWRNYXAiLCJkZWxldGUiLCJwcmVwYXJlUHVibGljRXhlY3V0aW9uIiwiaW5wdXQiLCJpbnB1dE9wdGlvbnMiLCJfb3B0aW9ucyR3b3JsZFNuYXBzaG80IiwiY2hlY2tlZCIsImNpdGF0aW9ucyIsInBvc2l0aW9ucyJdLCJzb3VyY2VzIjpbImV4cG9ydFByZXBhcmF0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgRW50aXR5LCBJRCwgUHJvamVjdERhdGEgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB0eXBlIHsgRXhwb3J0T3B0aW9ucyB9IGZyb20gJy4vZXhwb3J0cyc7XG5pbXBvcnQgeyBjYXB0dXJlUnVudGltZUNvbnRlbnQgfSBmcm9tICcuL3J1bnRpbWVWZXJzaW9ucyc7XG5pbXBvcnQgeyByZXNvbHZlUmV1c2VDb250ZW50LCByZXVzZU9yaWdpbiB9IGZyb20gJy4vcmV1c2UnO1xuaW1wb3J0IHsgcmVzb2x2ZVBpbm5lZFdvcmxkcyB9IGZyb20gJy4vcGlubmVkV29ybGRzJztcbmltcG9ydCB7IHNoYTI1NiwganNvbkJ5dGVzIH0gZnJvbSAnLi4vc3RvcmFnZS9qc29uJztcbmltcG9ydCB7IGNvbGxlY3RSZWZlcmVuY2VzLCB2YWxpZGF0ZVByb2plY3QgfSBmcm9tICcuL21vZGVsJztcbmltcG9ydCB7IGNyZWF0ZVByb2plY3Rpb24gfSBmcm9tICcuL3Byb2plY3Rpb24nO1xuaW1wb3J0IHR5cGUgeyBQcm9qZWN0ZWRCbG9jaywgUHJvamVjdGVkRW50aXR5LCBQcm9qZWN0aW9uSXNzdWUsIFB1YmxpY1Byb2plY3Rpb24sIFB1YmxpY1ZhbHVlIH0gZnJvbSAnLi9wcm9qZWN0aW9uJztcbmNvbnN0IHJldmlzaW9uUGF0dGVybj0vXig/OjB8WzEtOV1bMC05XSopJC87XG5jb25zdCBoYXNoPSh2YWx1ZTp1bmtub3duKT0+c2hhMjU2KGpzb25CeXRlcyh2YWx1ZSkpO1xuZXhwb3J0IHR5cGUgQ2l0YXRpb25Tb3VyY2U9e3B1YmxpY1ZlcnNpb25JZDpzdHJpbmc7cHJvZmlsZUlkOnN0cmluZztwcm9qZWN0OlByb2plY3REYXRhO3Byb2plY3Rpb246UHVibGljUHJvamVjdGlvbjtpZE1hcDpSZWNvcmQ8c3RyaW5nLHN0cmluZz59O1xuZnVuY3Rpb24gYmxvY2tzKHZhbHVlOlB1YmxpY1ZhbHVlfHVuZGVmaW5lZCk6UHJvamVjdGVkQmxvY2tbXXtyZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSk/dmFsdWUgYXMgdW5rbm93biBhcyBQcm9qZWN0ZWRCbG9ja1tdOltdO31cbmZ1bmN0aW9uIGVudGl0eURvY3VtZW50cyhlbnRpdHk6UHJvamVjdGVkRW50aXR5KTpbc3RyaW5nLFByb2plY3RlZEJsb2NrW11dW117cmV0dXJuIFsnYm9keScsJ3RleHQnLCdzdW1tYXJ5JywnZGVzY3JpcHRpb24nLCd1c2FnZU5vdGVzJywnY2FwdGlvbicsJ2FjdGlvbicsJ3R1dG9yaWFsJywnaW50ZXJwcmV0YXRpb24nLCd0YXJnZXRBdWRpZW5jZScsJ2V4cGVyaWVuY2UnLCd0aGVtZScsJ3RvbmUnLCdzY29wZSddLmZpbHRlcihmaWVsZD0+YmxvY2tzKGVudGl0eS5kYXRhW2ZpZWxkXSkubGVuZ3RoKS5tYXAoZmllbGQ9PltmaWVsZCxibG9ja3MoZW50aXR5LmRhdGFbZmllbGRdKV0pO31cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWxlY3RFeHBvcnRTb3VyY2UocHJvamVjdDogUHJvamVjdERhdGEsIG9wdGlvbnM6IEV4cG9ydE9wdGlvbnMpOiBQcm9taXNlPHsgb2s6IHRydWU7IHByb2plY3Q6IFByb2plY3REYXRhIH0gfCB7IG9rOiBmYWxzZTsgaXNzdWVzOiBQcm9qZWN0aW9uSXNzdWVbXSB9PiB7XG4gIGlmICgob3B0aW9ucy50YXJnZXRSZXZpc2lvbiA9PT0gdW5kZWZpbmVkKSA9PT0gKG9wdGlvbnMudGFyZ2V0VmVyc2lvbklkID09PSB1bmRlZmluZWQpKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogW3sgY29kZTogJ1ZBTElEQVRJT05fRkFJTEVEJywgbWVzc2FnZTogJ+WHuuWKm+OBmeOCi+ato+acrOOBrueJiOOCkuS4gOOBpOaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicgfV0gfTtcbiAgaWYgKG9wdGlvbnMudGFyZ2V0UmV2aXNpb24gIT09IHVuZGVmaW5lZCkge1xuICAgIGlmICghcmV2aXNpb25QYXR0ZXJuLnRlc3Qob3B0aW9ucy50YXJnZXRSZXZpc2lvbikgfHwgb3B0aW9ucy50YXJnZXRSZXZpc2lvbiAhPT0gcHJvamVjdC5yZXZpc2lvbikgcmV0dXJuIHsgb2s6IGZhbHNlLCBpc3N1ZXM6IFt7IGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcsIG1lc3NhZ2U6ICfpgbjmip7jgZfjgZ/niYjjgajlh7rlipvlhYPjga7niYjjgYzkuIDoh7TjgZfjgb7jgZvjgpPjgILlr77osaHniYjjgpLoqq3jgb/nm7TjgZfjgabjgY/jgaDjgZXjgYTjgIInIH1dIH07XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHByb2plY3QgfTtcbiAgfVxuICBjb25zdCBzbmFwc2hvdCA9IHByb2plY3Quc25hcHNob3RzLmZpbmQoc25hcHNob3QgPT4gc25hcHNob3QuaWQgPT09IG9wdGlvbnMudGFyZ2V0VmVyc2lvbklkKTtcbiAgaWYgKCFzbmFwc2hvdCB8fCBzbmFwc2hvdC5jb250ZW50LnByb2plY3RJZCAhPT0gcHJvamVjdC5wcm9qZWN0SWQpIHJldHVybiB7IG9rOiBmYWxzZSwgaXNzdWVzOiBbeyBjb2RlOiAnUkVGRVJFTkNFX0lOVkFMSUQnLCBtZXNzYWdlOiAn6YG45oqe44GX44Gf5YWs6ZaL54mI44Gu5L+d5a2Y5YaF5a6544GM6KaL44Gk44GL44KK44G+44Gb44KT44CCJywgZW50aXR5SWQ6IG9wdGlvbnMudGFyZ2V0VmVyc2lvbklkIH1dIH07XG4gIC8vIFByaXZhdGUgY2hlY2twb2ludHMsIHJldmlld3MgYW5kIGFuY2hvcnMgY2FuIHJlZmVyZW5jZSBhbm90aGVyIHBpbm5lZCB2ZXJzaW9uLlxuICAvLyBLZWVwIG9ubHkgdGhhdCBpbW11dGFibGUgZGVwZW5kZW5jeSBjbG9zdXJlIGZvciB2YWxpZGF0aW9uLCBuZXZlciBsaXZlIGNvbnRlbnQuXG4gIGNvbnN0IGRlcGVuZGVuY2llczogUHJvamVjdERhdGFbJ3NuYXBzaG90cyddID0gW107XG4gIGNvbnN0IHBlbmRpbmcgPSBbc25hcHNob3RdLCB2aXNpdGVkID0gbmV3IFNldDxJRD4oKTtcbiAgd2hpbGUgKHBlbmRpbmcubGVuZ3RoKSB7XG4gICAgY29uc3QgZGVwZW5kZW5jeSA9IHBlbmRpbmcucG9wKCkhO1xuICAgIGlmICh2aXNpdGVkLmhhcyhkZXBlbmRlbmN5LmlkKSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQoZGVwZW5kZW5jeS5pZCk7XG4gICAgaWYgKHByb2plY3Quc25hcHNob3RzLmZpbHRlcihjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmlkID09PSBkZXBlbmRlbmN5LmlkKS5sZW5ndGggIT09IDEgfHwgZGVwZW5kZW5jeS5jb250ZW50LnByb2plY3RJZCAhPT0gcHJvamVjdC5wcm9qZWN0SWQpIHJldHVybiB7IG9rOiBmYWxzZSwgaXNzdWVzOiBbeyBjb2RlOiAnUkVGRVJFTkNFX0lOVkFMSUQnLCBtZXNzYWdlOiAn5L+d5a2Y54mI44Gu5L6d5a2Y5YaF5a6544KS5LiA5oSP44Gr56K66KqN44Gn44GN44G+44Gb44KT44CCJywgZW50aXR5SWQ6IGRlcGVuZGVuY3kuaWQgfV0gfTtcbiAgICBpZiAoYXdhaXQgaGFzaChkZXBlbmRlbmN5LmNvbnRlbnQpICE9PSBkZXBlbmRlbmN5LmNvbnRlbnRIYXNoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogW3sgY29kZTogJ1ZBTElEQVRJT05fRkFJTEVEJywgbWVzc2FnZTogJ+S/neWtmOeJiOOBruWGheWuuWhhc2jjgYzkuIDoh7TjgZfjgarjgYTjgZ/jgoHlh7rlipvjgpLlgZzmraLjgZfjgb7jgZfjgZ/jgIInLCBlbnRpdHlJZDogZGVwZW5kZW5jeS5pZCB9XSB9O1xuICAgIGRlcGVuZGVuY2llcy5wdXNoKGRlcGVuZGVuY3kpO1xuICAgIGZvciAoY29uc3QgZW50aXR5IG9mIGRlcGVuZGVuY3kuY29udGVudC5lbnRpdGllcykgZm9yIChjb25zdCByZWZlcmVuY2Ugb2YgY29sbGVjdFJlZmVyZW5jZXMoZW50aXR5KSkgaWYgKHJlZmVyZW5jZS5zY29wZSA9PT0gJ3NuYXBzaG90Jykge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gcHJvamVjdC5zbmFwc2hvdHMuZmluZChjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmlkID09PSByZWZlcmVuY2UuaWQpO1xuICAgICAgaWYgKHRhcmdldCAmJiAhdmlzaXRlZC5oYXModGFyZ2V0LmlkKSkgcGVuZGluZy5wdXNoKHRhcmdldCk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7IG9rOiB0cnVlLCBwcm9qZWN0OiB7IC4uLnN0cnVjdHVyZWRDbG9uZShzbmFwc2hvdC5jb250ZW50KSwgc25hcHNob3RzOiBkZXBlbmRlbmNpZXMsIGhpc3Rvcnk6IFtdIH0gfTtcbn1cblxuLyoqIFJlc29sdmUgZml4ZWQgcGlucyBpbiBhbiBvdXRwdXQgdmlldywgd2l0aG91dCBjb3B5aW5nIGJvcnJvd2VkIGRhdGEgaW50byB0aGUgYXV0aG9yJ3MgY2Fub25pY2FsIGRvY3VtZW50LiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGlvbkV4cG9ydFZpZXcoY2FwdHVyZWQ6UHJvamVjdERhdGEsc2VsZWN0ZWQ6UHJvamVjdERhdGEsb3B0aW9uczpFeHBvcnRPcHRpb25zKTpQcm9taXNlPFByb2plY3REYXRhPntcbiBjb25zdCBlZGl0aW9uPWF3YWl0IGNhcHR1cmVSdW50aW1lQ29udGVudChjYXB0dXJlZCxvcHRpb25zLnRhcmdldFZlcnNpb25JZD8/Y2FwdHVyZWQucHJvamVjdElkLHt3b3JsZFNuYXBzaG90czpvcHRpb25zLndvcmxkU25hcHNob3RzPz97fX0pLHZpZXc9cmVzb2x2ZVJldXNlQ29udGVudChlZGl0aW9uLGVkaXRpb24uc25hcHNob3RzKTtcbiBmdW5jdGlvbiBub3JtYWxpemUodmFsdWU6dW5rbm93bixlbnRpdHlJZDpJRCxwYXRoOnN0cmluZ1tdPVtdKTp1bmtub3due1xuICBjb25zdCBvcmlnaW49cmV1c2VPcmlnaW4odmlldyxlbnRpdHlJZCk7aWYoQXJyYXkuaXNBcnJheSh2YWx1ZSkpcmV0dXJuIHZhbHVlLm1hcCgoaXRlbSxpbmRleCk9Pm5vcm1hbGl6ZShpdGVtLGVudGl0eUlkLFsuLi5wYXRoLFN0cmluZyhpbmRleCldKSk7aWYoIXZhbHVlfHx0eXBlb2YgdmFsdWUhPT0nb2JqZWN0JylyZXR1cm4gdmFsdWU7XG4gIGNvbnN0IG9iamVjdD12YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLHVua25vd24+LGVkaXRpb25JZD1vcHRpb25zLnRhcmdldFZlcnNpb25JZD8/dmlldy5wcm9qZWN0SWQ7XG4gIC8vIEFuIGV4cGxpY2l0IHJpY2gtdGV4dCBjaXRhdGlvbiByZXRhaW5zIHRoZSBvcmlnaW5hbCBlZGl0aW9uIGFuZCBpdHMgb3JpZ2luYWwgSURzLlxuICBpZihwYXRoLmluY2x1ZGVzKCdsaW5rcycpJiZwYXRoLmF0KC0xKT09PSd0YXJnZXQnJiZ0eXBlb2Ygb2JqZWN0LnNvdXJjZVZlcnNpb25JZD09PSdzdHJpbmcnKXJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUob2JqZWN0KTtcbiAgY29uc3QgbWFwcGVkPU9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhvYmplY3QpLmZpbHRlcigoW2tleV0pPT5rZXkhPT0ncmV1c2UnKS5tYXAoKFtrZXksaXRlbV0pPT5ba2V5LG9yaWdpbiYmWydzb3VyY2VWZXJzaW9uSWQnLCd0YXJnZXRTbmFwc2hvdElkJ10uaW5jbHVkZXMoa2V5KSYmaXRlbT09PW9yaWdpbi5zb3VyY2VWZXJzaW9uSWQ/ZWRpdGlvbklkOm5vcm1hbGl6ZShpdGVtLGVudGl0eUlkLFsuLi5wYXRoLGtleV0pXSkpO1xuICBpZihvcmlnaW4mJnR5cGVvZiBvYmplY3QuZW50aXR5SWQ9PT0nc3RyaW5nJyYmb2JqZWN0LnNvdXJjZVZlcnNpb25JZD09PW9yaWdpbi5zb3VyY2VWZXJzaW9uSWQpZm9yKGNvbnN0IGtleSBvZiBbJ2VudGl0eUlkJywnYmxvY2tJZCcsJ2xpbmVJZCddKWlmKHR5cGVvZiBvYmplY3Rba2V5XT09PSdzdHJpbmcnKW1hcHBlZFtrZXldPW9yaWdpbi5iaW5kaW5nc1tvYmplY3Rba2V5XSBhcyBzdHJpbmddPz9vYmplY3Rba2V5XTtcbiAgcmV0dXJuIG1hcHBlZDtcbiB9XG5cbiBjb25zdCB3b3JsZHM9cmVzb2x2ZVBpbm5lZFdvcmxkcyh2aWV3LG9wdGlvbnMud29ybGRTbmFwc2hvdHM/P3t9KS53b3JsZHMsZW50aXRpZXM9dmlldy5lbnRpdGllcy5tYXAoZW50aXR5PT4oey4uLmVudGl0eSxkYXRhOm5vcm1hbGl6ZShlbnRpdHkuZGF0YSxlbnRpdHkuaWQpfSBhcyBFbnRpdHkpKSxpZHM9bmV3IFNldChlbnRpdGllcy5tYXAoZT0+ZS5pZCkpLHJlbGF0aW9ucz1bLi4udmlldy5yZWxhdGlvbnNdLHJlbGF0aW9uSWRzPW5ldyBTZXQocmVsYXRpb25zLm1hcChyPT5yLmlkKSksY2FsZW5kYXJzPVsuLi52aWV3LmNhbGVuZGFyc107XG4gZm9yKGNvbnN0IHdvcmxkIG9mIHdvcmxkcyl7Zm9yKGNvbnN0IGVudGl0eSBvZiB3b3JsZC5lbnRpdGllcyl7aWYoaWRzLmhhcyhlbnRpdHkuaWQpKXRocm93IEVycm9yKCdSRUZFUkVOQ0VfSU5WQUxJRDog5Zu65a6a5LiW55WM44Go5Ye65Yqb5YWD44GuSUTjgYzooZ3nqoHjgZfjgabjgYTjgb7jgZnjgIInKTtpZHMuYWRkKGVudGl0eS5pZCk7ZW50aXRpZXMucHVzaCh7Li4uc3RydWN0dXJlZENsb25lKGVudGl0eSkscHJvamVjdElkOnZpZXcucHJvamVjdElkfSk7fWZvcihjb25zdCByZWxhdGlvbiBvZiB3b3JsZC5yZWxhdGlvbnMpe2lmKHJlbGF0aW9uSWRzLmhhcyhyZWxhdGlvbi5pZCkpdGhyb3cgRXJyb3IoJ1JFRkVSRU5DRV9JTlZBTElEOiDlm7rlrprkuJbnlYzjga7plqLkv4JJROOBjOihneeqgeOBl+OBpuOBhOOBvuOBmeOAgicpO3JlbGF0aW9uSWRzLmFkZChyZWxhdGlvbi5pZCk7cmVsYXRpb25zLnB1c2goey4uLnN0cnVjdHVyZWRDbG9uZShyZWxhdGlvbikscHJvamVjdElkOnZpZXcucHJvamVjdElkfSk7fWZvcihjb25zdCBjYWxlbmRhciBvZiB3b3JsZC5jYWxlbmRhcnMpaWYoIWNhbGVuZGFycy5zb21lKGM9PmMuaWQ9PT1jYWxlbmRhci5pZCkpY2FsZW5kYXJzLnB1c2goc3RydWN0dXJlZENsb25lKGNhbGVuZGFyKSk7fVxuIGNvbnN0IHBvbGljeT1lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1vcHRpb25zLnByb2plY3Rpb25Qcm9maWxlSWQpO2lmKCFwb2xpY3kmJm9wdGlvbnMudGFyZ2V0VmVyc2lvbklkKXtjb25zdCBhcHByb3ZlZD1jYXB0dXJlZC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1vcHRpb25zLnByb2plY3Rpb25Qcm9maWxlSWQmJmUua2luZD09PSdwcm9qZWN0aW9uX3Byb2ZpbGUnJiZlLmRhdGEuc291cmNlVmVyc2lvbklkPT09b3B0aW9ucy50YXJnZXRWZXJzaW9uSWQpO2lmKGFwcHJvdmVkKWVudGl0aWVzLnB1c2goc3RydWN0dXJlZENsb25lKGFwcHJvdmVkKSk7fVxuIHJldHVybiB7Li4uc2VsZWN0ZWQsZW50aXRpZXMscmVsYXRpb25zLGNhbGVuZGFyc307XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVQdWJsaWNQb3NpdGlvbnMocHJvamVjdGlvbjpQdWJsaWNQcm9qZWN0aW9uKTpQcm9qZWN0aW9uSXNzdWVbXXtcbiBjb25zdCBlZGl0aW9ucz1uZXcgTWFwKFtbJ3B1YmxpYy1wcm9qZWN0Jyxwcm9qZWN0aW9uXSwuLi4ocHJvamVjdGlvbi52ZXJzaW9ucz8/W10pLm1hcCh2ZXJzaW9uPT5bdmVyc2lvbi5pZCx2ZXJzaW9uLnByb2plY3Rpb25dIGFzIFtzdHJpbmcsUHVibGljUHJvamVjdGlvbl0pXSksaXNzdWVzOlByb2plY3Rpb25Jc3N1ZVtdPVtdO1xuIGZvcihjb25zdCBbdmVyc2lvbixlZGl0aW9uXW9mIGVkaXRpb25zKXtcbiAgY29uc3QgaW5zcGVjdD0odmFsdWU6dW5rbm93bik9PntpZihBcnJheS5pc0FycmF5KHZhbHVlKSl7dmFsdWUuZm9yRWFjaChpbnNwZWN0KTtyZXR1cm47fWlmKCF2YWx1ZXx8dHlwZW9mIHZhbHVlIT09J29iamVjdCcpcmV0dXJuO2NvbnN0IG9iamVjdD12YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLHVua25vd24+LGVudGl0eUlkPW9iamVjdC5lbnRpdHlJZD8/b2JqZWN0LnRhcmdldElkLHN0YXJ0PW9iamVjdC50YXJnZXRJZD9vYmplY3QudGFyZ2V0U3RhcnQ6b2JqZWN0LnN0YXJ0LGVuZD1vYmplY3QudGFyZ2V0SWQ/b2JqZWN0LnRhcmdldEVuZDpvYmplY3QuZW5kO1xuICAgaWYodHlwZW9mIGVudGl0eUlkPT09J3N0cmluZycmJihvYmplY3QuYmxvY2tJZCE9bnVsbHx8b2JqZWN0LmxpbmVJZCE9bnVsbHx8c3RhcnQhPW51bGx8fGVuZCE9bnVsbCkpe1xuICAgIGNvbnN0IHRhcmdldD1lZGl0aW9ucy5nZXQodHlwZW9mIG9iamVjdC5zb3VyY2VWZXJzaW9uSWQ9PT0nc3RyaW5nJz9vYmplY3Quc291cmNlVmVyc2lvbklkOnZlcnNpb24pLHJlY29yZD10YXJnZXQ/LmVudGl0aWVzLmZpbmQoZW50aXR5PT5lbnRpdHkuaWQ9PT1lbnRpdHlJZCksbGluZT10eXBlb2Ygb2JqZWN0LmxpbmVJZD09PSdzdHJpbmcnP3RhcmdldD8uZW50aXRpZXMuZmluZChlbnRpdHk9PmVudGl0eS5pZD09PW9iamVjdC5saW5lSWQmJmVudGl0eS5raW5kPT09J2RpYWxvZ3VlX2xpbmUnKTp1bmRlZmluZWQsYmxvY2s9dHlwZW9mIG9iamVjdC5ibG9ja0lkPT09J3N0cmluZyc/cmVjb3JkJiZlbnRpdHlEb2N1bWVudHMocmVjb3JkKS5mbGF0TWFwKChbLGRvY3VtZW50XSk9PmRvY3VtZW50KS5maW5kKGJsb2NrPT5ibG9jay5pZD09PW9iamVjdC5ibG9ja0lkKTp1bmRlZmluZWQsdGV4dD1ibG9jaz8udGV4dD8/KGxpbmU/YmxvY2tzKGxpbmUuZGF0YS50ZXh0KS5tYXAoYmxvY2s9PmJsb2NrLnRleHQpLmpvaW4oJ1xcbicpOnVuZGVmaW5lZCk7XG4gICAgY29uc3QgbWlzc2luZz0hcmVjb3JkfHxvYmplY3QuYmxvY2tJZCE9bnVsbCYmIWJsb2NrfHxvYmplY3QubGluZUlkIT1udWxsJiYhbGluZSxoYXNSYW5nZT1zdGFydCE9bnVsbHx8ZW5kIT1udWxsLGludmFsaWRSYW5nZT1oYXNSYW5nZSYmKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihzdGFydCl8fCFOdW1iZXIuaXNTYWZlSW50ZWdlcihlbmQpfHxOdW1iZXIoc3RhcnQpPDB8fE51bWJlcihlbmQpPE51bWJlcihzdGFydCl8fHRleHQ9PT11bmRlZmluZWR8fE51bWJlcihlbmQpPlsuLi50ZXh0XS5sZW5ndGgpO1xuICAgIGlmKG1pc3Npbmd8fGludmFsaWRSYW5nZSlpc3N1ZXMucHVzaCh7Y29kZTonUkVGRVJFTkNFX0lOVkFMSUQnLG1lc3NhZ2U6J+WFrOmWi+OBl+OBn+WbuuWumueJiOOBruacrOaWh+S9jee9ruOCkueiuuiqjeOBp+OBjeOBvuOBm+OCk+OAguWFrOmWi+aWh+OBqOaWh+Wtl+evhOWbsuOCkuWGjeeiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicsZW50aXR5SWR9KTtcbiAgIH1cbiAgIE9iamVjdC52YWx1ZXMob2JqZWN0KS5mb3JFYWNoKGluc3BlY3QpO1xuICB9O2VkaXRpb24uZW50aXRpZXMuZm9yRWFjaChlbnRpdHk9Pmluc3BlY3QoZW50aXR5LmRhdGEpKTtcbiB9XG4gcmV0dXJuIGlzc3Vlcztcbn1cbi8qKiBFYWNoIGhpc3RvcmljYWwgY2l0YXRpb24gaGFzIGl0cyBvd24gYXBwcm92ZWQgcG9saWN5IGFuZCBpbW11dGFibGUgYnl0ZXMuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGFyZUV4cG9ydENpdGF0aW9ucyhjYXB0dXJlZDpQcm9qZWN0RGF0YSxzZWxlY3RlZDpQcm9qZWN0RGF0YSxvcHRpb25zOkV4cG9ydE9wdGlvbnMsc3RyaWN0UmVmZXJlbmNlczpib29sZWFuKXtcbiB0eXBlIEFwcHJvdmVkPXtwdWJsaWNWZXJzaW9uSWQ6c3RyaW5nO2lkTWFwOlJlY29yZDxzdHJpbmcsc3RyaW5nPn07XG4gY29uc3QgdGFyZ2V0czpSZWNvcmQ8c3RyaW5nLEFwcHJvdmVkPj17fSx2ZXJzaW9uczp7aWQ6c3RyaW5nO3Byb2plY3Rpb246UHVibGljUHJvamVjdGlvbn1bXT1bXSxzb3VyY2VzOkNpdGF0aW9uU291cmNlW109W10sYWN0aXZlPW5ldyBTZXQ8c3RyaW5nPigpLG93bmVycz1uZXcgTWFwPHN0cmluZyxzdHJpbmc+KCkscHVibGljT3duZXJzPW5ldyBNYXA8c3RyaW5nLHN0cmluZz4oKTtcbiBhc3luYyBmdW5jdGlvbiB2aXNpdChlZGl0aW9uOlByb2plY3REYXRhLHByb2ZpbGVJZDpzdHJpbmcsZGVwdGg6bnVtYmVyKXtcbiAgaWYoZGVwdGg+NjQpdGhyb3cgRXJyb3IoJ0lNUE9SVF9MSU1JVDog5byV55So5Zu65a6a54mI44Gu5L6d5a2Y44GMNjTmrrXpmo7jgpLotoXjgYjjgabjgYTjgb7jgZnjgIInKTtcbiAgY29uc3QgcG9saWN5PWVkaXRpb24uZW50aXRpZXMuZmluZCgoZW50aXR5KTplbnRpdHkgaXMgRW50aXR5PCdwcm9qZWN0aW9uX3Byb2ZpbGUnPj0+ZW50aXR5LmlkPT09cHJvZmlsZUlkJiZlbnRpdHkua2luZD09PSdwcm9qZWN0aW9uX3Byb2ZpbGUnJiZlbnRpdHkuc3RhdHVzPT09J2NvbmZpcm1lZCcmJiFlbnRpdHkuZGVsZXRlZEF0KTtpZighcG9saWN5KXRocm93IEVycm9yKCdSRUZFUkVOQ0VfSU5WQUxJRDog5byV55So5Zu65a6a54mI44Gu5YWs6ZaL56+E5Zuy44GM5pyq56K66KqN44Gn44GZ44CCJyk7XG4gIGZvcihjb25zdCBkZWNsYXJhdGlvbiBvZiBwb2xpY3kuZGF0YS5jaXRlZFZlcnNpb25zPz9bXSl7XG4gICBjb25zdCBpZD1kZWNsYXJhdGlvbi5zb3VyY2VWZXJzaW9uSWQscHJpb3I9dGFyZ2V0c1tpZF07aWYoYWN0aXZlLmhhcyhpZCkpdGhyb3cgRXJyb3IoJ1JFRkVSRU5DRV9JTlZBTElEOiDlvJXnlKjlm7rlrprniYjjga7lhazplovkvp3lrZjjgYzlvqrnkrDjgZfjgabjgYTjgb7jgZnjgIInKTtcbiAgIGlmKHByaW9yKXtpZihwcmlvci5wdWJsaWNWZXJzaW9uSWQhPT1kZWNsYXJhdGlvbi5wdWJsaWNWZXJzaW9uSWR8fG93bmVycy5nZXQoaWQpIT09ZGVjbGFyYXRpb24ucHJvZmlsZUlkKXRocm93IEVycm9yKCdSRUZFUkVOQ0VfSU5WQUxJRDog5ZCM44GY5byV55So54mI44Gr55Ww44Gq44KL5YWs6ZaL56+E5Zuy44GM5oyH5a6a44GV44KM44Gm44GE44G+44GZ44CCJyk7Y29udGludWU7fVxuICAgaWYodmVyc2lvbnMubGVuZ3RoK2FjdGl2ZS5zaXplPj0xMjh8fHB1YmxpY093bmVycy5oYXMoZGVjbGFyYXRpb24ucHVibGljVmVyc2lvbklkKXx8IWRlY2xhcmF0aW9uLnB1YmxpY1ZlcnNpb25JZCl0aHJvdyBFcnJvcignSU1QT1JUX0xJTUlUOiDlvJXnlKjlm7rlrprniYjjga7kuIrpmZDjgb7jgZ/jga/lhazplovniYhJROOBjOS4jeato+OBp+OBmeOAgicpO1xuICAgcHVibGljT3duZXJzLnNldChkZWNsYXJhdGlvbi5wdWJsaWNWZXJzaW9uSWQsaWQpO1xuICAgYWN0aXZlLmFkZChpZCk7Y29uc3Qgb3duPWNhcHR1cmVkLnNuYXBzaG90cy5maW5kKHBpbj0+cGluLmlkPT09aWQpLHdvcmxkPShvcHRpb25zLndvcmxkUGlucz8/W10pLmZpbmQocGluPT5waW4uaWQ9PT1pZCkscGluPW93bj8/d29ybGQscmVnaXN0cnk9b3B0aW9ucy53b3JsZFNuYXBzaG90cz8/e307XG4gICBpZighcGlufHxhd2FpdCBzaGEyNTYoanNvbkJ5dGVzKHBpbi5jb250ZW50KSkhPT1waW4uY29udGVudEhhc2h8fHdvcmxkJiYoIXJlZ2lzdHJ5W2lkXXx8YXdhaXQgc2hhMjU2KGpzb25CeXRlcyhyZWdpc3RyeVtpZF0pKSE9PXBpbi5jb250ZW50SGFzaCkpdGhyb3cgRXJyb3IoJ0lOVEVHUklUWV9GQUlMRUQ6IOW8leeUqOeJiOOBruacn+W+hWhhc2jjgb7jgZ/jga/lhoXlrrnjgYzkuIDoh7TjgZfjgb7jgZvjgpPjgIInKTtcbiAgIGNvbnN0IGxpYnJhcnk9cGluLmNvbnRlbnQucHJvamVjdElkPT09Y2FwdHVyZWQucHJvamVjdElkP2NhcHR1cmVkLnNuYXBzaG90czpbLi4uKG9wdGlvbnMud29ybGRQaW5zPz9bXSkuZmlsdGVyKGl0ZW09Pml0ZW0uY29udGVudC5wcm9qZWN0SWQ9PT1waW4uY29udGVudC5wcm9qZWN0SWQpLm1hcChpdGVtPT4oey4uLml0ZW0sY3JlYXRlZEF0OicxOTcwLTAxLTAxVDAwOjAwOjAwLjAwMFonLHZlcnNpb25MYWJlbDon5byV55So44GZ44KL5Zu65a6a5LiW55WMJ30pKV07XG4gICBjb25zdCBvcmlnaW5hbD17Li4uc3RydWN0dXJlZENsb25lKHBpbi5jb250ZW50KSxzbmFwc2hvdHM6c3RydWN0dXJlZENsb25lKGxpYnJhcnkpLGhpc3Rvcnk6W119LGluc2lkZT1vcmlnaW5hbC5lbnRpdGllcy5maW5kKGVudGl0eT0+ZW50aXR5LmlkPT09ZGVjbGFyYXRpb24ucHJvZmlsZUlkJiZlbnRpdHkua2luZD09PSdwcm9qZWN0aW9uX3Byb2ZpbGUnKSxvdXRzaWRlPWNhcHR1cmVkLmVudGl0aWVzLmZpbmQoKGVudGl0eSk6ZW50aXR5IGlzIEVudGl0eTwncHJvamVjdGlvbl9wcm9maWxlJz49PmVudGl0eS5pZD09PWRlY2xhcmF0aW9uLnByb2ZpbGVJZCYmZW50aXR5LmtpbmQ9PT0ncHJvamVjdGlvbl9wcm9maWxlJyYmZW50aXR5LmRhdGEuc291cmNlVmVyc2lvbklkPT09aWQpO1xuICAgaWYoIWluc2lkZSYmIW91dHNpZGUpdGhyb3cgRXJyb3IoJ1JFRkVSRU5DRV9JTlZBTElEOiDlvJXnlKjlr77osaHniYjjga7lhazplovmlofjgpLnorroqo3jgZfjgZ/nr4Tlm7LjgYzjgYLjgorjgb7jgZvjgpPjgIInKTtcbiAgIGNvbnN0IHZpZXc9YXdhaXQgZXhlY3V0aW9uRXhwb3J0VmlldyhvcmlnaW5hbCxvcmlnaW5hbCx7Li4ub3B0aW9ucyxwcm9qZWN0aW9uUHJvZmlsZUlkOmRlY2xhcmF0aW9uLnByb2ZpbGVJZCx0YXJnZXRWZXJzaW9uSWQ6aWQsdGFyZ2V0UmV2aXNpb246dW5kZWZpbmVkfSk7XG4gICBpZighaW5zaWRlJiZvdXRzaWRlKXZpZXcuZW50aXRpZXMucHVzaCh7Li4uc3RydWN0dXJlZENsb25lKG91dHNpZGUpLHByb2plY3RJZDp2aWV3LnByb2plY3RJZH0pO1xuICAgYXdhaXQgdmlzaXQodmlldyxkZWNsYXJhdGlvbi5wcm9maWxlSWQsZGVwdGgrMSk7XG4gICBjb25zdCByZXN1bHQ9Y3JlYXRlUHJvamVjdGlvbih2aWV3LGRlY2xhcmF0aW9uLnByb2ZpbGVJZCx7c3RyaWN0UmVmZXJlbmNlcyxjb25maXJtZWRPbmx5OnRydWUsdGFyZ2V0VmVyc2lvbklkOmlkLHZlcnNpb25UYXJnZXRzOnRhcmdldHN9KTtpZighcmVzdWx0Lm9rKXRocm93IE9iamVjdC5hc3NpZ24oRXJyb3IoJ0VYUE9SVF9VTlNVUFBPUlRFRDog5byV55So54mI44Gu5YWs6ZaL5ZCN44O75pys5paH44O75b+F6KaB5Y+C54Wn44GM5pyq56K66KqN44Gn44GZ44CCJykse2lzc3VlczpyZXN1bHQuaXNzdWVzfSk7XG4gICB0YXJnZXRzW2lkXT17cHVibGljVmVyc2lvbklkOmRlY2xhcmF0aW9uLnB1YmxpY1ZlcnNpb25JZCxpZE1hcDpyZXN1bHQuaWRNYXB9O293bmVycy5zZXQoaWQsZGVjbGFyYXRpb24ucHJvZmlsZUlkKTt2ZXJzaW9ucy5wdXNoKHtpZDpkZWNsYXJhdGlvbi5wdWJsaWNWZXJzaW9uSWQscHJvamVjdGlvbjpyZXN1bHQucHJvamVjdGlvbn0pO3NvdXJjZXMucHVzaCh7cHVibGljVmVyc2lvbklkOmRlY2xhcmF0aW9uLnB1YmxpY1ZlcnNpb25JZCxwcm9maWxlSWQ6ZGVjbGFyYXRpb24ucHJvZmlsZUlkLHByb2plY3Q6dmlldyxwcm9qZWN0aW9uOnJlc3VsdC5wcm9qZWN0aW9uLGlkTWFwOnJlc3VsdC5pZE1hcH0pO2FjdGl2ZS5kZWxldGUoaWQpO1xuICB9XG4gfVxuIGF3YWl0IHZpc2l0KHNlbGVjdGVkLG9wdGlvbnMucHJvamVjdGlvblByb2ZpbGVJZCwwKTtyZXR1cm4ge3RhcmdldHMsdmVyc2lvbnMsc291cmNlc307XG59XG5cbi8qKiBTaGFyZWQgcHJlcGFyYXRpb24gY29udGFpbnMgbm8gYnJvd3NlciBidW5kbGUgb3IgYXNzZXQgYnl0ZXMuIFN0b3JlZCBldmlkZW5jZSByZXVzZXMgdGhlIGV4YWN0IHB1YmxpY2F0aW9uIHJ1bGVzLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBhcmVQdWJsaWNFeGVjdXRpb24oaW5wdXQ6UHJvamVjdERhdGEsaW5wdXRPcHRpb25zOkV4cG9ydE9wdGlvbnMpe1xuIGNvbnN0IGNhcHR1cmVkPXN0cnVjdHVyZWRDbG9uZShpbnB1dCksb3B0aW9ucz1zdHJ1Y3R1cmVkQ2xvbmUoaW5wdXRPcHRpb25zKSxzZWxlY3RlZD1hd2FpdCBzZWxlY3RFeHBvcnRTb3VyY2UoY2FwdHVyZWQsb3B0aW9ucyk7XG4gaWYoIXNlbGVjdGVkLm9rKXRocm93IE9iamVjdC5hc3NpZ24oRXJyb3IoJ1JFRkVSRU5DRV9JTlZBTElEOiDlh7rlipvlr77osaHniYjjgpLnorroqo3jgafjgY3jgb7jgZvjgpPjgIInKSx7aXNzdWVzOnNlbGVjdGVkLmlzc3Vlc30pO1xuIGNvbnN0IGNoZWNrZWQ9dmFsaWRhdGVQcm9qZWN0KHNlbGVjdGVkLnByb2plY3Qse3dvcmxkU25hcHNob3RzOm9wdGlvbnMud29ybGRTbmFwc2hvdHM/P3t9fSk7aWYoIWNoZWNrZWQub2spdGhyb3cgT2JqZWN0LmFzc2lnbihFcnJvcignUkVGRVJFTkNFX0lOVkFMSUQ6IOWHuuWKm+WvvuixoeeJiOOBruWPgueFp+OBjOS4jeato+OBp+OBmeOAgicpLHtpc3N1ZXM6Y2hlY2tlZC5pc3N1ZXN9KTtcbiBjb25zdCBwcm9qZWN0PWF3YWl0IGV4ZWN1dGlvbkV4cG9ydFZpZXcoY2FwdHVyZWQsc2VsZWN0ZWQucHJvamVjdCxvcHRpb25zKSxjaXRhdGlvbnM9YXdhaXQgcHJlcGFyZUV4cG9ydENpdGF0aW9ucyhjYXB0dXJlZCxwcm9qZWN0LG9wdGlvbnMsdHJ1ZSkscmVzdWx0PWNyZWF0ZVByb2plY3Rpb24ocHJvamVjdCxvcHRpb25zLnByb2plY3Rpb25Qcm9maWxlSWQse3N0cmljdFJlZmVyZW5jZXM6dHJ1ZSxjb25maXJtZWRPbmx5OnRydWUsdGFyZ2V0VmVyc2lvbklkOm9wdGlvbnMudGFyZ2V0VmVyc2lvbklkLHZlcnNpb25UYXJnZXRzOmNpdGF0aW9ucy50YXJnZXRzfSk7XG4gaWYoIXJlc3VsdC5vayl0aHJvdyBPYmplY3QuYXNzaWduKEVycm9yKCdFWFBPUlRfVU5TVVBQT1JURUQ6IOWbuuWumuOBl+OBn+WFrOmWi+evhOWbsuOCkuWGjeani+aIkOOBp+OBjeOBvuOBm+OCk+OAgicpLHtpc3N1ZXM6cmVzdWx0Lmlzc3Vlc30pO1xuIGlmKGNpdGF0aW9ucy52ZXJzaW9ucy5sZW5ndGgpcmVzdWx0LnByb2plY3Rpb24udmVyc2lvbnM9Y2l0YXRpb25zLnZlcnNpb25zO1xuIGNvbnN0IHBvc2l0aW9ucz12YWxpZGF0ZVB1YmxpY1Bvc2l0aW9ucyhyZXN1bHQucHJvamVjdGlvbik7aWYocG9zaXRpb25zLmxlbmd0aCl0aHJvdyBPYmplY3QuYXNzaWduKEVycm9yKCdSRUZFUkVOQ0VfSU5WQUxJRDog5Zu65a6a44GX44Gf5YWs6ZaL5pys5paH5L2N572u44GM5LiN5q2j44Gn44GZ44CCJykse2lzc3Vlczpwb3NpdGlvbnN9KTtcbiByZXR1cm4ge3Byb2plY3QscHJvamVjdGlvbjpyZXN1bHQucHJvamVjdGlvbixpZE1hcDpyZXN1bHQuaWRNYXAsY2l0YXRpb25zfTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBRUEsU0FBU0EscUJBQXFCLFFBQVEsbUJBQW1CO0FBQ3pELFNBQVNDLG1CQUFtQixFQUFFQyxXQUFXLFFBQVEsU0FBUztBQUMxRCxTQUFTQyxtQkFBbUIsUUFBUSxnQkFBZ0I7QUFDcEQsU0FBU0MsTUFBTSxFQUFFQyxTQUFTLFFBQVEsaUJBQWlCO0FBQ25ELFNBQVNDLGlCQUFpQixFQUFFQyxlQUFlLFFBQVEsU0FBUztBQUM1RCxTQUFTQyxnQkFBZ0IsUUFBUSxjQUFjO0FBRS9DLE1BQU1DLGVBQWUsR0FBQyxxQkFBcUI7QUFDM0MsTUFBTUMsSUFBSSxHQUFFQyxLQUFhLElBQUdQLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDTSxLQUFLLENBQUMsQ0FBQztBQUVwRCxTQUFTQyxNQUFNQSxDQUFDRCxLQUEyQixFQUFrQjtFQUFDLE9BQU9FLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSCxLQUFLLENBQUMsR0FBQ0EsS0FBSyxHQUFnQyxFQUFFO0FBQUM7QUFDbEksU0FBU0ksZUFBZUEsQ0FBQ0MsTUFBc0IsRUFBNkI7RUFBQyxPQUFPLENBQUMsTUFBTSxFQUFDLE1BQU0sRUFBQyxTQUFTLEVBQUMsYUFBYSxFQUFDLFlBQVksRUFBQyxTQUFTLEVBQUMsUUFBUSxFQUFDLFVBQVUsRUFBQyxnQkFBZ0IsRUFBQyxnQkFBZ0IsRUFBQyxZQUFZLEVBQUMsT0FBTyxFQUFDLE1BQU0sRUFBQyxPQUFPLENBQUMsQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLElBQUVOLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDRyxJQUFJLENBQUNELEtBQUssQ0FBQyxDQUFDLENBQUNFLE1BQU0sQ0FBQyxDQUFDQyxHQUFHLENBQUNILEtBQUssSUFBRSxDQUFDQSxLQUFLLEVBQUNOLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDRyxJQUFJLENBQUNELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUFDO0FBQzdVLE9BQU8sZUFBZUksa0JBQWtCQSxDQUFDQyxPQUFvQixFQUFFQyxPQUFzQixFQUEwRjtFQUM3SyxJQUFLQSxPQUFPLENBQUNDLGNBQWMsS0FBS0MsU0FBUyxNQUFPRixPQUFPLENBQUNHLGVBQWUsS0FBS0QsU0FBUyxDQUFDLEVBQUUsT0FBTztJQUFFRSxFQUFFLEVBQUUsS0FBSztJQUFFQyxNQUFNLEVBQUUsQ0FBQztNQUFFQyxJQUFJLEVBQUUsbUJBQW1CO01BQUVDLE9BQU8sRUFBRTtJQUF1QixDQUFDO0VBQUUsQ0FBQztFQUN0TCxJQUFJUCxPQUFPLENBQUNDLGNBQWMsS0FBS0MsU0FBUyxFQUFFO0lBQ3hDLElBQUksQ0FBQ2pCLGVBQWUsQ0FBQ3VCLElBQUksQ0FBQ1IsT0FBTyxDQUFDQyxjQUFjLENBQUMsSUFBSUQsT0FBTyxDQUFDQyxjQUFjLEtBQUtGLE9BQU8sQ0FBQ1UsUUFBUSxFQUFFLE9BQU87TUFBRUwsRUFBRSxFQUFFLEtBQUs7TUFBRUMsTUFBTSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFLG1CQUFtQjtRQUFFQyxPQUFPLEVBQUU7TUFBb0MsQ0FBQztJQUFFLENBQUM7SUFDN00sT0FBTztNQUFFSCxFQUFFLEVBQUUsSUFBSTtNQUFFTDtJQUFRLENBQUM7RUFDOUI7RUFDQSxNQUFNVyxRQUFRLEdBQUdYLE9BQU8sQ0FBQ1ksU0FBUyxDQUFDQyxJQUFJLENBQUNGLFFBQVEsSUFBSUEsUUFBUSxDQUFDRyxFQUFFLEtBQUtiLE9BQU8sQ0FBQ0csZUFBZSxDQUFDO0VBQzVGLElBQUksQ0FBQ08sUUFBUSxJQUFJQSxRQUFRLENBQUNJLE9BQU8sQ0FBQ0MsU0FBUyxLQUFLaEIsT0FBTyxDQUFDZ0IsU0FBUyxFQUFFLE9BQU87SUFBRVgsRUFBRSxFQUFFLEtBQUs7SUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFLG1CQUFtQjtNQUFFQyxPQUFPLEVBQUUsdUJBQXVCO01BQUVTLFFBQVEsRUFBRWhCLE9BQU8sQ0FBQ0c7SUFBZ0IsQ0FBQztFQUFFLENBQUM7RUFDck07RUFDQTtFQUNBLE1BQU1jLFlBQXNDLEdBQUcsRUFBRTtFQUNqRCxNQUFNQyxPQUFPLEdBQUcsQ0FBQ1IsUUFBUSxDQUFDO0lBQUVTLE9BQU8sR0FBRyxJQUFJQyxHQUFHLENBQUssQ0FBQztFQUNuRCxPQUFPRixPQUFPLENBQUN0QixNQUFNLEVBQUU7SUFDckIsTUFBTXlCLFVBQVUsR0FBR0gsT0FBTyxDQUFDSSxHQUFHLENBQUMsQ0FBRTtJQUNqQyxJQUFJSCxPQUFPLENBQUNJLEdBQUcsQ0FBQ0YsVUFBVSxDQUFDUixFQUFFLENBQUMsRUFBRTtJQUNoQ00sT0FBTyxDQUFDSyxHQUFHLENBQUNILFVBQVUsQ0FBQ1IsRUFBRSxDQUFDO0lBQzFCLElBQUlkLE9BQU8sQ0FBQ1ksU0FBUyxDQUFDbEIsTUFBTSxDQUFDZ0MsU0FBUyxJQUFJQSxTQUFTLENBQUNaLEVBQUUsS0FBS1EsVUFBVSxDQUFDUixFQUFFLENBQUMsQ0FBQ2pCLE1BQU0sS0FBSyxDQUFDLElBQUl5QixVQUFVLENBQUNQLE9BQU8sQ0FBQ0MsU0FBUyxLQUFLaEIsT0FBTyxDQUFDZ0IsU0FBUyxFQUFFLE9BQU87TUFBRVgsRUFBRSxFQUFFLEtBQUs7TUFBRUMsTUFBTSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFLG1CQUFtQjtRQUFFQyxPQUFPLEVBQUUsc0JBQXNCO1FBQUVTLFFBQVEsRUFBRUssVUFBVSxDQUFDUjtNQUFHLENBQUM7SUFBRSxDQUFDO0lBQ3JRLElBQUksT0FBTTNCLElBQUksQ0FBQ21DLFVBQVUsQ0FBQ1AsT0FBTyxDQUFDLE1BQUtPLFVBQVUsQ0FBQ0ssV0FBVyxFQUFFLE9BQU87TUFBRXRCLEVBQUUsRUFBRSxLQUFLO01BQUVDLE1BQU0sRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRSxtQkFBbUI7UUFBRUMsT0FBTyxFQUFFLDhCQUE4QjtRQUFFUyxRQUFRLEVBQUVLLFVBQVUsQ0FBQ1I7TUFBRyxDQUFDO0lBQUUsQ0FBQztJQUM5TEksWUFBWSxDQUFDVSxJQUFJLENBQUNOLFVBQVUsQ0FBQztJQUM3QixLQUFLLE1BQU03QixNQUFNLElBQUk2QixVQUFVLENBQUNQLE9BQU8sQ0FBQ2MsUUFBUSxFQUFFLEtBQUssTUFBTUMsU0FBUyxJQUFJL0MsaUJBQWlCLENBQUNVLE1BQU0sQ0FBQyxFQUFFLElBQUlxQyxTQUFTLENBQUNDLEtBQUssS0FBSyxVQUFVLEVBQUU7TUFDdkksTUFBTUMsTUFBTSxHQUFHaEMsT0FBTyxDQUFDWSxTQUFTLENBQUNDLElBQUksQ0FBQ2EsU0FBUyxJQUFJQSxTQUFTLENBQUNaLEVBQUUsS0FBS2dCLFNBQVMsQ0FBQ2hCLEVBQUUsQ0FBQztNQUNqRixJQUFJa0IsTUFBTSxJQUFJLENBQUNaLE9BQU8sQ0FBQ0ksR0FBRyxDQUFDUSxNQUFNLENBQUNsQixFQUFFLENBQUMsRUFBRUssT0FBTyxDQUFDUyxJQUFJLENBQUNJLE1BQU0sQ0FBQztJQUM3RDtFQUNGO0VBQ0EsT0FBTztJQUFFM0IsRUFBRSxFQUFFLElBQUk7SUFBRUwsT0FBTyxFQUFFO01BQUUsR0FBR2lDLGVBQWUsQ0FBQ3RCLFFBQVEsQ0FBQ0ksT0FBTyxDQUFDO01BQUVILFNBQVMsRUFBRU0sWUFBWTtNQUFFZ0IsT0FBTyxFQUFFO0lBQUc7RUFBRSxDQUFDO0FBQzlHOztBQUVBO0FBQ0EsT0FBTyxlQUFlQyxtQkFBbUJBLENBQUNDLFFBQW9CLEVBQUNDLFFBQW9CLEVBQUNwQyxPQUFxQixFQUFzQjtFQUFBLElBQUFxQyxxQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQTtFQUM5SCxNQUFNQyxPQUFPLEdBQUMsTUFBTWhFLHFCQUFxQixDQUFDMkQsUUFBUSxHQUFBRSxxQkFBQSxHQUFDckMsT0FBTyxDQUFDRyxlQUFlLGNBQUFrQyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFFRixRQUFRLENBQUNwQixTQUFTLEVBQUM7TUFBQzBCLGNBQWMsR0FBQUgscUJBQUEsR0FBQ3RDLE9BQU8sQ0FBQ3lDLGNBQWMsY0FBQUgscUJBQUEsY0FBQUEscUJBQUEsR0FBRSxDQUFDO0lBQUMsQ0FBQyxDQUFDO0lBQUNJLElBQUksR0FBQ2pFLG1CQUFtQixDQUFDK0QsT0FBTyxFQUFDQSxPQUFPLENBQUM3QixTQUFTLENBQUM7RUFDL0wsU0FBU2dDLFNBQVNBLENBQUN4RCxLQUFhLEVBQUM2QixRQUFXLEVBQUM0QixJQUFhLEdBQUMsRUFBRSxFQUFTO0lBQUEsSUFBQUMsc0JBQUE7SUFDckUsTUFBTUMsTUFBTSxHQUFDcEUsV0FBVyxDQUFDZ0UsSUFBSSxFQUFDMUIsUUFBUSxDQUFDO0lBQUMsSUFBRzNCLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSCxLQUFLLENBQUMsRUFBQyxPQUFPQSxLQUFLLENBQUNVLEdBQUcsQ0FBQyxDQUFDa0QsSUFBSSxFQUFDQyxLQUFLLEtBQUdMLFNBQVMsQ0FBQ0ksSUFBSSxFQUFDL0IsUUFBUSxFQUFDLENBQUMsR0FBRzRCLElBQUksRUFBQ0ssTUFBTSxDQUFDRCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxJQUFHLENBQUM3RCxLQUFLLElBQUUsT0FBT0EsS0FBSyxLQUFHLFFBQVEsRUFBQyxPQUFPQSxLQUFLO0lBQ2hNLE1BQU0rRCxNQUFNLEdBQUMvRCxLQUErQjtNQUFDZ0UsU0FBUyxJQUFBTixzQkFBQSxHQUFDN0MsT0FBTyxDQUFDRyxlQUFlLGNBQUEwQyxzQkFBQSxjQUFBQSxzQkFBQSxHQUFFSCxJQUFJLENBQUMzQixTQUFTO0lBQzlGO0lBQ0EsSUFBRzZCLElBQUksQ0FBQ1EsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFFUixJQUFJLENBQUNTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLFFBQVEsSUFBRSxPQUFPSCxNQUFNLENBQUNJLGVBQWUsS0FBRyxRQUFRLEVBQUMsT0FBT3RCLGVBQWUsQ0FBQ2tCLE1BQU0sQ0FBQztJQUMxSCxNQUFNSyxNQUFNLEdBQUNDLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ1IsTUFBTSxDQUFDLENBQUN6RCxNQUFNLENBQUMsQ0FBQyxDQUFDa0UsR0FBRyxDQUFDLEtBQUdBLEdBQUcsS0FBRyxPQUFPLENBQUMsQ0FBQzlELEdBQUcsQ0FBQyxDQUFDLENBQUM4RCxHQUFHLEVBQUNaLElBQUksQ0FBQyxLQUFHLENBQUNZLEdBQUcsRUFBQ2IsTUFBTSxJQUFFLENBQUMsaUJBQWlCLEVBQUMsa0JBQWtCLENBQUMsQ0FBQ00sUUFBUSxDQUFDTyxHQUFHLENBQUMsSUFBRVosSUFBSSxLQUFHRCxNQUFNLENBQUNRLGVBQWUsR0FBQ0gsU0FBUyxHQUFDUixTQUFTLENBQUNJLElBQUksRUFBQy9CLFFBQVEsRUFBQyxDQUFDLEdBQUc0QixJQUFJLEVBQUNlLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzVQLElBQUdiLE1BQU0sSUFBRSxPQUFPSSxNQUFNLENBQUNsQyxRQUFRLEtBQUcsUUFBUSxJQUFFa0MsTUFBTSxDQUFDSSxlQUFlLEtBQUdSLE1BQU0sQ0FBQ1EsZUFBZSxFQUFDLEtBQUksTUFBTUssR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFDLFNBQVMsRUFBQyxRQUFRLENBQUM7TUFBQSxJQUFBQyxnQkFBQTtNQUFDLElBQUcsT0FBT1YsTUFBTSxDQUFDUyxHQUFHLENBQUMsS0FBRyxRQUFRLEVBQUNKLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDLElBQUFDLGdCQUFBLEdBQUNkLE1BQU0sQ0FBQ2UsUUFBUSxDQUFDWCxNQUFNLENBQUNTLEdBQUcsQ0FBQyxDQUFXLGNBQUFDLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUVWLE1BQU0sQ0FBQ1MsR0FBRyxDQUFDO0lBQUM7SUFDaFAsT0FBT0osTUFBTTtFQUNkO0VBRUEsTUFBTU8sTUFBTSxHQUFDbkYsbUJBQW1CLENBQUMrRCxJQUFJLEdBQUFILHNCQUFBLEdBQUN2QyxPQUFPLENBQUN5QyxjQUFjLGNBQUFGLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3VCLE1BQU07SUFBQ2xDLFFBQVEsR0FBQ2MsSUFBSSxDQUFDZCxRQUFRLENBQUMvQixHQUFHLENBQUNMLE1BQU0sS0FBRztNQUFDLEdBQUdBLE1BQU07TUFBQ0csSUFBSSxFQUFDZ0QsU0FBUyxDQUFDbkQsTUFBTSxDQUFDRyxJQUFJLEVBQUNILE1BQU0sQ0FBQ3FCLEVBQUU7SUFBQyxDQUFDLENBQVcsQ0FBQztJQUFDa0QsR0FBRyxHQUFDLElBQUkzQyxHQUFHLENBQUNRLFFBQVEsQ0FBQy9CLEdBQUcsQ0FBQ21FLENBQUMsSUFBRUEsQ0FBQyxDQUFDbkQsRUFBRSxDQUFDLENBQUM7SUFBQ29ELFNBQVMsR0FBQyxDQUFDLEdBQUd2QixJQUFJLENBQUN1QixTQUFTLENBQUM7SUFBQ0MsV0FBVyxHQUFDLElBQUk5QyxHQUFHLENBQUM2QyxTQUFTLENBQUNwRSxHQUFHLENBQUNzRSxDQUFDLElBQUVBLENBQUMsQ0FBQ3RELEVBQUUsQ0FBQyxDQUFDO0lBQUN1RCxTQUFTLEdBQUMsQ0FBQyxHQUFHMUIsSUFBSSxDQUFDMEIsU0FBUyxDQUFDO0VBQ3JULEtBQUksTUFBTUMsS0FBSyxJQUFJUCxNQUFNLEVBQUM7SUFBQyxLQUFJLE1BQU10RSxNQUFNLElBQUk2RSxLQUFLLENBQUN6QyxRQUFRLEVBQUM7TUFBQyxJQUFHbUMsR0FBRyxDQUFDeEMsR0FBRyxDQUFDL0IsTUFBTSxDQUFDcUIsRUFBRSxDQUFDLEVBQUMsTUFBTXlELEtBQUssQ0FBQyx5Q0FBeUMsQ0FBQztNQUFDUCxHQUFHLENBQUN2QyxHQUFHLENBQUNoQyxNQUFNLENBQUNxQixFQUFFLENBQUM7TUFBQ2UsUUFBUSxDQUFDRCxJQUFJLENBQUM7UUFBQyxHQUFHSyxlQUFlLENBQUN4QyxNQUFNLENBQUM7UUFBQ3VCLFNBQVMsRUFBQzJCLElBQUksQ0FBQzNCO01BQVMsQ0FBQyxDQUFDO0lBQUM7SUFBQyxLQUFJLE1BQU13RCxRQUFRLElBQUlGLEtBQUssQ0FBQ0osU0FBUyxFQUFDO01BQUMsSUFBR0MsV0FBVyxDQUFDM0MsR0FBRyxDQUFDZ0QsUUFBUSxDQUFDMUQsRUFBRSxDQUFDLEVBQUMsTUFBTXlELEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQztNQUFDSixXQUFXLENBQUMxQyxHQUFHLENBQUMrQyxRQUFRLENBQUMxRCxFQUFFLENBQUM7TUFBQ29ELFNBQVMsQ0FBQ3RDLElBQUksQ0FBQztRQUFDLEdBQUdLLGVBQWUsQ0FBQ3VDLFFBQVEsQ0FBQztRQUFDeEQsU0FBUyxFQUFDMkIsSUFBSSxDQUFDM0I7TUFBUyxDQUFDLENBQUM7SUFBQztJQUFDLEtBQUksTUFBTXlELFFBQVEsSUFBSUgsS0FBSyxDQUFDRCxTQUFTLEVBQUMsSUFBRyxDQUFDQSxTQUFTLENBQUNLLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUM3RCxFQUFFLEtBQUcyRCxRQUFRLENBQUMzRCxFQUFFLENBQUMsRUFBQ3VELFNBQVMsQ0FBQ3pDLElBQUksQ0FBQ0ssZUFBZSxDQUFDd0MsUUFBUSxDQUFDLENBQUM7RUFBQztFQUNqa0IsTUFBTUcsTUFBTSxHQUFDL0MsUUFBUSxDQUFDaEIsSUFBSSxDQUFDb0QsQ0FBQyxJQUFFQSxDQUFDLENBQUNuRCxFQUFFLEtBQUdiLE9BQU8sQ0FBQzRFLG1CQUFtQixDQUFDO0VBQUMsSUFBRyxDQUFDRCxNQUFNLElBQUUzRSxPQUFPLENBQUNHLGVBQWUsRUFBQztJQUFDLE1BQU0wRSxRQUFRLEdBQUMxQyxRQUFRLENBQUNQLFFBQVEsQ0FBQ2hCLElBQUksQ0FBQ29ELENBQUMsSUFBRUEsQ0FBQyxDQUFDbkQsRUFBRSxLQUFHYixPQUFPLENBQUM0RSxtQkFBbUIsSUFBRVosQ0FBQyxDQUFDYyxJQUFJLEtBQUcsb0JBQW9CLElBQUVkLENBQUMsQ0FBQ3JFLElBQUksQ0FBQzJELGVBQWUsS0FBR3RELE9BQU8sQ0FBQ0csZUFBZSxDQUFDO0lBQUMsSUFBRzBFLFFBQVEsRUFBQ2pELFFBQVEsQ0FBQ0QsSUFBSSxDQUFDSyxlQUFlLENBQUM2QyxRQUFRLENBQUMsQ0FBQztFQUFDO0VBQzFULE9BQU87SUFBQyxHQUFHekMsUUFBUTtJQUFDUixRQUFRO0lBQUNxQyxTQUFTO0lBQUNHO0VBQVMsQ0FBQztBQUNsRDtBQUNBLE9BQU8sU0FBU1csdUJBQXVCQSxDQUFDQyxVQUEyQixFQUFtQjtFQUFBLElBQUFDLG9CQUFBO0VBQ3JGLE1BQU1DLFFBQVEsR0FBQyxJQUFJQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixFQUFDSCxVQUFVLENBQUMsRUFBQyxHQUFHLEVBQUFDLG9CQUFBLEdBQUNELFVBQVUsQ0FBQ0ksUUFBUSxjQUFBSCxvQkFBQSxjQUFBQSxvQkFBQSxHQUFFLEVBQUUsRUFBRXBGLEdBQUcsQ0FBQ3dGLE9BQU8sSUFBRSxDQUFDQSxPQUFPLENBQUN4RSxFQUFFLEVBQUN3RSxPQUFPLENBQUNMLFVBQVUsQ0FBOEIsQ0FBQyxDQUFDLENBQUM7SUFBQzNFLE1BQXdCLEdBQUMsRUFBRTtFQUMzTCxLQUFJLE1BQU0sQ0FBQ2dGLE9BQU8sRUFBQzdDLE9BQU8sQ0FBQyxJQUFHMEMsUUFBUSxFQUFDO0lBQ3RDLE1BQU1JLE9BQU8sR0FBRW5HLEtBQWEsSUFBRztNQUFBLElBQUFvRyxnQkFBQTtNQUFDLElBQUdsRyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDLEVBQUM7UUFBQ0EsS0FBSyxDQUFDcUcsT0FBTyxDQUFDRixPQUFPLENBQUM7UUFBQztNQUFPO01BQUMsSUFBRyxDQUFDbkcsS0FBSyxJQUFFLE9BQU9BLEtBQUssS0FBRyxRQUFRLEVBQUM7TUFBTyxNQUFNK0QsTUFBTSxHQUFDL0QsS0FBK0I7UUFBQzZCLFFBQVEsSUFBQXVFLGdCQUFBLEdBQUNyQyxNQUFNLENBQUNsQyxRQUFRLGNBQUF1RSxnQkFBQSxjQUFBQSxnQkFBQSxHQUFFckMsTUFBTSxDQUFDdUMsUUFBUTtRQUFDQyxLQUFLLEdBQUN4QyxNQUFNLENBQUN1QyxRQUFRLEdBQUN2QyxNQUFNLENBQUN5QyxXQUFXLEdBQUN6QyxNQUFNLENBQUN3QyxLQUFLO1FBQUNFLEdBQUcsR0FBQzFDLE1BQU0sQ0FBQ3VDLFFBQVEsR0FBQ3ZDLE1BQU0sQ0FBQzJDLFNBQVMsR0FBQzNDLE1BQU0sQ0FBQzBDLEdBQUc7TUFDN1QsSUFBRyxPQUFPNUUsUUFBUSxLQUFHLFFBQVEsS0FBR2tDLE1BQU0sQ0FBQzRDLE9BQU8sSUFBRSxJQUFJLElBQUU1QyxNQUFNLENBQUM2QyxNQUFNLElBQUUsSUFBSSxJQUFFTCxLQUFLLElBQUUsSUFBSSxJQUFFRSxHQUFHLElBQUUsSUFBSSxDQUFDLEVBQUM7UUFBQSxJQUFBSSxXQUFBO1FBQ2xHLE1BQU1qRSxNQUFNLEdBQUNtRCxRQUFRLENBQUNlLEdBQUcsQ0FBQyxPQUFPL0MsTUFBTSxDQUFDSSxlQUFlLEtBQUcsUUFBUSxHQUFDSixNQUFNLENBQUNJLGVBQWUsR0FBQytCLE9BQU8sQ0FBQztVQUFDYSxNQUFNLEdBQUNuRSxNQUFNLGFBQU5BLE1BQU0sdUJBQU5BLE1BQU0sQ0FBRUgsUUFBUSxDQUFDaEIsSUFBSSxDQUFDcEIsTUFBTSxJQUFFQSxNQUFNLENBQUNxQixFQUFFLEtBQUdHLFFBQVEsQ0FBQztVQUFDbUYsSUFBSSxHQUFDLE9BQU9qRCxNQUFNLENBQUM2QyxNQUFNLEtBQUcsUUFBUSxHQUFDaEUsTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUVILFFBQVEsQ0FBQ2hCLElBQUksQ0FBQ3BCLE1BQU0sSUFBRUEsTUFBTSxDQUFDcUIsRUFBRSxLQUFHcUMsTUFBTSxDQUFDNkMsTUFBTSxJQUFFdkcsTUFBTSxDQUFDc0YsSUFBSSxLQUFHLGVBQWUsQ0FBQyxHQUFDNUUsU0FBUztVQUFDa0csS0FBSyxHQUFDLE9BQU9sRCxNQUFNLENBQUM0QyxPQUFPLEtBQUcsUUFBUSxHQUFDSSxNQUFNLElBQUUzRyxlQUFlLENBQUMyRyxNQUFNLENBQUMsQ0FBQ0csT0FBTyxDQUFDLENBQUMsR0FBRUMsUUFBUSxDQUFDLEtBQUdBLFFBQVEsQ0FBQyxDQUFDMUYsSUFBSSxDQUFDd0YsS0FBSyxJQUFFQSxLQUFLLENBQUN2RixFQUFFLEtBQUdxQyxNQUFNLENBQUM0QyxPQUFPLENBQUMsR0FBQzVGLFNBQVM7VUFBQ3FHLElBQUksSUFBQVAsV0FBQSxHQUFDSSxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRUcsSUFBSSxjQUFBUCxXQUFBLGNBQUFBLFdBQUEsR0FBR0csSUFBSSxHQUFDL0csTUFBTSxDQUFDK0csSUFBSSxDQUFDeEcsSUFBSSxDQUFDNEcsSUFBSSxDQUFDLENBQUMxRyxHQUFHLENBQUN1RyxLQUFLLElBQUVBLEtBQUssQ0FBQ0csSUFBSSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBQ3RHLFNBQVU7UUFDemhCLE1BQU11RyxPQUFPLEdBQUMsQ0FBQ1AsTUFBTSxJQUFFaEQsTUFBTSxDQUFDNEMsT0FBTyxJQUFFLElBQUksSUFBRSxDQUFDTSxLQUFLLElBQUVsRCxNQUFNLENBQUM2QyxNQUFNLElBQUUsSUFBSSxJQUFFLENBQUNJLElBQUk7VUFBQ08sUUFBUSxHQUFDaEIsS0FBSyxJQUFFLElBQUksSUFBRUUsR0FBRyxJQUFFLElBQUk7VUFBQ2UsWUFBWSxHQUFDRCxRQUFRLEtBQUcsQ0FBQ0UsTUFBTSxDQUFDQyxhQUFhLENBQUNuQixLQUFLLENBQUMsSUFBRSxDQUFDa0IsTUFBTSxDQUFDQyxhQUFhLENBQUNqQixHQUFHLENBQUMsSUFBRWdCLE1BQU0sQ0FBQ2xCLEtBQUssQ0FBQyxHQUFDLENBQUMsSUFBRWtCLE1BQU0sQ0FBQ2hCLEdBQUcsQ0FBQyxHQUFDZ0IsTUFBTSxDQUFDbEIsS0FBSyxDQUFDLElBQUVhLElBQUksS0FBR3JHLFNBQVMsSUFBRTBHLE1BQU0sQ0FBQ2hCLEdBQUcsQ0FBQyxHQUFDLENBQUMsR0FBR1csSUFBSSxDQUFDLENBQUMzRyxNQUFNLENBQUM7UUFDN1IsSUFBRzZHLE9BQU8sSUFBRUUsWUFBWSxFQUFDdEcsTUFBTSxDQUFDc0IsSUFBSSxDQUFDO1VBQUNyQixJQUFJLEVBQUMsbUJBQW1CO1VBQUNDLE9BQU8sRUFBQywwQ0FBMEM7VUFBQ1M7UUFBUSxDQUFDLENBQUM7TUFDN0g7TUFDQXdDLE1BQU0sQ0FBQ3NELE1BQU0sQ0FBQzVELE1BQU0sQ0FBQyxDQUFDc0MsT0FBTyxDQUFDRixPQUFPLENBQUM7SUFDdkMsQ0FBQztJQUFDOUMsT0FBTyxDQUFDWixRQUFRLENBQUM0RCxPQUFPLENBQUNoRyxNQUFNLElBQUU4RixPQUFPLENBQUM5RixNQUFNLENBQUNHLElBQUksQ0FBQyxDQUFDO0VBQ3pEO0VBQ0EsT0FBT1UsTUFBTTtBQUNkO0FBQ0E7QUFDQSxPQUFPLGVBQWUwRyxzQkFBc0JBLENBQUM1RSxRQUFvQixFQUFDQyxRQUFvQixFQUFDcEMsT0FBcUIsRUFBQ2dILGdCQUF3QixFQUFDO0VBRXJJLE1BQU1DLE9BQStCLEdBQUMsQ0FBQyxDQUFDO0lBQUM3QixRQUFrRCxHQUFDLEVBQUU7SUFBQzhCLE9BQXdCLEdBQUMsRUFBRTtJQUFDQyxNQUFNLEdBQUMsSUFBSS9GLEdBQUcsQ0FBUyxDQUFDO0lBQUNnRyxNQUFNLEdBQUMsSUFBSWpDLEdBQUcsQ0FBZ0IsQ0FBQztJQUFDa0MsWUFBWSxHQUFDLElBQUlsQyxHQUFHLENBQWdCLENBQUM7RUFDek4sZUFBZW1DLEtBQUtBLENBQUM5RSxPQUFtQixFQUFDK0UsU0FBZ0IsRUFBQ0MsS0FBWSxFQUFDO0lBQ3RFLElBQUdBLEtBQUssR0FBQyxFQUFFLEVBQUMsTUFBTWxELEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQztJQUM5RCxNQUFNSyxNQUFNLEdBQUNuQyxPQUFPLENBQUNaLFFBQVEsQ0FBQ2hCLElBQUksQ0FBRXBCLE1BQU0sSUFBMENBLE1BQU0sQ0FBQ3FCLEVBQUUsS0FBRzBHLFNBQVMsSUFBRS9ILE1BQU0sQ0FBQ3NGLElBQUksS0FBRyxvQkFBb0IsSUFBRXRGLE1BQU0sQ0FBQ2lJLE1BQU0sS0FBRyxXQUFXLElBQUUsQ0FBQ2pJLE1BQU0sQ0FBQ2tJLFNBQVMsQ0FBQztJQUFDLElBQUcsQ0FBQy9DLE1BQU0sRUFBQyxNQUFNTCxLQUFLLENBQUMsc0NBQXNDLENBQUM7SUFDN1AsS0FBSSxNQUFNcUQsV0FBVyxLQUFBQyxxQkFBQSxHQUFJakQsTUFBTSxDQUFDaEYsSUFBSSxDQUFDa0ksYUFBYSxjQUFBRCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFFLEVBQUUsRUFBQztNQUFBLElBQUFBLHFCQUFBLEVBQUFFLGtCQUFBLEVBQUFDLHNCQUFBLEVBQUFDLG1CQUFBO01BQ3RELE1BQU1uSCxFQUFFLEdBQUM4RyxXQUFXLENBQUNyRSxlQUFlO1FBQUMyRSxLQUFLLEdBQUNoQixPQUFPLENBQUNwRyxFQUFFLENBQUM7TUFBQyxJQUFHc0csTUFBTSxDQUFDNUYsR0FBRyxDQUFDVixFQUFFLENBQUMsRUFBQyxNQUFNeUQsS0FBSyxDQUFDLHdDQUF3QyxDQUFDO01BQzlILElBQUcyRCxLQUFLLEVBQUM7UUFBQyxJQUFHQSxLQUFLLENBQUNDLGVBQWUsS0FBR1AsV0FBVyxDQUFDTyxlQUFlLElBQUVkLE1BQU0sQ0FBQ25CLEdBQUcsQ0FBQ3BGLEVBQUUsQ0FBQyxLQUFHOEcsV0FBVyxDQUFDSixTQUFTLEVBQUMsTUFBTWpELEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztRQUFDO01BQVM7TUFDNUssSUFBR2MsUUFBUSxDQUFDeEYsTUFBTSxHQUFDdUgsTUFBTSxDQUFDZ0IsSUFBSSxJQUFFLEdBQUcsSUFBRWQsWUFBWSxDQUFDOUYsR0FBRyxDQUFDb0csV0FBVyxDQUFDTyxlQUFlLENBQUMsSUFBRSxDQUFDUCxXQUFXLENBQUNPLGVBQWUsRUFBQyxNQUFNNUQsS0FBSyxDQUFDLHNDQUFzQyxDQUFDO01BQ3BLK0MsWUFBWSxDQUFDZSxHQUFHLENBQUNULFdBQVcsQ0FBQ08sZUFBZSxFQUFDckgsRUFBRSxDQUFDO01BQ2hEc0csTUFBTSxDQUFDM0YsR0FBRyxDQUFDWCxFQUFFLENBQUM7TUFBQyxNQUFNd0gsR0FBRyxHQUFDbEcsUUFBUSxDQUFDeEIsU0FBUyxDQUFDQyxJQUFJLENBQUMwSCxHQUFHLElBQUVBLEdBQUcsQ0FBQ3pILEVBQUUsS0FBR0EsRUFBRSxDQUFDO1FBQUN3RCxLQUFLLEdBQUMsRUFBQXlELGtCQUFBLEdBQUM5SCxPQUFPLENBQUN1SSxTQUFTLGNBQUFULGtCQUFBLGNBQUFBLGtCQUFBLEdBQUUsRUFBRSxFQUFFbEgsSUFBSSxDQUFDMEgsR0FBRyxJQUFFQSxHQUFHLENBQUN6SCxFQUFFLEtBQUdBLEVBQUUsQ0FBQztRQUFDeUgsR0FBRyxHQUFDRCxHQUFHLGFBQUhBLEdBQUcsY0FBSEEsR0FBRyxHQUFFaEUsS0FBSztRQUFDbUUsUUFBUSxJQUFBVCxzQkFBQSxHQUFDL0gsT0FBTyxDQUFDeUMsY0FBYyxjQUFBc0Ysc0JBQUEsY0FBQUEsc0JBQUEsR0FBRSxDQUFDLENBQUM7TUFDMUssSUFBRyxDQUFDTyxHQUFHLElBQUUsT0FBTTFKLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDeUosR0FBRyxDQUFDeEgsT0FBTyxDQUFDLENBQUMsTUFBR3dILEdBQUcsQ0FBQzVHLFdBQVcsSUFBRTJDLEtBQUssS0FBRyxDQUFDbUUsUUFBUSxDQUFDM0gsRUFBRSxDQUFDLElBQUUsT0FBTWpDLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDMkosUUFBUSxDQUFDM0gsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFHeUgsR0FBRyxDQUFDNUcsV0FBVyxDQUFDLEVBQUMsTUFBTTRDLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQztNQUN6TSxNQUFNbUUsT0FBTyxHQUFDSCxHQUFHLENBQUN4SCxPQUFPLENBQUNDLFNBQVMsS0FBR29CLFFBQVEsQ0FBQ3BCLFNBQVMsR0FBQ29CLFFBQVEsQ0FBQ3hCLFNBQVMsR0FBQyxDQUFDLEdBQUcsRUFBQXFILG1CQUFBLEdBQUNoSSxPQUFPLENBQUN1SSxTQUFTLGNBQUFQLG1CQUFBLGNBQUFBLG1CQUFBLEdBQUUsRUFBRSxFQUFFdkksTUFBTSxDQUFDc0QsSUFBSSxJQUFFQSxJQUFJLENBQUNqQyxPQUFPLENBQUNDLFNBQVMsS0FBR3VILEdBQUcsQ0FBQ3hILE9BQU8sQ0FBQ0MsU0FBUyxDQUFDLENBQUNsQixHQUFHLENBQUNrRCxJQUFJLEtBQUc7UUFBQyxHQUFHQSxJQUFJO1FBQUMyRixTQUFTLEVBQUMsMEJBQTBCO1FBQUNDLFlBQVksRUFBQztNQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDelAsTUFBTUMsUUFBUSxHQUFDO1VBQUMsR0FBRzVHLGVBQWUsQ0FBQ3NHLEdBQUcsQ0FBQ3hILE9BQU8sQ0FBQztVQUFDSCxTQUFTLEVBQUNxQixlQUFlLENBQUN5RyxPQUFPLENBQUM7VUFBQ3hHLE9BQU8sRUFBQztRQUFFLENBQUM7UUFBQzRHLE1BQU0sR0FBQ0QsUUFBUSxDQUFDaEgsUUFBUSxDQUFDaEIsSUFBSSxDQUFDcEIsTUFBTSxJQUFFQSxNQUFNLENBQUNxQixFQUFFLEtBQUc4RyxXQUFXLENBQUNKLFNBQVMsSUFBRS9ILE1BQU0sQ0FBQ3NGLElBQUksS0FBRyxvQkFBb0IsQ0FBQztRQUFDZ0UsT0FBTyxHQUFDM0csUUFBUSxDQUFDUCxRQUFRLENBQUNoQixJQUFJLENBQUVwQixNQUFNLElBQTBDQSxNQUFNLENBQUNxQixFQUFFLEtBQUc4RyxXQUFXLENBQUNKLFNBQVMsSUFBRS9ILE1BQU0sQ0FBQ3NGLElBQUksS0FBRyxvQkFBb0IsSUFBRXRGLE1BQU0sQ0FBQ0csSUFBSSxDQUFDMkQsZUFBZSxLQUFHekMsRUFBRSxDQUFDO01BQ3BZLElBQUcsQ0FBQ2dJLE1BQU0sSUFBRSxDQUFDQyxPQUFPLEVBQUMsTUFBTXhFLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztNQUM5RSxNQUFNNUIsSUFBSSxHQUFDLE1BQU1SLG1CQUFtQixDQUFDMEcsUUFBUSxFQUFDQSxRQUFRLEVBQUM7UUFBQyxHQUFHNUksT0FBTztRQUFDNEUsbUJBQW1CLEVBQUMrQyxXQUFXLENBQUNKLFNBQVM7UUFBQ3BILGVBQWUsRUFBQ1UsRUFBRTtRQUFDWixjQUFjLEVBQUNDO01BQVMsQ0FBQyxDQUFDO01BQzFKLElBQUcsQ0FBQzJJLE1BQU0sSUFBRUMsT0FBTyxFQUFDcEcsSUFBSSxDQUFDZCxRQUFRLENBQUNELElBQUksQ0FBQztRQUFDLEdBQUdLLGVBQWUsQ0FBQzhHLE9BQU8sQ0FBQztRQUFDL0gsU0FBUyxFQUFDMkIsSUFBSSxDQUFDM0I7TUFBUyxDQUFDLENBQUM7TUFDOUYsTUFBTXVHLEtBQUssQ0FBQzVFLElBQUksRUFBQ2lGLFdBQVcsQ0FBQ0osU0FBUyxFQUFDQyxLQUFLLEdBQUMsQ0FBQyxDQUFDO01BQy9DLE1BQU11QixNQUFNLEdBQUMvSixnQkFBZ0IsQ0FBQzBELElBQUksRUFBQ2lGLFdBQVcsQ0FBQ0osU0FBUyxFQUFDO1FBQUNQLGdCQUFnQjtRQUFDZ0MsYUFBYSxFQUFDLElBQUk7UUFBQzdJLGVBQWUsRUFBQ1UsRUFBRTtRQUFDb0ksY0FBYyxFQUFDaEM7TUFBTyxDQUFDLENBQUM7TUFBQyxJQUFHLENBQUM4QixNQUFNLENBQUMzSSxFQUFFLEVBQUMsTUFBTW9ELE1BQU0sQ0FBQzBGLE1BQU0sQ0FBQzVFLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQyxFQUFDO1FBQUNqRSxNQUFNLEVBQUMwSSxNQUFNLENBQUMxSTtNQUFNLENBQUMsQ0FBQztNQUN2UDRHLE9BQU8sQ0FBQ3BHLEVBQUUsQ0FBQyxHQUFDO1FBQUNxSCxlQUFlLEVBQUNQLFdBQVcsQ0FBQ08sZUFBZTtRQUFDaUIsS0FBSyxFQUFDSixNQUFNLENBQUNJO01BQUssQ0FBQztNQUFDL0IsTUFBTSxDQUFDZ0IsR0FBRyxDQUFDdkgsRUFBRSxFQUFDOEcsV0FBVyxDQUFDSixTQUFTLENBQUM7TUFBQ25DLFFBQVEsQ0FBQ3pELElBQUksQ0FBQztRQUFDZCxFQUFFLEVBQUM4RyxXQUFXLENBQUNPLGVBQWU7UUFBQ2xELFVBQVUsRUFBQytELE1BQU0sQ0FBQy9EO01BQVUsQ0FBQyxDQUFDO01BQUNrQyxPQUFPLENBQUN2RixJQUFJLENBQUM7UUFBQ3VHLGVBQWUsRUFBQ1AsV0FBVyxDQUFDTyxlQUFlO1FBQUNYLFNBQVMsRUFBQ0ksV0FBVyxDQUFDSixTQUFTO1FBQUN4SCxPQUFPLEVBQUMyQyxJQUFJO1FBQUNzQyxVQUFVLEVBQUMrRCxNQUFNLENBQUMvRCxVQUFVO1FBQUNtRSxLQUFLLEVBQUNKLE1BQU0sQ0FBQ0k7TUFBSyxDQUFDLENBQUM7TUFBQ2hDLE1BQU0sQ0FBQ2lDLE1BQU0sQ0FBQ3ZJLEVBQUUsQ0FBQztJQUMxVztFQUNEO0VBQ0EsTUFBTXlHLEtBQUssQ0FBQ2xGLFFBQVEsRUFBQ3BDLE9BQU8sQ0FBQzRFLG1CQUFtQixFQUFDLENBQUMsQ0FBQztFQUFDLE9BQU87SUFBQ3FDLE9BQU87SUFBQzdCLFFBQVE7SUFBQzhCO0VBQU8sQ0FBQztBQUN0Rjs7QUFFQTtBQUNBLE9BQU8sZUFBZW1DLHNCQUFzQkEsQ0FBQ0MsS0FBaUIsRUFBQ0MsWUFBMEIsRUFBQztFQUFBLElBQUFDLHNCQUFBO0VBQ3pGLE1BQU1ySCxRQUFRLEdBQUNILGVBQWUsQ0FBQ3NILEtBQUssQ0FBQztJQUFDdEosT0FBTyxHQUFDZ0MsZUFBZSxDQUFDdUgsWUFBWSxDQUFDO0lBQUNuSCxRQUFRLEdBQUMsTUFBTXRDLGtCQUFrQixDQUFDcUMsUUFBUSxFQUFDbkMsT0FBTyxDQUFDO0VBQy9ILElBQUcsQ0FBQ29DLFFBQVEsQ0FBQ2hDLEVBQUUsRUFBQyxNQUFNb0QsTUFBTSxDQUFDMEYsTUFBTSxDQUFDNUUsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLEVBQUM7SUFBQ2pFLE1BQU0sRUFBQytCLFFBQVEsQ0FBQy9CO0VBQU0sQ0FBQyxDQUFDO0VBQ3hHLE1BQU1vSixPQUFPLEdBQUMxSyxlQUFlLENBQUNxRCxRQUFRLENBQUNyQyxPQUFPLEVBQUM7SUFBQzBDLGNBQWMsR0FBQStHLHNCQUFBLEdBQUN4SixPQUFPLENBQUN5QyxjQUFjLGNBQUErRyxzQkFBQSxjQUFBQSxzQkFBQSxHQUFFLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxJQUFHLENBQUNDLE9BQU8sQ0FBQ3JKLEVBQUUsRUFBQyxNQUFNb0QsTUFBTSxDQUFDMEYsTUFBTSxDQUFDNUUsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLEVBQUM7SUFBQ2pFLE1BQU0sRUFBQ29KLE9BQU8sQ0FBQ3BKO0VBQU0sQ0FBQyxDQUFDO0VBQ2xNLE1BQU1OLE9BQU8sR0FBQyxNQUFNbUMsbUJBQW1CLENBQUNDLFFBQVEsRUFBQ0MsUUFBUSxDQUFDckMsT0FBTyxFQUFDQyxPQUFPLENBQUM7SUFBQzBKLFNBQVMsR0FBQyxNQUFNM0Msc0JBQXNCLENBQUM1RSxRQUFRLEVBQUNwQyxPQUFPLEVBQUNDLE9BQU8sRUFBQyxJQUFJLENBQUM7SUFBQytJLE1BQU0sR0FBQy9KLGdCQUFnQixDQUFDZSxPQUFPLEVBQUNDLE9BQU8sQ0FBQzRFLG1CQUFtQixFQUFDO01BQUNvQyxnQkFBZ0IsRUFBQyxJQUFJO01BQUNnQyxhQUFhLEVBQUMsSUFBSTtNQUFDN0ksZUFBZSxFQUFDSCxPQUFPLENBQUNHLGVBQWU7TUFBQzhJLGNBQWMsRUFBQ1MsU0FBUyxDQUFDekM7SUFBTyxDQUFDLENBQUM7RUFDalUsSUFBRyxDQUFDOEIsTUFBTSxDQUFDM0ksRUFBRSxFQUFDLE1BQU1vRCxNQUFNLENBQUMwRixNQUFNLENBQUM1RSxLQUFLLENBQUMsd0NBQXdDLENBQUMsRUFBQztJQUFDakUsTUFBTSxFQUFDMEksTUFBTSxDQUFDMUk7RUFBTSxDQUFDLENBQUM7RUFDekcsSUFBR3FKLFNBQVMsQ0FBQ3RFLFFBQVEsQ0FBQ3hGLE1BQU0sRUFBQ21KLE1BQU0sQ0FBQy9ELFVBQVUsQ0FBQ0ksUUFBUSxHQUFDc0UsU0FBUyxDQUFDdEUsUUFBUTtFQUMxRSxNQUFNdUUsU0FBUyxHQUFDNUUsdUJBQXVCLENBQUNnRSxNQUFNLENBQUMvRCxVQUFVLENBQUM7RUFBQyxJQUFHMkUsU0FBUyxDQUFDL0osTUFBTSxFQUFDLE1BQU00RCxNQUFNLENBQUMwRixNQUFNLENBQUM1RSxLQUFLLENBQUMscUNBQXFDLENBQUMsRUFBQztJQUFDakUsTUFBTSxFQUFDc0o7RUFBUyxDQUFDLENBQUM7RUFDbkssT0FBTztJQUFDNUosT0FBTztJQUFDaUYsVUFBVSxFQUFDK0QsTUFBTSxDQUFDL0QsVUFBVTtJQUFDbUUsS0FBSyxFQUFDSixNQUFNLENBQUNJLEtBQUs7SUFBQ087RUFBUyxDQUFDO0FBQzNFIiwiaWdub3JlTGlzdCI6W119