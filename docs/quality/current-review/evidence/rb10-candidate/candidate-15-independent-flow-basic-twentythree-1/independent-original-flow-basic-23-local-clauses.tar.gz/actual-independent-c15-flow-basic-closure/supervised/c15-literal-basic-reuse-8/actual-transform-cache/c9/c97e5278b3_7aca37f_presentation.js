// d8a29ba759f1e1e5db7ae1d46c90c20be1c4fc0c
import { validateRuntimeState, validateVariableValue } from './model';
import { applyEffectsAtomic, DomainValidationError, evaluateCondition, initializeRuntimeState, resetRuntimeLifecycle, runtimeExclusionIssues } from './conditions';
import { buildChapterReadingSequence } from './writingWorkspace';
import { captureRuntimeContent, capturedVersionIssue } from './runtimeVersions';
import { canonicalJson } from '../storage/json';
import { validateExternalInput } from './externalInputs';
import { resolvePinnedWorlds } from './pinnedWorlds';
import { adoptedRecord } from './adoption';
import { evaluateTargetScope } from './stateRules';
import { declaredRegressionPaths, regressionPathCoverage } from './regressionPaths';
import { isTick } from './time';
import { resolveReuseContent, reuseAuthorContent, reuseOrigin, reuseRuleContexts, reuseExecutionAnchor } from './reuse';
import { checkPresentationForeshadows } from './narrative';
const active = (project, kind) => project.entities.filter(entity => entity.kind === kind && adoptedRecord(entity));
const problem = (path, message, code = 'REFERENCE_INVALID') => ({
  ok: false,
  issues: [{
    code,
    path,
    message
  }]
});
export function presentationRuleContext(project, target) {
  var _active$find, _scene$data$chapterId, _active$find2;
  const node = active(project, 'flow_node').find(item => item.id === target.nodeId);
  const scene = active(project, 'scene').find(item => {
    var _target$sceneId;
    return item.id === ((_target$sceneId = target.sceneId) !== null && _target$sceneId !== void 0 ? _target$sceneId : node === null || node === void 0 ? void 0 : node.data.sceneId);
  });
  return {
    projectId: project.projectId,
    worldTick: target.worldTick,
    graphId: node ? (_active$find = active(project, 'flow_graph').find(graph => graph.data.nodeIds.includes(node.id))) === null || _active$find === void 0 ? void 0 : _active$find.id : undefined,
    chapterId: (_scene$data$chapterId = scene === null || scene === void 0 ? void 0 : scene.data.chapterId) !== null && _scene$data$chapterId !== void 0 ? _scene$data$chapterId : scene ? (_active$find2 = active(project, 'chapter').find(chapter => chapter.data.sceneIds.includes(scene.id))) === null || _active$find2 === void 0 ? void 0 : _active$find2.id : undefined
  };
}

/** Choice text is presented only by a manual choice, including disabled candidates shown to the author. */
export function presentationLineIds(project, target) {
  var _node$data$executionP, _scene$data$dialogueL;
  const node = active(project, 'flow_node').find(item => item.id === target.nodeId);
  const scene = active(project, 'scene').find(item => {
    var _target$sceneId2;
    return item.id === ((_target$sceneId2 = target.sceneId) !== null && _target$sceneId2 !== void 0 ? _target$sceneId2 : node === null || node === void 0 ? void 0 : node.data.sceneId);
  });
  const policy = (_node$data$executionP = node === null || node === void 0 ? void 0 : node.data.executionPolicy) !== null && _node$data$executionP !== void 0 ? _node$data$executionP : (node === null || node === void 0 ? void 0 : node.data.nodeType) === 'automatic' ? 'first_match' : 'manual_choice';
  return [...new Set([...((_scene$data$dialogueL = scene === null || scene === void 0 ? void 0 : scene.data.dialogueLineIds) !== null && _scene$data$dialogueL !== void 0 ? _scene$data$dialogueL : []), ...(node && policy === 'manual_choice' ? active(project, 'flow_edge').filter(edge => edge.data.fromId === node.id).flatMap(edge => edge.data.choiceLineId ? [edge.data.choiceLineId] : []) : [])])];
}
export function presentationAnchorApplies(project, state, anchor, target, declarationId) {
  var _reuseOrigin, _target$sceneId3;
  if (anchor.positionStatus === 'unresolved') return false;
  const declaration = declarationId ? reuseOrigin(project, declarationId) : undefined;
  if (anchor.sourceVersionId && ![project.projectId, state.contentVersionId, (_reuseOrigin = reuseOrigin(project, anchor.entityId)) === null || _reuseOrigin === void 0 ? void 0 : _reuseOrigin.sourceVersionId, declaration === null || declaration === void 0 ? void 0 : declaration.sourceVersionId].includes(anchor.sourceVersionId)) return false;
  const node = active(project, 'flow_node').find(item => item.id === target.nodeId);
  const sceneId = (_target$sceneId3 = target.sceneId) !== null && _target$sceneId3 !== void 0 ? _target$sceneId3 : node === null || node === void 0 ? void 0 : node.data.sceneId;
  const scene = active(project, 'scene').find(item => item.id === sceneId);
  const lines = presentationLineIds(project, target);
  if (![target.nodeId, sceneId, ...lines].includes(anchor.entityId)) return false;
  return [anchor.entityId, anchor.blockId, anchor.lineId].filter(id => !!id).every(id => state.seenIds.includes(id));
}

/** Reading order is block/line order and code-point position, never event/world-date order. */
export function presentationAnchorOrder(project, left, right, target) {
  var _scene$data$body, _ref, _left$blockId, _ref2, _right$blockId;
  if (left.positionStatus === 'unresolved' || right.positionStatus === 'unresolved') return undefined;
  const node = active(project, 'flow_node').find(item => item.id === target.nodeId);
  const scene = active(project, 'scene').find(item => {
    var _target$sceneId4;
    return item.id === ((_target$sceneId4 = target.sceneId) !== null && _target$sceneId4 !== void 0 ? _target$sceneId4 : node === null || node === void 0 ? void 0 : node.data.sceneId);
  });
  const lineIds = presentationLineIds(project, target);
  const positions = [...((_scene$data$body = scene === null || scene === void 0 ? void 0 : scene.data.body) !== null && _scene$data$body !== void 0 ? _scene$data$body : []).map(block => block.id)];
  for (const lineId of lineIds) {
    var _active$find$data$tex, _active$find3;
    positions.push(lineId, ...((_active$find$data$tex = (_active$find3 = active(project, 'dialogue_line').find(line => line.id === lineId)) === null || _active$find3 === void 0 ? void 0 : _active$find3.data.text) !== null && _active$find$data$tex !== void 0 ? _active$find$data$tex : []).map(block => block.id));
  }
  const leftBlock = (_ref = (_left$blockId = left.blockId) !== null && _left$blockId !== void 0 ? _left$blockId : left.lineId) !== null && _ref !== void 0 ? _ref : lineIds.includes(left.entityId) ? left.entityId : undefined;
  const rightBlock = (_ref2 = (_right$blockId = right.blockId) !== null && _right$blockId !== void 0 ? _right$blockId : right.lineId) !== null && _ref2 !== void 0 ? _ref2 : lineIds.includes(right.entityId) ? right.entityId : undefined;
  const first = positions.indexOf(leftBlock !== null && leftBlock !== void 0 ? leftBlock : ''),
    second = positions.indexOf(rightBlock !== null && rightBlock !== void 0 ? rightBlock : '');
  if (first >= 0 && second >= 0 && first !== second) return first < second;
  if (leftBlock !== rightBlock || left.entityId !== right.entityId || left.start == null || right.start == null || left.start === right.start) return undefined;
  if (left.start < right.start && left.end != null && left.end > right.start || right.start < left.start && right.end != null && right.end > left.start) return undefined;
  return left.start < right.start;
}

/** Shared atomic arrival for flow and chapter presentation. Conditions precede every disclosure effect. */
export function presentContent(project, state, target) {
  var _target$externalValue;
  const checked = validateRuntimeState(state);
  if (!checked.ok) return {
    ok: false,
    issues: checked.issues
  };
  const externalIssues = validateExternalInput(project, (_target$externalValue = target.externalValues) !== null && _target$externalValue !== void 0 ? _target$externalValue : {}, undefined, target.referenceEntities);
  if (externalIssues.length) return {
    ok: false,
    issues: externalIssues
  };
  try {
    var _ref3, _target$sceneId5, _target$referenceEnti;
    const node = target.nodeId ? active(project, 'flow_node').find(item => item.id === target.nodeId) : undefined;
    if (target.nodeId && !node) return problem('presentation.nodeId', '提示する分岐が存在しないか、削除・不採用です。');
    const sceneId = (_ref3 = (_target$sceneId5 = target.sceneId) !== null && _target$sceneId5 !== void 0 ? _target$sceneId5 : node === null || node === void 0 ? void 0 : node.data.sceneId) !== null && _ref3 !== void 0 ? _ref3 : undefined;
    if (!node && !sceneId) return problem('presentation', '提示する場面または分岐を指定してください。');
    const scene = sceneId ? active(project, 'scene').find(item => item.id === sceneId) : undefined;
    if (sceneId && !scene) return problem('presentation.sceneId', '提示する場面が存在しないか、削除・不採用です。');
    const initialContext = presentationRuleContext(project, {
      ...target,
      sceneId
    });
    const initialIssues = runtimeExclusionIssues({
      state,
      entities: project.entities,
      referenceEntities: target.referenceEntities,
      externalValues: target.externalValues,
      ruleContext: initialContext,
      ruleContexts: reuseRuleContexts(project, initialContext)
    });
    if (initialIssues.length) return {
      ok: false,
      issues: initialIssues
    };
    const resolved = {
        ...target,
        sceneId
      },
      next = structuredClone(state),
      seen = new Set(next.seenIds);
    if (node) {
      var _next$visitCounts$nod;
      next.presentationPosition = node.id;
      next.visitCounts[node.id] = ((_next$visitCounts$nod = next.visitCounts[node.id]) !== null && _next$visitCounts$nod !== void 0 ? _next$visitCounts$nod : 0) + 1;
      seen.add(node.id);
    }
    if (scene) {
      var _next$visitCounts$sce;
      seen.add(scene.id);
      next.visitCounts[scene.id] = ((_next$visitCounts$sce = next.visitCounts[scene.id]) !== null && _next$visitCounts$sce !== void 0 ? _next$visitCounts$sce : 0) + 1;
      for (const id of (_scene$data$blockIds = scene.data.blockIds) !== null && _scene$data$blockIds !== void 0 ? _scene$data$blockIds : []) {
        var _scene$data$blockIds;
        seen.add(id);
      }
      for (const block of scene.data.body) seen.add(block.id);
    }
    for (const lineId of presentationLineIds(project, resolved)) {
      var _node$id, _next$visitCounts$lin;
      const line = active(project, 'dialogue_line').find(item => item.id === lineId);
      if (!line) return problem(`${(_node$id = node === null || node === void 0 ? void 0 : node.id) !== null && _node$id !== void 0 ? _node$id : scene === null || scene === void 0 ? void 0 : scene.id}.dialogueLineIds`, '提示する台詞が存在しないか、削除・不採用です。');
      seen.add(line.id);
      next.visitCounts[line.id] = ((_next$visitCounts$lin = next.visitCounts[line.id]) !== null && _next$visitCounts$lin !== void 0 ? _next$visitCounts$lin : 0) + 1;
      for (const block of line.data.text) seen.add(block.id);
    }
    next.seenIds = [...seen];
    const variables = [...active(project, 'variable'), ...((_target$referenceEnti = target.referenceEntities) !== null && _target$referenceEnti !== void 0 ? _target$referenceEnti : []).filter(entity => entity.kind === 'variable' && adoptedRecord(entity))],
      ruleContext = presentationRuleContext(project, resolved),
      context = {
        state: next,
        variables,
        entities: project.entities,
        referenceEntities: target.referenceEntities,
        externalValues: target.externalValues,
        ruleContext,
        ruleContexts: reuseRuleContexts(project, ruleContext)
      };
    const conditions = [],
      disclosures = [];
    for (const disclosure of active(project, 'disclosure')) {
      var _context$ruleContexts, _reuseOrigin2, _reuseOrigin3, _disclosure$data$cond, _scope$routeCondition;
      const anchor = reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id);
      const scope = disclosure.data.targetScope;
      const disclosureContext = {
        ...context,
        ruleContext: (_context$ruleContexts = context.ruleContexts[disclosure.id]) !== null && _context$ruleContexts !== void 0 ? _context$ruleContexts : context.ruleContext
      };
      const scopeResult = scope ? evaluateTargetScope(scope, disclosureContext) : {
        value: 'true'
      };
      if (scopeResult.value === 'false') continue;
      if (anchor.sourceVersionId && ![project.projectId, state.contentVersionId, (_reuseOrigin2 = reuseOrigin(project, anchor.entityId)) === null || _reuseOrigin2 === void 0 ? void 0 : _reuseOrigin2.sourceVersionId, (_reuseOrigin3 = reuseOrigin(project, disclosure.id)) === null || _reuseOrigin3 === void 0 ? void 0 : _reuseOrigin3.sourceVersionId].includes(anchor.sourceVersionId)) continue;
      const lineIds = presentationLineIds(project, resolved);
      if (![node === null || node === void 0 ? void 0 : node.id, scene === null || scene === void 0 ? void 0 : scene.id, ...lineIds].includes(anchor.entityId)) continue;
      if (scopeResult.value === 'unknown') return problem(`${disclosure.id}.targetScope`, '開示の対象範囲・経路を確認できません。', 'CONDITION_UNKNOWN');
      if (anchor.positionStatus === 'unresolved' && [node === null || node === void 0 ? void 0 : node.id, scene === null || scene === void 0 ? void 0 : scene.id, ...lineIds].includes(anchor.entityId)) return problem(`${disclosure.id}.anchor`, anchor.positionReason || '提示位置が不明です。本文へ再リンクしてください。', 'CONDITION_UNKNOWN');
      if (!presentationAnchorApplies(project, next, anchor, resolved, disclosure.id)) continue;
      const result = evaluateCondition({
        op: 'all',
        children: [(_disclosure$data$cond = disclosure.data.condition) !== null && _disclosure$data$cond !== void 0 ? _disclosure$data$cond : {
          op: 'constant',
          value: true
        }, (_scope$routeCondition = scope === null || scope === void 0 ? void 0 : scope.routeCondition) !== null && _scope$routeCondition !== void 0 ? _scope$routeCondition : {
          op: 'constant',
          value: true
        }]
      }, disclosureContext);
      conditions.push({
        targetId: disclosure.id,
        ...result
      });
      if (result.value === 'unknown') return problem(`${disclosure.id}.condition`, result.reasons.join('、') || 'この場面の開示条件が未確認です。', 'CONDITION_UNKNOWN');
      if (result.value === 'true') disclosures.push(disclosure);
    }
    const ordered = disclosures.filter(disclosure => {
      var _disclosure$data$know, _disclosure$data$know2;
      return ((_disclosure$data$know = (_disclosure$data$know2 = disclosure.data.knowledgeEffects) === null || _disclosure$data$know2 === void 0 ? void 0 : _disclosure$data$know2.length) !== null && _disclosure$data$know !== void 0 ? _disclosure$data$know : 0) > 0;
    });
    for (let i = 0; i < ordered.length; i++) for (let j = i + 1; j < ordered.length; j++) {
      var _node$id2;
      if (presentationAnchorOrder(project, reuseExecutionAnchor(project, ordered[i].data.anchor, ordered[i].id), reuseExecutionAnchor(project, ordered[j].data.anchor, ordered[j].id), resolved) === undefined) return problem(`${(_node$id2 = node === null || node === void 0 ? void 0 : node.id) !== null && _node$id2 !== void 0 ? _node$id2 : scene === null || scene === void 0 ? void 0 : scene.id}.disclosures`, '複数の開示効果の提示順が確定していません。段落と文字位置を指定してください。', 'CONDITION_UNKNOWN');
    }
    ordered.sort((left, right) => presentationAnchorOrder(project, reuseExecutionAnchor(project, left.data.anchor, left.id), reuseExecutionAnchor(project, right.data.anchor, right.id), resolved) ? -1 : 1);
    const effects = [],
      effectPresentations = [];
    for (const disclosure of ordered) for (const effectId of (_disclosure$data$know3 = disclosure.data.knowledgeEffects) !== null && _disclosure$data$know3 !== void 0 ? _disclosure$data$know3 : []) {
      var _disclosure$data$know3, _target$referenceEnti2;
      const effect = [...project.entities, ...((_target$referenceEnti2 = target.referenceEntities) !== null && _target$referenceEnti2 !== void 0 ? _target$referenceEnti2 : [])].find(item => item.kind === 'effect' && item.id === effectId && adoptedRecord(item));
      if (!effect) return problem(`${disclosure.id}.knowledgeEffects`, '開示に指定した効果が存在しないか、削除・不採用です。');
      effects.push(effect);
      effectPresentations.push({
        project,
        target: resolved,
        anchor: reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id)
      });
    }
    const applied = applyEffectsAtomic(next, effects, {
      ...context,
      effectPresentations
    });
    if (!applied.ok) return applied;
    applied.state.seenIds = [...new Set([...applied.state.seenIds, ...disclosures.map(disclosure => disclosure.id)])];
    return {
      ok: true,
      state: applied.state,
      observationState: structuredClone(next),
      conditions
    };
  } catch (error) {
    return {
      ok: false,
      issues: error instanceof DomainValidationError ? error.issues : [{
        code: 'VALIDATION_FAILED',
        path: 'presentation',
        message: error instanceof Error ? error.message : '提示を検証できません。'
      }]
    };
  }
}
export function chapterNarrativeOccurrences(session) {
  return session.occurrences.map(occurrence => {
    var _occurrence$presentat, _occurrence$externalV;
    return {
      state: occurrence.after,
      observationState: (_occurrence$presentat = occurrence.presentationState) !== null && _occurrence$presentat !== void 0 ? _occurrence$presentat : undefined,
      conditions: occurrence.conditionResults,
      target: {
        sceneId: occurrence.entityId
      },
      worldTick: session.worldTick,
      externalValues: (_occurrence$externalV = occurrence.externalValues) !== null && _occurrence$externalV !== void 0 ? _occurrence$externalV : session.externalValues
    };
  });
}
export function checkChapterForeshadows(session) {
  return checkPresentationForeshadows(session.content, chapterNarrativeOccurrences(session), session.startState, session.status === 'terminal', session.referenceEntities, session.issues);
}
export async function startChapterReading(project, options = {}) {
  var _options$externalValu, _options$contentVersi, _sequence$, _project$snapshots$fi;
  const declarationProject = structuredClone({
    ...project,
    history: [],
    snapshots: [],
    authorAlternatives: undefined,
    entities: project.entities.filter(entity => ['collection', 'trace', 'checkpoint'].includes(entity.kind))
  });
  const worldTick = options.worldTick,
    requestedSelection = options.selection;
  if (worldTick !== undefined && !isTick(worldTick)) throw new DomainValidationError([{
    code: 'VALIDATION_FAILED',
    path: 'worldTick',
    message: '提示時点には整数の世界内tickを入力してください。'
  }]);
  const worldSnapshots = options.worldSnapshots ? structuredClone(options.worldSnapshots) : {};
  const chapterIdsOption = options.chapterIds ? [...options.chapterIds] : undefined,
    sceneIdsOption = options.sceneIds ? [...options.sceneIds] : undefined;
  const externalValues = structuredClone((_options$externalValu = options.externalValues) !== null && _options$externalValu !== void 0 ? _options$externalValu : {}),
    requestedState = options.state ? structuredClone(options.state) : undefined;
  const version = (_options$contentVersi = options.contentVersionId) !== null && _options$contentVersi !== void 0 ? _options$contentVersi : project.projectId,
    captured = await captureRuntimeContent(project, version, {
      worldSnapshots
    }),
    content = resolveReuseContent(captured, captured.snapshots);
  const closure = resolvePinnedWorlds(content, worldSnapshots);
  if (closure.errors.length) throw new DomainValidationError([{
    code: 'REFERENCE_INVALID',
    path: 'worldReferences',
    message: closure.errors[0]
  }]);
  const externalIssues = validateExternalInput(content, externalValues, undefined, closure.worlds.flatMap(world => world.entities));
  if (externalIssues.length) throw new DomainValidationError(externalIssues);
  if (sceneIdsOption !== null && sceneIdsOption !== void 0 && sceneIdsOption.some(id => !active(content, 'scene').some(scene => scene.id === id))) throw new DomainValidationError([{
    code: 'REFERENCE_INVALID',
    path: 'sceneIds',
    message: '読み通し経路に存在しない場面が指定されています。'
  }]);
  if (chapterIdsOption !== null && chapterIdsOption !== void 0 && chapterIdsOption.some(id => !active(content, 'chapter').some(chapter => chapter.id === id))) throw new DomainValidationError([{
    code: 'REFERENCE_INVALID',
    path: 'chapterIds',
    message: '読み通す章が存在しません。'
  }]);
  const sequence = buildChapterReadingSequence(content, chapterIdsOption, sceneIdsOption);
  if (requestedState && requestedState.contentVersionId !== version) throw new DomainValidationError([{
    code: 'VALIDATION_FAILED',
    path: 'state.contentVersionId',
    message: '開始状態と読み通し対象の版が違います。変更せず開始を止めました。'
  }]);
  const state = structuredClone(requestedState !== null && requestedState !== void 0 ? requestedState : initializeRuntimeState(content, version, closure.worlds.flatMap(world => world.entities)));
  state.contentVersionId = version;
  state.presentationPosition = null;
  state.provenance = 'partial';
  const validated = validateRuntimeState(state);
  if (!validated.ok) throw new DomainValidationError(validated.issues);
  const declarations = [...content.entities, ...closure.worlds.flatMap(world => world.entities)].filter(adoptedRecord);
  for (const [id, value] of Object.entries(state.variableValues)) {
    const variable = declarations.find(entity => entity.id === id && entity.kind === 'variable');
    if (!variable || variable.kind !== 'variable') throw new DomainValidationError([{
      code: 'REFERENCE_INVALID',
      path: `state.variableValues.${id}`,
      message: '開始状態に対象版の宣言がない状態値があります。'
    }]);
    const issues = validateVariableValue(variable, value, `state.variableValues.${id}`);
    if (issues.length) throw new DomainValidationError(issues);
  }
  const ruleContext = presentationRuleContext(content, {
    sceneId: (_sequence$ = sequence[0]) === null || _sequence$ === void 0 ? void 0 : _sequence$.scene.id,
    worldTick
  });
  const exclusions = runtimeExclusionIssues({
    state,
    entities: content.entities,
    referenceEntities: closure.worlds.flatMap(world => world.entities),
    externalValues,
    ruleContext,
    ruleContexts: reuseRuleContexts(content, ruleContext)
  });
  if (exclusions.some(issue => issue.code !== 'CONDITION_UNKNOWN')) throw new DomainValidationError(exclusions);
  const chapterIds = chapterIdsOption ? [...chapterIdsOption] : [...new Set(sequence.flatMap(entry => entry.chapterId ? [entry.chapterId] : []))];
  return {
    content,
    declarationProject,
    contentVersionId: version,
    contentRevision: content.revision,
    contentHash: (_project$snapshots$fi = project.snapshots.find(item => item.id === version)) === null || _project$snapshots$fi === void 0 ? void 0 : _project$snapshots$fi.contentHash,
    startState: structuredClone(state),
    state,
    worldTick,
    chapterIds,
    sceneIds: sequence.map(entry => entry.scene.id),
    selection: requestedSelection !== null && requestedSelection !== void 0 ? requestedSelection : sceneIdsOption ? 'scenes' : 'chapters',
    occurrences: [],
    externalValues,
    referenceEntities: structuredClone(closure.worlds.flatMap(world => world.entities)),
    status: exclusions.length ? 'unknown' : sequence.length ? 'ready' : 'terminal',
    issues: exclusions
  };
}
export function presentChapterOccurrence(content, state, target) {
  const {
    sceneId,
    previousSceneId
  } = target;
  const from = presentationRuleContext(content, {
      sceneId: previousSceneId
    }),
    to = presentationRuleContext(content, {
      sceneId
    });
  const events = previousSceneId && previousSceneId !== sceneId ? ['scene_end'] : [];
  if (from.chapterId && from.chapterId !== to.chapterId) events.push('chapter_end');
  const reset = resetRuntimeLifecycle({
    ...state,
    ...(state.resetCauses ? {
      resetCauses: []
    } : {})
  }, events, {
    state,
    entities: content.entities,
    referenceEntities: target.referenceEntities,
    externalValues: target.externalValues,
    ruleContext: presentationRuleContext(content, {
      sceneId: target.previousSceneId,
      worldTick: target.worldTick
    }),
    ruleContexts: reuseRuleContexts(content, presentationRuleContext(content, {
      sceneId: target.previousSceneId,
      worldTick: target.worldTick
    }))
  });
  if (!reset.ok) return reset;
  const result = presentContent(content, reset.state, target);
  if (!result.ok) return result;
  if (target.last) {
    var _reset$state$resetCau, _ended$state$resetCau;
    const ended = resetRuntimeLifecycle(result.state, ['scene_end', 'chapter_end', 'run_end'], {
      state: result.state,
      entities: content.entities,
      referenceEntities: target.referenceEntities,
      externalValues: target.externalValues,
      ruleContext: presentationRuleContext(content, target),
      ruleContexts: reuseRuleContexts(content, presentationRuleContext(content, target))
    });
    if (!ended.ok) return ended;
    result.state = ended.state;
    if (reset.state.resetCauses || ended.state.resetCauses) result.state.resetCauses = [...((_reset$state$resetCau = reset.state.resetCauses) !== null && _reset$state$resetCau !== void 0 ? _reset$state$resetCau : []), ...((_ended$state$resetCau = ended.state.resetCauses) !== null && _ended$state$resetCau !== void 0 ? _ended$state$resetCau : [])];
  }
  return result;
}
export function presentNextChapterScene(project, session) {
  var _session$occurrences$;
  const versionIssue = capturedVersionIssue(project, session.contentVersionId, session.contentRevision, session.contentHash);
  if (versionIssue) return {
    ...session,
    status: 'error',
    issues: [{
      code: 'VALIDATION_FAILED',
      path: 'contentVersionId',
      message: versionIssue
    }]
  };
  const sceneId = session.sceneIds[session.occurrences.length];
  if (!sceneId) return session;
  const result = presentChapterOccurrence(session.content, session.state, {
    sceneId,
    worldTick: session.worldTick,
    previousSceneId: (_session$occurrences$ = session.occurrences.at(-1)) === null || _session$occurrences$ === void 0 ? void 0 : _session$occurrences$.entityId,
    last: session.occurrences.length + 1 === session.sceneIds.length,
    externalValues: session.externalValues,
    referenceEntities: session.referenceEntities
  });
  if (!result.ok) return {
    ...session,
    status: result.issues.some(issue => issue.code === 'CONDITION_UNKNOWN') ? 'unknown' : 'error',
    issues: result.issues
  };
  const occurrence = {
    entityId: sceneId,
    occurrenceId: `${sceneId}:${session.occurrences.length + 1}`,
    before: structuredClone(session.state),
    after: result.state,
    presentationState: result.observationState,
    conditionResults: result.conditions,
    externalValues: structuredClone(session.externalValues)
  };
  const occurrences = [...session.occurrences, occurrence];
  return {
    ...session,
    state: result.state,
    occurrences,
    status: occurrences.length === session.sceneIds.length ? 'terminal' : 'ready',
    issues: []
  };
}
export function backChapterReading(session) {
  const previous = session.occurrences.at(-1);
  if (!previous) return {
    ...session,
    status: session.sceneIds.length ? 'ready' : 'terminal',
    issues: []
  };
  return {
    ...session,
    state: structuredClone(previous.before),
    occurrences: session.occurrences.slice(0, -1),
    status: 'ready',
    issues: []
  };
}
export function pinChapterReadingRecord(session, ids, declarationProject = (_session$declarationP => (_session$declarationP = session.declarationProject) !== null && _session$declarationP !== void 0 ? _session$declarationP : session.content)()) {
  const stateForRecord = state => ({
    ...structuredClone(state),
    contentVersionId: ids.snapshotId
  });
  const readingPath = {
    chapterIds: [...session.chapterIds],
    sceneIds: [...session.sceneIds],
    ...(session.selection ? {
      selection: session.selection
    } : {}),
    occurrences: session.occurrences.map(occurrence => ({
      ...structuredClone(occurrence),
      before: stateForRecord(occurrence.before),
      after: stateForRecord(occurrence.after),
      ...(occurrence.presentationState ? {
        presentationState: stateForRecord(occurrence.presentationState)
      } : {})
    }))
  };
  const {
    snapshots: _snapshots,
    history: _history,
    authorAlternatives: _authorAlternatives,
    ...content
  } = reuseAuthorContent(session.content);
  const dialogue = active(session.content, 'dialogue_line'),
    scenes = active(session.content, 'scene');
  const pathTargets = new Set([...session.sceneIds, ...scenes.filter(scene => session.sceneIds.includes(scene.id)).flatMap(scene => {
    var _dialogueLineIds;
    return (_dialogueLineIds = scene.data.dialogueLineIds) !== null && _dialogueLineIds !== void 0 ? _dialogueLineIds : [];
  })]);
  const disclosed = active(session.content, 'disclosure').filter(disclosure => pathTargets.has(disclosure.data.anchor.entityId));
  const observations = session.occurrences.flatMap(occurrence => occurrence.conditionResults);
  return {
    content: structuredClone(content),
    checkpoint: {
      contentVersionId: ids.snapshotId,
      contentRevision: session.contentRevision,
      runtimeState: stateForRecord(session.startState),
      origin: 'partial',
      ...(session.worldTick !== undefined ? {
        worldTick: session.worldTick
      } : {})
    },
    trace: {
      ...(declaredRegressionPaths(declarationProject).ids.length ? {
        regressionDeclarations: {
          projectRevision: declarationProject.revision,
          traceIds: declaredRegressionPaths(declarationProject).ids
        }
      } : {}),
      contentVersionId: ids.snapshotId,
      contentRevision: session.contentRevision,
      startCheckpointId: ids.checkpointId,
      seed: session.startState.rngSeed,
      engineVersion: '1.0.0',
      ...(session.worldTick !== undefined ? {
        initialWorldTick: session.worldTick
      } : {}),
      initialExternalValues: structuredClone(session.externalValues),
      externalMode: Object.keys(session.externalValues).length ? 'stub' : null,
      steps: [],
      mode: 'chapters',
      readingPath,
      coverage: {
        scenes: {
          checked: new Set(session.occurrences.map(occurrence => occurrence.entityId)).size,
          total: scenes.length
        },
        dialogue: {
          checked: dialogue.filter(line => session.state.seenIds.includes(line.id)).length,
          total: dialogue.length
        },
        choices: {
          checked: 0,
          total: 0
        },
        conditionTrue: {
          checked: new Set(observations.filter(result => result.value === 'true').map(result => result.targetId)).size,
          total: disclosed.length
        },
        conditionFalse: {
          checked: new Set(observations.filter(result => result.value === 'false').map(result => result.targetId)).size,
          total: disclosed.length
        },
        declaredTests: regressionPathCoverage(declarationProject, {
          contentVersionId: session.contentVersionId,
          mode: 'chapters',
          steps: [],
          readingPath: {
            ...readingPath,
            occurrences: readingPath.occurrences.map(occurrence => ({
              ...occurrence,
              before: {
                ...occurrence.before,
                contentVersionId: session.contentVersionId
              },
              after: {
                ...occurrence.after,
                contentVersionId: session.contentVersionId
              },
              ...(occurrence.presentationState ? {
                presentationState: {
                  ...occurrence.presentationState,
                  contentVersionId: session.contentVersionId
                }
              } : {})
            }))
          }
        }, session.startState, session.status)
      }
    }
  };
}

/** Replays the captured scene occurrences; recorded assertions cannot substitute for actual execution. */
export async function replayChapterReading(project, trace, checkpoint, options = {}) {
  var _trace$readingPath$se, _ref4, _trace$initialWorldTi, _trace$initialExterna;
  if (trace.mode !== 'chapters' || !trace.readingPath || trace.steps.length || trace.contentVersionId !== checkpoint.contentVersionId) throw new DomainValidationError([{
    code: 'VALIDATION_FAILED',
    path: 'readingPath',
    message: '章読み通し記録の版または形式が一致しません。'
  }]);
  if (trace.initialWorldTick != null && checkpoint.worldTick != null && trace.initialWorldTick !== checkpoint.worldTick) throw new DomainValidationError([{
    code: 'INTEGRITY_FAILED',
    path: 'initialWorldTick',
    message: '章経路の提示時点と保存した開始時点が一致しません。'
  }]);
  let session = await startChapterReading(project, {
    contentVersionId: trace.contentVersionId,
    chapterIds: trace.readingPath.chapterIds,
    sceneIds: trace.readingPath.sceneIds,
    selection: (_trace$readingPath$se = trace.readingPath.selection) !== null && _trace$readingPath$se !== void 0 ? _trace$readingPath$se : 'scenes',
    state: checkpoint.runtimeState,
    worldTick: (_ref4 = (_trace$initialWorldTi = trace.initialWorldTick) !== null && _trace$initialWorldTi !== void 0 ? _trace$initialWorldTi : checkpoint.worldTick) !== null && _ref4 !== void 0 ? _ref4 : undefined,
    externalValues: (_trace$initialExterna = trace.initialExternalValues) !== null && _trace$initialExterna !== void 0 ? _trace$initialExterna : {},
    worldSnapshots: options.worldSnapshots
  });
  if (trace.contentRevision && trace.contentRevision !== session.contentRevision || checkpoint.contentRevision && checkpoint.contentRevision !== session.contentRevision) throw new DomainValidationError([{
    code: 'VALIDATION_FAILED',
    path: 'contentRevision',
    message: '記録した開始状態と内容版の更新番号が違います。'
  }]);
  const seen = new Set();
  for (const [index, occurrence] of trace.readingPath.occurrences.entries()) {
    if (seen.has(occurrence.occurrenceId) || occurrence.entityId !== trace.readingPath.sceneIds[index] || canonicalJson(session.state) !== canonicalJson(occurrence.before)) throw new DomainValidationError([{
      code: 'INTEGRITY_FAILED',
      path: `readingPath.occurrences[${index}]`,
      message: '読み通しの順序・開始状態または提示識別子が一致しません。'
    }]);
    seen.add(occurrence.occurrenceId);
    session = presentNextChapterScene(project, session);
    const observed = session.occurrences.at(-1);
    if (occurrence.presentationState && (!(observed !== null && observed !== void 0 && observed.presentationState) || canonicalJson(observed.presentationState) !== canonicalJson(occurrence.presentationState))) throw new DomainValidationError([{
      code: 'INTEGRITY_FAILED',
      path: `readingPath.occurrences[${index}].presentationState`,
      message: '提示前の観測状態と再実行が一致しません。'
    }]);
    if (!observed || canonicalJson(observed.after) !== canonicalJson(occurrence.after) || canonicalJson(observed.conditionResults) !== canonicalJson(occurrence.conditionResults)) throw new DomainValidationError([{
      code: 'INTEGRITY_FAILED',
      path: `readingPath.occurrences[${index}]`,
      message: '記録された提示根拠と再実行が一致しません。'
    }]);
    // This is an opaque, captured occurrence identity, not a reference to the
    // scene embedded in its historical text. Cloning remaps entityId separately.
    // Keep it only after the independently executed states and observations match.
    observed.occurrenceId = occurrence.occurrenceId;
  }
  return session;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ2YWxpZGF0ZVJ1bnRpbWVTdGF0ZSIsInZhbGlkYXRlVmFyaWFibGVWYWx1ZSIsImFwcGx5RWZmZWN0c0F0b21pYyIsIkRvbWFpblZhbGlkYXRpb25FcnJvciIsImV2YWx1YXRlQ29uZGl0aW9uIiwiaW5pdGlhbGl6ZVJ1bnRpbWVTdGF0ZSIsInJlc2V0UnVudGltZUxpZmVjeWNsZSIsInJ1bnRpbWVFeGNsdXNpb25Jc3N1ZXMiLCJidWlsZENoYXB0ZXJSZWFkaW5nU2VxdWVuY2UiLCJjYXB0dXJlUnVudGltZUNvbnRlbnQiLCJjYXB0dXJlZFZlcnNpb25Jc3N1ZSIsImNhbm9uaWNhbEpzb24iLCJ2YWxpZGF0ZUV4dGVybmFsSW5wdXQiLCJyZXNvbHZlUGlubmVkV29ybGRzIiwiYWRvcHRlZFJlY29yZCIsImV2YWx1YXRlVGFyZ2V0U2NvcGUiLCJkZWNsYXJlZFJlZ3Jlc3Npb25QYXRocyIsInJlZ3Jlc3Npb25QYXRoQ292ZXJhZ2UiLCJpc1RpY2siLCJyZXNvbHZlUmV1c2VDb250ZW50IiwicmV1c2VBdXRob3JDb250ZW50IiwicmV1c2VPcmlnaW4iLCJyZXVzZVJ1bGVDb250ZXh0cyIsInJldXNlRXhlY3V0aW9uQW5jaG9yIiwiY2hlY2tQcmVzZW50YXRpb25Gb3Jlc2hhZG93cyIsImFjdGl2ZSIsInByb2plY3QiLCJraW5kIiwiZW50aXRpZXMiLCJmaWx0ZXIiLCJlbnRpdHkiLCJwcm9ibGVtIiwicGF0aCIsIm1lc3NhZ2UiLCJjb2RlIiwib2siLCJpc3N1ZXMiLCJwcmVzZW50YXRpb25SdWxlQ29udGV4dCIsInRhcmdldCIsIl9hY3RpdmUkZmluZCIsIl9zY2VuZSRkYXRhJGNoYXB0ZXJJZCIsIl9hY3RpdmUkZmluZDIiLCJub2RlIiwiZmluZCIsIml0ZW0iLCJpZCIsIm5vZGVJZCIsInNjZW5lIiwiX3RhcmdldCRzY2VuZUlkIiwic2NlbmVJZCIsImRhdGEiLCJwcm9qZWN0SWQiLCJ3b3JsZFRpY2siLCJncmFwaElkIiwiZ3JhcGgiLCJub2RlSWRzIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJjaGFwdGVySWQiLCJjaGFwdGVyIiwic2NlbmVJZHMiLCJwcmVzZW50YXRpb25MaW5lSWRzIiwiX25vZGUkZGF0YSRleGVjdXRpb25QIiwiX3NjZW5lJGRhdGEkZGlhbG9ndWVMIiwiX3RhcmdldCRzY2VuZUlkMiIsInBvbGljeSIsImV4ZWN1dGlvblBvbGljeSIsIm5vZGVUeXBlIiwiU2V0IiwiZGlhbG9ndWVMaW5lSWRzIiwiZWRnZSIsImZyb21JZCIsImZsYXRNYXAiLCJjaG9pY2VMaW5lSWQiLCJwcmVzZW50YXRpb25BbmNob3JBcHBsaWVzIiwic3RhdGUiLCJhbmNob3IiLCJkZWNsYXJhdGlvbklkIiwiX3JldXNlT3JpZ2luIiwiX3RhcmdldCRzY2VuZUlkMyIsInBvc2l0aW9uU3RhdHVzIiwiZGVjbGFyYXRpb24iLCJzb3VyY2VWZXJzaW9uSWQiLCJjb250ZW50VmVyc2lvbklkIiwiZW50aXR5SWQiLCJsaW5lcyIsImJsb2NrSWQiLCJsaW5lSWQiLCJldmVyeSIsInNlZW5JZHMiLCJwcmVzZW50YXRpb25BbmNob3JPcmRlciIsImxlZnQiLCJyaWdodCIsIl9zY2VuZSRkYXRhJGJvZHkiLCJfcmVmIiwiX2xlZnQkYmxvY2tJZCIsIl9yZWYyIiwiX3JpZ2h0JGJsb2NrSWQiLCJfdGFyZ2V0JHNjZW5lSWQ0IiwibGluZUlkcyIsInBvc2l0aW9ucyIsImJvZHkiLCJtYXAiLCJibG9jayIsIl9hY3RpdmUkZmluZCRkYXRhJHRleCIsIl9hY3RpdmUkZmluZDMiLCJwdXNoIiwibGluZSIsInRleHQiLCJsZWZ0QmxvY2siLCJyaWdodEJsb2NrIiwiZmlyc3QiLCJpbmRleE9mIiwic2Vjb25kIiwic3RhcnQiLCJlbmQiLCJwcmVzZW50Q29udGVudCIsIl90YXJnZXQkZXh0ZXJuYWxWYWx1ZSIsImNoZWNrZWQiLCJleHRlcm5hbElzc3VlcyIsImV4dGVybmFsVmFsdWVzIiwicmVmZXJlbmNlRW50aXRpZXMiLCJsZW5ndGgiLCJfcmVmMyIsIl90YXJnZXQkc2NlbmVJZDUiLCJfdGFyZ2V0JHJlZmVyZW5jZUVudGkiLCJpbml0aWFsQ29udGV4dCIsImluaXRpYWxJc3N1ZXMiLCJydWxlQ29udGV4dCIsInJ1bGVDb250ZXh0cyIsInJlc29sdmVkIiwibmV4dCIsInN0cnVjdHVyZWRDbG9uZSIsInNlZW4iLCJfbmV4dCR2aXNpdENvdW50cyRub2QiLCJwcmVzZW50YXRpb25Qb3NpdGlvbiIsInZpc2l0Q291bnRzIiwiYWRkIiwiX25leHQkdmlzaXRDb3VudHMkc2NlIiwiX3NjZW5lJGRhdGEkYmxvY2tJZHMiLCJibG9ja0lkcyIsIl9ub2RlJGlkIiwiX25leHQkdmlzaXRDb3VudHMkbGluIiwidmFyaWFibGVzIiwiY29udGV4dCIsImNvbmRpdGlvbnMiLCJkaXNjbG9zdXJlcyIsImRpc2Nsb3N1cmUiLCJfY29udGV4dCRydWxlQ29udGV4dHMiLCJfcmV1c2VPcmlnaW4yIiwiX3JldXNlT3JpZ2luMyIsIl9kaXNjbG9zdXJlJGRhdGEkY29uZCIsIl9zY29wZSRyb3V0ZUNvbmRpdGlvbiIsInNjb3BlIiwidGFyZ2V0U2NvcGUiLCJkaXNjbG9zdXJlQ29udGV4dCIsInNjb3BlUmVzdWx0IiwidmFsdWUiLCJwb3NpdGlvblJlYXNvbiIsInJlc3VsdCIsIm9wIiwiY2hpbGRyZW4iLCJjb25kaXRpb24iLCJyb3V0ZUNvbmRpdGlvbiIsInRhcmdldElkIiwicmVhc29ucyIsImpvaW4iLCJvcmRlcmVkIiwiX2Rpc2Nsb3N1cmUkZGF0YSRrbm93IiwiX2Rpc2Nsb3N1cmUkZGF0YSRrbm93MiIsImtub3dsZWRnZUVmZmVjdHMiLCJpIiwiaiIsIl9ub2RlJGlkMiIsInNvcnQiLCJlZmZlY3RzIiwiZWZmZWN0UHJlc2VudGF0aW9ucyIsImVmZmVjdElkIiwiX2Rpc2Nsb3N1cmUkZGF0YSRrbm93MyIsIl90YXJnZXQkcmVmZXJlbmNlRW50aTIiLCJlZmZlY3QiLCJhcHBsaWVkIiwib2JzZXJ2YXRpb25TdGF0ZSIsImVycm9yIiwiRXJyb3IiLCJjaGFwdGVyTmFycmF0aXZlT2NjdXJyZW5jZXMiLCJzZXNzaW9uIiwib2NjdXJyZW5jZXMiLCJvY2N1cnJlbmNlIiwiX29jY3VycmVuY2UkcHJlc2VudGF0IiwiX29jY3VycmVuY2UkZXh0ZXJuYWxWIiwiYWZ0ZXIiLCJwcmVzZW50YXRpb25TdGF0ZSIsImNvbmRpdGlvblJlc3VsdHMiLCJjaGVja0NoYXB0ZXJGb3Jlc2hhZG93cyIsImNvbnRlbnQiLCJzdGFydFN0YXRlIiwic3RhdHVzIiwic3RhcnRDaGFwdGVyUmVhZGluZyIsIm9wdGlvbnMiLCJfb3B0aW9ucyRleHRlcm5hbFZhbHUiLCJfb3B0aW9ucyRjb250ZW50VmVyc2kiLCJfc2VxdWVuY2UkIiwiX3Byb2plY3Qkc25hcHNob3RzJGZpIiwiZGVjbGFyYXRpb25Qcm9qZWN0IiwiaGlzdG9yeSIsInNuYXBzaG90cyIsImF1dGhvckFsdGVybmF0aXZlcyIsInJlcXVlc3RlZFNlbGVjdGlvbiIsInNlbGVjdGlvbiIsIndvcmxkU25hcHNob3RzIiwiY2hhcHRlcklkc09wdGlvbiIsImNoYXB0ZXJJZHMiLCJzY2VuZUlkc09wdGlvbiIsInJlcXVlc3RlZFN0YXRlIiwidmVyc2lvbiIsImNhcHR1cmVkIiwiY2xvc3VyZSIsImVycm9ycyIsIndvcmxkcyIsIndvcmxkIiwic29tZSIsInNlcXVlbmNlIiwicHJvdmVuYW5jZSIsInZhbGlkYXRlZCIsImRlY2xhcmF0aW9ucyIsIk9iamVjdCIsImVudHJpZXMiLCJ2YXJpYWJsZVZhbHVlcyIsInZhcmlhYmxlIiwiZXhjbHVzaW9ucyIsImlzc3VlIiwiZW50cnkiLCJjb250ZW50UmV2aXNpb24iLCJyZXZpc2lvbiIsImNvbnRlbnRIYXNoIiwicHJlc2VudENoYXB0ZXJPY2N1cnJlbmNlIiwicHJldmlvdXNTY2VuZUlkIiwiZnJvbSIsInRvIiwiZXZlbnRzIiwicmVzZXQiLCJyZXNldENhdXNlcyIsImxhc3QiLCJfcmVzZXQkc3RhdGUkcmVzZXRDYXUiLCJfZW5kZWQkc3RhdGUkcmVzZXRDYXUiLCJlbmRlZCIsInByZXNlbnROZXh0Q2hhcHRlclNjZW5lIiwiX3Nlc3Npb24kb2NjdXJyZW5jZXMkIiwidmVyc2lvbklzc3VlIiwiYXQiLCJvY2N1cnJlbmNlSWQiLCJiZWZvcmUiLCJiYWNrQ2hhcHRlclJlYWRpbmciLCJwcmV2aW91cyIsInNsaWNlIiwicGluQ2hhcHRlclJlYWRpbmdSZWNvcmQiLCJpZHMiLCJfc2Vzc2lvbiRkZWNsYXJhdGlvblAiLCJzdGF0ZUZvclJlY29yZCIsInNuYXBzaG90SWQiLCJyZWFkaW5nUGF0aCIsIl9zbmFwc2hvdHMiLCJfaGlzdG9yeSIsIl9hdXRob3JBbHRlcm5hdGl2ZXMiLCJkaWFsb2d1ZSIsInNjZW5lcyIsInBhdGhUYXJnZXRzIiwiX2RpYWxvZ3VlTGluZUlkcyIsImRpc2Nsb3NlZCIsImhhcyIsIm9ic2VydmF0aW9ucyIsImNoZWNrcG9pbnQiLCJydW50aW1lU3RhdGUiLCJvcmlnaW4iLCJ0cmFjZSIsInJlZ3Jlc3Npb25EZWNsYXJhdGlvbnMiLCJwcm9qZWN0UmV2aXNpb24iLCJ0cmFjZUlkcyIsInN0YXJ0Q2hlY2twb2ludElkIiwiY2hlY2twb2ludElkIiwic2VlZCIsInJuZ1NlZWQiLCJlbmdpbmVWZXJzaW9uIiwiaW5pdGlhbFdvcmxkVGljayIsImluaXRpYWxFeHRlcm5hbFZhbHVlcyIsImV4dGVybmFsTW9kZSIsImtleXMiLCJzdGVwcyIsIm1vZGUiLCJjb3ZlcmFnZSIsInNpemUiLCJ0b3RhbCIsImNob2ljZXMiLCJjb25kaXRpb25UcnVlIiwiY29uZGl0aW9uRmFsc2UiLCJkZWNsYXJlZFRlc3RzIiwicmVwbGF5Q2hhcHRlclJlYWRpbmciLCJfdHJhY2UkcmVhZGluZ1BhdGgkc2UiLCJfcmVmNCIsIl90cmFjZSRpbml0aWFsV29ybGRUaSIsIl90cmFjZSRpbml0aWFsRXh0ZXJuYSIsImluZGV4Iiwib2JzZXJ2ZWQiXSwic291cmNlcyI6WyJwcmVzZW50YXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDaGVja3BvaW50RGF0YSwgQ29udGVudEFuY2hvciwgRW50aXR5LCBJRCwgUHJlc2VudGF0aW9uQ29uZGl0aW9uUmVzdWx0LCBQcm9qZWN0Q29udGVudCwgUHJvamVjdERhdGEsIFJ1bnRpbWVDb250ZXh0LCBSdW50aW1lU3RhdGUsIFRyYWNlRGF0YSwgVHlwZWRWYWx1ZSwgVmFsaWRhdGlvbklzc3VlIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyB2YWxpZGF0ZVJ1bnRpbWVTdGF0ZSwgdmFsaWRhdGVWYXJpYWJsZVZhbHVlIH0gZnJvbSAnLi9tb2RlbCc7XG5pbXBvcnQgeyBhcHBseUVmZmVjdHNBdG9taWMsIERvbWFpblZhbGlkYXRpb25FcnJvciwgZXZhbHVhdGVDb25kaXRpb24sIGluaXRpYWxpemVSdW50aW1lU3RhdGUsIHJlc2V0UnVudGltZUxpZmVjeWNsZSwgcnVudGltZUV4Y2x1c2lvbklzc3VlcyB9IGZyb20gJy4vY29uZGl0aW9ucyc7XG5pbXBvcnQgeyBidWlsZENoYXB0ZXJSZWFkaW5nU2VxdWVuY2UgfSBmcm9tICcuL3dyaXRpbmdXb3Jrc3BhY2UnO1xuaW1wb3J0IHsgY2FwdHVyZVJ1bnRpbWVDb250ZW50LCBjYXB0dXJlZFZlcnNpb25Jc3N1ZSB9IGZyb20gJy4vcnVudGltZVZlcnNpb25zJztcbmltcG9ydCB0eXBlIHsgUHJlc2VudGF0aW9uT2NjdXJyZW5jZSwgUmVhZGluZ1BhdGgsIFJ1bnRpbWVUcmFjZUV4dGVuc2lvbnMgfSBmcm9tICcuL3J1bnRpbWVDb250cmFjdHMnO1xuaW1wb3J0IHsgY2Fub25pY2FsSnNvbiB9IGZyb20gJy4uL3N0b3JhZ2UvanNvbic7XG5pbXBvcnQgeyB2YWxpZGF0ZUV4dGVybmFsSW5wdXQgfSBmcm9tICcuL2V4dGVybmFsSW5wdXRzJztcbmltcG9ydCB7IHJlc29sdmVQaW5uZWRXb3JsZHMgfSBmcm9tICcuL3Bpbm5lZFdvcmxkcyc7XG5pbXBvcnQgdHlwZSB7IFByb2plY3RWYWxpZGF0aW9uT3B0aW9ucyB9IGZyb20gJy4vbW9kZWwnO1xuaW1wb3J0IHsgYWRvcHRlZFJlY29yZCB9IGZyb20gJy4vYWRvcHRpb24nO1xuaW1wb3J0IHsgZXZhbHVhdGVUYXJnZXRTY29wZSB9IGZyb20gJy4vc3RhdGVSdWxlcyc7XG5pbXBvcnQgeyBkZWNsYXJlZFJlZ3Jlc3Npb25QYXRocywgcmVncmVzc2lvblBhdGhDb3ZlcmFnZSB9IGZyb20gJy4vcmVncmVzc2lvblBhdGhzJztcbmltcG9ydCB7IGlzVGljayB9IGZyb20gJy4vdGltZSc7XG5pbXBvcnQgeyByZXNvbHZlUmV1c2VDb250ZW50LCByZXVzZUF1dGhvckNvbnRlbnQsIHJldXNlT3JpZ2luLCByZXVzZVJ1bGVDb250ZXh0cywgcmV1c2VFeGVjdXRpb25BbmNob3IgfSBmcm9tICcuL3JldXNlJztcbmltcG9ydCB7IGNoZWNrUHJlc2VudGF0aW9uRm9yZXNoYWRvd3MsIHR5cGUgTmFycmF0aXZlT2NjdXJyZW5jZSB9IGZyb20gJy4vbmFycmF0aXZlJztcblxuZXhwb3J0IGludGVyZmFjZSBQcmVzZW50YXRpb25UYXJnZXQgeyBub2RlSWQ/OiBJRDsgc2NlbmVJZD86IElEOyB3b3JsZFRpY2s/OiBzdHJpbmc7IGV4dGVybmFsVmFsdWVzPzogUmVjb3JkPElELCBUeXBlZFZhbHVlPjsgcmVmZXJlbmNlRW50aXRpZXM/OiBFbnRpdHlbXSB9XG5leHBvcnQgdHlwZSBDb250ZW50UHJlc2VudGF0aW9uID0geyBvazogdHJ1ZTsgc3RhdGU6IFJ1bnRpbWVTdGF0ZTsgb2JzZXJ2YXRpb25TdGF0ZTogUnVudGltZVN0YXRlOyBjb25kaXRpb25zOiBQcmVzZW50YXRpb25Db25kaXRpb25SZXN1bHRbXSB9IHwgeyBvazogZmFsc2U7IGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10gfTtcbmNvbnN0IGFjdGl2ZSA9IDxLIGV4dGVuZHMgRW50aXR5WydraW5kJ10+KHByb2plY3Q6IFByb2plY3REYXRhLCBraW5kOiBLKTogRW50aXR5PEs+W10gPT4gcHJvamVjdC5lbnRpdGllcy5maWx0ZXIoKGVudGl0eSk6IGVudGl0eSBpcyBFbnRpdHk8Sz4gPT4gZW50aXR5LmtpbmQgPT09IGtpbmQgJiYgYWRvcHRlZFJlY29yZChlbnRpdHkpKTtcbmNvbnN0IHByb2JsZW0gPSAocGF0aDogc3RyaW5nLCBtZXNzYWdlOiBzdHJpbmcsIGNvZGU6IFZhbGlkYXRpb25Jc3N1ZVsnY29kZSddID0gJ1JFRkVSRU5DRV9JTlZBTElEJyk6IENvbnRlbnRQcmVzZW50YXRpb24gPT4gKHsgb2s6IGZhbHNlLCBpc3N1ZXM6IFt7IGNvZGUsIHBhdGgsIG1lc3NhZ2UgfV0gfSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBwcmVzZW50YXRpb25SdWxlQ29udGV4dChwcm9qZWN0OiBQcm9qZWN0RGF0YSwgdGFyZ2V0OiBQcmVzZW50YXRpb25UYXJnZXQpOiBOb25OdWxsYWJsZTxSdW50aW1lQ29udGV4dFsncnVsZUNvbnRleHQnXT4ge1xuICBjb25zdCBub2RlID0gYWN0aXZlKHByb2plY3QsICdmbG93X25vZGUnKS5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gdGFyZ2V0Lm5vZGVJZCk7XG4gIGNvbnN0IHNjZW5lID0gYWN0aXZlKHByb2plY3QsICdzY2VuZScpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSAodGFyZ2V0LnNjZW5lSWQgPz8gbm9kZT8uZGF0YS5zY2VuZUlkKSk7XG4gIHJldHVybiB7IHByb2plY3RJZDogcHJvamVjdC5wcm9qZWN0SWQsIHdvcmxkVGljazogdGFyZ2V0LndvcmxkVGljaywgZ3JhcGhJZDogbm9kZSA/IGFjdGl2ZShwcm9qZWN0LCAnZmxvd19ncmFwaCcpLmZpbmQoZ3JhcGggPT4gZ3JhcGguZGF0YS5ub2RlSWRzLmluY2x1ZGVzKG5vZGUuaWQpKT8uaWQgOiB1bmRlZmluZWQsIGNoYXB0ZXJJZDogc2NlbmU/LmRhdGEuY2hhcHRlcklkID8/IChzY2VuZSA/IGFjdGl2ZShwcm9qZWN0LCAnY2hhcHRlcicpLmZpbmQoY2hhcHRlciA9PiBjaGFwdGVyLmRhdGEuc2NlbmVJZHMuaW5jbHVkZXMoc2NlbmUuaWQpKT8uaWQgOiB1bmRlZmluZWQpIH07XG59XG5cbi8qKiBDaG9pY2UgdGV4dCBpcyBwcmVzZW50ZWQgb25seSBieSBhIG1hbnVhbCBjaG9pY2UsIGluY2x1ZGluZyBkaXNhYmxlZCBjYW5kaWRhdGVzIHNob3duIHRvIHRoZSBhdXRob3IuICovXG5leHBvcnQgZnVuY3Rpb24gcHJlc2VudGF0aW9uTGluZUlkcyhwcm9qZWN0OiBQcm9qZWN0RGF0YSwgdGFyZ2V0OiBQcmVzZW50YXRpb25UYXJnZXQpOiBJRFtdIHtcbiAgY29uc3Qgbm9kZSA9IGFjdGl2ZShwcm9qZWN0LCAnZmxvd19ub2RlJykuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IHRhcmdldC5ub2RlSWQpO1xuICBjb25zdCBzY2VuZSA9IGFjdGl2ZShwcm9qZWN0LCAnc2NlbmUnKS5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gKHRhcmdldC5zY2VuZUlkID8/IG5vZGU/LmRhdGEuc2NlbmVJZCkpO1xuICBjb25zdCBwb2xpY3kgPSBub2RlPy5kYXRhLmV4ZWN1dGlvblBvbGljeSA/PyAobm9kZT8uZGF0YS5ub2RlVHlwZSA9PT0gJ2F1dG9tYXRpYycgPyAnZmlyc3RfbWF0Y2gnIDogJ21hbnVhbF9jaG9pY2UnKTtcbiAgcmV0dXJuIFsuLi5uZXcgU2V0KFsuLi4oc2NlbmU/LmRhdGEuZGlhbG9ndWVMaW5lSWRzID8/IFtdKSwgLi4uKG5vZGUgJiYgcG9saWN5ID09PSAnbWFudWFsX2Nob2ljZScgPyBhY3RpdmUocHJvamVjdCwgJ2Zsb3dfZWRnZScpLmZpbHRlcihlZGdlID0+IGVkZ2UuZGF0YS5mcm9tSWQgPT09IG5vZGUuaWQpLmZsYXRNYXAoZWRnZSA9PiBlZGdlLmRhdGEuY2hvaWNlTGluZUlkID8gW2VkZ2UuZGF0YS5jaG9pY2VMaW5lSWRdIDogW10pIDogW10pXSldO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcHJlc2VudGF0aW9uQW5jaG9yQXBwbGllcyhwcm9qZWN0OiBQcm9qZWN0RGF0YSwgc3RhdGU6IFJ1bnRpbWVTdGF0ZSwgYW5jaG9yOiBDb250ZW50QW5jaG9yLCB0YXJnZXQ6IFByZXNlbnRhdGlvblRhcmdldCwgZGVjbGFyYXRpb25JZD86IElEKTogYm9vbGVhbiB7XG4gIGlmIChhbmNob3IucG9zaXRpb25TdGF0dXMgPT09ICd1bnJlc29sdmVkJykgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBkZWNsYXJhdGlvbiA9IGRlY2xhcmF0aW9uSWQgPyByZXVzZU9yaWdpbihwcm9qZWN0LCBkZWNsYXJhdGlvbklkKSA6IHVuZGVmaW5lZDtcbiAgaWYgKGFuY2hvci5zb3VyY2VWZXJzaW9uSWQgJiYgIVtwcm9qZWN0LnByb2plY3RJZCwgc3RhdGUuY29udGVudFZlcnNpb25JZCwgcmV1c2VPcmlnaW4ocHJvamVjdCwgYW5jaG9yLmVudGl0eUlkKT8uc291cmNlVmVyc2lvbklkLCBkZWNsYXJhdGlvbj8uc291cmNlVmVyc2lvbklkXS5pbmNsdWRlcyhhbmNob3Iuc291cmNlVmVyc2lvbklkKSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBub2RlID0gYWN0aXZlKHByb2plY3QsICdmbG93X25vZGUnKS5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gdGFyZ2V0Lm5vZGVJZCk7XG4gIGNvbnN0IHNjZW5lSWQgPSB0YXJnZXQuc2NlbmVJZCA/PyBub2RlPy5kYXRhLnNjZW5lSWQ7XG4gIGNvbnN0IHNjZW5lID0gYWN0aXZlKHByb2plY3QsICdzY2VuZScpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBzY2VuZUlkKTtcbiAgY29uc3QgbGluZXMgPSBwcmVzZW50YXRpb25MaW5lSWRzKHByb2plY3QsIHRhcmdldCk7XG4gIGlmICghW3RhcmdldC5ub2RlSWQsIHNjZW5lSWQsIC4uLmxpbmVzXS5pbmNsdWRlcyhhbmNob3IuZW50aXR5SWQpKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBbYW5jaG9yLmVudGl0eUlkLCBhbmNob3IuYmxvY2tJZCwgYW5jaG9yLmxpbmVJZF0uZmlsdGVyKChpZCk6IGlkIGlzIElEID0+ICEhaWQpLmV2ZXJ5KGlkID0+IHN0YXRlLnNlZW5JZHMuaW5jbHVkZXMoaWQpKTtcbn1cblxuLyoqIFJlYWRpbmcgb3JkZXIgaXMgYmxvY2svbGluZSBvcmRlciBhbmQgY29kZS1wb2ludCBwb3NpdGlvbiwgbmV2ZXIgZXZlbnQvd29ybGQtZGF0ZSBvcmRlci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmVzZW50YXRpb25BbmNob3JPcmRlcihwcm9qZWN0OiBQcm9qZWN0RGF0YSwgbGVmdDogQ29udGVudEFuY2hvciwgcmlnaHQ6IENvbnRlbnRBbmNob3IsIHRhcmdldDogUHJlc2VudGF0aW9uVGFyZ2V0KTogYm9vbGVhbiB8IHVuZGVmaW5lZCB7XG4gIGlmIChsZWZ0LnBvc2l0aW9uU3RhdHVzID09PSAndW5yZXNvbHZlZCcgfHwgcmlnaHQucG9zaXRpb25TdGF0dXMgPT09ICd1bnJlc29sdmVkJykgcmV0dXJuIHVuZGVmaW5lZDtcbiAgY29uc3Qgbm9kZSA9IGFjdGl2ZShwcm9qZWN0LCAnZmxvd19ub2RlJykuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IHRhcmdldC5ub2RlSWQpO1xuICBjb25zdCBzY2VuZSA9IGFjdGl2ZShwcm9qZWN0LCAnc2NlbmUnKS5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gKHRhcmdldC5zY2VuZUlkID8/IG5vZGU/LmRhdGEuc2NlbmVJZCkpO1xuICBjb25zdCBsaW5lSWRzID0gcHJlc2VudGF0aW9uTGluZUlkcyhwcm9qZWN0LCB0YXJnZXQpO1xuICBjb25zdCBwb3NpdGlvbnMgPSBbLi4uKHNjZW5lPy5kYXRhLmJvZHkgPz8gW10pLm1hcChibG9jayA9PiBibG9jay5pZCldO1xuICBmb3IgKGNvbnN0IGxpbmVJZCBvZiBsaW5lSWRzKSBwb3NpdGlvbnMucHVzaChsaW5lSWQsIC4uLihhY3RpdmUocHJvamVjdCwgJ2RpYWxvZ3VlX2xpbmUnKS5maW5kKGxpbmUgPT4gbGluZS5pZCA9PT0gbGluZUlkKT8uZGF0YS50ZXh0ID8/IFtdKS5tYXAoYmxvY2sgPT4gYmxvY2suaWQpKTtcbiAgY29uc3QgbGVmdEJsb2NrID0gbGVmdC5ibG9ja0lkID8/IGxlZnQubGluZUlkID8/IChsaW5lSWRzLmluY2x1ZGVzKGxlZnQuZW50aXR5SWQpID8gbGVmdC5lbnRpdHlJZCA6IHVuZGVmaW5lZCk7XG4gIGNvbnN0IHJpZ2h0QmxvY2sgPSByaWdodC5ibG9ja0lkID8/IHJpZ2h0LmxpbmVJZCA/PyAobGluZUlkcy5pbmNsdWRlcyhyaWdodC5lbnRpdHlJZCkgPyByaWdodC5lbnRpdHlJZCA6IHVuZGVmaW5lZCk7XG4gIGNvbnN0IGZpcnN0ID0gcG9zaXRpb25zLmluZGV4T2YobGVmdEJsb2NrID8/ICcnKSwgc2Vjb25kID0gcG9zaXRpb25zLmluZGV4T2YocmlnaHRCbG9jayA/PyAnJyk7XG4gIGlmIChmaXJzdCA+PSAwICYmIHNlY29uZCA+PSAwICYmIGZpcnN0ICE9PSBzZWNvbmQpIHJldHVybiBmaXJzdCA8IHNlY29uZDtcbiAgaWYgKGxlZnRCbG9jayAhPT0gcmlnaHRCbG9jayB8fCBsZWZ0LmVudGl0eUlkICE9PSByaWdodC5lbnRpdHlJZCB8fCBsZWZ0LnN0YXJ0ID09IG51bGwgfHwgcmlnaHQuc3RhcnQgPT0gbnVsbCB8fCBsZWZ0LnN0YXJ0ID09PSByaWdodC5zdGFydCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKGxlZnQuc3RhcnQgPCByaWdodC5zdGFydCAmJiBsZWZ0LmVuZCAhPSBudWxsICYmIGxlZnQuZW5kID4gcmlnaHQuc3RhcnQgfHwgcmlnaHQuc3RhcnQgPCBsZWZ0LnN0YXJ0ICYmIHJpZ2h0LmVuZCAhPSBudWxsICYmIHJpZ2h0LmVuZCA+IGxlZnQuc3RhcnQpIHJldHVybiB1bmRlZmluZWQ7XG4gIHJldHVybiBsZWZ0LnN0YXJ0IDwgcmlnaHQuc3RhcnQ7XG59XG5cbi8qKiBTaGFyZWQgYXRvbWljIGFycml2YWwgZm9yIGZsb3cgYW5kIGNoYXB0ZXIgcHJlc2VudGF0aW9uLiBDb25kaXRpb25zIHByZWNlZGUgZXZlcnkgZGlzY2xvc3VyZSBlZmZlY3QuICovXG5leHBvcnQgZnVuY3Rpb24gcHJlc2VudENvbnRlbnQocHJvamVjdDogUHJvamVjdERhdGEsIHN0YXRlOiBSdW50aW1lU3RhdGUsIHRhcmdldDogUHJlc2VudGF0aW9uVGFyZ2V0KTogQ29udGVudFByZXNlbnRhdGlvbiB7XG4gIGNvbnN0IGNoZWNrZWQgPSB2YWxpZGF0ZVJ1bnRpbWVTdGF0ZShzdGF0ZSk7IGlmICghY2hlY2tlZC5vaykgcmV0dXJuIHsgb2s6IGZhbHNlLCBpc3N1ZXM6IGNoZWNrZWQuaXNzdWVzIH07XG4gIGNvbnN0IGV4dGVybmFsSXNzdWVzID0gdmFsaWRhdGVFeHRlcm5hbElucHV0KHByb2plY3QsIHRhcmdldC5leHRlcm5hbFZhbHVlcyA/PyB7fSwgdW5kZWZpbmVkLCB0YXJnZXQucmVmZXJlbmNlRW50aXRpZXMpOyBpZiAoZXh0ZXJuYWxJc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogZXh0ZXJuYWxJc3N1ZXMgfTtcbiAgdHJ5IHtcbiAgICBjb25zdCBub2RlID0gdGFyZ2V0Lm5vZGVJZCA/IGFjdGl2ZShwcm9qZWN0LCAnZmxvd19ub2RlJykuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IHRhcmdldC5ub2RlSWQpIDogdW5kZWZpbmVkO1xuICAgIGlmICh0YXJnZXQubm9kZUlkICYmICFub2RlKSByZXR1cm4gcHJvYmxlbSgncHJlc2VudGF0aW9uLm5vZGVJZCcsICfmj5DnpLrjgZnjgovliIblspDjgYzlrZjlnKjjgZfjgarjgYTjgYvjgIHliYrpmaTjg7vkuI3mjqHnlKjjgafjgZnjgIInKTtcbiAgICBjb25zdCBzY2VuZUlkID0gdGFyZ2V0LnNjZW5lSWQgPz8gbm9kZT8uZGF0YS5zY2VuZUlkID8/IHVuZGVmaW5lZDtcbiAgICBpZiAoIW5vZGUgJiYgIXNjZW5lSWQpIHJldHVybiBwcm9ibGVtKCdwcmVzZW50YXRpb24nLCAn5o+Q56S644GZ44KL5aC06Z2i44G+44Gf44Gv5YiG5bKQ44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgY29uc3Qgc2NlbmUgPSBzY2VuZUlkID8gYWN0aXZlKHByb2plY3QsICdzY2VuZScpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBzY2VuZUlkKSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoc2NlbmVJZCAmJiAhc2NlbmUpIHJldHVybiBwcm9ibGVtKCdwcmVzZW50YXRpb24uc2NlbmVJZCcsICfmj5DnpLrjgZnjgovloLTpnaLjgYzlrZjlnKjjgZfjgarjgYTjgYvjgIHliYrpmaTjg7vkuI3mjqHnlKjjgafjgZnjgIInKTtcbiAgICBjb25zdCBpbml0aWFsQ29udGV4dCA9IHByZXNlbnRhdGlvblJ1bGVDb250ZXh0KHByb2plY3QsIHsgLi4udGFyZ2V0LCBzY2VuZUlkIH0pO1xuICAgIGNvbnN0IGluaXRpYWxJc3N1ZXMgPSBydW50aW1lRXhjbHVzaW9uSXNzdWVzKHsgc3RhdGUsIGVudGl0aWVzOiBwcm9qZWN0LmVudGl0aWVzLCByZWZlcmVuY2VFbnRpdGllczogdGFyZ2V0LnJlZmVyZW5jZUVudGl0aWVzLCBleHRlcm5hbFZhbHVlczogdGFyZ2V0LmV4dGVybmFsVmFsdWVzLCBydWxlQ29udGV4dDogaW5pdGlhbENvbnRleHQsIHJ1bGVDb250ZXh0czogcmV1c2VSdWxlQ29udGV4dHMocHJvamVjdCwgaW5pdGlhbENvbnRleHQpIH0pO1xuICAgIGlmIChpbml0aWFsSXNzdWVzLmxlbmd0aCkgcmV0dXJuIHsgb2s6IGZhbHNlLCBpc3N1ZXM6IGluaXRpYWxJc3N1ZXMgfTtcbiAgICBjb25zdCByZXNvbHZlZCA9IHsgLi4udGFyZ2V0LCBzY2VuZUlkIH0sIG5leHQgPSBzdHJ1Y3R1cmVkQ2xvbmUoc3RhdGUpLCBzZWVuID0gbmV3IFNldChuZXh0LnNlZW5JZHMpO1xuICAgIGlmIChub2RlKSB7IG5leHQucHJlc2VudGF0aW9uUG9zaXRpb24gPSBub2RlLmlkOyBuZXh0LnZpc2l0Q291bnRzW25vZGUuaWRdID0gKG5leHQudmlzaXRDb3VudHNbbm9kZS5pZF0gPz8gMCkgKyAxOyBzZWVuLmFkZChub2RlLmlkKTsgfVxuICAgIGlmIChzY2VuZSkge1xuICAgICAgc2Vlbi5hZGQoc2NlbmUuaWQpOyBuZXh0LnZpc2l0Q291bnRzW3NjZW5lLmlkXSA9IChuZXh0LnZpc2l0Q291bnRzW3NjZW5lLmlkXSA/PyAwKSArIDE7XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIHNjZW5lLmRhdGEuYmxvY2tJZHMgPz8gW10pIHNlZW4uYWRkKGlkKTtcbiAgICAgIGZvciAoY29uc3QgYmxvY2sgb2Ygc2NlbmUuZGF0YS5ib2R5KSBzZWVuLmFkZChibG9jay5pZCk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgbGluZUlkIG9mIHByZXNlbnRhdGlvbkxpbmVJZHMocHJvamVjdCwgcmVzb2x2ZWQpKSB7XG4gICAgICBjb25zdCBsaW5lID0gYWN0aXZlKHByb2plY3QsICdkaWFsb2d1ZV9saW5lJykuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IGxpbmVJZCk7XG4gICAgICBpZiAoIWxpbmUpIHJldHVybiBwcm9ibGVtKGAke25vZGU/LmlkID8/IHNjZW5lPy5pZH0uZGlhbG9ndWVMaW5lSWRzYCwgJ+aPkOekuuOBmeOCi+WPsOipnuOBjOWtmOWcqOOBl+OBquOBhOOBi+OAgeWJiumZpOODu+S4jeaOoeeUqOOBp+OBmeOAgicpO1xuICAgICAgc2Vlbi5hZGQobGluZS5pZCk7IG5leHQudmlzaXRDb3VudHNbbGluZS5pZF0gPSAobmV4dC52aXNpdENvdW50c1tsaW5lLmlkXSA/PyAwKSArIDE7IGZvciAoY29uc3QgYmxvY2sgb2YgbGluZS5kYXRhLnRleHQpIHNlZW4uYWRkKGJsb2NrLmlkKTtcbiAgICB9XG4gICAgbmV4dC5zZWVuSWRzID0gWy4uLnNlZW5dO1xuICAgIGNvbnN0IHZhcmlhYmxlcyA9IFsuLi5hY3RpdmUocHJvamVjdCwgJ3ZhcmlhYmxlJyksIC4uLih0YXJnZXQucmVmZXJlbmNlRW50aXRpZXMgPz8gW10pLmZpbHRlcigoZW50aXR5KTogZW50aXR5IGlzIEVudGl0eTwndmFyaWFibGUnPiA9PiBlbnRpdHkua2luZCA9PT0gJ3ZhcmlhYmxlJyAmJiBhZG9wdGVkUmVjb3JkKGVudGl0eSkpXSwgcnVsZUNvbnRleHQgPSBwcmVzZW50YXRpb25SdWxlQ29udGV4dChwcm9qZWN0LCByZXNvbHZlZCksIGNvbnRleHQgPSB7IHN0YXRlOiBuZXh0LCB2YXJpYWJsZXMsIGVudGl0aWVzOiBwcm9qZWN0LmVudGl0aWVzLCByZWZlcmVuY2VFbnRpdGllczogdGFyZ2V0LnJlZmVyZW5jZUVudGl0aWVzLCBleHRlcm5hbFZhbHVlczogdGFyZ2V0LmV4dGVybmFsVmFsdWVzLCBydWxlQ29udGV4dCwgcnVsZUNvbnRleHRzOiByZXVzZVJ1bGVDb250ZXh0cyhwcm9qZWN0LCBydWxlQ29udGV4dCkgfTtcbiAgICBjb25zdCBjb25kaXRpb25zOiBQcmVzZW50YXRpb25Db25kaXRpb25SZXN1bHRbXSA9IFtdLCBkaXNjbG9zdXJlczogRW50aXR5PCdkaXNjbG9zdXJlJz5bXSA9IFtdO1xuICAgIGZvciAoY29uc3QgZGlzY2xvc3VyZSBvZiBhY3RpdmUocHJvamVjdCwgJ2Rpc2Nsb3N1cmUnKSkge1xuICAgICAgY29uc3QgYW5jaG9yID0gcmV1c2VFeGVjdXRpb25BbmNob3IocHJvamVjdCwgZGlzY2xvc3VyZS5kYXRhLmFuY2hvciwgZGlzY2xvc3VyZS5pZCk7XG4gICAgICBjb25zdCBzY29wZSA9IGRpc2Nsb3N1cmUuZGF0YS50YXJnZXRTY29wZTtcbiAgICAgIGNvbnN0IGRpc2Nsb3N1cmVDb250ZXh0ID0geyAuLi5jb250ZXh0LCBydWxlQ29udGV4dDogY29udGV4dC5ydWxlQ29udGV4dHNbZGlzY2xvc3VyZS5pZF0gPz8gY29udGV4dC5ydWxlQ29udGV4dCB9O1xuICAgICAgY29uc3Qgc2NvcGVSZXN1bHQgPSBzY29wZSA/IGV2YWx1YXRlVGFyZ2V0U2NvcGUoc2NvcGUsIGRpc2Nsb3N1cmVDb250ZXh0KSA6IHsgdmFsdWU6ICd0cnVlJyB9O1xuICAgICAgaWYgKHNjb3BlUmVzdWx0LnZhbHVlID09PSAnZmFsc2UnKSBjb250aW51ZTtcbiAgICAgIGlmIChhbmNob3Iuc291cmNlVmVyc2lvbklkICYmICFbcHJvamVjdC5wcm9qZWN0SWQsIHN0YXRlLmNvbnRlbnRWZXJzaW9uSWQsIHJldXNlT3JpZ2luKHByb2plY3QsIGFuY2hvci5lbnRpdHlJZCk/LnNvdXJjZVZlcnNpb25JZCwgcmV1c2VPcmlnaW4ocHJvamVjdCwgZGlzY2xvc3VyZS5pZCk/LnNvdXJjZVZlcnNpb25JZF0uaW5jbHVkZXMoYW5jaG9yLnNvdXJjZVZlcnNpb25JZCkpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgbGluZUlkcyA9IHByZXNlbnRhdGlvbkxpbmVJZHMocHJvamVjdCwgcmVzb2x2ZWQpO1xuICAgICAgaWYgKCFbbm9kZT8uaWQsIHNjZW5lPy5pZCwgLi4ubGluZUlkc10uaW5jbHVkZXMoYW5jaG9yLmVudGl0eUlkKSkgY29udGludWU7XG4gICAgICBpZiAoc2NvcGVSZXN1bHQudmFsdWUgPT09ICd1bmtub3duJykgcmV0dXJuIHByb2JsZW0oYCR7ZGlzY2xvc3VyZS5pZH0udGFyZ2V0U2NvcGVgLCAn6ZaL56S644Gu5a++6LGh56+E5Zuy44O757WM6Lev44KS56K66KqN44Gn44GN44G+44Gb44KT44CCJywgJ0NPTkRJVElPTl9VTktOT1dOJyk7XG4gICAgICBpZiAoYW5jaG9yLnBvc2l0aW9uU3RhdHVzID09PSAndW5yZXNvbHZlZCcgJiYgW25vZGU/LmlkLCBzY2VuZT8uaWQsIC4uLmxpbmVJZHNdLmluY2x1ZGVzKGFuY2hvci5lbnRpdHlJZCkpIHJldHVybiBwcm9ibGVtKGAke2Rpc2Nsb3N1cmUuaWR9LmFuY2hvcmAsIGFuY2hvci5wb3NpdGlvblJlYXNvbiB8fCAn5o+Q56S65L2N572u44GM5LiN5piO44Gn44GZ44CC5pys5paH44G45YaN44Oq44Oz44Kv44GX44Gm44GP44Gg44GV44GE44CCJywgJ0NPTkRJVElPTl9VTktOT1dOJyk7XG4gICAgICBpZiAoIXByZXNlbnRhdGlvbkFuY2hvckFwcGxpZXMocHJvamVjdCwgbmV4dCwgYW5jaG9yLCByZXNvbHZlZCwgZGlzY2xvc3VyZS5pZCkpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgcmVzdWx0ID0gZXZhbHVhdGVDb25kaXRpb24oeyBvcDogJ2FsbCcsIGNoaWxkcmVuOiBbZGlzY2xvc3VyZS5kYXRhLmNvbmRpdGlvbiA/PyB7IG9wOiAnY29uc3RhbnQnLCB2YWx1ZTogdHJ1ZSB9LCBzY29wZT8ucm91dGVDb25kaXRpb24gPz8geyBvcDogJ2NvbnN0YW50JywgdmFsdWU6IHRydWUgfV0gfSwgZGlzY2xvc3VyZUNvbnRleHQpO1xuICAgICAgY29uZGl0aW9ucy5wdXNoKHsgdGFyZ2V0SWQ6IGRpc2Nsb3N1cmUuaWQsIC4uLnJlc3VsdCB9KTtcbiAgICAgIGlmIChyZXN1bHQudmFsdWUgPT09ICd1bmtub3duJykgcmV0dXJuIHByb2JsZW0oYCR7ZGlzY2xvc3VyZS5pZH0uY29uZGl0aW9uYCwgcmVzdWx0LnJlYXNvbnMuam9pbign44CBJykgfHwgJ+OBk+OBruWgtOmdouOBrumWi+ekuuadoeS7tuOBjOacqueiuuiqjeOBp+OBmeOAgicsICdDT05ESVRJT05fVU5LTk9XTicpO1xuICAgICAgaWYgKHJlc3VsdC52YWx1ZSA9PT0gJ3RydWUnKSBkaXNjbG9zdXJlcy5wdXNoKGRpc2Nsb3N1cmUpO1xuICAgIH1cbiAgICBjb25zdCBvcmRlcmVkID0gZGlzY2xvc3VyZXMuZmlsdGVyKGRpc2Nsb3N1cmUgPT4gKGRpc2Nsb3N1cmUuZGF0YS5rbm93bGVkZ2VFZmZlY3RzPy5sZW5ndGggPz8gMCkgPiAwKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9yZGVyZWQubGVuZ3RoOyBpKyspIGZvciAobGV0IGogPSBpICsgMTsgaiA8IG9yZGVyZWQubGVuZ3RoOyBqKyspIGlmIChwcmVzZW50YXRpb25BbmNob3JPcmRlcihwcm9qZWN0LCByZXVzZUV4ZWN1dGlvbkFuY2hvcihwcm9qZWN0LCBvcmRlcmVkW2ldLmRhdGEuYW5jaG9yLCBvcmRlcmVkW2ldLmlkKSwgcmV1c2VFeGVjdXRpb25BbmNob3IocHJvamVjdCwgb3JkZXJlZFtqXS5kYXRhLmFuY2hvciwgb3JkZXJlZFtqXS5pZCksIHJlc29sdmVkKSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gcHJvYmxlbShgJHtub2RlPy5pZCA/PyBzY2VuZT8uaWR9LmRpc2Nsb3N1cmVzYCwgJ+ikh+aVsOOBrumWi+ekuuWKueaenOOBruaPkOekuumghuOBjOeiuuWumuOBl+OBpuOBhOOBvuOBm+OCk+OAguauteiQveOBqOaWh+Wtl+S9jee9ruOCkuaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicsICdDT05ESVRJT05fVU5LTk9XTicpO1xuICAgIG9yZGVyZWQuc29ydCgobGVmdCwgcmlnaHQpID0+IHByZXNlbnRhdGlvbkFuY2hvck9yZGVyKHByb2plY3QsIHJldXNlRXhlY3V0aW9uQW5jaG9yKHByb2plY3QsIGxlZnQuZGF0YS5hbmNob3IsIGxlZnQuaWQpLCByZXVzZUV4ZWN1dGlvbkFuY2hvcihwcm9qZWN0LCByaWdodC5kYXRhLmFuY2hvciwgcmlnaHQuaWQpLCByZXNvbHZlZCkgPyAtMSA6IDEpO1xuICAgIGNvbnN0IGVmZmVjdHM6IEVudGl0eTwnZWZmZWN0Jz5bXSA9IFtdLCBlZmZlY3RQcmVzZW50YXRpb25zOiBOb25OdWxsYWJsZTxSdW50aW1lQ29udGV4dFsnZWZmZWN0UHJlc2VudGF0aW9ucyddPiA9IFtdO1xuICAgIGZvciAoY29uc3QgZGlzY2xvc3VyZSBvZiBvcmRlcmVkKSBmb3IgKGNvbnN0IGVmZmVjdElkIG9mIGRpc2Nsb3N1cmUuZGF0YS5rbm93bGVkZ2VFZmZlY3RzID8/IFtdKSB7XG4gICAgICBjb25zdCBlZmZlY3QgPSBbLi4ucHJvamVjdC5lbnRpdGllcywgLi4uKHRhcmdldC5yZWZlcmVuY2VFbnRpdGllcyA/PyBbXSldLmZpbmQoKGl0ZW0pOiBpdGVtIGlzIEVudGl0eTwnZWZmZWN0Jz4gPT4gaXRlbS5raW5kID09PSAnZWZmZWN0JyAmJiBpdGVtLmlkID09PSBlZmZlY3RJZCAmJiBhZG9wdGVkUmVjb3JkKGl0ZW0pKTtcbiAgICAgIGlmICghZWZmZWN0KSByZXR1cm4gcHJvYmxlbShgJHtkaXNjbG9zdXJlLmlkfS5rbm93bGVkZ2VFZmZlY3RzYCwgJ+mWi+ekuuOBq+aMh+WumuOBl+OBn+WKueaenOOBjOWtmOWcqOOBl+OBquOBhOOBi+OAgeWJiumZpOODu+S4jeaOoeeUqOOBp+OBmeOAgicpO1xuICAgICAgZWZmZWN0cy5wdXNoKGVmZmVjdCk7IGVmZmVjdFByZXNlbnRhdGlvbnMucHVzaCh7IHByb2plY3QsIHRhcmdldDogcmVzb2x2ZWQsIGFuY2hvcjogcmV1c2VFeGVjdXRpb25BbmNob3IocHJvamVjdCwgZGlzY2xvc3VyZS5kYXRhLmFuY2hvciwgZGlzY2xvc3VyZS5pZCkgfSk7XG4gICAgfVxuICAgIGNvbnN0IGFwcGxpZWQgPSBhcHBseUVmZmVjdHNBdG9taWMobmV4dCwgZWZmZWN0cywgeyAuLi5jb250ZXh0LCBlZmZlY3RQcmVzZW50YXRpb25zIH0pOyBpZiAoIWFwcGxpZWQub2spIHJldHVybiBhcHBsaWVkO1xuICAgIGFwcGxpZWQuc3RhdGUuc2VlbklkcyA9IFsuLi5uZXcgU2V0KFsuLi5hcHBsaWVkLnN0YXRlLnNlZW5JZHMsIC4uLmRpc2Nsb3N1cmVzLm1hcChkaXNjbG9zdXJlID0+IGRpc2Nsb3N1cmUuaWQpXSldO1xuICAgIHJldHVybiB7IG9rOiB0cnVlLCBzdGF0ZTogYXBwbGllZC5zdGF0ZSwgb2JzZXJ2YXRpb25TdGF0ZTogc3RydWN0dXJlZENsb25lKG5leHQpLCBjb25kaXRpb25zIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7IHJldHVybiB7IG9rOiBmYWxzZSwgaXNzdWVzOiBlcnJvciBpbnN0YW5jZW9mIERvbWFpblZhbGlkYXRpb25FcnJvciA/IGVycm9yLmlzc3VlcyA6IFt7IGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcsIHBhdGg6ICdwcmVzZW50YXRpb24nLCBtZXNzYWdlOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICfmj5DnpLrjgpLmpJzoqLzjgafjgY3jgb7jgZvjgpPjgIInIH1dIH07IH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBDaGFwdGVyUmVhZGluZ09wdGlvbnMgeyBjaGFwdGVySWRzPzogSURbXTsgc2NlbmVJZHM/OiBJRFtdOyBzZWxlY3Rpb24/OiAnY2hhcHRlcnMnIHwgJ3NjZW5lcyc7IGNvbnRlbnRWZXJzaW9uSWQ/OiBJRDsgc3RhdGU/OiBSdW50aW1lU3RhdGU7IHdvcmxkVGljaz86IHN0cmluZzsgZXh0ZXJuYWxWYWx1ZXM/OiBSZWNvcmQ8SUQsIFR5cGVkVmFsdWU+OyB3b3JsZFNuYXBzaG90cz86IFJlY29yZDxJRCwgUHJvamVjdENvbnRlbnQ+IH1cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhcHRlclJlYWRpbmdTZXNzaW9uIHtcbiAgY29udGVudDogUHJvamVjdERhdGE7IGNvbnRlbnRWZXJzaW9uSWQ6IElEOyBjb250ZW50UmV2aXNpb246IHN0cmluZzsgY29udGVudEhhc2g/OiBzdHJpbmc7XG4gIGRlY2xhcmF0aW9uUHJvamVjdD86IFByb2plY3REYXRhO1xuICBzdGFydFN0YXRlOiBSdW50aW1lU3RhdGU7IHN0YXRlOiBSdW50aW1lU3RhdGU7IGNoYXB0ZXJJZHM6IElEW107IHNjZW5lSWRzOiBJRFtdOyBzZWxlY3Rpb24/OiAnY2hhcHRlcnMnIHwgJ3NjZW5lcyc7XG4gIG9jY3VycmVuY2VzOiBQcmVzZW50YXRpb25PY2N1cnJlbmNlW107IGV4dGVybmFsVmFsdWVzOiBSZWNvcmQ8SUQsIFR5cGVkVmFsdWU+OyByZWZlcmVuY2VFbnRpdGllczogRW50aXR5W107XG4gIHdvcmxkVGljaz86IHN0cmluZztcbiAgc3RhdHVzOiAncmVhZHknIHwgJ3Rlcm1pbmFsJyB8ICd1bmtub3duJyB8ICdlcnJvcic7IGlzc3VlczogVmFsaWRhdGlvbklzc3VlW107XG59XG5leHBvcnQgZnVuY3Rpb24gY2hhcHRlck5hcnJhdGl2ZU9jY3VycmVuY2VzKHNlc3Npb246IENoYXB0ZXJSZWFkaW5nU2Vzc2lvbik6IE5hcnJhdGl2ZU9jY3VycmVuY2VbXSB7XG4gIHJldHVybiBzZXNzaW9uLm9jY3VycmVuY2VzLm1hcChvY2N1cnJlbmNlID0+ICh7IHN0YXRlOiBvY2N1cnJlbmNlLmFmdGVyLCBvYnNlcnZhdGlvblN0YXRlOiBvY2N1cnJlbmNlLnByZXNlbnRhdGlvblN0YXRlID8/IHVuZGVmaW5lZCwgY29uZGl0aW9uczogb2NjdXJyZW5jZS5jb25kaXRpb25SZXN1bHRzLCB0YXJnZXQ6IHsgc2NlbmVJZDogb2NjdXJyZW5jZS5lbnRpdHlJZCB9LCB3b3JsZFRpY2s6IHNlc3Npb24ud29ybGRUaWNrLCBleHRlcm5hbFZhbHVlczogb2NjdXJyZW5jZS5leHRlcm5hbFZhbHVlcyA/PyBzZXNzaW9uLmV4dGVybmFsVmFsdWVzIH0pKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0NoYXB0ZXJGb3Jlc2hhZG93cyhzZXNzaW9uOiBDaGFwdGVyUmVhZGluZ1Nlc3Npb24pIHtcbiAgcmV0dXJuIGNoZWNrUHJlc2VudGF0aW9uRm9yZXNoYWRvd3Moc2Vzc2lvbi5jb250ZW50LCBjaGFwdGVyTmFycmF0aXZlT2NjdXJyZW5jZXMoc2Vzc2lvbiksIHNlc3Npb24uc3RhcnRTdGF0ZSwgc2Vzc2lvbi5zdGF0dXMgPT09ICd0ZXJtaW5hbCcsIHNlc3Npb24ucmVmZXJlbmNlRW50aXRpZXMsIHNlc3Npb24uaXNzdWVzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdGFydENoYXB0ZXJSZWFkaW5nKHByb2plY3Q6IFByb2plY3REYXRhLCBvcHRpb25zOiBDaGFwdGVyUmVhZGluZ09wdGlvbnMgPSB7fSk6IFByb21pc2U8Q2hhcHRlclJlYWRpbmdTZXNzaW9uPiB7XG4gIGNvbnN0IGRlY2xhcmF0aW9uUHJvamVjdCA9IHN0cnVjdHVyZWRDbG9uZSh7IC4uLnByb2plY3QsIGhpc3Rvcnk6IFtdLCBzbmFwc2hvdHM6IFtdLCBhdXRob3JBbHRlcm5hdGl2ZXM6IHVuZGVmaW5lZCwgZW50aXRpZXM6IHByb2plY3QuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiBbJ2NvbGxlY3Rpb24nLCAndHJhY2UnLCAnY2hlY2twb2ludCddLmluY2x1ZGVzKGVudGl0eS5raW5kKSkgfSk7XG4gIGNvbnN0IHdvcmxkVGljayA9IG9wdGlvbnMud29ybGRUaWNrLCByZXF1ZXN0ZWRTZWxlY3Rpb24gPSBvcHRpb25zLnNlbGVjdGlvbjtcbiAgaWYgKHdvcmxkVGljayAhPT0gdW5kZWZpbmVkICYmICFpc1RpY2sod29ybGRUaWNrKSkgdGhyb3cgbmV3IERvbWFpblZhbGlkYXRpb25FcnJvcihbeyBjb2RlOiAnVkFMSURBVElPTl9GQUlMRUQnLCBwYXRoOiAnd29ybGRUaWNrJywgbWVzc2FnZTogJ+aPkOekuuaZgueCueOBq+OBr+aVtOaVsOOBruS4lueVjOWGhXRpY2vjgpLlhaXlipvjgZfjgabjgY/jgaDjgZXjgYTjgIInIH1dKTtcbiAgY29uc3Qgd29ybGRTbmFwc2hvdHMgPSBvcHRpb25zLndvcmxkU25hcHNob3RzID8gc3RydWN0dXJlZENsb25lKG9wdGlvbnMud29ybGRTbmFwc2hvdHMpIDoge307XG4gIGNvbnN0IGNoYXB0ZXJJZHNPcHRpb24gPSBvcHRpb25zLmNoYXB0ZXJJZHMgPyBbLi4ub3B0aW9ucy5jaGFwdGVySWRzXSA6IHVuZGVmaW5lZCwgc2NlbmVJZHNPcHRpb24gPSBvcHRpb25zLnNjZW5lSWRzID8gWy4uLm9wdGlvbnMuc2NlbmVJZHNdIDogdW5kZWZpbmVkO1xuICBjb25zdCBleHRlcm5hbFZhbHVlcyA9IHN0cnVjdHVyZWRDbG9uZShvcHRpb25zLmV4dGVybmFsVmFsdWVzID8/IHt9KSwgcmVxdWVzdGVkU3RhdGUgPSBvcHRpb25zLnN0YXRlID8gc3RydWN0dXJlZENsb25lKG9wdGlvbnMuc3RhdGUpIDogdW5kZWZpbmVkO1xuICBjb25zdCB2ZXJzaW9uID0gb3B0aW9ucy5jb250ZW50VmVyc2lvbklkID8/IHByb2plY3QucHJvamVjdElkLCBjYXB0dXJlZCA9IGF3YWl0IGNhcHR1cmVSdW50aW1lQ29udGVudChwcm9qZWN0LCB2ZXJzaW9uLCB7IHdvcmxkU25hcHNob3RzIH0pLCBjb250ZW50ID0gcmVzb2x2ZVJldXNlQ29udGVudChjYXB0dXJlZCwgY2FwdHVyZWQuc25hcHNob3RzKTtcbiAgY29uc3QgY2xvc3VyZSA9IHJlc29sdmVQaW5uZWRXb3JsZHMoY29udGVudCwgd29ybGRTbmFwc2hvdHMpO1xuICBpZiAoY2xvc3VyZS5lcnJvcnMubGVuZ3RoKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdSRUZFUkVOQ0VfSU5WQUxJRCcsIHBhdGg6ICd3b3JsZFJlZmVyZW5jZXMnLCBtZXNzYWdlOiBjbG9zdXJlLmVycm9yc1swXSEgfV0pO1xuICBjb25zdCBleHRlcm5hbElzc3VlcyA9IHZhbGlkYXRlRXh0ZXJuYWxJbnB1dChjb250ZW50LCBleHRlcm5hbFZhbHVlcywgdW5kZWZpbmVkLCBjbG9zdXJlLndvcmxkcy5mbGF0TWFwKHdvcmxkID0+IHdvcmxkLmVudGl0aWVzKSk7IGlmIChleHRlcm5hbElzc3Vlcy5sZW5ndGgpIHRocm93IG5ldyBEb21haW5WYWxpZGF0aW9uRXJyb3IoZXh0ZXJuYWxJc3N1ZXMpO1xuICBpZiAoc2NlbmVJZHNPcHRpb24/LnNvbWUoaWQgPT4gIWFjdGl2ZShjb250ZW50LCAnc2NlbmUnKS5zb21lKHNjZW5lID0+IHNjZW5lLmlkID09PSBpZCkpKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdSRUZFUkVOQ0VfSU5WQUxJRCcsIHBhdGg6ICdzY2VuZUlkcycsIG1lc3NhZ2U6ICfoqq3jgb/pgJrjgZfntYzot6/jgavlrZjlnKjjgZfjgarjgYTloLTpnaLjgYzmjIflrprjgZXjgozjgabjgYTjgb7jgZnjgIInIH1dKTtcbiAgaWYgKGNoYXB0ZXJJZHNPcHRpb24/LnNvbWUoaWQgPT4gIWFjdGl2ZShjb250ZW50LCAnY2hhcHRlcicpLnNvbWUoY2hhcHRlciA9PiBjaGFwdGVyLmlkID09PSBpZCkpKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdSRUZFUkVOQ0VfSU5WQUxJRCcsIHBhdGg6ICdjaGFwdGVySWRzJywgbWVzc2FnZTogJ+iqreOBv+mAmuOBmeeroOOBjOWtmOWcqOOBl+OBvuOBm+OCk+OAgicgfV0pO1xuICBjb25zdCBzZXF1ZW5jZSA9IGJ1aWxkQ2hhcHRlclJlYWRpbmdTZXF1ZW5jZShjb250ZW50LCBjaGFwdGVySWRzT3B0aW9uLCBzY2VuZUlkc09wdGlvbik7XG4gIGlmIChyZXF1ZXN0ZWRTdGF0ZSAmJiByZXF1ZXN0ZWRTdGF0ZS5jb250ZW50VmVyc2lvbklkICE9PSB2ZXJzaW9uKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcsIHBhdGg6ICdzdGF0ZS5jb250ZW50VmVyc2lvbklkJywgbWVzc2FnZTogJ+mWi+Wni+eKtuaFi+OBqOiqreOBv+mAmuOBl+WvvuixoeOBrueJiOOBjOmBleOBhOOBvuOBmeOAguWkieabtOOBm+OBmumWi+Wni+OCkuatouOCgeOBvuOBl+OBn+OAgicgfV0pO1xuICBjb25zdCBzdGF0ZSA9IHN0cnVjdHVyZWRDbG9uZShyZXF1ZXN0ZWRTdGF0ZSA/PyBpbml0aWFsaXplUnVudGltZVN0YXRlKGNvbnRlbnQsIHZlcnNpb24sIGNsb3N1cmUud29ybGRzLmZsYXRNYXAod29ybGQgPT4gd29ybGQuZW50aXRpZXMpKSk7XG4gIHN0YXRlLmNvbnRlbnRWZXJzaW9uSWQgPSB2ZXJzaW9uOyBzdGF0ZS5wcmVzZW50YXRpb25Qb3NpdGlvbiA9IG51bGw7IHN0YXRlLnByb3ZlbmFuY2UgPSAncGFydGlhbCc7XG4gIGNvbnN0IHZhbGlkYXRlZCA9IHZhbGlkYXRlUnVudGltZVN0YXRlKHN0YXRlKTsgaWYgKCF2YWxpZGF0ZWQub2spIHRocm93IG5ldyBEb21haW5WYWxpZGF0aW9uRXJyb3IodmFsaWRhdGVkLmlzc3Vlcyk7XG4gIGNvbnN0IGRlY2xhcmF0aW9ucyA9IFsuLi5jb250ZW50LmVudGl0aWVzLCAuLi5jbG9zdXJlLndvcmxkcy5mbGF0TWFwKHdvcmxkID0+IHdvcmxkLmVudGl0aWVzKV0uZmlsdGVyKGFkb3B0ZWRSZWNvcmQpO1xuICBmb3IgKGNvbnN0IFtpZCwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHN0YXRlLnZhcmlhYmxlVmFsdWVzKSkge1xuICAgIGNvbnN0IHZhcmlhYmxlID0gZGVjbGFyYXRpb25zLmZpbmQoZW50aXR5ID0+IGVudGl0eS5pZCA9PT0gaWQgJiYgZW50aXR5LmtpbmQgPT09ICd2YXJpYWJsZScpO1xuICAgIGlmICghdmFyaWFibGUgfHwgdmFyaWFibGUua2luZCAhPT0gJ3ZhcmlhYmxlJykgdGhyb3cgbmV3IERvbWFpblZhbGlkYXRpb25FcnJvcihbeyBjb2RlOiAnUkVGRVJFTkNFX0lOVkFMSUQnLCBwYXRoOiBgc3RhdGUudmFyaWFibGVWYWx1ZXMuJHtpZH1gLCBtZXNzYWdlOiAn6ZaL5aeL54q25oWL44Gr5a++6LGh54mI44Gu5a6j6KiA44GM44Gq44GE54q25oWL5YCk44GM44GC44KK44G+44GZ44CCJyB9XSk7XG4gICAgY29uc3QgaXNzdWVzID0gdmFsaWRhdGVWYXJpYWJsZVZhbHVlKHZhcmlhYmxlLCB2YWx1ZSwgYHN0YXRlLnZhcmlhYmxlVmFsdWVzLiR7aWR9YCk7IGlmIChpc3N1ZXMubGVuZ3RoKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKGlzc3Vlcyk7XG4gIH1cbiAgY29uc3QgcnVsZUNvbnRleHQgPSBwcmVzZW50YXRpb25SdWxlQ29udGV4dChjb250ZW50LCB7IHNjZW5lSWQ6IHNlcXVlbmNlWzBdPy5zY2VuZS5pZCwgd29ybGRUaWNrIH0pO1xuICBjb25zdCBleGNsdXNpb25zID0gcnVudGltZUV4Y2x1c2lvbklzc3Vlcyh7IHN0YXRlLCBlbnRpdGllczogY29udGVudC5lbnRpdGllcywgcmVmZXJlbmNlRW50aXRpZXM6IGNsb3N1cmUud29ybGRzLmZsYXRNYXAod29ybGQgPT4gd29ybGQuZW50aXRpZXMpLCBleHRlcm5hbFZhbHVlcywgcnVsZUNvbnRleHQsIHJ1bGVDb250ZXh0czogcmV1c2VSdWxlQ29udGV4dHMoY29udGVudCwgcnVsZUNvbnRleHQpIH0pO1xuICBpZiAoZXhjbHVzaW9ucy5zb21lKGlzc3VlID0+IGlzc3VlLmNvZGUgIT09ICdDT05ESVRJT05fVU5LTk9XTicpKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKGV4Y2x1c2lvbnMpO1xuICBjb25zdCBjaGFwdGVySWRzID0gY2hhcHRlcklkc09wdGlvbiA/IFsuLi5jaGFwdGVySWRzT3B0aW9uXSA6IFsuLi5uZXcgU2V0KHNlcXVlbmNlLmZsYXRNYXAoZW50cnkgPT4gZW50cnkuY2hhcHRlcklkID8gW2VudHJ5LmNoYXB0ZXJJZF0gOiBbXSkpXTtcbiAgcmV0dXJuIHsgY29udGVudCwgZGVjbGFyYXRpb25Qcm9qZWN0LCBjb250ZW50VmVyc2lvbklkOiB2ZXJzaW9uLCBjb250ZW50UmV2aXNpb246IGNvbnRlbnQucmV2aXNpb24sIGNvbnRlbnRIYXNoOiBwcm9qZWN0LnNuYXBzaG90cy5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gdmVyc2lvbik/LmNvbnRlbnRIYXNoLCBzdGFydFN0YXRlOiBzdHJ1Y3R1cmVkQ2xvbmUoc3RhdGUpLCBzdGF0ZSwgd29ybGRUaWNrLCBjaGFwdGVySWRzLCBzY2VuZUlkczogc2VxdWVuY2UubWFwKGVudHJ5ID0+IGVudHJ5LnNjZW5lLmlkKSwgc2VsZWN0aW9uOiByZXF1ZXN0ZWRTZWxlY3Rpb24gPz8gKHNjZW5lSWRzT3B0aW9uID8gJ3NjZW5lcycgOiAnY2hhcHRlcnMnKSwgb2NjdXJyZW5jZXM6IFtdLCBleHRlcm5hbFZhbHVlcywgcmVmZXJlbmNlRW50aXRpZXM6IHN0cnVjdHVyZWRDbG9uZShjbG9zdXJlLndvcmxkcy5mbGF0TWFwKHdvcmxkID0+IHdvcmxkLmVudGl0aWVzKSksIHN0YXR1czogZXhjbHVzaW9ucy5sZW5ndGggPyAndW5rbm93bicgOiBzZXF1ZW5jZS5sZW5ndGggPyAncmVhZHknIDogJ3Rlcm1pbmFsJywgaXNzdWVzOiBleGNsdXNpb25zIH07XG59XG5leHBvcnQgZnVuY3Rpb24gcHJlc2VudENoYXB0ZXJPY2N1cnJlbmNlKGNvbnRlbnQ6IFByb2plY3REYXRhLCBzdGF0ZTogUnVudGltZVN0YXRlLCB0YXJnZXQ6IFByZXNlbnRhdGlvblRhcmdldCAmIHsgcHJldmlvdXNTY2VuZUlkPzogSUQ7IGxhc3Q/OiBib29sZWFuIH0pOiBDb250ZW50UHJlc2VudGF0aW9uIHtcbiAgY29uc3QgeyBzY2VuZUlkLCBwcmV2aW91c1NjZW5lSWQgfSA9IHRhcmdldDtcbiAgY29uc3QgZnJvbSA9IHByZXNlbnRhdGlvblJ1bGVDb250ZXh0KGNvbnRlbnQsIHsgc2NlbmVJZDogcHJldmlvdXNTY2VuZUlkIH0pLCB0byA9IHByZXNlbnRhdGlvblJ1bGVDb250ZXh0KGNvbnRlbnQsIHsgc2NlbmVJZCB9KTtcbiAgY29uc3QgZXZlbnRzOiAoJ3NjZW5lX2VuZCcgfCAnY2hhcHRlcl9lbmQnKVtdID0gcHJldmlvdXNTY2VuZUlkICYmIHByZXZpb3VzU2NlbmVJZCAhPT0gc2NlbmVJZCA/IFsnc2NlbmVfZW5kJ10gOiBbXTtcbiAgaWYgKGZyb20uY2hhcHRlcklkICYmIGZyb20uY2hhcHRlcklkICE9PSB0by5jaGFwdGVySWQpIGV2ZW50cy5wdXNoKCdjaGFwdGVyX2VuZCcpO1xuICBjb25zdCByZXNldCA9IHJlc2V0UnVudGltZUxpZmVjeWNsZSh7IC4uLnN0YXRlLCAuLi4oc3RhdGUucmVzZXRDYXVzZXMgPyB7IHJlc2V0Q2F1c2VzOiBbXSB9IDoge30pIH0sIGV2ZW50cywgeyBzdGF0ZSwgZW50aXRpZXM6IGNvbnRlbnQuZW50aXRpZXMsIHJlZmVyZW5jZUVudGl0aWVzOiB0YXJnZXQucmVmZXJlbmNlRW50aXRpZXMsIGV4dGVybmFsVmFsdWVzOiB0YXJnZXQuZXh0ZXJuYWxWYWx1ZXMsIHJ1bGVDb250ZXh0OiBwcmVzZW50YXRpb25SdWxlQ29udGV4dChjb250ZW50LCB7IHNjZW5lSWQ6IHRhcmdldC5wcmV2aW91c1NjZW5lSWQsIHdvcmxkVGljazogdGFyZ2V0LndvcmxkVGljayB9KSwgcnVsZUNvbnRleHRzOiByZXVzZVJ1bGVDb250ZXh0cyhjb250ZW50LCBwcmVzZW50YXRpb25SdWxlQ29udGV4dChjb250ZW50LCB7IHNjZW5lSWQ6IHRhcmdldC5wcmV2aW91c1NjZW5lSWQsIHdvcmxkVGljazogdGFyZ2V0LndvcmxkVGljayB9KSkgfSk7XG4gIGlmICghcmVzZXQub2spIHJldHVybiByZXNldDtcbiAgY29uc3QgcmVzdWx0ID0gcHJlc2VudENvbnRlbnQoY29udGVudCwgcmVzZXQuc3RhdGUsIHRhcmdldCk7XG4gIGlmICghcmVzdWx0Lm9rKSByZXR1cm4gcmVzdWx0O1xuICBpZiAodGFyZ2V0Lmxhc3QpIHtcbiAgICBjb25zdCBlbmRlZCA9IHJlc2V0UnVudGltZUxpZmVjeWNsZShyZXN1bHQuc3RhdGUsIFsnc2NlbmVfZW5kJywgJ2NoYXB0ZXJfZW5kJywgJ3J1bl9lbmQnXSwgeyBzdGF0ZTogcmVzdWx0LnN0YXRlLCBlbnRpdGllczogY29udGVudC5lbnRpdGllcywgcmVmZXJlbmNlRW50aXRpZXM6IHRhcmdldC5yZWZlcmVuY2VFbnRpdGllcywgZXh0ZXJuYWxWYWx1ZXM6IHRhcmdldC5leHRlcm5hbFZhbHVlcywgcnVsZUNvbnRleHQ6IHByZXNlbnRhdGlvblJ1bGVDb250ZXh0KGNvbnRlbnQsIHRhcmdldCksIHJ1bGVDb250ZXh0czogcmV1c2VSdWxlQ29udGV4dHMoY29udGVudCwgcHJlc2VudGF0aW9uUnVsZUNvbnRleHQoY29udGVudCwgdGFyZ2V0KSkgfSk7XG4gICAgaWYgKCFlbmRlZC5vaykgcmV0dXJuIGVuZGVkO1xuICAgIHJlc3VsdC5zdGF0ZSA9IGVuZGVkLnN0YXRlO1xuICAgIGlmIChyZXNldC5zdGF0ZS5yZXNldENhdXNlcyB8fCBlbmRlZC5zdGF0ZS5yZXNldENhdXNlcykgcmVzdWx0LnN0YXRlLnJlc2V0Q2F1c2VzID0gWy4uLihyZXNldC5zdGF0ZS5yZXNldENhdXNlcyA/PyBbXSksIC4uLihlbmRlZC5zdGF0ZS5yZXNldENhdXNlcyA/PyBbXSldO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5leHBvcnQgZnVuY3Rpb24gcHJlc2VudE5leHRDaGFwdGVyU2NlbmUocHJvamVjdDogUHJvamVjdERhdGEsIHNlc3Npb246IENoYXB0ZXJSZWFkaW5nU2Vzc2lvbik6IENoYXB0ZXJSZWFkaW5nU2Vzc2lvbiB7XG4gIGNvbnN0IHZlcnNpb25Jc3N1ZSA9IGNhcHR1cmVkVmVyc2lvbklzc3VlKHByb2plY3QsIHNlc3Npb24uY29udGVudFZlcnNpb25JZCwgc2Vzc2lvbi5jb250ZW50UmV2aXNpb24sIHNlc3Npb24uY29udGVudEhhc2gpO1xuICBpZiAodmVyc2lvbklzc3VlKSByZXR1cm4geyAuLi5zZXNzaW9uLCBzdGF0dXM6ICdlcnJvcicsIGlzc3VlczogW3sgY29kZTogJ1ZBTElEQVRJT05fRkFJTEVEJywgcGF0aDogJ2NvbnRlbnRWZXJzaW9uSWQnLCBtZXNzYWdlOiB2ZXJzaW9uSXNzdWUgfV0gfTtcbiAgY29uc3Qgc2NlbmVJZCA9IHNlc3Npb24uc2NlbmVJZHNbc2Vzc2lvbi5vY2N1cnJlbmNlcy5sZW5ndGhdOyBpZiAoIXNjZW5lSWQpIHJldHVybiBzZXNzaW9uO1xuICBjb25zdCByZXN1bHQgPSBwcmVzZW50Q2hhcHRlck9jY3VycmVuY2Uoc2Vzc2lvbi5jb250ZW50LCBzZXNzaW9uLnN0YXRlLCB7IHNjZW5lSWQsIHdvcmxkVGljazogc2Vzc2lvbi53b3JsZFRpY2ssIHByZXZpb3VzU2NlbmVJZDogc2Vzc2lvbi5vY2N1cnJlbmNlcy5hdCgtMSk/LmVudGl0eUlkLCBsYXN0OiBzZXNzaW9uLm9jY3VycmVuY2VzLmxlbmd0aCArIDEgPT09IHNlc3Npb24uc2NlbmVJZHMubGVuZ3RoLCBleHRlcm5hbFZhbHVlczogc2Vzc2lvbi5leHRlcm5hbFZhbHVlcywgcmVmZXJlbmNlRW50aXRpZXM6IHNlc3Npb24ucmVmZXJlbmNlRW50aXRpZXMgfSk7XG4gIGlmICghcmVzdWx0Lm9rKSByZXR1cm4geyAuLi5zZXNzaW9uLCBzdGF0dXM6IHJlc3VsdC5pc3N1ZXMuc29tZShpc3N1ZSA9PiBpc3N1ZS5jb2RlID09PSAnQ09ORElUSU9OX1VOS05PV04nKSA/ICd1bmtub3duJyA6ICdlcnJvcicsIGlzc3VlczogcmVzdWx0Lmlzc3VlcyB9O1xuICBjb25zdCBvY2N1cnJlbmNlOiBQcmVzZW50YXRpb25PY2N1cnJlbmNlID0geyBlbnRpdHlJZDogc2NlbmVJZCwgb2NjdXJyZW5jZUlkOiBgJHtzY2VuZUlkfToke3Nlc3Npb24ub2NjdXJyZW5jZXMubGVuZ3RoICsgMX1gLCBiZWZvcmU6IHN0cnVjdHVyZWRDbG9uZShzZXNzaW9uLnN0YXRlKSwgYWZ0ZXI6IHJlc3VsdC5zdGF0ZSwgcHJlc2VudGF0aW9uU3RhdGU6IHJlc3VsdC5vYnNlcnZhdGlvblN0YXRlLCBjb25kaXRpb25SZXN1bHRzOiByZXN1bHQuY29uZGl0aW9ucywgZXh0ZXJuYWxWYWx1ZXM6IHN0cnVjdHVyZWRDbG9uZShzZXNzaW9uLmV4dGVybmFsVmFsdWVzKSB9O1xuICBjb25zdCBvY2N1cnJlbmNlcyA9IFsuLi5zZXNzaW9uLm9jY3VycmVuY2VzLCBvY2N1cnJlbmNlXTtcbiAgcmV0dXJuIHsgLi4uc2Vzc2lvbiwgc3RhdGU6IHJlc3VsdC5zdGF0ZSwgb2NjdXJyZW5jZXMsIHN0YXR1czogb2NjdXJyZW5jZXMubGVuZ3RoID09PSBzZXNzaW9uLnNjZW5lSWRzLmxlbmd0aCA/ICd0ZXJtaW5hbCcgOiAncmVhZHknLCBpc3N1ZXM6IFtdIH07XG59XG5leHBvcnQgZnVuY3Rpb24gYmFja0NoYXB0ZXJSZWFkaW5nKHNlc3Npb246IENoYXB0ZXJSZWFkaW5nU2Vzc2lvbik6IENoYXB0ZXJSZWFkaW5nU2Vzc2lvbiB7XG4gIGNvbnN0IHByZXZpb3VzID0gc2Vzc2lvbi5vY2N1cnJlbmNlcy5hdCgtMSk7IGlmICghcHJldmlvdXMpIHJldHVybiB7IC4uLnNlc3Npb24sIHN0YXR1czogc2Vzc2lvbi5zY2VuZUlkcy5sZW5ndGggPyAncmVhZHknIDogJ3Rlcm1pbmFsJywgaXNzdWVzOiBbXSB9O1xuICByZXR1cm4geyAuLi5zZXNzaW9uLCBzdGF0ZTogc3RydWN0dXJlZENsb25lKHByZXZpb3VzLmJlZm9yZSksIG9jY3VycmVuY2VzOiBzZXNzaW9uLm9jY3VycmVuY2VzLnNsaWNlKDAsIC0xKSwgc3RhdHVzOiAncmVhZHknLCBpc3N1ZXM6IFtdIH07XG59XG5leHBvcnQgaW50ZXJmYWNlIENoYXB0ZXJSZWFkaW5nUmVjb3JkIHsgY2hlY2twb2ludDogQ2hlY2twb2ludERhdGE7IHRyYWNlOiBUcmFjZURhdGEgJiBSdW50aW1lVHJhY2VFeHRlbnNpb25zOyBjb250ZW50OiBQcm9qZWN0Q29udGVudCB9XG5leHBvcnQgZnVuY3Rpb24gcGluQ2hhcHRlclJlYWRpbmdSZWNvcmQoc2Vzc2lvbjogQ2hhcHRlclJlYWRpbmdTZXNzaW9uLCBpZHM6IHsgY2hlY2twb2ludElkOiBJRDsgc25hcHNob3RJZDogSUQgfSwgZGVjbGFyYXRpb25Qcm9qZWN0OiBQcm9qZWN0RGF0YSA9IHNlc3Npb24uZGVjbGFyYXRpb25Qcm9qZWN0ID8/IHNlc3Npb24uY29udGVudCk6IENoYXB0ZXJSZWFkaW5nUmVjb3JkIHtcbiAgY29uc3Qgc3RhdGVGb3JSZWNvcmQgPSAoc3RhdGU6IFJ1bnRpbWVTdGF0ZSkgPT4gKHsgLi4uc3RydWN0dXJlZENsb25lKHN0YXRlKSwgY29udGVudFZlcnNpb25JZDogaWRzLnNuYXBzaG90SWQgfSk7XG4gIGNvbnN0IHJlYWRpbmdQYXRoOiBSZWFkaW5nUGF0aCA9IHsgY2hhcHRlcklkczogWy4uLnNlc3Npb24uY2hhcHRlcklkc10sIHNjZW5lSWRzOiBbLi4uc2Vzc2lvbi5zY2VuZUlkc10sIC4uLihzZXNzaW9uLnNlbGVjdGlvbiA/IHsgc2VsZWN0aW9uOiBzZXNzaW9uLnNlbGVjdGlvbiB9IDoge30pLCBvY2N1cnJlbmNlczogc2Vzc2lvbi5vY2N1cnJlbmNlcy5tYXAob2NjdXJyZW5jZSA9PiAoeyAuLi5zdHJ1Y3R1cmVkQ2xvbmUob2NjdXJyZW5jZSksIGJlZm9yZTogc3RhdGVGb3JSZWNvcmQob2NjdXJyZW5jZS5iZWZvcmUpLCBhZnRlcjogc3RhdGVGb3JSZWNvcmQob2NjdXJyZW5jZS5hZnRlciksIC4uLihvY2N1cnJlbmNlLnByZXNlbnRhdGlvblN0YXRlID8geyBwcmVzZW50YXRpb25TdGF0ZTogc3RhdGVGb3JSZWNvcmQob2NjdXJyZW5jZS5wcmVzZW50YXRpb25TdGF0ZSkgfSA6IHt9KSB9KSkgfTtcbiAgY29uc3QgeyBzbmFwc2hvdHM6IF9zbmFwc2hvdHMsIGhpc3Rvcnk6IF9oaXN0b3J5LCBhdXRob3JBbHRlcm5hdGl2ZXM6IF9hdXRob3JBbHRlcm5hdGl2ZXMsIC4uLmNvbnRlbnQgfSA9IHJldXNlQXV0aG9yQ29udGVudChzZXNzaW9uLmNvbnRlbnQpO1xuICBjb25zdCBkaWFsb2d1ZSA9IGFjdGl2ZShzZXNzaW9uLmNvbnRlbnQsICdkaWFsb2d1ZV9saW5lJyksIHNjZW5lcyA9IGFjdGl2ZShzZXNzaW9uLmNvbnRlbnQsICdzY2VuZScpO1xuICBjb25zdCBwYXRoVGFyZ2V0cyA9IG5ldyBTZXQoWy4uLnNlc3Npb24uc2NlbmVJZHMsIC4uLnNjZW5lcy5maWx0ZXIoc2NlbmUgPT4gc2Vzc2lvbi5zY2VuZUlkcy5pbmNsdWRlcyhzY2VuZS5pZCkpLmZsYXRNYXAoc2NlbmUgPT4gKHNjZW5lLmRhdGEgYXMgRW50aXR5PCdzY2VuZSc+WydkYXRhJ10gJiB7IGRpYWxvZ3VlTGluZUlkcz86IElEW10gfCBudWxsIH0pLmRpYWxvZ3VlTGluZUlkcyA/PyBbXSldKTtcbiAgY29uc3QgZGlzY2xvc2VkID0gYWN0aXZlKHNlc3Npb24uY29udGVudCwgJ2Rpc2Nsb3N1cmUnKS5maWx0ZXIoZGlzY2xvc3VyZSA9PiBwYXRoVGFyZ2V0cy5oYXMoZGlzY2xvc3VyZS5kYXRhLmFuY2hvci5lbnRpdHlJZCkpO1xuICBjb25zdCBvYnNlcnZhdGlvbnMgPSBzZXNzaW9uLm9jY3VycmVuY2VzLmZsYXRNYXAob2NjdXJyZW5jZSA9PiBvY2N1cnJlbmNlLmNvbmRpdGlvblJlc3VsdHMpO1xuICByZXR1cm4ge1xuICAgIGNvbnRlbnQ6IHN0cnVjdHVyZWRDbG9uZShjb250ZW50KSxcbiAgICBjaGVja3BvaW50OiB7IGNvbnRlbnRWZXJzaW9uSWQ6IGlkcy5zbmFwc2hvdElkLCBjb250ZW50UmV2aXNpb246IHNlc3Npb24uY29udGVudFJldmlzaW9uLCBydW50aW1lU3RhdGU6IHN0YXRlRm9yUmVjb3JkKHNlc3Npb24uc3RhcnRTdGF0ZSksIG9yaWdpbjogJ3BhcnRpYWwnLCAuLi4oc2Vzc2lvbi53b3JsZFRpY2sgIT09IHVuZGVmaW5lZCA/IHsgd29ybGRUaWNrOiBzZXNzaW9uLndvcmxkVGljayB9IDoge30pIH0sXG4gICAgdHJhY2U6IHsgLi4uKGRlY2xhcmVkUmVncmVzc2lvblBhdGhzKGRlY2xhcmF0aW9uUHJvamVjdCkuaWRzLmxlbmd0aCA/IHsgcmVncmVzc2lvbkRlY2xhcmF0aW9uczogeyBwcm9qZWN0UmV2aXNpb246IGRlY2xhcmF0aW9uUHJvamVjdC5yZXZpc2lvbiwgdHJhY2VJZHM6IGRlY2xhcmVkUmVncmVzc2lvblBhdGhzKGRlY2xhcmF0aW9uUHJvamVjdCkuaWRzIH0gfSA6IHt9KSwgY29udGVudFZlcnNpb25JZDogaWRzLnNuYXBzaG90SWQsIGNvbnRlbnRSZXZpc2lvbjogc2Vzc2lvbi5jb250ZW50UmV2aXNpb24sIHN0YXJ0Q2hlY2twb2ludElkOiBpZHMuY2hlY2twb2ludElkLCBzZWVkOiBzZXNzaW9uLnN0YXJ0U3RhdGUucm5nU2VlZCwgZW5naW5lVmVyc2lvbjogJzEuMC4wJywgLi4uKHNlc3Npb24ud29ybGRUaWNrICE9PSB1bmRlZmluZWQgPyB7IGluaXRpYWxXb3JsZFRpY2s6IHNlc3Npb24ud29ybGRUaWNrIH0gOiB7fSksIGluaXRpYWxFeHRlcm5hbFZhbHVlczogc3RydWN0dXJlZENsb25lKHNlc3Npb24uZXh0ZXJuYWxWYWx1ZXMpLCBleHRlcm5hbE1vZGU6IE9iamVjdC5rZXlzKHNlc3Npb24uZXh0ZXJuYWxWYWx1ZXMpLmxlbmd0aCA/ICdzdHViJyA6IG51bGwsIHN0ZXBzOiBbXSwgbW9kZTogJ2NoYXB0ZXJzJywgcmVhZGluZ1BhdGgsIGNvdmVyYWdlOiB7XG4gICAgICBzY2VuZXM6IHsgY2hlY2tlZDogbmV3IFNldChzZXNzaW9uLm9jY3VycmVuY2VzLm1hcChvY2N1cnJlbmNlID0+IG9jY3VycmVuY2UuZW50aXR5SWQpKS5zaXplLCB0b3RhbDogc2NlbmVzLmxlbmd0aCB9LFxuICAgICAgZGlhbG9ndWU6IHsgY2hlY2tlZDogZGlhbG9ndWUuZmlsdGVyKGxpbmUgPT4gc2Vzc2lvbi5zdGF0ZS5zZWVuSWRzLmluY2x1ZGVzKGxpbmUuaWQpKS5sZW5ndGgsIHRvdGFsOiBkaWFsb2d1ZS5sZW5ndGggfSwgY2hvaWNlczogeyBjaGVja2VkOiAwLCB0b3RhbDogMCB9LFxuICAgICAgY29uZGl0aW9uVHJ1ZTogeyBjaGVja2VkOiBuZXcgU2V0KG9ic2VydmF0aW9ucy5maWx0ZXIocmVzdWx0ID0+IHJlc3VsdC52YWx1ZSA9PT0gJ3RydWUnKS5tYXAocmVzdWx0ID0+IHJlc3VsdC50YXJnZXRJZCkpLnNpemUsIHRvdGFsOiBkaXNjbG9zZWQubGVuZ3RoIH0sXG4gICAgICBjb25kaXRpb25GYWxzZTogeyBjaGVja2VkOiBuZXcgU2V0KG9ic2VydmF0aW9ucy5maWx0ZXIocmVzdWx0ID0+IHJlc3VsdC52YWx1ZSA9PT0gJ2ZhbHNlJykubWFwKHJlc3VsdCA9PiByZXN1bHQudGFyZ2V0SWQpKS5zaXplLCB0b3RhbDogZGlzY2xvc2VkLmxlbmd0aCB9LCBkZWNsYXJlZFRlc3RzOiByZWdyZXNzaW9uUGF0aENvdmVyYWdlKGRlY2xhcmF0aW9uUHJvamVjdCwgeyBjb250ZW50VmVyc2lvbklkOiBzZXNzaW9uLmNvbnRlbnRWZXJzaW9uSWQsIG1vZGU6ICdjaGFwdGVycycsIHN0ZXBzOiBbXSwgcmVhZGluZ1BhdGg6IHsgLi4ucmVhZGluZ1BhdGgsIG9jY3VycmVuY2VzOiByZWFkaW5nUGF0aC5vY2N1cnJlbmNlcy5tYXAob2NjdXJyZW5jZSA9PiAoeyAuLi5vY2N1cnJlbmNlLCBiZWZvcmU6IHsgLi4ub2NjdXJyZW5jZS5iZWZvcmUsIGNvbnRlbnRWZXJzaW9uSWQ6IHNlc3Npb24uY29udGVudFZlcnNpb25JZCB9LCBhZnRlcjogeyAuLi5vY2N1cnJlbmNlLmFmdGVyLCBjb250ZW50VmVyc2lvbklkOiBzZXNzaW9uLmNvbnRlbnRWZXJzaW9uSWQgfSwgLi4uKG9jY3VycmVuY2UucHJlc2VudGF0aW9uU3RhdGUgPyB7IHByZXNlbnRhdGlvblN0YXRlOiB7IC4uLm9jY3VycmVuY2UucHJlc2VudGF0aW9uU3RhdGUsIGNvbnRlbnRWZXJzaW9uSWQ6IHNlc3Npb24uY29udGVudFZlcnNpb25JZCB9IH0gOiB7fSkgfSkpIH0gfSwgc2Vzc2lvbi5zdGFydFN0YXRlLCBzZXNzaW9uLnN0YXR1cyksXG4gICAgfSB9LFxuICB9O1xufVxuXG4vKiogUmVwbGF5cyB0aGUgY2FwdHVyZWQgc2NlbmUgb2NjdXJyZW5jZXM7IHJlY29yZGVkIGFzc2VydGlvbnMgY2Fubm90IHN1YnN0aXR1dGUgZm9yIGFjdHVhbCBleGVjdXRpb24uICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVwbGF5Q2hhcHRlclJlYWRpbmcocHJvamVjdDogUHJvamVjdERhdGEsIHRyYWNlOiBUcmFjZURhdGEgJiBSdW50aW1lVHJhY2VFeHRlbnNpb25zLCBjaGVja3BvaW50OiBDaGVja3BvaW50RGF0YSwgb3B0aW9uczogUGljazxQcm9qZWN0VmFsaWRhdGlvbk9wdGlvbnMsICd3b3JsZFNuYXBzaG90cyc+ID0ge30pOiBQcm9taXNlPENoYXB0ZXJSZWFkaW5nU2Vzc2lvbj4ge1xuICBpZiAodHJhY2UubW9kZSAhPT0gJ2NoYXB0ZXJzJyB8fCAhdHJhY2UucmVhZGluZ1BhdGggfHwgdHJhY2Uuc3RlcHMubGVuZ3RoIHx8IHRyYWNlLmNvbnRlbnRWZXJzaW9uSWQgIT09IGNoZWNrcG9pbnQuY29udGVudFZlcnNpb25JZCkgdGhyb3cgbmV3IERvbWFpblZhbGlkYXRpb25FcnJvcihbeyBjb2RlOiAnVkFMSURBVElPTl9GQUlMRUQnLCBwYXRoOiAncmVhZGluZ1BhdGgnLCBtZXNzYWdlOiAn56ug6Kqt44G/6YCa44GX6KiY6Yyy44Gu54mI44G+44Gf44Gv5b2i5byP44GM5LiA6Ie044GX44G+44Gb44KT44CCJyB9XSk7XG4gIGlmICh0cmFjZS5pbml0aWFsV29ybGRUaWNrICE9IG51bGwgJiYgY2hlY2twb2ludC53b3JsZFRpY2sgIT0gbnVsbCAmJiB0cmFjZS5pbml0aWFsV29ybGRUaWNrICE9PSBjaGVja3BvaW50LndvcmxkVGljaykgdGhyb3cgbmV3IERvbWFpblZhbGlkYXRpb25FcnJvcihbeyBjb2RlOiAnSU5URUdSSVRZX0ZBSUxFRCcsIHBhdGg6ICdpbml0aWFsV29ybGRUaWNrJywgbWVzc2FnZTogJ+eroOe1jOi3r+OBruaPkOekuuaZgueCueOBqOS/neWtmOOBl+OBn+mWi+Wni+aZgueCueOBjOS4gOiHtOOBl+OBvuOBm+OCk+OAgicgfV0pO1xuICBsZXQgc2Vzc2lvbiA9IGF3YWl0IHN0YXJ0Q2hhcHRlclJlYWRpbmcocHJvamVjdCwgeyBjb250ZW50VmVyc2lvbklkOiB0cmFjZS5jb250ZW50VmVyc2lvbklkLCBjaGFwdGVySWRzOiB0cmFjZS5yZWFkaW5nUGF0aC5jaGFwdGVySWRzLCBzY2VuZUlkczogdHJhY2UucmVhZGluZ1BhdGguc2NlbmVJZHMsIHNlbGVjdGlvbjogdHJhY2UucmVhZGluZ1BhdGguc2VsZWN0aW9uID8/ICdzY2VuZXMnLCBzdGF0ZTogY2hlY2twb2ludC5ydW50aW1lU3RhdGUsIHdvcmxkVGljazogdHJhY2UuaW5pdGlhbFdvcmxkVGljayA/PyBjaGVja3BvaW50LndvcmxkVGljayA/PyB1bmRlZmluZWQsIGV4dGVybmFsVmFsdWVzOiB0cmFjZS5pbml0aWFsRXh0ZXJuYWxWYWx1ZXMgPz8ge30sIHdvcmxkU25hcHNob3RzOiBvcHRpb25zLndvcmxkU25hcHNob3RzIH0pO1xuICBpZiAodHJhY2UuY29udGVudFJldmlzaW9uICYmIHRyYWNlLmNvbnRlbnRSZXZpc2lvbiAhPT0gc2Vzc2lvbi5jb250ZW50UmV2aXNpb24gfHwgY2hlY2twb2ludC5jb250ZW50UmV2aXNpb24gJiYgY2hlY2twb2ludC5jb250ZW50UmV2aXNpb24gIT09IHNlc3Npb24uY29udGVudFJldmlzaW9uKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcsIHBhdGg6ICdjb250ZW50UmV2aXNpb24nLCBtZXNzYWdlOiAn6KiY6Yyy44GX44Gf6ZaL5aeL54q25oWL44Go5YaF5a6554mI44Gu5pu05paw55Wq5Y+344GM6YGV44GE44G+44GZ44CCJyB9XSk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCBbaW5kZXgsIG9jY3VycmVuY2VdIG9mIHRyYWNlLnJlYWRpbmdQYXRoLm9jY3VycmVuY2VzLmVudHJpZXMoKSkge1xuICAgIGlmIChzZWVuLmhhcyhvY2N1cnJlbmNlLm9jY3VycmVuY2VJZCkgfHwgb2NjdXJyZW5jZS5lbnRpdHlJZCAhPT0gdHJhY2UucmVhZGluZ1BhdGguc2NlbmVJZHNbaW5kZXhdIHx8IGNhbm9uaWNhbEpzb24oc2Vzc2lvbi5zdGF0ZSkgIT09IGNhbm9uaWNhbEpzb24ob2NjdXJyZW5jZS5iZWZvcmUpKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYHJlYWRpbmdQYXRoLm9jY3VycmVuY2VzWyR7aW5kZXh9XWAsIG1lc3NhZ2U6ICfoqq3jgb/pgJrjgZfjga7poIbluo/jg7vplovlp4vnirbmhYvjgb7jgZ/jga/mj5DnpLrorZjliKXlrZDjgYzkuIDoh7TjgZfjgb7jgZvjgpPjgIInIH1dKTtcbiAgICBzZWVuLmFkZChvY2N1cnJlbmNlLm9jY3VycmVuY2VJZCk7XG4gICAgc2Vzc2lvbiA9IHByZXNlbnROZXh0Q2hhcHRlclNjZW5lKHByb2plY3QsIHNlc3Npb24pO1xuICAgIGNvbnN0IG9ic2VydmVkID0gc2Vzc2lvbi5vY2N1cnJlbmNlcy5hdCgtMSk7XG4gICAgaWYgKG9jY3VycmVuY2UucHJlc2VudGF0aW9uU3RhdGUgJiYgKCFvYnNlcnZlZD8ucHJlc2VudGF0aW9uU3RhdGUgfHwgY2Fub25pY2FsSnNvbihvYnNlcnZlZC5wcmVzZW50YXRpb25TdGF0ZSkgIT09IGNhbm9uaWNhbEpzb24ob2NjdXJyZW5jZS5wcmVzZW50YXRpb25TdGF0ZSkpKSB0aHJvdyBuZXcgRG9tYWluVmFsaWRhdGlvbkVycm9yKFt7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYHJlYWRpbmdQYXRoLm9jY3VycmVuY2VzWyR7aW5kZXh9XS5wcmVzZW50YXRpb25TdGF0ZWAsIG1lc3NhZ2U6ICfmj5DnpLrliY3jga7oprPmuKznirbmhYvjgajlho3lrp/ooYzjgYzkuIDoh7TjgZfjgb7jgZvjgpPjgIInIH1dKTtcbiAgICBpZiAoIW9ic2VydmVkIHx8IGNhbm9uaWNhbEpzb24ob2JzZXJ2ZWQuYWZ0ZXIpICE9PSBjYW5vbmljYWxKc29uKG9jY3VycmVuY2UuYWZ0ZXIpIHx8IGNhbm9uaWNhbEpzb24ob2JzZXJ2ZWQuY29uZGl0aW9uUmVzdWx0cykgIT09IGNhbm9uaWNhbEpzb24ob2NjdXJyZW5jZS5jb25kaXRpb25SZXN1bHRzKSkgdGhyb3cgbmV3IERvbWFpblZhbGlkYXRpb25FcnJvcihbeyBjb2RlOiAnSU5URUdSSVRZX0ZBSUxFRCcsIHBhdGg6IGByZWFkaW5nUGF0aC5vY2N1cnJlbmNlc1ske2luZGV4fV1gLCBtZXNzYWdlOiAn6KiY6Yyy44GV44KM44Gf5o+Q56S65qC55oug44Go5YaN5a6f6KGM44GM5LiA6Ie044GX44G+44Gb44KT44CCJyB9XSk7XG4gICAgLy8gVGhpcyBpcyBhbiBvcGFxdWUsIGNhcHR1cmVkIG9jY3VycmVuY2UgaWRlbnRpdHksIG5vdCBhIHJlZmVyZW5jZSB0byB0aGVcbiAgICAvLyBzY2VuZSBlbWJlZGRlZCBpbiBpdHMgaGlzdG9yaWNhbCB0ZXh0LiBDbG9uaW5nIHJlbWFwcyBlbnRpdHlJZCBzZXBhcmF0ZWx5LlxuICAgIC8vIEtlZXAgaXQgb25seSBhZnRlciB0aGUgaW5kZXBlbmRlbnRseSBleGVjdXRlZCBzdGF0ZXMgYW5kIG9ic2VydmF0aW9ucyBtYXRjaC5cbiAgICBvYnNlcnZlZC5vY2N1cnJlbmNlSWQgPSBvY2N1cnJlbmNlLm9jY3VycmVuY2VJZDtcbiAgfVxuICByZXR1cm4gc2Vzc2lvbjtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsU0FBU0Esb0JBQW9CLEVBQUVDLHFCQUFxQixRQUFRLFNBQVM7QUFDckUsU0FBU0Msa0JBQWtCLEVBQUVDLHFCQUFxQixFQUFFQyxpQkFBaUIsRUFBRUMsc0JBQXNCLEVBQUVDLHFCQUFxQixFQUFFQyxzQkFBc0IsUUFBUSxjQUFjO0FBQ2xLLFNBQVNDLDJCQUEyQixRQUFRLG9CQUFvQjtBQUNoRSxTQUFTQyxxQkFBcUIsRUFBRUMsb0JBQW9CLFFBQVEsbUJBQW1CO0FBRS9FLFNBQVNDLGFBQWEsUUFBUSxpQkFBaUI7QUFDL0MsU0FBU0MscUJBQXFCLFFBQVEsa0JBQWtCO0FBQ3hELFNBQVNDLG1CQUFtQixRQUFRLGdCQUFnQjtBQUVwRCxTQUFTQyxhQUFhLFFBQVEsWUFBWTtBQUMxQyxTQUFTQyxtQkFBbUIsUUFBUSxjQUFjO0FBQ2xELFNBQVNDLHVCQUF1QixFQUFFQyxzQkFBc0IsUUFBUSxtQkFBbUI7QUFDbkYsU0FBU0MsTUFBTSxRQUFRLFFBQVE7QUFDL0IsU0FBU0MsbUJBQW1CLEVBQUVDLGtCQUFrQixFQUFFQyxXQUFXLEVBQUVDLGlCQUFpQixFQUFFQyxvQkFBb0IsUUFBUSxTQUFTO0FBQ3ZILFNBQVNDLDRCQUE0QixRQUFrQyxhQUFhO0FBSXBGLE1BQU1DLE1BQU0sR0FBR0EsQ0FBMkJDLE9BQW9CLEVBQUVDLElBQU8sS0FBa0JELE9BQU8sQ0FBQ0UsUUFBUSxDQUFDQyxNQUFNLENBQUVDLE1BQU0sSUFBMEJBLE1BQU0sQ0FBQ0gsSUFBSSxLQUFLQSxJQUFJLElBQUliLGFBQWEsQ0FBQ2dCLE1BQU0sQ0FBQyxDQUFDO0FBQ2hNLE1BQU1DLE9BQU8sR0FBR0EsQ0FBQ0MsSUFBWSxFQUFFQyxPQUFlLEVBQUVDLElBQTZCLEdBQUcsbUJBQW1CLE1BQTJCO0VBQUVDLEVBQUUsRUFBRSxLQUFLO0VBQUVDLE1BQU0sRUFBRSxDQUFDO0lBQUVGLElBQUk7SUFBRUYsSUFBSTtJQUFFQztFQUFRLENBQUM7QUFBRSxDQUFDLENBQUM7QUFFL0ssT0FBTyxTQUFTSSx1QkFBdUJBLENBQUNYLE9BQW9CLEVBQUVZLE1BQTBCLEVBQThDO0VBQUEsSUFBQUMsWUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxhQUFBO0VBQ3BJLE1BQU1DLElBQUksR0FBR2pCLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDaUIsSUFBSSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ0MsRUFBRSxLQUFLUCxNQUFNLENBQUNRLE1BQU0sQ0FBQztFQUNqRixNQUFNQyxLQUFLLEdBQUd0QixNQUFNLENBQUNDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQ2lCLElBQUksQ0FBQ0MsSUFBSTtJQUFBLElBQUFJLGVBQUE7SUFBQSxPQUFJSixJQUFJLENBQUNDLEVBQUUsT0FBQUcsZUFBQSxHQUFNVixNQUFNLENBQUNXLE9BQU8sY0FBQUQsZUFBQSxjQUFBQSxlQUFBLEdBQUlOLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFUSxJQUFJLENBQUNELE9BQU8sQ0FBQztFQUFBLEVBQUM7RUFDdkcsT0FBTztJQUFFRSxTQUFTLEVBQUV6QixPQUFPLENBQUN5QixTQUFTO0lBQUVDLFNBQVMsRUFBRWQsTUFBTSxDQUFDYyxTQUFTO0lBQUVDLE9BQU8sRUFBRVgsSUFBSSxJQUFBSCxZQUFBLEdBQUdkLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFLFlBQVksQ0FBQyxDQUFDaUIsSUFBSSxDQUFDVyxLQUFLLElBQUlBLEtBQUssQ0FBQ0osSUFBSSxDQUFDSyxPQUFPLENBQUNDLFFBQVEsQ0FBQ2QsSUFBSSxDQUFDRyxFQUFFLENBQUMsQ0FBQyxjQUFBTixZQUFBLHVCQUFqRkEsWUFBQSxDQUFtRk0sRUFBRSxHQUFHWSxTQUFTO0lBQUVDLFNBQVMsR0FBQWxCLHFCQUFBLEdBQUVPLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFRyxJQUFJLENBQUNRLFNBQVMsY0FBQWxCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUtPLEtBQUssSUFBQU4sYUFBQSxHQUFHaEIsTUFBTSxDQUFDQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUNpQixJQUFJLENBQUNnQixPQUFPLElBQUlBLE9BQU8sQ0FBQ1QsSUFBSSxDQUFDVSxRQUFRLENBQUNKLFFBQVEsQ0FBQ1QsS0FBSyxDQUFDRixFQUFFLENBQUMsQ0FBQyxjQUFBSixhQUFBLHVCQUFwRkEsYUFBQSxDQUFzRkksRUFBRSxHQUFHWTtFQUFXLENBQUM7QUFDN1U7O0FBRUE7QUFDQSxPQUFPLFNBQVNJLG1CQUFtQkEsQ0FBQ25DLE9BQW9CLEVBQUVZLE1BQTBCLEVBQVE7RUFBQSxJQUFBd0IscUJBQUEsRUFBQUMscUJBQUE7RUFDMUYsTUFBTXJCLElBQUksR0FBR2pCLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDaUIsSUFBSSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ0MsRUFBRSxLQUFLUCxNQUFNLENBQUNRLE1BQU0sQ0FBQztFQUNqRixNQUFNQyxLQUFLLEdBQUd0QixNQUFNLENBQUNDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQ2lCLElBQUksQ0FBQ0MsSUFBSTtJQUFBLElBQUFvQixnQkFBQTtJQUFBLE9BQUlwQixJQUFJLENBQUNDLEVBQUUsT0FBQW1CLGdCQUFBLEdBQU0xQixNQUFNLENBQUNXLE9BQU8sY0FBQWUsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSXRCLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFUSxJQUFJLENBQUNELE9BQU8sQ0FBQztFQUFBLEVBQUM7RUFDdkcsTUFBTWdCLE1BQU0sSUFBQUgscUJBQUEsR0FBR3BCLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFUSxJQUFJLENBQUNnQixlQUFlLGNBQUFKLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUssQ0FBQXBCLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFUSxJQUFJLENBQUNpQixRQUFRLE1BQUssV0FBVyxHQUFHLGFBQWEsR0FBRyxlQUFnQjtFQUNwSCxPQUFPLENBQUMsR0FBRyxJQUFJQyxHQUFHLENBQUMsQ0FBQyxLQUFBTCxxQkFBQSxHQUFJaEIsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUVHLElBQUksQ0FBQ21CLGVBQWUsY0FBQU4scUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLENBQUMsRUFBRSxJQUFJckIsSUFBSSxJQUFJdUIsTUFBTSxLQUFLLGVBQWUsR0FBR3hDLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDRyxNQUFNLENBQUN5QyxJQUFJLElBQUlBLElBQUksQ0FBQ3BCLElBQUksQ0FBQ3FCLE1BQU0sS0FBSzdCLElBQUksQ0FBQ0csRUFBRSxDQUFDLENBQUMyQixPQUFPLENBQUNGLElBQUksSUFBSUEsSUFBSSxDQUFDcEIsSUFBSSxDQUFDdUIsWUFBWSxHQUFHLENBQUNILElBQUksQ0FBQ3BCLElBQUksQ0FBQ3VCLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqUTtBQUVBLE9BQU8sU0FBU0MseUJBQXlCQSxDQUFDaEQsT0FBb0IsRUFBRWlELEtBQW1CLEVBQUVDLE1BQXFCLEVBQUV0QyxNQUEwQixFQUFFdUMsYUFBa0IsRUFBVztFQUFBLElBQUFDLFlBQUEsRUFBQUMsZ0JBQUE7RUFDbkssSUFBSUgsTUFBTSxDQUFDSSxjQUFjLEtBQUssWUFBWSxFQUFFLE9BQU8sS0FBSztFQUN4RCxNQUFNQyxXQUFXLEdBQUdKLGFBQWEsR0FBR3hELFdBQVcsQ0FBQ0ssT0FBTyxFQUFFbUQsYUFBYSxDQUFDLEdBQUdwQixTQUFTO0VBQ25GLElBQUltQixNQUFNLENBQUNNLGVBQWUsSUFBSSxDQUFDLENBQUN4RCxPQUFPLENBQUN5QixTQUFTLEVBQUV3QixLQUFLLENBQUNRLGdCQUFnQixHQUFBTCxZQUFBLEdBQUV6RCxXQUFXLENBQUNLLE9BQU8sRUFBRWtELE1BQU0sQ0FBQ1EsUUFBUSxDQUFDLGNBQUFOLFlBQUEsdUJBQXJDQSxZQUFBLENBQXVDSSxlQUFlLEVBQUVELFdBQVcsYUFBWEEsV0FBVyx1QkFBWEEsV0FBVyxDQUFFQyxlQUFlLENBQUMsQ0FBQzFCLFFBQVEsQ0FBQ29CLE1BQU0sQ0FBQ00sZUFBZSxDQUFDLEVBQUUsT0FBTyxLQUFLO0VBQy9NLE1BQU14QyxJQUFJLEdBQUdqQixNQUFNLENBQUNDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQ2lCLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNDLEVBQUUsS0FBS1AsTUFBTSxDQUFDUSxNQUFNLENBQUM7RUFDakYsTUFBTUcsT0FBTyxJQUFBOEIsZ0JBQUEsR0FBR3pDLE1BQU0sQ0FBQ1csT0FBTyxjQUFBOEIsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSXJDLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFUSxJQUFJLENBQUNELE9BQU87RUFDcEQsTUFBTUYsS0FBSyxHQUFHdEIsTUFBTSxDQUFDQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUNpQixJQUFJLENBQUNDLElBQUksSUFBSUEsSUFBSSxDQUFDQyxFQUFFLEtBQUtJLE9BQU8sQ0FBQztFQUN4RSxNQUFNb0MsS0FBSyxHQUFHeEIsbUJBQW1CLENBQUNuQyxPQUFPLEVBQUVZLE1BQU0sQ0FBQztFQUNsRCxJQUFJLENBQUMsQ0FBQ0EsTUFBTSxDQUFDUSxNQUFNLEVBQUVHLE9BQU8sRUFBRSxHQUFHb0MsS0FBSyxDQUFDLENBQUM3QixRQUFRLENBQUNvQixNQUFNLENBQUNRLFFBQVEsQ0FBQyxFQUFFLE9BQU8sS0FBSztFQUMvRSxPQUFPLENBQUNSLE1BQU0sQ0FBQ1EsUUFBUSxFQUFFUixNQUFNLENBQUNVLE9BQU8sRUFBRVYsTUFBTSxDQUFDVyxNQUFNLENBQUMsQ0FBQzFELE1BQU0sQ0FBRWdCLEVBQUUsSUFBZSxDQUFDLENBQUNBLEVBQUUsQ0FBQyxDQUFDMkMsS0FBSyxDQUFDM0MsRUFBRSxJQUFJOEIsS0FBSyxDQUFDYyxPQUFPLENBQUNqQyxRQUFRLENBQUNYLEVBQUUsQ0FBQyxDQUFDO0FBQ2hJOztBQUVBO0FBQ0EsT0FBTyxTQUFTNkMsdUJBQXVCQSxDQUFDaEUsT0FBb0IsRUFBRWlFLElBQW1CLEVBQUVDLEtBQW9CLEVBQUV0RCxNQUEwQixFQUF1QjtFQUFBLElBQUF1RCxnQkFBQSxFQUFBQyxJQUFBLEVBQUFDLGFBQUEsRUFBQUMsS0FBQSxFQUFBQyxjQUFBO0VBQ3hKLElBQUlOLElBQUksQ0FBQ1gsY0FBYyxLQUFLLFlBQVksSUFBSVksS0FBSyxDQUFDWixjQUFjLEtBQUssWUFBWSxFQUFFLE9BQU92QixTQUFTO0VBQ25HLE1BQU1mLElBQUksR0FBR2pCLE1BQU0sQ0FBQ0MsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDaUIsSUFBSSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ0MsRUFBRSxLQUFLUCxNQUFNLENBQUNRLE1BQU0sQ0FBQztFQUNqRixNQUFNQyxLQUFLLEdBQUd0QixNQUFNLENBQUNDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQ2lCLElBQUksQ0FBQ0MsSUFBSTtJQUFBLElBQUFzRCxnQkFBQTtJQUFBLE9BQUl0RCxJQUFJLENBQUNDLEVBQUUsT0FBQXFELGdCQUFBLEdBQU01RCxNQUFNLENBQUNXLE9BQU8sY0FBQWlELGdCQUFBLGNBQUFBLGdCQUFBLEdBQUl4RCxJQUFJLGFBQUpBLElBQUksdUJBQUpBLElBQUksQ0FBRVEsSUFBSSxDQUFDRCxPQUFPLENBQUM7RUFBQSxFQUFDO0VBQ3ZHLE1BQU1rRCxPQUFPLEdBQUd0QyxtQkFBbUIsQ0FBQ25DLE9BQU8sRUFBRVksTUFBTSxDQUFDO0VBQ3BELE1BQU04RCxTQUFTLEdBQUcsQ0FBQyxHQUFHLEVBQUFQLGdCQUFBLEdBQUM5QyxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRUcsSUFBSSxDQUFDbUQsSUFBSSxjQUFBUixnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEVBQUUsRUFBRVMsR0FBRyxDQUFDQyxLQUFLLElBQUlBLEtBQUssQ0FBQzFELEVBQUUsQ0FBQyxDQUFDO0VBQ3RFLEtBQUssTUFBTTBDLE1BQU0sSUFBSVksT0FBTztJQUFBLElBQUFLLHFCQUFBLEVBQUFDLGFBQUE7SUFBRUwsU0FBUyxDQUFDTSxJQUFJLENBQUNuQixNQUFNLEVBQUUsR0FBRyxFQUFBaUIscUJBQUEsSUFBQUMsYUFBQSxHQUFDaEYsTUFBTSxDQUFDQyxPQUFPLEVBQUUsZUFBZSxDQUFDLENBQUNpQixJQUFJLENBQUNnRSxJQUFJLElBQUlBLElBQUksQ0FBQzlELEVBQUUsS0FBSzBDLE1BQU0sQ0FBQyxjQUFBa0IsYUFBQSx1QkFBakVBLGFBQUEsQ0FBbUV2RCxJQUFJLENBQUMwRCxJQUFJLGNBQUFKLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFRixHQUFHLENBQUNDLEtBQUssSUFBSUEsS0FBSyxDQUFDMUQsRUFBRSxDQUFDLENBQUM7RUFBQztFQUNySyxNQUFNZ0UsU0FBUyxJQUFBZixJQUFBLElBQUFDLGFBQUEsR0FBR0osSUFBSSxDQUFDTCxPQUFPLGNBQUFTLGFBQUEsY0FBQUEsYUFBQSxHQUFJSixJQUFJLENBQUNKLE1BQU0sY0FBQU8sSUFBQSxjQUFBQSxJQUFBLEdBQUtLLE9BQU8sQ0FBQzNDLFFBQVEsQ0FBQ21DLElBQUksQ0FBQ1AsUUFBUSxDQUFDLEdBQUdPLElBQUksQ0FBQ1AsUUFBUSxHQUFHM0IsU0FBVTtFQUM5RyxNQUFNcUQsVUFBVSxJQUFBZCxLQUFBLElBQUFDLGNBQUEsR0FBR0wsS0FBSyxDQUFDTixPQUFPLGNBQUFXLGNBQUEsY0FBQUEsY0FBQSxHQUFJTCxLQUFLLENBQUNMLE1BQU0sY0FBQVMsS0FBQSxjQUFBQSxLQUFBLEdBQUtHLE9BQU8sQ0FBQzNDLFFBQVEsQ0FBQ29DLEtBQUssQ0FBQ1IsUUFBUSxDQUFDLEdBQUdRLEtBQUssQ0FBQ1IsUUFBUSxHQUFHM0IsU0FBVTtFQUNuSCxNQUFNc0QsS0FBSyxHQUFHWCxTQUFTLENBQUNZLE9BQU8sQ0FBQ0gsU0FBUyxhQUFUQSxTQUFTLGNBQVRBLFNBQVMsR0FBSSxFQUFFLENBQUM7SUFBRUksTUFBTSxHQUFHYixTQUFTLENBQUNZLE9BQU8sQ0FBQ0YsVUFBVSxhQUFWQSxVQUFVLGNBQVZBLFVBQVUsR0FBSSxFQUFFLENBQUM7RUFDOUYsSUFBSUMsS0FBSyxJQUFJLENBQUMsSUFBSUUsTUFBTSxJQUFJLENBQUMsSUFBSUYsS0FBSyxLQUFLRSxNQUFNLEVBQUUsT0FBT0YsS0FBSyxHQUFHRSxNQUFNO0VBQ3hFLElBQUlKLFNBQVMsS0FBS0MsVUFBVSxJQUFJbkIsSUFBSSxDQUFDUCxRQUFRLEtBQUtRLEtBQUssQ0FBQ1IsUUFBUSxJQUFJTyxJQUFJLENBQUN1QixLQUFLLElBQUksSUFBSSxJQUFJdEIsS0FBSyxDQUFDc0IsS0FBSyxJQUFJLElBQUksSUFBSXZCLElBQUksQ0FBQ3VCLEtBQUssS0FBS3RCLEtBQUssQ0FBQ3NCLEtBQUssRUFBRSxPQUFPekQsU0FBUztFQUM3SixJQUFJa0MsSUFBSSxDQUFDdUIsS0FBSyxHQUFHdEIsS0FBSyxDQUFDc0IsS0FBSyxJQUFJdkIsSUFBSSxDQUFDd0IsR0FBRyxJQUFJLElBQUksSUFBSXhCLElBQUksQ0FBQ3dCLEdBQUcsR0FBR3ZCLEtBQUssQ0FBQ3NCLEtBQUssSUFBSXRCLEtBQUssQ0FBQ3NCLEtBQUssR0FBR3ZCLElBQUksQ0FBQ3VCLEtBQUssSUFBSXRCLEtBQUssQ0FBQ3VCLEdBQUcsSUFBSSxJQUFJLElBQUl2QixLQUFLLENBQUN1QixHQUFHLEdBQUd4QixJQUFJLENBQUN1QixLQUFLLEVBQUUsT0FBT3pELFNBQVM7RUFDdkssT0FBT2tDLElBQUksQ0FBQ3VCLEtBQUssR0FBR3RCLEtBQUssQ0FBQ3NCLEtBQUs7QUFDakM7O0FBRUE7QUFDQSxPQUFPLFNBQVNFLGNBQWNBLENBQUMxRixPQUFvQixFQUFFaUQsS0FBbUIsRUFBRXJDLE1BQTBCLEVBQXVCO0VBQUEsSUFBQStFLHFCQUFBO0VBQ3pILE1BQU1DLE9BQU8sR0FBR3RILG9CQUFvQixDQUFDMkUsS0FBSyxDQUFDO0VBQUUsSUFBSSxDQUFDMkMsT0FBTyxDQUFDbkYsRUFBRSxFQUFFLE9BQU87SUFBRUEsRUFBRSxFQUFFLEtBQUs7SUFBRUMsTUFBTSxFQUFFa0YsT0FBTyxDQUFDbEY7RUFBTyxDQUFDO0VBQzFHLE1BQU1tRixjQUFjLEdBQUczRyxxQkFBcUIsQ0FBQ2MsT0FBTyxHQUFBMkYscUJBQUEsR0FBRS9FLE1BQU0sQ0FBQ2tGLGNBQWMsY0FBQUgscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxDQUFDLENBQUMsRUFBRTVELFNBQVMsRUFBRW5CLE1BQU0sQ0FBQ21GLGlCQUFpQixDQUFDO0VBQUUsSUFBSUYsY0FBYyxDQUFDRyxNQUFNLEVBQUUsT0FBTztJQUFFdkYsRUFBRSxFQUFFLEtBQUs7SUFBRUMsTUFBTSxFQUFFbUY7RUFBZSxDQUFDO0VBQ2hNLElBQUk7SUFBQSxJQUFBSSxLQUFBLEVBQUFDLGdCQUFBLEVBQUFDLHFCQUFBO0lBQ0YsTUFBTW5GLElBQUksR0FBR0osTUFBTSxDQUFDUSxNQUFNLEdBQUdyQixNQUFNLENBQUNDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQ2lCLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNDLEVBQUUsS0FBS1AsTUFBTSxDQUFDUSxNQUFNLENBQUMsR0FBR1csU0FBUztJQUM3RyxJQUFJbkIsTUFBTSxDQUFDUSxNQUFNLElBQUksQ0FBQ0osSUFBSSxFQUFFLE9BQU9YLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSx5QkFBeUIsQ0FBQztJQUM1RixNQUFNa0IsT0FBTyxJQUFBMEUsS0FBQSxJQUFBQyxnQkFBQSxHQUFHdEYsTUFBTSxDQUFDVyxPQUFPLGNBQUEyRSxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJbEYsSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVRLElBQUksQ0FBQ0QsT0FBTyxjQUFBMEUsS0FBQSxjQUFBQSxLQUFBLEdBQUlsRSxTQUFTO0lBQ2pFLElBQUksQ0FBQ2YsSUFBSSxJQUFJLENBQUNPLE9BQU8sRUFBRSxPQUFPbEIsT0FBTyxDQUFDLGNBQWMsRUFBRSx1QkFBdUIsQ0FBQztJQUM5RSxNQUFNZ0IsS0FBSyxHQUFHRSxPQUFPLEdBQUd4QixNQUFNLENBQUNDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQ2lCLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNDLEVBQUUsS0FBS0ksT0FBTyxDQUFDLEdBQUdRLFNBQVM7SUFDOUYsSUFBSVIsT0FBTyxJQUFJLENBQUNGLEtBQUssRUFBRSxPQUFPaEIsT0FBTyxDQUFDLHNCQUFzQixFQUFFLHlCQUF5QixDQUFDO0lBQ3hGLE1BQU0rRixjQUFjLEdBQUd6Rix1QkFBdUIsQ0FBQ1gsT0FBTyxFQUFFO01BQUUsR0FBR1ksTUFBTTtNQUFFVztJQUFRLENBQUMsQ0FBQztJQUMvRSxNQUFNOEUsYUFBYSxHQUFHeEgsc0JBQXNCLENBQUM7TUFBRW9FLEtBQUs7TUFBRS9DLFFBQVEsRUFBRUYsT0FBTyxDQUFDRSxRQUFRO01BQUU2RixpQkFBaUIsRUFBRW5GLE1BQU0sQ0FBQ21GLGlCQUFpQjtNQUFFRCxjQUFjLEVBQUVsRixNQUFNLENBQUNrRixjQUFjO01BQUVRLFdBQVcsRUFBRUYsY0FBYztNQUFFRyxZQUFZLEVBQUUzRyxpQkFBaUIsQ0FBQ0ksT0FBTyxFQUFFb0csY0FBYztJQUFFLENBQUMsQ0FBQztJQUM5UCxJQUFJQyxhQUFhLENBQUNMLE1BQU0sRUFBRSxPQUFPO01BQUV2RixFQUFFLEVBQUUsS0FBSztNQUFFQyxNQUFNLEVBQUUyRjtJQUFjLENBQUM7SUFDckUsTUFBTUcsUUFBUSxHQUFHO1FBQUUsR0FBRzVGLE1BQU07UUFBRVc7TUFBUSxDQUFDO01BQUVrRixJQUFJLEdBQUdDLGVBQWUsQ0FBQ3pELEtBQUssQ0FBQztNQUFFMEQsSUFBSSxHQUFHLElBQUlqRSxHQUFHLENBQUMrRCxJQUFJLENBQUMxQyxPQUFPLENBQUM7SUFDcEcsSUFBSS9DLElBQUksRUFBRTtNQUFBLElBQUE0RixxQkFBQTtNQUFFSCxJQUFJLENBQUNJLG9CQUFvQixHQUFHN0YsSUFBSSxDQUFDRyxFQUFFO01BQUVzRixJQUFJLENBQUNLLFdBQVcsQ0FBQzlGLElBQUksQ0FBQ0csRUFBRSxDQUFDLEdBQUcsRUFBQXlGLHFCQUFBLEdBQUNILElBQUksQ0FBQ0ssV0FBVyxDQUFDOUYsSUFBSSxDQUFDRyxFQUFFLENBQUMsY0FBQXlGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxJQUFJLENBQUM7TUFBRUQsSUFBSSxDQUFDSSxHQUFHLENBQUMvRixJQUFJLENBQUNHLEVBQUUsQ0FBQztJQUFFO0lBQ3RJLElBQUlFLEtBQUssRUFBRTtNQUFBLElBQUEyRixxQkFBQTtNQUNUTCxJQUFJLENBQUNJLEdBQUcsQ0FBQzFGLEtBQUssQ0FBQ0YsRUFBRSxDQUFDO01BQUVzRixJQUFJLENBQUNLLFdBQVcsQ0FBQ3pGLEtBQUssQ0FBQ0YsRUFBRSxDQUFDLEdBQUcsRUFBQTZGLHFCQUFBLEdBQUNQLElBQUksQ0FBQ0ssV0FBVyxDQUFDekYsS0FBSyxDQUFDRixFQUFFLENBQUMsY0FBQTZGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxJQUFJLENBQUM7TUFDdEYsS0FBSyxNQUFNN0YsRUFBRSxLQUFBOEYsb0JBQUEsR0FBSTVGLEtBQUssQ0FBQ0csSUFBSSxDQUFDMEYsUUFBUSxjQUFBRCxvQkFBQSxjQUFBQSxvQkFBQSxHQUFJLEVBQUU7UUFBQSxJQUFBQSxvQkFBQTtRQUFFTixJQUFJLENBQUNJLEdBQUcsQ0FBQzVGLEVBQUUsQ0FBQztNQUFDO01BQ3pELEtBQUssTUFBTTBELEtBQUssSUFBSXhELEtBQUssQ0FBQ0csSUFBSSxDQUFDbUQsSUFBSSxFQUFFZ0MsSUFBSSxDQUFDSSxHQUFHLENBQUNsQyxLQUFLLENBQUMxRCxFQUFFLENBQUM7SUFDekQ7SUFDQSxLQUFLLE1BQU0wQyxNQUFNLElBQUkxQixtQkFBbUIsQ0FBQ25DLE9BQU8sRUFBRXdHLFFBQVEsQ0FBQyxFQUFFO01BQUEsSUFBQVcsUUFBQSxFQUFBQyxxQkFBQTtNQUMzRCxNQUFNbkMsSUFBSSxHQUFHbEYsTUFBTSxDQUFDQyxPQUFPLEVBQUUsZUFBZSxDQUFDLENBQUNpQixJQUFJLENBQUNDLElBQUksSUFBSUEsSUFBSSxDQUFDQyxFQUFFLEtBQUswQyxNQUFNLENBQUM7TUFDOUUsSUFBSSxDQUFDb0IsSUFBSSxFQUFFLE9BQU81RSxPQUFPLENBQUMsSUFBQThHLFFBQUEsR0FBR25HLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFRyxFQUFFLGNBQUFnRyxRQUFBLGNBQUFBLFFBQUEsR0FBSTlGLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFRixFQUFFLGtCQUFrQixFQUFFLHlCQUF5QixDQUFDO01BQ2hHd0YsSUFBSSxDQUFDSSxHQUFHLENBQUM5QixJQUFJLENBQUM5RCxFQUFFLENBQUM7TUFBRXNGLElBQUksQ0FBQ0ssV0FBVyxDQUFDN0IsSUFBSSxDQUFDOUQsRUFBRSxDQUFDLEdBQUcsRUFBQWlHLHFCQUFBLEdBQUNYLElBQUksQ0FBQ0ssV0FBVyxDQUFDN0IsSUFBSSxDQUFDOUQsRUFBRSxDQUFDLGNBQUFpRyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsSUFBSSxDQUFDO01BQUUsS0FBSyxNQUFNdkMsS0FBSyxJQUFJSSxJQUFJLENBQUN6RCxJQUFJLENBQUMwRCxJQUFJLEVBQUV5QixJQUFJLENBQUNJLEdBQUcsQ0FBQ2xDLEtBQUssQ0FBQzFELEVBQUUsQ0FBQztJQUM3STtJQUNBc0YsSUFBSSxDQUFDMUMsT0FBTyxHQUFHLENBQUMsR0FBRzRDLElBQUksQ0FBQztJQUN4QixNQUFNVSxTQUFTLEdBQUcsQ0FBQyxHQUFHdEgsTUFBTSxDQUFDQyxPQUFPLEVBQUUsVUFBVSxDQUFDLEVBQUUsR0FBRyxFQUFBbUcscUJBQUEsR0FBQ3ZGLE1BQU0sQ0FBQ21GLGlCQUFpQixjQUFBSSxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUUsRUFBRWhHLE1BQU0sQ0FBRUMsTUFBTSxJQUFtQ0EsTUFBTSxDQUFDSCxJQUFJLEtBQUssVUFBVSxJQUFJYixhQUFhLENBQUNnQixNQUFNLENBQUMsQ0FBQyxDQUFDO01BQUVrRyxXQUFXLEdBQUczRix1QkFBdUIsQ0FBQ1gsT0FBTyxFQUFFd0csUUFBUSxDQUFDO01BQUVjLE9BQU8sR0FBRztRQUFFckUsS0FBSyxFQUFFd0QsSUFBSTtRQUFFWSxTQUFTO1FBQUVuSCxRQUFRLEVBQUVGLE9BQU8sQ0FBQ0UsUUFBUTtRQUFFNkYsaUJBQWlCLEVBQUVuRixNQUFNLENBQUNtRixpQkFBaUI7UUFBRUQsY0FBYyxFQUFFbEYsTUFBTSxDQUFDa0YsY0FBYztRQUFFUSxXQUFXO1FBQUVDLFlBQVksRUFBRTNHLGlCQUFpQixDQUFDSSxPQUFPLEVBQUVzRyxXQUFXO01BQUUsQ0FBQztJQUNqZCxNQUFNaUIsVUFBeUMsR0FBRyxFQUFFO01BQUVDLFdBQW1DLEdBQUcsRUFBRTtJQUM5RixLQUFLLE1BQU1DLFVBQVUsSUFBSTFILE1BQU0sQ0FBQ0MsT0FBTyxFQUFFLFlBQVksQ0FBQyxFQUFFO01BQUEsSUFBQTBILHFCQUFBLEVBQUFDLGFBQUEsRUFBQUMsYUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxxQkFBQTtNQUN0RCxNQUFNNUUsTUFBTSxHQUFHckQsb0JBQW9CLENBQUNHLE9BQU8sRUFBRXlILFVBQVUsQ0FBQ2pHLElBQUksQ0FBQzBCLE1BQU0sRUFBRXVFLFVBQVUsQ0FBQ3RHLEVBQUUsQ0FBQztNQUNuRixNQUFNNEcsS0FBSyxHQUFHTixVQUFVLENBQUNqRyxJQUFJLENBQUN3RyxXQUFXO01BQ3pDLE1BQU1DLGlCQUFpQixHQUFHO1FBQUUsR0FBR1gsT0FBTztRQUFFaEIsV0FBVyxHQUFBb0IscUJBQUEsR0FBRUosT0FBTyxDQUFDZixZQUFZLENBQUNrQixVQUFVLENBQUN0RyxFQUFFLENBQUMsY0FBQXVHLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUlKLE9BQU8sQ0FBQ2hCO01BQVksQ0FBQztNQUNqSCxNQUFNNEIsV0FBVyxHQUFHSCxLQUFLLEdBQUcxSSxtQkFBbUIsQ0FBQzBJLEtBQUssRUFBRUUsaUJBQWlCLENBQUMsR0FBRztRQUFFRSxLQUFLLEVBQUU7TUFBTyxDQUFDO01BQzdGLElBQUlELFdBQVcsQ0FBQ0MsS0FBSyxLQUFLLE9BQU8sRUFBRTtNQUNuQyxJQUFJakYsTUFBTSxDQUFDTSxlQUFlLElBQUksQ0FBQyxDQUFDeEQsT0FBTyxDQUFDeUIsU0FBUyxFQUFFd0IsS0FBSyxDQUFDUSxnQkFBZ0IsR0FBQWtFLGFBQUEsR0FBRWhJLFdBQVcsQ0FBQ0ssT0FBTyxFQUFFa0QsTUFBTSxDQUFDUSxRQUFRLENBQUMsY0FBQWlFLGFBQUEsdUJBQXJDQSxhQUFBLENBQXVDbkUsZUFBZSxHQUFBb0UsYUFBQSxHQUFFakksV0FBVyxDQUFDSyxPQUFPLEVBQUV5SCxVQUFVLENBQUN0RyxFQUFFLENBQUMsY0FBQXlHLGFBQUEsdUJBQW5DQSxhQUFBLENBQXFDcEUsZUFBZSxDQUFDLENBQUMxQixRQUFRLENBQUNvQixNQUFNLENBQUNNLGVBQWUsQ0FBQyxFQUFFO01BQzNOLE1BQU1pQixPQUFPLEdBQUd0QyxtQkFBbUIsQ0FBQ25DLE9BQU8sRUFBRXdHLFFBQVEsQ0FBQztNQUN0RCxJQUFJLENBQUMsQ0FBQ3hGLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFRyxFQUFFLEVBQUVFLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFRixFQUFFLEVBQUUsR0FBR3NELE9BQU8sQ0FBQyxDQUFDM0MsUUFBUSxDQUFDb0IsTUFBTSxDQUFDUSxRQUFRLENBQUMsRUFBRTtNQUNsRSxJQUFJd0UsV0FBVyxDQUFDQyxLQUFLLEtBQUssU0FBUyxFQUFFLE9BQU85SCxPQUFPLENBQUMsR0FBR29ILFVBQVUsQ0FBQ3RHLEVBQUUsY0FBYyxFQUFFLHFCQUFxQixFQUFFLG1CQUFtQixDQUFDO01BQy9ILElBQUkrQixNQUFNLENBQUNJLGNBQWMsS0FBSyxZQUFZLElBQUksQ0FBQ3RDLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFRyxFQUFFLEVBQUVFLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFRixFQUFFLEVBQUUsR0FBR3NELE9BQU8sQ0FBQyxDQUFDM0MsUUFBUSxDQUFDb0IsTUFBTSxDQUFDUSxRQUFRLENBQUMsRUFBRSxPQUFPckQsT0FBTyxDQUFDLEdBQUdvSCxVQUFVLENBQUN0RyxFQUFFLFNBQVMsRUFBRStCLE1BQU0sQ0FBQ2tGLGNBQWMsSUFBSSwwQkFBMEIsRUFBRSxtQkFBbUIsQ0FBQztNQUM5TixJQUFJLENBQUNwRix5QkFBeUIsQ0FBQ2hELE9BQU8sRUFBRXlHLElBQUksRUFBRXZELE1BQU0sRUFBRXNELFFBQVEsRUFBRWlCLFVBQVUsQ0FBQ3RHLEVBQUUsQ0FBQyxFQUFFO01BQ2hGLE1BQU1rSCxNQUFNLEdBQUczSixpQkFBaUIsQ0FBQztRQUFFNEosRUFBRSxFQUFFLEtBQUs7UUFBRUMsUUFBUSxFQUFFLEVBQUFWLHFCQUFBLEdBQUNKLFVBQVUsQ0FBQ2pHLElBQUksQ0FBQ2dILFNBQVMsY0FBQVgscUJBQUEsY0FBQUEscUJBQUEsR0FBSTtVQUFFUyxFQUFFLEVBQUUsVUFBVTtVQUFFSCxLQUFLLEVBQUU7UUFBSyxDQUFDLEdBQUFMLHFCQUFBLEdBQUVDLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFVSxjQUFjLGNBQUFYLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUk7VUFBRVEsRUFBRSxFQUFFLFVBQVU7VUFBRUgsS0FBSyxFQUFFO1FBQUssQ0FBQztNQUFFLENBQUMsRUFBRUYsaUJBQWlCLENBQUM7TUFDdE1WLFVBQVUsQ0FBQ3ZDLElBQUksQ0FBQztRQUFFMEQsUUFBUSxFQUFFakIsVUFBVSxDQUFDdEcsRUFBRTtRQUFFLEdBQUdrSDtNQUFPLENBQUMsQ0FBQztNQUN2RCxJQUFJQSxNQUFNLENBQUNGLEtBQUssS0FBSyxTQUFTLEVBQUUsT0FBTzlILE9BQU8sQ0FBQyxHQUFHb0gsVUFBVSxDQUFDdEcsRUFBRSxZQUFZLEVBQUVrSCxNQUFNLENBQUNNLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLGtCQUFrQixFQUFFLG1CQUFtQixDQUFDO01BQ2pKLElBQUlQLE1BQU0sQ0FBQ0YsS0FBSyxLQUFLLE1BQU0sRUFBRVgsV0FBVyxDQUFDeEMsSUFBSSxDQUFDeUMsVUFBVSxDQUFDO0lBQzNEO0lBQ0EsTUFBTW9CLE9BQU8sR0FBR3JCLFdBQVcsQ0FBQ3JILE1BQU0sQ0FBQ3NILFVBQVU7TUFBQSxJQUFBcUIscUJBQUEsRUFBQUMsc0JBQUE7TUFBQSxPQUFJLEVBQUFELHFCQUFBLElBQUFDLHNCQUFBLEdBQUN0QixVQUFVLENBQUNqRyxJQUFJLENBQUN3SCxnQkFBZ0IsY0FBQUQsc0JBQUEsdUJBQWhDQSxzQkFBQSxDQUFrQy9DLE1BQU0sY0FBQThDLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxJQUFJLENBQUM7SUFBQSxFQUFDO0lBQ3JHLEtBQUssSUFBSUcsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHSixPQUFPLENBQUM3QyxNQUFNLEVBQUVpRCxDQUFDLEVBQUUsRUFBRSxLQUFLLElBQUlDLENBQUMsR0FBR0QsQ0FBQyxHQUFHLENBQUMsRUFBRUMsQ0FBQyxHQUFHTCxPQUFPLENBQUM3QyxNQUFNLEVBQUVrRCxDQUFDLEVBQUU7TUFBQSxJQUFBQyxTQUFBO01BQUUsSUFBSW5GLHVCQUF1QixDQUFDaEUsT0FBTyxFQUFFSCxvQkFBb0IsQ0FBQ0csT0FBTyxFQUFFNkksT0FBTyxDQUFDSSxDQUFDLENBQUMsQ0FBQ3pILElBQUksQ0FBQzBCLE1BQU0sRUFBRTJGLE9BQU8sQ0FBQ0ksQ0FBQyxDQUFDLENBQUM5SCxFQUFFLENBQUMsRUFBRXRCLG9CQUFvQixDQUFDRyxPQUFPLEVBQUU2SSxPQUFPLENBQUNLLENBQUMsQ0FBQyxDQUFDMUgsSUFBSSxDQUFDMEIsTUFBTSxFQUFFMkYsT0FBTyxDQUFDSyxDQUFDLENBQUMsQ0FBQy9ILEVBQUUsQ0FBQyxFQUFFcUYsUUFBUSxDQUFDLEtBQUt6RSxTQUFTLEVBQUUsT0FBTzFCLE9BQU8sQ0FBQyxJQUFBOEksU0FBQSxHQUFHbkksSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVHLEVBQUUsY0FBQWdJLFNBQUEsY0FBQUEsU0FBQSxHQUFJOUgsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUVGLEVBQUUsY0FBYyxFQUFFLHdDQUF3QyxFQUFFLG1CQUFtQixDQUFDO0lBQUM7SUFDdFowSCxPQUFPLENBQUNPLElBQUksQ0FBQyxDQUFDbkYsSUFBSSxFQUFFQyxLQUFLLEtBQUtGLHVCQUF1QixDQUFDaEUsT0FBTyxFQUFFSCxvQkFBb0IsQ0FBQ0csT0FBTyxFQUFFaUUsSUFBSSxDQUFDekMsSUFBSSxDQUFDMEIsTUFBTSxFQUFFZSxJQUFJLENBQUM5QyxFQUFFLENBQUMsRUFBRXRCLG9CQUFvQixDQUFDRyxPQUFPLEVBQUVrRSxLQUFLLENBQUMxQyxJQUFJLENBQUMwQixNQUFNLEVBQUVnQixLQUFLLENBQUMvQyxFQUFFLENBQUMsRUFBRXFGLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4TSxNQUFNNkMsT0FBMkIsR0FBRyxFQUFFO01BQUVDLG1CQUF1RSxHQUFHLEVBQUU7SUFDcEgsS0FBSyxNQUFNN0IsVUFBVSxJQUFJb0IsT0FBTyxFQUFFLEtBQUssTUFBTVUsUUFBUSxLQUFBQyxzQkFBQSxHQUFJL0IsVUFBVSxDQUFDakcsSUFBSSxDQUFDd0gsZ0JBQWdCLGNBQUFRLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksRUFBRSxFQUFFO01BQUEsSUFBQUEsc0JBQUEsRUFBQUMsc0JBQUE7TUFDL0YsTUFBTUMsTUFBTSxHQUFHLENBQUMsR0FBRzFKLE9BQU8sQ0FBQ0UsUUFBUSxFQUFFLEtBQUF1SixzQkFBQSxHQUFJN0ksTUFBTSxDQUFDbUYsaUJBQWlCLGNBQUEwRCxzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUN4SSxJQUFJLENBQUVDLElBQUksSUFBK0JBLElBQUksQ0FBQ2pCLElBQUksS0FBSyxRQUFRLElBQUlpQixJQUFJLENBQUNDLEVBQUUsS0FBS29JLFFBQVEsSUFBSW5LLGFBQWEsQ0FBQzhCLElBQUksQ0FBQyxDQUFDO01BQ3pMLElBQUksQ0FBQ3dJLE1BQU0sRUFBRSxPQUFPckosT0FBTyxDQUFDLEdBQUdvSCxVQUFVLENBQUN0RyxFQUFFLG1CQUFtQixFQUFFLDRCQUE0QixDQUFDO01BQzlGa0ksT0FBTyxDQUFDckUsSUFBSSxDQUFDMEUsTUFBTSxDQUFDO01BQUVKLG1CQUFtQixDQUFDdEUsSUFBSSxDQUFDO1FBQUVoRixPQUFPO1FBQUVZLE1BQU0sRUFBRTRGLFFBQVE7UUFBRXRELE1BQU0sRUFBRXJELG9CQUFvQixDQUFDRyxPQUFPLEVBQUV5SCxVQUFVLENBQUNqRyxJQUFJLENBQUMwQixNQUFNLEVBQUV1RSxVQUFVLENBQUN0RyxFQUFFO01BQUUsQ0FBQyxDQUFDO0lBQzdKO0lBQ0EsTUFBTXdJLE9BQU8sR0FBR25MLGtCQUFrQixDQUFDaUksSUFBSSxFQUFFNEMsT0FBTyxFQUFFO01BQUUsR0FBRy9CLE9BQU87TUFBRWdDO0lBQW9CLENBQUMsQ0FBQztJQUFFLElBQUksQ0FBQ0ssT0FBTyxDQUFDbEosRUFBRSxFQUFFLE9BQU9rSixPQUFPO0lBQ3ZIQSxPQUFPLENBQUMxRyxLQUFLLENBQUNjLE9BQU8sR0FBRyxDQUFDLEdBQUcsSUFBSXJCLEdBQUcsQ0FBQyxDQUFDLEdBQUdpSCxPQUFPLENBQUMxRyxLQUFLLENBQUNjLE9BQU8sRUFBRSxHQUFHeUQsV0FBVyxDQUFDNUMsR0FBRyxDQUFDNkMsVUFBVSxJQUFJQSxVQUFVLENBQUN0RyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDakgsT0FBTztNQUFFVixFQUFFLEVBQUUsSUFBSTtNQUFFd0MsS0FBSyxFQUFFMEcsT0FBTyxDQUFDMUcsS0FBSztNQUFFMkcsZ0JBQWdCLEVBQUVsRCxlQUFlLENBQUNELElBQUksQ0FBQztNQUFFYztJQUFXLENBQUM7RUFDaEcsQ0FBQyxDQUFDLE9BQU9zQyxLQUFLLEVBQUU7SUFBRSxPQUFPO01BQUVwSixFQUFFLEVBQUUsS0FBSztNQUFFQyxNQUFNLEVBQUVtSixLQUFLLFlBQVlwTCxxQkFBcUIsR0FBR29MLEtBQUssQ0FBQ25KLE1BQU0sR0FBRyxDQUFDO1FBQUVGLElBQUksRUFBRSxtQkFBbUI7UUFBRUYsSUFBSSxFQUFFLGNBQWM7UUFBRUMsT0FBTyxFQUFFc0osS0FBSyxZQUFZQyxLQUFLLEdBQUdELEtBQUssQ0FBQ3RKLE9BQU8sR0FBRztNQUFjLENBQUM7SUFBRSxDQUFDO0VBQUU7QUFDbE87QUFXQSxPQUFPLFNBQVN3SiwyQkFBMkJBLENBQUNDLE9BQThCLEVBQXlCO0VBQ2pHLE9BQU9BLE9BQU8sQ0FBQ0MsV0FBVyxDQUFDckYsR0FBRyxDQUFDc0YsVUFBVTtJQUFBLElBQUFDLHFCQUFBLEVBQUFDLHFCQUFBO0lBQUEsT0FBSztNQUFFbkgsS0FBSyxFQUFFaUgsVUFBVSxDQUFDRyxLQUFLO01BQUVULGdCQUFnQixHQUFBTyxxQkFBQSxHQUFFRCxVQUFVLENBQUNJLGlCQUFpQixjQUFBSCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJcEksU0FBUztNQUFFd0YsVUFBVSxFQUFFMkMsVUFBVSxDQUFDSyxnQkFBZ0I7TUFBRTNKLE1BQU0sRUFBRTtRQUFFVyxPQUFPLEVBQUUySSxVQUFVLENBQUN4RztNQUFTLENBQUM7TUFBRWhDLFNBQVMsRUFBRXNJLE9BQU8sQ0FBQ3RJLFNBQVM7TUFBRW9FLGNBQWMsR0FBQXNFLHFCQUFBLEdBQUVGLFVBQVUsQ0FBQ3BFLGNBQWMsY0FBQXNFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUlKLE9BQU8sQ0FBQ2xFO0lBQWUsQ0FBQztFQUFBLENBQUMsQ0FBQztBQUNoVTtBQUNBLE9BQU8sU0FBUzBFLHVCQUF1QkEsQ0FBQ1IsT0FBOEIsRUFBRTtFQUN0RSxPQUFPbEssNEJBQTRCLENBQUNrSyxPQUFPLENBQUNTLE9BQU8sRUFBRVYsMkJBQTJCLENBQUNDLE9BQU8sQ0FBQyxFQUFFQSxPQUFPLENBQUNVLFVBQVUsRUFBRVYsT0FBTyxDQUFDVyxNQUFNLEtBQUssVUFBVSxFQUFFWCxPQUFPLENBQUNqRSxpQkFBaUIsRUFBRWlFLE9BQU8sQ0FBQ3RKLE1BQU0sQ0FBQztBQUMxTDtBQUNBLE9BQU8sZUFBZWtLLG1CQUFtQkEsQ0FBQzVLLE9BQW9CLEVBQUU2SyxPQUE4QixHQUFHLENBQUMsQ0FBQyxFQUFrQztFQUFBLElBQUFDLHFCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLFVBQUEsRUFBQUMscUJBQUE7RUFDbkksTUFBTUMsa0JBQWtCLEdBQUd4RSxlQUFlLENBQUM7SUFBRSxHQUFHMUcsT0FBTztJQUFFbUwsT0FBTyxFQUFFLEVBQUU7SUFBRUMsU0FBUyxFQUFFLEVBQUU7SUFBRUMsa0JBQWtCLEVBQUV0SixTQUFTO0lBQUU3QixRQUFRLEVBQUVGLE9BQU8sQ0FBQ0UsUUFBUSxDQUFDQyxNQUFNLENBQUNDLE1BQU0sSUFBSSxDQUFDLFlBQVksRUFBRSxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUMwQixRQUFRLENBQUMxQixNQUFNLENBQUNILElBQUksQ0FBQztFQUFFLENBQUMsQ0FBQztFQUMvTixNQUFNeUIsU0FBUyxHQUFHbUosT0FBTyxDQUFDbkosU0FBUztJQUFFNEosa0JBQWtCLEdBQUdULE9BQU8sQ0FBQ1UsU0FBUztFQUMzRSxJQUFJN0osU0FBUyxLQUFLSyxTQUFTLElBQUksQ0FBQ3ZDLE1BQU0sQ0FBQ2tDLFNBQVMsQ0FBQyxFQUFFLE1BQU0sSUFBSWpELHFCQUFxQixDQUFDLENBQUM7SUFBRStCLElBQUksRUFBRSxtQkFBbUI7SUFBRUYsSUFBSSxFQUFFLFdBQVc7SUFBRUMsT0FBTyxFQUFFO0VBQTZCLENBQUMsQ0FBQyxDQUFDO0VBQzdLLE1BQU1pTCxjQUFjLEdBQUdYLE9BQU8sQ0FBQ1csY0FBYyxHQUFHOUUsZUFBZSxDQUFDbUUsT0FBTyxDQUFDVyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDNUYsTUFBTUMsZ0JBQWdCLEdBQUdaLE9BQU8sQ0FBQ2EsVUFBVSxHQUFHLENBQUMsR0FBR2IsT0FBTyxDQUFDYSxVQUFVLENBQUMsR0FBRzNKLFNBQVM7SUFBRTRKLGNBQWMsR0FBR2QsT0FBTyxDQUFDM0ksUUFBUSxHQUFHLENBQUMsR0FBRzJJLE9BQU8sQ0FBQzNJLFFBQVEsQ0FBQyxHQUFHSCxTQUFTO0VBQ3hKLE1BQU0rRCxjQUFjLEdBQUdZLGVBQWUsRUFBQW9FLHFCQUFBLEdBQUNELE9BQU8sQ0FBQy9FLGNBQWMsY0FBQWdGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxDQUFDLENBQUM7SUFBRWMsY0FBYyxHQUFHZixPQUFPLENBQUM1SCxLQUFLLEdBQUd5RCxlQUFlLENBQUNtRSxPQUFPLENBQUM1SCxLQUFLLENBQUMsR0FBR2xCLFNBQVM7RUFDakosTUFBTThKLE9BQU8sSUFBQWQscUJBQUEsR0FBR0YsT0FBTyxDQUFDcEgsZ0JBQWdCLGNBQUFzSCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJL0ssT0FBTyxDQUFDeUIsU0FBUztJQUFFcUssUUFBUSxHQUFHLE1BQU0vTSxxQkFBcUIsQ0FBQ2lCLE9BQU8sRUFBRTZMLE9BQU8sRUFBRTtNQUFFTDtJQUFlLENBQUMsQ0FBQztJQUFFZixPQUFPLEdBQUdoTCxtQkFBbUIsQ0FBQ3FNLFFBQVEsRUFBRUEsUUFBUSxDQUFDVixTQUFTLENBQUM7RUFDeE0sTUFBTVcsT0FBTyxHQUFHNU0sbUJBQW1CLENBQUNzTCxPQUFPLEVBQUVlLGNBQWMsQ0FBQztFQUM1RCxJQUFJTyxPQUFPLENBQUNDLE1BQU0sQ0FBQ2hHLE1BQU0sRUFBRSxNQUFNLElBQUl2SCxxQkFBcUIsQ0FBQyxDQUFDO0lBQUUrQixJQUFJLEVBQUUsbUJBQW1CO0lBQUVGLElBQUksRUFBRSxpQkFBaUI7SUFBRUMsT0FBTyxFQUFFd0wsT0FBTyxDQUFDQyxNQUFNLENBQUMsQ0FBQztFQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ2pKLE1BQU1uRyxjQUFjLEdBQUczRyxxQkFBcUIsQ0FBQ3VMLE9BQU8sRUFBRTNFLGNBQWMsRUFBRS9ELFNBQVMsRUFBRWdLLE9BQU8sQ0FBQ0UsTUFBTSxDQUFDbkosT0FBTyxDQUFDb0osS0FBSyxJQUFJQSxLQUFLLENBQUNoTSxRQUFRLENBQUMsQ0FBQztFQUFFLElBQUkyRixjQUFjLENBQUNHLE1BQU0sRUFBRSxNQUFNLElBQUl2SCxxQkFBcUIsQ0FBQ29ILGNBQWMsQ0FBQztFQUM3TSxJQUFJOEYsY0FBYyxhQUFkQSxjQUFjLGVBQWRBLGNBQWMsQ0FBRVEsSUFBSSxDQUFDaEwsRUFBRSxJQUFJLENBQUNwQixNQUFNLENBQUMwSyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMwQixJQUFJLENBQUM5SyxLQUFLLElBQUlBLEtBQUssQ0FBQ0YsRUFBRSxLQUFLQSxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sSUFBSTFDLHFCQUFxQixDQUFDLENBQUM7SUFBRStCLElBQUksRUFBRSxtQkFBbUI7SUFBRUYsSUFBSSxFQUFFLFVBQVU7SUFBRUMsT0FBTyxFQUFFO0VBQTJCLENBQUMsQ0FBQyxDQUFDO0VBQ2pOLElBQUlrTCxnQkFBZ0IsYUFBaEJBLGdCQUFnQixlQUFoQkEsZ0JBQWdCLENBQUVVLElBQUksQ0FBQ2hMLEVBQUUsSUFBSSxDQUFDcEIsTUFBTSxDQUFDMEssT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDMEIsSUFBSSxDQUFDbEssT0FBTyxJQUFJQSxPQUFPLENBQUNkLEVBQUUsS0FBS0EsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLElBQUkxQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQUUrQixJQUFJLEVBQUUsbUJBQW1CO0lBQUVGLElBQUksRUFBRSxZQUFZO0lBQUVDLE9BQU8sRUFBRTtFQUFnQixDQUFDLENBQUMsQ0FBQztFQUNoTixNQUFNNkwsUUFBUSxHQUFHdE4sMkJBQTJCLENBQUMyTCxPQUFPLEVBQUVnQixnQkFBZ0IsRUFBRUUsY0FBYyxDQUFDO0VBQ3ZGLElBQUlDLGNBQWMsSUFBSUEsY0FBYyxDQUFDbkksZ0JBQWdCLEtBQUtvSSxPQUFPLEVBQUUsTUFBTSxJQUFJcE4scUJBQXFCLENBQUMsQ0FBQztJQUFFK0IsSUFBSSxFQUFFLG1CQUFtQjtJQUFFRixJQUFJLEVBQUUsd0JBQXdCO0lBQUVDLE9BQU8sRUFBRTtFQUFtQyxDQUFDLENBQUMsQ0FBQztFQUNoTixNQUFNMEMsS0FBSyxHQUFHeUQsZUFBZSxDQUFDa0YsY0FBYyxhQUFkQSxjQUFjLGNBQWRBLGNBQWMsR0FBSWpOLHNCQUFzQixDQUFDOEwsT0FBTyxFQUFFb0IsT0FBTyxFQUFFRSxPQUFPLENBQUNFLE1BQU0sQ0FBQ25KLE9BQU8sQ0FBQ29KLEtBQUssSUFBSUEsS0FBSyxDQUFDaE0sUUFBUSxDQUFDLENBQUMsQ0FBQztFQUMxSStDLEtBQUssQ0FBQ1EsZ0JBQWdCLEdBQUdvSSxPQUFPO0VBQUU1SSxLQUFLLENBQUM0RCxvQkFBb0IsR0FBRyxJQUFJO0VBQUU1RCxLQUFLLENBQUNvSixVQUFVLEdBQUcsU0FBUztFQUNqRyxNQUFNQyxTQUFTLEdBQUdoTyxvQkFBb0IsQ0FBQzJFLEtBQUssQ0FBQztFQUFFLElBQUksQ0FBQ3FKLFNBQVMsQ0FBQzdMLEVBQUUsRUFBRSxNQUFNLElBQUloQyxxQkFBcUIsQ0FBQzZOLFNBQVMsQ0FBQzVMLE1BQU0sQ0FBQztFQUNuSCxNQUFNNkwsWUFBWSxHQUFHLENBQUMsR0FBRzlCLE9BQU8sQ0FBQ3ZLLFFBQVEsRUFBRSxHQUFHNkwsT0FBTyxDQUFDRSxNQUFNLENBQUNuSixPQUFPLENBQUNvSixLQUFLLElBQUlBLEtBQUssQ0FBQ2hNLFFBQVEsQ0FBQyxDQUFDLENBQUNDLE1BQU0sQ0FBQ2YsYUFBYSxDQUFDO0VBQ3BILEtBQUssTUFBTSxDQUFDK0IsRUFBRSxFQUFFZ0gsS0FBSyxDQUFDLElBQUlxRSxNQUFNLENBQUNDLE9BQU8sQ0FBQ3hKLEtBQUssQ0FBQ3lKLGNBQWMsQ0FBQyxFQUFFO0lBQzlELE1BQU1DLFFBQVEsR0FBR0osWUFBWSxDQUFDdEwsSUFBSSxDQUFDYixNQUFNLElBQUlBLE1BQU0sQ0FBQ2UsRUFBRSxLQUFLQSxFQUFFLElBQUlmLE1BQU0sQ0FBQ0gsSUFBSSxLQUFLLFVBQVUsQ0FBQztJQUM1RixJQUFJLENBQUMwTSxRQUFRLElBQUlBLFFBQVEsQ0FBQzFNLElBQUksS0FBSyxVQUFVLEVBQUUsTUFBTSxJQUFJeEIscUJBQXFCLENBQUMsQ0FBQztNQUFFK0IsSUFBSSxFQUFFLG1CQUFtQjtNQUFFRixJQUFJLEVBQUUsd0JBQXdCYSxFQUFFLEVBQUU7TUFBRVosT0FBTyxFQUFFO0lBQTBCLENBQUMsQ0FBQyxDQUFDO0lBQ3ZMLE1BQU1HLE1BQU0sR0FBR25DLHFCQUFxQixDQUFDb08sUUFBUSxFQUFFeEUsS0FBSyxFQUFFLHdCQUF3QmhILEVBQUUsRUFBRSxDQUFDO0lBQUUsSUFBSVQsTUFBTSxDQUFDc0YsTUFBTSxFQUFFLE1BQU0sSUFBSXZILHFCQUFxQixDQUFDaUMsTUFBTSxDQUFDO0VBQ2pKO0VBQ0EsTUFBTTRGLFdBQVcsR0FBRzNGLHVCQUF1QixDQUFDOEosT0FBTyxFQUFFO0lBQUVsSixPQUFPLEdBQUF5SixVQUFBLEdBQUVvQixRQUFRLENBQUMsQ0FBQyxDQUFDLGNBQUFwQixVQUFBLHVCQUFYQSxVQUFBLENBQWEzSixLQUFLLENBQUNGLEVBQUU7SUFBRU87RUFBVSxDQUFDLENBQUM7RUFDbkcsTUFBTWtMLFVBQVUsR0FBRy9OLHNCQUFzQixDQUFDO0lBQUVvRSxLQUFLO0lBQUUvQyxRQUFRLEVBQUV1SyxPQUFPLENBQUN2SyxRQUFRO0lBQUU2RixpQkFBaUIsRUFBRWdHLE9BQU8sQ0FBQ0UsTUFBTSxDQUFDbkosT0FBTyxDQUFDb0osS0FBSyxJQUFJQSxLQUFLLENBQUNoTSxRQUFRLENBQUM7SUFBRTRGLGNBQWM7SUFBRVEsV0FBVztJQUFFQyxZQUFZLEVBQUUzRyxpQkFBaUIsQ0FBQzZLLE9BQU8sRUFBRW5FLFdBQVc7RUFBRSxDQUFDLENBQUM7RUFDeE8sSUFBSXNHLFVBQVUsQ0FBQ1QsSUFBSSxDQUFDVSxLQUFLLElBQUlBLEtBQUssQ0FBQ3JNLElBQUksS0FBSyxtQkFBbUIsQ0FBQyxFQUFFLE1BQU0sSUFBSS9CLHFCQUFxQixDQUFDbU8sVUFBVSxDQUFDO0VBQzdHLE1BQU1sQixVQUFVLEdBQUdELGdCQUFnQixHQUFHLENBQUMsR0FBR0EsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSS9JLEdBQUcsQ0FBQzBKLFFBQVEsQ0FBQ3RKLE9BQU8sQ0FBQ2dLLEtBQUssSUFBSUEsS0FBSyxDQUFDOUssU0FBUyxHQUFHLENBQUM4SyxLQUFLLENBQUM5SyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQy9JLE9BQU87SUFBRXlJLE9BQU87SUFBRVMsa0JBQWtCO0lBQUV6SCxnQkFBZ0IsRUFBRW9JLE9BQU87SUFBRWtCLGVBQWUsRUFBRXRDLE9BQU8sQ0FBQ3VDLFFBQVE7SUFBRUMsV0FBVyxHQUFBaEMscUJBQUEsR0FBRWpMLE9BQU8sQ0FBQ29MLFNBQVMsQ0FBQ25LLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNDLEVBQUUsS0FBSzBLLE9BQU8sQ0FBQyxjQUFBWixxQkFBQSx1QkFBbkRBLHFCQUFBLENBQXFEZ0MsV0FBVztJQUFFdkMsVUFBVSxFQUFFaEUsZUFBZSxDQUFDekQsS0FBSyxDQUFDO0lBQUVBLEtBQUs7SUFBRXZCLFNBQVM7SUFBRWdLLFVBQVU7SUFBRXhKLFFBQVEsRUFBRWtLLFFBQVEsQ0FBQ3hILEdBQUcsQ0FBQ2tJLEtBQUssSUFBSUEsS0FBSyxDQUFDekwsS0FBSyxDQUFDRixFQUFFLENBQUM7SUFBRW9LLFNBQVMsRUFBRUQsa0JBQWtCLGFBQWxCQSxrQkFBa0IsY0FBbEJBLGtCQUFrQixHQUFLSyxjQUFjLEdBQUcsUUFBUSxHQUFHLFVBQVc7SUFBRTFCLFdBQVcsRUFBRSxFQUFFO0lBQUVuRSxjQUFjO0lBQUVDLGlCQUFpQixFQUFFVyxlQUFlLENBQUNxRixPQUFPLENBQUNFLE1BQU0sQ0FBQ25KLE9BQU8sQ0FBQ29KLEtBQUssSUFBSUEsS0FBSyxDQUFDaE0sUUFBUSxDQUFDLENBQUM7SUFBRXlLLE1BQU0sRUFBRWlDLFVBQVUsQ0FBQzVHLE1BQU0sR0FBRyxTQUFTLEdBQUdvRyxRQUFRLENBQUNwRyxNQUFNLEdBQUcsT0FBTyxHQUFHLFVBQVU7SUFBRXRGLE1BQU0sRUFBRWtNO0VBQVcsQ0FBQztBQUM3a0I7QUFDQSxPQUFPLFNBQVNNLHdCQUF3QkEsQ0FBQ3pDLE9BQW9CLEVBQUV4SCxLQUFtQixFQUFFckMsTUFBcUUsRUFBdUI7RUFDOUssTUFBTTtJQUFFVyxPQUFPO0lBQUU0TDtFQUFnQixDQUFDLEdBQUd2TSxNQUFNO0VBQzNDLE1BQU13TSxJQUFJLEdBQUd6TSx1QkFBdUIsQ0FBQzhKLE9BQU8sRUFBRTtNQUFFbEosT0FBTyxFQUFFNEw7SUFBZ0IsQ0FBQyxDQUFDO0lBQUVFLEVBQUUsR0FBRzFNLHVCQUF1QixDQUFDOEosT0FBTyxFQUFFO01BQUVsSjtJQUFRLENBQUMsQ0FBQztFQUMvSCxNQUFNK0wsTUFBdUMsR0FBR0gsZUFBZSxJQUFJQSxlQUFlLEtBQUs1TCxPQUFPLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFO0VBQ25ILElBQUk2TCxJQUFJLENBQUNwTCxTQUFTLElBQUlvTCxJQUFJLENBQUNwTCxTQUFTLEtBQUtxTCxFQUFFLENBQUNyTCxTQUFTLEVBQUVzTCxNQUFNLENBQUN0SSxJQUFJLENBQUMsYUFBYSxDQUFDO0VBQ2pGLE1BQU11SSxLQUFLLEdBQUczTyxxQkFBcUIsQ0FBQztJQUFFLEdBQUdxRSxLQUFLO0lBQUUsSUFBSUEsS0FBSyxDQUFDdUssV0FBVyxHQUFHO01BQUVBLFdBQVcsRUFBRTtJQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7RUFBRSxDQUFDLEVBQUVGLE1BQU0sRUFBRTtJQUFFckssS0FBSztJQUFFL0MsUUFBUSxFQUFFdUssT0FBTyxDQUFDdkssUUFBUTtJQUFFNkYsaUJBQWlCLEVBQUVuRixNQUFNLENBQUNtRixpQkFBaUI7SUFBRUQsY0FBYyxFQUFFbEYsTUFBTSxDQUFDa0YsY0FBYztJQUFFUSxXQUFXLEVBQUUzRix1QkFBdUIsQ0FBQzhKLE9BQU8sRUFBRTtNQUFFbEosT0FBTyxFQUFFWCxNQUFNLENBQUN1TSxlQUFlO01BQUV6TCxTQUFTLEVBQUVkLE1BQU0sQ0FBQ2M7SUFBVSxDQUFDLENBQUM7SUFBRTZFLFlBQVksRUFBRTNHLGlCQUFpQixDQUFDNkssT0FBTyxFQUFFOUosdUJBQXVCLENBQUM4SixPQUFPLEVBQUU7TUFBRWxKLE9BQU8sRUFBRVgsTUFBTSxDQUFDdU0sZUFBZTtNQUFFekwsU0FBUyxFQUFFZCxNQUFNLENBQUNjO0lBQVUsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3RlLElBQUksQ0FBQzZMLEtBQUssQ0FBQzlNLEVBQUUsRUFBRSxPQUFPOE0sS0FBSztFQUMzQixNQUFNbEYsTUFBTSxHQUFHM0MsY0FBYyxDQUFDK0UsT0FBTyxFQUFFOEMsS0FBSyxDQUFDdEssS0FBSyxFQUFFckMsTUFBTSxDQUFDO0VBQzNELElBQUksQ0FBQ3lILE1BQU0sQ0FBQzVILEVBQUUsRUFBRSxPQUFPNEgsTUFBTTtFQUM3QixJQUFJekgsTUFBTSxDQUFDNk0sSUFBSSxFQUFFO0lBQUEsSUFBQUMscUJBQUEsRUFBQUMscUJBQUE7SUFDZixNQUFNQyxLQUFLLEdBQUdoUCxxQkFBcUIsQ0FBQ3lKLE1BQU0sQ0FBQ3BGLEtBQUssRUFBRSxDQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUUsU0FBUyxDQUFDLEVBQUU7TUFBRUEsS0FBSyxFQUFFb0YsTUFBTSxDQUFDcEYsS0FBSztNQUFFL0MsUUFBUSxFQUFFdUssT0FBTyxDQUFDdkssUUFBUTtNQUFFNkYsaUJBQWlCLEVBQUVuRixNQUFNLENBQUNtRixpQkFBaUI7TUFBRUQsY0FBYyxFQUFFbEYsTUFBTSxDQUFDa0YsY0FBYztNQUFFUSxXQUFXLEVBQUUzRix1QkFBdUIsQ0FBQzhKLE9BQU8sRUFBRTdKLE1BQU0sQ0FBQztNQUFFMkYsWUFBWSxFQUFFM0csaUJBQWlCLENBQUM2SyxPQUFPLEVBQUU5Six1QkFBdUIsQ0FBQzhKLE9BQU8sRUFBRTdKLE1BQU0sQ0FBQztJQUFFLENBQUMsQ0FBQztJQUM5VyxJQUFJLENBQUNnTixLQUFLLENBQUNuTixFQUFFLEVBQUUsT0FBT21OLEtBQUs7SUFDM0J2RixNQUFNLENBQUNwRixLQUFLLEdBQUcySyxLQUFLLENBQUMzSyxLQUFLO0lBQzFCLElBQUlzSyxLQUFLLENBQUN0SyxLQUFLLENBQUN1SyxXQUFXLElBQUlJLEtBQUssQ0FBQzNLLEtBQUssQ0FBQ3VLLFdBQVcsRUFBRW5GLE1BQU0sQ0FBQ3BGLEtBQUssQ0FBQ3VLLFdBQVcsR0FBRyxDQUFDLEtBQUFFLHFCQUFBLEdBQUlILEtBQUssQ0FBQ3RLLEtBQUssQ0FBQ3VLLFdBQVcsY0FBQUUscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLENBQUMsRUFBRSxLQUFBQyxxQkFBQSxHQUFJQyxLQUFLLENBQUMzSyxLQUFLLENBQUN1SyxXQUFXLGNBQUFHLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxDQUFDLENBQUM7RUFDN0o7RUFDQSxPQUFPdEYsTUFBTTtBQUNmO0FBQ0EsT0FBTyxTQUFTd0YsdUJBQXVCQSxDQUFDN04sT0FBb0IsRUFBRWdLLE9BQThCLEVBQXlCO0VBQUEsSUFBQThELHFCQUFBO0VBQ25ILE1BQU1DLFlBQVksR0FBRy9PLG9CQUFvQixDQUFDZ0IsT0FBTyxFQUFFZ0ssT0FBTyxDQUFDdkcsZ0JBQWdCLEVBQUV1RyxPQUFPLENBQUMrQyxlQUFlLEVBQUUvQyxPQUFPLENBQUNpRCxXQUFXLENBQUM7RUFDMUgsSUFBSWMsWUFBWSxFQUFFLE9BQU87SUFBRSxHQUFHL0QsT0FBTztJQUFFVyxNQUFNLEVBQUUsT0FBTztJQUFFakssTUFBTSxFQUFFLENBQUM7TUFBRUYsSUFBSSxFQUFFLG1CQUFtQjtNQUFFRixJQUFJLEVBQUUsa0JBQWtCO01BQUVDLE9BQU8sRUFBRXdOO0lBQWEsQ0FBQztFQUFFLENBQUM7RUFDbEosTUFBTXhNLE9BQU8sR0FBR3lJLE9BQU8sQ0FBQzlILFFBQVEsQ0FBQzhILE9BQU8sQ0FBQ0MsV0FBVyxDQUFDakUsTUFBTSxDQUFDO0VBQUUsSUFBSSxDQUFDekUsT0FBTyxFQUFFLE9BQU95SSxPQUFPO0VBQzFGLE1BQU0zQixNQUFNLEdBQUc2RSx3QkFBd0IsQ0FBQ2xELE9BQU8sQ0FBQ1MsT0FBTyxFQUFFVCxPQUFPLENBQUMvRyxLQUFLLEVBQUU7SUFBRTFCLE9BQU87SUFBRUcsU0FBUyxFQUFFc0ksT0FBTyxDQUFDdEksU0FBUztJQUFFeUwsZUFBZSxHQUFBVyxxQkFBQSxHQUFFOUQsT0FBTyxDQUFDQyxXQUFXLENBQUMrRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBQUYscUJBQUEsdUJBQTFCQSxxQkFBQSxDQUE0QnBLLFFBQVE7SUFBRStKLElBQUksRUFBRXpELE9BQU8sQ0FBQ0MsV0FBVyxDQUFDakUsTUFBTSxHQUFHLENBQUMsS0FBS2dFLE9BQU8sQ0FBQzlILFFBQVEsQ0FBQzhELE1BQU07SUFBRUYsY0FBYyxFQUFFa0UsT0FBTyxDQUFDbEUsY0FBYztJQUFFQyxpQkFBaUIsRUFBRWlFLE9BQU8sQ0FBQ2pFO0VBQWtCLENBQUMsQ0FBQztFQUNqVSxJQUFJLENBQUNzQyxNQUFNLENBQUM1SCxFQUFFLEVBQUUsT0FBTztJQUFFLEdBQUd1SixPQUFPO0lBQUVXLE1BQU0sRUFBRXRDLE1BQU0sQ0FBQzNILE1BQU0sQ0FBQ3lMLElBQUksQ0FBQ1UsS0FBSyxJQUFJQSxLQUFLLENBQUNyTSxJQUFJLEtBQUssbUJBQW1CLENBQUMsR0FBRyxTQUFTLEdBQUcsT0FBTztJQUFFRSxNQUFNLEVBQUUySCxNQUFNLENBQUMzSDtFQUFPLENBQUM7RUFDM0osTUFBTXdKLFVBQWtDLEdBQUc7SUFBRXhHLFFBQVEsRUFBRW5DLE9BQU87SUFBRTBNLFlBQVksRUFBRSxHQUFHMU0sT0FBTyxJQUFJeUksT0FBTyxDQUFDQyxXQUFXLENBQUNqRSxNQUFNLEdBQUcsQ0FBQyxFQUFFO0lBQUVrSSxNQUFNLEVBQUV4SCxlQUFlLENBQUNzRCxPQUFPLENBQUMvRyxLQUFLLENBQUM7SUFBRW9ILEtBQUssRUFBRWhDLE1BQU0sQ0FBQ3BGLEtBQUs7SUFBRXFILGlCQUFpQixFQUFFakMsTUFBTSxDQUFDdUIsZ0JBQWdCO0lBQUVXLGdCQUFnQixFQUFFbEMsTUFBTSxDQUFDZCxVQUFVO0lBQUV6QixjQUFjLEVBQUVZLGVBQWUsQ0FBQ3NELE9BQU8sQ0FBQ2xFLGNBQWM7RUFBRSxDQUFDO0VBQ3JVLE1BQU1tRSxXQUFXLEdBQUcsQ0FBQyxHQUFHRCxPQUFPLENBQUNDLFdBQVcsRUFBRUMsVUFBVSxDQUFDO0VBQ3hELE9BQU87SUFBRSxHQUFHRixPQUFPO0lBQUUvRyxLQUFLLEVBQUVvRixNQUFNLENBQUNwRixLQUFLO0lBQUVnSCxXQUFXO0lBQUVVLE1BQU0sRUFBRVYsV0FBVyxDQUFDakUsTUFBTSxLQUFLZ0UsT0FBTyxDQUFDOUgsUUFBUSxDQUFDOEQsTUFBTSxHQUFHLFVBQVUsR0FBRyxPQUFPO0lBQUV0RixNQUFNLEVBQUU7RUFBRyxDQUFDO0FBQ3BKO0FBQ0EsT0FBTyxTQUFTeU4sa0JBQWtCQSxDQUFDbkUsT0FBOEIsRUFBeUI7RUFDeEYsTUFBTW9FLFFBQVEsR0FBR3BFLE9BQU8sQ0FBQ0MsV0FBVyxDQUFDK0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUUsSUFBSSxDQUFDSSxRQUFRLEVBQUUsT0FBTztJQUFFLEdBQUdwRSxPQUFPO0lBQUVXLE1BQU0sRUFBRVgsT0FBTyxDQUFDOUgsUUFBUSxDQUFDOEQsTUFBTSxHQUFHLE9BQU8sR0FBRyxVQUFVO0lBQUV0RixNQUFNLEVBQUU7RUFBRyxDQUFDO0VBQ3JKLE9BQU87SUFBRSxHQUFHc0osT0FBTztJQUFFL0csS0FBSyxFQUFFeUQsZUFBZSxDQUFDMEgsUUFBUSxDQUFDRixNQUFNLENBQUM7SUFBRWpFLFdBQVcsRUFBRUQsT0FBTyxDQUFDQyxXQUFXLENBQUNvRSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQUUxRCxNQUFNLEVBQUUsT0FBTztJQUFFakssTUFBTSxFQUFFO0VBQUcsQ0FBQztBQUM1STtBQUVBLE9BQU8sU0FBUzROLHVCQUF1QkEsQ0FBQ3RFLE9BQThCLEVBQUV1RSxHQUF5QyxFQUFFckQsa0JBQStCLElBQUFzRCxxQkFBQSxLQUFBQSxxQkFBQSxHQUFHeEUsT0FBTyxDQUFDa0Isa0JBQWtCLGNBQUFzRCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJeEUsT0FBTyxDQUFDUyxPQUFPLEtBQXdCO0VBQ3hOLE1BQU1nRSxjQUFjLEdBQUl4TCxLQUFtQixLQUFNO0lBQUUsR0FBR3lELGVBQWUsQ0FBQ3pELEtBQUssQ0FBQztJQUFFUSxnQkFBZ0IsRUFBRThLLEdBQUcsQ0FBQ0c7RUFBVyxDQUFDLENBQUM7RUFDakgsTUFBTUMsV0FBd0IsR0FBRztJQUFFakQsVUFBVSxFQUFFLENBQUMsR0FBRzFCLE9BQU8sQ0FBQzBCLFVBQVUsQ0FBQztJQUFFeEosUUFBUSxFQUFFLENBQUMsR0FBRzhILE9BQU8sQ0FBQzlILFFBQVEsQ0FBQztJQUFFLElBQUk4SCxPQUFPLENBQUN1QixTQUFTLEdBQUc7TUFBRUEsU0FBUyxFQUFFdkIsT0FBTyxDQUFDdUI7SUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRXRCLFdBQVcsRUFBRUQsT0FBTyxDQUFDQyxXQUFXLENBQUNyRixHQUFHLENBQUNzRixVQUFVLEtBQUs7TUFBRSxHQUFHeEQsZUFBZSxDQUFDd0QsVUFBVSxDQUFDO01BQUVnRSxNQUFNLEVBQUVPLGNBQWMsQ0FBQ3ZFLFVBQVUsQ0FBQ2dFLE1BQU0sQ0FBQztNQUFFN0QsS0FBSyxFQUFFb0UsY0FBYyxDQUFDdkUsVUFBVSxDQUFDRyxLQUFLLENBQUM7TUFBRSxJQUFJSCxVQUFVLENBQUNJLGlCQUFpQixHQUFHO1FBQUVBLGlCQUFpQixFQUFFbUUsY0FBYyxDQUFDdkUsVUFBVSxDQUFDSSxpQkFBaUI7TUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0VBQUUsQ0FBQztFQUNyYyxNQUFNO0lBQUVjLFNBQVMsRUFBRXdELFVBQVU7SUFBRXpELE9BQU8sRUFBRTBELFFBQVE7SUFBRXhELGtCQUFrQixFQUFFeUQsbUJBQW1CO0lBQUUsR0FBR3JFO0VBQVEsQ0FBQyxHQUFHL0ssa0JBQWtCLENBQUNzSyxPQUFPLENBQUNTLE9BQU8sQ0FBQztFQUM3SSxNQUFNc0UsUUFBUSxHQUFHaFAsTUFBTSxDQUFDaUssT0FBTyxDQUFDUyxPQUFPLEVBQUUsZUFBZSxDQUFDO0lBQUV1RSxNQUFNLEdBQUdqUCxNQUFNLENBQUNpSyxPQUFPLENBQUNTLE9BQU8sRUFBRSxPQUFPLENBQUM7RUFDcEcsTUFBTXdFLFdBQVcsR0FBRyxJQUFJdk0sR0FBRyxDQUFDLENBQUMsR0FBR3NILE9BQU8sQ0FBQzlILFFBQVEsRUFBRSxHQUFHOE0sTUFBTSxDQUFDN08sTUFBTSxDQUFDa0IsS0FBSyxJQUFJMkksT0FBTyxDQUFDOUgsUUFBUSxDQUFDSixRQUFRLENBQUNULEtBQUssQ0FBQ0YsRUFBRSxDQUFDLENBQUMsQ0FBQzJCLE9BQU8sQ0FBQ3pCLEtBQUs7SUFBQSxJQUFBNk4sZ0JBQUE7SUFBQSxRQUFBQSxnQkFBQSxHQUFLN04sS0FBSyxDQUFDRyxJQUFJLENBQWlFbUIsZUFBZSxjQUFBdU0sZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxFQUFFO0VBQUEsRUFBQyxDQUFDLENBQUM7RUFDdE8sTUFBTUMsU0FBUyxHQUFHcFAsTUFBTSxDQUFDaUssT0FBTyxDQUFDUyxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUN0SyxNQUFNLENBQUNzSCxVQUFVLElBQUl3SCxXQUFXLENBQUNHLEdBQUcsQ0FBQzNILFVBQVUsQ0FBQ2pHLElBQUksQ0FBQzBCLE1BQU0sQ0FBQ1EsUUFBUSxDQUFDLENBQUM7RUFDOUgsTUFBTTJMLFlBQVksR0FBR3JGLE9BQU8sQ0FBQ0MsV0FBVyxDQUFDbkgsT0FBTyxDQUFDb0gsVUFBVSxJQUFJQSxVQUFVLENBQUNLLGdCQUFnQixDQUFDO0VBQzNGLE9BQU87SUFDTEUsT0FBTyxFQUFFL0QsZUFBZSxDQUFDK0QsT0FBTyxDQUFDO0lBQ2pDNkUsVUFBVSxFQUFFO01BQUU3TCxnQkFBZ0IsRUFBRThLLEdBQUcsQ0FBQ0csVUFBVTtNQUFFM0IsZUFBZSxFQUFFL0MsT0FBTyxDQUFDK0MsZUFBZTtNQUFFd0MsWUFBWSxFQUFFZCxjQUFjLENBQUN6RSxPQUFPLENBQUNVLFVBQVUsQ0FBQztNQUFFOEUsTUFBTSxFQUFFLFNBQVM7TUFBRSxJQUFJeEYsT0FBTyxDQUFDdEksU0FBUyxLQUFLSyxTQUFTLEdBQUc7UUFBRUwsU0FBUyxFQUFFc0ksT0FBTyxDQUFDdEk7TUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQUUsQ0FBQztJQUM3TytOLEtBQUssRUFBRTtNQUFFLElBQUluUSx1QkFBdUIsQ0FBQzRMLGtCQUFrQixDQUFDLENBQUNxRCxHQUFHLENBQUN2SSxNQUFNLEdBQUc7UUFBRTBKLHNCQUFzQixFQUFFO1VBQUVDLGVBQWUsRUFBRXpFLGtCQUFrQixDQUFDOEIsUUFBUTtVQUFFNEMsUUFBUSxFQUFFdFEsdUJBQXVCLENBQUM0TCxrQkFBa0IsQ0FBQyxDQUFDcUQ7UUFBSTtNQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUFFOUssZ0JBQWdCLEVBQUU4SyxHQUFHLENBQUNHLFVBQVU7TUFBRTNCLGVBQWUsRUFBRS9DLE9BQU8sQ0FBQytDLGVBQWU7TUFBRThDLGlCQUFpQixFQUFFdEIsR0FBRyxDQUFDdUIsWUFBWTtNQUFFQyxJQUFJLEVBQUUvRixPQUFPLENBQUNVLFVBQVUsQ0FBQ3NGLE9BQU87TUFBRUMsYUFBYSxFQUFFLE9BQU87TUFBRSxJQUFJakcsT0FBTyxDQUFDdEksU0FBUyxLQUFLSyxTQUFTLEdBQUc7UUFBRW1PLGdCQUFnQixFQUFFbEcsT0FBTyxDQUFDdEk7TUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7TUFBRXlPLHFCQUFxQixFQUFFekosZUFBZSxDQUFDc0QsT0FBTyxDQUFDbEUsY0FBYyxDQUFDO01BQUVzSyxZQUFZLEVBQUU1RCxNQUFNLENBQUM2RCxJQUFJLENBQUNyRyxPQUFPLENBQUNsRSxjQUFjLENBQUMsQ0FBQ0UsTUFBTSxHQUFHLE1BQU0sR0FBRyxJQUFJO01BQUVzSyxLQUFLLEVBQUUsRUFBRTtNQUFFQyxJQUFJLEVBQUUsVUFBVTtNQUFFNUIsV0FBVztNQUFFNkIsUUFBUSxFQUFFO1FBQ2pwQnhCLE1BQU0sRUFBRTtVQUFFcEosT0FBTyxFQUFFLElBQUlsRCxHQUFHLENBQUNzSCxPQUFPLENBQUNDLFdBQVcsQ0FBQ3JGLEdBQUcsQ0FBQ3NGLFVBQVUsSUFBSUEsVUFBVSxDQUFDeEcsUUFBUSxDQUFDLENBQUMsQ0FBQytNLElBQUk7VUFBRUMsS0FBSyxFQUFFMUIsTUFBTSxDQUFDaEo7UUFBTyxDQUFDO1FBQ25IK0ksUUFBUSxFQUFFO1VBQUVuSixPQUFPLEVBQUVtSixRQUFRLENBQUM1TyxNQUFNLENBQUM4RSxJQUFJLElBQUkrRSxPQUFPLENBQUMvRyxLQUFLLENBQUNjLE9BQU8sQ0FBQ2pDLFFBQVEsQ0FBQ21ELElBQUksQ0FBQzlELEVBQUUsQ0FBQyxDQUFDLENBQUM2RSxNQUFNO1VBQUUwSyxLQUFLLEVBQUUzQixRQUFRLENBQUMvSTtRQUFPLENBQUM7UUFBRTJLLE9BQU8sRUFBRTtVQUFFL0ssT0FBTyxFQUFFLENBQUM7VUFBRThLLEtBQUssRUFBRTtRQUFFLENBQUM7UUFDekpFLGFBQWEsRUFBRTtVQUFFaEwsT0FBTyxFQUFFLElBQUlsRCxHQUFHLENBQUMyTSxZQUFZLENBQUNsUCxNQUFNLENBQUNrSSxNQUFNLElBQUlBLE1BQU0sQ0FBQ0YsS0FBSyxLQUFLLE1BQU0sQ0FBQyxDQUFDdkQsR0FBRyxDQUFDeUQsTUFBTSxJQUFJQSxNQUFNLENBQUNLLFFBQVEsQ0FBQyxDQUFDLENBQUMrSCxJQUFJO1VBQUVDLEtBQUssRUFBRXZCLFNBQVMsQ0FBQ25KO1FBQU8sQ0FBQztRQUN4SjZLLGNBQWMsRUFBRTtVQUFFakwsT0FBTyxFQUFFLElBQUlsRCxHQUFHLENBQUMyTSxZQUFZLENBQUNsUCxNQUFNLENBQUNrSSxNQUFNLElBQUlBLE1BQU0sQ0FBQ0YsS0FBSyxLQUFLLE9BQU8sQ0FBQyxDQUFDdkQsR0FBRyxDQUFDeUQsTUFBTSxJQUFJQSxNQUFNLENBQUNLLFFBQVEsQ0FBQyxDQUFDLENBQUMrSCxJQUFJO1VBQUVDLEtBQUssRUFBRXZCLFNBQVMsQ0FBQ25KO1FBQU8sQ0FBQztRQUFFOEssYUFBYSxFQUFFdlIsc0JBQXNCLENBQUMyTCxrQkFBa0IsRUFBRTtVQUFFekgsZ0JBQWdCLEVBQUV1RyxPQUFPLENBQUN2RyxnQkFBZ0I7VUFBRThNLElBQUksRUFBRSxVQUFVO1VBQUVELEtBQUssRUFBRSxFQUFFO1VBQUUzQixXQUFXLEVBQUU7WUFBRSxHQUFHQSxXQUFXO1lBQUUxRSxXQUFXLEVBQUUwRSxXQUFXLENBQUMxRSxXQUFXLENBQUNyRixHQUFHLENBQUNzRixVQUFVLEtBQUs7Y0FBRSxHQUFHQSxVQUFVO2NBQUVnRSxNQUFNLEVBQUU7Z0JBQUUsR0FBR2hFLFVBQVUsQ0FBQ2dFLE1BQU07Z0JBQUV6SyxnQkFBZ0IsRUFBRXVHLE9BQU8sQ0FBQ3ZHO2NBQWlCLENBQUM7Y0FBRTRHLEtBQUssRUFBRTtnQkFBRSxHQUFHSCxVQUFVLENBQUNHLEtBQUs7Z0JBQUU1RyxnQkFBZ0IsRUFBRXVHLE9BQU8sQ0FBQ3ZHO2NBQWlCLENBQUM7Y0FBRSxJQUFJeUcsVUFBVSxDQUFDSSxpQkFBaUIsR0FBRztnQkFBRUEsaUJBQWlCLEVBQUU7a0JBQUUsR0FBR0osVUFBVSxDQUFDSSxpQkFBaUI7a0JBQUU3RyxnQkFBZ0IsRUFBRXVHLE9BQU8sQ0FBQ3ZHO2dCQUFpQjtjQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFBRSxDQUFDLENBQUM7VUFBRTtRQUFFLENBQUMsRUFBRXVHLE9BQU8sQ0FBQ1UsVUFBVSxFQUFFVixPQUFPLENBQUNXLE1BQU07TUFDaHVCO0lBQUU7RUFDSixDQUFDO0FBQ0g7O0FBRUE7QUFDQSxPQUFPLGVBQWVvRyxvQkFBb0JBLENBQUMvUSxPQUFvQixFQUFFeVAsS0FBeUMsRUFBRUgsVUFBMEIsRUFBRXpFLE9BQXlELEdBQUcsQ0FBQyxDQUFDLEVBQWtDO0VBQUEsSUFBQW1HLHFCQUFBLEVBQUFDLEtBQUEsRUFBQUMscUJBQUEsRUFBQUMscUJBQUE7RUFDdE8sSUFBSTFCLEtBQUssQ0FBQ2MsSUFBSSxLQUFLLFVBQVUsSUFBSSxDQUFDZCxLQUFLLENBQUNkLFdBQVcsSUFBSWMsS0FBSyxDQUFDYSxLQUFLLENBQUN0SyxNQUFNLElBQUl5SixLQUFLLENBQUNoTSxnQkFBZ0IsS0FBSzZMLFVBQVUsQ0FBQzdMLGdCQUFnQixFQUFFLE1BQU0sSUFBSWhGLHFCQUFxQixDQUFDLENBQUM7SUFBRStCLElBQUksRUFBRSxtQkFBbUI7SUFBRUYsSUFBSSxFQUFFLGFBQWE7SUFBRUMsT0FBTyxFQUFFO0VBQXlCLENBQUMsQ0FBQyxDQUFDO0VBQzdQLElBQUlrUCxLQUFLLENBQUNTLGdCQUFnQixJQUFJLElBQUksSUFBSVosVUFBVSxDQUFDNU4sU0FBUyxJQUFJLElBQUksSUFBSStOLEtBQUssQ0FBQ1MsZ0JBQWdCLEtBQUtaLFVBQVUsQ0FBQzVOLFNBQVMsRUFBRSxNQUFNLElBQUlqRCxxQkFBcUIsQ0FBQyxDQUFDO0lBQUUrQixJQUFJLEVBQUUsa0JBQWtCO0lBQUVGLElBQUksRUFBRSxrQkFBa0I7SUFBRUMsT0FBTyxFQUFFO0VBQTRCLENBQUMsQ0FBQyxDQUFDO0VBQ3RQLElBQUl5SixPQUFPLEdBQUcsTUFBTVksbUJBQW1CLENBQUM1SyxPQUFPLEVBQUU7SUFBRXlELGdCQUFnQixFQUFFZ00sS0FBSyxDQUFDaE0sZ0JBQWdCO0lBQUVpSSxVQUFVLEVBQUUrRCxLQUFLLENBQUNkLFdBQVcsQ0FBQ2pELFVBQVU7SUFBRXhKLFFBQVEsRUFBRXVOLEtBQUssQ0FBQ2QsV0FBVyxDQUFDek0sUUFBUTtJQUFFcUosU0FBUyxHQUFBeUYscUJBQUEsR0FBRXZCLEtBQUssQ0FBQ2QsV0FBVyxDQUFDcEQsU0FBUyxjQUFBeUYscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxRQUFRO0lBQUUvTixLQUFLLEVBQUVxTSxVQUFVLENBQUNDLFlBQVk7SUFBRTdOLFNBQVMsR0FBQXVQLEtBQUEsSUFBQUMscUJBQUEsR0FBRXpCLEtBQUssQ0FBQ1MsZ0JBQWdCLGNBQUFnQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJNUIsVUFBVSxDQUFDNU4sU0FBUyxjQUFBdVAsS0FBQSxjQUFBQSxLQUFBLEdBQUlsUCxTQUFTO0lBQUUrRCxjQUFjLEdBQUFxTCxxQkFBQSxHQUFFMUIsS0FBSyxDQUFDVSxxQkFBcUIsY0FBQWdCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxDQUFDO0lBQUUzRixjQUFjLEVBQUVYLE9BQU8sQ0FBQ1c7RUFBZSxDQUFDLENBQUM7RUFDcmEsSUFBSWlFLEtBQUssQ0FBQzFDLGVBQWUsSUFBSTBDLEtBQUssQ0FBQzFDLGVBQWUsS0FBSy9DLE9BQU8sQ0FBQytDLGVBQWUsSUFBSXVDLFVBQVUsQ0FBQ3ZDLGVBQWUsSUFBSXVDLFVBQVUsQ0FBQ3ZDLGVBQWUsS0FBSy9DLE9BQU8sQ0FBQytDLGVBQWUsRUFBRSxNQUFNLElBQUl0TyxxQkFBcUIsQ0FBQyxDQUFDO0lBQUUrQixJQUFJLEVBQUUsbUJBQW1CO0lBQUVGLElBQUksRUFBRSxpQkFBaUI7SUFBRUMsT0FBTyxFQUFFO0VBQTBCLENBQUMsQ0FBQyxDQUFDO0VBQ3JTLE1BQU1vRyxJQUFJLEdBQUcsSUFBSWpFLEdBQUcsQ0FBUyxDQUFDO0VBQzlCLEtBQUssTUFBTSxDQUFDME8sS0FBSyxFQUFFbEgsVUFBVSxDQUFDLElBQUl1RixLQUFLLENBQUNkLFdBQVcsQ0FBQzFFLFdBQVcsQ0FBQ3dDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7SUFDekUsSUFBSTlGLElBQUksQ0FBQ3lJLEdBQUcsQ0FBQ2xGLFVBQVUsQ0FBQytELFlBQVksQ0FBQyxJQUFJL0QsVUFBVSxDQUFDeEcsUUFBUSxLQUFLK0wsS0FBSyxDQUFDZCxXQUFXLENBQUN6TSxRQUFRLENBQUNrUCxLQUFLLENBQUMsSUFBSW5TLGFBQWEsQ0FBQytLLE9BQU8sQ0FBQy9HLEtBQUssQ0FBQyxLQUFLaEUsYUFBYSxDQUFDaUwsVUFBVSxDQUFDZ0UsTUFBTSxDQUFDLEVBQUUsTUFBTSxJQUFJelAscUJBQXFCLENBQUMsQ0FBQztNQUFFK0IsSUFBSSxFQUFFLGtCQUFrQjtNQUFFRixJQUFJLEVBQUUsMkJBQTJCOFEsS0FBSyxHQUFHO01BQUU3USxPQUFPLEVBQUU7SUFBK0IsQ0FBQyxDQUFDLENBQUM7SUFDNVRvRyxJQUFJLENBQUNJLEdBQUcsQ0FBQ21ELFVBQVUsQ0FBQytELFlBQVksQ0FBQztJQUNqQ2pFLE9BQU8sR0FBRzZELHVCQUF1QixDQUFDN04sT0FBTyxFQUFFZ0ssT0FBTyxDQUFDO0lBQ25ELE1BQU1xSCxRQUFRLEdBQUdySCxPQUFPLENBQUNDLFdBQVcsQ0FBQytELEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzQyxJQUFJOUQsVUFBVSxDQUFDSSxpQkFBaUIsS0FBSyxFQUFDK0csUUFBUSxhQUFSQSxRQUFRLGVBQVJBLFFBQVEsQ0FBRS9HLGlCQUFpQixLQUFJckwsYUFBYSxDQUFDb1MsUUFBUSxDQUFDL0csaUJBQWlCLENBQUMsS0FBS3JMLGFBQWEsQ0FBQ2lMLFVBQVUsQ0FBQ0ksaUJBQWlCLENBQUMsQ0FBQyxFQUFFLE1BQU0sSUFBSTdMLHFCQUFxQixDQUFDLENBQUM7TUFBRStCLElBQUksRUFBRSxrQkFBa0I7TUFBRUYsSUFBSSxFQUFFLDJCQUEyQjhRLEtBQUsscUJBQXFCO01BQUU3USxPQUFPLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUM7SUFDOVQsSUFBSSxDQUFDOFEsUUFBUSxJQUFJcFMsYUFBYSxDQUFDb1MsUUFBUSxDQUFDaEgsS0FBSyxDQUFDLEtBQUtwTCxhQUFhLENBQUNpTCxVQUFVLENBQUNHLEtBQUssQ0FBQyxJQUFJcEwsYUFBYSxDQUFDb1MsUUFBUSxDQUFDOUcsZ0JBQWdCLENBQUMsS0FBS3RMLGFBQWEsQ0FBQ2lMLFVBQVUsQ0FBQ0ssZ0JBQWdCLENBQUMsRUFBRSxNQUFNLElBQUk5TCxxQkFBcUIsQ0FBQyxDQUFDO01BQUUrQixJQUFJLEVBQUUsa0JBQWtCO01BQUVGLElBQUksRUFBRSwyQkFBMkI4USxLQUFLLEdBQUc7TUFBRTdRLE9BQU8sRUFBRTtJQUF3QixDQUFDLENBQUMsQ0FBQztJQUMzVDtJQUNBO0lBQ0E7SUFDQThRLFFBQVEsQ0FBQ3BELFlBQVksR0FBRy9ELFVBQVUsQ0FBQytELFlBQVk7RUFDakQ7RUFDQSxPQUFPakUsT0FBTztBQUNoQiIsImlnbm9yZUxpc3QiOltdfQ==