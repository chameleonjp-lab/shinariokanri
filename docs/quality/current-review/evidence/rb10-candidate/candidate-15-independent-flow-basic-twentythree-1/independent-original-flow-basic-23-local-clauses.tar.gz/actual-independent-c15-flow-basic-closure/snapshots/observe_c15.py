"""Independent literal-clause ledger updater. Only explicit reviewed observations are marked.
No inference from a run exit code, test count, CI, historical targets, or component existence.
"""
from pathlib import Path
from collections import Counter
import json,hashlib,datetime,shutil
ROOT=Path(__file__).resolve().parent
LEDGER=ROOT/'ORIGINAL116_C15_ACTUAL_CLAUSE_LEDGER.json'
EXT=Path('/workspace/shinariokanri-independent-artifacts/c15-6ed5654')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def desc(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def walk(suites):
 for s in suites:
  yield from s.get('specs',[])
  yield from walk(s.get('suites',[]))
def mark(case,run,pattern,texts,whole=False,notes=None):
 assert set(texts)<=set(['given','when','then','negative_or_edge'])
 d=load(LEDGER);o=load(ROOT/'candidate/docs/data/acceptance_cases.json')
 assert len(d['cases'])==len(o)==116
 for row,original in zip(d['cases'],o):assert row['originalContract']==original
 result=ROOT/'results'/run;b=load(result/'EXECUTION_BINDING.json')
 assert b['commit']==d['commit'] and b['tree']==d['tree'] and b['sealedCandidateUnchanged']
 files=list((EXT/run/'artifacts').rglob(pattern));assert len(files)==1,(pattern,files)
 p=files[0];report=load(result/'playwright.json');matched=[]
 for sp in walk(report['suites']):
  for t in sp.get('tests',[]):
   for r in t.get('results',[]):
    if r['status']!='passed':continue
    for a in r.get('attachments',[]):
     ap=Path(a['path']) if a.get('path') else None
     if ap and ap.is_file() and sha(ap)==sha(p):matched.append((sp,r))
 assert len(matched)==1,(case,run,'matching actually passed result missing')
 sp,r=matched[0];source=result/'input-source'/('harness/'+Path(sp['file']).name)
 proof={'testTitle':sp['title'],'actualStatus':'passed','durationMS':r['duration'],'run':run,'executionBinding':desc(result/'EXECUTION_BINDING.json'),'raw':desc(result/'raw.log'),'actualProcedure':desc(source),'proof':desc(p),'actualArchiveBindings':[desc(q) for q in sorted(p.parent.glob('*binding*.json'))],'normalization':'Actual individual result only; original conditions unchanged and historical/physical/live promotion forbidden.','environment':b['environment']}
 sup=ROOT/'supervised'/run
 for key,file in [('supervisorLaunch','LAUNCH_INPUTS.json'),('compiledArtifactManifest','COMPILED_ARTIFACTS.json')]:
  if(sup/file).exists():proof[key]=desc(sup/file)
 hist=ROOT/'preparation-history'/'ledger-snapshots';hist.mkdir(exist_ok=True)
 saved=hist/(sha(LEDGER)+'.json')
 if not saved.exists():shutil.copyfile(LEDGER,saved)
 row=next(c for c in d['cases'] if c['caseId']==case)
 for key,text in texts.items():
  row['clauses'][key]['actualStatus']='observed_passed_C15_normal_production_and_native'
  row['clauses'][key]['directObservation']=text
  row['clauses'][key]['proof']=proof
 if whole:
  assert len(texts)==4 and not any(c.get('environmentOnlyConditions') for c in row['clauses'].values()),'No local whole claim may absorb a named external requirement'
  row['caseResult']='fully_observed_local_original_four_clauses'
 else:row['caseResult']='partially_observed_C15_original_combination'
 if notes:row['adjudicationNotes']=notes
 d['fullyObservedLocalCases']=[c['caseId'] for c in d['cases'] if c.get('caseResult')=='fully_observed_local_original_four_clauses']
 d['whole116Passed']=False;d['historicalResultsPromoted']=0;d['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 LEDGER.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 summary={'commit':d['commit'],'tree':d['tree'],'build':d['build'],'ledger':desc(LEDGER),'caseCounts':dict(Counter(c.get('caseResult','unjudged_C15_original_combination') for c in d['cases'])),'clauseCounts':dict(Counter(c['actualStatus'] for row in d['cases'] for c in row['clauses'].values())),'environmentPartClauses':sum(bool(c.get('environmentOnlyConditions')) for row in d['cases'] for c in row['clauses'].values()),'caseSpecificNextActionsPresent':True,'physicalLiveInferred':False,'updatedAt':d['updatedAt']}
 (ROOT/'ORIGINAL116_C15_CURRENT_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'case':case,'run':run,'ledgerSHA256':sha(LEDGER),'wholeLocalCount':len(d['fullyObservedLocalCases'])},ensure_ascii=False))
if __name__=='__main__':
 mark('AT-F17','c15-literal-runtime-3','F17-literal-denominators-*.json',{
 'given':'Exact actual fixture has four scene IDs, three choice edges and four explicit node/edge condition sites. Three createEntity default gates were removed from the fixture before this execution; the earlier seven-site failure is preserved.',
 'when':'Ordinary Reader chose exactly two edges, saved its trace atomically, cold reloaded and replayed to the intended terminal. Then the scene body was edited and atomically saved; reconfirmation UI reports the old trace as pending.',
 'then':'Saved coverage has scenes checked3/total4, choices checked2/total3, dialogue checked3/total4 and condition true/false denominators4 each. Merely presenting three scenes did not credit every condition outcome.',
 'negative_or_edge':'Dialogue, choice and condition coverage remain separate in the actual archive. After normal content modification, the old fixed snapshot and trace remained identical and the trace is explicitly pending reconfirmation.'},whole=True)
