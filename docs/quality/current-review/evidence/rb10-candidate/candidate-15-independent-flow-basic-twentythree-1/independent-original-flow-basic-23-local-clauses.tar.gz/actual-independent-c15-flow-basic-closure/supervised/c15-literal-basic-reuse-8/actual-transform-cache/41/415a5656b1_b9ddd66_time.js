// be5c916201f0b704b51acad5f1d08660828e15ab
export const TICK_PATTERN = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/;
export const MAX_TICK = 10n ** 38n - 1n;
export const GREGORIAN_CALENDAR = {
  id: 'proleptic-gregorian-second',
  name: '先発グレゴリオ暦',
  kind: 'gregorian',
  originLabel: '0000-01-01 00:00:00',
  ticksPerDay: '86400'
};
export function isTick(value) {
  return typeof value === 'string' && TICK_PATTERN.test(value);
}
export function parseTick(value) {
  if (!isTick(value)) throw new RangeError('tickは38桁以内の正規整数文字列で指定してください。');
  return BigInt(value);
}
export function toTick(value) {
  if (value < -MAX_TICK || value > MAX_TICK) throw new RangeError('tickが38桁の範囲を超えています。');
  return value.toString();
}
export function addTicks(a, b) {
  return toTick(parseTick(a) + parseTick(b));
}
export function subtractTicks(a, b) {
  return toTick(parseTick(a) - parseTick(b));
}
export function compareTicks(a, b) {
  const x = parseTick(a),
    y = parseTick(b);
  return x < y ? -1 : x > y ? 1 : 0;
}
export function formatRelativeTick(at, mainStart, unit = '1') {
  const delta = parseTick(at) - parseTick(mainStart),
    divisor = parseTick(unit);
  if (divisor <= 0n) throw new RangeError('表示単位は正の整数です。');
  const negative = delta < 0n,
    abs = negative ? -delta : delta,
    quotient = abs / divisor,
    remainder = abs % divisor;
  return `${negative ? '−' : delta > 0n ? '+' : ''}${quotient}${remainder ? ` + ${remainder}/${divisor}` : ''}`;
}
export function tickToScreen(at, origin, ticksPerPixel, maxPixels = 1000000) {
  const divisor = parseTick(ticksPerPixel);
  if (divisor <= 0n || !Number.isSafeInteger(maxPixels) || maxPixels <= 0) throw new RangeError('描画単位が不正です。');
  const delta = parseTick(at) - parseTick(origin),
    quotient = delta / divisor;
  if (quotient > BigInt(maxPixels)) return maxPixels;
  if (quotient < -BigInt(maxPixels)) return -maxPixels;
  // Only this derived coordinate converts to Number; original ticks are untouched.
  return Number(quotient) + Number(delta % divisor) / Number(divisor);
}
export function floorDiv(a, b) {
  if (b <= 0n) throw new RangeError('除数は正数です。');
  const q = a / b,
    r = a % b;
  return r < 0n ? q - 1n : q;
}
function mod(a, b) {
  return a - floorDiv(a, b) * b;
}
export function isLeapYear(year) {
  return mod(year, 4n) === 0n && (mod(year, 100n) !== 0n || mod(year, 400n) === 0n);
}
const MONTH_DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function gregorianYearStart(year) {
  // Astronomical year 0 is a leap year; origin is 0000-01-01.
  return 365n * year + floorDiv(year + 3n, 4n) - floorDiv(year + 99n, 100n) + floorDiv(year + 399n, 400n);
}
export function validateCalendar(input, path = 'calendar') {
  const fail = (message, field = path) => ({
    ok: false,
    issues: [{
      code: 'VALIDATION_FAILED',
      path: field,
      message
    }]
  });
  if (!input || typeof input !== 'object' || Array.isArray(input)) return fail('暦はオブジェクトです。');
  const cal = input;
  const allowed = cal.kind === 'repeating' ? ['id', 'name', 'kind', 'originLabel', 'ticksPerDay', 'years'] : ['id', 'name', 'kind', 'originLabel', 'ticksPerDay'];
  if (Object.keys(cal).some(key => !allowed.includes(key))) return fail('暦に未知の項目があります。');
  if (typeof cal.id !== 'string' || !cal.id || typeof cal.name !== 'string' || !cal.name || typeof cal.originLabel !== 'string') return fail('暦のID・名称・原点ラベルが必要です。');
  if (!isTick(cal.ticksPerDay) || parseTick(cal.ticksPerDay) <= 0n) return fail('1日のtick数は正の整数です。', `${path}.ticksPerDay`);
  if (cal.kind === 'gregorian') {
    if (cal.ticksPerDay !== '86400') return fail('標準暦は1日86400tickです。', `${path}.ticksPerDay`);
    return {
      ok: true,
      value: input
    };
  }
  if (cal.kind !== 'repeating' || !Array.isArray(cal.years) || cal.years.length < 1 || cal.years.length > 400) return fail('繰返し暦は1〜400年の周期が必要です。');
  for (let i = 0; i < cal.years.length; i++) {
    const year = cal.years[i];
    if (!year || typeof year !== 'object' || Object.keys(year).some(key => key !== 'months') || !Array.isArray(year.months) || year.months.length < 1 || year.months.length > 24) return fail('1年の月数は1〜24です。', `${path}.years[${i}]`);
    for (let j = 0; j < year.months.length; j++) {
      const month = year.months[j];
      if (!month || typeof month !== 'object' || Object.keys(month).some(key => !['name', 'days'].includes(key)) || typeof month.name !== 'string' || !month.name || !Number.isInteger(month.days) || month.days < 1 || month.days > 400) return fail('月名と1〜400の日数が必要です。', `${path}.years[${i}].months[${j}]`);
    }
  }
  return {
    ok: true,
    value: input
  };
}
export function calendarDateToTick(date, calendar = GREGORIAN_CALENDAR) {
  var _date$tickOfDay;
  const valid = validateCalendar(calendar);
  if (!valid.ok) throw new RangeError(valid.issues[0].message);
  const year = parseTick(date.year),
    monthIndex = date.month - 1;
  if (!Number.isInteger(date.month) || !Number.isInteger(date.day)) throw new RangeError('月・日は整数です。');
  let days;
  if (calendar.kind === 'gregorian') {
    const monthDays = [...MONTH_DAYS];
    if (isLeapYear(year)) monthDays[1] = 29;
    if (monthIndex < 0 || monthIndex >= 12 || date.day < 1 || date.day > monthDays[monthIndex]) throw new RangeError('暦に存在しない日付です。');
    days = gregorianYearStart(year) + BigInt(monthDays.slice(0, monthIndex).reduce((a, b) => a + b, 0) + date.day - 1);
  } else {
    const period = BigInt(calendar.years.length),
      position = Number(mod(year, period));
    const lengths = calendar.years.map(y => y.months.reduce((sum, month) => sum + month.days, 0));
    const months = calendar.years[position].months;
    if (monthIndex < 0 || monthIndex >= months.length || date.day < 1 || date.day > months[monthIndex].days) throw new RangeError('暦に存在しない日付です。');
    days = floorDiv(year, period) * BigInt(lengths.reduce((a, b) => a + b, 0)) + BigInt(lengths.slice(0, position).reduce((a, b) => a + b, 0));
    days += BigInt(months.slice(0, monthIndex).reduce((sum, month) => sum + month.days, 0) + date.day - 1);
  }
  const withinDay = parseTick((_date$tickOfDay = date.tickOfDay) !== null && _date$tickOfDay !== void 0 ? _date$tickOfDay : '0'),
    ticksPerDay = parseTick(calendar.ticksPerDay);
  if (withinDay < 0n || withinDay >= ticksPerDay) throw new RangeError('時刻は1日のtick範囲内で指定してください。');
  return toTick(days * ticksPerDay + withinDay);
}
export function tickToCalendarDate(tick, calendar = GREGORIAN_CALENDAR) {
  const valid = validateCalendar(calendar);
  if (!valid.ok) throw new RangeError(valid.issues[0].message);
  const value = parseTick(tick),
    ticksPerDay = parseTick(calendar.ticksPerDay),
    dayNumber = floorDiv(value, ticksPerDay);
  let year, dayOfYear, months;
  if (calendar.kind === 'gregorian') {
    const cycle = floorDiv(dayNumber, 146097n),
      cycleStart = cycle * 400n;
    year = cycleStart;
    const remainder = dayNumber - cycle * 146097n;
    // A bounded loop (at most 400), independent of the size of a world tick.
    while (year < cycleStart + 399n && gregorianYearStart(year + 1n) - cycle * 146097n <= remainder) year++;
    dayOfYear = Number(dayNumber - gregorianYearStart(year));
    months = MONTH_DAYS.map((days, index) => ({
      days: index === 1 && isLeapYear(year) ? 29 : days
    }));
  } else {
    const lengths = calendar.years.map(y => y.months.reduce((sum, month) => sum + month.days, 0)),
      cycleDays = BigInt(lengths.reduce((a, b) => a + b, 0));
    const cycle = floorDiv(dayNumber, cycleDays);
    let remainder = Number(mod(dayNumber, cycleDays)),
      position = 0;
    while (position < lengths.length - 1 && remainder >= lengths[position]) remainder -= lengths[position++];
    year = cycle * BigInt(lengths.length) + BigInt(position);
    dayOfYear = remainder;
    months = calendar.years[position].months;
  }
  let month = 0;
  while (month < months.length - 1 && dayOfYear >= months[month].days) dayOfYear -= months[month++].days;
  return {
    year: year.toString(),
    month: month + 1,
    day: dayOfYear + 1,
    tickOfDay: mod(value, ticksPerDay).toString()
  };
}
export function formatCalendarTick(tick, calendar = GREGORIAN_CALENDAR) {
  const date = tickToCalendarDate(tick, calendar);
  return `${date.year}年${date.month}月${date.day}日${date.tickOfDay !== '0' ? ` +${date.tickOfDay} tick` : ''}`;
}
function absoluteResolution(time, path) {
  try {
    if (time.mode === 'unknown') return {
      status: 'unknown',
      reason: time.reason || '日時が未定です。',
      path
    };
    if (time.mode === 'instant') {
      parseTick(time.at);
      return {
        status: 'resolved',
        earliest: time.at,
        latest: time.at,
        endEarliest: time.at,
        endLatest: time.at,
        calendarId: time.calendarId,
        mode: time.mode
      };
    }
    if (time.mode === 'interval') {
      if (compareTicks(time.start, time.end) >= 0) return {
        status: 'conflict',
        reason: '期間は開始より後に終了してください。',
        path
      };
      return {
        status: 'resolved',
        earliest: time.start,
        latest: time.start,
        endEarliest: time.end,
        endLatest: time.end,
        calendarId: time.calendarId,
        mode: time.mode
      };
    }
    if (compareTicks(time.earliest, time.latest) > 0) return {
      status: 'conflict',
      reason: '概算範囲が逆転しています。',
      path
    };
    return {
      status: 'resolved',
      earliest: time.earliest,
      latest: time.latest,
      endEarliest: time.earliest,
      endLatest: time.latest,
      calendarId: time.calendarId,
      mode: time.mode
    };
  } catch (error) {
    return {
      status: 'conflict',
      reason: error instanceof Error ? error.message : '日時を解決できません。',
      path
    };
  }
}
function relativeValue(time, anchor, path, prefixUnknown) {
  try {
    if (compareTicks(time.minOffset, time.maxOffset) > 0) return {
      status: 'conflict',
      reason: '相対日時の範囲が逆転しています。',
      path: path()
    };
    if (anchor.status !== 'resolved') return prefixUnknown ? {
      ...anchor,
      path: [...path(), ...anchor.path].slice(0, 64)
    } : anchor;
    const earliest = addTicks(time.anchorPoint === 'start' ? anchor.earliest : anchor.endEarliest, time.minOffset),
      latest = addTicks(time.anchorPoint === 'start' ? anchor.latest : anchor.endLatest, time.maxOffset);
    return {
      status: 'resolved',
      earliest,
      latest,
      endEarliest: earliest,
      endLatest: latest,
      calendarId: anchor.calendarId,
      mode: 'relative'
    };
  } catch (error) {
    return {
      status: 'conflict',
      reason: error instanceof Error ? error.message : '日時を解決できません。',
      path: path()
    };
  }
}
/** One relative-time evaluator shared by validation, previews and character lifetimes. */
export function resolveRelativeTime(time, anchor, path = []) {
  return relativeValue(time, anchor, () => path, true);
}
function eventIndex(events) {
  const index = new Map();
  for (const event of events) if (!event.deletedAt && !index.has(event.id)) index.set(event.id, event);
  return index;
}
/** Public arbitrary-TimeSpec wrapper. The supplied chain remains a set of forbidden ancestor IDs. */
export function resolveTime(time, events = [], chain = []) {
  if (time.mode !== 'relative') return absoluteResolution(time, chain);
  const index = eventIndex(events),
    path = [...chain],
    visited = new Set(chain),
    frames = [];
  let cursor = time;
  while (cursor.mode === 'relative') {
    if (visited.has(cursor.anchorEventId)) return {
      status: 'conflict',
      reason: '相対日時の参照が循環しています。',
      path: [...path, cursor.anchorEventId]
    };
    try {
      if (compareTicks(cursor.minOffset, cursor.maxOffset) > 0) return {
        status: 'conflict',
        reason: '相対日時の範囲が逆転しています。',
        path: [...path]
      };
    } catch (error) {
      return {
        status: 'conflict',
        reason: error instanceof Error ? error.message : '日時を解決できません。',
        path: [...path]
      };
    }
    const anchor = index.get(cursor.anchorEventId);
    if (!anchor) return {
      status: 'unknown',
      reason: '基準となる出来事がありません。',
      path: [...path, cursor.anchorEventId]
    };
    frames.push({
      time: cursor,
      pathLength: path.length
    });
    visited.add(anchor.id);
    path.push(anchor.id);
    cursor = anchor.data.time;
  }
  let resolved = absoluteResolution(cursor, path);
  for (let i = frames.length - 1; i >= 0 && resolved.status === 'resolved'; i--) {
    const frame = frames[i];
    resolved = relativeValue(frame.time, resolved, () => path.slice(0, frame.pathLength), false);
  }
  return resolved;
}
/** Indexed and iterative O(events + anchors). Diagnostic paths are bounded for cyclic imported graphs. */
export function resolveEventTimes(events) {
  const index = eventIndex(events),
    resolved = new Map();
  for (const event of index.values()) {
    if (resolved.has(event.id)) continue;
    const path = [],
      visiting = new Map();
    let cursor = event.id;
    while (!resolved.has(cursor)) {
      const current = index.get(cursor);
      if (!current) {
        resolved.set(cursor, {
          status: 'unknown',
          reason: '基準となる出来事がありません。',
          path: [cursor]
        });
        break;
      }
      const cycleStart = visiting.get(cursor);
      if (cycleStart !== undefined) {
        const cycle = path.slice(cycleStart);
        for (let i = 0; i < cycle.length; i++) resolved.set(cycle[i], {
          status: 'conflict',
          reason: '相対日時の参照が循環しています。',
          path: Array.from({
            length: Math.min(cycle.length + 1, 64)
          }, (_, offset) => cycle[(i + offset) % cycle.length])
        });
        break;
      }
      if (current.data.time.mode !== 'relative') {
        resolved.set(cursor, absoluteResolution(current.data.time, [cursor]));
        break;
      }
      const relative = current.data.time;
      // Cycles take precedence when an anchor already appears in this path, matching resolveTime.
      if (!visiting.has(relative.anchorEventId) && relative.anchorEventId !== cursor) try {
        if (compareTicks(relative.minOffset, relative.maxOffset) > 0) {
          resolved.set(cursor, {
            status: 'conflict',
            reason: '相対日時の範囲が逆転しています。',
            path: [cursor]
          });
          break;
        }
      } catch (error) {
        resolved.set(cursor, {
          status: 'conflict',
          reason: error instanceof Error ? error.message : '日時を解決できません。',
          path: [cursor]
        });
        break;
      }
      visiting.set(cursor, path.length);
      path.push(cursor);
      cursor = relative.anchorEventId;
    }
    for (let i = path.length - 1; i >= 0; i--) {
      const id = path[i],
        current = index.get(id);
      if (!resolved.has(id) && current.data.time.mode === 'relative') resolved.set(id, resolveRelativeTime(current.data.time, resolved.get(current.data.time.anchorEventId), [id]));
    }
  }
  return resolved;
}
export function validateEventTimes(events) {
  const issues = [],
    index = eventIndex(events),
    times = resolveEventTimes(events);
  for (const event of index.values()) {
    const time = times.get(event.id);
    if (time.status === 'conflict') issues.push({
      code: 'TIME_CONSTRAINT_CONFLICT',
      path: `entities.${event.id}.data.time`,
      message: time.reason
    });
    for (const constraint of (_event$data$constrain = event.data.constraints) !== null && _event$data$constrain !== void 0 ? _event$data$constrain : []) {
      var _event$data$constrain;
      const target = index.get(constraint.targetEventId);
      if (!target || time.status !== 'resolved') continue;
      const other = times.get(target.id);
      if (other.status !== 'resolved') continue;
      let conflict = time.calendarId !== other.calendarId;
      if (constraint.type === 'before') conflict || (conflict = time.mode === 'interval' ? compareTicks(time.endEarliest, other.latest) > 0 : compareTicks(time.endEarliest, other.latest) >= 0);else if (constraint.type === 'same_start') conflict || (conflict = compareTicks(time.earliest, other.latest) > 0 || compareTicks(other.earliest, time.latest) > 0);else {
        const minGap = parseTick(other.earliest) - parseTick(time.endLatest),
          maxGap = parseTick(other.latest) - parseTick(time.endEarliest);
        conflict || (conflict = maxGap < parseTick(constraint.minimumTicks) || minGap > parseTick(constraint.maximumTicks));
      }
      if (conflict) issues.push({
        code: 'TIME_CONSTRAINT_CONFLICT',
        path: `entities.${event.id}.data.constraints`,
        message: '指定した出来事の日時制約と矛盾しています。'
      });
    }
  }
  // Cyclic dependency constraints cannot be applied even while their dates are unknown.
  const colors = new Map(),
    dependencies = new Map();
  for (const event of index.values()) {
    var _event$data$constrain2;
    dependencies.set(event.id, ((_event$data$constrain2 = event.data.constraints) !== null && _event$data$constrain2 !== void 0 ? _event$data$constrain2 : []).map(constraint => constraint.targetEventId));
  }
  for (const event of index.values()) if (event.data.time.mode === 'relative' && index.has(event.data.time.anchorEventId)) dependencies.get(event.data.time.anchorEventId).push(event.id);
  for (const event of index.values()) {
    if (colors.get(event.id)) continue;
    const stack = [{
      id: event.id,
      targets: dependencies.get(event.id),
      cursor: 0
    }];
    colors.set(event.id, 1);
    while (stack.length) {
      const current = stack[stack.length - 1];
      if (current.cursor === current.targets.length) {
        colors.set(current.id, 2);
        stack.pop();
        continue;
      }
      const targetId = current.targets[current.cursor++],
        target = index.get(targetId);
      if (!target) continue;
      if (colors.get(targetId) === 1) issues.push({
        code: 'TIME_CONSTRAINT_CONFLICT',
        path: `entities.${current.id}.data.constraints`,
        message: '日時制約の依存が循環しています。'
      });else if (!colors.has(targetId)) {
        colors.set(targetId, 1);
        stack.push({
          id: targetId,
          targets: dependencies.get(target.id),
          cursor: 0
        });
      }
    }
  }
  return issues;
}

/** Shared IDs are safe only when the complete calendar definition is unchanged. */
export function sameCalendarDefinition(left, right) {
  if (left.id !== right.id || left.kind !== right.kind || left.name !== right.name || left.originLabel !== right.originLabel || left.ticksPerDay !== right.ticksPerDay) return false;
  if (left.kind === 'gregorian' || right.kind === 'gregorian') return left.kind === right.kind;
  return left.years.length === right.years.length && left.years.every((year, i) => year.months.length === right.years[i].months.length && year.months.every((month, j) => month.name === right.years[i].months[j].name && month.days === right.years[i].months[j].days));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJUSUNLX1BBVFRFUk4iLCJNQVhfVElDSyIsIkdSRUdPUklBTl9DQUxFTkRBUiIsImlkIiwibmFtZSIsImtpbmQiLCJvcmlnaW5MYWJlbCIsInRpY2tzUGVyRGF5IiwiaXNUaWNrIiwidmFsdWUiLCJ0ZXN0IiwicGFyc2VUaWNrIiwiUmFuZ2VFcnJvciIsIkJpZ0ludCIsInRvVGljayIsInRvU3RyaW5nIiwiYWRkVGlja3MiLCJhIiwiYiIsInN1YnRyYWN0VGlja3MiLCJjb21wYXJlVGlja3MiLCJ4IiwieSIsImZvcm1hdFJlbGF0aXZlVGljayIsImF0IiwibWFpblN0YXJ0IiwidW5pdCIsImRlbHRhIiwiZGl2aXNvciIsIm5lZ2F0aXZlIiwiYWJzIiwicXVvdGllbnQiLCJyZW1haW5kZXIiLCJ0aWNrVG9TY3JlZW4iLCJvcmlnaW4iLCJ0aWNrc1BlclBpeGVsIiwibWF4UGl4ZWxzIiwiTnVtYmVyIiwiaXNTYWZlSW50ZWdlciIsImZsb29yRGl2IiwicSIsInIiLCJtb2QiLCJpc0xlYXBZZWFyIiwieWVhciIsIk1PTlRIX0RBWVMiLCJncmVnb3JpYW5ZZWFyU3RhcnQiLCJ2YWxpZGF0ZUNhbGVuZGFyIiwiaW5wdXQiLCJwYXRoIiwiZmFpbCIsIm1lc3NhZ2UiLCJmaWVsZCIsIm9rIiwiaXNzdWVzIiwiY29kZSIsIkFycmF5IiwiaXNBcnJheSIsImNhbCIsImFsbG93ZWQiLCJPYmplY3QiLCJrZXlzIiwic29tZSIsImtleSIsImluY2x1ZGVzIiwieWVhcnMiLCJsZW5ndGgiLCJpIiwibW9udGhzIiwiaiIsIm1vbnRoIiwiaXNJbnRlZ2VyIiwiZGF5cyIsImNhbGVuZGFyRGF0ZVRvVGljayIsImRhdGUiLCJjYWxlbmRhciIsIl9kYXRlJHRpY2tPZkRheSIsInZhbGlkIiwibW9udGhJbmRleCIsImRheSIsIm1vbnRoRGF5cyIsInNsaWNlIiwicmVkdWNlIiwicGVyaW9kIiwicG9zaXRpb24iLCJsZW5ndGhzIiwibWFwIiwic3VtIiwid2l0aGluRGF5IiwidGlja09mRGF5IiwidGlja1RvQ2FsZW5kYXJEYXRlIiwidGljayIsImRheU51bWJlciIsImRheU9mWWVhciIsImN5Y2xlIiwiY3ljbGVTdGFydCIsImluZGV4IiwiY3ljbGVEYXlzIiwiZm9ybWF0Q2FsZW5kYXJUaWNrIiwiYWJzb2x1dGVSZXNvbHV0aW9uIiwidGltZSIsIm1vZGUiLCJzdGF0dXMiLCJyZWFzb24iLCJlYXJsaWVzdCIsImxhdGVzdCIsImVuZEVhcmxpZXN0IiwiZW5kTGF0ZXN0IiwiY2FsZW5kYXJJZCIsInN0YXJ0IiwiZW5kIiwiZXJyb3IiLCJFcnJvciIsInJlbGF0aXZlVmFsdWUiLCJhbmNob3IiLCJwcmVmaXhVbmtub3duIiwibWluT2Zmc2V0IiwibWF4T2Zmc2V0IiwiYW5jaG9yUG9pbnQiLCJyZXNvbHZlUmVsYXRpdmVUaW1lIiwiZXZlbnRJbmRleCIsImV2ZW50cyIsIk1hcCIsImV2ZW50IiwiZGVsZXRlZEF0IiwiaGFzIiwic2V0IiwicmVzb2x2ZVRpbWUiLCJjaGFpbiIsInZpc2l0ZWQiLCJTZXQiLCJmcmFtZXMiLCJjdXJzb3IiLCJhbmNob3JFdmVudElkIiwiZ2V0IiwicHVzaCIsInBhdGhMZW5ndGgiLCJhZGQiLCJkYXRhIiwicmVzb2x2ZWQiLCJmcmFtZSIsInJlc29sdmVFdmVudFRpbWVzIiwidmFsdWVzIiwidmlzaXRpbmciLCJjdXJyZW50IiwidW5kZWZpbmVkIiwiZnJvbSIsIk1hdGgiLCJtaW4iLCJfIiwib2Zmc2V0IiwicmVsYXRpdmUiLCJ2YWxpZGF0ZUV2ZW50VGltZXMiLCJ0aW1lcyIsImNvbnN0cmFpbnQiLCJfZXZlbnQkZGF0YSRjb25zdHJhaW4iLCJjb25zdHJhaW50cyIsInRhcmdldCIsInRhcmdldEV2ZW50SWQiLCJvdGhlciIsImNvbmZsaWN0IiwidHlwZSIsIm1pbkdhcCIsIm1heEdhcCIsIm1pbmltdW1UaWNrcyIsIm1heGltdW1UaWNrcyIsImNvbG9ycyIsImRlcGVuZGVuY2llcyIsIl9ldmVudCRkYXRhJGNvbnN0cmFpbjIiLCJzdGFjayIsInRhcmdldHMiLCJwb3AiLCJ0YXJnZXRJZCIsInNhbWVDYWxlbmRhckRlZmluaXRpb24iLCJsZWZ0IiwicmlnaHQiLCJldmVyeSJdLCJzb3VyY2VzIjpbInRpbWUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDYWxlbmRhckRlZmluaXRpb24sIEVudGl0eSwgSUQsIFRpY2ssIFRpbWVTcGVjLCBWYWxpZGF0aW9uSXNzdWUsIFZhbGlkYXRpb25SZXN1bHQgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGNvbnN0IFRJQ0tfUEFUVEVSTiA9IC9eKD86MHwtWzEtOV1bMC05XXswLDM3fXxbMS05XVswLTldezAsMzd9KSQvO1xuZXhwb3J0IGNvbnN0IE1BWF9USUNLID0gMTBuICoqIDM4biAtIDFuO1xuZXhwb3J0IGNvbnN0IEdSRUdPUklBTl9DQUxFTkRBUjogQ2FsZW5kYXJEZWZpbml0aW9uID0geyBpZDogJ3Byb2xlcHRpYy1ncmVnb3JpYW4tc2Vjb25kJywgbmFtZTogJ+WFiOeZuuOCsOODrOOCtOODquOCquaapicsIGtpbmQ6ICdncmVnb3JpYW4nLCBvcmlnaW5MYWJlbDogJzAwMDAtMDEtMDEgMDA6MDA6MDAnLCB0aWNrc1BlckRheTogJzg2NDAwJyB9O1xuZXhwb3J0IGZ1bmN0aW9uIGlzVGljayh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIFRpY2sgeyByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiBUSUNLX1BBVFRFUk4udGVzdCh2YWx1ZSk7IH1cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVRpY2sodmFsdWU6IFRpY2spOiBiaWdpbnQgeyBpZiAoIWlzVGljayh2YWx1ZSkpIHRocm93IG5ldyBSYW5nZUVycm9yKCd0aWNr44GvMzjmoYHku6XlhoXjga7mraPopo/mlbTmlbDmloflrZfliJfjgafmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTsgcmV0dXJuIEJpZ0ludCh2YWx1ZSk7IH1cbmV4cG9ydCBmdW5jdGlvbiB0b1RpY2sodmFsdWU6IGJpZ2ludCk6IFRpY2sgeyBpZiAodmFsdWUgPCAtTUFYX1RJQ0sgfHwgdmFsdWUgPiBNQVhfVElDSykgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ3RpY2vjgYwzOOahgeOBruevhOWbsuOCkui2heOBiOOBpuOBhOOBvuOBmeOAgicpOyByZXR1cm4gdmFsdWUudG9TdHJpbmcoKTsgfVxuZXhwb3J0IGZ1bmN0aW9uIGFkZFRpY2tzKGE6IFRpY2ssIGI6IFRpY2spOiBUaWNrIHsgcmV0dXJuIHRvVGljayhwYXJzZVRpY2soYSkgKyBwYXJzZVRpY2soYikpOyB9XG5leHBvcnQgZnVuY3Rpb24gc3VidHJhY3RUaWNrcyhhOiBUaWNrLCBiOiBUaWNrKTogVGljayB7IHJldHVybiB0b1RpY2socGFyc2VUaWNrKGEpIC0gcGFyc2VUaWNrKGIpKTsgfVxuZXhwb3J0IGZ1bmN0aW9uIGNvbXBhcmVUaWNrcyhhOiBUaWNrLCBiOiBUaWNrKTogLTEgfCAwIHwgMSB7IGNvbnN0IHggPSBwYXJzZVRpY2soYSksIHkgPSBwYXJzZVRpY2soYik7IHJldHVybiB4IDwgeSA/IC0xIDogeCA+IHkgPyAxIDogMDsgfVxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFJlbGF0aXZlVGljayhhdDogVGljaywgbWFpblN0YXJ0OiBUaWNrLCB1bml0OiBUaWNrID0gJzEnKTogc3RyaW5nIHtcbiAgY29uc3QgZGVsdGEgPSBwYXJzZVRpY2soYXQpIC0gcGFyc2VUaWNrKG1haW5TdGFydCksIGRpdmlzb3IgPSBwYXJzZVRpY2sodW5pdCk7XG4gIGlmIChkaXZpc29yIDw9IDBuKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcign6KGo56S65Y2Y5L2N44Gv5q2j44Gu5pW05pWw44Gn44GZ44CCJyk7XG4gIGNvbnN0IG5lZ2F0aXZlID0gZGVsdGEgPCAwbiwgYWJzID0gbmVnYXRpdmUgPyAtZGVsdGEgOiBkZWx0YSwgcXVvdGllbnQgPSBhYnMgLyBkaXZpc29yLCByZW1haW5kZXIgPSBhYnMgJSBkaXZpc29yO1xuICByZXR1cm4gYCR7bmVnYXRpdmUgPyAn4oiSJyA6IGRlbHRhID4gMG4gPyAnKycgOiAnJ30ke3F1b3RpZW50fSR7cmVtYWluZGVyID8gYCArICR7cmVtYWluZGVyfS8ke2Rpdmlzb3J9YCA6ICcnfWA7XG59XG5leHBvcnQgZnVuY3Rpb24gdGlja1RvU2NyZWVuKGF0OiBUaWNrLCBvcmlnaW46IFRpY2ssIHRpY2tzUGVyUGl4ZWw6IFRpY2ssIG1heFBpeGVscyA9IDFfMDAwXzAwMCk6IG51bWJlciB7XG4gIGNvbnN0IGRpdmlzb3IgPSBwYXJzZVRpY2sodGlja3NQZXJQaXhlbCk7XG4gIGlmIChkaXZpc29yIDw9IDBuIHx8ICFOdW1iZXIuaXNTYWZlSW50ZWdlcihtYXhQaXhlbHMpIHx8IG1heFBpeGVscyA8PSAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcign5o+P55S75Y2Y5L2N44GM5LiN5q2j44Gn44GZ44CCJyk7XG4gIGNvbnN0IGRlbHRhID0gcGFyc2VUaWNrKGF0KSAtIHBhcnNlVGljayhvcmlnaW4pLCBxdW90aWVudCA9IGRlbHRhIC8gZGl2aXNvcjtcbiAgaWYgKHF1b3RpZW50ID4gQmlnSW50KG1heFBpeGVscykpIHJldHVybiBtYXhQaXhlbHM7XG4gIGlmIChxdW90aWVudCA8IC1CaWdJbnQobWF4UGl4ZWxzKSkgcmV0dXJuIC1tYXhQaXhlbHM7XG4gIC8vIE9ubHkgdGhpcyBkZXJpdmVkIGNvb3JkaW5hdGUgY29udmVydHMgdG8gTnVtYmVyOyBvcmlnaW5hbCB0aWNrcyBhcmUgdW50b3VjaGVkLlxuICByZXR1cm4gTnVtYmVyKHF1b3RpZW50KSArIE51bWJlcihkZWx0YSAlIGRpdmlzb3IpIC8gTnVtYmVyKGRpdmlzb3IpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZsb29yRGl2KGE6IGJpZ2ludCwgYjogYmlnaW50KTogYmlnaW50IHsgaWYgKGIgPD0gMG4pIHRocm93IG5ldyBSYW5nZUVycm9yKCfpmaTmlbDjga/mraPmlbDjgafjgZnjgIInKTsgY29uc3QgcSA9IGEgLyBiLCByID0gYSAlIGI7IHJldHVybiByIDwgMG4gPyBxIC0gMW4gOiBxOyB9XG5mdW5jdGlvbiBtb2QoYTogYmlnaW50LCBiOiBiaWdpbnQpOiBiaWdpbnQgeyByZXR1cm4gYSAtIGZsb29yRGl2KGEsIGIpICogYjsgfVxuZXhwb3J0IGZ1bmN0aW9uIGlzTGVhcFllYXIoeWVhcjogYmlnaW50KTogYm9vbGVhbiB7IHJldHVybiBtb2QoeWVhciwgNG4pID09PSAwbiAmJiAobW9kKHllYXIsIDEwMG4pICE9PSAwbiB8fCBtb2QoeWVhciwgNDAwbikgPT09IDBuKTsgfVxuY29uc3QgTU9OVEhfREFZUyA9IFszMSwgMjgsIDMxLCAzMCwgMzEsIDMwLCAzMSwgMzEsIDMwLCAzMSwgMzAsIDMxXTtcbmZ1bmN0aW9uIGdyZWdvcmlhblllYXJTdGFydCh5ZWFyOiBiaWdpbnQpOiBiaWdpbnQge1xuICAvLyBBc3Ryb25vbWljYWwgeWVhciAwIGlzIGEgbGVhcCB5ZWFyOyBvcmlnaW4gaXMgMDAwMC0wMS0wMS5cbiAgcmV0dXJuIDM2NW4gKiB5ZWFyICsgZmxvb3JEaXYoeWVhciArIDNuLCA0bikgLSBmbG9vckRpdih5ZWFyICsgOTluLCAxMDBuKSArIGZsb29yRGl2KHllYXIgKyAzOTluLCA0MDBuKTtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ2FsZW5kYXJEYXRlIHsgeWVhcjogc3RyaW5nOyBtb250aDogbnVtYmVyOyBkYXk6IG51bWJlcjsgdGlja09mRGF5PzogVGljayB9XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVDYWxlbmRhcihpbnB1dDogdW5rbm93biwgcGF0aCA9ICdjYWxlbmRhcicpOiBWYWxpZGF0aW9uUmVzdWx0PENhbGVuZGFyRGVmaW5pdGlvbj4ge1xuICBjb25zdCBmYWlsID0gKG1lc3NhZ2U6IHN0cmluZywgZmllbGQgPSBwYXRoKTogVmFsaWRhdGlvblJlc3VsdDxDYWxlbmRhckRlZmluaXRpb24+ID0+ICh7IG9rOiBmYWxzZSwgaXNzdWVzOiBbeyBjb2RlOiAnVkFMSURBVElPTl9GQUlMRUQnLCBwYXRoOiBmaWVsZCwgbWVzc2FnZSB9XSB9KTtcbiAgaWYgKCFpbnB1dCB8fCB0eXBlb2YgaW5wdXQgIT09ICdvYmplY3QnIHx8IEFycmF5LmlzQXJyYXkoaW5wdXQpKSByZXR1cm4gZmFpbCgn5pqm44Gv44Kq44OW44K444Kn44Kv44OI44Gn44GZ44CCJyk7XG4gIGNvbnN0IGNhbCA9IGlucHV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCBhbGxvd2VkID0gY2FsLmtpbmQgPT09ICdyZXBlYXRpbmcnID8gWydpZCcsICduYW1lJywgJ2tpbmQnLCAnb3JpZ2luTGFiZWwnLCAndGlja3NQZXJEYXknLCAneWVhcnMnXSA6IFsnaWQnLCAnbmFtZScsICdraW5kJywgJ29yaWdpbkxhYmVsJywgJ3RpY2tzUGVyRGF5J107XG4gIGlmIChPYmplY3Qua2V5cyhjYWwpLnNvbWUoa2V5ID0+ICFhbGxvd2VkLmluY2x1ZGVzKGtleSkpKSByZXR1cm4gZmFpbCgn5pqm44Gr5pyq55+l44Gu6aCF55uu44GM44GC44KK44G+44GZ44CCJyk7XG4gIGlmICh0eXBlb2YgY2FsLmlkICE9PSAnc3RyaW5nJyB8fCAhY2FsLmlkIHx8IHR5cGVvZiBjYWwubmFtZSAhPT0gJ3N0cmluZycgfHwgIWNhbC5uYW1lIHx8IHR5cGVvZiBjYWwub3JpZ2luTGFiZWwgIT09ICdzdHJpbmcnKSByZXR1cm4gZmFpbCgn5pqm44GuSUTjg7vlkI3np7Djg7vljp/ngrnjg6njg5njg6vjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgaWYgKCFpc1RpY2soY2FsLnRpY2tzUGVyRGF5KSB8fCBwYXJzZVRpY2soY2FsLnRpY2tzUGVyRGF5KSA8PSAwbikgcmV0dXJuIGZhaWwoJzHml6Xjga50aWNr5pWw44Gv5q2j44Gu5pW05pWw44Gn44GZ44CCJywgYCR7cGF0aH0udGlja3NQZXJEYXlgKTtcbiAgaWYgKGNhbC5raW5kID09PSAnZ3JlZ29yaWFuJykge1xuICAgIGlmIChjYWwudGlja3NQZXJEYXkgIT09ICc4NjQwMCcpIHJldHVybiBmYWlsKCfmqJnmupbmmqbjga8x5pelODY0MDB0aWNr44Gn44GZ44CCJywgYCR7cGF0aH0udGlja3NQZXJEYXlgKTtcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IGlucHV0IGFzIENhbGVuZGFyRGVmaW5pdGlvbiB9O1xuICB9XG4gIGlmIChjYWwua2luZCAhPT0gJ3JlcGVhdGluZycgfHwgIUFycmF5LmlzQXJyYXkoY2FsLnllYXJzKSB8fCBjYWwueWVhcnMubGVuZ3RoIDwgMSB8fCBjYWwueWVhcnMubGVuZ3RoID4gNDAwKSByZXR1cm4gZmFpbCgn57mw6L+U44GX5pqm44GvMeOAnDQwMOW5tOOBruWRqOacn+OBjOW/heimgeOBp+OBmeOAgicpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGNhbC55ZWFycy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHllYXIgPSBjYWwueWVhcnNbaV07XG4gICAgaWYgKCF5ZWFyIHx8IHR5cGVvZiB5ZWFyICE9PSAnb2JqZWN0JyB8fCBPYmplY3Qua2V5cyh5ZWFyKS5zb21lKGtleSA9PiBrZXkgIT09ICdtb250aHMnKSB8fCAhQXJyYXkuaXNBcnJheSh5ZWFyLm1vbnRocykgfHwgeWVhci5tb250aHMubGVuZ3RoIDwgMSB8fCB5ZWFyLm1vbnRocy5sZW5ndGggPiAyNCkgcmV0dXJuIGZhaWwoJzHlubTjga7mnIjmlbDjga8x44CcMjTjgafjgZnjgIInLCBgJHtwYXRofS55ZWFyc1ske2l9XWApO1xuICAgIGZvciAobGV0IGogPSAwOyBqIDwgeWVhci5tb250aHMubGVuZ3RoOyBqKyspIHtcbiAgICAgIGNvbnN0IG1vbnRoID0geWVhci5tb250aHNbal07XG4gICAgICBpZiAoIW1vbnRoIHx8IHR5cGVvZiBtb250aCAhPT0gJ29iamVjdCcgfHwgT2JqZWN0LmtleXMobW9udGgpLnNvbWUoa2V5ID0+ICFbJ25hbWUnLCAnZGF5cyddLmluY2x1ZGVzKGtleSkpIHx8IHR5cGVvZiBtb250aC5uYW1lICE9PSAnc3RyaW5nJyB8fCAhbW9udGgubmFtZSB8fCAhTnVtYmVyLmlzSW50ZWdlcihtb250aC5kYXlzKSB8fCBtb250aC5kYXlzIDwgMSB8fCBtb250aC5kYXlzID4gNDAwKSByZXR1cm4gZmFpbCgn5pyI5ZCN44GoMeOAnDQwMOOBruaXpeaVsOOBjOW/heimgeOBp+OBmeOAgicsIGAke3BhdGh9LnllYXJzWyR7aX1dLm1vbnRoc1ske2p9XWApO1xuICAgIH1cbiAgfVxuICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IGlucHV0IGFzIENhbGVuZGFyRGVmaW5pdGlvbiB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNhbGVuZGFyRGF0ZVRvVGljayhkYXRlOiBDYWxlbmRhckRhdGUsIGNhbGVuZGFyOiBDYWxlbmRhckRlZmluaXRpb24gPSBHUkVHT1JJQU5fQ0FMRU5EQVIpOiBUaWNrIHtcbiAgY29uc3QgdmFsaWQgPSB2YWxpZGF0ZUNhbGVuZGFyKGNhbGVuZGFyKTsgaWYgKCF2YWxpZC5vaykgdGhyb3cgbmV3IFJhbmdlRXJyb3IodmFsaWQuaXNzdWVzWzBdLm1lc3NhZ2UpO1xuICBjb25zdCB5ZWFyID0gcGFyc2VUaWNrKGRhdGUueWVhciksIG1vbnRoSW5kZXggPSBkYXRlLm1vbnRoIC0gMTtcbiAgaWYgKCFOdW1iZXIuaXNJbnRlZ2VyKGRhdGUubW9udGgpIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKGRhdGUuZGF5KSkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ+aciOODu+aXpeOBr+aVtOaVsOOBp+OBmeOAgicpO1xuICBsZXQgZGF5czogYmlnaW50O1xuICBpZiAoY2FsZW5kYXIua2luZCA9PT0gJ2dyZWdvcmlhbicpIHtcbiAgICBjb25zdCBtb250aERheXMgPSBbLi4uTU9OVEhfREFZU107IGlmIChpc0xlYXBZZWFyKHllYXIpKSBtb250aERheXNbMV0gPSAyOTtcbiAgICBpZiAobW9udGhJbmRleCA8IDAgfHwgbW9udGhJbmRleCA+PSAxMiB8fCBkYXRlLmRheSA8IDEgfHwgZGF0ZS5kYXkgPiBtb250aERheXNbbW9udGhJbmRleF0pIHRocm93IG5ldyBSYW5nZUVycm9yKCfmmqbjgavlrZjlnKjjgZfjgarjgYTml6Xku5jjgafjgZnjgIInKTtcbiAgICBkYXlzID0gZ3JlZ29yaWFuWWVhclN0YXJ0KHllYXIpICsgQmlnSW50KG1vbnRoRGF5cy5zbGljZSgwLCBtb250aEluZGV4KS5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiLCAwKSArIGRhdGUuZGF5IC0gMSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgcGVyaW9kID0gQmlnSW50KGNhbGVuZGFyLnllYXJzLmxlbmd0aCksIHBvc2l0aW9uID0gTnVtYmVyKG1vZCh5ZWFyLCBwZXJpb2QpKTtcbiAgICBjb25zdCBsZW5ndGhzID0gY2FsZW5kYXIueWVhcnMubWFwKHkgPT4geS5tb250aHMucmVkdWNlKChzdW0sIG1vbnRoKSA9PiBzdW0gKyBtb250aC5kYXlzLCAwKSk7XG4gICAgY29uc3QgbW9udGhzID0gY2FsZW5kYXIueWVhcnNbcG9zaXRpb25dLm1vbnRocztcbiAgICBpZiAobW9udGhJbmRleCA8IDAgfHwgbW9udGhJbmRleCA+PSBtb250aHMubGVuZ3RoIHx8IGRhdGUuZGF5IDwgMSB8fCBkYXRlLmRheSA+IG1vbnRoc1ttb250aEluZGV4XS5kYXlzKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcign5pqm44Gr5a2Y5Zyo44GX44Gq44GE5pel5LuY44Gn44GZ44CCJyk7XG4gICAgZGF5cyA9IGZsb29yRGl2KHllYXIsIHBlcmlvZCkgKiBCaWdJbnQobGVuZ3Rocy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiLCAwKSkgKyBCaWdJbnQobGVuZ3Rocy5zbGljZSgwLCBwb3NpdGlvbikucmVkdWNlKChhLCBiKSA9PiBhICsgYiwgMCkpO1xuICAgIGRheXMgKz0gQmlnSW50KG1vbnRocy5zbGljZSgwLCBtb250aEluZGV4KS5yZWR1Y2UoKHN1bSwgbW9udGgpID0+IHN1bSArIG1vbnRoLmRheXMsIDApICsgZGF0ZS5kYXkgLSAxKTtcbiAgfVxuICBjb25zdCB3aXRoaW5EYXkgPSBwYXJzZVRpY2soZGF0ZS50aWNrT2ZEYXkgPz8gJzAnKSwgdGlja3NQZXJEYXkgPSBwYXJzZVRpY2soY2FsZW5kYXIudGlja3NQZXJEYXkpO1xuICBpZiAod2l0aGluRGF5IDwgMG4gfHwgd2l0aGluRGF5ID49IHRpY2tzUGVyRGF5KSB0aHJvdyBuZXcgUmFuZ2VFcnJvcign5pmC5Yi744GvMeaXpeOBrnRpY2vnr4Tlm7LlhoXjgafmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgcmV0dXJuIHRvVGljayhkYXlzICogdGlja3NQZXJEYXkgKyB3aXRoaW5EYXkpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHRpY2tUb0NhbGVuZGFyRGF0ZSh0aWNrOiBUaWNrLCBjYWxlbmRhcjogQ2FsZW5kYXJEZWZpbml0aW9uID0gR1JFR09SSUFOX0NBTEVOREFSKTogQ2FsZW5kYXJEYXRlIHtcbiAgY29uc3QgdmFsaWQgPSB2YWxpZGF0ZUNhbGVuZGFyKGNhbGVuZGFyKTsgaWYgKCF2YWxpZC5vaykgdGhyb3cgbmV3IFJhbmdlRXJyb3IodmFsaWQuaXNzdWVzWzBdLm1lc3NhZ2UpO1xuICBjb25zdCB2YWx1ZSA9IHBhcnNlVGljayh0aWNrKSwgdGlja3NQZXJEYXkgPSBwYXJzZVRpY2soY2FsZW5kYXIudGlja3NQZXJEYXkpLCBkYXlOdW1iZXIgPSBmbG9vckRpdih2YWx1ZSwgdGlja3NQZXJEYXkpO1xuICBsZXQgeWVhcjogYmlnaW50LCBkYXlPZlllYXI6IG51bWJlciwgbW9udGhzOiB7IGRheXM6IG51bWJlciB9W107XG4gIGlmIChjYWxlbmRhci5raW5kID09PSAnZ3JlZ29yaWFuJykge1xuICAgIGNvbnN0IGN5Y2xlID0gZmxvb3JEaXYoZGF5TnVtYmVyLCAxNDYwOTduKSwgY3ljbGVTdGFydCA9IGN5Y2xlICogNDAwbjtcbiAgICB5ZWFyID0gY3ljbGVTdGFydDsgY29uc3QgcmVtYWluZGVyID0gZGF5TnVtYmVyIC0gY3ljbGUgKiAxNDYwOTduO1xuICAgIC8vIEEgYm91bmRlZCBsb29wIChhdCBtb3N0IDQwMCksIGluZGVwZW5kZW50IG9mIHRoZSBzaXplIG9mIGEgd29ybGQgdGljay5cbiAgICB3aGlsZSAoeWVhciA8IGN5Y2xlU3RhcnQgKyAzOTluICYmIGdyZWdvcmlhblllYXJTdGFydCh5ZWFyICsgMW4pIC0gY3ljbGUgKiAxNDYwOTduIDw9IHJlbWFpbmRlcikgeWVhcisrO1xuICAgIGRheU9mWWVhciA9IE51bWJlcihkYXlOdW1iZXIgLSBncmVnb3JpYW5ZZWFyU3RhcnQoeWVhcikpO1xuICAgIG1vbnRocyA9IE1PTlRIX0RBWVMubWFwKChkYXlzLCBpbmRleCkgPT4gKHsgZGF5czogaW5kZXggPT09IDEgJiYgaXNMZWFwWWVhcih5ZWFyKSA/IDI5IDogZGF5cyB9KSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgbGVuZ3RocyA9IGNhbGVuZGFyLnllYXJzLm1hcCh5ID0+IHkubW9udGhzLnJlZHVjZSgoc3VtLCBtb250aCkgPT4gc3VtICsgbW9udGguZGF5cywgMCkpLCBjeWNsZURheXMgPSBCaWdJbnQobGVuZ3Rocy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiLCAwKSk7XG4gICAgY29uc3QgY3ljbGUgPSBmbG9vckRpdihkYXlOdW1iZXIsIGN5Y2xlRGF5cyk7IGxldCByZW1haW5kZXIgPSBOdW1iZXIobW9kKGRheU51bWJlciwgY3ljbGVEYXlzKSksIHBvc2l0aW9uID0gMDtcbiAgICB3aGlsZSAocG9zaXRpb24gPCBsZW5ndGhzLmxlbmd0aCAtIDEgJiYgcmVtYWluZGVyID49IGxlbmd0aHNbcG9zaXRpb25dKSByZW1haW5kZXIgLT0gbGVuZ3Roc1twb3NpdGlvbisrXTtcbiAgICB5ZWFyID0gY3ljbGUgKiBCaWdJbnQobGVuZ3Rocy5sZW5ndGgpICsgQmlnSW50KHBvc2l0aW9uKTsgZGF5T2ZZZWFyID0gcmVtYWluZGVyOyBtb250aHMgPSBjYWxlbmRhci55ZWFyc1twb3NpdGlvbl0ubW9udGhzO1xuICB9XG4gIGxldCBtb250aCA9IDA7IHdoaWxlIChtb250aCA8IG1vbnRocy5sZW5ndGggLSAxICYmIGRheU9mWWVhciA+PSBtb250aHNbbW9udGhdLmRheXMpIGRheU9mWWVhciAtPSBtb250aHNbbW9udGgrK10uZGF5cztcbiAgcmV0dXJuIHsgeWVhcjogeWVhci50b1N0cmluZygpLCBtb250aDogbW9udGggKyAxLCBkYXk6IGRheU9mWWVhciArIDEsIHRpY2tPZkRheTogbW9kKHZhbHVlLCB0aWNrc1BlckRheSkudG9TdHJpbmcoKSB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdENhbGVuZGFyVGljayh0aWNrOiBUaWNrLCBjYWxlbmRhcjogQ2FsZW5kYXJEZWZpbml0aW9uID0gR1JFR09SSUFOX0NBTEVOREFSKTogc3RyaW5nIHtcbiAgY29uc3QgZGF0ZSA9IHRpY2tUb0NhbGVuZGFyRGF0ZSh0aWNrLCBjYWxlbmRhcik7IHJldHVybiBgJHtkYXRlLnllYXJ95bm0JHtkYXRlLm1vbnRofeaciCR7ZGF0ZS5kYXl95pelJHtkYXRlLnRpY2tPZkRheSAhPT0gJzAnID8gYCArJHtkYXRlLnRpY2tPZkRheX0gdGlja2AgOiAnJ31gO1xufVxuZXhwb3J0IGludGVyZmFjZSBSZXNvbHZlZFRpbWUgeyBzdGF0dXM6ICdyZXNvbHZlZCc7IGVhcmxpZXN0OiBUaWNrOyBsYXRlc3Q6IFRpY2s7IGVuZEVhcmxpZXN0OiBUaWNrOyBlbmRMYXRlc3Q6IFRpY2s7IGNhbGVuZGFySWQ6IHN0cmluZzsgbW9kZTogVGltZVNwZWNbJ21vZGUnXSB9XG5leHBvcnQgdHlwZSBUaW1lUmVzb2x1dGlvbiA9IFJlc29sdmVkVGltZSB8IHsgc3RhdHVzOiAndW5rbm93bicgfCAnY29uZmxpY3QnOyByZWFzb246IHN0cmluZzsgcGF0aDogSURbXSB9O1xuZnVuY3Rpb24gYWJzb2x1dGVSZXNvbHV0aW9uKHRpbWU6IEV4Y2x1ZGU8VGltZVNwZWMsIHsgbW9kZTogJ3JlbGF0aXZlJyB9PiwgcGF0aDogSURbXSk6IFRpbWVSZXNvbHV0aW9uIHtcbiAgdHJ5IHtcbiAgICBpZiAodGltZS5tb2RlID09PSAndW5rbm93bicpIHJldHVybiB7IHN0YXR1czogJ3Vua25vd24nLCByZWFzb246IHRpbWUucmVhc29uIHx8ICfml6XmmYLjgYzmnKrlrprjgafjgZnjgIInLCBwYXRoIH07XG4gICAgaWYgKHRpbWUubW9kZSA9PT0gJ2luc3RhbnQnKSB7IHBhcnNlVGljayh0aW1lLmF0KTsgcmV0dXJuIHsgc3RhdHVzOiAncmVzb2x2ZWQnLCBlYXJsaWVzdDogdGltZS5hdCwgbGF0ZXN0OiB0aW1lLmF0LCBlbmRFYXJsaWVzdDogdGltZS5hdCwgZW5kTGF0ZXN0OiB0aW1lLmF0LCBjYWxlbmRhcklkOiB0aW1lLmNhbGVuZGFySWQsIG1vZGU6IHRpbWUubW9kZSB9OyB9XG4gICAgaWYgKHRpbWUubW9kZSA9PT0gJ2ludGVydmFsJykge1xuICAgICAgaWYgKGNvbXBhcmVUaWNrcyh0aW1lLnN0YXJ0LCB0aW1lLmVuZCkgPj0gMCkgcmV0dXJuIHsgc3RhdHVzOiAnY29uZmxpY3QnLCByZWFzb246ICfmnJ/plpPjga/plovlp4vjgojjgorlvozjgavntYLkuobjgZfjgabjgY/jgaDjgZXjgYTjgIInLCBwYXRoIH07XG4gICAgICByZXR1cm4geyBzdGF0dXM6ICdyZXNvbHZlZCcsIGVhcmxpZXN0OiB0aW1lLnN0YXJ0LCBsYXRlc3Q6IHRpbWUuc3RhcnQsIGVuZEVhcmxpZXN0OiB0aW1lLmVuZCwgZW5kTGF0ZXN0OiB0aW1lLmVuZCwgY2FsZW5kYXJJZDogdGltZS5jYWxlbmRhcklkLCBtb2RlOiB0aW1lLm1vZGUgfTtcbiAgICB9XG4gICAgaWYgKGNvbXBhcmVUaWNrcyh0aW1lLmVhcmxpZXN0LCB0aW1lLmxhdGVzdCkgPiAwKSByZXR1cm4geyBzdGF0dXM6ICdjb25mbGljdCcsIHJlYXNvbjogJ+amgueul+evhOWbsuOBjOmAhui7ouOBl+OBpuOBhOOBvuOBmeOAgicsIHBhdGggfTtcbiAgICByZXR1cm4geyBzdGF0dXM6ICdyZXNvbHZlZCcsIGVhcmxpZXN0OiB0aW1lLmVhcmxpZXN0LCBsYXRlc3Q6IHRpbWUubGF0ZXN0LCBlbmRFYXJsaWVzdDogdGltZS5lYXJsaWVzdCwgZW5kTGF0ZXN0OiB0aW1lLmxhdGVzdCwgY2FsZW5kYXJJZDogdGltZS5jYWxlbmRhcklkLCBtb2RlOiB0aW1lLm1vZGUgfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHsgcmV0dXJuIHsgc3RhdHVzOiAnY29uZmxpY3QnLCByZWFzb246IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ+aXpeaZguOCkuino+axuuOBp+OBjeOBvuOBm+OCk+OAgicsIHBhdGggfTsgfVxufVxuZnVuY3Rpb24gcmVsYXRpdmVWYWx1ZSh0aW1lOiBFeHRyYWN0PFRpbWVTcGVjLCB7IG1vZGU6ICdyZWxhdGl2ZScgfT4sIGFuY2hvcjogVGltZVJlc29sdXRpb24sIHBhdGg6ICgpID0+IElEW10sIHByZWZpeFVua25vd246IGJvb2xlYW4pOiBUaW1lUmVzb2x1dGlvbiB7XG4gIHRyeSB7XG4gICAgaWYgKGNvbXBhcmVUaWNrcyh0aW1lLm1pbk9mZnNldCwgdGltZS5tYXhPZmZzZXQpID4gMCkgcmV0dXJuIHsgc3RhdHVzOiAnY29uZmxpY3QnLCByZWFzb246ICfnm7jlr77ml6XmmYLjga7nr4Tlm7LjgYzpgIbou6LjgZfjgabjgYTjgb7jgZnjgIInLCBwYXRoOiBwYXRoKCkgfTtcbiAgICBpZiAoYW5jaG9yLnN0YXR1cyAhPT0gJ3Jlc29sdmVkJykgcmV0dXJuIHByZWZpeFVua25vd24gPyB7IC4uLmFuY2hvciwgcGF0aDogWy4uLnBhdGgoKSwgLi4uYW5jaG9yLnBhdGhdLnNsaWNlKDAsIDY0KSB9IDogYW5jaG9yO1xuICAgIGNvbnN0IGVhcmxpZXN0ID0gYWRkVGlja3ModGltZS5hbmNob3JQb2ludCA9PT0gJ3N0YXJ0JyA/IGFuY2hvci5lYXJsaWVzdCA6IGFuY2hvci5lbmRFYXJsaWVzdCwgdGltZS5taW5PZmZzZXQpLCBsYXRlc3QgPSBhZGRUaWNrcyh0aW1lLmFuY2hvclBvaW50ID09PSAnc3RhcnQnID8gYW5jaG9yLmxhdGVzdCA6IGFuY2hvci5lbmRMYXRlc3QsIHRpbWUubWF4T2Zmc2V0KTtcbiAgICByZXR1cm4geyBzdGF0dXM6ICdyZXNvbHZlZCcsIGVhcmxpZXN0LCBsYXRlc3QsIGVuZEVhcmxpZXN0OiBlYXJsaWVzdCwgZW5kTGF0ZXN0OiBsYXRlc3QsIGNhbGVuZGFySWQ6IGFuY2hvci5jYWxlbmRhcklkLCBtb2RlOiAncmVsYXRpdmUnIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7IHJldHVybiB7IHN0YXR1czogJ2NvbmZsaWN0JywgcmVhc29uOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICfml6XmmYLjgpLop6PmsbrjgafjgY3jgb7jgZvjgpPjgIInLCBwYXRoOiBwYXRoKCkgfTsgfVxufVxuLyoqIE9uZSByZWxhdGl2ZS10aW1lIGV2YWx1YXRvciBzaGFyZWQgYnkgdmFsaWRhdGlvbiwgcHJldmlld3MgYW5kIGNoYXJhY3RlciBsaWZldGltZXMuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZVJlbGF0aXZlVGltZSh0aW1lOiBFeHRyYWN0PFRpbWVTcGVjLCB7IG1vZGU6ICdyZWxhdGl2ZScgfT4sIGFuY2hvcjogVGltZVJlc29sdXRpb24sIHBhdGg6IElEW10gPSBbXSk6IFRpbWVSZXNvbHV0aW9uIHtcbiAgcmV0dXJuIHJlbGF0aXZlVmFsdWUodGltZSwgYW5jaG9yLCAoKSA9PiBwYXRoLCB0cnVlKTtcbn1cbmZ1bmN0aW9uIGV2ZW50SW5kZXgoZXZlbnRzOiBFbnRpdHk8J2V2ZW50Jz5bXSk6IE1hcDxJRCwgRW50aXR5PCdldmVudCc+PiB7IGNvbnN0IGluZGV4ID0gbmV3IE1hcDxJRCwgRW50aXR5PCdldmVudCc+PigpOyBmb3IgKGNvbnN0IGV2ZW50IG9mIGV2ZW50cykgaWYgKCFldmVudC5kZWxldGVkQXQgJiYgIWluZGV4LmhhcyhldmVudC5pZCkpIGluZGV4LnNldChldmVudC5pZCwgZXZlbnQpOyByZXR1cm4gaW5kZXg7IH1cbi8qKiBQdWJsaWMgYXJiaXRyYXJ5LVRpbWVTcGVjIHdyYXBwZXIuIFRoZSBzdXBwbGllZCBjaGFpbiByZW1haW5zIGEgc2V0IG9mIGZvcmJpZGRlbiBhbmNlc3RvciBJRHMuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZVRpbWUodGltZTogVGltZVNwZWMsIGV2ZW50czogRW50aXR5PCdldmVudCc+W10gPSBbXSwgY2hhaW46IElEW10gPSBbXSk6IFRpbWVSZXNvbHV0aW9uIHtcbiAgaWYgKHRpbWUubW9kZSAhPT0gJ3JlbGF0aXZlJykgcmV0dXJuIGFic29sdXRlUmVzb2x1dGlvbih0aW1lLCBjaGFpbik7XG4gIGNvbnN0IGluZGV4ID0gZXZlbnRJbmRleChldmVudHMpLCBwYXRoID0gWy4uLmNoYWluXSwgdmlzaXRlZCA9IG5ldyBTZXQoY2hhaW4pLCBmcmFtZXM6IHsgdGltZTogRXh0cmFjdDxUaW1lU3BlYywgeyBtb2RlOiAncmVsYXRpdmUnIH0+OyBwYXRoTGVuZ3RoOiBudW1iZXIgfVtdID0gW107XG4gIGxldCBjdXJzb3I6IFRpbWVTcGVjID0gdGltZTtcbiAgd2hpbGUgKGN1cnNvci5tb2RlID09PSAncmVsYXRpdmUnKSB7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKGN1cnNvci5hbmNob3JFdmVudElkKSkgcmV0dXJuIHsgc3RhdHVzOiAnY29uZmxpY3QnLCByZWFzb246ICfnm7jlr77ml6XmmYLjga7lj4LnhafjgYzlvqrnkrDjgZfjgabjgYTjgb7jgZnjgIInLCBwYXRoOiBbLi4ucGF0aCwgY3Vyc29yLmFuY2hvckV2ZW50SWRdIH07XG4gICAgdHJ5IHsgaWYgKGNvbXBhcmVUaWNrcyhjdXJzb3IubWluT2Zmc2V0LCBjdXJzb3IubWF4T2Zmc2V0KSA+IDApIHJldHVybiB7IHN0YXR1czogJ2NvbmZsaWN0JywgcmVhc29uOiAn55u45a++5pel5pmC44Gu56+E5Zuy44GM6YCG6Lui44GX44Gm44GE44G+44GZ44CCJywgcGF0aDogWy4uLnBhdGhdIH07IH0gY2F0Y2ggKGVycm9yKSB7IHJldHVybiB7IHN0YXR1czogJ2NvbmZsaWN0JywgcmVhc29uOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICfml6XmmYLjgpLop6PmsbrjgafjgY3jgb7jgZvjgpPjgIInLCBwYXRoOiBbLi4ucGF0aF0gfTsgfVxuICAgIGNvbnN0IGFuY2hvciA9IGluZGV4LmdldChjdXJzb3IuYW5jaG9yRXZlbnRJZCk7IGlmICghYW5jaG9yKSByZXR1cm4geyBzdGF0dXM6ICd1bmtub3duJywgcmVhc29uOiAn5Z+65rqW44Go44Gq44KL5Ye65p2l5LqL44GM44GC44KK44G+44Gb44KT44CCJywgcGF0aDogWy4uLnBhdGgsIGN1cnNvci5hbmNob3JFdmVudElkXSB9O1xuICAgIGZyYW1lcy5wdXNoKHsgdGltZTogY3Vyc29yLCBwYXRoTGVuZ3RoOiBwYXRoLmxlbmd0aCB9KTsgdmlzaXRlZC5hZGQoYW5jaG9yLmlkKTsgcGF0aC5wdXNoKGFuY2hvci5pZCk7IGN1cnNvciA9IGFuY2hvci5kYXRhLnRpbWU7XG4gIH1cbiAgbGV0IHJlc29sdmVkID0gYWJzb2x1dGVSZXNvbHV0aW9uKGN1cnNvciwgcGF0aCk7XG4gIGZvciAobGV0IGkgPSBmcmFtZXMubGVuZ3RoIC0gMTsgaSA+PSAwICYmIHJlc29sdmVkLnN0YXR1cyA9PT0gJ3Jlc29sdmVkJzsgaS0tKSB7IGNvbnN0IGZyYW1lID0gZnJhbWVzW2ldOyByZXNvbHZlZCA9IHJlbGF0aXZlVmFsdWUoZnJhbWUudGltZSwgcmVzb2x2ZWQsICgpID0+IHBhdGguc2xpY2UoMCwgZnJhbWUucGF0aExlbmd0aCksIGZhbHNlKTsgfVxuICByZXR1cm4gcmVzb2x2ZWQ7XG59XG4vKiogSW5kZXhlZCBhbmQgaXRlcmF0aXZlIE8oZXZlbnRzICsgYW5jaG9ycykuIERpYWdub3N0aWMgcGF0aHMgYXJlIGJvdW5kZWQgZm9yIGN5Y2xpYyBpbXBvcnRlZCBncmFwaHMuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUV2ZW50VGltZXMoZXZlbnRzOiBFbnRpdHk8J2V2ZW50Jz5bXSk6IE1hcDxJRCwgVGltZVJlc29sdXRpb24+IHtcbiAgY29uc3QgaW5kZXggPSBldmVudEluZGV4KGV2ZW50cyksIHJlc29sdmVkID0gbmV3IE1hcDxJRCwgVGltZVJlc29sdXRpb24+KCk7XG4gIGZvciAoY29uc3QgZXZlbnQgb2YgaW5kZXgudmFsdWVzKCkpIHtcbiAgICBpZiAocmVzb2x2ZWQuaGFzKGV2ZW50LmlkKSkgY29udGludWU7XG4gICAgY29uc3QgcGF0aDogSURbXSA9IFtdLCB2aXNpdGluZyA9IG5ldyBNYXA8SUQsIG51bWJlcj4oKTsgbGV0IGN1cnNvciA9IGV2ZW50LmlkO1xuICAgIHdoaWxlICghcmVzb2x2ZWQuaGFzKGN1cnNvcikpIHtcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBpbmRleC5nZXQoY3Vyc29yKTsgaWYgKCFjdXJyZW50KSB7IHJlc29sdmVkLnNldChjdXJzb3IsIHsgc3RhdHVzOiAndW5rbm93bicsIHJlYXNvbjogJ+Wfuua6luOBqOOBquOCi+WHuuadpeS6i+OBjOOBguOCiuOBvuOBm+OCk+OAgicsIHBhdGg6IFtjdXJzb3JdIH0pOyBicmVhazsgfVxuICAgICAgY29uc3QgY3ljbGVTdGFydCA9IHZpc2l0aW5nLmdldChjdXJzb3IpO1xuICAgICAgaWYgKGN5Y2xlU3RhcnQgIT09IHVuZGVmaW5lZCkgeyBjb25zdCBjeWNsZSA9IHBhdGguc2xpY2UoY3ljbGVTdGFydCk7IGZvciAobGV0IGkgPSAwOyBpIDwgY3ljbGUubGVuZ3RoOyBpKyspIHJlc29sdmVkLnNldChjeWNsZVtpXSwgeyBzdGF0dXM6ICdjb25mbGljdCcsIHJlYXNvbjogJ+ebuOWvvuaXpeaZguOBruWPgueFp+OBjOW+queSsOOBl+OBpuOBhOOBvuOBmeOAgicsIHBhdGg6IEFycmF5LmZyb20oeyBsZW5ndGg6IE1hdGgubWluKGN5Y2xlLmxlbmd0aCArIDEsIDY0KSB9LCAoXywgb2Zmc2V0KSA9PiBjeWNsZVsoaSArIG9mZnNldCkgJSBjeWNsZS5sZW5ndGhdKSB9KTsgYnJlYWs7IH1cbiAgICAgIGlmIChjdXJyZW50LmRhdGEudGltZS5tb2RlICE9PSAncmVsYXRpdmUnKSB7IHJlc29sdmVkLnNldChjdXJzb3IsIGFic29sdXRlUmVzb2x1dGlvbihjdXJyZW50LmRhdGEudGltZSwgW2N1cnNvcl0pKTsgYnJlYWs7IH1cbiAgICAgIGNvbnN0IHJlbGF0aXZlID0gY3VycmVudC5kYXRhLnRpbWU7XG4gICAgICAvLyBDeWNsZXMgdGFrZSBwcmVjZWRlbmNlIHdoZW4gYW4gYW5jaG9yIGFscmVhZHkgYXBwZWFycyBpbiB0aGlzIHBhdGgsIG1hdGNoaW5nIHJlc29sdmVUaW1lLlxuICAgICAgaWYgKCF2aXNpdGluZy5oYXMocmVsYXRpdmUuYW5jaG9yRXZlbnRJZCkgJiYgcmVsYXRpdmUuYW5jaG9yRXZlbnRJZCAhPT0gY3Vyc29yKSB0cnkgeyBpZiAoY29tcGFyZVRpY2tzKHJlbGF0aXZlLm1pbk9mZnNldCwgcmVsYXRpdmUubWF4T2Zmc2V0KSA+IDApIHsgcmVzb2x2ZWQuc2V0KGN1cnNvciwgeyBzdGF0dXM6ICdjb25mbGljdCcsIHJlYXNvbjogJ+ebuOWvvuaXpeaZguOBruevhOWbsuOBjOmAhui7ouOBl+OBpuOBhOOBvuOBmeOAgicsIHBhdGg6IFtjdXJzb3JdIH0pOyBicmVhazsgfSB9IGNhdGNoIChlcnJvcikgeyByZXNvbHZlZC5zZXQoY3Vyc29yLCB7IHN0YXR1czogJ2NvbmZsaWN0JywgcmVhc29uOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICfml6XmmYLjgpLop6PmsbrjgafjgY3jgb7jgZvjgpPjgIInLCBwYXRoOiBbY3Vyc29yXSB9KTsgYnJlYWs7IH1cbiAgICAgIHZpc2l0aW5nLnNldChjdXJzb3IsIHBhdGgubGVuZ3RoKTsgcGF0aC5wdXNoKGN1cnNvcik7IGN1cnNvciA9IHJlbGF0aXZlLmFuY2hvckV2ZW50SWQ7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBwYXRoLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7IGNvbnN0IGlkID0gcGF0aFtpXSwgY3VycmVudCA9IGluZGV4LmdldChpZCkhOyBpZiAoIXJlc29sdmVkLmhhcyhpZCkgJiYgY3VycmVudC5kYXRhLnRpbWUubW9kZSA9PT0gJ3JlbGF0aXZlJykgcmVzb2x2ZWQuc2V0KGlkLCByZXNvbHZlUmVsYXRpdmVUaW1lKGN1cnJlbnQuZGF0YS50aW1lLCByZXNvbHZlZC5nZXQoY3VycmVudC5kYXRhLnRpbWUuYW5jaG9yRXZlbnRJZCkhLCBbaWRdKSk7IH1cbiAgfVxuICByZXR1cm4gcmVzb2x2ZWQ7XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVFdmVudFRpbWVzKGV2ZW50czogRW50aXR5PCdldmVudCc+W10pOiBWYWxpZGF0aW9uSXNzdWVbXSB7XG4gIGNvbnN0IGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10gPSBbXSwgaW5kZXggPSBldmVudEluZGV4KGV2ZW50cyksIHRpbWVzID0gcmVzb2x2ZUV2ZW50VGltZXMoZXZlbnRzKTtcbiAgZm9yIChjb25zdCBldmVudCBvZiBpbmRleC52YWx1ZXMoKSkge1xuICAgIGNvbnN0IHRpbWUgPSB0aW1lcy5nZXQoZXZlbnQuaWQpITtcbiAgICBpZiAodGltZS5zdGF0dXMgPT09ICdjb25mbGljdCcpIGlzc3Vlcy5wdXNoKHsgY29kZTogJ1RJTUVfQ09OU1RSQUlOVF9DT05GTElDVCcsIHBhdGg6IGBlbnRpdGllcy4ke2V2ZW50LmlkfS5kYXRhLnRpbWVgLCBtZXNzYWdlOiB0aW1lLnJlYXNvbiB9KTtcbiAgICBmb3IgKGNvbnN0IGNvbnN0cmFpbnQgb2YgZXZlbnQuZGF0YS5jb25zdHJhaW50cyA/PyBbXSkge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gaW5kZXguZ2V0KGNvbnN0cmFpbnQudGFyZ2V0RXZlbnRJZCk7IGlmICghdGFyZ2V0IHx8IHRpbWUuc3RhdHVzICE9PSAncmVzb2x2ZWQnKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IG90aGVyID0gdGltZXMuZ2V0KHRhcmdldC5pZCkhOyBpZiAob3RoZXIuc3RhdHVzICE9PSAncmVzb2x2ZWQnKSBjb250aW51ZTtcbiAgICAgIGxldCBjb25mbGljdCA9IHRpbWUuY2FsZW5kYXJJZCAhPT0gb3RoZXIuY2FsZW5kYXJJZDtcbiAgICAgIGlmIChjb25zdHJhaW50LnR5cGUgPT09ICdiZWZvcmUnKSBjb25mbGljdCB8fD0gdGltZS5tb2RlID09PSAnaW50ZXJ2YWwnID8gY29tcGFyZVRpY2tzKHRpbWUuZW5kRWFybGllc3QsIG90aGVyLmxhdGVzdCkgPiAwIDogY29tcGFyZVRpY2tzKHRpbWUuZW5kRWFybGllc3QsIG90aGVyLmxhdGVzdCkgPj0gMDtcbiAgICAgIGVsc2UgaWYgKGNvbnN0cmFpbnQudHlwZSA9PT0gJ3NhbWVfc3RhcnQnKSBjb25mbGljdCB8fD0gY29tcGFyZVRpY2tzKHRpbWUuZWFybGllc3QsIG90aGVyLmxhdGVzdCkgPiAwIHx8IGNvbXBhcmVUaWNrcyhvdGhlci5lYXJsaWVzdCwgdGltZS5sYXRlc3QpID4gMDtcbiAgICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBtaW5HYXAgPSBwYXJzZVRpY2sob3RoZXIuZWFybGllc3QpIC0gcGFyc2VUaWNrKHRpbWUuZW5kTGF0ZXN0KSwgbWF4R2FwID0gcGFyc2VUaWNrKG90aGVyLmxhdGVzdCkgLSBwYXJzZVRpY2sodGltZS5lbmRFYXJsaWVzdCk7XG4gICAgICAgIGNvbmZsaWN0IHx8PSBtYXhHYXAgPCBwYXJzZVRpY2soY29uc3RyYWludC5taW5pbXVtVGlja3MpIHx8IG1pbkdhcCA+IHBhcnNlVGljayhjb25zdHJhaW50Lm1heGltdW1UaWNrcyk7XG4gICAgICB9XG4gICAgICBpZiAoY29uZmxpY3QpIGlzc3Vlcy5wdXNoKHsgY29kZTogJ1RJTUVfQ09OU1RSQUlOVF9DT05GTElDVCcsIHBhdGg6IGBlbnRpdGllcy4ke2V2ZW50LmlkfS5kYXRhLmNvbnN0cmFpbnRzYCwgbWVzc2FnZTogJ+aMh+WumuOBl+OBn+WHuuadpeS6i+OBruaXpeaZguWItue0hOOBqOefm+ebvuOBl+OBpuOBhOOBvuOBmeOAgicgfSk7XG4gICAgfVxuICB9XG4gIC8vIEN5Y2xpYyBkZXBlbmRlbmN5IGNvbnN0cmFpbnRzIGNhbm5vdCBiZSBhcHBsaWVkIGV2ZW4gd2hpbGUgdGhlaXIgZGF0ZXMgYXJlIHVua25vd24uXG4gIGNvbnN0IGNvbG9ycyA9IG5ldyBNYXA8SUQsIG51bWJlcj4oKSwgZGVwZW5kZW5jaWVzID0gbmV3IE1hcDxJRCwgSURbXT4oKTtcbiAgZm9yIChjb25zdCBldmVudCBvZiBpbmRleC52YWx1ZXMoKSkgeyBkZXBlbmRlbmNpZXMuc2V0KGV2ZW50LmlkLCAoZXZlbnQuZGF0YS5jb25zdHJhaW50cyA/PyBbXSkubWFwKGNvbnN0cmFpbnQgPT4gY29uc3RyYWludC50YXJnZXRFdmVudElkKSk7IH1cbiAgZm9yIChjb25zdCBldmVudCBvZiBpbmRleC52YWx1ZXMoKSkgaWYgKGV2ZW50LmRhdGEudGltZS5tb2RlID09PSAncmVsYXRpdmUnICYmIGluZGV4LmhhcyhldmVudC5kYXRhLnRpbWUuYW5jaG9yRXZlbnRJZCkpIGRlcGVuZGVuY2llcy5nZXQoZXZlbnQuZGF0YS50aW1lLmFuY2hvckV2ZW50SWQpIS5wdXNoKGV2ZW50LmlkKTtcbiAgZm9yIChjb25zdCBldmVudCBvZiBpbmRleC52YWx1ZXMoKSkge1xuICAgIGlmIChjb2xvcnMuZ2V0KGV2ZW50LmlkKSkgY29udGludWU7XG4gICAgY29uc3Qgc3RhY2s6IHsgaWQ6IElEOyB0YXJnZXRzOiBJRFtdOyBjdXJzb3I6IG51bWJlciB9W10gPSBbeyBpZDogZXZlbnQuaWQsIHRhcmdldHM6IGRlcGVuZGVuY2llcy5nZXQoZXZlbnQuaWQpISwgY3Vyc29yOiAwIH1dOyBjb2xvcnMuc2V0KGV2ZW50LmlkLCAxKTtcbiAgICB3aGlsZSAoc3RhY2subGVuZ3RoKSB7XG4gICAgICBjb25zdCBjdXJyZW50ID0gc3RhY2tbc3RhY2subGVuZ3RoIC0gMV07IGlmIChjdXJyZW50LmN1cnNvciA9PT0gY3VycmVudC50YXJnZXRzLmxlbmd0aCkgeyBjb2xvcnMuc2V0KGN1cnJlbnQuaWQsIDIpOyBzdGFjay5wb3AoKTsgY29udGludWU7IH1cbiAgICAgIGNvbnN0IHRhcmdldElkID0gY3VycmVudC50YXJnZXRzW2N1cnJlbnQuY3Vyc29yKytdLCB0YXJnZXQgPSBpbmRleC5nZXQodGFyZ2V0SWQpOyBpZiAoIXRhcmdldCkgY29udGludWU7XG4gICAgICBpZiAoY29sb3JzLmdldCh0YXJnZXRJZCkgPT09IDEpIGlzc3Vlcy5wdXNoKHsgY29kZTogJ1RJTUVfQ09OU1RSQUlOVF9DT05GTElDVCcsIHBhdGg6IGBlbnRpdGllcy4ke2N1cnJlbnQuaWR9LmRhdGEuY29uc3RyYWludHNgLCBtZXNzYWdlOiAn5pel5pmC5Yi257SE44Gu5L6d5a2Y44GM5b6q55Kw44GX44Gm44GE44G+44GZ44CCJyB9KTtcbiAgICAgIGVsc2UgaWYgKCFjb2xvcnMuaGFzKHRhcmdldElkKSkgeyBjb2xvcnMuc2V0KHRhcmdldElkLCAxKTsgc3RhY2sucHVzaCh7IGlkOiB0YXJnZXRJZCwgdGFyZ2V0czogZGVwZW5kZW5jaWVzLmdldCh0YXJnZXQuaWQpISwgY3Vyc29yOiAwIH0pOyB9XG4gICAgfVxuICB9XG4gIHJldHVybiBpc3N1ZXM7XG59XG5cbi8qKiBTaGFyZWQgSURzIGFyZSBzYWZlIG9ubHkgd2hlbiB0aGUgY29tcGxldGUgY2FsZW5kYXIgZGVmaW5pdGlvbiBpcyB1bmNoYW5nZWQuICovXG5leHBvcnQgZnVuY3Rpb24gc2FtZUNhbGVuZGFyRGVmaW5pdGlvbihsZWZ0OiBDYWxlbmRhckRlZmluaXRpb24sIHJpZ2h0OiBDYWxlbmRhckRlZmluaXRpb24pOiBib29sZWFuIHtcbiAgaWYgKGxlZnQuaWQgIT09IHJpZ2h0LmlkIHx8IGxlZnQua2luZCAhPT0gcmlnaHQua2luZCB8fCBsZWZ0Lm5hbWUgIT09IHJpZ2h0Lm5hbWUgfHwgbGVmdC5vcmlnaW5MYWJlbCAhPT0gcmlnaHQub3JpZ2luTGFiZWwgfHwgbGVmdC50aWNrc1BlckRheSAhPT0gcmlnaHQudGlja3NQZXJEYXkpIHJldHVybiBmYWxzZTtcbiAgaWYgKGxlZnQua2luZCA9PT0gJ2dyZWdvcmlhbicgfHwgcmlnaHQua2luZCA9PT0gJ2dyZWdvcmlhbicpIHJldHVybiBsZWZ0LmtpbmQgPT09IHJpZ2h0LmtpbmQ7XG4gIHJldHVybiBsZWZ0LnllYXJzLmxlbmd0aCA9PT0gcmlnaHQueWVhcnMubGVuZ3RoICYmIGxlZnQueWVhcnMuZXZlcnkoKHllYXIsIGkpID0+IHllYXIubW9udGhzLmxlbmd0aCA9PT0gcmlnaHQueWVhcnNbaV0ubW9udGhzLmxlbmd0aCAmJiB5ZWFyLm1vbnRocy5ldmVyeSgobW9udGgsIGopID0+IG1vbnRoLm5hbWUgPT09IHJpZ2h0LnllYXJzW2ldLm1vbnRoc1tqXS5uYW1lICYmIG1vbnRoLmRheXMgPT09IHJpZ2h0LnllYXJzW2ldLm1vbnRoc1tqXS5kYXlzKSk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUVBLE9BQU8sTUFBTUEsWUFBWSxHQUFHLDRDQUE0QztBQUN4RSxPQUFPLE1BQU1DLFFBQVEsR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLEVBQUU7QUFDdkMsT0FBTyxNQUFNQyxrQkFBc0MsR0FBRztFQUFFQyxFQUFFLEVBQUUsNEJBQTRCO0VBQUVDLElBQUksRUFBRSxVQUFVO0VBQUVDLElBQUksRUFBRSxXQUFXO0VBQUVDLFdBQVcsRUFBRSxxQkFBcUI7RUFBRUMsV0FBVyxFQUFFO0FBQVEsQ0FBQztBQUN6TCxPQUFPLFNBQVNDLE1BQU1BLENBQUNDLEtBQWMsRUFBaUI7RUFBRSxPQUFPLE9BQU9BLEtBQUssS0FBSyxRQUFRLElBQUlULFlBQVksQ0FBQ1UsSUFBSSxDQUFDRCxLQUFLLENBQUM7QUFBRTtBQUN0SCxPQUFPLFNBQVNFLFNBQVNBLENBQUNGLEtBQVcsRUFBVTtFQUFFLElBQUksQ0FBQ0QsTUFBTSxDQUFDQyxLQUFLLENBQUMsRUFBRSxNQUFNLElBQUlHLFVBQVUsQ0FBQyw4QkFBOEIsQ0FBQztFQUFFLE9BQU9DLE1BQU0sQ0FBQ0osS0FBSyxDQUFDO0FBQUU7QUFDakosT0FBTyxTQUFTSyxNQUFNQSxDQUFDTCxLQUFhLEVBQVE7RUFBRSxJQUFJQSxLQUFLLEdBQUcsQ0FBQ1IsUUFBUSxJQUFJUSxLQUFLLEdBQUdSLFFBQVEsRUFBRSxNQUFNLElBQUlXLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQztFQUFFLE9BQU9ILEtBQUssQ0FBQ00sUUFBUSxDQUFDLENBQUM7QUFBRTtBQUMvSixPQUFPLFNBQVNDLFFBQVFBLENBQUNDLENBQU8sRUFBRUMsQ0FBTyxFQUFRO0VBQUUsT0FBT0osTUFBTSxDQUFDSCxTQUFTLENBQUNNLENBQUMsQ0FBQyxHQUFHTixTQUFTLENBQUNPLENBQUMsQ0FBQyxDQUFDO0FBQUU7QUFDL0YsT0FBTyxTQUFTQyxhQUFhQSxDQUFDRixDQUFPLEVBQUVDLENBQU8sRUFBUTtFQUFFLE9BQU9KLE1BQU0sQ0FBQ0gsU0FBUyxDQUFDTSxDQUFDLENBQUMsR0FBR04sU0FBUyxDQUFDTyxDQUFDLENBQUMsQ0FBQztBQUFFO0FBQ3BHLE9BQU8sU0FBU0UsWUFBWUEsQ0FBQ0gsQ0FBTyxFQUFFQyxDQUFPLEVBQWM7RUFBRSxNQUFNRyxDQUFDLEdBQUdWLFNBQVMsQ0FBQ00sQ0FBQyxDQUFDO0lBQUVLLENBQUMsR0FBR1gsU0FBUyxDQUFDTyxDQUFDLENBQUM7RUFBRSxPQUFPRyxDQUFDLEdBQUdDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBR0QsQ0FBQyxHQUFHQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFBRTtBQUMxSSxPQUFPLFNBQVNDLGtCQUFrQkEsQ0FBQ0MsRUFBUSxFQUFFQyxTQUFlLEVBQUVDLElBQVUsR0FBRyxHQUFHLEVBQVU7RUFDdEYsTUFBTUMsS0FBSyxHQUFHaEIsU0FBUyxDQUFDYSxFQUFFLENBQUMsR0FBR2IsU0FBUyxDQUFDYyxTQUFTLENBQUM7SUFBRUcsT0FBTyxHQUFHakIsU0FBUyxDQUFDZSxJQUFJLENBQUM7RUFDN0UsSUFBSUUsT0FBTyxJQUFJLEVBQUUsRUFBRSxNQUFNLElBQUloQixVQUFVLENBQUMsY0FBYyxDQUFDO0VBQ3ZELE1BQU1pQixRQUFRLEdBQUdGLEtBQUssR0FBRyxFQUFFO0lBQUVHLEdBQUcsR0FBR0QsUUFBUSxHQUFHLENBQUNGLEtBQUssR0FBR0EsS0FBSztJQUFFSSxRQUFRLEdBQUdELEdBQUcsR0FBR0YsT0FBTztJQUFFSSxTQUFTLEdBQUdGLEdBQUcsR0FBR0YsT0FBTztFQUNqSCxPQUFPLEdBQUdDLFFBQVEsR0FBRyxHQUFHLEdBQUdGLEtBQUssR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBR0ksUUFBUSxHQUFHQyxTQUFTLEdBQUcsTUFBTUEsU0FBUyxJQUFJSixPQUFPLEVBQUUsR0FBRyxFQUFFLEVBQUU7QUFDL0c7QUFDQSxPQUFPLFNBQVNLLFlBQVlBLENBQUNULEVBQVEsRUFBRVUsTUFBWSxFQUFFQyxhQUFtQixFQUFFQyxTQUFTLEdBQUcsT0FBUyxFQUFVO0VBQ3ZHLE1BQU1SLE9BQU8sR0FBR2pCLFNBQVMsQ0FBQ3dCLGFBQWEsQ0FBQztFQUN4QyxJQUFJUCxPQUFPLElBQUksRUFBRSxJQUFJLENBQUNTLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDRixTQUFTLENBQUMsSUFBSUEsU0FBUyxJQUFJLENBQUMsRUFBRSxNQUFNLElBQUl4QixVQUFVLENBQUMsWUFBWSxDQUFDO0VBQzNHLE1BQU1lLEtBQUssR0FBR2hCLFNBQVMsQ0FBQ2EsRUFBRSxDQUFDLEdBQUdiLFNBQVMsQ0FBQ3VCLE1BQU0sQ0FBQztJQUFFSCxRQUFRLEdBQUdKLEtBQUssR0FBR0MsT0FBTztFQUMzRSxJQUFJRyxRQUFRLEdBQUdsQixNQUFNLENBQUN1QixTQUFTLENBQUMsRUFBRSxPQUFPQSxTQUFTO0VBQ2xELElBQUlMLFFBQVEsR0FBRyxDQUFDbEIsTUFBTSxDQUFDdUIsU0FBUyxDQUFDLEVBQUUsT0FBTyxDQUFDQSxTQUFTO0VBQ3BEO0VBQ0EsT0FBT0MsTUFBTSxDQUFDTixRQUFRLENBQUMsR0FBR00sTUFBTSxDQUFDVixLQUFLLEdBQUdDLE9BQU8sQ0FBQyxHQUFHUyxNQUFNLENBQUNULE9BQU8sQ0FBQztBQUNyRTtBQUNBLE9BQU8sU0FBU1csUUFBUUEsQ0FBQ3RCLENBQVMsRUFBRUMsQ0FBUyxFQUFVO0VBQUUsSUFBSUEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLElBQUlOLFVBQVUsQ0FBQyxVQUFVLENBQUM7RUFBRSxNQUFNNEIsQ0FBQyxHQUFHdkIsQ0FBQyxHQUFHQyxDQUFDO0lBQUV1QixDQUFDLEdBQUd4QixDQUFDLEdBQUdDLENBQUM7RUFBRSxPQUFPdUIsQ0FBQyxHQUFHLEVBQUUsR0FBR0QsQ0FBQyxHQUFHLEVBQUUsR0FBR0EsQ0FBQztBQUFFO0FBQ2hLLFNBQVNFLEdBQUdBLENBQUN6QixDQUFTLEVBQUVDLENBQVMsRUFBVTtFQUFFLE9BQU9ELENBQUMsR0FBR3NCLFFBQVEsQ0FBQ3RCLENBQUMsRUFBRUMsQ0FBQyxDQUFDLEdBQUdBLENBQUM7QUFBRTtBQUM1RSxPQUFPLFNBQVN5QixVQUFVQSxDQUFDQyxJQUFZLEVBQVc7RUFBRSxPQUFPRixHQUFHLENBQUNFLElBQUksRUFBRSxFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUtGLEdBQUcsQ0FBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSUYsR0FBRyxDQUFDRSxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQUU7QUFDdkksTUFBTUMsVUFBVSxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7QUFDbkUsU0FBU0Msa0JBQWtCQSxDQUFDRixJQUFZLEVBQVU7RUFDaEQ7RUFDQSxPQUFPLElBQUksR0FBR0EsSUFBSSxHQUFHTCxRQUFRLENBQUNLLElBQUksR0FBRyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUdMLFFBQVEsQ0FBQ0ssSUFBSSxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBR0wsUUFBUSxDQUFDSyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksQ0FBQztBQUN6RztBQUVBLE9BQU8sU0FBU0csZ0JBQWdCQSxDQUFDQyxLQUFjLEVBQUVDLElBQUksR0FBRyxVQUFVLEVBQXdDO0VBQ3hHLE1BQU1DLElBQUksR0FBR0EsQ0FBQ0MsT0FBZSxFQUFFQyxLQUFLLEdBQUdILElBQUksTUFBNEM7SUFBRUksRUFBRSxFQUFFLEtBQUs7SUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFLG1CQUFtQjtNQUFFTixJQUFJLEVBQUVHLEtBQUs7TUFBRUQ7SUFBUSxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3BLLElBQUksQ0FBQ0gsS0FBSyxJQUFJLE9BQU9BLEtBQUssS0FBSyxRQUFRLElBQUlRLEtBQUssQ0FBQ0MsT0FBTyxDQUFDVCxLQUFLLENBQUMsRUFBRSxPQUFPRSxJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzNGLE1BQU1RLEdBQUcsR0FBR1YsS0FBZ0M7RUFDNUMsTUFBTVcsT0FBTyxHQUFHRCxHQUFHLENBQUNyRCxJQUFJLEtBQUssV0FBVyxHQUFHLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUM7RUFDL0osSUFBSXVELE1BQU0sQ0FBQ0MsSUFBSSxDQUFDSCxHQUFHLENBQUMsQ0FBQ0ksSUFBSSxDQUFDQyxHQUFHLElBQUksQ0FBQ0osT0FBTyxDQUFDSyxRQUFRLENBQUNELEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBT2IsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUN0RixJQUFJLE9BQU9RLEdBQUcsQ0FBQ3ZELEVBQUUsS0FBSyxRQUFRLElBQUksQ0FBQ3VELEdBQUcsQ0FBQ3ZELEVBQUUsSUFBSSxPQUFPdUQsR0FBRyxDQUFDdEQsSUFBSSxLQUFLLFFBQVEsSUFBSSxDQUFDc0QsR0FBRyxDQUFDdEQsSUFBSSxJQUFJLE9BQU9zRCxHQUFHLENBQUNwRCxXQUFXLEtBQUssUUFBUSxFQUFFLE9BQU80QyxJQUFJLENBQUMscUJBQXFCLENBQUM7RUFDakssSUFBSSxDQUFDMUMsTUFBTSxDQUFDa0QsR0FBRyxDQUFDbkQsV0FBVyxDQUFDLElBQUlJLFNBQVMsQ0FBQytDLEdBQUcsQ0FBQ25ELFdBQVcsQ0FBQyxJQUFJLEVBQUUsRUFBRSxPQUFPMkMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLEdBQUdELElBQUksY0FBYyxDQUFDO0VBQ3hILElBQUlTLEdBQUcsQ0FBQ3JELElBQUksS0FBSyxXQUFXLEVBQUU7SUFDNUIsSUFBSXFELEdBQUcsQ0FBQ25ELFdBQVcsS0FBSyxPQUFPLEVBQUUsT0FBTzJDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHRCxJQUFJLGNBQWMsQ0FBQztJQUN6RixPQUFPO01BQUVJLEVBQUUsRUFBRSxJQUFJO01BQUU1QyxLQUFLLEVBQUV1QztJQUE0QixDQUFDO0VBQ3pEO0VBQ0EsSUFBSVUsR0FBRyxDQUFDckQsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDbUQsS0FBSyxDQUFDQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ08sS0FBSyxDQUFDLElBQUlQLEdBQUcsQ0FBQ08sS0FBSyxDQUFDQyxNQUFNLEdBQUcsQ0FBQyxJQUFJUixHQUFHLENBQUNPLEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEdBQUcsRUFBRSxPQUFPaEIsSUFBSSxDQUFDLHNCQUFzQixDQUFDO0VBQ2hKLEtBQUssSUFBSWlCLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR1QsR0FBRyxDQUFDTyxLQUFLLENBQUNDLE1BQU0sRUFBRUMsQ0FBQyxFQUFFLEVBQUU7SUFDekMsTUFBTXZCLElBQUksR0FBR2MsR0FBRyxDQUFDTyxLQUFLLENBQUNFLENBQUMsQ0FBQztJQUN6QixJQUFJLENBQUN2QixJQUFJLElBQUksT0FBT0EsSUFBSSxLQUFLLFFBQVEsSUFBSWdCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDakIsSUFBSSxDQUFDLENBQUNrQixJQUFJLENBQUNDLEdBQUcsSUFBSUEsR0FBRyxLQUFLLFFBQVEsQ0FBQyxJQUFJLENBQUNQLEtBQUssQ0FBQ0MsT0FBTyxDQUFDYixJQUFJLENBQUN3QixNQUFNLENBQUMsSUFBSXhCLElBQUksQ0FBQ3dCLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLENBQUMsSUFBSXRCLElBQUksQ0FBQ3dCLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLEVBQUUsRUFBRSxPQUFPaEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxHQUFHRCxJQUFJLFVBQVVrQixDQUFDLEdBQUcsQ0FBQztJQUNqTyxLQUFLLElBQUlFLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR3pCLElBQUksQ0FBQ3dCLE1BQU0sQ0FBQ0YsTUFBTSxFQUFFRyxDQUFDLEVBQUUsRUFBRTtNQUMzQyxNQUFNQyxLQUFLLEdBQUcxQixJQUFJLENBQUN3QixNQUFNLENBQUNDLENBQUMsQ0FBQztNQUM1QixJQUFJLENBQUNDLEtBQUssSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJVixNQUFNLENBQUNDLElBQUksQ0FBQ1MsS0FBSyxDQUFDLENBQUNSLElBQUksQ0FBQ0MsR0FBRyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUNDLFFBQVEsQ0FBQ0QsR0FBRyxDQUFDLENBQUMsSUFBSSxPQUFPTyxLQUFLLENBQUNsRSxJQUFJLEtBQUssUUFBUSxJQUFJLENBQUNrRSxLQUFLLENBQUNsRSxJQUFJLElBQUksQ0FBQ2lDLE1BQU0sQ0FBQ2tDLFNBQVMsQ0FBQ0QsS0FBSyxDQUFDRSxJQUFJLENBQUMsSUFBSUYsS0FBSyxDQUFDRSxJQUFJLEdBQUcsQ0FBQyxJQUFJRixLQUFLLENBQUNFLElBQUksR0FBRyxHQUFHLEVBQUUsT0FBT3RCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxHQUFHRCxJQUFJLFVBQVVrQixDQUFDLFlBQVlFLENBQUMsR0FBRyxDQUFDO0lBQzFTO0VBQ0Y7RUFDQSxPQUFPO0lBQUVoQixFQUFFLEVBQUUsSUFBSTtJQUFFNUMsS0FBSyxFQUFFdUM7RUFBNEIsQ0FBQztBQUN6RDtBQUNBLE9BQU8sU0FBU3lCLGtCQUFrQkEsQ0FBQ0MsSUFBa0IsRUFBRUMsUUFBNEIsR0FBR3pFLGtCQUFrQixFQUFRO0VBQUEsSUFBQTBFLGVBQUE7RUFDOUcsTUFBTUMsS0FBSyxHQUFHOUIsZ0JBQWdCLENBQUM0QixRQUFRLENBQUM7RUFBRSxJQUFJLENBQUNFLEtBQUssQ0FBQ3hCLEVBQUUsRUFBRSxNQUFNLElBQUl6QyxVQUFVLENBQUNpRSxLQUFLLENBQUN2QixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNILE9BQU8sQ0FBQztFQUN0RyxNQUFNUCxJQUFJLEdBQUdqQyxTQUFTLENBQUMrRCxJQUFJLENBQUM5QixJQUFJLENBQUM7SUFBRWtDLFVBQVUsR0FBR0osSUFBSSxDQUFDSixLQUFLLEdBQUcsQ0FBQztFQUM5RCxJQUFJLENBQUNqQyxNQUFNLENBQUNrQyxTQUFTLENBQUNHLElBQUksQ0FBQ0osS0FBSyxDQUFDLElBQUksQ0FBQ2pDLE1BQU0sQ0FBQ2tDLFNBQVMsQ0FBQ0csSUFBSSxDQUFDSyxHQUFHLENBQUMsRUFBRSxNQUFNLElBQUluRSxVQUFVLENBQUMsV0FBVyxDQUFDO0VBQ25HLElBQUk0RCxJQUFZO0VBQ2hCLElBQUlHLFFBQVEsQ0FBQ3RFLElBQUksS0FBSyxXQUFXLEVBQUU7SUFDakMsTUFBTTJFLFNBQVMsR0FBRyxDQUFDLEdBQUduQyxVQUFVLENBQUM7SUFBRSxJQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQyxFQUFFb0MsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUU7SUFDMUUsSUFBSUYsVUFBVSxHQUFHLENBQUMsSUFBSUEsVUFBVSxJQUFJLEVBQUUsSUFBSUosSUFBSSxDQUFDSyxHQUFHLEdBQUcsQ0FBQyxJQUFJTCxJQUFJLENBQUNLLEdBQUcsR0FBR0MsU0FBUyxDQUFDRixVQUFVLENBQUMsRUFBRSxNQUFNLElBQUlsRSxVQUFVLENBQUMsY0FBYyxDQUFDO0lBQ2hJNEQsSUFBSSxHQUFHMUIsa0JBQWtCLENBQUNGLElBQUksQ0FBQyxHQUFHL0IsTUFBTSxDQUFDbUUsU0FBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQyxFQUFFSCxVQUFVLENBQUMsQ0FBQ0ksTUFBTSxDQUFDLENBQUNqRSxDQUFDLEVBQUVDLENBQUMsS0FBS0QsQ0FBQyxHQUFHQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUd3RCxJQUFJLENBQUNLLEdBQUcsR0FBRyxDQUFDLENBQUM7RUFDcEgsQ0FBQyxNQUFNO0lBQ0wsTUFBTUksTUFBTSxHQUFHdEUsTUFBTSxDQUFDOEQsUUFBUSxDQUFDVixLQUFLLENBQUNDLE1BQU0sQ0FBQztNQUFFa0IsUUFBUSxHQUFHL0MsTUFBTSxDQUFDSyxHQUFHLENBQUNFLElBQUksRUFBRXVDLE1BQU0sQ0FBQyxDQUFDO0lBQ2xGLE1BQU1FLE9BQU8sR0FBR1YsUUFBUSxDQUFDVixLQUFLLENBQUNxQixHQUFHLENBQUNoRSxDQUFDLElBQUlBLENBQUMsQ0FBQzhDLE1BQU0sQ0FBQ2MsTUFBTSxDQUFDLENBQUNLLEdBQUcsRUFBRWpCLEtBQUssS0FBS2lCLEdBQUcsR0FBR2pCLEtBQUssQ0FBQ0UsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzdGLE1BQU1KLE1BQU0sR0FBR08sUUFBUSxDQUFDVixLQUFLLENBQUNtQixRQUFRLENBQUMsQ0FBQ2hCLE1BQU07SUFDOUMsSUFBSVUsVUFBVSxHQUFHLENBQUMsSUFBSUEsVUFBVSxJQUFJVixNQUFNLENBQUNGLE1BQU0sSUFBSVEsSUFBSSxDQUFDSyxHQUFHLEdBQUcsQ0FBQyxJQUFJTCxJQUFJLENBQUNLLEdBQUcsR0FBR1gsTUFBTSxDQUFDVSxVQUFVLENBQUMsQ0FBQ04sSUFBSSxFQUFFLE1BQU0sSUFBSTVELFVBQVUsQ0FBQyxjQUFjLENBQUM7SUFDN0k0RCxJQUFJLEdBQUdqQyxRQUFRLENBQUNLLElBQUksRUFBRXVDLE1BQU0sQ0FBQyxHQUFHdEUsTUFBTSxDQUFDd0UsT0FBTyxDQUFDSCxNQUFNLENBQUMsQ0FBQ2pFLENBQUMsRUFBRUMsQ0FBQyxLQUFLRCxDQUFDLEdBQUdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHTCxNQUFNLENBQUN3RSxPQUFPLENBQUNKLEtBQUssQ0FBQyxDQUFDLEVBQUVHLFFBQVEsQ0FBQyxDQUFDRixNQUFNLENBQUMsQ0FBQ2pFLENBQUMsRUFBRUMsQ0FBQyxLQUFLRCxDQUFDLEdBQUdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMxSXNELElBQUksSUFBSTNELE1BQU0sQ0FBQ3VELE1BQU0sQ0FBQ2EsS0FBSyxDQUFDLENBQUMsRUFBRUgsVUFBVSxDQUFDLENBQUNJLE1BQU0sQ0FBQyxDQUFDSyxHQUFHLEVBQUVqQixLQUFLLEtBQUtpQixHQUFHLEdBQUdqQixLQUFLLENBQUNFLElBQUksRUFBRSxDQUFDLENBQUMsR0FBR0UsSUFBSSxDQUFDSyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0VBQ3hHO0VBQ0EsTUFBTVMsU0FBUyxHQUFHN0UsU0FBUyxFQUFBaUUsZUFBQSxHQUFDRixJQUFJLENBQUNlLFNBQVMsY0FBQWIsZUFBQSxjQUFBQSxlQUFBLEdBQUksR0FBRyxDQUFDO0lBQUVyRSxXQUFXLEdBQUdJLFNBQVMsQ0FBQ2dFLFFBQVEsQ0FBQ3BFLFdBQVcsQ0FBQztFQUNqRyxJQUFJaUYsU0FBUyxHQUFHLEVBQUUsSUFBSUEsU0FBUyxJQUFJakYsV0FBVyxFQUFFLE1BQU0sSUFBSUssVUFBVSxDQUFDLHlCQUF5QixDQUFDO0VBQy9GLE9BQU9FLE1BQU0sQ0FBQzBELElBQUksR0FBR2pFLFdBQVcsR0FBR2lGLFNBQVMsQ0FBQztBQUMvQztBQUNBLE9BQU8sU0FBU0Usa0JBQWtCQSxDQUFDQyxJQUFVLEVBQUVoQixRQUE0QixHQUFHekUsa0JBQWtCLEVBQWdCO0VBQzlHLE1BQU0yRSxLQUFLLEdBQUc5QixnQkFBZ0IsQ0FBQzRCLFFBQVEsQ0FBQztFQUFFLElBQUksQ0FBQ0UsS0FBSyxDQUFDeEIsRUFBRSxFQUFFLE1BQU0sSUFBSXpDLFVBQVUsQ0FBQ2lFLEtBQUssQ0FBQ3ZCLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ0gsT0FBTyxDQUFDO0VBQ3RHLE1BQU0xQyxLQUFLLEdBQUdFLFNBQVMsQ0FBQ2dGLElBQUksQ0FBQztJQUFFcEYsV0FBVyxHQUFHSSxTQUFTLENBQUNnRSxRQUFRLENBQUNwRSxXQUFXLENBQUM7SUFBRXFGLFNBQVMsR0FBR3JELFFBQVEsQ0FBQzlCLEtBQUssRUFBRUYsV0FBVyxDQUFDO0VBQ3RILElBQUlxQyxJQUFZLEVBQUVpRCxTQUFpQixFQUFFekIsTUFBMEI7RUFDL0QsSUFBSU8sUUFBUSxDQUFDdEUsSUFBSSxLQUFLLFdBQVcsRUFBRTtJQUNqQyxNQUFNeUYsS0FBSyxHQUFHdkQsUUFBUSxDQUFDcUQsU0FBUyxFQUFFLE9BQU8sQ0FBQztNQUFFRyxVQUFVLEdBQUdELEtBQUssR0FBRyxJQUFJO0lBQ3JFbEQsSUFBSSxHQUFHbUQsVUFBVTtJQUFFLE1BQU0vRCxTQUFTLEdBQUc0RCxTQUFTLEdBQUdFLEtBQUssR0FBRyxPQUFPO0lBQ2hFO0lBQ0EsT0FBT2xELElBQUksR0FBR21ELFVBQVUsR0FBRyxJQUFJLElBQUlqRCxrQkFBa0IsQ0FBQ0YsSUFBSSxHQUFHLEVBQUUsQ0FBQyxHQUFHa0QsS0FBSyxHQUFHLE9BQU8sSUFBSTlELFNBQVMsRUFBRVksSUFBSSxFQUFFO0lBQ3ZHaUQsU0FBUyxHQUFHeEQsTUFBTSxDQUFDdUQsU0FBUyxHQUFHOUMsa0JBQWtCLENBQUNGLElBQUksQ0FBQyxDQUFDO0lBQ3hEd0IsTUFBTSxHQUFHdkIsVUFBVSxDQUFDeUMsR0FBRyxDQUFDLENBQUNkLElBQUksRUFBRXdCLEtBQUssTUFBTTtNQUFFeEIsSUFBSSxFQUFFd0IsS0FBSyxLQUFLLENBQUMsSUFBSXJELFVBQVUsQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHNEI7SUFBSyxDQUFDLENBQUMsQ0FBQztFQUNuRyxDQUFDLE1BQU07SUFDTCxNQUFNYSxPQUFPLEdBQUdWLFFBQVEsQ0FBQ1YsS0FBSyxDQUFDcUIsR0FBRyxDQUFDaEUsQ0FBQyxJQUFJQSxDQUFDLENBQUM4QyxNQUFNLENBQUNjLE1BQU0sQ0FBQyxDQUFDSyxHQUFHLEVBQUVqQixLQUFLLEtBQUtpQixHQUFHLEdBQUdqQixLQUFLLENBQUNFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztNQUFFeUIsU0FBUyxHQUFHcEYsTUFBTSxDQUFDd0UsT0FBTyxDQUFDSCxNQUFNLENBQUMsQ0FBQ2pFLENBQUMsRUFBRUMsQ0FBQyxLQUFLRCxDQUFDLEdBQUdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNySixNQUFNNEUsS0FBSyxHQUFHdkQsUUFBUSxDQUFDcUQsU0FBUyxFQUFFSyxTQUFTLENBQUM7SUFBRSxJQUFJakUsU0FBUyxHQUFHSyxNQUFNLENBQUNLLEdBQUcsQ0FBQ2tELFNBQVMsRUFBRUssU0FBUyxDQUFDLENBQUM7TUFBRWIsUUFBUSxHQUFHLENBQUM7SUFDN0csT0FBT0EsUUFBUSxHQUFHQyxPQUFPLENBQUNuQixNQUFNLEdBQUcsQ0FBQyxJQUFJbEMsU0FBUyxJQUFJcUQsT0FBTyxDQUFDRCxRQUFRLENBQUMsRUFBRXBELFNBQVMsSUFBSXFELE9BQU8sQ0FBQ0QsUUFBUSxFQUFFLENBQUM7SUFDeEd4QyxJQUFJLEdBQUdrRCxLQUFLLEdBQUdqRixNQUFNLENBQUN3RSxPQUFPLENBQUNuQixNQUFNLENBQUMsR0FBR3JELE1BQU0sQ0FBQ3VFLFFBQVEsQ0FBQztJQUFFUyxTQUFTLEdBQUc3RCxTQUFTO0lBQUVvQyxNQUFNLEdBQUdPLFFBQVEsQ0FBQ1YsS0FBSyxDQUFDbUIsUUFBUSxDQUFDLENBQUNoQixNQUFNO0VBQzNIO0VBQ0EsSUFBSUUsS0FBSyxHQUFHLENBQUM7RUFBRSxPQUFPQSxLQUFLLEdBQUdGLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLENBQUMsSUFBSTJCLFNBQVMsSUFBSXpCLE1BQU0sQ0FBQ0UsS0FBSyxDQUFDLENBQUNFLElBQUksRUFBRXFCLFNBQVMsSUFBSXpCLE1BQU0sQ0FBQ0UsS0FBSyxFQUFFLENBQUMsQ0FBQ0UsSUFBSTtFQUNySCxPQUFPO0lBQUU1QixJQUFJLEVBQUVBLElBQUksQ0FBQzdCLFFBQVEsQ0FBQyxDQUFDO0lBQUV1RCxLQUFLLEVBQUVBLEtBQUssR0FBRyxDQUFDO0lBQUVTLEdBQUcsRUFBRWMsU0FBUyxHQUFHLENBQUM7SUFBRUosU0FBUyxFQUFFL0MsR0FBRyxDQUFDakMsS0FBSyxFQUFFRixXQUFXLENBQUMsQ0FBQ1EsUUFBUSxDQUFDO0VBQUUsQ0FBQztBQUN2SDtBQUNBLE9BQU8sU0FBU21GLGtCQUFrQkEsQ0FBQ1AsSUFBVSxFQUFFaEIsUUFBNEIsR0FBR3pFLGtCQUFrQixFQUFVO0VBQ3hHLE1BQU13RSxJQUFJLEdBQUdnQixrQkFBa0IsQ0FBQ0MsSUFBSSxFQUFFaEIsUUFBUSxDQUFDO0VBQUUsT0FBTyxHQUFHRCxJQUFJLENBQUM5QixJQUFJLElBQUk4QixJQUFJLENBQUNKLEtBQUssSUFBSUksSUFBSSxDQUFDSyxHQUFHLElBQUlMLElBQUksQ0FBQ2UsU0FBUyxLQUFLLEdBQUcsR0FBRyxLQUFLZixJQUFJLENBQUNlLFNBQVMsT0FBTyxHQUFHLEVBQUUsRUFBRTtBQUM5SjtBQUdBLFNBQVNVLGtCQUFrQkEsQ0FBQ0MsSUFBNkMsRUFBRW5ELElBQVUsRUFBa0I7RUFDckcsSUFBSTtJQUNGLElBQUltRCxJQUFJLENBQUNDLElBQUksS0FBSyxTQUFTLEVBQUUsT0FBTztNQUFFQyxNQUFNLEVBQUUsU0FBUztNQUFFQyxNQUFNLEVBQUVILElBQUksQ0FBQ0csTUFBTSxJQUFJLFVBQVU7TUFBRXREO0lBQUssQ0FBQztJQUNsRyxJQUFJbUQsSUFBSSxDQUFDQyxJQUFJLEtBQUssU0FBUyxFQUFFO01BQUUxRixTQUFTLENBQUN5RixJQUFJLENBQUM1RSxFQUFFLENBQUM7TUFBRSxPQUFPO1FBQUU4RSxNQUFNLEVBQUUsVUFBVTtRQUFFRSxRQUFRLEVBQUVKLElBQUksQ0FBQzVFLEVBQUU7UUFBRWlGLE1BQU0sRUFBRUwsSUFBSSxDQUFDNUUsRUFBRTtRQUFFa0YsV0FBVyxFQUFFTixJQUFJLENBQUM1RSxFQUFFO1FBQUVtRixTQUFTLEVBQUVQLElBQUksQ0FBQzVFLEVBQUU7UUFBRW9GLFVBQVUsRUFBRVIsSUFBSSxDQUFDUSxVQUFVO1FBQUVQLElBQUksRUFBRUQsSUFBSSxDQUFDQztNQUFLLENBQUM7SUFBRTtJQUM5TSxJQUFJRCxJQUFJLENBQUNDLElBQUksS0FBSyxVQUFVLEVBQUU7TUFDNUIsSUFBSWpGLFlBQVksQ0FBQ2dGLElBQUksQ0FBQ1MsS0FBSyxFQUFFVCxJQUFJLENBQUNVLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPO1FBQUVSLE1BQU0sRUFBRSxVQUFVO1FBQUVDLE1BQU0sRUFBRSxvQkFBb0I7UUFBRXREO01BQUssQ0FBQztNQUM5RyxPQUFPO1FBQUVxRCxNQUFNLEVBQUUsVUFBVTtRQUFFRSxRQUFRLEVBQUVKLElBQUksQ0FBQ1MsS0FBSztRQUFFSixNQUFNLEVBQUVMLElBQUksQ0FBQ1MsS0FBSztRQUFFSCxXQUFXLEVBQUVOLElBQUksQ0FBQ1UsR0FBRztRQUFFSCxTQUFTLEVBQUVQLElBQUksQ0FBQ1UsR0FBRztRQUFFRixVQUFVLEVBQUVSLElBQUksQ0FBQ1EsVUFBVTtRQUFFUCxJQUFJLEVBQUVELElBQUksQ0FBQ0M7TUFBSyxDQUFDO0lBQ25LO0lBQ0EsSUFBSWpGLFlBQVksQ0FBQ2dGLElBQUksQ0FBQ0ksUUFBUSxFQUFFSixJQUFJLENBQUNLLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPO01BQUVILE1BQU0sRUFBRSxVQUFVO01BQUVDLE1BQU0sRUFBRSxlQUFlO01BQUV0RDtJQUFLLENBQUM7SUFDOUcsT0FBTztNQUFFcUQsTUFBTSxFQUFFLFVBQVU7TUFBRUUsUUFBUSxFQUFFSixJQUFJLENBQUNJLFFBQVE7TUFBRUMsTUFBTSxFQUFFTCxJQUFJLENBQUNLLE1BQU07TUFBRUMsV0FBVyxFQUFFTixJQUFJLENBQUNJLFFBQVE7TUFBRUcsU0FBUyxFQUFFUCxJQUFJLENBQUNLLE1BQU07TUFBRUcsVUFBVSxFQUFFUixJQUFJLENBQUNRLFVBQVU7TUFBRVAsSUFBSSxFQUFFRCxJQUFJLENBQUNDO0lBQUssQ0FBQztFQUMvSyxDQUFDLENBQUMsT0FBT1UsS0FBSyxFQUFFO0lBQUUsT0FBTztNQUFFVCxNQUFNLEVBQUUsVUFBVTtNQUFFQyxNQUFNLEVBQUVRLEtBQUssWUFBWUMsS0FBSyxHQUFHRCxLQUFLLENBQUM1RCxPQUFPLEdBQUcsYUFBYTtNQUFFRjtJQUFLLENBQUM7RUFBRTtBQUN6SDtBQUNBLFNBQVNnRSxhQUFhQSxDQUFDYixJQUE2QyxFQUFFYyxNQUFzQixFQUFFakUsSUFBZ0IsRUFBRWtFLGFBQXNCLEVBQWtCO0VBQ3RKLElBQUk7SUFDRixJQUFJL0YsWUFBWSxDQUFDZ0YsSUFBSSxDQUFDZ0IsU0FBUyxFQUFFaEIsSUFBSSxDQUFDaUIsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU87TUFBRWYsTUFBTSxFQUFFLFVBQVU7TUFBRUMsTUFBTSxFQUFFLGtCQUFrQjtNQUFFdEQsSUFBSSxFQUFFQSxJQUFJLENBQUM7SUFBRSxDQUFDO0lBQzdILElBQUlpRSxNQUFNLENBQUNaLE1BQU0sS0FBSyxVQUFVLEVBQUUsT0FBT2EsYUFBYSxHQUFHO01BQUUsR0FBR0QsTUFBTTtNQUFFakUsSUFBSSxFQUFFLENBQUMsR0FBR0EsSUFBSSxDQUFDLENBQUMsRUFBRSxHQUFHaUUsTUFBTSxDQUFDakUsSUFBSSxDQUFDLENBQUNnQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUU7SUFBRSxDQUFDLEdBQUdpQyxNQUFNO0lBQy9ILE1BQU1WLFFBQVEsR0FBR3hGLFFBQVEsQ0FBQ29GLElBQUksQ0FBQ2tCLFdBQVcsS0FBSyxPQUFPLEdBQUdKLE1BQU0sQ0FBQ1YsUUFBUSxHQUFHVSxNQUFNLENBQUNSLFdBQVcsRUFBRU4sSUFBSSxDQUFDZ0IsU0FBUyxDQUFDO01BQUVYLE1BQU0sR0FBR3pGLFFBQVEsQ0FBQ29GLElBQUksQ0FBQ2tCLFdBQVcsS0FBSyxPQUFPLEdBQUdKLE1BQU0sQ0FBQ1QsTUFBTSxHQUFHUyxNQUFNLENBQUNQLFNBQVMsRUFBRVAsSUFBSSxDQUFDaUIsU0FBUyxDQUFDO0lBQ2xOLE9BQU87TUFBRWYsTUFBTSxFQUFFLFVBQVU7TUFBRUUsUUFBUTtNQUFFQyxNQUFNO01BQUVDLFdBQVcsRUFBRUYsUUFBUTtNQUFFRyxTQUFTLEVBQUVGLE1BQU07TUFBRUcsVUFBVSxFQUFFTSxNQUFNLENBQUNOLFVBQVU7TUFBRVAsSUFBSSxFQUFFO0lBQVcsQ0FBQztFQUM1SSxDQUFDLENBQUMsT0FBT1UsS0FBSyxFQUFFO0lBQUUsT0FBTztNQUFFVCxNQUFNLEVBQUUsVUFBVTtNQUFFQyxNQUFNLEVBQUVRLEtBQUssWUFBWUMsS0FBSyxHQUFHRCxLQUFLLENBQUM1RCxPQUFPLEdBQUcsYUFBYTtNQUFFRixJQUFJLEVBQUVBLElBQUksQ0FBQztJQUFFLENBQUM7RUFBRTtBQUNqSTtBQUNBO0FBQ0EsT0FBTyxTQUFTc0UsbUJBQW1CQSxDQUFDbkIsSUFBNkMsRUFBRWMsTUFBc0IsRUFBRWpFLElBQVUsR0FBRyxFQUFFLEVBQWtCO0VBQzFJLE9BQU9nRSxhQUFhLENBQUNiLElBQUksRUFBRWMsTUFBTSxFQUFFLE1BQU1qRSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQ3REO0FBQ0EsU0FBU3VFLFVBQVVBLENBQUNDLE1BQXlCLEVBQTRCO0VBQUUsTUFBTXpCLEtBQUssR0FBRyxJQUFJMEIsR0FBRyxDQUFzQixDQUFDO0VBQUUsS0FBSyxNQUFNQyxLQUFLLElBQUlGLE1BQU0sRUFBRSxJQUFJLENBQUNFLEtBQUssQ0FBQ0MsU0FBUyxJQUFJLENBQUM1QixLQUFLLENBQUM2QixHQUFHLENBQUNGLEtBQUssQ0FBQ3hILEVBQUUsQ0FBQyxFQUFFNkYsS0FBSyxDQUFDOEIsR0FBRyxDQUFDSCxLQUFLLENBQUN4SCxFQUFFLEVBQUV3SCxLQUFLLENBQUM7RUFBRSxPQUFPM0IsS0FBSztBQUFFO0FBQzdPO0FBQ0EsT0FBTyxTQUFTK0IsV0FBV0EsQ0FBQzNCLElBQWMsRUFBRXFCLE1BQXlCLEdBQUcsRUFBRSxFQUFFTyxLQUFXLEdBQUcsRUFBRSxFQUFrQjtFQUM1RyxJQUFJNUIsSUFBSSxDQUFDQyxJQUFJLEtBQUssVUFBVSxFQUFFLE9BQU9GLGtCQUFrQixDQUFDQyxJQUFJLEVBQUU0QixLQUFLLENBQUM7RUFDcEUsTUFBTWhDLEtBQUssR0FBR3dCLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDO0lBQUV4RSxJQUFJLEdBQUcsQ0FBQyxHQUFHK0UsS0FBSyxDQUFDO0lBQUVDLE9BQU8sR0FBRyxJQUFJQyxHQUFHLENBQUNGLEtBQUssQ0FBQztJQUFFRyxNQUErRSxHQUFHLEVBQUU7RUFDbkssSUFBSUMsTUFBZ0IsR0FBR2hDLElBQUk7RUFDM0IsT0FBT2dDLE1BQU0sQ0FBQy9CLElBQUksS0FBSyxVQUFVLEVBQUU7SUFDakMsSUFBSTRCLE9BQU8sQ0FBQ0osR0FBRyxDQUFDTyxNQUFNLENBQUNDLGFBQWEsQ0FBQyxFQUFFLE9BQU87TUFBRS9CLE1BQU0sRUFBRSxVQUFVO01BQUVDLE1BQU0sRUFBRSxrQkFBa0I7TUFBRXRELElBQUksRUFBRSxDQUFDLEdBQUdBLElBQUksRUFBRW1GLE1BQU0sQ0FBQ0MsYUFBYTtJQUFFLENBQUM7SUFDdkksSUFBSTtNQUFFLElBQUlqSCxZQUFZLENBQUNnSCxNQUFNLENBQUNoQixTQUFTLEVBQUVnQixNQUFNLENBQUNmLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPO1FBQUVmLE1BQU0sRUFBRSxVQUFVO1FBQUVDLE1BQU0sRUFBRSxrQkFBa0I7UUFBRXRELElBQUksRUFBRSxDQUFDLEdBQUdBLElBQUk7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDLE9BQU84RCxLQUFLLEVBQUU7TUFBRSxPQUFPO1FBQUVULE1BQU0sRUFBRSxVQUFVO1FBQUVDLE1BQU0sRUFBRVEsS0FBSyxZQUFZQyxLQUFLLEdBQUdELEtBQUssQ0FBQzVELE9BQU8sR0FBRyxhQUFhO1FBQUVGLElBQUksRUFBRSxDQUFDLEdBQUdBLElBQUk7TUFBRSxDQUFDO0lBQUU7SUFDOVEsTUFBTWlFLE1BQU0sR0FBR2xCLEtBQUssQ0FBQ3NDLEdBQUcsQ0FBQ0YsTUFBTSxDQUFDQyxhQUFhLENBQUM7SUFBRSxJQUFJLENBQUNuQixNQUFNLEVBQUUsT0FBTztNQUFFWixNQUFNLEVBQUUsU0FBUztNQUFFQyxNQUFNLEVBQUUsaUJBQWlCO01BQUV0RCxJQUFJLEVBQUUsQ0FBQyxHQUFHQSxJQUFJLEVBQUVtRixNQUFNLENBQUNDLGFBQWE7SUFBRSxDQUFDO0lBQzNKRixNQUFNLENBQUNJLElBQUksQ0FBQztNQUFFbkMsSUFBSSxFQUFFZ0MsTUFBTTtNQUFFSSxVQUFVLEVBQUV2RixJQUFJLENBQUNpQjtJQUFPLENBQUMsQ0FBQztJQUFFK0QsT0FBTyxDQUFDUSxHQUFHLENBQUN2QixNQUFNLENBQUMvRyxFQUFFLENBQUM7SUFBRThDLElBQUksQ0FBQ3NGLElBQUksQ0FBQ3JCLE1BQU0sQ0FBQy9HLEVBQUUsQ0FBQztJQUFFaUksTUFBTSxHQUFHbEIsTUFBTSxDQUFDd0IsSUFBSSxDQUFDdEMsSUFBSTtFQUNqSTtFQUNBLElBQUl1QyxRQUFRLEdBQUd4QyxrQkFBa0IsQ0FBQ2lDLE1BQU0sRUFBRW5GLElBQUksQ0FBQztFQUMvQyxLQUFLLElBQUlrQixDQUFDLEdBQUdnRSxNQUFNLENBQUNqRSxNQUFNLEdBQUcsQ0FBQyxFQUFFQyxDQUFDLElBQUksQ0FBQyxJQUFJd0UsUUFBUSxDQUFDckMsTUFBTSxLQUFLLFVBQVUsRUFBRW5DLENBQUMsRUFBRSxFQUFFO0lBQUUsTUFBTXlFLEtBQUssR0FBR1QsTUFBTSxDQUFDaEUsQ0FBQyxDQUFDO0lBQUV3RSxRQUFRLEdBQUcxQixhQUFhLENBQUMyQixLQUFLLENBQUN4QyxJQUFJLEVBQUV1QyxRQUFRLEVBQUUsTUFBTTFGLElBQUksQ0FBQ2dDLEtBQUssQ0FBQyxDQUFDLEVBQUUyRCxLQUFLLENBQUNKLFVBQVUsQ0FBQyxFQUFFLEtBQUssQ0FBQztFQUFFO0VBQ3hNLE9BQU9HLFFBQVE7QUFDakI7QUFDQTtBQUNBLE9BQU8sU0FBU0UsaUJBQWlCQSxDQUFDcEIsTUFBeUIsRUFBMkI7RUFDcEYsTUFBTXpCLEtBQUssR0FBR3dCLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDO0lBQUVrQixRQUFRLEdBQUcsSUFBSWpCLEdBQUcsQ0FBcUIsQ0FBQztFQUMxRSxLQUFLLE1BQU1DLEtBQUssSUFBSTNCLEtBQUssQ0FBQzhDLE1BQU0sQ0FBQyxDQUFDLEVBQUU7SUFDbEMsSUFBSUgsUUFBUSxDQUFDZCxHQUFHLENBQUNGLEtBQUssQ0FBQ3hILEVBQUUsQ0FBQyxFQUFFO0lBQzVCLE1BQU04QyxJQUFVLEdBQUcsRUFBRTtNQUFFOEYsUUFBUSxHQUFHLElBQUlyQixHQUFHLENBQWEsQ0FBQztJQUFFLElBQUlVLE1BQU0sR0FBR1QsS0FBSyxDQUFDeEgsRUFBRTtJQUM5RSxPQUFPLENBQUN3SSxRQUFRLENBQUNkLEdBQUcsQ0FBQ08sTUFBTSxDQUFDLEVBQUU7TUFDNUIsTUFBTVksT0FBTyxHQUFHaEQsS0FBSyxDQUFDc0MsR0FBRyxDQUFDRixNQUFNLENBQUM7TUFBRSxJQUFJLENBQUNZLE9BQU8sRUFBRTtRQUFFTCxRQUFRLENBQUNiLEdBQUcsQ0FBQ00sTUFBTSxFQUFFO1VBQUU5QixNQUFNLEVBQUUsU0FBUztVQUFFQyxNQUFNLEVBQUUsaUJBQWlCO1VBQUV0RCxJQUFJLEVBQUUsQ0FBQ21GLE1BQU07UUFBRSxDQUFDLENBQUM7UUFBRTtNQUFPO01BQ2xKLE1BQU1yQyxVQUFVLEdBQUdnRCxRQUFRLENBQUNULEdBQUcsQ0FBQ0YsTUFBTSxDQUFDO01BQ3ZDLElBQUlyQyxVQUFVLEtBQUtrRCxTQUFTLEVBQUU7UUFBRSxNQUFNbkQsS0FBSyxHQUFHN0MsSUFBSSxDQUFDZ0MsS0FBSyxDQUFDYyxVQUFVLENBQUM7UUFBRSxLQUFLLElBQUk1QixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUcyQixLQUFLLENBQUM1QixNQUFNLEVBQUVDLENBQUMsRUFBRSxFQUFFd0UsUUFBUSxDQUFDYixHQUFHLENBQUNoQyxLQUFLLENBQUMzQixDQUFDLENBQUMsRUFBRTtVQUFFbUMsTUFBTSxFQUFFLFVBQVU7VUFBRUMsTUFBTSxFQUFFLGtCQUFrQjtVQUFFdEQsSUFBSSxFQUFFTyxLQUFLLENBQUMwRixJQUFJLENBQUM7WUFBRWhGLE1BQU0sRUFBRWlGLElBQUksQ0FBQ0MsR0FBRyxDQUFDdEQsS0FBSyxDQUFDNUIsTUFBTSxHQUFHLENBQUMsRUFBRSxFQUFFO1VBQUUsQ0FBQyxFQUFFLENBQUNtRixDQUFDLEVBQUVDLE1BQU0sS0FBS3hELEtBQUssQ0FBQyxDQUFDM0IsQ0FBQyxHQUFHbUYsTUFBTSxJQUFJeEQsS0FBSyxDQUFDNUIsTUFBTSxDQUFDO1FBQUUsQ0FBQyxDQUFDO1FBQUU7TUFBTztNQUNqVCxJQUFJOEUsT0FBTyxDQUFDTixJQUFJLENBQUN0QyxJQUFJLENBQUNDLElBQUksS0FBSyxVQUFVLEVBQUU7UUFBRXNDLFFBQVEsQ0FBQ2IsR0FBRyxDQUFDTSxNQUFNLEVBQUVqQyxrQkFBa0IsQ0FBQzZDLE9BQU8sQ0FBQ04sSUFBSSxDQUFDdEMsSUFBSSxFQUFFLENBQUNnQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQUU7TUFBTztNQUMzSCxNQUFNbUIsUUFBUSxHQUFHUCxPQUFPLENBQUNOLElBQUksQ0FBQ3RDLElBQUk7TUFDbEM7TUFDQSxJQUFJLENBQUMyQyxRQUFRLENBQUNsQixHQUFHLENBQUMwQixRQUFRLENBQUNsQixhQUFhLENBQUMsSUFBSWtCLFFBQVEsQ0FBQ2xCLGFBQWEsS0FBS0QsTUFBTSxFQUFFLElBQUk7UUFBRSxJQUFJaEgsWUFBWSxDQUFDbUksUUFBUSxDQUFDbkMsU0FBUyxFQUFFbUMsUUFBUSxDQUFDbEMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1VBQUVzQixRQUFRLENBQUNiLEdBQUcsQ0FBQ00sTUFBTSxFQUFFO1lBQUU5QixNQUFNLEVBQUUsVUFBVTtZQUFFQyxNQUFNLEVBQUUsa0JBQWtCO1lBQUV0RCxJQUFJLEVBQUUsQ0FBQ21GLE1BQU07VUFBRSxDQUFDLENBQUM7VUFBRTtRQUFPO01BQUUsQ0FBQyxDQUFDLE9BQU9yQixLQUFLLEVBQUU7UUFBRTRCLFFBQVEsQ0FBQ2IsR0FBRyxDQUFDTSxNQUFNLEVBQUU7VUFBRTlCLE1BQU0sRUFBRSxVQUFVO1VBQUVDLE1BQU0sRUFBRVEsS0FBSyxZQUFZQyxLQUFLLEdBQUdELEtBQUssQ0FBQzVELE9BQU8sR0FBRyxhQUFhO1VBQUVGLElBQUksRUFBRSxDQUFDbUYsTUFBTTtRQUFFLENBQUMsQ0FBQztRQUFFO01BQU87TUFDaFpXLFFBQVEsQ0FBQ2pCLEdBQUcsQ0FBQ00sTUFBTSxFQUFFbkYsSUFBSSxDQUFDaUIsTUFBTSxDQUFDO01BQUVqQixJQUFJLENBQUNzRixJQUFJLENBQUNILE1BQU0sQ0FBQztNQUFFQSxNQUFNLEdBQUdtQixRQUFRLENBQUNsQixhQUFhO0lBQ3ZGO0lBQ0EsS0FBSyxJQUFJbEUsQ0FBQyxHQUFHbEIsSUFBSSxDQUFDaUIsTUFBTSxHQUFHLENBQUMsRUFBRUMsQ0FBQyxJQUFJLENBQUMsRUFBRUEsQ0FBQyxFQUFFLEVBQUU7TUFBRSxNQUFNaEUsRUFBRSxHQUFHOEMsSUFBSSxDQUFDa0IsQ0FBQyxDQUFDO1FBQUU2RSxPQUFPLEdBQUdoRCxLQUFLLENBQUNzQyxHQUFHLENBQUNuSSxFQUFFLENBQUU7TUFBRSxJQUFJLENBQUN3SSxRQUFRLENBQUNkLEdBQUcsQ0FBQzFILEVBQUUsQ0FBQyxJQUFJNkksT0FBTyxDQUFDTixJQUFJLENBQUN0QyxJQUFJLENBQUNDLElBQUksS0FBSyxVQUFVLEVBQUVzQyxRQUFRLENBQUNiLEdBQUcsQ0FBQzNILEVBQUUsRUFBRW9ILG1CQUFtQixDQUFDeUIsT0FBTyxDQUFDTixJQUFJLENBQUN0QyxJQUFJLEVBQUV1QyxRQUFRLENBQUNMLEdBQUcsQ0FBQ1UsT0FBTyxDQUFDTixJQUFJLENBQUN0QyxJQUFJLENBQUNpQyxhQUFhLENBQUMsRUFBRyxDQUFDbEksRUFBRSxDQUFDLENBQUMsQ0FBQztJQUFFO0VBQzdRO0VBQ0EsT0FBT3dJLFFBQVE7QUFDakI7QUFDQSxPQUFPLFNBQVNhLGtCQUFrQkEsQ0FBQy9CLE1BQXlCLEVBQXFCO0VBQy9FLE1BQU1uRSxNQUF5QixHQUFHLEVBQUU7SUFBRTBDLEtBQUssR0FBR3dCLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDO0lBQUVnQyxLQUFLLEdBQUdaLGlCQUFpQixDQUFDcEIsTUFBTSxDQUFDO0VBQ25HLEtBQUssTUFBTUUsS0FBSyxJQUFJM0IsS0FBSyxDQUFDOEMsTUFBTSxDQUFDLENBQUMsRUFBRTtJQUNsQyxNQUFNMUMsSUFBSSxHQUFHcUQsS0FBSyxDQUFDbkIsR0FBRyxDQUFDWCxLQUFLLENBQUN4SCxFQUFFLENBQUU7SUFDakMsSUFBSWlHLElBQUksQ0FBQ0UsTUFBTSxLQUFLLFVBQVUsRUFBRWhELE1BQU0sQ0FBQ2lGLElBQUksQ0FBQztNQUFFaEYsSUFBSSxFQUFFLDBCQUEwQjtNQUFFTixJQUFJLEVBQUUsWUFBWTBFLEtBQUssQ0FBQ3hILEVBQUUsWUFBWTtNQUFFZ0QsT0FBTyxFQUFFaUQsSUFBSSxDQUFDRztJQUFPLENBQUMsQ0FBQztJQUMvSSxLQUFLLE1BQU1tRCxVQUFVLEtBQUFDLHFCQUFBLEdBQUloQyxLQUFLLENBQUNlLElBQUksQ0FBQ2tCLFdBQVcsY0FBQUQscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLEVBQUU7TUFBQSxJQUFBQSxxQkFBQTtNQUNyRCxNQUFNRSxNQUFNLEdBQUc3RCxLQUFLLENBQUNzQyxHQUFHLENBQUNvQixVQUFVLENBQUNJLGFBQWEsQ0FBQztNQUFFLElBQUksQ0FBQ0QsTUFBTSxJQUFJekQsSUFBSSxDQUFDRSxNQUFNLEtBQUssVUFBVSxFQUFFO01BQy9GLE1BQU15RCxLQUFLLEdBQUdOLEtBQUssQ0FBQ25CLEdBQUcsQ0FBQ3VCLE1BQU0sQ0FBQzFKLEVBQUUsQ0FBRTtNQUFFLElBQUk0SixLQUFLLENBQUN6RCxNQUFNLEtBQUssVUFBVSxFQUFFO01BQ3RFLElBQUkwRCxRQUFRLEdBQUc1RCxJQUFJLENBQUNRLFVBQVUsS0FBS21ELEtBQUssQ0FBQ25ELFVBQVU7TUFDbkQsSUFBSThDLFVBQVUsQ0FBQ08sSUFBSSxLQUFLLFFBQVEsRUFBRUQsUUFBUSxLQUFSQSxRQUFRLEdBQUs1RCxJQUFJLENBQUNDLElBQUksS0FBSyxVQUFVLEdBQUdqRixZQUFZLENBQUNnRixJQUFJLENBQUNNLFdBQVcsRUFBRXFELEtBQUssQ0FBQ3RELE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBR3JGLFlBQVksQ0FBQ2dGLElBQUksQ0FBQ00sV0FBVyxFQUFFcUQsS0FBSyxDQUFDdEQsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQzFLLElBQUlpRCxVQUFVLENBQUNPLElBQUksS0FBSyxZQUFZLEVBQUVELFFBQVEsS0FBUkEsUUFBUSxHQUFLNUksWUFBWSxDQUFDZ0YsSUFBSSxDQUFDSSxRQUFRLEVBQUV1RCxLQUFLLENBQUN0RCxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUlyRixZQUFZLENBQUMySSxLQUFLLENBQUN2RCxRQUFRLEVBQUVKLElBQUksQ0FBQ0ssTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFDLEtBQ2xKO1FBQ0gsTUFBTXlELE1BQU0sR0FBR3ZKLFNBQVMsQ0FBQ29KLEtBQUssQ0FBQ3ZELFFBQVEsQ0FBQyxHQUFHN0YsU0FBUyxDQUFDeUYsSUFBSSxDQUFDTyxTQUFTLENBQUM7VUFBRXdELE1BQU0sR0FBR3hKLFNBQVMsQ0FBQ29KLEtBQUssQ0FBQ3RELE1BQU0sQ0FBQyxHQUFHOUYsU0FBUyxDQUFDeUYsSUFBSSxDQUFDTSxXQUFXLENBQUM7UUFDcElzRCxRQUFRLEtBQVJBLFFBQVEsR0FBS0csTUFBTSxHQUFHeEosU0FBUyxDQUFDK0ksVUFBVSxDQUFDVSxZQUFZLENBQUMsSUFBSUYsTUFBTSxHQUFHdkosU0FBUyxDQUFDK0ksVUFBVSxDQUFDVyxZQUFZLENBQUM7TUFDekc7TUFDQSxJQUFJTCxRQUFRLEVBQUUxRyxNQUFNLENBQUNpRixJQUFJLENBQUM7UUFBRWhGLElBQUksRUFBRSwwQkFBMEI7UUFBRU4sSUFBSSxFQUFFLFlBQVkwRSxLQUFLLENBQUN4SCxFQUFFLG1CQUFtQjtRQUFFZ0QsT0FBTyxFQUFFO01BQXdCLENBQUMsQ0FBQztJQUNsSjtFQUNGO0VBQ0E7RUFDQSxNQUFNbUgsTUFBTSxHQUFHLElBQUk1QyxHQUFHLENBQWEsQ0FBQztJQUFFNkMsWUFBWSxHQUFHLElBQUk3QyxHQUFHLENBQVcsQ0FBQztFQUN4RSxLQUFLLE1BQU1DLEtBQUssSUFBSTNCLEtBQUssQ0FBQzhDLE1BQU0sQ0FBQyxDQUFDLEVBQUU7SUFBQSxJQUFBMEIsc0JBQUE7SUFBRUQsWUFBWSxDQUFDekMsR0FBRyxDQUFDSCxLQUFLLENBQUN4SCxFQUFFLEVBQUUsRUFBQXFLLHNCQUFBLEdBQUM3QyxLQUFLLENBQUNlLElBQUksQ0FBQ2tCLFdBQVcsY0FBQVksc0JBQUEsY0FBQUEsc0JBQUEsR0FBSSxFQUFFLEVBQUVsRixHQUFHLENBQUNvRSxVQUFVLElBQUlBLFVBQVUsQ0FBQ0ksYUFBYSxDQUFDLENBQUM7RUFBRTtFQUM5SSxLQUFLLE1BQU1uQyxLQUFLLElBQUkzQixLQUFLLENBQUM4QyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUluQixLQUFLLENBQUNlLElBQUksQ0FBQ3RDLElBQUksQ0FBQ0MsSUFBSSxLQUFLLFVBQVUsSUFBSUwsS0FBSyxDQUFDNkIsR0FBRyxDQUFDRixLQUFLLENBQUNlLElBQUksQ0FBQ3RDLElBQUksQ0FBQ2lDLGFBQWEsQ0FBQyxFQUFFa0MsWUFBWSxDQUFDakMsR0FBRyxDQUFDWCxLQUFLLENBQUNlLElBQUksQ0FBQ3RDLElBQUksQ0FBQ2lDLGFBQWEsQ0FBQyxDQUFFRSxJQUFJLENBQUNaLEtBQUssQ0FBQ3hILEVBQUUsQ0FBQztFQUN4TCxLQUFLLE1BQU13SCxLQUFLLElBQUkzQixLQUFLLENBQUM4QyxNQUFNLENBQUMsQ0FBQyxFQUFFO0lBQ2xDLElBQUl3QixNQUFNLENBQUNoQyxHQUFHLENBQUNYLEtBQUssQ0FBQ3hILEVBQUUsQ0FBQyxFQUFFO0lBQzFCLE1BQU1zSyxLQUFrRCxHQUFHLENBQUM7TUFBRXRLLEVBQUUsRUFBRXdILEtBQUssQ0FBQ3hILEVBQUU7TUFBRXVLLE9BQU8sRUFBRUgsWUFBWSxDQUFDakMsR0FBRyxDQUFDWCxLQUFLLENBQUN4SCxFQUFFLENBQUU7TUFBRWlJLE1BQU0sRUFBRTtJQUFFLENBQUMsQ0FBQztJQUFFa0MsTUFBTSxDQUFDeEMsR0FBRyxDQUFDSCxLQUFLLENBQUN4SCxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZKLE9BQU9zSyxLQUFLLENBQUN2RyxNQUFNLEVBQUU7TUFDbkIsTUFBTThFLE9BQU8sR0FBR3lCLEtBQUssQ0FBQ0EsS0FBSyxDQUFDdkcsTUFBTSxHQUFHLENBQUMsQ0FBQztNQUFFLElBQUk4RSxPQUFPLENBQUNaLE1BQU0sS0FBS1ksT0FBTyxDQUFDMEIsT0FBTyxDQUFDeEcsTUFBTSxFQUFFO1FBQUVvRyxNQUFNLENBQUN4QyxHQUFHLENBQUNrQixPQUFPLENBQUM3SSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQUVzSyxLQUFLLENBQUNFLEdBQUcsQ0FBQyxDQUFDO1FBQUU7TUFBVTtNQUM1SSxNQUFNQyxRQUFRLEdBQUc1QixPQUFPLENBQUMwQixPQUFPLENBQUMxQixPQUFPLENBQUNaLE1BQU0sRUFBRSxDQUFDO1FBQUV5QixNQUFNLEdBQUc3RCxLQUFLLENBQUNzQyxHQUFHLENBQUNzQyxRQUFRLENBQUM7TUFBRSxJQUFJLENBQUNmLE1BQU0sRUFBRTtNQUMvRixJQUFJUyxNQUFNLENBQUNoQyxHQUFHLENBQUNzQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUV0SCxNQUFNLENBQUNpRixJQUFJLENBQUM7UUFBRWhGLElBQUksRUFBRSwwQkFBMEI7UUFBRU4sSUFBSSxFQUFFLFlBQVkrRixPQUFPLENBQUM3SSxFQUFFLG1CQUFtQjtRQUFFZ0QsT0FBTyxFQUFFO01BQW1CLENBQUMsQ0FBQyxDQUFDLEtBQzNKLElBQUksQ0FBQ21ILE1BQU0sQ0FBQ3pDLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxFQUFFO1FBQUVOLE1BQU0sQ0FBQ3hDLEdBQUcsQ0FBQzhDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFBRUgsS0FBSyxDQUFDbEMsSUFBSSxDQUFDO1VBQUVwSSxFQUFFLEVBQUV5SyxRQUFRO1VBQUVGLE9BQU8sRUFBRUgsWUFBWSxDQUFDakMsR0FBRyxDQUFDdUIsTUFBTSxDQUFDMUosRUFBRSxDQUFFO1VBQUVpSSxNQUFNLEVBQUU7UUFBRSxDQUFDLENBQUM7TUFBRTtJQUM3STtFQUNGO0VBQ0EsT0FBTzlFLE1BQU07QUFDZjs7QUFFQTtBQUNBLE9BQU8sU0FBU3VILHNCQUFzQkEsQ0FBQ0MsSUFBd0IsRUFBRUMsS0FBeUIsRUFBVztFQUNuRyxJQUFJRCxJQUFJLENBQUMzSyxFQUFFLEtBQUs0SyxLQUFLLENBQUM1SyxFQUFFLElBQUkySyxJQUFJLENBQUN6SyxJQUFJLEtBQUswSyxLQUFLLENBQUMxSyxJQUFJLElBQUl5SyxJQUFJLENBQUMxSyxJQUFJLEtBQUsySyxLQUFLLENBQUMzSyxJQUFJLElBQUkwSyxJQUFJLENBQUN4SyxXQUFXLEtBQUt5SyxLQUFLLENBQUN6SyxXQUFXLElBQUl3SyxJQUFJLENBQUN2SyxXQUFXLEtBQUt3SyxLQUFLLENBQUN4SyxXQUFXLEVBQUUsT0FBTyxLQUFLO0VBQ2xMLElBQUl1SyxJQUFJLENBQUN6SyxJQUFJLEtBQUssV0FBVyxJQUFJMEssS0FBSyxDQUFDMUssSUFBSSxLQUFLLFdBQVcsRUFBRSxPQUFPeUssSUFBSSxDQUFDekssSUFBSSxLQUFLMEssS0FBSyxDQUFDMUssSUFBSTtFQUM1RixPQUFPeUssSUFBSSxDQUFDN0csS0FBSyxDQUFDQyxNQUFNLEtBQUs2RyxLQUFLLENBQUM5RyxLQUFLLENBQUNDLE1BQU0sSUFBSTRHLElBQUksQ0FBQzdHLEtBQUssQ0FBQytHLEtBQUssQ0FBQyxDQUFDcEksSUFBSSxFQUFFdUIsQ0FBQyxLQUFLdkIsSUFBSSxDQUFDd0IsTUFBTSxDQUFDRixNQUFNLEtBQUs2RyxLQUFLLENBQUM5RyxLQUFLLENBQUNFLENBQUMsQ0FBQyxDQUFDQyxNQUFNLENBQUNGLE1BQU0sSUFBSXRCLElBQUksQ0FBQ3dCLE1BQU0sQ0FBQzRHLEtBQUssQ0FBQyxDQUFDMUcsS0FBSyxFQUFFRCxDQUFDLEtBQUtDLEtBQUssQ0FBQ2xFLElBQUksS0FBSzJLLEtBQUssQ0FBQzlHLEtBQUssQ0FBQ0UsQ0FBQyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLENBQUNqRSxJQUFJLElBQUlrRSxLQUFLLENBQUNFLElBQUksS0FBS3VHLEtBQUssQ0FBQzlHLEtBQUssQ0FBQ0UsQ0FBQyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLENBQUNHLElBQUksQ0FBQyxDQUFDO0FBQ3hRIiwiaWdub3JlTGlzdCI6W119