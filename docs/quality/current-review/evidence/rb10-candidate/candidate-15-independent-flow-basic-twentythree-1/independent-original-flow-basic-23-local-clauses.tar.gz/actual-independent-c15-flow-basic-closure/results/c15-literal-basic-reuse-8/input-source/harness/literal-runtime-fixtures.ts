import {createEntity,createProject,textToRichText} from '../candidate/src/domain/model';
import {createWorldSnapshot} from '../candidate/src/domain/world';
import type {Entity,EntityDataMap,EntityKind,ProjectData,TypedValue,Condition} from '../candidate/src/domain/types';
import {startTrial} from '../candidate/src/domain/runtime';

function add<K extends EntityKind>(p:ProjectData,kind:K,name:string,data:Partial<EntityDataMap[K]>={}):Entity<K>{
  const e=createEntity(p.projectId,kind,name,data);e.status='confirmed';p.entities.push(e);return e;
}
const boolean=(value:boolean):TypedValue=>({type:'boolean',value});
const integer=(value:number):TypedValue=>({type:'integer',value});
const enumeration=(value:string):TypedValue=>({type:'enum',value});

/** The original F37/F38/F39/F41 values, not a renamed integer-only example. */
export function originalStateWork(){
  const p=createProject('原F37–F41 型・初期化・原因・禁止遷移');
  const affinity=add(p,'variable','好感度',{key:'affinity',valueType:'integer',scope:'run',initial:integer(0),allowed:{min:0,max:10}});
  const alive=add(p,'variable','生存',{key:'life',valueType:'enum',scope:'across_runs',initial:enumeration('存命'),allowed:{values:['存命','死亡']},description:textToRichText('存命と死亡は一つの状態の反対の値')});
  const unsettled=add(p,'variable','まだ宣言していない真偽',{key:'undecided',valueType:'boolean',scope:'run',initial:{type:'unknown',value:null,reason:'作者がまだ決めていない'}});
  const money=add(p,'variable','run所持金10',{key:'money',valueType:'integer',scope:'run',initial:integer(10),allowed:{min:0,max:100}});
  const memory=add(p,'variable','across_runs記憶',{key:'memory',valueType:'boolean',scope:'across_runs',initial:boolean(false)});
  const derived=add(p,'variable','好意は好感度から算出',{key:'liking',valueType:'boolean',scope:'run',initial:{type:'unknown',value:null,reason:'好感度から算出'},derived:{op:'compare',variableId:affinity.id,comparator:'ge',value:integer(5)}});
  const unused=add(p,'variable','未使用Y・外部利用宣言あり',{key:'external_y',valueType:'integer',scope:'across_runs',initial:integer(7),allowed:{},externalUseDeclared:true});
  const questState=add(p,'variable','クエスト状態',{key:'quest_state',valueType:'enum',scope:'run',initial:enumeration('完了'),allowed:{values:['未受注','進行中','完了','失敗']},transitionRules:[
    {from:enumeration('未受注'),to:enumeration('進行中')},
    {from:enumeration('進行中'),to:enumeration('完了')},
    {from:enumeration('進行中'),to:enumeration('失敗')},
  ]});
  const quest=add(p,'quest','完了と制作進捗を分けるクエスト',{key:'q',stateVariableId:questState.id});
  const exceptionEvidence=add(p,'source','再受注の確認済み根拠',{sourceType:'observation',locator:'作者が期限と対象経路を指定した再受注',accessedAt:'2026-10-08T12:00:00.000Z'});
  const keyType=add(p,'item','鍵の種類',{itemMode:'type'}),key=add(p,'item','一つだけの名前付き鍵',{itemMode:'instance',typeId:keyType.id});
  const first=add(p,'scene','状態Xを読んで更新する場面',{body:textToRichText('好感度が変わった理由を確認する😀')});
  const second=add(p,'scene','明示resetの後の場面',{body:textToRichText('合流しただけでは初期化しない。')});
  const entry=add(p,'flow_node','状態と禁止遷移の宣言入口',{nodeType:'entry',sceneId:first.id});
  const merge=add(p,'flow_node','状態Xを読む合流先',{nodeType:'choice',sceneId:second.id});
  const end=add(p,'flow_node','記憶と金額を確認する終端',{nodeType:'terminal',terminalReason:'型と規則の確認を終えた'});
  const setAffinity=add(p,'effect','Xを好感度5へ更新',{operation:'set',targetId:affinity.id,value:integer(5)});
  const setMemory=add(p,'effect','記憶を持ち越す',{operation:'set',targetId:memory.id,value:boolean(true)});
  const addMoney=add(p,'effect','所持金を加算する',{operation:'add',targetId:money.id,value:integer(1)});
  const grant=add(p,'effect','鍵を一個取得する',{operation:'grant',targetId:key.id,instanceId:key.id,value:integer(1)});
  const prohibited=add(p,'effect','完了を未受注へ戻す禁止効果',{operation:'set',targetId:questState.id,value:enumeration('未受注'),reason:'備考だけ'});
  const reset=add(p,'effect','理由付き明示reset',{operation:'reset',targetId:questState.id,value:enumeration('未受注'),reason:'作者が明示して最初からやり直す'});
  // Keep the initial file structurally valid. The normal editor later submits
  // the derived target and must refuse it without altering this saved effect.
  const derivedWrite=add(p,'effect','算出状態への禁止代入を試す入力元',{operation:'set',targetId:memory.id,value:boolean(false)});
  const get=add(p,'flow_edge','好感度5・記憶・所持金11へ進む',{fromId:entry.id,toId:merge.id,label:'好感度5・記憶・所持金11へ進む',effectIds:[setAffinity.id,setMemory.id,addMoney.id]});
  const skip=add(p,'flow_edge','好感度0のまま同じ合流先へ',{fromId:entry.id,toId:merge.id,label:'好感度0のまま同じ合流先へ'});
  const invalid=add(p,'flow_edge','禁止遷移と金額と鍵を一括適用する',{fromId:merge.id,toId:end.id,label:'禁止遷移と金額と鍵を一括適用する',effectIds:[addMoney.id,grant.id,prohibited.id]});
  const resetAffinity=add(p,'effect','Xを明示初期化する原因',{operation:'reset',targetId:affinity.id,value:integer(0),reason:'作者がXの差を明示して解消する'});
  const resetPath=add(p,'flow_edge','理由付きresetだけを明示する',{fromId:merge.id,toId:end.id,label:'理由付きresetだけを明示する',effectIds:[reset.id,resetAffinity.id]});
  const derivedPath=add(p,'flow_edge','算出状態へ直接代入する',{fromId:merge.id,toId:end.id,label:'算出状態へ直接代入する',effectIds:[derivedWrite.id]});
  const finish=add(p,'flow_edge','この差を保って終える',{fromId:merge.id,toId:end.id,label:'この差を保って終える',condition:{op:'compare',variableId:affinity.id,comparator:'ge',value:integer(0)}});
  const graph=add(p,'flow_graph','原型と初期化の図',{nodeIds:[entry.id,merge.id,end.id],edgeIds:[get.id,skip.id,invalid.id,resetPath.id,derivedPath.id,finish.id],entryIds:[entry.id],exitIds:[end.id]});
  return {p,affinity,alive,unsettled,money,memory,derived,unused,questState,quest,exceptionEvidence,keyType,key,first,second,entry,merge,end,setAffinity,setMemory,addMoney,grant,prohibited,reset,resetAffinity,derivedWrite,get,skip,invalid,resetPath,derivedPath,finish,graph};
}

/** Four scenes, three choices, four distinct condition observation sites. */
export function originalCoverageWork(){
  const p=createProject('原F17 場面4・選択肢3・条件4');
  const state=add(p,'variable','条件結果を分ける状態',{key:'condition_bool',valueType:'boolean',scope:'run',initial:boolean(true)});
  const scenes=Array.from({length:4},(_,i)=>add(p,'scene',`原母数の場面${i+1}`,{body:textToRichText(`原母数の本文${i+1}😀`)}));
  const entry=add(p,'flow_node','母数4/3/4の入口',{nodeType:'entry',sceneId:scenes[0].id,gate:{op:'compare',variableId:state.id,comparator:'eq',value:boolean(true)}});
  const a=add(p,'flow_node','二つ目まで確認する場面',{nodeType:'choice',sceneId:scenes[1].id});
  const b=add(p,'flow_node','未選択の第三場面',{nodeType:'terminal',sceneId:scenes[2].id,terminalReason:'未選択の別経路'});
  const end=add(p,'flow_node','四番目の意図終端',{nodeType:'terminal',sceneId:scenes[3].id,terminalReason:'二選択を確認した'});
  const edge1=add(p,'flow_edge','母数の選択肢1',{fromId:entry.id,toId:a.id,label:'母数の選択肢1',condition:{op:'compare',variableId:state.id,comparator:'eq',value:boolean(true)}});
  const edge2=add(p,'flow_edge','母数の選択肢2',{fromId:entry.id,toId:b.id,label:'母数の選択肢2',condition:{op:'constant',value:true}});
  const edge3=add(p,'flow_edge','母数の選択肢3',{fromId:a.id,toId:end.id,label:'母数の選択肢3',condition:{op:'not',child:{op:'compare',variableId:state.id,comparator:'eq',value:boolean(false)}}});
  // Keep exactly four explicit condition sites: entry gate + three edges.
  // Ordinary createEntity supplies a true gate to every node; those three
  // unconditional defaults must be omitted from this original-denominator fixture.
  delete a.data.gate;delete b.data.gate;delete end.data.gate;
  const graph=add(p,'flow_graph','母数を宣言した図',{nodeIds:[entry.id,a.id,b.id,end.id],edgeIds:[edge1.id,edge2.id,edge3.id],entryIds:[entry.id],exitIds:[b.id,end.id]});
  const lines=scenes.map((s,i)=>{const l=add(p,'dialogue_line',`母数の台詞${i+1}`,{text:textToRichText(`母数の台詞本文${i+1}`)});s.data.dialogueLineIds=[l.id];return l;});
  return {p,state,scenes,entry,a,b,end,edge1,edge2,edge3,graph,lines};
}

/** Exact key/affinity checkpoint, plus missing affinity in the same old edition. */
export async function originalCheckpointWork(){
  let p=createProject('原F15 鍵あり・好感度5と値欠落');
  const key=add(p,'variable','鍵あり',{key:'has_key',valueType:'boolean',scope:'run',initial:boolean(false)});
  const affinity=add(p,'variable','好感度',{key:'affinity',valueType:'integer',scope:'run',initial:integer(0),allowed:{min:0,max:10}});
  const entry=add(p,'flow_node','型付き途中開始',{nodeType:'entry'}),end=add(p,'flow_node','途中開始の終端',{nodeType:'terminal',terminalReason:'途中からの状態だけを確認した'});
  const condition:Condition={op:'all',children:[{op:'compare',variableId:key.id,comparator:'eq',value:boolean(true)},{op:'compare',variableId:affinity.id,comparator:'eq',value:integer(5)}]};
  const edge=add(p,'flow_edge','鍵ありかつ好感度5',{fromId:entry.id,toId:end.id,label:'鍵ありかつ好感度5',condition});
  const graph=add(p,'flow_graph','途中開始の図',{nodeIds:[entry.id,end.id],edgeIds:[edge.id],entryIds:[entry.id],exitIds:[end.id]});
  p=await createWorldSnapshot(p,'原F15旧作品版');const pin=p.snapshots.at(-1)!;
  const initial=startTrial(p,{entryId:entry.id,contentVersionId:pin.id,seed:'original-checkpoint-seed'}).startState;
  const state={...structuredClone(initial),provenance:'partial' as const,variableValues:{[key.id]:boolean(true),[affinity.id]:integer(5)}};
  const cp=add(p,'checkpoint','鍵あり・好感度5の途中状態',{contentVersionId:pin.id,contentRevision:pin.content.revision,runtimeState:state,origin:'partial'});
  const missing=add(p,'checkpoint','好感度が欠落した途中状態',{contentVersionId:pin.id,contentRevision:pin.content.revision,runtimeState:{...structuredClone(state),variableValues:{[key.id]:boolean(true)}},origin:'partial'});
  return {p,key,affinity,entry,end,condition,edge,graph,pin,cp,missing};
}
