// 6227506a9853a0007fdbb3be91d5b142ec4fa469
/** Author-only diagnostics. Never include these or idMap in a reader response. */

const text = {
    type: 'text'
  },
  rich = {
    type: 'rich'
  },
  ref = {
    type: 'ref'
  },
  refs = {
    type: 'refs'
  };
const number = {
    type: 'number'
  },
  boolean = {
    type: 'boolean'
  },
  time = {
    type: 'time'
  };
const condition = {
    type: 'condition'
  },
  typed = {
    type: 'typed'
  };
const oneOf = (...values) => ({
  type: 'enum',
  values
});

/** All output fields are enumerated here. Unknown fields are never copied. */
export const PROJECTION_FIELDS = Object.freeze({
  character: {
    reading: text,
    summary: rich,
    body: rich,
    birth: time,
    death: time
  },
  group: {
    groupType: oneOf('display', 'faction', 'plot_thread', 'category'),
    members: refs,
    parentId: ref,
    summary: rich
  },
  event: {
    summary: rich,
    time,
    laneRole: oneOf('common', 'participants', 'both'),
    participants: {
      type: 'participants'
    },
    locationId: ref,
    itemIds: refs
  },
  place: {
    parentId: ref,
    reading: text,
    body: rich,
    mapIds: refs
  },
  item: {
    itemMode: oneOf('type', 'instance'),
    typeId: ref,
    body: rich
  },
  note: {
    body: rich,
    attachmentIds: refs
  },
  chapter: {
    sceneIds: refs,
    summary: rich
  },
  scene: {
    summary: rich,
    body: rich,
    eventIds: refs,
    dialogueLineIds: refs,
    chapterId: ref,
    threadIds: refs,
    povId: ref,
    blockIds: refs,
    tension: number,
    importance: number
  },
  goal: {
    ownerId: ref,
    description: rich,
    changes: refs,
    evidenceSceneIds: refs
  },
  flow_node: {
    nodeType: oneOf('scene', 'choice', 'automatic', 'call', 'entry', 'exit', 'terminal'),
    sceneId: ref,
    childGraphId: ref,
    terminalReason: text,
    trigger: {
      type: 'trigger'
    },
    gate: condition,
    executionPolicy: oneOf('manual_choice', 'first_match', 'all_match'),
    fallbackId: ref,
    shownInformationIds: refs
  },
  flow_edge: {
    fromId: ref,
    toId: ref,
    edgeType: oneOf('choice', 'automatic', 'call_return'),
    label: text,
    condition,
    effectIds: refs,
    priority: number,
    choiceLineId: ref
  },
  flow_graph: {
    nodeIds: refs,
    edgeIds: refs,
    entryIds: refs,
    exitIds: refs,
    parentGraphId: ref,
    parameters: {
      type: 'parameters'
    }
  },
  dialogue_line: {
    text: rich,
    speakerId: ref,
    choiceEdgeId: ref,
    cueIds: refs
  },
  quest: {
    key: text,
    stateVariableId: ref,
    description: rich,
    flowIds: refs,
    transitionRules: {
      type: 'transitions'
    }
  },
  lore: {
    body: rich,
    assertionIds: refs,
    reading: text
  },
  variable: {
    key: text,
    valueType: oneOf('boolean', 'integer', 'enum'),
    scope: oneOf('scene', 'chapter', 'character', 'run', 'across_runs'),
    initial: typed,
    allowed: {
      type: 'allowed'
    },
    ownerId: ref,
    externalContractId: ref,
    externalUseDeclared: boolean,
    description: rich,
    derived: {
      type: 'expression'
    },
    resetRules: {
      type: 'resets'
    },
    exclusions: {
      type: 'exclusions'
    },
    transitionRules: {
      type: 'transitions'
    }
  },
  effect: {
    operation: oneOf('set', 'add', 'grant', 'consume', 'move', 'assert', 'mark_seen', 'reset'),
    targetId: ref,
    value: typed,
    condition,
    instanceId: ref,
    reason: text,
    exceptionDetails: {
      type: 'exception'
    }
  },
  assertion: {
    subjectId: ref,
    predicate: text,
    value: typed,
    truthKind: oneOf('author_truth', 'testimony', 'belief', 'hypothesis'),
    holderId: ref,
    sourceIds: refs,
    evidenceLocation: {
      type: 'anchor'
    },
    reason: text,
    validity: {
      type: 'validity'
    }
  },
  foreshadow: {
    question: rich,
    intent: rich,
    truthAssertionIds: refs,
    clueIds: refs,
    payoffIds: refs,
    requiredInfo: refs,
    alternativeInfo: {
      type: 'alternatives'
    },
    deadline: {
      type: 'scope'
    },
    exceptions: {
      type: 'exceptions'
    },
    presentationDeadline: {
      type: 'anchor'
    },
    resolutionPolicy: oneOf('this_work', 'sequel', 'intentional_open', 'red_herring', 'undecided', 'rejected')
  },
  disclosure: {
    foreshadowId: ref,
    anchor: {
      type: 'anchor'
    },
    stage: oneOf('hint', 'suspicion', 'reinforce', 'reveal', 'alternative'),
    role: oneOf('clue', 'payoff'),
    targetScope: {
      type: 'scope'
    },
    condition,
    knowledgeEffects: refs
  },
  attachment: {
    displayName: text
  },
  source: {
    accessedAt: {
      type: 'datetime'
    },
    excerptLocation: text,
    attachmentId: ref,
    sourceType: oneOf('web', 'file', 'book', 'observation'),
    locator: text,
    interpretation: rich,
    redistributionAllowed: boolean
  },
  cue: {
    anchor: {
      type: 'anchor'
    },
    cueType: text,
    attachmentId: ref,
    speakerId: ref,
    expression: text,
    waitMs: number,
    mediaTime: number,
    camera: {
      type: 'camera'
    }
  },
  storyboard_frame: {
    anchor: {
      type: 'anchor'
    },
    mediaStartMs: number,
    mediaEndMs: number,
    referenceAssetId: ref,
    finalAssetId: ref,
    cueIds: refs,
    caption: rich
  },
  localization: {
    sourceLineId: ref,
    language: text,
    text: rich,
    stage: oneOf('draft', 'reviewed', 'needs_review'),
    recordingIds: refs
  },
  recording: {
    sourceLineId: ref,
    language: text,
    translationId: ref,
    attachmentId: ref,
    stage: oneOf('planned', 'recorded', 'reviewed', 'needs_review')
  },
  terminology: {
    canonical: text,
    reading: text,
    variants: {
      type: 'public_strings'
    },
    validity: {
      type: 'validity'
    },
    exceptions: {
      type: 'exceptions'
    },
    language: text,
    usageNotes: rich,
    voiceOwnerId: ref
  },
  voice_rule: {
    characterId: ref,
    validity: {
      type: 'validity'
    },
    firstPerson: text,
    addressing: text,
    phrasing: text,
    examples: rich,
    exceptions: {
      type: 'exceptions'
    }
  },
  map: {
    placeId: ref,
    coordinateSystem: oneOf('normalized'),
    attachmentId: ref,
    parentMapId: ref,
    pins: {
      type: 'pins'
    }
  },
  travel_route: {
    fromPlaceId: ref,
    toPlaceId: ref,
    direction: oneOf('one_way', 'two_way'),
    method: text
  },
  collection: {
    mode: oneOf('fixed'),
    memberIds: refs
  },
  gameplay_spec: {
    sceneId: ref,
    action: rich,
    mechanic: text,
    tutorial: rich,
    reward: typed,
    questId: ref,
    taskIds: refs,
    intentionalDifference: text
  },
  production_task: {
    deadline: {
      type: 'real_date'
    },
    estimate: {
      type: 'estimate'
    },
    blockingReason: text,
    targetIds: refs,
    stage: oneOf('writing', 'review', 'implementation', 'translation', 'recording', 'verification', 'publication'),
    progress: oneOf('todo', 'doing', 'done', 'needs_review'),
    dependsOn: refs
  },
  media_variant: {
    medium: oneOf('game', 'novel', 'video', 'audio', 'promotion', 'custom'),
    baseSnapshotId: {
      type: 'version_ref'
    },
    previousVariantId: ref,
    releaseAt: {
      type: 'datetime'
    },
    body: rich,
    sourceIds: refs,
    needsReview: boolean
  },
  external_contract: {
    key: text,
    owner: oneOf('tool', 'game'),
    inputType: oneOf('boolean', 'integer', 'enum'),
    outputType: oneOf('boolean', 'integer', 'enum'),
    missingPolicy: oneOf('unknown', 'block'),
    description: rich,
    version: {
      type: 'semver'
    },
    stubValues: {
      type: 'typeds'
    }
  }
});
export const PROJECTABLE_KINDS = Object.freeze(Object.keys(PROJECTION_FIELDS));
const BEHAVIOR_REFS = new Set(['fromId', 'toId', 'effectIds', 'nodeIds', 'edgeIds', 'entryIds', 'exitIds', 'childGraphId', 'fallbackId', 'targetId', 'instanceId', 'stateVariableId', 'externalContractId', 'shownInformationIds', 'knowledgeEffects']);
const FORBIDDEN_FIELDS = new Set(['handoffReceipt', 'authorNotes', 'aliases', 'quotedText', 'originLineIds', 'replacedByLineIds', 'lineage', 'customValues', 'assetPath', 'licenseNote', 'history', 'query', 'sourceHash']);
const BLOCK_KINDS = new Set(['paragraph', 'heading', 'list_item', 'quote']);
const ASSET_TYPES = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/gif': 'gif',
  'image/webp': 'webp',
  'audio/wav': 'wav',
  'audio/mpeg': 'mp3',
  'application/pdf': 'pdf',
  'video/mp4': 'mp4',
  'video/webm': 'webm',
  'video/ogg': 'ogv',
  'audio/ogg': 'ogg',
  'text/plain': 'txt',
  'application/json': 'json',
  'application/octet-stream': 'bin'
};
const TICK = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/;
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value) ? value : undefined;
const own = (value, key) => value && Object.prototype.hasOwnProperty.call(value, key) ? value[key] : undefined;
const hasOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const empty = value => value == null || value === '' || Array.isArray(value) && value.length === 0;
const integer = value => typeof value === 'number' && Number.isSafeInteger(value);

/** Pure, fail-closed projection. Public prose is supplied by the author; this is not a text redactor. */
export function createProjection(project, profileId, options = {}) {
  var _object, _object2, _object3, _object7;
  const issues = [],
    omissions = [];
  if (!project || !Array.isArray(project.entities) || !Array.isArray(project.relations) || project.entities.some(entity => !entity || typeof entity.id !== 'string' || !object(entity.data))) return {
    ok: false,
    issues: [{
      code: 'VALIDATION_FAILED',
      message: '作品の公開元データが不正です。'
    }],
    omissions
  };
  const fail = (code, message, entityId, field) => {
    issues.push({
      code,
      message,
      ...(entityId ? {
        entityId
      } : {}),
      ...(field ? {
        field
      } : {})
    });
  };
  const omit = (entityId, reason, field) => {
    omissions.push({
      entityId,
      reason,
      ...(field ? {
        field
      } : {})
    });
  };
  const source = new Map();
  for (const entity of project.entities) {
    if (source.has(entity.id)) fail('VALIDATION_FAILED', '同じIDの情報が重複しています。', entity.id);
    source.set(entity.id, entity);
  }
  const profile = source.get(profileId);
  if (!profile || profile.kind !== 'projection_profile' || profile.projectId !== project.projectId || profile.deletedAt) {
    return {
      ok: false,
      issues: [{
        code: 'REFERENCE_INVALID',
        message: 'この作品の公開範囲を選んでください。',
        entityId: profileId
      }],
      omissions
    };
  }
  const policy = profile.data;
  if (policy.sourceVersionId != null && policy.sourceVersionId !== options.targetVersionId && policy.sourceVersionId !== project.revision) fail('VALIDATION_FAILED', '公開範囲が固定された版と出力元の版が一致しません。', profileId, 'sourceVersionId');
  if (((_object = object(policy.routeScope)) === null || _object === void 0 ? void 0 : _object.targetSnapshotId) != null && object(policy.routeScope).targetSnapshotId !== options.targetVersionId) fail('VALIDATION_FAILED', '公開範囲の対象snapshotを読み込んでください。', profileId, 'routeScope.targetSnapshotId');
  if (policy.idPolicy != null && !['remap', 'preserve'].includes(String(policy.idPolicy))) fail('VALIDATION_FAILED', '公開IDの方式が不正です。', profileId, 'idPolicy');
  if (policy.includeAuthorNotes === true) fail('FORBIDDEN', '公開用出力に作者メモは含められません。', profileId, 'includeAuthorNotes');
  const title = own(policy, 'publicTitle');
  if (typeof title !== 'string' || !title.trim()) fail('PUBLIC_TEXT_REQUIRED', '作者が確認した公開用の作品名を指定してください。', profileId, 'publicTitle');
  const includedIds = own(policy, 'includedIds'),
    allowedKinds = own(policy, 'allowedKinds');
  if (!Array.isArray(includedIds) || includedIds.some(id => typeof id !== 'string') || new Set(includedIds).size !== includedIds.length) fail('VALIDATION_FAILED', '公開するIDを重複のない一覧で指定してください。', profileId, 'includedIds');
  if (!Array.isArray(allowedKinds) || allowedKinds.length === 0 || allowedKinds.some(kind => typeof kind !== 'string' || !hasOwn(PROJECTION_FIELDS, kind))) fail('EXPORT_UNSUPPORTED', '公開可能な種類だけを明示的に選んでください。', profileId, 'allowedKinds');
  const publicTexts = (_object2 = object(own(policy, 'publicTexts'))) !== null && _object2 !== void 0 ? _object2 : {};
  const publicIds = (_object3 = object(own(policy, 'publicIds'))) !== null && _object3 !== void 0 ? _object3 : {};
  const namePolicies = object(own(policy, 'namePolicy'));
  const scopeIds = scopedEntityIds(source, policy, project.projectId, publicTexts, fail);
  const statuses = Array.isArray(policy.includedStatuses) ? policy.includedStatuses : ['confirmed'];
  if (statuses.some(status => !['confirmed', 'provisional', 'needs_review'].includes(String(status)))) fail('FORBIDDEN', '没案と作者別案は公開対象にできません。', profileId, 'includedStatuses');
  const selected = [];
  const names = new Map();
  const explicitPublicIds = new Map();
  const included = new Set(Array.isArray(includedIds) ? includedIds : []);
  // Selection is a set; the chosen content version owns the presentation order.
  const orderedIds = [...source.keys()].filter(id => included.has(id));
  for (const id of included) if (!source.has(id)) orderedIds.push(id);
  for (const id of orderedIds) {
    var _object4, _object5, _ref, _object6;
    const entity = source.get(id);
    if (!entity || entity.projectId !== project.projectId) {
      fail('REFERENCE_INVALID', '作品内にない情報が公開範囲に含まれています。', id);
      continue;
    }
    if (scopeIds && !scopeIds.has(id)) {
      omit(id, '指定した章またはグラフの範囲外');
      continue;
    }
    if (entity.deletedAt || !statuses.includes(entity.status) || options.confirmedOnly && entity.status !== 'confirmed') {
      omit(id, '削除済み、未確定、没案または別案');
      continue;
    }
    if (!Array.isArray(allowedKinds) || !allowedKinds.includes(entity.kind)) {
      omit(id, '許可されていない種類');
      continue;
    }
    if (!hasOwn(PROJECTION_FIELDS, entity.kind)) {
      fail('EXPORT_UNSUPPORTED', 'この種類の安全な投影は未対応です。', id);
      continue;
    }
    if (['scene', 'flow_node'].includes(entity.kind) && ((_object4 = object(entity.data.reuse)) === null || _object4 === void 0 ? void 0 : _object4.mode) !== undefined && ((_object5 = object(entity.data.reuse)) === null || _object5 === void 0 ? void 0 : _object5.mode) !== 'clone') {
      fail('EXPORT_UNSUPPORTED', '固定共通元と使用先を合わせた公開範囲・公開名・本文を確認する出力は未対応です。再利用を省略した出力は作成できません。', id, 'reuse');
      continue;
    }
    const byEntityId = object(own(namePolicies, 'byEntityId'));
    const namePolicy = (_ref = (_object6 = object(own(byEntityId, id))) !== null && _object6 !== void 0 ? _object6 : object(own(namePolicies, 'defaultPolicy'))) !== null && _ref !== void 0 ? _ref : typeof (namePolicies === null || namePolicies === void 0 ? void 0 : namePolicies.mode) === 'string' ? namePolicies : undefined;
    if ((namePolicy === null || namePolicy === void 0 ? void 0 : namePolicy.mode) === 'exclude') {
      omit(id, '作者が非公開を選択');
      continue;
    }
    let publicName;
    if ((namePolicy === null || namePolicy === void 0 ? void 0 : namePolicy.mode) === 'replace') publicName = namePolicy.replacement;else if ((namePolicy === null || namePolicy === void 0 ? void 0 : namePolicy.mode) === 'anonymize') {
      publicName = namePolicy.publicName;
      if (typeof namePolicy.publicId === 'string') explicitPublicIds.set(id, namePolicy.publicId);
    } else if ((namePolicy === null || namePolicy === void 0 ? void 0 : namePolicy.mode) === 'alias') {
      const aliases = Array.isArray(entity.data.aliases) ? entity.data.aliases : [];
      const alias = aliases.map(object).find(value => (value === null || value === void 0 ? void 0 : value.id) === namePolicy.aliasId);
      publicName = alias === null || alias === void 0 ? void 0 : alias.text;
    } else if (entity.name === '') publicName = '';
    if (typeof publicName !== 'string' || entity.name !== '' && !publicName.trim()) {
      fail('PUBLIC_TEXT_REQUIRED', 'この情報の公開名または公開別名を指定してください。', id, 'namePolicy');
      continue;
    }
    names.set(id, publicName);
    selected.push(entity);
  }
  const idMap = Object.create(null);
  const emittedIds = new Set();
  let sequence = 0;
  const addId = id => {
    var _ref2, _explicitPublicIds$ge;
    if (Object.prototype.hasOwnProperty.call(idMap, id)) return;
    const candidate = (_ref2 = (_explicitPublicIds$ge = explicitPublicIds.get(id)) !== null && _explicitPublicIds$ge !== void 0 ? _explicitPublicIds$ge : own(publicIds, id)) !== null && _ref2 !== void 0 ? _ref2 : policy.idPolicy === 'preserve' ? id : `public-${String(++sequence).padStart(6, '0')}`;
    if (typeof candidate !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(candidate) || emittedIds.has(candidate)) {
      fail('VALIDATION_FAILED', '公開IDが不正、または重複しています。', id, 'publicIds');
      return;
    }
    idMap[id] = candidate;
    emittedIds.add(candidate);
  };
  selected.forEach(entity => addId(entity.id));
  // Public block IDs belong to the author-provided documents, never to hidden source documents.
  const allowedFields = object(own(policy, 'allowedFields'));
  const excludedFields = Array.isArray(policy.excludedFields) ? policy.excludedFields : [];
  const publicBlockIds = new Set();
  const publicBlockOwners = new Map(),
    sourceBlockOwners = new Map();
  for (const entity of selected) {
    for (const value of Object.values(entity.data)) if (Array.isArray(value)) for (const raw of value) {
      const block = object(raw);
      if (typeof (block === null || block === void 0 ? void 0 : block.id) === 'string' && typeof block.text === 'string') sourceBlockOwners.set(block.id, entity.id);
    }
    const fields = object(own(publicTexts, entity.id));
    const schema = PROJECTION_FIELDS[entity.kind];
    const explicit = own(allowedFields, entity.kind);
    for (const [field, rule] of Object.entries(schema)) if (rule.type === 'rich' && (!Array.isArray(explicit) || explicit.includes(field)) && !excludedFields.includes(field) && !excludedFields.includes(`${entity.kind}.${field}`) && Array.isArray(own(fields, field))) {
      for (const block of fields[field]) {
        const record = object(block);
        if (typeof (record === null || record === void 0 ? void 0 : record.id) === 'string') {
          if (source.has(record.id) || publicBlockIds.has(record.id)) fail('VALIDATION_FAILED', '公開文の段落IDが他の情報と重複しています。', entity.id, field);else {
            publicBlockIds.add(record.id);
            publicBlockOwners.set(record.id, entity.id);
            addId(record.id);
          }
        }
      }
    }
    const trigger = object(entity.data.trigger);
    if (entity.kind === 'flow_node' && typeof (trigger === null || trigger === void 0 ? void 0 : trigger.id) === 'string') addId(trigger.id);
  }
  const selectedIds = new Set(selected.map(entity => entity.id));
  const blockSources = (_object7 = object(policy.blockSources)) !== null && _object7 !== void 0 ? _object7 : {};
  for (const [publicBlock, sourceBlock] of Object.entries(blockSources)) {
    if (typeof sourceBlock !== 'string' || !publicBlockIds.has(publicBlock) || !idMap[publicBlock] || sourceBlockOwners.get(sourceBlock) !== publicBlockOwners.get(publicBlock)) {
      fail('REFERENCE_INVALID', '公開段落の元ID対応が不正です。', profileId, 'blockSources');
      continue;
    }
    if (idMap[sourceBlock] && idMap[sourceBlock] !== idMap[publicBlock]) {
      fail('REFERENCE_INVALID', '同じ原段落に複数の公開位置が指定されています。', profileId, 'blockSources');
      continue;
    }
    idMap[sourceBlock] = idMap[publicBlock];
  }
  const calendars = [],
    calendarIds = new Map();
  const publicCalendarId = (value, entity, field) => {
    if (typeof value !== 'string') {
      fail('REFERENCE_INVALID', '日時が使う暦を指定してください。', entity.id, field);
      return undefined;
    }
    if (calendarIds.has(value)) return calendarIds.get(value);
    const sourceCalendar = project.calendars.find(calendar => calendar.id === value);
    if (!sourceCalendar || !['gregorian', 'repeating'].includes(sourceCalendar.kind) || !TICK.test(sourceCalendar.ticksPerDay) || BigInt(sourceCalendar.ticksPerDay) <= 0n) {
      fail('REFERENCE_INVALID', '日時が使う暦を安全に出力できません。', entity.id, field);
      return undefined;
    }
    let publicId = `public-calendar-${calendars.length + 1}`;
    while (emittedIds.has(publicId)) publicId += '-calendar';
    emittedIds.add(publicId);
    const calendar = {
      id: publicId,
      name: `暦${calendars.length + 1}`,
      kind: sourceCalendar.kind,
      originLabel: '原点',
      ticksPerDay: sourceCalendar.ticksPerDay
    };
    if (sourceCalendar.kind === 'repeating') {
      if (!Array.isArray(sourceCalendar.years) || !sourceCalendar.years.length || sourceCalendar.years.length > 400) {
        fail('EXPORT_UNSUPPORTED', '繰り返し暦の周期を安全に出力できません。', entity.id, field);
        return undefined;
      }
      calendar.years = [];
      for (const year of sourceCalendar.years) {
        if (!Array.isArray(year.months) || !year.months.length || year.months.length > 24 || year.months.some(month => !integer(month.days) || month.days < 1 || month.days > 400)) {
          fail('EXPORT_UNSUPPORTED', '繰り返し暦の月を安全に出力できません。', entity.id, field);
          return undefined;
        }
        calendar.years.push({
          months: year.months.map((month, index) => ({
            name: `月${index + 1}`,
            days: month.days
          }))
        });
      }
    }
    calendarIds.set(value, publicId);
    calendars.push(calendar);
    return publicId;
  };
  const reference = (value, entity, field, mandatory = false) => {
    if (value == null) return undefined;
    if (typeof value === 'string' && selectedIds.has(value) && Object.prototype.hasOwnProperty.call(idMap, value)) return idMap[value];
    if (typeof value === 'string' && Object.prototype.hasOwnProperty.call(idMap, value) && field.includes('block')) return idMap[value];
    if (mandatory || options.strictReferences) fail('REFERENCE_INVALID', '公開範囲にない参照先が必要です。範囲または代替文を見直してください。', entity.id, field);else omit(entity.id, '公開範囲にない参照を除外', field);
    return undefined;
  };
  const mapEnum = (value, variableId, entity, field) => {
    const replacements = object(own(object(own(policy, 'publicValues')), variableId));
    const replacement = typeof value === 'string' ? own(replacements, value) : undefined;
    if (typeof replacement !== 'string') {
      fail('PUBLIC_TEXT_REQUIRED', '列挙値の公開用表記を指定してください。', entity.id, field);
      return undefined;
    }
    return replacement;
  };
  const typedValue = (value, variableId, entity, field) => {
    if (typeof value === 'string' && entity.kind === 'assertion') {
      const mapped = reference(value, entity, field, true);
      return mapped;
    }
    const input = object(value);
    if (!input) {
      fail('VALIDATION_FAILED', '型付きの値が必要です。', entity.id, field);
      return undefined;
    }
    if (input.type === 'boolean' && typeof input.value === 'boolean') return {
      type: 'boolean',
      value: input.value
    };
    if (input.type === 'integer' && integer(input.value)) return {
      type: 'integer',
      value: input.value
    };
    if (input.type === 'enum') {
      const mapped = mapEnum(input.value, variableId, entity, field);
      return mapped === undefined ? undefined : {
        type: 'enum',
        value: mapped
      };
    }
    if (input.type === 'ref') {
      const mapped = reference(input.value, entity, field, true);
      return mapped ? {
        type: 'ref',
        value: mapped
      } : undefined;
    }
    fail('EXPORT_UNSUPPORTED', '未確定値や自由文字列の値は安全な制作出力に対応していません。', entity.id, field);
    return undefined;
  };
  const conditionValue = (input, entity, field) => {
    let nodes = 0;
    const visit = (value, depth) => {
      const ast = object(value);
      if (!ast || depth > 16 || ++nodes > 256) {
        fail('EXPORT_UNSUPPORTED', '条件の形または深さが対応範囲を超えています。', entity.id, field);
        return undefined;
      }
      const requiredRef = key => reference(ast[key], entity, `${field}.${key}`, true);
      switch (ast.op) {
        case 'constant':
          if (typeof ast.value === 'boolean') return {
            op: 'constant',
            value: ast.value
          };
          break;
        case 'all':
        case 'any':
          {
            if (!Array.isArray(ast.children) || ast.children.length === 0) break;
            const children = ast.children.map(child => visit(child, depth + 1));
            return children.every(child => child !== undefined) ? {
              op: ast.op,
              children: children
            } : undefined;
          }
        case 'not':
          {
            const child = visit(ast.child, depth + 1);
            return child === undefined ? undefined : {
              op: 'not',
              child
            };
          }
        case 'compare':
          {
            const variableId = requiredRef('variableId');
            const variable = typeof ast.variableId === 'string' ? source.get(ast.variableId) : undefined;
            const comparator = ast.comparator;
            if (!variable || variable.kind !== 'variable' || !['eq', 'ne', 'lt', 'le', 'gt', 'ge', 'in'].includes(String(comparator))) break;
            let compared;
            if (comparator === 'in' && Array.isArray(ast.value)) {
              const values = ast.value.map(item => typedValue(item, variable.id, entity, field));
              if (values.every(item => item !== undefined)) compared = values;
            } else compared = typedValue(ast.value, variable.id, entity, field);
            if (variableId && compared !== undefined) return {
              op: 'compare',
              variableId,
              comparator: String(comparator),
              value: compared
            };
            return undefined;
          }
        case 'item':
          {
            const itemId = requiredRef('itemId');
            if (itemId && integer(ast.quantity) && ast.quantity >= 0) return {
              op: 'item',
              itemId,
              quantity: ast.quantity
            };
            break;
          }
        case 'known':
          {
            const assertionId = requiredRef('assertionId'),
              holderId = requiredRef('holderId');
            if (assertionId && holderId) return {
              op: 'known',
              assertionId,
              holderId
            };
            return undefined;
          }
        case 'visited':
          {
            const entityId = requiredRef('entityId');
            if (entityId && integer(ast.count) && ast.count >= 0) return {
              op: 'visited',
              entityId,
              count: ast.count
            };
            break;
          }
        case 'external':
          {
            const contractId = requiredRef('contractId');
            if (contractId) return {
              op: 'external',
              contractId
            };
            return undefined;
          }
      }
      fail('EXPORT_UNSUPPORTED', 'この条件は対応先で安全に表せません。', entity.id, field);
      return undefined;
    };
    return visit(input, 1);
  };
  const publicField = (entity, field) => own(object(own(publicTexts, entity.id)), field);
  const textValue = (entity, field) => {
    const value = publicField(entity, field);
    if (typeof value === 'string') return value;
    if (!empty(entity.data[field])) fail('PUBLIC_TEXT_REQUIRED', '原文の安全性は自動判定できません。公開用の文面を指定するか、この項目を除外してください。', entity.id, field);
    return undefined;
  };
  const anchorValue = (value, entity, field) => {
    var _options$versionTarge, _fixed$idMap;
    const input = object(value);
    if (!input) {
      fail('VALIDATION_FAILED', '本文位置が不正です。', entity.id, field);
      return undefined;
    }
    if (input.positionStatus === 'unresolved') {
      if (options.strictReferences) fail('REFERENCE_INVALID', '公開する本文位置の再リンクが必要です。', entity.id, field);else omit(entity.id, '位置不明の本文参照を除外', field);
      return undefined;
    }
    const fixed = input.sourceVersionId && input.sourceVersionId !== project.projectId && input.sourceVersionId !== options.targetVersionId ? (_options$versionTarge = options.versionTargets) === null || _options$versionTarge === void 0 ? void 0 : _options$versionTarge[String(input.sourceVersionId)] : undefined;
    if (input.sourceVersionId && input.sourceVersionId !== project.projectId && input.sourceVersionId !== options.targetVersionId && !fixed) {
      fail('EXPORT_UNSUPPORTED', '別の固定版を指す位置には、その版の公開範囲確認が必要です。黙って現在位置へ移しません。', entity.id, field);
      return undefined;
    }
    const targetMap = (_fixed$idMap = fixed === null || fixed === void 0 ? void 0 : fixed.idMap) !== null && _fixed$idMap !== void 0 ? _fixed$idMap : idMap,
      targetId = fixed ? targetMap[String(input.entityId)] : reference(input.entityId, entity, field, true);
    if (!targetId) {
      fail('REFERENCE_INVALID', '引用固定版の公開対象がありません。', entity.id, field);
      return undefined;
    }
    const output = {
      entityId: targetId,
      ...(fixed ? {
        sourceVersionId: fixed.publicVersionId
      } : {})
    };
    for (const key of ['blockId', 'lineId']) if (input[key] != null) {
      const sourceId = input[key];
      if (typeof sourceId !== 'string' || !Object.prototype.hasOwnProperty.call(targetMap, sourceId)) {
        if (options.strictReferences) fail('REFERENCE_INVALID', '公開文に存在しない位置への参照です。', entity.id, field);else omit(entity.id, '非公開の本文位置を除外', field);
        return undefined;
      }
      output[key] = targetMap[sourceId];
    }
    if (integer(input.start) && integer(input.end) && input.start >= 0 && input.end >= input.start) {
      output.start = input.start;
      output.end = input.end;
    }
    return output;
  };
  const richValue = (entity, field) => {
    const input = publicField(entity, field);
    if (typeof input === 'string') return [{
      id: `${idMap[entity.id]}.${field}`,
      kind: 'paragraph',
      text: input
    }];
    if (!Array.isArray(input)) {
      if (!empty(entity.data[field])) fail('PUBLIC_TEXT_REQUIRED', '公開用の本文を指定してください。原文の秘密は自動で除けません。', entity.id, field);
      return undefined;
    }
    const output = [];
    for (const raw of input) {
      const block = object(raw);
      if (!block || typeof block.id !== 'string' || !idMap[block.id] || !BLOCK_KINDS.has(String(block.kind)) || typeof block.text !== 'string') {
        fail('VALIDATION_FAILED', '公開文の段落が不正です。', entity.id, field);
        continue;
      }
      const projected = {
        id: idMap[block.id],
        kind: String(block.kind),
        text: block.text
      };
      if (Array.isArray(block.unresolvedAnnotations) && block.unresolvedAnnotations.length) omit(entity.id, '再リンク待ちの本文注記を除外', field);
      const length = [...block.text].length;
      const validRange = range => integer(range.start) && integer(range.end) && range.start >= 0 && range.end > range.start && range.end <= length;
      if (Array.isArray(block.ruby)) {
        const ruby = [];
        for (const rawRuby of block.ruby) {
          const range = object(rawRuby);
          if (!range || !validRange(range) || typeof range.text !== 'string') {
            fail('VALIDATION_FAILED', '公開文のルビ範囲が不正です。', entity.id, field);
            continue;
          }
          ruby.push({
            start: range.start,
            end: range.end,
            text: range.text
          });
        }
        projected.ruby = ruby;
      }
      if (Array.isArray(block.links)) {
        const links = [];
        for (const rawLink of block.links) {
          var _object8, _options$versionTarge2, _fixed$idMap2, _target$targetId, _target$targetId2, _fixed$publicVersionI;
          const range = object(rawLink);
          if (!range || !validRange(range)) {
            fail('VALIDATION_FAILED', '公開文のリンク範囲が不正です。', entity.id, field);
            continue;
          }
          const target = (_object8 = object(range.target)) !== null && _object8 !== void 0 ? _object8 : range;
          if (target.positionStatus === 'unresolved') {
            if (options.strictReferences) fail('REFERENCE_INVALID', '公開文のリンク先位置の再リンクが必要です。', entity.id, field);else omit(entity.id, '位置不明のリンクを除外', field);
            continue;
          }
          const fixed = target.sourceVersionId && target.sourceVersionId !== project.projectId && target.sourceVersionId !== options.targetVersionId ? (_options$versionTarge2 = options.versionTargets) === null || _options$versionTarge2 === void 0 ? void 0 : _options$versionTarge2[String(target.sourceVersionId)] : undefined,
            targetMap = (_fixed$idMap2 = fixed === null || fixed === void 0 ? void 0 : fixed.idMap) !== null && _fixed$idMap2 !== void 0 ? _fixed$idMap2 : idMap;
          if (target.sourceVersionId && target.sourceVersionId !== project.projectId && target.sourceVersionId !== options.targetVersionId && !fixed) {
            fail('EXPORT_UNSUPPORTED', '公開リンクには別の固定版の公開確認が必要です。現在位置へ代用しません。', entity.id, field);
            continue;
          }
          const targetId = fixed ? targetMap[String((_target$targetId = target.targetId) !== null && _target$targetId !== void 0 ? _target$targetId : target.entityId)] : reference((_target$targetId2 = target.targetId) !== null && _target$targetId2 !== void 0 ? _target$targetId2 : target.entityId, entity, `${field}.links`);
          if (!targetId) continue;
          const link = {
            start: range.start,
            end: range.end,
            targetId
          };
          if (target.sourceVersionId) link.sourceVersionId = (_fixed$publicVersionI = fixed === null || fixed === void 0 ? void 0 : fixed.publicVersionId) !== null && _fixed$publicVersionI !== void 0 ? _fixed$publicVersionI : 'public-project';
          if (integer(target.start) && integer(target.end)) {
            link.targetStart = target.start;
            link.targetEnd = target.end;
          }
          let valid = true;
          for (const key of ['blockId', 'lineId']) if (target[key] != null) {
            const origin = target[key];
            if (typeof origin !== 'string' || !Object.prototype.hasOwnProperty.call(targetMap, origin)) {
              if (options.strictReferences) fail('REFERENCE_INVALID', '公開文に存在しない位置へのリンクです。', entity.id, field);else omit(entity.id, '非公開の位置へのリンクを除外', field);
              valid = false;
              break;
            }
            link[key] = targetMap[origin];
          }
          if (valid) links.push(link);
        }
        if (links.length) projected.links = links;
      }
      output.push(projected);
    }
    return output;
  };
  const behaviorText = (entity, field) => {
    const value = textValue(entity, field);
    return value !== null && value !== void 0 ? value : '';
  };
  const scopeValue = (value, entity, field) => {
    const input = object(value);
    if (!input || input.projectId !== project.projectId) {
      fail('REFERENCE_INVALID', '対象作品の範囲を公開先へ対応できません。', entity.id, field);
      return;
    }
    const output = {
      projectId: 'public-project'
    };
    for (const key of ['graphId', 'chapterId']) if (input[key] != null) {
      const mapped = reference(input[key], entity, field, true);
      if (!mapped) return;
      output[key] = mapped;
    }
    if (input.targetSnapshotId != null) {
      if (input.targetSnapshotId !== project.projectId && input.targetSnapshotId !== options.targetVersionId) {
        fail('EXPORT_UNSUPPORTED', '別版限定の範囲を現在版へ代用しません。', entity.id, field);
        return;
      }
      output.targetSnapshotId = 'public-project';
    }
    if (input.routeCondition != null) {
      const mapped = conditionValue(input.routeCondition, entity, field);
      if (!mapped) return;
      output.routeCondition = mapped;
    }
    return output;
  };
  const validityValue = (value, entity, field) => {
    const input = object(value);
    if (!input) return;
    let range = null;
    if (input.worldRange != null) {
      const raw = object(input.worldRange);
      if (!raw || ['start', 'end'].some(key => raw[key] !== null && (typeof raw[key] !== 'string' || !TICK.test(String(raw[key]))))) {
        fail('VALIDATION_FAILED', '期間の整数tickが不正です。', entity.id, field);
        return;
      }
      range = {
        start: raw.start,
        end: raw.end
      };
    }
    const route = input.routeCondition == null ? null : conditionValue(input.routeCondition, entity, field),
      anchor = input.presentationAnchor == null ? null : anchorValue(input.presentationAnchor, entity, field);
    if (route === undefined || anchor === undefined) return;
    return {
      worldRange: range,
      routeCondition: route,
      presentationAnchor: anchor
    };
  };
  const exceptionValue = (value, entity, field) => {
    const input = object(value);
    if (!input) return;
    const target = scopeValue(input.targetScope, entity, field),
      validity = validityValue(input.validity, entity, field);
    if (!target || !validity || !Array.isArray(input.evidenceIds)) return;
    const evidence = input.evidenceIds.map(id => reference(id, entity, field, true));
    if (evidence.some(id => !id)) return;
    const reason = behaviorText(entity, 'exceptionReason');
    if (!reason.trim()) {
      fail('PUBLIC_TEXT_REQUIRED', '有限例外の公開用理由を指定してください。', entity.id, field);
      return;
    }
    return {
      reason,
      targetScope: target,
      validity,
      evidenceIds: evidence
    };
  };
  const expressionValue = (value, entity, field, depth = 0) => {
    if (depth > 64) {
      fail('EXPORT_UNSUPPORTED', '算出式の上限を超えています。', entity.id, field);
      return;
    }
    const input = object(value);
    if (!input) return;
    if (input.op === 'value') {
      const mapped = typedValue(input.value, entity.id, entity, field);
      return mapped ? {
        op: 'value',
        value: mapped
      } : undefined;
    }
    if (input.op === 'variable') {
      const id = reference(input.variableId, entity, field, true);
      return id ? {
        op: 'variable',
        variableId: id
      } : undefined;
    }
    if (['add', 'subtract', 'multiply'].includes(String(input.op))) {
      const left = expressionValue(input.left, entity, field, depth + 1),
        right = expressionValue(input.right, entity, field, depth + 1);
      return left && right ? {
        op: String(input.op),
        left,
        right
      } : undefined;
    }
    if (input.op === 'if') {
      const condition = conditionValue(input.condition, entity, field),
        yes = expressionValue(input.then, entity, field, depth + 1),
        no = expressionValue(input.else, entity, field, depth + 1);
      return condition && yes && no ? {
        op: 'if',
        condition,
        then: yes,
        else: no
      } : undefined;
    }
    return conditionValue(input, entity, field);
  };
  const serialize = (entity, field, rule) => {
    const value = entity.data[field];
    if (rule.type === 'text') return textValue(entity, field);
    if (rule.type === 'rich') return richValue(entity, field);
    if (value == null) return undefined;
    switch (rule.type) {
      case 'public_strings':
        {
          if (Array.isArray(value) && !value.length) return [];
          let approved;
          try {
            approved = JSON.parse(String(publicField(entity, field)));
          } catch {}
          if (Array.isArray(approved) && approved.every(item => typeof item === 'string')) return approved;
          fail('PUBLIC_TEXT_REQUIRED', '公開用の文字列一覧をJSON文章で指定してください。', entity.id, field);
          return;
        }
      case 'real_date':
        {
          const input = object(value);
          if (input && typeof input.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(input.date) && typeof input.timeZone === 'string') return {
            date: input.date,
            timeZone: input.timeZone
          };
          break;
        }
      case 'estimate':
        {
          const input = object(value);
          let assumptions;
          try {
            assumptions = JSON.parse(String(publicField(entity, 'estimateAssumptions')));
          } catch {}
          const source = publicField(entity, 'estimateSource'),
            unit = publicField(entity, 'estimateUnit');
          if (!input || !Array.isArray(assumptions) || assumptions.some(item => typeof item !== 'string') || typeof source !== 'string' || typeof unit !== 'string') {
            fail('PUBLIC_TEXT_REQUIRED', '見積の公開用仮定と出所を指定してください。', entity.id, field);
            return;
          }
          const scope = scopeValue(input.scope, entity, field);
          if (!scope) return;
          return {
            unit,
            assumptions: assumptions,
            source,
            unknownCount: Number(input.unknownCount),
            scope,
            ...(input.value != null ? {
              value: Number(input.value)
            } : {}),
            ...(input.range ? {
              range: input.range
            } : {}),
            ...(input.speed != null ? {
              speed: Number(input.speed)
            } : {})
          };
        }
      case 'parameters':
        {
          if (!Array.isArray(value)) break;
          const approved = publicField(entity, 'parameters');
          let names;
          try {
            names = typeof approved === 'string' ? JSON.parse(approved) : undefined;
          } catch {}
          if (value.length && !object(names)) {
            fail('PUBLIC_TEXT_REQUIRED', '公開用の引数名をkey→公開keyのJSON文章で指定してください。', entity.id, field);
            return;
          }
          const output = [];
          for (const raw of value) {
            const input = object(raw),
              key = input && own(object(names), String(input.key));
            if (!input || typeof key !== 'string' || !/^[-_.a-zA-Z0-9]{1,128}$/.test(key) || !['boolean', 'integer', 'enum'].includes(String(input.type))) {
              fail('PUBLIC_TEXT_REQUIRED', '引数の公開名と型を確認してください。', entity.id, field);
              return;
            }
            const initial = input.default == null ? undefined : typedValue(input.default, entity.id, entity, field);
            if (input.default != null && !initial) return;
            output.push({
              key,
              type: String(input.type),
              ...(initial ? {
                default: initial
              } : {})
            });
          }
          return output;
        }
      case 'expression':
        return expressionValue(value, entity, field);
      case 'scope':
        return scopeValue(value, entity, field);
      case 'validity':
        return validityValue(value, entity, field);
      case 'exception':
        return exceptionValue(value, entity, field);
      case 'exceptions':
        {
          if (!Array.isArray(value)) break;
          const mapped = value.map(item => exceptionValue(item, entity, field));
          return mapped.every(item => item !== undefined) ? mapped : undefined;
        }
      case 'resets':
        {
          if (!Array.isArray(value)) break;
          const output = [];
          for (const raw of value) {
            const input = object(raw);
            if (!input || !['scene_end', 'chapter_end', 'run_end', 'new_loop', 'full_reset'].includes(String(input.on))) break;
            const mapped = typedValue(input.value, entity.id, entity, field);
            if (!mapped) return;
            output.push({
              on: String(input.on),
              value: mapped,
              reason: behaviorText(entity, 'resetReason')
            });
          }
          if (output.length !== value.length) break;
          return output;
        }
      case 'exclusions':
        {
          if (!Array.isArray(value)) break;
          const output = [];
          for (const raw of value) {
            const input = object(raw);
            if (!input) return;
            const variableId = reference(input.variableId, entity, field, true),
              current = typedValue(input.value, entity.id, entity, field),
              other = typedValue(input.otherValue, String(input.variableId), entity, field),
              exceptions = input.exceptions == null ? [] : Array.isArray(input.exceptions) ? input.exceptions.map(item => exceptionValue(item, entity, field)) : undefined;
            if (!variableId || !current || !other || !exceptions || exceptions.some(item => !item)) return;
            const reason = behaviorText(entity, 'exclusionReason');
            if (!reason.trim()) {
              fail('PUBLIC_TEXT_REQUIRED', '相互排他の公開用理由を指定してください。', entity.id, field);
              return;
            }
            output.push({
              variableId,
              value: current,
              otherValue: other,
              reason,
              exceptions: exceptions
            });
          }
          return output;
        }
      case 'alternatives':
        {
          const input = object(value);
          if (!input) break;
          const output = {};
          for (const [key, ids] of Object.entries(input)) {
            const id = reference(key, entity, field, true);
            if (!id || !Array.isArray(ids)) return;
            const mapped = ids.map(item => reference(item, entity, field, true));
            if (mapped.some(item => !item)) return;
            output[id] = mapped;
          }
          return output;
        }
      case 'camera':
        {
          const approved = publicField(entity, field);
          let input;
          try {
            input = typeof approved === 'string' ? JSON.parse(approved) : undefined;
          } catch {
            break;
          }
          const camera = object(input);
          if (!camera) {
            fail('PUBLIC_TEXT_REQUIRED', '公開用カメラ指定をJSON文章で指定してください。', entity.id, field);
            return;
          }
          const output = {};
          for (const [key, item] of Object.entries(camera)) {
            if (!['shot', 'angle', 'movement', 'durationMs'].includes(key) || !(typeof item === 'string' || typeof item === 'number' && Number.isFinite(item) && item >= 0)) {
              fail('EXPORT_UNSUPPORTED', 'カメラの指定項目を安全に表せません。', entity.id, field);
              return;
            }
            output[key] = item;
          }
          return output;
        }
      case 'ref':
        return reference(value, entity, field, BEHAVIOR_REFS.has(field));
      case 'refs':
        {
          if (!Array.isArray(value)) break;
          return value.map(id => reference(id, entity, field, options.strictReferences && BEHAVIOR_REFS.has(field))).filter(id => id !== undefined);
        }
      case 'number':
        if (typeof value === 'number' && Number.isFinite(value)) return value;
        break;
      case 'boolean':
        if (typeof value === 'boolean') return value;
        break;
      case 'enum':
        if (typeof value === 'string' && rule.values.includes(value)) return value;
        break;
      case 'condition':
        return conditionValue(value, entity, field);
      case 'typed':
        return typedValue(value, entity.kind === 'effect' && typeof entity.data.targetId === 'string' ? entity.data.targetId : entity.id, entity, field);
      case 'typeds':
        {
          if (!Array.isArray(value)) break;
          const output = value.map(item => typedValue(item, entity.id, entity, field));
          return output.every(item => item !== undefined) ? output : undefined;
        }
      case 'semver':
        if (typeof value === 'string' && /^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/.test(value)) return value;
        break;
      case 'allowed':
        {
          const input = object(value);
          if (!input) break;
          const output = {};
          if (input.min !== undefined || input.max !== undefined) {
            if (!integer(input.min) || !integer(input.max) || input.min > input.max) break;
            output.min = input.min;
            output.max = input.max;
          }
          if (Array.isArray(input.values)) {
            const values = input.values.map(item => typeof item === 'string' ? mapEnum(item, entity.id, entity, field) : typeof item === 'boolean' || integer(item) ? item : undefined);
            if (values.some(item => item === undefined)) break;
            if (new Set(values).size !== values.length) {
              fail('VALIDATION_FAILED', '公開列挙値が重複しています。', entity.id, field);
              return undefined;
            }
            output.values = values;
          }
          return output;
        }
      case 'time':
        {
          const input = object(value);
          if (!input) break;
          const output = {
            mode: String(input.mode)
          };
          if (['instant', 'interval', 'uncertain'].includes(String(input.mode))) {
            var _textValue;
            const fields = input.mode === 'instant' ? ['at'] : input.mode === 'interval' ? ['start', 'end'] : ['earliest', 'latest'];
            for (const key of fields) {
              if (typeof input[key] !== 'string' || !TICK.test(input[key])) {
                fail('VALIDATION_FAILED', '世界日時のtickが不正です。', entity.id, field);
                return undefined;
              }
              output[key] = input[key];
            }
            const calendarId = publicCalendarId(input.calendarId, entity, field);
            if (!calendarId) return undefined;
            output.calendarId = calendarId;
            if (input.mode === 'uncertain') output.precision = (_textValue = textValue(entity, 'precision')) !== null && _textValue !== void 0 ? _textValue : '';
            return output;
          }
          if (input.mode === 'unknown') {
            const reason = publicField(entity, 'reason');
            return {
              mode: 'unknown',
              reason: typeof reason === 'string' ? reason : ''
            };
          }
          if (input.mode === 'relative') {
            const anchorEventId = reference(input.anchorEventId, entity, field, true);
            if (anchorEventId && ['start', 'end'].includes(String(input.anchorPoint)) && typeof input.minOffset === 'string' && TICK.test(input.minOffset) && typeof input.maxOffset === 'string' && TICK.test(input.maxOffset)) return {
              mode: 'relative',
              anchorEventId,
              anchorPoint: String(input.anchorPoint),
              minOffset: input.minOffset,
              maxOffset: input.maxOffset
            };
          }
          break;
        }
      case 'participants':
        {
          if (!Array.isArray(value)) break;
          const output = [];
          for (const raw of value) {
            const participant = object(raw);
            if (!participant) continue;
            const characterId = reference(participant.characterId, entity, field);
            if (!characterId) continue;
            if (!['actor', 'witness', 'mentioned', 'informed', 'custom'].includes(String(participant.role))) {
              fail('VALIDATION_FAILED', '参加役割が不正です。', entity.id, field);
              continue;
            }
            output.push({
              characterId,
              role: String(participant.role)
            });
          }
          return output;
        }
      case 'pins':
        {
          if (!Array.isArray(value)) break;
          const output = [];
          for (const raw of value) {
            const pin = object(raw);
            if (!pin) continue;
            const placeId = reference(pin.placeId, entity, field);
            if (!placeId) continue;
            if (typeof pin.x !== 'number' || typeof pin.y !== 'number' || pin.x < 0 || pin.x > 1 || pin.y < 0 || pin.y > 1) {
              fail('VALIDATION_FAILED', '地図座標が不正です。', entity.id, field);
              continue;
            }
            output.push({
              placeId,
              x: pin.x,
              y: pin.y
            });
          }
          return output;
        }
      case 'datetime':
        if (typeof value === 'string' && Number.isFinite(Date.parse(value))) return value;
        break;
      case 'version_ref':
        {
          var _options$versionTarge3;
          const fixed = (_options$versionTarge3 = options.versionTargets) === null || _options$versionTarge3 === void 0 ? void 0 : _options$versionTarge3[String(value)];
          if (!fixed) {
            fail('EXPORT_UNSUPPORTED', '媒体の元固定版の公開範囲を確認してください。', entity.id, field);
            return undefined;
          }
          return fixed.publicVersionId;
        }
      case 'anchor':
        return anchorValue(value, entity, field);
      case 'trigger':
        {
          const input = object(value);
          if (!input || !['enter', 'talk', 'battle_result', 'manual', 'custom'].includes(String(input.event)) || !['once', 'repeatable'].includes(String(input.repeat))) break;
          const eventKey = textValue(entity, 'eventKey');
          if (typeof input.eventKey === 'string' && input.eventKey && eventKey === undefined) {
            fail('PUBLIC_TEXT_REQUIRED', '外部イベント名の公開表記を指定してください。', entity.id, 'eventKey');
            return undefined;
          }
          const deadline = input.deadline != null ? serialize({
            ...entity,
            data: {
              ...entity.data,
              deadline: input.deadline
            }
          }, 'deadline', time) : undefined;
          if (input.deadline != null && deadline === undefined) return undefined;
          const output = {
            event: String(input.event),
            repeat: String(input.repeat),
            eventKey: eventKey !== null && eventKey !== void 0 ? eventKey : ''
          };
          if (typeof input.id === 'string' && idMap[input.id]) output.id = idMap[input.id];
          if (input.scope != null) {
            if (!['scene', 'chapter', 'character', 'run', 'across_runs'].includes(String(input.scope))) break;
            output.scope = String(input.scope);
          }
          if (deadline !== undefined) output.deadline = deadline;
          return output;
        }
      case 'transitions':
        {
          if (!Array.isArray(value)) break;
          const output = [];
          const variableId = entity.kind === 'quest' && typeof entity.data.stateVariableId === 'string' ? entity.data.stateVariableId : entity.id;
          for (const raw of value) {
            const transition = object(raw);
            if (!transition) {
              fail('VALIDATION_FAILED', '状態遷移の形が不正です。', entity.id, field);
              continue;
            }
            const from = typedValue(transition.from, variableId, entity, field),
              to = typedValue(transition.to, variableId, entity, field);
            const details = transition.exceptionDetails ? exceptionValue(transition.exceptionDetails, entity, field) : undefined;
            if (transition.exception === true && !details) {
              fail('EXPORT_UNSUPPORTED', '理由・範囲・期限・根拠のある例外を公開範囲へ含めてください。', entity.id, field);
              continue;
            }
            if (from !== undefined && to !== undefined) output.push({
              from,
              to,
              ...(details ? {
                exception: true,
                exceptionDetails: details
              } : {})
            });
          }
          return output;
        }
    }
    fail('EXPORT_UNSUPPORTED', 'この項目は対応先で安全に表せません。', entity.id, field);
    return undefined;
  };
  const entities = [];
  for (const entity of selected) {
    const schema = PROJECTION_FIELDS[entity.kind];
    const explicit = own(allowedFields, entity.kind);
    const fields = Array.isArray(explicit) ? explicit : Object.keys(schema);
    const output = {};
    for (const field of fields) {
      if (typeof field !== 'string' || FORBIDDEN_FIELDS.has(field) || !hasOwn(schema, field)) {
        fail('FORBIDDEN', '許可されていない項目を公開しようとしています。', entity.id, String(field));
        continue;
      }
      if (excludedFields.includes(field) || excludedFields.includes(`${entity.kind}.${field}`)) {
        omit(entity.id, '作者が項目を除外', field);
        continue;
      }
      const value = serialize(entity, field, schema[field]);
      if (value !== undefined) output[field] = value;
    }
    for (const field of Object.keys(entity.data)) if (!fields.includes(field) || !hasOwn(schema, field)) omit(entity.id, FORBIDDEN_FIELDS.has(field) ? '作者情報・秘密の項目を除外' : '公開を許可していない項目を除外', field);
    if (entity.kind === 'attachment') {
      const approved = Array.isArray(policy.approvedAttachmentIds) && policy.approvedAttachmentIds.includes(entity.id);
      const provenance = typeof entity.data.provenanceId === 'string' ? source.get(entity.data.provenanceId) : undefined;
      if (!approved || provenance && provenance.data.redistributionAllowed !== true) fail('FORBIDDEN', '添付の再配布許可を確認してください。', entity.id);
      const mediaType = entity.data.mediaType;
      if (typeof mediaType !== 'string' || !ASSET_TYPES[mediaType]) fail('EXPORT_UNSUPPORTED', 'この素材形式は公開出力に対応していません。', entity.id, 'mediaType');else {
        output.mediaType = mediaType;
        output.assetPath = `assets/${idMap[entity.id]}.${ASSET_TYPES[mediaType]}`;
      }
      if (typeof entity.data.contentHash !== 'string' || !/^[a-f0-9]{64}$/.test(entity.data.contentHash) || !integer(entity.data.byteSize) || entity.data.byteSize < 0) fail('VALIDATION_FAILED', '素材のhashとサイズが不正です。', entity.id);else {
        output.contentHash = entity.data.contentHash;
        output.byteSize = entity.data.byteSize;
        output.bytesIncluded = false;
      }
    }
    if (entity.kind === 'source' && entity.data.sourceType === 'web' && typeof output.locator === 'string') {
      try {
        const url = new URL(output.locator);
        if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error();
      } catch {
        fail('FORBIDDEN', '公開資料のURLは認証情報を含まないHTTP/HTTPSにしてください。', entity.id, 'locator');
      }
    }
    entities.push({
      id: idMap[entity.id],
      kind: entity.kind,
      name: names.get(entity.id),
      status: entity.status,
      data: output
    });
  }
  const relations = [];
  const relationIds = Array.isArray(policy.allowedRelationIds) ? policy.allowedRelationIds : [];
  const relationSource = new Map(project.relations.map(relation => [relation.id, relation]));
  for (const rawId of relationIds) {
    if (typeof rawId !== 'string') {
      fail('VALIDATION_FAILED', '関係の公開IDが不正です。', profileId, 'allowedRelationIds');
      continue;
    }
    const relation = relationSource.get(rawId);
    if (!relation || relation.projectId !== project.projectId) {
      fail('REFERENCE_INVALID', '作品内にない関係が公開範囲に含まれています。', rawId);
      continue;
    }
    if (!selectedIds.has(relation.fromId) || !selectedIds.has(relation.toId) || relation.status !== 'confirmed' || relation.deletedAt) {
      omit(rawId, '非公開の始点・終点、削除済みまたは未確定の関係');
      continue;
    }
    const publicRelationType = own(object(own(publicTexts, rawId)), 'relationType');
    if (typeof publicRelationType !== 'string' || !publicRelationType) {
      fail('PUBLIC_TEXT_REQUIRED', '公開用の関係名を指定してください。', rawId, 'relationType');
      continue;
    }
    addId(rawId);
    const validity = validityValue(relation.validity, {
      id: rawId,
      projectId: project.projectId,
      kind: 'note',
      name: '',
      status: relation.status,
      data: {}
    }, 'validity');
    relations.push({
      ...(validity ? {
        validity
      } : {}),
      id: idMap[rawId],
      fromId: idMap[relation.fromId],
      toId: idMap[relation.toId],
      relationType: publicRelationType,
      direction: relation.direction,
      evidenceIds: relation.evidenceIds.filter(id => selectedIds.has(id)).map(id => idMap[id])
    });
  }
  if (issues.length) return {
    ok: false,
    issues,
    omissions
  };
  const projection = {
    format: 'scenario-projection',
    formatVersion: '1.0.0',
    title: title,
    mainStart: project.mainStart,
    calendars,
    entities,
    relations,
    searchIndex: []
  };
  projection.searchIndex = buildProjectionSearchIndex(projection);
  return {
    ok: true,
    projection,
    omissions,
    idMap
  };
}

/** A scope can narrow an ID allowlist; it never adds an ID the author did not approve. */
function scopedEntityIds(source, policy, projectId, publicTexts, fail) {
  var _scope$chapterId;
  const scope = object(policy.routeScope);
  if (!scope) return undefined;
  if (scope.projectId !== projectId) {
    fail('REFERENCE_INVALID', '公開範囲が別の作品を参照しています。', undefined, 'routeScope');
    return new Set();
  }
  if (scope.routeCondition != null) {
    fail('EXPORT_UNSUPPORTED', '条件付き経路の安全な公開範囲は未対応です。IDまたは章・グラフで限定してください。', undefined, 'routeScope.routeCondition');
    return new Set();
  }
  if (scope.chapterId != null && scope.graphId != null) {
    fail('EXPORT_UNSUPPORTED', '章とグラフの範囲は一度に一つ選んでください。', undefined, 'routeScope');
    return new Set();
  }
  if (scope.chapterId == null && scope.graphId == null) return undefined;
  const rootId = (_scope$chapterId = scope.chapterId) !== null && _scope$chapterId !== void 0 ? _scope$chapterId : scope.graphId;
  const root = typeof rootId === 'string' ? source.get(rootId) : undefined;
  if (!root || root.projectId !== projectId || root.kind !== (scope.chapterId != null ? 'chapter' : 'flow_graph') || root.deletedAt) {
    fail('REFERENCE_INVALID', '公開範囲の章またはグラフが見つかりません。', typeof rootId === 'string' ? rootId : undefined, 'routeScope');
    return new Set();
  }
  const approved = new Set(Array.isArray(policy.includedIds) ? policy.includedIds.filter(id => typeof id === 'string') : []);
  const narrative = new Set();
  const scenes = new Set();
  if (root.kind === 'chapter') {
    narrative.add(root.id);
    for (const entity of source.values()) if (entity.kind === 'scene' && (entity.data.chapterId === root.id || Array.isArray(root.data.sceneIds) && root.data.sceneIds.includes(entity.id))) scenes.add(entity.id);
  } else {
    const graphs = [root],
      visitedGraphs = new Set();
    while (graphs.length) {
      const graph = graphs.pop();
      if (visitedGraphs.has(graph.id)) continue;
      visitedGraphs.add(graph.id);
      narrative.add(graph.id);
      for (const value of [...(Array.isArray(graph.data.nodeIds) ? graph.data.nodeIds : []), ...(Array.isArray(graph.data.edgeIds) ? graph.data.edgeIds : [])]) if (typeof value === 'string') narrative.add(value);
      for (const value of Array.isArray(graph.data.nodeIds) ? graph.data.nodeIds : []) {
        const node = typeof value === 'string' ? source.get(value) : undefined;
        if (!node || node.kind !== 'flow_node') continue;
        if (typeof node.data.sceneId === 'string') scenes.add(node.data.sceneId);
        const child = typeof node.data.childGraphId === 'string' ? source.get(node.data.childGraphId) : undefined;
        if ((child === null || child === void 0 ? void 0 : child.kind) === 'flow_graph' && approved.has(child.id)) graphs.push(child);
      }
    }
  }
  const eligible = entity => {
    if (entity.kind === 'scene') return scenes.has(entity.id);
    if (['flow_graph', 'flow_node', 'flow_edge'].includes(entity.kind)) return root.kind === 'flow_graph' && narrative.has(entity.id);
    if (entity.kind === 'chapter') return root.kind === 'chapter' ? entity.id === root.id : [...scenes].some(id => {
      var _source$get;
      return ((_source$get = source.get(id)) === null || _source$get === void 0 ? void 0 : _source$get.data.chapterId) === entity.id;
    });
    return true;
  };
  const result = new Set(),
    queue = [...narrative, ...scenes];
  const enqueue = value => {
    if (typeof value === 'string' && approved.has(value)) queue.push(value);
  };
  const conditionRefs = (value, depth = 1) => {
    const ast = object(value);
    if (!ast || depth > 16) return;
    for (const field of ['variableId', 'itemId', 'assertionId', 'holderId', 'entityId', 'contractId']) enqueue(ast[field]);
    if (Array.isArray(ast.children)) ast.children.forEach(child => conditionRefs(child, depth + 1));
    if (ast.child) conditionRefs(ast.child, depth + 1);
  };
  while (queue.length) {
    const id = queue.pop();
    if (result.has(id) || !approved.has(id)) continue;
    const entity = source.get(id);
    if (!entity || !eligible(entity)) continue;
    result.add(id);
    for (const [field, rule] of Object.entries((_PROJECTION_FIELDS$en = PROJECTION_FIELDS[entity.kind]) !== null && _PROJECTION_FIELDS$en !== void 0 ? _PROJECTION_FIELDS$en : {})) {
      var _PROJECTION_FIELDS$en, _object9, _object0, _object1;
      if (field === 'parentId' || field === 'parentGraphId') continue;
      const value = entity.data[field];
      if (rule.type === 'ref') enqueue(value);else if (rule.type === 'refs' && Array.isArray(value)) value.forEach(enqueue);else if (rule.type === 'condition') conditionRefs(value);else if (rule.type === 'typed' && ((_object9 = object(value)) === null || _object9 === void 0 ? void 0 : _object9.type) === 'ref') enqueue((_object0 = object(value)) === null || _object0 === void 0 ? void 0 : _object0.value);else if (rule.type === 'time') enqueue((_object1 = object(value)) === null || _object1 === void 0 ? void 0 : _object1.anchorEventId);else if (rule.type === 'anchor') {
        var _object10, _object11;
        enqueue((_object10 = object(value)) === null || _object10 === void 0 ? void 0 : _object10.entityId);
        enqueue((_object11 = object(value)) === null || _object11 === void 0 ? void 0 : _object11.lineId);
      } else if (rule.type === 'participants' && Array.isArray(value)) value.forEach(value => {
        var _object12;
        return enqueue((_object12 = object(value)) === null || _object12 === void 0 ? void 0 : _object12.characterId);
      });else if (rule.type === 'pins' && Array.isArray(value)) value.forEach(value => {
        var _object13;
        return enqueue((_object13 = object(value)) === null || _object13 === void 0 ? void 0 : _object13.placeId);
      });else if (rule.type === 'rich') {
        const document = own(object(own(publicTexts, entity.id)), field);
        if (Array.isArray(document)) for (const block of document) {
          var _object14;
          if (Array.isArray((_object14 = object(block)) === null || _object14 === void 0 ? void 0 : _object14.links)) for (const link of object(block).links) {
            var _object15, _object16, _target$entityId;
            const target = (_object15 = object((_object16 = object(link)) === null || _object16 === void 0 ? void 0 : _object16.target)) !== null && _object15 !== void 0 ? _object15 : object(link);
            enqueue((_target$entityId = target === null || target === void 0 ? void 0 : target.entityId) !== null && _target$entityId !== void 0 ? _target$entityId : target === null || target === void 0 ? void 0 : target.targetId);
            enqueue(target === null || target === void 0 ? void 0 : target.lineId);
          }
        }
      }
    }
  }
  return result;
}
function publicStrings(value) {
  if (typeof value === 'string') return [value];
  if (Array.isArray(value)) return value.flatMap(publicStrings);
  if (value && typeof value === 'object') return Object.entries(value).filter(([key]) => ['text', 'reading', 'summary', 'body', 'description', 'label', 'canonical'].includes(key)).flatMap(([, child]) => publicStrings(child));
  return [];
}
export function buildProjectionSearchIndex(projection) {
  return projection.entities.map(entity => {
    const text = [entity.name, ...publicStrings(entity.data)].join('\n');
    return {
      entityId: entity.id,
      kind: entity.kind,
      name: entity.name,
      text,
      normalized: text.normalize('NFKC').toLocaleLowerCase('ja')
    };
  });
}
/** Only accepts a projection. Searching the author project is a different operation. */
export function searchProjection(projection, query) {
  const normalized = query.normalize('NFKC').toLocaleLowerCase('ja').trim();
  return normalized ? projection.searchIndex.filter(entry => entry.normalized.includes(normalized)) : [];
}
function freeze(value) {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
/** Caller supplies identity/time. A released projection never aliases mutable author data. */
export async function createProjectionSnapshot(projection, options) {
  if (!options.id || !/^(?:0|[1-9][0-9]*)$/.test(options.sourceRevision) || !Number.isFinite(Date.parse(options.createdAt))) throw new Error('VALIDATION_FAILED: snapshotのID・対象版・日時を指定してください。');
  const content = structuredClone(projection);
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(content)));
  const contentHash = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
  return freeze({
    ...options,
    immutable: true,
    contentHash,
    projection: content
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXh0IiwidHlwZSIsInJpY2giLCJyZWYiLCJyZWZzIiwibnVtYmVyIiwiYm9vbGVhbiIsInRpbWUiLCJjb25kaXRpb24iLCJ0eXBlZCIsIm9uZU9mIiwidmFsdWVzIiwiUFJPSkVDVElPTl9GSUVMRFMiLCJPYmplY3QiLCJmcmVlemUiLCJjaGFyYWN0ZXIiLCJyZWFkaW5nIiwic3VtbWFyeSIsImJvZHkiLCJiaXJ0aCIsImRlYXRoIiwiZ3JvdXAiLCJncm91cFR5cGUiLCJtZW1iZXJzIiwicGFyZW50SWQiLCJldmVudCIsImxhbmVSb2xlIiwicGFydGljaXBhbnRzIiwibG9jYXRpb25JZCIsIml0ZW1JZHMiLCJwbGFjZSIsIm1hcElkcyIsIml0ZW0iLCJpdGVtTW9kZSIsInR5cGVJZCIsIm5vdGUiLCJhdHRhY2htZW50SWRzIiwiY2hhcHRlciIsInNjZW5lSWRzIiwic2NlbmUiLCJldmVudElkcyIsImRpYWxvZ3VlTGluZUlkcyIsImNoYXB0ZXJJZCIsInRocmVhZElkcyIsInBvdklkIiwiYmxvY2tJZHMiLCJ0ZW5zaW9uIiwiaW1wb3J0YW5jZSIsImdvYWwiLCJvd25lcklkIiwiZGVzY3JpcHRpb24iLCJjaGFuZ2VzIiwiZXZpZGVuY2VTY2VuZUlkcyIsImZsb3dfbm9kZSIsIm5vZGVUeXBlIiwic2NlbmVJZCIsImNoaWxkR3JhcGhJZCIsInRlcm1pbmFsUmVhc29uIiwidHJpZ2dlciIsImdhdGUiLCJleGVjdXRpb25Qb2xpY3kiLCJmYWxsYmFja0lkIiwic2hvd25JbmZvcm1hdGlvbklkcyIsImZsb3dfZWRnZSIsImZyb21JZCIsInRvSWQiLCJlZGdlVHlwZSIsImxhYmVsIiwiZWZmZWN0SWRzIiwicHJpb3JpdHkiLCJjaG9pY2VMaW5lSWQiLCJmbG93X2dyYXBoIiwibm9kZUlkcyIsImVkZ2VJZHMiLCJlbnRyeUlkcyIsImV4aXRJZHMiLCJwYXJlbnRHcmFwaElkIiwicGFyYW1ldGVycyIsImRpYWxvZ3VlX2xpbmUiLCJzcGVha2VySWQiLCJjaG9pY2VFZGdlSWQiLCJjdWVJZHMiLCJxdWVzdCIsImtleSIsInN0YXRlVmFyaWFibGVJZCIsImZsb3dJZHMiLCJ0cmFuc2l0aW9uUnVsZXMiLCJsb3JlIiwiYXNzZXJ0aW9uSWRzIiwidmFyaWFibGUiLCJ2YWx1ZVR5cGUiLCJzY29wZSIsImluaXRpYWwiLCJhbGxvd2VkIiwiZXh0ZXJuYWxDb250cmFjdElkIiwiZXh0ZXJuYWxVc2VEZWNsYXJlZCIsImRlcml2ZWQiLCJyZXNldFJ1bGVzIiwiZXhjbHVzaW9ucyIsImVmZmVjdCIsIm9wZXJhdGlvbiIsInRhcmdldElkIiwidmFsdWUiLCJpbnN0YW5jZUlkIiwicmVhc29uIiwiZXhjZXB0aW9uRGV0YWlscyIsImFzc2VydGlvbiIsInN1YmplY3RJZCIsInByZWRpY2F0ZSIsInRydXRoS2luZCIsImhvbGRlcklkIiwic291cmNlSWRzIiwiZXZpZGVuY2VMb2NhdGlvbiIsInZhbGlkaXR5IiwiZm9yZXNoYWRvdyIsInF1ZXN0aW9uIiwiaW50ZW50IiwidHJ1dGhBc3NlcnRpb25JZHMiLCJjbHVlSWRzIiwicGF5b2ZmSWRzIiwicmVxdWlyZWRJbmZvIiwiYWx0ZXJuYXRpdmVJbmZvIiwiZGVhZGxpbmUiLCJleGNlcHRpb25zIiwicHJlc2VudGF0aW9uRGVhZGxpbmUiLCJyZXNvbHV0aW9uUG9saWN5IiwiZGlzY2xvc3VyZSIsImZvcmVzaGFkb3dJZCIsImFuY2hvciIsInN0YWdlIiwicm9sZSIsInRhcmdldFNjb3BlIiwia25vd2xlZGdlRWZmZWN0cyIsImF0dGFjaG1lbnQiLCJkaXNwbGF5TmFtZSIsInNvdXJjZSIsImFjY2Vzc2VkQXQiLCJleGNlcnB0TG9jYXRpb24iLCJhdHRhY2htZW50SWQiLCJzb3VyY2VUeXBlIiwibG9jYXRvciIsImludGVycHJldGF0aW9uIiwicmVkaXN0cmlidXRpb25BbGxvd2VkIiwiY3VlIiwiY3VlVHlwZSIsImV4cHJlc3Npb24iLCJ3YWl0TXMiLCJtZWRpYVRpbWUiLCJjYW1lcmEiLCJzdG9yeWJvYXJkX2ZyYW1lIiwibWVkaWFTdGFydE1zIiwibWVkaWFFbmRNcyIsInJlZmVyZW5jZUFzc2V0SWQiLCJmaW5hbEFzc2V0SWQiLCJjYXB0aW9uIiwibG9jYWxpemF0aW9uIiwic291cmNlTGluZUlkIiwibGFuZ3VhZ2UiLCJyZWNvcmRpbmdJZHMiLCJyZWNvcmRpbmciLCJ0cmFuc2xhdGlvbklkIiwidGVybWlub2xvZ3kiLCJjYW5vbmljYWwiLCJ2YXJpYW50cyIsInVzYWdlTm90ZXMiLCJ2b2ljZU93bmVySWQiLCJ2b2ljZV9ydWxlIiwiY2hhcmFjdGVySWQiLCJmaXJzdFBlcnNvbiIsImFkZHJlc3NpbmciLCJwaHJhc2luZyIsImV4YW1wbGVzIiwibWFwIiwicGxhY2VJZCIsImNvb3JkaW5hdGVTeXN0ZW0iLCJwYXJlbnRNYXBJZCIsInBpbnMiLCJ0cmF2ZWxfcm91dGUiLCJmcm9tUGxhY2VJZCIsInRvUGxhY2VJZCIsImRpcmVjdGlvbiIsIm1ldGhvZCIsImNvbGxlY3Rpb24iLCJtb2RlIiwibWVtYmVySWRzIiwiZ2FtZXBsYXlfc3BlYyIsImFjdGlvbiIsIm1lY2hhbmljIiwidHV0b3JpYWwiLCJyZXdhcmQiLCJxdWVzdElkIiwidGFza0lkcyIsImludGVudGlvbmFsRGlmZmVyZW5jZSIsInByb2R1Y3Rpb25fdGFzayIsImVzdGltYXRlIiwiYmxvY2tpbmdSZWFzb24iLCJ0YXJnZXRJZHMiLCJwcm9ncmVzcyIsImRlcGVuZHNPbiIsIm1lZGlhX3ZhcmlhbnQiLCJtZWRpdW0iLCJiYXNlU25hcHNob3RJZCIsInByZXZpb3VzVmFyaWFudElkIiwicmVsZWFzZUF0IiwibmVlZHNSZXZpZXciLCJleHRlcm5hbF9jb250cmFjdCIsIm93bmVyIiwiaW5wdXRUeXBlIiwib3V0cHV0VHlwZSIsIm1pc3NpbmdQb2xpY3kiLCJ2ZXJzaW9uIiwic3R1YlZhbHVlcyIsIlBST0pFQ1RBQkxFX0tJTkRTIiwia2V5cyIsIkJFSEFWSU9SX1JFRlMiLCJTZXQiLCJGT1JCSURERU5fRklFTERTIiwiQkxPQ0tfS0lORFMiLCJBU1NFVF9UWVBFUyIsIlRJQ0siLCJvYmplY3QiLCJBcnJheSIsImlzQXJyYXkiLCJ1bmRlZmluZWQiLCJvd24iLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJoYXNPd24iLCJlbXB0eSIsImxlbmd0aCIsImludGVnZXIiLCJOdW1iZXIiLCJpc1NhZmVJbnRlZ2VyIiwiY3JlYXRlUHJvamVjdGlvbiIsInByb2plY3QiLCJwcm9maWxlSWQiLCJvcHRpb25zIiwiX29iamVjdCIsIl9vYmplY3QyIiwiX29iamVjdDMiLCJfb2JqZWN0NyIsImlzc3VlcyIsIm9taXNzaW9ucyIsImVudGl0aWVzIiwicmVsYXRpb25zIiwic29tZSIsImVudGl0eSIsImlkIiwiZGF0YSIsIm9rIiwiY29kZSIsIm1lc3NhZ2UiLCJmYWlsIiwiZW50aXR5SWQiLCJmaWVsZCIsInB1c2giLCJvbWl0IiwiTWFwIiwiaGFzIiwic2V0IiwicHJvZmlsZSIsImdldCIsImtpbmQiLCJwcm9qZWN0SWQiLCJkZWxldGVkQXQiLCJwb2xpY3kiLCJzb3VyY2VWZXJzaW9uSWQiLCJ0YXJnZXRWZXJzaW9uSWQiLCJyZXZpc2lvbiIsInJvdXRlU2NvcGUiLCJ0YXJnZXRTbmFwc2hvdElkIiwiaWRQb2xpY3kiLCJpbmNsdWRlcyIsIlN0cmluZyIsImluY2x1ZGVBdXRob3JOb3RlcyIsInRpdGxlIiwidHJpbSIsImluY2x1ZGVkSWRzIiwiYWxsb3dlZEtpbmRzIiwic2l6ZSIsInB1YmxpY1RleHRzIiwicHVibGljSWRzIiwibmFtZVBvbGljaWVzIiwic2NvcGVJZHMiLCJzY29wZWRFbnRpdHlJZHMiLCJzdGF0dXNlcyIsImluY2x1ZGVkU3RhdHVzZXMiLCJzdGF0dXMiLCJzZWxlY3RlZCIsIm5hbWVzIiwiZXhwbGljaXRQdWJsaWNJZHMiLCJpbmNsdWRlZCIsIm9yZGVyZWRJZHMiLCJmaWx0ZXIiLCJfb2JqZWN0NCIsIl9vYmplY3Q1IiwiX3JlZiIsIl9vYmplY3Q2IiwiY29uZmlybWVkT25seSIsInJldXNlIiwiYnlFbnRpdHlJZCIsIm5hbWVQb2xpY3kiLCJwdWJsaWNOYW1lIiwicmVwbGFjZW1lbnQiLCJwdWJsaWNJZCIsImFsaWFzZXMiLCJhbGlhcyIsImZpbmQiLCJhbGlhc0lkIiwibmFtZSIsImlkTWFwIiwiY3JlYXRlIiwiZW1pdHRlZElkcyIsInNlcXVlbmNlIiwiYWRkSWQiLCJfcmVmMiIsIl9leHBsaWNpdFB1YmxpY0lkcyRnZSIsImNhbmRpZGF0ZSIsInBhZFN0YXJ0IiwidGVzdCIsImFkZCIsImZvckVhY2giLCJhbGxvd2VkRmllbGRzIiwiZXhjbHVkZWRGaWVsZHMiLCJwdWJsaWNCbG9ja0lkcyIsInB1YmxpY0Jsb2NrT3duZXJzIiwic291cmNlQmxvY2tPd25lcnMiLCJyYXciLCJibG9jayIsImZpZWxkcyIsInNjaGVtYSIsImV4cGxpY2l0IiwicnVsZSIsImVudHJpZXMiLCJyZWNvcmQiLCJzZWxlY3RlZElkcyIsImJsb2NrU291cmNlcyIsInB1YmxpY0Jsb2NrIiwic291cmNlQmxvY2siLCJjYWxlbmRhcnMiLCJjYWxlbmRhcklkcyIsInB1YmxpY0NhbGVuZGFySWQiLCJzb3VyY2VDYWxlbmRhciIsImNhbGVuZGFyIiwidGlja3NQZXJEYXkiLCJCaWdJbnQiLCJvcmlnaW5MYWJlbCIsInllYXJzIiwieWVhciIsIm1vbnRocyIsIm1vbnRoIiwiZGF5cyIsImluZGV4IiwicmVmZXJlbmNlIiwibWFuZGF0b3J5Iiwic3RyaWN0UmVmZXJlbmNlcyIsIm1hcEVudW0iLCJ2YXJpYWJsZUlkIiwicmVwbGFjZW1lbnRzIiwidHlwZWRWYWx1ZSIsIm1hcHBlZCIsImlucHV0IiwiY29uZGl0aW9uVmFsdWUiLCJub2RlcyIsInZpc2l0IiwiZGVwdGgiLCJhc3QiLCJyZXF1aXJlZFJlZiIsIm9wIiwiY2hpbGRyZW4iLCJjaGlsZCIsImV2ZXJ5IiwiY29tcGFyYXRvciIsImNvbXBhcmVkIiwiaXRlbUlkIiwicXVhbnRpdHkiLCJhc3NlcnRpb25JZCIsImNvdW50IiwiY29udHJhY3RJZCIsInB1YmxpY0ZpZWxkIiwidGV4dFZhbHVlIiwiYW5jaG9yVmFsdWUiLCJfb3B0aW9ucyR2ZXJzaW9uVGFyZ2UiLCJfZml4ZWQkaWRNYXAiLCJwb3NpdGlvblN0YXR1cyIsImZpeGVkIiwidmVyc2lvblRhcmdldHMiLCJ0YXJnZXRNYXAiLCJvdXRwdXQiLCJwdWJsaWNWZXJzaW9uSWQiLCJzb3VyY2VJZCIsInN0YXJ0IiwiZW5kIiwicmljaFZhbHVlIiwicHJvamVjdGVkIiwidW5yZXNvbHZlZEFubm90YXRpb25zIiwidmFsaWRSYW5nZSIsInJhbmdlIiwicnVieSIsInJhd1J1YnkiLCJsaW5rcyIsInJhd0xpbmsiLCJfb2JqZWN0OCIsIl9vcHRpb25zJHZlcnNpb25UYXJnZTIiLCJfZml4ZWQkaWRNYXAyIiwiX3RhcmdldCR0YXJnZXRJZCIsIl90YXJnZXQkdGFyZ2V0SWQyIiwiX2ZpeGVkJHB1YmxpY1ZlcnNpb25JIiwidGFyZ2V0IiwibGluayIsInRhcmdldFN0YXJ0IiwidGFyZ2V0RW5kIiwidmFsaWQiLCJvcmlnaW4iLCJiZWhhdmlvclRleHQiLCJzY29wZVZhbHVlIiwicm91dGVDb25kaXRpb24iLCJ2YWxpZGl0eVZhbHVlIiwid29ybGRSYW5nZSIsInJvdXRlIiwicHJlc2VudGF0aW9uQW5jaG9yIiwiZXhjZXB0aW9uVmFsdWUiLCJldmlkZW5jZUlkcyIsImV2aWRlbmNlIiwiZXhwcmVzc2lvblZhbHVlIiwibGVmdCIsInJpZ2h0IiwieWVzIiwidGhlbiIsIm5vIiwiZWxzZSIsInNlcmlhbGl6ZSIsImFwcHJvdmVkIiwiSlNPTiIsInBhcnNlIiwiZGF0ZSIsInRpbWVab25lIiwiYXNzdW1wdGlvbnMiLCJ1bml0IiwidW5rbm93bkNvdW50Iiwic3BlZWQiLCJkZWZhdWx0Iiwib24iLCJjdXJyZW50Iiwib3RoZXIiLCJvdGhlclZhbHVlIiwiaWRzIiwiaXNGaW5pdGUiLCJtaW4iLCJtYXgiLCJfdGV4dFZhbHVlIiwiY2FsZW5kYXJJZCIsInByZWNpc2lvbiIsImFuY2hvckV2ZW50SWQiLCJhbmNob3JQb2ludCIsIm1pbk9mZnNldCIsIm1heE9mZnNldCIsInBhcnRpY2lwYW50IiwicGluIiwieCIsInkiLCJEYXRlIiwiX29wdGlvbnMkdmVyc2lvblRhcmdlMyIsInJlcGVhdCIsImV2ZW50S2V5IiwidHJhbnNpdGlvbiIsImZyb20iLCJ0byIsImRldGFpbHMiLCJleGNlcHRpb24iLCJhcHByb3ZlZEF0dGFjaG1lbnRJZHMiLCJwcm92ZW5hbmNlIiwicHJvdmVuYW5jZUlkIiwibWVkaWFUeXBlIiwiYXNzZXRQYXRoIiwiY29udGVudEhhc2giLCJieXRlU2l6ZSIsImJ5dGVzSW5jbHVkZWQiLCJ1cmwiLCJVUkwiLCJwcm90b2NvbCIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJFcnJvciIsInJlbGF0aW9uSWRzIiwiYWxsb3dlZFJlbGF0aW9uSWRzIiwicmVsYXRpb25Tb3VyY2UiLCJyZWxhdGlvbiIsInJhd0lkIiwicHVibGljUmVsYXRpb25UeXBlIiwicmVsYXRpb25UeXBlIiwicHJvamVjdGlvbiIsImZvcm1hdCIsImZvcm1hdFZlcnNpb24iLCJtYWluU3RhcnQiLCJzZWFyY2hJbmRleCIsImJ1aWxkUHJvamVjdGlvblNlYXJjaEluZGV4IiwiX3Njb3BlJGNoYXB0ZXJJZCIsImdyYXBoSWQiLCJyb290SWQiLCJyb290IiwibmFycmF0aXZlIiwic2NlbmVzIiwiZ3JhcGhzIiwidmlzaXRlZEdyYXBocyIsImdyYXBoIiwicG9wIiwibm9kZSIsImVsaWdpYmxlIiwiX3NvdXJjZSRnZXQiLCJyZXN1bHQiLCJxdWV1ZSIsImVucXVldWUiLCJjb25kaXRpb25SZWZzIiwiX1BST0pFQ1RJT05fRklFTERTJGVuIiwiX29iamVjdDkiLCJfb2JqZWN0MCIsIl9vYmplY3QxIiwiX29iamVjdDEwIiwiX29iamVjdDExIiwibGluZUlkIiwiX29iamVjdDEyIiwiX29iamVjdDEzIiwiZG9jdW1lbnQiLCJfb2JqZWN0MTQiLCJfb2JqZWN0MTUiLCJfb2JqZWN0MTYiLCJfdGFyZ2V0JGVudGl0eUlkIiwicHVibGljU3RyaW5ncyIsImZsYXRNYXAiLCJqb2luIiwibm9ybWFsaXplZCIsIm5vcm1hbGl6ZSIsInRvTG9jYWxlTG93ZXJDYXNlIiwic2VhcmNoUHJvamVjdGlvbiIsInF1ZXJ5IiwiZW50cnkiLCJjcmVhdGVQcm9qZWN0aW9uU25hcHNob3QiLCJzb3VyY2VSZXZpc2lvbiIsImNyZWF0ZWRBdCIsImNvbnRlbnQiLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJkaWdlc3QiLCJjcnlwdG8iLCJzdWJ0bGUiLCJUZXh0RW5jb2RlciIsImVuY29kZSIsInN0cmluZ2lmeSIsIlVpbnQ4QXJyYXkiLCJ0b1N0cmluZyIsImltbXV0YWJsZSJdLCJzb3VyY2VzIjpbInByb2plY3Rpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBFbnRpdHlLaW5kLCBQcm9qZWN0RGF0YSB9IGZyb20gJy4vdHlwZXMnO1xuXG4vKiogQXV0aG9yLW9ubHkgZGlhZ25vc3RpY3MuIE5ldmVyIGluY2x1ZGUgdGhlc2Ugb3IgaWRNYXAgaW4gYSByZWFkZXIgcmVzcG9uc2UuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb2plY3Rpb25Jc3N1ZSB7XG4gIGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcgfCAnUkVGRVJFTkNFX0lOVkFMSUQnIHwgJ0ZPUkJJRERFTicgfCAnRVhQT1JUX1VOU1VQUE9SVEVEJyB8ICdQVUJMSUNfVEVYVF9SRVFVSVJFRCc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgZW50aXR5SWQ/OiBzdHJpbmc7XG4gIGZpZWxkPzogc3RyaW5nO1xufVxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0aW9uT21pc3Npb24geyBlbnRpdHlJZDogc3RyaW5nOyBmaWVsZD86IHN0cmluZzsgcmVhc29uOiBzdHJpbmcgfVxuZXhwb3J0IHR5cGUgUHVibGljVmFsdWUgPSBudWxsIHwgYm9vbGVhbiB8IG51bWJlciB8IHN0cmluZyB8IFB1YmxpY1ZhbHVlW10gfCB7IFtrZXk6IHN0cmluZ106IFB1YmxpY1ZhbHVlIH07XG5leHBvcnQgaW50ZXJmYWNlIFByb2plY3RlZEJsb2NrIHtcbiAgaWQ6IHN0cmluZztcbiAga2luZDogJ3BhcmFncmFwaCcgfCAnaGVhZGluZycgfCAnbGlzdF9pdGVtJyB8ICdxdW90ZSc7XG4gIHRleHQ6IHN0cmluZztcbiAgcnVieT86IHsgc3RhcnQ6IG51bWJlcjsgZW5kOiBudW1iZXI7IHRleHQ6IHN0cmluZyB9W107XG4gIGxpbmtzPzogeyBzdGFydDogbnVtYmVyOyBlbmQ6IG51bWJlcjsgdGFyZ2V0SWQ6IHN0cmluZzsgYmxvY2tJZD86IHN0cmluZzsgbGluZUlkPzogc3RyaW5nOyBzb3VyY2VWZXJzaW9uSWQ/OnN0cmluZzsgdGFyZ2V0U3RhcnQ/Om51bWJlcjsgdGFyZ2V0RW5kPzpudW1iZXIgfVtdO1xufVxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0ZWRFbnRpdHkgeyBpZDogc3RyaW5nOyBraW5kOiBFbnRpdHlLaW5kOyBuYW1lOiBzdHJpbmc7IHN0YXR1czogc3RyaW5nOyBkYXRhOiBSZWNvcmQ8c3RyaW5nLCBQdWJsaWNWYWx1ZT4gfVxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0ZWRSZWxhdGlvbiB7IGlkOiBzdHJpbmc7IGZyb21JZDogc3RyaW5nOyB0b0lkOiBzdHJpbmc7IHJlbGF0aW9uVHlwZTogc3RyaW5nOyBkaXJlY3Rpb246ICdmb3J3YXJkJyB8ICdzeW1tZXRyaWMnOyBldmlkZW5jZUlkczogc3RyaW5nW107IHZhbGlkaXR5PzpQdWJsaWNWYWx1ZSB9XG5leHBvcnQgaW50ZXJmYWNlIFByb2plY3Rpb25TZWFyY2hFbnRyeSB7IGVudGl0eUlkOiBzdHJpbmc7IGtpbmQ6IEVudGl0eUtpbmQ7IG5hbWU6IHN0cmluZzsgdGV4dDogc3RyaW5nOyBub3JtYWxpemVkOiBzdHJpbmcgfVxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0ZWRDYWxlbmRhciB7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZzsga2luZDogJ2dyZWdvcmlhbicgfCAncmVwZWF0aW5nJzsgb3JpZ2luTGFiZWw6IHN0cmluZzsgdGlja3NQZXJEYXk6IHN0cmluZzsgeWVhcnM/OiB7IG1vbnRoczogeyBuYW1lOiBzdHJpbmc7IGRheXM6IG51bWJlciB9W10gfVtdIH1cbmV4cG9ydCBpbnRlcmZhY2UgUHVibGljUHJvamVjdGlvbiB7XG4gIGZvcm1hdDogJ3NjZW5hcmlvLXByb2plY3Rpb24nO1xuICBmb3JtYXRWZXJzaW9uOiAnMS4wLjAnO1xuICB0aXRsZTogc3RyaW5nO1xuICBtYWluU3RhcnQ/OnN0cmluZztcbiAgY2FsZW5kYXJzOiBQcm9qZWN0ZWRDYWxlbmRhcltdO1xuICBlbnRpdGllczogUHJvamVjdGVkRW50aXR5W107XG4gIHJlbGF0aW9uczogUHJvamVjdGVkUmVsYXRpb25bXTtcbiAgc2VhcmNoSW5kZXg6IFByb2plY3Rpb25TZWFyY2hFbnRyeVtdO1xuICB2ZXJzaW9ucz86e2lkOnN0cmluZztwcm9qZWN0aW9uOlB1YmxpY1Byb2plY3Rpb259W107XG59XG5leHBvcnQgdHlwZSBQcm9qZWN0aW9uUmVzdWx0ID1cbiAgfCB7IG9rOiB0cnVlOyBwcm9qZWN0aW9uOiBQdWJsaWNQcm9qZWN0aW9uOyBvbWlzc2lvbnM6IFByb2plY3Rpb25PbWlzc2lvbltdOyBpZE1hcDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB9XG4gIHwgeyBvazogZmFsc2U7IGlzc3VlczogUHJvamVjdGlvbklzc3VlW107IG9taXNzaW9uczogUHJvamVjdGlvbk9taXNzaW9uW10gfTtcbmV4cG9ydCBpbnRlcmZhY2UgUHJvamVjdGlvbk9wdGlvbnMge1xuICAvKiogRXhlY3V0YWJsZSBvdXRwdXQgbXVzdCByZWplY3QgYSByZW1vdmVkIGRlcGVuZGVuY3kgaW5zdGVhZCBvZiBjaGFuZ2luZyBiZWhhdmlvci4gKi9cbiAgc3RyaWN0UmVmZXJlbmNlcz86IGJvb2xlYW47XG4gIC8qKiBSZWFkZXIgYW5kIHByb2R1Y3Rpb24gb3V0cHV0IG5ldmVyIHByb21vdGUgZHJhZnQvYWx0ZXJuYXRlIGNvbnRlbnQuICovXG4gIGNvbmZpcm1lZE9ubHk/OiBib29sZWFuO1xuICAvKiogVGhlIGNhbGxlciBtdXN0IGxvYWQgYW5kIHZlcmlmeSB0aGlzIHNuYXBzaG90IGJlZm9yZSBwcm9qZWN0aW5nIGl0LiAqL1xuICB0YXJnZXRWZXJzaW9uSWQ/OiBzdHJpbmc7XG4gIHZlcnNpb25UYXJnZXRzPzpSZWNvcmQ8c3RyaW5nLHtwdWJsaWNWZXJzaW9uSWQ6c3RyaW5nO2lkTWFwOlJlY29yZDxzdHJpbmcsc3RyaW5nPn0+O1xufVxuXG50eXBlIE9iamVjdFZhbHVlID0gUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG50eXBlIFNvdXJjZVJlY29yZCA9IHsgaWQ6IHN0cmluZzsgcHJvamVjdElkOiBzdHJpbmc7IGtpbmQ6IEVudGl0eUtpbmQ7IG5hbWU6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmc7IGRlbGV0ZWRBdD86IHN0cmluZyB8IG51bGw7IGRhdGE6IE9iamVjdFZhbHVlIH07XG50eXBlIEZpZWxkUnVsZSA9XG4gIHwgeyB0eXBlOiAndGV4dCcgfCAnZGF0ZXRpbWUnIHwgJ3JpY2gnIHwgJ3JlZicgfCAndmVyc2lvbl9yZWYnIHwgJ3JlZnMnIHwgJ251bWJlcicgfCAnYm9vbGVhbicgfCAndGltZScgfCAnY29uZGl0aW9uJyB8ICd0eXBlZCcgfCAndHlwZWRzJyB8ICdhbGxvd2VkJyB8ICd0cmlnZ2VyJyB8ICdwYXJ0aWNpcGFudHMnIHwgJ3BpbnMnIHwgJ2FuY2hvcicgfCAndHJhbnNpdGlvbnMnIHwgJ3NlbXZlcicgfCAnZXhwcmVzc2lvbicgfCAncmVzZXRzJyB8ICdleGNsdXNpb25zJyB8ICd2YWxpZGl0eScgfCAnc2NvcGUnIHwgJ2V4Y2VwdGlvbicgfCAnZXhjZXB0aW9ucycgfCAnYWx0ZXJuYXRpdmVzJyB8ICdjYW1lcmEnIHwgJ3BhcmFtZXRlcnMnIHwgJ3B1YmxpY19zdHJpbmdzJyB8ICdyZWFsX2RhdGUnIHwgJ2VzdGltYXRlJyB9XG4gIHwgeyB0eXBlOiAnZW51bSc7IHZhbHVlczogcmVhZG9ubHkgc3RyaW5nW10gfTtcbmNvbnN0IHRleHQ6IEZpZWxkUnVsZSA9IHsgdHlwZTogJ3RleHQnIH0sIHJpY2g6IEZpZWxkUnVsZSA9IHsgdHlwZTogJ3JpY2gnIH0sIHJlZjogRmllbGRSdWxlID0geyB0eXBlOiAncmVmJyB9LCByZWZzOiBGaWVsZFJ1bGUgPSB7IHR5cGU6ICdyZWZzJyB9O1xuY29uc3QgbnVtYmVyOiBGaWVsZFJ1bGUgPSB7IHR5cGU6ICdudW1iZXInIH0sIGJvb2xlYW46IEZpZWxkUnVsZSA9IHsgdHlwZTogJ2Jvb2xlYW4nIH0sIHRpbWU6IEZpZWxkUnVsZSA9IHsgdHlwZTogJ3RpbWUnIH07XG5jb25zdCBjb25kaXRpb246IEZpZWxkUnVsZSA9IHsgdHlwZTogJ2NvbmRpdGlvbicgfSwgdHlwZWQ6IEZpZWxkUnVsZSA9IHsgdHlwZTogJ3R5cGVkJyB9O1xuY29uc3Qgb25lT2YgPSAoLi4udmFsdWVzOiBzdHJpbmdbXSk6IEZpZWxkUnVsZSA9PiAoeyB0eXBlOiAnZW51bScsIHZhbHVlcyB9KTtcblxuLyoqIEFsbCBvdXRwdXQgZmllbGRzIGFyZSBlbnVtZXJhdGVkIGhlcmUuIFVua25vd24gZmllbGRzIGFyZSBuZXZlciBjb3BpZWQuICovXG5leHBvcnQgY29uc3QgUFJPSkVDVElPTl9GSUVMRFM6IFJlYWRvbmx5PFBhcnRpYWw8UmVjb3JkPEVudGl0eUtpbmQsIFJlYWRvbmx5PFJlY29yZDxzdHJpbmcsIEZpZWxkUnVsZT4+Pj4+ID0gT2JqZWN0LmZyZWV6ZSh7XG4gIGNoYXJhY3RlcjogeyByZWFkaW5nOiB0ZXh0LCBzdW1tYXJ5OiByaWNoLCBib2R5OiByaWNoLCBiaXJ0aDogdGltZSwgZGVhdGg6IHRpbWUgfSxcbiAgZ3JvdXA6IHsgZ3JvdXBUeXBlOiBvbmVPZignZGlzcGxheScsICdmYWN0aW9uJywgJ3Bsb3RfdGhyZWFkJywgJ2NhdGVnb3J5JyksIG1lbWJlcnM6IHJlZnMsIHBhcmVudElkOiByZWYsIHN1bW1hcnk6IHJpY2ggfSxcbiAgZXZlbnQ6IHsgc3VtbWFyeTogcmljaCwgdGltZSwgbGFuZVJvbGU6IG9uZU9mKCdjb21tb24nLCAncGFydGljaXBhbnRzJywgJ2JvdGgnKSwgcGFydGljaXBhbnRzOiB7IHR5cGU6ICdwYXJ0aWNpcGFudHMnIH0sIGxvY2F0aW9uSWQ6IHJlZiwgaXRlbUlkczogcmVmcyB9LFxuICBwbGFjZTogeyBwYXJlbnRJZDogcmVmLCByZWFkaW5nOiB0ZXh0LCBib2R5OiByaWNoLCBtYXBJZHM6IHJlZnMgfSxcbiAgaXRlbTogeyBpdGVtTW9kZTogb25lT2YoJ3R5cGUnLCAnaW5zdGFuY2UnKSwgdHlwZUlkOiByZWYsIGJvZHk6IHJpY2ggfSxcbiAgbm90ZTogeyBib2R5OiByaWNoLCBhdHRhY2htZW50SWRzOiByZWZzIH0sXG4gIGNoYXB0ZXI6IHsgc2NlbmVJZHM6IHJlZnMsIHN1bW1hcnk6IHJpY2ggfSxcbiAgc2NlbmU6IHsgc3VtbWFyeTogcmljaCwgYm9keTogcmljaCwgZXZlbnRJZHM6IHJlZnMsIGRpYWxvZ3VlTGluZUlkczogcmVmcywgY2hhcHRlcklkOiByZWYsIHRocmVhZElkczogcmVmcywgcG92SWQ6IHJlZiwgYmxvY2tJZHM6IHJlZnMsIHRlbnNpb246IG51bWJlciwgaW1wb3J0YW5jZTogbnVtYmVyIH0sXG4gIGdvYWw6IHsgb3duZXJJZDogcmVmLCBkZXNjcmlwdGlvbjogcmljaCwgY2hhbmdlczogcmVmcywgZXZpZGVuY2VTY2VuZUlkczogcmVmcyB9LFxuICBmbG93X25vZGU6IHsgbm9kZVR5cGU6IG9uZU9mKCdzY2VuZScsICdjaG9pY2UnLCAnYXV0b21hdGljJywgJ2NhbGwnLCAnZW50cnknLCAnZXhpdCcsICd0ZXJtaW5hbCcpLCBzY2VuZUlkOiByZWYsIGNoaWxkR3JhcGhJZDogcmVmLCB0ZXJtaW5hbFJlYXNvbjogdGV4dCwgdHJpZ2dlcjogeyB0eXBlOiAndHJpZ2dlcicgfSwgZ2F0ZTogY29uZGl0aW9uLCBleGVjdXRpb25Qb2xpY3k6IG9uZU9mKCdtYW51YWxfY2hvaWNlJywgJ2ZpcnN0X21hdGNoJywgJ2FsbF9tYXRjaCcpLCBmYWxsYmFja0lkOiByZWYsIHNob3duSW5mb3JtYXRpb25JZHM6IHJlZnMgfSxcbiAgZmxvd19lZGdlOiB7IGZyb21JZDogcmVmLCB0b0lkOiByZWYsIGVkZ2VUeXBlOiBvbmVPZignY2hvaWNlJywgJ2F1dG9tYXRpYycsICdjYWxsX3JldHVybicpLCBsYWJlbDogdGV4dCwgY29uZGl0aW9uLCBlZmZlY3RJZHM6IHJlZnMsIHByaW9yaXR5OiBudW1iZXIsIGNob2ljZUxpbmVJZDogcmVmIH0sXG4gIGZsb3dfZ3JhcGg6IHsgbm9kZUlkczogcmVmcywgZWRnZUlkczogcmVmcywgZW50cnlJZHM6IHJlZnMsIGV4aXRJZHM6IHJlZnMsIHBhcmVudEdyYXBoSWQ6IHJlZixwYXJhbWV0ZXJzOnt0eXBlOidwYXJhbWV0ZXJzJ30gfSxcbiAgZGlhbG9ndWVfbGluZTogeyB0ZXh0OiByaWNoLCBzcGVha2VySWQ6IHJlZiwgY2hvaWNlRWRnZUlkOiByZWYsIGN1ZUlkczogcmVmcyB9LFxuICBxdWVzdDogeyBrZXk6IHRleHQsIHN0YXRlVmFyaWFibGVJZDogcmVmLCBkZXNjcmlwdGlvbjogcmljaCwgZmxvd0lkczogcmVmcywgdHJhbnNpdGlvblJ1bGVzOiB7IHR5cGU6ICd0cmFuc2l0aW9ucycgfSB9LFxuICBsb3JlOiB7IGJvZHk6IHJpY2gsIGFzc2VydGlvbklkczogcmVmcywgcmVhZGluZzogdGV4dCB9LFxuICB2YXJpYWJsZTogeyBrZXk6IHRleHQsIHZhbHVlVHlwZTogb25lT2YoJ2Jvb2xlYW4nLCAnaW50ZWdlcicsICdlbnVtJyksIHNjb3BlOiBvbmVPZignc2NlbmUnLCAnY2hhcHRlcicsICdjaGFyYWN0ZXInLCAncnVuJywgJ2Fjcm9zc19ydW5zJyksIGluaXRpYWw6IHR5cGVkLCBhbGxvd2VkOiB7IHR5cGU6ICdhbGxvd2VkJyB9LCBvd25lcklkOiByZWYsIGV4dGVybmFsQ29udHJhY3RJZDogcmVmLCBleHRlcm5hbFVzZURlY2xhcmVkOiBib29sZWFuLCBkZXNjcmlwdGlvbjogcmljaCwgZGVyaXZlZDp7dHlwZTonZXhwcmVzc2lvbid9LHJlc2V0UnVsZXM6e3R5cGU6J3Jlc2V0cyd9LGV4Y2x1c2lvbnM6e3R5cGU6J2V4Y2x1c2lvbnMnfSwgdHJhbnNpdGlvblJ1bGVzOiB7IHR5cGU6ICd0cmFuc2l0aW9ucycgfSB9LFxuICBlZmZlY3Q6IHsgb3BlcmF0aW9uOiBvbmVPZignc2V0JywgJ2FkZCcsICdncmFudCcsICdjb25zdW1lJywgJ21vdmUnLCAnYXNzZXJ0JywgJ21hcmtfc2VlbicsICdyZXNldCcpLCB0YXJnZXRJZDogcmVmLCB2YWx1ZTogdHlwZWQsIGNvbmRpdGlvbiwgaW5zdGFuY2VJZDogcmVmLCByZWFzb246IHRleHQsIGV4Y2VwdGlvbkRldGFpbHM6e3R5cGU6J2V4Y2VwdGlvbid9IH0sXG4gIGFzc2VydGlvbjogeyBzdWJqZWN0SWQ6IHJlZiwgcHJlZGljYXRlOiB0ZXh0LCB2YWx1ZTogdHlwZWQsIHRydXRoS2luZDogb25lT2YoJ2F1dGhvcl90cnV0aCcsICd0ZXN0aW1vbnknLCAnYmVsaWVmJywgJ2h5cG90aGVzaXMnKSwgaG9sZGVySWQ6IHJlZiwgc291cmNlSWRzOiByZWZzLCBldmlkZW5jZUxvY2F0aW9uOiB7IHR5cGU6ICdhbmNob3InIH0sIHJlYXNvbjogdGV4dCwgdmFsaWRpdHk6e3R5cGU6J3ZhbGlkaXR5J30gfSxcbiAgZm9yZXNoYWRvdzogeyBxdWVzdGlvbjogcmljaCwgaW50ZW50OiByaWNoLCB0cnV0aEFzc2VydGlvbklkczogcmVmcywgY2x1ZUlkczogcmVmcywgcGF5b2ZmSWRzOiByZWZzLCByZXF1aXJlZEluZm86IHJlZnMsIGFsdGVybmF0aXZlSW5mbzp7dHlwZTonYWx0ZXJuYXRpdmVzJ30sZGVhZGxpbmU6e3R5cGU6J3Njb3BlJ30sZXhjZXB0aW9uczp7dHlwZTonZXhjZXB0aW9ucyd9LCBwcmVzZW50YXRpb25EZWFkbGluZTogeyB0eXBlOiAnYW5jaG9yJyB9LCByZXNvbHV0aW9uUG9saWN5OiBvbmVPZigndGhpc193b3JrJywgJ3NlcXVlbCcsICdpbnRlbnRpb25hbF9vcGVuJywgJ3JlZF9oZXJyaW5nJywgJ3VuZGVjaWRlZCcsICdyZWplY3RlZCcpIH0sXG4gIGRpc2Nsb3N1cmU6IHsgZm9yZXNoYWRvd0lkOiByZWYsIGFuY2hvcjogeyB0eXBlOiAnYW5jaG9yJyB9LCBzdGFnZTogb25lT2YoJ2hpbnQnLCAnc3VzcGljaW9uJywgJ3JlaW5mb3JjZScsICdyZXZlYWwnLCAnYWx0ZXJuYXRpdmUnKSwgcm9sZTogb25lT2YoJ2NsdWUnLCAncGF5b2ZmJyksIHRhcmdldFNjb3BlOnt0eXBlOidzY29wZSd9LGNvbmRpdGlvbiwga25vd2xlZGdlRWZmZWN0czogcmVmcyB9LFxuICBhdHRhY2htZW50OiB7IGRpc3BsYXlOYW1lOiB0ZXh0IH0sXG4gIHNvdXJjZTogeyBhY2Nlc3NlZEF0Ont0eXBlOidkYXRldGltZSd9LGV4Y2VycHRMb2NhdGlvbjp0ZXh0LGF0dGFjaG1lbnRJZDpyZWYsc291cmNlVHlwZTogb25lT2YoJ3dlYicsICdmaWxlJywgJ2Jvb2snLCAnb2JzZXJ2YXRpb24nKSwgbG9jYXRvcjogdGV4dCwgaW50ZXJwcmV0YXRpb246IHJpY2gsIHJlZGlzdHJpYnV0aW9uQWxsb3dlZDogYm9vbGVhbiB9LFxuICBjdWU6IHsgYW5jaG9yOiB7IHR5cGU6ICdhbmNob3InIH0sIGN1ZVR5cGU6IHRleHQsIGF0dGFjaG1lbnRJZDogcmVmLCBzcGVha2VySWQ6IHJlZiwgZXhwcmVzc2lvbjogdGV4dCwgd2FpdE1zOiBudW1iZXIsbWVkaWFUaW1lOm51bWJlcixjYW1lcmE6e3R5cGU6J2NhbWVyYSd9IH0sXG4gIHN0b3J5Ym9hcmRfZnJhbWU6IHsgYW5jaG9yOiB7IHR5cGU6ICdhbmNob3InIH0sIG1lZGlhU3RhcnRNczogbnVtYmVyLCBtZWRpYUVuZE1zOiBudW1iZXIsIHJlZmVyZW5jZUFzc2V0SWQ6IHJlZiwgZmluYWxBc3NldElkOiByZWYsIGN1ZUlkczogcmVmcywgY2FwdGlvbjogcmljaCB9LFxuICBsb2NhbGl6YXRpb246IHsgc291cmNlTGluZUlkOiByZWYsIGxhbmd1YWdlOiB0ZXh0LCB0ZXh0OiByaWNoLCBzdGFnZTogb25lT2YoJ2RyYWZ0JywgJ3Jldmlld2VkJywgJ25lZWRzX3JldmlldycpLCByZWNvcmRpbmdJZHM6IHJlZnMgfSxcbiAgcmVjb3JkaW5nOiB7IHNvdXJjZUxpbmVJZDogcmVmLCBsYW5ndWFnZTogdGV4dCwgdHJhbnNsYXRpb25JZDogcmVmLCBhdHRhY2htZW50SWQ6IHJlZiwgc3RhZ2U6IG9uZU9mKCdwbGFubmVkJywgJ3JlY29yZGVkJywgJ3Jldmlld2VkJywgJ25lZWRzX3JldmlldycpIH0sXG4gIHRlcm1pbm9sb2d5OiB7IGNhbm9uaWNhbDogdGV4dCwgcmVhZGluZzogdGV4dCx2YXJpYW50czp7dHlwZToncHVibGljX3N0cmluZ3MnfSx2YWxpZGl0eTp7dHlwZTondmFsaWRpdHknfSxleGNlcHRpb25zOnt0eXBlOidleGNlcHRpb25zJ30sIGxhbmd1YWdlOiB0ZXh0LCB1c2FnZU5vdGVzOiByaWNoLCB2b2ljZU93bmVySWQ6IHJlZiB9LFxuICB2b2ljZV9ydWxlOntjaGFyYWN0ZXJJZDpyZWYsdmFsaWRpdHk6e3R5cGU6J3ZhbGlkaXR5J30sZmlyc3RQZXJzb246dGV4dCxhZGRyZXNzaW5nOnRleHQscGhyYXNpbmc6dGV4dCxleGFtcGxlczpyaWNoLGV4Y2VwdGlvbnM6e3R5cGU6J2V4Y2VwdGlvbnMnfX0sXG4gIG1hcDogeyBwbGFjZUlkOiByZWYsIGNvb3JkaW5hdGVTeXN0ZW06IG9uZU9mKCdub3JtYWxpemVkJyksIGF0dGFjaG1lbnRJZDogcmVmLCBwYXJlbnRNYXBJZDogcmVmLCBwaW5zOiB7IHR5cGU6ICdwaW5zJyB9IH0sXG4gIHRyYXZlbF9yb3V0ZTogeyBmcm9tUGxhY2VJZDogcmVmLCB0b1BsYWNlSWQ6IHJlZiwgZGlyZWN0aW9uOiBvbmVPZignb25lX3dheScsICd0d29fd2F5JyksIG1ldGhvZDogdGV4dCB9LFxuICBjb2xsZWN0aW9uOiB7IG1vZGU6IG9uZU9mKCdmaXhlZCcpLCBtZW1iZXJJZHM6IHJlZnMgfSxcbiAgZ2FtZXBsYXlfc3BlYzogeyBzY2VuZUlkOiByZWYsIGFjdGlvbjogcmljaCwgbWVjaGFuaWM6dGV4dCx0dXRvcmlhbDpyaWNoLHJld2FyZDp0eXBlZCxxdWVzdElkOiByZWYsIHRhc2tJZHM6IHJlZnMsaW50ZW50aW9uYWxEaWZmZXJlbmNlOnRleHQgfSxcbiAgcHJvZHVjdGlvbl90YXNrOiB7IGRlYWRsaW5lOnt0eXBlOidyZWFsX2RhdGUnfSxlc3RpbWF0ZTp7dHlwZTonZXN0aW1hdGUnfSxibG9ja2luZ1JlYXNvbjp0ZXh0LHRhcmdldElkczogcmVmcywgc3RhZ2U6IG9uZU9mKCd3cml0aW5nJywgJ3JldmlldycsICdpbXBsZW1lbnRhdGlvbicsICd0cmFuc2xhdGlvbicsICdyZWNvcmRpbmcnLCAndmVyaWZpY2F0aW9uJywgJ3B1YmxpY2F0aW9uJyksIHByb2dyZXNzOiBvbmVPZigndG9kbycsICdkb2luZycsICdkb25lJywgJ25lZWRzX3JldmlldycpLCBkZXBlbmRzT246IHJlZnMgfSxcbiAgbWVkaWFfdmFyaWFudDogeyBtZWRpdW06IG9uZU9mKCdnYW1lJywgJ25vdmVsJywgJ3ZpZGVvJywgJ2F1ZGlvJywgJ3Byb21vdGlvbicsICdjdXN0b20nKSxiYXNlU25hcHNob3RJZDp7dHlwZTondmVyc2lvbl9yZWYnfSxwcmV2aW91c1ZhcmlhbnRJZDpyZWYscmVsZWFzZUF0Ont0eXBlOidkYXRldGltZSd9LCBib2R5OiByaWNoLCBzb3VyY2VJZHM6IHJlZnMsIG5lZWRzUmV2aWV3OiBib29sZWFuIH0sXG4gIGV4dGVybmFsX2NvbnRyYWN0OiB7IGtleTogdGV4dCwgb3duZXI6IG9uZU9mKCd0b29sJywgJ2dhbWUnKSwgaW5wdXRUeXBlOiBvbmVPZignYm9vbGVhbicsICdpbnRlZ2VyJywgJ2VudW0nKSwgb3V0cHV0VHlwZTogb25lT2YoJ2Jvb2xlYW4nLCAnaW50ZWdlcicsICdlbnVtJyksIG1pc3NpbmdQb2xpY3k6IG9uZU9mKCd1bmtub3duJywgJ2Jsb2NrJyksIGRlc2NyaXB0aW9uOiByaWNoLCB2ZXJzaW9uOiB7IHR5cGU6ICdzZW12ZXInIH0sIHN0dWJWYWx1ZXM6IHsgdHlwZTogJ3R5cGVkcycgfSB9LFxufSk7XG5leHBvcnQgY29uc3QgUFJPSkVDVEFCTEVfS0lORFMgPSBPYmplY3QuZnJlZXplKE9iamVjdC5rZXlzKFBST0pFQ1RJT05fRklFTERTKSBhcyBFbnRpdHlLaW5kW10pO1xuY29uc3QgQkVIQVZJT1JfUkVGUyA9IG5ldyBTZXQoWydmcm9tSWQnLCAndG9JZCcsICdlZmZlY3RJZHMnLCAnbm9kZUlkcycsICdlZGdlSWRzJywgJ2VudHJ5SWRzJywgJ2V4aXRJZHMnLCAnY2hpbGRHcmFwaElkJywgJ2ZhbGxiYWNrSWQnLCAndGFyZ2V0SWQnLCAnaW5zdGFuY2VJZCcsICdzdGF0ZVZhcmlhYmxlSWQnLCAnZXh0ZXJuYWxDb250cmFjdElkJywgJ3Nob3duSW5mb3JtYXRpb25JZHMnLCAna25vd2xlZGdlRWZmZWN0cyddKTtcbmNvbnN0IEZPUkJJRERFTl9GSUVMRFMgPSBuZXcgU2V0KFsnaGFuZG9mZlJlY2VpcHQnLCdhdXRob3JOb3RlcycsICdhbGlhc2VzJywgJ3F1b3RlZFRleHQnLCAnb3JpZ2luTGluZUlkcycsICdyZXBsYWNlZEJ5TGluZUlkcycsICdsaW5lYWdlJywgJ2N1c3RvbVZhbHVlcycsICdhc3NldFBhdGgnLCAnbGljZW5zZU5vdGUnLCAnaGlzdG9yeScsICdxdWVyeScsICdzb3VyY2VIYXNoJ10pO1xuY29uc3QgQkxPQ0tfS0lORFMgPSBuZXcgU2V0KFsncGFyYWdyYXBoJywgJ2hlYWRpbmcnLCAnbGlzdF9pdGVtJywgJ3F1b3RlJ10pO1xuY29uc3QgQVNTRVRfVFlQRVM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7ICdpbWFnZS9wbmcnOiAncG5nJywgJ2ltYWdlL2pwZWcnOiAnanBnJywgJ2ltYWdlL2dpZic6ICdnaWYnLCAnaW1hZ2Uvd2VicCc6ICd3ZWJwJywgJ2F1ZGlvL3dhdic6ICd3YXYnLCAnYXVkaW8vbXBlZyc6ICdtcDMnLCAnYXBwbGljYXRpb24vcGRmJzogJ3BkZicsICd2aWRlby9tcDQnOidtcDQnLCd2aWRlby93ZWJtJzond2VibScsJ3ZpZGVvL29nZyc6J29ndicsJ2F1ZGlvL29nZyc6J29nZycsJ3RleHQvcGxhaW4nOid0eHQnLCdhcHBsaWNhdGlvbi9qc29uJzonanNvbicsJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbSc6J2JpbicgfTtcbmNvbnN0IFRJQ0sgPSAvXig/OjB8LVsxLTldWzAtOV17MCwzN318WzEtOV1bMC05XXswLDM3fSkkLztcbmNvbnN0IG9iamVjdCA9ICh2YWx1ZTogdW5rbm93bik6IE9iamVjdFZhbHVlIHwgdW5kZWZpbmVkID0+IHZhbHVlICE9PSBudWxsICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUgYXMgT2JqZWN0VmFsdWUgOiB1bmRlZmluZWQ7XG5jb25zdCBvd24gPSAodmFsdWU6IE9iamVjdFZhbHVlIHwgdW5kZWZpbmVkLCBrZXk6IHN0cmluZyk6IHVua25vd24gPT4gdmFsdWUgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHZhbHVlLCBrZXkpID8gdmFsdWVba2V5XSA6IHVuZGVmaW5lZDtcbmNvbnN0IGhhc093biA9ICh2YWx1ZTogb2JqZWN0LCBrZXk6IHN0cmluZyk6IGJvb2xlYW4gPT4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHZhbHVlLCBrZXkpO1xuY29uc3QgZW1wdHkgPSAodmFsdWU6IHVua25vd24pOiBib29sZWFuID0+IHZhbHVlID09IG51bGwgfHwgdmFsdWUgPT09ICcnIHx8IChBcnJheS5pc0FycmF5KHZhbHVlKSAmJiB2YWx1ZS5sZW5ndGggPT09IDApO1xuY29uc3QgaW50ZWdlciA9ICh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIG51bWJlciA9PiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmIE51bWJlci5pc1NhZmVJbnRlZ2VyKHZhbHVlKTtcblxuLyoqIFB1cmUsIGZhaWwtY2xvc2VkIHByb2plY3Rpb24uIFB1YmxpYyBwcm9zZSBpcyBzdXBwbGllZCBieSB0aGUgYXV0aG9yOyB0aGlzIGlzIG5vdCBhIHRleHQgcmVkYWN0b3IuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUHJvamVjdGlvbihwcm9qZWN0OiBQcm9qZWN0RGF0YSwgcHJvZmlsZUlkOiBzdHJpbmcsIG9wdGlvbnM6IFByb2plY3Rpb25PcHRpb25zID0ge30pOiBQcm9qZWN0aW9uUmVzdWx0IHtcbiAgY29uc3QgaXNzdWVzOiBQcm9qZWN0aW9uSXNzdWVbXSA9IFtdLCBvbWlzc2lvbnM6IFByb2plY3Rpb25PbWlzc2lvbltdID0gW107XG4gIGlmICghcHJvamVjdCB8fCAhQXJyYXkuaXNBcnJheShwcm9qZWN0LmVudGl0aWVzKSB8fCAhQXJyYXkuaXNBcnJheShwcm9qZWN0LnJlbGF0aW9ucykgfHwgcHJvamVjdC5lbnRpdGllcy5zb21lKGVudGl0eSA9PiAhZW50aXR5IHx8IHR5cGVvZiBlbnRpdHkuaWQgIT09ICdzdHJpbmcnIHx8ICFvYmplY3QoZW50aXR5LmRhdGEpKSkgcmV0dXJuIHsgb2s6IGZhbHNlLCBpc3N1ZXM6IFt7IGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcsIG1lc3NhZ2U6ICfkvZzlk4Hjga7lhazplovlhYPjg4fjg7zjgr/jgYzkuI3mraPjgafjgZnjgIInIH1dLCBvbWlzc2lvbnMgfTtcbiAgY29uc3QgZmFpbCA9IChjb2RlOiBQcm9qZWN0aW9uSXNzdWVbJ2NvZGUnXSwgbWVzc2FnZTogc3RyaW5nLCBlbnRpdHlJZD86IHN0cmluZywgZmllbGQ/OiBzdHJpbmcpID0+IHsgaXNzdWVzLnB1c2goeyBjb2RlLCBtZXNzYWdlLCAuLi4oZW50aXR5SWQgPyB7IGVudGl0eUlkIH0gOiB7fSksIC4uLihmaWVsZCA/IHsgZmllbGQgfSA6IHt9KSB9KTsgfTtcbiAgY29uc3Qgb21pdCA9IChlbnRpdHlJZDogc3RyaW5nLCByZWFzb246IHN0cmluZywgZmllbGQ/OiBzdHJpbmcpID0+IHsgb21pc3Npb25zLnB1c2goeyBlbnRpdHlJZCwgcmVhc29uLCAuLi4oZmllbGQgPyB7IGZpZWxkIH0gOiB7fSkgfSk7IH07XG4gIGNvbnN0IHNvdXJjZSA9IG5ldyBNYXA8c3RyaW5nLCBTb3VyY2VSZWNvcmQ+KCk7XG4gIGZvciAoY29uc3QgZW50aXR5IG9mIHByb2plY3QuZW50aXRpZXMpIHtcbiAgICBpZiAoc291cmNlLmhhcyhlbnRpdHkuaWQpKSBmYWlsKCdWQUxJREFUSU9OX0ZBSUxFRCcsICflkIzjgZhJROOBruaDheWgseOBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicsIGVudGl0eS5pZCk7XG4gICAgc291cmNlLnNldChlbnRpdHkuaWQsIGVudGl0eSBhcyB1bmtub3duIGFzIFNvdXJjZVJlY29yZCk7XG4gIH1cbiAgY29uc3QgcHJvZmlsZSA9IHNvdXJjZS5nZXQocHJvZmlsZUlkKTtcbiAgaWYgKCFwcm9maWxlIHx8IHByb2ZpbGUua2luZCAhPT0gJ3Byb2plY3Rpb25fcHJvZmlsZScgfHwgcHJvZmlsZS5wcm9qZWN0SWQgIT09IHByb2plY3QucHJvamVjdElkIHx8IHByb2ZpbGUuZGVsZXRlZEF0KSB7XG4gICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBpc3N1ZXM6IFt7IGNvZGU6ICdSRUZFUkVOQ0VfSU5WQUxJRCcsIG1lc3NhZ2U6ICfjgZPjga7kvZzlk4Hjga7lhazplovnr4Tlm7LjgpLpgbjjgpPjgafjgY/jgaDjgZXjgYTjgIInLCBlbnRpdHlJZDogcHJvZmlsZUlkIH1dLCBvbWlzc2lvbnMgfTtcbiAgfVxuICBjb25zdCBwb2xpY3kgPSBwcm9maWxlLmRhdGE7XG4gIGlmIChwb2xpY3kuc291cmNlVmVyc2lvbklkICE9IG51bGwgJiYgcG9saWN5LnNvdXJjZVZlcnNpb25JZCAhPT0gb3B0aW9ucy50YXJnZXRWZXJzaW9uSWQgJiYgcG9saWN5LnNvdXJjZVZlcnNpb25JZCAhPT0gcHJvamVjdC5yZXZpc2lvbikgZmFpbCgnVkFMSURBVElPTl9GQUlMRUQnLCAn5YWs6ZaL56+E5Zuy44GM5Zu65a6a44GV44KM44Gf54mI44Go5Ye65Yqb5YWD44Gu54mI44GM5LiA6Ie044GX44G+44Gb44KT44CCJywgcHJvZmlsZUlkLCAnc291cmNlVmVyc2lvbklkJyk7XG4gIGlmIChvYmplY3QocG9saWN5LnJvdXRlU2NvcGUpPy50YXJnZXRTbmFwc2hvdElkICE9IG51bGwgJiYgb2JqZWN0KHBvbGljeS5yb3V0ZVNjb3BlKSEudGFyZ2V0U25hcHNob3RJZCAhPT0gb3B0aW9ucy50YXJnZXRWZXJzaW9uSWQpIGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi+evhOWbsuOBruWvvuixoXNuYXBzaG9044KS6Kqt44G/6L6844KT44Gn44GP44Gg44GV44GE44CCJywgcHJvZmlsZUlkLCAncm91dGVTY29wZS50YXJnZXRTbmFwc2hvdElkJyk7XG4gIGlmIChwb2xpY3kuaWRQb2xpY3kgIT0gbnVsbCAmJiAhWydyZW1hcCcsICdwcmVzZXJ2ZSddLmluY2x1ZGVzKFN0cmluZyhwb2xpY3kuaWRQb2xpY3kpKSkgZmFpbCgnVkFMSURBVElPTl9GQUlMRUQnLCAn5YWs6ZaLSUTjga7mlrnlvI/jgYzkuI3mraPjgafjgZnjgIInLCBwcm9maWxlSWQsICdpZFBvbGljeScpO1xuICBpZiAocG9saWN5LmluY2x1ZGVBdXRob3JOb3RlcyA9PT0gdHJ1ZSkgZmFpbCgnRk9SQklEREVOJywgJ+WFrOmWi+eUqOWHuuWKm+OBq+S9nOiAheODoeODouOBr+WQq+OCgeOCieOCjOOBvuOBm+OCk+OAgicsIHByb2ZpbGVJZCwgJ2luY2x1ZGVBdXRob3JOb3RlcycpO1xuICBjb25zdCB0aXRsZSA9IG93bihwb2xpY3ksICdwdWJsaWNUaXRsZScpO1xuICBpZiAodHlwZW9mIHRpdGxlICE9PSAnc3RyaW5nJyB8fCAhdGl0bGUudHJpbSgpKSBmYWlsKCdQVUJMSUNfVEVYVF9SRVFVSVJFRCcsICfkvZzogIXjgYznorroqo3jgZfjgZ/lhazplovnlKjjga7kvZzlk4HlkI3jgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLCBwcm9maWxlSWQsICdwdWJsaWNUaXRsZScpO1xuICBjb25zdCBpbmNsdWRlZElkcyA9IG93bihwb2xpY3ksICdpbmNsdWRlZElkcycpLCBhbGxvd2VkS2luZHMgPSBvd24ocG9saWN5LCAnYWxsb3dlZEtpbmRzJyk7XG4gIGlmICghQXJyYXkuaXNBcnJheShpbmNsdWRlZElkcykgfHwgaW5jbHVkZWRJZHMuc29tZShpZCA9PiB0eXBlb2YgaWQgIT09ICdzdHJpbmcnKSB8fCBuZXcgU2V0KGluY2x1ZGVkSWRzKS5zaXplICE9PSBpbmNsdWRlZElkcy5sZW5ndGgpIGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi+OBmeOCi0lE44KS6YeN6KSH44Gu44Gq44GE5LiA6Kan44Gn5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJywgcHJvZmlsZUlkLCAnaW5jbHVkZWRJZHMnKTtcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFsbG93ZWRLaW5kcykgfHwgYWxsb3dlZEtpbmRzLmxlbmd0aCA9PT0gMCB8fCBhbGxvd2VkS2luZHMuc29tZShraW5kID0+IHR5cGVvZiBraW5kICE9PSAnc3RyaW5nJyB8fCAhaGFzT3duKFBST0pFQ1RJT05fRklFTERTLCBraW5kKSkpIGZhaWwoJ0VYUE9SVF9VTlNVUFBPUlRFRCcsICflhazplovlj6/og73jgarnqK7poZ7jgaDjgZHjgpLmmI7npLrnmoTjgavpgbjjgpPjgafjgY/jgaDjgZXjgYTjgIInLCBwcm9maWxlSWQsICdhbGxvd2VkS2luZHMnKTtcbiAgY29uc3QgcHVibGljVGV4dHMgPSBvYmplY3Qob3duKHBvbGljeSwgJ3B1YmxpY1RleHRzJykpID8/IHt9O1xuICBjb25zdCBwdWJsaWNJZHMgPSBvYmplY3Qob3duKHBvbGljeSwgJ3B1YmxpY0lkcycpKSA/PyB7fTtcbiAgY29uc3QgbmFtZVBvbGljaWVzID0gb2JqZWN0KG93bihwb2xpY3ksICduYW1lUG9saWN5JykpO1xuICBjb25zdCBzY29wZUlkcyA9IHNjb3BlZEVudGl0eUlkcyhzb3VyY2UsIHBvbGljeSwgcHJvamVjdC5wcm9qZWN0SWQsIHB1YmxpY1RleHRzLCBmYWlsKTtcbiAgY29uc3Qgc3RhdHVzZXMgPSBBcnJheS5pc0FycmF5KHBvbGljeS5pbmNsdWRlZFN0YXR1c2VzKSA/IHBvbGljeS5pbmNsdWRlZFN0YXR1c2VzIDogWydjb25maXJtZWQnXTtcbiAgaWYgKHN0YXR1c2VzLnNvbWUoc3RhdHVzID0+ICFbJ2NvbmZpcm1lZCcsICdwcm92aXNpb25hbCcsICduZWVkc19yZXZpZXcnXS5pbmNsdWRlcyhTdHJpbmcoc3RhdHVzKSkpKSBmYWlsKCdGT1JCSURERU4nLCAn5rKh5qGI44Go5L2c6ICF5Yil5qGI44Gv5YWs6ZaL5a++6LGh44Gr44Gn44GN44G+44Gb44KT44CCJywgcHJvZmlsZUlkLCAnaW5jbHVkZWRTdGF0dXNlcycpO1xuICBjb25zdCBzZWxlY3RlZDogU291cmNlUmVjb3JkW10gPSBbXTtcbiAgY29uc3QgbmFtZXMgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xuICBjb25zdCBleHBsaWNpdFB1YmxpY0lkcyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XG4gIGNvbnN0IGluY2x1ZGVkID0gbmV3IFNldDxzdHJpbmc+KEFycmF5LmlzQXJyYXkoaW5jbHVkZWRJZHMpID8gaW5jbHVkZWRJZHMgOiBbXSk7XG4gIC8vIFNlbGVjdGlvbiBpcyBhIHNldDsgdGhlIGNob3NlbiBjb250ZW50IHZlcnNpb24gb3ducyB0aGUgcHJlc2VudGF0aW9uIG9yZGVyLlxuICBjb25zdCBvcmRlcmVkSWRzID0gWy4uLnNvdXJjZS5rZXlzKCldLmZpbHRlcihpZCA9PiBpbmNsdWRlZC5oYXMoaWQpKTtcbiAgZm9yIChjb25zdCBpZCBvZiBpbmNsdWRlZCkgaWYgKCFzb3VyY2UuaGFzKGlkKSkgb3JkZXJlZElkcy5wdXNoKGlkKTtcbiAgZm9yIChjb25zdCBpZCBvZiBvcmRlcmVkSWRzKSB7XG4gICAgY29uc3QgZW50aXR5ID0gc291cmNlLmdldChpZCk7XG4gICAgaWYgKCFlbnRpdHkgfHwgZW50aXR5LnByb2plY3RJZCAhPT0gcHJvamVjdC5wcm9qZWN0SWQpIHsgZmFpbCgnUkVGRVJFTkNFX0lOVkFMSUQnLCAn5L2c5ZOB5YaF44Gr44Gq44GE5oOF5aCx44GM5YWs6ZaL56+E5Zuy44Gr5ZCr44G+44KM44Gm44GE44G+44GZ44CCJywgaWQpOyBjb250aW51ZTsgfVxuICAgIGlmIChzY29wZUlkcyAmJiAhc2NvcGVJZHMuaGFzKGlkKSkgeyBvbWl0KGlkLCAn5oyH5a6a44GX44Gf56ug44G+44Gf44Gv44Kw44Op44OV44Gu56+E5Zuy5aSWJyk7IGNvbnRpbnVlOyB9XG4gICAgaWYgKGVudGl0eS5kZWxldGVkQXQgfHwgIXN0YXR1c2VzLmluY2x1ZGVzKGVudGl0eS5zdGF0dXMpIHx8IChvcHRpb25zLmNvbmZpcm1lZE9ubHkgJiYgZW50aXR5LnN0YXR1cyAhPT0gJ2NvbmZpcm1lZCcpKSB7IG9taXQoaWQsICfliYrpmaTmuIjjgb/jgIHmnKrnorrlrprjgIHmsqHmoYjjgb7jgZ/jga/liKXmoYgnKTsgY29udGludWU7IH1cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoYWxsb3dlZEtpbmRzKSB8fCAhYWxsb3dlZEtpbmRzLmluY2x1ZGVzKGVudGl0eS5raW5kKSkgeyBvbWl0KGlkLCAn6Kix5Y+v44GV44KM44Gm44GE44Gq44GE56iu6aGeJyk7IGNvbnRpbnVlOyB9XG4gICAgaWYgKCFoYXNPd24oUFJPSkVDVElPTl9GSUVMRFMsIGVudGl0eS5raW5kKSkgeyBmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCAn44GT44Gu56iu6aGe44Gu5a6J5YWo44Gq5oqV5b2x44Gv5pyq5a++5b+c44Gn44GZ44CCJywgaWQpOyBjb250aW51ZTsgfVxuICAgIGlmIChbJ3NjZW5lJywgJ2Zsb3dfbm9kZSddLmluY2x1ZGVzKGVudGl0eS5raW5kKSAmJiBvYmplY3QoZW50aXR5LmRhdGEucmV1c2UpPy5tb2RlICE9PSB1bmRlZmluZWQgJiYgb2JqZWN0KGVudGl0eS5kYXRhLnJldXNlKT8ubW9kZSAhPT0gJ2Nsb25lJykgeyBmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCAn5Zu65a6a5YWx6YCa5YWD44Go5L2/55So5YWI44KS5ZCI44KP44Gb44Gf5YWs6ZaL56+E5Zuy44O75YWs6ZaL5ZCN44O75pys5paH44KS56K66KqN44GZ44KL5Ye65Yqb44Gv5pyq5a++5b+c44Gn44GZ44CC5YaN5Yip55So44KS55yB55Wl44GX44Gf5Ye65Yqb44Gv5L2c5oiQ44Gn44GN44G+44Gb44KT44CCJywgaWQsICdyZXVzZScpOyBjb250aW51ZTsgfVxuICAgIGNvbnN0IGJ5RW50aXR5SWQgPSBvYmplY3Qob3duKG5hbWVQb2xpY2llcywgJ2J5RW50aXR5SWQnKSk7XG4gICAgY29uc3QgbmFtZVBvbGljeSA9IG9iamVjdChvd24oYnlFbnRpdHlJZCwgaWQpKSA/PyBvYmplY3Qob3duKG5hbWVQb2xpY2llcywgJ2RlZmF1bHRQb2xpY3knKSkgPz8gKHR5cGVvZiBuYW1lUG9saWNpZXM/Lm1vZGUgPT09ICdzdHJpbmcnID8gbmFtZVBvbGljaWVzIDogdW5kZWZpbmVkKTtcbiAgICBpZiAobmFtZVBvbGljeT8ubW9kZSA9PT0gJ2V4Y2x1ZGUnKSB7IG9taXQoaWQsICfkvZzogIXjgYzpnZ7lhazplovjgpLpgbjmip4nKTsgY29udGludWU7IH1cbiAgICBsZXQgcHVibGljTmFtZTogdW5rbm93bjtcbiAgICBpZiAobmFtZVBvbGljeT8ubW9kZSA9PT0gJ3JlcGxhY2UnKSBwdWJsaWNOYW1lID0gbmFtZVBvbGljeS5yZXBsYWNlbWVudDtcbiAgICBlbHNlIGlmIChuYW1lUG9saWN5Py5tb2RlID09PSAnYW5vbnltaXplJykgeyBwdWJsaWNOYW1lID0gbmFtZVBvbGljeS5wdWJsaWNOYW1lOyBpZiAodHlwZW9mIG5hbWVQb2xpY3kucHVibGljSWQgPT09ICdzdHJpbmcnKSBleHBsaWNpdFB1YmxpY0lkcy5zZXQoaWQsIG5hbWVQb2xpY3kucHVibGljSWQpOyB9XG4gICAgZWxzZSBpZiAobmFtZVBvbGljeT8ubW9kZSA9PT0gJ2FsaWFzJykge1xuICAgICAgY29uc3QgYWxpYXNlcyA9IEFycmF5LmlzQXJyYXkoZW50aXR5LmRhdGEuYWxpYXNlcykgPyBlbnRpdHkuZGF0YS5hbGlhc2VzIDogW107XG4gICAgICBjb25zdCBhbGlhcyA9IGFsaWFzZXMubWFwKG9iamVjdCkuZmluZCh2YWx1ZSA9PiB2YWx1ZT8uaWQgPT09IG5hbWVQb2xpY3kuYWxpYXNJZCk7XG4gICAgICBwdWJsaWNOYW1lID0gYWxpYXM/LnRleHQ7XG4gICAgfSBlbHNlIGlmIChlbnRpdHkubmFtZSA9PT0gJycpIHB1YmxpY05hbWUgPSAnJztcbiAgICBpZiAodHlwZW9mIHB1YmxpY05hbWUgIT09ICdzdHJpbmcnIHx8IChlbnRpdHkubmFtZSAhPT0gJycgJiYgIXB1YmxpY05hbWUudHJpbSgpKSkgeyBmYWlsKCdQVUJMSUNfVEVYVF9SRVFVSVJFRCcsICfjgZPjga7mg4XloLHjga7lhazplovlkI3jgb7jgZ/jga/lhazplovliKXlkI3jgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLCBpZCwgJ25hbWVQb2xpY3knKTsgY29udGludWU7IH1cbiAgICBuYW1lcy5zZXQoaWQsIHB1YmxpY05hbWUpO1xuICAgIHNlbGVjdGVkLnB1c2goZW50aXR5KTtcbiAgfVxuICBjb25zdCBpZE1hcDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IE9iamVjdC5jcmVhdGUobnVsbCkgYXMgUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgY29uc3QgZW1pdHRlZElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBsZXQgc2VxdWVuY2UgPSAwO1xuICBjb25zdCBhZGRJZCA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChpZE1hcCwgaWQpKSByZXR1cm47XG4gICAgY29uc3QgY2FuZGlkYXRlID0gZXhwbGljaXRQdWJsaWNJZHMuZ2V0KGlkKSA/PyBvd24ocHVibGljSWRzLCBpZCkgPz8gKHBvbGljeS5pZFBvbGljeSA9PT0gJ3ByZXNlcnZlJyA/IGlkIDogYHB1YmxpYy0ke1N0cmluZygrK3NlcXVlbmNlKS5wYWRTdGFydCg2LCAnMCcpfWApO1xuICAgIGlmICh0eXBlb2YgY2FuZGlkYXRlICE9PSAnc3RyaW5nJyB8fCAhL15bYS16QS1aMC05XVthLXpBLVowLTkuXy1dezAsMTI3fSQvLnRlc3QoY2FuZGlkYXRlKSB8fCBlbWl0dGVkSWRzLmhhcyhjYW5kaWRhdGUpKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi0lE44GM5LiN5q2j44CB44G+44Gf44Gv6YeN6KSH44GX44Gm44GE44G+44GZ44CCJywgaWQsICdwdWJsaWNJZHMnKTsgcmV0dXJuOyB9XG4gICAgaWRNYXBbaWRdID0gY2FuZGlkYXRlOyBlbWl0dGVkSWRzLmFkZChjYW5kaWRhdGUpO1xuICB9O1xuICBzZWxlY3RlZC5mb3JFYWNoKGVudGl0eSA9PiBhZGRJZChlbnRpdHkuaWQpKTtcbiAgLy8gUHVibGljIGJsb2NrIElEcyBiZWxvbmcgdG8gdGhlIGF1dGhvci1wcm92aWRlZCBkb2N1bWVudHMsIG5ldmVyIHRvIGhpZGRlbiBzb3VyY2UgZG9jdW1lbnRzLlxuICBjb25zdCBhbGxvd2VkRmllbGRzID0gb2JqZWN0KG93bihwb2xpY3ksICdhbGxvd2VkRmllbGRzJykpO1xuICBjb25zdCBleGNsdWRlZEZpZWxkcyA9IEFycmF5LmlzQXJyYXkocG9saWN5LmV4Y2x1ZGVkRmllbGRzKSA/IHBvbGljeS5leGNsdWRlZEZpZWxkcyA6IFtdO1xuICBjb25zdCBwdWJsaWNCbG9ja0lkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBwdWJsaWNCbG9ja093bmVycz1uZXcgTWFwPHN0cmluZyxzdHJpbmc+KCksc291cmNlQmxvY2tPd25lcnM9bmV3IE1hcDxzdHJpbmcsc3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IGVudGl0eSBvZiBzZWxlY3RlZCkge1xuICAgIGZvcihjb25zdCB2YWx1ZSBvZiBPYmplY3QudmFsdWVzKGVudGl0eS5kYXRhKSlpZihBcnJheS5pc0FycmF5KHZhbHVlKSlmb3IoY29uc3QgcmF3IG9mIHZhbHVlKXtjb25zdCBibG9jaz1vYmplY3QocmF3KTtpZih0eXBlb2YgYmxvY2s/LmlkPT09J3N0cmluZycmJnR5cGVvZiBibG9jay50ZXh0PT09J3N0cmluZycpc291cmNlQmxvY2tPd25lcnMuc2V0KGJsb2NrLmlkLGVudGl0eS5pZCk7fVxuICAgIGNvbnN0IGZpZWxkcyA9IG9iamVjdChvd24ocHVibGljVGV4dHMsIGVudGl0eS5pZCkpO1xuICAgIGNvbnN0IHNjaGVtYSA9IFBST0pFQ1RJT05fRklFTERTW2VudGl0eS5raW5kXSE7XG4gICAgY29uc3QgZXhwbGljaXQgPSBvd24oYWxsb3dlZEZpZWxkcywgZW50aXR5LmtpbmQpO1xuICAgIGZvciAoY29uc3QgW2ZpZWxkLCBydWxlXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWEpKSBpZiAocnVsZS50eXBlID09PSAncmljaCcgJiYgKCFBcnJheS5pc0FycmF5KGV4cGxpY2l0KSB8fCBleHBsaWNpdC5pbmNsdWRlcyhmaWVsZCkpICYmICFleGNsdWRlZEZpZWxkcy5pbmNsdWRlcyhmaWVsZCkgJiYgIWV4Y2x1ZGVkRmllbGRzLmluY2x1ZGVzKGAke2VudGl0eS5raW5kfS4ke2ZpZWxkfWApICYmIEFycmF5LmlzQXJyYXkob3duKGZpZWxkcywgZmllbGQpKSkge1xuICAgICAgZm9yIChjb25zdCBibG9jayBvZiBmaWVsZHMhW2ZpZWxkXSBhcyB1bmtub3duW10pIHtcbiAgICAgICAgY29uc3QgcmVjb3JkID0gb2JqZWN0KGJsb2NrKTtcbiAgICAgICAgaWYgKHR5cGVvZiByZWNvcmQ/LmlkID09PSAnc3RyaW5nJykge1xuICAgICAgICAgIGlmIChzb3VyY2UuaGFzKHJlY29yZC5pZCkgfHwgcHVibGljQmxvY2tJZHMuaGFzKHJlY29yZC5pZCkpIGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi+aWh+OBruauteiQvUlE44GM5LuW44Gu5oOF5aCx44Go6YeN6KSH44GX44Gm44GE44G+44GZ44CCJywgZW50aXR5LmlkLCBmaWVsZCk7XG4gICAgICAgICAgZWxzZSB7IHB1YmxpY0Jsb2NrSWRzLmFkZChyZWNvcmQuaWQpO3B1YmxpY0Jsb2NrT3duZXJzLnNldChyZWNvcmQuaWQsZW50aXR5LmlkKTsgYWRkSWQocmVjb3JkLmlkKTsgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHRyaWdnZXIgPSBvYmplY3QoZW50aXR5LmRhdGEudHJpZ2dlcik7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnZmxvd19ub2RlJyAmJiB0eXBlb2YgdHJpZ2dlcj8uaWQgPT09ICdzdHJpbmcnKSBhZGRJZCh0cmlnZ2VyLmlkKTtcbiAgfVxuICBjb25zdCBzZWxlY3RlZElkcyA9IG5ldyBTZXQoc2VsZWN0ZWQubWFwKGVudGl0eSA9PiBlbnRpdHkuaWQpKTtcbiAgY29uc3QgYmxvY2tTb3VyY2VzPW9iamVjdChwb2xpY3kuYmxvY2tTb3VyY2VzKT8/e307XG4gIGZvcihjb25zdCBbcHVibGljQmxvY2ssc291cmNlQmxvY2tdb2YgT2JqZWN0LmVudHJpZXMoYmxvY2tTb3VyY2VzKSl7aWYodHlwZW9mIHNvdXJjZUJsb2NrIT09J3N0cmluZyd8fCFwdWJsaWNCbG9ja0lkcy5oYXMocHVibGljQmxvY2spfHwhaWRNYXBbcHVibGljQmxvY2tdfHxzb3VyY2VCbG9ja093bmVycy5nZXQoc291cmNlQmxvY2spIT09cHVibGljQmxvY2tPd25lcnMuZ2V0KHB1YmxpY0Jsb2NrKSl7ZmFpbCgnUkVGRVJFTkNFX0lOVkFMSUQnLCflhazplovmrrXokL3jga7lhYNJROWvvuW/nOOBjOS4jeato+OBp+OBmeOAgicscHJvZmlsZUlkLCdibG9ja1NvdXJjZXMnKTtjb250aW51ZTt9aWYoaWRNYXBbc291cmNlQmxvY2tdJiZpZE1hcFtzb3VyY2VCbG9ja10hPT1pZE1hcFtwdWJsaWNCbG9ja10pe2ZhaWwoJ1JFRkVSRU5DRV9JTlZBTElEJywn5ZCM44GY5Y6f5q616JC944Gr6KSH5pWw44Gu5YWs6ZaL5L2N572u44GM5oyH5a6a44GV44KM44Gm44GE44G+44GZ44CCJyxwcm9maWxlSWQsJ2Jsb2NrU291cmNlcycpO2NvbnRpbnVlO31pZE1hcFtzb3VyY2VCbG9ja109aWRNYXBbcHVibGljQmxvY2tdO31cbiAgY29uc3QgY2FsZW5kYXJzOiBQcm9qZWN0ZWRDYWxlbmRhcltdID0gW10sIGNhbGVuZGFySWRzID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcbiAgY29uc3QgcHVibGljQ2FsZW5kYXJJZCA9ICh2YWx1ZTogdW5rbm93biwgZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQgPT4ge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnKSB7IGZhaWwoJ1JFRkVSRU5DRV9JTlZBTElEJywgJ+aXpeaZguOBjOS9v+OBhuaapuOCkuaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicsIGVudGl0eS5pZCwgZmllbGQpOyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgaWYgKGNhbGVuZGFySWRzLmhhcyh2YWx1ZSkpIHJldHVybiBjYWxlbmRhcklkcy5nZXQodmFsdWUpO1xuICAgIGNvbnN0IHNvdXJjZUNhbGVuZGFyID0gcHJvamVjdC5jYWxlbmRhcnMuZmluZChjYWxlbmRhciA9PiBjYWxlbmRhci5pZCA9PT0gdmFsdWUpO1xuICAgIGlmICghc291cmNlQ2FsZW5kYXIgfHwgIVsnZ3JlZ29yaWFuJywgJ3JlcGVhdGluZyddLmluY2x1ZGVzKHNvdXJjZUNhbGVuZGFyLmtpbmQpIHx8ICFUSUNLLnRlc3Qoc291cmNlQ2FsZW5kYXIudGlja3NQZXJEYXkpIHx8IEJpZ0ludChzb3VyY2VDYWxlbmRhci50aWNrc1BlckRheSkgPD0gMG4pIHsgZmFpbCgnUkVGRVJFTkNFX0lOVkFMSUQnLCAn5pel5pmC44GM5L2/44GG5pqm44KS5a6J5YWo44Gr5Ye65Yqb44Gn44GN44G+44Gb44KT44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICBsZXQgcHVibGljSWQgPSBgcHVibGljLWNhbGVuZGFyLSR7Y2FsZW5kYXJzLmxlbmd0aCArIDF9YDtcbiAgICB3aGlsZSAoZW1pdHRlZElkcy5oYXMocHVibGljSWQpKSBwdWJsaWNJZCArPSAnLWNhbGVuZGFyJztcbiAgICBlbWl0dGVkSWRzLmFkZChwdWJsaWNJZCk7XG4gICAgY29uc3QgY2FsZW5kYXI6IFByb2plY3RlZENhbGVuZGFyID0geyBpZDogcHVibGljSWQsIG5hbWU6IGDmmqYke2NhbGVuZGFycy5sZW5ndGggKyAxfWAsIGtpbmQ6IHNvdXJjZUNhbGVuZGFyLmtpbmQsIG9yaWdpbkxhYmVsOiAn5Y6f54K5JywgdGlja3NQZXJEYXk6IHNvdXJjZUNhbGVuZGFyLnRpY2tzUGVyRGF5IH07XG4gICAgaWYgKHNvdXJjZUNhbGVuZGFyLmtpbmQgPT09ICdyZXBlYXRpbmcnKSB7XG4gICAgICBpZiAoIUFycmF5LmlzQXJyYXkoc291cmNlQ2FsZW5kYXIueWVhcnMpIHx8ICFzb3VyY2VDYWxlbmRhci55ZWFycy5sZW5ndGggfHwgc291cmNlQ2FsZW5kYXIueWVhcnMubGVuZ3RoID4gNDAwKSB7IGZhaWwoJ0VYUE9SVF9VTlNVUFBPUlRFRCcsICfnubDjgorov5TjgZfmmqbjga7lkajmnJ/jgpLlronlhajjgavlh7rlipvjgafjgY3jgb7jgZvjgpPjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICAgICAgY2FsZW5kYXIueWVhcnMgPSBbXTtcbiAgICAgIGZvciAoY29uc3QgeWVhciBvZiBzb3VyY2VDYWxlbmRhci55ZWFycykge1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoeWVhci5tb250aHMpIHx8ICF5ZWFyLm1vbnRocy5sZW5ndGggfHwgeWVhci5tb250aHMubGVuZ3RoID4gMjQgfHwgeWVhci5tb250aHMuc29tZShtb250aCA9PiAhaW50ZWdlcihtb250aC5kYXlzKSB8fCBtb250aC5kYXlzIDwgMSB8fCBtb250aC5kYXlzID4gNDAwKSkgeyBmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCAn57mw44KK6L+U44GX5pqm44Gu5pyI44KS5a6J5YWo44Gr5Ye65Yqb44Gn44GN44G+44Gb44KT44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICAgICAgY2FsZW5kYXIueWVhcnMucHVzaCh7IG1vbnRoczogeWVhci5tb250aHMubWFwKChtb250aCwgaW5kZXgpID0+ICh7IG5hbWU6IGDmnIgke2luZGV4ICsgMX1gLCBkYXlzOiBtb250aC5kYXlzIH0pKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgY2FsZW5kYXJJZHMuc2V0KHZhbHVlLCBwdWJsaWNJZCk7IGNhbGVuZGFycy5wdXNoKGNhbGVuZGFyKTtcbiAgICByZXR1cm4gcHVibGljSWQ7XG4gIH07XG4gIGNvbnN0IHJlZmVyZW5jZSA9ICh2YWx1ZTogdW5rbm93biwgZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcsIG1hbmRhdG9yeSA9IGZhbHNlKTogc3RyaW5nIHwgdW5kZWZpbmVkID0+IHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiBzZWxlY3RlZElkcy5oYXModmFsdWUpICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChpZE1hcCwgdmFsdWUpKSByZXR1cm4gaWRNYXBbdmFsdWVdO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChpZE1hcCwgdmFsdWUpICYmIGZpZWxkLmluY2x1ZGVzKCdibG9jaycpKSByZXR1cm4gaWRNYXBbdmFsdWVdO1xuICAgIGlmIChtYW5kYXRvcnkgfHwgb3B0aW9ucy5zdHJpY3RSZWZlcmVuY2VzKSBmYWlsKCdSRUZFUkVOQ0VfSU5WQUxJRCcsICflhazplovnr4Tlm7LjgavjgarjgYTlj4LnhaflhYjjgYzlv4XopoHjgafjgZnjgILnr4Tlm7Ljgb7jgZ/jga/ku6Pmm7/mlofjgpLopovnm7TjgZfjgabjgY/jgaDjgZXjgYTjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTtcbiAgICBlbHNlIG9taXQoZW50aXR5LmlkLCAn5YWs6ZaL56+E5Zuy44Gr44Gq44GE5Y+C54Wn44KS6Zmk5aSWJywgZmllbGQpO1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH07XG4gIGNvbnN0IG1hcEVudW0gPSAodmFsdWU6IHVua25vd24sIHZhcmlhYmxlSWQ6IHN0cmluZywgZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQgPT4ge1xuICAgIGNvbnN0IHJlcGxhY2VtZW50cyA9IG9iamVjdChvd24ob2JqZWN0KG93bihwb2xpY3ksICdwdWJsaWNWYWx1ZXMnKSksIHZhcmlhYmxlSWQpKTtcbiAgICBjb25zdCByZXBsYWNlbWVudCA9IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyBvd24ocmVwbGFjZW1lbnRzLCB2YWx1ZSkgOiB1bmRlZmluZWQ7XG4gICAgaWYgKHR5cGVvZiByZXBsYWNlbWVudCAhPT0gJ3N0cmluZycpIHsgZmFpbCgnUFVCTElDX1RFWFRfUkVRVUlSRUQnLCAn5YiX5oyZ5YCk44Gu5YWs6ZaL55So6KGo6KiY44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICByZXR1cm4gcmVwbGFjZW1lbnQ7XG4gIH07XG4gIGNvbnN0IHR5cGVkVmFsdWUgPSAodmFsdWU6IHVua25vd24sIHZhcmlhYmxlSWQ6IHN0cmluZywgZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcpOiBQdWJsaWNWYWx1ZSB8IHVuZGVmaW5lZCA9PiB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgZW50aXR5LmtpbmQgPT09ICdhc3NlcnRpb24nKSB7IGNvbnN0IG1hcHBlZCA9IHJlZmVyZW5jZSh2YWx1ZSwgZW50aXR5LCBmaWVsZCwgdHJ1ZSk7IHJldHVybiBtYXBwZWQ7IH1cbiAgICBjb25zdCBpbnB1dCA9IG9iamVjdCh2YWx1ZSk7XG4gICAgaWYgKCFpbnB1dCkgeyBmYWlsKCdWQUxJREFUSU9OX0ZBSUxFRCcsICflnovku5jjgY3jga7lgKTjgYzlv4XopoHjgafjgZnjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICAgIGlmIChpbnB1dC50eXBlID09PSAnYm9vbGVhbicgJiYgdHlwZW9mIGlucHV0LnZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiB7IHR5cGU6ICdib29sZWFuJywgdmFsdWU6IGlucHV0LnZhbHVlIH07XG4gICAgaWYgKGlucHV0LnR5cGUgPT09ICdpbnRlZ2VyJyAmJiBpbnRlZ2VyKGlucHV0LnZhbHVlKSkgcmV0dXJuIHsgdHlwZTogJ2ludGVnZXInLCB2YWx1ZTogaW5wdXQudmFsdWUgfTtcbiAgICBpZiAoaW5wdXQudHlwZSA9PT0gJ2VudW0nKSB7IGNvbnN0IG1hcHBlZCA9IG1hcEVudW0oaW5wdXQudmFsdWUsIHZhcmlhYmxlSWQsIGVudGl0eSwgZmllbGQpOyByZXR1cm4gbWFwcGVkID09PSB1bmRlZmluZWQgPyB1bmRlZmluZWQgOiB7IHR5cGU6ICdlbnVtJywgdmFsdWU6IG1hcHBlZCB9OyB9XG4gICAgaWYgKGlucHV0LnR5cGUgPT09ICdyZWYnKSB7IGNvbnN0IG1hcHBlZCA9IHJlZmVyZW5jZShpbnB1dC52YWx1ZSwgZW50aXR5LCBmaWVsZCwgdHJ1ZSk7IHJldHVybiBtYXBwZWQgPyB7IHR5cGU6ICdyZWYnLCB2YWx1ZTogbWFwcGVkIH0gOiB1bmRlZmluZWQ7IH1cbiAgICBmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCAn5pyq56K65a6a5YCk44KE6Ieq55Sx5paH5a2X5YiX44Gu5YCk44Gv5a6J5YWo44Gq5Yi25L2c5Ye65Yqb44Gr5a++5b+c44GX44Gm44GE44G+44Gb44KT44CCJywgZW50aXR5LmlkLCBmaWVsZCk7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfTtcbiAgY29uc3QgY29uZGl0aW9uVmFsdWUgPSAoaW5wdXQ6IHVua25vd24sIGVudGl0eTogU291cmNlUmVjb3JkLCBmaWVsZDogc3RyaW5nKTogUHVibGljVmFsdWUgfCB1bmRlZmluZWQgPT4ge1xuICAgIGxldCBub2RlcyA9IDA7XG4gICAgY29uc3QgdmlzaXQgPSAodmFsdWU6IHVua25vd24sIGRlcHRoOiBudW1iZXIpOiBQdWJsaWNWYWx1ZSB8IHVuZGVmaW5lZCA9PiB7XG4gICAgICBjb25zdCBhc3QgPSBvYmplY3QodmFsdWUpO1xuICAgICAgaWYgKCFhc3QgfHwgZGVwdGggPiAxNiB8fCArK25vZGVzID4gMjU2KSB7IGZhaWwoJ0VYUE9SVF9VTlNVUFBPUlRFRCcsICfmnaHku7bjga7lvaLjgb7jgZ/jga/mt7HjgZXjgYzlr77lv5znr4Tlm7LjgpLotoXjgYjjgabjgYTjgb7jgZnjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICAgICAgY29uc3QgcmVxdWlyZWRSZWYgPSAoa2V5OiBzdHJpbmcpID0+IHJlZmVyZW5jZShhc3Rba2V5XSwgZW50aXR5LCBgJHtmaWVsZH0uJHtrZXl9YCwgdHJ1ZSk7XG4gICAgICBzd2l0Y2ggKGFzdC5vcCkge1xuICAgICAgICBjYXNlICdjb25zdGFudCc6IGlmICh0eXBlb2YgYXN0LnZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiB7IG9wOiAnY29uc3RhbnQnLCB2YWx1ZTogYXN0LnZhbHVlIH07IGJyZWFrO1xuICAgICAgICBjYXNlICdhbGwnOiBjYXNlICdhbnknOiB7XG4gICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGFzdC5jaGlsZHJlbikgfHwgYXN0LmNoaWxkcmVuLmxlbmd0aCA9PT0gMCkgYnJlYWs7XG4gICAgICAgICAgY29uc3QgY2hpbGRyZW4gPSBhc3QuY2hpbGRyZW4ubWFwKGNoaWxkID0+IHZpc2l0KGNoaWxkLCBkZXB0aCArIDEpKTtcbiAgICAgICAgICByZXR1cm4gY2hpbGRyZW4uZXZlcnkoY2hpbGQgPT4gY2hpbGQgIT09IHVuZGVmaW5lZCkgPyB7IG9wOiBhc3Qub3AsIGNoaWxkcmVuOiBjaGlsZHJlbiBhcyBQdWJsaWNWYWx1ZVtdIH0gOiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAnbm90JzogeyBjb25zdCBjaGlsZCA9IHZpc2l0KGFzdC5jaGlsZCwgZGVwdGggKyAxKTsgcmV0dXJuIGNoaWxkID09PSB1bmRlZmluZWQgPyB1bmRlZmluZWQgOiB7IG9wOiAnbm90JywgY2hpbGQgfTsgfVxuICAgICAgICBjYXNlICdjb21wYXJlJzoge1xuICAgICAgICAgIGNvbnN0IHZhcmlhYmxlSWQgPSByZXF1aXJlZFJlZigndmFyaWFibGVJZCcpO1xuICAgICAgICAgIGNvbnN0IHZhcmlhYmxlID0gdHlwZW9mIGFzdC52YXJpYWJsZUlkID09PSAnc3RyaW5nJyA/IHNvdXJjZS5nZXQoYXN0LnZhcmlhYmxlSWQpIDogdW5kZWZpbmVkO1xuICAgICAgICAgIGNvbnN0IGNvbXBhcmF0b3IgPSBhc3QuY29tcGFyYXRvcjtcbiAgICAgICAgICBpZiAoIXZhcmlhYmxlIHx8IHZhcmlhYmxlLmtpbmQgIT09ICd2YXJpYWJsZScgfHwgIVsnZXEnLCAnbmUnLCAnbHQnLCAnbGUnLCAnZ3QnLCAnZ2UnLCAnaW4nXS5pbmNsdWRlcyhTdHJpbmcoY29tcGFyYXRvcikpKSBicmVhaztcbiAgICAgICAgICBsZXQgY29tcGFyZWQ6IFB1YmxpY1ZhbHVlIHwgdW5kZWZpbmVkO1xuICAgICAgICAgIGlmIChjb21wYXJhdG9yID09PSAnaW4nICYmIEFycmF5LmlzQXJyYXkoYXN0LnZhbHVlKSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gYXN0LnZhbHVlLm1hcChpdGVtID0+IHR5cGVkVmFsdWUoaXRlbSwgdmFyaWFibGUuaWQsIGVudGl0eSwgZmllbGQpKTtcbiAgICAgICAgICAgIGlmICh2YWx1ZXMuZXZlcnkoaXRlbSA9PiBpdGVtICE9PSB1bmRlZmluZWQpKSBjb21wYXJlZCA9IHZhbHVlcyBhcyBQdWJsaWNWYWx1ZVtdO1xuICAgICAgICAgIH0gZWxzZSBjb21wYXJlZCA9IHR5cGVkVmFsdWUoYXN0LnZhbHVlLCB2YXJpYWJsZS5pZCwgZW50aXR5LCBmaWVsZCk7XG4gICAgICAgICAgaWYgKHZhcmlhYmxlSWQgJiYgY29tcGFyZWQgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHsgb3A6ICdjb21wYXJlJywgdmFyaWFibGVJZCwgY29tcGFyYXRvcjogU3RyaW5nKGNvbXBhcmF0b3IpLCB2YWx1ZTogY29tcGFyZWQgfTtcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgJ2l0ZW0nOiB7IGNvbnN0IGl0ZW1JZCA9IHJlcXVpcmVkUmVmKCdpdGVtSWQnKTsgaWYgKGl0ZW1JZCAmJiBpbnRlZ2VyKGFzdC5xdWFudGl0eSkgJiYgYXN0LnF1YW50aXR5ID49IDApIHJldHVybiB7IG9wOiAnaXRlbScsIGl0ZW1JZCwgcXVhbnRpdHk6IGFzdC5xdWFudGl0eSB9OyBicmVhazsgfVxuICAgICAgICBjYXNlICdrbm93bic6IHsgY29uc3QgYXNzZXJ0aW9uSWQgPSByZXF1aXJlZFJlZignYXNzZXJ0aW9uSWQnKSwgaG9sZGVySWQgPSByZXF1aXJlZFJlZignaG9sZGVySWQnKTsgaWYgKGFzc2VydGlvbklkICYmIGhvbGRlcklkKSByZXR1cm4geyBvcDogJ2tub3duJywgYXNzZXJ0aW9uSWQsIGhvbGRlcklkIH07IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICAgICAgY2FzZSAndmlzaXRlZCc6IHsgY29uc3QgZW50aXR5SWQgPSByZXF1aXJlZFJlZignZW50aXR5SWQnKTsgaWYgKGVudGl0eUlkICYmIGludGVnZXIoYXN0LmNvdW50KSAmJiBhc3QuY291bnQgPj0gMCkgcmV0dXJuIHsgb3A6ICd2aXNpdGVkJywgZW50aXR5SWQsIGNvdW50OiBhc3QuY291bnQgfTsgYnJlYWs7IH1cbiAgICAgICAgY2FzZSAnZXh0ZXJuYWwnOiB7IGNvbnN0IGNvbnRyYWN0SWQgPSByZXF1aXJlZFJlZignY29udHJhY3RJZCcpOyBpZiAoY29udHJhY3RJZCkgcmV0dXJuIHsgb3A6ICdleHRlcm5hbCcsIGNvbnRyYWN0SWQgfTsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICAgICAgfVxuICAgICAgZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywgJ+OBk+OBruadoeS7tuOBr+WvvuW/nOWFiOOBp+WuieWFqOOBq+ihqOOBm+OBvuOBm+OCk+OAgicsIGVudGl0eS5pZCwgZmllbGQpO1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIHJldHVybiB2aXNpdChpbnB1dCwgMSk7XG4gIH07XG4gIGNvbnN0IHB1YmxpY0ZpZWxkID0gKGVudGl0eTogU291cmNlUmVjb3JkLCBmaWVsZDogc3RyaW5nKTogdW5rbm93biA9PiBvd24ob2JqZWN0KG93bihwdWJsaWNUZXh0cywgZW50aXR5LmlkKSksIGZpZWxkKTtcbiAgY29uc3QgdGV4dFZhbHVlID0gKGVudGl0eTogU291cmNlUmVjb3JkLCBmaWVsZDogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IHB1YmxpY0ZpZWxkKGVudGl0eSwgZmllbGQpO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gdmFsdWU7XG4gICAgaWYgKCFlbXB0eShlbnRpdHkuZGF0YVtmaWVsZF0pKSBmYWlsKCdQVUJMSUNfVEVYVF9SRVFVSVJFRCcsICfljp/mlofjga7lronlhajmgKfjga/oh6rli5XliKTlrprjgafjgY3jgb7jgZvjgpPjgILlhazplovnlKjjga7mlofpnaLjgpLmjIflrprjgZnjgovjgYvjgIHjgZPjga7poIXnm67jgpLpmaTlpJbjgZfjgabjgY/jgaDjgZXjgYTjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9O1xuICBjb25zdCBhbmNob3JWYWx1ZSA9ICh2YWx1ZTogdW5rbm93biwgZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcpOiBQdWJsaWNWYWx1ZSB8IHVuZGVmaW5lZCA9PiB7XG4gICAgY29uc3QgaW5wdXQgPSBvYmplY3QodmFsdWUpOyBpZiAoIWlucHV0KSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+acrOaWh+S9jee9ruOBjOS4jeato+OBp+OBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgaWYgKGlucHV0LnBvc2l0aW9uU3RhdHVzID09PSAndW5yZXNvbHZlZCcpIHsgaWYgKG9wdGlvbnMuc3RyaWN0UmVmZXJlbmNlcykgZmFpbCgnUkVGRVJFTkNFX0lOVkFMSUQnLCAn5YWs6ZaL44GZ44KL5pys5paH5L2N572u44Gu5YaN44Oq44Oz44Kv44GM5b+F6KaB44Gn44GZ44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IGVsc2Ugb21pdChlbnRpdHkuaWQsICfkvY3nva7kuI3mmI7jga7mnKzmloflj4LnhafjgpLpmaTlpJYnLCBmaWVsZCk7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICBjb25zdCBmaXhlZD1pbnB1dC5zb3VyY2VWZXJzaW9uSWQmJmlucHV0LnNvdXJjZVZlcnNpb25JZCE9PXByb2plY3QucHJvamVjdElkJiZpbnB1dC5zb3VyY2VWZXJzaW9uSWQhPT1vcHRpb25zLnRhcmdldFZlcnNpb25JZD9vcHRpb25zLnZlcnNpb25UYXJnZXRzPy5bU3RyaW5nKGlucHV0LnNvdXJjZVZlcnNpb25JZCldOnVuZGVmaW5lZDtcbiAgICBpZihpbnB1dC5zb3VyY2VWZXJzaW9uSWQmJmlucHV0LnNvdXJjZVZlcnNpb25JZCE9PXByb2plY3QucHJvamVjdElkJiZpbnB1dC5zb3VyY2VWZXJzaW9uSWQhPT1vcHRpb25zLnRhcmdldFZlcnNpb25JZCYmIWZpeGVkKXtmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCfliKXjga7lm7rlrprniYjjgpLmjIfjgZnkvY3nva7jgavjga/jgIHjgZ3jga7niYjjga7lhazplovnr4Tlm7Lnorroqo3jgYzlv4XopoHjgafjgZnjgILpu5njgaPjgabnj77lnKjkvY3nva7jgbjnp7vjgZfjgb7jgZvjgpPjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuIHVuZGVmaW5lZDt9XG4gICAgY29uc3QgdGFyZ2V0TWFwPWZpeGVkPy5pZE1hcD8/aWRNYXAsdGFyZ2V0SWQ9Zml4ZWQ/dGFyZ2V0TWFwW1N0cmluZyhpbnB1dC5lbnRpdHlJZCldOnJlZmVyZW5jZShpbnB1dC5lbnRpdHlJZCwgZW50aXR5LCBmaWVsZCwgdHJ1ZSk7IGlmICghdGFyZ2V0SWQpe2ZhaWwoJ1JFRkVSRU5DRV9JTlZBTElEJywn5byV55So5Zu65a6a54mI44Gu5YWs6ZaL5a++6LGh44GM44GC44KK44G+44Gb44KT44CCJyxlbnRpdHkuaWQsZmllbGQpO3JldHVybiB1bmRlZmluZWQ7fVxuICAgIGNvbnN0IG91dHB1dDogUmVjb3JkPHN0cmluZywgUHVibGljVmFsdWU+ID0geyBlbnRpdHlJZDogdGFyZ2V0SWQsLi4uZml4ZWQ/e3NvdXJjZVZlcnNpb25JZDpmaXhlZC5wdWJsaWNWZXJzaW9uSWR9Ont9IH07XG4gICAgZm9yIChjb25zdCBrZXkgb2YgWydibG9ja0lkJywgJ2xpbmVJZCddKSBpZiAoaW5wdXRba2V5XSAhPSBudWxsKSB7XG4gICAgICBjb25zdCBzb3VyY2VJZCA9IGlucHV0W2tleV07XG4gICAgICBpZiAodHlwZW9mIHNvdXJjZUlkICE9PSAnc3RyaW5nJyB8fCAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHRhcmdldE1hcCwgc291cmNlSWQpKSB7IGlmIChvcHRpb25zLnN0cmljdFJlZmVyZW5jZXMpIGZhaWwoJ1JFRkVSRU5DRV9JTlZBTElEJywgJ+WFrOmWi+aWh+OBq+WtmOWcqOOBl+OBquOBhOS9jee9ruOBuOOBruWPgueFp+OBp+OBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyBlbHNlIG9taXQoZW50aXR5LmlkLCAn6Z2e5YWs6ZaL44Gu5pys5paH5L2N572u44KS6Zmk5aSWJywgZmllbGQpOyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgICBvdXRwdXRba2V5XSA9IHRhcmdldE1hcFtzb3VyY2VJZF07XG4gICAgfVxuICAgIGlmIChpbnRlZ2VyKGlucHV0LnN0YXJ0KSAmJiBpbnRlZ2VyKGlucHV0LmVuZCkgJiYgaW5wdXQuc3RhcnQgPj0gMCAmJiBpbnB1dC5lbmQgPj0gaW5wdXQuc3RhcnQpIHsgb3V0cHV0LnN0YXJ0ID0gaW5wdXQuc3RhcnQ7IG91dHB1dC5lbmQgPSBpbnB1dC5lbmQ7IH1cbiAgICByZXR1cm4gb3V0cHV0O1xuICB9O1xuICBjb25zdCByaWNoVmFsdWUgPSAoZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcpOiBQdWJsaWNWYWx1ZSB8IHVuZGVmaW5lZCA9PiB7XG4gICAgY29uc3QgaW5wdXQgPSBwdWJsaWNGaWVsZChlbnRpdHksIGZpZWxkKTtcbiAgICBpZiAodHlwZW9mIGlucHV0ID09PSAnc3RyaW5nJykgcmV0dXJuIFt7IGlkOiBgJHtpZE1hcFtlbnRpdHkuaWRdfS4ke2ZpZWxkfWAsIGtpbmQ6ICdwYXJhZ3JhcGgnLCB0ZXh0OiBpbnB1dCB9XTtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoaW5wdXQpKSB7IGlmICghZW1wdHkoZW50aXR5LmRhdGFbZmllbGRdKSkgZmFpbCgnUFVCTElDX1RFWFRfUkVRVUlSRUQnLCAn5YWs6ZaL55So44Gu5pys5paH44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CC5Y6f5paH44Gu56eY5a+G44Gv6Ieq5YuV44Gn6Zmk44GR44G+44Gb44KT44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICBjb25zdCBvdXRwdXQ6IFB1YmxpY1ZhbHVlW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IHJhdyBvZiBpbnB1dCkge1xuICAgICAgY29uc3QgYmxvY2sgPSBvYmplY3QocmF3KTtcbiAgICAgIGlmICghYmxvY2sgfHwgdHlwZW9mIGJsb2NrLmlkICE9PSAnc3RyaW5nJyB8fCAhaWRNYXBbYmxvY2suaWRdIHx8ICFCTE9DS19LSU5EUy5oYXMoU3RyaW5nKGJsb2NrLmtpbmQpKSB8fCB0eXBlb2YgYmxvY2sudGV4dCAhPT0gJ3N0cmluZycpIHsgZmFpbCgnVkFMSURBVElPTl9GQUlMRUQnLCAn5YWs6ZaL5paH44Gu5q616JC944GM5LiN5q2j44Gn44GZ44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IGNvbnRpbnVlOyB9XG4gICAgICBjb25zdCBwcm9qZWN0ZWQ6IFJlY29yZDxzdHJpbmcsIFB1YmxpY1ZhbHVlPiA9IHsgaWQ6IGlkTWFwW2Jsb2NrLmlkXSwga2luZDogU3RyaW5nKGJsb2NrLmtpbmQpLCB0ZXh0OiBibG9jay50ZXh0IH07XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShibG9jay51bnJlc29sdmVkQW5ub3RhdGlvbnMpICYmIGJsb2NrLnVucmVzb2x2ZWRBbm5vdGF0aW9ucy5sZW5ndGgpIG9taXQoZW50aXR5LmlkLCAn5YaN44Oq44Oz44Kv5b6F44Gh44Gu5pys5paH5rOo6KiY44KS6Zmk5aSWJywgZmllbGQpO1xuICAgICAgY29uc3QgbGVuZ3RoID0gWy4uLmJsb2NrLnRleHRdLmxlbmd0aDtcbiAgICAgIGNvbnN0IHZhbGlkUmFuZ2UgPSAocmFuZ2U6IE9iamVjdFZhbHVlKTogYm9vbGVhbiA9PiBpbnRlZ2VyKHJhbmdlLnN0YXJ0KSAmJiBpbnRlZ2VyKHJhbmdlLmVuZCkgJiYgcmFuZ2Uuc3RhcnQgPj0gMCAmJiByYW5nZS5lbmQgPiByYW5nZS5zdGFydCAmJiByYW5nZS5lbmQgPD0gbGVuZ3RoO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYmxvY2sucnVieSkpIHtcbiAgICAgICAgY29uc3QgcnVieTogUHVibGljVmFsdWVbXSA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHJhd1J1Ynkgb2YgYmxvY2sucnVieSkgeyBjb25zdCByYW5nZSA9IG9iamVjdChyYXdSdWJ5KTsgaWYgKCFyYW5nZSB8fCAhdmFsaWRSYW5nZShyYW5nZSkgfHwgdHlwZW9mIHJhbmdlLnRleHQgIT09ICdzdHJpbmcnKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi+aWh+OBruODq+ODk+evhOWbsuOBjOS4jeato+OBp+OBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyBjb250aW51ZTsgfSBydWJ5LnB1c2goeyBzdGFydDogcmFuZ2Uuc3RhcnQgYXMgbnVtYmVyLCBlbmQ6IHJhbmdlLmVuZCBhcyBudW1iZXIsIHRleHQ6IHJhbmdlLnRleHQgfSk7IH1cbiAgICAgICAgcHJvamVjdGVkLnJ1YnkgPSBydWJ5O1xuICAgICAgfVxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYmxvY2subGlua3MpKSB7XG4gICAgICAgIGNvbnN0IGxpbmtzOiBQdWJsaWNWYWx1ZVtdID0gW107XG4gICAgICAgIGZvciAoY29uc3QgcmF3TGluayBvZiBibG9jay5saW5rcykge1xuICAgICAgICAgIGNvbnN0IHJhbmdlID0gb2JqZWN0KHJhd0xpbmspO1xuICAgICAgICAgIGlmICghcmFuZ2UgfHwgIXZhbGlkUmFuZ2UocmFuZ2UpKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi+aWh+OBruODquODs+OCr+evhOWbsuOBjOS4jeato+OBp+OBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyBjb250aW51ZTsgfVxuICAgICAgICAgIGNvbnN0IHRhcmdldCA9IG9iamVjdChyYW5nZS50YXJnZXQpID8/IHJhbmdlO1xuICAgICAgICAgIGlmICh0YXJnZXQucG9zaXRpb25TdGF0dXMgPT09ICd1bnJlc29sdmVkJykgeyBpZiAob3B0aW9ucy5zdHJpY3RSZWZlcmVuY2VzKSBmYWlsKCdSRUZFUkVOQ0VfSU5WQUxJRCcsICflhazplovmlofjga7jg6rjg7Pjgq/lhYjkvY3nva7jga7lho3jg6rjg7Pjgq/jgYzlv4XopoHjgafjgZnjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTsgZWxzZSBvbWl0KGVudGl0eS5pZCwgJ+S9jee9ruS4jeaYjuOBruODquODs+OCr+OCkumZpOWklicsIGZpZWxkKTsgY29udGludWU7IH1cbiAgICAgICAgICBjb25zdCBmaXhlZD10YXJnZXQuc291cmNlVmVyc2lvbklkJiZ0YXJnZXQuc291cmNlVmVyc2lvbklkIT09cHJvamVjdC5wcm9qZWN0SWQmJnRhcmdldC5zb3VyY2VWZXJzaW9uSWQhPT1vcHRpb25zLnRhcmdldFZlcnNpb25JZD9vcHRpb25zLnZlcnNpb25UYXJnZXRzPy5bU3RyaW5nKHRhcmdldC5zb3VyY2VWZXJzaW9uSWQpXTp1bmRlZmluZWQsdGFyZ2V0TWFwPWZpeGVkPy5pZE1hcD8/aWRNYXA7XG4gICAgICAgICAgaWYodGFyZ2V0LnNvdXJjZVZlcnNpb25JZCYmdGFyZ2V0LnNvdXJjZVZlcnNpb25JZCE9PXByb2plY3QucHJvamVjdElkJiZ0YXJnZXQuc291cmNlVmVyc2lvbklkIT09b3B0aW9ucy50YXJnZXRWZXJzaW9uSWQmJiFmaXhlZCl7ZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywn5YWs6ZaL44Oq44Oz44Kv44Gr44Gv5Yil44Gu5Zu65a6a54mI44Gu5YWs6ZaL56K66KqN44GM5b+F6KaB44Gn44GZ44CC54++5Zyo5L2N572u44G45Luj55So44GX44G+44Gb44KT44CCJyxlbnRpdHkuaWQsZmllbGQpO2NvbnRpbnVlO31cbiAgICAgICAgICBjb25zdCB0YXJnZXRJZCA9IGZpeGVkP3RhcmdldE1hcFtTdHJpbmcodGFyZ2V0LnRhcmdldElkPz90YXJnZXQuZW50aXR5SWQpXTpyZWZlcmVuY2UodGFyZ2V0LnRhcmdldElkID8/IHRhcmdldC5lbnRpdHlJZCwgZW50aXR5LCBgJHtmaWVsZH0ubGlua3NgKTtcbiAgICAgICAgICBpZiAoIXRhcmdldElkKSBjb250aW51ZTtcbiAgICAgICAgICBjb25zdCBsaW5rOiBSZWNvcmQ8c3RyaW5nLCBQdWJsaWNWYWx1ZT4gPSB7IHN0YXJ0OiByYW5nZS5zdGFydCBhcyBudW1iZXIsIGVuZDogcmFuZ2UuZW5kIGFzIG51bWJlciwgdGFyZ2V0SWQgfTtcbiAgICAgICAgICBpZih0YXJnZXQuc291cmNlVmVyc2lvbklkKWxpbmsuc291cmNlVmVyc2lvbklkPWZpeGVkPy5wdWJsaWNWZXJzaW9uSWQ/PydwdWJsaWMtcHJvamVjdCc7aWYoaW50ZWdlcih0YXJnZXQuc3RhcnQpJiZpbnRlZ2VyKHRhcmdldC5lbmQpKXtsaW5rLnRhcmdldFN0YXJ0PXRhcmdldC5zdGFydDtsaW5rLnRhcmdldEVuZD10YXJnZXQuZW5kO31cbiAgICAgICAgICBsZXQgdmFsaWQgPSB0cnVlO1xuICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIFsnYmxvY2tJZCcsICdsaW5lSWQnXSkgaWYgKHRhcmdldFtrZXldICE9IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnN0IG9yaWdpbiA9IHRhcmdldFtrZXldOyBpZiAodHlwZW9mIG9yaWdpbiAhPT0gJ3N0cmluZycgfHwgIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh0YXJnZXRNYXAsIG9yaWdpbikpIHsgaWYgKG9wdGlvbnMuc3RyaWN0UmVmZXJlbmNlcykgZmFpbCgnUkVGRVJFTkNFX0lOVkFMSUQnLCAn5YWs6ZaL5paH44Gr5a2Y5Zyo44GX44Gq44GE5L2N572u44G444Gu44Oq44Oz44Kv44Gn44GZ44CCJywgZW50aXR5LmlkLCBmaWVsZCk7IGVsc2Ugb21pdChlbnRpdHkuaWQsICfpnZ7lhazplovjga7kvY3nva7jgbjjga7jg6rjg7Pjgq/jgpLpmaTlpJYnLCBmaWVsZCk7IHZhbGlkID0gZmFsc2U7IGJyZWFrOyB9XG4gICAgICAgICAgICBsaW5rW2tleV0gPSB0YXJnZXRNYXBbb3JpZ2luXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHZhbGlkKSBsaW5rcy5wdXNoKGxpbmspO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsaW5rcy5sZW5ndGgpIHByb2plY3RlZC5saW5rcyA9IGxpbmtzO1xuICAgICAgfVxuICAgICAgb3V0cHV0LnB1c2gocHJvamVjdGVkKTtcbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfTtcbiAgY29uc3QgYmVoYXZpb3JUZXh0PShlbnRpdHk6U291cmNlUmVjb3JkLGZpZWxkOnN0cmluZyk6c3RyaW5nPT57Y29uc3QgdmFsdWU9dGV4dFZhbHVlKGVudGl0eSxmaWVsZCk7cmV0dXJuIHZhbHVlPz8nJzt9O1xuICBjb25zdCBzY29wZVZhbHVlPSh2YWx1ZTp1bmtub3duLGVudGl0eTpTb3VyY2VSZWNvcmQsZmllbGQ6c3RyaW5nKTpQdWJsaWNWYWx1ZXx1bmRlZmluZWQ9PntcbiAgICBjb25zdCBpbnB1dD1vYmplY3QodmFsdWUpO2lmKCFpbnB1dHx8aW5wdXQucHJvamVjdElkIT09cHJvamVjdC5wcm9qZWN0SWQpe2ZhaWwoJ1JFRkVSRU5DRV9JTlZBTElEJywn5a++6LGh5L2c5ZOB44Gu56+E5Zuy44KS5YWs6ZaL5YWI44G45a++5b+c44Gn44GN44G+44Gb44KT44CCJyxlbnRpdHkuaWQsZmllbGQpO3JldHVybjt9XG4gICAgY29uc3Qgb3V0cHV0OlJlY29yZDxzdHJpbmcsUHVibGljVmFsdWU+PXtwcm9qZWN0SWQ6J3B1YmxpYy1wcm9qZWN0J307XG4gICAgZm9yKGNvbnN0IGtleSBvZiBbJ2dyYXBoSWQnLCdjaGFwdGVySWQnXSlpZihpbnB1dFtrZXldIT1udWxsKXtjb25zdCBtYXBwZWQ9cmVmZXJlbmNlKGlucHV0W2tleV0sZW50aXR5LGZpZWxkLHRydWUpO2lmKCFtYXBwZWQpcmV0dXJuO291dHB1dFtrZXldPW1hcHBlZDt9XG4gICAgaWYoaW5wdXQudGFyZ2V0U25hcHNob3RJZCE9bnVsbCl7aWYoaW5wdXQudGFyZ2V0U25hcHNob3RJZCE9PXByb2plY3QucHJvamVjdElkJiZpbnB1dC50YXJnZXRTbmFwc2hvdElkIT09b3B0aW9ucy50YXJnZXRWZXJzaW9uSWQpe2ZhaWwoJ0VYUE9SVF9VTlNVUFBPUlRFRCcsJ+WIpeeJiOmZkOWumuOBruevhOWbsuOCkuePvuWcqOeJiOOBuOS7o+eUqOOBl+OBvuOBm+OCk+OAgicsZW50aXR5LmlkLGZpZWxkKTtyZXR1cm47fW91dHB1dC50YXJnZXRTbmFwc2hvdElkPSdwdWJsaWMtcHJvamVjdCc7fVxuICAgIGlmKGlucHV0LnJvdXRlQ29uZGl0aW9uIT1udWxsKXtjb25zdCBtYXBwZWQ9Y29uZGl0aW9uVmFsdWUoaW5wdXQucm91dGVDb25kaXRpb24sZW50aXR5LGZpZWxkKTtpZighbWFwcGVkKXJldHVybjtvdXRwdXQucm91dGVDb25kaXRpb249bWFwcGVkO31yZXR1cm4gb3V0cHV0O1xuICB9O1xuICBjb25zdCB2YWxpZGl0eVZhbHVlPSh2YWx1ZTp1bmtub3duLGVudGl0eTpTb3VyY2VSZWNvcmQsZmllbGQ6c3RyaW5nKTpQdWJsaWNWYWx1ZXx1bmRlZmluZWQ9Pntjb25zdCBpbnB1dD1vYmplY3QodmFsdWUpO2lmKCFpbnB1dClyZXR1cm47bGV0IHJhbmdlOlB1YmxpY1ZhbHVlPW51bGw7aWYoaW5wdXQud29ybGRSYW5nZSE9bnVsbCl7Y29uc3QgcmF3PW9iamVjdChpbnB1dC53b3JsZFJhbmdlKTtpZighcmF3fHxbJ3N0YXJ0JywnZW5kJ10uc29tZShrZXk9PnJhd1trZXldIT09bnVsbCYmKHR5cGVvZiByYXdba2V5XSE9PSdzdHJpbmcnfHwhVElDSy50ZXN0KFN0cmluZyhyYXdba2V5XSkpKSkpe2ZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywn5pyf6ZaT44Gu5pW05pWwdGlja+OBjOS4jeato+OBp+OBmeOAgicsZW50aXR5LmlkLGZpZWxkKTtyZXR1cm47fXJhbmdlPXtzdGFydDpyYXcuc3RhcnQgYXMgc3RyaW5nfG51bGwsZW5kOnJhdy5lbmQgYXMgc3RyaW5nfG51bGx9O31jb25zdCByb3V0ZT1pbnB1dC5yb3V0ZUNvbmRpdGlvbj09bnVsbD9udWxsOmNvbmRpdGlvblZhbHVlKGlucHV0LnJvdXRlQ29uZGl0aW9uLGVudGl0eSxmaWVsZCksYW5jaG9yPWlucHV0LnByZXNlbnRhdGlvbkFuY2hvcj09bnVsbD9udWxsOmFuY2hvclZhbHVlKGlucHV0LnByZXNlbnRhdGlvbkFuY2hvcixlbnRpdHksZmllbGQpO2lmKHJvdXRlPT09dW5kZWZpbmVkfHxhbmNob3I9PT11bmRlZmluZWQpcmV0dXJuO3JldHVybiB7d29ybGRSYW5nZTpyYW5nZSxyb3V0ZUNvbmRpdGlvbjpyb3V0ZSxwcmVzZW50YXRpb25BbmNob3I6YW5jaG9yfTt9O1xuICBjb25zdCBleGNlcHRpb25WYWx1ZT0odmFsdWU6dW5rbm93bixlbnRpdHk6U291cmNlUmVjb3JkLGZpZWxkOnN0cmluZyk6UHVibGljVmFsdWV8dW5kZWZpbmVkPT57Y29uc3QgaW5wdXQ9b2JqZWN0KHZhbHVlKTtpZighaW5wdXQpcmV0dXJuO2NvbnN0IHRhcmdldD1zY29wZVZhbHVlKGlucHV0LnRhcmdldFNjb3BlLGVudGl0eSxmaWVsZCksdmFsaWRpdHk9dmFsaWRpdHlWYWx1ZShpbnB1dC52YWxpZGl0eSxlbnRpdHksZmllbGQpO2lmKCF0YXJnZXR8fCF2YWxpZGl0eXx8IUFycmF5LmlzQXJyYXkoaW5wdXQuZXZpZGVuY2VJZHMpKXJldHVybjtjb25zdCBldmlkZW5jZT1pbnB1dC5ldmlkZW5jZUlkcy5tYXAoaWQ9PnJlZmVyZW5jZShpZCxlbnRpdHksZmllbGQsdHJ1ZSkpO2lmKGV2aWRlbmNlLnNvbWUoaWQ9PiFpZCkpcmV0dXJuO2NvbnN0IHJlYXNvbj1iZWhhdmlvclRleHQoZW50aXR5LCdleGNlcHRpb25SZWFzb24nKTtpZighcmVhc29uLnRyaW0oKSl7ZmFpbCgnUFVCTElDX1RFWFRfUkVRVUlSRUQnLCfmnInpmZDkvovlpJbjga7lhazplovnlKjnkIbnlLHjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuO31yZXR1cm4ge3JlYXNvbix0YXJnZXRTY29wZTp0YXJnZXQsdmFsaWRpdHksZXZpZGVuY2VJZHM6ZXZpZGVuY2UgYXMgc3RyaW5nW119O307XG4gIGNvbnN0IGV4cHJlc3Npb25WYWx1ZT0odmFsdWU6dW5rbm93bixlbnRpdHk6U291cmNlUmVjb3JkLGZpZWxkOnN0cmluZyxkZXB0aD0wKTpQdWJsaWNWYWx1ZXx1bmRlZmluZWQ9PntpZihkZXB0aD42NCl7ZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywn566X5Ye65byP44Gu5LiK6ZmQ44KS6LaF44GI44Gm44GE44G+44GZ44CCJyxlbnRpdHkuaWQsZmllbGQpO3JldHVybjt9Y29uc3QgaW5wdXQ9b2JqZWN0KHZhbHVlKTtpZighaW5wdXQpcmV0dXJuO2lmKGlucHV0Lm9wPT09J3ZhbHVlJyl7Y29uc3QgbWFwcGVkPXR5cGVkVmFsdWUoaW5wdXQudmFsdWUsZW50aXR5LmlkLGVudGl0eSxmaWVsZCk7cmV0dXJuIG1hcHBlZD97b3A6J3ZhbHVlJyx2YWx1ZTptYXBwZWR9OnVuZGVmaW5lZDt9aWYoaW5wdXQub3A9PT0ndmFyaWFibGUnKXtjb25zdCBpZD1yZWZlcmVuY2UoaW5wdXQudmFyaWFibGVJZCxlbnRpdHksZmllbGQsdHJ1ZSk7cmV0dXJuIGlkP3tvcDondmFyaWFibGUnLHZhcmlhYmxlSWQ6aWR9OnVuZGVmaW5lZDt9aWYoWydhZGQnLCdzdWJ0cmFjdCcsJ211bHRpcGx5J10uaW5jbHVkZXMoU3RyaW5nKGlucHV0Lm9wKSkpe2NvbnN0IGxlZnQ9ZXhwcmVzc2lvblZhbHVlKGlucHV0LmxlZnQsZW50aXR5LGZpZWxkLGRlcHRoKzEpLHJpZ2h0PWV4cHJlc3Npb25WYWx1ZShpbnB1dC5yaWdodCxlbnRpdHksZmllbGQsZGVwdGgrMSk7cmV0dXJuIGxlZnQmJnJpZ2h0P3tvcDpTdHJpbmcoaW5wdXQub3ApLGxlZnQscmlnaHR9OnVuZGVmaW5lZDt9aWYoaW5wdXQub3A9PT0naWYnKXtjb25zdCBjb25kaXRpb249Y29uZGl0aW9uVmFsdWUoaW5wdXQuY29uZGl0aW9uLGVudGl0eSxmaWVsZCkseWVzPWV4cHJlc3Npb25WYWx1ZShpbnB1dC50aGVuLGVudGl0eSxmaWVsZCxkZXB0aCsxKSxubz1leHByZXNzaW9uVmFsdWUoaW5wdXQuZWxzZSxlbnRpdHksZmllbGQsZGVwdGgrMSk7cmV0dXJuIGNvbmRpdGlvbiYmeWVzJiZubz97b3A6J2lmJyxjb25kaXRpb24sdGhlbjp5ZXMsZWxzZTpub306dW5kZWZpbmVkO31yZXR1cm4gY29uZGl0aW9uVmFsdWUoaW5wdXQsZW50aXR5LGZpZWxkKTt9O1xuICBjb25zdCBzZXJpYWxpemUgPSAoZW50aXR5OiBTb3VyY2VSZWNvcmQsIGZpZWxkOiBzdHJpbmcsIHJ1bGU6IEZpZWxkUnVsZSk6IFB1YmxpY1ZhbHVlIHwgdW5kZWZpbmVkID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IGVudGl0eS5kYXRhW2ZpZWxkXTtcbiAgICBpZiAocnVsZS50eXBlID09PSAndGV4dCcpIHJldHVybiB0ZXh0VmFsdWUoZW50aXR5LCBmaWVsZCk7XG4gICAgaWYgKHJ1bGUudHlwZSA9PT0gJ3JpY2gnKSByZXR1cm4gcmljaFZhbHVlKGVudGl0eSwgZmllbGQpO1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgIHN3aXRjaCAocnVsZS50eXBlKSB7XG4gICAgICBjYXNlICdwdWJsaWNfc3RyaW5ncyc6e2lmKEFycmF5LmlzQXJyYXkodmFsdWUpJiYhdmFsdWUubGVuZ3RoKXJldHVybiBbXTtsZXQgYXBwcm92ZWQ6dW5rbm93bjt0cnl7YXBwcm92ZWQ9SlNPTi5wYXJzZShTdHJpbmcocHVibGljRmllbGQoZW50aXR5LGZpZWxkKSkpO31jYXRjaHt9aWYoQXJyYXkuaXNBcnJheShhcHByb3ZlZCkmJmFwcHJvdmVkLmV2ZXJ5KGl0ZW09PnR5cGVvZiBpdGVtPT09J3N0cmluZycpKXJldHVybiBhcHByb3ZlZDtmYWlsKCdQVUJMSUNfVEVYVF9SRVFVSVJFRCcsJ+WFrOmWi+eUqOOBruaWh+Wtl+WIl+S4gOimp+OCkkpTT07mlofnq6DjgafmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuO31cbiAgICAgIGNhc2UgJ3JlYWxfZGF0ZSc6e2NvbnN0IGlucHV0PW9iamVjdCh2YWx1ZSk7aWYoaW5wdXQmJnR5cGVvZiBpbnB1dC5kYXRlPT09J3N0cmluZycmJi9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kLy50ZXN0KGlucHV0LmRhdGUpJiZ0eXBlb2YgaW5wdXQudGltZVpvbmU9PT0nc3RyaW5nJylyZXR1cm4ge2RhdGU6aW5wdXQuZGF0ZSx0aW1lWm9uZTppbnB1dC50aW1lWm9uZX07YnJlYWs7fVxuICAgICAgY2FzZSAnZXN0aW1hdGUnOntjb25zdCBpbnB1dD1vYmplY3QodmFsdWUpO2xldCBhc3N1bXB0aW9uczp1bmtub3duO3RyeXthc3N1bXB0aW9ucz1KU09OLnBhcnNlKFN0cmluZyhwdWJsaWNGaWVsZChlbnRpdHksJ2VzdGltYXRlQXNzdW1wdGlvbnMnKSkpO31jYXRjaHt9Y29uc3Qgc291cmNlPXB1YmxpY0ZpZWxkKGVudGl0eSwnZXN0aW1hdGVTb3VyY2UnKSx1bml0PXB1YmxpY0ZpZWxkKGVudGl0eSwnZXN0aW1hdGVVbml0Jyk7aWYoIWlucHV0fHwhQXJyYXkuaXNBcnJheShhc3N1bXB0aW9ucyl8fGFzc3VtcHRpb25zLnNvbWUoaXRlbT0+dHlwZW9mIGl0ZW0hPT0nc3RyaW5nJyl8fHR5cGVvZiBzb3VyY2UhPT0nc3RyaW5nJ3x8dHlwZW9mIHVuaXQhPT0nc3RyaW5nJyl7ZmFpbCgnUFVCTElDX1RFWFRfUkVRVUlSRUQnLCfopovnqY3jga7lhazplovnlKjku67lrprjgajlh7rmiYDjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuO31jb25zdCBzY29wZT1zY29wZVZhbHVlKGlucHV0LnNjb3BlLGVudGl0eSxmaWVsZCk7aWYoIXNjb3BlKXJldHVybjtyZXR1cm4ge3VuaXQsYXNzdW1wdGlvbnM6YXNzdW1wdGlvbnMgYXMgc3RyaW5nW10sc291cmNlLHVua25vd25Db3VudDpOdW1iZXIoaW5wdXQudW5rbm93bkNvdW50KSxzY29wZSwuLi5pbnB1dC52YWx1ZSE9bnVsbD97dmFsdWU6TnVtYmVyKGlucHV0LnZhbHVlKX06e30sLi4uaW5wdXQucmFuZ2U/e3JhbmdlOmlucHV0LnJhbmdlIGFzIFB1YmxpY1ZhbHVlfTp7fSwuLi5pbnB1dC5zcGVlZCE9bnVsbD97c3BlZWQ6TnVtYmVyKGlucHV0LnNwZWVkKX06e319O31cbiAgICAgIGNhc2UgJ3BhcmFtZXRlcnMnOntpZighQXJyYXkuaXNBcnJheSh2YWx1ZSkpYnJlYWs7Y29uc3QgYXBwcm92ZWQ9cHVibGljRmllbGQoZW50aXR5LCdwYXJhbWV0ZXJzJyk7bGV0IG5hbWVzOnVua25vd247dHJ5e25hbWVzPXR5cGVvZiBhcHByb3ZlZD09PSdzdHJpbmcnP0pTT04ucGFyc2UoYXBwcm92ZWQpOnVuZGVmaW5lZDt9Y2F0Y2h7fWlmKHZhbHVlLmxlbmd0aCYmIW9iamVjdChuYW1lcykpe2ZhaWwoJ1BVQkxJQ19URVhUX1JFUVVJUkVEJywn5YWs6ZaL55So44Gu5byV5pWw5ZCN44KSa2V54oaS5YWs6ZaLa2V544GuSlNPTuaWh+eroOOBp+aMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicsZW50aXR5LmlkLGZpZWxkKTtyZXR1cm47fWNvbnN0IG91dHB1dDpQdWJsaWNWYWx1ZVtdPVtdO2Zvcihjb25zdCByYXcgb2YgdmFsdWUpe2NvbnN0IGlucHV0PW9iamVjdChyYXcpLGtleT1pbnB1dCYmb3duKG9iamVjdChuYW1lcyksU3RyaW5nKGlucHV0LmtleSkpO2lmKCFpbnB1dHx8dHlwZW9mIGtleSE9PSdzdHJpbmcnfHwhL15bLV8uYS16QS1aMC05XXsxLDEyOH0kLy50ZXN0KGtleSl8fCFbJ2Jvb2xlYW4nLCdpbnRlZ2VyJywnZW51bSddLmluY2x1ZGVzKFN0cmluZyhpbnB1dC50eXBlKSkpe2ZhaWwoJ1BVQkxJQ19URVhUX1JFUVVJUkVEJywn5byV5pWw44Gu5YWs6ZaL5ZCN44Go5Z6L44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJyxlbnRpdHkuaWQsZmllbGQpO3JldHVybjt9Y29uc3QgaW5pdGlhbD1pbnB1dC5kZWZhdWx0PT1udWxsP3VuZGVmaW5lZDp0eXBlZFZhbHVlKGlucHV0LmRlZmF1bHQsZW50aXR5LmlkLGVudGl0eSxmaWVsZCk7aWYoaW5wdXQuZGVmYXVsdCE9bnVsbCYmIWluaXRpYWwpcmV0dXJuO291dHB1dC5wdXNoKHtrZXksdHlwZTpTdHJpbmcoaW5wdXQudHlwZSksLi4uaW5pdGlhbD97ZGVmYXVsdDppbml0aWFsfTp7fX0pO31yZXR1cm4gb3V0cHV0O31cbiAgICAgIGNhc2UgJ2V4cHJlc3Npb24nOnJldHVybiBleHByZXNzaW9uVmFsdWUodmFsdWUsZW50aXR5LGZpZWxkKTtcbiAgICAgIGNhc2UgJ3Njb3BlJzpyZXR1cm4gc2NvcGVWYWx1ZSh2YWx1ZSxlbnRpdHksZmllbGQpO1xuICAgICAgY2FzZSAndmFsaWRpdHknOnJldHVybiB2YWxpZGl0eVZhbHVlKHZhbHVlLGVudGl0eSxmaWVsZCk7XG4gICAgICBjYXNlICdleGNlcHRpb24nOnJldHVybiBleGNlcHRpb25WYWx1ZSh2YWx1ZSxlbnRpdHksZmllbGQpO1xuICAgICAgY2FzZSAnZXhjZXB0aW9ucyc6e2lmKCFBcnJheS5pc0FycmF5KHZhbHVlKSlicmVhaztjb25zdCBtYXBwZWQ9dmFsdWUubWFwKGl0ZW09PmV4Y2VwdGlvblZhbHVlKGl0ZW0sZW50aXR5LGZpZWxkKSk7cmV0dXJuIG1hcHBlZC5ldmVyeShpdGVtPT5pdGVtIT09dW5kZWZpbmVkKT9tYXBwZWQgYXMgUHVibGljVmFsdWVbXTp1bmRlZmluZWQ7fVxuICAgICAgY2FzZSAncmVzZXRzJzp7aWYoIUFycmF5LmlzQXJyYXkodmFsdWUpKWJyZWFrO2NvbnN0IG91dHB1dDpQdWJsaWNWYWx1ZVtdPVtdO2Zvcihjb25zdCByYXcgb2YgdmFsdWUpe2NvbnN0IGlucHV0PW9iamVjdChyYXcpO2lmKCFpbnB1dHx8IVsnc2NlbmVfZW5kJywnY2hhcHRlcl9lbmQnLCdydW5fZW5kJywnbmV3X2xvb3AnLCdmdWxsX3Jlc2V0J10uaW5jbHVkZXMoU3RyaW5nKGlucHV0Lm9uKSkpYnJlYWs7Y29uc3QgbWFwcGVkPXR5cGVkVmFsdWUoaW5wdXQudmFsdWUsZW50aXR5LmlkLGVudGl0eSxmaWVsZCk7aWYoIW1hcHBlZClyZXR1cm47b3V0cHV0LnB1c2goe29uOlN0cmluZyhpbnB1dC5vbiksdmFsdWU6bWFwcGVkLHJlYXNvbjpiZWhhdmlvclRleHQoZW50aXR5LCdyZXNldFJlYXNvbicpfSk7fWlmKG91dHB1dC5sZW5ndGghPT12YWx1ZS5sZW5ndGgpYnJlYWs7cmV0dXJuIG91dHB1dDt9XG4gICAgICBjYXNlICdleGNsdXNpb25zJzp7aWYoIUFycmF5LmlzQXJyYXkodmFsdWUpKWJyZWFrO2NvbnN0IG91dHB1dDpQdWJsaWNWYWx1ZVtdPVtdO2Zvcihjb25zdCByYXcgb2YgdmFsdWUpe2NvbnN0IGlucHV0PW9iamVjdChyYXcpO2lmKCFpbnB1dClyZXR1cm47Y29uc3QgdmFyaWFibGVJZD1yZWZlcmVuY2UoaW5wdXQudmFyaWFibGVJZCxlbnRpdHksZmllbGQsdHJ1ZSksY3VycmVudD10eXBlZFZhbHVlKGlucHV0LnZhbHVlLGVudGl0eS5pZCxlbnRpdHksZmllbGQpLG90aGVyPXR5cGVkVmFsdWUoaW5wdXQub3RoZXJWYWx1ZSxTdHJpbmcoaW5wdXQudmFyaWFibGVJZCksZW50aXR5LGZpZWxkKSxleGNlcHRpb25zPWlucHV0LmV4Y2VwdGlvbnM9PW51bGw/W106QXJyYXkuaXNBcnJheShpbnB1dC5leGNlcHRpb25zKT9pbnB1dC5leGNlcHRpb25zLm1hcChpdGVtPT5leGNlcHRpb25WYWx1ZShpdGVtLGVudGl0eSxmaWVsZCkpOnVuZGVmaW5lZDtpZighdmFyaWFibGVJZHx8IWN1cnJlbnR8fCFvdGhlcnx8IWV4Y2VwdGlvbnN8fGV4Y2VwdGlvbnMuc29tZShpdGVtPT4haXRlbSkpcmV0dXJuO2NvbnN0IHJlYXNvbj1iZWhhdmlvclRleHQoZW50aXR5LCdleGNsdXNpb25SZWFzb24nKTtpZighcmVhc29uLnRyaW0oKSl7ZmFpbCgnUFVCTElDX1RFWFRfUkVRVUlSRUQnLCfnm7jkupLmjpLku5bjga7lhazplovnlKjnkIbnlLHjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuO31vdXRwdXQucHVzaCh7dmFyaWFibGVJZCx2YWx1ZTpjdXJyZW50LG90aGVyVmFsdWU6b3RoZXIscmVhc29uLGV4Y2VwdGlvbnM6ZXhjZXB0aW9ucyBhcyBQdWJsaWNWYWx1ZVtdfSk7fXJldHVybiBvdXRwdXQ7fVxuICAgICAgY2FzZSAnYWx0ZXJuYXRpdmVzJzp7Y29uc3QgaW5wdXQ9b2JqZWN0KHZhbHVlKTtpZighaW5wdXQpYnJlYWs7Y29uc3Qgb3V0cHV0OlJlY29yZDxzdHJpbmcsUHVibGljVmFsdWU+PXt9O2Zvcihjb25zdCBba2V5LGlkc10gb2YgT2JqZWN0LmVudHJpZXMoaW5wdXQpKXtjb25zdCBpZD1yZWZlcmVuY2Uoa2V5LGVudGl0eSxmaWVsZCx0cnVlKTtpZighaWR8fCFBcnJheS5pc0FycmF5KGlkcykpcmV0dXJuO2NvbnN0IG1hcHBlZD1pZHMubWFwKGl0ZW09PnJlZmVyZW5jZShpdGVtLGVudGl0eSxmaWVsZCx0cnVlKSk7aWYobWFwcGVkLnNvbWUoaXRlbT0+IWl0ZW0pKXJldHVybjtvdXRwdXRbaWRdPW1hcHBlZCBhcyBzdHJpbmdbXTt9cmV0dXJuIG91dHB1dDt9XG4gICAgICBjYXNlICdjYW1lcmEnOntjb25zdCBhcHByb3ZlZD1wdWJsaWNGaWVsZChlbnRpdHksZmllbGQpO2xldCBpbnB1dDp1bmtub3duO3RyeXtpbnB1dD10eXBlb2YgYXBwcm92ZWQ9PT0nc3RyaW5nJz9KU09OLnBhcnNlKGFwcHJvdmVkKTp1bmRlZmluZWQ7fWNhdGNoe2JyZWFrO31jb25zdCBjYW1lcmE9b2JqZWN0KGlucHV0KTtpZighY2FtZXJhKXtmYWlsKCdQVUJMSUNfVEVYVF9SRVFVSVJFRCcsJ+WFrOmWi+eUqOOCq+ODoeODqeaMh+WumuOCkkpTT07mlofnq6DjgafmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuO31jb25zdCBvdXRwdXQ6UmVjb3JkPHN0cmluZyxQdWJsaWNWYWx1ZT49e307Zm9yKGNvbnN0IFtrZXksaXRlbV0gb2YgT2JqZWN0LmVudHJpZXMoY2FtZXJhKSl7aWYoIVsnc2hvdCcsJ2FuZ2xlJywnbW92ZW1lbnQnLCdkdXJhdGlvbk1zJ10uaW5jbHVkZXMoa2V5KXx8ISh0eXBlb2YgaXRlbT09PSdzdHJpbmcnfHx0eXBlb2YgaXRlbT09PSdudW1iZXInJiZOdW1iZXIuaXNGaW5pdGUoaXRlbSkmJml0ZW0+PTApKXtmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCfjgqvjg6Hjg6njga7mjIflrprpoIXnm67jgpLlronlhajjgavooajjgZvjgb7jgZvjgpPjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuO31vdXRwdXRba2V5XT1pdGVtO31yZXR1cm4gb3V0cHV0O31cbiAgICAgIGNhc2UgJ3JlZic6IHJldHVybiByZWZlcmVuY2UodmFsdWUsIGVudGl0eSwgZmllbGQsIEJFSEFWSU9SX1JFRlMuaGFzKGZpZWxkKSk7XG4gICAgICBjYXNlICdyZWZzJzoge1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSBicmVhaztcbiAgICAgICAgcmV0dXJuIHZhbHVlLm1hcChpZCA9PiByZWZlcmVuY2UoaWQsIGVudGl0eSwgZmllbGQsIG9wdGlvbnMuc3RyaWN0UmVmZXJlbmNlcyAmJiBCRUhBVklPUl9SRUZTLmhhcyhmaWVsZCkpKS5maWx0ZXIoKGlkKTogaWQgaXMgc3RyaW5nID0+IGlkICE9PSB1bmRlZmluZWQpO1xuICAgICAgfVxuICAgICAgY2FzZSAnbnVtYmVyJzogaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHZhbHVlKSkgcmV0dXJuIHZhbHVlOyBicmVhaztcbiAgICAgIGNhc2UgJ2Jvb2xlYW4nOiBpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiB2YWx1ZTsgYnJlYWs7XG4gICAgICBjYXNlICdlbnVtJzogaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgcnVsZS52YWx1ZXMuaW5jbHVkZXModmFsdWUpKSByZXR1cm4gdmFsdWU7IGJyZWFrO1xuICAgICAgY2FzZSAnY29uZGl0aW9uJzogcmV0dXJuIGNvbmRpdGlvblZhbHVlKHZhbHVlLCBlbnRpdHksIGZpZWxkKTtcbiAgICAgIGNhc2UgJ3R5cGVkJzogcmV0dXJuIHR5cGVkVmFsdWUodmFsdWUsIGVudGl0eS5raW5kID09PSAnZWZmZWN0JyAmJiB0eXBlb2YgZW50aXR5LmRhdGEudGFyZ2V0SWQgPT09ICdzdHJpbmcnID8gZW50aXR5LmRhdGEudGFyZ2V0SWQgOiBlbnRpdHkuaWQsIGVudGl0eSwgZmllbGQpO1xuICAgICAgY2FzZSAndHlwZWRzJzoge1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSBicmVhaztcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gdmFsdWUubWFwKGl0ZW0gPT4gdHlwZWRWYWx1ZShpdGVtLCBlbnRpdHkuaWQsIGVudGl0eSwgZmllbGQpKTtcbiAgICAgICAgcmV0dXJuIG91dHB1dC5ldmVyeShpdGVtID0+IGl0ZW0gIT09IHVuZGVmaW5lZCkgPyBvdXRwdXQgYXMgUHVibGljVmFsdWVbXSA6IHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGNhc2UgJ3NlbXZlcic6IGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIC9eKD86MHxbMS05XVswLTldKilcXC4oPzowfFsxLTldWzAtOV0qKVxcLig/OjB8WzEtOV1bMC05XSopJC8udGVzdCh2YWx1ZSkpIHJldHVybiB2YWx1ZTsgYnJlYWs7XG4gICAgICBjYXNlICdhbGxvd2VkJzoge1xuICAgICAgICBjb25zdCBpbnB1dCA9IG9iamVjdCh2YWx1ZSk7IGlmICghaW5wdXQpIGJyZWFrO1xuICAgICAgICBjb25zdCBvdXRwdXQ6IFJlY29yZDxzdHJpbmcsIFB1YmxpY1ZhbHVlPiA9IHt9O1xuICAgICAgICBpZiAoaW5wdXQubWluICE9PSB1bmRlZmluZWQgfHwgaW5wdXQubWF4ICE9PSB1bmRlZmluZWQpIHsgaWYgKCFpbnRlZ2VyKGlucHV0Lm1pbikgfHwgIWludGVnZXIoaW5wdXQubWF4KSB8fCBpbnB1dC5taW4gPiBpbnB1dC5tYXgpIGJyZWFrOyBvdXRwdXQubWluID0gaW5wdXQubWluOyBvdXRwdXQubWF4ID0gaW5wdXQubWF4OyB9XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlucHV0LnZhbHVlcykpIHtcbiAgICAgICAgICBjb25zdCB2YWx1ZXMgPSBpbnB1dC52YWx1ZXMubWFwKGl0ZW0gPT4gdHlwZW9mIGl0ZW0gPT09ICdzdHJpbmcnID8gbWFwRW51bShpdGVtLCBlbnRpdHkuaWQsIGVudGl0eSwgZmllbGQpIDogdHlwZW9mIGl0ZW0gPT09ICdib29sZWFuJyB8fCBpbnRlZ2VyKGl0ZW0pID8gaXRlbSA6IHVuZGVmaW5lZCk7XG4gICAgICAgICAgaWYgKHZhbHVlcy5zb21lKGl0ZW0gPT4gaXRlbSA9PT0gdW5kZWZpbmVkKSkgYnJlYWs7XG4gICAgICAgICAgaWYgKG5ldyBTZXQodmFsdWVzKS5zaXplICE9PSB2YWx1ZXMubGVuZ3RoKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WFrOmWi+WIl+aMmeWApOOBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgICAgICAgb3V0cHV0LnZhbHVlcyA9IHZhbHVlcyBhcyBQdWJsaWNWYWx1ZVtdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgICB9XG4gICAgICBjYXNlICd0aW1lJzoge1xuICAgICAgICBjb25zdCBpbnB1dCA9IG9iamVjdCh2YWx1ZSk7IGlmICghaW5wdXQpIGJyZWFrO1xuICAgICAgICBjb25zdCBvdXRwdXQ6IFJlY29yZDxzdHJpbmcsIFB1YmxpY1ZhbHVlPiA9IHsgbW9kZTogU3RyaW5nKGlucHV0Lm1vZGUpIH07XG4gICAgICAgIGlmIChbJ2luc3RhbnQnLCAnaW50ZXJ2YWwnLCAndW5jZXJ0YWluJ10uaW5jbHVkZXMoU3RyaW5nKGlucHV0Lm1vZGUpKSkge1xuICAgICAgICAgIGNvbnN0IGZpZWxkcyA9IGlucHV0Lm1vZGUgPT09ICdpbnN0YW50JyA/IFsnYXQnXSA6IGlucHV0Lm1vZGUgPT09ICdpbnRlcnZhbCcgPyBbJ3N0YXJ0JywgJ2VuZCddIDogWydlYXJsaWVzdCcsICdsYXRlc3QnXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBmaWVsZHMpIHsgaWYgKHR5cGVvZiBpbnB1dFtrZXldICE9PSAnc3RyaW5nJyB8fCAhVElDSy50ZXN0KGlucHV0W2tleV0pKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+S4lueVjOaXpeaZguOBrnRpY2vjgYzkuI3mraPjgafjgZnjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTsgcmV0dXJuIHVuZGVmaW5lZDsgfSBvdXRwdXRba2V5XSA9IGlucHV0W2tleV07IH1cbiAgICAgICAgICBjb25zdCBjYWxlbmRhcklkID0gcHVibGljQ2FsZW5kYXJJZChpbnB1dC5jYWxlbmRhcklkLCBlbnRpdHksIGZpZWxkKTsgaWYgKCFjYWxlbmRhcklkKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgIG91dHB1dC5jYWxlbmRhcklkID0gY2FsZW5kYXJJZDtcbiAgICAgICAgICBpZiAoaW5wdXQubW9kZSA9PT0gJ3VuY2VydGFpbicpIG91dHB1dC5wcmVjaXNpb24gPSB0ZXh0VmFsdWUoZW50aXR5LCAncHJlY2lzaW9uJykgPz8gJyc7XG4gICAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5wdXQubW9kZSA9PT0gJ3Vua25vd24nKSB7IGNvbnN0IHJlYXNvbiA9IHB1YmxpY0ZpZWxkKGVudGl0eSwgJ3JlYXNvbicpOyByZXR1cm4geyBtb2RlOiAndW5rbm93bicsIHJlYXNvbjogdHlwZW9mIHJlYXNvbiA9PT0gJ3N0cmluZycgPyByZWFzb24gOiAnJyB9OyB9XG4gICAgICAgIGlmIChpbnB1dC5tb2RlID09PSAncmVsYXRpdmUnKSB7XG4gICAgICAgICAgY29uc3QgYW5jaG9yRXZlbnRJZCA9IHJlZmVyZW5jZShpbnB1dC5hbmNob3JFdmVudElkLCBlbnRpdHksIGZpZWxkLCB0cnVlKTtcbiAgICAgICAgICBpZiAoYW5jaG9yRXZlbnRJZCAmJiBbJ3N0YXJ0JywgJ2VuZCddLmluY2x1ZGVzKFN0cmluZyhpbnB1dC5hbmNob3JQb2ludCkpICYmIHR5cGVvZiBpbnB1dC5taW5PZmZzZXQgPT09ICdzdHJpbmcnICYmIFRJQ0sudGVzdChpbnB1dC5taW5PZmZzZXQpICYmIHR5cGVvZiBpbnB1dC5tYXhPZmZzZXQgPT09ICdzdHJpbmcnICYmIFRJQ0sudGVzdChpbnB1dC5tYXhPZmZzZXQpKSByZXR1cm4geyBtb2RlOiAncmVsYXRpdmUnLCBhbmNob3JFdmVudElkLCBhbmNob3JQb2ludDogU3RyaW5nKGlucHV0LmFuY2hvclBvaW50KSwgbWluT2Zmc2V0OiBpbnB1dC5taW5PZmZzZXQsIG1heE9mZnNldDogaW5wdXQubWF4T2Zmc2V0IH07XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdwYXJ0aWNpcGFudHMnOiB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheSh2YWx1ZSkpIGJyZWFrO1xuICAgICAgICBjb25zdCBvdXRwdXQ6IFB1YmxpY1ZhbHVlW10gPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCByYXcgb2YgdmFsdWUpIHsgY29uc3QgcGFydGljaXBhbnQgPSBvYmplY3QocmF3KTsgaWYgKCFwYXJ0aWNpcGFudCkgY29udGludWU7IGNvbnN0IGNoYXJhY3RlcklkID0gcmVmZXJlbmNlKHBhcnRpY2lwYW50LmNoYXJhY3RlcklkLCBlbnRpdHksIGZpZWxkKTsgaWYgKCFjaGFyYWN0ZXJJZCkgY29udGludWU7IGlmICghWydhY3RvcicsICd3aXRuZXNzJywgJ21lbnRpb25lZCcsICdpbmZvcm1lZCcsICdjdXN0b20nXS5pbmNsdWRlcyhTdHJpbmcocGFydGljaXBhbnQucm9sZSkpKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WPguWKoOW9ueWJsuOBjOS4jeato+OBp+OBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyBjb250aW51ZTsgfSBvdXRwdXQucHVzaCh7IGNoYXJhY3RlcklkLCByb2xlOiBTdHJpbmcocGFydGljaXBhbnQucm9sZSkgfSk7IH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICAgIH1cbiAgICAgIGNhc2UgJ3BpbnMnOiB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheSh2YWx1ZSkpIGJyZWFrO1xuICAgICAgICBjb25zdCBvdXRwdXQ6IFB1YmxpY1ZhbHVlW10gPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCByYXcgb2YgdmFsdWUpIHsgY29uc3QgcGluID0gb2JqZWN0KHJhdyk7IGlmICghcGluKSBjb250aW51ZTsgY29uc3QgcGxhY2VJZCA9IHJlZmVyZW5jZShwaW4ucGxhY2VJZCwgZW50aXR5LCBmaWVsZCk7IGlmICghcGxhY2VJZCkgY29udGludWU7IGlmICh0eXBlb2YgcGluLnggIT09ICdudW1iZXInIHx8IHR5cGVvZiBwaW4ueSAhPT0gJ251bWJlcicgfHwgcGluLnggPCAwIHx8IHBpbi54ID4gMSB8fCBwaW4ueSA8IDAgfHwgcGluLnkgPiAxKSB7IGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+WcsOWbs+W6p+aomeOBjOS4jeato+OBp+OBmeOAgicsIGVudGl0eS5pZCwgZmllbGQpOyBjb250aW51ZTsgfSBvdXRwdXQucHVzaCh7IHBsYWNlSWQsIHg6IHBpbi54LCB5OiBwaW4ueSB9KTsgfVxuICAgICAgICByZXR1cm4gb3V0cHV0O1xuICAgICAgfVxuICAgICAgY2FzZSAnZGF0ZXRpbWUnOiBpZih0eXBlb2YgdmFsdWU9PT0nc3RyaW5nJyYmTnVtYmVyLmlzRmluaXRlKERhdGUucGFyc2UodmFsdWUpKSlyZXR1cm4gdmFsdWU7YnJlYWs7XG4gICAgICBjYXNlICd2ZXJzaW9uX3JlZic6IHtjb25zdCBmaXhlZD1vcHRpb25zLnZlcnNpb25UYXJnZXRzPy5bU3RyaW5nKHZhbHVlKV07aWYoIWZpeGVkKXtmYWlsKCdFWFBPUlRfVU5TVVBQT1JURUQnLCflqpLkvZPjga7lhYPlm7rlrprniYjjga7lhazplovnr4Tlm7LjgpLnorroqo3jgZfjgabjgY/jgaDjgZXjgYTjgIInLGVudGl0eS5pZCxmaWVsZCk7cmV0dXJuIHVuZGVmaW5lZDt9cmV0dXJuIGZpeGVkLnB1YmxpY1ZlcnNpb25JZDt9XG4gICAgICBjYXNlICdhbmNob3InOiByZXR1cm4gYW5jaG9yVmFsdWUodmFsdWUsIGVudGl0eSwgZmllbGQpO1xuICAgICAgY2FzZSAndHJpZ2dlcic6IHtcbiAgICAgICAgY29uc3QgaW5wdXQgPSBvYmplY3QodmFsdWUpOyBpZiAoIWlucHV0IHx8ICFbJ2VudGVyJywgJ3RhbGsnLCAnYmF0dGxlX3Jlc3VsdCcsICdtYW51YWwnLCAnY3VzdG9tJ10uaW5jbHVkZXMoU3RyaW5nKGlucHV0LmV2ZW50KSkgfHwgIVsnb25jZScsICdyZXBlYXRhYmxlJ10uaW5jbHVkZXMoU3RyaW5nKGlucHV0LnJlcGVhdCkpKSBicmVhaztcbiAgICAgICAgY29uc3QgZXZlbnRLZXkgPSB0ZXh0VmFsdWUoZW50aXR5LCAnZXZlbnRLZXknKTtcbiAgICAgICAgaWYgKHR5cGVvZiBpbnB1dC5ldmVudEtleSA9PT0gJ3N0cmluZycgJiYgaW5wdXQuZXZlbnRLZXkgJiYgZXZlbnRLZXkgPT09IHVuZGVmaW5lZCkgeyBmYWlsKCdQVUJMSUNfVEVYVF9SRVFVSVJFRCcsICflpJbpg6jjgqTjg5njg7Pjg4jlkI3jga7lhazplovooajoqJjjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInLCBlbnRpdHkuaWQsICdldmVudEtleScpOyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgICAgIGNvbnN0IGRlYWRsaW5lID0gaW5wdXQuZGVhZGxpbmUgIT0gbnVsbCA/IHNlcmlhbGl6ZSh7IC4uLmVudGl0eSwgZGF0YTogeyAuLi5lbnRpdHkuZGF0YSwgZGVhZGxpbmU6IGlucHV0LmRlYWRsaW5lIH0gfSwgJ2RlYWRsaW5lJywgdGltZSkgOiB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChpbnB1dC5kZWFkbGluZSAhPSBudWxsICYmIGRlYWRsaW5lID09PSB1bmRlZmluZWQpIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IG91dHB1dDogUmVjb3JkPHN0cmluZywgUHVibGljVmFsdWU+ID0geyBldmVudDogU3RyaW5nKGlucHV0LmV2ZW50KSwgcmVwZWF0OiBTdHJpbmcoaW5wdXQucmVwZWF0KSwgZXZlbnRLZXk6IGV2ZW50S2V5ID8/ICcnIH07XG4gICAgICAgIGlmICh0eXBlb2YgaW5wdXQuaWQgPT09ICdzdHJpbmcnICYmIGlkTWFwW2lucHV0LmlkXSkgb3V0cHV0LmlkID0gaWRNYXBbaW5wdXQuaWRdO1xuICAgICAgICBpZiAoaW5wdXQuc2NvcGUgIT0gbnVsbCkgeyBpZiAoIVsnc2NlbmUnLCAnY2hhcHRlcicsICdjaGFyYWN0ZXInLCAncnVuJywgJ2Fjcm9zc19ydW5zJ10uaW5jbHVkZXMoU3RyaW5nKGlucHV0LnNjb3BlKSkpIGJyZWFrOyBvdXRwdXQuc2NvcGUgPSBTdHJpbmcoaW5wdXQuc2NvcGUpOyB9XG4gICAgICAgIGlmIChkZWFkbGluZSAhPT0gdW5kZWZpbmVkKSBvdXRwdXQuZGVhZGxpbmUgPSBkZWFkbGluZTtcbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICAgIH1cbiAgICAgIGNhc2UgJ3RyYW5zaXRpb25zJzoge1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSBicmVhaztcbiAgICAgICAgY29uc3Qgb3V0cHV0OiBQdWJsaWNWYWx1ZVtdID0gW107XG4gICAgICAgIGNvbnN0IHZhcmlhYmxlSWQgPSBlbnRpdHkua2luZCA9PT0gJ3F1ZXN0JyAmJiB0eXBlb2YgZW50aXR5LmRhdGEuc3RhdGVWYXJpYWJsZUlkID09PSAnc3RyaW5nJyA/IGVudGl0eS5kYXRhLnN0YXRlVmFyaWFibGVJZCA6IGVudGl0eS5pZDtcbiAgICAgICAgZm9yIChjb25zdCByYXcgb2YgdmFsdWUpIHtcbiAgICAgICAgICBjb25zdCB0cmFuc2l0aW9uID0gb2JqZWN0KHJhdyk7IGlmICghdHJhbnNpdGlvbikgeyBmYWlsKCdWQUxJREFUSU9OX0ZBSUxFRCcsICfnirbmhYvpgbfnp7vjga7lvaLjgYzkuI3mraPjgafjgZnjgIInLCBlbnRpdHkuaWQsIGZpZWxkKTsgY29udGludWU7IH1cbiAgICAgICAgICBjb25zdCBmcm9tID0gdHlwZWRWYWx1ZSh0cmFuc2l0aW9uLmZyb20sIHZhcmlhYmxlSWQsIGVudGl0eSwgZmllbGQpLCB0byA9IHR5cGVkVmFsdWUodHJhbnNpdGlvbi50bywgdmFyaWFibGVJZCwgZW50aXR5LCBmaWVsZCk7XG4gICAgICAgICAgY29uc3QgZGV0YWlscz10cmFuc2l0aW9uLmV4Y2VwdGlvbkRldGFpbHM/ZXhjZXB0aW9uVmFsdWUodHJhbnNpdGlvbi5leGNlcHRpb25EZXRhaWxzLGVudGl0eSxmaWVsZCk6dW5kZWZpbmVkO2lmKHRyYW5zaXRpb24uZXhjZXB0aW9uPT09dHJ1ZSYmIWRldGFpbHMpe2ZhaWwoJ0VYUE9SVF9VTlNVUFBPUlRFRCcsJ+eQhueUseODu+evhOWbsuODu+acn+mZkOODu+agueaLoOOBruOBguOCi+S+i+WkluOCkuWFrOmWi+evhOWbsuOBuOWQq+OCgeOBpuOBj+OBoOOBleOBhOOAgicsZW50aXR5LmlkLGZpZWxkKTtjb250aW51ZTt9XG4gICAgICAgICAgaWYoZnJvbSE9PXVuZGVmaW5lZCYmdG8hPT11bmRlZmluZWQpb3V0cHV0LnB1c2goe2Zyb20sdG8sLi4uKGRldGFpbHM/e2V4Y2VwdGlvbjp0cnVlLGV4Y2VwdGlvbkRldGFpbHM6ZGV0YWlsc306e30pfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICAgIH1cbiAgICB9XG4gICAgZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywgJ+OBk+OBrumgheebruOBr+WvvuW/nOWFiOOBp+WuieWFqOOBq+ihqOOBm+OBvuOBm+OCk+OAgicsIGVudGl0eS5pZCwgZmllbGQpO1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH07XG4gIGNvbnN0IGVudGl0aWVzOiBQcm9qZWN0ZWRFbnRpdHlbXSA9IFtdO1xuICBmb3IgKGNvbnN0IGVudGl0eSBvZiBzZWxlY3RlZCkge1xuICAgIGNvbnN0IHNjaGVtYSA9IFBST0pFQ1RJT05fRklFTERTW2VudGl0eS5raW5kXSE7XG4gICAgY29uc3QgZXhwbGljaXQgPSBvd24oYWxsb3dlZEZpZWxkcywgZW50aXR5LmtpbmQpO1xuICAgIGNvbnN0IGZpZWxkcyA9IEFycmF5LmlzQXJyYXkoZXhwbGljaXQpID8gZXhwbGljaXQgOiBPYmplY3Qua2V5cyhzY2hlbWEpO1xuICAgIGNvbnN0IG91dHB1dDogUmVjb3JkPHN0cmluZywgUHVibGljVmFsdWU+ID0ge307XG4gICAgZm9yIChjb25zdCBmaWVsZCBvZiBmaWVsZHMpIHtcbiAgICAgIGlmICh0eXBlb2YgZmllbGQgIT09ICdzdHJpbmcnIHx8IEZPUkJJRERFTl9GSUVMRFMuaGFzKGZpZWxkKSB8fCAhaGFzT3duKHNjaGVtYSwgZmllbGQpKSB7IGZhaWwoJ0ZPUkJJRERFTicsICfoqLHlj6/jgZXjgozjgabjgYTjgarjgYTpoIXnm67jgpLlhazplovjgZfjgojjgYbjgajjgZfjgabjgYTjgb7jgZnjgIInLCBlbnRpdHkuaWQsIFN0cmluZyhmaWVsZCkpOyBjb250aW51ZTsgfVxuICAgICAgaWYgKGV4Y2x1ZGVkRmllbGRzLmluY2x1ZGVzKGZpZWxkKSB8fCBleGNsdWRlZEZpZWxkcy5pbmNsdWRlcyhgJHtlbnRpdHkua2luZH0uJHtmaWVsZH1gKSkgeyBvbWl0KGVudGl0eS5pZCwgJ+S9nOiAheOBjOmgheebruOCkumZpOWklicsIGZpZWxkKTsgY29udGludWU7IH1cbiAgICAgIGNvbnN0IHZhbHVlID0gc2VyaWFsaXplKGVudGl0eSwgZmllbGQsIHNjaGVtYVtmaWVsZF0pOyBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkgb3V0cHV0W2ZpZWxkXSA9IHZhbHVlO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIE9iamVjdC5rZXlzKGVudGl0eS5kYXRhKSkgaWYgKCFmaWVsZHMuaW5jbHVkZXMoZmllbGQpIHx8ICFoYXNPd24oc2NoZW1hLCBmaWVsZCkpIG9taXQoZW50aXR5LmlkLCBGT1JCSURERU5fRklFTERTLmhhcyhmaWVsZCkgPyAn5L2c6ICF5oOF5aCx44O756eY5a+G44Gu6aCF55uu44KS6Zmk5aSWJyA6ICflhazplovjgpLoqLHlj6/jgZfjgabjgYTjgarjgYTpoIXnm67jgpLpmaTlpJYnLCBmaWVsZCk7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnYXR0YWNobWVudCcpIHtcbiAgICAgIGNvbnN0IGFwcHJvdmVkID0gQXJyYXkuaXNBcnJheShwb2xpY3kuYXBwcm92ZWRBdHRhY2htZW50SWRzKSAmJiBwb2xpY3kuYXBwcm92ZWRBdHRhY2htZW50SWRzLmluY2x1ZGVzKGVudGl0eS5pZCk7XG4gICAgICBjb25zdCBwcm92ZW5hbmNlID0gdHlwZW9mIGVudGl0eS5kYXRhLnByb3ZlbmFuY2VJZCA9PT0gJ3N0cmluZycgPyBzb3VyY2UuZ2V0KGVudGl0eS5kYXRhLnByb3ZlbmFuY2VJZCkgOiB1bmRlZmluZWQ7XG4gICAgICBpZiAoIWFwcHJvdmVkIHx8IChwcm92ZW5hbmNlICYmIHByb3ZlbmFuY2UuZGF0YS5yZWRpc3RyaWJ1dGlvbkFsbG93ZWQgIT09IHRydWUpKSBmYWlsKCdGT1JCSURERU4nLCAn5re75LuY44Gu5YaN6YWN5biD6Kix5Y+v44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJywgZW50aXR5LmlkKTtcbiAgICAgIGNvbnN0IG1lZGlhVHlwZSA9IGVudGl0eS5kYXRhLm1lZGlhVHlwZTtcbiAgICAgIGlmICh0eXBlb2YgbWVkaWFUeXBlICE9PSAnc3RyaW5nJyB8fCAhQVNTRVRfVFlQRVNbbWVkaWFUeXBlXSkgZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywgJ+OBk+OBrue0oOadkOW9ouW8j+OBr+WFrOmWi+WHuuWKm+OBq+WvvuW/nOOBl+OBpuOBhOOBvuOBm+OCk+OAgicsIGVudGl0eS5pZCwgJ21lZGlhVHlwZScpO1xuICAgICAgZWxzZSB7IG91dHB1dC5tZWRpYVR5cGUgPSBtZWRpYVR5cGU7IG91dHB1dC5hc3NldFBhdGggPSBgYXNzZXRzLyR7aWRNYXBbZW50aXR5LmlkXX0uJHtBU1NFVF9UWVBFU1ttZWRpYVR5cGVdfWA7IH1cbiAgICAgIGlmICh0eXBlb2YgZW50aXR5LmRhdGEuY29udGVudEhhc2ggIT09ICdzdHJpbmcnIHx8ICEvXlthLWYwLTldezY0fSQvLnRlc3QoZW50aXR5LmRhdGEuY29udGVudEhhc2gpIHx8ICFpbnRlZ2VyKGVudGl0eS5kYXRhLmJ5dGVTaXplKSB8fCBlbnRpdHkuZGF0YS5ieXRlU2l6ZSA8IDApIGZhaWwoJ1ZBTElEQVRJT05fRkFJTEVEJywgJ+e0oOadkOOBrmhhc2jjgajjgrXjgqTjgrrjgYzkuI3mraPjgafjgZnjgIInLCBlbnRpdHkuaWQpO1xuICAgICAgZWxzZSB7IG91dHB1dC5jb250ZW50SGFzaCA9IGVudGl0eS5kYXRhLmNvbnRlbnRIYXNoOyBvdXRwdXQuYnl0ZVNpemUgPSBlbnRpdHkuZGF0YS5ieXRlU2l6ZTsgb3V0cHV0LmJ5dGVzSW5jbHVkZWQgPSBmYWxzZTsgfVxuICAgIH1cbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdzb3VyY2UnICYmIGVudGl0eS5kYXRhLnNvdXJjZVR5cGUgPT09ICd3ZWInICYmIHR5cGVvZiBvdXRwdXQubG9jYXRvciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHRyeSB7IGNvbnN0IHVybCA9IG5ldyBVUkwob3V0cHV0LmxvY2F0b3IpOyBpZiAoIVsnaHR0cDonLCAnaHR0cHM6J10uaW5jbHVkZXModXJsLnByb3RvY29sKSB8fCB1cmwudXNlcm5hbWUgfHwgdXJsLnBhc3N3b3JkKSB0aHJvdyBuZXcgRXJyb3IoKTsgfSBjYXRjaCB7IGZhaWwoJ0ZPUkJJRERFTicsICflhazplovos4fmlpnjga5VUkzjga/oqo3oqLzmg4XloLHjgpLlkKvjgb7jgarjgYRIVFRQL0hUVFBT44Gr44GX44Gm44GP44Gg44GV44GE44CCJywgZW50aXR5LmlkLCAnbG9jYXRvcicpOyB9XG4gICAgfVxuICAgIGVudGl0aWVzLnB1c2goeyBpZDogaWRNYXBbZW50aXR5LmlkXSwga2luZDogZW50aXR5LmtpbmQsIG5hbWU6IG5hbWVzLmdldChlbnRpdHkuaWQpISwgc3RhdHVzOiBlbnRpdHkuc3RhdHVzLCBkYXRhOiBvdXRwdXQgfSk7XG4gIH1cbiAgY29uc3QgcmVsYXRpb25zOiBQcm9qZWN0ZWRSZWxhdGlvbltdID0gW107XG4gIGNvbnN0IHJlbGF0aW9uSWRzID0gQXJyYXkuaXNBcnJheShwb2xpY3kuYWxsb3dlZFJlbGF0aW9uSWRzKSA/IHBvbGljeS5hbGxvd2VkUmVsYXRpb25JZHMgOiBbXTtcbiAgY29uc3QgcmVsYXRpb25Tb3VyY2UgPSBuZXcgTWFwKHByb2plY3QucmVsYXRpb25zLm1hcChyZWxhdGlvbiA9PiBbcmVsYXRpb24uaWQsIHJlbGF0aW9uXSkpO1xuICBmb3IgKGNvbnN0IHJhd0lkIG9mIHJlbGF0aW9uSWRzKSB7XG4gICAgaWYgKHR5cGVvZiByYXdJZCAhPT0gJ3N0cmluZycpIHsgZmFpbCgnVkFMSURBVElPTl9GQUlMRUQnLCAn6Zai5L+C44Gu5YWs6ZaLSUTjgYzkuI3mraPjgafjgZnjgIInLCBwcm9maWxlSWQsICdhbGxvd2VkUmVsYXRpb25JZHMnKTsgY29udGludWU7IH1cbiAgICBjb25zdCByZWxhdGlvbiA9IHJlbGF0aW9uU291cmNlLmdldChyYXdJZCk7XG4gICAgaWYgKCFyZWxhdGlvbiB8fCByZWxhdGlvbi5wcm9qZWN0SWQgIT09IHByb2plY3QucHJvamVjdElkKSB7IGZhaWwoJ1JFRkVSRU5DRV9JTlZBTElEJywgJ+S9nOWTgeWGheOBq+OBquOBhOmWouS/guOBjOWFrOmWi+evhOWbsuOBq+WQq+OBvuOCjOOBpuOBhOOBvuOBmeOAgicsIHJhd0lkKTsgY29udGludWU7IH1cbiAgICBpZiAoIXNlbGVjdGVkSWRzLmhhcyhyZWxhdGlvbi5mcm9tSWQpIHx8ICFzZWxlY3RlZElkcy5oYXMocmVsYXRpb24udG9JZCkgfHwgcmVsYXRpb24uc3RhdHVzICE9PSAnY29uZmlybWVkJyB8fCByZWxhdGlvbi5kZWxldGVkQXQpIHsgb21pdChyYXdJZCwgJ+mdnuWFrOmWi+OBruWni+eCueODu+e1gueCueOAgeWJiumZpOa4iOOBv+OBvuOBn+OBr+acqueiuuWumuOBrumWouS/gicpOyBjb250aW51ZTsgfVxuICAgIGNvbnN0IHB1YmxpY1JlbGF0aW9uVHlwZSA9IG93bihvYmplY3Qob3duKHB1YmxpY1RleHRzLCByYXdJZCkpLCAncmVsYXRpb25UeXBlJyk7XG4gICAgaWYgKHR5cGVvZiBwdWJsaWNSZWxhdGlvblR5cGUgIT09ICdzdHJpbmcnIHx8ICFwdWJsaWNSZWxhdGlvblR5cGUpIHsgZmFpbCgnUFVCTElDX1RFWFRfUkVRVUlSRUQnLCAn5YWs6ZaL55So44Gu6Zai5L+C5ZCN44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJywgcmF3SWQsICdyZWxhdGlvblR5cGUnKTsgY29udGludWU7IH1cbiAgICBhZGRJZChyYXdJZCk7XG4gICAgY29uc3QgdmFsaWRpdHk9dmFsaWRpdHlWYWx1ZShyZWxhdGlvbi52YWxpZGl0eSx7aWQ6cmF3SWQscHJvamVjdElkOnByb2plY3QucHJvamVjdElkLGtpbmQ6J25vdGUnLG5hbWU6Jycsc3RhdHVzOnJlbGF0aW9uLnN0YXR1cyxkYXRhOnt9fSwndmFsaWRpdHknKTtcbiAgICByZWxhdGlvbnMucHVzaCh7IC4uLnZhbGlkaXR5P3t2YWxpZGl0eX06e30saWQ6IGlkTWFwW3Jhd0lkXSwgZnJvbUlkOiBpZE1hcFtyZWxhdGlvbi5mcm9tSWRdLCB0b0lkOiBpZE1hcFtyZWxhdGlvbi50b0lkXSwgcmVsYXRpb25UeXBlOiBwdWJsaWNSZWxhdGlvblR5cGUsIGRpcmVjdGlvbjogcmVsYXRpb24uZGlyZWN0aW9uLCBldmlkZW5jZUlkczogcmVsYXRpb24uZXZpZGVuY2VJZHMuZmlsdGVyKGlkID0+IHNlbGVjdGVkSWRzLmhhcyhpZCkpLm1hcChpZCA9PiBpZE1hcFtpZF0pIH0pO1xuICB9XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3Vlcywgb21pc3Npb25zIH07XG4gIGNvbnN0IHByb2plY3Rpb246IFB1YmxpY1Byb2plY3Rpb24gPSB7IGZvcm1hdDogJ3NjZW5hcmlvLXByb2plY3Rpb24nLCBmb3JtYXRWZXJzaW9uOiAnMS4wLjAnLCB0aXRsZTogdGl0bGUgYXMgc3RyaW5nLCBtYWluU3RhcnQ6cHJvamVjdC5tYWluU3RhcnQsIGNhbGVuZGFycywgZW50aXRpZXMsIHJlbGF0aW9ucywgc2VhcmNoSW5kZXg6IFtdIH07XG4gIHByb2plY3Rpb24uc2VhcmNoSW5kZXggPSBidWlsZFByb2plY3Rpb25TZWFyY2hJbmRleChwcm9qZWN0aW9uKTtcbiAgcmV0dXJuIHsgb2s6IHRydWUsIHByb2plY3Rpb24sIG9taXNzaW9ucywgaWRNYXAgfTtcbn1cblxuLyoqIEEgc2NvcGUgY2FuIG5hcnJvdyBhbiBJRCBhbGxvd2xpc3Q7IGl0IG5ldmVyIGFkZHMgYW4gSUQgdGhlIGF1dGhvciBkaWQgbm90IGFwcHJvdmUuICovXG5mdW5jdGlvbiBzY29wZWRFbnRpdHlJZHMoc291cmNlOiBNYXA8c3RyaW5nLCBTb3VyY2VSZWNvcmQ+LCBwb2xpY3k6IE9iamVjdFZhbHVlLCBwcm9qZWN0SWQ6IHN0cmluZywgcHVibGljVGV4dHM6IE9iamVjdFZhbHVlLCBmYWlsOiAoY29kZTogUHJvamVjdGlvbklzc3VlWydjb2RlJ10sIG1lc3NhZ2U6IHN0cmluZywgZW50aXR5SWQ/OiBzdHJpbmcsIGZpZWxkPzogc3RyaW5nKSA9PiB2b2lkKTogU2V0PHN0cmluZz4gfCB1bmRlZmluZWQge1xuICBjb25zdCBzY29wZSA9IG9iamVjdChwb2xpY3kucm91dGVTY29wZSk7XG4gIGlmICghc2NvcGUpIHJldHVybiB1bmRlZmluZWQ7XG4gIGlmIChzY29wZS5wcm9qZWN0SWQgIT09IHByb2plY3RJZCkgeyBmYWlsKCdSRUZFUkVOQ0VfSU5WQUxJRCcsICflhazplovnr4Tlm7LjgYzliKXjga7kvZzlk4HjgpLlj4LnhafjgZfjgabjgYTjgb7jgZnjgIInLCB1bmRlZmluZWQsICdyb3V0ZVNjb3BlJyk7IHJldHVybiBuZXcgU2V0KCk7IH1cbiAgaWYgKHNjb3BlLnJvdXRlQ29uZGl0aW9uICE9IG51bGwpIHsgZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywgJ+adoeS7tuS7mOOBjee1jOi3r+OBruWuieWFqOOBquWFrOmWi+evhOWbsuOBr+acquWvvuW/nOOBp+OBmeOAgklE44G+44Gf44Gv56ug44O744Kw44Op44OV44Gn6ZmQ5a6a44GX44Gm44GP44Gg44GV44GE44CCJywgdW5kZWZpbmVkLCAncm91dGVTY29wZS5yb3V0ZUNvbmRpdGlvbicpOyByZXR1cm4gbmV3IFNldCgpOyB9XG4gIGlmIChzY29wZS5jaGFwdGVySWQgIT0gbnVsbCAmJiBzY29wZS5ncmFwaElkICE9IG51bGwpIHsgZmFpbCgnRVhQT1JUX1VOU1VQUE9SVEVEJywgJ+eroOOBqOOCsOODqeODleOBruevhOWbsuOBr+S4gOW6puOBq+S4gOOBpOmBuOOCk+OBp+OBj+OBoOOBleOBhOOAgicsIHVuZGVmaW5lZCwgJ3JvdXRlU2NvcGUnKTsgcmV0dXJuIG5ldyBTZXQoKTsgfVxuICBpZiAoc2NvcGUuY2hhcHRlcklkID09IG51bGwgJiYgc2NvcGUuZ3JhcGhJZCA9PSBudWxsKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCByb290SWQgPSBzY29wZS5jaGFwdGVySWQgPz8gc2NvcGUuZ3JhcGhJZDtcbiAgY29uc3Qgcm9vdCA9IHR5cGVvZiByb290SWQgPT09ICdzdHJpbmcnID8gc291cmNlLmdldChyb290SWQpIDogdW5kZWZpbmVkO1xuICBpZiAoIXJvb3QgfHwgcm9vdC5wcm9qZWN0SWQgIT09IHByb2plY3RJZCB8fCByb290LmtpbmQgIT09IChzY29wZS5jaGFwdGVySWQgIT0gbnVsbCA/ICdjaGFwdGVyJyA6ICdmbG93X2dyYXBoJykgfHwgcm9vdC5kZWxldGVkQXQpIHsgZmFpbCgnUkVGRVJFTkNFX0lOVkFMSUQnLCAn5YWs6ZaL56+E5Zuy44Gu56ug44G+44Gf44Gv44Kw44Op44OV44GM6KaL44Gk44GL44KK44G+44Gb44KT44CCJywgdHlwZW9mIHJvb3RJZCA9PT0gJ3N0cmluZycgPyByb290SWQgOiB1bmRlZmluZWQsICdyb3V0ZVNjb3BlJyk7IHJldHVybiBuZXcgU2V0KCk7IH1cbiAgY29uc3QgYXBwcm92ZWQgPSBuZXcgU2V0KEFycmF5LmlzQXJyYXkocG9saWN5LmluY2x1ZGVkSWRzKSA/IHBvbGljeS5pbmNsdWRlZElkcy5maWx0ZXIoKGlkKTogaWQgaXMgc3RyaW5nID0+IHR5cGVvZiBpZCA9PT0gJ3N0cmluZycpIDogW10pO1xuICBjb25zdCBuYXJyYXRpdmUgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3Qgc2NlbmVzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGlmIChyb290LmtpbmQgPT09ICdjaGFwdGVyJykge1xuICAgIG5hcnJhdGl2ZS5hZGQocm9vdC5pZCk7XG4gICAgZm9yIChjb25zdCBlbnRpdHkgb2Ygc291cmNlLnZhbHVlcygpKSBpZiAoZW50aXR5LmtpbmQgPT09ICdzY2VuZScgJiYgKGVudGl0eS5kYXRhLmNoYXB0ZXJJZCA9PT0gcm9vdC5pZCB8fCAoQXJyYXkuaXNBcnJheShyb290LmRhdGEuc2NlbmVJZHMpICYmIHJvb3QuZGF0YS5zY2VuZUlkcy5pbmNsdWRlcyhlbnRpdHkuaWQpKSkpIHNjZW5lcy5hZGQoZW50aXR5LmlkKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBncmFwaHM6IFNvdXJjZVJlY29yZFtdID0gW3Jvb3RdLCB2aXNpdGVkR3JhcGhzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgd2hpbGUgKGdyYXBocy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGdyYXBoID0gZ3JhcGhzLnBvcCgpITsgaWYgKHZpc2l0ZWRHcmFwaHMuaGFzKGdyYXBoLmlkKSkgY29udGludWU7XG4gICAgICB2aXNpdGVkR3JhcGhzLmFkZChncmFwaC5pZCk7IG5hcnJhdGl2ZS5hZGQoZ3JhcGguaWQpO1xuICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBbLi4uQXJyYXkuaXNBcnJheShncmFwaC5kYXRhLm5vZGVJZHMpID8gZ3JhcGguZGF0YS5ub2RlSWRzIDogW10sIC4uLkFycmF5LmlzQXJyYXkoZ3JhcGguZGF0YS5lZGdlSWRzKSA/IGdyYXBoLmRhdGEuZWRnZUlkcyA6IFtdXSkgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIG5hcnJhdGl2ZS5hZGQodmFsdWUpO1xuICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBBcnJheS5pc0FycmF5KGdyYXBoLmRhdGEubm9kZUlkcykgPyBncmFwaC5kYXRhLm5vZGVJZHMgOiBbXSkge1xuICAgICAgICBjb25zdCBub2RlID0gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHNvdXJjZS5nZXQodmFsdWUpIDogdW5kZWZpbmVkO1xuICAgICAgICBpZiAoIW5vZGUgfHwgbm9kZS5raW5kICE9PSAnZmxvd19ub2RlJykgY29udGludWU7XG4gICAgICAgIGlmICh0eXBlb2Ygbm9kZS5kYXRhLnNjZW5lSWQgPT09ICdzdHJpbmcnKSBzY2VuZXMuYWRkKG5vZGUuZGF0YS5zY2VuZUlkKTtcbiAgICAgICAgY29uc3QgY2hpbGQgPSB0eXBlb2Ygbm9kZS5kYXRhLmNoaWxkR3JhcGhJZCA9PT0gJ3N0cmluZycgPyBzb3VyY2UuZ2V0KG5vZGUuZGF0YS5jaGlsZEdyYXBoSWQpIDogdW5kZWZpbmVkO1xuICAgICAgICBpZiAoY2hpbGQ/LmtpbmQgPT09ICdmbG93X2dyYXBoJyAmJiBhcHByb3ZlZC5oYXMoY2hpbGQuaWQpKSBncmFwaHMucHVzaChjaGlsZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IGVsaWdpYmxlID0gKGVudGl0eTogU291cmNlUmVjb3JkKTogYm9vbGVhbiA9PiB7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnc2NlbmUnKSByZXR1cm4gc2NlbmVzLmhhcyhlbnRpdHkuaWQpO1xuICAgIGlmIChbJ2Zsb3dfZ3JhcGgnLCAnZmxvd19ub2RlJywgJ2Zsb3dfZWRnZSddLmluY2x1ZGVzKGVudGl0eS5raW5kKSkgcmV0dXJuIHJvb3Qua2luZCA9PT0gJ2Zsb3dfZ3JhcGgnICYmIG5hcnJhdGl2ZS5oYXMoZW50aXR5LmlkKTtcbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdjaGFwdGVyJykgcmV0dXJuIHJvb3Qua2luZCA9PT0gJ2NoYXB0ZXInID8gZW50aXR5LmlkID09PSByb290LmlkIDogWy4uLnNjZW5lc10uc29tZShpZCA9PiBzb3VyY2UuZ2V0KGlkKT8uZGF0YS5jaGFwdGVySWQgPT09IGVudGl0eS5pZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG4gIGNvbnN0IHJlc3VsdCA9IG5ldyBTZXQ8c3RyaW5nPigpLCBxdWV1ZSA9IFsuLi5uYXJyYXRpdmUsIC4uLnNjZW5lc107XG4gIGNvbnN0IGVucXVldWUgPSAodmFsdWU6IHVua25vd24pID0+IHsgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgYXBwcm92ZWQuaGFzKHZhbHVlKSkgcXVldWUucHVzaCh2YWx1ZSk7IH07XG4gIGNvbnN0IGNvbmRpdGlvblJlZnMgPSAodmFsdWU6IHVua25vd24sIGRlcHRoID0gMSkgPT4ge1xuICAgIGNvbnN0IGFzdCA9IG9iamVjdCh2YWx1ZSk7IGlmICghYXN0IHx8IGRlcHRoID4gMTYpIHJldHVybjtcbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIFsndmFyaWFibGVJZCcsICdpdGVtSWQnLCAnYXNzZXJ0aW9uSWQnLCAnaG9sZGVySWQnLCAnZW50aXR5SWQnLCAnY29udHJhY3RJZCddKSBlbnF1ZXVlKGFzdFtmaWVsZF0pO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGFzdC5jaGlsZHJlbikpIGFzdC5jaGlsZHJlbi5mb3JFYWNoKGNoaWxkID0+IGNvbmRpdGlvblJlZnMoY2hpbGQsIGRlcHRoICsgMSkpO1xuICAgIGlmIChhc3QuY2hpbGQpIGNvbmRpdGlvblJlZnMoYXN0LmNoaWxkLCBkZXB0aCArIDEpO1xuICB9O1xuICB3aGlsZSAocXVldWUubGVuZ3RoKSB7XG4gICAgY29uc3QgaWQgPSBxdWV1ZS5wb3AoKSE7XG4gICAgaWYgKHJlc3VsdC5oYXMoaWQpIHx8ICFhcHByb3ZlZC5oYXMoaWQpKSBjb250aW51ZTtcbiAgICBjb25zdCBlbnRpdHkgPSBzb3VyY2UuZ2V0KGlkKTsgaWYgKCFlbnRpdHkgfHwgIWVsaWdpYmxlKGVudGl0eSkpIGNvbnRpbnVlO1xuICAgIHJlc3VsdC5hZGQoaWQpO1xuICAgIGZvciAoY29uc3QgW2ZpZWxkLCBydWxlXSBvZiBPYmplY3QuZW50cmllcyhQUk9KRUNUSU9OX0ZJRUxEU1tlbnRpdHkua2luZF0gPz8ge30pKSB7XG4gICAgICBpZiAoZmllbGQgPT09ICdwYXJlbnRJZCcgfHwgZmllbGQgPT09ICdwYXJlbnRHcmFwaElkJykgY29udGludWU7XG4gICAgICBjb25zdCB2YWx1ZSA9IGVudGl0eS5kYXRhW2ZpZWxkXTtcbiAgICAgIGlmIChydWxlLnR5cGUgPT09ICdyZWYnKSBlbnF1ZXVlKHZhbHVlKTtcbiAgICAgIGVsc2UgaWYgKHJ1bGUudHlwZSA9PT0gJ3JlZnMnICYmIEFycmF5LmlzQXJyYXkodmFsdWUpKSB2YWx1ZS5mb3JFYWNoKGVucXVldWUpO1xuICAgICAgZWxzZSBpZiAocnVsZS50eXBlID09PSAnY29uZGl0aW9uJykgY29uZGl0aW9uUmVmcyh2YWx1ZSk7XG4gICAgICBlbHNlIGlmIChydWxlLnR5cGUgPT09ICd0eXBlZCcgJiYgb2JqZWN0KHZhbHVlKT8udHlwZSA9PT0gJ3JlZicpIGVucXVldWUob2JqZWN0KHZhbHVlKT8udmFsdWUpO1xuICAgICAgZWxzZSBpZiAocnVsZS50eXBlID09PSAndGltZScpIGVucXVldWUob2JqZWN0KHZhbHVlKT8uYW5jaG9yRXZlbnRJZCk7XG4gICAgICBlbHNlIGlmIChydWxlLnR5cGUgPT09ICdhbmNob3InKSB7IGVucXVldWUob2JqZWN0KHZhbHVlKT8uZW50aXR5SWQpOyBlbnF1ZXVlKG9iamVjdCh2YWx1ZSk/LmxpbmVJZCk7IH1cbiAgICAgIGVsc2UgaWYgKHJ1bGUudHlwZSA9PT0gJ3BhcnRpY2lwYW50cycgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlLmZvckVhY2godmFsdWUgPT4gZW5xdWV1ZShvYmplY3QodmFsdWUpPy5jaGFyYWN0ZXJJZCkpO1xuICAgICAgZWxzZSBpZiAocnVsZS50eXBlID09PSAncGlucycgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlLmZvckVhY2godmFsdWUgPT4gZW5xdWV1ZShvYmplY3QodmFsdWUpPy5wbGFjZUlkKSk7XG4gICAgICBlbHNlIGlmIChydWxlLnR5cGUgPT09ICdyaWNoJykge1xuICAgICAgICBjb25zdCBkb2N1bWVudCA9IG93bihvYmplY3Qob3duKHB1YmxpY1RleHRzLCBlbnRpdHkuaWQpKSwgZmllbGQpO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShkb2N1bWVudCkpIGZvciAoY29uc3QgYmxvY2sgb2YgZG9jdW1lbnQpIGlmIChBcnJheS5pc0FycmF5KG9iamVjdChibG9jayk/LmxpbmtzKSkgZm9yIChjb25zdCBsaW5rIG9mIG9iamVjdChibG9jaykhLmxpbmtzIGFzIHVua25vd25bXSkge1xuICAgICAgICAgIGNvbnN0IHRhcmdldCA9IG9iamVjdChvYmplY3QobGluayk/LnRhcmdldCkgPz8gb2JqZWN0KGxpbmspO1xuICAgICAgICAgIGVucXVldWUodGFyZ2V0Py5lbnRpdHlJZCA/PyB0YXJnZXQ/LnRhcmdldElkKTsgZW5xdWV1ZSh0YXJnZXQ/LmxpbmVJZCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gcHVibGljU3RyaW5ncyh2YWx1ZTogUHVibGljVmFsdWUpOiBzdHJpbmdbXSB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gW3ZhbHVlXTtcbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUuZmxhdE1hcChwdWJsaWNTdHJpbmdzKTtcbiAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHJldHVybiBPYmplY3QuZW50cmllcyh2YWx1ZSkuZmlsdGVyKChba2V5XSkgPT4gWyd0ZXh0JywgJ3JlYWRpbmcnLCAnc3VtbWFyeScsICdib2R5JywgJ2Rlc2NyaXB0aW9uJywgJ2xhYmVsJywgJ2Nhbm9uaWNhbCddLmluY2x1ZGVzKGtleSkpLmZsYXRNYXAoKFssIGNoaWxkXSkgPT4gcHVibGljU3RyaW5ncyhjaGlsZCkpO1xuICByZXR1cm4gW107XG59XG5leHBvcnQgZnVuY3Rpb24gYnVpbGRQcm9qZWN0aW9uU2VhcmNoSW5kZXgocHJvamVjdGlvbjogUGljazxQdWJsaWNQcm9qZWN0aW9uLCAnZW50aXRpZXMnPik6IFByb2plY3Rpb25TZWFyY2hFbnRyeVtdIHtcbiAgcmV0dXJuIHByb2plY3Rpb24uZW50aXRpZXMubWFwKGVudGl0eSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IFtlbnRpdHkubmFtZSwgLi4ucHVibGljU3RyaW5ncyhlbnRpdHkuZGF0YSldLmpvaW4oJ1xcbicpO1xuICAgIHJldHVybiB7IGVudGl0eUlkOiBlbnRpdHkuaWQsIGtpbmQ6IGVudGl0eS5raW5kLCBuYW1lOiBlbnRpdHkubmFtZSwgdGV4dCwgbm9ybWFsaXplZDogdGV4dC5ub3JtYWxpemUoJ05GS0MnKS50b0xvY2FsZUxvd2VyQ2FzZSgnamEnKSB9O1xuICB9KTtcbn1cbi8qKiBPbmx5IGFjY2VwdHMgYSBwcm9qZWN0aW9uLiBTZWFyY2hpbmcgdGhlIGF1dGhvciBwcm9qZWN0IGlzIGEgZGlmZmVyZW50IG9wZXJhdGlvbi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWFyY2hQcm9qZWN0aW9uKHByb2plY3Rpb246IFB1YmxpY1Byb2plY3Rpb24sIHF1ZXJ5OiBzdHJpbmcpOiBQcm9qZWN0aW9uU2VhcmNoRW50cnlbXSB7XG4gIGNvbnN0IG5vcm1hbGl6ZWQgPSBxdWVyeS5ub3JtYWxpemUoJ05GS0MnKS50b0xvY2FsZUxvd2VyQ2FzZSgnamEnKS50cmltKCk7XG4gIHJldHVybiBub3JtYWxpemVkID8gcHJvamVjdGlvbi5zZWFyY2hJbmRleC5maWx0ZXIoZW50cnkgPT4gZW50cnkubm9ybWFsaXplZC5pbmNsdWRlcyhub3JtYWxpemVkKSkgOiBbXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0aW9uU25hcHNob3QgeyBpZDogc3RyaW5nOyBzb3VyY2VSZXZpc2lvbjogc3RyaW5nOyBjcmVhdGVkQXQ6IHN0cmluZzsgaW1tdXRhYmxlOiB0cnVlOyBjb250ZW50SGFzaDogc3RyaW5nOyBwcm9qZWN0aW9uOiBQdWJsaWNQcm9qZWN0aW9uIH1cbmV4cG9ydCB0eXBlIERlZXBSZWFkb25seTxUPiA9IFQgZXh0ZW5kcyByZWFkb25seSAoaW5mZXIgVilbXSA/IHJlYWRvbmx5IERlZXBSZWFkb25seTxWPltdIDogVCBleHRlbmRzIG9iamVjdCA/IHsgcmVhZG9ubHkgW0sgaW4ga2V5b2YgVF06IERlZXBSZWFkb25seTxUW0tdPiB9IDogVDtcbmZ1bmN0aW9uIGZyZWV6ZTxUPih2YWx1ZTogVCk6IERlZXBSZWFkb25seTxUPiB7XG4gIGlmICh2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7IGZvciAoY29uc3QgY2hpbGQgb2YgT2JqZWN0LnZhbHVlcyh2YWx1ZSkpIGZyZWV6ZShjaGlsZCk7IE9iamVjdC5mcmVlemUodmFsdWUpOyB9XG4gIHJldHVybiB2YWx1ZSBhcyBEZWVwUmVhZG9ubHk8VD47XG59XG4vKiogQ2FsbGVyIHN1cHBsaWVzIGlkZW50aXR5L3RpbWUuIEEgcmVsZWFzZWQgcHJvamVjdGlvbiBuZXZlciBhbGlhc2VzIG11dGFibGUgYXV0aG9yIGRhdGEuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlUHJvamVjdGlvblNuYXBzaG90KHByb2plY3Rpb246IFB1YmxpY1Byb2plY3Rpb24sIG9wdGlvbnM6IHsgaWQ6IHN0cmluZzsgc291cmNlUmV2aXNpb246IHN0cmluZzsgY3JlYXRlZEF0OiBzdHJpbmcgfSk6IFByb21pc2U8RGVlcFJlYWRvbmx5PFByb2plY3Rpb25TbmFwc2hvdD4+IHtcbiAgaWYgKCFvcHRpb25zLmlkIHx8ICEvXig/OjB8WzEtOV1bMC05XSopJC8udGVzdChvcHRpb25zLnNvdXJjZVJldmlzaW9uKSB8fCAhTnVtYmVyLmlzRmluaXRlKERhdGUucGFyc2Uob3B0aW9ucy5jcmVhdGVkQXQpKSkgdGhyb3cgbmV3IEVycm9yKCdWQUxJREFUSU9OX0ZBSUxFRDogc25hcHNob3Tjga5JROODu+WvvuixoeeJiOODu+aXpeaZguOCkuaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICBjb25zdCBjb250ZW50ID0gc3RydWN0dXJlZENsb25lKHByb2plY3Rpb24pO1xuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShKU09OLnN0cmluZ2lmeShjb250ZW50KSkpO1xuICBjb25zdCBjb250ZW50SGFzaCA9IFsuLi5uZXcgVWludDhBcnJheShkaWdlc3QpXS5tYXAodmFsdWUgPT4gdmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJycpO1xuICByZXR1cm4gZnJlZXplKHsgLi4ub3B0aW9ucywgaW1tdXRhYmxlOiB0cnVlIGFzIGNvbnN0LCBjb250ZW50SGFzaCwgcHJvamVjdGlvbjogY29udGVudCB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBRUE7O0FBaURBLE1BQU1BLElBQWUsR0FBRztJQUFFQyxJQUFJLEVBQUU7RUFBTyxDQUFDO0VBQUVDLElBQWUsR0FBRztJQUFFRCxJQUFJLEVBQUU7RUFBTyxDQUFDO0VBQUVFLEdBQWMsR0FBRztJQUFFRixJQUFJLEVBQUU7RUFBTSxDQUFDO0VBQUVHLElBQWUsR0FBRztJQUFFSCxJQUFJLEVBQUU7RUFBTyxDQUFDO0FBQ2xKLE1BQU1JLE1BQWlCLEdBQUc7SUFBRUosSUFBSSxFQUFFO0VBQVMsQ0FBQztFQUFFSyxPQUFrQixHQUFHO0lBQUVMLElBQUksRUFBRTtFQUFVLENBQUM7RUFBRU0sSUFBZSxHQUFHO0lBQUVOLElBQUksRUFBRTtFQUFPLENBQUM7QUFDMUgsTUFBTU8sU0FBb0IsR0FBRztJQUFFUCxJQUFJLEVBQUU7RUFBWSxDQUFDO0VBQUVRLEtBQWdCLEdBQUc7SUFBRVIsSUFBSSxFQUFFO0VBQVEsQ0FBQztBQUN4RixNQUFNUyxLQUFLLEdBQUdBLENBQUMsR0FBR0MsTUFBZ0IsTUFBaUI7RUFBRVYsSUFBSSxFQUFFLE1BQU07RUFBRVU7QUFBTyxDQUFDLENBQUM7O0FBRTVFO0FBQ0EsT0FBTyxNQUFNQyxpQkFBNkYsR0FBR0MsTUFBTSxDQUFDQyxNQUFNLENBQUM7RUFDekhDLFNBQVMsRUFBRTtJQUFFQyxPQUFPLEVBQUVoQixJQUFJO0lBQUVpQixPQUFPLEVBQUVmLElBQUk7SUFBRWdCLElBQUksRUFBRWhCLElBQUk7SUFBRWlCLEtBQUssRUFBRVosSUFBSTtJQUFFYSxLQUFLLEVBQUViO0VBQUssQ0FBQztFQUNqRmMsS0FBSyxFQUFFO0lBQUVDLFNBQVMsRUFBRVosS0FBSyxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQztJQUFFYSxPQUFPLEVBQUVuQixJQUFJO0lBQUVvQixRQUFRLEVBQUVyQixHQUFHO0lBQUVjLE9BQU8sRUFBRWY7RUFBSyxDQUFDO0VBQ3pIdUIsS0FBSyxFQUFFO0lBQUVSLE9BQU8sRUFBRWYsSUFBSTtJQUFFSyxJQUFJO0lBQUVtQixRQUFRLEVBQUVoQixLQUFLLENBQUMsUUFBUSxFQUFFLGNBQWMsRUFBRSxNQUFNLENBQUM7SUFBRWlCLFlBQVksRUFBRTtNQUFFMUIsSUFBSSxFQUFFO0lBQWUsQ0FBQztJQUFFMkIsVUFBVSxFQUFFekIsR0FBRztJQUFFMEIsT0FBTyxFQUFFekI7RUFBSyxDQUFDO0VBQ3pKMEIsS0FBSyxFQUFFO0lBQUVOLFFBQVEsRUFBRXJCLEdBQUc7SUFBRWEsT0FBTyxFQUFFaEIsSUFBSTtJQUFFa0IsSUFBSSxFQUFFaEIsSUFBSTtJQUFFNkIsTUFBTSxFQUFFM0I7RUFBSyxDQUFDO0VBQ2pFNEIsSUFBSSxFQUFFO0lBQUVDLFFBQVEsRUFBRXZCLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDO0lBQUV3QixNQUFNLEVBQUUvQixHQUFHO0lBQUVlLElBQUksRUFBRWhCO0VBQUssQ0FBQztFQUN0RWlDLElBQUksRUFBRTtJQUFFakIsSUFBSSxFQUFFaEIsSUFBSTtJQUFFa0MsYUFBYSxFQUFFaEM7RUFBSyxDQUFDO0VBQ3pDaUMsT0FBTyxFQUFFO0lBQUVDLFFBQVEsRUFBRWxDLElBQUk7SUFBRWEsT0FBTyxFQUFFZjtFQUFLLENBQUM7RUFDMUNxQyxLQUFLLEVBQUU7SUFBRXRCLE9BQU8sRUFBRWYsSUFBSTtJQUFFZ0IsSUFBSSxFQUFFaEIsSUFBSTtJQUFFc0MsUUFBUSxFQUFFcEMsSUFBSTtJQUFFcUMsZUFBZSxFQUFFckMsSUFBSTtJQUFFc0MsU0FBUyxFQUFFdkMsR0FBRztJQUFFd0MsU0FBUyxFQUFFdkMsSUFBSTtJQUFFd0MsS0FBSyxFQUFFekMsR0FBRztJQUFFMEMsUUFBUSxFQUFFekMsSUFBSTtJQUFFMEMsT0FBTyxFQUFFekMsTUFBTTtJQUFFMEMsVUFBVSxFQUFFMUM7RUFBTyxDQUFDO0VBQzdLMkMsSUFBSSxFQUFFO0lBQUVDLE9BQU8sRUFBRTlDLEdBQUc7SUFBRStDLFdBQVcsRUFBRWhELElBQUk7SUFBRWlELE9BQU8sRUFBRS9DLElBQUk7SUFBRWdELGdCQUFnQixFQUFFaEQ7RUFBSyxDQUFDO0VBQ2hGaUQsU0FBUyxFQUFFO0lBQUVDLFFBQVEsRUFBRTVDLEtBQUssQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLENBQUM7SUFBRTZDLE9BQU8sRUFBRXBELEdBQUc7SUFBRXFELFlBQVksRUFBRXJELEdBQUc7SUFBRXNELGNBQWMsRUFBRXpELElBQUk7SUFBRTBELE9BQU8sRUFBRTtNQUFFekQsSUFBSSxFQUFFO0lBQVUsQ0FBQztJQUFFMEQsSUFBSSxFQUFFbkQsU0FBUztJQUFFb0QsZUFBZSxFQUFFbEQsS0FBSyxDQUFDLGVBQWUsRUFBRSxhQUFhLEVBQUUsV0FBVyxDQUFDO0lBQUVtRCxVQUFVLEVBQUUxRCxHQUFHO0lBQUUyRCxtQkFBbUIsRUFBRTFEO0VBQUssQ0FBQztFQUMxVDJELFNBQVMsRUFBRTtJQUFFQyxNQUFNLEVBQUU3RCxHQUFHO0lBQUU4RCxJQUFJLEVBQUU5RCxHQUFHO0lBQUUrRCxRQUFRLEVBQUV4RCxLQUFLLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxhQUFhLENBQUM7SUFBRXlELEtBQUssRUFBRW5FLElBQUk7SUFBRVEsU0FBUztJQUFFNEQsU0FBUyxFQUFFaEUsSUFBSTtJQUFFaUUsUUFBUSxFQUFFaEUsTUFBTTtJQUFFaUUsWUFBWSxFQUFFbkU7RUFBSSxDQUFDO0VBQzFLb0UsVUFBVSxFQUFFO0lBQUVDLE9BQU8sRUFBRXBFLElBQUk7SUFBRXFFLE9BQU8sRUFBRXJFLElBQUk7SUFBRXNFLFFBQVEsRUFBRXRFLElBQUk7SUFBRXVFLE9BQU8sRUFBRXZFLElBQUk7SUFBRXdFLGFBQWEsRUFBRXpFLEdBQUc7SUFBQzBFLFVBQVUsRUFBQztNQUFDNUUsSUFBSSxFQUFDO0lBQVk7RUFBRSxDQUFDO0VBQzlINkUsYUFBYSxFQUFFO0lBQUU5RSxJQUFJLEVBQUVFLElBQUk7SUFBRTZFLFNBQVMsRUFBRTVFLEdBQUc7SUFBRTZFLFlBQVksRUFBRTdFLEdBQUc7SUFBRThFLE1BQU0sRUFBRTdFO0VBQUssQ0FBQztFQUM5RThFLEtBQUssRUFBRTtJQUFFQyxHQUFHLEVBQUVuRixJQUFJO0lBQUVvRixlQUFlLEVBQUVqRixHQUFHO0lBQUUrQyxXQUFXLEVBQUVoRCxJQUFJO0lBQUVtRixPQUFPLEVBQUVqRixJQUFJO0lBQUVrRixlQUFlLEVBQUU7TUFBRXJGLElBQUksRUFBRTtJQUFjO0VBQUUsQ0FBQztFQUN0SHNGLElBQUksRUFBRTtJQUFFckUsSUFBSSxFQUFFaEIsSUFBSTtJQUFFc0YsWUFBWSxFQUFFcEYsSUFBSTtJQUFFWSxPQUFPLEVBQUVoQjtFQUFLLENBQUM7RUFDdkR5RixRQUFRLEVBQUU7SUFBRU4sR0FBRyxFQUFFbkYsSUFBSTtJQUFFMEYsU0FBUyxFQUFFaEYsS0FBSyxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDO0lBQUVpRixLQUFLLEVBQUVqRixLQUFLLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLGFBQWEsQ0FBQztJQUFFa0YsT0FBTyxFQUFFbkYsS0FBSztJQUFFb0YsT0FBTyxFQUFFO01BQUU1RixJQUFJLEVBQUU7SUFBVSxDQUFDO0lBQUVnRCxPQUFPLEVBQUU5QyxHQUFHO0lBQUUyRixrQkFBa0IsRUFBRTNGLEdBQUc7SUFBRTRGLG1CQUFtQixFQUFFekYsT0FBTztJQUFFNEMsV0FBVyxFQUFFaEQsSUFBSTtJQUFFOEYsT0FBTyxFQUFDO01BQUMvRixJQUFJLEVBQUM7SUFBWSxDQUFDO0lBQUNnRyxVQUFVLEVBQUM7TUFBQ2hHLElBQUksRUFBQztJQUFRLENBQUM7SUFBQ2lHLFVBQVUsRUFBQztNQUFDakcsSUFBSSxFQUFDO0lBQVksQ0FBQztJQUFFcUYsZUFBZSxFQUFFO01BQUVyRixJQUFJLEVBQUU7SUFBYztFQUFFLENBQUM7RUFDblprRyxNQUFNLEVBQUU7SUFBRUMsU0FBUyxFQUFFMUYsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUM7SUFBRTJGLFFBQVEsRUFBRWxHLEdBQUc7SUFBRW1HLEtBQUssRUFBRTdGLEtBQUs7SUFBRUQsU0FBUztJQUFFK0YsVUFBVSxFQUFFcEcsR0FBRztJQUFFcUcsTUFBTSxFQUFFeEcsSUFBSTtJQUFFeUcsZ0JBQWdCLEVBQUM7TUFBQ3hHLElBQUksRUFBQztJQUFXO0VBQUUsQ0FBQztFQUNsTnlHLFNBQVMsRUFBRTtJQUFFQyxTQUFTLEVBQUV4RyxHQUFHO0lBQUV5RyxTQUFTLEVBQUU1RyxJQUFJO0lBQUVzRyxLQUFLLEVBQUU3RixLQUFLO0lBQUVvRyxTQUFTLEVBQUVuRyxLQUFLLENBQUMsY0FBYyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsWUFBWSxDQUFDO0lBQUVvRyxRQUFRLEVBQUUzRyxHQUFHO0lBQUU0RyxTQUFTLEVBQUUzRyxJQUFJO0lBQUU0RyxnQkFBZ0IsRUFBRTtNQUFFL0csSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUFFdUcsTUFBTSxFQUFFeEcsSUFBSTtJQUFFaUgsUUFBUSxFQUFDO01BQUNoSCxJQUFJLEVBQUM7SUFBVTtFQUFFLENBQUM7RUFDblBpSCxVQUFVLEVBQUU7SUFBRUMsUUFBUSxFQUFFakgsSUFBSTtJQUFFa0gsTUFBTSxFQUFFbEgsSUFBSTtJQUFFbUgsaUJBQWlCLEVBQUVqSCxJQUFJO0lBQUVrSCxPQUFPLEVBQUVsSCxJQUFJO0lBQUVtSCxTQUFTLEVBQUVuSCxJQUFJO0lBQUVvSCxZQUFZLEVBQUVwSCxJQUFJO0lBQUVxSCxlQUFlLEVBQUM7TUFBQ3hILElBQUksRUFBQztJQUFjLENBQUM7SUFBQ3lILFFBQVEsRUFBQztNQUFDekgsSUFBSSxFQUFDO0lBQU8sQ0FBQztJQUFDMEgsVUFBVSxFQUFDO01BQUMxSCxJQUFJLEVBQUM7SUFBWSxDQUFDO0lBQUUySCxvQkFBb0IsRUFBRTtNQUFFM0gsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUFFNEgsZ0JBQWdCLEVBQUVuSCxLQUFLLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLFVBQVU7RUFBRSxDQUFDO0VBQzdXb0gsVUFBVSxFQUFFO0lBQUVDLFlBQVksRUFBRTVILEdBQUc7SUFBRTZILE1BQU0sRUFBRTtNQUFFL0gsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUFFZ0ksS0FBSyxFQUFFdkgsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxhQUFhLENBQUM7SUFBRXdILElBQUksRUFBRXhILEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDO0lBQUV5SCxXQUFXLEVBQUM7TUFBQ2xJLElBQUksRUFBQztJQUFPLENBQUM7SUFBQ08sU0FBUztJQUFFNEgsZ0JBQWdCLEVBQUVoSTtFQUFLLENBQUM7RUFDbk9pSSxVQUFVLEVBQUU7SUFBRUMsV0FBVyxFQUFFdEk7RUFBSyxDQUFDO0VBQ2pDdUksTUFBTSxFQUFFO0lBQUVDLFVBQVUsRUFBQztNQUFDdkksSUFBSSxFQUFDO0lBQVUsQ0FBQztJQUFDd0ksZUFBZSxFQUFDekksSUFBSTtJQUFDMEksWUFBWSxFQUFDdkksR0FBRztJQUFDd0ksVUFBVSxFQUFFakksS0FBSyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLGFBQWEsQ0FBQztJQUFFa0ksT0FBTyxFQUFFNUksSUFBSTtJQUFFNkksY0FBYyxFQUFFM0ksSUFBSTtJQUFFNEkscUJBQXFCLEVBQUV4STtFQUFRLENBQUM7RUFDM015SSxHQUFHLEVBQUU7SUFBRWYsTUFBTSxFQUFFO01BQUUvSCxJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQUUrSSxPQUFPLEVBQUVoSixJQUFJO0lBQUUwSSxZQUFZLEVBQUV2SSxHQUFHO0lBQUU0RSxTQUFTLEVBQUU1RSxHQUFHO0lBQUU4SSxVQUFVLEVBQUVqSixJQUFJO0lBQUVrSixNQUFNLEVBQUU3SSxNQUFNO0lBQUM4SSxTQUFTLEVBQUM5SSxNQUFNO0lBQUMrSSxNQUFNLEVBQUM7TUFBQ25KLElBQUksRUFBQztJQUFRO0VBQUUsQ0FBQztFQUMvSm9KLGdCQUFnQixFQUFFO0lBQUVyQixNQUFNLEVBQUU7TUFBRS9ILElBQUksRUFBRTtJQUFTLENBQUM7SUFBRXFKLFlBQVksRUFBRWpKLE1BQU07SUFBRWtKLFVBQVUsRUFBRWxKLE1BQU07SUFBRW1KLGdCQUFnQixFQUFFckosR0FBRztJQUFFc0osWUFBWSxFQUFFdEosR0FBRztJQUFFOEUsTUFBTSxFQUFFN0UsSUFBSTtJQUFFc0osT0FBTyxFQUFFeEo7RUFBSyxDQUFDO0VBQ2pLeUosWUFBWSxFQUFFO0lBQUVDLFlBQVksRUFBRXpKLEdBQUc7SUFBRTBKLFFBQVEsRUFBRTdKLElBQUk7SUFBRUEsSUFBSSxFQUFFRSxJQUFJO0lBQUUrSCxLQUFLLEVBQUV2SCxLQUFLLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxjQUFjLENBQUM7SUFBRW9KLFlBQVksRUFBRTFKO0VBQUssQ0FBQztFQUN0STJKLFNBQVMsRUFBRTtJQUFFSCxZQUFZLEVBQUV6SixHQUFHO0lBQUUwSixRQUFRLEVBQUU3SixJQUFJO0lBQUVnSyxhQUFhLEVBQUU3SixHQUFHO0lBQUV1SSxZQUFZLEVBQUV2SSxHQUFHO0lBQUU4SCxLQUFLLEVBQUV2SCxLQUFLLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsY0FBYztFQUFFLENBQUM7RUFDeEp1SixXQUFXLEVBQUU7SUFBRUMsU0FBUyxFQUFFbEssSUFBSTtJQUFFZ0IsT0FBTyxFQUFFaEIsSUFBSTtJQUFDbUssUUFBUSxFQUFDO01BQUNsSyxJQUFJLEVBQUM7SUFBZ0IsQ0FBQztJQUFDZ0gsUUFBUSxFQUFDO01BQUNoSCxJQUFJLEVBQUM7SUFBVSxDQUFDO0lBQUMwSCxVQUFVLEVBQUM7TUFBQzFILElBQUksRUFBQztJQUFZLENBQUM7SUFBRTRKLFFBQVEsRUFBRTdKLElBQUk7SUFBRW9LLFVBQVUsRUFBRWxLLElBQUk7SUFBRW1LLFlBQVksRUFBRWxLO0VBQUksQ0FBQztFQUMvTG1LLFVBQVUsRUFBQztJQUFDQyxXQUFXLEVBQUNwSyxHQUFHO0lBQUM4RyxRQUFRLEVBQUM7TUFBQ2hILElBQUksRUFBQztJQUFVLENBQUM7SUFBQ3VLLFdBQVcsRUFBQ3hLLElBQUk7SUFBQ3lLLFVBQVUsRUFBQ3pLLElBQUk7SUFBQzBLLFFBQVEsRUFBQzFLLElBQUk7SUFBQzJLLFFBQVEsRUFBQ3pLLElBQUk7SUFBQ3lILFVBQVUsRUFBQztNQUFDMUgsSUFBSSxFQUFDO0lBQVk7RUFBQyxDQUFDO0VBQ25KMkssR0FBRyxFQUFFO0lBQUVDLE9BQU8sRUFBRTFLLEdBQUc7SUFBRTJLLGdCQUFnQixFQUFFcEssS0FBSyxDQUFDLFlBQVksQ0FBQztJQUFFZ0ksWUFBWSxFQUFFdkksR0FBRztJQUFFNEssV0FBVyxFQUFFNUssR0FBRztJQUFFNkssSUFBSSxFQUFFO01BQUUvSyxJQUFJLEVBQUU7SUFBTztFQUFFLENBQUM7RUFDekhnTCxZQUFZLEVBQUU7SUFBRUMsV0FBVyxFQUFFL0ssR0FBRztJQUFFZ0wsU0FBUyxFQUFFaEwsR0FBRztJQUFFaUwsU0FBUyxFQUFFMUssS0FBSyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUM7SUFBRTJLLE1BQU0sRUFBRXJMO0VBQUssQ0FBQztFQUN4R3NMLFVBQVUsRUFBRTtJQUFFQyxJQUFJLEVBQUU3SyxLQUFLLENBQUMsT0FBTyxDQUFDO0lBQUU4SyxTQUFTLEVBQUVwTDtFQUFLLENBQUM7RUFDckRxTCxhQUFhLEVBQUU7SUFBRWxJLE9BQU8sRUFBRXBELEdBQUc7SUFBRXVMLE1BQU0sRUFBRXhMLElBQUk7SUFBRXlMLFFBQVEsRUFBQzNMLElBQUk7SUFBQzRMLFFBQVEsRUFBQzFMLElBQUk7SUFBQzJMLE1BQU0sRUFBQ3BMLEtBQUs7SUFBQ3FMLE9BQU8sRUFBRTNMLEdBQUc7SUFBRTRMLE9BQU8sRUFBRTNMLElBQUk7SUFBQzRMLHFCQUFxQixFQUFDaE07RUFBSyxDQUFDO0VBQzlJaU0sZUFBZSxFQUFFO0lBQUV2RSxRQUFRLEVBQUM7TUFBQ3pILElBQUksRUFBQztJQUFXLENBQUM7SUFBQ2lNLFFBQVEsRUFBQztNQUFDak0sSUFBSSxFQUFDO0lBQVUsQ0FBQztJQUFDa00sY0FBYyxFQUFDbk0sSUFBSTtJQUFDb00sU0FBUyxFQUFFaE0sSUFBSTtJQUFFNkgsS0FBSyxFQUFFdkgsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRSxjQUFjLEVBQUUsYUFBYSxDQUFDO0lBQUUyTCxRQUFRLEVBQUUzTCxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxDQUFDO0lBQUU0TCxTQUFTLEVBQUVsTTtFQUFLLENBQUM7RUFDMVNtTSxhQUFhLEVBQUU7SUFBRUMsTUFBTSxFQUFFOUwsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDO0lBQUMrTCxjQUFjLEVBQUM7TUFBQ3hNLElBQUksRUFBQztJQUFhLENBQUM7SUFBQ3lNLGlCQUFpQixFQUFDdk0sR0FBRztJQUFDd00sU0FBUyxFQUFDO01BQUMxTSxJQUFJLEVBQUM7SUFBVSxDQUFDO0lBQUVpQixJQUFJLEVBQUVoQixJQUFJO0lBQUU2RyxTQUFTLEVBQUUzRyxJQUFJO0lBQUV3TSxXQUFXLEVBQUV0TTtFQUFRLENBQUM7RUFDbk91TSxpQkFBaUIsRUFBRTtJQUFFMUgsR0FBRyxFQUFFbkYsSUFBSTtJQUFFOE0sS0FBSyxFQUFFcE0sS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7SUFBRXFNLFNBQVMsRUFBRXJNLEtBQUssQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQztJQUFFc00sVUFBVSxFQUFFdE0sS0FBSyxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDO0lBQUV1TSxhQUFhLEVBQUV2TSxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQztJQUFFd0MsV0FBVyxFQUFFaEQsSUFBSTtJQUFFZ04sT0FBTyxFQUFFO01BQUVqTixJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQUVrTixVQUFVLEVBQUU7TUFBRWxOLElBQUksRUFBRTtJQUFTO0VBQUU7QUFDMVIsQ0FBQyxDQUFDO0FBQ0YsT0FBTyxNQUFNbU4saUJBQWlCLEdBQUd2TSxNQUFNLENBQUNDLE1BQU0sQ0FBQ0QsTUFBTSxDQUFDd00sSUFBSSxDQUFDek0saUJBQWlCLENBQWlCLENBQUM7QUFDOUYsTUFBTTBNLGFBQWEsR0FBRyxJQUFJQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLG9CQUFvQixFQUFFLHFCQUFxQixFQUFFLGtCQUFrQixDQUFDLENBQUM7QUFDdlAsTUFBTUMsZ0JBQWdCLEdBQUcsSUFBSUQsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLG1CQUFtQixFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsV0FBVyxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQzFOLE1BQU1FLFdBQVcsR0FBRyxJQUFJRixHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztBQUMzRSxNQUFNRyxXQUFtQyxHQUFHO0VBQUUsV0FBVyxFQUFFLEtBQUs7RUFBRSxZQUFZLEVBQUUsS0FBSztFQUFFLFdBQVcsRUFBRSxLQUFLO0VBQUUsWUFBWSxFQUFFLE1BQU07RUFBRSxXQUFXLEVBQUUsS0FBSztFQUFFLFlBQVksRUFBRSxLQUFLO0VBQUUsaUJBQWlCLEVBQUUsS0FBSztFQUFFLFdBQVcsRUFBQyxLQUFLO0VBQUMsWUFBWSxFQUFDLE1BQU07RUFBQyxXQUFXLEVBQUMsS0FBSztFQUFDLFdBQVcsRUFBQyxLQUFLO0VBQUMsWUFBWSxFQUFDLEtBQUs7RUFBQyxrQkFBa0IsRUFBQyxNQUFNO0VBQUMsMEJBQTBCLEVBQUM7QUFBTSxDQUFDO0FBQzdWLE1BQU1DLElBQUksR0FBRyw0Q0FBNEM7QUFDekQsTUFBTUMsTUFBTSxHQUFJdEgsS0FBYyxJQUE4QkEsS0FBSyxLQUFLLElBQUksSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJLENBQUN1SCxLQUFLLENBQUNDLE9BQU8sQ0FBQ3hILEtBQUssQ0FBQyxHQUFHQSxLQUFLLEdBQWtCeUgsU0FBUztBQUNuSyxNQUFNQyxHQUFHLEdBQUdBLENBQUMxSCxLQUE4QixFQUFFbkIsR0FBVyxLQUFjbUIsS0FBSyxJQUFJekYsTUFBTSxDQUFDb04sU0FBUyxDQUFDQyxjQUFjLENBQUNDLElBQUksQ0FBQzdILEtBQUssRUFBRW5CLEdBQUcsQ0FBQyxHQUFHbUIsS0FBSyxDQUFDbkIsR0FBRyxDQUFDLEdBQUc0SSxTQUFTO0FBQ3hKLE1BQU1LLE1BQU0sR0FBR0EsQ0FBQzlILEtBQWEsRUFBRW5CLEdBQVcsS0FBY3RFLE1BQU0sQ0FBQ29OLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDQyxJQUFJLENBQUM3SCxLQUFLLEVBQUVuQixHQUFHLENBQUM7QUFDeEcsTUFBTWtKLEtBQUssR0FBSS9ILEtBQWMsSUFBY0EsS0FBSyxJQUFJLElBQUksSUFBSUEsS0FBSyxLQUFLLEVBQUUsSUFBS3VILEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLElBQUlBLEtBQUssQ0FBQ2dJLE1BQU0sS0FBSyxDQUFFO0FBQ3hILE1BQU1DLE9BQU8sR0FBSWpJLEtBQWMsSUFBc0IsT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSWtJLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDbkksS0FBSyxDQUFDOztBQUU3RztBQUNBLE9BQU8sU0FBU29JLGdCQUFnQkEsQ0FBQ0MsT0FBb0IsRUFBRUMsU0FBaUIsRUFBRUMsT0FBMEIsR0FBRyxDQUFDLENBQUMsRUFBb0I7RUFBQSxJQUFBQyxPQUFBLEVBQUFDLFFBQUEsRUFBQUMsUUFBQSxFQUFBQyxRQUFBO0VBQzNILE1BQU1DLE1BQXlCLEdBQUcsRUFBRTtJQUFFQyxTQUErQixHQUFHLEVBQUU7RUFDMUUsSUFBSSxDQUFDUixPQUFPLElBQUksQ0FBQ2QsS0FBSyxDQUFDQyxPQUFPLENBQUNhLE9BQU8sQ0FBQ1MsUUFBUSxDQUFDLElBQUksQ0FBQ3ZCLEtBQUssQ0FBQ0MsT0FBTyxDQUFDYSxPQUFPLENBQUNVLFNBQVMsQ0FBQyxJQUFJVixPQUFPLENBQUNTLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDQyxNQUFNLElBQUksQ0FBQ0EsTUFBTSxJQUFJLE9BQU9BLE1BQU0sQ0FBQ0MsRUFBRSxLQUFLLFFBQVEsSUFBSSxDQUFDNUIsTUFBTSxDQUFDMkIsTUFBTSxDQUFDRSxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU87SUFBRUMsRUFBRSxFQUFFLEtBQUs7SUFBRVIsTUFBTSxFQUFFLENBQUM7TUFBRVMsSUFBSSxFQUFFLG1CQUFtQjtNQUFFQyxPQUFPLEVBQUU7SUFBa0IsQ0FBQyxDQUFDO0lBQUVUO0VBQVUsQ0FBQztFQUNoUyxNQUFNVSxJQUFJLEdBQUdBLENBQUNGLElBQTZCLEVBQUVDLE9BQWUsRUFBRUUsUUFBaUIsRUFBRUMsS0FBYyxLQUFLO0lBQUViLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDO01BQUVMLElBQUk7TUFBRUMsT0FBTztNQUFFLElBQUlFLFFBQVEsR0FBRztRQUFFQTtNQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUFFLElBQUlDLEtBQUssR0FBRztRQUFFQTtNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUM7RUFBRSxDQUFDO0VBQ3ZNLE1BQU1FLElBQUksR0FBR0EsQ0FBQ0gsUUFBZ0IsRUFBRXRKLE1BQWMsRUFBRXVKLEtBQWMsS0FBSztJQUFFWixTQUFTLENBQUNhLElBQUksQ0FBQztNQUFFRixRQUFRO01BQUV0SixNQUFNO01BQUUsSUFBSXVKLEtBQUssR0FBRztRQUFFQTtNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUM7RUFBRSxDQUFDO0VBQ3pJLE1BQU14SCxNQUFNLEdBQUcsSUFBSTJILEdBQUcsQ0FBdUIsQ0FBQztFQUM5QyxLQUFLLE1BQU1YLE1BQU0sSUFBSVosT0FBTyxDQUFDUyxRQUFRLEVBQUU7SUFDckMsSUFBSTdHLE1BQU0sQ0FBQzRILEdBQUcsQ0FBQ1osTUFBTSxDQUFDQyxFQUFFLENBQUMsRUFBRUssSUFBSSxDQUFDLG1CQUFtQixFQUFFLGtCQUFrQixFQUFFTixNQUFNLENBQUNDLEVBQUUsQ0FBQztJQUNuRmpILE1BQU0sQ0FBQzZILEdBQUcsQ0FBQ2IsTUFBTSxDQUFDQyxFQUFFLEVBQUVELE1BQWlDLENBQUM7RUFDMUQ7RUFDQSxNQUFNYyxPQUFPLEdBQUc5SCxNQUFNLENBQUMrSCxHQUFHLENBQUMxQixTQUFTLENBQUM7RUFDckMsSUFBSSxDQUFDeUIsT0FBTyxJQUFJQSxPQUFPLENBQUNFLElBQUksS0FBSyxvQkFBb0IsSUFBSUYsT0FBTyxDQUFDRyxTQUFTLEtBQUs3QixPQUFPLENBQUM2QixTQUFTLElBQUlILE9BQU8sQ0FBQ0ksU0FBUyxFQUFFO0lBQ3JILE9BQU87TUFBRWYsRUFBRSxFQUFFLEtBQUs7TUFBRVIsTUFBTSxFQUFFLENBQUM7UUFBRVMsSUFBSSxFQUFFLG1CQUFtQjtRQUFFQyxPQUFPLEVBQUUsb0JBQW9CO1FBQUVFLFFBQVEsRUFBRWxCO01BQVUsQ0FBQyxDQUFDO01BQUVPO0lBQVUsQ0FBQztFQUM5SDtFQUNBLE1BQU11QixNQUFNLEdBQUdMLE9BQU8sQ0FBQ1osSUFBSTtFQUMzQixJQUFJaUIsTUFBTSxDQUFDQyxlQUFlLElBQUksSUFBSSxJQUFJRCxNQUFNLENBQUNDLGVBQWUsS0FBSzlCLE9BQU8sQ0FBQytCLGVBQWUsSUFBSUYsTUFBTSxDQUFDQyxlQUFlLEtBQUtoQyxPQUFPLENBQUNrQyxRQUFRLEVBQUVoQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsMkJBQTJCLEVBQUVqQixTQUFTLEVBQUUsaUJBQWlCLENBQUM7RUFDN04sSUFBSSxFQUFBRSxPQUFBLEdBQUFsQixNQUFNLENBQUM4QyxNQUFNLENBQUNJLFVBQVUsQ0FBQyxjQUFBaEMsT0FBQSx1QkFBekJBLE9BQUEsQ0FBMkJpQyxnQkFBZ0IsS0FBSSxJQUFJLElBQUluRCxNQUFNLENBQUM4QyxNQUFNLENBQUNJLFVBQVUsQ0FBQyxDQUFFQyxnQkFBZ0IsS0FBS2xDLE9BQU8sQ0FBQytCLGVBQWUsRUFBRWYsSUFBSSxDQUFDLG1CQUFtQixFQUFFLDRCQUE0QixFQUFFakIsU0FBUyxFQUFFLDZCQUE2QixDQUFDO0VBQ3JPLElBQUk4QixNQUFNLENBQUNNLFFBQVEsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNSLE1BQU0sQ0FBQ00sUUFBUSxDQUFDLENBQUMsRUFBRW5CLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxlQUFlLEVBQUVqQixTQUFTLEVBQUUsVUFBVSxDQUFDO0VBQzFKLElBQUk4QixNQUFNLENBQUNTLGtCQUFrQixLQUFLLElBQUksRUFBRXRCLElBQUksQ0FBQyxXQUFXLEVBQUUscUJBQXFCLEVBQUVqQixTQUFTLEVBQUUsb0JBQW9CLENBQUM7RUFDakgsTUFBTXdDLEtBQUssR0FBR3BELEdBQUcsQ0FBQzBDLE1BQU0sRUFBRSxhQUFhLENBQUM7RUFDeEMsSUFBSSxPQUFPVSxLQUFLLEtBQUssUUFBUSxJQUFJLENBQUNBLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsRUFBRXhCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSwwQkFBMEIsRUFBRWpCLFNBQVMsRUFBRSxhQUFhLENBQUM7RUFDbEksTUFBTTBDLFdBQVcsR0FBR3RELEdBQUcsQ0FBQzBDLE1BQU0sRUFBRSxhQUFhLENBQUM7SUFBRWEsWUFBWSxHQUFHdkQsR0FBRyxDQUFDMEMsTUFBTSxFQUFFLGNBQWMsQ0FBQztFQUMxRixJQUFJLENBQUM3QyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3dELFdBQVcsQ0FBQyxJQUFJQSxXQUFXLENBQUNoQyxJQUFJLENBQUNFLEVBQUUsSUFBSSxPQUFPQSxFQUFFLEtBQUssUUFBUSxDQUFDLElBQUksSUFBSWpDLEdBQUcsQ0FBQytELFdBQVcsQ0FBQyxDQUFDRSxJQUFJLEtBQUtGLFdBQVcsQ0FBQ2hELE1BQU0sRUFBRXVCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSwwQkFBMEIsRUFBRWpCLFNBQVMsRUFBRSxhQUFhLENBQUM7RUFDdE4sSUFBSSxDQUFDZixLQUFLLENBQUNDLE9BQU8sQ0FBQ3lELFlBQVksQ0FBQyxJQUFJQSxZQUFZLENBQUNqRCxNQUFNLEtBQUssQ0FBQyxJQUFJaUQsWUFBWSxDQUFDakMsSUFBSSxDQUFDaUIsSUFBSSxJQUFJLE9BQU9BLElBQUksS0FBSyxRQUFRLElBQUksQ0FBQ25DLE1BQU0sQ0FBQ3hOLGlCQUFpQixFQUFFMlAsSUFBSSxDQUFDLENBQUMsRUFBRVYsSUFBSSxDQUFDLG9CQUFvQixFQUFFLHdCQUF3QixFQUFFakIsU0FBUyxFQUFFLGNBQWMsQ0FBQztFQUN6TyxNQUFNNkMsV0FBVyxJQUFBMUMsUUFBQSxHQUFHbkIsTUFBTSxDQUFDSSxHQUFHLENBQUMwQyxNQUFNLEVBQUUsYUFBYSxDQUFDLENBQUMsY0FBQTNCLFFBQUEsY0FBQUEsUUFBQSxHQUFJLENBQUMsQ0FBQztFQUM1RCxNQUFNMkMsU0FBUyxJQUFBMUMsUUFBQSxHQUFHcEIsTUFBTSxDQUFDSSxHQUFHLENBQUMwQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUMsY0FBQTFCLFFBQUEsY0FBQUEsUUFBQSxHQUFJLENBQUMsQ0FBQztFQUN4RCxNQUFNMkMsWUFBWSxHQUFHL0QsTUFBTSxDQUFDSSxHQUFHLENBQUMwQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7RUFDdEQsTUFBTWtCLFFBQVEsR0FBR0MsZUFBZSxDQUFDdEosTUFBTSxFQUFFbUksTUFBTSxFQUFFL0IsT0FBTyxDQUFDNkIsU0FBUyxFQUFFaUIsV0FBVyxFQUFFNUIsSUFBSSxDQUFDO0VBQ3RGLE1BQU1pQyxRQUFRLEdBQUdqRSxLQUFLLENBQUNDLE9BQU8sQ0FBQzRDLE1BQU0sQ0FBQ3FCLGdCQUFnQixDQUFDLEdBQUdyQixNQUFNLENBQUNxQixnQkFBZ0IsR0FBRyxDQUFDLFdBQVcsQ0FBQztFQUNqRyxJQUFJRCxRQUFRLENBQUN4QyxJQUFJLENBQUMwQyxNQUFNLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUUsY0FBYyxDQUFDLENBQUNmLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDYyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUVuQyxJQUFJLENBQUMsV0FBVyxFQUFFLHFCQUFxQixFQUFFakIsU0FBUyxFQUFFLGtCQUFrQixDQUFDO0VBQzVLLE1BQU1xRCxRQUF3QixHQUFHLEVBQUU7RUFDbkMsTUFBTUMsS0FBSyxHQUFHLElBQUloQyxHQUFHLENBQWlCLENBQUM7RUFDdkMsTUFBTWlDLGlCQUFpQixHQUFHLElBQUlqQyxHQUFHLENBQWlCLENBQUM7RUFDbkQsTUFBTWtDLFFBQVEsR0FBRyxJQUFJN0UsR0FBRyxDQUFTTSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3dELFdBQVcsQ0FBQyxHQUFHQSxXQUFXLEdBQUcsRUFBRSxDQUFDO0VBQy9FO0VBQ0EsTUFBTWUsVUFBVSxHQUFHLENBQUMsR0FBRzlKLE1BQU0sQ0FBQzhFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2lGLE1BQU0sQ0FBQzlDLEVBQUUsSUFBSTRDLFFBQVEsQ0FBQ2pDLEdBQUcsQ0FBQ1gsRUFBRSxDQUFDLENBQUM7RUFDcEUsS0FBSyxNQUFNQSxFQUFFLElBQUk0QyxRQUFRLEVBQUUsSUFBSSxDQUFDN0osTUFBTSxDQUFDNEgsR0FBRyxDQUFDWCxFQUFFLENBQUMsRUFBRTZDLFVBQVUsQ0FBQ3JDLElBQUksQ0FBQ1IsRUFBRSxDQUFDO0VBQ25FLEtBQUssTUFBTUEsRUFBRSxJQUFJNkMsVUFBVSxFQUFFO0lBQUEsSUFBQUUsUUFBQSxFQUFBQyxRQUFBLEVBQUFDLElBQUEsRUFBQUMsUUFBQTtJQUMzQixNQUFNbkQsTUFBTSxHQUFHaEgsTUFBTSxDQUFDK0gsR0FBRyxDQUFDZCxFQUFFLENBQUM7SUFDN0IsSUFBSSxDQUFDRCxNQUFNLElBQUlBLE1BQU0sQ0FBQ2lCLFNBQVMsS0FBSzdCLE9BQU8sQ0FBQzZCLFNBQVMsRUFBRTtNQUFFWCxJQUFJLENBQUMsbUJBQW1CLEVBQUUsd0JBQXdCLEVBQUVMLEVBQUUsQ0FBQztNQUFFO0lBQVU7SUFDNUgsSUFBSW9DLFFBQVEsSUFBSSxDQUFDQSxRQUFRLENBQUN6QixHQUFHLENBQUNYLEVBQUUsQ0FBQyxFQUFFO01BQUVTLElBQUksQ0FBQ1QsRUFBRSxFQUFFLGlCQUFpQixDQUFDO01BQUU7SUFBVTtJQUM1RSxJQUFJRCxNQUFNLENBQUNrQixTQUFTLElBQUksQ0FBQ3FCLFFBQVEsQ0FBQ2IsUUFBUSxDQUFDMUIsTUFBTSxDQUFDeUMsTUFBTSxDQUFDLElBQUtuRCxPQUFPLENBQUM4RCxhQUFhLElBQUlwRCxNQUFNLENBQUN5QyxNQUFNLEtBQUssV0FBWSxFQUFFO01BQUUvQixJQUFJLENBQUNULEVBQUUsRUFBRSxrQkFBa0IsQ0FBQztNQUFFO0lBQVU7SUFDakssSUFBSSxDQUFDM0IsS0FBSyxDQUFDQyxPQUFPLENBQUN5RCxZQUFZLENBQUMsSUFBSSxDQUFDQSxZQUFZLENBQUNOLFFBQVEsQ0FBQzFCLE1BQU0sQ0FBQ2dCLElBQUksQ0FBQyxFQUFFO01BQUVOLElBQUksQ0FBQ1QsRUFBRSxFQUFFLFlBQVksQ0FBQztNQUFFO0lBQVU7SUFDN0csSUFBSSxDQUFDcEIsTUFBTSxDQUFDeE4saUJBQWlCLEVBQUUyTyxNQUFNLENBQUNnQixJQUFJLENBQUMsRUFBRTtNQUFFVixJQUFJLENBQUMsb0JBQW9CLEVBQUUsbUJBQW1CLEVBQUVMLEVBQUUsQ0FBQztNQUFFO0lBQVU7SUFDOUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQzFCLE1BQU0sQ0FBQ2dCLElBQUksQ0FBQyxJQUFJLEVBQUFnQyxRQUFBLEdBQUEzRSxNQUFNLENBQUMyQixNQUFNLENBQUNFLElBQUksQ0FBQ21ELEtBQUssQ0FBQyxjQUFBTCxRQUFBLHVCQUF6QkEsUUFBQSxDQUEyQmhILElBQUksTUFBS3dDLFNBQVMsSUFBSSxFQUFBeUUsUUFBQSxHQUFBNUUsTUFBTSxDQUFDMkIsTUFBTSxDQUFDRSxJQUFJLENBQUNtRCxLQUFLLENBQUMsY0FBQUosUUFBQSx1QkFBekJBLFFBQUEsQ0FBMkJqSCxJQUFJLE1BQUssT0FBTyxFQUFFO01BQUVzRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsNERBQTRELEVBQUVMLEVBQUUsRUFBRSxPQUFPLENBQUM7TUFBRTtJQUFVO0lBQ3JRLE1BQU1xRCxVQUFVLEdBQUdqRixNQUFNLENBQUNJLEdBQUcsQ0FBQzJELFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztJQUMxRCxNQUFNbUIsVUFBVSxJQUFBTCxJQUFBLElBQUFDLFFBQUEsR0FBRzlFLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDNkUsVUFBVSxFQUFFckQsRUFBRSxDQUFDLENBQUMsY0FBQWtELFFBQUEsY0FBQUEsUUFBQSxHQUFJOUUsTUFBTSxDQUFDSSxHQUFHLENBQUMyRCxZQUFZLEVBQUUsZUFBZSxDQUFDLENBQUMsY0FBQWMsSUFBQSxjQUFBQSxJQUFBLEdBQUssUUFBT2QsWUFBWSxhQUFaQSxZQUFZLHVCQUFaQSxZQUFZLENBQUVwRyxJQUFJLE1BQUssUUFBUSxHQUFHb0csWUFBWSxHQUFHNUQsU0FBVTtJQUNuSyxJQUFJLENBQUErRSxVQUFVLGFBQVZBLFVBQVUsdUJBQVZBLFVBQVUsQ0FBRXZILElBQUksTUFBSyxTQUFTLEVBQUU7TUFBRTBFLElBQUksQ0FBQ1QsRUFBRSxFQUFFLFdBQVcsQ0FBQztNQUFFO0lBQVU7SUFDdkUsSUFBSXVELFVBQW1CO0lBQ3ZCLElBQUksQ0FBQUQsVUFBVSxhQUFWQSxVQUFVLHVCQUFWQSxVQUFVLENBQUV2SCxJQUFJLE1BQUssU0FBUyxFQUFFd0gsVUFBVSxHQUFHRCxVQUFVLENBQUNFLFdBQVcsQ0FBQyxLQUNuRSxJQUFJLENBQUFGLFVBQVUsYUFBVkEsVUFBVSx1QkFBVkEsVUFBVSxDQUFFdkgsSUFBSSxNQUFLLFdBQVcsRUFBRTtNQUFFd0gsVUFBVSxHQUFHRCxVQUFVLENBQUNDLFVBQVU7TUFBRSxJQUFJLE9BQU9ELFVBQVUsQ0FBQ0csUUFBUSxLQUFLLFFBQVEsRUFBRWQsaUJBQWlCLENBQUMvQixHQUFHLENBQUNaLEVBQUUsRUFBRXNELFVBQVUsQ0FBQ0csUUFBUSxDQUFDO0lBQUUsQ0FBQyxNQUMxSyxJQUFJLENBQUFILFVBQVUsYUFBVkEsVUFBVSx1QkFBVkEsVUFBVSxDQUFFdkgsSUFBSSxNQUFLLE9BQU8sRUFBRTtNQUNyQyxNQUFNMkgsT0FBTyxHQUFHckYsS0FBSyxDQUFDQyxPQUFPLENBQUN5QixNQUFNLENBQUNFLElBQUksQ0FBQ3lELE9BQU8sQ0FBQyxHQUFHM0QsTUFBTSxDQUFDRSxJQUFJLENBQUN5RCxPQUFPLEdBQUcsRUFBRTtNQUM3RSxNQUFNQyxLQUFLLEdBQUdELE9BQU8sQ0FBQ3RJLEdBQUcsQ0FBQ2dELE1BQU0sQ0FBQyxDQUFDd0YsSUFBSSxDQUFDOU0sS0FBSyxJQUFJLENBQUFBLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFa0osRUFBRSxNQUFLc0QsVUFBVSxDQUFDTyxPQUFPLENBQUM7TUFDakZOLFVBQVUsR0FBR0ksS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUVuVCxJQUFJO0lBQzFCLENBQUMsTUFBTSxJQUFJdVAsTUFBTSxDQUFDK0QsSUFBSSxLQUFLLEVBQUUsRUFBRVAsVUFBVSxHQUFHLEVBQUU7SUFDOUMsSUFBSSxPQUFPQSxVQUFVLEtBQUssUUFBUSxJQUFLeEQsTUFBTSxDQUFDK0QsSUFBSSxLQUFLLEVBQUUsSUFBSSxDQUFDUCxVQUFVLENBQUMxQixJQUFJLENBQUMsQ0FBRSxFQUFFO01BQUV4QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsMkJBQTJCLEVBQUVMLEVBQUUsRUFBRSxZQUFZLENBQUM7TUFBRTtJQUFVO0lBQzNLMEMsS0FBSyxDQUFDOUIsR0FBRyxDQUFDWixFQUFFLEVBQUV1RCxVQUFVLENBQUM7SUFDekJkLFFBQVEsQ0FBQ2pDLElBQUksQ0FBQ1QsTUFBTSxDQUFDO0VBQ3ZCO0VBQ0EsTUFBTWdFLEtBQTZCLEdBQUcxUyxNQUFNLENBQUMyUyxNQUFNLENBQUMsSUFBSSxDQUEyQjtFQUNuRixNQUFNQyxVQUFVLEdBQUcsSUFBSWxHLEdBQUcsQ0FBUyxDQUFDO0VBQ3BDLElBQUltRyxRQUFRLEdBQUcsQ0FBQztFQUNoQixNQUFNQyxLQUFLLEdBQUluRSxFQUFVLElBQUs7SUFBQSxJQUFBb0UsS0FBQSxFQUFBQyxxQkFBQTtJQUM1QixJQUFJaFQsTUFBTSxDQUFDb04sU0FBUyxDQUFDQyxjQUFjLENBQUNDLElBQUksQ0FBQ29GLEtBQUssRUFBRS9ELEVBQUUsQ0FBQyxFQUFFO0lBQ3JELE1BQU1zRSxTQUFTLElBQUFGLEtBQUEsSUFBQUMscUJBQUEsR0FBRzFCLGlCQUFpQixDQUFDN0IsR0FBRyxDQUFDZCxFQUFFLENBQUMsY0FBQXFFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUk3RixHQUFHLENBQUMwRCxTQUFTLEVBQUVsQyxFQUFFLENBQUMsY0FBQW9FLEtBQUEsY0FBQUEsS0FBQSxHQUFLbEQsTUFBTSxDQUFDTSxRQUFRLEtBQUssVUFBVSxHQUFHeEIsRUFBRSxHQUFHLFVBQVUwQixNQUFNLENBQUMsRUFBRXdDLFFBQVEsQ0FBQyxDQUFDSyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFHO0lBQzVKLElBQUksT0FBT0QsU0FBUyxLQUFLLFFBQVEsSUFBSSxDQUFDLG9DQUFvQyxDQUFDRSxJQUFJLENBQUNGLFNBQVMsQ0FBQyxJQUFJTCxVQUFVLENBQUN0RCxHQUFHLENBQUMyRCxTQUFTLENBQUMsRUFBRTtNQUFFakUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLHFCQUFxQixFQUFFTCxFQUFFLEVBQUUsV0FBVyxDQUFDO01BQUU7SUFBUTtJQUN0TStELEtBQUssQ0FBQy9ELEVBQUUsQ0FBQyxHQUFHc0UsU0FBUztJQUFFTCxVQUFVLENBQUNRLEdBQUcsQ0FBQ0gsU0FBUyxDQUFDO0VBQ2xELENBQUM7RUFDRDdCLFFBQVEsQ0FBQ2lDLE9BQU8sQ0FBQzNFLE1BQU0sSUFBSW9FLEtBQUssQ0FBQ3BFLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDLENBQUM7RUFDNUM7RUFDQSxNQUFNMkUsYUFBYSxHQUFHdkcsTUFBTSxDQUFDSSxHQUFHLENBQUMwQyxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUM7RUFDMUQsTUFBTTBELGNBQWMsR0FBR3ZHLEtBQUssQ0FBQ0MsT0FBTyxDQUFDNEMsTUFBTSxDQUFDMEQsY0FBYyxDQUFDLEdBQUcxRCxNQUFNLENBQUMwRCxjQUFjLEdBQUcsRUFBRTtFQUN4RixNQUFNQyxjQUFjLEdBQUcsSUFBSTlHLEdBQUcsQ0FBUyxDQUFDO0VBQ3hDLE1BQU0rRyxpQkFBaUIsR0FBQyxJQUFJcEUsR0FBRyxDQUFnQixDQUFDO0lBQUNxRSxpQkFBaUIsR0FBQyxJQUFJckUsR0FBRyxDQUFnQixDQUFDO0VBQzNGLEtBQUssTUFBTVgsTUFBTSxJQUFJMEMsUUFBUSxFQUFFO0lBQzdCLEtBQUksTUFBTTNMLEtBQUssSUFBSXpGLE1BQU0sQ0FBQ0YsTUFBTSxDQUFDNE8sTUFBTSxDQUFDRSxJQUFJLENBQUMsRUFBQyxJQUFHNUIsS0FBSyxDQUFDQyxPQUFPLENBQUN4SCxLQUFLLENBQUMsRUFBQyxLQUFJLE1BQU1rTyxHQUFHLElBQUlsTyxLQUFLLEVBQUM7TUFBQyxNQUFNbU8sS0FBSyxHQUFDN0csTUFBTSxDQUFDNEcsR0FBRyxDQUFDO01BQUMsSUFBRyxRQUFPQyxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRWpGLEVBQUUsTUFBRyxRQUFRLElBQUUsT0FBT2lGLEtBQUssQ0FBQ3pVLElBQUksS0FBRyxRQUFRLEVBQUN1VSxpQkFBaUIsQ0FBQ25FLEdBQUcsQ0FBQ3FFLEtBQUssQ0FBQ2pGLEVBQUUsRUFBQ0QsTUFBTSxDQUFDQyxFQUFFLENBQUM7SUFBQztJQUM3TixNQUFNa0YsTUFBTSxHQUFHOUcsTUFBTSxDQUFDSSxHQUFHLENBQUN5RCxXQUFXLEVBQUVsQyxNQUFNLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELE1BQU1tRixNQUFNLEdBQUcvVCxpQkFBaUIsQ0FBQzJPLE1BQU0sQ0FBQ2dCLElBQUksQ0FBRTtJQUM5QyxNQUFNcUUsUUFBUSxHQUFHNUcsR0FBRyxDQUFDbUcsYUFBYSxFQUFFNUUsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDO0lBQ2hELEtBQUssTUFBTSxDQUFDUixLQUFLLEVBQUU4RSxJQUFJLENBQUMsSUFBSWhVLE1BQU0sQ0FBQ2lVLE9BQU8sQ0FBQ0gsTUFBTSxDQUFDLEVBQUUsSUFBSUUsSUFBSSxDQUFDNVUsSUFBSSxLQUFLLE1BQU0sS0FBSyxDQUFDNE4sS0FBSyxDQUFDQyxPQUFPLENBQUM4RyxRQUFRLENBQUMsSUFBSUEsUUFBUSxDQUFDM0QsUUFBUSxDQUFDbEIsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDcUUsY0FBYyxDQUFDbkQsUUFBUSxDQUFDbEIsS0FBSyxDQUFDLElBQUksQ0FBQ3FFLGNBQWMsQ0FBQ25ELFFBQVEsQ0FBQyxHQUFHMUIsTUFBTSxDQUFDZ0IsSUFBSSxJQUFJUixLQUFLLEVBQUUsQ0FBQyxJQUFJbEMsS0FBSyxDQUFDQyxPQUFPLENBQUNFLEdBQUcsQ0FBQzBHLE1BQU0sRUFBRTNFLEtBQUssQ0FBQyxDQUFDLEVBQUU7TUFDclEsS0FBSyxNQUFNMEUsS0FBSyxJQUFJQyxNQUFNLENBQUUzRSxLQUFLLENBQUMsRUFBZTtRQUMvQyxNQUFNZ0YsTUFBTSxHQUFHbkgsTUFBTSxDQUFDNkcsS0FBSyxDQUFDO1FBQzVCLElBQUksUUFBT00sTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUV2RixFQUFFLE1BQUssUUFBUSxFQUFFO1VBQ2xDLElBQUlqSCxNQUFNLENBQUM0SCxHQUFHLENBQUM0RSxNQUFNLENBQUN2RixFQUFFLENBQUMsSUFBSTZFLGNBQWMsQ0FBQ2xFLEdBQUcsQ0FBQzRFLE1BQU0sQ0FBQ3ZGLEVBQUUsQ0FBQyxFQUFFSyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsd0JBQXdCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUMsQ0FBQyxLQUM3SDtZQUFFc0UsY0FBYyxDQUFDSixHQUFHLENBQUNjLE1BQU0sQ0FBQ3ZGLEVBQUUsQ0FBQztZQUFDOEUsaUJBQWlCLENBQUNsRSxHQUFHLENBQUMyRSxNQUFNLENBQUN2RixFQUFFLEVBQUNELE1BQU0sQ0FBQ0MsRUFBRSxDQUFDO1lBQUVtRSxLQUFLLENBQUNvQixNQUFNLENBQUN2RixFQUFFLENBQUM7VUFBRTtRQUNyRztNQUNGO0lBQ0Y7SUFDQSxNQUFNOUwsT0FBTyxHQUFHa0ssTUFBTSxDQUFDMkIsTUFBTSxDQUFDRSxJQUFJLENBQUMvTCxPQUFPLENBQUM7SUFDM0MsSUFBSTZMLE1BQU0sQ0FBQ2dCLElBQUksS0FBSyxXQUFXLElBQUksUUFBTzdNLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFOEwsRUFBRSxNQUFLLFFBQVEsRUFBRW1FLEtBQUssQ0FBQ2pRLE9BQU8sQ0FBQzhMLEVBQUUsQ0FBQztFQUN2RjtFQUNBLE1BQU13RixXQUFXLEdBQUcsSUFBSXpILEdBQUcsQ0FBQzBFLFFBQVEsQ0FBQ3JILEdBQUcsQ0FBQzJFLE1BQU0sSUFBSUEsTUFBTSxDQUFDQyxFQUFFLENBQUMsQ0FBQztFQUM5RCxNQUFNeUYsWUFBWSxJQUFBaEcsUUFBQSxHQUFDckIsTUFBTSxDQUFDOEMsTUFBTSxDQUFDdUUsWUFBWSxDQUFDLGNBQUFoRyxRQUFBLGNBQUFBLFFBQUEsR0FBRSxDQUFDLENBQUM7RUFDbEQsS0FBSSxNQUFNLENBQUNpRyxXQUFXLEVBQUNDLFdBQVcsQ0FBQyxJQUFHdFUsTUFBTSxDQUFDaVUsT0FBTyxDQUFDRyxZQUFZLENBQUMsRUFBQztJQUFDLElBQUcsT0FBT0UsV0FBVyxLQUFHLFFBQVEsSUFBRSxDQUFDZCxjQUFjLENBQUNsRSxHQUFHLENBQUMrRSxXQUFXLENBQUMsSUFBRSxDQUFDM0IsS0FBSyxDQUFDMkIsV0FBVyxDQUFDLElBQUVYLGlCQUFpQixDQUFDakUsR0FBRyxDQUFDNkUsV0FBVyxDQUFDLEtBQUdiLGlCQUFpQixDQUFDaEUsR0FBRyxDQUFDNEUsV0FBVyxDQUFDLEVBQUM7TUFBQ3JGLElBQUksQ0FBQyxtQkFBbUIsRUFBQyxrQkFBa0IsRUFBQ2pCLFNBQVMsRUFBQyxjQUFjLENBQUM7TUFBQztJQUFTO0lBQUMsSUFBRzJFLEtBQUssQ0FBQzRCLFdBQVcsQ0FBQyxJQUFFNUIsS0FBSyxDQUFDNEIsV0FBVyxDQUFDLEtBQUc1QixLQUFLLENBQUMyQixXQUFXLENBQUMsRUFBQztNQUFDckYsSUFBSSxDQUFDLG1CQUFtQixFQUFDLHlCQUF5QixFQUFDakIsU0FBUyxFQUFDLGNBQWMsQ0FBQztNQUFDO0lBQVM7SUFBQzJFLEtBQUssQ0FBQzRCLFdBQVcsQ0FBQyxHQUFDNUIsS0FBSyxDQUFDMkIsV0FBVyxDQUFDO0VBQUM7RUFDbmYsTUFBTUUsU0FBOEIsR0FBRyxFQUFFO0lBQUVDLFdBQVcsR0FBRyxJQUFJbkYsR0FBRyxDQUFpQixDQUFDO0VBQ2xGLE1BQU1vRixnQkFBZ0IsR0FBR0EsQ0FBQ2hQLEtBQWMsRUFBRWlKLE1BQW9CLEVBQUVRLEtBQWEsS0FBeUI7SUFDcEcsSUFBSSxPQUFPekosS0FBSyxLQUFLLFFBQVEsRUFBRTtNQUFFdUosSUFBSSxDQUFDLG1CQUFtQixFQUFFLGtCQUFrQixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO01BQUUsT0FBT2hDLFNBQVM7SUFBRTtJQUNwSCxJQUFJc0gsV0FBVyxDQUFDbEYsR0FBRyxDQUFDN0osS0FBSyxDQUFDLEVBQUUsT0FBTytPLFdBQVcsQ0FBQy9FLEdBQUcsQ0FBQ2hLLEtBQUssQ0FBQztJQUN6RCxNQUFNaVAsY0FBYyxHQUFHNUcsT0FBTyxDQUFDeUcsU0FBUyxDQUFDaEMsSUFBSSxDQUFDb0MsUUFBUSxJQUFJQSxRQUFRLENBQUNoRyxFQUFFLEtBQUtsSixLQUFLLENBQUM7SUFDaEYsSUFBSSxDQUFDaVAsY0FBYyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUN0RSxRQUFRLENBQUNzRSxjQUFjLENBQUNoRixJQUFJLENBQUMsSUFBSSxDQUFDNUMsSUFBSSxDQUFDcUcsSUFBSSxDQUFDdUIsY0FBYyxDQUFDRSxXQUFXLENBQUMsSUFBSUMsTUFBTSxDQUFDSCxjQUFjLENBQUNFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsRUFBRTtNQUFFNUYsSUFBSSxDQUFDLG1CQUFtQixFQUFFLG9CQUFvQixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO01BQUUsT0FBT2hDLFNBQVM7SUFBRTtJQUMvUCxJQUFJa0YsUUFBUSxHQUFHLG1CQUFtQm1DLFNBQVMsQ0FBQzlHLE1BQU0sR0FBRyxDQUFDLEVBQUU7SUFDeEQsT0FBT21GLFVBQVUsQ0FBQ3RELEdBQUcsQ0FBQzhDLFFBQVEsQ0FBQyxFQUFFQSxRQUFRLElBQUksV0FBVztJQUN4RFEsVUFBVSxDQUFDUSxHQUFHLENBQUNoQixRQUFRLENBQUM7SUFDeEIsTUFBTXVDLFFBQTJCLEdBQUc7TUFBRWhHLEVBQUUsRUFBRXlELFFBQVE7TUFBRUssSUFBSSxFQUFFLElBQUk4QixTQUFTLENBQUM5RyxNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQUVpQyxJQUFJLEVBQUVnRixjQUFjLENBQUNoRixJQUFJO01BQUVvRixXQUFXLEVBQUUsSUFBSTtNQUFFRixXQUFXLEVBQUVGLGNBQWMsQ0FBQ0U7SUFBWSxDQUFDO0lBQzdLLElBQUlGLGNBQWMsQ0FBQ2hGLElBQUksS0FBSyxXQUFXLEVBQUU7TUFDdkMsSUFBSSxDQUFDMUMsS0FBSyxDQUFDQyxPQUFPLENBQUN5SCxjQUFjLENBQUNLLEtBQUssQ0FBQyxJQUFJLENBQUNMLGNBQWMsQ0FBQ0ssS0FBSyxDQUFDdEgsTUFBTSxJQUFJaUgsY0FBYyxDQUFDSyxLQUFLLENBQUN0SCxNQUFNLEdBQUcsR0FBRyxFQUFFO1FBQUV1QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsc0JBQXNCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7UUFBRSxPQUFPaEMsU0FBUztNQUFFO01BQ3pNeUgsUUFBUSxDQUFDSSxLQUFLLEdBQUcsRUFBRTtNQUNuQixLQUFLLE1BQU1DLElBQUksSUFBSU4sY0FBYyxDQUFDSyxLQUFLLEVBQUU7UUFDdkMsSUFBSSxDQUFDL0gsS0FBSyxDQUFDQyxPQUFPLENBQUMrSCxJQUFJLENBQUNDLE1BQU0sQ0FBQyxJQUFJLENBQUNELElBQUksQ0FBQ0MsTUFBTSxDQUFDeEgsTUFBTSxJQUFJdUgsSUFBSSxDQUFDQyxNQUFNLENBQUN4SCxNQUFNLEdBQUcsRUFBRSxJQUFJdUgsSUFBSSxDQUFDQyxNQUFNLENBQUN4RyxJQUFJLENBQUN5RyxLQUFLLElBQUksQ0FBQ3hILE9BQU8sQ0FBQ3dILEtBQUssQ0FBQ0MsSUFBSSxDQUFDLElBQUlELEtBQUssQ0FBQ0MsSUFBSSxHQUFHLENBQUMsSUFBSUQsS0FBSyxDQUFDQyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUU7VUFBRW5HLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxxQkFBcUIsRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztVQUFFLE9BQU9oQyxTQUFTO1FBQUU7UUFDclF5SCxRQUFRLENBQUNJLEtBQUssQ0FBQzVGLElBQUksQ0FBQztVQUFFOEYsTUFBTSxFQUFFRCxJQUFJLENBQUNDLE1BQU0sQ0FBQ2xMLEdBQUcsQ0FBQyxDQUFDbUwsS0FBSyxFQUFFRSxLQUFLLE1BQU07WUFBRTNDLElBQUksRUFBRSxJQUFJMkMsS0FBSyxHQUFHLENBQUMsRUFBRTtZQUFFRCxJQUFJLEVBQUVELEtBQUssQ0FBQ0M7VUFBSyxDQUFDLENBQUM7UUFBRSxDQUFDLENBQUM7TUFDbkg7SUFDRjtJQUNBWCxXQUFXLENBQUNqRixHQUFHLENBQUM5SixLQUFLLEVBQUUyTSxRQUFRLENBQUM7SUFBRW1DLFNBQVMsQ0FBQ3BGLElBQUksQ0FBQ3dGLFFBQVEsQ0FBQztJQUMxRCxPQUFPdkMsUUFBUTtFQUNqQixDQUFDO0VBQ0QsTUFBTWlELFNBQVMsR0FBR0EsQ0FBQzVQLEtBQWMsRUFBRWlKLE1BQW9CLEVBQUVRLEtBQWEsRUFBRW9HLFNBQVMsR0FBRyxLQUFLLEtBQXlCO0lBQ2hILElBQUk3UCxLQUFLLElBQUksSUFBSSxFQUFFLE9BQU95SCxTQUFTO0lBQ25DLElBQUksT0FBT3pILEtBQUssS0FBSyxRQUFRLElBQUkwTyxXQUFXLENBQUM3RSxHQUFHLENBQUM3SixLQUFLLENBQUMsSUFBSXpGLE1BQU0sQ0FBQ29OLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDQyxJQUFJLENBQUNvRixLQUFLLEVBQUVqTixLQUFLLENBQUMsRUFBRSxPQUFPaU4sS0FBSyxDQUFDak4sS0FBSyxDQUFDO0lBQ2xJLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSXpGLE1BQU0sQ0FBQ29OLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDQyxJQUFJLENBQUNvRixLQUFLLEVBQUVqTixLQUFLLENBQUMsSUFBSXlKLEtBQUssQ0FBQ2tCLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPc0MsS0FBSyxDQUFDak4sS0FBSyxDQUFDO0lBQ25JLElBQUk2UCxTQUFTLElBQUl0SCxPQUFPLENBQUN1SCxnQkFBZ0IsRUFBRXZHLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxvQ0FBb0MsRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQyxDQUFDLEtBQ3hIRSxJQUFJLENBQUNWLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLGNBQWMsRUFBRU8sS0FBSyxDQUFDO0lBQzNDLE9BQU9oQyxTQUFTO0VBQ2xCLENBQUM7RUFDRCxNQUFNc0ksT0FBTyxHQUFHQSxDQUFDL1AsS0FBYyxFQUFFZ1EsVUFBa0IsRUFBRS9HLE1BQW9CLEVBQUVRLEtBQWEsS0FBeUI7SUFDL0csTUFBTXdHLFlBQVksR0FBRzNJLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDSixNQUFNLENBQUNJLEdBQUcsQ0FBQzBDLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQyxFQUFFNEYsVUFBVSxDQUFDLENBQUM7SUFDakYsTUFBTXRELFdBQVcsR0FBRyxPQUFPMU0sS0FBSyxLQUFLLFFBQVEsR0FBRzBILEdBQUcsQ0FBQ3VJLFlBQVksRUFBRWpRLEtBQUssQ0FBQyxHQUFHeUgsU0FBUztJQUNwRixJQUFJLE9BQU9pRixXQUFXLEtBQUssUUFBUSxFQUFFO01BQUVuRCxJQUFJLENBQUMsc0JBQXNCLEVBQUUscUJBQXFCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7TUFBRSxPQUFPaEMsU0FBUztJQUFFO0lBQ2hJLE9BQU9pRixXQUFXO0VBQ3BCLENBQUM7RUFDRCxNQUFNd0QsVUFBVSxHQUFHQSxDQUFDbFEsS0FBYyxFQUFFZ1EsVUFBa0IsRUFBRS9HLE1BQW9CLEVBQUVRLEtBQWEsS0FBOEI7SUFDdkgsSUFBSSxPQUFPekosS0FBSyxLQUFLLFFBQVEsSUFBSWlKLE1BQU0sQ0FBQ2dCLElBQUksS0FBSyxXQUFXLEVBQUU7TUFBRSxNQUFNa0csTUFBTSxHQUFHUCxTQUFTLENBQUM1UCxLQUFLLEVBQUVpSixNQUFNLEVBQUVRLEtBQUssRUFBRSxJQUFJLENBQUM7TUFBRSxPQUFPMEcsTUFBTTtJQUFFO0lBQ3JJLE1BQU1DLEtBQUssR0FBRzlJLE1BQU0sQ0FBQ3RILEtBQUssQ0FBQztJQUMzQixJQUFJLENBQUNvUSxLQUFLLEVBQUU7TUFBRTdHLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxhQUFhLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7TUFBRSxPQUFPaEMsU0FBUztJQUFFO0lBQzVGLElBQUkySSxLQUFLLENBQUN6VyxJQUFJLEtBQUssU0FBUyxJQUFJLE9BQU95VyxLQUFLLENBQUNwUSxLQUFLLEtBQUssU0FBUyxFQUFFLE9BQU87TUFBRXJHLElBQUksRUFBRSxTQUFTO01BQUVxRyxLQUFLLEVBQUVvUSxLQUFLLENBQUNwUTtJQUFNLENBQUM7SUFDaEgsSUFBSW9RLEtBQUssQ0FBQ3pXLElBQUksS0FBSyxTQUFTLElBQUlzTyxPQUFPLENBQUNtSSxLQUFLLENBQUNwUSxLQUFLLENBQUMsRUFBRSxPQUFPO01BQUVyRyxJQUFJLEVBQUUsU0FBUztNQUFFcUcsS0FBSyxFQUFFb1EsS0FBSyxDQUFDcFE7SUFBTSxDQUFDO0lBQ3BHLElBQUlvUSxLQUFLLENBQUN6VyxJQUFJLEtBQUssTUFBTSxFQUFFO01BQUUsTUFBTXdXLE1BQU0sR0FBR0osT0FBTyxDQUFDSyxLQUFLLENBQUNwUSxLQUFLLEVBQUVnUSxVQUFVLEVBQUUvRyxNQUFNLEVBQUVRLEtBQUssQ0FBQztNQUFFLE9BQU8wRyxNQUFNLEtBQUsxSSxTQUFTLEdBQUdBLFNBQVMsR0FBRztRQUFFOU4sSUFBSSxFQUFFLE1BQU07UUFBRXFHLEtBQUssRUFBRW1RO01BQU8sQ0FBQztJQUFFO0lBQ3hLLElBQUlDLEtBQUssQ0FBQ3pXLElBQUksS0FBSyxLQUFLLEVBQUU7TUFBRSxNQUFNd1csTUFBTSxHQUFHUCxTQUFTLENBQUNRLEtBQUssQ0FBQ3BRLEtBQUssRUFBRWlKLE1BQU0sRUFBRVEsS0FBSyxFQUFFLElBQUksQ0FBQztNQUFFLE9BQU8wRyxNQUFNLEdBQUc7UUFBRXhXLElBQUksRUFBRSxLQUFLO1FBQUVxRyxLQUFLLEVBQUVtUTtNQUFPLENBQUMsR0FBRzFJLFNBQVM7SUFBRTtJQUNwSjhCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxnQ0FBZ0MsRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztJQUM5RSxPQUFPaEMsU0FBUztFQUNsQixDQUFDO0VBQ0QsTUFBTTRJLGNBQWMsR0FBR0EsQ0FBQ0QsS0FBYyxFQUFFbkgsTUFBb0IsRUFBRVEsS0FBYSxLQUE4QjtJQUN2RyxJQUFJNkcsS0FBSyxHQUFHLENBQUM7SUFDYixNQUFNQyxLQUFLLEdBQUdBLENBQUN2USxLQUFjLEVBQUV3USxLQUFhLEtBQThCO01BQ3hFLE1BQU1DLEdBQUcsR0FBR25KLE1BQU0sQ0FBQ3RILEtBQUssQ0FBQztNQUN6QixJQUFJLENBQUN5USxHQUFHLElBQUlELEtBQUssR0FBRyxFQUFFLElBQUksRUFBRUYsS0FBSyxHQUFHLEdBQUcsRUFBRTtRQUFFL0csSUFBSSxDQUFDLG9CQUFvQixFQUFFLHdCQUF3QixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO1FBQUUsT0FBT2hDLFNBQVM7TUFBRTtNQUNySSxNQUFNaUosV0FBVyxHQUFJN1IsR0FBVyxJQUFLK1EsU0FBUyxDQUFDYSxHQUFHLENBQUM1UixHQUFHLENBQUMsRUFBRW9LLE1BQU0sRUFBRSxHQUFHUSxLQUFLLElBQUk1SyxHQUFHLEVBQUUsRUFBRSxJQUFJLENBQUM7TUFDekYsUUFBUTRSLEdBQUcsQ0FBQ0UsRUFBRTtRQUNaLEtBQUssVUFBVTtVQUFFLElBQUksT0FBT0YsR0FBRyxDQUFDelEsS0FBSyxLQUFLLFNBQVMsRUFBRSxPQUFPO1lBQUUyUSxFQUFFLEVBQUUsVUFBVTtZQUFFM1EsS0FBSyxFQUFFeVEsR0FBRyxDQUFDelE7VUFBTSxDQUFDO1VBQUU7UUFDbEcsS0FBSyxLQUFLO1FBQUUsS0FBSyxLQUFLO1VBQUU7WUFDdEIsSUFBSSxDQUFDdUgsS0FBSyxDQUFDQyxPQUFPLENBQUNpSixHQUFHLENBQUNHLFFBQVEsQ0FBQyxJQUFJSCxHQUFHLENBQUNHLFFBQVEsQ0FBQzVJLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDL0QsTUFBTTRJLFFBQVEsR0FBR0gsR0FBRyxDQUFDRyxRQUFRLENBQUN0TSxHQUFHLENBQUN1TSxLQUFLLElBQUlOLEtBQUssQ0FBQ00sS0FBSyxFQUFFTCxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDbkUsT0FBT0ksUUFBUSxDQUFDRSxLQUFLLENBQUNELEtBQUssSUFBSUEsS0FBSyxLQUFLcEosU0FBUyxDQUFDLEdBQUc7Y0FBRWtKLEVBQUUsRUFBRUYsR0FBRyxDQUFDRSxFQUFFO2NBQUVDLFFBQVEsRUFBRUE7WUFBMEIsQ0FBQyxHQUFHbkosU0FBUztVQUN2SDtRQUNBLEtBQUssS0FBSztVQUFFO1lBQUUsTUFBTW9KLEtBQUssR0FBR04sS0FBSyxDQUFDRSxHQUFHLENBQUNJLEtBQUssRUFBRUwsS0FBSyxHQUFHLENBQUMsQ0FBQztZQUFFLE9BQU9LLEtBQUssS0FBS3BKLFNBQVMsR0FBR0EsU0FBUyxHQUFHO2NBQUVrSixFQUFFLEVBQUUsS0FBSztjQUFFRTtZQUFNLENBQUM7VUFBRTtRQUN4SCxLQUFLLFNBQVM7VUFBRTtZQUNkLE1BQU1iLFVBQVUsR0FBR1UsV0FBVyxDQUFDLFlBQVksQ0FBQztZQUM1QyxNQUFNdlIsUUFBUSxHQUFHLE9BQU9zUixHQUFHLENBQUNULFVBQVUsS0FBSyxRQUFRLEdBQUcvTixNQUFNLENBQUMrSCxHQUFHLENBQUN5RyxHQUFHLENBQUNULFVBQVUsQ0FBQyxHQUFHdkksU0FBUztZQUM1RixNQUFNc0osVUFBVSxHQUFHTixHQUFHLENBQUNNLFVBQVU7WUFDakMsSUFBSSxDQUFDNVIsUUFBUSxJQUFJQSxRQUFRLENBQUM4SyxJQUFJLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQ1UsUUFBUSxDQUFDQyxNQUFNLENBQUNtRyxVQUFVLENBQUMsQ0FBQyxFQUFFO1lBQzNILElBQUlDLFFBQWlDO1lBQ3JDLElBQUlELFVBQVUsS0FBSyxJQUFJLElBQUl4SixLQUFLLENBQUNDLE9BQU8sQ0FBQ2lKLEdBQUcsQ0FBQ3pRLEtBQUssQ0FBQyxFQUFFO2NBQ25ELE1BQU0zRixNQUFNLEdBQUdvVyxHQUFHLENBQUN6USxLQUFLLENBQUNzRSxHQUFHLENBQUM1SSxJQUFJLElBQUl3VSxVQUFVLENBQUN4VSxJQUFJLEVBQUV5RCxRQUFRLENBQUMrSixFQUFFLEVBQUVELE1BQU0sRUFBRVEsS0FBSyxDQUFDLENBQUM7Y0FDbEYsSUFBSXBQLE1BQU0sQ0FBQ3lXLEtBQUssQ0FBQ3BWLElBQUksSUFBSUEsSUFBSSxLQUFLK0wsU0FBUyxDQUFDLEVBQUV1SixRQUFRLEdBQUczVyxNQUF1QjtZQUNsRixDQUFDLE1BQU0yVyxRQUFRLEdBQUdkLFVBQVUsQ0FBQ08sR0FBRyxDQUFDelEsS0FBSyxFQUFFYixRQUFRLENBQUMrSixFQUFFLEVBQUVELE1BQU0sRUFBRVEsS0FBSyxDQUFDO1lBQ25FLElBQUl1RyxVQUFVLElBQUlnQixRQUFRLEtBQUt2SixTQUFTLEVBQUUsT0FBTztjQUFFa0osRUFBRSxFQUFFLFNBQVM7Y0FBRVgsVUFBVTtjQUFFZSxVQUFVLEVBQUVuRyxNQUFNLENBQUNtRyxVQUFVLENBQUM7Y0FBRS9RLEtBQUssRUFBRWdSO1lBQVMsQ0FBQztZQUMvSCxPQUFPdkosU0FBUztVQUNsQjtRQUNBLEtBQUssTUFBTTtVQUFFO1lBQUUsTUFBTXdKLE1BQU0sR0FBR1AsV0FBVyxDQUFDLFFBQVEsQ0FBQztZQUFFLElBQUlPLE1BQU0sSUFBSWhKLE9BQU8sQ0FBQ3dJLEdBQUcsQ0FBQ1MsUUFBUSxDQUFDLElBQUlULEdBQUcsQ0FBQ1MsUUFBUSxJQUFJLENBQUMsRUFBRSxPQUFPO2NBQUVQLEVBQUUsRUFBRSxNQUFNO2NBQUVNLE1BQU07Y0FBRUMsUUFBUSxFQUFFVCxHQUFHLENBQUNTO1lBQVMsQ0FBQztZQUFFO1VBQU87UUFDN0ssS0FBSyxPQUFPO1VBQUU7WUFBRSxNQUFNQyxXQUFXLEdBQUdULFdBQVcsQ0FBQyxhQUFhLENBQUM7Y0FBRWxRLFFBQVEsR0FBR2tRLFdBQVcsQ0FBQyxVQUFVLENBQUM7WUFBRSxJQUFJUyxXQUFXLElBQUkzUSxRQUFRLEVBQUUsT0FBTztjQUFFbVEsRUFBRSxFQUFFLE9BQU87Y0FBRVEsV0FBVztjQUFFM1E7WUFBUyxDQUFDO1lBQUUsT0FBT2lILFNBQVM7VUFBRTtRQUNsTSxLQUFLLFNBQVM7VUFBRTtZQUFFLE1BQU0rQixRQUFRLEdBQUdrSCxXQUFXLENBQUMsVUFBVSxDQUFDO1lBQUUsSUFBSWxILFFBQVEsSUFBSXZCLE9BQU8sQ0FBQ3dJLEdBQUcsQ0FBQ1csS0FBSyxDQUFDLElBQUlYLEdBQUcsQ0FBQ1csS0FBSyxJQUFJLENBQUMsRUFBRSxPQUFPO2NBQUVULEVBQUUsRUFBRSxTQUFTO2NBQUVuSCxRQUFRO2NBQUU0SCxLQUFLLEVBQUVYLEdBQUcsQ0FBQ1c7WUFBTSxDQUFDO1lBQUU7VUFBTztRQUMvSyxLQUFLLFVBQVU7VUFBRTtZQUFFLE1BQU1DLFVBQVUsR0FBR1gsV0FBVyxDQUFDLFlBQVksQ0FBQztZQUFFLElBQUlXLFVBQVUsRUFBRSxPQUFPO2NBQUVWLEVBQUUsRUFBRSxVQUFVO2NBQUVVO1lBQVcsQ0FBQztZQUFFLE9BQU81SixTQUFTO1VBQUU7TUFDNUk7TUFDQThCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxvQkFBb0IsRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztNQUNsRSxPQUFPaEMsU0FBUztJQUNsQixDQUFDO0lBQ0QsT0FBTzhJLEtBQUssQ0FBQ0gsS0FBSyxFQUFFLENBQUMsQ0FBQztFQUN4QixDQUFDO0VBQ0QsTUFBTWtCLFdBQVcsR0FBR0EsQ0FBQ3JJLE1BQW9CLEVBQUVRLEtBQWEsS0FBYy9CLEdBQUcsQ0FBQ0osTUFBTSxDQUFDSSxHQUFHLENBQUN5RCxXQUFXLEVBQUVsQyxNQUFNLENBQUNDLEVBQUUsQ0FBQyxDQUFDLEVBQUVPLEtBQUssQ0FBQztFQUNySCxNQUFNOEgsU0FBUyxHQUFHQSxDQUFDdEksTUFBb0IsRUFBRVEsS0FBYSxLQUF5QjtJQUM3RSxNQUFNekosS0FBSyxHQUFHc1IsV0FBVyxDQUFDckksTUFBTSxFQUFFUSxLQUFLLENBQUM7SUFDeEMsSUFBSSxPQUFPekosS0FBSyxLQUFLLFFBQVEsRUFBRSxPQUFPQSxLQUFLO0lBQzNDLElBQUksQ0FBQytILEtBQUssQ0FBQ2tCLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDTSxLQUFLLENBQUMsQ0FBQyxFQUFFRixJQUFJLENBQUMsc0JBQXNCLEVBQUUsOENBQThDLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7SUFDOUgsT0FBT2hDLFNBQVM7RUFDbEIsQ0FBQztFQUNELE1BQU0rSixXQUFXLEdBQUdBLENBQUN4UixLQUFjLEVBQUVpSixNQUFvQixFQUFFUSxLQUFhLEtBQThCO0lBQUEsSUFBQWdJLHFCQUFBLEVBQUFDLFlBQUE7SUFDcEcsTUFBTXRCLEtBQUssR0FBRzlJLE1BQU0sQ0FBQ3RILEtBQUssQ0FBQztJQUFFLElBQUksQ0FBQ29RLEtBQUssRUFBRTtNQUFFN0csSUFBSSxDQUFDLG1CQUFtQixFQUFFLFlBQVksRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztNQUFFLE9BQU9oQyxTQUFTO0lBQUU7SUFDeEgsSUFBSTJJLEtBQUssQ0FBQ3VCLGNBQWMsS0FBSyxZQUFZLEVBQUU7TUFBRSxJQUFJcEosT0FBTyxDQUFDdUgsZ0JBQWdCLEVBQUV2RyxJQUFJLENBQUMsbUJBQW1CLEVBQUUscUJBQXFCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUMsQ0FBQyxLQUFNRSxJQUFJLENBQUNWLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLGNBQWMsRUFBRU8sS0FBSyxDQUFDO01BQUUsT0FBT2hDLFNBQVM7SUFBRTtJQUM5TSxNQUFNbUssS0FBSyxHQUFDeEIsS0FBSyxDQUFDL0YsZUFBZSxJQUFFK0YsS0FBSyxDQUFDL0YsZUFBZSxLQUFHaEMsT0FBTyxDQUFDNkIsU0FBUyxJQUFFa0csS0FBSyxDQUFDL0YsZUFBZSxLQUFHOUIsT0FBTyxDQUFDK0IsZUFBZSxJQUFBbUgscUJBQUEsR0FBQ2xKLE9BQU8sQ0FBQ3NKLGNBQWMsY0FBQUoscUJBQUEsdUJBQXRCQSxxQkFBQSxDQUF5QjdHLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQy9GLGVBQWUsQ0FBQyxDQUFDLEdBQUM1QyxTQUFTO0lBQy9MLElBQUcySSxLQUFLLENBQUMvRixlQUFlLElBQUUrRixLQUFLLENBQUMvRixlQUFlLEtBQUdoQyxPQUFPLENBQUM2QixTQUFTLElBQUVrRyxLQUFLLENBQUMvRixlQUFlLEtBQUc5QixPQUFPLENBQUMrQixlQUFlLElBQUUsQ0FBQ3NILEtBQUssRUFBQztNQUFDckksSUFBSSxDQUFDLG9CQUFvQixFQUFDLDZDQUE2QyxFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO01BQUMsT0FBT2hDLFNBQVM7SUFBQztJQUN4TyxNQUFNcUssU0FBUyxJQUFBSixZQUFBLEdBQUNFLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFM0UsS0FBSyxjQUFBeUUsWUFBQSxjQUFBQSxZQUFBLEdBQUV6RSxLQUFLO01BQUNsTixRQUFRLEdBQUM2UixLQUFLLEdBQUNFLFNBQVMsQ0FBQ2xILE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQzVHLFFBQVEsQ0FBQyxDQUFDLEdBQUNvRyxTQUFTLENBQUNRLEtBQUssQ0FBQzVHLFFBQVEsRUFBRVAsTUFBTSxFQUFFUSxLQUFLLEVBQUUsSUFBSSxDQUFDO0lBQUUsSUFBSSxDQUFDMUosUUFBUSxFQUFDO01BQUN3SixJQUFJLENBQUMsbUJBQW1CLEVBQUMsbUJBQW1CLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7TUFBQyxPQUFPaEMsU0FBUztJQUFDO0lBQ25PLE1BQU1zSyxNQUFtQyxHQUFHO01BQUV2SSxRQUFRLEVBQUV6SixRQUFRO01BQUMsSUFBRzZSLEtBQUssR0FBQztRQUFDdkgsZUFBZSxFQUFDdUgsS0FBSyxDQUFDSTtNQUFlLENBQUMsR0FBQyxDQUFDLENBQUM7SUFBQyxDQUFDO0lBQ3RILEtBQUssTUFBTW5ULEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsRUFBRSxJQUFJdVIsS0FBSyxDQUFDdlIsR0FBRyxDQUFDLElBQUksSUFBSSxFQUFFO01BQy9ELE1BQU1vVCxRQUFRLEdBQUc3QixLQUFLLENBQUN2UixHQUFHLENBQUM7TUFDM0IsSUFBSSxPQUFPb1QsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDMVgsTUFBTSxDQUFDb04sU0FBUyxDQUFDQyxjQUFjLENBQUNDLElBQUksQ0FBQ2lLLFNBQVMsRUFBRUcsUUFBUSxDQUFDLEVBQUU7UUFBRSxJQUFJMUosT0FBTyxDQUFDdUgsZ0JBQWdCLEVBQUV2RyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsb0JBQW9CLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUMsQ0FBQyxLQUFNRSxJQUFJLENBQUNWLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLGFBQWEsRUFBRU8sS0FBSyxDQUFDO1FBQUUsT0FBT2hDLFNBQVM7TUFBRTtNQUNqUXNLLE1BQU0sQ0FBQ2xULEdBQUcsQ0FBQyxHQUFHaVQsU0FBUyxDQUFDRyxRQUFRLENBQUM7SUFDbkM7SUFDQSxJQUFJaEssT0FBTyxDQUFDbUksS0FBSyxDQUFDOEIsS0FBSyxDQUFDLElBQUlqSyxPQUFPLENBQUNtSSxLQUFLLENBQUMrQixHQUFHLENBQUMsSUFBSS9CLEtBQUssQ0FBQzhCLEtBQUssSUFBSSxDQUFDLElBQUk5QixLQUFLLENBQUMrQixHQUFHLElBQUkvQixLQUFLLENBQUM4QixLQUFLLEVBQUU7TUFBRUgsTUFBTSxDQUFDRyxLQUFLLEdBQUc5QixLQUFLLENBQUM4QixLQUFLO01BQUVILE1BQU0sQ0FBQ0ksR0FBRyxHQUFHL0IsS0FBSyxDQUFDK0IsR0FBRztJQUFFO0lBQ3RKLE9BQU9KLE1BQU07RUFDZixDQUFDO0VBQ0QsTUFBTUssU0FBUyxHQUFHQSxDQUFDbkosTUFBb0IsRUFBRVEsS0FBYSxLQUE4QjtJQUNsRixNQUFNMkcsS0FBSyxHQUFHa0IsV0FBVyxDQUFDckksTUFBTSxFQUFFUSxLQUFLLENBQUM7SUFDeEMsSUFBSSxPQUFPMkcsS0FBSyxLQUFLLFFBQVEsRUFBRSxPQUFPLENBQUM7TUFBRWxILEVBQUUsRUFBRSxHQUFHK0QsS0FBSyxDQUFDaEUsTUFBTSxDQUFDQyxFQUFFLENBQUMsSUFBSU8sS0FBSyxFQUFFO01BQUVRLElBQUksRUFBRSxXQUFXO01BQUV2USxJQUFJLEVBQUUwVztJQUFNLENBQUMsQ0FBQztJQUM5RyxJQUFJLENBQUM3SSxLQUFLLENBQUNDLE9BQU8sQ0FBQzRJLEtBQUssQ0FBQyxFQUFFO01BQUUsSUFBSSxDQUFDckksS0FBSyxDQUFDa0IsTUFBTSxDQUFDRSxJQUFJLENBQUNNLEtBQUssQ0FBQyxDQUFDLEVBQUVGLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxpQ0FBaUMsRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztNQUFFLE9BQU9oQyxTQUFTO0lBQUU7SUFDbEssTUFBTXNLLE1BQXFCLEdBQUcsRUFBRTtJQUNoQyxLQUFLLE1BQU03RCxHQUFHLElBQUlrQyxLQUFLLEVBQUU7TUFDdkIsTUFBTWpDLEtBQUssR0FBRzdHLE1BQU0sQ0FBQzRHLEdBQUcsQ0FBQztNQUN6QixJQUFJLENBQUNDLEtBQUssSUFBSSxPQUFPQSxLQUFLLENBQUNqRixFQUFFLEtBQUssUUFBUSxJQUFJLENBQUMrRCxLQUFLLENBQUNrQixLQUFLLENBQUNqRixFQUFFLENBQUMsSUFBSSxDQUFDL0IsV0FBVyxDQUFDMEMsR0FBRyxDQUFDZSxNQUFNLENBQUN1RCxLQUFLLENBQUNsRSxJQUFJLENBQUMsQ0FBQyxJQUFJLE9BQU9rRSxLQUFLLENBQUN6VSxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQUU2UCxJQUFJLENBQUMsbUJBQW1CLEVBQUUsY0FBYyxFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO1FBQUU7TUFBVTtNQUNuTixNQUFNNEksU0FBc0MsR0FBRztRQUFFbkosRUFBRSxFQUFFK0QsS0FBSyxDQUFDa0IsS0FBSyxDQUFDakYsRUFBRSxDQUFDO1FBQUVlLElBQUksRUFBRVcsTUFBTSxDQUFDdUQsS0FBSyxDQUFDbEUsSUFBSSxDQUFDO1FBQUV2USxJQUFJLEVBQUV5VSxLQUFLLENBQUN6VTtNQUFLLENBQUM7TUFDbEgsSUFBSTZOLEtBQUssQ0FBQ0MsT0FBTyxDQUFDMkcsS0FBSyxDQUFDbUUscUJBQXFCLENBQUMsSUFBSW5FLEtBQUssQ0FBQ21FLHFCQUFxQixDQUFDdEssTUFBTSxFQUFFMkIsSUFBSSxDQUFDVixNQUFNLENBQUNDLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRU8sS0FBSyxDQUFDO01BQzlILE1BQU16QixNQUFNLEdBQUcsQ0FBQyxHQUFHbUcsS0FBSyxDQUFDelUsSUFBSSxDQUFDLENBQUNzTyxNQUFNO01BQ3JDLE1BQU11SyxVQUFVLEdBQUlDLEtBQWtCLElBQWN2SyxPQUFPLENBQUN1SyxLQUFLLENBQUNOLEtBQUssQ0FBQyxJQUFJakssT0FBTyxDQUFDdUssS0FBSyxDQUFDTCxHQUFHLENBQUMsSUFBSUssS0FBSyxDQUFDTixLQUFLLElBQUksQ0FBQyxJQUFJTSxLQUFLLENBQUNMLEdBQUcsR0FBR0ssS0FBSyxDQUFDTixLQUFLLElBQUlNLEtBQUssQ0FBQ0wsR0FBRyxJQUFJbkssTUFBTTtNQUNwSyxJQUFJVCxLQUFLLENBQUNDLE9BQU8sQ0FBQzJHLEtBQUssQ0FBQ3NFLElBQUksQ0FBQyxFQUFFO1FBQzdCLE1BQU1BLElBQW1CLEdBQUcsRUFBRTtRQUM5QixLQUFLLE1BQU1DLE9BQU8sSUFBSXZFLEtBQUssQ0FBQ3NFLElBQUksRUFBRTtVQUFFLE1BQU1ELEtBQUssR0FBR2xMLE1BQU0sQ0FBQ29MLE9BQU8sQ0FBQztVQUFFLElBQUksQ0FBQ0YsS0FBSyxJQUFJLENBQUNELFVBQVUsQ0FBQ0MsS0FBSyxDQUFDLElBQUksT0FBT0EsS0FBSyxDQUFDOVksSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUFFNlAsSUFBSSxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO1lBQUU7VUFBVTtVQUFFZ0osSUFBSSxDQUFDL0ksSUFBSSxDQUFDO1lBQUV3SSxLQUFLLEVBQUVNLEtBQUssQ0FBQ04sS0FBZTtZQUFFQyxHQUFHLEVBQUVLLEtBQUssQ0FBQ0wsR0FBYTtZQUFFelksSUFBSSxFQUFFOFksS0FBSyxDQUFDOVk7VUFBSyxDQUFDLENBQUM7UUFBRTtRQUM3UzJZLFNBQVMsQ0FBQ0ksSUFBSSxHQUFHQSxJQUFJO01BQ3ZCO01BQ0EsSUFBSWxMLEtBQUssQ0FBQ0MsT0FBTyxDQUFDMkcsS0FBSyxDQUFDd0UsS0FBSyxDQUFDLEVBQUU7UUFDOUIsTUFBTUEsS0FBb0IsR0FBRyxFQUFFO1FBQy9CLEtBQUssTUFBTUMsT0FBTyxJQUFJekUsS0FBSyxDQUFDd0UsS0FBSyxFQUFFO1VBQUEsSUFBQUUsUUFBQSxFQUFBQyxzQkFBQSxFQUFBQyxhQUFBLEVBQUFDLGdCQUFBLEVBQUFDLGlCQUFBLEVBQUFDLHFCQUFBO1VBQ2pDLE1BQU1WLEtBQUssR0FBR2xMLE1BQU0sQ0FBQ3NMLE9BQU8sQ0FBQztVQUM3QixJQUFJLENBQUNKLEtBQUssSUFBSSxDQUFDRCxVQUFVLENBQUNDLEtBQUssQ0FBQyxFQUFFO1lBQUVqSixJQUFJLENBQUMsbUJBQW1CLEVBQUUsaUJBQWlCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7WUFBRTtVQUFVO1VBQzlHLE1BQU0wSixNQUFNLElBQUFOLFFBQUEsR0FBR3ZMLE1BQU0sQ0FBQ2tMLEtBQUssQ0FBQ1csTUFBTSxDQUFDLGNBQUFOLFFBQUEsY0FBQUEsUUFBQSxHQUFJTCxLQUFLO1VBQzVDLElBQUlXLE1BQU0sQ0FBQ3hCLGNBQWMsS0FBSyxZQUFZLEVBQUU7WUFBRSxJQUFJcEosT0FBTyxDQUFDdUgsZ0JBQWdCLEVBQUV2RyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsdUJBQXVCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUMsQ0FBQyxLQUFNRSxJQUFJLENBQUNWLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLGFBQWEsRUFBRU8sS0FBSyxDQUFDO1lBQUU7VUFBVTtVQUN4TSxNQUFNbUksS0FBSyxHQUFDdUIsTUFBTSxDQUFDOUksZUFBZSxJQUFFOEksTUFBTSxDQUFDOUksZUFBZSxLQUFHaEMsT0FBTyxDQUFDNkIsU0FBUyxJQUFFaUosTUFBTSxDQUFDOUksZUFBZSxLQUFHOUIsT0FBTyxDQUFDK0IsZUFBZSxJQUFBd0ksc0JBQUEsR0FBQ3ZLLE9BQU8sQ0FBQ3NKLGNBQWMsY0FBQWlCLHNCQUFBLHVCQUF0QkEsc0JBQUEsQ0FBeUJsSSxNQUFNLENBQUN1SSxNQUFNLENBQUM5SSxlQUFlLENBQUMsQ0FBQyxHQUFDNUMsU0FBUztZQUFDcUssU0FBUyxJQUFBaUIsYUFBQSxHQUFDbkIsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUUzRSxLQUFLLGNBQUE4RixhQUFBLGNBQUFBLGFBQUEsR0FBRTlGLEtBQUs7VUFDak8sSUFBR2tHLE1BQU0sQ0FBQzlJLGVBQWUsSUFBRThJLE1BQU0sQ0FBQzlJLGVBQWUsS0FBR2hDLE9BQU8sQ0FBQzZCLFNBQVMsSUFBRWlKLE1BQU0sQ0FBQzlJLGVBQWUsS0FBRzlCLE9BQU8sQ0FBQytCLGVBQWUsSUFBRSxDQUFDc0gsS0FBSyxFQUFDO1lBQUNySSxJQUFJLENBQUMsb0JBQW9CLEVBQUMscUNBQXFDLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7WUFBQztVQUFTO1VBQzNOLE1BQU0xSixRQUFRLEdBQUc2UixLQUFLLEdBQUNFLFNBQVMsQ0FBQ2xILE1BQU0sRUFBQW9JLGdCQUFBLEdBQUNHLE1BQU0sQ0FBQ3BULFFBQVEsY0FBQWlULGdCQUFBLGNBQUFBLGdCQUFBLEdBQUVHLE1BQU0sQ0FBQzNKLFFBQVEsQ0FBQyxDQUFDLEdBQUNvRyxTQUFTLEVBQUFxRCxpQkFBQSxHQUFDRSxNQUFNLENBQUNwVCxRQUFRLGNBQUFrVCxpQkFBQSxjQUFBQSxpQkFBQSxHQUFJRSxNQUFNLENBQUMzSixRQUFRLEVBQUVQLE1BQU0sRUFBRSxHQUFHUSxLQUFLLFFBQVEsQ0FBQztVQUNsSixJQUFJLENBQUMxSixRQUFRLEVBQUU7VUFDZixNQUFNcVQsSUFBaUMsR0FBRztZQUFFbEIsS0FBSyxFQUFFTSxLQUFLLENBQUNOLEtBQWU7WUFBRUMsR0FBRyxFQUFFSyxLQUFLLENBQUNMLEdBQWE7WUFBRXBTO1VBQVMsQ0FBQztVQUM5RyxJQUFHb1QsTUFBTSxDQUFDOUksZUFBZSxFQUFDK0ksSUFBSSxDQUFDL0ksZUFBZSxJQUFBNkkscUJBQUEsR0FBQ3RCLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFSSxlQUFlLGNBQUFrQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFFLGdCQUFnQjtVQUFDLElBQUdqTCxPQUFPLENBQUNrTCxNQUFNLENBQUNqQixLQUFLLENBQUMsSUFBRWpLLE9BQU8sQ0FBQ2tMLE1BQU0sQ0FBQ2hCLEdBQUcsQ0FBQyxFQUFDO1lBQUNpQixJQUFJLENBQUNDLFdBQVcsR0FBQ0YsTUFBTSxDQUFDakIsS0FBSztZQUFDa0IsSUFBSSxDQUFDRSxTQUFTLEdBQUNILE1BQU0sQ0FBQ2hCLEdBQUc7VUFBQztVQUMvTCxJQUFJb0IsS0FBSyxHQUFHLElBQUk7VUFDaEIsS0FBSyxNQUFNMVUsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxFQUFFLElBQUlzVSxNQUFNLENBQUN0VSxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUU7WUFDaEUsTUFBTTJVLE1BQU0sR0FBR0wsTUFBTSxDQUFDdFUsR0FBRyxDQUFDO1lBQUUsSUFBSSxPQUFPMlUsTUFBTSxLQUFLLFFBQVEsSUFBSSxDQUFDalosTUFBTSxDQUFDb04sU0FBUyxDQUFDQyxjQUFjLENBQUNDLElBQUksQ0FBQ2lLLFNBQVMsRUFBRTBCLE1BQU0sQ0FBQyxFQUFFO2NBQUUsSUFBSWpMLE9BQU8sQ0FBQ3VILGdCQUFnQixFQUFFdkcsSUFBSSxDQUFDLG1CQUFtQixFQUFFLHFCQUFxQixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDLENBQUMsS0FBTUUsSUFBSSxDQUFDVixNQUFNLENBQUNDLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRU8sS0FBSyxDQUFDO2NBQUU4SixLQUFLLEdBQUcsS0FBSztjQUFFO1lBQU87WUFDalNILElBQUksQ0FBQ3ZVLEdBQUcsQ0FBQyxHQUFHaVQsU0FBUyxDQUFDMEIsTUFBTSxDQUFDO1VBQy9CO1VBQ0EsSUFBSUQsS0FBSyxFQUFFWixLQUFLLENBQUNqSixJQUFJLENBQUMwSixJQUFJLENBQUM7UUFDN0I7UUFDQSxJQUFJVCxLQUFLLENBQUMzSyxNQUFNLEVBQUVxSyxTQUFTLENBQUNNLEtBQUssR0FBR0EsS0FBSztNQUMzQztNQUNBWixNQUFNLENBQUNySSxJQUFJLENBQUMySSxTQUFTLENBQUM7SUFDeEI7SUFDQSxPQUFPTixNQUFNO0VBQ2YsQ0FBQztFQUNELE1BQU0wQixZQUFZLEdBQUNBLENBQUN4SyxNQUFtQixFQUFDUSxLQUFZLEtBQVU7SUFBQyxNQUFNekosS0FBSyxHQUFDdVIsU0FBUyxDQUFDdEksTUFBTSxFQUFDUSxLQUFLLENBQUM7SUFBQyxPQUFPekosS0FBSyxhQUFMQSxLQUFLLGNBQUxBLEtBQUssR0FBRSxFQUFFO0VBQUMsQ0FBQztFQUNySCxNQUFNMFQsVUFBVSxHQUFDQSxDQUFDMVQsS0FBYSxFQUFDaUosTUFBbUIsRUFBQ1EsS0FBWSxLQUF5QjtJQUN2RixNQUFNMkcsS0FBSyxHQUFDOUksTUFBTSxDQUFDdEgsS0FBSyxDQUFDO0lBQUMsSUFBRyxDQUFDb1EsS0FBSyxJQUFFQSxLQUFLLENBQUNsRyxTQUFTLEtBQUc3QixPQUFPLENBQUM2QixTQUFTLEVBQUM7TUFBQ1gsSUFBSSxDQUFDLG1CQUFtQixFQUFDLHNCQUFzQixFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO01BQUM7SUFBTztJQUNsSixNQUFNc0ksTUFBaUMsR0FBQztNQUFDN0gsU0FBUyxFQUFDO0lBQWdCLENBQUM7SUFDcEUsS0FBSSxNQUFNckwsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFDLFdBQVcsQ0FBQyxFQUFDLElBQUd1UixLQUFLLENBQUN2UixHQUFHLENBQUMsSUFBRSxJQUFJLEVBQUM7TUFBQyxNQUFNc1IsTUFBTSxHQUFDUCxTQUFTLENBQUNRLEtBQUssQ0FBQ3ZSLEdBQUcsQ0FBQyxFQUFDb0ssTUFBTSxFQUFDUSxLQUFLLEVBQUMsSUFBSSxDQUFDO01BQUMsSUFBRyxDQUFDMEcsTUFBTSxFQUFDO01BQU80QixNQUFNLENBQUNsVCxHQUFHLENBQUMsR0FBQ3NSLE1BQU07SUFBQztJQUN4SixJQUFHQyxLQUFLLENBQUMzRixnQkFBZ0IsSUFBRSxJQUFJLEVBQUM7TUFBQyxJQUFHMkYsS0FBSyxDQUFDM0YsZ0JBQWdCLEtBQUdwQyxPQUFPLENBQUM2QixTQUFTLElBQUVrRyxLQUFLLENBQUMzRixnQkFBZ0IsS0FBR2xDLE9BQU8sQ0FBQytCLGVBQWUsRUFBQztRQUFDZixJQUFJLENBQUMsb0JBQW9CLEVBQUMscUJBQXFCLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7UUFBQztNQUFPO01BQUNzSSxNQUFNLENBQUN0SCxnQkFBZ0IsR0FBQyxnQkFBZ0I7SUFBQztJQUNwUCxJQUFHMkYsS0FBSyxDQUFDdUQsY0FBYyxJQUFFLElBQUksRUFBQztNQUFDLE1BQU14RCxNQUFNLEdBQUNFLGNBQWMsQ0FBQ0QsS0FBSyxDQUFDdUQsY0FBYyxFQUFDMUssTUFBTSxFQUFDUSxLQUFLLENBQUM7TUFBQyxJQUFHLENBQUMwRyxNQUFNLEVBQUM7TUFBTzRCLE1BQU0sQ0FBQzRCLGNBQWMsR0FBQ3hELE1BQU07SUFBQztJQUFDLE9BQU80QixNQUFNO0VBQzdKLENBQUM7RUFDRCxNQUFNNkIsYUFBYSxHQUFDQSxDQUFDNVQsS0FBYSxFQUFDaUosTUFBbUIsRUFBQ1EsS0FBWSxLQUF5QjtJQUFDLE1BQU0yRyxLQUFLLEdBQUM5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7SUFBQyxJQUFHLENBQUNvUSxLQUFLLEVBQUM7SUFBTyxJQUFJb0MsS0FBaUIsR0FBQyxJQUFJO0lBQUMsSUFBR3BDLEtBQUssQ0FBQ3lELFVBQVUsSUFBRSxJQUFJLEVBQUM7TUFBQyxNQUFNM0YsR0FBRyxHQUFDNUcsTUFBTSxDQUFDOEksS0FBSyxDQUFDeUQsVUFBVSxDQUFDO01BQUMsSUFBRyxDQUFDM0YsR0FBRyxJQUFFLENBQUMsT0FBTyxFQUFDLEtBQUssQ0FBQyxDQUFDbEYsSUFBSSxDQUFDbkssR0FBRyxJQUFFcVAsR0FBRyxDQUFDclAsR0FBRyxDQUFDLEtBQUcsSUFBSSxLQUFHLE9BQU9xUCxHQUFHLENBQUNyUCxHQUFHLENBQUMsS0FBRyxRQUFRLElBQUUsQ0FBQ3dJLElBQUksQ0FBQ3FHLElBQUksQ0FBQzlDLE1BQU0sQ0FBQ3NELEdBQUcsQ0FBQ3JQLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7UUFBQzBLLElBQUksQ0FBQyxtQkFBbUIsRUFBQyxpQkFBaUIsRUFBQ04sTUFBTSxDQUFDQyxFQUFFLEVBQUNPLEtBQUssQ0FBQztRQUFDO01BQU87TUFBQytJLEtBQUssR0FBQztRQUFDTixLQUFLLEVBQUNoRSxHQUFHLENBQUNnRSxLQUFvQjtRQUFDQyxHQUFHLEVBQUNqRSxHQUFHLENBQUNpRTtNQUFrQixDQUFDO0lBQUM7SUFBQyxNQUFNMkIsS0FBSyxHQUFDMUQsS0FBSyxDQUFDdUQsY0FBYyxJQUFFLElBQUksR0FBQyxJQUFJLEdBQUN0RCxjQUFjLENBQUNELEtBQUssQ0FBQ3VELGNBQWMsRUFBQzFLLE1BQU0sRUFBQ1EsS0FBSyxDQUFDO01BQUMvSCxNQUFNLEdBQUMwTyxLQUFLLENBQUMyRCxrQkFBa0IsSUFBRSxJQUFJLEdBQUMsSUFBSSxHQUFDdkMsV0FBVyxDQUFDcEIsS0FBSyxDQUFDMkQsa0JBQWtCLEVBQUM5SyxNQUFNLEVBQUNRLEtBQUssQ0FBQztJQUFDLElBQUdxSyxLQUFLLEtBQUdyTSxTQUFTLElBQUUvRixNQUFNLEtBQUcrRixTQUFTLEVBQUM7SUFBTyxPQUFPO01BQUNvTSxVQUFVLEVBQUNyQixLQUFLO01BQUNtQixjQUFjLEVBQUNHLEtBQUs7TUFBQ0Msa0JBQWtCLEVBQUNyUztJQUFNLENBQUM7RUFBQyxDQUFDO0VBQy93QixNQUFNc1MsY0FBYyxHQUFDQSxDQUFDaFUsS0FBYSxFQUFDaUosTUFBbUIsRUFBQ1EsS0FBWSxLQUF5QjtJQUFDLE1BQU0yRyxLQUFLLEdBQUM5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7SUFBQyxJQUFHLENBQUNvUSxLQUFLLEVBQUM7SUFBTyxNQUFNK0MsTUFBTSxHQUFDTyxVQUFVLENBQUN0RCxLQUFLLENBQUN2TyxXQUFXLEVBQUNvSCxNQUFNLEVBQUNRLEtBQUssQ0FBQztNQUFDOUksUUFBUSxHQUFDaVQsYUFBYSxDQUFDeEQsS0FBSyxDQUFDelAsUUFBUSxFQUFDc0ksTUFBTSxFQUFDUSxLQUFLLENBQUM7SUFBQyxJQUFHLENBQUMwSixNQUFNLElBQUUsQ0FBQ3hTLFFBQVEsSUFBRSxDQUFDNEcsS0FBSyxDQUFDQyxPQUFPLENBQUM0SSxLQUFLLENBQUM2RCxXQUFXLENBQUMsRUFBQztJQUFPLE1BQU1DLFFBQVEsR0FBQzlELEtBQUssQ0FBQzZELFdBQVcsQ0FBQzNQLEdBQUcsQ0FBQzRFLEVBQUUsSUFBRTBHLFNBQVMsQ0FBQzFHLEVBQUUsRUFBQ0QsTUFBTSxFQUFDUSxLQUFLLEVBQUMsSUFBSSxDQUFDLENBQUM7SUFBQyxJQUFHeUssUUFBUSxDQUFDbEwsSUFBSSxDQUFDRSxFQUFFLElBQUUsQ0FBQ0EsRUFBRSxDQUFDLEVBQUM7SUFBTyxNQUFNaEosTUFBTSxHQUFDdVQsWUFBWSxDQUFDeEssTUFBTSxFQUFDLGlCQUFpQixDQUFDO0lBQUMsSUFBRyxDQUFDL0ksTUFBTSxDQUFDNkssSUFBSSxDQUFDLENBQUMsRUFBQztNQUFDeEIsSUFBSSxDQUFDLHNCQUFzQixFQUFDLHNCQUFzQixFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO01BQUM7SUFBTztJQUFDLE9BQU87TUFBQ3ZKLE1BQU07TUFBQzJCLFdBQVcsRUFBQ3NSLE1BQU07TUFBQ3hTLFFBQVE7TUFBQ3NULFdBQVcsRUFBQ0M7SUFBb0IsQ0FBQztFQUFDLENBQUM7RUFDam9CLE1BQU1DLGVBQWUsR0FBQ0EsQ0FBQ25VLEtBQWEsRUFBQ2lKLE1BQW1CLEVBQUNRLEtBQVksRUFBQytHLEtBQUssR0FBQyxDQUFDLEtBQXlCO0lBQUMsSUFBR0EsS0FBSyxHQUFDLEVBQUUsRUFBQztNQUFDakgsSUFBSSxDQUFDLG9CQUFvQixFQUFDLGdCQUFnQixFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO01BQUM7SUFBTztJQUFDLE1BQU0yRyxLQUFLLEdBQUM5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7SUFBQyxJQUFHLENBQUNvUSxLQUFLLEVBQUM7SUFBTyxJQUFHQSxLQUFLLENBQUNPLEVBQUUsS0FBRyxPQUFPLEVBQUM7TUFBQyxNQUFNUixNQUFNLEdBQUNELFVBQVUsQ0FBQ0UsS0FBSyxDQUFDcFEsS0FBSyxFQUFDaUosTUFBTSxDQUFDQyxFQUFFLEVBQUNELE1BQU0sRUFBQ1EsS0FBSyxDQUFDO01BQUMsT0FBTzBHLE1BQU0sR0FBQztRQUFDUSxFQUFFLEVBQUMsT0FBTztRQUFDM1EsS0FBSyxFQUFDbVE7TUFBTSxDQUFDLEdBQUMxSSxTQUFTO0lBQUM7SUFBQyxJQUFHMkksS0FBSyxDQUFDTyxFQUFFLEtBQUcsVUFBVSxFQUFDO01BQUMsTUFBTXpILEVBQUUsR0FBQzBHLFNBQVMsQ0FBQ1EsS0FBSyxDQUFDSixVQUFVLEVBQUMvRyxNQUFNLEVBQUNRLEtBQUssRUFBQyxJQUFJLENBQUM7TUFBQyxPQUFPUCxFQUFFLEdBQUM7UUFBQ3lILEVBQUUsRUFBQyxVQUFVO1FBQUNYLFVBQVUsRUFBQzlHO01BQUUsQ0FBQyxHQUFDekIsU0FBUztJQUFDO0lBQUMsSUFBRyxDQUFDLEtBQUssRUFBQyxVQUFVLEVBQUMsVUFBVSxDQUFDLENBQUNrRCxRQUFRLENBQUNDLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQ08sRUFBRSxDQUFDLENBQUMsRUFBQztNQUFDLE1BQU15RCxJQUFJLEdBQUNELGVBQWUsQ0FBQy9ELEtBQUssQ0FBQ2dFLElBQUksRUFBQ25MLE1BQU0sRUFBQ1EsS0FBSyxFQUFDK0csS0FBSyxHQUFDLENBQUMsQ0FBQztRQUFDNkQsS0FBSyxHQUFDRixlQUFlLENBQUMvRCxLQUFLLENBQUNpRSxLQUFLLEVBQUNwTCxNQUFNLEVBQUNRLEtBQUssRUFBQytHLEtBQUssR0FBQyxDQUFDLENBQUM7TUFBQyxPQUFPNEQsSUFBSSxJQUFFQyxLQUFLLEdBQUM7UUFBQzFELEVBQUUsRUFBQy9GLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQ08sRUFBRSxDQUFDO1FBQUN5RCxJQUFJO1FBQUNDO01BQUssQ0FBQyxHQUFDNU0sU0FBUztJQUFDO0lBQUMsSUFBRzJJLEtBQUssQ0FBQ08sRUFBRSxLQUFHLElBQUksRUFBQztNQUFDLE1BQU16VyxTQUFTLEdBQUNtVyxjQUFjLENBQUNELEtBQUssQ0FBQ2xXLFNBQVMsRUFBQytPLE1BQU0sRUFBQ1EsS0FBSyxDQUFDO1FBQUM2SyxHQUFHLEdBQUNILGVBQWUsQ0FBQy9ELEtBQUssQ0FBQ21FLElBQUksRUFBQ3RMLE1BQU0sRUFBQ1EsS0FBSyxFQUFDK0csS0FBSyxHQUFDLENBQUMsQ0FBQztRQUFDZ0UsRUFBRSxHQUFDTCxlQUFlLENBQUMvRCxLQUFLLENBQUNxRSxJQUFJLEVBQUN4TCxNQUFNLEVBQUNRLEtBQUssRUFBQytHLEtBQUssR0FBQyxDQUFDLENBQUM7TUFBQyxPQUFPdFcsU0FBUyxJQUFFb2EsR0FBRyxJQUFFRSxFQUFFLEdBQUM7UUFBQzdELEVBQUUsRUFBQyxJQUFJO1FBQUN6VyxTQUFTO1FBQUNxYSxJQUFJLEVBQUNELEdBQUc7UUFBQ0csSUFBSSxFQUFDRDtNQUFFLENBQUMsR0FBQy9NLFNBQVM7SUFBQztJQUFDLE9BQU80SSxjQUFjLENBQUNELEtBQUssRUFBQ25ILE1BQU0sRUFBQ1EsS0FBSyxDQUFDO0VBQUMsQ0FBQztFQUM1Z0MsTUFBTWlMLFNBQVMsR0FBR0EsQ0FBQ3pMLE1BQW9CLEVBQUVRLEtBQWEsRUFBRThFLElBQWUsS0FBOEI7SUFDbkcsTUFBTXZPLEtBQUssR0FBR2lKLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDTSxLQUFLLENBQUM7SUFDaEMsSUFBSThFLElBQUksQ0FBQzVVLElBQUksS0FBSyxNQUFNLEVBQUUsT0FBTzRYLFNBQVMsQ0FBQ3RJLE1BQU0sRUFBRVEsS0FBSyxDQUFDO0lBQ3pELElBQUk4RSxJQUFJLENBQUM1VSxJQUFJLEtBQUssTUFBTSxFQUFFLE9BQU95WSxTQUFTLENBQUNuSixNQUFNLEVBQUVRLEtBQUssQ0FBQztJQUN6RCxJQUFJekosS0FBSyxJQUFJLElBQUksRUFBRSxPQUFPeUgsU0FBUztJQUNuQyxRQUFROEcsSUFBSSxDQUFDNVUsSUFBSTtNQUNmLEtBQUssZ0JBQWdCO1FBQUM7VUFBQyxJQUFHNE4sS0FBSyxDQUFDQyxPQUFPLENBQUN4SCxLQUFLLENBQUMsSUFBRSxDQUFDQSxLQUFLLENBQUNnSSxNQUFNLEVBQUMsT0FBTyxFQUFFO1VBQUMsSUFBSTJNLFFBQWdCO1VBQUMsSUFBRztZQUFDQSxRQUFRLEdBQUNDLElBQUksQ0FBQ0MsS0FBSyxDQUFDakssTUFBTSxDQUFDMEcsV0FBVyxDQUFDckksTUFBTSxFQUFDUSxLQUFLLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxPQUFLLENBQUM7VUFBQyxJQUFHbEMsS0FBSyxDQUFDQyxPQUFPLENBQUNtTixRQUFRLENBQUMsSUFBRUEsUUFBUSxDQUFDN0QsS0FBSyxDQUFDcFYsSUFBSSxJQUFFLE9BQU9BLElBQUksS0FBRyxRQUFRLENBQUMsRUFBQyxPQUFPaVosUUFBUTtVQUFDcEwsSUFBSSxDQUFDLHNCQUFzQixFQUFDLDRCQUE0QixFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO1VBQUM7UUFBTztNQUMxVSxLQUFLLFdBQVc7UUFBQztVQUFDLE1BQU0yRyxLQUFLLEdBQUM5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7VUFBQyxJQUFHb1EsS0FBSyxJQUFFLE9BQU9BLEtBQUssQ0FBQzBFLElBQUksS0FBRyxRQUFRLElBQUUscUJBQXFCLENBQUNwSCxJQUFJLENBQUMwQyxLQUFLLENBQUMwRSxJQUFJLENBQUMsSUFBRSxPQUFPMUUsS0FBSyxDQUFDMkUsUUFBUSxLQUFHLFFBQVEsRUFBQyxPQUFPO1lBQUNELElBQUksRUFBQzFFLEtBQUssQ0FBQzBFLElBQUk7WUFBQ0MsUUFBUSxFQUFDM0UsS0FBSyxDQUFDMkU7VUFBUSxDQUFDO1VBQUM7UUFBTTtNQUNwTixLQUFLLFVBQVU7UUFBQztVQUFDLE1BQU0zRSxLQUFLLEdBQUM5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7VUFBQyxJQUFJZ1YsV0FBbUI7VUFBQyxJQUFHO1lBQUNBLFdBQVcsR0FBQ0osSUFBSSxDQUFDQyxLQUFLLENBQUNqSyxNQUFNLENBQUMwRyxXQUFXLENBQUNySSxNQUFNLEVBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxPQUFLLENBQUM7VUFBQyxNQUFNaEgsTUFBTSxHQUFDcVAsV0FBVyxDQUFDckksTUFBTSxFQUFDLGdCQUFnQixDQUFDO1lBQUNnTSxJQUFJLEdBQUMzRCxXQUFXLENBQUNySSxNQUFNLEVBQUMsY0FBYyxDQUFDO1VBQUMsSUFBRyxDQUFDbUgsS0FBSyxJQUFFLENBQUM3SSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3dOLFdBQVcsQ0FBQyxJQUFFQSxXQUFXLENBQUNoTSxJQUFJLENBQUN0TixJQUFJLElBQUUsT0FBT0EsSUFBSSxLQUFHLFFBQVEsQ0FBQyxJQUFFLE9BQU91RyxNQUFNLEtBQUcsUUFBUSxJQUFFLE9BQU9nVCxJQUFJLEtBQUcsUUFBUSxFQUFDO1lBQUMxTCxJQUFJLENBQUMsc0JBQXNCLEVBQUMsdUJBQXVCLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7WUFBQztVQUFPO1VBQUMsTUFBTXBLLEtBQUssR0FBQ3FVLFVBQVUsQ0FBQ3RELEtBQUssQ0FBQy9RLEtBQUssRUFBQzRKLE1BQU0sRUFBQ1EsS0FBSyxDQUFDO1VBQUMsSUFBRyxDQUFDcEssS0FBSyxFQUFDO1VBQU8sT0FBTztZQUFDNFYsSUFBSTtZQUFDRCxXQUFXLEVBQUNBLFdBQXVCO1lBQUMvUyxNQUFNO1lBQUNpVCxZQUFZLEVBQUNoTixNQUFNLENBQUNrSSxLQUFLLENBQUM4RSxZQUFZLENBQUM7WUFBQzdWLEtBQUs7WUFBQyxJQUFHK1EsS0FBSyxDQUFDcFEsS0FBSyxJQUFFLElBQUksR0FBQztjQUFDQSxLQUFLLEVBQUNrSSxNQUFNLENBQUNrSSxLQUFLLENBQUNwUSxLQUFLO1lBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztZQUFDLElBQUdvUSxLQUFLLENBQUNvQyxLQUFLLEdBQUM7Y0FBQ0EsS0FBSyxFQUFDcEMsS0FBSyxDQUFDb0M7WUFBb0IsQ0FBQyxHQUFDLENBQUMsQ0FBQztZQUFDLElBQUdwQyxLQUFLLENBQUMrRSxLQUFLLElBQUUsSUFBSSxHQUFDO2NBQUNBLEtBQUssRUFBQ2pOLE1BQU0sQ0FBQ2tJLEtBQUssQ0FBQytFLEtBQUs7WUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO1VBQUEsQ0FBQztRQUFDO01BQ2h4QixLQUFLLFlBQVk7UUFBQztVQUFDLElBQUcsQ0FBQzVOLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLEVBQUM7VUFBTSxNQUFNMlUsUUFBUSxHQUFDckQsV0FBVyxDQUFDckksTUFBTSxFQUFDLFlBQVksQ0FBQztVQUFDLElBQUkyQyxLQUFhO1VBQUMsSUFBRztZQUFDQSxLQUFLLEdBQUMsT0FBTytJLFFBQVEsS0FBRyxRQUFRLEdBQUNDLElBQUksQ0FBQ0MsS0FBSyxDQUFDRixRQUFRLENBQUMsR0FBQ2xOLFNBQVM7VUFBQyxDQUFDLE9BQUssQ0FBQztVQUFDLElBQUd6SCxLQUFLLENBQUNnSSxNQUFNLElBQUUsQ0FBQ1YsTUFBTSxDQUFDc0UsS0FBSyxDQUFDLEVBQUM7WUFBQ3JDLElBQUksQ0FBQyxzQkFBc0IsRUFBQyxvQ0FBb0MsRUFBQ04sTUFBTSxDQUFDQyxFQUFFLEVBQUNPLEtBQUssQ0FBQztZQUFDO1VBQU87VUFBQyxNQUFNc0ksTUFBb0IsR0FBQyxFQUFFO1VBQUMsS0FBSSxNQUFNN0QsR0FBRyxJQUFJbE8sS0FBSyxFQUFDO1lBQUMsTUFBTW9RLEtBQUssR0FBQzlJLE1BQU0sQ0FBQzRHLEdBQUcsQ0FBQztjQUFDclAsR0FBRyxHQUFDdVIsS0FBSyxJQUFFMUksR0FBRyxDQUFDSixNQUFNLENBQUNzRSxLQUFLLENBQUMsRUFBQ2hCLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQ3ZSLEdBQUcsQ0FBQyxDQUFDO1lBQUMsSUFBRyxDQUFDdVIsS0FBSyxJQUFFLE9BQU92UixHQUFHLEtBQUcsUUFBUSxJQUFFLENBQUMseUJBQXlCLENBQUM2TyxJQUFJLENBQUM3TyxHQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsU0FBUyxFQUFDLFNBQVMsRUFBQyxNQUFNLENBQUMsQ0FBQzhMLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDd0YsS0FBSyxDQUFDelcsSUFBSSxDQUFDLENBQUMsRUFBQztjQUFDNFAsSUFBSSxDQUFDLHNCQUFzQixFQUFDLG9CQUFvQixFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO2NBQUM7WUFBTztZQUFDLE1BQU1uSyxPQUFPLEdBQUM4USxLQUFLLENBQUNnRixPQUFPLElBQUUsSUFBSSxHQUFDM04sU0FBUyxHQUFDeUksVUFBVSxDQUFDRSxLQUFLLENBQUNnRixPQUFPLEVBQUNuTSxNQUFNLENBQUNDLEVBQUUsRUFBQ0QsTUFBTSxFQUFDUSxLQUFLLENBQUM7WUFBQyxJQUFHMkcsS0FBSyxDQUFDZ0YsT0FBTyxJQUFFLElBQUksSUFBRSxDQUFDOVYsT0FBTyxFQUFDO1lBQU95UyxNQUFNLENBQUNySSxJQUFJLENBQUM7Y0FBQzdLLEdBQUc7Y0FBQ2xGLElBQUksRUFBQ2lSLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQ3pXLElBQUksQ0FBQztjQUFDLElBQUcyRixPQUFPLEdBQUM7Z0JBQUM4VixPQUFPLEVBQUM5VjtjQUFPLENBQUMsR0FBQyxDQUFDLENBQUM7WUFBQSxDQUFDLENBQUM7VUFBQztVQUFDLE9BQU95UyxNQUFNO1FBQUM7TUFDdDJCLEtBQUssWUFBWTtRQUFDLE9BQU9vQyxlQUFlLENBQUNuVSxLQUFLLEVBQUNpSixNQUFNLEVBQUNRLEtBQUssQ0FBQztNQUM1RCxLQUFLLE9BQU87UUFBQyxPQUFPaUssVUFBVSxDQUFDMVQsS0FBSyxFQUFDaUosTUFBTSxFQUFDUSxLQUFLLENBQUM7TUFDbEQsS0FBSyxVQUFVO1FBQUMsT0FBT21LLGFBQWEsQ0FBQzVULEtBQUssRUFBQ2lKLE1BQU0sRUFBQ1EsS0FBSyxDQUFDO01BQ3hELEtBQUssV0FBVztRQUFDLE9BQU91SyxjQUFjLENBQUNoVSxLQUFLLEVBQUNpSixNQUFNLEVBQUNRLEtBQUssQ0FBQztNQUMxRCxLQUFLLFlBQVk7UUFBQztVQUFDLElBQUcsQ0FBQ2xDLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLEVBQUM7VUFBTSxNQUFNbVEsTUFBTSxHQUFDblEsS0FBSyxDQUFDc0UsR0FBRyxDQUFDNUksSUFBSSxJQUFFc1ksY0FBYyxDQUFDdFksSUFBSSxFQUFDdU4sTUFBTSxFQUFDUSxLQUFLLENBQUMsQ0FBQztVQUFDLE9BQU8wRyxNQUFNLENBQUNXLEtBQUssQ0FBQ3BWLElBQUksSUFBRUEsSUFBSSxLQUFHK0wsU0FBUyxDQUFDLEdBQUMwSSxNQUFNLEdBQWtCMUksU0FBUztRQUFDO01BQ2hNLEtBQUssUUFBUTtRQUFDO1VBQUMsSUFBRyxDQUFDRixLQUFLLENBQUNDLE9BQU8sQ0FBQ3hILEtBQUssQ0FBQyxFQUFDO1VBQU0sTUFBTStSLE1BQW9CLEdBQUMsRUFBRTtVQUFDLEtBQUksTUFBTTdELEdBQUcsSUFBSWxPLEtBQUssRUFBQztZQUFDLE1BQU1vUSxLQUFLLEdBQUM5SSxNQUFNLENBQUM0RyxHQUFHLENBQUM7WUFBQyxJQUFHLENBQUNrQyxLQUFLLElBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBQyxhQUFhLEVBQUMsU0FBUyxFQUFDLFVBQVUsRUFBQyxZQUFZLENBQUMsQ0FBQ3pGLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDd0YsS0FBSyxDQUFDaUYsRUFBRSxDQUFDLENBQUMsRUFBQztZQUFNLE1BQU1sRixNQUFNLEdBQUNELFVBQVUsQ0FBQ0UsS0FBSyxDQUFDcFEsS0FBSyxFQUFDaUosTUFBTSxDQUFDQyxFQUFFLEVBQUNELE1BQU0sRUFBQ1EsS0FBSyxDQUFDO1lBQUMsSUFBRyxDQUFDMEcsTUFBTSxFQUFDO1lBQU80QixNQUFNLENBQUNySSxJQUFJLENBQUM7Y0FBQzJMLEVBQUUsRUFBQ3pLLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQ2lGLEVBQUUsQ0FBQztjQUFDclYsS0FBSyxFQUFDbVEsTUFBTTtjQUFDalEsTUFBTSxFQUFDdVQsWUFBWSxDQUFDeEssTUFBTSxFQUFDLGFBQWE7WUFBQyxDQUFDLENBQUM7VUFBQztVQUFDLElBQUc4SSxNQUFNLENBQUMvSixNQUFNLEtBQUdoSSxLQUFLLENBQUNnSSxNQUFNLEVBQUM7VUFBTSxPQUFPK0osTUFBTTtRQUFDO01BQ3BjLEtBQUssWUFBWTtRQUFDO1VBQUMsSUFBRyxDQUFDeEssS0FBSyxDQUFDQyxPQUFPLENBQUN4SCxLQUFLLENBQUMsRUFBQztVQUFNLE1BQU0rUixNQUFvQixHQUFDLEVBQUU7VUFBQyxLQUFJLE1BQU03RCxHQUFHLElBQUlsTyxLQUFLLEVBQUM7WUFBQyxNQUFNb1EsS0FBSyxHQUFDOUksTUFBTSxDQUFDNEcsR0FBRyxDQUFDO1lBQUMsSUFBRyxDQUFDa0MsS0FBSyxFQUFDO1lBQU8sTUFBTUosVUFBVSxHQUFDSixTQUFTLENBQUNRLEtBQUssQ0FBQ0osVUFBVSxFQUFDL0csTUFBTSxFQUFDUSxLQUFLLEVBQUMsSUFBSSxDQUFDO2NBQUM2TCxPQUFPLEdBQUNwRixVQUFVLENBQUNFLEtBQUssQ0FBQ3BRLEtBQUssRUFBQ2lKLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDRCxNQUFNLEVBQUNRLEtBQUssQ0FBQztjQUFDOEwsS0FBSyxHQUFDckYsVUFBVSxDQUFDRSxLQUFLLENBQUNvRixVQUFVLEVBQUM1SyxNQUFNLENBQUN3RixLQUFLLENBQUNKLFVBQVUsQ0FBQyxFQUFDL0csTUFBTSxFQUFDUSxLQUFLLENBQUM7Y0FBQ3BJLFVBQVUsR0FBQytPLEtBQUssQ0FBQy9PLFVBQVUsSUFBRSxJQUFJLEdBQUMsRUFBRSxHQUFDa0csS0FBSyxDQUFDQyxPQUFPLENBQUM0SSxLQUFLLENBQUMvTyxVQUFVLENBQUMsR0FBQytPLEtBQUssQ0FBQy9PLFVBQVUsQ0FBQ2lELEdBQUcsQ0FBQzVJLElBQUksSUFBRXNZLGNBQWMsQ0FBQ3RZLElBQUksRUFBQ3VOLE1BQU0sRUFBQ1EsS0FBSyxDQUFDLENBQUMsR0FBQ2hDLFNBQVM7WUFBQyxJQUFHLENBQUN1SSxVQUFVLElBQUUsQ0FBQ3NGLE9BQU8sSUFBRSxDQUFDQyxLQUFLLElBQUUsQ0FBQ2xVLFVBQVUsSUFBRUEsVUFBVSxDQUFDMkgsSUFBSSxDQUFDdE4sSUFBSSxJQUFFLENBQUNBLElBQUksQ0FBQyxFQUFDO1lBQU8sTUFBTXdFLE1BQU0sR0FBQ3VULFlBQVksQ0FBQ3hLLE1BQU0sRUFBQyxpQkFBaUIsQ0FBQztZQUFDLElBQUcsQ0FBQy9JLE1BQU0sQ0FBQzZLLElBQUksQ0FBQyxDQUFDLEVBQUM7Y0FBQ3hCLElBQUksQ0FBQyxzQkFBc0IsRUFBQyxzQkFBc0IsRUFBQ04sTUFBTSxDQUFDQyxFQUFFLEVBQUNPLEtBQUssQ0FBQztjQUFDO1lBQU87WUFBQ3NJLE1BQU0sQ0FBQ3JJLElBQUksQ0FBQztjQUFDc0csVUFBVTtjQUFDaFEsS0FBSyxFQUFDc1YsT0FBTztjQUFDRSxVQUFVLEVBQUNELEtBQUs7Y0FBQ3JWLE1BQU07Y0FBQ21CLFVBQVUsRUFBQ0E7WUFBMkIsQ0FBQyxDQUFDO1VBQUM7VUFBQyxPQUFPMFEsTUFBTTtRQUFDO01BQ3p6QixLQUFLLGNBQWM7UUFBQztVQUFDLE1BQU0zQixLQUFLLEdBQUM5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7VUFBQyxJQUFHLENBQUNvUSxLQUFLLEVBQUM7VUFBTSxNQUFNMkIsTUFBaUMsR0FBQyxDQUFDLENBQUM7VUFBQyxLQUFJLE1BQU0sQ0FBQ2xULEdBQUcsRUFBQzRXLEdBQUcsQ0FBQyxJQUFJbGIsTUFBTSxDQUFDaVUsT0FBTyxDQUFDNEIsS0FBSyxDQUFDLEVBQUM7WUFBQyxNQUFNbEgsRUFBRSxHQUFDMEcsU0FBUyxDQUFDL1EsR0FBRyxFQUFDb0ssTUFBTSxFQUFDUSxLQUFLLEVBQUMsSUFBSSxDQUFDO1lBQUMsSUFBRyxDQUFDUCxFQUFFLElBQUUsQ0FBQzNCLEtBQUssQ0FBQ0MsT0FBTyxDQUFDaU8sR0FBRyxDQUFDLEVBQUM7WUFBTyxNQUFNdEYsTUFBTSxHQUFDc0YsR0FBRyxDQUFDblIsR0FBRyxDQUFDNUksSUFBSSxJQUFFa1UsU0FBUyxDQUFDbFUsSUFBSSxFQUFDdU4sTUFBTSxFQUFDUSxLQUFLLEVBQUMsSUFBSSxDQUFDLENBQUM7WUFBQyxJQUFHMEcsTUFBTSxDQUFDbkgsSUFBSSxDQUFDdE4sSUFBSSxJQUFFLENBQUNBLElBQUksQ0FBQyxFQUFDO1lBQU9xVyxNQUFNLENBQUM3SSxFQUFFLENBQUMsR0FBQ2lILE1BQWtCO1VBQUM7VUFBQyxPQUFPNEIsTUFBTTtRQUFDO01BQ25YLEtBQUssUUFBUTtRQUFDO1VBQUMsTUFBTTRDLFFBQVEsR0FBQ3JELFdBQVcsQ0FBQ3JJLE1BQU0sRUFBQ1EsS0FBSyxDQUFDO1VBQUMsSUFBSTJHLEtBQWE7VUFBQyxJQUFHO1lBQUNBLEtBQUssR0FBQyxPQUFPdUUsUUFBUSxLQUFHLFFBQVEsR0FBQ0MsSUFBSSxDQUFDQyxLQUFLLENBQUNGLFFBQVEsQ0FBQyxHQUFDbE4sU0FBUztVQUFDLENBQUMsT0FBSztZQUFDO1VBQU07VUFBQyxNQUFNM0UsTUFBTSxHQUFDd0UsTUFBTSxDQUFDOEksS0FBSyxDQUFDO1VBQUMsSUFBRyxDQUFDdE4sTUFBTSxFQUFDO1lBQUN5RyxJQUFJLENBQUMsc0JBQXNCLEVBQUMsMkJBQTJCLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7WUFBQztVQUFPO1VBQUMsTUFBTXNJLE1BQWlDLEdBQUMsQ0FBQyxDQUFDO1VBQUMsS0FBSSxNQUFNLENBQUNsVCxHQUFHLEVBQUNuRCxJQUFJLENBQUMsSUFBSW5CLE1BQU0sQ0FBQ2lVLE9BQU8sQ0FBQzFMLE1BQU0sQ0FBQyxFQUFDO1lBQUMsSUFBRyxDQUFDLENBQUMsTUFBTSxFQUFDLE9BQU8sRUFBQyxVQUFVLEVBQUMsWUFBWSxDQUFDLENBQUM2SCxRQUFRLENBQUM5TCxHQUFHLENBQUMsSUFBRSxFQUFFLE9BQU9uRCxJQUFJLEtBQUcsUUFBUSxJQUFFLE9BQU9BLElBQUksS0FBRyxRQUFRLElBQUV3TSxNQUFNLENBQUN3TixRQUFRLENBQUNoYSxJQUFJLENBQUMsSUFBRUEsSUFBSSxJQUFFLENBQUMsQ0FBQyxFQUFDO2NBQUM2TixJQUFJLENBQUMsb0JBQW9CLEVBQUMsb0JBQW9CLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7Y0FBQztZQUFPO1lBQUNzSSxNQUFNLENBQUNsVCxHQUFHLENBQUMsR0FBQ25ELElBQUk7VUFBQztVQUFDLE9BQU9xVyxNQUFNO1FBQUM7TUFDdG1CLEtBQUssS0FBSztRQUFFLE9BQU9uQyxTQUFTLENBQUM1UCxLQUFLLEVBQUVpSixNQUFNLEVBQUVRLEtBQUssRUFBRXpDLGFBQWEsQ0FBQzZDLEdBQUcsQ0FBQ0osS0FBSyxDQUFDLENBQUM7TUFDNUUsS0FBSyxNQUFNO1FBQUU7VUFDWCxJQUFJLENBQUNsQyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3hILEtBQUssQ0FBQyxFQUFFO1VBQzNCLE9BQU9BLEtBQUssQ0FBQ3NFLEdBQUcsQ0FBQzRFLEVBQUUsSUFBSTBHLFNBQVMsQ0FBQzFHLEVBQUUsRUFBRUQsTUFBTSxFQUFFUSxLQUFLLEVBQUVsQixPQUFPLENBQUN1SCxnQkFBZ0IsSUFBSTlJLGFBQWEsQ0FBQzZDLEdBQUcsQ0FBQ0osS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDdUMsTUFBTSxDQUFFOUMsRUFBRSxJQUFtQkEsRUFBRSxLQUFLekIsU0FBUyxDQUFDO1FBQzNKO01BQ0EsS0FBSyxRQUFRO1FBQUUsSUFBSSxPQUFPekgsS0FBSyxLQUFLLFFBQVEsSUFBSWtJLE1BQU0sQ0FBQ3dOLFFBQVEsQ0FBQzFWLEtBQUssQ0FBQyxFQUFFLE9BQU9BLEtBQUs7UUFBRTtNQUN0RixLQUFLLFNBQVM7UUFBRSxJQUFJLE9BQU9BLEtBQUssS0FBSyxTQUFTLEVBQUUsT0FBT0EsS0FBSztRQUFFO01BQzlELEtBQUssTUFBTTtRQUFFLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSXVPLElBQUksQ0FBQ2xVLE1BQU0sQ0FBQ3NRLFFBQVEsQ0FBQzNLLEtBQUssQ0FBQyxFQUFFLE9BQU9BLEtBQUs7UUFBRTtNQUN6RixLQUFLLFdBQVc7UUFBRSxPQUFPcVEsY0FBYyxDQUFDclEsS0FBSyxFQUFFaUosTUFBTSxFQUFFUSxLQUFLLENBQUM7TUFDN0QsS0FBSyxPQUFPO1FBQUUsT0FBT3lHLFVBQVUsQ0FBQ2xRLEtBQUssRUFBRWlKLE1BQU0sQ0FBQ2dCLElBQUksS0FBSyxRQUFRLElBQUksT0FBT2hCLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDcEosUUFBUSxLQUFLLFFBQVEsR0FBR2tKLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDcEosUUFBUSxHQUFHa0osTUFBTSxDQUFDQyxFQUFFLEVBQUVELE1BQU0sRUFBRVEsS0FBSyxDQUFDO01BQzlKLEtBQUssUUFBUTtRQUFFO1VBQ2IsSUFBSSxDQUFDbEMsS0FBSyxDQUFDQyxPQUFPLENBQUN4SCxLQUFLLENBQUMsRUFBRTtVQUMzQixNQUFNK1IsTUFBTSxHQUFHL1IsS0FBSyxDQUFDc0UsR0FBRyxDQUFDNUksSUFBSSxJQUFJd1UsVUFBVSxDQUFDeFUsSUFBSSxFQUFFdU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVELE1BQU0sRUFBRVEsS0FBSyxDQUFDLENBQUM7VUFDNUUsT0FBT3NJLE1BQU0sQ0FBQ2pCLEtBQUssQ0FBQ3BWLElBQUksSUFBSUEsSUFBSSxLQUFLK0wsU0FBUyxDQUFDLEdBQUdzSyxNQUFNLEdBQW9CdEssU0FBUztRQUN2RjtNQUNBLEtBQUssUUFBUTtRQUFFLElBQUksT0FBT3pILEtBQUssS0FBSyxRQUFRLElBQUksMkRBQTJELENBQUMwTixJQUFJLENBQUMxTixLQUFLLENBQUMsRUFBRSxPQUFPQSxLQUFLO1FBQUU7TUFDdkksS0FBSyxTQUFTO1FBQUU7VUFDZCxNQUFNb1EsS0FBSyxHQUFHOUksTUFBTSxDQUFDdEgsS0FBSyxDQUFDO1VBQUUsSUFBSSxDQUFDb1EsS0FBSyxFQUFFO1VBQ3pDLE1BQU0yQixNQUFtQyxHQUFHLENBQUMsQ0FBQztVQUM5QyxJQUFJM0IsS0FBSyxDQUFDdUYsR0FBRyxLQUFLbE8sU0FBUyxJQUFJMkksS0FBSyxDQUFDd0YsR0FBRyxLQUFLbk8sU0FBUyxFQUFFO1lBQUUsSUFBSSxDQUFDUSxPQUFPLENBQUNtSSxLQUFLLENBQUN1RixHQUFHLENBQUMsSUFBSSxDQUFDMU4sT0FBTyxDQUFDbUksS0FBSyxDQUFDd0YsR0FBRyxDQUFDLElBQUl4RixLQUFLLENBQUN1RixHQUFHLEdBQUd2RixLQUFLLENBQUN3RixHQUFHLEVBQUU7WUFBTzdELE1BQU0sQ0FBQzRELEdBQUcsR0FBR3ZGLEtBQUssQ0FBQ3VGLEdBQUc7WUFBRTVELE1BQU0sQ0FBQzZELEdBQUcsR0FBR3hGLEtBQUssQ0FBQ3dGLEdBQUc7VUFBRTtVQUMxTCxJQUFJck8sS0FBSyxDQUFDQyxPQUFPLENBQUM0SSxLQUFLLENBQUMvVixNQUFNLENBQUMsRUFBRTtZQUMvQixNQUFNQSxNQUFNLEdBQUcrVixLQUFLLENBQUMvVixNQUFNLENBQUNpSyxHQUFHLENBQUM1SSxJQUFJLElBQUksT0FBT0EsSUFBSSxLQUFLLFFBQVEsR0FBR3FVLE9BQU8sQ0FBQ3JVLElBQUksRUFBRXVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFRCxNQUFNLEVBQUVRLEtBQUssQ0FBQyxHQUFHLE9BQU8vTixJQUFJLEtBQUssU0FBUyxJQUFJdU0sT0FBTyxDQUFDdk0sSUFBSSxDQUFDLEdBQUdBLElBQUksR0FBRytMLFNBQVMsQ0FBQztZQUMzSyxJQUFJcE4sTUFBTSxDQUFDMk8sSUFBSSxDQUFDdE4sSUFBSSxJQUFJQSxJQUFJLEtBQUsrTCxTQUFTLENBQUMsRUFBRTtZQUM3QyxJQUFJLElBQUlSLEdBQUcsQ0FBQzVNLE1BQU0sQ0FBQyxDQUFDNlEsSUFBSSxLQUFLN1EsTUFBTSxDQUFDMk4sTUFBTSxFQUFFO2NBQUV1QixJQUFJLENBQUMsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7Y0FBRSxPQUFPaEMsU0FBUztZQUFFO1lBQy9Ic0ssTUFBTSxDQUFDMVgsTUFBTSxHQUFHQSxNQUF1QjtVQUN6QztVQUNBLE9BQU8wWCxNQUFNO1FBQ2Y7TUFDQSxLQUFLLE1BQU07UUFBRTtVQUNYLE1BQU0zQixLQUFLLEdBQUc5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7VUFBRSxJQUFJLENBQUNvUSxLQUFLLEVBQUU7VUFDekMsTUFBTTJCLE1BQW1DLEdBQUc7WUFBRTlNLElBQUksRUFBRTJGLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQ25MLElBQUk7VUFBRSxDQUFDO1VBQ3hFLElBQUksQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLFdBQVcsQ0FBQyxDQUFDMEYsUUFBUSxDQUFDQyxNQUFNLENBQUN3RixLQUFLLENBQUNuTCxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQUEsSUFBQTRRLFVBQUE7WUFDckUsTUFBTXpILE1BQU0sR0FBR2dDLEtBQUssQ0FBQ25MLElBQUksS0FBSyxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBR21MLEtBQUssQ0FBQ25MLElBQUksS0FBSyxVQUFVLEdBQUcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDO1lBQ3hILEtBQUssTUFBTXBHLEdBQUcsSUFBSXVQLE1BQU0sRUFBRTtjQUFFLElBQUksT0FBT2dDLEtBQUssQ0FBQ3ZSLEdBQUcsQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDd0ksSUFBSSxDQUFDcUcsSUFBSSxDQUFDMEMsS0FBSyxDQUFDdlIsR0FBRyxDQUFDLENBQUMsRUFBRTtnQkFBRTBLLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxpQkFBaUIsRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztnQkFBRSxPQUFPaEMsU0FBUztjQUFFO2NBQUVzSyxNQUFNLENBQUNsVCxHQUFHLENBQUMsR0FBR3VSLEtBQUssQ0FBQ3ZSLEdBQUcsQ0FBQztZQUFFO1lBQzFNLE1BQU1pWCxVQUFVLEdBQUc5RyxnQkFBZ0IsQ0FBQ29CLEtBQUssQ0FBQzBGLFVBQVUsRUFBRTdNLE1BQU0sRUFBRVEsS0FBSyxDQUFDO1lBQUUsSUFBSSxDQUFDcU0sVUFBVSxFQUFFLE9BQU9yTyxTQUFTO1lBQ3ZHc0ssTUFBTSxDQUFDK0QsVUFBVSxHQUFHQSxVQUFVO1lBQzlCLElBQUkxRixLQUFLLENBQUNuTCxJQUFJLEtBQUssV0FBVyxFQUFFOE0sTUFBTSxDQUFDZ0UsU0FBUyxJQUFBRixVQUFBLEdBQUd0RSxTQUFTLENBQUN0SSxNQUFNLEVBQUUsV0FBVyxDQUFDLGNBQUE0TSxVQUFBLGNBQUFBLFVBQUEsR0FBSSxFQUFFO1lBQ3ZGLE9BQU85RCxNQUFNO1VBQ2Y7VUFDQSxJQUFJM0IsS0FBSyxDQUFDbkwsSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUFFLE1BQU0vRSxNQUFNLEdBQUdvUixXQUFXLENBQUNySSxNQUFNLEVBQUUsUUFBUSxDQUFDO1lBQUUsT0FBTztjQUFFaEUsSUFBSSxFQUFFLFNBQVM7Y0FBRS9FLE1BQU0sRUFBRSxPQUFPQSxNQUFNLEtBQUssUUFBUSxHQUFHQSxNQUFNLEdBQUc7WUFBRyxDQUFDO1VBQUU7VUFDNUosSUFBSWtRLEtBQUssQ0FBQ25MLElBQUksS0FBSyxVQUFVLEVBQUU7WUFDN0IsTUFBTStRLGFBQWEsR0FBR3BHLFNBQVMsQ0FBQ1EsS0FBSyxDQUFDNEYsYUFBYSxFQUFFL00sTUFBTSxFQUFFUSxLQUFLLEVBQUUsSUFBSSxDQUFDO1lBQ3pFLElBQUl1TSxhQUFhLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUNyTCxRQUFRLENBQUNDLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQzZGLFdBQVcsQ0FBQyxDQUFDLElBQUksT0FBTzdGLEtBQUssQ0FBQzhGLFNBQVMsS0FBSyxRQUFRLElBQUk3TyxJQUFJLENBQUNxRyxJQUFJLENBQUMwQyxLQUFLLENBQUM4RixTQUFTLENBQUMsSUFBSSxPQUFPOUYsS0FBSyxDQUFDK0YsU0FBUyxLQUFLLFFBQVEsSUFBSTlPLElBQUksQ0FBQ3FHLElBQUksQ0FBQzBDLEtBQUssQ0FBQytGLFNBQVMsQ0FBQyxFQUFFLE9BQU87Y0FBRWxSLElBQUksRUFBRSxVQUFVO2NBQUUrUSxhQUFhO2NBQUVDLFdBQVcsRUFBRXJMLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQzZGLFdBQVcsQ0FBQztjQUFFQyxTQUFTLEVBQUU5RixLQUFLLENBQUM4RixTQUFTO2NBQUVDLFNBQVMsRUFBRS9GLEtBQUssQ0FBQytGO1lBQVUsQ0FBQztVQUNqVztVQUNBO1FBQ0Y7TUFDQSxLQUFLLGNBQWM7UUFBRTtVQUNuQixJQUFJLENBQUM1TyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3hILEtBQUssQ0FBQyxFQUFFO1VBQzNCLE1BQU0rUixNQUFxQixHQUFHLEVBQUU7VUFDaEMsS0FBSyxNQUFNN0QsR0FBRyxJQUFJbE8sS0FBSyxFQUFFO1lBQUUsTUFBTW9XLFdBQVcsR0FBRzlPLE1BQU0sQ0FBQzRHLEdBQUcsQ0FBQztZQUFFLElBQUksQ0FBQ2tJLFdBQVcsRUFBRTtZQUFVLE1BQU1uUyxXQUFXLEdBQUcyTCxTQUFTLENBQUN3RyxXQUFXLENBQUNuUyxXQUFXLEVBQUVnRixNQUFNLEVBQUVRLEtBQUssQ0FBQztZQUFFLElBQUksQ0FBQ3hGLFdBQVcsRUFBRTtZQUFVLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQzBHLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDd0wsV0FBVyxDQUFDeFUsSUFBSSxDQUFDLENBQUMsRUFBRTtjQUFFMkgsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFlBQVksRUFBRU4sTUFBTSxDQUFDQyxFQUFFLEVBQUVPLEtBQUssQ0FBQztjQUFFO1lBQVU7WUFBRXNJLE1BQU0sQ0FBQ3JJLElBQUksQ0FBQztjQUFFekYsV0FBVztjQUFFckMsSUFBSSxFQUFFZ0osTUFBTSxDQUFDd0wsV0FBVyxDQUFDeFUsSUFBSTtZQUFFLENBQUMsQ0FBQztVQUFFO1VBQ25hLE9BQU9tUSxNQUFNO1FBQ2Y7TUFDQSxLQUFLLE1BQU07UUFBRTtVQUNYLElBQUksQ0FBQ3hLLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLEVBQUU7VUFDM0IsTUFBTStSLE1BQXFCLEdBQUcsRUFBRTtVQUNoQyxLQUFLLE1BQU03RCxHQUFHLElBQUlsTyxLQUFLLEVBQUU7WUFBRSxNQUFNcVcsR0FBRyxHQUFHL08sTUFBTSxDQUFDNEcsR0FBRyxDQUFDO1lBQUUsSUFBSSxDQUFDbUksR0FBRyxFQUFFO1lBQVUsTUFBTTlSLE9BQU8sR0FBR3FMLFNBQVMsQ0FBQ3lHLEdBQUcsQ0FBQzlSLE9BQU8sRUFBRTBFLE1BQU0sRUFBRVEsS0FBSyxDQUFDO1lBQUUsSUFBSSxDQUFDbEYsT0FBTyxFQUFFO1lBQVUsSUFBSSxPQUFPOFIsR0FBRyxDQUFDQyxDQUFDLEtBQUssUUFBUSxJQUFJLE9BQU9ELEdBQUcsQ0FBQ0UsQ0FBQyxLQUFLLFFBQVEsSUFBSUYsR0FBRyxDQUFDQyxDQUFDLEdBQUcsQ0FBQyxJQUFJRCxHQUFHLENBQUNDLENBQUMsR0FBRyxDQUFDLElBQUlELEdBQUcsQ0FBQ0UsQ0FBQyxHQUFHLENBQUMsSUFBSUYsR0FBRyxDQUFDRSxDQUFDLEdBQUcsQ0FBQyxFQUFFO2NBQUVoTixJQUFJLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO2NBQUU7WUFBVTtZQUFFc0ksTUFBTSxDQUFDckksSUFBSSxDQUFDO2NBQUVuRixPQUFPO2NBQUUrUixDQUFDLEVBQUVELEdBQUcsQ0FBQ0MsQ0FBQztjQUFFQyxDQUFDLEVBQUVGLEdBQUcsQ0FBQ0U7WUFBRSxDQUFDLENBQUM7VUFBRTtVQUM5WCxPQUFPeEUsTUFBTTtRQUNmO01BQ0EsS0FBSyxVQUFVO1FBQUUsSUFBRyxPQUFPL1IsS0FBSyxLQUFHLFFBQVEsSUFBRWtJLE1BQU0sQ0FBQ3dOLFFBQVEsQ0FBQ2MsSUFBSSxDQUFDM0IsS0FBSyxDQUFDN1UsS0FBSyxDQUFDLENBQUMsRUFBQyxPQUFPQSxLQUFLO1FBQUM7TUFDN0YsS0FBSyxhQUFhO1FBQUU7VUFBQSxJQUFBeVcsc0JBQUE7VUFBQyxNQUFNN0UsS0FBSyxJQUFBNkUsc0JBQUEsR0FBQ2xPLE9BQU8sQ0FBQ3NKLGNBQWMsY0FBQTRFLHNCQUFBLHVCQUF0QkEsc0JBQUEsQ0FBeUI3TCxNQUFNLENBQUM1SyxLQUFLLENBQUMsQ0FBQztVQUFDLElBQUcsQ0FBQzRSLEtBQUssRUFBQztZQUFDckksSUFBSSxDQUFDLG9CQUFvQixFQUFDLHdCQUF3QixFQUFDTixNQUFNLENBQUNDLEVBQUUsRUFBQ08sS0FBSyxDQUFDO1lBQUMsT0FBT2hDLFNBQVM7VUFBQztVQUFDLE9BQU9tSyxLQUFLLENBQUNJLGVBQWU7UUFBQztNQUN2TSxLQUFLLFFBQVE7UUFBRSxPQUFPUixXQUFXLENBQUN4UixLQUFLLEVBQUVpSixNQUFNLEVBQUVRLEtBQUssQ0FBQztNQUN2RCxLQUFLLFNBQVM7UUFBRTtVQUNkLE1BQU0yRyxLQUFLLEdBQUc5SSxNQUFNLENBQUN0SCxLQUFLLENBQUM7VUFBRSxJQUFJLENBQUNvUSxLQUFLLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQ3pGLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDd0YsS0FBSyxDQUFDalYsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDd1AsUUFBUSxDQUFDQyxNQUFNLENBQUN3RixLQUFLLENBQUNzRyxNQUFNLENBQUMsQ0FBQyxFQUFFO1VBQzVMLE1BQU1DLFFBQVEsR0FBR3BGLFNBQVMsQ0FBQ3RJLE1BQU0sRUFBRSxVQUFVLENBQUM7VUFDOUMsSUFBSSxPQUFPbUgsS0FBSyxDQUFDdUcsUUFBUSxLQUFLLFFBQVEsSUFBSXZHLEtBQUssQ0FBQ3VHLFFBQVEsSUFBSUEsUUFBUSxLQUFLbFAsU0FBUyxFQUFFO1lBQUU4QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsd0JBQXdCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLFVBQVUsQ0FBQztZQUFFLE9BQU96QixTQUFTO1VBQUU7VUFDdkwsTUFBTXJHLFFBQVEsR0FBR2dQLEtBQUssQ0FBQ2hQLFFBQVEsSUFBSSxJQUFJLEdBQUdzVCxTQUFTLENBQUM7WUFBRSxHQUFHekwsTUFBTTtZQUFFRSxJQUFJLEVBQUU7Y0FBRSxHQUFHRixNQUFNLENBQUNFLElBQUk7Y0FBRS9ILFFBQVEsRUFBRWdQLEtBQUssQ0FBQ2hQO1lBQVM7VUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFbkgsSUFBSSxDQUFDLEdBQUd3TixTQUFTO1VBQ3BKLElBQUkySSxLQUFLLENBQUNoUCxRQUFRLElBQUksSUFBSSxJQUFJQSxRQUFRLEtBQUtxRyxTQUFTLEVBQUUsT0FBT0EsU0FBUztVQUN0RSxNQUFNc0ssTUFBbUMsR0FBRztZQUFFNVcsS0FBSyxFQUFFeVAsTUFBTSxDQUFDd0YsS0FBSyxDQUFDalYsS0FBSyxDQUFDO1lBQUV1YixNQUFNLEVBQUU5TCxNQUFNLENBQUN3RixLQUFLLENBQUNzRyxNQUFNLENBQUM7WUFBRUMsUUFBUSxFQUFFQSxRQUFRLGFBQVJBLFFBQVEsY0FBUkEsUUFBUSxHQUFJO1VBQUcsQ0FBQztVQUNsSSxJQUFJLE9BQU92RyxLQUFLLENBQUNsSCxFQUFFLEtBQUssUUFBUSxJQUFJK0QsS0FBSyxDQUFDbUQsS0FBSyxDQUFDbEgsRUFBRSxDQUFDLEVBQUU2SSxNQUFNLENBQUM3SSxFQUFFLEdBQUcrRCxLQUFLLENBQUNtRCxLQUFLLENBQUNsSCxFQUFFLENBQUM7VUFDaEYsSUFBSWtILEtBQUssQ0FBQy9RLEtBQUssSUFBSSxJQUFJLEVBQUU7WUFBRSxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsYUFBYSxDQUFDLENBQUNzTCxRQUFRLENBQUNDLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQy9RLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFBTzBTLE1BQU0sQ0FBQzFTLEtBQUssR0FBR3VMLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQy9RLEtBQUssQ0FBQztVQUFFO1VBQ2xLLElBQUkrQixRQUFRLEtBQUtxRyxTQUFTLEVBQUVzSyxNQUFNLENBQUMzUSxRQUFRLEdBQUdBLFFBQVE7VUFDdEQsT0FBTzJRLE1BQU07UUFDZjtNQUNBLEtBQUssYUFBYTtRQUFFO1VBQ2xCLElBQUksQ0FBQ3hLLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLEVBQUU7VUFDM0IsTUFBTStSLE1BQXFCLEdBQUcsRUFBRTtVQUNoQyxNQUFNL0IsVUFBVSxHQUFHL0csTUFBTSxDQUFDZ0IsSUFBSSxLQUFLLE9BQU8sSUFBSSxPQUFPaEIsTUFBTSxDQUFDRSxJQUFJLENBQUNySyxlQUFlLEtBQUssUUFBUSxHQUFHbUssTUFBTSxDQUFDRSxJQUFJLENBQUNySyxlQUFlLEdBQUdtSyxNQUFNLENBQUNDLEVBQUU7VUFDdkksS0FBSyxNQUFNZ0YsR0FBRyxJQUFJbE8sS0FBSyxFQUFFO1lBQ3ZCLE1BQU00VyxVQUFVLEdBQUd0UCxNQUFNLENBQUM0RyxHQUFHLENBQUM7WUFBRSxJQUFJLENBQUMwSSxVQUFVLEVBQUU7Y0FBRXJOLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxjQUFjLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFTyxLQUFLLENBQUM7Y0FBRTtZQUFVO1lBQzFILE1BQU1vTixJQUFJLEdBQUczRyxVQUFVLENBQUMwRyxVQUFVLENBQUNDLElBQUksRUFBRTdHLFVBQVUsRUFBRS9HLE1BQU0sRUFBRVEsS0FBSyxDQUFDO2NBQUVxTixFQUFFLEdBQUc1RyxVQUFVLENBQUMwRyxVQUFVLENBQUNFLEVBQUUsRUFBRTlHLFVBQVUsRUFBRS9HLE1BQU0sRUFBRVEsS0FBSyxDQUFDO1lBQzlILE1BQU1zTixPQUFPLEdBQUNILFVBQVUsQ0FBQ3pXLGdCQUFnQixHQUFDNlQsY0FBYyxDQUFDNEMsVUFBVSxDQUFDelcsZ0JBQWdCLEVBQUM4SSxNQUFNLEVBQUNRLEtBQUssQ0FBQyxHQUFDaEMsU0FBUztZQUFDLElBQUdtUCxVQUFVLENBQUNJLFNBQVMsS0FBRyxJQUFJLElBQUUsQ0FBQ0QsT0FBTyxFQUFDO2NBQUN4TixJQUFJLENBQUMsb0JBQW9CLEVBQUMsZ0NBQWdDLEVBQUNOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTyxLQUFLLENBQUM7Y0FBQztZQUFTO1lBQzVPLElBQUdvTixJQUFJLEtBQUdwUCxTQUFTLElBQUVxUCxFQUFFLEtBQUdyUCxTQUFTLEVBQUNzSyxNQUFNLENBQUNySSxJQUFJLENBQUM7Y0FBQ21OLElBQUk7Y0FBQ0MsRUFBRTtjQUFDLElBQUlDLE9BQU8sR0FBQztnQkFBQ0MsU0FBUyxFQUFDLElBQUk7Z0JBQUM3VyxnQkFBZ0IsRUFBQzRXO2NBQU8sQ0FBQyxHQUFDLENBQUMsQ0FBQztZQUFDLENBQUMsQ0FBQztVQUN0SDtVQUNBLE9BQU9oRixNQUFNO1FBQ2Y7SUFDRjtJQUNBeEksSUFBSSxDQUFDLG9CQUFvQixFQUFFLG9CQUFvQixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRU8sS0FBSyxDQUFDO0lBQ2xFLE9BQU9oQyxTQUFTO0VBQ2xCLENBQUM7RUFDRCxNQUFNcUIsUUFBMkIsR0FBRyxFQUFFO0VBQ3RDLEtBQUssTUFBTUcsTUFBTSxJQUFJMEMsUUFBUSxFQUFFO0lBQzdCLE1BQU0wQyxNQUFNLEdBQUcvVCxpQkFBaUIsQ0FBQzJPLE1BQU0sQ0FBQ2dCLElBQUksQ0FBRTtJQUM5QyxNQUFNcUUsUUFBUSxHQUFHNUcsR0FBRyxDQUFDbUcsYUFBYSxFQUFFNUUsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDO0lBQ2hELE1BQU1tRSxNQUFNLEdBQUc3RyxLQUFLLENBQUNDLE9BQU8sQ0FBQzhHLFFBQVEsQ0FBQyxHQUFHQSxRQUFRLEdBQUcvVCxNQUFNLENBQUN3TSxJQUFJLENBQUNzSCxNQUFNLENBQUM7SUFDdkUsTUFBTTBELE1BQW1DLEdBQUcsQ0FBQyxDQUFDO0lBQzlDLEtBQUssTUFBTXRJLEtBQUssSUFBSTJFLE1BQU0sRUFBRTtNQUMxQixJQUFJLE9BQU8zRSxLQUFLLEtBQUssUUFBUSxJQUFJdkMsZ0JBQWdCLENBQUMyQyxHQUFHLENBQUNKLEtBQUssQ0FBQyxJQUFJLENBQUMzQixNQUFNLENBQUN1RyxNQUFNLEVBQUU1RSxLQUFLLENBQUMsRUFBRTtRQUFFRixJQUFJLENBQUMsV0FBVyxFQUFFLHlCQUF5QixFQUFFTixNQUFNLENBQUNDLEVBQUUsRUFBRTBCLE1BQU0sQ0FBQ25CLEtBQUssQ0FBQyxDQUFDO1FBQUU7TUFBVTtNQUM1SyxJQUFJcUUsY0FBYyxDQUFDbkQsUUFBUSxDQUFDbEIsS0FBSyxDQUFDLElBQUlxRSxjQUFjLENBQUNuRCxRQUFRLENBQUMsR0FBRzFCLE1BQU0sQ0FBQ2dCLElBQUksSUFBSVIsS0FBSyxFQUFFLENBQUMsRUFBRTtRQUFFRSxJQUFJLENBQUNWLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLFVBQVUsRUFBRU8sS0FBSyxDQUFDO1FBQUU7TUFBVTtNQUMxSSxNQUFNekosS0FBSyxHQUFHMFUsU0FBUyxDQUFDekwsTUFBTSxFQUFFUSxLQUFLLEVBQUU0RSxNQUFNLENBQUM1RSxLQUFLLENBQUMsQ0FBQztNQUFFLElBQUl6SixLQUFLLEtBQUt5SCxTQUFTLEVBQUVzSyxNQUFNLENBQUN0SSxLQUFLLENBQUMsR0FBR3pKLEtBQUs7SUFDdkc7SUFDQSxLQUFLLE1BQU15SixLQUFLLElBQUlsUCxNQUFNLENBQUN3TSxJQUFJLENBQUNrQyxNQUFNLENBQUNFLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQ2lGLE1BQU0sQ0FBQ3pELFFBQVEsQ0FBQ2xCLEtBQUssQ0FBQyxJQUFJLENBQUMzQixNQUFNLENBQUN1RyxNQUFNLEVBQUU1RSxLQUFLLENBQUMsRUFBRUUsSUFBSSxDQUFDVixNQUFNLENBQUNDLEVBQUUsRUFBRWhDLGdCQUFnQixDQUFDMkMsR0FBRyxDQUFDSixLQUFLLENBQUMsR0FBRyxlQUFlLEdBQUcsaUJBQWlCLEVBQUVBLEtBQUssQ0FBQztJQUM5TCxJQUFJUixNQUFNLENBQUNnQixJQUFJLEtBQUssWUFBWSxFQUFFO01BQ2hDLE1BQU0wSyxRQUFRLEdBQUdwTixLQUFLLENBQUNDLE9BQU8sQ0FBQzRDLE1BQU0sQ0FBQzZNLHFCQUFxQixDQUFDLElBQUk3TSxNQUFNLENBQUM2TSxxQkFBcUIsQ0FBQ3RNLFFBQVEsQ0FBQzFCLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDO01BQ2hILE1BQU1nTyxVQUFVLEdBQUcsT0FBT2pPLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDZ08sWUFBWSxLQUFLLFFBQVEsR0FBR2xWLE1BQU0sQ0FBQytILEdBQUcsQ0FBQ2YsTUFBTSxDQUFDRSxJQUFJLENBQUNnTyxZQUFZLENBQUMsR0FBRzFQLFNBQVM7TUFDbEgsSUFBSSxDQUFDa04sUUFBUSxJQUFLdUMsVUFBVSxJQUFJQSxVQUFVLENBQUMvTixJQUFJLENBQUMzRyxxQkFBcUIsS0FBSyxJQUFLLEVBQUUrRyxJQUFJLENBQUMsV0FBVyxFQUFFLG9CQUFvQixFQUFFTixNQUFNLENBQUNDLEVBQUUsQ0FBQztNQUNuSSxNQUFNa08sU0FBUyxHQUFHbk8sTUFBTSxDQUFDRSxJQUFJLENBQUNpTyxTQUFTO01BQ3ZDLElBQUksT0FBT0EsU0FBUyxLQUFLLFFBQVEsSUFBSSxDQUFDaFEsV0FBVyxDQUFDZ1EsU0FBUyxDQUFDLEVBQUU3TixJQUFJLENBQUMsb0JBQW9CLEVBQUUsdUJBQXVCLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDLEtBQ3JJO1FBQUU2SSxNQUFNLENBQUNxRixTQUFTLEdBQUdBLFNBQVM7UUFBRXJGLE1BQU0sQ0FBQ3NGLFNBQVMsR0FBRyxVQUFVcEssS0FBSyxDQUFDaEUsTUFBTSxDQUFDQyxFQUFFLENBQUMsSUFBSTlCLFdBQVcsQ0FBQ2dRLFNBQVMsQ0FBQyxFQUFFO01BQUU7TUFDaEgsSUFBSSxPQUFPbk8sTUFBTSxDQUFDRSxJQUFJLENBQUNtTyxXQUFXLEtBQUssUUFBUSxJQUFJLENBQUMsZ0JBQWdCLENBQUM1SixJQUFJLENBQUN6RSxNQUFNLENBQUNFLElBQUksQ0FBQ21PLFdBQVcsQ0FBQyxJQUFJLENBQUNyUCxPQUFPLENBQUNnQixNQUFNLENBQUNFLElBQUksQ0FBQ29PLFFBQVEsQ0FBQyxJQUFJdE8sTUFBTSxDQUFDRSxJQUFJLENBQUNvTyxRQUFRLEdBQUcsQ0FBQyxFQUFFaE8sSUFBSSxDQUFDLG1CQUFtQixFQUFFLG1CQUFtQixFQUFFTixNQUFNLENBQUNDLEVBQUUsQ0FBQyxDQUFDLEtBQ3ZOO1FBQUU2SSxNQUFNLENBQUN1RixXQUFXLEdBQUdyTyxNQUFNLENBQUNFLElBQUksQ0FBQ21PLFdBQVc7UUFBRXZGLE1BQU0sQ0FBQ3dGLFFBQVEsR0FBR3RPLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDb08sUUFBUTtRQUFFeEYsTUFBTSxDQUFDeUYsYUFBYSxHQUFHLEtBQUs7TUFBRTtJQUM3SDtJQUNBLElBQUl2TyxNQUFNLENBQUNnQixJQUFJLEtBQUssUUFBUSxJQUFJaEIsTUFBTSxDQUFDRSxJQUFJLENBQUM5RyxVQUFVLEtBQUssS0FBSyxJQUFJLE9BQU8wUCxNQUFNLENBQUN6UCxPQUFPLEtBQUssUUFBUSxFQUFFO01BQ3RHLElBQUk7UUFBRSxNQUFNbVYsR0FBRyxHQUFHLElBQUlDLEdBQUcsQ0FBQzNGLE1BQU0sQ0FBQ3pQLE9BQU8sQ0FBQztRQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQ3FJLFFBQVEsQ0FBQzhNLEdBQUcsQ0FBQ0UsUUFBUSxDQUFDLElBQUlGLEdBQUcsQ0FBQ0csUUFBUSxJQUFJSCxHQUFHLENBQUNJLFFBQVEsRUFBRSxNQUFNLElBQUlDLEtBQUssQ0FBQyxDQUFDO01BQUUsQ0FBQyxDQUFDLE1BQU07UUFBRXZPLElBQUksQ0FBQyxXQUFXLEVBQUUsc0NBQXNDLEVBQUVOLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFLFNBQVMsQ0FBQztNQUFFO0lBQzVPO0lBQ0FKLFFBQVEsQ0FBQ1ksSUFBSSxDQUFDO01BQUVSLEVBQUUsRUFBRStELEtBQUssQ0FBQ2hFLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDO01BQUVlLElBQUksRUFBRWhCLE1BQU0sQ0FBQ2dCLElBQUk7TUFBRStDLElBQUksRUFBRXBCLEtBQUssQ0FBQzVCLEdBQUcsQ0FBQ2YsTUFBTSxDQUFDQyxFQUFFLENBQUU7TUFBRXdDLE1BQU0sRUFBRXpDLE1BQU0sQ0FBQ3lDLE1BQU07TUFBRXZDLElBQUksRUFBRTRJO0lBQU8sQ0FBQyxDQUFDO0VBQzlIO0VBQ0EsTUFBTWhKLFNBQThCLEdBQUcsRUFBRTtFQUN6QyxNQUFNZ1AsV0FBVyxHQUFHeFEsS0FBSyxDQUFDQyxPQUFPLENBQUM0QyxNQUFNLENBQUM0TixrQkFBa0IsQ0FBQyxHQUFHNU4sTUFBTSxDQUFDNE4sa0JBQWtCLEdBQUcsRUFBRTtFQUM3RixNQUFNQyxjQUFjLEdBQUcsSUFBSXJPLEdBQUcsQ0FBQ3ZCLE9BQU8sQ0FBQ1UsU0FBUyxDQUFDekUsR0FBRyxDQUFDNFQsUUFBUSxJQUFJLENBQUNBLFFBQVEsQ0FBQ2hQLEVBQUUsRUFBRWdQLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDMUYsS0FBSyxNQUFNQyxLQUFLLElBQUlKLFdBQVcsRUFBRTtJQUMvQixJQUFJLE9BQU9JLEtBQUssS0FBSyxRQUFRLEVBQUU7TUFBRTVPLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxlQUFlLEVBQUVqQixTQUFTLEVBQUUsb0JBQW9CLENBQUM7TUFBRTtJQUFVO0lBQ3hILE1BQU00UCxRQUFRLEdBQUdELGNBQWMsQ0FBQ2pPLEdBQUcsQ0FBQ21PLEtBQUssQ0FBQztJQUMxQyxJQUFJLENBQUNELFFBQVEsSUFBSUEsUUFBUSxDQUFDaE8sU0FBUyxLQUFLN0IsT0FBTyxDQUFDNkIsU0FBUyxFQUFFO01BQUVYLElBQUksQ0FBQyxtQkFBbUIsRUFBRSx3QkFBd0IsRUFBRTRPLEtBQUssQ0FBQztNQUFFO0lBQVU7SUFDbkksSUFBSSxDQUFDekosV0FBVyxDQUFDN0UsR0FBRyxDQUFDcU8sUUFBUSxDQUFDeGEsTUFBTSxDQUFDLElBQUksQ0FBQ2dSLFdBQVcsQ0FBQzdFLEdBQUcsQ0FBQ3FPLFFBQVEsQ0FBQ3ZhLElBQUksQ0FBQyxJQUFJdWEsUUFBUSxDQUFDeE0sTUFBTSxLQUFLLFdBQVcsSUFBSXdNLFFBQVEsQ0FBQy9OLFNBQVMsRUFBRTtNQUFFUixJQUFJLENBQUN3TyxLQUFLLEVBQUUseUJBQXlCLENBQUM7TUFBRTtJQUFVO0lBQ3ZMLE1BQU1DLGtCQUFrQixHQUFHMVEsR0FBRyxDQUFDSixNQUFNLENBQUNJLEdBQUcsQ0FBQ3lELFdBQVcsRUFBRWdOLEtBQUssQ0FBQyxDQUFDLEVBQUUsY0FBYyxDQUFDO0lBQy9FLElBQUksT0FBT0Msa0JBQWtCLEtBQUssUUFBUSxJQUFJLENBQUNBLGtCQUFrQixFQUFFO01BQUU3TyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsbUJBQW1CLEVBQUU0TyxLQUFLLEVBQUUsY0FBYyxDQUFDO01BQUU7SUFBVTtJQUN6SjlLLEtBQUssQ0FBQzhLLEtBQUssQ0FBQztJQUNaLE1BQU14WCxRQUFRLEdBQUNpVCxhQUFhLENBQUNzRSxRQUFRLENBQUN2WCxRQUFRLEVBQUM7TUFBQ3VJLEVBQUUsRUFBQ2lQLEtBQUs7TUFBQ2pPLFNBQVMsRUFBQzdCLE9BQU8sQ0FBQzZCLFNBQVM7TUFBQ0QsSUFBSSxFQUFDLE1BQU07TUFBQytDLElBQUksRUFBQyxFQUFFO01BQUN0QixNQUFNLEVBQUN3TSxRQUFRLENBQUN4TSxNQUFNO01BQUN2QyxJQUFJLEVBQUMsQ0FBQztJQUFDLENBQUMsRUFBQyxVQUFVLENBQUM7SUFDcEpKLFNBQVMsQ0FBQ1csSUFBSSxDQUFDO01BQUUsSUFBRy9JLFFBQVEsR0FBQztRQUFDQTtNQUFRLENBQUMsR0FBQyxDQUFDLENBQUM7TUFBQ3VJLEVBQUUsRUFBRStELEtBQUssQ0FBQ2tMLEtBQUssQ0FBQztNQUFFemEsTUFBTSxFQUFFdVAsS0FBSyxDQUFDaUwsUUFBUSxDQUFDeGEsTUFBTSxDQUFDO01BQUVDLElBQUksRUFBRXNQLEtBQUssQ0FBQ2lMLFFBQVEsQ0FBQ3ZhLElBQUksQ0FBQztNQUFFMGEsWUFBWSxFQUFFRCxrQkFBa0I7TUFBRXRULFNBQVMsRUFBRW9ULFFBQVEsQ0FBQ3BULFNBQVM7TUFBRW1QLFdBQVcsRUFBRWlFLFFBQVEsQ0FBQ2pFLFdBQVcsQ0FBQ2pJLE1BQU0sQ0FBQzlDLEVBQUUsSUFBSXdGLFdBQVcsQ0FBQzdFLEdBQUcsQ0FBQ1gsRUFBRSxDQUFDLENBQUMsQ0FBQzVFLEdBQUcsQ0FBQzRFLEVBQUUsSUFBSStELEtBQUssQ0FBQy9ELEVBQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztFQUN2UjtFQUNBLElBQUlOLE1BQU0sQ0FBQ1osTUFBTSxFQUFFLE9BQU87SUFBRW9CLEVBQUUsRUFBRSxLQUFLO0lBQUVSLE1BQU07SUFBRUM7RUFBVSxDQUFDO0VBQzFELE1BQU15UCxVQUE0QixHQUFHO0lBQUVDLE1BQU0sRUFBRSxxQkFBcUI7SUFBRUMsYUFBYSxFQUFFLE9BQU87SUFBRTFOLEtBQUssRUFBRUEsS0FBZTtJQUFFMk4sU0FBUyxFQUFDcFEsT0FBTyxDQUFDb1EsU0FBUztJQUFFM0osU0FBUztJQUFFaEcsUUFBUTtJQUFFQyxTQUFTO0lBQUUyUCxXQUFXLEVBQUU7RUFBRyxDQUFDO0VBQ3BNSixVQUFVLENBQUNJLFdBQVcsR0FBR0MsMEJBQTBCLENBQUNMLFVBQVUsQ0FBQztFQUMvRCxPQUFPO0lBQUVsUCxFQUFFLEVBQUUsSUFBSTtJQUFFa1AsVUFBVTtJQUFFelAsU0FBUztJQUFFb0U7RUFBTSxDQUFDO0FBQ25EOztBQUVBO0FBQ0EsU0FBUzFCLGVBQWVBLENBQUN0SixNQUFpQyxFQUFFbUksTUFBbUIsRUFBRUYsU0FBaUIsRUFBRWlCLFdBQXdCLEVBQUU1QixJQUFpRyxFQUEyQjtFQUFBLElBQUFxUCxnQkFBQTtFQUN4UCxNQUFNdlosS0FBSyxHQUFHaUksTUFBTSxDQUFDOEMsTUFBTSxDQUFDSSxVQUFVLENBQUM7RUFDdkMsSUFBSSxDQUFDbkwsS0FBSyxFQUFFLE9BQU9vSSxTQUFTO0VBQzVCLElBQUlwSSxLQUFLLENBQUM2SyxTQUFTLEtBQUtBLFNBQVMsRUFBRTtJQUFFWCxJQUFJLENBQUMsbUJBQW1CLEVBQUUsb0JBQW9CLEVBQUU5QixTQUFTLEVBQUUsWUFBWSxDQUFDO0lBQUUsT0FBTyxJQUFJUixHQUFHLENBQUMsQ0FBQztFQUFFO0VBQ2pJLElBQUk1SCxLQUFLLENBQUNzVSxjQUFjLElBQUksSUFBSSxFQUFFO0lBQUVwSyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsMkNBQTJDLEVBQUU5QixTQUFTLEVBQUUsMkJBQTJCLENBQUM7SUFBRSxPQUFPLElBQUlSLEdBQUcsQ0FBQyxDQUFDO0VBQUU7RUFDdkssSUFBSTVILEtBQUssQ0FBQ2pELFNBQVMsSUFBSSxJQUFJLElBQUlpRCxLQUFLLENBQUN3WixPQUFPLElBQUksSUFBSSxFQUFFO0lBQUV0UCxJQUFJLENBQUMsb0JBQW9CLEVBQUUsd0JBQXdCLEVBQUU5QixTQUFTLEVBQUUsWUFBWSxDQUFDO0lBQUUsT0FBTyxJQUFJUixHQUFHLENBQUMsQ0FBQztFQUFFO0VBQ3pKLElBQUk1SCxLQUFLLENBQUNqRCxTQUFTLElBQUksSUFBSSxJQUFJaUQsS0FBSyxDQUFDd1osT0FBTyxJQUFJLElBQUksRUFBRSxPQUFPcFIsU0FBUztFQUN0RSxNQUFNcVIsTUFBTSxJQUFBRixnQkFBQSxHQUFHdlosS0FBSyxDQUFDakQsU0FBUyxjQUFBd2MsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSXZaLEtBQUssQ0FBQ3daLE9BQU87RUFDL0MsTUFBTUUsSUFBSSxHQUFHLE9BQU9ELE1BQU0sS0FBSyxRQUFRLEdBQUc3VyxNQUFNLENBQUMrSCxHQUFHLENBQUM4TyxNQUFNLENBQUMsR0FBR3JSLFNBQVM7RUFDeEUsSUFBSSxDQUFDc1IsSUFBSSxJQUFJQSxJQUFJLENBQUM3TyxTQUFTLEtBQUtBLFNBQVMsSUFBSTZPLElBQUksQ0FBQzlPLElBQUksTUFBTTVLLEtBQUssQ0FBQ2pELFNBQVMsSUFBSSxJQUFJLEdBQUcsU0FBUyxHQUFHLFlBQVksQ0FBQyxJQUFJMmMsSUFBSSxDQUFDNU8sU0FBUyxFQUFFO0lBQUVaLElBQUksQ0FBQyxtQkFBbUIsRUFBRSx1QkFBdUIsRUFBRSxPQUFPdVAsTUFBTSxLQUFLLFFBQVEsR0FBR0EsTUFBTSxHQUFHclIsU0FBUyxFQUFFLFlBQVksQ0FBQztJQUFFLE9BQU8sSUFBSVIsR0FBRyxDQUFDLENBQUM7RUFBRTtFQUMxUSxNQUFNME4sUUFBUSxHQUFHLElBQUkxTixHQUFHLENBQUNNLEtBQUssQ0FBQ0MsT0FBTyxDQUFDNEMsTUFBTSxDQUFDWSxXQUFXLENBQUMsR0FBR1osTUFBTSxDQUFDWSxXQUFXLENBQUNnQixNQUFNLENBQUU5QyxFQUFFLElBQW1CLE9BQU9BLEVBQUUsS0FBSyxRQUFRLENBQUMsR0FBRyxFQUFFLENBQUM7RUFDMUksTUFBTThQLFNBQVMsR0FBRyxJQUFJL1IsR0FBRyxDQUFTLENBQUM7RUFDbkMsTUFBTWdTLE1BQU0sR0FBRyxJQUFJaFMsR0FBRyxDQUFTLENBQUM7RUFDaEMsSUFBSThSLElBQUksQ0FBQzlPLElBQUksS0FBSyxTQUFTLEVBQUU7SUFDM0IrTyxTQUFTLENBQUNyTCxHQUFHLENBQUNvTCxJQUFJLENBQUM3UCxFQUFFLENBQUM7SUFDdEIsS0FBSyxNQUFNRCxNQUFNLElBQUloSCxNQUFNLENBQUM1SCxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUk0TyxNQUFNLENBQUNnQixJQUFJLEtBQUssT0FBTyxLQUFLaEIsTUFBTSxDQUFDRSxJQUFJLENBQUMvTSxTQUFTLEtBQUsyYyxJQUFJLENBQUM3UCxFQUFFLElBQUszQixLQUFLLENBQUNDLE9BQU8sQ0FBQ3VSLElBQUksQ0FBQzVQLElBQUksQ0FBQ25OLFFBQVEsQ0FBQyxJQUFJK2MsSUFBSSxDQUFDNVAsSUFBSSxDQUFDbk4sUUFBUSxDQUFDMk8sUUFBUSxDQUFDMUIsTUFBTSxDQUFDQyxFQUFFLENBQUUsQ0FBQyxFQUFFK1AsTUFBTSxDQUFDdEwsR0FBRyxDQUFDMUUsTUFBTSxDQUFDQyxFQUFFLENBQUM7RUFDbE4sQ0FBQyxNQUFNO0lBQ0wsTUFBTWdRLE1BQXNCLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDO01BQUVJLGFBQWEsR0FBRyxJQUFJbFMsR0FBRyxDQUFTLENBQUM7SUFDeEUsT0FBT2lTLE1BQU0sQ0FBQ2xSLE1BQU0sRUFBRTtNQUNwQixNQUFNb1IsS0FBSyxHQUFHRixNQUFNLENBQUNHLEdBQUcsQ0FBQyxDQUFFO01BQUUsSUFBSUYsYUFBYSxDQUFDdFAsR0FBRyxDQUFDdVAsS0FBSyxDQUFDbFEsRUFBRSxDQUFDLEVBQUU7TUFDOURpUSxhQUFhLENBQUN4TCxHQUFHLENBQUN5TCxLQUFLLENBQUNsUSxFQUFFLENBQUM7TUFBRThQLFNBQVMsQ0FBQ3JMLEdBQUcsQ0FBQ3lMLEtBQUssQ0FBQ2xRLEVBQUUsQ0FBQztNQUNwRCxLQUFLLE1BQU1sSixLQUFLLElBQUksQ0FBQyxJQUFHdUgsS0FBSyxDQUFDQyxPQUFPLENBQUM0UixLQUFLLENBQUNqUSxJQUFJLENBQUNqTCxPQUFPLENBQUMsR0FBR2tiLEtBQUssQ0FBQ2pRLElBQUksQ0FBQ2pMLE9BQU8sR0FBRyxFQUFFLEdBQUUsSUFBR3FKLEtBQUssQ0FBQ0MsT0FBTyxDQUFDNFIsS0FBSyxDQUFDalEsSUFBSSxDQUFDaEwsT0FBTyxDQUFDLEdBQUdpYixLQUFLLENBQUNqUSxJQUFJLENBQUNoTCxPQUFPLEdBQUcsRUFBRSxFQUFDLEVBQUUsSUFBSSxPQUFPNkIsS0FBSyxLQUFLLFFBQVEsRUFBRWdaLFNBQVMsQ0FBQ3JMLEdBQUcsQ0FBQzNOLEtBQUssQ0FBQztNQUN6TSxLQUFLLE1BQU1BLEtBQUssSUFBSXVILEtBQUssQ0FBQ0MsT0FBTyxDQUFDNFIsS0FBSyxDQUFDalEsSUFBSSxDQUFDakwsT0FBTyxDQUFDLEdBQUdrYixLQUFLLENBQUNqUSxJQUFJLENBQUNqTCxPQUFPLEdBQUcsRUFBRSxFQUFFO1FBQy9FLE1BQU1vYixJQUFJLEdBQUcsT0FBT3RaLEtBQUssS0FBSyxRQUFRLEdBQUdpQyxNQUFNLENBQUMrSCxHQUFHLENBQUNoSyxLQUFLLENBQUMsR0FBR3lILFNBQVM7UUFDdEUsSUFBSSxDQUFDNlIsSUFBSSxJQUFJQSxJQUFJLENBQUNyUCxJQUFJLEtBQUssV0FBVyxFQUFFO1FBQ3hDLElBQUksT0FBT3FQLElBQUksQ0FBQ25RLElBQUksQ0FBQ2xNLE9BQU8sS0FBSyxRQUFRLEVBQUVnYyxNQUFNLENBQUN0TCxHQUFHLENBQUMyTCxJQUFJLENBQUNuUSxJQUFJLENBQUNsTSxPQUFPLENBQUM7UUFDeEUsTUFBTTRULEtBQUssR0FBRyxPQUFPeUksSUFBSSxDQUFDblEsSUFBSSxDQUFDak0sWUFBWSxLQUFLLFFBQVEsR0FBRytFLE1BQU0sQ0FBQytILEdBQUcsQ0FBQ3NQLElBQUksQ0FBQ25RLElBQUksQ0FBQ2pNLFlBQVksQ0FBQyxHQUFHdUssU0FBUztRQUN6RyxJQUFJLENBQUFvSixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRTVHLElBQUksTUFBSyxZQUFZLElBQUkwSyxRQUFRLENBQUM5SyxHQUFHLENBQUNnSCxLQUFLLENBQUMzSCxFQUFFLENBQUMsRUFBRWdRLE1BQU0sQ0FBQ3hQLElBQUksQ0FBQ21ILEtBQUssQ0FBQztNQUNoRjtJQUNGO0VBQ0Y7RUFDQSxNQUFNMEksUUFBUSxHQUFJdFEsTUFBb0IsSUFBYztJQUNsRCxJQUFJQSxNQUFNLENBQUNnQixJQUFJLEtBQUssT0FBTyxFQUFFLE9BQU9nUCxNQUFNLENBQUNwUCxHQUFHLENBQUNaLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDO0lBQ3pELElBQUksQ0FBQyxZQUFZLEVBQUUsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDeUIsUUFBUSxDQUFDMUIsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLEVBQUUsT0FBTzhPLElBQUksQ0FBQzlPLElBQUksS0FBSyxZQUFZLElBQUkrTyxTQUFTLENBQUNuUCxHQUFHLENBQUNaLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDO0lBQ2pJLElBQUlELE1BQU0sQ0FBQ2dCLElBQUksS0FBSyxTQUFTLEVBQUUsT0FBTzhPLElBQUksQ0FBQzlPLElBQUksS0FBSyxTQUFTLEdBQUdoQixNQUFNLENBQUNDLEVBQUUsS0FBSzZQLElBQUksQ0FBQzdQLEVBQUUsR0FBRyxDQUFDLEdBQUcrUCxNQUFNLENBQUMsQ0FBQ2pRLElBQUksQ0FBQ0UsRUFBRTtNQUFBLElBQUFzUSxXQUFBO01BQUEsT0FBSSxFQUFBQSxXQUFBLEdBQUF2WCxNQUFNLENBQUMrSCxHQUFHLENBQUNkLEVBQUUsQ0FBQyxjQUFBc1EsV0FBQSx1QkFBZEEsV0FBQSxDQUFnQnJRLElBQUksQ0FBQy9NLFNBQVMsTUFBSzZNLE1BQU0sQ0FBQ0MsRUFBRTtJQUFBLEVBQUM7SUFDNUosT0FBTyxJQUFJO0VBQ2IsQ0FBQztFQUNELE1BQU11USxNQUFNLEdBQUcsSUFBSXhTLEdBQUcsQ0FBUyxDQUFDO0lBQUV5UyxLQUFLLEdBQUcsQ0FBQyxHQUFHVixTQUFTLEVBQUUsR0FBR0MsTUFBTSxDQUFDO0VBQ25FLE1BQU1VLE9BQU8sR0FBSTNaLEtBQWMsSUFBSztJQUFFLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSTJVLFFBQVEsQ0FBQzlLLEdBQUcsQ0FBQzdKLEtBQUssQ0FBQyxFQUFFMFosS0FBSyxDQUFDaFEsSUFBSSxDQUFDMUosS0FBSyxDQUFDO0VBQUUsQ0FBQztFQUNoSCxNQUFNNFosYUFBYSxHQUFHQSxDQUFDNVosS0FBYyxFQUFFd1EsS0FBSyxHQUFHLENBQUMsS0FBSztJQUNuRCxNQUFNQyxHQUFHLEdBQUduSixNQUFNLENBQUN0SCxLQUFLLENBQUM7SUFBRSxJQUFJLENBQUN5USxHQUFHLElBQUlELEtBQUssR0FBRyxFQUFFLEVBQUU7SUFDbkQsS0FBSyxNQUFNL0csS0FBSyxJQUFJLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUMsRUFBRWtRLE9BQU8sQ0FBQ2xKLEdBQUcsQ0FBQ2hILEtBQUssQ0FBQyxDQUFDO0lBQ3RILElBQUlsQyxLQUFLLENBQUNDLE9BQU8sQ0FBQ2lKLEdBQUcsQ0FBQ0csUUFBUSxDQUFDLEVBQUVILEdBQUcsQ0FBQ0csUUFBUSxDQUFDaEQsT0FBTyxDQUFDaUQsS0FBSyxJQUFJK0ksYUFBYSxDQUFDL0ksS0FBSyxFQUFFTCxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDL0YsSUFBSUMsR0FBRyxDQUFDSSxLQUFLLEVBQUUrSSxhQUFhLENBQUNuSixHQUFHLENBQUNJLEtBQUssRUFBRUwsS0FBSyxHQUFHLENBQUMsQ0FBQztFQUNwRCxDQUFDO0VBQ0QsT0FBT2tKLEtBQUssQ0FBQzFSLE1BQU0sRUFBRTtJQUNuQixNQUFNa0IsRUFBRSxHQUFHd1EsS0FBSyxDQUFDTCxHQUFHLENBQUMsQ0FBRTtJQUN2QixJQUFJSSxNQUFNLENBQUM1UCxHQUFHLENBQUNYLEVBQUUsQ0FBQyxJQUFJLENBQUN5TCxRQUFRLENBQUM5SyxHQUFHLENBQUNYLEVBQUUsQ0FBQyxFQUFFO0lBQ3pDLE1BQU1ELE1BQU0sR0FBR2hILE1BQU0sQ0FBQytILEdBQUcsQ0FBQ2QsRUFBRSxDQUFDO0lBQUUsSUFBSSxDQUFDRCxNQUFNLElBQUksQ0FBQ3NRLFFBQVEsQ0FBQ3RRLE1BQU0sQ0FBQyxFQUFFO0lBQ2pFd1EsTUFBTSxDQUFDOUwsR0FBRyxDQUFDekUsRUFBRSxDQUFDO0lBQ2QsS0FBSyxNQUFNLENBQUNPLEtBQUssRUFBRThFLElBQUksQ0FBQyxJQUFJaFUsTUFBTSxDQUFDaVUsT0FBTyxFQUFBcUwscUJBQUEsR0FBQ3ZmLGlCQUFpQixDQUFDMk8sTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLGNBQUE0UCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFBQSxJQUFBQSxxQkFBQSxFQUFBQyxRQUFBLEVBQUFDLFFBQUEsRUFBQUMsUUFBQTtNQUNoRixJQUFJdlEsS0FBSyxLQUFLLFVBQVUsSUFBSUEsS0FBSyxLQUFLLGVBQWUsRUFBRTtNQUN2RCxNQUFNekosS0FBSyxHQUFHaUosTUFBTSxDQUFDRSxJQUFJLENBQUNNLEtBQUssQ0FBQztNQUNoQyxJQUFJOEUsSUFBSSxDQUFDNVUsSUFBSSxLQUFLLEtBQUssRUFBRWdnQixPQUFPLENBQUMzWixLQUFLLENBQUMsQ0FBQyxLQUNuQyxJQUFJdU8sSUFBSSxDQUFDNVUsSUFBSSxLQUFLLE1BQU0sSUFBSTROLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLEVBQUVBLEtBQUssQ0FBQzROLE9BQU8sQ0FBQytMLE9BQU8sQ0FBQyxDQUFDLEtBQ3pFLElBQUlwTCxJQUFJLENBQUM1VSxJQUFJLEtBQUssV0FBVyxFQUFFaWdCLGFBQWEsQ0FBQzVaLEtBQUssQ0FBQyxDQUFDLEtBQ3BELElBQUl1TyxJQUFJLENBQUM1VSxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUFtZ0IsUUFBQSxHQUFBeFMsTUFBTSxDQUFDdEgsS0FBSyxDQUFDLGNBQUE4WixRQUFBLHVCQUFiQSxRQUFBLENBQWVuZ0IsSUFBSSxNQUFLLEtBQUssRUFBRWdnQixPQUFPLEVBQUFJLFFBQUEsR0FBQ3pTLE1BQU0sQ0FBQ3RILEtBQUssQ0FBQyxjQUFBK1osUUFBQSx1QkFBYkEsUUFBQSxDQUFlL1osS0FBSyxDQUFDLENBQUMsS0FDMUYsSUFBSXVPLElBQUksQ0FBQzVVLElBQUksS0FBSyxNQUFNLEVBQUVnZ0IsT0FBTyxFQUFBSyxRQUFBLEdBQUMxUyxNQUFNLENBQUN0SCxLQUFLLENBQUMsY0FBQWdhLFFBQUEsdUJBQWJBLFFBQUEsQ0FBZWhFLGFBQWEsQ0FBQyxDQUFDLEtBQ2hFLElBQUl6SCxJQUFJLENBQUM1VSxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQUEsSUFBQXNnQixTQUFBLEVBQUFDLFNBQUE7UUFBRVAsT0FBTyxFQUFBTSxTQUFBLEdBQUMzUyxNQUFNLENBQUN0SCxLQUFLLENBQUMsY0FBQWlhLFNBQUEsdUJBQWJBLFNBQUEsQ0FBZXpRLFFBQVEsQ0FBQztRQUFFbVEsT0FBTyxFQUFBTyxTQUFBLEdBQUM1UyxNQUFNLENBQUN0SCxLQUFLLENBQUMsY0FBQWthLFNBQUEsdUJBQWJBLFNBQUEsQ0FBZUMsTUFBTSxDQUFDO01BQUUsQ0FBQyxNQUNqRyxJQUFJNUwsSUFBSSxDQUFDNVUsSUFBSSxLQUFLLGNBQWMsSUFBSTROLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEgsS0FBSyxDQUFDLEVBQUVBLEtBQUssQ0FBQzROLE9BQU8sQ0FBQzVOLEtBQUs7UUFBQSxJQUFBb2EsU0FBQTtRQUFBLE9BQUlULE9BQU8sRUFBQVMsU0FBQSxHQUFDOVMsTUFBTSxDQUFDdEgsS0FBSyxDQUFDLGNBQUFvYSxTQUFBLHVCQUFiQSxTQUFBLENBQWVuVyxXQUFXLENBQUM7TUFBQSxFQUFDLENBQUMsS0FDdEgsSUFBSXNLLElBQUksQ0FBQzVVLElBQUksS0FBSyxNQUFNLElBQUk0TixLQUFLLENBQUNDLE9BQU8sQ0FBQ3hILEtBQUssQ0FBQyxFQUFFQSxLQUFLLENBQUM0TixPQUFPLENBQUM1TixLQUFLO1FBQUEsSUFBQXFhLFNBQUE7UUFBQSxPQUFJVixPQUFPLEVBQUFVLFNBQUEsR0FBQy9TLE1BQU0sQ0FBQ3RILEtBQUssQ0FBQyxjQUFBcWEsU0FBQSx1QkFBYkEsU0FBQSxDQUFlOVYsT0FBTyxDQUFDO01BQUEsRUFBQyxDQUFDLEtBQzFHLElBQUlnSyxJQUFJLENBQUM1VSxJQUFJLEtBQUssTUFBTSxFQUFFO1FBQzdCLE1BQU0yZ0IsUUFBUSxHQUFHNVMsR0FBRyxDQUFDSixNQUFNLENBQUNJLEdBQUcsQ0FBQ3lELFdBQVcsRUFBRWxDLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDLENBQUMsRUFBRU8sS0FBSyxDQUFDO1FBQ2hFLElBQUlsQyxLQUFLLENBQUNDLE9BQU8sQ0FBQzhTLFFBQVEsQ0FBQyxFQUFFLEtBQUssTUFBTW5NLEtBQUssSUFBSW1NLFFBQVE7VUFBQSxJQUFBQyxTQUFBO1VBQUUsSUFBSWhULEtBQUssQ0FBQ0MsT0FBTyxFQUFBK1MsU0FBQSxHQUFDalQsTUFBTSxDQUFDNkcsS0FBSyxDQUFDLGNBQUFvTSxTQUFBLHVCQUFiQSxTQUFBLENBQWU1SCxLQUFLLENBQUMsRUFBRSxLQUFLLE1BQU1TLElBQUksSUFBSTlMLE1BQU0sQ0FBQzZHLEtBQUssQ0FBQyxDQUFFd0UsS0FBSyxFQUFlO1lBQUEsSUFBQTZILFNBQUEsRUFBQUMsU0FBQSxFQUFBQyxnQkFBQTtZQUN4SixNQUFNdkgsTUFBTSxJQUFBcUgsU0FBQSxHQUFHbFQsTUFBTSxFQUFBbVQsU0FBQSxHQUFDblQsTUFBTSxDQUFDOEwsSUFBSSxDQUFDLGNBQUFxSCxTQUFBLHVCQUFaQSxTQUFBLENBQWN0SCxNQUFNLENBQUMsY0FBQXFILFNBQUEsY0FBQUEsU0FBQSxHQUFJbFQsTUFBTSxDQUFDOEwsSUFBSSxDQUFDO1lBQzNEdUcsT0FBTyxFQUFBZSxnQkFBQSxHQUFDdkgsTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUUzSixRQUFRLGNBQUFrUixnQkFBQSxjQUFBQSxnQkFBQSxHQUFJdkgsTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUVwVCxRQUFRLENBQUM7WUFBRTRaLE9BQU8sQ0FBQ3hHLE1BQU0sYUFBTkEsTUFBTSx1QkFBTkEsTUFBTSxDQUFFZ0gsTUFBTSxDQUFDO1VBQ3hFO1FBQUM7TUFDSDtJQUNGO0VBQ0Y7RUFDQSxPQUFPVixNQUFNO0FBQ2Y7QUFFQSxTQUFTa0IsYUFBYUEsQ0FBQzNhLEtBQWtCLEVBQVk7RUFDbkQsSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxFQUFFLE9BQU8sQ0FBQ0EsS0FBSyxDQUFDO0VBQzdDLElBQUl1SCxLQUFLLENBQUNDLE9BQU8sQ0FBQ3hILEtBQUssQ0FBQyxFQUFFLE9BQU9BLEtBQUssQ0FBQzRhLE9BQU8sQ0FBQ0QsYUFBYSxDQUFDO0VBQzdELElBQUkzYSxLQUFLLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsRUFBRSxPQUFPekYsTUFBTSxDQUFDaVUsT0FBTyxDQUFDeE8sS0FBSyxDQUFDLENBQUNnTSxNQUFNLENBQUMsQ0FBQyxDQUFDbk4sR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQzhMLFFBQVEsQ0FBQzlMLEdBQUcsQ0FBQyxDQUFDLENBQUMrYixPQUFPLENBQUMsQ0FBQyxHQUFHL0osS0FBSyxDQUFDLEtBQUs4SixhQUFhLENBQUM5SixLQUFLLENBQUMsQ0FBQztFQUM5TixPQUFPLEVBQUU7QUFDWDtBQUNBLE9BQU8sU0FBUzhILDBCQUEwQkEsQ0FBQ0wsVUFBOEMsRUFBMkI7RUFDbEgsT0FBT0EsVUFBVSxDQUFDeFAsUUFBUSxDQUFDeEUsR0FBRyxDQUFDMkUsTUFBTSxJQUFJO0lBQ3ZDLE1BQU12UCxJQUFJLEdBQUcsQ0FBQ3VQLE1BQU0sQ0FBQytELElBQUksRUFBRSxHQUFHMk4sYUFBYSxDQUFDMVIsTUFBTSxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDMFIsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNwRSxPQUFPO01BQUVyUixRQUFRLEVBQUVQLE1BQU0sQ0FBQ0MsRUFBRTtNQUFFZSxJQUFJLEVBQUVoQixNQUFNLENBQUNnQixJQUFJO01BQUUrQyxJQUFJLEVBQUUvRCxNQUFNLENBQUMrRCxJQUFJO01BQUV0VCxJQUFJO01BQUVvaEIsVUFBVSxFQUFFcGhCLElBQUksQ0FBQ3FoQixTQUFTLENBQUMsTUFBTSxDQUFDLENBQUNDLGlCQUFpQixDQUFDLElBQUk7SUFBRSxDQUFDO0VBQ3hJLENBQUMsQ0FBQztBQUNKO0FBQ0E7QUFDQSxPQUFPLFNBQVNDLGdCQUFnQkEsQ0FBQzNDLFVBQTRCLEVBQUU0QyxLQUFhLEVBQTJCO0VBQ3JHLE1BQU1KLFVBQVUsR0FBR0ksS0FBSyxDQUFDSCxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUNDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDalEsSUFBSSxDQUFDLENBQUM7RUFDekUsT0FBTytQLFVBQVUsR0FBR3hDLFVBQVUsQ0FBQ0ksV0FBVyxDQUFDMU0sTUFBTSxDQUFDbVAsS0FBSyxJQUFJQSxLQUFLLENBQUNMLFVBQVUsQ0FBQ25RLFFBQVEsQ0FBQ21RLFVBQVUsQ0FBQyxDQUFDLEdBQUcsRUFBRTtBQUN4RztBQUlBLFNBQVN0Z0IsTUFBTUEsQ0FBSXdGLEtBQVEsRUFBbUI7RUFDNUMsSUFBSUEsS0FBSyxJQUFJLE9BQU9BLEtBQUssS0FBSyxRQUFRLEVBQUU7SUFBRSxLQUFLLE1BQU02USxLQUFLLElBQUl0VyxNQUFNLENBQUNGLE1BQU0sQ0FBQzJGLEtBQUssQ0FBQyxFQUFFeEYsTUFBTSxDQUFDcVcsS0FBSyxDQUFDO0lBQUV0VyxNQUFNLENBQUNDLE1BQU0sQ0FBQ3dGLEtBQUssQ0FBQztFQUFFO0VBQ3pILE9BQU9BLEtBQUs7QUFDZDtBQUNBO0FBQ0EsT0FBTyxlQUFlb2Isd0JBQXdCQSxDQUFDOUMsVUFBNEIsRUFBRS9QLE9BQWtFLEVBQTZDO0VBQzFMLElBQUksQ0FBQ0EsT0FBTyxDQUFDVyxFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQ3dFLElBQUksQ0FBQ25GLE9BQU8sQ0FBQzhTLGNBQWMsQ0FBQyxJQUFJLENBQUNuVCxNQUFNLENBQUN3TixRQUFRLENBQUNjLElBQUksQ0FBQzNCLEtBQUssQ0FBQ3RNLE9BQU8sQ0FBQytTLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxJQUFJeEQsS0FBSyxDQUFDLGlEQUFpRCxDQUFDO0VBQzdMLE1BQU15RCxPQUFPLEdBQUdDLGVBQWUsQ0FBQ2xELFVBQVUsQ0FBQztFQUMzQyxNQUFNbUQsTUFBTSxHQUFHLE1BQU1DLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDRixNQUFNLENBQUMsU0FBUyxFQUFFLElBQUlHLFdBQVcsQ0FBQyxDQUFDLENBQUNDLE1BQU0sQ0FBQ2pILElBQUksQ0FBQ2tILFNBQVMsQ0FBQ1AsT0FBTyxDQUFDLENBQUMsQ0FBQztFQUN2RyxNQUFNakUsV0FBVyxHQUFHLENBQUMsR0FBRyxJQUFJeUUsVUFBVSxDQUFDTixNQUFNLENBQUMsQ0FBQyxDQUFDblgsR0FBRyxDQUFDdEUsS0FBSyxJQUFJQSxLQUFLLENBQUNnYyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUN2TyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUNvTixJQUFJLENBQUMsRUFBRSxDQUFDO0VBQzFHLE9BQU9yZ0IsTUFBTSxDQUFDO0lBQUUsR0FBRytOLE9BQU87SUFBRTBULFNBQVMsRUFBRSxJQUFhO0lBQUUzRSxXQUFXO0lBQUVnQixVQUFVLEVBQUVpRDtFQUFRLENBQUMsQ0FBQztBQUMzRiIsImlnbm9yZUxpc3QiOltdfQ==