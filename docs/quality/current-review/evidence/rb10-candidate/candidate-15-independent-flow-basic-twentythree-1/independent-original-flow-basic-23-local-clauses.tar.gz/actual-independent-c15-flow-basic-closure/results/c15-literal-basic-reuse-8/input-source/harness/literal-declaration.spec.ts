import {test,expect} from '@playwright/test';
import {appURL,nav,backup,durable,digest,evidence} from './common';
import {editData,saveEditor,freshRoundtrip,openRecord} from './extended-support';

test('AT-F37 literal new work and drafts: declare one life enum, affinity integer and unknown boolean through normal registration, refuse wrong type/outside value, cold/new/clone',async({page,browser},info)=>{
  test.setTimeout(240000);
  await page.goto(appURL);await page.getByLabel('作品名',{exact:true}).fill('原F37 新作と下書きの状態登録');await page.getByRole('button',{name:'作品を作成',exact:true}).click();await expect(page.locator('.app-shell')).toBeVisible();
  const empty=await backup(page);expect(empty.parsed.project.entities).toHaveLength(0);
  async function declare(name:string,data:Record<string,unknown>){
    await nav(page,/^資料/);await page.getByLabel('情報の種類',{exact:true}).selectOption('variable');await page.getByRole('button',{name:'状態変数を追加',exact:true}).first().click();
    await page.getByRole('dialog').getByLabel('名前',{exact:true}).fill(name);await page.getByRole('dialog').getByRole('button',{name:'編集を始める'}).click();await expect(page.locator('#entity-name')).toHaveValue(name);
    await editData(page,value=>Object.assign(value,data));await saveEditor(page);
  }
  await declare('生存',{key:'life',valueType:'enum',scope:'across_runs',initial:{type:'enum',value:'存命'},allowed:{values:['存命','死亡']}});
  await expect(page.getByRole('region',{name:'同義語・反対語の状態候補',exact:true})).toContainText('存命／死亡');
  await declare('好感度',{key:'affinity',valueType:'integer',scope:'run',initial:{type:'integer',value:0},allowed:{min:0,max:10}});
  await declare('未設定boolean',{key:'unsettled',valueType:'boolean',scope:'run',initial:{type:'unknown',value:null,reason:'作者の下書きで未設定'},allowed:{values:[false,true]}});
  const registered=await backup(page),variables=registered.parsed.project.entities.filter(e=>e.kind==='variable');expect(variables).toHaveLength(3);
  const life=variables.find(e=>e.name==='生存')!,unknown=variables.find(e=>e.name==='未設定boolean')!;
  expect(life.data).toMatchObject({valueType:'enum',initial:{type:'enum',value:'存命'},allowed:{values:['存命','死亡']}});expect(unknown.data.initial).toEqual({type:'unknown',value:null,reason:'作者の下書きで未設定'});
  await openRecord(page,'variable','生存');const before=await durable(page);const raw=await editData(page,value=>{value.initial={type:'integer',value:1};});const wrongType=await raw.inputValue();
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);expect(await durable(page)).toEqual(before);await expect(raw).toHaveValue(wrongType);
  await nav(page,/^構成/);await openRecord(page,'variable','生存');await page.locator('details.advanced-details').filter({has:page.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true})}).locator('summary').click();await expect(page.getByRole('textbox',{name:'詳細データ',exact:true})).toHaveValue(wrongType);
  const outside=await editData(page,value=>{value.initial={type:'enum',value:'未定義の生存値'};});const outsideRaw=await outside.inputValue();await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/値|許容|候補/);expect(await durable(page)).toEqual(before);await expect(outside).toHaveValue(outsideRaw);
  await editData(page,value=>{value.initial={type:'enum',value:'死亡'};});await saveEditor(page);await page.reload();await expect(page.locator('.app-shell')).toBeVisible();const cold=await backup(page);
  expect(cold.parsed.project.entities.find(e=>e.id===life.id)?.data).toMatchObject({initial:{type:'enum',value:'死亡'}});expect(cold.parsed.project.entities.find(e=>e.id===unknown.id)?.data).toMatchObject({initial:{type:'unknown',value:null}});
  const fresh=await freshRoundtrip(browser,cold.bytes),clone=await freshRoundtrip(browser,cold.bytes,'clone');expect(fresh.parsed.project).toEqual(cold.parsed.project);expect(clone.parsed.project.entities.filter(e=>e.kind==='variable')).toHaveLength(3);
  await evidence(info,'F37-normal-new-declaration',{given:{normalNewWork:true,initialEntityCount:0,draftsCreatedThroughNormalDialog:true},when:{ordinaryRegisteredLifeEnum:['存命','死亡'],affinityInteger:0,booleanUnknown:true,wrongTypeAndOutsideValueActuallyRefused:true},then:{oneLifeVariableOnly:true,unknownNeverBecameFalse:true,coldStableIDs: variables.map(e=>e.id),newAndClone:true},negative:{meaningCandidateObserved:true,wrongInputRetainedThroughNavigation:true,canonicalNativeRowsUnchanged:true,explicitRepairRequired:true},archiveSHA256:digest(cold.bytes),layer:'normal production App/native IndexedDB',physical:'not_run',actualAuth:'not_run'});
});
