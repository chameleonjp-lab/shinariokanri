"""Own C15 durable correctness supervisor; launch only after parent OPEN.
Does not run performance, change candidate files, or certify acceptance.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, shutil, signal, subprocess, sys, time
ROOT = Path(__file__).resolve().parent
EXPECTED = ('6ed5654ca6226061a48651dd317ce1a922c5d07b', '2e1650180b7769e8a2e59a6a01510c8d64bdac8b', 'd0fc32b97242aa86b09f')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp(p, value):
    tmp = p.with_name(p.name + '.writing')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    os.replace(tmp, p)
def manifest(p, relative=None):
    return {'file': str(relative or p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['type', 'browser'])
parser.add_argument('run')
parser.add_argument('--spec', default='f58-original.spec.ts')
parser.add_argument('--type-binding', default='type-success-6.json')
parser.add_argument('--fixture', action='append', default=[])
parser.add_argument('--worker', action='store_true')
a = parser.parse_args()
assert os.environ.get('REVIEW_EXECUTION_WINDOW') == 'open', 'Parent OPEN required; never open itself on a timer'
assert a.run and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in a.run)
binding = json.loads((ROOT/'candidate-binding.json').read_text())
assert (binding['commit'], binding['tree'], binding['buildInfo']['version']) == EXPECTED
assert binding['dirty'] is False and binding['phase'] == 'clean_fixed_candidate_independent_review'
DEST = ROOT/'supervised'/a.run
status = DEST/'STATUS.json'; log = DEST/'supervisor.raw.log'
if not a.worker:
    assert not DEST.exists(), 'Retain every attempt under a new run ID'
    DEST.mkdir(parents=True)
    launch = DEST/'launch-inputs'; launch.mkdir()
    entries = []
    files = ['supervise.py', 'run.mjs', 'server.mjs', 'playwright.config.ts', 'package.json', 'tsconfig.json', 'ORIGINAL_CONTRACTS.json', 'candidate-binding.json', 'PARENT_BINDING.json']
    files += ['harness/'+p.name for p in sorted((ROOT/'harness').iterdir()) if p.is_file()]
    files += [x['file'] for x in binding['distFiles']] + [x['file'] for x in binding.get('generatedInputs', [])]
    files += [str(p.relative_to(ROOT)) for d in ['old-c11-dist', 'preparation-history/c11-c15-real-update', 'regression-inputs'] for p in sorted((ROOT/d).rglob('*')) if p.is_file()]
    for file in files:
        source = (ROOT/'candidate'/file) if file.startswith(('dist/', 'src/portable/generated/')) else ROOT/file
        dest = launch/file; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, dest)
        assert sha(dest) == sha(source)
        entries.append(manifest(dest, file))
    fixture_entries=[]
    for i, file in enumerate(a.fixture):
        source=Path(file).resolve(); assert str(source).startswith(('/workspace/', '/tmp/')) and source.is_file()
        dest=launch/'external-fixtures'/str(i)/source.name; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, dest)
        assert sha(dest)==sha(source)
        fixture_entries.append({'source': str(source), **manifest(dest, str(dest.relative_to(launch)))})
    stamp(DEST/'LAUNCH_INPUTS.json', {'commit':EXPECTED[0], 'tree':EXPECTED[1], 'build':EXPECTED[2], 'recordedAt':now(), 'mode':a.mode, 'run':a.run, 'entries':entries, 'fixtures':fixture_entries, 'inference':'Input capture only; no test or performance result inferred'})
    worker_args=[sys.executable, str(ROOT/'supervise.py'), a.mode, a.run, '--spec', a.spec, '--type-binding', a.type_binding, '--worker']
    for file in a.fixture: worker_args += ['--fixture', file]
    with log.open('xb') as stream:
        worker=subprocess.Popen(worker_args, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)
    stamp(DEST/'LAUNCH.json', {'startedAt':now(), 'ownedSupervisorPID':worker.pid, 'ownedProcessGroup':worker.pid, 'workerCommand':worker_args, 'statusPath':str(status), 'log':str(log), 'wholeCasePassesInferred':0})
    print(json.dumps({'run':a.run, 'ownedSupervisorPID':worker.pid, 'ownedProcessGroup':worker.pid, 'statusPath':str(status), 'log':str(log)})); sys.exit(0)
assert os.getpgrp()==os.getpid(), 'Worker must own an isolated process group'
assert (DEST/'LAUNCH_INPUTS.json').exists()
record={'commit':EXPECTED[0], 'tree':EXPECTED[1], 'build':EXPECTED[2], 'mode':a.mode, 'run':a.run, 'startedAt':now(), 'ownedSupervisorPID':os.getpid(), 'ownedProcessGroup':os.getpgrp(), 'status':'running_unadjudicated', 'clockAccelerated':False, 'physical':'not_run', 'actualAuth':'not_run', 'wholeCasePassesInferred':0, 'inputCaptureSHA256':sha(DEST/'LAUNCH_INPUTS.json'), 'compiledArtifactsScope':'Isolated Playwright transform cache; existence is not proof every cache entry executed', 'lastHeartbeatAt':now()}
env=os.environ.copy(); env.update(REVIEW_RUN=a.run, REVIEW_SPEC=a.spec, REVIEW_TYPE_BINDING=a.type_binding, PWTEST_CACHE_DIR=str(DEST/'actual-transform-cache'), REVIEW_SERVER_STATUS_FILE=str(DEST/'SERVER_STATUS.json'))
command=['node',str(ROOT/'run.mjs'),a.mode]; record['command']=command; stamp(status,record)
child=None
try:
    child=subprocess.Popen(command,cwd=ROOT,env=env,close_fds=True)
    record['ownedNodePID']=child.pid; stamp(status,record)
    while child.poll() is None:
        record['lastHeartbeatAt']=now()
        result=ROOT/'results'/a.run
        record['runnerInputsPresent']=(result/'INPUTS.json').exists()
        record['rawLogBytes']=(result/'raw.in-progress.log').stat().st_size if (result/'raw.in-progress.log').exists() else 0
        if (DEST/'SERVER_STATUS.json').exists():
            try: record['server']=json.loads((DEST/'SERVER_STATUS.json').read_text())
            except (OSError,json.JSONDecodeError): pass
        stamp(status,record); time.sleep(1)
    record['exitCode']=child.returncode; record['finishedAt']=now(); record['status']='process_finished_unadjudicated'
    result=ROOT/'results'/a.run
    record['runnerFinishedBindingPresent']=(result/'EXECUTION_BINDING.json').exists()
    record['runnerBindingSHA256']=sha(result/'EXECUTION_BINDING.json') if record['runnerFinishedBindingPresent'] else None
    for item in json.loads((DEST/'LAUNCH_INPUTS.json').read_text())['entries']:
        captured=DEST/'launch-inputs'/item['file']; assert sha(captured)==item['sha256']
    compiled=[]
    cache=DEST/'actual-transform-cache'
    if cache.exists():
        for p in sorted(cache.rglob('*')):
            if p.is_file(): compiled.append(manifest(p,str(p.relative_to(DEST))))
    stamp(DEST/'COMPILED_ARTIFACTS.json', {'scope':record['compiledArtifactsScope'], 'run':a.run, 'commit':EXPECTED[0], 'files':compiled})
    record['compiledArtifactsManifestSHA256']=sha(DEST/'COMPILED_ARTIFACTS.json'); stamp(status,record)
except BaseException as exc:
    record['status']='supervisor_failed_unadjudicated'; record['recordedAt']=now(); record['errorType']=type(exc).__name__; record['errorMessage']=str(exc); record['childExitCode']=child.poll() if child else None; stamp(status,record); raise
print(json.dumps({'run':a.run,'status':record['status'],'exitCode':record.get('exitCode'),'finishedBindingPresent':record.get('runnerFinishedBindingPresent'),'wholeCasePassesInferred':0}),flush=True)
