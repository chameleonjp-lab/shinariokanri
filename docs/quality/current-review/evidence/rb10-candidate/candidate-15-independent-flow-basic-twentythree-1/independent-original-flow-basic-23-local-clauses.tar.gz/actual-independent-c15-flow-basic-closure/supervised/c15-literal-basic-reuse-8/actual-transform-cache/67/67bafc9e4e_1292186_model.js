// 05e3b137ce2680f293fb90d23f6748d7d5ac5b4c
import { resolvePinnedWorlds } from './pinnedWorlds';
import { resolveReuseContent, reuseValidationIssues } from './reuse';
import { FORMAT_VERSION } from './types';
import { GREGORIAN_CALENDAR, compareTicks, isTick, parseTick, validateCalendar, validateEventTimes, sameCalendarDefinition } from './time';
import { validateTemplateAssignments, validateTemplateDefinition } from './templates';
export const KIND_LABELS = {
  character: '人物',
  group: 'グループ',
  event: '出来事',
  place: '場所',
  item: '物品',
  note: 'メモ',
  chapter: '章',
  scene: '場面',
  goal: '目標',
  flow_node: '進行ノード',
  flow_edge: '進行線',
  flow_graph: '分岐図',
  dialogue_line: '台詞',
  quest: 'クエスト',
  lore: '設定',
  variable: '状態変数',
  effect: '効果',
  assertion: '事実・認識',
  foreshadow: '伏線',
  disclosure: '手掛かり・回収',
  checkpoint: '途中開始点',
  trace: '試読記録',
  attachment: '添付素材',
  source: '資料・出所',
  cue: '演出',
  storyboard_frame: '絵コンテ',
  localization: '翻訳',
  recording: '収録',
  terminology: '用語',
  map: '地図',
  travel_route: '移動経路',
  template: '雛形',
  collection: '一覧',
  review: 'レビュー',
  creative_brief: '企画',
  decision: '制作判断',
  gameplay_spec: 'ゲーム仕様',
  production_task: '制作タスク',
  media_variant: '媒体版',
  voice_rule: '口調',
  external_contract: '外部契約',
  snapshot: '公開版',
  projection_profile: '公開投影'
};
export const ENTITY_KINDS = Object.keys(KIND_LABELS);
export const STATUSES = ['confirmed', 'provisional', 'needs_review', 'rejected', 'alternate'];
export const SCOPES = ['scene', 'chapter', 'character', 'run', 'across_runs'];
export const RELATION_TYPES = [{
  key: 'trust',
  label: '信頼',
  fromKinds: ['character'],
  toKinds: ['character'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'causes',
  label: '因果',
  fromKinds: ['event'],
  toKinds: ['event'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'requires',
  label: '前提',
  fromKinds: ENTITY_KINDS,
  toKinds: ENTITY_KINDS,
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'foreshadow_payoff',
  label: '手掛かり→回収',
  fromKinds: ['disclosure'],
  toKinds: ['disclosure'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'parent_of',
  label: '親子',
  fromKinds: ['character'],
  toKinds: ['character'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'event_foreshadow',
  label: '出来事の予告',
  fromKinds: ['event'],
  toKinds: ['event'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'event_payoff',
  label: '出来事の回収',
  fromKinds: ['event'],
  toKinds: ['event'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'mentor_of',
  label: '師弟',
  fromKinds: ['character'],
  toKinds: ['character'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'bloodline',
  label: '血統',
  fromKinds: ['character'],
  toKinds: ['character'],
  allowSelf: false,
  allowSymmetric: false
}, {
  key: 'related',
  label: '関連',
  fromKinds: ENTITY_KINDS,
  toKinds: ENTITY_KINDS,
  allowSelf: false,
  allowSymmetric: true
}, {
  key: 'reference',
  label: '参照',
  fromKinds: ENTITY_KINDS,
  toKinds: ENTITY_KINDS,
  allowSelf: true,
  allowSymmetric: false
}];
export const RELATION_LABELS = Object.fromEntries(RELATION_TYPES.map(type => [type.key, type.label]));
export const ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export const REVISION_PATTERN = /^(?:0|[1-9][0-9]*)$/;
export const emptyValidity = () => ({
  worldRange: null,
  routeCondition: null,
  presentationAnchor: null
});
export const newId = () => crypto.randomUUID();
export function textToRichText(text) {
  return text === '' ? [] : text.split('\n').map(line => ({
    id: newId(),
    kind: 'paragraph',
    text: line
  }));
}
export function richTextToPlainText(text) {
  return (text !== null && text !== void 0 ? text : []).map(block => block.text).join('\n');
}
export function getEntity(project, id) {
  return project.entities.find(entity => entity.id === id && !entity.deletedAt);
}
export function getEntitiesByKind(project, kind) {
  return project.entities.filter(entity => entity.kind === kind && !entity.deletedAt);
}
export function defaultData(kind) {
  // A required reference stays null in an unsaved editor draft; no fake ID is generated.
  const unknown = {
    type: 'unknown',
    value: null,
    reason: '未入力'
  };
  const data = {
    character: {
      reading: '',
      aliases: [],
      summary: [],
      body: [],
      authorNotes: [],
      goals: [],
      voiceRules: []
    },
    group: {
      groupType: 'display',
      members: [],
      parentId: null,
      summary: []
    },
    event: {
      summary: [],
      time: {
        mode: 'unknown',
        reason: ''
      },
      laneRole: 'common',
      participants: [],
      locationId: null,
      itemIds: [],
      authorNotes: [],
      constraints: []
    },
    place: {
      parentId: null,
      reading: '',
      aliases: [],
      body: [],
      mapIds: [],
      changes: []
    },
    item: {
      itemMode: 'type',
      typeId: null,
      body: [],
      properties: null,
      changes: []
    },
    note: {
      body: [],
      attachmentIds: [],
      convertedToIds: [],
      originNoteId: null
    },
    chapter: {
      sceneIds: [],
      summary: [],
      authorNotes: [],
      structureRole: ''
    },
    scene: {
      summary: [],
      body: [],
      authorNotes: [],
      eventIds: [],
      chapterId: null,
      threadIds: [],
      povId: null,
      goals: [],
      conflicts: [],
      results: [],
      newInformation: [],
      tension: null,
      importance: null,
      blockIds: []
    },
    goal: {
      ownerId: null,
      description: [],
      changes: [],
      evidenceSceneIds: [],
      validity: emptyValidity()
    },
    flow_node: {
      nodeType: 'choice',
      sceneId: null,
      childGraphId: null,
      terminalReason: '',
      gate: {
        op: 'constant',
        value: true
      },
      executionPolicy: 'manual_choice',
      fallbackId: null
    },
    flow_edge: {
      fromId: null,
      toId: {
        unresolved: {
          label: '',
          reason: '未完成'
        }
      },
      edgeType: 'choice',
      label: '',
      condition: {
        op: 'constant',
        value: true
      },
      effectIds: [],
      priority: 0,
      choiceLineId: null
    },
    flow_graph: {
      nodeIds: [],
      edgeIds: [],
      entryIds: [],
      exitIds: [],
      parentGraphId: null,
      parameters: []
    },
    dialogue_line: {
      text: [],
      speakerId: null,
      choiceEdgeId: null,
      cueIds: [],
      originLineIds: []
    },
    quest: {
      key: '',
      stateVariableId: null,
      description: [],
      flowIds: [],
      transitionRules: [],
      gameplaySpecIds: []
    },
    lore: {
      body: [],
      assertionIds: [],
      sourceIds: [],
      reading: '',
      aliases: []
    },
    variable: {
      key: '',
      valueType: 'boolean',
      scope: 'run',
      initial: unknown,
      allowed: {
        values: [false, true]
      },
      description: [],
      ownerId: null,
      externalContractId: null,
      resetRules: [],
      transitionRules: [],
      externalUseDeclared: false
    },
    effect: {
      operation: 'set',
      targetId: null,
      value: unknown,
      condition: {
        op: 'constant',
        value: true
      },
      instanceId: null,
      reason: ''
    },
    assertion: {
      subjectId: null,
      predicate: '',
      value: unknown,
      truthKind: 'author_truth',
      holderId: null,
      sourceIds: [],
      evidenceLocation: null,
      validity: emptyValidity(),
      reason: ''
    },
    foreshadow: {
      question: [],
      intent: [],
      resolutionPolicy: 'undecided',
      truthAssertionIds: [],
      clueIds: [],
      payoffIds: [],
      requiredInfo: [],
      deadline: null,
      exceptions: []
    },
    disclosure: {
      foreshadowId: null,
      anchor: {
        entityId: null
      },
      stage: 'hint',
      role: 'clue',
      condition: {
        op: 'constant',
        value: true
      },
      knowledgeEffects: [],
      targetScope: null
    },
    checkpoint: {
      contentVersionId: null,
      runtimeState: emptyRuntimeState(''),
      origin: 'partial',
      traceId: null
    },
    trace: {
      contentVersionId: null,
      startCheckpointId: null,
      steps: [],
      seed: '',
      engineVersion: '1.0.0',
      externalMode: 'stub'
    },
    attachment: {
      mediaType: '',
      contentHash: '',
      byteSize: 0,
      assetPath: '',
      displayName: '',
      stage: 'reference',
      revisionHistory: []
    },
    source: {
      sourceType: 'web',
      locator: '',
      accessedAt: null,
      excerptLocation: '',
      interpretation: [],
      attachmentId: null,
      redistributionAllowed: false
    },
    cue: {
      anchor: {
        entityId: null
      },
      cueType: '',
      attachmentId: null,
      speakerId: null,
      expression: '',
      waitMs: null,
      camera: null,
      mediaTime: null,
      stage: ''
    },
    storyboard_frame: {
      anchor: {
        entityId: null
      },
      mediaStartMs: 0,
      mediaEndMs: null,
      referenceAssetId: null,
      finalAssetId: null,
      cueIds: [],
      caption: []
    },
    localization: {
      sourceLineId: null,
      language: '',
      sourceHash: '',
      text: [],
      stage: 'draft',
      reviewedBy: null,
      recordingIds: []
    },
    recording: {
      sourceLineId: null,
      language: '',
      sourceHash: '',
      translationId: null,
      attachmentId: null,
      notes: [],
      stage: 'planned',
      reviewedBy: null
    },
    terminology: {
      canonical: '',
      reading: '',
      variants: [],
      language: null,
      usageNotes: [],
      validity: emptyValidity(),
      exceptions: [],
      voiceOwnerId: null
    },
    map: {
      placeId: null,
      coordinateSystem: 'normalized',
      attachmentId: null,
      parentMapId: null,
      pins: []
    },
    travel_route: {
      fromPlaceId: null,
      toPlaceId: null,
      direction: 'one_way',
      method: '',
      minimumTicks: null,
      maximumTicks: null,
      evidence: [],
      validity: emptyValidity()
    },
    template: {
      targetKind: 'character',
      fields: [],
      description: '',
      version: '0',
      defaults: {}
    },
    collection: {
      mode: 'fixed',
      memberIds: [],
      query: null,
      sort: {
        field: 'name',
        direction: 'asc'
      }
    },
    review: {
      target: null,
      targetVersionId: null,
      body: [],
      stage: 'open',
      assigneeId: null,
      quotedText: '',
      resolution: []
    },
    creative_brief: {
      targetAudience: [],
      experience: [],
      theme: [],
      tone: [],
      scope: [],
      deliverableIds: [],
      decisionIds: []
    },
    decision: {
      subject: '',
      reason: [],
      targetVersionId: null,
      outcome: 'deferred',
      priority: '',
      requirementIds: [],
      reviewIds: []
    },
    gameplay_spec: {
      sceneId: null,
      action: [],
      mechanic: '',
      tutorial: [],
      reward: null,
      questId: null,
      taskIds: [],
      intentionalDifference: ''
    },
    production_task: {
      targetIds: [],
      stage: 'writing',
      progress: 'todo',
      assigneeId: null,
      deadline: null,
      dependsOn: [],
      estimate: null,
      blockingReason: ''
    },
    media_variant: {
      medium: 'novel',
      baseSnapshotId: null,
      body: [],
      releaseAt: null,
      projectionProfileId: null,
      sourceIds: [],
      needsReview: false
    },
    voice_rule: {
      characterId: null,
      validity: emptyValidity(),
      firstPerson: '',
      addressing: '',
      phrasing: '',
      examples: [],
      exceptions: []
    },
    external_contract: {
      key: '',
      owner: 'tool',
      inputType: 'boolean',
      outputType: 'boolean',
      missingPolicy: 'unknown',
      description: [],
      stubValues: [],
      adapterProfileIds: [],
      version: '1.0.0'
    },
    snapshot: {
      versionLabel: '',
      contentHash: '',
      immutable: true,
      parentVersionIds: [],
      releasedAt: null,
      referencedWorldVersionIds: []
    },
    projection_profile: {
      audience: '',
      includedIds: [],
      namePolicy: {
        mode: 'exclude'
      },
      allowedKinds: [],
      excludedFields: ['authorNotes'],
      routeScope: null,
      includeAuthorNotes: false,
      publicTitle: '',
      publicTexts: {},
      allowedRelationIds: [],
      idPolicy: 'remap'
    }
  };
  if (!(kind in data)) throw new RangeError('未対応の情報種別です。');
  return data[kind];
}
export function createEntity(projectId, kind, name = '', data) {
  const now = new Date().toISOString();
  return {
    id: newId(),
    projectId,
    kind,
    revision: '0',
    name,
    status: 'provisional',
    visibility: 'private',
    createdAt: now,
    updatedAt: now,
    customValues: {},
    data: {
      ...defaultData(kind),
      ...data
    }
  };
}
export function createProject(name = '新しい作品') {
  return {
    projectId: newId(),
    name,
    formatVersion: FORMAT_VERSION,
    revision: '0',
    calendarId: GREGORIAN_CALENDAR.id,
    mainStart: '0',
    calendars: [structuredClone(GREGORIAN_CALENDAR)],
    worldReferences: [],
    entities: [],
    relations: [],
    snapshots: [],
    history: [],
    views: []
  };
}
export function emptyRuntimeState(contentVersionId) {
  return {
    contentVersionId,
    variableValues: {},
    itemInstances: [],
    assertions: [],
    seenIds: [],
    visitCounts: {},
    onceTriggers: [],
    rngSeed: 'scenario-1',
    rngPosition: 0,
    callStack: [],
    presentationPosition: null,
    loopNumber: 0,
    provenance: 'full_play'
  };
}
export function createDemoProject() {
  const project = createProject('霧の門 — サンプル作品'),
    id = project.projectId;
  const ao = createEntity(id, 'character', 'アオ', {
    reading: 'あお',
    summary: textToRichText('消えた父を探す、記録係の少女。')
  });
  const guard = createEntity(id, 'character', '門番', {
    reading: 'もんばん',
    summary: textToRichText('霧の門を守る人物。本名はまだ明かされていない。')
  });
  const gate = createEntity(id, 'place', '霧の門', {
    reading: 'きりのもん',
    body: textToRichText('町の北端。夜になると扉の文字が浮かび上がる。')
  });
  const event = createEntity(id, 'event', '父が鍵を隠した日', {
    summary: textToRichText('父は古い鍵を記録庫へ残した。'),
    time: {
      mode: 'instant',
      at: '-10',
      calendarId: project.calendarId
    },
    laneRole: 'common',
    locationId: gate.id
  });
  const key = createEntity(id, 'variable', '鍵を持っている', {
    key: 'has_key',
    valueType: 'boolean',
    initial: {
      type: 'boolean',
      value: false
    }
  });
  const affection = createEntity(id, 'variable', '門番からの信頼', {
    key: 'guard_trust',
    valueType: 'integer',
    initial: {
      type: 'integer',
      value: 0
    },
    allowed: {
      min: -10,
      max: 10
    }
  });
  const scene1 = createEntity(id, 'scene', '古い記録', {
    summary: textToRichText('アオは記録庫で、父の筆跡を見つける。'),
    body: textToRichText('「まだ、ここにいたんだね」\n埃に埋もれた本の間から、小さな鍵が落ちた。'),
    eventIds: [event.id],
    povId: ao.id,
    tension: 3
  });
  const scene2 = createEntity(id, 'scene', '霧の門', {
    summary: textToRichText('鍵を得た道と、記録を飛ばした道が合流する。'),
    body: textToRichText('門番は掌を差し出した。\n「扉は、記憶を持つ者にしか開かない」'),
    povId: ao.id,
    tension: 7
  });
  const chapter = createEntity(id, 'chapter', '第一章　残された記憶', {
    sceneIds: [scene1.id, scene2.id],
    summary: textToRichText('古い記録を読むかどうかで、門の先に進めるかが変わる。')
  });
  scene1.data.chapterId = chapter.id;
  scene2.data.chapterId = chapter.id;
  const entry = createEntity(id, 'flow_node', '記録を読むか', {
    nodeType: 'choice',
    executionPolicy: 'manual_choice'
  });
  const read = createEntity(id, 'flow_node', '古い記録を提示', {
    nodeType: 'automatic',
    sceneId: scene1.id,
    executionPolicy: 'first_match'
  });
  const merge = createEntity(id, 'flow_node', '同じ門へ合流', {
    nodeType: 'choice',
    sceneId: scene2.id,
    executionPolicy: 'manual_choice'
  });
  const reveal = createEntity(id, 'flow_node', '門の先へ', {
    nodeType: 'terminal',
    terminalReason: '鍵を使い、父の足跡をたどる。'
  });
  const stay = createEntity(id, 'flow_node', '町へ戻る', {
    nodeType: 'terminal',
    terminalReason: '手掛かりを探し直す、意図した別の結末。'
  });
  const setKey = createEntity(id, 'effect', '鍵を得る', {
    operation: 'set',
    targetId: key.id,
    value: {
      type: 'boolean',
      value: true
    }
  });
  const gainTrust = createEntity(id, 'effect', '信頼が増える', {
    operation: 'add',
    targetId: affection.id,
    value: {
      type: 'integer',
      value: 1
    }
  });
  const question = createEntity(id, 'foreshadow', '門を開く鍵はどこか', {
    question: textToRichText('門を開く鍵はどこか？'),
    intent: textToRichText('父の記録と門の意味を結ぶ。'),
    resolutionPolicy: 'this_work'
  });
  const clue = createEntity(id, 'disclosure', '鍵の記録', {
    foreshadowId: question.id,
    anchor: {
      entityId: read.id
    },
    role: 'clue',
    stage: 'hint'
  });
  const payoff = createEntity(id, 'disclosure', '門の真相', {
    foreshadowId: question.id,
    anchor: {
      entityId: reveal.id
    },
    role: 'payoff',
    stage: 'reveal'
  });
  question.data.clueIds = [clue.id];
  question.data.payoffIds = [payoff.id];
  question.data.requiredInfo = [clue.id];
  const seeClue = createEntity(id, 'effect', '手掛かりを提示', {
    operation: 'mark_seen',
    targetId: clue.id,
    value: null
  });
  const seePayoff = createEntity(id, 'effect', '真相を提示', {
    operation: 'mark_seen',
    targetId: payoff.id,
    value: null
  });
  const edges = [createEntity(id, 'flow_edge', '鍵と記録を調べる', {
    fromId: entry.id,
    toId: read.id,
    label: '鍵と記録を調べる',
    effectIds: [setKey.id, gainTrust.id, seeClue.id]
  }), createEntity(id, 'flow_edge', '記録を飛ばす', {
    fromId: entry.id,
    toId: merge.id,
    label: '記録を飛ばす'
  }), createEntity(id, 'flow_edge', '門へ向かう', {
    fromId: read.id,
    toId: merge.id,
    edgeType: 'automatic',
    priority: 1
  }), createEntity(id, 'flow_edge', '鍵で門を開く', {
    fromId: merge.id,
    toId: reveal.id,
    label: '鍵で門を開く',
    condition: {
      op: 'compare',
      variableId: key.id,
      comparator: 'eq',
      value: {
        type: 'boolean',
        value: true
      }
    },
    effectIds: [seePayoff.id]
  }), createEntity(id, 'flow_edge', '町へ戻る', {
    fromId: merge.id,
    toId: stay.id,
    label: '町へ戻る'
  })];
  const graph = createEntity(id, 'flow_graph', '霧の門の分岐', {
    nodeIds: [entry.id, read.id, merge.id, reveal.id, stay.id],
    edgeIds: edges.map(e => e.id),
    entryIds: [entry.id],
    exitIds: [reveal.id, stay.id]
  });
  const line = createEntity(id, 'dialogue_line', '', {
    speakerId: guard.id,
    text: textToRichText('扉は、記憶を持つ者にしか開かない。')
  });
  const task = createEntity(id, 'production_task', '門の場面を見直す', {
    targetIds: [scene2.id],
    stage: 'review',
    progress: 'todo'
  });
  project.entities = [ao, guard, gate, event, key, affection, scene1, scene2, chapter, entry, read, merge, reveal, stay, setKey, gainTrust, question, clue, payoff, seeClue, seePayoff, ...edges, graph, line, task];
  project.entities.forEach(entity => {
    entity.status = 'confirmed';
  });
  project.relations = [{
    id: newId(),
    projectId: id,
    revision: '0',
    fromId: ao.id,
    toId: guard.id,
    relationType: 'trust',
    direction: 'forward',
    validity: emptyValidity(),
    evidenceIds: [scene2.id],
    status: 'provisional',
    visibility: 'private'
  }];
  return project;
}
const txt = (min = 0, max) => ({
  type: 'text',
  min,
  max,
  maxBytes: 1024 * 1024
});
const short = txt(0, 128),
  key = txt(1, 128);
const num = (min, max, integer = false) => ({
  type: 'number',
  min,
  max,
  integer
});
const bool = {
    type: 'boolean'
  },
  idSchema = {
    type: 'id'
  },
  tick = {
    type: 'tick'
  },
  typed = {
    type: 'typed'
  };
const en = (...values) => ({
  type: 'enum',
  values
});
const ref = (...kinds) => ({
  type: 'ref',
  kinds: kinds.length ? kinds : undefined,
  scope: 'entity'
});
const scopedRef = scope => ({
  type: 'ref',
  scope
});
const arr = (item, unique = false, min, max) => ({
  type: 'array',
  item,
  unique,
  min,
  max
});
const refs = (...kinds) => arr(ref(...kinds), true);
const obj = fields => ({
  type: 'object',
  fields
});
const req = schema => ({
  schema,
  required: true
});
const opt = schema => ({
  schema,
  nullable: true
});
const optionalValue = schema => ({
  schema,
  nullable: false
});
const rich = {
    type: 'richtext'
  },
  summary = {
    type: 'richtext',
    max: 2048
  };
const cond = {
    type: 'condition'
  },
  time = {
    type: 'time'
  };
const record = (value, recordKey) => ({
  type: 'record',
  value,
  key: recordKey
});
const union = (...choices) => ({
  type: 'union',
  choices
});
const anchor = obj({
  entityId: req(ref()),
  blockId: opt(scopedRef('block')),
  lineId: opt(ref('dialogue_line')),
  start: opt(num(0, undefined, true)),
  end: opt(num(0, undefined, true)),
  sourceVersionId: opt(scopedRef('snapshot')),
  positionStatus: opt(en('unresolved')),
  positionReason: opt(txt(1)),
  quotedText: opt(txt())
});
const unresolvedTextAnnotation = union(obj({
  kind: req(en('ruby')),
  originalText: req(txt()),
  reason: req(txt(1)),
  reading: req(txt())
}), obj({
  kind: req(en('link')),
  originalText: req(txt()),
  reason: req(txt(1)),
  target: req(anchor)
}));
const nullableValidity = obj({
  worldRange: {
    schema: obj({
      start: {
        schema: tick,
        required: true,
        nullable: true
      },
      end: {
        schema: tick,
        required: true,
        nullable: true
      }
    }),
    required: true,
    nullable: true
  },
  routeCondition: {
    schema: cond,
    required: true,
    nullable: true
  },
  presentationAnchor: {
    schema: anchor,
    required: true,
    nullable: true
  }
});
const targetScope = obj({
  projectId: req(scopedRef('project')),
  graphId: opt(ref('flow_graph')),
  chapterId: opt(ref('chapter')),
  routeCondition: opt(cond),
  targetSnapshotId: opt(scopedRef('snapshot'))
});
const alias = obj({
  id: req(idSchema),
  text: req(txt(1, 128)),
  reading: req(short),
  validity: req(nullableValidity),
  audienceHolderIds: req(refs('character')),
  isPublicDefault: req(bool)
});
const exception = obj({
  reason: req(txt(1)),
  targetScope: req(targetScope),
  validity: req(nullableValidity),
  evidenceIds: req(refs())
});
const transition = obj({
  from: req(typed),
  to: req(typed),
  reason: opt(txt()),
  exception: opt(bool),
  exceptionDetails: opt(exception)
});
const resetRule = obj({
  on: req(en('scene_end', 'chapter_end', 'run_end', 'new_loop', 'full_reset')),
  value: req(typed),
  reason: opt(txt())
});
const allowed = obj({
  min: opt(num(undefined, undefined, true)),
  max: opt(num(undefined, undefined, true)),
  values: opt(arr(union(txt(), bool), true))
});
const trigger = obj({
  id: opt(idSchema),
  event: req(en('enter', 'talk', 'battle_result', 'manual', 'custom')),
  eventKey: req(txt()),
  repeat: req(en('once', 'repeatable')),
  scope: opt(en(...SCOPES)),
  deadline: opt(time)
});
const reuse = obj({
  mode: req(en('reference', 'clone', 'override')),
  sourceId: req(ref()),
  pinnedSnapshotId: req(scopedRef('snapshot')),
  overrideFields: req(arr(txt(1), true)),
  bindings: opt(record(idSchema, idSchema))
});
const unresolved = obj({
  unresolved: req(obj({
    label: req(txt()),
    reason: req(txt(1))
  }))
});
const runtimeItem = obj({
  instanceId: req(idSchema),
  typeId: req(ref('item')),
  quantity: req(num(0, undefined, true)),
  ownerId: opt(ref('character', 'group')),
  locationId: opt(ref('place')),
  consumed: req(bool),
  reason: opt(txt())
});
const runtimeAssertion = obj({
  assertionId: req(ref('assertion')),
  holderId: opt(ref('character')),
  truth: req(en('true', 'false', 'unknown')),
  sourceEffectId: opt(ref('effect'))
});
const presentationResult = obj({
  targetId: req(ref('flow_node', 'flow_edge', 'disclosure')),
  value: req(en('true', 'false', 'unknown')),
  reasons: req(arr(txt()))
});
const callFrame = obj({
  graphId: req(ref('flow_graph')),
  returnNodeId: req(ref('flow_node')),
  parameters: req(record(typed, key))
});
const runtime = obj({
  contentVersionId: req(scopedRef('snapshot')),
  variableValues: req(record(typed, ref('variable'))),
  itemInstances: req(arr(runtimeItem)),
  assertions: req(arr(runtimeAssertion)),
  seenIds: req(arr(scopedRef('presentation'), true)),
  visitCounts: req(record(num(0, undefined, true), ref())),
  onceTriggers: req(arr(txt(1), true)),
  rngSeed: req(txt(1)),
  rngPosition: req(num(0, undefined, true)),
  callStack: req(arr(callFrame)),
  presentationPosition: opt(ref('flow_node')),
  loopNumber: req(num(0, undefined, true)),
  provenance: req(en('full_play', 'partial', 'imported', 'stub')),
  resetCauses: opt(arr(obj({
    variableId: req(ref('variable')),
    on: req(en('scene_end', 'chapter_end', 'run_end', 'new_loop', 'full_reset')),
    before: req(typed),
    after: req(typed),
    reason: req(txt())
  })))
});
const readingOccurrence = obj({
  entityId: req(ref('scene')),
  occurrenceId: req(txt(1, 256)),
  before: req(runtime),
  after: req(runtime),
  presentationState: opt(runtime),
  conditionResults: req(arr(presentationResult)),
  externalValues: opt(record(typed, ref('external_contract'))),
  worldTick: opt(tick)
});
const readingPath = obj({
  chapterIds: req(refs('chapter')),
  sceneIds: req(arr(ref('scene'))),
  selection: opt(en('chapters', 'scenes')),
  occurrences: req(arr(readingOccurrence))
});
const groupCoverage = obj({
  checked: req(num(0, undefined, true)),
  total: req(num(0, undefined, true))
});
const coverageCount = obj({
  byProvenance: opt(record(groupCoverage, en('full_play', 'partial', 'imported', 'stub'))),
  byExternalMode: opt(record(groupCoverage, en('internal', 'stub', 'actual', 'mixed'))),
  checked: req(num(0, undefined, true)),
  total: req(num(0, undefined, true)),
  excluded: opt(num(0, undefined, true)),
  unknown: opt(num(0, undefined, true))
});
const coverage = obj(Object.fromEntries(['scenes', 'dialogue', 'choices', 'conditionTrue', 'conditionFalse', 'declaredTests'].map(field => [field, req(coverageCount)])));
const fieldDefinition = obj({
  key: req(key),
  label: req(txt(1, 128)),
  type: req(en('text', 'number', 'boolean', 'enum', 'date', 'ref')),
  required: req(bool),
  nullable: req(bool),
  default: {
    schema: {
      type: 'custom'
    },
    required: true,
    nullable: true
  },
  allowedValues: opt(arr(txt(), true)),
  targetKinds: opt(arr(en(...ENTITY_KINDS), true)),
  help: opt(txt())
});
const estimate = obj({
  value: opt(num(0)),
  range: opt(obj({
    min: req(num(0)),
    max: req(num(0))
  })),
  unit: req(txt(1)),
  assumptions: req(arr(txt())),
  scope: req(targetScope),
  unknownCount: req(num(0, undefined, true)),
  source: req(txt()),
  speed: opt(num(Number.MIN_VALUE))
});
const publicText = obj({
  ...Object.fromEntries(['summary', 'body', 'text', 'description', 'question', 'intent', 'caption', 'usageNotes', 'interpretation', 'examples', 'action', 'tutorial'].map(field => [field, opt(rich)])),
  ...Object.fromEntries(['label', 'reading', 'terminalReason', 'reason', 'key', 'canonical', 'language', 'locale', 'sourceHash', 'expression', 'method', 'locator', 'predicate', 'cueType', 'precision', 'displayName', 'relationType', 'eventKey', 'resetReason', 'exclusionReason', 'exceptionReason', 'camera', 'parameters', 'variants', 'estimateAssumptions', 'estimateSource', 'blockingReason', 'mechanic', 'intentionalDifference', 'excerptLocation', 'estimateUnit', 'firstPerson', 'addressing', 'phrasing'].map(field => [field, opt(txt())]))
});

/** Field registry doubles as the reference walker; text is never searched for UUIDs. */
export const ENTITY_SCHEMAS = {
  character: obj({
    reading: opt(short),
    aliases: opt(arr(alias)),
    summary: opt(summary),
    body: opt(rich),
    authorNotes: opt(rich),
    birth: opt(time),
    death: opt(time),
    goals: opt(refs('goal')),
    voiceRules: opt(refs('voice_rule'))
  }),
  group: obj({
    groupType: req(en('display', 'faction', 'plot_thread', 'category')),
    members: opt(refs()),
    parentId: opt(ref('group')),
    summary: opt(summary)
  }),
  event: obj({
    summary: req(summary),
    time: req(time),
    laneRole: req(en('common', 'participants', 'both')),
    participants: opt(arr(obj({
      characterId: req(ref('character')),
      role: req(en('actor', 'witness', 'mentioned', 'informed', 'custom')),
      evidenceIds: opt(refs()),
      knowledgeEffectIds: opt(refs('effect'))
    }))),
    locationId: opt(ref('place')),
    itemIds: opt(refs('item')),
    authorNotes: opt(rich),
    constraints: opt(arr(union(obj({
      type: req(en('before', 'same_start')),
      targetEventId: req(ref('event'))
    }), obj({
      type: req(en('end_gap')),
      targetEventId: req(ref('event')),
      minimumTicks: req(tick),
      maximumTicks: req(tick)
    }))))
  }),
  place: obj({
    parentId: opt(ref('place')),
    reading: opt(short),
    aliases: opt(arr(alias)),
    body: opt(rich),
    mapIds: opt(refs('map')),
    changes: opt(refs('assertion'))
  }),
  item: obj({
    itemMode: req(en('type', 'instance')),
    typeId: opt(ref('item')),
    body: opt(rich),
    properties: opt({
      type: 'custom'
    }),
    changes: opt(refs('assertion'))
  }),
  note: obj({
    handoffReceipt: opt(obj({
      approval: req(obj({
        entityId: req(scopedRef('entity')),
        sourceVersionId: req(scopedRef('snapshot'))
      })),
      sourceVersionId: req(scopedRef('snapshot')),
      verificationVersionId: req(scopedRef('snapshot')),
      profileVersionId: req(scopedRef('snapshot')),
      sourceRevision: req({
        type: 'revision'
      }),
      profileId: req(ref('projection_profile')),
      packageHash: req({
        type: 'hash'
      }),
      receiptHash: req({
        type: 'hash'
      }),
      mode: req(en('stub', 'actual', 'mixed')),
      rawJson: req(txt(1, 1024 * 1024)),
      idMappings: req(arr(obj({
        entityId: req(scopedRef('record')),
        sourceVersionId: req(scopedRef('snapshot')),
        publicId: req(txt(1, 256))
      }))),
      projectionBindings: req(arr(obj({
        entityId: req(scopedRef('projection_record')),
        sourceVersionId: req(scopedRef('snapshot')),
        editionVersionId: req(scopedRef('snapshot')),
        publicId: req(txt(1, 256))
      }))),
      citationBindings: req(arr(obj({
        sourceVersionId: req(scopedRef('snapshot')),
        publicVersionId: req(txt(1, 256))
      }))),
      worldVersions: req(arr(obj({
        sourceVersionId: req(scopedRef('snapshot')),
        contentHash: req({
          type: 'hash'
        })
      })))
    })),
    body: req(rich),
    attachmentIds: opt(refs('attachment')),
    convertedToIds: opt(refs()),
    originNoteId: opt(ref('note'))
  }),
  chapter: obj({
    sceneIds: req(refs('scene')),
    summary: opt(summary),
    authorNotes: opt(rich),
    structureRole: opt(short)
  }),
  scene: obj({
    summary: req(summary),
    body: req(rich),
    authorNotes: req(rich),
    eventIds: req(refs('event')),
    dialogueLineIds: opt(refs('dialogue_line')),
    chapterId: opt(ref('chapter')),
    threadIds: opt(refs('group')),
    povId: opt(ref('character')),
    goals: opt(rich),
    conflicts: opt(rich),
    results: opt(rich),
    newInformation: opt(rich),
    tension: opt(num(0, 10)),
    importance: opt(num(0, 10)),
    blockIds: opt(arr(scopedRef('block'), true)),
    reuse: opt(reuse)
  }),
  goal: obj({
    ownerId: req(ref('character', 'group')),
    description: req(rich),
    changes: opt(refs('assertion')),
    evidenceSceneIds: opt(refs('scene')),
    validity: opt(nullableValidity)
  }),
  flow_node: obj({
    nodeType: req(en('scene', 'choice', 'automatic', 'call', 'entry', 'exit', 'terminal')),
    sceneId: opt(ref('scene')),
    childGraphId: opt(ref('flow_graph')),
    terminalReason: opt(txt()),
    trigger: opt(trigger),
    gate: opt(cond),
    executionPolicy: opt(en('manual_choice', 'first_match', 'all_match')),
    fallbackId: opt(ref('flow_node')),
    reuse: opt(reuse)
  }),
  flow_edge: obj({
    fromId: req(ref('flow_node')),
    toId: req(union(ref('flow_node'), unresolved)),
    edgeType: req(en('choice', 'automatic', 'call_return')),
    label: opt(txt()),
    condition: opt(cond),
    effectIds: opt(refs('effect')),
    priority: opt(num(undefined, undefined, true)),
    choiceLineId: opt(ref('dialogue_line'))
  }),
  flow_graph: obj({
    nodeIds: req(refs('flow_node')),
    edgeIds: req(refs('flow_edge')),
    entryIds: req(refs('flow_node')),
    exitIds: req(refs('flow_node')),
    parentGraphId: opt(ref('flow_graph')),
    parameters: opt(arr(obj({
      key: req(key),
      type: req(en('boolean', 'integer', 'enum')),
      default: opt(typed)
    })))
  }),
  dialogue_line: obj({
    text: req(rich),
    speakerId: opt(ref('character')),
    choiceEdgeId: opt(ref('flow_edge')),
    cueIds: opt(refs('cue')),
    originLineIds: opt(refs('dialogue_line')),
    replacedByLineIds: opt(refs('dialogue_line')),
    lineage: opt(obj({
      mode: req(en('split', 'merge', 'copy')),
      baseRevision: req({
        type: 'revision'
      }),
      reason: req(txt(1)),
      segments: req(arr(obj({
        source: req(anchor),
        target: req(anchor)
      }), false, 1))
    })),
    claimAssertionIds: opt(refs('assertion')),
    assertionIntent: opt(en('statement', 'lie', 'misunderstanding', 'quotation')),
    assertionReason: opt(txt())
  }),
  quest: obj({
    key: req(key),
    stateVariableId: req(ref('variable')),
    description: opt(rich),
    flowIds: opt(refs('flow_graph')),
    transitionRules: opt(arr(transition)),
    gameplaySpecIds: opt(refs('gameplay_spec'))
  }),
  lore: obj({
    body: req(rich),
    assertionIds: opt(refs('assertion')),
    sourceIds: opt(refs('source')),
    reading: opt(short),
    aliases: opt(arr(alias))
  }),
  variable: obj({
    key: req(key),
    valueType: req(en('boolean', 'integer', 'enum')),
    scope: req(en(...SCOPES)),
    initial: req(typed),
    allowed: req(allowed),
    description: opt(rich),
    ownerId: opt(ref('character')),
    derived: opt({
      type: 'expression'
    }),
    externalContractId: opt(ref('external_contract')),
    resetRules: opt(arr(resetRule)),
    transitionRules: opt(arr(transition)),
    exclusions: opt(arr(obj({
      variableId: req(ref('variable')),
      value: req(typed),
      otherValue: req(typed),
      reason: req(txt(1)),
      exceptions: opt(arr(exception))
    }))),
    externalUseDeclared: opt(bool)
  }),
  effect: obj({
    operation: req(en('set', 'add', 'grant', 'consume', 'move', 'assert', 'mark_seen', 'reset')),
    targetId: req(ref()),
    value: opt(typed),
    condition: opt(cond),
    instanceId: opt(ref('item')),
    reason: opt(txt()),
    exceptionDetails: opt(exception)
  }),
  assertion: obj({
    subjectId: req(ref()),
    predicate: req(txt(1, 128)),
    value: req(union(typed, ref())),
    truthKind: req(en('author_truth', 'testimony', 'belief', 'hypothesis')),
    holderId: opt(ref('character')),
    sourceIds: opt(refs('source', 'assertion', 'event', 'scene', 'dialogue_line')),
    evidenceLocation: opt(anchor),
    validity: opt(nullableValidity),
    reason: opt(txt())
  }),
  foreshadow: obj({
    question: req(rich),
    intent: req(rich),
    resolutionPolicy: req(en('this_work', 'sequel', 'intentional_open', 'red_herring', 'undecided', 'rejected')),
    truthAssertionIds: opt(refs('assertion')),
    clueIds: opt(refs('disclosure')),
    payoffIds: opt(refs('disclosure')),
    requiredInfo: opt(refs('disclosure', 'assertion')),
    alternativeInfo: opt(record(refs('disclosure', 'assertion'), ref('disclosure', 'assertion'))),
    deadline: opt(targetScope),
    presentationDeadline: opt(anchor),
    exceptions: opt(arr(exception))
  }),
  disclosure: obj({
    foreshadowId: req(ref('foreshadow')),
    anchor: req(anchor),
    stage: req(en('hint', 'suspicion', 'reinforce', 'reveal', 'alternative')),
    role: req(en('clue', 'payoff')),
    condition: opt(cond),
    knowledgeEffects: opt(refs('effect')),
    targetScope: opt(targetScope)
  }),
  checkpoint: obj({
    worldTick: opt(tick),
    contentVersionId: req(scopedRef('snapshot')),
    runtimeState: req(runtime),
    presentationState: opt(runtime),
    presentationResults: opt(arr(presentationResult)),
    contentRevision: opt({
      type: 'revision'
    }),
    origin: opt(en('full_play', 'partial', 'imported')),
    traceId: opt(ref('trace')),
    migration: opt(obj({
      sourceCheckpointId: req(ref('checkpoint')),
      sourceVersionId: req(scopedRef('snapshot')),
      baseRevision: req({
        type: 'revision'
      }),
      method: req(en('migrate', 'recreate'))
    }))
  }),
  trace: obj({
    contentVersionId: req(scopedRef('snapshot')),
    startCheckpointId: req(ref('checkpoint')),
    steps: req(arr(obj({
      nodeId: req(ref('flow_node')),
      edgeIds: req(refs('flow_edge')),
      before: req(runtime),
      after: req(runtime),
      presentationState: opt(runtime),
      conditionResults: opt(arr(presentationResult)),
      operation: opt(en('advance', 'stub')),
      occurrenceId: opt(txt()),
      worldTick: opt(tick),
      externalMode: opt(en('stub', 'actual', 'mixed')),
      externalValues: opt(record(typed, ref('external_contract')))
    }))),
    contentRevision: opt({
      type: 'revision'
    }),
    initialExternalValues: opt(record(typed, ref('external_contract'))),
    initialStubBaseState: opt(runtime),
    initialStubValues: opt(obj({
      variables: opt(record(typed, ref('variable'))),
      external: opt(record(typed, ref('external_contract')))
    })),
    initialWorldTick: opt(tick),
    seed: opt(txt()),
    engineVersion: opt(txt()),
    externalMode: opt(en('stub', 'actual', 'mixed')),
    coverage: opt(coverage),
    regressionDeclarations: opt(obj({
      projectRevision: req({
        type: 'revision'
      }),
      traceIds: req(refs('trace'))
    })),
    reconfirmation: opt(obj({
      sourceTraceId: req(ref('trace')),
      sourceVersionId: req(scopedRef('snapshot')),
      baseRevision: req({
        type: 'revision'
      }),
      startCheckpointId: opt(ref('checkpoint'))
    })),
    mode: opt(en('flow', 'chapters', null)),
    readingPath: opt(union(readingPath, en(null)))
  }),
  attachment: obj({
    mediaType: req(txt(1, 128)),
    contentHash: req({
      type: 'hash'
    }),
    byteSize: req(num(0, 32 * 1024 * 1024, true)),
    assetPath: req({
      type: 'safe_path'
    }),
    displayName: opt(txt()),
    provenanceId: opt(ref('source')),
    licenseNote: opt(txt()),
    stage: opt(en('reference', 'temporary', 'final')),
    revisionHistory: opt(refs('attachment'))
  }),
  source: obj({
    sourceType: req(en('web', 'file', 'book', 'observation')),
    locator: req(txt(1)),
    accessedAt: opt({
      type: 'datetime'
    }),
    excerptLocation: opt(txt()),
    interpretation: opt(rich),
    attachmentId: opt(ref('attachment')),
    redistributionAllowed: opt(bool)
  }),
  cue: obj({
    anchor: req(anchor),
    cueType: req(txt(1, 128)),
    attachmentId: opt(ref('attachment')),
    speakerId: opt(ref('character')),
    expression: opt(txt()),
    waitMs: opt(num(0, undefined, true)),
    camera: opt({
      type: 'custom'
    }),
    mediaTime: opt(num(0, undefined, true)),
    stage: opt(short)
  }),
  storyboard_frame: obj({
    anchor: req(anchor),
    mediaStartMs: req(num(0, undefined, true)),
    mediaEndMs: opt(num(0, undefined, true)),
    referenceAssetId: opt(ref('attachment')),
    finalAssetId: opt(ref('attachment')),
    cueIds: opt(refs('cue')),
    caption: opt(rich)
  }),
  localization: obj({
    sourceLineId: req(ref('dialogue_line')),
    language: req(txt(1, 128)),
    sourceHash: req({
      type: 'hash'
    }),
    text: req(rich),
    stage: opt(en('draft', 'reviewed', 'needs_review')),
    reviewedBy: opt(scopedRef('identity')),
    recordingIds: opt(refs('recording'))
  }),
  recording: obj({
    sourceLineId: req(ref('dialogue_line')),
    language: req(txt(1, 128)),
    sourceHash: req({
      type: 'hash'
    }),
    translationId: opt(ref('localization')),
    attachmentId: opt(ref('attachment')),
    notes: opt(rich),
    stage: opt(en('planned', 'recorded', 'reviewed', 'needs_review')),
    reviewedBy: opt(scopedRef('identity'))
  }),
  terminology: obj({
    canonical: req(txt(1, 128)),
    reading: req(short),
    variants: opt(arr(short, true)),
    language: opt(short),
    usageNotes: opt(rich),
    validity: opt(nullableValidity),
    exceptions: opt(arr(exception)),
    voiceOwnerId: opt(ref('character'))
  }),
  map: obj({
    placeId: req(ref('place')),
    coordinateSystem: req(en('normalized')),
    attachmentId: opt(ref('attachment')),
    parentMapId: opt(ref('map')),
    pins: opt(arr(obj({
      id: req(idSchema),
      placeId: req(ref('place')),
      x: req(num(0, 1)),
      y: req(num(0, 1)),
      label: opt(txt())
    })))
  }),
  travel_route: obj({
    fromPlaceId: req(ref('place')),
    toPlaceId: req(ref('place')),
    direction: req(en('one_way', 'two_way')),
    method: opt(txt()),
    minimumTicks: opt(tick),
    maximumTicks: opt(tick),
    evidence: opt(refs()),
    validity: opt(nullableValidity)
  }),
  template: obj({
    targetKind: req(en(...ENTITY_KINDS)),
    fields: req(arr(fieldDefinition)),
    description: opt(txt()),
    version: opt({
      type: 'revision'
    }),
    defaults: opt(record({
      type: 'custom'
    }, key))
  }),
  collection: obj({
    purpose: opt(en('regression')),
    mode: req(en('dynamic', 'fixed')),
    query: opt({
      type: 'query'
    }),
    memberIds: opt(refs()),
    sort: opt(obj({
      field: req(en('name', 'createdAt', 'updatedAt', 'kind')),
      direction: req(en('asc', 'desc'))
    }))
  }),
  review: obj({
    target: req(union(anchor, ref())),
    targetVersionId: req(scopedRef('snapshot')),
    body: req(rich),
    stage: req(en('open', 'fixed', 'verified')),
    assigneeId: opt(scopedRef('identity')),
    quotedText: opt(txt()),
    resolution: opt(rich),
    sharedSource: opt(obj({
      connection: req(txt(1)),
      sharedSnapshot: req(txt(1)),
      comment: req(txt(1)),
      publicVersion: req(txt(1)),
      publicEntity: opt(txt(1)),
      publicRelation: opt(txt(1)),
      publicBlock: opt(txt(1)),
      startCp: opt(num(0, undefined, true)),
      endCp: opt(num(0, undefined, true)),
      projectionHash: req(txt(64, 64)),
      commentBodyHash: req(txt(64, 64)),
      quotedText: req(txt()),
      observedStage: req(en('open', 'fixed', 'verified'))
    }))
  }),
  creative_brief: obj({
    targetAudience: req(rich),
    experience: req(rich),
    theme: req(rich),
    tone: req(rich),
    scope: req(rich),
    deliverableIds: opt(refs()),
    decisionIds: opt(refs('decision'))
  }),
  decision: obj({
    subject: req(txt(1)),
    reason: req(rich),
    targetVersionId: req(scopedRef('snapshot')),
    outcome: req(en('accepted', 'rejected', 'deferred')),
    priority: opt(short),
    requirementIds: opt(arr(short, true)),
    reviewIds: opt(refs('review'))
  }),
  gameplay_spec: obj({
    sceneId: req(ref('scene')),
    action: req(rich),
    mechanic: opt(txt()),
    tutorial: opt(rich),
    reward: opt(typed),
    questId: opt(ref('quest')),
    taskIds: opt(refs('production_task')),
    intentionalDifference: opt(txt())
  }),
  production_task: obj({
    targetIds: req(refs()),
    stage: req(en('writing', 'review', 'implementation', 'translation', 'recording', 'verification', 'publication')),
    progress: req(en('todo', 'doing', 'done', 'needs_review')),
    assigneeId: opt(scopedRef('identity')),
    deadline: opt(obj({
      date: req({
        type: 'date'
      }),
      timeZone: req(txt(1, 128))
    })),
    dependsOn: opt(refs('production_task')),
    estimate: opt(estimate),
    blockingReason: opt(txt())
  }),
  media_variant: obj({
    previousVariantId: opt(ref('media_variant')),
    confirmationRecipientIds: opt(arr(scopedRef('identity'), true)),
    medium: req(en('game', 'novel', 'video', 'audio', 'promotion', 'custom')),
    baseSnapshotId: req(scopedRef('snapshot')),
    body: opt(rich),
    releaseAt: opt({
      type: 'datetime'
    }),
    projectionProfileId: opt(ref('projection_profile')),
    sourceIds: opt(refs()),
    needsReview: opt(bool)
  }),
  voice_rule: obj({
    characterId: req(ref('character')),
    validity: req(nullableValidity),
    firstPerson: opt(short),
    addressing: opt(txt()),
    phrasing: opt(txt()),
    examples: opt(rich),
    exceptions: opt(arr(exception))
  }),
  external_contract: obj({
    key: req(key),
    owner: req(en('tool', 'game')),
    inputType: req(txt(1, 128)),
    outputType: req(txt(1, 128)),
    missingPolicy: req(en('unknown', 'block')),
    description: opt(rich),
    stubValues: opt(arr(typed)),
    adapterProfileIds: opt(refs('projection_profile')),
    version: opt(short)
  }),
  snapshot: obj({
    versionLabel: req(txt(1, 128)),
    contentHash: req({
      type: 'hash'
    }),
    immutable: req(en(true)),
    parentVersionIds: opt(arr(scopedRef('snapshot'), true)),
    releasedAt: opt({
      type: 'datetime'
    }),
    referencedWorldVersionIds: opt(arr(scopedRef('snapshot'), true))
  }),
  projection_profile: obj({
    blockSources: opt(record(scopedRef('block'), scopedRef('projection_record'))),
    citedVersions: opt(arr(obj({
      sourceVersionId: req(scopedRef('snapshot')),
      profileId: req(ref('projection_profile')),
      publicVersionId: req(idSchema)
    }))),
    audience: req(txt(1, 128)),
    includedIds: req(refs()),
    namePolicy: req({
      type: 'name_policy'
    }),
    allowedKinds: opt(arr(en(...ENTITY_KINDS), true)),
    excludedFields: opt(arr(txt(1), true)),
    routeScope: opt(targetScope),
    includeAuthorNotes: opt(bool),
    publicTitle: opt(txt()),
    publicTexts: opt(record(publicText, scopedRef('record'))),
    allowedFields: opt(record(arr(txt(1), true), en(...ENTITY_KINDS))),
    allowedRelationIds: opt(arr(scopedRef('relation'), true)),
    idPolicy: opt(en('remap', 'preserve')),
    publicIds: opt(record(idSchema, scopedRef('projection_record'))),
    sourceVersionId: opt(scopedRef('snapshot')),
    publicValues: opt(record(record(txt(), txt()), ref('variable', 'external_contract', 'assertion'))),
    includedStatuses: opt(arr(en(...STATUSES), true)),
    publicVersionLabel: opt(txt()),
    approvedAttachmentIds: opt(refs('attachment'))
  })
};
const isObject = value => !!value && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
const utf8Encoder = new TextEncoder();
const utf8Bytes = value => utf8Encoder.encode(value).byteLength;
// Count the same Unicode code points as the string iterator, without building
// an array for every field. Invalid surrogates are still rejected separately.
function codePointLength(value) {
  let count = 0;
  for (let i = 0; i < value.length; i++, count++) {
    const code = value.charCodeAt(i),
      next = value.charCodeAt(i + 1);
    if (code >= 0xd800 && code <= 0xdbff && next >= 0xdc00 && next <= 0xdfff) i++;
  }
  return count;
}
function validUnicode(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = value.charCodeAt(++i);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
    } else if (code >= 0xdc00 && code <= 0xdfff) return false;
  }
  return true;
}
function addIssue(issues, path, message, code = 'VALIDATION_FAILED') {
  if (issues.length < 256) issues.push({
    code,
    path,
    message
  });
}
function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function conditionSchema(value) {
  switch (value.op) {
    case 'constant':
      return obj({
        op: req(en('constant')),
        value: req(bool)
      });
    case 'all':
    case 'any':
      return obj({
        op: req(en('all', 'any')),
        children: req(arr(cond, false, 1, 256))
      });
    case 'not':
      return obj({
        op: req(en('not')),
        child: req(cond)
      });
    case 'compare':
      return obj({
        op: req(en('compare')),
        variableId: req(ref('variable')),
        comparator: req(en('eq', 'ne', 'lt', 'le', 'gt', 'ge', 'in')),
        value: req(value.comparator === 'in' ? arr(typed, false, 1, 256) : typed)
      });
    case 'item':
      return obj({
        op: req(en('item')),
        itemId: req(ref('item')),
        quantity: req(num(1, undefined, true))
      });
    case 'known':
      return obj({
        op: req(en('known')),
        assertionId: req(ref('assertion')),
        holderId: req(ref('character'))
      });
    case 'visited':
      return obj({
        op: req(en('visited')),
        entityId: req(ref()),
        count: req(num(1, undefined, true))
      });
    case 'external':
      return obj({
        op: req(en('external')),
        contractId: req(ref('external_contract'))
      });
    default:
      return undefined;
  }
}
function expressionSchema(value) {
  const expression = {
    type: 'expression'
  };
  switch (value.op) {
    case 'value':
      return obj({
        op: req(en('value')),
        value: req(typed)
      });
    case 'variable':
      return obj({
        op: req(en('variable')),
        variableId: req(ref('variable'))
      });
    case 'add':
    case 'subtract':
    case 'multiply':
      return obj({
        op: req(en('add', 'subtract', 'multiply')),
        left: req(expression),
        right: req(expression)
      });
    case 'if':
      return obj({
        op: req(en('if')),
        condition: req(cond),
        then: req(expression),
        else: req(expression)
      });
    default:
      return conditionSchema(value);
  }
}
function timeSchema(value) {
  const calendarId = req(scopedRef('calendar'));
  switch (value.mode) {
    case 'instant':
      return obj({
        mode: req(en('instant')),
        at: req(tick),
        calendarId
      });
    case 'interval':
      return obj({
        mode: req(en('interval')),
        start: req(tick),
        end: req(tick),
        calendarId
      });
    case 'uncertain':
      return obj({
        mode: req(en('uncertain')),
        earliest: req(tick),
        latest: req(tick),
        calendarId,
        precision: req(txt())
      });
    case 'relative':
      return obj({
        mode: req(en('relative')),
        anchorEventId: req(ref('event')),
        anchorPoint: req(en('start', 'end')),
        minOffset: req(tick),
        maxOffset: req(tick)
      });
    case 'unknown':
      return obj({
        mode: req(en('unknown')),
        reason: req(txt())
      });
    default:
      return undefined;
  }
}
function querySchema(value) {
  switch (value.op) {
    case 'all':
    case 'any':
      return obj({
        op: req(en('all', 'any')),
        children: req(arr({
          type: 'query'
        }, false, 1, 256))
      });
    case 'kind':
      return obj({
        op: req(en('kind')),
        value: req(en(...ENTITY_KINDS))
      });
    case 'text':
      return obj({
        op: req(en('text')),
        value: req(txt())
      });
    case 'status':
      return obj({
        op: req(en('status')),
        value: req(en(...STATUSES))
      });
    case 'participant':
      return obj({
        op: req(en('participant')),
        characterId: req(ref('character'))
      });
    case 'production':
      return obj({
        op: req(en('production')),
        value: req(en('todo', 'doing', 'done', 'needs_review'))
      });
    case 'chapter':
      return obj({
        op: req(en('chapter')),
        chapterId: req(ref('chapter'))
      });
    case 'foreshadow':
      return obj({
        op: req(en('foreshadow')),
        foreshadowId: optionalValue(ref('foreshadow')),
        resolutionPolicy: optionalValue(en('this_work', 'sequel', 'intentional_open', 'red_herring', 'undecided', 'rejected')),
        role: optionalValue(en('clue', 'payoff')),
        stage: optionalValue(en('hint', 'suspicion', 'reinforce', 'reveal', 'alternative'))
      });
    default:
      return undefined;
  }
}
function namePolicySchema(value) {
  if (!('mode' in value)) {
    const policy = union(...['alias', 'replace', 'exclude', 'anonymize'].map(mode => namePolicySchema({
      mode
    })));
    return obj({
      defaultPolicy: opt(policy),
      byEntityId: opt(record(policy, ref()))
    });
  }
  switch (value.mode) {
    case 'alias':
      return obj({
        mode: req(en('alias')),
        aliasId: req(scopedRef('alias'))
      });
    case 'replace':
      return obj({
        mode: req(en('replace')),
        replacement: req(txt(1, 128))
      });
    case 'exclude':
      return obj({
        mode: req(en('exclude'))
      });
    case 'anonymize':
      return obj({
        mode: req(en('anonymize')),
        publicId: req(idSchema),
        publicName: req(txt(1, 128))
      });
    default:
      return undefined;
  }
}
const textSpan = {
  start: req(num(0, undefined, true)),
  end: req(num(0, undefined, true))
};
const richTextBlocks = arr(obj({
  id: req(idSchema),
  kind: req(en('paragraph', 'heading', 'list_item', 'quote')),
  text: req(txt()),
  ruby: opt(arr(obj({
    ...textSpan,
    text: req(txt())
  }))),
  links: opt(arr(obj({
    ...textSpan,
    target: req(anchor)
  }))),
  unresolvedAnnotations: opt(arr(unresolvedTextAnnotation))
}));
function walk(schema, value, path, issues, references, depth = 0, ast) {
  if (issues.length >= 256) return;
  if (depth > 32) {
    addIssue(issues, path, '構造の深さが上限32を超えています。', 'IMPORT_LIMIT');
    return;
  }
  const fail = message => addIssue(issues, path, message);
  switch (schema.type) {
    case 'json':
      {
        const visit = (item, itemPath, level, seen) => {
          if (level > 100) {
            addIssue(issues, itemPath, 'JSON階層の上限を超えています。', 'IMPORT_LIMIT');
            return;
          }
          if (item === null || typeof item === 'string' || typeof item === 'boolean') return;
          if (typeof item === 'number' && Number.isFinite(item)) return;
          if (!item || typeof item !== 'object' || seen.has(item)) {
            addIssue(issues, itemPath, '通常のJSON値を指定してください。');
            return;
          }
          seen.add(item);
          if (Array.isArray(item)) item.forEach((child, index) => visit(child, `${itemPath}[${index}]`, level + 1, seen));else if (Object.getPrototypeOf(item) === Object.prototype || Object.getPrototypeOf(item) === null) {
            for (const [key, child] of Object.entries(item)) {
              if (['__proto__', 'prototype', 'constructor'].includes(key)) addIssue(issues, `${itemPath}.${key}`, '予約済みのキーは使えません。');else visit(child, `${itemPath}.${key}`, level + 1, seen);
            }
          } else addIssue(issues, itemPath, '通常のJSONオブジェクトを指定してください。');
          seen.delete(item);
        };
        visit(value, path, 0, new Set());
        return;
      }
    case 'text':
      {
        if (typeof value !== 'string') {
          fail('文字列を入力してください。');
          return;
        }
        if (!validUnicode(value)) fail('文字列に不正なUnicodeがあります。');
        const count = codePointLength(value);
        if (schema.min !== undefined && count < schema.min) fail(`${schema.min}文字以上で入力してください。`);
        if (schema.max !== undefined && count > schema.max) fail(`${schema.max}文字以内で入力してください。`);
        if (schema.maxBytes !== undefined && utf8Bytes(value) > schema.maxBytes) fail('本文が1 MiBの上限を超えています。');
        return;
      }
    case 'number':
      if (typeof value !== 'number' || !Number.isFinite(value) || schema.integer && !Number.isSafeInteger(value)) fail(schema.integer ? '安全な範囲の整数を入力してください。' : '有限の数値を入力してください。');else if (schema.min !== undefined && value < schema.min || schema.max !== undefined && value > schema.max) fail('数値が許容範囲外です。');
      return;
    case 'boolean':
      if (typeof value !== 'boolean') fail('真偽値を指定してください。');
      return;
    case 'enum':
      if (!schema.values.includes(value)) fail('宣言された値を選んでください。');
      return;
    case 'id':
      if (typeof value !== 'string' || !ID_PATTERN.test(value)) fail('小文字のUUIDを指定してください。');
      return;
    case 'ref':
      {
        var _schema$scope;
        const valid = typeof value === 'string' && (schema.scope === 'calendar' ? value.length > 0 : ID_PATTERN.test(value));
        if (!valid) fail(schema.scope === 'calendar' ? '暦IDが必要です。' : '参照先は小文字UUIDです。');
        // Keep typed string paths for explicit public-to-native ID conversion.
        // Format validation above still rejects them at every native boundary.
        if (typeof value === 'string') references.push({
          id: value,
          path,
          kinds: schema.kinds,
          scope: (_schema$scope = schema.scope) !== null && _schema$scope !== void 0 ? _schema$scope : 'entity'
        });
        return;
      }
    case 'tick':
      if (!isTick(value)) fail('tickは38桁以内の正規整数文字列です。');
      return;
    case 'revision':
      if (typeof value !== 'string' || !REVISION_PATTERN.test(value)) fail('revisionは0以上の整数文字列です。');
      return;
    case 'datetime':
      if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.\d+)?(?:Z|\+00:00)$/.test(value) || !Number.isFinite(Date.parse(value)) || !validDate(value.slice(0, 10))) fail('UTCのRFC 3339日時を指定してください。');
      return;
    case 'date':
      if (typeof value !== 'string' || !validDate(value)) fail('実在するYYYY-MM-DD形式の日付を指定してください。');
      return;
    case 'hash':
      if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) fail('SHA-256は小文字16進数64文字です。');
      return;
    case 'safe_path':
      if (typeof value !== 'string' || !value || value.startsWith('/') || value.includes('\\') || value.includes('\0') || /^[a-zA-Z]:/.test(value) || value.split('/').some(part => !part || part === '.' || part === '..') || /[\u0000-\u001f\u007f]/.test(value)) fail('安全な相対パスを指定してください。');
      return;
    case 'array':
      {
        var _schema$max;
        if (!Array.isArray(value)) {
          fail('配列を指定してください。');
          return;
        }
        if (value.length > ((_schema$max = schema.max) !== null && _schema$max !== void 0 ? _schema$max : 100000) || schema.min !== undefined && value.length < schema.min) {
          fail('配列の件数が許容範囲外です。');
          return;
        }
        if (schema.unique && new Set(value.map(item => typeof item === 'object' ? JSON.stringify(item) : item)).size !== value.length) fail('同じ値を集合内で重複保存できません。');
        value.forEach((item, i) => walk(schema.item, item, `${path}[${i}]`, issues, references, depth + 1, ast));
        return;
      }
    case 'object':
      {
        if (!isObject(value)) {
          fail('オブジェクトを指定してください。');
          return;
        }
        for (const field of Object.keys(value)) if (!Object.hasOwn(schema.fields, field)) addIssue(issues, `${path}.${field}`, '未知の項目は保存できません。');
        for (const field of Object.keys(schema.fields)) {
          const definition = schema.fields[field];
          const item = value[field],
            fieldPath = `${path}.${field}`;
          if (item === undefined) {
            if (definition.required) addIssue(issues, fieldPath, '必須項目です。');
            continue;
          }
          if (item === null && definition.nullable) continue;
          walk(definition.schema, item, fieldPath, issues, references, depth + 1, ast);
        }
        return;
      }
    case 'record':
      if (!isObject(value)) {
        fail('項目の辞書を指定してください。');
        return;
      }
      for (const [field, item] of Object.entries(value)) {
        if (['__proto__', 'prototype', 'constructor'].includes(field)) {
          addIssue(issues, `${path}.${field}`, '予約済みのキーは使えません。');
          continue;
        }
        if (schema.key) walk(schema.key, field, `${path}.${field}.$key`, issues, references, depth + 1, ast);
        walk(schema.value, item, `${path}.${field}`, issues, references, depth + 1, ast);
      }
      return;
    case 'union':
      {
        let shortest;
        for (const choice of schema.choices) {
          const branchIssues = [],
            branchRefs = [];
          walk(choice, value, path, branchIssues, branchRefs, depth + 1, ast);
          if (!branchIssues.length) {
            references.push(...branchRefs);
            return;
          }
          if (!shortest || branchIssues.length < shortest.length) shortest = branchIssues;
        }
        issues.push(...(shortest !== null && shortest !== void 0 ? shortest : [{
          code: 'VALIDATION_FAILED',
          path,
          message: '対応する型ではありません。'
        }]));
        return;
      }
    case 'typed':
      {
        if (!isObject(value)) {
          fail('型と値を指定してください。');
          return;
        }
        let valueSchema;
        switch (value.type) {
          case 'boolean':
            valueSchema = bool;
            break;
          case 'integer':
            valueSchema = num(undefined, undefined, true);
            break;
          case 'enum':
          case 'text':
            valueSchema = txt();
            break;
          case 'ref':
            valueSchema = ref();
            break;
          case 'unknown':
            walk(obj({
              type: req(en('unknown')),
              value: {
                schema: txt(),
                required: true,
                nullable: true
              },
              reason: req(txt())
            }), value, path, issues, references, depth + 1, ast);
            if (value.value !== null) fail('未定値のvalueはnullです。');
            return;
          default:
            fail('未知の値型です。');
            return;
        }
        walk(obj({
          type: req(en(value.type)),
          value: req(valueSchema)
        }), value, path, issues, references, depth + 1, ast);
        return;
      }
    case 'custom':
      if (value === null) return;
      if (typeof value === 'string') walk(txt(), value, path, issues, references, depth, ast);else if (typeof value === 'number') walk(num(), value, path, issues, references, depth, ast);else if (typeof value === 'boolean') return;else if (isObject(value) && value.type === 'ref') walk(obj({
        type: req(en('ref')),
        value: req(ref())
      }), value, path, issues, references, depth + 1, ast);else if (isObject(value) && value.type === 'date') walk(obj({
        type: req(en('date')),
        value: req({
          type: 'date'
        })
      }), value, path, issues, references, depth + 1, ast);else fail('カスタム値は文字列・数値・真偽・日付・参照またはnullです。');
      return;
    case 'richtext':
      {
        walk(richTextBlocks, value, path, issues, references, depth + 1, ast);
        if (!Array.isArray(value)) return;
        let bytes = 0,
          chars = 0;
        const blockIds = new Set();
        value.forEach((block, i) => {
          if (!isObject(block) || typeof block.text !== 'string') return;
          const length = codePointLength(block.text);
          bytes += utf8Bytes(block.text);
          chars += length;
          if (typeof block.id === 'string') {
            if (blockIds.has(block.id)) addIssue(issues, `${path}[${i}].id`, '段落IDが重複しています。');
            blockIds.add(block.id);
          }
          if (Array.isArray(block.unresolvedAnnotations)) for (const annotation of block.unresolvedAnnotations) if (isObject(annotation)) for (const field of ['originalText', 'reason', 'reading']) if (typeof annotation[field] === 'string') bytes += utf8Bytes(annotation[field]);
          for (const field of ['ruby', 'links']) if (Array.isArray(block[field])) block[field].forEach((range, j) => {
            if (!isObject(range)) return;
            if (typeof range.start === 'number' && typeof range.end === 'number' && (range.start >= range.end || range.end > length)) addIssue(issues, `${path}[${i}].${field}[${j}]`, '文字範囲はコードポイントで数え、本文内の半開区間を指定してください。');
            if (typeof range.text === 'string') bytes += utf8Bytes(range.text);
          });
        });
        if (bytes > 1024 * 1024) fail('本文フィールドが1 MiBを超えています。');
        if (schema.max !== undefined && chars > schema.max) fail(`要約は${schema.max}文字以内です。`);
        return;
      }
    case 'condition':
    case 'expression':
      {
        const budget = ast !== null && ast !== void 0 ? ast : {
          counter: {
            count: 0
          },
          depth: 0
        };
        budget.counter.count++;
        if (budget.counter.count > 256 || budget.depth >= 16) {
          fail('条件・式は深さ16、ノード256までです。');
          return;
        }
        if (!isObject(value)) {
          fail('条件・式は型付きASTで指定してください。');
          return;
        }
        const definition = schema.type === 'condition' ? conditionSchema(value) : expressionSchema(value);
        if (!definition) {
          fail('未知の条件・式opです。');
          return;
        }
        walk(definition, value, path, issues, references, 0, {
          counter: budget.counter,
          depth: budget.depth + 1
        });
        return;
      }
    case 'time':
      {
        if (!isObject(value)) {
          fail('日時はTimeSpecで指定してください。');
          return;
        }
        const definition = timeSchema(value);
        if (!definition) {
          fail('未知の日時modeです。');
          return;
        }
        const before = issues.length;
        walk(definition, value, path, issues, references, depth + 1, ast);
        if (issues.length === before) {
          if (value.mode === 'interval' && compareTicks(value.start, value.end) >= 0) fail('期間はstart < endの半開区間です。');
          if (value.mode === 'uncertain' && compareTicks(value.earliest, value.latest) > 0) fail('earliestはlatest以下です。');
          if (value.mode === 'relative' && compareTicks(value.minOffset, value.maxOffset) > 0) fail('minOffsetはmaxOffset以下です。');
        }
        return;
      }
    case 'query':
    case 'name_policy':
      {
        if (!isObject(value)) {
          fail('型付きのオブジェクトを指定してください。');
          return;
        }
        const definition = schema.type === 'query' ? querySchema(value) : namePolicySchema(value);
        if (!definition) {
          fail('未知の規則です。');
          return;
        }
        const before = issues.length;
        walk(definition, value, path, issues, references, depth + 1, ast);
        if (schema.type === 'query' && value.op === 'foreshadow' && issues.length === before && !['foreshadowId', 'resolutionPolicy', 'role', 'stage'].some(field => value[field] !== undefined && value[field] !== null)) {
          addIssue(issues, path, '伏線検索には対象・回収方針・開示役割・段階のいずれかを指定してください。');
        }
        return;
      }
  }
}
const commonFields = {
  id: req(idSchema),
  projectId: req(scopedRef('project')),
  kind: req(en(...ENTITY_KINDS)),
  revision: req({
    type: 'revision'
  }),
  name: req(short),
  status: req(en(...STATUSES)),
  visibility: req(en('private', 'team', 'projection')),
  retainIfUnreferenced: opt(bool),
  projectionProfileId: opt(ref('projection_profile')),
  templateId: opt(ref('template')),
  createdAt: req({
    type: 'datetime'
  }),
  updatedAt: req({
    type: 'datetime'
  }),
  deletedAt: opt({
    type: 'datetime'
  }),
  deletionOperationId: opt(idSchema),
  customValues: req(record({
    type: 'custom'
  }, key))
};
const relationSchema = obj({
  id: req(idSchema),
  projectId: req(scopedRef('project')),
  revision: req({
    type: 'revision'
  }),
  fromId: req(ref()),
  toId: req(ref()),
  relationType: req(txt(1, 128)),
  direction: req(en('forward', 'symmetric')),
  validity: req(nullableValidity),
  evidenceIds: req(refs()),
  status: req(en(...STATUSES)),
  visibility: req(en('private', 'team', 'projection')),
  projectionProfileId: opt(ref('projection_profile')),
  deletedAt: opt({
    type: 'datetime'
  }),
  deletionOperationId: opt(idSchema)
});
const entityRecordSchemas = new Map();
function entitySchema(kind) {
  const data = ENTITY_SCHEMAS[kind],
    cached = entityRecordSchemas.get(kind);
  if ((cached === null || cached === void 0 ? void 0 : cached.data) === data) return cached.record;
  const record = obj({
    ...commonFields,
    kind: req(en(kind)),
    data: req(data)
  });
  entityRecordSchemas.set(kind, {
    data,
    record
  });
  return record;
}
function simpleValidate(schema, value, path, references = []) {
  const issues = [];
  walk(schema, value, path, issues, references);
  return issues.length ? {
    ok: false,
    issues
  } : {
    ok: true,
    value: value
  };
}
export function validateCondition(input, path = 'condition') {
  return simpleValidate(cond, input, path);
}
export function validateExpression(input, path = 'expression') {
  return simpleValidate({
    type: 'expression'
  }, input, path);
}
export function validateTypedValue(input, path = 'value') {
  return simpleValidate(typed, input, path);
}
export function validateTimeSpec(input, path = 'time') {
  return simpleValidate(time, input, path);
}
export function validateRuntimeState(input, path = 'runtimeState') {
  const result = simpleValidate(runtime, input, path);
  if (!result.ok) return result;
  const issues = [],
    ids = new Set(),
    assertions = new Set();
  result.value.itemInstances.forEach((item, i) => {
    if (ids.has(item.instanceId)) addIssue(issues, `${path}.itemInstances[${i}].instanceId`, '物品個体のIDが重複しています。');
    ids.add(item.instanceId);
    if (item.ownerId && item.locationId || item.consumed && item.quantity !== 0 || !item.consumed && item.quantity < 1) addIssue(issues, `${path}.itemInstances[${i}]`, '物品の所在・所有・消費状態・数量が不整合です。');
  });
  result.value.assertions.forEach((assertion, i) => {
    const key = `${assertion.assertionId}/${assertion.holderId}`;
    if (assertions.has(key)) addIssue(issues, `${path}.assertions[${i}]`, '同じ人物・事実の認識が重複しています。');
    assertions.add(key);
  });
  return issues.length ? {
    ok: false,
    issues
  } : result;
}
/** Optional legacy evidence may be absent; supplied initial evidence must be complete and consistent. */
export function validateInitialPresentationResults(state, input, entities, path = 'presentationResults') {
  const checked = simpleValidate(arr(presentationResult), input, path);
  if (!checked.ok) return checked.issues;
  const issues = [],
    seen = new Set(state.seenIds),
    observed = new Set();
  const node = entities.find(entity => entity.kind === 'flow_node' && entity.id === state.presentationPosition && !entity.deletedAt && entity.status !== 'rejected');
  const eligible = entities.filter(entity => {
    if (entity.kind !== 'disclosure' || entity.deletedAt || entity.status === 'rejected' || !node || !seen.has(node.id)) return false;
    const anchor = entity.data.anchor;
    return anchor.positionStatus !== 'unresolved' && (anchor.entityId === node.id || anchor.entityId === node.data.sceneId) && (!anchor.blockId || seen.has(anchor.blockId)) && (!anchor.lineId || seen.has(anchor.lineId));
  });
  const targets = new Set(eligible.map(disclosure => disclosure.id));
  checked.value.forEach((result, index) => {
    const location = `${path}[${index}]`;
    if (observed.has(result.targetId)) addIssue(issues, `${location}.targetId`, '初期提示の条件結果が重複しています。');
    observed.add(result.targetId);
    if (!targets.has(result.targetId)) addIssue(issues, `${location}.targetId`, '初期提示の対象ではない開示の条件結果です。', 'REFERENCE_INVALID');
    if (result.value === 'unknown') addIssue(issues, `${location}.value`, '未確認の開示条件では初期提示を完了できません。');
    if (result.value === 'true' && !seen.has(result.targetId)) addIssue(issues, `${location}.value`, '提示した条件結果と既読の証跡が一致しません。');
    if (result.value === 'false' && seen.has(result.targetId) && state.provenance === 'full_play') addIssue(issues, `${location}.value`, '提示済みの開示を初期条件のfalseで取り消すことはできません。');
  });
  for (const disclosure of eligible) if (!observed.has(disclosure.id)) addIssue(issues, path, '初期提示の開示条件結果が不足しています。');
  return issues;
}
export function validateEffectData(input, path = 'effect') {
  return simpleValidate(ENTITY_SCHEMAS.effect, input, path);
}
function validateEntityRecord(input, path, references) {
  if (!isObject(input) || !ENTITY_KINDS.includes(input.kind)) return {
    ok: false,
    issues: [{
      code: 'VALIDATION_FAILED',
      path: `${path}.kind`,
      message: '未対応の情報種別です。'
    }]
  };
  const result = simpleValidate(entitySchema(input.kind), input, path, references);
  if (!result.ok) return result;
  const issues = [];
  validateLocalRules(result.value, path, issues);
  return issues.length ? {
    ok: false,
    issues
  } : result;
}
export function validateEntity(input, path = 'entity') {
  return validateEntityRecord(input, path);
}
export function validateRelation(input, path = 'relation') {
  return simpleValidate(relationSchema, input, path);
}
export function validateVariableValue(variable, value, path = 'value', allowUnknown = true) {
  const issues = [],
    data = variable.data;
  if (value.type === 'unknown') {
    if (!allowUnknown) addIssue(issues, path, '未定の値はこの操作で使えません。', 'CONDITION_UNKNOWN');
    return issues;
  }
  if (value.type !== data.valueType) {
    addIssue(issues, path, '状態変数の宣言型と値の型が一致しません。');
    return issues;
  }
  if (value.type === 'integer') {
    var _data$allowed$min, _data$allowed$max;
    const min = (_data$allowed$min = data.allowed.min) !== null && _data$allowed$min !== void 0 ? _data$allowed$min : -2147483647,
      max = (_data$allowed$max = data.allowed.max) !== null && _data$allowed$max !== void 0 ? _data$allowed$max : 2147483647;
    if (!Number.isSafeInteger(value.value) || value.value < min || value.value > max) addIssue(issues, path, '状態変数の値が宣言した整数範囲外です。');
  }
  if ((value.type === 'enum' || value.type === 'boolean') && data.allowed.values && !data.allowed.values.includes(value.value)) addIssue(issues, path, '状態変数の値が許容集合にありません。');
  return issues;
}
function validateLocalRules(entity, path, issues) {
  var _entity$data$terminal, _entity$data$value, _entity$data$value2, _entity$data$reason, _entity$data$sourceId;
  const issue = (field, message) => addIssue(issues, `${path}.${field}`, message);
  const unnamed = ['dialogue_line', 'effect', 'assertion', 'disclosure', 'cue', 'storyboard_frame', 'localization', 'recording', 'checkpoint', 'trace'];
  if (!unnamed.includes(entity.kind) && !entity.name.trim()) {
    if (entity.kind !== 'event') issue('name', '名称を入力してください。');else if (!richTextToPlainText(entity.data.summary).trim()) issue('data.summary', '名称または要約を入力してください。');
  }
  if (entity.visibility === 'projection' && !entity.projectionProfileId) issue('projectionProfileId', '公開投影の対象プロファイルを指定してください。');
  if (entity.deletedAt && !entity.deletionOperationId) issue('deletionOperationId', '削除には削除操作IDが必要です。');
  if (!entity.deletedAt && entity.deletionOperationId) issue('deletionOperationId', '削除されていない情報に削除操作IDは保存できません。');
  for (const customKey of Object.keys(entity.customValues)) {
    const schema = ENTITY_SCHEMAS[entity.kind];
    if (Object.hasOwn(commonFields, customKey) || schema.type === 'object' && Object.hasOwn(schema.fields, customKey)) issue(`customValues.${customKey}`, '標準項目とカスタム項目のキーが衝突しています。');
  }
  switch (entity.kind) {
    case 'event':
      for (const [index, constraint] of ((_entity$data$constrai = entity.data.constraints) !== null && _entity$data$constrai !== void 0 ? _entity$data$constrai : []).entries()) {
        var _entity$data$constrai;
        if (constraint.type === 'end_gap' && compareTicks(constraint.minimumTicks, constraint.maximumTicks) > 0) issue(`data.constraints[${index}]`, '日時差の最小値は最大値以下です。');
      }
      break;
    case 'item':
      if (entity.data.itemMode === 'instance' && !entity.data.typeId) issue('data.typeId', '物品の個体には種類への参照が必要です。');
      break;
    case 'flow_node':
      if (entity.data.nodeType === 'terminal' && !((_entity$data$terminal = entity.data.terminalReason) !== null && _entity$data$terminal !== void 0 && _entity$data$terminal.trim())) issue('data.terminalReason', '意図した終端には終了理由が必要です。');
      if (entity.data.nodeType === 'call' && !entity.data.childGraphId) issue('data.childGraphId', '呼出ノードには子分岐図が必要です。');
      break;
    case 'variable':
      {
        var _data$resetRules2, _data$resetRules3;
        const data = entity.data;
        if (data.scope === 'character' && !data.ownerId) issue('data.ownerId', '人物scopeには所有人物が必要です。');
        if (data.valueType === 'integer') {
          var _data$allowed$min2, _data$allowed$max2;
          if (data.allowed.values) issue('data.allowed.values', '整数には集合ではなくmin/maxを指定してください。');
          if (((_data$allowed$min2 = data.allowed.min) !== null && _data$allowed$min2 !== void 0 ? _data$allowed$min2 : -2147483647) > ((_data$allowed$max2 = data.allowed.max) !== null && _data$allowed$max2 !== void 0 ? _data$allowed$max2 : 2147483647)) issue('data.allowed', '整数の最小値は最大値以下です。');
        } else {
          var _data$allowed$values, _data$allowed$values2;
          if (data.allowed.min != null || data.allowed.max != null) issue('data.allowed', 'この型に数値範囲は設定できません。');
          if (data.valueType === 'enum' && (!((_data$allowed$values = data.allowed.values) !== null && _data$allowed$values !== void 0 && _data$allowed$values.length) || data.allowed.values.some(value => typeof value !== 'string' || !value))) issue('data.allowed.values', 'enumには空でない文字列の候補集合が必要です。');
          if (data.valueType === 'boolean' && (_data$allowed$values2 = data.allowed.values) !== null && _data$allowed$values2 !== void 0 && _data$allowed$values2.some(value => typeof value !== 'boolean')) issue('data.allowed.values', 'booleanの候補は真偽値です。');
        }
        issues.push(...validateVariableValue(entity, data.initial, `${path}.data.initial`));
        for (const [i, rule] of ((_data$resetRules = data.resetRules) !== null && _data$resetRules !== void 0 ? _data$resetRules : []).entries()) {
          var _data$resetRules;
          issues.push(...validateVariableValue(entity, rule.value, `${path}.data.resetRules[${i}].value`));
        }
        if (new Set(((_data$resetRules2 = data.resetRules) !== null && _data$resetRules2 !== void 0 ? _data$resetRules2 : []).map(rule => rule.on)).size !== ((_data$resetRules3 = data.resetRules) !== null && _data$resetRules3 !== void 0 ? _data$resetRules3 : []).length) issue('data.resetRules', '同じ終了時点の初期化規則は一つにしてください。');
        for (const [i, rule] of ((_data$transitionRules = data.transitionRules) !== null && _data$transitionRules !== void 0 ? _data$transitionRules : []).entries()) {
          var _data$transitionRules, _rule$reason;
          issues.push(...validateVariableValue(entity, rule.from, `${path}.data.transitionRules[${i}].from`, false), ...validateVariableValue(entity, rule.to, `${path}.data.transitionRules[${i}].to`, false));
          if (rule.exception && !((_rule$reason = rule.reason) !== null && _rule$reason !== void 0 && _rule$reason.trim())) issue(`data.transitionRules[${i}].reason`, '例外遷移には理由が必要です。');
        }
        for (const [i, rule] of ((_data$exclusions = data.exclusions) !== null && _data$exclusions !== void 0 ? _data$exclusions : []).entries()) {
          var _data$exclusions;
          issues.push(...validateVariableValue(entity, rule.value, `${path}.data.exclusions[${i}].value`, false));
          if (!rule.reason.trim()) issue(`data.exclusions[${i}].reason`, '相互排他には理由が必要です。');
        }
        break;
      }
    case 'effect':
      if (['set', 'add', 'move'].includes(entity.data.operation) && (!entity.data.value || entity.data.value.type === 'unknown')) issue('data.value', 'この効果には既知の入力値が必要です。');
      if (entity.data.operation === 'add' && ((_entity$data$value = entity.data.value) === null || _entity$data$value === void 0 ? void 0 : _entity$data$value.type) !== 'integer') issue('data.value', 'addはinteger値だけを使えます。');
      if (entity.data.operation === 'move' && ((_entity$data$value2 = entity.data.value) === null || _entity$data$value2 === void 0 ? void 0 : _entity$data$value2.type) !== 'ref') issue('data.value', 'moveには所在・所有先のref値が必要です。');
      if (entity.data.operation === 'consume' && !((_entity$data$reason = entity.data.reason) !== null && _entity$data$reason !== void 0 && _entity$data$reason.trim())) issue('data.reason', '消費・破壊には理由が必要です。');
      if (['grant', 'consume'].includes(entity.data.operation) && entity.data.value != null && (entity.data.value.type !== 'integer' || entity.data.value.value < 1)) issue('data.value', '物品数量は正のintegerです。');
      if (entity.data.operation === 'assert' && entity.data.value != null && entity.data.value.type !== 'boolean') issue('data.value', 'assertの真偽入力はbooleanです。');
      break;
    case 'assertion':
      if (entity.data.truthKind === 'belief' && !entity.data.holderId) issue('data.holderId', 'beliefには認識を持つ人物が必要です。');
      if (entity.data.truthKind === 'testimony' && !((_entity$data$sourceId = entity.data.sourceIds) !== null && _entity$data$sourceId !== void 0 && _entity$data$sourceId.length)) issue('data.sourceIds', 'testimonyには出所が必要です。');
      break;
    case 'storyboard_frame':
      if (entity.data.mediaEndMs != null && entity.data.mediaEndMs < entity.data.mediaStartMs) issue('data.mediaEndMs', '演出の終了は開始以上です。');
      break;
    case 'travel_route':
      if (entity.data.minimumTicks != null && parseTick(entity.data.minimumTicks) < 0n || entity.data.maximumTicks != null && parseTick(entity.data.maximumTicks) < 0n) issue('data', '移動所要時間は0以上です。');
      if (entity.data.minimumTicks != null && entity.data.maximumTicks != null && compareTicks(entity.data.minimumTicks, entity.data.maximumTicks) > 0) issue('data.maximumTicks', '最大所要時間は最小以上です。');
      break;
    case 'collection':
      if (entity.data.purpose === 'regression' && entity.data.mode !== 'fixed') issue('data.mode', '回帰経路集合は宣言した固定経路の集合です。');
      if (entity.data.mode === 'dynamic' && !entity.data.query) issue('data.query', '動的一覧には型付き検索条件が必要です。');
      if (entity.data.mode === 'fixed' && !Array.isArray(entity.data.memberIds)) issue('data.memberIds', '固定一覧にはID配列が必要です。');
      break;
    case 'template':
      {
        issues.push(...validateTemplateDefinition(entity.data, `${path}.data`));
        break;
      }
    case 'production_task':
      if (entity.data.deadline) {
        try {
          new Intl.DateTimeFormat('ja', {
            timeZone: entity.data.deadline.timeZone
          });
        } catch {
          issue('data.deadline.timeZone', '有効なタイムゾーンを指定してください。');
        }
      }
      if (entity.data.estimate) {
        const estimate = entity.data.estimate;
        if (estimate.value == null === (estimate.range == null)) issue('data.estimate', '見積もりはvalueまたはrangeの一つです。');
        if (estimate.range && estimate.range.min > estimate.range.max) issue('data.estimate.range', '見積範囲が逆転しています。');
        if (['reading_minutes', 'playing_minutes'].includes(estimate.unit) && !estimate.speed) issue('data.estimate.speed', '本文量からの時間見積もりには速度が必要です。');
      }
      break;
    case 'review':
      {
        const source = entity.data.sharedSource;
        if (!source) break;
        try {
          const url = new URL(source.connection);
          if (url.origin !== source.connection || url.username || url.password || !['https:', 'http:'].includes(url.protocol) || url.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) issue('data.sharedSource.connection', '指摘の専用接続先のoriginを確認してください。');
        } catch {
          issue('data.sharedSource.connection', '指摘の接続先が不正です。');
        }
        if (!ID_PATTERN.test(source.sharedSnapshot) || !ID_PATTERN.test(source.comment) || !source.publicVersion || !/^([a-f0-9]{64})$/.test(source.projectionHash) || !/^([a-f0-9]{64})$/.test(source.commentBodyHash)) issue('data.sharedSource', '元の公開版・指摘・hashが不正です。');
        if (!!source.publicEntity === !!source.publicRelation || source.publicRelation && (source.publicBlock !== undefined || source.startCp !== undefined || source.endCp !== undefined) || source.publicBlock !== undefined && (source.startCp === undefined || source.endCp === undefined || source.endCp <= source.startCp) || source.publicBlock === undefined && (source.startCp !== undefined || source.endCp !== undefined)) issue('data.sharedSource', '元指摘の対象とUnicode位置の組合せを確認してください。');
        break;
      }
    case 'localization':
    case 'recording':
      if (!/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(entity.data.language)) issue('data.language', '言語コードを指定してください（例: ja、en-US）。');
      break;
  }
  validateNestedRanges(entity.data, `${path}.data`, issues);
}
function validateNestedRanges(value, path, issues, depth = 0) {
  if (depth > 32 || !value || typeof value !== 'object') return;
  if (Array.isArray(value)) {
    value.forEach((item, i) => validateNestedRanges(item, `${path}[${i}]`, issues, depth + 1));
    return;
  }
  const object = value;
  if ('worldRange' in object && isObject(object.worldRange)) {
    const range = object.worldRange;
    if (isTick(range.start) && isTick(range.end) && compareTicks(range.start, range.end) >= 0) addIssue(issues, `${path}.worldRange`, '有効期間はstart < endの半開区間です。');
  }
  if ('entityId' in object && typeof object.start === 'number' && typeof object.end === 'number' && object.start >= object.end) addIssue(issues, path, '位置の文字範囲はstart < endです。');
  for (const [field, item] of Object.entries(object)) validateNestedRanges(item, `${path}.${field}`, issues, depth + 1);
}
export function collectReferences(entity) {
  const references = [];
  walk(entitySchema(entity.kind), entity, '', [], references);
  return references.map(reference => ({
    ...reference,
    path: reference.path.replace(/^\./, '')
  }));
}
export function collectRelationReferences(relation) {
  const references = [];
  walk(relationSchema, relation, '', [], references);
  return references.map(reference => ({
    ...reference,
    path: reference.path.replace(/^\./, '')
  }));
}
function pathParts(path) {
  return path.replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
}
function rewritePaths(source, references, idMap) {
  const copy = structuredClone(source),
    lookup = id => idMap instanceof Map ? idMap.get(id) : Object.hasOwn(idMap, id) ? idMap[id] : undefined;
  // Rewrite values while their old paths still exist, then move inner dictionary keys.
  const ordered = [...references].sort((a, b) => {
    const aKey = a.path.endsWith('.$key'),
      bKey = b.path.endsWith('.$key');
    return Number(aKey) - Number(bKey) || (aKey ? pathParts(b.path).length - pathParts(a.path).length : 0);
  });
  for (const reference of ordered) {
    const replacement = lookup(reference.id);
    if (!replacement) continue;
    const parts = pathParts(reference.path),
      dictionaryKey = parts.at(-1) === '$key';
    if (dictionaryKey) parts.pop();
    const field = parts.pop();
    if (!field) continue;
    let cursor = copy;
    for (const part of parts) cursor = cursor[part];
    if (dictionaryKey) {
      if (replacement === field) continue;
      if (Object.hasOwn(cursor, replacement)) throw new Error('REFERENCE_INVALID: 参照の統合で辞書キーが衝突します。保持する内容を選んでください。');
      cursor[replacement] = cursor[field];
      delete cursor[field];
    } else cursor[field] = replacement;
  }
  return copy;
}
export function rewriteEntityReferences(entity, idMap) {
  var _entity$data$reuse;
  const copy = rewritePaths(entity, collectReferences(entity), idMap),
    lookup = id => {
      var _ref;
      return (_ref = idMap instanceof Map ? idMap.get(id) : idMap[id]) !== null && _ref !== void 0 ? _ref : id;
    };
  if ((entity.kind === 'scene' || entity.kind === 'flow_node') && (_entity$data$reuse = entity.data.reuse) !== null && _entity$data$reuse !== void 0 && _entity$data$reuse.bindings && (copy.kind === 'scene' || copy.kind === 'flow_node') && copy.data.reuse) copy.data.reuse.bindings = Object.fromEntries(Object.entries(entity.data.reuse.bindings).map(([source, target]) => [lookup(source), lookup(target)]));
  return copy;
}
export function rewriteRelationReferences(relation, idMap) {
  return rewritePaths(relation, collectRelationReferences(relation), idMap);
}
const worldReferenceSchema = obj({
  projectId: req(idSchema),
  immutableSnapshotId: req(idSchema),
  contentHash: req({
    type: 'hash'
  })
});
const viewSchema = obj({
  id: req(idSchema),
  name: req(txt(1, 128)),
  view: req(txt(1)),
  entityIds: req(refs()),
  settings: req(record(union(txt(), num(), bool, en(null)), key))
});
const projectHeaderFields = {
  projectId: req(idSchema),
  name: req(txt(1, 128)),
  formatVersion: req(en(FORMAT_VERSION)),
  revision: req({
    type: 'revision'
  }),
  calendarId: req(txt(1)),
  mainStart: req(tick),
  worldReferences: req(arr(worldReferenceSchema))
};
const projectContentKeys = [...Object.keys(projectHeaderFields), 'calendars', 'entities', 'relations', 'views'];
const projectKeys = [...projectContentKeys, 'authorAlternatives'];
const alternativesSchema = arr({
  type: 'json'
}, false, 0, 100);
function validateActiveRecordNamespace(project, worlds, path, issues) {
  const pinnedProjects = new Set(),
    activeProjects = new Set([project.projectId]),
    ids = new Set();
  project.worldReferences.forEach((reference, index) => {
    if (pinnedProjects.has(reference.projectId)) addIssue(issues, `${path}.worldReferences[${index}]`, '同じ世界の複数の版を同時に参照すると、IDの参照先が曖昧になります。一つの固定版を選んでください。', 'REFERENCE_INVALID');
    pinnedProjects.add(reference.projectId);
  });
  const contexts = [{
    content: project,
    location: path
  }, ...worlds.map(world => {
    const referenceIndex = project.worldReferences.findIndex(reference => reference.projectId === world.projectId);
    return {
      content: world,
      location: `${path}.worldReferences[${referenceIndex}]`
    };
  })];
  const calendars = new Map();
  for (const [index, {
    content,
    location
  }] of contexts.entries()) {
    if (index > 0) {
      if (activeProjects.has(content.projectId)) addIssue(issues, location, '同じ作品・世界の複数の内容が現在の参照範囲に含まれています。固定版を一つにしてください。', 'REFERENCE_INVALID');
      activeProjects.add(content.projectId);
    }
    for (const [calendarIndex, calendar] of content.calendars.entries()) {
      const previous = calendars.get(calendar.id);
      if (previous && !sameCalendarDefinition(previous, calendar)) addIssue(issues, `${location}.calendars[${calendarIndex}].id`, '同じ暦IDに異なる定義があります。固定版の日時を読み替えず、暦IDを明示して対応付けてください。', 'REFERENCE_INVALID');
      calendars.set(calendar.id, calendar);
    }
    for (const [collection, records] of [['entities', content.entities], ['relations', content.relations]]) records.forEach((record, recordIndex) => {
      const recordPath = `${location}.${collection}[${recordIndex}]`;
      if (ids.has(record.id)) addIssue(issues, `${recordPath}.id`, '現在の作品と参照中の共通世界でentity・relationのIDが衝突しています。曖昧な参照は保存できません。', 'REFERENCE_INVALID');
      ids.add(record.id);
      if (record.projectId !== content.projectId) addIssue(issues, `${recordPath}.projectId`, '参照範囲のレコードが所属する作品・世界と一致しません。', 'REFERENCE_INVALID');
    });
  }
}
function validateContent(input, path, options, snapshotIds, versionContents = new Map(), reuse) {
  var _closure$worlds, _options$worlds, _closure$references, _closure$references2, _options$relationType;
  const issues = [];
  if (!isObject(input)) return {
    ok: false,
    issues: [{
      code: 'VALIDATION_FAILED',
      path,
      message: '作品はオブジェクトです。'
    }]
  };
  for (const field of Object.keys(input)) if (!projectContentKeys.includes(field)) addIssue(issues, `${path}.${field}`, '作品に未知の項目があります。');
  const header = Object.fromEntries(Object.keys(projectHeaderFields).filter(field => Object.hasOwn(input, field)).map(field => [field, input[field]]));
  walk(obj(projectHeaderFields), header, path, issues, []);
  if (input.formatVersion !== FORMAT_VERSION) addIssue(issues, `${path}.formatVersion`, '対応していない形式版です。', 'FORMAT_UNSUPPORTED');
  const arrays = ['entities', 'relations', 'calendars', 'views'];
  for (const field of arrays) if (!Array.isArray(input[field])) addIssue(issues, `${path}.${field}`, '必須の配列です。');
  if (issues.length) return {
    ok: false,
    issues
  };
  const entities = input.entities,
    relations = input.relations,
    calendars = input.calendars;
  if (entities.length + relations.length > 100000) return {
    ok: false,
    issues: [{
      code: 'IMPORT_LIMIT',
      path,
      message: 'entityとrelationの合計は100,000件までです。'
    }]
  };
  const previousEntities = new Map(reuse === null || reuse === void 0 ? void 0 : reuse.previous.entities.map(entity => [entity.id, entity])),
    previousRelations = new Map(reuse === null || reuse === void 0 ? void 0 : reuse.previous.relations.map(relation => [relation.id, relation]));
  // The structural walk already sees every typed reference. Keep those exact
  // observations for this synchronous validation instead of walking it twice.
  const entityReferences = new WeakMap(),
    relationReferences = new WeakMap();
  const relative = (references, prefix) => references.map(reference => ({
    ...reference,
    path: reference.path.slice(prefix.length + 1)
  }));
  entities.forEach((entity, i) => {
    if (reuse && isObject(entity) && previousEntities.get(entity.id) === entity) return;
    const prefix = `${path}.entities[${i}]`,
      references = [];
    const result = validateEntityRecord(entity, prefix, references);
    if (!result.ok) issues.push(...result.issues);else entityReferences.set(result.value, relative(references, prefix));
  });
  relations.forEach((relation, i) => {
    if (reuse && isObject(relation) && Object.is(previousRelations.get(relation.id), relation)) return;
    const prefix = `${path}.relations[${i}]`,
      references = [];
    const result = simpleValidate(relationSchema, relation, prefix, references);
    if (!result.ok) issues.push(...result.issues);else relationReferences.set(result.value, relative(references, prefix));
  });
  calendars.forEach((calendar, i) => {
    const result = validateCalendar(calendar, `${path}.calendars[${i}]`);
    if (!result.ok) issues.push(...result.issues);
  });
  const viewRefs = [];
  walk(arr(viewSchema), input.views, `${path}.views`, issues, viewRefs);
  if (issues.length) return {
    ok: false,
    issues: issues.slice(0, 256)
  };
  const project = input;
  const reusableSnapshots = [...versionContents].map(([id, content]) => ({
    id,
    content,
    contentHash: '',
    createdAt: '',
    versionLabel: ''
  }));
  issues.push(...reuseValidationIssues(project, reusableSnapshots, path));
  if (issues.length) return {
    ok: false,
    issues: issues.slice(0, 256)
  };
  const executionProject = project.entities.some(entity => {
    var _entity$data$reuse2;
    return (entity.kind === 'scene' || entity.kind === 'flow_node') && ((_entity$data$reuse2 = entity.data.reuse) === null || _entity$data$reuse2 === void 0 ? void 0 : _entity$data$reuse2.bindings);
  }) ? resolveReuseContent(project, reusableSnapshots) : project;
  const allowedWorldIds = new Set(executionProject.worldReferences.map(reference => reference.projectId));
  const closure = options.worldSnapshots ? resolvePinnedWorlds(executionProject, options.worldSnapshots) : undefined;
  if (closure) for (const message of closure.errors) addIssue(issues, `${path}.worldReferences`, message, 'REFERENCE_INVALID');
  const worlds = (_closure$worlds = closure === null || closure === void 0 ? void 0 : closure.worlds) !== null && _closure$worlds !== void 0 ? _closure$worlds : ((_options$worlds = options.worlds) !== null && _options$worlds !== void 0 ? _options$worlds : []).filter(world => allowedWorldIds.has(world.projectId));
  if (entities.length + relations.length + worlds.reduce((count, world) => count + world.entities.length + world.relations.length, 0) > 100000) addIssue(issues, path, '参照世界を含むレコード数が100,000件を超えています。', 'IMPORT_LIMIT');
  // Validate before constructing maps: a world record must never overwrite a local ID.
  // Each historical content calls this independently with its own pinned worlds.
  validateActiveRecordNamespace(project, worlds, path, issues);
  if (executionProject !== project) validateActiveRecordNamespace(executionProject, worlds, `${path}.reuse`, issues);
  if (issues.length) return {
    ok: false,
    issues: issues.slice(0, 256)
  };
  const allEntities = [...executionProject.entities, ...worlds.flatMap(world => world.entities)],
    entityMap = new Map(allEntities.map(entity => [entity.id, entity]));
  const relationMap = new Map([...project.relations, ...worlds.flatMap(world => world.relations)].map(relation => [relation.id, relation]));
  const allCalendarIds = new Set([...project.calendars, ...worlds.flatMap(world => world.calendars)].map(calendar => calendar.id));
  const ids = new Set();
  for (const [collection, records] of [['entities', project.entities], ['relations', project.relations]]) records.forEach((record, i) => {
    if (ids.has(record.id)) addIssue(issues, `${path}.${collection}[${i}].id`, 'entityとrelationのIDは作品内で一意です。');
    ids.add(record.id);
    if (record.projectId !== project.projectId) addIssue(issues, `${path}.${collection}[${i}].projectId`, 'レコードが別の作品に属しています。', 'REFERENCE_INVALID');
  });
  const calendarIds = project.calendars.map(calendar => calendar.id);
  if (new Set(calendarIds).size !== calendarIds.length) addIssue(issues, `${path}.calendars`, '暦IDが重複しています。');
  if (!calendarIds.includes(project.calendarId)) addIssue(issues, `${path}.calendarId`, '作品の暦が定義されていません。', 'REFERENCE_INVALID');
  const worldKeys = project.worldReferences.map(world => `${world.projectId}/${world.immutableSnapshotId}`);
  if (new Set(worldKeys).size !== worldKeys.length || project.worldReferences.some(world => world.projectId === project.projectId)) addIssue(issues, `${path}.worldReferences`, '共通世界参照の重複または自己参照があります。');
  const blocks = new Map(),
    aliases = new Map();
  for (const entity of allEntities) collectContentIds(entity.data, entity.id, blocks, aliases, issues, `${path}.entities.${entity.id}.data`);
  const projectionIds = new Set([...entityMap.keys(), ...relationMap.keys(), ...blocks.keys()]);
  for (const entity of allEntities) {
    var _entity$data$trigger;
    if (entity.kind === 'flow_node' && (_entity$data$trigger = entity.data.trigger) !== null && _entity$data$trigger !== void 0 && _entity$data$trigger.id) projectionIds.add(entity.data.trigger.id);
    if (entity.kind === 'projection_profile') for (const publicFields of Object.values((_entity$data$publicTe = entity.data.publicTexts) !== null && _entity$data$publicTe !== void 0 ? _entity$data$publicTe : {})) {
      var _entity$data$publicTe;
      for (const field of Object.values(publicFields)) if (Array.isArray(field)) for (const block of field) if (isObject(block) && typeof block.id === 'string') projectionIds.add(block.id);
    }
  }
  const worldVersionDependencies = worlds.flatMap(world => [...world.entities.flatMap(collectReferences), ...world.relations.flatMap(collectRelationReferences)]).filter(reference => {
    var _options$worldSnapsho;
    return reference.scope === 'snapshot' && ((_options$worldSnapsho = options.worldSnapshots) === null || _options$worldSnapsho === void 0 ? void 0 : _options$worldSnapsho[reference.id]) && worlds.some(world => {
      var _options$worldSnapsho2;
      return world.projectId === ((_options$worldSnapsho2 = options.worldSnapshots) === null || _options$worldSnapsho2 === void 0 ? void 0 : _options$worldSnapsho2[reference.id].projectId);
    });
  }).map(reference => reference.id);
  const knownVersions = new Set([...snapshotIds, ...worldVersionDependencies, project.projectId, ...allEntities.filter(entity => entity.kind === 'snapshot').map(entity => entity.id), ...((_closure$references = closure === null || closure === void 0 ? void 0 : closure.references) !== null && _closure$references !== void 0 ? _closure$references : executionProject.worldReferences).map(world => world.immutableSnapshotId)]);
  const knownProjects = new Set([project.projectId, ...((_closure$references2 = closure === null || closure === void 0 ? void 0 : closure.references) !== null && _closure$references2 !== void 0 ? _closure$references2 : executionProject.worldReferences).map(world => world.projectId)]);
  const currentIndex = {
      entities: entityMap,
      relations: relationMap,
      blocks,
      calendars: allCalendarIds,
      projects: knownProjects,
      projectionIds
    },
    versionIndexes = new Map();
  function versionIndex(versionId) {
    var _versionContents$get, _options$worldSnapsho3, _versionClosure$world, _options$worlds2;
    if (versionId === project.projectId && !project.entities.some(entity => {
      var _entity$data$reuse3;
      return (entity.kind === 'scene' || entity.kind === 'flow_node') && ((_entity$data$reuse3 = entity.data.reuse) === null || _entity$data$reuse3 === void 0 ? void 0 : _entity$data$reuse3.bindings);
    })) return currentIndex;
    const cached = versionIndexes.get(versionId);
    if (cached) return cached;
    const rawContent = versionId === project.projectId ? project : (_versionContents$get = versionContents.get(versionId)) !== null && _versionContents$get !== void 0 ? _versionContents$get : (_options$worldSnapsho3 = options.worldSnapshots) === null || _options$worldSnapsho3 === void 0 ? void 0 : _options$worldSnapsho3[versionId];
    if (!rawContent) return undefined;
    let content = rawContent;
    try {
      if (content.entities.some(entity => {
        var _entity$data$reuse4;
        return (entity.kind === 'scene' || entity.kind === 'flow_node') && ((_entity$data$reuse4 = entity.data.reuse) === null || _entity$data$reuse4 === void 0 ? void 0 : _entity$data$reuse4.bindings);
      })) content = resolveReuseContent(content, reusableSnapshots);
    } catch {
      return undefined;
    }
    const versionClosure = options.worldSnapshots ? resolvePinnedWorlds(content, options.worldSnapshots) : undefined;
    if (versionClosure) for (const message of versionClosure.errors) addIssue(issues, `${path}.versions.${versionId}.worldReferences`, message, 'REFERENCE_INVALID');
    const pinnedWorlds = (_versionClosure$world = versionClosure === null || versionClosure === void 0 ? void 0 : versionClosure.worlds) !== null && _versionClosure$world !== void 0 ? _versionClosure$world : ((_options$worlds2 = options.worlds) !== null && _options$worlds2 !== void 0 ? _options$worlds2 : []).filter(world => content.worldReferences.some(reference => reference.projectId === world.projectId));
    const before = issues.length;
    validateActiveRecordNamespace(content, pinnedWorlds, `${path}.versions.${versionId}`, issues);
    if (issues.length !== before) return undefined;
    const records = [...content.entities, ...pinnedWorlds.flatMap(world => world.entities)],
      versionBlocks = new Map();
    for (const record of records) if (isObject(record)) collectContentIds(record.data, record.id, versionBlocks, new Map(), [], 'version');
    const versionProjectionIds = new Set([...records.map(record => record.id), ...content.relations.map(relation => relation.id), ...pinnedWorlds.flatMap(world => world.relations.map(relation => relation.id)), ...versionBlocks.keys()]);
    for (const entity of records) {
      var _entity$data$trigger2;
      if (entity.kind === 'flow_node' && (_entity$data$trigger2 = entity.data.trigger) !== null && _entity$data$trigger2 !== void 0 && _entity$data$trigger2.id) versionProjectionIds.add(entity.data.trigger.id);
      if (entity.kind === 'projection_profile') for (const fields of Object.values((_entity$data$publicTe2 = entity.data.publicTexts) !== null && _entity$data$publicTe2 !== void 0 ? _entity$data$publicTe2 : {})) {
        var _entity$data$publicTe2;
        for (const value of Object.values(fields)) if (Array.isArray(value)) for (const block of value) if (isObject(block) && typeof block.id === 'string') versionProjectionIds.add(block.id);
      }
    }
    const index = {
      entities: new Map(records.filter(record => isObject(record)).map(record => [record.id, record])),
      relations: new Map([...content.relations, ...pinnedWorlds.flatMap(world => world.relations)].filter(record => isObject(record)).map(record => [record.id, record])),
      blocks: versionBlocks,
      calendars: new Set([...content.calendars, ...pinnedWorlds.flatMap(world => world.calendars)].map(calendar => calendar.id)),
      projects: new Set([content.projectId, ...pinnedWorlds.map(world => world.projectId)]),
      projectionIds: versionProjectionIds
    };
    versionIndexes.set(versionId, index);
    return index;
  }
  function inspect(reference, prefix = '', index = currentIndex) {
    const location = prefix ? `${prefix}.${reference.path}` : reference.path;
    let exists = true;
    if (reference.scope === 'entity') {
      const target = index.entities.get(reference.id);
      exists = !!target;
      if (target && reference.kinds && !reference.kinds.includes(target.kind)) addIssue(issues, location, `参照先の種類は${reference.kinds.map(kind => KIND_LABELS[kind]).join(' / ')}です。`, 'REFERENCE_INVALID');
      if (target && options.runtime && target.deletedAt) addIssue(issues, location, '削除済み情報は実行用出力で参照できません。', 'REFERENCE_INVALID');
    } else if (reference.scope === 'relation') exists = index.relations.has(reference.id);else if (reference.scope === 'record') exists = index.entities.has(reference.id) || index.relations.has(reference.id);else if (reference.scope === 'projection_record') exists = index.projectionIds.has(reference.id);else if (reference.scope === 'presentation') exists = index.entities.has(reference.id) || index.blocks.has(reference.id);else if (reference.scope === 'calendar') exists = index.calendars.has(reference.id);else if (reference.scope === 'project') exists = index.projects.has(reference.id);else if (reference.scope === 'snapshot') exists = knownVersions.has(reference.id);else if (reference.scope === 'block') exists = index.blocks.has(reference.id);else if (reference.scope === 'alias') exists = aliases.has(reference.id);
    if (!exists) addIssue(issues, location, '参照先が存在しないか、指定した作品・共通世界の範囲外です。', 'REFERENCE_INVALID');
  }
  const referencesFor = entity => {
    const observed = entityReferences.get(entity);
    if (observed) return observed;
    if (!reuse || previousEntities.get(entity.id) !== entity) return collectReferences(entity);
    const cached = reuse.references.get(entity);
    if (cached) return cached;
    const references = collectReferences(entity);
    reuse.references.set(entity, references);
    return references;
  };
  project.entities.forEach((entity, i) => {
    const prefix = `${path}.entities[${i}]`;
    for (const reference of referencesFor(entity)) {
      var _entity$data$handoffR, _ref2, _entity$data$publicTe3;
      const parts = pathParts(reference.path),
        parent = parts.slice(0, -1).reduce((object, field) => object && typeof object === 'object' ? object[field] : undefined, entity);
      const reuseVersion = (entity.kind === 'scene' || entity.kind === 'flow_node') && entity.data.reuse && reference.path === 'data.reuse.sourceId' ? entity.data.reuse.pinnedSnapshotId : undefined;
      const profileVersion = entity.kind === 'projection_profile' && entity.data.sourceVersionId && /^data\.(?:includedIds|publicTexts|blockSources|publicIds|publicValues|namePolicy|allowedRelationIds|approvedAttachmentIds)(?:\.|\[)/.test(reference.path) ? entity.data.sourceVersionId : undefined;
      const gameProfileVersion = entity.kind === 'note' && reference.path === 'data.handoffReceipt.profileId' ? (_entity$data$handoffR = entity.data.handoffReceipt) === null || _entity$data$handoffR === void 0 ? void 0 : _entity$data$handoffR.profileVersionId : undefined;
      const anchorVersion = (_ref2 = gameProfileVersion !== null && gameProfileVersion !== void 0 ? gameProfileVersion : reuseVersion) !== null && _ref2 !== void 0 ? _ref2 : isObject(parent) && typeof parent.entityId === 'string' && typeof parent.sourceVersionId === 'string' ? parent.sourceVersionId : entity.kind === 'review' && reference.path.startsWith('data.target.') ? entity.data.targetVersionId : profileVersion;
      // Independently authored public paragraphs belong to the approval policy,
      // while blockSources values still resolve in the historical source edition.
      if (entity.kind === 'projection_profile' && reference.scope === 'projection_record' && reference.path.endsWith('.$key') && Object.values((_entity$data$publicTe3 = entity.data.publicTexts) !== null && _entity$data$publicTe3 !== void 0 ? _entity$data$publicTe3 : {}).some(fields => Object.values(fields).some(value => Array.isArray(value) && value.some(block => block.id === reference.id)))) {
        inspect(reference, prefix);
        continue;
      }
      const usesVersion = entity.kind === 'checkpoint' && (reference.path.startsWith('data.runtimeState.') || reference.path.startsWith('data.presentationState.') || reference.path.startsWith('data.presentationResults[')) || entity.kind === 'trace' && (reference.path.startsWith('data.steps[') || reference.path.startsWith('data.initialExternalValues.') || reference.path.startsWith('data.initialStubValues.') || reference.path.startsWith('data.initialStubBaseState.') || reference.path.startsWith('data.readingPath.'));
      if (anchorVersion || usesVersion && (entity.kind === 'checkpoint' || entity.kind === 'trace')) {
        const version = anchorVersion !== null && anchorVersion !== void 0 ? anchorVersion : entity.kind === 'checkpoint' || entity.kind === 'trace' ? entity.data.contentVersionId : project.projectId,
          index = versionIndex(version);
        if (!index) {
          addIssue(issues, anchorVersion ? entity.kind === 'review' ? `${prefix}.data.targetVersionId` : `${prefix}.${parts.slice(0, -1).join('.')}.sourceVersionId` : `${prefix}.data.contentVersionId`, '参照する固定版の本文がありません。', 'REFERENCE_INVALID');
          continue;
        }
        inspect(reference, prefix, index);
      } else inspect(reference, prefix);
    }
  });
  project.relations.forEach((relation, i) => {
    var _relationReferences$g;
    return ((_relationReferences$g = relationReferences.get(relation)) !== null && _relationReferences$g !== void 0 ? _relationReferences$g : collectRelationReferences(relation)).forEach(reference => inspect(reference, `${path}.relations[${i}]`));
  });
  viewRefs.forEach(reference => inspect(reference));
  const relationTypes = (_options$relationType = options.relationTypes) !== null && _options$relationType !== void 0 ? _options$relationType : RELATION_TYPES;
  project.relations.forEach((relation, i) => {
    const location = `${path}.relations[${i}]`,
      type = relationTypes.find(candidate => candidate.key === relation.relationType),
      from = entityMap.get(relation.fromId),
      to = entityMap.get(relation.toId);
    if (!type) addIssue(issues, `${location}.relationType`, '関係の種類が辞書に定義されていません。');else {
      if (from && !type.fromKinds.includes(from.kind)) addIssue(issues, `${location}.fromId`, 'この関係で許されない始点種類です。', 'REFERENCE_INVALID');
      if (to && !type.toKinds.includes(to.kind)) addIssue(issues, `${location}.toId`, 'この関係で許されない終点種類です。', 'REFERENCE_INVALID');
      if (relation.fromId === relation.toId && !type.allowSelf) addIssue(issues, location, 'この関係は自己関係を許しません。');
      if (relation.direction === 'symmetric' && !type.allowSymmetric) addIssue(issues, `${location}.direction`, 'この関係は対称ではありません。');
    }
    if (relation.deletedAt && !relation.deletionOperationId) addIssue(issues, `${location}.deletionOperationId`, '削除には操作IDが必要です。');
    validateNestedRanges(relation.validity, `${location}.validity`, issues);
  });
  let affectedIds;
  if (reuse && JSON.stringify(project.worldReferences) === JSON.stringify(reuse.previous.worldReferences) && JSON.stringify(project.calendars) === JSON.stringify(reuse.previous.calendars)) {
    affectedIds = new Set([...project.entities.filter(entity => previousEntities.get(entity.id) !== entity).map(entity => entity.id), ...project.relations.filter(relation => previousRelations.get(relation.id) !== relation).map(relation => relation.id)]);
    for (const id of previousEntities.keys()) if (!entityMap.has(id)) affectedIds.add(id);
    for (const id of previousRelations.keys()) if (!relationMap.has(id)) affectedIds.add(id);
  }
  validateCrossEntityRules(project, entityMap, aliases, knownVersions, blocks, issues, path, options, versionIndex, affectedIds ? entity => previousEntities.get(entity.id) !== entity || referencesFor(entity).some(reference => affectedIds.has(reference.id)) : undefined);
  return issues.length ? {
    ok: false,
    issues: issues.slice(0, 256)
  } : {
    ok: true,
    value: project
  };
}
function collectContentIds(value, owner, blocks, aliases, issues, path, depth = 0) {
  if (depth > 32 || !value || typeof value !== 'object') return;
  if (Array.isArray(value)) {
    value.forEach((child, i) => collectContentIds(child, owner, blocks, aliases, issues, `${path}[${i}]`, depth + 1));
    return;
  }
  const object = value;
  if (typeof object.id === 'string' && typeof object.text === 'string' && ['paragraph', 'heading', 'list_item', 'quote'].includes(object.kind)) {
    if (blocks.has(object.id)) addIssue(issues, `${path}.id`, '本文ブロックIDが重複しています。');
    blocks.set(object.id, {
      entityId: owner,
      text: object.text
    });
  }
  if (typeof object.id === 'string' && 'isPublicDefault' in object) {
    if (aliases.has(object.id)) addIssue(issues, `${path}.id`, '別名IDが重複しています。');
    aliases.set(object.id, {
      entityId: owner,
      alias: object
    });
  }
  for (const [key, child] of Object.entries(object)) {
    // Trace/checkpoint values and projection public text are copies, not canonical blocks.
    if (['runtimeState', 'before', 'after', 'publicTexts'].includes(key)) continue;
    collectContentIds(child, owner, blocks, aliases, issues, `${path}.${key}`, depth + 1);
  }
}
function cycleIssues(nodes, edges, issues, path, label) {
  const index = new Map(nodes.map(node => [node.id, node])),
    colors = new Map();
  for (const node of nodes) {
    if (colors.get(node.id)) continue;
    const stack = [{
      id: node.id,
      ids: edges(node),
      cursor: 0
    }];
    colors.set(node.id, 1);
    while (stack.length) {
      const current = stack[stack.length - 1];
      if (current.cursor >= current.ids.length) {
        colors.set(current.id, 2);
        stack.pop();
        continue;
      }
      const nextId = current.ids[current.cursor++],
        next = index.get(nextId);
      if (!next) continue;
      if (colors.get(nextId) === 1) {
        addIssue(issues, `${path}.entities.${current.id}.data`, `${label}に循環があります。`);
        continue;
      }
      if (!colors.get(nextId)) {
        colors.set(nextId, 1);
        stack.push({
          id: nextId,
          ids: edges(next),
          cursor: 0
        });
      }
    }
  }
}
function validateCrossEntityRules(project, entityMap, aliases, knownVersions, blocks, issues, path, options, resolveVersion, affected) {
  const keys = new Map(),
    translationKeys = new Set();
  // Assignments also depend on a template's whole field set, including new fields.
  // Keep this check identical in full imports and incremental local saves.
  if (project.entities.some(entity => !!entity.templateId && !entity.deletedAt)) issues.push(...validateTemplateAssignments(project, path, [...entityMap.values()]));
  project.entities.forEach((entity, i) => {
    const location = `${path}.entities[${i}]`;
    if (entity.deletedAt) return;
    if (entity.kind === 'variable' || entity.kind === 'quest' || entity.kind === 'external_contract') {
      var _entity$data$ownerId;
      const unique = `${entity.kind}/${entity.kind === 'variable' ? `${entity.data.scope}/${(_entity$data$ownerId = entity.data.ownerId) !== null && _entity$data$ownerId !== void 0 ? _entity$data$ownerId : ''}/` : ''}${entity.data.key}`;
      if (keys.has(unique)) addIssue(issues, `${location}.data.key`, '同じスコープでキーが重複しています。');
      keys.set(unique, entity.id);
    }
    if (entity.kind === 'localization') {
      const unique = `${entity.data.sourceLineId}/${entity.data.language}/${entity.data.sourceHash}`;
      if (translationKeys.has(unique)) addIssue(issues, location, '同じ台詞・言語・原文版の翻訳が重複しています。');
      translationKeys.add(unique);
    }
    // Namespace/key uniqueness, reference existence and graph-wide checks always run.
    // Value/anchor rules only need unchanged records when one of their dependencies changed.
    // Checkpoint/trace evidence also depends on the eligible record set, including newly added IDs.
    if (affected && !affected(entity) && entity.kind !== 'checkpoint' && entity.kind !== 'trace') return;
    if (entity.kind === 'template') issues.push(...validateTemplateDefinition(entity.data, `${location}.data`, entityMap));
    if (entity.kind === 'item' && entity.data.itemMode === 'instance') {
      const type = entity.data.typeId ? entityMap.get(entity.data.typeId) : undefined;
      if ((type === null || type === void 0 ? void 0 : type.kind) === 'item' && type.data.itemMode !== 'type') addIssue(issues, `${location}.data.typeId`, '個体のtypeIdは物品種類を参照してください。', 'REFERENCE_INVALID');
    }
    if (entity.kind === 'quest') {
      const variable = entityMap.get(entity.data.stateVariableId);
      if ((variable === null || variable === void 0 ? void 0 : variable.kind) === 'variable') for (const [j, rule] of ((_entity$data$transiti = entity.data.transitionRules) !== null && _entity$data$transiti !== void 0 ? _entity$data$transiti : []).entries()) {
        var _entity$data$transiti;
        issues.push(...validateVariableValue(variable, rule.from, `${location}.data.transitionRules[${j}].from`, false), ...validateVariableValue(variable, rule.to, `${location}.data.transitionRules[${j}].to`, false));
      }
    }
    if (entity.kind === 'variable') for (const [j, rule] of ((_entity$data$exclusio = entity.data.exclusions) !== null && _entity$data$exclusio !== void 0 ? _entity$data$exclusio : []).entries()) {
      var _entity$data$exclusio;
      const other = entityMap.get(rule.variableId);
      if ((other === null || other === void 0 ? void 0 : other.kind) === 'variable') issues.push(...validateVariableValue(other, rule.otherValue, `${location}.data.exclusions[${j}].otherValue`, false));
    }
    if (entity.kind === 'collection' && entity.data.purpose === 'regression') for (const [j, id] of ((_entity$data$memberId = entity.data.memberIds) !== null && _entity$data$memberId !== void 0 ? _entity$data$memberId : []).entries()) {
      var _entity$data$memberId;
      const trace = entityMap.get(id);
      if (trace && trace.kind !== 'trace') addIssue(issues, `${location}.data.memberIds[${j}]`, '回帰経路集合には保存した試読記録を指定してください。', 'REFERENCE_INVALID');
    }
    if (entity.kind === 'effect') {
      var _entity$data$value3;
      const target = entityMap.get(entity.data.targetId),
        operation = entity.data.operation;
      if (target && ['set', 'add', 'reset'].includes(operation)) {
        if (target.kind !== 'variable') addIssue(issues, `${location}.data.targetId`, '状態更新効果は状態変数を参照してください。', 'REFERENCE_INVALID');else {
          if (target.data.derived) addIssue(issues, `${location}.data.targetId`, '算出状態へ直接代入できません。');
          if (operation === 'add' && target.data.valueType !== 'integer') addIssue(issues, `${location}.data.targetId`, 'addはinteger状態だけです。');
          if (entity.data.value && operation !== 'add') issues.push(...validateVariableValue(target, entity.data.value, `${location}.data.value`));
        }
      }
      if (target && ['grant', 'consume', 'move'].includes(operation) && target.kind !== 'item') addIssue(issues, `${location}.data.targetId`, '物品効果は物品を参照してください。', 'REFERENCE_INVALID');
      if ((target === null || target === void 0 ? void 0 : target.kind) === 'item' && ['grant', 'consume', 'move'].includes(operation) && entity.data.instanceId) {
        const instance = entityMap.get(entity.data.instanceId);
        if ((instance === null || instance === void 0 ? void 0 : instance.kind) === 'item' && (instance.data.itemMode !== 'instance' || (target.data.itemMode === 'type' ? instance.data.typeId !== target.id : instance.id !== target.id))) addIssue(issues, `${location}.data.instanceId`, '指定した個体が効果の対象物品に属していません。', 'REFERENCE_INVALID');
      }
      if (target && operation === 'assert' && target.kind !== 'assertion') addIssue(issues, `${location}.data.targetId`, '認識効果は事実・認識を参照してください。', 'REFERENCE_INVALID');
      if (operation === 'move' && ((_entity$data$value3 = entity.data.value) === null || _entity$data$value3 === void 0 ? void 0 : _entity$data$value3.type) === 'ref') {
        const destination = entityMap.get(entity.data.value.value);
        if (destination && !['character', 'group', 'place'].includes(destination.kind)) addIssue(issues, `${location}.data.value`, '物品の移動先は人物・グループ・場所です。', 'REFERENCE_INVALID');
      }
    }
    if (entity.kind === 'flow_graph') {
      var _entity$data$paramete;
      for (const entry of [...entity.data.entryIds, ...entity.data.exitIds]) if (!entity.data.nodeIds.includes(entry)) addIssue(issues, `${location}.data`, '入口・出口はその分岐図のノード集合に含めてください。');
      for (const edgeId of entity.data.edgeIds) {
        const edge = entityMap.get(edgeId);
        if ((edge === null || edge === void 0 ? void 0 : edge.kind) !== 'flow_edge') continue;
        if (!entity.data.nodeIds.includes(edge.data.fromId) || typeof edge.data.toId === 'string' && !entity.data.nodeIds.includes(edge.data.toId)) addIssue(issues, `${location}.data.edgeIds`, '進行線の始点・終点は同じ分岐図内に置いてください。');
      }
      const parameterKeys = ((_entity$data$paramete = entity.data.parameters) !== null && _entity$data$paramete !== void 0 ? _entity$data$paramete : []).map(parameter => parameter.key);
      if (new Set(parameterKeys).size !== parameterKeys.length) addIssue(issues, `${location}.data.parameters`, '引数のキーが重複しています。');
    }
    if (entity.kind === 'flow_edge' && options.runtime && typeof entity.data.toId !== 'string') addIssue(issues, `${location}.data.toId`, '未完成の分岐先は実行用出力できません。', 'EXPORT_UNSUPPORTED');
    if (entity.kind === 'variable' && options.runtime && entity.data.initial.type === 'unknown' && !entity.data.derived) addIssue(issues, `${location}.data.initial`, '初期値が未定です。', 'CONDITION_UNKNOWN');
    validateConditionTypesInValue(entity.data, location, entityMap, issues);
    if (entity.kind === 'review' && typeof entity.data.target === 'object') {
      validateAnchors(entity.data.target, `${location}.data.target`, entityMap, blocks, issues, 0, resolveVersion, entity.data.targetVersionId);
      validateAnchors({
        ...entity.data,
        target: null
      }, `${location}.data`, entityMap, blocks, issues, 0, resolveVersion);
    } else validateAnchors(entity.data, `${location}.data`, entityMap, blocks, issues, 0, resolveVersion);
    if (entity.kind === 'projection_profile') {
      const policy = entity.data.namePolicy;
      if ('mode' in policy && policy.mode === 'alias') {
        const alias = aliases.get(policy.aliasId);
        if (alias && !entity.data.includedIds.includes(alias.entityId)) addIssue(issues, `${location}.data.namePolicy`, '別名は投影対象の本体に属している必要があります。');
      } else if (!('mode' in policy)) for (const [targetId, specific] of Object.entries((_policy$byEntityId = policy.byEntityId) !== null && _policy$byEntityId !== void 0 ? _policy$byEntityId : {})) {
        var _policy$byEntityId, _aliases$get;
        if (specific.mode === 'alias' && ((_aliases$get = aliases.get(specific.aliasId)) === null || _aliases$get === void 0 ? void 0 : _aliases$get.entityId) !== targetId) addIssue(issues, `${location}.data.namePolicy.byEntityId.${targetId}`, '別名が指定した本体に属していません。');
      }
    }
    if (entity.kind === 'checkpoint' && (!knownVersions.has(entity.data.runtimeState.contentVersionId) || entity.data.runtimeState.contentVersionId !== entity.data.contentVersionId)) addIssue(issues, `${location}.data.runtimeState.contentVersionId`, '途中開始の状態と対象版が一致しません。');
    if (entity.kind === 'checkpoint') {
      const result = validateRuntimeState(entity.data.runtimeState, `${location}.data.runtimeState`);
      if (!result.ok) issues.push(...result.issues);
      if (entity.data.presentationState && (entity.data.presentationState.contentVersionId !== entity.data.contentVersionId || entity.data.presentationState.presentationPosition !== entity.data.runtimeState.presentationPosition || entity.data.presentationState.provenance !== entity.data.runtimeState.provenance)) addIssue(issues, `${location}.data.presentationState`, '提示前の観測状態と開始点・対象版・由来が一致しません。');
      if (entity.data.presentationResults != null) {
        var _entity$data$origin;
        const version = resolveVersion(entity.data.contentVersionId);
        if (version) issues.push(...validateInitialPresentationResults({
          ...entity.data.runtimeState,
          provenance: (_entity$data$origin = entity.data.origin) !== null && _entity$data$origin !== void 0 ? _entity$data$origin : 'partial'
        }, entity.data.presentationResults, [...version.entities.values()], `${location}.data.presentationResults`));
      }
    }
    if (entity.kind === 'trace') {
      var _trace$readingPath;
      const trace = entity.data;
      if (trace.initialStubBaseState && !trace.initialStubValues) addIssue(issues, `${location}.data.initialStubBaseState`, 'stub前の個別状態には初期stub入力の記録が必要です。');
      if (trace.mode === 'chapters') {
        if (trace.initialStubValues || trace.initialStubBaseState) addIssue(issues, `${location}.data.initialStubValues`, '章経路の個別開始はcheckpointへ、外部仮値はinitialExternalValuesへ記録してください。');
        if (!trace.readingPath) addIssue(issues, `${location}.data.readingPath`, '章読み通しには提示経路が必要です。');
        if (trace.steps.length) addIssue(issues, `${location}.data.steps`, '章読み通しとフロー遷移を混在させられません。');
      } else if (trace.readingPath != null) addIssue(issues, `${location}.data.readingPath`, '提示経路はmode:chaptersの記録に指定してください。');
      trace.steps.forEach((step, index) => {
        for (const [field, state] of [['before', step.before], ['after', step.after]]) {
          const result = validateRuntimeState(state, `${location}.data.steps[${index}].${field}`);
          if (!result.ok) issues.push(...result.issues);
        }
        if (step.presentationState && (step.presentationState.contentVersionId !== trace.contentVersionId || step.presentationState.presentationPosition !== step.after.presentationPosition || step.presentationState.provenance !== step.after.provenance)) addIssue(issues, `${location}.data.steps[${index}].presentationState`, '提示前の観測状態と提示先・対象版・由来が一致しません。');
      });
      (_trace$readingPath = trace.readingPath) === null || _trace$readingPath === void 0 || _trace$readingPath.occurrences.forEach((occurrence, index) => {
        for (const [field, state] of [['before', occurrence.before], ['after', occurrence.after]]) {
          const result = validateRuntimeState(state, `${location}.data.readingPath.occurrences[${index}].${field}`);
          if (!result.ok) issues.push(...result.issues);
        }
      });
    }
  });
  for (const kind of ['place', 'group', 'flow_graph', 'map']) cycleIssues(project.entities.filter(entity => entity.kind === kind && !entity.deletedAt), entity => {
    if (entity.kind === 'place' || entity.kind === 'group') return entity.data.parentId ? [entity.data.parentId] : [];
    if (entity.kind === 'flow_graph') return entity.data.parentGraphId ? [entity.data.parentGraphId] : [];
    if (entity.kind === 'map') return entity.data.parentMapId ? [entity.data.parentMapId] : [];
    return [];
  }, issues, path, `${KIND_LABELS[kind]}の階層`);
  cycleIssues(project.entities.filter(entity => entity.kind === 'production_task' && !entity.deletedAt), entity => {
    var _entity$data$dependsO;
    return entity.kind === 'production_task' ? (_entity$data$dependsO = entity.data.dependsOn) !== null && _entity$data$dependsO !== void 0 ? _entity$data$dependsO : [] : [];
  }, issues, path, '制作依存');
  cycleIssues(project.entities.filter(entity => entity.kind === 'variable' && !entity.deletedAt), entity => entity.kind === 'variable' && entity.data.derived ? expressionReferences(entity.data.derived) : [], issues, path, '算出状態');
  cycleIssues(project.entities.filter(entity => entity.kind === 'flow_graph' && !entity.deletedAt), entity => entity.kind === 'flow_graph' ? entity.data.nodeIds.flatMap(nodeId => {
    const node = entityMap.get(nodeId);
    return (node === null || node === void 0 ? void 0 : node.kind) === 'flow_node' && node.data.childGraphId ? [node.data.childGraphId] : [];
  }) : [], issues, path, '分岐図の呼出階層');
  issues.push(...validateEventTimes([...entityMap.values()].filter(entity => entity.kind === 'event' && !entity.deletedAt)));
  const automaticPriority = new Map();
  for (const entity of project.entities) if (entity.kind === 'flow_edge' && entity.data.edgeType === 'automatic' && !entity.deletedAt) {
    var _entity$data$priority;
    const priorityKey = `${entity.data.fromId}/${(_entity$data$priority = entity.data.priority) !== null && _entity$data$priority !== void 0 ? _entity$data$priority : 0}`;
    if (automaticPriority.has(priorityKey)) addIssue(issues, `${path}.entities.${entity.id}.data.priority`, '同じ始点の自動候補で優先順位が重複しています。');
    automaticPriority.set(priorityKey, entity.id);
  }
}
function expressionReferences(expression) {
  const references = [];
  walk({
    type: 'expression'
  }, expression, '', [], references);
  return references.filter(reference => {
    var _reference$kinds;
    return (_reference$kinds = reference.kinds) === null || _reference$kinds === void 0 ? void 0 : _reference$kinds.includes('variable');
  }).map(reference => reference.id);
}
function validateConditionTypesInValue(value, path, entities, issues, depth = 0) {
  if (depth > 32 || !value || typeof value !== 'object') return;
  if (Array.isArray(value)) {
    value.forEach((child, i) => validateConditionTypesInValue(child, `${path}[${i}]`, entities, issues, depth + 1));
    return;
  }
  const object = value;
  if (object.op === 'compare') {
    const variable = entities.get(object.variableId);
    if ((variable === null || variable === void 0 ? void 0 : variable.kind) === 'variable') {
      const comparator = object.comparator,
        values = Array.isArray(object.value) ? object.value : [object.value];
      if (['lt', 'le', 'gt', 'ge'].includes(comparator) && variable.data.valueType !== 'integer') addIssue(issues, `${path}.comparator`, '順序比較はintegerにだけ使えます。');
      values.forEach((item, i) => {
        if (item.type !== 'unknown' && item.type !== variable.data.valueType) addIssue(issues, `${path}.value${values.length > 1 ? `[${i}]` : ''}`, '比較値の型が状態変数と一致しません。');
      });
    }
  }
  for (const [field, child] of Object.entries(object)) validateConditionTypesInValue(child, `${path}.${field}`, entities, issues, depth + 1);
}
function validateAnchors(value, path, entities, blocks, issues, depth = 0, resolveVersion, defaultVersion) {
  if (depth > 32 || !value || typeof value !== 'object') return;
  if (Array.isArray(value)) {
    value.forEach((child, i) => validateAnchors(child, `${path}[${i}]`, entities, blocks, issues, depth + 1, resolveVersion, defaultVersion));
    return;
  }
  const object = value;
  if (typeof object.entityId === 'string') {
    var _index$entities, _index$blocks;
    if (object.positionStatus === 'unresolved' && (!object.positionReason || object.start != null || object.end != null)) addIssue(issues, path, '位置不明には理由を付け、確定した文字範囲を外してください。');
    if (object.positionStatus !== 'unresolved' && (object.positionReason != null || object.quotedText != null)) addIssue(issues, path, '位置不明の理由・引用は位置不明状態と一緒に保存してください。');
    const version = typeof object.sourceVersionId === 'string' ? object.sourceVersionId : defaultVersion,
      index = version && resolveVersion ? resolveVersion(version) : undefined;
    const entityIndex = (_index$entities = index === null || index === void 0 ? void 0 : index.entities) !== null && _index$entities !== void 0 ? _index$entities : entities,
      blockIndex = (_index$blocks = index === null || index === void 0 ? void 0 : index.blocks) !== null && _index$blocks !== void 0 ? _index$blocks : blocks;
    let targetText;
    if (typeof object.blockId === 'string') {
      const block = blockIndex.get(object.blockId);
      if (block && block.entityId !== object.entityId) addIssue(issues, `${path}.blockId`, '段落は指定した情報に属していません。', 'REFERENCE_INVALID');
      targetText = block === null || block === void 0 ? void 0 : block.text;
    }
    if (typeof object.lineId === 'string') {
      const line = entityIndex.get(object.lineId);
      if ((line === null || line === void 0 ? void 0 : line.kind) === 'dialogue_line') targetText = richTextToPlainText(line.data.text);
    }
    if (typeof object.start === 'number' || typeof object.end === 'number') {
      if (typeof object.start !== 'number' || typeof object.end !== 'number') addIssue(issues, path, '文字範囲はstart/endを対で指定してください。');
      if (targetText === undefined) addIssue(issues, path, '文字範囲には本文ブロックまたは台詞への参照が必要です。');else if (typeof object.end === 'number' && object.end > codePointLength(targetText)) addIssue(issues, `${path}.end`, '文字範囲が参照元の本文を超えています。');
    }
  }
  for (const [field, child] of Object.entries(object)) if (!['publicTexts', 'before', 'after', 'runtimeState'].includes(field)) validateAnchors(child, `${path}.${field}`, entities, blocks, issues, depth + 1, resolveVersion);
}
export function validateProject(input, options = {}) {
  if (!isObject(input)) return {
    ok: false,
    issues: [{
      code: 'VALIDATION_FAILED',
      path: 'project',
      message: '作品はオブジェクトです。'
    }]
  };
  const issues = [];
  for (const field of Object.keys(input)) if (![...projectKeys, 'snapshots', 'history'].includes(field)) addIssue(issues, `project.${field}`, '作品に未知の項目があります。');
  if (!Array.isArray(input.snapshots)) addIssue(issues, 'project.snapshots', '必須の配列です。');
  if (!Array.isArray(input.history)) addIssue(issues, 'project.history', '必須の配列です。');
  const snapshotIds = new Set((Array.isArray(input.snapshots) ? input.snapshots : []).flatMap(snapshot => isObject(snapshot) && typeof snapshot.id === 'string' ? [snapshot.id] : []));
  if (Object.hasOwn(input, 'authorAlternatives')) walk(alternativesSchema, input.authorAlternatives, 'project.authorAlternatives', issues, []);
  const content = Object.fromEntries(projectContentKeys.filter(field => Object.hasOwn(input, field)).map(field => [field, input[field]]));
  const validated = validateContent(content, 'project', options, snapshotIds, snapshotContentMap(input.snapshots));
  if (!validated.ok) issues.push(...validated.issues);
  if (issues.length) return {
    ok: false,
    issues: issues.slice(0, 256)
  };
  const project = input;
  validateSnapshotCollection(project.snapshots, 'project.snapshots', project.projectId, options, issues);
  const historyIds = new Set();
  project.history.forEach((command, i) => {
    const path = `project.history[${i}]`,
      raw = command;
    if (!isObject(raw)) {
      addIssue(issues, path, '履歴はコマンドです。');
      return;
    }
    const commandMeta = obj({
      operationId: req(idSchema),
      projectId: req(idSchema),
      baseRevision: req({
        type: 'revision'
      }),
      revision: req({
        type: 'revision'
      }),
      targetIds: req(arr(idSchema, true)),
      reason: req(txt()),
      createdAt: req({
        type: 'datetime'
      }),
      compensatesOperationId: opt(idSchema),
      idMap: opt(record(idSchema, idSchema)),
      importOrigin: opt(obj({
        sourceProjectId: req(idSchema),
        sourceOperationId: req(idSchema),
        importOperationId: req(idSchema)
      }))
    });
    for (const field of Object.keys(raw)) if (field !== 'before' && field !== 'after' && commandMeta.type === 'object' && !Object.hasOwn(commandMeta.fields, field)) addIssue(issues, `${path}.${field}`, 'コマンドに未知の項目があります。');
    walk(commandMeta, Object.fromEntries(Object.entries(raw).filter(([field]) => field !== 'before' && field !== 'after')), path, issues, []);
    if (historyIds.has(command.operationId)) addIssue(issues, `${path}.operationId`, '履歴の操作IDが重複しています。');
    historyIds.add(command.operationId);
    if (command.projectId !== project.projectId) addIssue(issues, `${path}.projectId`, '履歴が別の作品に属しています。');
    for (const field of ['before', 'after']) {
      if (!isObject(raw[field])) {
        addIssue(issues, `${path}.${field}`, '変更前後の内容を保持してください。');
        continue;
      }
      const state = raw[field];
      if (!Array.isArray(state.snapshots)) addIssue(issues, `${path}.${field}.snapshots`, '復元に必要な公開版配列が必要です。');
      if (Object.hasOwn(state, 'authorAlternatives')) walk(alternativesSchema, state.authorAlternatives, `${path}.${field}.authorAlternatives`, issues, []);
      const historical = Object.fromEntries(Object.entries(state).filter(([key]) => key !== 'snapshots' && key !== 'authorAlternatives'));
      const historicalIds = new Set((Array.isArray(state.snapshots) ? state.snapshots : []).flatMap(item => isObject(item) && typeof item.id === 'string' ? [item.id] : []));
      const result = validateContent(historical, `${path}.${field}`, options, historicalIds, snapshotContentMap(state.snapshots));
      if (!result.ok) issues.push(...result.issues);else if (result.value.projectId !== project.projectId) addIssue(issues, `${path}.${field}.projectId`, '履歴の内容が別の作品に属しています。');
      if (Array.isArray(state.snapshots)) validateSnapshotCollection(state.snapshots, `${path}.${field}.snapshots`, project.projectId, options, issues);
    }
  });
  return issues.length ? {
    ok: false,
    issues: issues.slice(0, 256)
  } : {
    ok: true,
    value: project
  };
}
/** Current content for an edit of previously verified storage. Imports still use validateProject. */
export function validateCurrentProject(input, options = {}, reuse) {
  const issues = [];
  for (const field of Object.keys(input)) if (![...projectKeys, 'snapshots', 'history'].includes(field)) addIssue(issues, `project.${field}`, '作品に未知の項目があります。');
  if (!Array.isArray(input.snapshots) || !Array.isArray(input.history)) addIssue(issues, 'project', '公開版と履歴の配列が必要です。');
  if (Object.hasOwn(input, 'authorAlternatives')) walk(alternativesSchema, input.authorAlternatives, 'project.authorAlternatives', issues, []);
  if (issues.length) return {
    ok: false,
    issues
  };
  const ids = new Set(input.snapshots.map(snapshot => snapshot.id));
  const content = Object.fromEntries(projectContentKeys.filter(field => Object.hasOwn(input, field)).map(field => [field, input[field]]));
  const result = validateContent(content, 'project', options, ids, snapshotContentMap(input.snapshots), reuse);
  return result.ok ? {
    ok: true,
    value: input
  } : result;
}
function validateSnapshotCollection(snapshots, path, projectId, options, issues) {
  const ids = new Set(snapshots.flatMap(snapshot => isObject(snapshot) && typeof snapshot.id === 'string' ? [snapshot.id] : [])),
    duplicates = new Set(),
    contents = snapshotContentMap(snapshots);
  snapshots.forEach((snapshot, i) => {
    const location = `${path}[${i}]`;
    if (!isObject(snapshot)) {
      addIssue(issues, location, '公開版はオブジェクトです。');
      return;
    }
    const metadata = obj({
      id: req(idSchema),
      versionLabel: req(txt(1, 128)),
      contentHash: req({
        type: 'hash'
      }),
      createdAt: req({
        type: 'datetime'
      })
    });
    for (const field of Object.keys(snapshot)) if (!['id', 'versionLabel', 'contentHash', 'createdAt', 'content'].includes(field)) addIssue(issues, `${location}.${field}`, '公開版に未知の項目があります。');
    walk(metadata, Object.fromEntries(Object.entries(snapshot).filter(([field]) => field !== 'content')), location, issues, []);
    if (typeof snapshot.id === 'string') {
      if (duplicates.has(snapshot.id)) addIssue(issues, `${location}.id`, '公開版のIDが重複しています。');
      duplicates.add(snapshot.id);
      if (snapshot.id === projectId) addIssue(issues, `${location}.id`, '公開版IDは作品IDと別にしてください。');
    }
    const result = validateContent(snapshot.content, `${location}.content`, options, ids, contents);
    if (!result.ok) issues.push(...result.issues);else if (result.value.projectId !== projectId) addIssue(issues, `${location}.content.projectId`, '公開版が別の作品に属しています。');
  });
}
function snapshotContentMap(snapshots) {
  if (!Array.isArray(snapshots)) return new Map();
  return new Map(snapshots.flatMap(snapshot => isObject(snapshot) && typeof snapshot.id === 'string' && isObject(snapshot.content) && ['entities', 'relations', 'calendars', 'worldReferences'].every(key => Array.isArray(snapshot.content[key]) && snapshot.content[key].every(isObject)) ? [[snapshot.id, snapshot.content]] : []));
}
/** Portable structural schema. Cross-record rules remain in validateProject. */
export function toJsonSchema() {
  const reference = name => ({
    $ref: `#/$defs/${name}`
  });
  function convert(schema) {
    var _schema$max2;
    switch (schema.type) {
      case 'text':
        return {
          type: 'string',
          ...(schema.min != null ? {
            minLength: schema.min
          } : {}),
          ...(schema.max != null ? {
            maxLength: schema.max
          } : {})
        };
      case 'number':
        return {
          type: schema.integer ? 'integer' : 'number',
          ...(schema.min != null ? {
            minimum: schema.min
          } : schema.integer ? {
            minimum: Number.MIN_SAFE_INTEGER
          } : {}),
          ...(schema.max != null ? {
            maximum: schema.max
          } : schema.integer ? {
            maximum: Number.MAX_SAFE_INTEGER
          } : {})
        };
      case 'boolean':
        return {
          type: 'boolean'
        };
      case 'json':
        return {};
      case 'enum':
        return {
          enum: schema.values
        };
      case 'id':
        return reference('ID');
      case 'ref':
        return {
          ...(schema.scope === 'calendar' ? {
            type: 'string',
            minLength: 1
          } : reference('ID')),
          ...(schema.kinds || schema.scope ? {
            $comment: JSON.stringify({
              ...(schema.kinds ? {
                targetKinds: schema.kinds
              } : {}),
              ...(schema.scope ? {
                referenceScope: schema.scope
              } : {})
            })
          } : {})
        };
      case 'tick':
        return reference('Tick');
      case 'revision':
        return reference('Revision');
      case 'datetime':
        return {
          type: 'string',
          format: 'date-time',
          pattern: '^\\d{4}-\\d{2}-\\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\\.\\d+)?(?:Z|\\+00:00)$'
        };
      case 'date':
        return {
          type: 'string',
          format: 'date'
        };
      case 'hash':
        return {
          type: 'string',
          pattern: '^[0-9a-f]{64}$'
        };
      case 'safe_path':
        return {
          type: 'string',
          minLength: 1,
          pattern: '^(?!/)(?![a-zA-Z]:)(?!.*[\\\\\\u0000-\\u001f\\u007f])(?!.*(?:^|/)\\.\\.?(?:/|$))(?!.*//)(?!.*\\/$).+$'
        };
      case 'array':
        return {
          type: 'array',
          items: convert(schema.item),
          ...(schema.min != null ? {
            minItems: schema.min
          } : {}),
          maxItems: (_schema$max2 = schema.max) !== null && _schema$max2 !== void 0 ? _schema$max2 : 100000,
          ...(schema.unique ? {
            uniqueItems: true
          } : {})
        };
      case 'object':
        return {
          type: 'object',
          properties: Object.fromEntries(Object.entries(schema.fields).map(([name, field]) => [name, field.nullable ? {
            anyOf: [convert(field.schema), {
              type: 'null'
            }]
          } : convert(field.schema)])),
          required: Object.entries(schema.fields).filter(([, field]) => field.required).map(([name]) => name),
          additionalProperties: false
        };
      case 'record':
        return {
          type: 'object',
          additionalProperties: convert(schema.value),
          ...(schema.key ? {
            propertyNames: convert(schema.key)
          } : {})
        };
      case 'union':
        return {
          anyOf: schema.choices.map(convert)
        };
      case 'richtext':
        return reference('RichText');
      case 'custom':
        return reference('CustomValue');
      case 'typed':
        return reference('TypedValue');
      case 'time':
        return reference('TimeSpec');
      case 'condition':
        return reference('Condition');
      case 'expression':
        return reference('Expression');
      case 'name_policy':
        return reference('NamePolicy');
      case 'query':
        return reference('Query');
    }
  }
  const conditionalDefinitions = ['constant', 'all', 'any', 'not', 'compare', 'item', 'known', 'visited', 'external'].map(op => {
    const definition = convert(conditionSchema({
      op,
      comparator: 'eq'
    }));
    definition.properties.op = {
      const: op
    };
    return definition;
  });
  conditionalDefinitions.push(convert(conditionSchema({
    op: 'compare',
    comparator: 'in'
  })));
  // Separate comparison operators to avoid an ambiguous oneOf branch for `in`.
  const compareDefinition = conditionalDefinitions[4];
  compareDefinition.properties.comparator = {
    enum: ['eq', 'ne', 'lt', 'le', 'gt', 'ge']
  };
  const inDefinition = conditionalDefinitions.at(-1);
  inDefinition.properties.comparator = {
    const: 'in'
  };
  const span = {
    start: req(num(0, undefined, true)),
    end: req(num(0, undefined, true))
  };
  const block = obj({
    id: req(idSchema),
    kind: req(en('paragraph', 'heading', 'list_item', 'quote')),
    text: req(txt()),
    ruby: opt(arr(obj({
      ...span,
      text: req(txt())
    }))),
    links: opt(arr(obj({
      ...span,
      target: req(anchor)
    }))),
    unresolvedAnnotations: opt(arr(unresolvedTextAnnotation))
  });
  const calendarCommon = {
    id: req(txt(1)),
    name: req(txt(1)),
    originLabel: req(txt()),
    ticksPerDay: req(tick)
  };
  const calendar = union(obj({
    ...calendarCommon,
    kind: req(en('gregorian'))
  }), obj({
    ...calendarCommon,
    kind: req(en('repeating')),
    years: req(arr(obj({
      months: req(arr(obj({
        name: req(txt(1)),
        days: req(num(1, 400, true))
      }), false, 1, 24))
    }), false, 1, 400))
  }));
  const defs = {
    ID: {
      type: 'string',
      pattern: ID_PATTERN.source
    },
    Tick: {
      type: 'string',
      pattern: '^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$'
    },
    Revision: {
      type: 'string',
      pattern: REVISION_PATTERN.source
    },
    RichText: convert(arr(block)),
    CustomValue: {
      anyOf: [{
        type: ['string', 'number', 'boolean', 'null']
      }, convert(obj({
        type: req(en('ref')),
        value: req(ref())
      })), convert(obj({
        type: req(en('date')),
        value: req({
          type: 'date'
        })
      }))]
    },
    TypedValue: {
      oneOf: [convert(obj({
        type: req(en('boolean')),
        value: req(bool)
      })), convert(obj({
        type: req(en('integer')),
        value: req(num(undefined, undefined, true))
      })), convert(obj({
        type: req(en('enum', 'text')),
        value: req(txt())
      })), convert(obj({
        type: req(en('ref')),
        value: req(ref())
      })), convert(obj({
        type: req(en('unknown')),
        value: req(en(null)),
        reason: req(txt())
      }))]
    },
    TimeSpec: {
      oneOf: ['instant', 'interval', 'uncertain', 'relative', 'unknown'].map(mode => convert(timeSchema({
        mode
      })))
    },
    Condition: {
      oneOf: conditionalDefinitions
    },
    Expression: {
      anyOf: [reference('Condition'), ...['value', 'variable', 'add', 'subtract', 'multiply', 'if'].map(op => convert(expressionSchema({
        op
      })))]
    },
    NamePolicy: {
      anyOf: [...['alias', 'replace', 'exclude', 'anonymize'].map(mode => convert(namePolicySchema({
        mode
      }))), convert(namePolicySchema({}))]
    },
    Query: {
      oneOf: ['all', 'any', 'kind', 'text', 'status', 'participant', 'production', 'chapter', 'foreshadow'].map(op => {
        const definition = convert(querySchema({
          op
        }));
        definition.properties.op = {
          const: op
        };
        // Ajv strictRequired checks required keys against properties declared in
        // the same subschema. The value constraints live on the query branch,
        // so repeat an unconstrained declaration here solely for that check.
        if (op === 'foreshadow') definition.anyOf = ['foreshadowId', 'resolutionPolicy', 'role', 'stage'].map(field => ({
          properties: {
            [field]: {}
          },
          required: [field]
        }));
        return definition;
      })
    },
    Calendar: convert(calendar),
    Relation: convert(relationSchema),
    WorldReference: convert(worldReferenceSchema),
    SavedView: convert(viewSchema),
    Entity: {
      oneOf: ENTITY_KINDS.map(kind => reference(`Entity_${kind}`))
    }
  };
  for (const kind of ENTITY_KINDS) defs[`Entity_${kind}`] = convert(entitySchema(kind));
  const arbitraryValue = {};
  const valueSnapshot = {
    type: 'object',
    properties: {
      present: {
        type: 'boolean'
      },
      value: arbitraryValue
    },
    required: ['present'],
    additionalProperties: false
  };
  defs.AlternativePatch = {
    type: 'object',
    properties: {
      key: {
        type: 'string',
        minLength: 1
      },
      scope: {
        enum: ['project', 'entity', 'relation', 'presentation']
      },
      itemId: reference('ID'),
      path: {
        type: 'array',
        items: {
          type: 'string'
        }
      },
      label: {
        type: 'string'
      },
      before: valueSnapshot,
      after: valueSnapshot
    },
    required: ['key', 'scope', 'path', 'label', 'before', 'after'],
    additionalProperties: false
  };
  defs.AlternativeApplyReceipt = {
    type: 'object',
    properties: {
      id: reference('ID'),
      createdAt: {
        type: 'string',
        format: 'date-time'
      },
      alternativeVersionId: reference('ID'),
      sourceSnapshotId: {
        anyOf: [reference('ID'), {
          type: 'null'
        }]
      },
      selectedChangeKeys: {
        type: 'array',
        items: {
          type: 'string'
        },
        minItems: 1,
        uniqueItems: true
      },
      fromCanonicalRevision: reference('Revision'),
      appliedRevision: reference('Revision'),
      patches: {
        type: 'array',
        items: reference('AlternativePatch'),
        minItems: 1
      }
    },
    required: ['id', 'createdAt', 'alternativeVersionId', 'sourceSnapshotId', 'selectedChangeKeys', 'fromCanonicalRevision', 'appliedRevision', 'patches'],
    additionalProperties: false
  };
  defs.StructurePlan = {
    type: 'object',
    properties: {
      chapterId: reference('ID'),
      templateId: {
        type: 'string',
        minLength: 1
      },
      beatLabels: {
        type: 'array',
        items: {
          type: 'string',
          minLength: 1
        },
        maxItems: 100
      },
      assignments: {
        type: 'object',
        additionalProperties: reference('ID')
      }
    },
    required: ['chapterId', 'templateId', 'beatLabels', 'assignments'],
    additionalProperties: false
  };
  defs.AlternativeVersion = {
    type: 'object',
    properties: {
      id: reference('ID'),
      parentVersionId: {
        anyOf: [reference('ID'), {
          type: 'null'
        }]
      },
      label: {
        type: 'string',
        minLength: 1
      },
      createdAt: {
        type: 'string',
        format: 'date-time'
      },
      content: reference('ProjectContent'),
      contentHash: {
        type: 'string',
        pattern: '^[0-9a-f]{64}$'
      },
      structurePlan: reference('StructurePlan')
    },
    required: ['id', 'parentVersionId', 'label', 'createdAt', 'content', 'contentHash'],
    additionalProperties: false
  };
  defs.AuthorAlternative = {
    type: 'object',
    properties: {
      id: reference('ID'),
      projectId: reference('ID'),
      name: {
        type: 'string',
        minLength: 1
      },
      status: {
        enum: ['active', 'provisional', 'needs_review', 'rejected', 'accepted']
      },
      baseRevision: reference('Revision'),
      sourceSnapshotId: {
        anyOf: [reference('ID'), {
          type: 'null'
        }]
      },
      baseContent: reference('ProjectContent'),
      baseContentHash: {
        type: 'string',
        pattern: '^[0-9a-f]{64}$'
      },
      versions: {
        type: 'array',
        items: reference('AlternativeVersion'),
        minItems: 1,
        maxItems: 500
      },
      headVersionId: reference('ID'),
      applyReceipts: {
        type: 'array',
        items: reference('AlternativeApplyReceipt')
      },
      integrityHash: {
        type: 'string',
        pattern: '^[0-9a-f]{64}$'
      },
      createdAt: {
        type: 'string',
        format: 'date-time'
      },
      updatedAt: {
        type: 'string',
        format: 'date-time'
      }
    },
    required: ['id', 'projectId', 'name', 'status', 'baseRevision', 'sourceSnapshotId', 'baseContent', 'baseContentHash', 'versions', 'headVersionId', 'applyReceipts', 'integrityHash', 'createdAt', 'updatedAt'],
    additionalProperties: false
  };
  const traceSchema = defs.Entity_trace;
  traceSchema.allOf = [{
    if: {
      properties: {
        data: {
          type: 'object',
          properties: {
            mode: {
              const: 'chapters'
            }
          },
          required: ['mode']
        }
      },
      required: ['data']
    },
    then: {
      properties: {
        data: {
          type: 'object',
          properties: {
            readingPath: {
              not: {
                type: 'null'
              }
            },
            steps: {
              type: 'array',
              maxItems: 0
            }
          },
          required: ['readingPath']
        }
      },
      required: ['data']
    },
    else: {
      properties: {
        data: {
          type: 'object',
          properties: {
            readingPath: {
              type: 'null'
            }
          }
        }
      },
      required: ['data']
    }
  }];
  const content = convert(obj({
    ...projectHeaderFields,
    calendars: req(arr(calendar)),
    entities: req(arr(ref())),
    relations: req(arr(relationSchema)),
    views: req(arr(viewSchema))
  }));
  const contentProperties = content.properties;
  contentProperties.entities = {
    type: 'array',
    items: reference('Entity'),
    maxItems: 100000
  };
  defs.ProjectContent = content;
  defs.ProjectSnapshot = convert(obj({
    id: req(idSchema),
    versionLabel: req(txt(1, 128)),
    contentHash: req({
      type: 'hash'
    }),
    createdAt: req({
      type: 'datetime'
    })
  }));
  defs.ProjectSnapshot.properties.content = reference('ProjectContent');
  defs.ProjectSnapshot.required.push('content');
  defs.ContentState = {
    ...content,
    properties: {
      ...contentProperties,
      snapshots: {
        type: 'array',
        items: reference('ProjectSnapshot')
      },
      authorAlternatives: {
        type: 'array',
        items: reference('AuthorAlternative'),
        maxItems: 100
      }
    },
    required: [...content.required, 'snapshots']
  };
  defs.CommandRecord = convert(obj({
    operationId: req(idSchema),
    projectId: req(idSchema),
    baseRevision: req({
      type: 'revision'
    }),
    revision: req({
      type: 'revision'
    }),
    targetIds: req(arr(idSchema, true)),
    reason: req(txt()),
    createdAt: req({
      type: 'datetime'
    }),
    compensatesOperationId: opt(idSchema),
    idMap: opt(record(idSchema, idSchema)),
    importOrigin: opt(obj({
      sourceProjectId: req(idSchema),
      sourceOperationId: req(idSchema),
      importOperationId: req(idSchema)
    }))
  }));
  Object.assign(defs.CommandRecord.properties, {
    before: reference('ContentState'),
    after: reference('ContentState')
  });
  defs.CommandRecord.required.push('before', 'after');
  return {
    $schema: 'https://json-schema.org/draft/2020-12/schema',
    $id: `https://shinariokanri.local/schema/project-${FORMAT_VERSION}.json`,
    title: 'Scenario project 1.0.0',
    description: 'Structural contract. validateProject additionally checks references, scopes, cycles, ranges, Unicode spans, comparison types and effect inputs. UTF-8 byte limits and SHA-256 integrity require executable validators.',
    ...content,
    properties: {
      ...contentProperties,
      snapshots: {
        type: 'array',
        items: reference('ProjectSnapshot')
      },
      history: {
        type: 'array',
        items: reference('CommandRecord')
      },
      authorAlternatives: {
        type: 'array',
        items: reference('AuthorAlternative'),
        maxItems: 100
      }
    },
    required: [...content.required, 'snapshots', 'history'],
    $defs: defs
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXNvbHZlUGlubmVkV29ybGRzIiwicmVzb2x2ZVJldXNlQ29udGVudCIsInJldXNlVmFsaWRhdGlvbklzc3VlcyIsIkZPUk1BVF9WRVJTSU9OIiwiR1JFR09SSUFOX0NBTEVOREFSIiwiY29tcGFyZVRpY2tzIiwiaXNUaWNrIiwicGFyc2VUaWNrIiwidmFsaWRhdGVDYWxlbmRhciIsInZhbGlkYXRlRXZlbnRUaW1lcyIsInNhbWVDYWxlbmRhckRlZmluaXRpb24iLCJ2YWxpZGF0ZVRlbXBsYXRlQXNzaWdubWVudHMiLCJ2YWxpZGF0ZVRlbXBsYXRlRGVmaW5pdGlvbiIsIktJTkRfTEFCRUxTIiwiY2hhcmFjdGVyIiwiZ3JvdXAiLCJldmVudCIsInBsYWNlIiwiaXRlbSIsIm5vdGUiLCJjaGFwdGVyIiwic2NlbmUiLCJnb2FsIiwiZmxvd19ub2RlIiwiZmxvd19lZGdlIiwiZmxvd19ncmFwaCIsImRpYWxvZ3VlX2xpbmUiLCJxdWVzdCIsImxvcmUiLCJ2YXJpYWJsZSIsImVmZmVjdCIsImFzc2VydGlvbiIsImZvcmVzaGFkb3ciLCJkaXNjbG9zdXJlIiwiY2hlY2twb2ludCIsInRyYWNlIiwiYXR0YWNobWVudCIsInNvdXJjZSIsImN1ZSIsInN0b3J5Ym9hcmRfZnJhbWUiLCJsb2NhbGl6YXRpb24iLCJyZWNvcmRpbmciLCJ0ZXJtaW5vbG9neSIsIm1hcCIsInRyYXZlbF9yb3V0ZSIsInRlbXBsYXRlIiwiY29sbGVjdGlvbiIsInJldmlldyIsImNyZWF0aXZlX2JyaWVmIiwiZGVjaXNpb24iLCJnYW1lcGxheV9zcGVjIiwicHJvZHVjdGlvbl90YXNrIiwibWVkaWFfdmFyaWFudCIsInZvaWNlX3J1bGUiLCJleHRlcm5hbF9jb250cmFjdCIsInNuYXBzaG90IiwicHJvamVjdGlvbl9wcm9maWxlIiwiRU5USVRZX0tJTkRTIiwiT2JqZWN0Iiwia2V5cyIsIlNUQVRVU0VTIiwiU0NPUEVTIiwiUkVMQVRJT05fVFlQRVMiLCJrZXkiLCJsYWJlbCIsImZyb21LaW5kcyIsInRvS2luZHMiLCJhbGxvd1NlbGYiLCJhbGxvd1N5bW1ldHJpYyIsIlJFTEFUSU9OX0xBQkVMUyIsImZyb21FbnRyaWVzIiwidHlwZSIsIklEX1BBVFRFUk4iLCJSRVZJU0lPTl9QQVRURVJOIiwiZW1wdHlWYWxpZGl0eSIsIndvcmxkUmFuZ2UiLCJyb3V0ZUNvbmRpdGlvbiIsInByZXNlbnRhdGlvbkFuY2hvciIsIm5ld0lkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInRleHRUb1JpY2hUZXh0IiwidGV4dCIsInNwbGl0IiwibGluZSIsImlkIiwia2luZCIsInJpY2hUZXh0VG9QbGFpblRleHQiLCJibG9jayIsImpvaW4iLCJnZXRFbnRpdHkiLCJwcm9qZWN0IiwiZW50aXRpZXMiLCJmaW5kIiwiZW50aXR5IiwiZGVsZXRlZEF0IiwiZ2V0RW50aXRpZXNCeUtpbmQiLCJmaWx0ZXIiLCJkZWZhdWx0RGF0YSIsInVua25vd24iLCJ2YWx1ZSIsInJlYXNvbiIsImRhdGEiLCJyZWFkaW5nIiwiYWxpYXNlcyIsInN1bW1hcnkiLCJib2R5IiwiYXV0aG9yTm90ZXMiLCJnb2FscyIsInZvaWNlUnVsZXMiLCJncm91cFR5cGUiLCJtZW1iZXJzIiwicGFyZW50SWQiLCJ0aW1lIiwibW9kZSIsImxhbmVSb2xlIiwicGFydGljaXBhbnRzIiwibG9jYXRpb25JZCIsIml0ZW1JZHMiLCJjb25zdHJhaW50cyIsIm1hcElkcyIsImNoYW5nZXMiLCJpdGVtTW9kZSIsInR5cGVJZCIsInByb3BlcnRpZXMiLCJhdHRhY2htZW50SWRzIiwiY29udmVydGVkVG9JZHMiLCJvcmlnaW5Ob3RlSWQiLCJzY2VuZUlkcyIsInN0cnVjdHVyZVJvbGUiLCJldmVudElkcyIsImNoYXB0ZXJJZCIsInRocmVhZElkcyIsInBvdklkIiwiY29uZmxpY3RzIiwicmVzdWx0cyIsIm5ld0luZm9ybWF0aW9uIiwidGVuc2lvbiIsImltcG9ydGFuY2UiLCJibG9ja0lkcyIsIm93bmVySWQiLCJkZXNjcmlwdGlvbiIsImV2aWRlbmNlU2NlbmVJZHMiLCJ2YWxpZGl0eSIsIm5vZGVUeXBlIiwic2NlbmVJZCIsImNoaWxkR3JhcGhJZCIsInRlcm1pbmFsUmVhc29uIiwiZ2F0ZSIsIm9wIiwiZXhlY3V0aW9uUG9saWN5IiwiZmFsbGJhY2tJZCIsImZyb21JZCIsInRvSWQiLCJ1bnJlc29sdmVkIiwiZWRnZVR5cGUiLCJjb25kaXRpb24iLCJlZmZlY3RJZHMiLCJwcmlvcml0eSIsImNob2ljZUxpbmVJZCIsIm5vZGVJZHMiLCJlZGdlSWRzIiwiZW50cnlJZHMiLCJleGl0SWRzIiwicGFyZW50R3JhcGhJZCIsInBhcmFtZXRlcnMiLCJzcGVha2VySWQiLCJjaG9pY2VFZGdlSWQiLCJjdWVJZHMiLCJvcmlnaW5MaW5lSWRzIiwic3RhdGVWYXJpYWJsZUlkIiwiZmxvd0lkcyIsInRyYW5zaXRpb25SdWxlcyIsImdhbWVwbGF5U3BlY0lkcyIsImFzc2VydGlvbklkcyIsInNvdXJjZUlkcyIsInZhbHVlVHlwZSIsInNjb3BlIiwiaW5pdGlhbCIsImFsbG93ZWQiLCJ2YWx1ZXMiLCJleHRlcm5hbENvbnRyYWN0SWQiLCJyZXNldFJ1bGVzIiwiZXh0ZXJuYWxVc2VEZWNsYXJlZCIsIm9wZXJhdGlvbiIsInRhcmdldElkIiwiaW5zdGFuY2VJZCIsInN1YmplY3RJZCIsInByZWRpY2F0ZSIsInRydXRoS2luZCIsImhvbGRlcklkIiwiZXZpZGVuY2VMb2NhdGlvbiIsInF1ZXN0aW9uIiwiaW50ZW50IiwicmVzb2x1dGlvblBvbGljeSIsInRydXRoQXNzZXJ0aW9uSWRzIiwiY2x1ZUlkcyIsInBheW9mZklkcyIsInJlcXVpcmVkSW5mbyIsImRlYWRsaW5lIiwiZXhjZXB0aW9ucyIsImZvcmVzaGFkb3dJZCIsImFuY2hvciIsImVudGl0eUlkIiwic3RhZ2UiLCJyb2xlIiwia25vd2xlZGdlRWZmZWN0cyIsInRhcmdldFNjb3BlIiwiY29udGVudFZlcnNpb25JZCIsInJ1bnRpbWVTdGF0ZSIsImVtcHR5UnVudGltZVN0YXRlIiwib3JpZ2luIiwidHJhY2VJZCIsInN0YXJ0Q2hlY2twb2ludElkIiwic3RlcHMiLCJzZWVkIiwiZW5naW5lVmVyc2lvbiIsImV4dGVybmFsTW9kZSIsIm1lZGlhVHlwZSIsImNvbnRlbnRIYXNoIiwiYnl0ZVNpemUiLCJhc3NldFBhdGgiLCJkaXNwbGF5TmFtZSIsInJldmlzaW9uSGlzdG9yeSIsInNvdXJjZVR5cGUiLCJsb2NhdG9yIiwiYWNjZXNzZWRBdCIsImV4Y2VycHRMb2NhdGlvbiIsImludGVycHJldGF0aW9uIiwiYXR0YWNobWVudElkIiwicmVkaXN0cmlidXRpb25BbGxvd2VkIiwiY3VlVHlwZSIsImV4cHJlc3Npb24iLCJ3YWl0TXMiLCJjYW1lcmEiLCJtZWRpYVRpbWUiLCJtZWRpYVN0YXJ0TXMiLCJtZWRpYUVuZE1zIiwicmVmZXJlbmNlQXNzZXRJZCIsImZpbmFsQXNzZXRJZCIsImNhcHRpb24iLCJzb3VyY2VMaW5lSWQiLCJsYW5ndWFnZSIsInNvdXJjZUhhc2giLCJyZXZpZXdlZEJ5IiwicmVjb3JkaW5nSWRzIiwidHJhbnNsYXRpb25JZCIsIm5vdGVzIiwiY2Fub25pY2FsIiwidmFyaWFudHMiLCJ1c2FnZU5vdGVzIiwidm9pY2VPd25lcklkIiwicGxhY2VJZCIsImNvb3JkaW5hdGVTeXN0ZW0iLCJwYXJlbnRNYXBJZCIsInBpbnMiLCJmcm9tUGxhY2VJZCIsInRvUGxhY2VJZCIsImRpcmVjdGlvbiIsIm1ldGhvZCIsIm1pbmltdW1UaWNrcyIsIm1heGltdW1UaWNrcyIsImV2aWRlbmNlIiwidGFyZ2V0S2luZCIsImZpZWxkcyIsInZlcnNpb24iLCJkZWZhdWx0cyIsIm1lbWJlcklkcyIsInF1ZXJ5Iiwic29ydCIsImZpZWxkIiwidGFyZ2V0IiwidGFyZ2V0VmVyc2lvbklkIiwiYXNzaWduZWVJZCIsInF1b3RlZFRleHQiLCJyZXNvbHV0aW9uIiwidGFyZ2V0QXVkaWVuY2UiLCJleHBlcmllbmNlIiwidGhlbWUiLCJ0b25lIiwiZGVsaXZlcmFibGVJZHMiLCJkZWNpc2lvbklkcyIsInN1YmplY3QiLCJvdXRjb21lIiwicmVxdWlyZW1lbnRJZHMiLCJyZXZpZXdJZHMiLCJhY3Rpb24iLCJtZWNoYW5pYyIsInR1dG9yaWFsIiwicmV3YXJkIiwicXVlc3RJZCIsInRhc2tJZHMiLCJpbnRlbnRpb25hbERpZmZlcmVuY2UiLCJ0YXJnZXRJZHMiLCJwcm9ncmVzcyIsImRlcGVuZHNPbiIsImVzdGltYXRlIiwiYmxvY2tpbmdSZWFzb24iLCJtZWRpdW0iLCJiYXNlU25hcHNob3RJZCIsInJlbGVhc2VBdCIsInByb2plY3Rpb25Qcm9maWxlSWQiLCJuZWVkc1JldmlldyIsImNoYXJhY3RlcklkIiwiZmlyc3RQZXJzb24iLCJhZGRyZXNzaW5nIiwicGhyYXNpbmciLCJleGFtcGxlcyIsIm93bmVyIiwiaW5wdXRUeXBlIiwib3V0cHV0VHlwZSIsIm1pc3NpbmdQb2xpY3kiLCJzdHViVmFsdWVzIiwiYWRhcHRlclByb2ZpbGVJZHMiLCJ2ZXJzaW9uTGFiZWwiLCJpbW11dGFibGUiLCJwYXJlbnRWZXJzaW9uSWRzIiwicmVsZWFzZWRBdCIsInJlZmVyZW5jZWRXb3JsZFZlcnNpb25JZHMiLCJhdWRpZW5jZSIsImluY2x1ZGVkSWRzIiwibmFtZVBvbGljeSIsImFsbG93ZWRLaW5kcyIsImV4Y2x1ZGVkRmllbGRzIiwicm91dGVTY29wZSIsImluY2x1ZGVBdXRob3JOb3RlcyIsInB1YmxpY1RpdGxlIiwicHVibGljVGV4dHMiLCJhbGxvd2VkUmVsYXRpb25JZHMiLCJpZFBvbGljeSIsIlJhbmdlRXJyb3IiLCJjcmVhdGVFbnRpdHkiLCJwcm9qZWN0SWQiLCJuYW1lIiwibm93IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicmV2aXNpb24iLCJzdGF0dXMiLCJ2aXNpYmlsaXR5IiwiY3JlYXRlZEF0IiwidXBkYXRlZEF0IiwiY3VzdG9tVmFsdWVzIiwiY3JlYXRlUHJvamVjdCIsImZvcm1hdFZlcnNpb24iLCJjYWxlbmRhcklkIiwibWFpblN0YXJ0IiwiY2FsZW5kYXJzIiwic3RydWN0dXJlZENsb25lIiwid29ybGRSZWZlcmVuY2VzIiwicmVsYXRpb25zIiwic25hcHNob3RzIiwiaGlzdG9yeSIsInZpZXdzIiwidmFyaWFibGVWYWx1ZXMiLCJpdGVtSW5zdGFuY2VzIiwiYXNzZXJ0aW9ucyIsInNlZW5JZHMiLCJ2aXNpdENvdW50cyIsIm9uY2VUcmlnZ2VycyIsInJuZ1NlZWQiLCJybmdQb3NpdGlvbiIsImNhbGxTdGFjayIsInByZXNlbnRhdGlvblBvc2l0aW9uIiwibG9vcE51bWJlciIsInByb3ZlbmFuY2UiLCJjcmVhdGVEZW1vUHJvamVjdCIsImFvIiwiZ3VhcmQiLCJhdCIsImFmZmVjdGlvbiIsIm1pbiIsIm1heCIsInNjZW5lMSIsInNjZW5lMiIsImVudHJ5IiwicmVhZCIsIm1lcmdlIiwicmV2ZWFsIiwic3RheSIsInNldEtleSIsImdhaW5UcnVzdCIsImNsdWUiLCJwYXlvZmYiLCJzZWVDbHVlIiwic2VlUGF5b2ZmIiwiZWRnZXMiLCJ2YXJpYWJsZUlkIiwiY29tcGFyYXRvciIsImdyYXBoIiwiZSIsInRhc2siLCJmb3JFYWNoIiwicmVsYXRpb25UeXBlIiwiZXZpZGVuY2VJZHMiLCJ0eHQiLCJtYXhCeXRlcyIsInNob3J0IiwibnVtIiwiaW50ZWdlciIsImJvb2wiLCJpZFNjaGVtYSIsInRpY2siLCJ0eXBlZCIsImVuIiwicmVmIiwia2luZHMiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJzY29wZWRSZWYiLCJhcnIiLCJ1bmlxdWUiLCJyZWZzIiwib2JqIiwicmVxIiwic2NoZW1hIiwicmVxdWlyZWQiLCJvcHQiLCJudWxsYWJsZSIsIm9wdGlvbmFsVmFsdWUiLCJyaWNoIiwiY29uZCIsInJlY29yZCIsInJlY29yZEtleSIsInVuaW9uIiwiY2hvaWNlcyIsImJsb2NrSWQiLCJsaW5lSWQiLCJzdGFydCIsImVuZCIsInNvdXJjZVZlcnNpb25JZCIsInBvc2l0aW9uU3RhdHVzIiwicG9zaXRpb25SZWFzb24iLCJ1bnJlc29sdmVkVGV4dEFubm90YXRpb24iLCJvcmlnaW5hbFRleHQiLCJudWxsYWJsZVZhbGlkaXR5IiwiZ3JhcGhJZCIsInRhcmdldFNuYXBzaG90SWQiLCJhbGlhcyIsImF1ZGllbmNlSG9sZGVySWRzIiwiaXNQdWJsaWNEZWZhdWx0IiwiZXhjZXB0aW9uIiwidHJhbnNpdGlvbiIsImZyb20iLCJ0byIsImV4Y2VwdGlvbkRldGFpbHMiLCJyZXNldFJ1bGUiLCJvbiIsInRyaWdnZXIiLCJldmVudEtleSIsInJlcGVhdCIsInJldXNlIiwic291cmNlSWQiLCJwaW5uZWRTbmFwc2hvdElkIiwib3ZlcnJpZGVGaWVsZHMiLCJiaW5kaW5ncyIsInJ1bnRpbWVJdGVtIiwicXVhbnRpdHkiLCJjb25zdW1lZCIsInJ1bnRpbWVBc3NlcnRpb24iLCJhc3NlcnRpb25JZCIsInRydXRoIiwic291cmNlRWZmZWN0SWQiLCJwcmVzZW50YXRpb25SZXN1bHQiLCJyZWFzb25zIiwiY2FsbEZyYW1lIiwicmV0dXJuTm9kZUlkIiwicnVudGltZSIsInJlc2V0Q2F1c2VzIiwiYmVmb3JlIiwiYWZ0ZXIiLCJyZWFkaW5nT2NjdXJyZW5jZSIsIm9jY3VycmVuY2VJZCIsInByZXNlbnRhdGlvblN0YXRlIiwiY29uZGl0aW9uUmVzdWx0cyIsImV4dGVybmFsVmFsdWVzIiwid29ybGRUaWNrIiwicmVhZGluZ1BhdGgiLCJjaGFwdGVySWRzIiwic2VsZWN0aW9uIiwib2NjdXJyZW5jZXMiLCJncm91cENvdmVyYWdlIiwiY2hlY2tlZCIsInRvdGFsIiwiY292ZXJhZ2VDb3VudCIsImJ5UHJvdmVuYW5jZSIsImJ5RXh0ZXJuYWxNb2RlIiwiZXhjbHVkZWQiLCJjb3ZlcmFnZSIsImZpZWxkRGVmaW5pdGlvbiIsImRlZmF1bHQiLCJhbGxvd2VkVmFsdWVzIiwidGFyZ2V0S2luZHMiLCJoZWxwIiwicmFuZ2UiLCJ1bml0IiwiYXNzdW1wdGlvbnMiLCJ1bmtub3duQ291bnQiLCJzcGVlZCIsIk51bWJlciIsIk1JTl9WQUxVRSIsInB1YmxpY1RleHQiLCJFTlRJVFlfU0NIRU1BUyIsImJpcnRoIiwiZGVhdGgiLCJrbm93bGVkZ2VFZmZlY3RJZHMiLCJ0YXJnZXRFdmVudElkIiwiaGFuZG9mZlJlY2VpcHQiLCJhcHByb3ZhbCIsInZlcmlmaWNhdGlvblZlcnNpb25JZCIsInByb2ZpbGVWZXJzaW9uSWQiLCJzb3VyY2VSZXZpc2lvbiIsInByb2ZpbGVJZCIsInBhY2thZ2VIYXNoIiwicmVjZWlwdEhhc2giLCJyYXdKc29uIiwiaWRNYXBwaW5ncyIsInB1YmxpY0lkIiwicHJvamVjdGlvbkJpbmRpbmdzIiwiZWRpdGlvblZlcnNpb25JZCIsImNpdGF0aW9uQmluZGluZ3MiLCJwdWJsaWNWZXJzaW9uSWQiLCJ3b3JsZFZlcnNpb25zIiwiZGlhbG9ndWVMaW5lSWRzIiwicmVwbGFjZWRCeUxpbmVJZHMiLCJsaW5lYWdlIiwiYmFzZVJldmlzaW9uIiwic2VnbWVudHMiLCJjbGFpbUFzc2VydGlvbklkcyIsImFzc2VydGlvbkludGVudCIsImFzc2VydGlvblJlYXNvbiIsImRlcml2ZWQiLCJleGNsdXNpb25zIiwib3RoZXJWYWx1ZSIsImFsdGVybmF0aXZlSW5mbyIsInByZXNlbnRhdGlvbkRlYWRsaW5lIiwicHJlc2VudGF0aW9uUmVzdWx0cyIsImNvbnRlbnRSZXZpc2lvbiIsIm1pZ3JhdGlvbiIsInNvdXJjZUNoZWNrcG9pbnRJZCIsIm5vZGVJZCIsImluaXRpYWxFeHRlcm5hbFZhbHVlcyIsImluaXRpYWxTdHViQmFzZVN0YXRlIiwiaW5pdGlhbFN0dWJWYWx1ZXMiLCJ2YXJpYWJsZXMiLCJleHRlcm5hbCIsImluaXRpYWxXb3JsZFRpY2siLCJyZWdyZXNzaW9uRGVjbGFyYXRpb25zIiwicHJvamVjdFJldmlzaW9uIiwidHJhY2VJZHMiLCJyZWNvbmZpcm1hdGlvbiIsInNvdXJjZVRyYWNlSWQiLCJwcm92ZW5hbmNlSWQiLCJsaWNlbnNlTm90ZSIsIngiLCJ5IiwicHVycG9zZSIsInNoYXJlZFNvdXJjZSIsImNvbm5lY3Rpb24iLCJzaGFyZWRTbmFwc2hvdCIsImNvbW1lbnQiLCJwdWJsaWNWZXJzaW9uIiwicHVibGljRW50aXR5IiwicHVibGljUmVsYXRpb24iLCJwdWJsaWNCbG9jayIsInN0YXJ0Q3AiLCJlbmRDcCIsInByb2plY3Rpb25IYXNoIiwiY29tbWVudEJvZHlIYXNoIiwib2JzZXJ2ZWRTdGFnZSIsImRhdGUiLCJ0aW1lWm9uZSIsInByZXZpb3VzVmFyaWFudElkIiwiY29uZmlybWF0aW9uUmVjaXBpZW50SWRzIiwiYmxvY2tTb3VyY2VzIiwiY2l0ZWRWZXJzaW9ucyIsImFsbG93ZWRGaWVsZHMiLCJwdWJsaWNJZHMiLCJwdWJsaWNWYWx1ZXMiLCJpbmNsdWRlZFN0YXR1c2VzIiwicHVibGljVmVyc2lvbkxhYmVsIiwiYXBwcm92ZWRBdHRhY2htZW50SWRzIiwiaXNPYmplY3QiLCJBcnJheSIsImlzQXJyYXkiLCJnZXRQcm90b3R5cGVPZiIsInByb3RvdHlwZSIsInV0ZjhFbmNvZGVyIiwiVGV4dEVuY29kZXIiLCJ1dGY4Qnl0ZXMiLCJlbmNvZGUiLCJieXRlTGVuZ3RoIiwiY29kZVBvaW50TGVuZ3RoIiwiY291bnQiLCJpIiwiY29kZSIsImNoYXJDb2RlQXQiLCJuZXh0IiwidmFsaWRVbmljb2RlIiwiYWRkSXNzdWUiLCJpc3N1ZXMiLCJwYXRoIiwibWVzc2FnZSIsInB1c2giLCJ2YWxpZERhdGUiLCJ0ZXN0IiwiaXNGaW5pdGUiLCJnZXRUaW1lIiwic2xpY2UiLCJjb25kaXRpb25TY2hlbWEiLCJjaGlsZHJlbiIsImNoaWxkIiwiaXRlbUlkIiwiY29udHJhY3RJZCIsImV4cHJlc3Npb25TY2hlbWEiLCJsZWZ0IiwicmlnaHQiLCJ0aGVuIiwiZWxzZSIsInRpbWVTY2hlbWEiLCJlYXJsaWVzdCIsImxhdGVzdCIsInByZWNpc2lvbiIsImFuY2hvckV2ZW50SWQiLCJhbmNob3JQb2ludCIsIm1pbk9mZnNldCIsIm1heE9mZnNldCIsInF1ZXJ5U2NoZW1hIiwibmFtZVBvbGljeVNjaGVtYSIsInBvbGljeSIsImRlZmF1bHRQb2xpY3kiLCJieUVudGl0eUlkIiwiYWxpYXNJZCIsInJlcGxhY2VtZW50IiwicHVibGljTmFtZSIsInRleHRTcGFuIiwicmljaFRleHRCbG9ja3MiLCJydWJ5IiwibGlua3MiLCJ1bnJlc29sdmVkQW5ub3RhdGlvbnMiLCJ3YWxrIiwicmVmZXJlbmNlcyIsImRlcHRoIiwiYXN0IiwiZmFpbCIsInZpc2l0IiwiaXRlbVBhdGgiLCJsZXZlbCIsInNlZW4iLCJoYXMiLCJhZGQiLCJpbmRleCIsImVudHJpZXMiLCJpbmNsdWRlcyIsImRlbGV0ZSIsIlNldCIsImlzU2FmZUludGVnZXIiLCJfc2NoZW1hJHNjb3BlIiwidmFsaWQiLCJwYXJzZSIsInN0YXJ0c1dpdGgiLCJzb21lIiwicGFydCIsIl9zY2hlbWEkbWF4IiwiSlNPTiIsInN0cmluZ2lmeSIsInNpemUiLCJoYXNPd24iLCJkZWZpbml0aW9uIiwiZmllbGRQYXRoIiwic2hvcnRlc3QiLCJjaG9pY2UiLCJicmFuY2hJc3N1ZXMiLCJicmFuY2hSZWZzIiwidmFsdWVTY2hlbWEiLCJieXRlcyIsImNoYXJzIiwiYW5ub3RhdGlvbiIsImoiLCJidWRnZXQiLCJjb3VudGVyIiwiY29tbW9uRmllbGRzIiwicmV0YWluSWZVbnJlZmVyZW5jZWQiLCJ0ZW1wbGF0ZUlkIiwiZGVsZXRpb25PcGVyYXRpb25JZCIsInJlbGF0aW9uU2NoZW1hIiwiZW50aXR5UmVjb3JkU2NoZW1hcyIsIk1hcCIsImVudGl0eVNjaGVtYSIsImNhY2hlZCIsImdldCIsInNldCIsInNpbXBsZVZhbGlkYXRlIiwib2siLCJ2YWxpZGF0ZUNvbmRpdGlvbiIsImlucHV0IiwidmFsaWRhdGVFeHByZXNzaW9uIiwidmFsaWRhdGVUeXBlZFZhbHVlIiwidmFsaWRhdGVUaW1lU3BlYyIsInZhbGlkYXRlUnVudGltZVN0YXRlIiwicmVzdWx0IiwiaWRzIiwidmFsaWRhdGVJbml0aWFsUHJlc2VudGF0aW9uUmVzdWx0cyIsInN0YXRlIiwib2JzZXJ2ZWQiLCJub2RlIiwiZWxpZ2libGUiLCJ0YXJnZXRzIiwibG9jYXRpb24iLCJ2YWxpZGF0ZUVmZmVjdERhdGEiLCJ2YWxpZGF0ZUVudGl0eVJlY29yZCIsInZhbGlkYXRlTG9jYWxSdWxlcyIsInZhbGlkYXRlRW50aXR5IiwidmFsaWRhdGVSZWxhdGlvbiIsInZhbGlkYXRlVmFyaWFibGVWYWx1ZSIsImFsbG93VW5rbm93biIsIl9kYXRhJGFsbG93ZWQkbWluIiwiX2RhdGEkYWxsb3dlZCRtYXgiLCJfZW50aXR5JGRhdGEkdGVybWluYWwiLCJfZW50aXR5JGRhdGEkdmFsdWUiLCJfZW50aXR5JGRhdGEkdmFsdWUyIiwiX2VudGl0eSRkYXRhJHJlYXNvbiIsIl9lbnRpdHkkZGF0YSRzb3VyY2VJZCIsImlzc3VlIiwidW5uYW1lZCIsInRyaW0iLCJjdXN0b21LZXkiLCJjb25zdHJhaW50IiwiX2VudGl0eSRkYXRhJGNvbnN0cmFpIiwiX2RhdGEkcmVzZXRSdWxlczIiLCJfZGF0YSRyZXNldFJ1bGVzMyIsIl9kYXRhJGFsbG93ZWQkbWluMiIsIl9kYXRhJGFsbG93ZWQkbWF4MiIsIl9kYXRhJGFsbG93ZWQkdmFsdWVzIiwiX2RhdGEkYWxsb3dlZCR2YWx1ZXMyIiwicnVsZSIsIl9kYXRhJHJlc2V0UnVsZXMiLCJfZGF0YSR0cmFuc2l0aW9uUnVsZXMiLCJfcnVsZSRyZWFzb24iLCJfZGF0YSRleGNsdXNpb25zIiwiSW50bCIsIkRhdGVUaW1lRm9ybWF0IiwidXJsIiwiVVJMIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsInByb3RvY29sIiwiaG9zdG5hbWUiLCJ2YWxpZGF0ZU5lc3RlZFJhbmdlcyIsIm9iamVjdCIsImNvbGxlY3RSZWZlcmVuY2VzIiwicmVmZXJlbmNlIiwicmVwbGFjZSIsImNvbGxlY3RSZWxhdGlvblJlZmVyZW5jZXMiLCJyZWxhdGlvbiIsInBhdGhQYXJ0cyIsIkJvb2xlYW4iLCJyZXdyaXRlUGF0aHMiLCJpZE1hcCIsImNvcHkiLCJsb29rdXAiLCJvcmRlcmVkIiwiYSIsImIiLCJhS2V5IiwiZW5kc1dpdGgiLCJiS2V5IiwicGFydHMiLCJkaWN0aW9uYXJ5S2V5IiwicG9wIiwiY3Vyc29yIiwiRXJyb3IiLCJyZXdyaXRlRW50aXR5UmVmZXJlbmNlcyIsIl9lbnRpdHkkZGF0YSRyZXVzZSIsIl9yZWYiLCJyZXdyaXRlUmVsYXRpb25SZWZlcmVuY2VzIiwid29ybGRSZWZlcmVuY2VTY2hlbWEiLCJpbW11dGFibGVTbmFwc2hvdElkIiwidmlld1NjaGVtYSIsInZpZXciLCJlbnRpdHlJZHMiLCJzZXR0aW5ncyIsInByb2plY3RIZWFkZXJGaWVsZHMiLCJwcm9qZWN0Q29udGVudEtleXMiLCJwcm9qZWN0S2V5cyIsImFsdGVybmF0aXZlc1NjaGVtYSIsInZhbGlkYXRlQWN0aXZlUmVjb3JkTmFtZXNwYWNlIiwid29ybGRzIiwicGlubmVkUHJvamVjdHMiLCJhY3RpdmVQcm9qZWN0cyIsImNvbnRleHRzIiwiY29udGVudCIsIndvcmxkIiwicmVmZXJlbmNlSW5kZXgiLCJmaW5kSW5kZXgiLCJjYWxlbmRhckluZGV4IiwiY2FsZW5kYXIiLCJwcmV2aW91cyIsInJlY29yZHMiLCJyZWNvcmRJbmRleCIsInJlY29yZFBhdGgiLCJ2YWxpZGF0ZUNvbnRlbnQiLCJvcHRpb25zIiwic25hcHNob3RJZHMiLCJ2ZXJzaW9uQ29udGVudHMiLCJfY2xvc3VyZSR3b3JsZHMiLCJfb3B0aW9ucyR3b3JsZHMiLCJfY2xvc3VyZSRyZWZlcmVuY2VzIiwiX2Nsb3N1cmUkcmVmZXJlbmNlczIiLCJfb3B0aW9ucyRyZWxhdGlvblR5cGUiLCJoZWFkZXIiLCJhcnJheXMiLCJwcmV2aW91c0VudGl0aWVzIiwicHJldmlvdXNSZWxhdGlvbnMiLCJlbnRpdHlSZWZlcmVuY2VzIiwiV2Vha01hcCIsInJlbGF0aW9uUmVmZXJlbmNlcyIsInJlbGF0aXZlIiwicHJlZml4IiwiaXMiLCJ2aWV3UmVmcyIsInJldXNhYmxlU25hcHNob3RzIiwiZXhlY3V0aW9uUHJvamVjdCIsIl9lbnRpdHkkZGF0YSRyZXVzZTIiLCJhbGxvd2VkV29ybGRJZHMiLCJjbG9zdXJlIiwid29ybGRTbmFwc2hvdHMiLCJlcnJvcnMiLCJyZWR1Y2UiLCJhbGxFbnRpdGllcyIsImZsYXRNYXAiLCJlbnRpdHlNYXAiLCJyZWxhdGlvbk1hcCIsImFsbENhbGVuZGFySWRzIiwiY2FsZW5kYXJJZHMiLCJ3b3JsZEtleXMiLCJibG9ja3MiLCJjb2xsZWN0Q29udGVudElkcyIsInByb2plY3Rpb25JZHMiLCJfZW50aXR5JGRhdGEkdHJpZ2dlciIsInB1YmxpY0ZpZWxkcyIsIl9lbnRpdHkkZGF0YSRwdWJsaWNUZSIsIndvcmxkVmVyc2lvbkRlcGVuZGVuY2llcyIsIl9vcHRpb25zJHdvcmxkU25hcHNobyIsIl9vcHRpb25zJHdvcmxkU25hcHNobzIiLCJrbm93blZlcnNpb25zIiwia25vd25Qcm9qZWN0cyIsImN1cnJlbnRJbmRleCIsInByb2plY3RzIiwidmVyc2lvbkluZGV4ZXMiLCJ2ZXJzaW9uSW5kZXgiLCJ2ZXJzaW9uSWQiLCJfdmVyc2lvbkNvbnRlbnRzJGdldCIsIl9vcHRpb25zJHdvcmxkU25hcHNobzMiLCJfdmVyc2lvbkNsb3N1cmUkd29ybGQiLCJfb3B0aW9ucyR3b3JsZHMyIiwiX2VudGl0eSRkYXRhJHJldXNlMyIsInJhd0NvbnRlbnQiLCJfZW50aXR5JGRhdGEkcmV1c2U0IiwidmVyc2lvbkNsb3N1cmUiLCJwaW5uZWRXb3JsZHMiLCJ2ZXJzaW9uQmxvY2tzIiwidmVyc2lvblByb2plY3Rpb25JZHMiLCJfZW50aXR5JGRhdGEkdHJpZ2dlcjIiLCJfZW50aXR5JGRhdGEkcHVibGljVGUyIiwiaW5zcGVjdCIsImV4aXN0cyIsInJlZmVyZW5jZXNGb3IiLCJfZW50aXR5JGRhdGEkaGFuZG9mZlIiLCJfcmVmMiIsIl9lbnRpdHkkZGF0YSRwdWJsaWNUZTMiLCJwYXJlbnQiLCJyZXVzZVZlcnNpb24iLCJwcm9maWxlVmVyc2lvbiIsImdhbWVQcm9maWxlVmVyc2lvbiIsImFuY2hvclZlcnNpb24iLCJ1c2VzVmVyc2lvbiIsIl9yZWxhdGlvblJlZmVyZW5jZXMkZyIsInJlbGF0aW9uVHlwZXMiLCJjYW5kaWRhdGUiLCJhZmZlY3RlZElkcyIsInZhbGlkYXRlQ3Jvc3NFbnRpdHlSdWxlcyIsImN5Y2xlSXNzdWVzIiwibm9kZXMiLCJjb2xvcnMiLCJzdGFjayIsImN1cnJlbnQiLCJuZXh0SWQiLCJyZXNvbHZlVmVyc2lvbiIsImFmZmVjdGVkIiwidHJhbnNsYXRpb25LZXlzIiwiX2VudGl0eSRkYXRhJG93bmVySWQiLCJfZW50aXR5JGRhdGEkdHJhbnNpdGkiLCJfZW50aXR5JGRhdGEkZXhjbHVzaW8iLCJvdGhlciIsIl9lbnRpdHkkZGF0YSRtZW1iZXJJZCIsIl9lbnRpdHkkZGF0YSR2YWx1ZTMiLCJpbnN0YW5jZSIsImRlc3RpbmF0aW9uIiwiX2VudGl0eSRkYXRhJHBhcmFtZXRlIiwiZWRnZUlkIiwiZWRnZSIsInBhcmFtZXRlcktleXMiLCJwYXJhbWV0ZXIiLCJ2YWxpZGF0ZUNvbmRpdGlvblR5cGVzSW5WYWx1ZSIsInZhbGlkYXRlQW5jaG9ycyIsInNwZWNpZmljIiwiX3BvbGljeSRieUVudGl0eUlkIiwiX2FsaWFzZXMkZ2V0IiwiX2VudGl0eSRkYXRhJG9yaWdpbiIsIl90cmFjZSRyZWFkaW5nUGF0aCIsInN0ZXAiLCJvY2N1cnJlbmNlIiwiX2VudGl0eSRkYXRhJGRlcGVuZHNPIiwiZXhwcmVzc2lvblJlZmVyZW5jZXMiLCJhdXRvbWF0aWNQcmlvcml0eSIsIl9lbnRpdHkkZGF0YSRwcmlvcml0eSIsInByaW9yaXR5S2V5IiwiX3JlZmVyZW5jZSRraW5kcyIsImRlZmF1bHRWZXJzaW9uIiwiX2luZGV4JGVudGl0aWVzIiwiX2luZGV4JGJsb2NrcyIsImVudGl0eUluZGV4IiwiYmxvY2tJbmRleCIsInRhcmdldFRleHQiLCJ2YWxpZGF0ZVByb2plY3QiLCJhdXRob3JBbHRlcm5hdGl2ZXMiLCJ2YWxpZGF0ZWQiLCJzbmFwc2hvdENvbnRlbnRNYXAiLCJ2YWxpZGF0ZVNuYXBzaG90Q29sbGVjdGlvbiIsImhpc3RvcnlJZHMiLCJjb21tYW5kIiwicmF3IiwiY29tbWFuZE1ldGEiLCJvcGVyYXRpb25JZCIsImNvbXBlbnNhdGVzT3BlcmF0aW9uSWQiLCJpbXBvcnRPcmlnaW4iLCJzb3VyY2VQcm9qZWN0SWQiLCJzb3VyY2VPcGVyYXRpb25JZCIsImltcG9ydE9wZXJhdGlvbklkIiwiaGlzdG9yaWNhbCIsImhpc3RvcmljYWxJZHMiLCJ2YWxpZGF0ZUN1cnJlbnRQcm9qZWN0IiwiZHVwbGljYXRlcyIsImNvbnRlbnRzIiwibWV0YWRhdGEiLCJldmVyeSIsInRvSnNvblNjaGVtYSIsIiRyZWYiLCJjb252ZXJ0IiwiX3NjaGVtYSRtYXgyIiwibWluTGVuZ3RoIiwibWF4TGVuZ3RoIiwibWluaW11bSIsIk1JTl9TQUZFX0lOVEVHRVIiLCJtYXhpbXVtIiwiTUFYX1NBRkVfSU5URUdFUiIsImVudW0iLCIkY29tbWVudCIsInJlZmVyZW5jZVNjb3BlIiwiZm9ybWF0IiwicGF0dGVybiIsIml0ZW1zIiwibWluSXRlbXMiLCJtYXhJdGVtcyIsInVuaXF1ZUl0ZW1zIiwiYW55T2YiLCJhZGRpdGlvbmFsUHJvcGVydGllcyIsInByb3BlcnR5TmFtZXMiLCJjb25kaXRpb25hbERlZmluaXRpb25zIiwiY29uc3QiLCJjb21wYXJlRGVmaW5pdGlvbiIsImluRGVmaW5pdGlvbiIsInNwYW4iLCJjYWxlbmRhckNvbW1vbiIsIm9yaWdpbkxhYmVsIiwidGlja3NQZXJEYXkiLCJ5ZWFycyIsIm1vbnRocyIsImRheXMiLCJkZWZzIiwiSUQiLCJUaWNrIiwiUmV2aXNpb24iLCJSaWNoVGV4dCIsIkN1c3RvbVZhbHVlIiwiVHlwZWRWYWx1ZSIsIm9uZU9mIiwiVGltZVNwZWMiLCJDb25kaXRpb24iLCJFeHByZXNzaW9uIiwiTmFtZVBvbGljeSIsIlF1ZXJ5IiwiQ2FsZW5kYXIiLCJSZWxhdGlvbiIsIldvcmxkUmVmZXJlbmNlIiwiU2F2ZWRWaWV3IiwiRW50aXR5IiwiYXJiaXRyYXJ5VmFsdWUiLCJ2YWx1ZVNuYXBzaG90IiwicHJlc2VudCIsIkFsdGVybmF0aXZlUGF0Y2giLCJBbHRlcm5hdGl2ZUFwcGx5UmVjZWlwdCIsImFsdGVybmF0aXZlVmVyc2lvbklkIiwic291cmNlU25hcHNob3RJZCIsInNlbGVjdGVkQ2hhbmdlS2V5cyIsImZyb21DYW5vbmljYWxSZXZpc2lvbiIsImFwcGxpZWRSZXZpc2lvbiIsInBhdGNoZXMiLCJTdHJ1Y3R1cmVQbGFuIiwiYmVhdExhYmVscyIsImFzc2lnbm1lbnRzIiwiQWx0ZXJuYXRpdmVWZXJzaW9uIiwicGFyZW50VmVyc2lvbklkIiwic3RydWN0dXJlUGxhbiIsIkF1dGhvckFsdGVybmF0aXZlIiwiYmFzZUNvbnRlbnQiLCJiYXNlQ29udGVudEhhc2giLCJ2ZXJzaW9ucyIsImhlYWRWZXJzaW9uSWQiLCJhcHBseVJlY2VpcHRzIiwiaW50ZWdyaXR5SGFzaCIsInRyYWNlU2NoZW1hIiwiRW50aXR5X3RyYWNlIiwiYWxsT2YiLCJpZiIsIm5vdCIsImNvbnRlbnRQcm9wZXJ0aWVzIiwiUHJvamVjdENvbnRlbnQiLCJQcm9qZWN0U25hcHNob3QiLCJDb250ZW50U3RhdGUiLCJDb21tYW5kUmVjb3JkIiwiYXNzaWduIiwiJHNjaGVtYSIsIiRpZCIsInRpdGxlIiwiJGRlZnMiXSwic291cmNlcyI6WyJtb2RlbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyByZXNvbHZlUGlubmVkV29ybGRzIH0gZnJvbSAnLi9waW5uZWRXb3JsZHMnO1xuaW1wb3J0IHsgcmVzb2x2ZVJldXNlQ29udGVudCwgcmV1c2VWYWxpZGF0aW9uSXNzdWVzIH0gZnJvbSAnLi9yZXVzZSc7XG5pbXBvcnQgeyBGT1JNQVRfVkVSU0lPTiB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHR5cGUgeyBBbGlhcywgQ2FsZW5kYXJEZWZpbml0aW9uLCBDb25kaXRpb24sIEVudGl0eSwgRW50aXR5RGF0YU1hcCwgRW50aXR5S2luZCwgRXhwcmVzc2lvbiwgSUQsIFByZXNlbnRhdGlvbkNvbmRpdGlvblJlc3VsdCwgUHJvamVjdENvbnRlbnQsIFByb2plY3REYXRhLCBSZWxhdGlvbiwgUmVsYXRpb25UeXBlRGVmaW5pdGlvbiwgUmljaFRleHQsIFJ1bnRpbWVTdGF0ZSwgVGltZVNwZWMsIFR5cGVkVmFsdWUsIFZhbGlkYXRpb25Jc3N1ZSwgVmFsaWRhdGlvblJlc3VsdCwgVmFsaWRpdHkgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IEdSRUdPUklBTl9DQUxFTkRBUiwgY29tcGFyZVRpY2tzLCBpc1RpY2ssIHBhcnNlVGljaywgdmFsaWRhdGVDYWxlbmRhciwgdmFsaWRhdGVFdmVudFRpbWVzLCBzYW1lQ2FsZW5kYXJEZWZpbml0aW9uIH0gZnJvbSAnLi90aW1lJztcbmltcG9ydCB7IHZhbGlkYXRlVGVtcGxhdGVBc3NpZ25tZW50cywgdmFsaWRhdGVUZW1wbGF0ZURlZmluaXRpb24gfSBmcm9tICcuL3RlbXBsYXRlcyc7XG5cbmV4cG9ydCBjb25zdCBLSU5EX0xBQkVMUzogUmVjb3JkPEVudGl0eUtpbmQsIHN0cmluZz4gPSB7XG4gIGNoYXJhY3RlcjogJ+S6uueJqScsIGdyb3VwOiAn44Kw44Or44O844OXJywgZXZlbnQ6ICflh7rmnaXkuosnLCBwbGFjZTogJ+WgtOaJgCcsIGl0ZW06ICfnianlk4EnLCBub3RlOiAn44Oh44OiJywgY2hhcHRlcjogJ+eroCcsIHNjZW5lOiAn5aC06Z2iJywgZ29hbDogJ+ebruaomScsXG4gIGZsb3dfbm9kZTogJ+mAsuihjOODjuODvOODiScsIGZsb3dfZWRnZTogJ+mAsuihjOe3micsIGZsb3dfZ3JhcGg6ICfliIblspDlm7MnLCBkaWFsb2d1ZV9saW5lOiAn5Y+w6KmeJywgcXVlc3Q6ICfjgq/jgqjjgrnjg4gnLCBsb3JlOiAn6Kit5a6aJywgdmFyaWFibGU6ICfnirbmhYvlpInmlbAnLFxuICBlZmZlY3Q6ICflirnmnpwnLCBhc3NlcnRpb246ICfkuovlrp/jg7voqo3orZgnLCBmb3Jlc2hhZG93OiAn5LyP57eaJywgZGlzY2xvc3VyZTogJ+aJi+aOm+OBi+OCiuODu+WbnuWPjicsIGNoZWNrcG9pbnQ6ICfpgJTkuK3plovlp4vngrknLCB0cmFjZTogJ+ippuiqreiomOmMsicsIGF0dGFjaG1lbnQ6ICfmt7vku5jntKDmnZAnLFxuICBzb3VyY2U6ICfos4fmlpnjg7vlh7rmiYAnLCBjdWU6ICfmvJTlh7onLCBzdG9yeWJvYXJkX2ZyYW1lOiAn57W144Kz44Oz44OGJywgbG9jYWxpemF0aW9uOiAn57+76KizJywgcmVjb3JkaW5nOiAn5Y+O6YyyJywgdGVybWlub2xvZ3k6ICfnlKjoqp4nLCBtYXA6ICflnLDlm7MnLCB0cmF2ZWxfcm91dGU6ICfnp7vli5XntYzot68nLFxuICB0ZW1wbGF0ZTogJ+mbm+W9oicsIGNvbGxlY3Rpb246ICfkuIDopqcnLCByZXZpZXc6ICfjg6zjg5Pjg6Xjg7wnLCBjcmVhdGl2ZV9icmllZjogJ+S8geeUuycsIGRlY2lzaW9uOiAn5Yi25L2c5Yik5patJywgZ2FtZXBsYXlfc3BlYzogJ+OCsuODvOODoOS7leanmCcsIHByb2R1Y3Rpb25fdGFzazogJ+WItuS9nOOCv+OCueOCrycsXG4gIG1lZGlhX3ZhcmlhbnQ6ICflqpLkvZPniYgnLCB2b2ljZV9ydWxlOiAn5Y+j6Kq/JywgZXh0ZXJuYWxfY29udHJhY3Q6ICflpJbpg6jlpZHntIQnLCBzbmFwc2hvdDogJ+WFrOmWi+eJiCcsIHByb2plY3Rpb25fcHJvZmlsZTogJ+WFrOmWi+aKleW9sScsXG59O1xuZXhwb3J0IGNvbnN0IEVOVElUWV9LSU5EUyA9IE9iamVjdC5rZXlzKEtJTkRfTEFCRUxTKSBhcyBFbnRpdHlLaW5kW107XG5leHBvcnQgY29uc3QgU1RBVFVTRVMgPSBbJ2NvbmZpcm1lZCcsICdwcm92aXNpb25hbCcsICduZWVkc19yZXZpZXcnLCAncmVqZWN0ZWQnLCAnYWx0ZXJuYXRlJ10gYXMgY29uc3Q7XG5leHBvcnQgY29uc3QgU0NPUEVTID0gWydzY2VuZScsICdjaGFwdGVyJywgJ2NoYXJhY3RlcicsICdydW4nLCAnYWNyb3NzX3J1bnMnXSBhcyBjb25zdDtcbmV4cG9ydCBjb25zdCBSRUxBVElPTl9UWVBFUzogUmVsYXRpb25UeXBlRGVmaW5pdGlvbltdID0gW1xuICB7IGtleTogJ3RydXN0JywgbGFiZWw6ICfkv6HpoLwnLCBmcm9tS2luZHM6IFsnY2hhcmFjdGVyJ10sIHRvS2luZHM6IFsnY2hhcmFjdGVyJ10sIGFsbG93U2VsZjogZmFsc2UsIGFsbG93U3ltbWV0cmljOiBmYWxzZSB9LFxuICB7IGtleTogJ2NhdXNlcycsIGxhYmVsOiAn5Zug5p6cJywgZnJvbUtpbmRzOiBbJ2V2ZW50J10sIHRvS2luZHM6IFsnZXZlbnQnXSwgYWxsb3dTZWxmOiBmYWxzZSwgYWxsb3dTeW1tZXRyaWM6IGZhbHNlIH0sXG4gIHsga2V5OiAncmVxdWlyZXMnLCBsYWJlbDogJ+WJjeaPkCcsIGZyb21LaW5kczogRU5USVRZX0tJTkRTLCB0b0tpbmRzOiBFTlRJVFlfS0lORFMsIGFsbG93U2VsZjogZmFsc2UsIGFsbG93U3ltbWV0cmljOiBmYWxzZSB9LFxuICB7IGtleTogJ2ZvcmVzaGFkb3dfcGF5b2ZmJywgbGFiZWw6ICfmiYvmjpvjgYvjgorihpLlm57lj44nLCBmcm9tS2luZHM6IFsnZGlzY2xvc3VyZSddLCB0b0tpbmRzOiBbJ2Rpc2Nsb3N1cmUnXSwgYWxsb3dTZWxmOiBmYWxzZSwgYWxsb3dTeW1tZXRyaWM6IGZhbHNlIH0sXG4gIHsga2V5OiAncGFyZW50X29mJywgbGFiZWw6ICfopqrlrZAnLCBmcm9tS2luZHM6IFsnY2hhcmFjdGVyJ10sIHRvS2luZHM6IFsnY2hhcmFjdGVyJ10sIGFsbG93U2VsZjogZmFsc2UsIGFsbG93U3ltbWV0cmljOiBmYWxzZSB9LFxuICB7IGtleTogJ2V2ZW50X2ZvcmVzaGFkb3cnLCBsYWJlbDogJ+WHuuadpeS6i+OBruS6iOWRiicsIGZyb21LaW5kczogWydldmVudCddLCB0b0tpbmRzOiBbJ2V2ZW50J10sIGFsbG93U2VsZjogZmFsc2UsIGFsbG93U3ltbWV0cmljOiBmYWxzZSB9LFxuICB7IGtleTogJ2V2ZW50X3BheW9mZicsIGxhYmVsOiAn5Ye65p2l5LqL44Gu5Zue5Y+OJywgZnJvbUtpbmRzOiBbJ2V2ZW50J10sIHRvS2luZHM6IFsnZXZlbnQnXSwgYWxsb3dTZWxmOiBmYWxzZSwgYWxsb3dTeW1tZXRyaWM6IGZhbHNlIH0sXG4gIHsga2V5OiAnbWVudG9yX29mJywgbGFiZWw6ICfluKvlvJ8nLCBmcm9tS2luZHM6IFsnY2hhcmFjdGVyJ10sIHRvS2luZHM6IFsnY2hhcmFjdGVyJ10sIGFsbG93U2VsZjogZmFsc2UsIGFsbG93U3ltbWV0cmljOiBmYWxzZSB9LFxuICB7IGtleTogJ2Jsb29kbGluZScsIGxhYmVsOiAn6KGA57WxJywgZnJvbUtpbmRzOiBbJ2NoYXJhY3RlciddLCB0b0tpbmRzOiBbJ2NoYXJhY3RlciddLCBhbGxvd1NlbGY6IGZhbHNlLCBhbGxvd1N5bW1ldHJpYzogZmFsc2UgfSxcbiAgeyBrZXk6ICdyZWxhdGVkJywgbGFiZWw6ICfplqLpgKMnLCBmcm9tS2luZHM6IEVOVElUWV9LSU5EUywgdG9LaW5kczogRU5USVRZX0tJTkRTLCBhbGxvd1NlbGY6IGZhbHNlLCBhbGxvd1N5bW1ldHJpYzogdHJ1ZSB9LFxuICB7IGtleTogJ3JlZmVyZW5jZScsIGxhYmVsOiAn5Y+C54WnJywgZnJvbUtpbmRzOiBFTlRJVFlfS0lORFMsIHRvS2luZHM6IEVOVElUWV9LSU5EUywgYWxsb3dTZWxmOiB0cnVlLCBhbGxvd1N5bW1ldHJpYzogZmFsc2UgfSxcbl07XG5leHBvcnQgY29uc3QgUkVMQVRJT05fTEFCRUxTID0gT2JqZWN0LmZyb21FbnRyaWVzKFJFTEFUSU9OX1RZUEVTLm1hcCh0eXBlID0+IFt0eXBlLmtleSwgdHlwZS5sYWJlbF0pKSBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuZXhwb3J0IGNvbnN0IElEX1BBVFRFUk4gPSAvXlswLTlhLWZdezh9LVswLTlhLWZdezR9LVswLTlhLWZdezR9LVswLTlhLWZdezR9LVswLTlhLWZdezEyfSQvO1xuZXhwb3J0IGNvbnN0IFJFVklTSU9OX1BBVFRFUk4gPSAvXig/OjB8WzEtOV1bMC05XSopJC87XG5leHBvcnQgY29uc3QgZW1wdHlWYWxpZGl0eSA9ICgpOiBWYWxpZGl0eSA9PiAoeyB3b3JsZFJhbmdlOiBudWxsLCByb3V0ZUNvbmRpdGlvbjogbnVsbCwgcHJlc2VudGF0aW9uQW5jaG9yOiBudWxsIH0pO1xuZXhwb3J0IGNvbnN0IG5ld0lkID0gKCk6IElEID0+IGNyeXB0by5yYW5kb21VVUlEKCk7XG5leHBvcnQgZnVuY3Rpb24gdGV4dFRvUmljaFRleHQodGV4dDogc3RyaW5nKTogUmljaFRleHQgeyByZXR1cm4gdGV4dCA9PT0gJycgPyBbXSA6IHRleHQuc3BsaXQoJ1xcbicpLm1hcChsaW5lID0+ICh7IGlkOiBuZXdJZCgpLCBraW5kOiAncGFyYWdyYXBoJywgdGV4dDogbGluZSB9KSk7IH1cbmV4cG9ydCBmdW5jdGlvbiByaWNoVGV4dFRvUGxhaW5UZXh0KHRleHQ6IFJpY2hUZXh0IHwgbnVsbCB8IHVuZGVmaW5lZCk6IHN0cmluZyB7IHJldHVybiAodGV4dCA/PyBbXSkubWFwKGJsb2NrID0+IGJsb2NrLnRleHQpLmpvaW4oJ1xcbicpOyB9XG5leHBvcnQgZnVuY3Rpb24gZ2V0RW50aXR5PEsgZXh0ZW5kcyBFbnRpdHlLaW5kID0gRW50aXR5S2luZD4ocHJvamVjdDogUGljazxQcm9qZWN0RGF0YSwgJ2VudGl0aWVzJz4sIGlkOiBJRCk6IEVudGl0eTxLPiB8IHVuZGVmaW5lZCB7IHJldHVybiBwcm9qZWN0LmVudGl0aWVzLmZpbmQoZW50aXR5ID0+IGVudGl0eS5pZCA9PT0gaWQgJiYgIWVudGl0eS5kZWxldGVkQXQpIGFzIEVudGl0eTxLPiB8IHVuZGVmaW5lZDsgfVxuZXhwb3J0IGZ1bmN0aW9uIGdldEVudGl0aWVzQnlLaW5kPEsgZXh0ZW5kcyBFbnRpdHlLaW5kPihwcm9qZWN0OiBQaWNrPFByb2plY3REYXRhLCAnZW50aXRpZXMnPiwga2luZDogSyk6IEVudGl0eTxLPltdIHsgcmV0dXJuIHByb2plY3QuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiBlbnRpdHkua2luZCA9PT0ga2luZCAmJiAhZW50aXR5LmRlbGV0ZWRBdCkgYXMgRW50aXR5PEs+W107IH1cbmV4cG9ydCBmdW5jdGlvbiBkZWZhdWx0RGF0YTxLIGV4dGVuZHMgRW50aXR5S2luZD4oa2luZDogSyk6IEVudGl0eURhdGFNYXBbS10ge1xuICAvLyBBIHJlcXVpcmVkIHJlZmVyZW5jZSBzdGF5cyBudWxsIGluIGFuIHVuc2F2ZWQgZWRpdG9yIGRyYWZ0OyBubyBmYWtlIElEIGlzIGdlbmVyYXRlZC5cbiAgY29uc3QgdW5rbm93bjogVHlwZWRWYWx1ZSA9IHsgdHlwZTogJ3Vua25vd24nLCB2YWx1ZTogbnVsbCwgcmVhc29uOiAn5pyq5YWl5YqbJyB9O1xuICBjb25zdCBkYXRhOiBSZWNvcmQ8RW50aXR5S2luZCwgdW5rbm93bj4gPSB7XG4gICAgY2hhcmFjdGVyOiB7IHJlYWRpbmc6ICcnLCBhbGlhc2VzOiBbXSwgc3VtbWFyeTogW10sIGJvZHk6IFtdLCBhdXRob3JOb3RlczogW10sIGdvYWxzOiBbXSwgdm9pY2VSdWxlczogW10gfSxcbiAgICBncm91cDogeyBncm91cFR5cGU6ICdkaXNwbGF5JywgbWVtYmVyczogW10sIHBhcmVudElkOiBudWxsLCBzdW1tYXJ5OiBbXSB9LFxuICAgIGV2ZW50OiB7IHN1bW1hcnk6IFtdLCB0aW1lOiB7IG1vZGU6ICd1bmtub3duJywgcmVhc29uOiAnJyB9LCBsYW5lUm9sZTogJ2NvbW1vbicsIHBhcnRpY2lwYW50czogW10sIGxvY2F0aW9uSWQ6IG51bGwsIGl0ZW1JZHM6IFtdLCBhdXRob3JOb3RlczogW10sIGNvbnN0cmFpbnRzOiBbXSB9LFxuICAgIHBsYWNlOiB7IHBhcmVudElkOiBudWxsLCByZWFkaW5nOiAnJywgYWxpYXNlczogW10sIGJvZHk6IFtdLCBtYXBJZHM6IFtdLCBjaGFuZ2VzOiBbXSB9LFxuICAgIGl0ZW06IHsgaXRlbU1vZGU6ICd0eXBlJywgdHlwZUlkOiBudWxsLCBib2R5OiBbXSwgcHJvcGVydGllczogbnVsbCwgY2hhbmdlczogW10gfSxcbiAgICBub3RlOiB7IGJvZHk6IFtdLCBhdHRhY2htZW50SWRzOiBbXSwgY29udmVydGVkVG9JZHM6IFtdLCBvcmlnaW5Ob3RlSWQ6IG51bGwgfSxcbiAgICBjaGFwdGVyOiB7IHNjZW5lSWRzOiBbXSwgc3VtbWFyeTogW10sIGF1dGhvck5vdGVzOiBbXSwgc3RydWN0dXJlUm9sZTogJycgfSxcbiAgICBzY2VuZTogeyBzdW1tYXJ5OiBbXSwgYm9keTogW10sIGF1dGhvck5vdGVzOiBbXSwgZXZlbnRJZHM6IFtdLCBjaGFwdGVySWQ6IG51bGwsIHRocmVhZElkczogW10sIHBvdklkOiBudWxsLCBnb2FsczogW10sIGNvbmZsaWN0czogW10sIHJlc3VsdHM6IFtdLCBuZXdJbmZvcm1hdGlvbjogW10sIHRlbnNpb246IG51bGwsIGltcG9ydGFuY2U6IG51bGwsIGJsb2NrSWRzOiBbXSB9LFxuICAgIGdvYWw6IHsgb3duZXJJZDogbnVsbCwgZGVzY3JpcHRpb246IFtdLCBjaGFuZ2VzOiBbXSwgZXZpZGVuY2VTY2VuZUlkczogW10sIHZhbGlkaXR5OiBlbXB0eVZhbGlkaXR5KCkgfSxcbiAgICBmbG93X25vZGU6IHsgbm9kZVR5cGU6ICdjaG9pY2UnLCBzY2VuZUlkOiBudWxsLCBjaGlsZEdyYXBoSWQ6IG51bGwsIHRlcm1pbmFsUmVhc29uOiAnJywgZ2F0ZTogeyBvcDogJ2NvbnN0YW50JywgdmFsdWU6IHRydWUgfSwgZXhlY3V0aW9uUG9saWN5OiAnbWFudWFsX2Nob2ljZScsIGZhbGxiYWNrSWQ6IG51bGwgfSxcbiAgICBmbG93X2VkZ2U6IHsgZnJvbUlkOiBudWxsLCB0b0lkOiB7IHVucmVzb2x2ZWQ6IHsgbGFiZWw6ICcnLCByZWFzb246ICfmnKrlrozmiJAnIH0gfSwgZWRnZVR5cGU6ICdjaG9pY2UnLCBsYWJlbDogJycsIGNvbmRpdGlvbjogeyBvcDogJ2NvbnN0YW50JywgdmFsdWU6IHRydWUgfSwgZWZmZWN0SWRzOiBbXSwgcHJpb3JpdHk6IDAsIGNob2ljZUxpbmVJZDogbnVsbCB9LFxuICAgIGZsb3dfZ3JhcGg6IHsgbm9kZUlkczogW10sIGVkZ2VJZHM6IFtdLCBlbnRyeUlkczogW10sIGV4aXRJZHM6IFtdLCBwYXJlbnRHcmFwaElkOiBudWxsLCBwYXJhbWV0ZXJzOiBbXSB9LFxuICAgIGRpYWxvZ3VlX2xpbmU6IHsgdGV4dDogW10sIHNwZWFrZXJJZDogbnVsbCwgY2hvaWNlRWRnZUlkOiBudWxsLCBjdWVJZHM6IFtdLCBvcmlnaW5MaW5lSWRzOiBbXSB9LFxuICAgIHF1ZXN0OiB7IGtleTogJycsIHN0YXRlVmFyaWFibGVJZDogbnVsbCwgZGVzY3JpcHRpb246IFtdLCBmbG93SWRzOiBbXSwgdHJhbnNpdGlvblJ1bGVzOiBbXSwgZ2FtZXBsYXlTcGVjSWRzOiBbXSB9LFxuICAgIGxvcmU6IHsgYm9keTogW10sIGFzc2VydGlvbklkczogW10sIHNvdXJjZUlkczogW10sIHJlYWRpbmc6ICcnLCBhbGlhc2VzOiBbXSB9LFxuICAgIHZhcmlhYmxlOiB7IGtleTogJycsIHZhbHVlVHlwZTogJ2Jvb2xlYW4nLCBzY29wZTogJ3J1bicsIGluaXRpYWw6IHVua25vd24sIGFsbG93ZWQ6IHsgdmFsdWVzOiBbZmFsc2UsIHRydWVdIH0sIGRlc2NyaXB0aW9uOiBbXSwgb3duZXJJZDogbnVsbCwgZXh0ZXJuYWxDb250cmFjdElkOiBudWxsLCByZXNldFJ1bGVzOiBbXSwgdHJhbnNpdGlvblJ1bGVzOiBbXSwgZXh0ZXJuYWxVc2VEZWNsYXJlZDogZmFsc2UgfSxcbiAgICBlZmZlY3Q6IHsgb3BlcmF0aW9uOiAnc2V0JywgdGFyZ2V0SWQ6IG51bGwsIHZhbHVlOiB1bmtub3duLCBjb25kaXRpb246IHsgb3A6ICdjb25zdGFudCcsIHZhbHVlOiB0cnVlIH0sIGluc3RhbmNlSWQ6IG51bGwsIHJlYXNvbjogJycgfSxcbiAgICBhc3NlcnRpb246IHsgc3ViamVjdElkOiBudWxsLCBwcmVkaWNhdGU6ICcnLCB2YWx1ZTogdW5rbm93biwgdHJ1dGhLaW5kOiAnYXV0aG9yX3RydXRoJywgaG9sZGVySWQ6IG51bGwsIHNvdXJjZUlkczogW10sIGV2aWRlbmNlTG9jYXRpb246IG51bGwsIHZhbGlkaXR5OiBlbXB0eVZhbGlkaXR5KCksIHJlYXNvbjogJycgfSxcbiAgICBmb3Jlc2hhZG93OiB7IHF1ZXN0aW9uOiBbXSwgaW50ZW50OiBbXSwgcmVzb2x1dGlvblBvbGljeTogJ3VuZGVjaWRlZCcsIHRydXRoQXNzZXJ0aW9uSWRzOiBbXSwgY2x1ZUlkczogW10sIHBheW9mZklkczogW10sIHJlcXVpcmVkSW5mbzogW10sIGRlYWRsaW5lOiBudWxsLCBleGNlcHRpb25zOiBbXSB9LFxuICAgIGRpc2Nsb3N1cmU6IHsgZm9yZXNoYWRvd0lkOiBudWxsLCBhbmNob3I6IHsgZW50aXR5SWQ6IG51bGwgfSwgc3RhZ2U6ICdoaW50Jywgcm9sZTogJ2NsdWUnLCBjb25kaXRpb246IHsgb3A6ICdjb25zdGFudCcsIHZhbHVlOiB0cnVlIH0sIGtub3dsZWRnZUVmZmVjdHM6IFtdLCB0YXJnZXRTY29wZTogbnVsbCB9LFxuICAgIGNoZWNrcG9pbnQ6IHsgY29udGVudFZlcnNpb25JZDogbnVsbCwgcnVudGltZVN0YXRlOiBlbXB0eVJ1bnRpbWVTdGF0ZSgnJyksIG9yaWdpbjogJ3BhcnRpYWwnLCB0cmFjZUlkOiBudWxsIH0sXG4gICAgdHJhY2U6IHsgY29udGVudFZlcnNpb25JZDogbnVsbCwgc3RhcnRDaGVja3BvaW50SWQ6IG51bGwsIHN0ZXBzOiBbXSwgc2VlZDogJycsIGVuZ2luZVZlcnNpb246ICcxLjAuMCcsIGV4dGVybmFsTW9kZTogJ3N0dWInIH0sXG4gICAgYXR0YWNobWVudDogeyBtZWRpYVR5cGU6ICcnLCBjb250ZW50SGFzaDogJycsIGJ5dGVTaXplOiAwLCBhc3NldFBhdGg6ICcnLCBkaXNwbGF5TmFtZTogJycsIHN0YWdlOiAncmVmZXJlbmNlJywgcmV2aXNpb25IaXN0b3J5OiBbXSB9LFxuICAgIHNvdXJjZTogeyBzb3VyY2VUeXBlOiAnd2ViJywgbG9jYXRvcjogJycsIGFjY2Vzc2VkQXQ6IG51bGwsIGV4Y2VycHRMb2NhdGlvbjogJycsIGludGVycHJldGF0aW9uOiBbXSwgYXR0YWNobWVudElkOiBudWxsLCByZWRpc3RyaWJ1dGlvbkFsbG93ZWQ6IGZhbHNlIH0sXG4gICAgY3VlOiB7IGFuY2hvcjogeyBlbnRpdHlJZDogbnVsbCB9LCBjdWVUeXBlOiAnJywgYXR0YWNobWVudElkOiBudWxsLCBzcGVha2VySWQ6IG51bGwsIGV4cHJlc3Npb246ICcnLCB3YWl0TXM6IG51bGwsIGNhbWVyYTogbnVsbCwgbWVkaWFUaW1lOiBudWxsLCBzdGFnZTogJycgfSxcbiAgICBzdG9yeWJvYXJkX2ZyYW1lOiB7IGFuY2hvcjogeyBlbnRpdHlJZDogbnVsbCB9LCBtZWRpYVN0YXJ0TXM6IDAsIG1lZGlhRW5kTXM6IG51bGwsIHJlZmVyZW5jZUFzc2V0SWQ6IG51bGwsIGZpbmFsQXNzZXRJZDogbnVsbCwgY3VlSWRzOiBbXSwgY2FwdGlvbjogW10gfSxcbiAgICBsb2NhbGl6YXRpb246IHsgc291cmNlTGluZUlkOiBudWxsLCBsYW5ndWFnZTogJycsIHNvdXJjZUhhc2g6ICcnLCB0ZXh0OiBbXSwgc3RhZ2U6ICdkcmFmdCcsIHJldmlld2VkQnk6IG51bGwsIHJlY29yZGluZ0lkczogW10gfSxcbiAgICByZWNvcmRpbmc6IHsgc291cmNlTGluZUlkOiBudWxsLCBsYW5ndWFnZTogJycsIHNvdXJjZUhhc2g6ICcnLCB0cmFuc2xhdGlvbklkOiBudWxsLCBhdHRhY2htZW50SWQ6IG51bGwsIG5vdGVzOiBbXSwgc3RhZ2U6ICdwbGFubmVkJywgcmV2aWV3ZWRCeTogbnVsbCB9LFxuICAgIHRlcm1pbm9sb2d5OiB7IGNhbm9uaWNhbDogJycsIHJlYWRpbmc6ICcnLCB2YXJpYW50czogW10sIGxhbmd1YWdlOiBudWxsLCB1c2FnZU5vdGVzOiBbXSwgdmFsaWRpdHk6IGVtcHR5VmFsaWRpdHkoKSwgZXhjZXB0aW9uczogW10sIHZvaWNlT3duZXJJZDogbnVsbCB9LFxuICAgIG1hcDogeyBwbGFjZUlkOiBudWxsLCBjb29yZGluYXRlU3lzdGVtOiAnbm9ybWFsaXplZCcsIGF0dGFjaG1lbnRJZDogbnVsbCwgcGFyZW50TWFwSWQ6IG51bGwsIHBpbnM6IFtdIH0sXG4gICAgdHJhdmVsX3JvdXRlOiB7IGZyb21QbGFjZUlkOiBudWxsLCB0b1BsYWNlSWQ6IG51bGwsIGRpcmVjdGlvbjogJ29uZV93YXknLCBtZXRob2Q6ICcnLCBtaW5pbXVtVGlja3M6IG51bGwsIG1heGltdW1UaWNrczogbnVsbCwgZXZpZGVuY2U6IFtdLCB2YWxpZGl0eTogZW1wdHlWYWxpZGl0eSgpIH0sXG4gICAgdGVtcGxhdGU6IHsgdGFyZ2V0S2luZDogJ2NoYXJhY3RlcicsIGZpZWxkczogW10sIGRlc2NyaXB0aW9uOiAnJywgdmVyc2lvbjogJzAnLCBkZWZhdWx0czoge30gfSxcbiAgICBjb2xsZWN0aW9uOiB7IG1vZGU6ICdmaXhlZCcsIG1lbWJlcklkczogW10sIHF1ZXJ5OiBudWxsLCBzb3J0OiB7IGZpZWxkOiAnbmFtZScsIGRpcmVjdGlvbjogJ2FzYycgfSB9LFxuICAgIHJldmlldzogeyB0YXJnZXQ6IG51bGwsIHRhcmdldFZlcnNpb25JZDogbnVsbCwgYm9keTogW10sIHN0YWdlOiAnb3BlbicsIGFzc2lnbmVlSWQ6IG51bGwsIHF1b3RlZFRleHQ6ICcnLCByZXNvbHV0aW9uOiBbXSB9LFxuICAgIGNyZWF0aXZlX2JyaWVmOiB7IHRhcmdldEF1ZGllbmNlOiBbXSwgZXhwZXJpZW5jZTogW10sIHRoZW1lOiBbXSwgdG9uZTogW10sIHNjb3BlOiBbXSwgZGVsaXZlcmFibGVJZHM6IFtdLCBkZWNpc2lvbklkczogW10gfSxcbiAgICBkZWNpc2lvbjogeyBzdWJqZWN0OiAnJywgcmVhc29uOiBbXSwgdGFyZ2V0VmVyc2lvbklkOiBudWxsLCBvdXRjb21lOiAnZGVmZXJyZWQnLCBwcmlvcml0eTogJycsIHJlcXVpcmVtZW50SWRzOiBbXSwgcmV2aWV3SWRzOiBbXSB9LFxuICAgIGdhbWVwbGF5X3NwZWM6IHsgc2NlbmVJZDogbnVsbCwgYWN0aW9uOiBbXSwgbWVjaGFuaWM6ICcnLCB0dXRvcmlhbDogW10sIHJld2FyZDogbnVsbCwgcXVlc3RJZDogbnVsbCwgdGFza0lkczogW10sIGludGVudGlvbmFsRGlmZmVyZW5jZTogJycgfSxcbiAgICBwcm9kdWN0aW9uX3Rhc2s6IHsgdGFyZ2V0SWRzOiBbXSwgc3RhZ2U6ICd3cml0aW5nJywgcHJvZ3Jlc3M6ICd0b2RvJywgYXNzaWduZWVJZDogbnVsbCwgZGVhZGxpbmU6IG51bGwsIGRlcGVuZHNPbjogW10sIGVzdGltYXRlOiBudWxsLCBibG9ja2luZ1JlYXNvbjogJycgfSxcbiAgICBtZWRpYV92YXJpYW50OiB7IG1lZGl1bTogJ25vdmVsJywgYmFzZVNuYXBzaG90SWQ6IG51bGwsIGJvZHk6IFtdLCByZWxlYXNlQXQ6IG51bGwsIHByb2plY3Rpb25Qcm9maWxlSWQ6IG51bGwsIHNvdXJjZUlkczogW10sIG5lZWRzUmV2aWV3OiBmYWxzZSB9LFxuICAgIHZvaWNlX3J1bGU6IHsgY2hhcmFjdGVySWQ6IG51bGwsIHZhbGlkaXR5OiBlbXB0eVZhbGlkaXR5KCksIGZpcnN0UGVyc29uOiAnJywgYWRkcmVzc2luZzogJycsIHBocmFzaW5nOiAnJywgZXhhbXBsZXM6IFtdLCBleGNlcHRpb25zOiBbXSB9LFxuICAgIGV4dGVybmFsX2NvbnRyYWN0OiB7IGtleTogJycsIG93bmVyOiAndG9vbCcsIGlucHV0VHlwZTogJ2Jvb2xlYW4nLCBvdXRwdXRUeXBlOiAnYm9vbGVhbicsIG1pc3NpbmdQb2xpY3k6ICd1bmtub3duJywgZGVzY3JpcHRpb246IFtdLCBzdHViVmFsdWVzOiBbXSwgYWRhcHRlclByb2ZpbGVJZHM6IFtdLCB2ZXJzaW9uOiAnMS4wLjAnIH0sXG4gICAgc25hcHNob3Q6IHsgdmVyc2lvbkxhYmVsOiAnJywgY29udGVudEhhc2g6ICcnLCBpbW11dGFibGU6IHRydWUsIHBhcmVudFZlcnNpb25JZHM6IFtdLCByZWxlYXNlZEF0OiBudWxsLCByZWZlcmVuY2VkV29ybGRWZXJzaW9uSWRzOiBbXSB9LFxuICAgIHByb2plY3Rpb25fcHJvZmlsZTogeyBhdWRpZW5jZTogJycsIGluY2x1ZGVkSWRzOiBbXSwgbmFtZVBvbGljeTogeyBtb2RlOiAnZXhjbHVkZScgfSwgYWxsb3dlZEtpbmRzOiBbXSwgZXhjbHVkZWRGaWVsZHM6IFsnYXV0aG9yTm90ZXMnXSwgcm91dGVTY29wZTogbnVsbCwgaW5jbHVkZUF1dGhvck5vdGVzOiBmYWxzZSwgcHVibGljVGl0bGU6ICcnLCBwdWJsaWNUZXh0czoge30sIGFsbG93ZWRSZWxhdGlvbklkczogW10sIGlkUG9saWN5OiAncmVtYXAnIH0sXG4gIH07XG4gIGlmICghKGtpbmQgaW4gZGF0YSkpIHRocm93IG5ldyBSYW5nZUVycm9yKCfmnKrlr77lv5zjga7mg4XloLHnqK7liKXjgafjgZnjgIInKTtcbiAgcmV0dXJuIGRhdGFba2luZF0gYXMgRW50aXR5RGF0YU1hcFtLXTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVFbnRpdHk8SyBleHRlbmRzIEVudGl0eUtpbmQ+KHByb2plY3RJZDogSUQsIGtpbmQ6IEssIG5hbWUgPSAnJywgZGF0YT86IFBhcnRpYWw8RW50aXR5RGF0YU1hcFtLXT4pOiBFbnRpdHk8Sz4ge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIHJldHVybiB7IGlkOiBuZXdJZCgpLCBwcm9qZWN0SWQsIGtpbmQsIHJldmlzaW9uOiAnMCcsIG5hbWUsIHN0YXR1czogJ3Byb3Zpc2lvbmFsJywgdmlzaWJpbGl0eTogJ3ByaXZhdGUnLCBjcmVhdGVkQXQ6IG5vdywgdXBkYXRlZEF0OiBub3csIGN1c3RvbVZhbHVlczoge30sIGRhdGE6IHsgLi4uZGVmYXVsdERhdGEoa2luZCksIC4uLmRhdGEgfSB9IGFzIEVudGl0eTxLPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVQcm9qZWN0KG5hbWUgPSAn5paw44GX44GE5L2c5ZOBJyk6IFByb2plY3REYXRhIHtcbiAgcmV0dXJuIHsgcHJvamVjdElkOiBuZXdJZCgpLCBuYW1lLCBmb3JtYXRWZXJzaW9uOiBGT1JNQVRfVkVSU0lPTiwgcmV2aXNpb246ICcwJywgY2FsZW5kYXJJZDogR1JFR09SSUFOX0NBTEVOREFSLmlkLCBtYWluU3RhcnQ6ICcwJywgY2FsZW5kYXJzOiBbc3RydWN0dXJlZENsb25lKEdSRUdPUklBTl9DQUxFTkRBUildLCB3b3JsZFJlZmVyZW5jZXM6IFtdLCBlbnRpdGllczogW10sIHJlbGF0aW9uczogW10sIHNuYXBzaG90czogW10sIGhpc3Rvcnk6IFtdLCB2aWV3czogW10gfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlbXB0eVJ1bnRpbWVTdGF0ZShjb250ZW50VmVyc2lvbklkOiBJRCk6IFJ1bnRpbWVTdGF0ZSB7IHJldHVybiB7IGNvbnRlbnRWZXJzaW9uSWQsIHZhcmlhYmxlVmFsdWVzOiB7fSwgaXRlbUluc3RhbmNlczogW10sIGFzc2VydGlvbnM6IFtdLCBzZWVuSWRzOiBbXSwgdmlzaXRDb3VudHM6IHt9LCBvbmNlVHJpZ2dlcnM6IFtdLCBybmdTZWVkOiAnc2NlbmFyaW8tMScsIHJuZ1Bvc2l0aW9uOiAwLCBjYWxsU3RhY2s6IFtdLCBwcmVzZW50YXRpb25Qb3NpdGlvbjogbnVsbCwgbG9vcE51bWJlcjogMCwgcHJvdmVuYW5jZTogJ2Z1bGxfcGxheScgfTsgfVxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZURlbW9Qcm9qZWN0KCk6IFByb2plY3REYXRhIHtcbiAgY29uc3QgcHJvamVjdCA9IGNyZWF0ZVByb2plY3QoJ+mcp+OBrumWgCDigJQg44K144Oz44OX44Or5L2c5ZOBJyksIGlkID0gcHJvamVjdC5wcm9qZWN0SWQ7XG4gIGNvbnN0IGFvID0gY3JlYXRlRW50aXR5KGlkLCAnY2hhcmFjdGVyJywgJ+OCouOCqicsIHsgcmVhZGluZzogJ+OBguOBiicsIHN1bW1hcnk6IHRleHRUb1JpY2hUZXh0KCfmtojjgYjjgZ/niLbjgpLmjqLjgZnjgIHoqJjpjLLkv4Ljga7lsJHlpbPjgIInKSB9KTtcbiAgY29uc3QgZ3VhcmQgPSBjcmVhdGVFbnRpdHkoaWQsICdjaGFyYWN0ZXInLCAn6ZaA55WqJywgeyByZWFkaW5nOiAn44KC44KT44Gw44KTJywgc3VtbWFyeTogdGV4dFRvUmljaFRleHQoJ+mcp+OBrumWgOOCkuWuiOOCi+S6uueJqeOAguacrOWQjeOBr+OBvuOBoOaYjuOBi+OBleOCjOOBpuOBhOOBquOBhOOAgicpIH0pO1xuICBjb25zdCBnYXRlID0gY3JlYXRlRW50aXR5KGlkLCAncGxhY2UnLCAn6Zyn44Gu6ZaAJywgeyByZWFkaW5nOiAn44GN44KK44Gu44KC44KTJywgYm9keTogdGV4dFRvUmljaFRleHQoJ+eUuuOBruWMl+err+OAguWknOOBq+OBquOCi+OBqOaJieOBruaWh+Wtl+OBjOa1ruOBi+OBs+S4iuOBjOOCi+OAgicpIH0pO1xuICBjb25zdCBldmVudCA9IGNyZWF0ZUVudGl0eShpZCwgJ2V2ZW50JywgJ+eItuOBjOmNteOCkumaoOOBl+OBn+aXpScsIHsgc3VtbWFyeTogdGV4dFRvUmljaFRleHQoJ+eItuOBr+WPpOOBhOmNteOCkuiomOmMsuW6q+OBuOaui+OBl+OBn+OAgicpLCB0aW1lOiB7IG1vZGU6ICdpbnN0YW50JywgYXQ6ICctMTAnLCBjYWxlbmRhcklkOiBwcm9qZWN0LmNhbGVuZGFySWQgfSwgbGFuZVJvbGU6ICdjb21tb24nLCBsb2NhdGlvbklkOiBnYXRlLmlkIH0pO1xuICBjb25zdCBrZXkgPSBjcmVhdGVFbnRpdHkoaWQsICd2YXJpYWJsZScsICfpjbXjgpLmjIHjgaPjgabjgYTjgosnLCB7IGtleTogJ2hhc19rZXknLCB2YWx1ZVR5cGU6ICdib29sZWFuJywgaW5pdGlhbDogeyB0eXBlOiAnYm9vbGVhbicsIHZhbHVlOiBmYWxzZSB9IH0pO1xuICBjb25zdCBhZmZlY3Rpb24gPSBjcmVhdGVFbnRpdHkoaWQsICd2YXJpYWJsZScsICfploDnlarjgYvjgonjga7kv6HpoLwnLCB7IGtleTogJ2d1YXJkX3RydXN0JywgdmFsdWVUeXBlOiAnaW50ZWdlcicsIGluaXRpYWw6IHsgdHlwZTogJ2ludGVnZXInLCB2YWx1ZTogMCB9LCBhbGxvd2VkOiB7IG1pbjogLTEwLCBtYXg6IDEwIH0gfSk7XG4gIGNvbnN0IHNjZW5lMSA9IGNyZWF0ZUVudGl0eShpZCwgJ3NjZW5lJywgJ+WPpOOBhOiomOmMsicsIHsgc3VtbWFyeTogdGV4dFRvUmljaFRleHQoJ+OCouOCquOBr+iomOmMsuW6q+OBp+OAgeeItuOBruethui3oeOCkuimi+OBpOOBkeOCi+OAgicpLCBib2R5OiB0ZXh0VG9SaWNoVGV4dCgn44CM44G+44Gg44CB44GT44GT44Gr44GE44Gf44KT44Gg44Gt44CNXFxu5Z+D44Gr5Z+L44KC44KM44Gf5pys44Gu6ZaT44GL44KJ44CB5bCP44GV44Gq6Y2144GM6JC944Gh44Gf44CCJyksIGV2ZW50SWRzOiBbZXZlbnQuaWRdLCBwb3ZJZDogYW8uaWQsIHRlbnNpb246IDMgfSk7XG4gIGNvbnN0IHNjZW5lMiA9IGNyZWF0ZUVudGl0eShpZCwgJ3NjZW5lJywgJ+mcp+OBrumWgCcsIHsgc3VtbWFyeTogdGV4dFRvUmljaFRleHQoJ+mNteOCkuW+l+OBn+mBk+OBqOOAgeiomOmMsuOCkumjm+OBsOOBl+OBn+mBk+OBjOWQiOa1geOBmeOCi+OAgicpLCBib2R5OiB0ZXh0VG9SaWNoVGV4dCgn6ZaA55Wq44Gv5o6M44KS5beu44GX5Ye644GX44Gf44CCXFxu44CM5omJ44Gv44CB6KiY5oa244KS5oyB44Gk6ICF44Gr44GX44GL6ZaL44GL44Gq44GE44CNJyksIHBvdklkOiBhby5pZCwgdGVuc2lvbjogNyB9KTtcbiAgY29uc3QgY2hhcHRlciA9IGNyZWF0ZUVudGl0eShpZCwgJ2NoYXB0ZXInLCAn56ys5LiA56ug44CA5q6L44GV44KM44Gf6KiY5oa2JywgeyBzY2VuZUlkczogW3NjZW5lMS5pZCwgc2NlbmUyLmlkXSwgc3VtbWFyeTogdGV4dFRvUmljaFRleHQoJ+WPpOOBhOiomOmMsuOCkuiqreOCgOOBi+OBqeOBhuOBi+OBp+OAgemWgOOBruWFiOOBq+mAsuOCgeOCi+OBi+OBjOWkieOCj+OCi+OAgicpIH0pO1xuICBzY2VuZTEuZGF0YS5jaGFwdGVySWQgPSBjaGFwdGVyLmlkOyBzY2VuZTIuZGF0YS5jaGFwdGVySWQgPSBjaGFwdGVyLmlkO1xuICBjb25zdCBlbnRyeSA9IGNyZWF0ZUVudGl0eShpZCwgJ2Zsb3dfbm9kZScsICfoqJjpjLLjgpLoqq3jgoDjgYsnLCB7IG5vZGVUeXBlOiAnY2hvaWNlJywgZXhlY3V0aW9uUG9saWN5OiAnbWFudWFsX2Nob2ljZScgfSk7XG4gIGNvbnN0IHJlYWQgPSBjcmVhdGVFbnRpdHkoaWQsICdmbG93X25vZGUnLCAn5Y+k44GE6KiY6Yyy44KS5o+Q56S6JywgeyBub2RlVHlwZTogJ2F1dG9tYXRpYycsIHNjZW5lSWQ6IHNjZW5lMS5pZCwgZXhlY3V0aW9uUG9saWN5OiAnZmlyc3RfbWF0Y2gnIH0pO1xuICBjb25zdCBtZXJnZSA9IGNyZWF0ZUVudGl0eShpZCwgJ2Zsb3dfbm9kZScsICflkIzjgZjploDjgbjlkIjmtYEnLCB7IG5vZGVUeXBlOiAnY2hvaWNlJywgc2NlbmVJZDogc2NlbmUyLmlkLCBleGVjdXRpb25Qb2xpY3k6ICdtYW51YWxfY2hvaWNlJyB9KTtcbiAgY29uc3QgcmV2ZWFsID0gY3JlYXRlRW50aXR5KGlkLCAnZmxvd19ub2RlJywgJ+mWgOOBruWFiOOBuCcsIHsgbm9kZVR5cGU6ICd0ZXJtaW5hbCcsIHRlcm1pbmFsUmVhc29uOiAn6Y2144KS5L2/44GE44CB54i244Gu6Laz6Leh44KS44Gf44Gp44KL44CCJyB9KTtcbiAgY29uc3Qgc3RheSA9IGNyZWF0ZUVudGl0eShpZCwgJ2Zsb3dfbm9kZScsICfnlLrjgbjmiLvjgosnLCB7IG5vZGVUeXBlOiAndGVybWluYWwnLCB0ZXJtaW5hbFJlYXNvbjogJ+aJi+aOm+OBi+OCiuOCkuaOouOBl+ebtOOBmeOAgeaEj+Wbs+OBl+OBn+WIpeOBrue1kOacq+OAgicgfSk7XG4gIGNvbnN0IHNldEtleSA9IGNyZWF0ZUVudGl0eShpZCwgJ2VmZmVjdCcsICfpjbXjgpLlvpfjgosnLCB7IG9wZXJhdGlvbjogJ3NldCcsIHRhcmdldElkOiBrZXkuaWQsIHZhbHVlOiB7IHR5cGU6ICdib29sZWFuJywgdmFsdWU6IHRydWUgfSB9KTtcbiAgY29uc3QgZ2FpblRydXN0ID0gY3JlYXRlRW50aXR5KGlkLCAnZWZmZWN0JywgJ+S/oemgvOOBjOWil+OBiOOCiycsIHsgb3BlcmF0aW9uOiAnYWRkJywgdGFyZ2V0SWQ6IGFmZmVjdGlvbi5pZCwgdmFsdWU6IHsgdHlwZTogJ2ludGVnZXInLCB2YWx1ZTogMSB9IH0pO1xuICBjb25zdCBxdWVzdGlvbiA9IGNyZWF0ZUVudGl0eShpZCwgJ2ZvcmVzaGFkb3cnLCAn6ZaA44KS6ZaL44GP6Y2144Gv44Gp44GT44GLJywgeyBxdWVzdGlvbjogdGV4dFRvUmljaFRleHQoJ+mWgOOCkumWi+OBj+mNteOBr+OBqeOBk+OBi++8nycpLCBpbnRlbnQ6IHRleHRUb1JpY2hUZXh0KCfniLbjga7oqJjpjLLjgajploDjga7mhI/lkbPjgpLntZDjgbbjgIInKSwgcmVzb2x1dGlvblBvbGljeTogJ3RoaXNfd29yaycgfSk7XG4gIGNvbnN0IGNsdWUgPSBjcmVhdGVFbnRpdHkoaWQsICdkaXNjbG9zdXJlJywgJ+mNteOBruiomOmMsicsIHsgZm9yZXNoYWRvd0lkOiBxdWVzdGlvbi5pZCwgYW5jaG9yOiB7IGVudGl0eUlkOiByZWFkLmlkIH0sIHJvbGU6ICdjbHVlJywgc3RhZ2U6ICdoaW50JyB9KTtcbiAgY29uc3QgcGF5b2ZmID0gY3JlYXRlRW50aXR5KGlkLCAnZGlzY2xvc3VyZScsICfploDjga7nnJ/nm7gnLCB7IGZvcmVzaGFkb3dJZDogcXVlc3Rpb24uaWQsIGFuY2hvcjogeyBlbnRpdHlJZDogcmV2ZWFsLmlkIH0sIHJvbGU6ICdwYXlvZmYnLCBzdGFnZTogJ3JldmVhbCcgfSk7XG4gIHF1ZXN0aW9uLmRhdGEuY2x1ZUlkcyA9IFtjbHVlLmlkXTsgcXVlc3Rpb24uZGF0YS5wYXlvZmZJZHMgPSBbcGF5b2ZmLmlkXTsgcXVlc3Rpb24uZGF0YS5yZXF1aXJlZEluZm8gPSBbY2x1ZS5pZF07XG4gIGNvbnN0IHNlZUNsdWUgPSBjcmVhdGVFbnRpdHkoaWQsICdlZmZlY3QnLCAn5omL5o6b44GL44KK44KS5o+Q56S6JywgeyBvcGVyYXRpb246ICdtYXJrX3NlZW4nLCB0YXJnZXRJZDogY2x1ZS5pZCwgdmFsdWU6IG51bGwgfSk7XG4gIGNvbnN0IHNlZVBheW9mZiA9IGNyZWF0ZUVudGl0eShpZCwgJ2VmZmVjdCcsICfnnJ/nm7jjgpLmj5DnpLonLCB7IG9wZXJhdGlvbjogJ21hcmtfc2VlbicsIHRhcmdldElkOiBwYXlvZmYuaWQsIHZhbHVlOiBudWxsIH0pO1xuICBjb25zdCBlZGdlczogRW50aXR5PCdmbG93X2VkZ2UnPltdID0gW1xuICAgIGNyZWF0ZUVudGl0eShpZCwgJ2Zsb3dfZWRnZScsICfpjbXjgajoqJjpjLLjgpLoqr/jgbnjgosnLCB7IGZyb21JZDogZW50cnkuaWQsIHRvSWQ6IHJlYWQuaWQsIGxhYmVsOiAn6Y2144Go6KiY6Yyy44KS6Kq/44G544KLJywgZWZmZWN0SWRzOiBbc2V0S2V5LmlkLCBnYWluVHJ1c3QuaWQsIHNlZUNsdWUuaWRdIH0pLFxuICAgIGNyZWF0ZUVudGl0eShpZCwgJ2Zsb3dfZWRnZScsICfoqJjpjLLjgpLpo5vjgbDjgZknLCB7IGZyb21JZDogZW50cnkuaWQsIHRvSWQ6IG1lcmdlLmlkLCBsYWJlbDogJ+iomOmMsuOCkumjm+OBsOOBmScgfSksXG4gICAgY3JlYXRlRW50aXR5KGlkLCAnZmxvd19lZGdlJywgJ+mWgOOBuOWQkeOBi+OBhicsIHsgZnJvbUlkOiByZWFkLmlkLCB0b0lkOiBtZXJnZS5pZCwgZWRnZVR5cGU6ICdhdXRvbWF0aWMnLCBwcmlvcml0eTogMSB9KSxcbiAgICBjcmVhdGVFbnRpdHkoaWQsICdmbG93X2VkZ2UnLCAn6Y2144Gn6ZaA44KS6ZaL44GPJywgeyBmcm9tSWQ6IG1lcmdlLmlkLCB0b0lkOiByZXZlYWwuaWQsIGxhYmVsOiAn6Y2144Gn6ZaA44KS6ZaL44GPJywgY29uZGl0aW9uOiB7IG9wOiAnY29tcGFyZScsIHZhcmlhYmxlSWQ6IGtleS5pZCwgY29tcGFyYXRvcjogJ2VxJywgdmFsdWU6IHsgdHlwZTogJ2Jvb2xlYW4nLCB2YWx1ZTogdHJ1ZSB9IH0sIGVmZmVjdElkczogW3NlZVBheW9mZi5pZF0gfSksXG4gICAgY3JlYXRlRW50aXR5KGlkLCAnZmxvd19lZGdlJywgJ+eUuuOBuOaIu+OCiycsIHsgZnJvbUlkOiBtZXJnZS5pZCwgdG9JZDogc3RheS5pZCwgbGFiZWw6ICfnlLrjgbjmiLvjgosnIH0pLFxuICBdO1xuICBjb25zdCBncmFwaCA9IGNyZWF0ZUVudGl0eShpZCwgJ2Zsb3dfZ3JhcGgnLCAn6Zyn44Gu6ZaA44Gu5YiG5bKQJywgeyBub2RlSWRzOiBbZW50cnkuaWQsIHJlYWQuaWQsIG1lcmdlLmlkLCByZXZlYWwuaWQsIHN0YXkuaWRdLCBlZGdlSWRzOiBlZGdlcy5tYXAoZSA9PiBlLmlkKSwgZW50cnlJZHM6IFtlbnRyeS5pZF0sIGV4aXRJZHM6IFtyZXZlYWwuaWQsIHN0YXkuaWRdIH0pO1xuICBjb25zdCBsaW5lID0gY3JlYXRlRW50aXR5KGlkLCAnZGlhbG9ndWVfbGluZScsICcnLCB7IHNwZWFrZXJJZDogZ3VhcmQuaWQsIHRleHQ6IHRleHRUb1JpY2hUZXh0KCfmiYnjga/jgIHoqJjmhrbjgpLmjIHjgaTogIXjgavjgZfjgYvplovjgYvjgarjgYTjgIInKSB9KTtcbiAgY29uc3QgdGFzayA9IGNyZWF0ZUVudGl0eShpZCwgJ3Byb2R1Y3Rpb25fdGFzaycsICfploDjga7loLTpnaLjgpLopovnm7TjgZknLCB7IHRhcmdldElkczogW3NjZW5lMi5pZF0sIHN0YWdlOiAncmV2aWV3JywgcHJvZ3Jlc3M6ICd0b2RvJyB9KTtcbiAgcHJvamVjdC5lbnRpdGllcyA9IFthbywgZ3VhcmQsIGdhdGUsIGV2ZW50LCBrZXksIGFmZmVjdGlvbiwgc2NlbmUxLCBzY2VuZTIsIGNoYXB0ZXIsIGVudHJ5LCByZWFkLCBtZXJnZSwgcmV2ZWFsLCBzdGF5LCBzZXRLZXksIGdhaW5UcnVzdCwgcXVlc3Rpb24sIGNsdWUsIHBheW9mZiwgc2VlQ2x1ZSwgc2VlUGF5b2ZmLCAuLi5lZGdlcywgZ3JhcGgsIGxpbmUsIHRhc2tdO1xuICBwcm9qZWN0LmVudGl0aWVzLmZvckVhY2goZW50aXR5ID0+IHsgZW50aXR5LnN0YXR1cyA9ICdjb25maXJtZWQnOyB9KTtcbiAgcHJvamVjdC5yZWxhdGlvbnMgPSBbeyBpZDogbmV3SWQoKSwgcHJvamVjdElkOiBpZCwgcmV2aXNpb246ICcwJywgZnJvbUlkOiBhby5pZCwgdG9JZDogZ3VhcmQuaWQsIHJlbGF0aW9uVHlwZTogJ3RydXN0JywgZGlyZWN0aW9uOiAnZm9yd2FyZCcsIHZhbGlkaXR5OiBlbXB0eVZhbGlkaXR5KCksIGV2aWRlbmNlSWRzOiBbc2NlbmUyLmlkXSwgc3RhdHVzOiAncHJvdmlzaW9uYWwnLCB2aXNpYmlsaXR5OiAncHJpdmF0ZScgfV07XG4gIHJldHVybiBwcm9qZWN0O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIERvbWFpblJlZmVyZW5jZSB7IGlkOiBJRDsgcGF0aDogc3RyaW5nOyBraW5kcz86IEVudGl0eUtpbmRbXTsgc2NvcGU6ICdlbnRpdHknIHwgJ3JlbGF0aW9uJyB8ICdyZWNvcmQnIHwgJ3Byb2plY3Rpb25fcmVjb3JkJyB8ICdwcmVzZW50YXRpb24nIHwgJ2Jsb2NrJyB8ICdhbGlhcycgfCAnc25hcHNob3QnIHwgJ3Byb2plY3QnIHwgJ2NhbGVuZGFyJyB8ICdpZGVudGl0eScgfVxudHlwZSBGaWVsZCA9IHsgc2NoZW1hOiBTY2hlbWE7IHJlcXVpcmVkPzogYm9vbGVhbjsgbnVsbGFibGU/OiBib29sZWFuIH07XG5leHBvcnQgdHlwZSBTY2hlbWEgPVxuICB8IHsgdHlwZTogJ3RleHQnOyBtaW4/OiBudW1iZXI7IG1heD86IG51bWJlcjsgbWF4Qnl0ZXM/OiBudW1iZXIgfVxuICB8IHsgdHlwZTogJ251bWJlcic7IGludGVnZXI/OiBib29sZWFuOyBtaW4/OiBudW1iZXI7IG1heD86IG51bWJlciB9XG4gIHwgeyB0eXBlOiAnYm9vbGVhbicgfCAnaWQnIHwgJ3RpY2snIHwgJ3JldmlzaW9uJyB8ICdkYXRldGltZScgfCAnZGF0ZScgfCAnaGFzaCcgfCAnc2FmZV9wYXRoJyB8ICdjdXN0b20nIHwgJ3R5cGVkJyB8ICd0aW1lJyB8ICdjb25kaXRpb24nIHwgJ2V4cHJlc3Npb24nIHwgJ25hbWVfcG9saWN5JyB8ICdqc29uJyB9XG4gIHwgeyB0eXBlOiAnZW51bSc7IHZhbHVlczogcmVhZG9ubHkgKHN0cmluZyB8IGJvb2xlYW4gfCBudWxsKVtdIH1cbiAgfCB7IHR5cGU6ICdyZWYnOyBraW5kcz86IEVudGl0eUtpbmRbXTsgc2NvcGU/OiBEb21haW5SZWZlcmVuY2VbJ3Njb3BlJ10gfVxuICB8IHsgdHlwZTogJ3JpY2h0ZXh0JzsgbWF4PzogbnVtYmVyIH1cbiAgfCB7IHR5cGU6ICdhcnJheSc7IGl0ZW06IFNjaGVtYTsgbWluPzogbnVtYmVyOyBtYXg/OiBudW1iZXI7IHVuaXF1ZT86IGJvb2xlYW4gfVxuICB8IHsgdHlwZTogJ29iamVjdCc7IGZpZWxkczogUmVjb3JkPHN0cmluZywgRmllbGQ+IH1cbiAgfCB7IHR5cGU6ICdyZWNvcmQnOyB2YWx1ZTogU2NoZW1hOyBrZXk/OiBTY2hlbWEgfVxuICB8IHsgdHlwZTogJ3VuaW9uJzsgY2hvaWNlczogU2NoZW1hW10gfVxuICB8IHsgdHlwZTogJ3F1ZXJ5JyB9O1xuY29uc3QgdHh0ID0gKG1pbiA9IDAsIG1heD86IG51bWJlcik6IFNjaGVtYSA9PiAoeyB0eXBlOiAndGV4dCcsIG1pbiwgbWF4LCBtYXhCeXRlczogMTAyNCAqIDEwMjQgfSk7XG5jb25zdCBzaG9ydDogU2NoZW1hID0gdHh0KDAsIDEyOCksIGtleTogU2NoZW1hID0gdHh0KDEsIDEyOCk7XG5jb25zdCBudW0gPSAobWluPzogbnVtYmVyLCBtYXg/OiBudW1iZXIsIGludGVnZXIgPSBmYWxzZSk6IFNjaGVtYSA9PiAoeyB0eXBlOiAnbnVtYmVyJywgbWluLCBtYXgsIGludGVnZXIgfSk7XG5jb25zdCBib29sOiBTY2hlbWEgPSB7IHR5cGU6ICdib29sZWFuJyB9LCBpZFNjaGVtYTogU2NoZW1hID0geyB0eXBlOiAnaWQnIH0sIHRpY2s6IFNjaGVtYSA9IHsgdHlwZTogJ3RpY2snIH0sIHR5cGVkOiBTY2hlbWEgPSB7IHR5cGU6ICd0eXBlZCcgfTtcbmNvbnN0IGVuID0gKC4uLnZhbHVlczogKHN0cmluZyB8IGJvb2xlYW4gfCBudWxsKVtdKTogU2NoZW1hID0+ICh7IHR5cGU6ICdlbnVtJywgdmFsdWVzIH0pO1xuY29uc3QgcmVmID0gKC4uLmtpbmRzOiBFbnRpdHlLaW5kW10pOiBTY2hlbWEgPT4gKHsgdHlwZTogJ3JlZicsIGtpbmRzOiBraW5kcy5sZW5ndGggPyBraW5kcyA6IHVuZGVmaW5lZCwgc2NvcGU6ICdlbnRpdHknIH0pO1xuY29uc3Qgc2NvcGVkUmVmID0gKHNjb3BlOiBEb21haW5SZWZlcmVuY2VbJ3Njb3BlJ10pOiBTY2hlbWEgPT4gKHsgdHlwZTogJ3JlZicsIHNjb3BlIH0pO1xuY29uc3QgYXJyID0gKGl0ZW06IFNjaGVtYSwgdW5pcXVlID0gZmFsc2UsIG1pbj86IG51bWJlciwgbWF4PzogbnVtYmVyKTogU2NoZW1hID0+ICh7IHR5cGU6ICdhcnJheScsIGl0ZW0sIHVuaXF1ZSwgbWluLCBtYXggfSk7XG5jb25zdCByZWZzID0gKC4uLmtpbmRzOiBFbnRpdHlLaW5kW10pOiBTY2hlbWEgPT4gYXJyKHJlZiguLi5raW5kcyksIHRydWUpO1xuY29uc3Qgb2JqID0gKGZpZWxkczogUmVjb3JkPHN0cmluZywgRmllbGQ+KTogU2NoZW1hID0+ICh7IHR5cGU6ICdvYmplY3QnLCBmaWVsZHMgfSk7XG5jb25zdCByZXEgPSAoc2NoZW1hOiBTY2hlbWEpOiBGaWVsZCA9PiAoeyBzY2hlbWEsIHJlcXVpcmVkOiB0cnVlIH0pO1xuY29uc3Qgb3B0ID0gKHNjaGVtYTogU2NoZW1hKTogRmllbGQgPT4gKHsgc2NoZW1hLCBudWxsYWJsZTogdHJ1ZSB9KTtcbmNvbnN0IG9wdGlvbmFsVmFsdWUgPSAoc2NoZW1hOiBTY2hlbWEpOiBGaWVsZCA9PiAoeyBzY2hlbWEsIG51bGxhYmxlOiBmYWxzZSB9KTtcbmNvbnN0IHJpY2g6IFNjaGVtYSA9IHsgdHlwZTogJ3JpY2h0ZXh0JyB9LCBzdW1tYXJ5OiBTY2hlbWEgPSB7IHR5cGU6ICdyaWNodGV4dCcsIG1heDogMjA0OCB9O1xuY29uc3QgY29uZDogU2NoZW1hID0geyB0eXBlOiAnY29uZGl0aW9uJyB9LCB0aW1lOiBTY2hlbWEgPSB7IHR5cGU6ICd0aW1lJyB9O1xuY29uc3QgcmVjb3JkID0gKHZhbHVlOiBTY2hlbWEsIHJlY29yZEtleT86IFNjaGVtYSk6IFNjaGVtYSA9PiAoeyB0eXBlOiAncmVjb3JkJywgdmFsdWUsIGtleTogcmVjb3JkS2V5IH0pO1xuY29uc3QgdW5pb24gPSAoLi4uY2hvaWNlczogU2NoZW1hW10pOiBTY2hlbWEgPT4gKHsgdHlwZTogJ3VuaW9uJywgY2hvaWNlcyB9KTtcbmNvbnN0IGFuY2hvciA9IG9iaih7IGVudGl0eUlkOiByZXEocmVmKCkpLCBibG9ja0lkOiBvcHQoc2NvcGVkUmVmKCdibG9jaycpKSwgbGluZUlkOiBvcHQocmVmKCdkaWFsb2d1ZV9saW5lJykpLCBzdGFydDogb3B0KG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgZW5kOiBvcHQobnVtKDAsIHVuZGVmaW5lZCwgdHJ1ZSkpLCBzb3VyY2VWZXJzaW9uSWQ6IG9wdChzY29wZWRSZWYoJ3NuYXBzaG90JykpLCBwb3NpdGlvblN0YXR1czogb3B0KGVuKCd1bnJlc29sdmVkJykpLCBwb3NpdGlvblJlYXNvbjogb3B0KHR4dCgxKSksIHF1b3RlZFRleHQ6IG9wdCh0eHQoKSkgfSk7XG5jb25zdCB1bnJlc29sdmVkVGV4dEFubm90YXRpb24gPSB1bmlvbihvYmooeyBraW5kOiByZXEoZW4oJ3J1YnknKSksIG9yaWdpbmFsVGV4dDogcmVxKHR4dCgpKSwgcmVhc29uOiByZXEodHh0KDEpKSwgcmVhZGluZzogcmVxKHR4dCgpKSB9KSwgb2JqKHsga2luZDogcmVxKGVuKCdsaW5rJykpLCBvcmlnaW5hbFRleHQ6IHJlcSh0eHQoKSksIHJlYXNvbjogcmVxKHR4dCgxKSksIHRhcmdldDogcmVxKGFuY2hvcikgfSkpO1xuY29uc3QgbnVsbGFibGVWYWxpZGl0eSA9IG9iaih7IHdvcmxkUmFuZ2U6IHsgc2NoZW1hOiBvYmooeyBzdGFydDogeyBzY2hlbWE6IHRpY2ssIHJlcXVpcmVkOiB0cnVlLCBudWxsYWJsZTogdHJ1ZSB9LCBlbmQ6IHsgc2NoZW1hOiB0aWNrLCByZXF1aXJlZDogdHJ1ZSwgbnVsbGFibGU6IHRydWUgfSB9KSwgcmVxdWlyZWQ6IHRydWUsIG51bGxhYmxlOiB0cnVlIH0sIHJvdXRlQ29uZGl0aW9uOiB7IHNjaGVtYTogY29uZCwgcmVxdWlyZWQ6IHRydWUsIG51bGxhYmxlOiB0cnVlIH0sIHByZXNlbnRhdGlvbkFuY2hvcjogeyBzY2hlbWE6IGFuY2hvciwgcmVxdWlyZWQ6IHRydWUsIG51bGxhYmxlOiB0cnVlIH0gfSk7XG5jb25zdCB0YXJnZXRTY29wZSA9IG9iaih7IHByb2plY3RJZDogcmVxKHNjb3BlZFJlZigncHJvamVjdCcpKSwgZ3JhcGhJZDogb3B0KHJlZignZmxvd19ncmFwaCcpKSwgY2hhcHRlcklkOiBvcHQocmVmKCdjaGFwdGVyJykpLCByb3V0ZUNvbmRpdGlvbjogb3B0KGNvbmQpLCB0YXJnZXRTbmFwc2hvdElkOiBvcHQoc2NvcGVkUmVmKCdzbmFwc2hvdCcpKSB9KTtcbmNvbnN0IGFsaWFzID0gb2JqKHsgaWQ6IHJlcShpZFNjaGVtYSksIHRleHQ6IHJlcSh0eHQoMSwgMTI4KSksIHJlYWRpbmc6IHJlcShzaG9ydCksIHZhbGlkaXR5OiByZXEobnVsbGFibGVWYWxpZGl0eSksIGF1ZGllbmNlSG9sZGVySWRzOiByZXEocmVmcygnY2hhcmFjdGVyJykpLCBpc1B1YmxpY0RlZmF1bHQ6IHJlcShib29sKSB9KTtcbmNvbnN0IGV4Y2VwdGlvbiA9IG9iaih7IHJlYXNvbjogcmVxKHR4dCgxKSksIHRhcmdldFNjb3BlOiByZXEodGFyZ2V0U2NvcGUpLCB2YWxpZGl0eTogcmVxKG51bGxhYmxlVmFsaWRpdHkpLCBldmlkZW5jZUlkczogcmVxKHJlZnMoKSkgfSk7XG5jb25zdCB0cmFuc2l0aW9uID0gb2JqKHsgZnJvbTogcmVxKHR5cGVkKSwgdG86IHJlcSh0eXBlZCksIHJlYXNvbjogb3B0KHR4dCgpKSwgZXhjZXB0aW9uOiBvcHQoYm9vbCksIGV4Y2VwdGlvbkRldGFpbHM6IG9wdChleGNlcHRpb24pIH0pO1xuY29uc3QgcmVzZXRSdWxlID0gb2JqKHsgb246IHJlcShlbignc2NlbmVfZW5kJywgJ2NoYXB0ZXJfZW5kJywgJ3J1bl9lbmQnLCAnbmV3X2xvb3AnLCAnZnVsbF9yZXNldCcpKSwgdmFsdWU6IHJlcSh0eXBlZCksIHJlYXNvbjogb3B0KHR4dCgpKSB9KTtcbmNvbnN0IGFsbG93ZWQgPSBvYmooeyBtaW46IG9wdChudW0odW5kZWZpbmVkLCB1bmRlZmluZWQsIHRydWUpKSwgbWF4OiBvcHQobnVtKHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB0cnVlKSksIHZhbHVlczogb3B0KGFycih1bmlvbih0eHQoKSwgYm9vbCksIHRydWUpKSB9KTtcbmNvbnN0IHRyaWdnZXIgPSBvYmooeyBpZDogb3B0KGlkU2NoZW1hKSwgZXZlbnQ6IHJlcShlbignZW50ZXInLCAndGFsaycsICdiYXR0bGVfcmVzdWx0JywgJ21hbnVhbCcsICdjdXN0b20nKSksIGV2ZW50S2V5OiByZXEodHh0KCkpLCByZXBlYXQ6IHJlcShlbignb25jZScsICdyZXBlYXRhYmxlJykpLCBzY29wZTogb3B0KGVuKC4uLlNDT1BFUykpLCBkZWFkbGluZTogb3B0KHRpbWUpIH0pO1xuY29uc3QgcmV1c2UgPSBvYmooeyBtb2RlOiByZXEoZW4oJ3JlZmVyZW5jZScsICdjbG9uZScsICdvdmVycmlkZScpKSwgc291cmNlSWQ6IHJlcShyZWYoKSksIHBpbm5lZFNuYXBzaG90SWQ6IHJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLCBvdmVycmlkZUZpZWxkczogcmVxKGFycih0eHQoMSksIHRydWUpKSwgYmluZGluZ3M6IG9wdChyZWNvcmQoaWRTY2hlbWEsIGlkU2NoZW1hKSkgfSk7XG5jb25zdCB1bnJlc29sdmVkID0gb2JqKHsgdW5yZXNvbHZlZDogcmVxKG9iaih7IGxhYmVsOiByZXEodHh0KCkpLCByZWFzb246IHJlcSh0eHQoMSkpIH0pKSB9KTtcbmNvbnN0IHJ1bnRpbWVJdGVtID0gb2JqKHsgaW5zdGFuY2VJZDogcmVxKGlkU2NoZW1hKSwgdHlwZUlkOiByZXEocmVmKCdpdGVtJykpLCBxdWFudGl0eTogcmVxKG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgb3duZXJJZDogb3B0KHJlZignY2hhcmFjdGVyJywgJ2dyb3VwJykpLCBsb2NhdGlvbklkOiBvcHQocmVmKCdwbGFjZScpKSwgY29uc3VtZWQ6IHJlcShib29sKSwgcmVhc29uOiBvcHQodHh0KCkpIH0pO1xuY29uc3QgcnVudGltZUFzc2VydGlvbiA9IG9iaih7IGFzc2VydGlvbklkOiByZXEocmVmKCdhc3NlcnRpb24nKSksIGhvbGRlcklkOiBvcHQocmVmKCdjaGFyYWN0ZXInKSksIHRydXRoOiByZXEoZW4oJ3RydWUnLCAnZmFsc2UnLCAndW5rbm93bicpKSwgc291cmNlRWZmZWN0SWQ6IG9wdChyZWYoJ2VmZmVjdCcpKSB9KTtcbmNvbnN0IHByZXNlbnRhdGlvblJlc3VsdCA9IG9iaih7IHRhcmdldElkOiByZXEocmVmKCdmbG93X25vZGUnLCAnZmxvd19lZGdlJywgJ2Rpc2Nsb3N1cmUnKSksIHZhbHVlOiByZXEoZW4oJ3RydWUnLCAnZmFsc2UnLCAndW5rbm93bicpKSwgcmVhc29uczogcmVxKGFycih0eHQoKSkpIH0pO1xuY29uc3QgY2FsbEZyYW1lID0gb2JqKHsgZ3JhcGhJZDogcmVxKHJlZignZmxvd19ncmFwaCcpKSwgcmV0dXJuTm9kZUlkOiByZXEocmVmKCdmbG93X25vZGUnKSksIHBhcmFtZXRlcnM6IHJlcShyZWNvcmQodHlwZWQsIGtleSkpIH0pO1xuY29uc3QgcnVudGltZSA9IG9iaih7IGNvbnRlbnRWZXJzaW9uSWQ6IHJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLCB2YXJpYWJsZVZhbHVlczogcmVxKHJlY29yZCh0eXBlZCwgcmVmKCd2YXJpYWJsZScpKSksIGl0ZW1JbnN0YW5jZXM6IHJlcShhcnIocnVudGltZUl0ZW0pKSwgYXNzZXJ0aW9uczogcmVxKGFycihydW50aW1lQXNzZXJ0aW9uKSksIHNlZW5JZHM6IHJlcShhcnIoc2NvcGVkUmVmKCdwcmVzZW50YXRpb24nKSwgdHJ1ZSkpLCB2aXNpdENvdW50czogcmVxKHJlY29yZChudW0oMCwgdW5kZWZpbmVkLCB0cnVlKSwgcmVmKCkpKSwgb25jZVRyaWdnZXJzOiByZXEoYXJyKHR4dCgxKSwgdHJ1ZSkpLCBybmdTZWVkOiByZXEodHh0KDEpKSwgcm5nUG9zaXRpb246IHJlcShudW0oMCwgdW5kZWZpbmVkLCB0cnVlKSksIGNhbGxTdGFjazogcmVxKGFycihjYWxsRnJhbWUpKSwgcHJlc2VudGF0aW9uUG9zaXRpb246IG9wdChyZWYoJ2Zsb3dfbm9kZScpKSwgbG9vcE51bWJlcjogcmVxKG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgcHJvdmVuYW5jZTogcmVxKGVuKCdmdWxsX3BsYXknLCAncGFydGlhbCcsICdpbXBvcnRlZCcsICdzdHViJykpLCByZXNldENhdXNlczogb3B0KGFycihvYmooeyB2YXJpYWJsZUlkOiByZXEocmVmKCd2YXJpYWJsZScpKSwgb246IHJlcShlbignc2NlbmVfZW5kJywgJ2NoYXB0ZXJfZW5kJywgJ3J1bl9lbmQnLCAnbmV3X2xvb3AnLCAnZnVsbF9yZXNldCcpKSwgYmVmb3JlOiByZXEodHlwZWQpLCBhZnRlcjogcmVxKHR5cGVkKSwgcmVhc29uOiByZXEodHh0KCkpIH0pKSkgfSk7XG5jb25zdCByZWFkaW5nT2NjdXJyZW5jZSA9IG9iaih7IGVudGl0eUlkOiByZXEocmVmKCdzY2VuZScpKSwgb2NjdXJyZW5jZUlkOiByZXEodHh0KDEsIDI1NikpLCBiZWZvcmU6IHJlcShydW50aW1lKSwgYWZ0ZXI6IHJlcShydW50aW1lKSwgcHJlc2VudGF0aW9uU3RhdGU6IG9wdChydW50aW1lKSwgY29uZGl0aW9uUmVzdWx0czogcmVxKGFycihwcmVzZW50YXRpb25SZXN1bHQpKSwgZXh0ZXJuYWxWYWx1ZXM6IG9wdChyZWNvcmQodHlwZWQsIHJlZignZXh0ZXJuYWxfY29udHJhY3QnKSkpLCB3b3JsZFRpY2s6IG9wdCh0aWNrKSB9KTtcbmNvbnN0IHJlYWRpbmdQYXRoID0gb2JqKHsgY2hhcHRlcklkczogcmVxKHJlZnMoJ2NoYXB0ZXInKSksIHNjZW5lSWRzOiByZXEoYXJyKHJlZignc2NlbmUnKSkpLCBzZWxlY3Rpb246IG9wdChlbignY2hhcHRlcnMnLCAnc2NlbmVzJykpLCBvY2N1cnJlbmNlczogcmVxKGFycihyZWFkaW5nT2NjdXJyZW5jZSkpIH0pO1xuY29uc3QgZ3JvdXBDb3ZlcmFnZSA9IG9iaih7IGNoZWNrZWQ6IHJlcShudW0oMCwgdW5kZWZpbmVkLCB0cnVlKSksIHRvdGFsOiByZXEobnVtKDAsIHVuZGVmaW5lZCwgdHJ1ZSkpIH0pO1xuY29uc3QgY292ZXJhZ2VDb3VudCA9IG9iaih7IGJ5UHJvdmVuYW5jZTogb3B0KHJlY29yZChncm91cENvdmVyYWdlLCBlbignZnVsbF9wbGF5JywgJ3BhcnRpYWwnLCAnaW1wb3J0ZWQnLCAnc3R1YicpKSksIGJ5RXh0ZXJuYWxNb2RlOiBvcHQocmVjb3JkKGdyb3VwQ292ZXJhZ2UsIGVuKCdpbnRlcm5hbCcsICdzdHViJywgJ2FjdHVhbCcsICdtaXhlZCcpKSksIGNoZWNrZWQ6IHJlcShudW0oMCwgdW5kZWZpbmVkLCB0cnVlKSksIHRvdGFsOiByZXEobnVtKDAsIHVuZGVmaW5lZCwgdHJ1ZSkpLCBleGNsdWRlZDogb3B0KG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgdW5rbm93bjogb3B0KG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSB9KTtcbmNvbnN0IGNvdmVyYWdlID0gb2JqKE9iamVjdC5mcm9tRW50cmllcyhbJ3NjZW5lcycsICdkaWFsb2d1ZScsICdjaG9pY2VzJywgJ2NvbmRpdGlvblRydWUnLCAnY29uZGl0aW9uRmFsc2UnLCAnZGVjbGFyZWRUZXN0cyddLm1hcChmaWVsZCA9PiBbZmllbGQsIHJlcShjb3ZlcmFnZUNvdW50KV0pKSk7XG5jb25zdCBmaWVsZERlZmluaXRpb24gPSBvYmooeyBrZXk6IHJlcShrZXkpLCBsYWJlbDogcmVxKHR4dCgxLCAxMjgpKSwgdHlwZTogcmVxKGVuKCd0ZXh0JywgJ251bWJlcicsICdib29sZWFuJywgJ2VudW0nLCAnZGF0ZScsICdyZWYnKSksIHJlcXVpcmVkOiByZXEoYm9vbCksIG51bGxhYmxlOiByZXEoYm9vbCksIGRlZmF1bHQ6IHsgc2NoZW1hOiB7IHR5cGU6ICdjdXN0b20nIH0sIHJlcXVpcmVkOiB0cnVlLCBudWxsYWJsZTogdHJ1ZSB9LCBhbGxvd2VkVmFsdWVzOiBvcHQoYXJyKHR4dCgpLCB0cnVlKSksIHRhcmdldEtpbmRzOiBvcHQoYXJyKGVuKC4uLkVOVElUWV9LSU5EUyksIHRydWUpKSwgaGVscDogb3B0KHR4dCgpKSB9KTtcbmNvbnN0IGVzdGltYXRlID0gb2JqKHsgdmFsdWU6IG9wdChudW0oMCkpLCByYW5nZTogb3B0KG9iaih7IG1pbjogcmVxKG51bSgwKSksIG1heDogcmVxKG51bSgwKSkgfSkpLCB1bml0OiByZXEodHh0KDEpKSwgYXNzdW1wdGlvbnM6IHJlcShhcnIodHh0KCkpKSwgc2NvcGU6IHJlcSh0YXJnZXRTY29wZSksIHVua25vd25Db3VudDogcmVxKG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgc291cmNlOiByZXEodHh0KCkpLCBzcGVlZDogb3B0KG51bShOdW1iZXIuTUlOX1ZBTFVFKSkgfSk7XG5jb25zdCBwdWJsaWNUZXh0ID0gb2JqKHtcbiAgLi4uT2JqZWN0LmZyb21FbnRyaWVzKFsnc3VtbWFyeScsICdib2R5JywgJ3RleHQnLCAnZGVzY3JpcHRpb24nLCAncXVlc3Rpb24nLCAnaW50ZW50JywgJ2NhcHRpb24nLCAndXNhZ2VOb3RlcycsICdpbnRlcnByZXRhdGlvbicsJ2V4YW1wbGVzJywnYWN0aW9uJywndHV0b3JpYWwnXS5tYXAoZmllbGQgPT4gW2ZpZWxkLCBvcHQocmljaCldKSksXG4gIC4uLk9iamVjdC5mcm9tRW50cmllcyhbJ2xhYmVsJywgJ3JlYWRpbmcnLCAndGVybWluYWxSZWFzb24nLCAncmVhc29uJywgJ2tleScsICdjYW5vbmljYWwnLCAnbGFuZ3VhZ2UnLCAnbG9jYWxlJywgJ3NvdXJjZUhhc2gnLCAnZXhwcmVzc2lvbicsICdtZXRob2QnLCAnbG9jYXRvcicsICdwcmVkaWNhdGUnLCAnY3VlVHlwZScsICdwcmVjaXNpb24nLCAnZGlzcGxheU5hbWUnLCAncmVsYXRpb25UeXBlJywgJ2V2ZW50S2V5JywgJ3Jlc2V0UmVhc29uJywgJ2V4Y2x1c2lvblJlYXNvbicsICdleGNlcHRpb25SZWFzb24nLCAnY2FtZXJhJywncGFyYW1ldGVycycsJ3ZhcmlhbnRzJywnZXN0aW1hdGVBc3N1bXB0aW9ucycsJ2VzdGltYXRlU291cmNlJywnYmxvY2tpbmdSZWFzb24nLCdtZWNoYW5pYycsJ2ludGVudGlvbmFsRGlmZmVyZW5jZScsJ2V4Y2VycHRMb2NhdGlvbicsJ2VzdGltYXRlVW5pdCcsJ2ZpcnN0UGVyc29uJywnYWRkcmVzc2luZycsJ3BocmFzaW5nJ10ubWFwKGZpZWxkID0+IFtmaWVsZCwgb3B0KHR4dCgpKV0pKSxcbn0pO1xuXG4vKiogRmllbGQgcmVnaXN0cnkgZG91YmxlcyBhcyB0aGUgcmVmZXJlbmNlIHdhbGtlcjsgdGV4dCBpcyBuZXZlciBzZWFyY2hlZCBmb3IgVVVJRHMuICovXG5leHBvcnQgY29uc3QgRU5USVRZX1NDSEVNQVM6IFJlY29yZDxFbnRpdHlLaW5kLCBTY2hlbWE+ID0ge1xuICBjaGFyYWN0ZXI6IG9iaih7IHJlYWRpbmc6IG9wdChzaG9ydCksIGFsaWFzZXM6IG9wdChhcnIoYWxpYXMpKSwgc3VtbWFyeTogb3B0KHN1bW1hcnkpLCBib2R5OiBvcHQocmljaCksIGF1dGhvck5vdGVzOiBvcHQocmljaCksIGJpcnRoOiBvcHQodGltZSksIGRlYXRoOiBvcHQodGltZSksIGdvYWxzOiBvcHQocmVmcygnZ29hbCcpKSwgdm9pY2VSdWxlczogb3B0KHJlZnMoJ3ZvaWNlX3J1bGUnKSkgfSksXG4gIGdyb3VwOiBvYmooeyBncm91cFR5cGU6IHJlcShlbignZGlzcGxheScsICdmYWN0aW9uJywgJ3Bsb3RfdGhyZWFkJywgJ2NhdGVnb3J5JykpLCBtZW1iZXJzOiBvcHQocmVmcygpKSwgcGFyZW50SWQ6IG9wdChyZWYoJ2dyb3VwJykpLCBzdW1tYXJ5OiBvcHQoc3VtbWFyeSkgfSksXG4gIGV2ZW50OiBvYmooeyBzdW1tYXJ5OiByZXEoc3VtbWFyeSksIHRpbWU6IHJlcSh0aW1lKSwgbGFuZVJvbGU6IHJlcShlbignY29tbW9uJywgJ3BhcnRpY2lwYW50cycsICdib3RoJykpLCBwYXJ0aWNpcGFudHM6IG9wdChhcnIob2JqKHsgY2hhcmFjdGVySWQ6IHJlcShyZWYoJ2NoYXJhY3RlcicpKSwgcm9sZTogcmVxKGVuKCdhY3RvcicsICd3aXRuZXNzJywgJ21lbnRpb25lZCcsICdpbmZvcm1lZCcsICdjdXN0b20nKSksIGV2aWRlbmNlSWRzOiBvcHQocmVmcygpKSwga25vd2xlZGdlRWZmZWN0SWRzOiBvcHQocmVmcygnZWZmZWN0JykpIH0pKSksIGxvY2F0aW9uSWQ6IG9wdChyZWYoJ3BsYWNlJykpLCBpdGVtSWRzOiBvcHQocmVmcygnaXRlbScpKSwgYXV0aG9yTm90ZXM6IG9wdChyaWNoKSwgY29uc3RyYWludHM6IG9wdChhcnIodW5pb24ob2JqKHsgdHlwZTogcmVxKGVuKCdiZWZvcmUnLCAnc2FtZV9zdGFydCcpKSwgdGFyZ2V0RXZlbnRJZDogcmVxKHJlZignZXZlbnQnKSkgfSksIG9iaih7IHR5cGU6IHJlcShlbignZW5kX2dhcCcpKSwgdGFyZ2V0RXZlbnRJZDogcmVxKHJlZignZXZlbnQnKSksIG1pbmltdW1UaWNrczogcmVxKHRpY2spLCBtYXhpbXVtVGlja3M6IHJlcSh0aWNrKSB9KSkpKSB9KSxcbiAgcGxhY2U6IG9iaih7IHBhcmVudElkOiBvcHQocmVmKCdwbGFjZScpKSwgcmVhZGluZzogb3B0KHNob3J0KSwgYWxpYXNlczogb3B0KGFycihhbGlhcykpLCBib2R5OiBvcHQocmljaCksIG1hcElkczogb3B0KHJlZnMoJ21hcCcpKSwgY2hhbmdlczogb3B0KHJlZnMoJ2Fzc2VydGlvbicpKSB9KSxcbiAgaXRlbTogb2JqKHsgaXRlbU1vZGU6IHJlcShlbigndHlwZScsICdpbnN0YW5jZScpKSwgdHlwZUlkOiBvcHQocmVmKCdpdGVtJykpLCBib2R5OiBvcHQocmljaCksIHByb3BlcnRpZXM6IG9wdCh7IHR5cGU6ICdjdXN0b20nIH0pLCBjaGFuZ2VzOiBvcHQocmVmcygnYXNzZXJ0aW9uJykpIH0pLFxuICBub3RlOiBvYmooeyBoYW5kb2ZmUmVjZWlwdDogb3B0KG9iaih7YXBwcm92YWw6cmVxKG9iaih7ZW50aXR5SWQ6cmVxKHNjb3BlZFJlZignZW50aXR5JykpLHNvdXJjZVZlcnNpb25JZDpyZXEoc2NvcGVkUmVmKCdzbmFwc2hvdCcpKX0pKSxzb3VyY2VWZXJzaW9uSWQ6cmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksdmVyaWZpY2F0aW9uVmVyc2lvbklkOnJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLHByb2ZpbGVWZXJzaW9uSWQ6cmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksc291cmNlUmV2aXNpb246cmVxKHt0eXBlOidyZXZpc2lvbid9KSxwcm9maWxlSWQ6cmVxKHJlZigncHJvamVjdGlvbl9wcm9maWxlJykpLHBhY2thZ2VIYXNoOnJlcSh7dHlwZTonaGFzaCd9KSxyZWNlaXB0SGFzaDpyZXEoe3R5cGU6J2hhc2gnfSksbW9kZTpyZXEoZW4oJ3N0dWInLCdhY3R1YWwnLCdtaXhlZCcpKSxyYXdKc29uOnJlcSh0eHQoMSwxMDI0KjEwMjQpKSxpZE1hcHBpbmdzOnJlcShhcnIob2JqKHtlbnRpdHlJZDpyZXEoc2NvcGVkUmVmKCdyZWNvcmQnKSksc291cmNlVmVyc2lvbklkOnJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLHB1YmxpY0lkOnJlcSh0eHQoMSwyNTYpKX0pKSkscHJvamVjdGlvbkJpbmRpbmdzOnJlcShhcnIob2JqKHtlbnRpdHlJZDpyZXEoc2NvcGVkUmVmKCdwcm9qZWN0aW9uX3JlY29yZCcpKSxzb3VyY2VWZXJzaW9uSWQ6cmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksZWRpdGlvblZlcnNpb25JZDpyZXEoc2NvcGVkUmVmKCdzbmFwc2hvdCcpKSxwdWJsaWNJZDpyZXEodHh0KDEsMjU2KSl9KSkpLGNpdGF0aW9uQmluZGluZ3M6cmVxKGFycihvYmooe3NvdXJjZVZlcnNpb25JZDpyZXEoc2NvcGVkUmVmKCdzbmFwc2hvdCcpKSxwdWJsaWNWZXJzaW9uSWQ6cmVxKHR4dCgxLDI1NikpfSkpKSx3b3JsZFZlcnNpb25zOnJlcShhcnIob2JqKHtzb3VyY2VWZXJzaW9uSWQ6cmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksY29udGVudEhhc2g6cmVxKHt0eXBlOidoYXNoJ30pfSkpKSB9KSksIGJvZHk6IHJlcShyaWNoKSwgYXR0YWNobWVudElkczogb3B0KHJlZnMoJ2F0dGFjaG1lbnQnKSksIGNvbnZlcnRlZFRvSWRzOiBvcHQocmVmcygpKSwgb3JpZ2luTm90ZUlkOiBvcHQocmVmKCdub3RlJykpIH0pLFxuICBjaGFwdGVyOiBvYmooeyBzY2VuZUlkczogcmVxKHJlZnMoJ3NjZW5lJykpLCBzdW1tYXJ5OiBvcHQoc3VtbWFyeSksIGF1dGhvck5vdGVzOiBvcHQocmljaCksIHN0cnVjdHVyZVJvbGU6IG9wdChzaG9ydCkgfSksXG4gIHNjZW5lOiBvYmooeyBzdW1tYXJ5OiByZXEoc3VtbWFyeSksIGJvZHk6IHJlcShyaWNoKSwgYXV0aG9yTm90ZXM6IHJlcShyaWNoKSwgZXZlbnRJZHM6IHJlcShyZWZzKCdldmVudCcpKSwgZGlhbG9ndWVMaW5lSWRzOiBvcHQocmVmcygnZGlhbG9ndWVfbGluZScpKSwgY2hhcHRlcklkOiBvcHQocmVmKCdjaGFwdGVyJykpLCB0aHJlYWRJZHM6IG9wdChyZWZzKCdncm91cCcpKSwgcG92SWQ6IG9wdChyZWYoJ2NoYXJhY3RlcicpKSwgZ29hbHM6IG9wdChyaWNoKSwgY29uZmxpY3RzOiBvcHQocmljaCksIHJlc3VsdHM6IG9wdChyaWNoKSwgbmV3SW5mb3JtYXRpb246IG9wdChyaWNoKSwgdGVuc2lvbjogb3B0KG51bSgwLCAxMCkpLCBpbXBvcnRhbmNlOiBvcHQobnVtKDAsIDEwKSksIGJsb2NrSWRzOiBvcHQoYXJyKHNjb3BlZFJlZignYmxvY2snKSwgdHJ1ZSkpLCByZXVzZTogb3B0KHJldXNlKSB9KSxcbiAgZ29hbDogb2JqKHsgb3duZXJJZDogcmVxKHJlZignY2hhcmFjdGVyJywgJ2dyb3VwJykpLCBkZXNjcmlwdGlvbjogcmVxKHJpY2gpLCBjaGFuZ2VzOiBvcHQocmVmcygnYXNzZXJ0aW9uJykpLCBldmlkZW5jZVNjZW5lSWRzOiBvcHQocmVmcygnc2NlbmUnKSksIHZhbGlkaXR5OiBvcHQobnVsbGFibGVWYWxpZGl0eSkgfSksXG4gIGZsb3dfbm9kZTogb2JqKHsgbm9kZVR5cGU6IHJlcShlbignc2NlbmUnLCAnY2hvaWNlJywgJ2F1dG9tYXRpYycsICdjYWxsJywgJ2VudHJ5JywgJ2V4aXQnLCAndGVybWluYWwnKSksIHNjZW5lSWQ6IG9wdChyZWYoJ3NjZW5lJykpLCBjaGlsZEdyYXBoSWQ6IG9wdChyZWYoJ2Zsb3dfZ3JhcGgnKSksIHRlcm1pbmFsUmVhc29uOiBvcHQodHh0KCkpLCB0cmlnZ2VyOiBvcHQodHJpZ2dlciksIGdhdGU6IG9wdChjb25kKSwgZXhlY3V0aW9uUG9saWN5OiBvcHQoZW4oJ21hbnVhbF9jaG9pY2UnLCAnZmlyc3RfbWF0Y2gnLCAnYWxsX21hdGNoJykpLCBmYWxsYmFja0lkOiBvcHQocmVmKCdmbG93X25vZGUnKSksIHJldXNlOiBvcHQocmV1c2UpIH0pLFxuICBmbG93X2VkZ2U6IG9iaih7IGZyb21JZDogcmVxKHJlZignZmxvd19ub2RlJykpLCB0b0lkOiByZXEodW5pb24ocmVmKCdmbG93X25vZGUnKSwgdW5yZXNvbHZlZCkpLCBlZGdlVHlwZTogcmVxKGVuKCdjaG9pY2UnLCAnYXV0b21hdGljJywgJ2NhbGxfcmV0dXJuJykpLCBsYWJlbDogb3B0KHR4dCgpKSwgY29uZGl0aW9uOiBvcHQoY29uZCksIGVmZmVjdElkczogb3B0KHJlZnMoJ2VmZmVjdCcpKSwgcHJpb3JpdHk6IG9wdChudW0odW5kZWZpbmVkLCB1bmRlZmluZWQsIHRydWUpKSwgY2hvaWNlTGluZUlkOiBvcHQocmVmKCdkaWFsb2d1ZV9saW5lJykpIH0pLFxuICBmbG93X2dyYXBoOiBvYmooeyBub2RlSWRzOiByZXEocmVmcygnZmxvd19ub2RlJykpLCBlZGdlSWRzOiByZXEocmVmcygnZmxvd19lZGdlJykpLCBlbnRyeUlkczogcmVxKHJlZnMoJ2Zsb3dfbm9kZScpKSwgZXhpdElkczogcmVxKHJlZnMoJ2Zsb3dfbm9kZScpKSwgcGFyZW50R3JhcGhJZDogb3B0KHJlZignZmxvd19ncmFwaCcpKSwgcGFyYW1ldGVyczogb3B0KGFycihvYmooeyBrZXk6IHJlcShrZXkpLCB0eXBlOiByZXEoZW4oJ2Jvb2xlYW4nLCAnaW50ZWdlcicsICdlbnVtJykpLCBkZWZhdWx0OiBvcHQodHlwZWQpIH0pKSkgfSksXG4gIGRpYWxvZ3VlX2xpbmU6IG9iaih7IHRleHQ6IHJlcShyaWNoKSwgc3BlYWtlcklkOiBvcHQocmVmKCdjaGFyYWN0ZXInKSksIGNob2ljZUVkZ2VJZDogb3B0KHJlZignZmxvd19lZGdlJykpLCBjdWVJZHM6IG9wdChyZWZzKCdjdWUnKSksIG9yaWdpbkxpbmVJZHM6IG9wdChyZWZzKCdkaWFsb2d1ZV9saW5lJykpLCByZXBsYWNlZEJ5TGluZUlkczogb3B0KHJlZnMoJ2RpYWxvZ3VlX2xpbmUnKSksIGxpbmVhZ2U6IG9wdChvYmooeyBtb2RlOiByZXEoZW4oJ3NwbGl0JywgJ21lcmdlJywgJ2NvcHknKSksIGJhc2VSZXZpc2lvbjogcmVxKHsgdHlwZTogJ3JldmlzaW9uJyB9KSwgcmVhc29uOiByZXEodHh0KDEpKSwgc2VnbWVudHM6IHJlcShhcnIob2JqKHsgc291cmNlOiByZXEoYW5jaG9yKSwgdGFyZ2V0OiByZXEoYW5jaG9yKSB9KSwgZmFsc2UsIDEpKSB9KSksIGNsYWltQXNzZXJ0aW9uSWRzOiBvcHQocmVmcygnYXNzZXJ0aW9uJykpLCBhc3NlcnRpb25JbnRlbnQ6IG9wdChlbignc3RhdGVtZW50JywgJ2xpZScsICdtaXN1bmRlcnN0YW5kaW5nJywgJ3F1b3RhdGlvbicpKSwgYXNzZXJ0aW9uUmVhc29uOiBvcHQodHh0KCkpIH0pLFxuICBxdWVzdDogb2JqKHsga2V5OiByZXEoa2V5KSwgc3RhdGVWYXJpYWJsZUlkOiByZXEocmVmKCd2YXJpYWJsZScpKSwgZGVzY3JpcHRpb246IG9wdChyaWNoKSwgZmxvd0lkczogb3B0KHJlZnMoJ2Zsb3dfZ3JhcGgnKSksIHRyYW5zaXRpb25SdWxlczogb3B0KGFycih0cmFuc2l0aW9uKSksIGdhbWVwbGF5U3BlY0lkczogb3B0KHJlZnMoJ2dhbWVwbGF5X3NwZWMnKSkgfSksXG4gIGxvcmU6IG9iaih7IGJvZHk6IHJlcShyaWNoKSwgYXNzZXJ0aW9uSWRzOiBvcHQocmVmcygnYXNzZXJ0aW9uJykpLCBzb3VyY2VJZHM6IG9wdChyZWZzKCdzb3VyY2UnKSksIHJlYWRpbmc6IG9wdChzaG9ydCksIGFsaWFzZXM6IG9wdChhcnIoYWxpYXMpKSB9KSxcbiAgdmFyaWFibGU6IG9iaih7IGtleTogcmVxKGtleSksIHZhbHVlVHlwZTogcmVxKGVuKCdib29sZWFuJywgJ2ludGVnZXInLCAnZW51bScpKSwgc2NvcGU6IHJlcShlbiguLi5TQ09QRVMpKSwgaW5pdGlhbDogcmVxKHR5cGVkKSwgYWxsb3dlZDogcmVxKGFsbG93ZWQpLCBkZXNjcmlwdGlvbjogb3B0KHJpY2gpLCBvd25lcklkOiBvcHQocmVmKCdjaGFyYWN0ZXInKSksIGRlcml2ZWQ6IG9wdCh7IHR5cGU6ICdleHByZXNzaW9uJyB9KSwgZXh0ZXJuYWxDb250cmFjdElkOiBvcHQocmVmKCdleHRlcm5hbF9jb250cmFjdCcpKSwgcmVzZXRSdWxlczogb3B0KGFycihyZXNldFJ1bGUpKSwgdHJhbnNpdGlvblJ1bGVzOiBvcHQoYXJyKHRyYW5zaXRpb24pKSwgZXhjbHVzaW9uczogb3B0KGFycihvYmooeyB2YXJpYWJsZUlkOiByZXEocmVmKCd2YXJpYWJsZScpKSwgdmFsdWU6IHJlcSh0eXBlZCksIG90aGVyVmFsdWU6IHJlcSh0eXBlZCksIHJlYXNvbjogcmVxKHR4dCgxKSksIGV4Y2VwdGlvbnM6IG9wdChhcnIoZXhjZXB0aW9uKSkgfSkpKSwgZXh0ZXJuYWxVc2VEZWNsYXJlZDogb3B0KGJvb2wpIH0pLFxuICBlZmZlY3Q6IG9iaih7IG9wZXJhdGlvbjogcmVxKGVuKCdzZXQnLCAnYWRkJywgJ2dyYW50JywgJ2NvbnN1bWUnLCAnbW92ZScsICdhc3NlcnQnLCAnbWFya19zZWVuJywgJ3Jlc2V0JykpLCB0YXJnZXRJZDogcmVxKHJlZigpKSwgdmFsdWU6IG9wdCh0eXBlZCksIGNvbmRpdGlvbjogb3B0KGNvbmQpLCBpbnN0YW5jZUlkOiBvcHQocmVmKCdpdGVtJykpLCByZWFzb246IG9wdCh0eHQoKSksIGV4Y2VwdGlvbkRldGFpbHM6IG9wdChleGNlcHRpb24pIH0pLFxuICBhc3NlcnRpb246IG9iaih7IHN1YmplY3RJZDogcmVxKHJlZigpKSwgcHJlZGljYXRlOiByZXEodHh0KDEsIDEyOCkpLCB2YWx1ZTogcmVxKHVuaW9uKHR5cGVkLCByZWYoKSkpLCB0cnV0aEtpbmQ6IHJlcShlbignYXV0aG9yX3RydXRoJywgJ3Rlc3RpbW9ueScsICdiZWxpZWYnLCAnaHlwb3RoZXNpcycpKSwgaG9sZGVySWQ6IG9wdChyZWYoJ2NoYXJhY3RlcicpKSwgc291cmNlSWRzOiBvcHQocmVmcygnc291cmNlJywgJ2Fzc2VydGlvbicsICdldmVudCcsICdzY2VuZScsICdkaWFsb2d1ZV9saW5lJykpLCBldmlkZW5jZUxvY2F0aW9uOiBvcHQoYW5jaG9yKSwgdmFsaWRpdHk6IG9wdChudWxsYWJsZVZhbGlkaXR5KSwgcmVhc29uOiBvcHQodHh0KCkpIH0pLFxuICBmb3Jlc2hhZG93OiBvYmooeyBxdWVzdGlvbjogcmVxKHJpY2gpLCBpbnRlbnQ6IHJlcShyaWNoKSwgcmVzb2x1dGlvblBvbGljeTogcmVxKGVuKCd0aGlzX3dvcmsnLCAnc2VxdWVsJywgJ2ludGVudGlvbmFsX29wZW4nLCAncmVkX2hlcnJpbmcnLCAndW5kZWNpZGVkJywgJ3JlamVjdGVkJykpLCB0cnV0aEFzc2VydGlvbklkczogb3B0KHJlZnMoJ2Fzc2VydGlvbicpKSwgY2x1ZUlkczogb3B0KHJlZnMoJ2Rpc2Nsb3N1cmUnKSksIHBheW9mZklkczogb3B0KHJlZnMoJ2Rpc2Nsb3N1cmUnKSksIHJlcXVpcmVkSW5mbzogb3B0KHJlZnMoJ2Rpc2Nsb3N1cmUnLCAnYXNzZXJ0aW9uJykpLCBhbHRlcm5hdGl2ZUluZm86IG9wdChyZWNvcmQocmVmcygnZGlzY2xvc3VyZScsICdhc3NlcnRpb24nKSwgcmVmKCdkaXNjbG9zdXJlJywgJ2Fzc2VydGlvbicpKSksIGRlYWRsaW5lOiBvcHQodGFyZ2V0U2NvcGUpLCBwcmVzZW50YXRpb25EZWFkbGluZTogb3B0KGFuY2hvciksIGV4Y2VwdGlvbnM6IG9wdChhcnIoZXhjZXB0aW9uKSkgfSksXG4gIGRpc2Nsb3N1cmU6IG9iaih7IGZvcmVzaGFkb3dJZDogcmVxKHJlZignZm9yZXNoYWRvdycpKSwgYW5jaG9yOiByZXEoYW5jaG9yKSwgc3RhZ2U6IHJlcShlbignaGludCcsICdzdXNwaWNpb24nLCAncmVpbmZvcmNlJywgJ3JldmVhbCcsICdhbHRlcm5hdGl2ZScpKSwgcm9sZTogcmVxKGVuKCdjbHVlJywgJ3BheW9mZicpKSwgY29uZGl0aW9uOiBvcHQoY29uZCksIGtub3dsZWRnZUVmZmVjdHM6IG9wdChyZWZzKCdlZmZlY3QnKSksIHRhcmdldFNjb3BlOiBvcHQodGFyZ2V0U2NvcGUpIH0pLFxuICBjaGVja3BvaW50OiBvYmooeyB3b3JsZFRpY2s6IG9wdCh0aWNrKSwgY29udGVudFZlcnNpb25JZDogcmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksIHJ1bnRpbWVTdGF0ZTogcmVxKHJ1bnRpbWUpLCBwcmVzZW50YXRpb25TdGF0ZTogb3B0KHJ1bnRpbWUpLCBwcmVzZW50YXRpb25SZXN1bHRzOiBvcHQoYXJyKHByZXNlbnRhdGlvblJlc3VsdCkpLCBjb250ZW50UmV2aXNpb246IG9wdCh7IHR5cGU6ICdyZXZpc2lvbicgfSksIG9yaWdpbjogb3B0KGVuKCdmdWxsX3BsYXknLCAncGFydGlhbCcsICdpbXBvcnRlZCcpKSwgdHJhY2VJZDogb3B0KHJlZigndHJhY2UnKSksIG1pZ3JhdGlvbjogb3B0KG9iaih7IHNvdXJjZUNoZWNrcG9pbnRJZDogcmVxKHJlZignY2hlY2twb2ludCcpKSwgc291cmNlVmVyc2lvbklkOiByZXEoc2NvcGVkUmVmKCdzbmFwc2hvdCcpKSwgYmFzZVJldmlzaW9uOiByZXEoeyB0eXBlOiAncmV2aXNpb24nIH0pLCBtZXRob2Q6IHJlcShlbignbWlncmF0ZScsICdyZWNyZWF0ZScpKSB9KSkgfSksXG4gIHRyYWNlOiBvYmooeyBjb250ZW50VmVyc2lvbklkOiByZXEoc2NvcGVkUmVmKCdzbmFwc2hvdCcpKSwgc3RhcnRDaGVja3BvaW50SWQ6IHJlcShyZWYoJ2NoZWNrcG9pbnQnKSksIHN0ZXBzOiByZXEoYXJyKG9iaih7IG5vZGVJZDogcmVxKHJlZignZmxvd19ub2RlJykpLCBlZGdlSWRzOiByZXEocmVmcygnZmxvd19lZGdlJykpLCBiZWZvcmU6IHJlcShydW50aW1lKSwgYWZ0ZXI6IHJlcShydW50aW1lKSwgcHJlc2VudGF0aW9uU3RhdGU6IG9wdChydW50aW1lKSwgY29uZGl0aW9uUmVzdWx0czogb3B0KGFycihwcmVzZW50YXRpb25SZXN1bHQpKSwgb3BlcmF0aW9uOiBvcHQoZW4oJ2FkdmFuY2UnLCAnc3R1YicpKSwgb2NjdXJyZW5jZUlkOiBvcHQodHh0KCkpLCB3b3JsZFRpY2s6IG9wdCh0aWNrKSwgZXh0ZXJuYWxNb2RlOiBvcHQoZW4oJ3N0dWInLCAnYWN0dWFsJywgJ21peGVkJykpLCBleHRlcm5hbFZhbHVlczogb3B0KHJlY29yZCh0eXBlZCwgcmVmKCdleHRlcm5hbF9jb250cmFjdCcpKSkgfSkpKSwgY29udGVudFJldmlzaW9uOiBvcHQoeyB0eXBlOiAncmV2aXNpb24nIH0pLCBpbml0aWFsRXh0ZXJuYWxWYWx1ZXM6IG9wdChyZWNvcmQodHlwZWQsIHJlZignZXh0ZXJuYWxfY29udHJhY3QnKSkpLCBpbml0aWFsU3R1YkJhc2VTdGF0ZTogb3B0KHJ1bnRpbWUpLCBpbml0aWFsU3R1YlZhbHVlczogb3B0KG9iaih7IHZhcmlhYmxlczogb3B0KHJlY29yZCh0eXBlZCwgcmVmKCd2YXJpYWJsZScpKSksIGV4dGVybmFsOiBvcHQocmVjb3JkKHR5cGVkLCByZWYoJ2V4dGVybmFsX2NvbnRyYWN0JykpKSB9KSksIGluaXRpYWxXb3JsZFRpY2s6IG9wdCh0aWNrKSwgc2VlZDogb3B0KHR4dCgpKSwgZW5naW5lVmVyc2lvbjogb3B0KHR4dCgpKSwgZXh0ZXJuYWxNb2RlOiBvcHQoZW4oJ3N0dWInLCAnYWN0dWFsJywgJ21peGVkJykpLCBjb3ZlcmFnZTogb3B0KGNvdmVyYWdlKSwgcmVncmVzc2lvbkRlY2xhcmF0aW9uczogb3B0KG9iaih7IHByb2plY3RSZXZpc2lvbjogcmVxKHsgdHlwZTogJ3JldmlzaW9uJyB9KSwgdHJhY2VJZHM6IHJlcShyZWZzKCd0cmFjZScpKSB9KSksIHJlY29uZmlybWF0aW9uOiBvcHQob2JqKHsgc291cmNlVHJhY2VJZDogcmVxKHJlZigndHJhY2UnKSksIHNvdXJjZVZlcnNpb25JZDogcmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksIGJhc2VSZXZpc2lvbjogcmVxKHsgdHlwZTogJ3JldmlzaW9uJyB9KSwgc3RhcnRDaGVja3BvaW50SWQ6IG9wdChyZWYoJ2NoZWNrcG9pbnQnKSkgfSkpLCBtb2RlOiBvcHQoZW4oJ2Zsb3cnLCAnY2hhcHRlcnMnLCBudWxsKSksIHJlYWRpbmdQYXRoOiBvcHQodW5pb24ocmVhZGluZ1BhdGgsIGVuKG51bGwpKSkgfSksXG4gIGF0dGFjaG1lbnQ6IG9iaih7IG1lZGlhVHlwZTogcmVxKHR4dCgxLCAxMjgpKSwgY29udGVudEhhc2g6IHJlcSh7IHR5cGU6ICdoYXNoJyB9KSwgYnl0ZVNpemU6IHJlcShudW0oMCwgMzIgKiAxMDI0ICogMTAyNCwgdHJ1ZSkpLCBhc3NldFBhdGg6IHJlcSh7IHR5cGU6ICdzYWZlX3BhdGgnIH0pLCBkaXNwbGF5TmFtZTogb3B0KHR4dCgpKSwgcHJvdmVuYW5jZUlkOiBvcHQocmVmKCdzb3VyY2UnKSksIGxpY2Vuc2VOb3RlOiBvcHQodHh0KCkpLCBzdGFnZTogb3B0KGVuKCdyZWZlcmVuY2UnLCAndGVtcG9yYXJ5JywgJ2ZpbmFsJykpLCByZXZpc2lvbkhpc3Rvcnk6IG9wdChyZWZzKCdhdHRhY2htZW50JykpIH0pLFxuICBzb3VyY2U6IG9iaih7IHNvdXJjZVR5cGU6IHJlcShlbignd2ViJywgJ2ZpbGUnLCAnYm9vaycsICdvYnNlcnZhdGlvbicpKSwgbG9jYXRvcjogcmVxKHR4dCgxKSksIGFjY2Vzc2VkQXQ6IG9wdCh7IHR5cGU6ICdkYXRldGltZScgfSksIGV4Y2VycHRMb2NhdGlvbjogb3B0KHR4dCgpKSwgaW50ZXJwcmV0YXRpb246IG9wdChyaWNoKSwgYXR0YWNobWVudElkOiBvcHQocmVmKCdhdHRhY2htZW50JykpLCByZWRpc3RyaWJ1dGlvbkFsbG93ZWQ6IG9wdChib29sKSB9KSxcbiAgY3VlOiBvYmooeyBhbmNob3I6IHJlcShhbmNob3IpLCBjdWVUeXBlOiByZXEodHh0KDEsIDEyOCkpLCBhdHRhY2htZW50SWQ6IG9wdChyZWYoJ2F0dGFjaG1lbnQnKSksIHNwZWFrZXJJZDogb3B0KHJlZignY2hhcmFjdGVyJykpLCBleHByZXNzaW9uOiBvcHQodHh0KCkpLCB3YWl0TXM6IG9wdChudW0oMCwgdW5kZWZpbmVkLCB0cnVlKSksIGNhbWVyYTogb3B0KHsgdHlwZTogJ2N1c3RvbScgfSksIG1lZGlhVGltZTogb3B0KG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgc3RhZ2U6IG9wdChzaG9ydCkgfSksXG4gIHN0b3J5Ym9hcmRfZnJhbWU6IG9iaih7IGFuY2hvcjogcmVxKGFuY2hvciksIG1lZGlhU3RhcnRNczogcmVxKG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgbWVkaWFFbmRNczogb3B0KG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgcmVmZXJlbmNlQXNzZXRJZDogb3B0KHJlZignYXR0YWNobWVudCcpKSwgZmluYWxBc3NldElkOiBvcHQocmVmKCdhdHRhY2htZW50JykpLCBjdWVJZHM6IG9wdChyZWZzKCdjdWUnKSksIGNhcHRpb246IG9wdChyaWNoKSB9KSxcbiAgbG9jYWxpemF0aW9uOiBvYmooeyBzb3VyY2VMaW5lSWQ6IHJlcShyZWYoJ2RpYWxvZ3VlX2xpbmUnKSksIGxhbmd1YWdlOiByZXEodHh0KDEsIDEyOCkpLCBzb3VyY2VIYXNoOiByZXEoeyB0eXBlOiAnaGFzaCcgfSksIHRleHQ6IHJlcShyaWNoKSwgc3RhZ2U6IG9wdChlbignZHJhZnQnLCAncmV2aWV3ZWQnLCAnbmVlZHNfcmV2aWV3JykpLCByZXZpZXdlZEJ5OiBvcHQoc2NvcGVkUmVmKCdpZGVudGl0eScpKSwgcmVjb3JkaW5nSWRzOiBvcHQocmVmcygncmVjb3JkaW5nJykpIH0pLFxuICByZWNvcmRpbmc6IG9iaih7IHNvdXJjZUxpbmVJZDogcmVxKHJlZignZGlhbG9ndWVfbGluZScpKSwgbGFuZ3VhZ2U6IHJlcSh0eHQoMSwgMTI4KSksIHNvdXJjZUhhc2g6IHJlcSh7IHR5cGU6ICdoYXNoJyB9KSwgdHJhbnNsYXRpb25JZDogb3B0KHJlZignbG9jYWxpemF0aW9uJykpLCBhdHRhY2htZW50SWQ6IG9wdChyZWYoJ2F0dGFjaG1lbnQnKSksIG5vdGVzOiBvcHQocmljaCksIHN0YWdlOiBvcHQoZW4oJ3BsYW5uZWQnLCAncmVjb3JkZWQnLCAncmV2aWV3ZWQnLCAnbmVlZHNfcmV2aWV3JykpLCByZXZpZXdlZEJ5OiBvcHQoc2NvcGVkUmVmKCdpZGVudGl0eScpKSB9KSxcbiAgdGVybWlub2xvZ3k6IG9iaih7IGNhbm9uaWNhbDogcmVxKHR4dCgxLCAxMjgpKSwgcmVhZGluZzogcmVxKHNob3J0KSwgdmFyaWFudHM6IG9wdChhcnIoc2hvcnQsIHRydWUpKSwgbGFuZ3VhZ2U6IG9wdChzaG9ydCksIHVzYWdlTm90ZXM6IG9wdChyaWNoKSwgdmFsaWRpdHk6IG9wdChudWxsYWJsZVZhbGlkaXR5KSwgZXhjZXB0aW9uczogb3B0KGFycihleGNlcHRpb24pKSwgdm9pY2VPd25lcklkOiBvcHQocmVmKCdjaGFyYWN0ZXInKSkgfSksXG4gIG1hcDogb2JqKHsgcGxhY2VJZDogcmVxKHJlZigncGxhY2UnKSksIGNvb3JkaW5hdGVTeXN0ZW06IHJlcShlbignbm9ybWFsaXplZCcpKSwgYXR0YWNobWVudElkOiBvcHQocmVmKCdhdHRhY2htZW50JykpLCBwYXJlbnRNYXBJZDogb3B0KHJlZignbWFwJykpLCBwaW5zOiBvcHQoYXJyKG9iaih7IGlkOiByZXEoaWRTY2hlbWEpLCBwbGFjZUlkOiByZXEocmVmKCdwbGFjZScpKSwgeDogcmVxKG51bSgwLCAxKSksIHk6IHJlcShudW0oMCwgMSkpLCBsYWJlbDogb3B0KHR4dCgpKSB9KSkpIH0pLFxuICB0cmF2ZWxfcm91dGU6IG9iaih7IGZyb21QbGFjZUlkOiByZXEocmVmKCdwbGFjZScpKSwgdG9QbGFjZUlkOiByZXEocmVmKCdwbGFjZScpKSwgZGlyZWN0aW9uOiByZXEoZW4oJ29uZV93YXknLCAndHdvX3dheScpKSwgbWV0aG9kOiBvcHQodHh0KCkpLCBtaW5pbXVtVGlja3M6IG9wdCh0aWNrKSwgbWF4aW11bVRpY2tzOiBvcHQodGljayksIGV2aWRlbmNlOiBvcHQocmVmcygpKSwgdmFsaWRpdHk6IG9wdChudWxsYWJsZVZhbGlkaXR5KSB9KSxcbiAgdGVtcGxhdGU6IG9iaih7IHRhcmdldEtpbmQ6IHJlcShlbiguLi5FTlRJVFlfS0lORFMpKSwgZmllbGRzOiByZXEoYXJyKGZpZWxkRGVmaW5pdGlvbikpLCBkZXNjcmlwdGlvbjogb3B0KHR4dCgpKSwgdmVyc2lvbjogb3B0KHsgdHlwZTogJ3JldmlzaW9uJyB9KSwgZGVmYXVsdHM6IG9wdChyZWNvcmQoeyB0eXBlOiAnY3VzdG9tJyB9LCBrZXkpKSB9KSxcbiAgY29sbGVjdGlvbjogb2JqKHsgcHVycG9zZTogb3B0KGVuKCdyZWdyZXNzaW9uJykpLCBtb2RlOiByZXEoZW4oJ2R5bmFtaWMnLCAnZml4ZWQnKSksIHF1ZXJ5OiBvcHQoeyB0eXBlOiAncXVlcnknIH0pLCBtZW1iZXJJZHM6IG9wdChyZWZzKCkpLCBzb3J0OiBvcHQob2JqKHsgZmllbGQ6IHJlcShlbignbmFtZScsICdjcmVhdGVkQXQnLCAndXBkYXRlZEF0JywgJ2tpbmQnKSksIGRpcmVjdGlvbjogcmVxKGVuKCdhc2MnLCAnZGVzYycpKSB9KSkgfSksXG4gIHJldmlldzogb2JqKHsgdGFyZ2V0OiByZXEodW5pb24oYW5jaG9yLCByZWYoKSkpLCB0YXJnZXRWZXJzaW9uSWQ6IHJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLCBib2R5OiByZXEocmljaCksIHN0YWdlOiByZXEoZW4oJ29wZW4nLCAnZml4ZWQnLCAndmVyaWZpZWQnKSksIGFzc2lnbmVlSWQ6IG9wdChzY29wZWRSZWYoJ2lkZW50aXR5JykpLCBxdW90ZWRUZXh0OiBvcHQodHh0KCkpLCByZXNvbHV0aW9uOiBvcHQocmljaCksc2hhcmVkU291cmNlOm9wdChvYmooe2Nvbm5lY3Rpb246cmVxKHR4dCgxKSksc2hhcmVkU25hcHNob3Q6cmVxKHR4dCgxKSksY29tbWVudDpyZXEodHh0KDEpKSxwdWJsaWNWZXJzaW9uOnJlcSh0eHQoMSkpLHB1YmxpY0VudGl0eTpvcHQodHh0KDEpKSxwdWJsaWNSZWxhdGlvbjpvcHQodHh0KDEpKSxwdWJsaWNCbG9jazpvcHQodHh0KDEpKSxzdGFydENwOm9wdChudW0oMCx1bmRlZmluZWQsdHJ1ZSkpLGVuZENwOm9wdChudW0oMCx1bmRlZmluZWQsdHJ1ZSkpLHByb2plY3Rpb25IYXNoOnJlcSh0eHQoNjQsNjQpKSxjb21tZW50Qm9keUhhc2g6cmVxKHR4dCg2NCw2NCkpLHF1b3RlZFRleHQ6cmVxKHR4dCgpKSxvYnNlcnZlZFN0YWdlOnJlcShlbignb3BlbicsJ2ZpeGVkJywndmVyaWZpZWQnKSl9KSkgfSksXG4gIGNyZWF0aXZlX2JyaWVmOiBvYmooeyB0YXJnZXRBdWRpZW5jZTogcmVxKHJpY2gpLCBleHBlcmllbmNlOiByZXEocmljaCksIHRoZW1lOiByZXEocmljaCksIHRvbmU6IHJlcShyaWNoKSwgc2NvcGU6IHJlcShyaWNoKSwgZGVsaXZlcmFibGVJZHM6IG9wdChyZWZzKCkpLCBkZWNpc2lvbklkczogb3B0KHJlZnMoJ2RlY2lzaW9uJykpIH0pLFxuICBkZWNpc2lvbjogb2JqKHsgc3ViamVjdDogcmVxKHR4dCgxKSksIHJlYXNvbjogcmVxKHJpY2gpLCB0YXJnZXRWZXJzaW9uSWQ6IHJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLCBvdXRjb21lOiByZXEoZW4oJ2FjY2VwdGVkJywgJ3JlamVjdGVkJywgJ2RlZmVycmVkJykpLCBwcmlvcml0eTogb3B0KHNob3J0KSwgcmVxdWlyZW1lbnRJZHM6IG9wdChhcnIoc2hvcnQsIHRydWUpKSwgcmV2aWV3SWRzOiBvcHQocmVmcygncmV2aWV3JykpIH0pLFxuICBnYW1lcGxheV9zcGVjOiBvYmooeyBzY2VuZUlkOiByZXEocmVmKCdzY2VuZScpKSwgYWN0aW9uOiByZXEocmljaCksIG1lY2hhbmljOiBvcHQodHh0KCkpLCB0dXRvcmlhbDogb3B0KHJpY2gpLCByZXdhcmQ6IG9wdCh0eXBlZCksIHF1ZXN0SWQ6IG9wdChyZWYoJ3F1ZXN0JykpLCB0YXNrSWRzOiBvcHQocmVmcygncHJvZHVjdGlvbl90YXNrJykpLCBpbnRlbnRpb25hbERpZmZlcmVuY2U6IG9wdCh0eHQoKSkgfSksXG4gIHByb2R1Y3Rpb25fdGFzazogb2JqKHsgdGFyZ2V0SWRzOiByZXEocmVmcygpKSwgc3RhZ2U6IHJlcShlbignd3JpdGluZycsICdyZXZpZXcnLCAnaW1wbGVtZW50YXRpb24nLCAndHJhbnNsYXRpb24nLCAncmVjb3JkaW5nJywgJ3ZlcmlmaWNhdGlvbicsICdwdWJsaWNhdGlvbicpKSwgcHJvZ3Jlc3M6IHJlcShlbigndG9kbycsICdkb2luZycsICdkb25lJywgJ25lZWRzX3JldmlldycpKSwgYXNzaWduZWVJZDogb3B0KHNjb3BlZFJlZignaWRlbnRpdHknKSksIGRlYWRsaW5lOiBvcHQob2JqKHsgZGF0ZTogcmVxKHsgdHlwZTogJ2RhdGUnIH0pLCB0aW1lWm9uZTogcmVxKHR4dCgxLCAxMjgpKSB9KSksIGRlcGVuZHNPbjogb3B0KHJlZnMoJ3Byb2R1Y3Rpb25fdGFzaycpKSwgZXN0aW1hdGU6IG9wdChlc3RpbWF0ZSksIGJsb2NraW5nUmVhc29uOiBvcHQodHh0KCkpIH0pLFxuICBtZWRpYV92YXJpYW50OiBvYmooeyBwcmV2aW91c1ZhcmlhbnRJZDogb3B0KHJlZignbWVkaWFfdmFyaWFudCcpKSwgY29uZmlybWF0aW9uUmVjaXBpZW50SWRzOiBvcHQoYXJyKHNjb3BlZFJlZignaWRlbnRpdHknKSwgdHJ1ZSkpLCBtZWRpdW06IHJlcShlbignZ2FtZScsICdub3ZlbCcsICd2aWRlbycsICdhdWRpbycsICdwcm9tb3Rpb24nLCAnY3VzdG9tJykpLCBiYXNlU25hcHNob3RJZDogcmVxKHNjb3BlZFJlZignc25hcHNob3QnKSksIGJvZHk6IG9wdChyaWNoKSwgcmVsZWFzZUF0OiBvcHQoeyB0eXBlOiAnZGF0ZXRpbWUnIH0pLCBwcm9qZWN0aW9uUHJvZmlsZUlkOiBvcHQocmVmKCdwcm9qZWN0aW9uX3Byb2ZpbGUnKSksIHNvdXJjZUlkczogb3B0KHJlZnMoKSksIG5lZWRzUmV2aWV3OiBvcHQoYm9vbCkgfSksXG4gIHZvaWNlX3J1bGU6IG9iaih7IGNoYXJhY3RlcklkOiByZXEocmVmKCdjaGFyYWN0ZXInKSksIHZhbGlkaXR5OiByZXEobnVsbGFibGVWYWxpZGl0eSksIGZpcnN0UGVyc29uOiBvcHQoc2hvcnQpLCBhZGRyZXNzaW5nOiBvcHQodHh0KCkpLCBwaHJhc2luZzogb3B0KHR4dCgpKSwgZXhhbXBsZXM6IG9wdChyaWNoKSwgZXhjZXB0aW9uczogb3B0KGFycihleGNlcHRpb24pKSB9KSxcbiAgZXh0ZXJuYWxfY29udHJhY3Q6IG9iaih7IGtleTogcmVxKGtleSksIG93bmVyOiByZXEoZW4oJ3Rvb2wnLCAnZ2FtZScpKSwgaW5wdXRUeXBlOiByZXEodHh0KDEsIDEyOCkpLCBvdXRwdXRUeXBlOiByZXEodHh0KDEsIDEyOCkpLCBtaXNzaW5nUG9saWN5OiByZXEoZW4oJ3Vua25vd24nLCAnYmxvY2snKSksIGRlc2NyaXB0aW9uOiBvcHQocmljaCksIHN0dWJWYWx1ZXM6IG9wdChhcnIodHlwZWQpKSwgYWRhcHRlclByb2ZpbGVJZHM6IG9wdChyZWZzKCdwcm9qZWN0aW9uX3Byb2ZpbGUnKSksIHZlcnNpb246IG9wdChzaG9ydCkgfSksXG4gIHNuYXBzaG90OiBvYmooeyB2ZXJzaW9uTGFiZWw6IHJlcSh0eHQoMSwgMTI4KSksIGNvbnRlbnRIYXNoOiByZXEoeyB0eXBlOiAnaGFzaCcgfSksIGltbXV0YWJsZTogcmVxKGVuKHRydWUpKSwgcGFyZW50VmVyc2lvbklkczogb3B0KGFycihzY29wZWRSZWYoJ3NuYXBzaG90JyksIHRydWUpKSwgcmVsZWFzZWRBdDogb3B0KHsgdHlwZTogJ2RhdGV0aW1lJyB9KSwgcmVmZXJlbmNlZFdvcmxkVmVyc2lvbklkczogb3B0KGFycihzY29wZWRSZWYoJ3NuYXBzaG90JyksIHRydWUpKSB9KSxcbiAgcHJvamVjdGlvbl9wcm9maWxlOiBvYmooeyBibG9ja1NvdXJjZXM6b3B0KHJlY29yZChzY29wZWRSZWYoJ2Jsb2NrJyksc2NvcGVkUmVmKCdwcm9qZWN0aW9uX3JlY29yZCcpKSksY2l0ZWRWZXJzaW9uczpvcHQoYXJyKG9iaih7c291cmNlVmVyc2lvbklkOnJlcShzY29wZWRSZWYoJ3NuYXBzaG90JykpLHByb2ZpbGVJZDpyZXEocmVmKCdwcm9qZWN0aW9uX3Byb2ZpbGUnKSkscHVibGljVmVyc2lvbklkOnJlcShpZFNjaGVtYSl9KSkpLGF1ZGllbmNlOiByZXEodHh0KDEsIDEyOCkpLCBpbmNsdWRlZElkczogcmVxKHJlZnMoKSksIG5hbWVQb2xpY3k6IHJlcSh7IHR5cGU6ICduYW1lX3BvbGljeScgfSksIGFsbG93ZWRLaW5kczogb3B0KGFycihlbiguLi5FTlRJVFlfS0lORFMpLCB0cnVlKSksIGV4Y2x1ZGVkRmllbGRzOiBvcHQoYXJyKHR4dCgxKSwgdHJ1ZSkpLCByb3V0ZVNjb3BlOiBvcHQodGFyZ2V0U2NvcGUpLCBpbmNsdWRlQXV0aG9yTm90ZXM6IG9wdChib29sKSwgcHVibGljVGl0bGU6IG9wdCh0eHQoKSksIHB1YmxpY1RleHRzOiBvcHQocmVjb3JkKHB1YmxpY1RleHQsIHNjb3BlZFJlZigncmVjb3JkJykpKSwgYWxsb3dlZEZpZWxkczogb3B0KHJlY29yZChhcnIodHh0KDEpLCB0cnVlKSwgZW4oLi4uRU5USVRZX0tJTkRTKSkpLCBhbGxvd2VkUmVsYXRpb25JZHM6IG9wdChhcnIoc2NvcGVkUmVmKCdyZWxhdGlvbicpLCB0cnVlKSksIGlkUG9saWN5OiBvcHQoZW4oJ3JlbWFwJywgJ3ByZXNlcnZlJykpLCBwdWJsaWNJZHM6IG9wdChyZWNvcmQoaWRTY2hlbWEsIHNjb3BlZFJlZigncHJvamVjdGlvbl9yZWNvcmQnKSkpLCBzb3VyY2VWZXJzaW9uSWQ6IG9wdChzY29wZWRSZWYoJ3NuYXBzaG90JykpLCBwdWJsaWNWYWx1ZXM6IG9wdChyZWNvcmQocmVjb3JkKHR4dCgpLCB0eHQoKSksIHJlZigndmFyaWFibGUnLCAnZXh0ZXJuYWxfY29udHJhY3QnLCAnYXNzZXJ0aW9uJykpKSwgaW5jbHVkZWRTdGF0dXNlczogb3B0KGFycihlbiguLi5TVEFUVVNFUyksIHRydWUpKSwgcHVibGljVmVyc2lvbkxhYmVsOiBvcHQodHh0KCkpLCBhcHByb3ZlZEF0dGFjaG1lbnRJZHM6IG9wdChyZWZzKCdhdHRhY2htZW50JykpIH0pLFxufTtcblxuY29uc3QgaXNPYmplY3QgPSAodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9PiAhIXZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpICYmIChPYmplY3QuZ2V0UHJvdG90eXBlT2YodmFsdWUpID09PSBPYmplY3QucHJvdG90eXBlIHx8IE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWx1ZSkgPT09IG51bGwpO1xuY29uc3QgdXRmOEVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbmNvbnN0IHV0ZjhCeXRlcyA9ICh2YWx1ZTogc3RyaW5nKTogbnVtYmVyID0+IHV0ZjhFbmNvZGVyLmVuY29kZSh2YWx1ZSkuYnl0ZUxlbmd0aDtcbi8vIENvdW50IHRoZSBzYW1lIFVuaWNvZGUgY29kZSBwb2ludHMgYXMgdGhlIHN0cmluZyBpdGVyYXRvciwgd2l0aG91dCBidWlsZGluZ1xuLy8gYW4gYXJyYXkgZm9yIGV2ZXJ5IGZpZWxkLiBJbnZhbGlkIHN1cnJvZ2F0ZXMgYXJlIHN0aWxsIHJlamVjdGVkIHNlcGFyYXRlbHkuXG5mdW5jdGlvbiBjb2RlUG9pbnRMZW5ndGgodmFsdWU6IHN0cmluZyk6IG51bWJlciB7XG4gIGxldCBjb3VudCA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyssIGNvdW50KyspIHtcbiAgICBjb25zdCBjb2RlID0gdmFsdWUuY2hhckNvZGVBdChpKSwgbmV4dCA9IHZhbHVlLmNoYXJDb2RlQXQoaSArIDEpO1xuICAgIGlmIChjb2RlID49IDB4ZDgwMCAmJiBjb2RlIDw9IDB4ZGJmZiAmJiBuZXh0ID49IDB4ZGMwMCAmJiBuZXh0IDw9IDB4ZGZmZikgaSsrO1xuICB9XG4gIHJldHVybiBjb3VudDtcbn1cbmZ1bmN0aW9uIHZhbGlkVW5pY29kZSh2YWx1ZTogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjb2RlID0gdmFsdWUuY2hhckNvZGVBdChpKTtcbiAgICBpZiAoY29kZSA+PSAweGQ4MDAgJiYgY29kZSA8PSAweGRiZmYpIHsgY29uc3QgbmV4dCA9IHZhbHVlLmNoYXJDb2RlQXQoKytpKTsgaWYgKCEobmV4dCA+PSAweGRjMDAgJiYgbmV4dCA8PSAweGRmZmYpKSByZXR1cm4gZmFsc2U7IH1cbiAgICBlbHNlIGlmIChjb2RlID49IDB4ZGMwMCAmJiBjb2RlIDw9IDB4ZGZmZikgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gYWRkSXNzdWUoaXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSwgcGF0aDogc3RyaW5nLCBtZXNzYWdlOiBzdHJpbmcsIGNvZGU6IFZhbGlkYXRpb25Jc3N1ZVsnY29kZSddID0gJ1ZBTElEQVRJT05fRkFJTEVEJyk6IHZvaWQgeyBpZiAoaXNzdWVzLmxlbmd0aCA8IDI1NikgaXNzdWVzLnB1c2goeyBjb2RlLCBwYXRoLCBtZXNzYWdlIH0pOyB9XG5mdW5jdGlvbiB2YWxpZERhdGUodmFsdWU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBpZiAoIS9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kLy50ZXN0KHZhbHVlKSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBkYXRlID0gbmV3IERhdGUoYCR7dmFsdWV9VDAwOjAwOjAwWmApOyByZXR1cm4gTnVtYmVyLmlzRmluaXRlKGRhdGUuZ2V0VGltZSgpKSAmJiBkYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApID09PSB2YWx1ZTtcbn1cbmZ1bmN0aW9uIGNvbmRpdGlvblNjaGVtYSh2YWx1ZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBTY2hlbWEgfCB1bmRlZmluZWQge1xuICBzd2l0Y2ggKHZhbHVlLm9wKSB7XG4gICAgY2FzZSAnY29uc3RhbnQnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbignY29uc3RhbnQnKSksIHZhbHVlOiByZXEoYm9vbCkgfSk7XG4gICAgY2FzZSAnYWxsJzogY2FzZSAnYW55JzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ2FsbCcsICdhbnknKSksIGNoaWxkcmVuOiByZXEoYXJyKGNvbmQsIGZhbHNlLCAxLCAyNTYpKSB9KTtcbiAgICBjYXNlICdub3QnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbignbm90JykpLCBjaGlsZDogcmVxKGNvbmQpIH0pO1xuICAgIGNhc2UgJ2NvbXBhcmUnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbignY29tcGFyZScpKSwgdmFyaWFibGVJZDogcmVxKHJlZigndmFyaWFibGUnKSksIGNvbXBhcmF0b3I6IHJlcShlbignZXEnLCAnbmUnLCAnbHQnLCAnbGUnLCAnZ3QnLCAnZ2UnLCAnaW4nKSksIHZhbHVlOiByZXEodmFsdWUuY29tcGFyYXRvciA9PT0gJ2luJyA/IGFycih0eXBlZCwgZmFsc2UsIDEsIDI1NikgOiB0eXBlZCkgfSk7XG4gICAgY2FzZSAnaXRlbSc6IHJldHVybiBvYmooeyBvcDogcmVxKGVuKCdpdGVtJykpLCBpdGVtSWQ6IHJlcShyZWYoJ2l0ZW0nKSksIHF1YW50aXR5OiByZXEobnVtKDEsIHVuZGVmaW5lZCwgdHJ1ZSkpIH0pO1xuICAgIGNhc2UgJ2tub3duJzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ2tub3duJykpLCBhc3NlcnRpb25JZDogcmVxKHJlZignYXNzZXJ0aW9uJykpLCBob2xkZXJJZDogcmVxKHJlZignY2hhcmFjdGVyJykpIH0pO1xuICAgIGNhc2UgJ3Zpc2l0ZWQnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbigndmlzaXRlZCcpKSwgZW50aXR5SWQ6IHJlcShyZWYoKSksIGNvdW50OiByZXEobnVtKDEsIHVuZGVmaW5lZCwgdHJ1ZSkpIH0pO1xuICAgIGNhc2UgJ2V4dGVybmFsJzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ2V4dGVybmFsJykpLCBjb250cmFjdElkOiByZXEocmVmKCdleHRlcm5hbF9jb250cmFjdCcpKSB9KTtcbiAgICBkZWZhdWx0OiByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59XG5mdW5jdGlvbiBleHByZXNzaW9uU2NoZW1hKHZhbHVlOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFNjaGVtYSB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGV4cHJlc3Npb246IFNjaGVtYSA9IHsgdHlwZTogJ2V4cHJlc3Npb24nIH07XG4gIHN3aXRjaCAodmFsdWUub3ApIHtcbiAgICBjYXNlICd2YWx1ZSc6IHJldHVybiBvYmooeyBvcDogcmVxKGVuKCd2YWx1ZScpKSwgdmFsdWU6IHJlcSh0eXBlZCkgfSk7XG4gICAgY2FzZSAndmFyaWFibGUnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbigndmFyaWFibGUnKSksIHZhcmlhYmxlSWQ6IHJlcShyZWYoJ3ZhcmlhYmxlJykpIH0pO1xuICAgIGNhc2UgJ2FkZCc6IGNhc2UgJ3N1YnRyYWN0JzogY2FzZSAnbXVsdGlwbHknOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbignYWRkJywgJ3N1YnRyYWN0JywgJ211bHRpcGx5JykpLCBsZWZ0OiByZXEoZXhwcmVzc2lvbiksIHJpZ2h0OiByZXEoZXhwcmVzc2lvbikgfSk7XG4gICAgY2FzZSAnaWYnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbignaWYnKSksIGNvbmRpdGlvbjogcmVxKGNvbmQpLCB0aGVuOiByZXEoZXhwcmVzc2lvbiksIGVsc2U6IHJlcShleHByZXNzaW9uKSB9KTtcbiAgICBkZWZhdWx0OiByZXR1cm4gY29uZGl0aW9uU2NoZW1hKHZhbHVlKTtcbiAgfVxufVxuZnVuY3Rpb24gdGltZVNjaGVtYSh2YWx1ZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBTY2hlbWEgfCB1bmRlZmluZWQge1xuICBjb25zdCBjYWxlbmRhcklkID0gcmVxKHNjb3BlZFJlZignY2FsZW5kYXInKSk7XG4gIHN3aXRjaCAodmFsdWUubW9kZSkge1xuICAgIGNhc2UgJ2luc3RhbnQnOiByZXR1cm4gb2JqKHsgbW9kZTogcmVxKGVuKCdpbnN0YW50JykpLCBhdDogcmVxKHRpY2spLCBjYWxlbmRhcklkIH0pO1xuICAgIGNhc2UgJ2ludGVydmFsJzogcmV0dXJuIG9iaih7IG1vZGU6IHJlcShlbignaW50ZXJ2YWwnKSksIHN0YXJ0OiByZXEodGljayksIGVuZDogcmVxKHRpY2spLCBjYWxlbmRhcklkIH0pO1xuICAgIGNhc2UgJ3VuY2VydGFpbic6IHJldHVybiBvYmooeyBtb2RlOiByZXEoZW4oJ3VuY2VydGFpbicpKSwgZWFybGllc3Q6IHJlcSh0aWNrKSwgbGF0ZXN0OiByZXEodGljayksIGNhbGVuZGFySWQsIHByZWNpc2lvbjogcmVxKHR4dCgpKSB9KTtcbiAgICBjYXNlICdyZWxhdGl2ZSc6IHJldHVybiBvYmooeyBtb2RlOiByZXEoZW4oJ3JlbGF0aXZlJykpLCBhbmNob3JFdmVudElkOiByZXEocmVmKCdldmVudCcpKSwgYW5jaG9yUG9pbnQ6IHJlcShlbignc3RhcnQnLCAnZW5kJykpLCBtaW5PZmZzZXQ6IHJlcSh0aWNrKSwgbWF4T2Zmc2V0OiByZXEodGljaykgfSk7XG4gICAgY2FzZSAndW5rbm93bic6IHJldHVybiBvYmooeyBtb2RlOiByZXEoZW4oJ3Vua25vd24nKSksIHJlYXNvbjogcmVxKHR4dCgpKSB9KTtcbiAgICBkZWZhdWx0OiByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59XG5mdW5jdGlvbiBxdWVyeVNjaGVtYSh2YWx1ZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBTY2hlbWEgfCB1bmRlZmluZWQge1xuICBzd2l0Y2ggKHZhbHVlLm9wKSB7XG4gICAgY2FzZSAnYWxsJzogY2FzZSAnYW55JzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ2FsbCcsICdhbnknKSksIGNoaWxkcmVuOiByZXEoYXJyKHsgdHlwZTogJ3F1ZXJ5JyB9LCBmYWxzZSwgMSwgMjU2KSkgfSk7XG4gICAgY2FzZSAna2luZCc6IHJldHVybiBvYmooeyBvcDogcmVxKGVuKCdraW5kJykpLCB2YWx1ZTogcmVxKGVuKC4uLkVOVElUWV9LSU5EUykpIH0pO1xuICAgIGNhc2UgJ3RleHQnOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbigndGV4dCcpKSwgdmFsdWU6IHJlcSh0eHQoKSkgfSk7XG4gICAgY2FzZSAnc3RhdHVzJzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ3N0YXR1cycpKSwgdmFsdWU6IHJlcShlbiguLi5TVEFUVVNFUykpIH0pO1xuICAgIGNhc2UgJ3BhcnRpY2lwYW50JzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ3BhcnRpY2lwYW50JykpLCBjaGFyYWN0ZXJJZDogcmVxKHJlZignY2hhcmFjdGVyJykpIH0pO1xuICAgIGNhc2UgJ3Byb2R1Y3Rpb24nOiByZXR1cm4gb2JqKHsgb3A6IHJlcShlbigncHJvZHVjdGlvbicpKSwgdmFsdWU6IHJlcShlbigndG9kbycsICdkb2luZycsICdkb25lJywgJ25lZWRzX3JldmlldycpKSB9KTtcbiAgICBjYXNlICdjaGFwdGVyJzogcmV0dXJuIG9iaih7IG9wOiByZXEoZW4oJ2NoYXB0ZXInKSksIGNoYXB0ZXJJZDogcmVxKHJlZignY2hhcHRlcicpKSB9KTtcbiAgICBjYXNlICdmb3Jlc2hhZG93JzogcmV0dXJuIG9iaih7XG4gICAgICBvcDogcmVxKGVuKCdmb3Jlc2hhZG93JykpLFxuICAgICAgZm9yZXNoYWRvd0lkOiBvcHRpb25hbFZhbHVlKHJlZignZm9yZXNoYWRvdycpKSxcbiAgICAgIHJlc29sdXRpb25Qb2xpY3k6IG9wdGlvbmFsVmFsdWUoZW4oJ3RoaXNfd29yaycsICdzZXF1ZWwnLCAnaW50ZW50aW9uYWxfb3BlbicsICdyZWRfaGVycmluZycsICd1bmRlY2lkZWQnLCAncmVqZWN0ZWQnKSksXG4gICAgICByb2xlOiBvcHRpb25hbFZhbHVlKGVuKCdjbHVlJywgJ3BheW9mZicpKSxcbiAgICAgIHN0YWdlOiBvcHRpb25hbFZhbHVlKGVuKCdoaW50JywgJ3N1c3BpY2lvbicsICdyZWluZm9yY2UnLCAncmV2ZWFsJywgJ2FsdGVybmF0aXZlJykpLFxuICAgIH0pO1xuICAgIGRlZmF1bHQ6IHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbn1cbmZ1bmN0aW9uIG5hbWVQb2xpY3lTY2hlbWEodmFsdWU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogU2NoZW1hIHwgdW5kZWZpbmVkIHtcbiAgaWYgKCEoJ21vZGUnIGluIHZhbHVlKSkge1xuICAgIGNvbnN0IHBvbGljeSA9IHVuaW9uKC4uLlsnYWxpYXMnLCAncmVwbGFjZScsICdleGNsdWRlJywgJ2Fub255bWl6ZSddLm1hcChtb2RlID0+IG5hbWVQb2xpY3lTY2hlbWEoeyBtb2RlIH0pISkpO1xuICAgIHJldHVybiBvYmooeyBkZWZhdWx0UG9saWN5OiBvcHQocG9saWN5KSwgYnlFbnRpdHlJZDogb3B0KHJlY29yZChwb2xpY3ksIHJlZigpKSkgfSk7XG4gIH1cbiAgc3dpdGNoICh2YWx1ZS5tb2RlKSB7XG4gICAgY2FzZSAnYWxpYXMnOiByZXR1cm4gb2JqKHsgbW9kZTogcmVxKGVuKCdhbGlhcycpKSwgYWxpYXNJZDogcmVxKHNjb3BlZFJlZignYWxpYXMnKSkgfSk7XG4gICAgY2FzZSAncmVwbGFjZSc6IHJldHVybiBvYmooeyBtb2RlOiByZXEoZW4oJ3JlcGxhY2UnKSksIHJlcGxhY2VtZW50OiByZXEodHh0KDEsIDEyOCkpIH0pO1xuICAgIGNhc2UgJ2V4Y2x1ZGUnOiByZXR1cm4gb2JqKHsgbW9kZTogcmVxKGVuKCdleGNsdWRlJykpIH0pO1xuICAgIGNhc2UgJ2Fub255bWl6ZSc6IHJldHVybiBvYmooeyBtb2RlOiByZXEoZW4oJ2Fub255bWl6ZScpKSwgcHVibGljSWQ6IHJlcShpZFNjaGVtYSksIHB1YmxpY05hbWU6IHJlcSh0eHQoMSwgMTI4KSkgfSk7XG4gICAgZGVmYXVsdDogcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuaW50ZXJmYWNlIEFzdEJ1ZGdldCB7IGNvdW50ZXI6IHsgY291bnQ6IG51bWJlciB9OyBkZXB0aDogbnVtYmVyIH1cbmNvbnN0IHRleHRTcGFuID0geyBzdGFydDogcmVxKG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSwgZW5kOiByZXEobnVtKDAsIHVuZGVmaW5lZCwgdHJ1ZSkpIH07XG5jb25zdCByaWNoVGV4dEJsb2NrcyA9IGFycihvYmooeyBpZDogcmVxKGlkU2NoZW1hKSwga2luZDogcmVxKGVuKCdwYXJhZ3JhcGgnLCAnaGVhZGluZycsICdsaXN0X2l0ZW0nLCAncXVvdGUnKSksIHRleHQ6IHJlcSh0eHQoKSksIHJ1Ynk6IG9wdChhcnIob2JqKHsgLi4udGV4dFNwYW4sIHRleHQ6IHJlcSh0eHQoKSkgfSkpKSwgbGlua3M6IG9wdChhcnIob2JqKHsgLi4udGV4dFNwYW4sIHRhcmdldDogcmVxKGFuY2hvcikgfSkpKSwgdW5yZXNvbHZlZEFubm90YXRpb25zOiBvcHQoYXJyKHVucmVzb2x2ZWRUZXh0QW5ub3RhdGlvbikpIH0pKTtcbmZ1bmN0aW9uIHdhbGsoc2NoZW1hOiBTY2hlbWEsIHZhbHVlOiB1bmtub3duLCBwYXRoOiBzdHJpbmcsIGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10sIHJlZmVyZW5jZXM6IERvbWFpblJlZmVyZW5jZVtdLCBkZXB0aCA9IDAsIGFzdD86IEFzdEJ1ZGdldCk6IHZvaWQge1xuICBpZiAoaXNzdWVzLmxlbmd0aCA+PSAyNTYpIHJldHVybjtcbiAgaWYgKGRlcHRoID4gMzIpIHsgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn5qeL6YCg44Gu5rex44GV44GM5LiK6ZmQMzLjgpLotoXjgYjjgabjgYTjgb7jgZnjgIInLCAnSU1QT1JUX0xJTUlUJyk7IHJldHVybjsgfVxuICBjb25zdCBmYWlsID0gKG1lc3NhZ2U6IHN0cmluZyk6IHZvaWQgPT4gYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCBtZXNzYWdlKTtcbiAgc3dpdGNoIChzY2hlbWEudHlwZSkge1xuICAgIGNhc2UgJ2pzb24nOiB7XG4gICAgICBjb25zdCB2aXNpdCA9IChpdGVtOiB1bmtub3duLCBpdGVtUGF0aDogc3RyaW5nLCBsZXZlbDogbnVtYmVyLCBzZWVuOiBTZXQ8b2JqZWN0Pik6IHZvaWQgPT4ge1xuICAgICAgICBpZiAobGV2ZWwgPiAxMDApIHsgYWRkSXNzdWUoaXNzdWVzLCBpdGVtUGF0aCwgJ0pTT07pmo7lsaTjga7kuIrpmZDjgpLotoXjgYjjgabjgYTjgb7jgZnjgIInLCAnSU1QT1JUX0xJTUlUJyk7IHJldHVybjsgfVxuICAgICAgICBpZiAoaXRlbSA9PT0gbnVsbCB8fCB0eXBlb2YgaXRlbSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIGl0ZW0gPT09ICdib29sZWFuJykgcmV0dXJuO1xuICAgICAgICBpZiAodHlwZW9mIGl0ZW0gPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZShpdGVtKSkgcmV0dXJuO1xuICAgICAgICBpZiAoIWl0ZW0gfHwgdHlwZW9mIGl0ZW0gIT09ICdvYmplY3QnIHx8IHNlZW4uaGFzKGl0ZW0pKSB7IGFkZElzc3VlKGlzc3VlcywgaXRlbVBhdGgsICfpgJrluLjjga5KU09O5YCk44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7IHJldHVybjsgfVxuICAgICAgICBzZWVuLmFkZChpdGVtKTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaXRlbSkpIGl0ZW0uZm9yRWFjaCgoY2hpbGQsIGluZGV4KSA9PiB2aXNpdChjaGlsZCwgYCR7aXRlbVBhdGh9WyR7aW5kZXh9XWAsIGxldmVsICsgMSwgc2VlbikpO1xuICAgICAgICBlbHNlIGlmIChPYmplY3QuZ2V0UHJvdG90eXBlT2YoaXRlbSkgPT09IE9iamVjdC5wcm90b3R5cGUgfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKGl0ZW0pID09PSBudWxsKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBba2V5LCBjaGlsZF0gb2YgT2JqZWN0LmVudHJpZXMoaXRlbSkpIHtcbiAgICAgICAgICAgIGlmIChbJ19fcHJvdG9fXycsICdwcm90b3R5cGUnLCAnY29uc3RydWN0b3InXS5pbmNsdWRlcyhrZXkpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2l0ZW1QYXRofS4ke2tleX1gLCAn5LqI57SE5riI44G/44Gu44Kt44O844Gv5L2/44GI44G+44Gb44KT44CCJyk7XG4gICAgICAgICAgICBlbHNlIHZpc2l0KGNoaWxkLCBgJHtpdGVtUGF0aH0uJHtrZXl9YCwgbGV2ZWwgKyAxLCBzZWVuKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBhZGRJc3N1ZShpc3N1ZXMsIGl0ZW1QYXRoLCAn6YCa5bi444GuSlNPTuOCquODluOCuOOCp+OCr+ODiOOCkuaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgICAgICBzZWVuLmRlbGV0ZShpdGVtKTtcbiAgICAgIH07XG4gICAgICB2aXNpdCh2YWx1ZSwgcGF0aCwgMCwgbmV3IFNldCgpKTsgcmV0dXJuO1xuICAgIH1cbiAgICBjYXNlICd0ZXh0Jzoge1xuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycpIHsgZmFpbCgn5paH5a2X5YiX44KS5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJyk7IHJldHVybjsgfVxuICAgICAgaWYgKCF2YWxpZFVuaWNvZGUodmFsdWUpKSBmYWlsKCfmloflrZfliJfjgavkuI3mraPjgapVbmljb2Rl44GM44GC44KK44G+44GZ44CCJyk7XG4gICAgICBjb25zdCBjb3VudCA9IGNvZGVQb2ludExlbmd0aCh2YWx1ZSk7XG4gICAgICBpZiAoc2NoZW1hLm1pbiAhPT0gdW5kZWZpbmVkICYmIGNvdW50IDwgc2NoZW1hLm1pbikgZmFpbChgJHtzY2hlbWEubWlufeaWh+Wtl+S7peS4iuOBp+WFpeWKm+OBl+OBpuOBj+OBoOOBleOBhOOAgmApO1xuICAgICAgaWYgKHNjaGVtYS5tYXggIT09IHVuZGVmaW5lZCAmJiBjb3VudCA+IHNjaGVtYS5tYXgpIGZhaWwoYCR7c2NoZW1hLm1heH3mloflrZfku6XlhoXjgaflhaXlipvjgZfjgabjgY/jgaDjgZXjgYTjgIJgKTtcbiAgICAgIGlmIChzY2hlbWEubWF4Qnl0ZXMgIT09IHVuZGVmaW5lZCAmJiB1dGY4Qnl0ZXModmFsdWUpID4gc2NoZW1hLm1heEJ5dGVzKSBmYWlsKCfmnKzmlofjgYwxIE1pQuOBruS4iumZkOOCkui2heOBiOOBpuOBhOOBvuOBmeOAgicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjYXNlICdudW1iZXInOlxuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ251bWJlcicgfHwgIU51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgfHwgKHNjaGVtYS5pbnRlZ2VyICYmICFOdW1iZXIuaXNTYWZlSW50ZWdlcih2YWx1ZSkpKSBmYWlsKHNjaGVtYS5pbnRlZ2VyID8gJ+WuieWFqOOBquevhOWbsuOBruaVtOaVsOOCkuWFpeWKm+OBl+OBpuOBj+OBoOOBleOBhOOAgicgOiAn5pyJ6ZmQ44Gu5pWw5YCk44KS5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgICBlbHNlIGlmICgoc2NoZW1hLm1pbiAhPT0gdW5kZWZpbmVkICYmIHZhbHVlIDwgc2NoZW1hLm1pbikgfHwgKHNjaGVtYS5tYXggIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSA+IHNjaGVtYS5tYXgpKSBmYWlsKCfmlbDlgKTjgYzoqLHlrrnnr4Tlm7LlpJbjgafjgZnjgIInKTtcbiAgICAgIHJldHVybjtcbiAgICBjYXNlICdib29sZWFuJzogaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ2Jvb2xlYW4nKSBmYWlsKCfnnJ/lgb3lgKTjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTsgcmV0dXJuO1xuICAgIGNhc2UgJ2VudW0nOiBpZiAoIXNjaGVtYS52YWx1ZXMuaW5jbHVkZXModmFsdWUgYXMgc3RyaW5nIHwgYm9vbGVhbiB8IG51bGwpKSBmYWlsKCflrqPoqIDjgZXjgozjgZ/lgKTjgpLpgbjjgpPjgafjgY/jgaDjgZXjgYTjgIInKTsgcmV0dXJuO1xuICAgIGNhc2UgJ2lkJzogaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgfHwgIUlEX1BBVFRFUk4udGVzdCh2YWx1ZSkpIGZhaWwoJ+Wwj+aWh+Wtl+OBrlVVSUTjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTsgcmV0dXJuO1xuICAgIGNhc2UgJ3JlZic6IHtcbiAgICAgIGNvbnN0IHZhbGlkID0gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiAoc2NoZW1hLnNjb3BlID09PSAnY2FsZW5kYXInID8gdmFsdWUubGVuZ3RoID4gMCA6IElEX1BBVFRFUk4udGVzdCh2YWx1ZSkpO1xuICAgICAgaWYgKCF2YWxpZCkgZmFpbChzY2hlbWEuc2NvcGUgPT09ICdjYWxlbmRhcicgPyAn5pqmSUTjgYzlv4XopoHjgafjgZnjgIInIDogJ+WPgueFp+WFiOOBr+Wwj+aWh+Wtl1VVSUTjgafjgZnjgIInKTtcbiAgICAgIC8vIEtlZXAgdHlwZWQgc3RyaW5nIHBhdGhzIGZvciBleHBsaWNpdCBwdWJsaWMtdG8tbmF0aXZlIElEIGNvbnZlcnNpb24uXG4gICAgICAvLyBGb3JtYXQgdmFsaWRhdGlvbiBhYm92ZSBzdGlsbCByZWplY3RzIHRoZW0gYXQgZXZlcnkgbmF0aXZlIGJvdW5kYXJ5LlxuICAgICAgaWYodHlwZW9mIHZhbHVlPT09J3N0cmluZycpcmVmZXJlbmNlcy5wdXNoKHsgaWQ6IHZhbHVlLCBwYXRoLCBraW5kczogc2NoZW1hLmtpbmRzLCBzY29wZTogc2NoZW1hLnNjb3BlID8/ICdlbnRpdHknIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjYXNlICd0aWNrJzogaWYgKCFpc1RpY2sodmFsdWUpKSBmYWlsKCd0aWNr44GvMzjmoYHku6XlhoXjga7mraPopo/mlbTmlbDmloflrZfliJfjgafjgZnjgIInKTsgcmV0dXJuO1xuICAgIGNhc2UgJ3JldmlzaW9uJzogaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgfHwgIVJFVklTSU9OX1BBVFRFUk4udGVzdCh2YWx1ZSkpIGZhaWwoJ3JldmlzaW9u44GvMOS7peS4iuOBruaVtOaVsOaWh+Wtl+WIl+OBp+OBmeOAgicpOyByZXR1cm47XG4gICAgY2FzZSAnZGF0ZXRpbWUnOlxuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgfHwgIS9eXFxkezR9LVxcZHsyfS1cXGR7Mn1UKD86WzAxXVswLTldfDJbMC0zXSk6WzAtNV1bMC05XTpbMC01XVswLTldKD86XFwuXFxkKyk/KD86WnxcXCswMDowMCkkLy50ZXN0KHZhbHVlKSB8fCAhTnVtYmVyLmlzRmluaXRlKERhdGUucGFyc2UodmFsdWUpKSB8fCAhdmFsaWREYXRlKHZhbHVlLnNsaWNlKDAsIDEwKSkpIGZhaWwoJ1VUQ+OBrlJGQyAzMzM55pel5pmC44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgICByZXR1cm47XG4gICAgY2FzZSAnZGF0ZSc6IGlmICh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnIHx8ICF2YWxpZERhdGUodmFsdWUpKSBmYWlsKCflrp/lnKjjgZnjgotZWVlZLU1NLURE5b2i5byP44Gu5pel5LuY44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7IHJldHVybjtcbiAgICBjYXNlICdoYXNoJzogaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgfHwgIS9eWzAtOWEtZl17NjR9JC8udGVzdCh2YWx1ZSkpIGZhaWwoJ1NIQS0yNTbjga/lsI/mloflrZcxNumAsuaVsDY05paH5a2X44Gn44GZ44CCJyk7IHJldHVybjtcbiAgICBjYXNlICdzYWZlX3BhdGgnOlxuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgfHwgIXZhbHVlIHx8IHZhbHVlLnN0YXJ0c1dpdGgoJy8nKSB8fCB2YWx1ZS5pbmNsdWRlcygnXFxcXCcpIHx8IHZhbHVlLmluY2x1ZGVzKCdcXDAnKSB8fCAvXlthLXpBLVpdOi8udGVzdCh2YWx1ZSkgfHwgdmFsdWUuc3BsaXQoJy8nKS5zb21lKHBhcnQgPT4gIXBhcnQgfHwgcGFydCA9PT0gJy4nIHx8IHBhcnQgPT09ICcuLicpIHx8IC9bXFx1MDAwMC1cXHUwMDFmXFx1MDA3Zl0vLnRlc3QodmFsdWUpKSBmYWlsKCflronlhajjgarnm7jlr77jg5HjgrnjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgICAgIHJldHVybjtcbiAgICBjYXNlICdhcnJheSc6IHtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHsgZmFpbCgn6YWN5YiX44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7IHJldHVybjsgfVxuICAgICAgaWYgKHZhbHVlLmxlbmd0aCA+IChzY2hlbWEubWF4ID8/IDEwMF8wMDApIHx8IChzY2hlbWEubWluICE9PSB1bmRlZmluZWQgJiYgdmFsdWUubGVuZ3RoIDwgc2NoZW1hLm1pbikpIHsgZmFpbCgn6YWN5YiX44Gu5Lu25pWw44GM6Kix5a6556+E5Zuy5aSW44Gn44GZ44CCJyk7IHJldHVybjsgfVxuICAgICAgaWYgKHNjaGVtYS51bmlxdWUgJiYgbmV3IFNldCh2YWx1ZS5tYXAoaXRlbSA9PiB0eXBlb2YgaXRlbSA9PT0gJ29iamVjdCcgPyBKU09OLnN0cmluZ2lmeShpdGVtKSA6IGl0ZW0pKS5zaXplICE9PSB2YWx1ZS5sZW5ndGgpIGZhaWwoJ+WQjOOBmOWApOOCkumbhuWQiOWGheOBp+mHjeikh+S/neWtmOOBp+OBjeOBvuOBm+OCk+OAgicpO1xuICAgICAgdmFsdWUuZm9yRWFjaCgoaXRlbSwgaSkgPT4gd2FsayhzY2hlbWEuaXRlbSwgaXRlbSwgYCR7cGF0aH1bJHtpfV1gLCBpc3N1ZXMsIHJlZmVyZW5jZXMsIGRlcHRoICsgMSwgYXN0KSk7IHJldHVybjtcbiAgICB9XG4gICAgY2FzZSAnb2JqZWN0Jzoge1xuICAgICAgaWYgKCFpc09iamVjdCh2YWx1ZSkpIHsgZmFpbCgn44Kq44OW44K444Kn44Kv44OI44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7IHJldHVybjsgfVxuICAgICAgZm9yIChjb25zdCBmaWVsZCBvZiBPYmplY3Qua2V5cyh2YWx1ZSkpIGlmICghT2JqZWN0Lmhhc093bihzY2hlbWEuZmllbGRzLCBmaWVsZCkpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtmaWVsZH1gLCAn5pyq55+l44Gu6aCF55uu44Gv5L+d5a2Y44Gn44GN44G+44Gb44KT44CCJyk7XG4gICAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIE9iamVjdC5rZXlzKHNjaGVtYS5maWVsZHMpKSB7XG4gICAgICAgIGNvbnN0IGRlZmluaXRpb24gPSBzY2hlbWEuZmllbGRzW2ZpZWxkXSE7XG4gICAgICAgIGNvbnN0IGl0ZW0gPSB2YWx1ZVtmaWVsZF0sIGZpZWxkUGF0aCA9IGAke3BhdGh9LiR7ZmllbGR9YDtcbiAgICAgICAgaWYgKGl0ZW0gPT09IHVuZGVmaW5lZCkgeyBpZiAoZGVmaW5pdGlvbi5yZXF1aXJlZCkgYWRkSXNzdWUoaXNzdWVzLCBmaWVsZFBhdGgsICflv4XpoIjpoIXnm67jgafjgZnjgIInKTsgY29udGludWU7IH1cbiAgICAgICAgaWYgKGl0ZW0gPT09IG51bGwgJiYgZGVmaW5pdGlvbi5udWxsYWJsZSkgY29udGludWU7XG4gICAgICAgIHdhbGsoZGVmaW5pdGlvbi5zY2hlbWEsIGl0ZW0sIGZpZWxkUGF0aCwgaXNzdWVzLCByZWZlcmVuY2VzLCBkZXB0aCArIDEsIGFzdCk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNhc2UgJ3JlY29yZCc6XG4gICAgICBpZiAoIWlzT2JqZWN0KHZhbHVlKSkgeyBmYWlsKCfpoIXnm67jga7ovp7mm7jjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTsgcmV0dXJuOyB9XG4gICAgICBmb3IgKGNvbnN0IFtmaWVsZCwgaXRlbV0gb2YgT2JqZWN0LmVudHJpZXModmFsdWUpKSB7XG4gICAgICAgIGlmIChbJ19fcHJvdG9fXycsICdwcm90b3R5cGUnLCAnY29uc3RydWN0b3InXS5pbmNsdWRlcyhmaWVsZCkpIHsgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS4ke2ZpZWxkfWAsICfkuojntITmuIjjgb/jga7jgq3jg7zjga/kvb/jgYjjgb7jgZvjgpPjgIInKTsgY29udGludWU7IH1cbiAgICAgICAgaWYgKHNjaGVtYS5rZXkpIHdhbGsoc2NoZW1hLmtleSwgZmllbGQsIGAke3BhdGh9LiR7ZmllbGR9LiRrZXlgLCBpc3N1ZXMsIHJlZmVyZW5jZXMsIGRlcHRoICsgMSwgYXN0KTtcbiAgICAgICAgd2FsayhzY2hlbWEudmFsdWUsIGl0ZW0sIGAke3BhdGh9LiR7ZmllbGR9YCwgaXNzdWVzLCByZWZlcmVuY2VzLCBkZXB0aCArIDEsIGFzdCk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgY2FzZSAndW5pb24nOiB7XG4gICAgICBsZXQgc2hvcnRlc3Q6IFZhbGlkYXRpb25Jc3N1ZVtdIHwgdW5kZWZpbmVkO1xuICAgICAgZm9yIChjb25zdCBjaG9pY2Ugb2Ygc2NoZW1hLmNob2ljZXMpIHtcbiAgICAgICAgY29uc3QgYnJhbmNoSXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSA9IFtdLCBicmFuY2hSZWZzOiBEb21haW5SZWZlcmVuY2VbXSA9IFtdO1xuICAgICAgICB3YWxrKGNob2ljZSwgdmFsdWUsIHBhdGgsIGJyYW5jaElzc3VlcywgYnJhbmNoUmVmcywgZGVwdGggKyAxLCBhc3QpO1xuICAgICAgICBpZiAoIWJyYW5jaElzc3Vlcy5sZW5ndGgpIHsgcmVmZXJlbmNlcy5wdXNoKC4uLmJyYW5jaFJlZnMpOyByZXR1cm47IH1cbiAgICAgICAgaWYgKCFzaG9ydGVzdCB8fCBicmFuY2hJc3N1ZXMubGVuZ3RoIDwgc2hvcnRlc3QubGVuZ3RoKSBzaG9ydGVzdCA9IGJyYW5jaElzc3VlcztcbiAgICAgIH1cbiAgICAgIGlzc3Vlcy5wdXNoKC4uLihzaG9ydGVzdCA/PyBbeyBjb2RlOiAnVkFMSURBVElPTl9GQUlMRUQnIGFzIGNvbnN0LCBwYXRoLCBtZXNzYWdlOiAn5a++5b+c44GZ44KL5Z6L44Gn44Gv44GC44KK44G+44Gb44KT44CCJyB9XSkpOyByZXR1cm47XG4gICAgfVxuICAgIGNhc2UgJ3R5cGVkJzoge1xuICAgICAgaWYgKCFpc09iamVjdCh2YWx1ZSkpIHsgZmFpbCgn5Z6L44Go5YCk44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7IHJldHVybjsgfVxuICAgICAgbGV0IHZhbHVlU2NoZW1hOiBTY2hlbWE7XG4gICAgICBzd2l0Y2ggKHZhbHVlLnR5cGUpIHtcbiAgICAgICAgY2FzZSAnYm9vbGVhbic6IHZhbHVlU2NoZW1hID0gYm9vbDsgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2ludGVnZXInOiB2YWx1ZVNjaGVtYSA9IG51bSh1bmRlZmluZWQsIHVuZGVmaW5lZCwgdHJ1ZSk7IGJyZWFrO1xuICAgICAgICBjYXNlICdlbnVtJzogY2FzZSAndGV4dCc6IHZhbHVlU2NoZW1hID0gdHh0KCk7IGJyZWFrO1xuICAgICAgICBjYXNlICdyZWYnOiB2YWx1ZVNjaGVtYSA9IHJlZigpOyBicmVhaztcbiAgICAgICAgY2FzZSAndW5rbm93bic6IHdhbGsob2JqKHsgdHlwZTogcmVxKGVuKCd1bmtub3duJykpLCB2YWx1ZTogeyBzY2hlbWE6IHR4dCgpLCByZXF1aXJlZDogdHJ1ZSwgbnVsbGFibGU6IHRydWUgfSwgcmVhc29uOiByZXEodHh0KCkpIH0pLCB2YWx1ZSwgcGF0aCwgaXNzdWVzLCByZWZlcmVuY2VzLCBkZXB0aCArIDEsIGFzdCk7IGlmICh2YWx1ZS52YWx1ZSAhPT0gbnVsbCkgZmFpbCgn5pyq5a6a5YCk44GudmFsdWXjga9udWxs44Gn44GZ44CCJyk7IHJldHVybjtcbiAgICAgICAgZGVmYXVsdDogZmFpbCgn5pyq55+l44Gu5YCk5Z6L44Gn44GZ44CCJyk7IHJldHVybjtcbiAgICAgIH1cbiAgICAgIHdhbGsob2JqKHsgdHlwZTogcmVxKGVuKHZhbHVlLnR5cGUgYXMgc3RyaW5nKSksIHZhbHVlOiByZXEodmFsdWVTY2hlbWEpIH0pLCB2YWx1ZSwgcGF0aCwgaXNzdWVzLCByZWZlcmVuY2VzLCBkZXB0aCArIDEsIGFzdCk7IHJldHVybjtcbiAgICB9XG4gICAgY2FzZSAnY3VzdG9tJzpcbiAgICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuO1xuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHdhbGsodHh0KCksIHZhbHVlLCBwYXRoLCBpc3N1ZXMsIHJlZmVyZW5jZXMsIGRlcHRoLCBhc3QpO1xuICAgICAgZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykgd2FsayhudW0oKSwgdmFsdWUsIHBhdGgsIGlzc3VlcywgcmVmZXJlbmNlcywgZGVwdGgsIGFzdCk7XG4gICAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuO1xuICAgICAgZWxzZSBpZiAoaXNPYmplY3QodmFsdWUpICYmIHZhbHVlLnR5cGUgPT09ICdyZWYnKSB3YWxrKG9iaih7IHR5cGU6IHJlcShlbigncmVmJykpLCB2YWx1ZTogcmVxKHJlZigpKSB9KSwgdmFsdWUsIHBhdGgsIGlzc3VlcywgcmVmZXJlbmNlcywgZGVwdGggKyAxLCBhc3QpO1xuICAgICAgZWxzZSBpZiAoaXNPYmplY3QodmFsdWUpICYmIHZhbHVlLnR5cGUgPT09ICdkYXRlJykgd2FsayhvYmooeyB0eXBlOiByZXEoZW4oJ2RhdGUnKSksIHZhbHVlOiByZXEoeyB0eXBlOiAnZGF0ZScgfSkgfSksIHZhbHVlLCBwYXRoLCBpc3N1ZXMsIHJlZmVyZW5jZXMsIGRlcHRoICsgMSwgYXN0KTtcbiAgICAgIGVsc2UgZmFpbCgn44Kr44K544K/44Og5YCk44Gv5paH5a2X5YiX44O75pWw5YCk44O755yf5YG944O75pel5LuY44O75Y+C54Wn44G+44Gf44GvbnVsbOOBp+OBmeOAgicpO1xuICAgICAgcmV0dXJuO1xuICAgIGNhc2UgJ3JpY2h0ZXh0Jzoge1xuICAgICAgd2FsayhyaWNoVGV4dEJsb2NrcywgdmFsdWUsIHBhdGgsIGlzc3VlcywgcmVmZXJlbmNlcywgZGVwdGggKyAxLCBhc3QpO1xuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuO1xuICAgICAgbGV0IGJ5dGVzID0gMCwgY2hhcnMgPSAwOyBjb25zdCBibG9ja0lkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAgICAgdmFsdWUuZm9yRWFjaCgoYmxvY2s6IHVua25vd24sIGkpID0+IHtcbiAgICAgICAgaWYgKCFpc09iamVjdChibG9jaykgfHwgdHlwZW9mIGJsb2NrLnRleHQgIT09ICdzdHJpbmcnKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGxlbmd0aCA9IGNvZGVQb2ludExlbmd0aChibG9jay50ZXh0KTtcbiAgICAgICAgYnl0ZXMgKz0gdXRmOEJ5dGVzKGJsb2NrLnRleHQpOyBjaGFycyArPSBsZW5ndGg7XG4gICAgICAgIGlmICh0eXBlb2YgYmxvY2suaWQgPT09ICdzdHJpbmcnKSB7IGlmIChibG9ja0lkcy5oYXMoYmxvY2suaWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9WyR7aX1dLmlkYCwgJ+auteiQvUlE44GM6YeN6KSH44GX44Gm44GE44G+44GZ44CCJyk7IGJsb2NrSWRzLmFkZChibG9jay5pZCk7IH1cbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYmxvY2sudW5yZXNvbHZlZEFubm90YXRpb25zKSkgZm9yIChjb25zdCBhbm5vdGF0aW9uIG9mIGJsb2NrLnVucmVzb2x2ZWRBbm5vdGF0aW9ucykgaWYgKGlzT2JqZWN0KGFubm90YXRpb24pKSBmb3IgKGNvbnN0IGZpZWxkIG9mIFsnb3JpZ2luYWxUZXh0JywgJ3JlYXNvbicsICdyZWFkaW5nJ10pIGlmICh0eXBlb2YgYW5ub3RhdGlvbltmaWVsZF0gPT09ICdzdHJpbmcnKSBieXRlcyArPSB1dGY4Qnl0ZXMoYW5ub3RhdGlvbltmaWVsZF0gYXMgc3RyaW5nKTtcbiAgICAgICAgZm9yIChjb25zdCBmaWVsZCBvZiBbJ3J1YnknLCAnbGlua3MnXSkgaWYgKEFycmF5LmlzQXJyYXkoYmxvY2tbZmllbGRdKSkgKGJsb2NrW2ZpZWxkXSBhcyB1bmtub3duW10pLmZvckVhY2goKHJhbmdlLCBqKSA9PiB7XG4gICAgICAgICAgaWYgKCFpc09iamVjdChyYW5nZSkpIHJldHVybjtcbiAgICAgICAgICBpZiAodHlwZW9mIHJhbmdlLnN0YXJ0ID09PSAnbnVtYmVyJyAmJiB0eXBlb2YgcmFuZ2UuZW5kID09PSAnbnVtYmVyJyAmJiAocmFuZ2Uuc3RhcnQgPj0gcmFuZ2UuZW5kIHx8IHJhbmdlLmVuZCA+IGxlbmd0aCkpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH1bJHtpfV0uJHtmaWVsZH1bJHtqfV1gLCAn5paH5a2X56+E5Zuy44Gv44Kz44O844OJ44Od44Kk44Oz44OI44Gn5pWw44GI44CB5pys5paH5YaF44Gu5Y2K6ZaL5Yy66ZaT44KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgICAgICAgaWYgKHR5cGVvZiByYW5nZS50ZXh0ID09PSAnc3RyaW5nJykgYnl0ZXMgKz0gdXRmOEJ5dGVzKHJhbmdlLnRleHQpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgaWYgKGJ5dGVzID4gMTAyNCAqIDEwMjQpIGZhaWwoJ+acrOaWh+ODleOCo+ODvOODq+ODieOBjDEgTWlC44KS6LaF44GI44Gm44GE44G+44GZ44CCJyk7XG4gICAgICBpZiAoc2NoZW1hLm1heCAhPT0gdW5kZWZpbmVkICYmIGNoYXJzID4gc2NoZW1hLm1heCkgZmFpbChg6KaB57SE44GvJHtzY2hlbWEubWF4feaWh+Wtl+S7peWGheOBp+OBmeOAgmApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjYXNlICdjb25kaXRpb24nOiBjYXNlICdleHByZXNzaW9uJzoge1xuICAgICAgY29uc3QgYnVkZ2V0ID0gYXN0ID8/IHsgY291bnRlcjogeyBjb3VudDogMCB9LCBkZXB0aDogMCB9OyBidWRnZXQuY291bnRlci5jb3VudCsrO1xuICAgICAgaWYgKGJ1ZGdldC5jb3VudGVyLmNvdW50ID4gMjU2IHx8IGJ1ZGdldC5kZXB0aCA+PSAxNikgeyBmYWlsKCfmnaHku7bjg7vlvI/jga/mt7HjgZUxNuOAgeODjuODvOODiTI1NuOBvuOBp+OBp+OBmeOAgicpOyByZXR1cm47IH1cbiAgICAgIGlmICghaXNPYmplY3QodmFsdWUpKSB7IGZhaWwoJ+adoeS7tuODu+W8j+OBr+Wei+S7mOOBjUFTVOOBp+aMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicpOyByZXR1cm47IH1cbiAgICAgIGNvbnN0IGRlZmluaXRpb24gPSBzY2hlbWEudHlwZSA9PT0gJ2NvbmRpdGlvbicgPyBjb25kaXRpb25TY2hlbWEodmFsdWUpIDogZXhwcmVzc2lvblNjaGVtYSh2YWx1ZSk7XG4gICAgICBpZiAoIWRlZmluaXRpb24pIHsgZmFpbCgn5pyq55+l44Gu5p2h5Lu244O75byPb3DjgafjgZnjgIInKTsgcmV0dXJuOyB9XG4gICAgICB3YWxrKGRlZmluaXRpb24sIHZhbHVlLCBwYXRoLCBpc3N1ZXMsIHJlZmVyZW5jZXMsIDAsIHsgY291bnRlcjogYnVkZ2V0LmNvdW50ZXIsIGRlcHRoOiBidWRnZXQuZGVwdGggKyAxIH0pOyByZXR1cm47XG4gICAgfVxuICAgIGNhc2UgJ3RpbWUnOiB7XG4gICAgICBpZiAoIWlzT2JqZWN0KHZhbHVlKSkgeyBmYWlsKCfml6XmmYLjga9UaW1lU3BlY+OBp+aMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicpOyByZXR1cm47IH1cbiAgICAgIGNvbnN0IGRlZmluaXRpb24gPSB0aW1lU2NoZW1hKHZhbHVlKTsgaWYgKCFkZWZpbml0aW9uKSB7IGZhaWwoJ+acquefpeOBruaXpeaZgm1vZGXjgafjgZnjgIInKTsgcmV0dXJuOyB9XG4gICAgICBjb25zdCBiZWZvcmUgPSBpc3N1ZXMubGVuZ3RoOyB3YWxrKGRlZmluaXRpb24sIHZhbHVlLCBwYXRoLCBpc3N1ZXMsIHJlZmVyZW5jZXMsIGRlcHRoICsgMSwgYXN0KTtcbiAgICAgIGlmIChpc3N1ZXMubGVuZ3RoID09PSBiZWZvcmUpIHtcbiAgICAgICAgaWYgKHZhbHVlLm1vZGUgPT09ICdpbnRlcnZhbCcgJiYgY29tcGFyZVRpY2tzKHZhbHVlLnN0YXJ0IGFzIHN0cmluZywgdmFsdWUuZW5kIGFzIHN0cmluZykgPj0gMCkgZmFpbCgn5pyf6ZaT44Gvc3RhcnQgPCBlbmTjga7ljYrplovljLrplpPjgafjgZnjgIInKTtcbiAgICAgICAgaWYgKHZhbHVlLm1vZGUgPT09ICd1bmNlcnRhaW4nICYmIGNvbXBhcmVUaWNrcyh2YWx1ZS5lYXJsaWVzdCBhcyBzdHJpbmcsIHZhbHVlLmxhdGVzdCBhcyBzdHJpbmcpID4gMCkgZmFpbCgnZWFybGllc3Tjga9sYXRlc3Tku6XkuIvjgafjgZnjgIInKTtcbiAgICAgICAgaWYgKHZhbHVlLm1vZGUgPT09ICdyZWxhdGl2ZScgJiYgY29tcGFyZVRpY2tzKHZhbHVlLm1pbk9mZnNldCBhcyBzdHJpbmcsIHZhbHVlLm1heE9mZnNldCBhcyBzdHJpbmcpID4gMCkgZmFpbCgnbWluT2Zmc2V044GvbWF4T2Zmc2V05Lul5LiL44Gn44GZ44CCJyk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNhc2UgJ3F1ZXJ5JzogY2FzZSAnbmFtZV9wb2xpY3knOiB7XG4gICAgICBpZiAoIWlzT2JqZWN0KHZhbHVlKSkgeyBmYWlsKCflnovku5jjgY3jga7jgqrjg5bjgrjjgqfjgq/jg4jjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTsgcmV0dXJuOyB9XG4gICAgICBjb25zdCBkZWZpbml0aW9uID0gc2NoZW1hLnR5cGUgPT09ICdxdWVyeScgPyBxdWVyeVNjaGVtYSh2YWx1ZSkgOiBuYW1lUG9saWN5U2NoZW1hKHZhbHVlKTtcbiAgICAgIGlmICghZGVmaW5pdGlvbikgeyBmYWlsKCfmnKrnn6Xjga7opo/liYfjgafjgZnjgIInKTsgcmV0dXJuOyB9XG4gICAgICBjb25zdCBiZWZvcmUgPSBpc3N1ZXMubGVuZ3RoO1xuICAgICAgd2FsayhkZWZpbml0aW9uLCB2YWx1ZSwgcGF0aCwgaXNzdWVzLCByZWZlcmVuY2VzLCBkZXB0aCArIDEsIGFzdCk7XG4gICAgICBpZiAoc2NoZW1hLnR5cGUgPT09ICdxdWVyeScgJiYgdmFsdWUub3AgPT09ICdmb3Jlc2hhZG93JyAmJiBpc3N1ZXMubGVuZ3RoID09PSBiZWZvcmVcbiAgICAgICAgJiYgIVsnZm9yZXNoYWRvd0lkJywgJ3Jlc29sdXRpb25Qb2xpY3knLCAncm9sZScsICdzdGFnZSddLnNvbWUoZmllbGQgPT4gdmFsdWVbZmllbGRdICE9PSB1bmRlZmluZWQgJiYgdmFsdWVbZmllbGRdICE9PSBudWxsKSkge1xuICAgICAgICBhZGRJc3N1ZShpc3N1ZXMsIHBhdGgsICfkvI/nt5rmpJzntKLjgavjga/lr77osaHjg7vlm57lj47mlrnph53jg7vplovnpLrlvbnlibLjg7vmrrXpmo7jga7jgYTjgZrjgozjgYvjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbn1cblxuY29uc3QgY29tbW9uRmllbGRzOiBSZWNvcmQ8c3RyaW5nLCBGaWVsZD4gPSB7IGlkOiByZXEoaWRTY2hlbWEpLCBwcm9qZWN0SWQ6IHJlcShzY29wZWRSZWYoJ3Byb2plY3QnKSksIGtpbmQ6IHJlcShlbiguLi5FTlRJVFlfS0lORFMpKSwgcmV2aXNpb246IHJlcSh7IHR5cGU6ICdyZXZpc2lvbicgfSksIG5hbWU6IHJlcShzaG9ydCksIHN0YXR1czogcmVxKGVuKC4uLlNUQVRVU0VTKSksIHZpc2liaWxpdHk6IHJlcShlbigncHJpdmF0ZScsICd0ZWFtJywgJ3Byb2plY3Rpb24nKSksIHJldGFpbklmVW5yZWZlcmVuY2VkOiBvcHQoYm9vbCksIHByb2plY3Rpb25Qcm9maWxlSWQ6IG9wdChyZWYoJ3Byb2plY3Rpb25fcHJvZmlsZScpKSwgdGVtcGxhdGVJZDogb3B0KHJlZigndGVtcGxhdGUnKSksIGNyZWF0ZWRBdDogcmVxKHsgdHlwZTogJ2RhdGV0aW1lJyB9KSwgdXBkYXRlZEF0OiByZXEoeyB0eXBlOiAnZGF0ZXRpbWUnIH0pLCBkZWxldGVkQXQ6IG9wdCh7IHR5cGU6ICdkYXRldGltZScgfSksIGRlbGV0aW9uT3BlcmF0aW9uSWQ6IG9wdChpZFNjaGVtYSksIGN1c3RvbVZhbHVlczogcmVxKHJlY29yZCh7IHR5cGU6ICdjdXN0b20nIH0sIGtleSkpIH07XG5jb25zdCByZWxhdGlvblNjaGVtYSA9IG9iaih7IGlkOiByZXEoaWRTY2hlbWEpLCBwcm9qZWN0SWQ6IHJlcShzY29wZWRSZWYoJ3Byb2plY3QnKSksIHJldmlzaW9uOiByZXEoeyB0eXBlOiAncmV2aXNpb24nIH0pLCBmcm9tSWQ6IHJlcShyZWYoKSksIHRvSWQ6IHJlcShyZWYoKSksIHJlbGF0aW9uVHlwZTogcmVxKHR4dCgxLCAxMjgpKSwgZGlyZWN0aW9uOiByZXEoZW4oJ2ZvcndhcmQnLCAnc3ltbWV0cmljJykpLCB2YWxpZGl0eTogcmVxKG51bGxhYmxlVmFsaWRpdHkpLCBldmlkZW5jZUlkczogcmVxKHJlZnMoKSksIHN0YXR1czogcmVxKGVuKC4uLlNUQVRVU0VTKSksIHZpc2liaWxpdHk6IHJlcShlbigncHJpdmF0ZScsICd0ZWFtJywgJ3Byb2plY3Rpb24nKSksIHByb2plY3Rpb25Qcm9maWxlSWQ6IG9wdChyZWYoJ3Byb2plY3Rpb25fcHJvZmlsZScpKSwgZGVsZXRlZEF0OiBvcHQoeyB0eXBlOiAnZGF0ZXRpbWUnIH0pLCBkZWxldGlvbk9wZXJhdGlvbklkOiBvcHQoaWRTY2hlbWEpIH0pO1xuY29uc3QgZW50aXR5UmVjb3JkU2NoZW1hcyA9IG5ldyBNYXA8RW50aXR5S2luZCwgeyBkYXRhOiBTY2hlbWE7IHJlY29yZDogU2NoZW1hIH0+KCk7XG5mdW5jdGlvbiBlbnRpdHlTY2hlbWEoa2luZDogRW50aXR5S2luZCk6IFNjaGVtYSB7XG4gIGNvbnN0IGRhdGEgPSBFTlRJVFlfU0NIRU1BU1traW5kXSwgY2FjaGVkID0gZW50aXR5UmVjb3JkU2NoZW1hcy5nZXQoa2luZCk7XG4gIGlmIChjYWNoZWQ/LmRhdGEgPT09IGRhdGEpIHJldHVybiBjYWNoZWQucmVjb3JkO1xuICBjb25zdCByZWNvcmQgPSBvYmooeyAuLi5jb21tb25GaWVsZHMsIGtpbmQ6IHJlcShlbihraW5kKSksIGRhdGE6IHJlcShkYXRhKSB9KTtcbiAgZW50aXR5UmVjb3JkU2NoZW1hcy5zZXQoa2luZCwgeyBkYXRhLCByZWNvcmQgfSk7XG4gIHJldHVybiByZWNvcmQ7XG59XG5mdW5jdGlvbiBzaW1wbGVWYWxpZGF0ZTxUPihzY2hlbWE6IFNjaGVtYSwgdmFsdWU6IHVua25vd24sIHBhdGg6IHN0cmluZywgcmVmZXJlbmNlczpEb21haW5SZWZlcmVuY2VbXT1bXSk6IFZhbGlkYXRpb25SZXN1bHQ8VD4geyBjb25zdCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdID0gW107IHdhbGsoc2NoZW1hLCB2YWx1ZSwgcGF0aCwgaXNzdWVzLCByZWZlcmVuY2VzKTsgcmV0dXJuIGlzc3Vlcy5sZW5ndGggPyB7IG9rOiBmYWxzZSwgaXNzdWVzIH0gOiB7IG9rOiB0cnVlLCB2YWx1ZTogdmFsdWUgYXMgVCB9OyB9XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVDb25kaXRpb24oaW5wdXQ6IHVua25vd24sIHBhdGggPSAnY29uZGl0aW9uJyk6IFZhbGlkYXRpb25SZXN1bHQ8Q29uZGl0aW9uPiB7IHJldHVybiBzaW1wbGVWYWxpZGF0ZShjb25kLCBpbnB1dCwgcGF0aCk7IH1cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZUV4cHJlc3Npb24oaW5wdXQ6IHVua25vd24sIHBhdGggPSAnZXhwcmVzc2lvbicpOiBWYWxpZGF0aW9uUmVzdWx0PEV4cHJlc3Npb24+IHsgcmV0dXJuIHNpbXBsZVZhbGlkYXRlKHsgdHlwZTogJ2V4cHJlc3Npb24nIH0sIGlucHV0LCBwYXRoKTsgfVxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlVHlwZWRWYWx1ZShpbnB1dDogdW5rbm93biwgcGF0aCA9ICd2YWx1ZScpOiBWYWxpZGF0aW9uUmVzdWx0PFR5cGVkVmFsdWU+IHsgcmV0dXJuIHNpbXBsZVZhbGlkYXRlKHR5cGVkLCBpbnB1dCwgcGF0aCk7IH1cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZVRpbWVTcGVjKGlucHV0OiB1bmtub3duLCBwYXRoID0gJ3RpbWUnKTogVmFsaWRhdGlvblJlc3VsdDxUaW1lU3BlYz4geyByZXR1cm4gc2ltcGxlVmFsaWRhdGUodGltZSwgaW5wdXQsIHBhdGgpOyB9XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVSdW50aW1lU3RhdGUoaW5wdXQ6IHVua25vd24sIHBhdGggPSAncnVudGltZVN0YXRlJyk6IFZhbGlkYXRpb25SZXN1bHQ8UnVudGltZVN0YXRlPiB7XG4gIGNvbnN0IHJlc3VsdCA9IHNpbXBsZVZhbGlkYXRlPFJ1bnRpbWVTdGF0ZT4ocnVudGltZSwgaW5wdXQsIHBhdGgpOyBpZiAoIXJlc3VsdC5vaykgcmV0dXJuIHJlc3VsdDtcbiAgY29uc3QgaXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSA9IFtdLCBpZHMgPSBuZXcgU2V0PElEPigpLCBhc3NlcnRpb25zID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIHJlc3VsdC52YWx1ZS5pdGVtSW5zdGFuY2VzLmZvckVhY2goKGl0ZW0sIGkpID0+IHtcbiAgICBpZiAoaWRzLmhhcyhpdGVtLmluc3RhbmNlSWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9Lml0ZW1JbnN0YW5jZXNbJHtpfV0uaW5zdGFuY2VJZGAsICfnianlk4HlgIvkvZPjga5JROOBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicpOyBpZHMuYWRkKGl0ZW0uaW5zdGFuY2VJZCk7XG4gICAgaWYgKChpdGVtLm93bmVySWQgJiYgaXRlbS5sb2NhdGlvbklkKSB8fCAoaXRlbS5jb25zdW1lZCAmJiBpdGVtLnF1YW50aXR5ICE9PSAwKSB8fCAoIWl0ZW0uY29uc3VtZWQgJiYgaXRlbS5xdWFudGl0eSA8IDEpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9Lml0ZW1JbnN0YW5jZXNbJHtpfV1gLCAn54mp5ZOB44Gu5omA5Zyo44O75omA5pyJ44O75raI6LK754q25oWL44O75pWw6YeP44GM5LiN5pW05ZCI44Gn44GZ44CCJyk7XG4gIH0pO1xuICByZXN1bHQudmFsdWUuYXNzZXJ0aW9ucy5mb3JFYWNoKChhc3NlcnRpb24sIGkpID0+IHsgY29uc3Qga2V5ID0gYCR7YXNzZXJ0aW9uLmFzc2VydGlvbklkfS8ke2Fzc2VydGlvbi5ob2xkZXJJZH1gOyBpZiAoYXNzZXJ0aW9ucy5oYXMoa2V5KSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5hc3NlcnRpb25zWyR7aX1dYCwgJ+WQjOOBmOS6uueJqeODu+S6i+Wun+OBruiqjeitmOOBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicpOyBhc3NlcnRpb25zLmFkZChrZXkpOyB9KTtcbiAgcmV0dXJuIGlzc3Vlcy5sZW5ndGggPyB7IG9rOiBmYWxzZSwgaXNzdWVzIH0gOiByZXN1bHQ7XG59XG4vKiogT3B0aW9uYWwgbGVnYWN5IGV2aWRlbmNlIG1heSBiZSBhYnNlbnQ7IHN1cHBsaWVkIGluaXRpYWwgZXZpZGVuY2UgbXVzdCBiZSBjb21wbGV0ZSBhbmQgY29uc2lzdGVudC4gKi9cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZUluaXRpYWxQcmVzZW50YXRpb25SZXN1bHRzKHN0YXRlOiBSdW50aW1lU3RhdGUsIGlucHV0OiB1bmtub3duLCBlbnRpdGllczogcmVhZG9ubHkgRW50aXR5W10sIHBhdGggPSAncHJlc2VudGF0aW9uUmVzdWx0cycpOiBWYWxpZGF0aW9uSXNzdWVbXSB7XG4gIGNvbnN0IGNoZWNrZWQgPSBzaW1wbGVWYWxpZGF0ZTxQcmVzZW50YXRpb25Db25kaXRpb25SZXN1bHRbXT4oYXJyKHByZXNlbnRhdGlvblJlc3VsdCksIGlucHV0LCBwYXRoKTtcbiAgaWYgKCFjaGVja2VkLm9rKSByZXR1cm4gY2hlY2tlZC5pc3N1ZXM7XG4gIGNvbnN0IGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10gPSBbXSwgc2VlbiA9IG5ldyBTZXQoc3RhdGUuc2VlbklkcyksIG9ic2VydmVkID0gbmV3IFNldDxJRD4oKTtcbiAgY29uc3Qgbm9kZSA9IGVudGl0aWVzLmZpbmQoKGVudGl0eSk6IGVudGl0eSBpcyBFbnRpdHk8J2Zsb3dfbm9kZSc+ID0+IGVudGl0eS5raW5kID09PSAnZmxvd19ub2RlJyAmJiBlbnRpdHkuaWQgPT09IHN0YXRlLnByZXNlbnRhdGlvblBvc2l0aW9uICYmICFlbnRpdHkuZGVsZXRlZEF0ICYmIGVudGl0eS5zdGF0dXMgIT09ICdyZWplY3RlZCcpO1xuICBjb25zdCBlbGlnaWJsZSA9IGVudGl0aWVzLmZpbHRlcigoZW50aXR5KTogZW50aXR5IGlzIEVudGl0eTwnZGlzY2xvc3VyZSc+ID0+IHtcbiAgICBpZiAoZW50aXR5LmtpbmQgIT09ICdkaXNjbG9zdXJlJyB8fCBlbnRpdHkuZGVsZXRlZEF0IHx8IGVudGl0eS5zdGF0dXMgPT09ICdyZWplY3RlZCcgfHwgIW5vZGUgfHwgIXNlZW4uaGFzKG5vZGUuaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgYW5jaG9yID0gZW50aXR5LmRhdGEuYW5jaG9yO1xuICAgIHJldHVybiBhbmNob3IucG9zaXRpb25TdGF0dXMgIT09ICd1bnJlc29sdmVkJyAmJiAoYW5jaG9yLmVudGl0eUlkID09PSBub2RlLmlkIHx8IGFuY2hvci5lbnRpdHlJZCA9PT0gbm9kZS5kYXRhLnNjZW5lSWQpXG4gICAgICAmJiAoIWFuY2hvci5ibG9ja0lkIHx8IHNlZW4uaGFzKGFuY2hvci5ibG9ja0lkKSkgJiYgKCFhbmNob3IubGluZUlkIHx8IHNlZW4uaGFzKGFuY2hvci5saW5lSWQpKTtcbiAgfSk7XG4gIGNvbnN0IHRhcmdldHMgPSBuZXcgU2V0KGVsaWdpYmxlLm1hcChkaXNjbG9zdXJlID0+IGRpc2Nsb3N1cmUuaWQpKTtcbiAgY2hlY2tlZC52YWx1ZS5mb3JFYWNoKChyZXN1bHQsIGluZGV4KSA9PiB7XG4gICAgY29uc3QgbG9jYXRpb24gPSBgJHtwYXRofVske2luZGV4fV1gO1xuICAgIGlmIChvYnNlcnZlZC5oYXMocmVzdWx0LnRhcmdldElkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0udGFyZ2V0SWRgLCAn5Yid5pyf5o+Q56S644Gu5p2h5Lu257WQ5p6c44GM6YeN6KSH44GX44Gm44GE44G+44GZ44CCJyk7XG4gICAgb2JzZXJ2ZWQuYWRkKHJlc3VsdC50YXJnZXRJZCk7XG4gICAgaWYgKCF0YXJnZXRzLmhhcyhyZXN1bHQudGFyZ2V0SWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS50YXJnZXRJZGAsICfliJ3mnJ/mj5DnpLrjga7lr77osaHjgafjga/jgarjgYTplovnpLrjga7mnaHku7bntZDmnpzjgafjgZnjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICBpZiAocmVzdWx0LnZhbHVlID09PSAndW5rbm93bicpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LnZhbHVlYCwgJ+acqueiuuiqjeOBrumWi+ekuuadoeS7tuOBp+OBr+WIneacn+aPkOekuuOCkuWujOS6huOBp+OBjeOBvuOBm+OCk+OAgicpO1xuICAgIGlmIChyZXN1bHQudmFsdWUgPT09ICd0cnVlJyAmJiAhc2Vlbi5oYXMocmVzdWx0LnRhcmdldElkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0udmFsdWVgLCAn5o+Q56S644GX44Gf5p2h5Lu257WQ5p6c44Go5pei6Kqt44Gu6Ki86Leh44GM5LiA6Ie044GX44G+44Gb44KT44CCJyk7XG4gICAgaWYgKHJlc3VsdC52YWx1ZSA9PT0gJ2ZhbHNlJyAmJiBzZWVuLmhhcyhyZXN1bHQudGFyZ2V0SWQpICYmIHN0YXRlLnByb3ZlbmFuY2UgPT09ICdmdWxsX3BsYXknKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS52YWx1ZWAsICfmj5DnpLrmuIjjgb/jga7plovnpLrjgpLliJ3mnJ/mnaHku7bjga5mYWxzZeOBp+WPluOCiua2iOOBmeOBk+OBqOOBr+OBp+OBjeOBvuOBm+OCk+OAgicpO1xuICB9KTtcbiAgZm9yIChjb25zdCBkaXNjbG9zdXJlIG9mIGVsaWdpYmxlKSBpZiAoIW9ic2VydmVkLmhhcyhkaXNjbG9zdXJlLmlkKSkgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn5Yid5pyf5o+Q56S644Gu6ZaL56S65p2h5Lu257WQ5p6c44GM5LiN6Laz44GX44Gm44GE44G+44GZ44CCJyk7XG4gIHJldHVybiBpc3N1ZXM7XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVFZmZlY3REYXRhKGlucHV0OiB1bmtub3duLCBwYXRoID0gJ2VmZmVjdCcpOiBWYWxpZGF0aW9uUmVzdWx0PEVudGl0eURhdGFNYXBbJ2VmZmVjdCddPiB7IHJldHVybiBzaW1wbGVWYWxpZGF0ZShFTlRJVFlfU0NIRU1BUy5lZmZlY3QsIGlucHV0LCBwYXRoKTsgfVxuZnVuY3Rpb24gdmFsaWRhdGVFbnRpdHlSZWNvcmQoaW5wdXQ6IHVua25vd24sIHBhdGg6IHN0cmluZywgcmVmZXJlbmNlcz86RG9tYWluUmVmZXJlbmNlW10pOiBWYWxpZGF0aW9uUmVzdWx0PEVudGl0eT4ge1xuICBpZiAoIWlzT2JqZWN0KGlucHV0KSB8fCAhRU5USVRZX0tJTkRTLmluY2x1ZGVzKGlucHV0LmtpbmQgYXMgRW50aXR5S2luZCkpIHJldHVybiB7IG9rOiBmYWxzZSwgaXNzdWVzOiBbeyBjb2RlOiAnVkFMSURBVElPTl9GQUlMRUQnLCBwYXRoOiBgJHtwYXRofS5raW5kYCwgbWVzc2FnZTogJ+acquWvvuW/nOOBruaDheWgseeoruWIpeOBp+OBmeOAgicgfV0gfTtcbiAgY29uc3QgcmVzdWx0ID0gc2ltcGxlVmFsaWRhdGU8RW50aXR5PihlbnRpdHlTY2hlbWEoaW5wdXQua2luZCBhcyBFbnRpdHlLaW5kKSwgaW5wdXQsIHBhdGgscmVmZXJlbmNlcyk7XG4gIGlmICghcmVzdWx0Lm9rKSByZXR1cm4gcmVzdWx0O1xuICBjb25zdCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdID0gW107IHZhbGlkYXRlTG9jYWxSdWxlcyhyZXN1bHQudmFsdWUsIHBhdGgsIGlzc3Vlcyk7XG4gIHJldHVybiBpc3N1ZXMubGVuZ3RoID8geyBvazogZmFsc2UsIGlzc3VlcyB9IDogcmVzdWx0O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlRW50aXR5KGlucHV0OiB1bmtub3duLCBwYXRoID0gJ2VudGl0eScpOiBWYWxpZGF0aW9uUmVzdWx0PEVudGl0eT4ge3JldHVybiB2YWxpZGF0ZUVudGl0eVJlY29yZChpbnB1dCxwYXRoKTt9XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVSZWxhdGlvbihpbnB1dDogdW5rbm93biwgcGF0aCA9ICdyZWxhdGlvbicpOiBWYWxpZGF0aW9uUmVzdWx0PFJlbGF0aW9uPiB7IHJldHVybiBzaW1wbGVWYWxpZGF0ZShyZWxhdGlvblNjaGVtYSwgaW5wdXQsIHBhdGgpOyB9XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZVZhcmlhYmxlVmFsdWUodmFyaWFibGU6IEVudGl0eTwndmFyaWFibGUnPiwgdmFsdWU6IFR5cGVkVmFsdWUsIHBhdGggPSAndmFsdWUnLCBhbGxvd1Vua25vd24gPSB0cnVlKTogVmFsaWRhdGlvbklzc3VlW10ge1xuICBjb25zdCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdID0gW10sIGRhdGEgPSB2YXJpYWJsZS5kYXRhO1xuICBpZiAodmFsdWUudHlwZSA9PT0gJ3Vua25vd24nKSB7IGlmICghYWxsb3dVbmtub3duKSBhZGRJc3N1ZShpc3N1ZXMsIHBhdGgsICfmnKrlrprjga7lgKTjga/jgZPjga7mk43kvZzjgafkvb/jgYjjgb7jgZvjgpPjgIInLCAnQ09ORElUSU9OX1VOS05PV04nKTsgcmV0dXJuIGlzc3VlczsgfVxuICBpZiAodmFsdWUudHlwZSAhPT0gZGF0YS52YWx1ZVR5cGUpIHsgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn54q25oWL5aSJ5pWw44Gu5a6j6KiA5Z6L44Go5YCk44Gu5Z6L44GM5LiA6Ie044GX44G+44Gb44KT44CCJyk7IHJldHVybiBpc3N1ZXM7IH1cbiAgaWYgKHZhbHVlLnR5cGUgPT09ICdpbnRlZ2VyJykge1xuICAgIGNvbnN0IG1pbiA9IGRhdGEuYWxsb3dlZC5taW4gPz8gLTJfMTQ3XzQ4M182NDcsIG1heCA9IGRhdGEuYWxsb3dlZC5tYXggPz8gMl8xNDdfNDgzXzY0NztcbiAgICBpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKHZhbHVlLnZhbHVlKSB8fCB2YWx1ZS52YWx1ZSA8IG1pbiB8fCB2YWx1ZS52YWx1ZSA+IG1heCkgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn54q25oWL5aSJ5pWw44Gu5YCk44GM5a6j6KiA44GX44Gf5pW05pWw56+E5Zuy5aSW44Gn44GZ44CCJyk7XG4gIH1cbiAgaWYgKCh2YWx1ZS50eXBlID09PSAnZW51bScgfHwgdmFsdWUudHlwZSA9PT0gJ2Jvb2xlYW4nKSAmJiBkYXRhLmFsbG93ZWQudmFsdWVzICYmICFkYXRhLmFsbG93ZWQudmFsdWVzLmluY2x1ZGVzKHZhbHVlLnZhbHVlKSkgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn54q25oWL5aSJ5pWw44Gu5YCk44GM6Kix5a656ZuG5ZCI44Gr44GC44KK44G+44Gb44KT44CCJyk7XG4gIHJldHVybiBpc3N1ZXM7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZUxvY2FsUnVsZXMoZW50aXR5OiBFbnRpdHksIHBhdGg6IHN0cmluZywgaXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSk6IHZvaWQge1xuICBjb25zdCBpc3N1ZSA9IChmaWVsZDogc3RyaW5nLCBtZXNzYWdlOiBzdHJpbmcpOiB2b2lkID0+IGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtmaWVsZH1gLCBtZXNzYWdlKTtcbiAgY29uc3QgdW5uYW1lZDogRW50aXR5S2luZFtdID0gWydkaWFsb2d1ZV9saW5lJywgJ2VmZmVjdCcsICdhc3NlcnRpb24nLCAnZGlzY2xvc3VyZScsICdjdWUnLCAnc3Rvcnlib2FyZF9mcmFtZScsICdsb2NhbGl6YXRpb24nLCAncmVjb3JkaW5nJywgJ2NoZWNrcG9pbnQnLCAndHJhY2UnXTtcbiAgaWYgKCF1bm5hbWVkLmluY2x1ZGVzKGVudGl0eS5raW5kKSAmJiAhZW50aXR5Lm5hbWUudHJpbSgpKSB7XG4gICAgaWYgKGVudGl0eS5raW5kICE9PSAnZXZlbnQnKSBpc3N1ZSgnbmFtZScsICflkI3np7DjgpLlhaXlipvjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgICBlbHNlIGlmICghcmljaFRleHRUb1BsYWluVGV4dChlbnRpdHkuZGF0YS5zdW1tYXJ5KS50cmltKCkpIGlzc3VlKCdkYXRhLnN1bW1hcnknLCAn5ZCN56ew44G+44Gf44Gv6KaB57SE44KS5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gIH1cbiAgaWYgKGVudGl0eS52aXNpYmlsaXR5ID09PSAncHJvamVjdGlvbicgJiYgIWVudGl0eS5wcm9qZWN0aW9uUHJvZmlsZUlkKSBpc3N1ZSgncHJvamVjdGlvblByb2ZpbGVJZCcsICflhazplovmipXlvbHjga7lr77osaHjg5fjg63jg5XjgqHjgqTjg6vjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgaWYgKGVudGl0eS5kZWxldGVkQXQgJiYgIWVudGl0eS5kZWxldGlvbk9wZXJhdGlvbklkKSBpc3N1ZSgnZGVsZXRpb25PcGVyYXRpb25JZCcsICfliYrpmaTjgavjga/liYrpmaTmk43kvZxJROOBjOW/heimgeOBp+OBmeOAgicpO1xuICBpZiAoIWVudGl0eS5kZWxldGVkQXQgJiYgZW50aXR5LmRlbGV0aW9uT3BlcmF0aW9uSWQpIGlzc3VlKCdkZWxldGlvbk9wZXJhdGlvbklkJywgJ+WJiumZpOOBleOCjOOBpuOBhOOBquOBhOaDheWgseOBq+WJiumZpOaTjeS9nElE44Gv5L+d5a2Y44Gn44GN44G+44Gb44KT44CCJyk7XG4gIGZvciAoY29uc3QgY3VzdG9tS2V5IG9mIE9iamVjdC5rZXlzKGVudGl0eS5jdXN0b21WYWx1ZXMpKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gRU5USVRZX1NDSEVNQVNbZW50aXR5LmtpbmRdO1xuICAgIGlmIChPYmplY3QuaGFzT3duKGNvbW1vbkZpZWxkcywgY3VzdG9tS2V5KSB8fCAoc2NoZW1hLnR5cGUgPT09ICdvYmplY3QnICYmIE9iamVjdC5oYXNPd24oc2NoZW1hLmZpZWxkcywgY3VzdG9tS2V5KSkpIGlzc3VlKGBjdXN0b21WYWx1ZXMuJHtjdXN0b21LZXl9YCwgJ+aomea6lumgheebruOBqOOCq+OCueOCv+ODoOmgheebruOBruOCreODvOOBjOihneeqgeOBl+OBpuOBhOOBvuOBmeOAgicpO1xuICB9XG4gIHN3aXRjaCAoZW50aXR5LmtpbmQpIHtcbiAgICBjYXNlICdldmVudCc6XG4gICAgICBmb3IgKGNvbnN0IFtpbmRleCwgY29uc3RyYWludF0gb2YgKGVudGl0eS5kYXRhLmNvbnN0cmFpbnRzID8/IFtdKS5lbnRyaWVzKCkpIGlmIChjb25zdHJhaW50LnR5cGUgPT09ICdlbmRfZ2FwJyAmJiBjb21wYXJlVGlja3MoY29uc3RyYWludC5taW5pbXVtVGlja3MsIGNvbnN0cmFpbnQubWF4aW11bVRpY2tzKSA+IDApIGlzc3VlKGBkYXRhLmNvbnN0cmFpbnRzWyR7aW5kZXh9XWAsICfml6XmmYLlt67jga7mnIDlsI/lgKTjga/mnIDlpKflgKTku6XkuIvjgafjgZnjgIInKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2l0ZW0nOiBpZiAoZW50aXR5LmRhdGEuaXRlbU1vZGUgPT09ICdpbnN0YW5jZScgJiYgIWVudGl0eS5kYXRhLnR5cGVJZCkgaXNzdWUoJ2RhdGEudHlwZUlkJywgJ+eJqeWTgeOBruWAi+S9k+OBq+OBr+eorumhnuOBuOOBruWPgueFp+OBjOW/heimgeOBp+OBmeOAgicpOyBicmVhaztcbiAgICBjYXNlICdmbG93X25vZGUnOlxuICAgICAgaWYgKGVudGl0eS5kYXRhLm5vZGVUeXBlID09PSAndGVybWluYWwnICYmICFlbnRpdHkuZGF0YS50ZXJtaW5hbFJlYXNvbj8udHJpbSgpKSBpc3N1ZSgnZGF0YS50ZXJtaW5hbFJlYXNvbicsICfmhI/lm7PjgZfjgZ/ntYLnq6/jgavjga/ntYLkuobnkIbnlLHjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICAgIGlmIChlbnRpdHkuZGF0YS5ub2RlVHlwZSA9PT0gJ2NhbGwnICYmICFlbnRpdHkuZGF0YS5jaGlsZEdyYXBoSWQpIGlzc3VlKCdkYXRhLmNoaWxkR3JhcGhJZCcsICflkbzlh7rjg47jg7zjg4njgavjga/lrZDliIblspDlm7PjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3ZhcmlhYmxlJzoge1xuICAgICAgY29uc3QgZGF0YSA9IGVudGl0eS5kYXRhO1xuICAgICAgaWYgKGRhdGEuc2NvcGUgPT09ICdjaGFyYWN0ZXInICYmICFkYXRhLm93bmVySWQpIGlzc3VlKCdkYXRhLm93bmVySWQnLCAn5Lq654mpc2NvcGXjgavjga/miYDmnInkurrnianjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICAgIGlmIChkYXRhLnZhbHVlVHlwZSA9PT0gJ2ludGVnZXInKSB7XG4gICAgICAgIGlmIChkYXRhLmFsbG93ZWQudmFsdWVzKSBpc3N1ZSgnZGF0YS5hbGxvd2VkLnZhbHVlcycsICfmlbTmlbDjgavjga/pm4blkIjjgafjga/jgarjgY9taW4vbWF444KS5oyH5a6a44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgICAgIGlmICgoZGF0YS5hbGxvd2VkLm1pbiA/PyAtMl8xNDdfNDgzXzY0NykgPiAoZGF0YS5hbGxvd2VkLm1heCA/PyAyXzE0N180ODNfNjQ3KSkgaXNzdWUoJ2RhdGEuYWxsb3dlZCcsICfmlbTmlbDjga7mnIDlsI/lgKTjga/mnIDlpKflgKTku6XkuIvjgafjgZnjgIInKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChkYXRhLmFsbG93ZWQubWluICE9IG51bGwgfHwgZGF0YS5hbGxvd2VkLm1heCAhPSBudWxsKSBpc3N1ZSgnZGF0YS5hbGxvd2VkJywgJ+OBk+OBruWei+OBq+aVsOWApOevhOWbsuOBr+ioreWumuOBp+OBjeOBvuOBm+OCk+OAgicpO1xuICAgICAgICBpZiAoZGF0YS52YWx1ZVR5cGUgPT09ICdlbnVtJyAmJiAoIWRhdGEuYWxsb3dlZC52YWx1ZXM/Lmxlbmd0aCB8fCBkYXRhLmFsbG93ZWQudmFsdWVzLnNvbWUodmFsdWUgPT4gdHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJyB8fCAhdmFsdWUpKSkgaXNzdWUoJ2RhdGEuYWxsb3dlZC52YWx1ZXMnLCAnZW51beOBq+OBr+epuuOBp+OBquOBhOaWh+Wtl+WIl+OBruWAmeijnOmbhuWQiOOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgICBpZiAoZGF0YS52YWx1ZVR5cGUgPT09ICdib29sZWFuJyAmJiBkYXRhLmFsbG93ZWQudmFsdWVzPy5zb21lKHZhbHVlID0+IHR5cGVvZiB2YWx1ZSAhPT0gJ2Jvb2xlYW4nKSkgaXNzdWUoJ2RhdGEuYWxsb3dlZC52YWx1ZXMnLCAnYm9vbGVhbuOBruWAmeijnOOBr+ecn+WBveWApOOBp+OBmeOAgicpO1xuICAgICAgfVxuICAgICAgaXNzdWVzLnB1c2goLi4udmFsaWRhdGVWYXJpYWJsZVZhbHVlKGVudGl0eSwgZGF0YS5pbml0aWFsLCBgJHtwYXRofS5kYXRhLmluaXRpYWxgKSk7XG4gICAgICBmb3IgKGNvbnN0IFtpLCBydWxlXSBvZiAoZGF0YS5yZXNldFJ1bGVzID8/IFtdKS5lbnRyaWVzKCkpIGlzc3Vlcy5wdXNoKC4uLnZhbGlkYXRlVmFyaWFibGVWYWx1ZShlbnRpdHksIHJ1bGUudmFsdWUsIGAke3BhdGh9LmRhdGEucmVzZXRSdWxlc1ske2l9XS52YWx1ZWApKTtcbiAgICAgIGlmIChuZXcgU2V0KChkYXRhLnJlc2V0UnVsZXMgPz8gW10pLm1hcChydWxlID0+IHJ1bGUub24pKS5zaXplICE9PSAoZGF0YS5yZXNldFJ1bGVzID8/IFtdKS5sZW5ndGgpIGlzc3VlKCdkYXRhLnJlc2V0UnVsZXMnLCAn5ZCM44GY57WC5LqG5pmC54K544Gu5Yid5pyf5YyW6KaP5YmH44Gv5LiA44Gk44Gr44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgICBmb3IgKGNvbnN0IFtpLCBydWxlXSBvZiAoZGF0YS50cmFuc2l0aW9uUnVsZXMgPz8gW10pLmVudHJpZXMoKSkge1xuICAgICAgICBpc3N1ZXMucHVzaCguLi52YWxpZGF0ZVZhcmlhYmxlVmFsdWUoZW50aXR5LCBydWxlLmZyb20sIGAke3BhdGh9LmRhdGEudHJhbnNpdGlvblJ1bGVzWyR7aX1dLmZyb21gLCBmYWxzZSksIC4uLnZhbGlkYXRlVmFyaWFibGVWYWx1ZShlbnRpdHksIHJ1bGUudG8sIGAke3BhdGh9LmRhdGEudHJhbnNpdGlvblJ1bGVzWyR7aX1dLnRvYCwgZmFsc2UpKTtcbiAgICAgICAgaWYgKHJ1bGUuZXhjZXB0aW9uICYmICFydWxlLnJlYXNvbj8udHJpbSgpKSBpc3N1ZShgZGF0YS50cmFuc2l0aW9uUnVsZXNbJHtpfV0ucmVhc29uYCwgJ+S+i+WklumBt+enu+OBq+OBr+eQhueUseOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCBbaSwgcnVsZV0gb2YgKGRhdGEuZXhjbHVzaW9ucyA/PyBbXSkuZW50cmllcygpKSB7XG4gICAgICAgIGlzc3Vlcy5wdXNoKC4uLnZhbGlkYXRlVmFyaWFibGVWYWx1ZShlbnRpdHksIHJ1bGUudmFsdWUsIGAke3BhdGh9LmRhdGEuZXhjbHVzaW9uc1ske2l9XS52YWx1ZWAsIGZhbHNlKSk7XG4gICAgICAgIGlmICghcnVsZS5yZWFzb24udHJpbSgpKSBpc3N1ZShgZGF0YS5leGNsdXNpb25zWyR7aX1dLnJlYXNvbmAsICfnm7jkupLmjpLku5bjgavjga/nkIbnlLHjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlICdlZmZlY3QnOlxuICAgICAgaWYgKFsnc2V0JywgJ2FkZCcsICdtb3ZlJ10uaW5jbHVkZXMoZW50aXR5LmRhdGEub3BlcmF0aW9uKSAmJiAoIWVudGl0eS5kYXRhLnZhbHVlIHx8IGVudGl0eS5kYXRhLnZhbHVlLnR5cGUgPT09ICd1bmtub3duJykpIGlzc3VlKCdkYXRhLnZhbHVlJywgJ+OBk+OBruWKueaenOOBq+OBr+aXouefpeOBruWFpeWKm+WApOOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgaWYgKGVudGl0eS5kYXRhLm9wZXJhdGlvbiA9PT0gJ2FkZCcgJiYgZW50aXR5LmRhdGEudmFsdWU/LnR5cGUgIT09ICdpbnRlZ2VyJykgaXNzdWUoJ2RhdGEudmFsdWUnLCAnYWRk44GvaW50ZWdlcuWApOOBoOOBkeOCkuS9v+OBiOOBvuOBmeOAgicpO1xuICAgICAgaWYgKGVudGl0eS5kYXRhLm9wZXJhdGlvbiA9PT0gJ21vdmUnICYmIGVudGl0eS5kYXRhLnZhbHVlPy50eXBlICE9PSAncmVmJykgaXNzdWUoJ2RhdGEudmFsdWUnLCAnbW92ZeOBq+OBr+aJgOWcqOODu+aJgOacieWFiOOBrnJlZuWApOOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgaWYgKGVudGl0eS5kYXRhLm9wZXJhdGlvbiA9PT0gJ2NvbnN1bWUnICYmICFlbnRpdHkuZGF0YS5yZWFzb24/LnRyaW0oKSkgaXNzdWUoJ2RhdGEucmVhc29uJywgJ+a2iOiyu+ODu+egtOWjiuOBq+OBr+eQhueUseOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgaWYgKFsnZ3JhbnQnLCAnY29uc3VtZSddLmluY2x1ZGVzKGVudGl0eS5kYXRhLm9wZXJhdGlvbikgJiYgZW50aXR5LmRhdGEudmFsdWUgIT0gbnVsbCAmJiAoZW50aXR5LmRhdGEudmFsdWUudHlwZSAhPT0gJ2ludGVnZXInIHx8IGVudGl0eS5kYXRhLnZhbHVlLnZhbHVlIDwgMSkpIGlzc3VlKCdkYXRhLnZhbHVlJywgJ+eJqeWTgeaVsOmHj+OBr+ato+OBrmludGVnZXLjgafjgZnjgIInKTtcbiAgICAgIGlmIChlbnRpdHkuZGF0YS5vcGVyYXRpb24gPT09ICdhc3NlcnQnICYmIGVudGl0eS5kYXRhLnZhbHVlICE9IG51bGwgJiYgZW50aXR5LmRhdGEudmFsdWUudHlwZSAhPT0gJ2Jvb2xlYW4nKSBpc3N1ZSgnZGF0YS52YWx1ZScsICdhc3NlcnTjga7nnJ/lgb3lhaXlipvjga9ib29sZWFu44Gn44GZ44CCJyk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdhc3NlcnRpb24nOlxuICAgICAgaWYgKGVudGl0eS5kYXRhLnRydXRoS2luZCA9PT0gJ2JlbGllZicgJiYgIWVudGl0eS5kYXRhLmhvbGRlcklkKSBpc3N1ZSgnZGF0YS5ob2xkZXJJZCcsICdiZWxpZWbjgavjga/oqo3orZjjgpLmjIHjgaTkurrnianjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICAgIGlmIChlbnRpdHkuZGF0YS50cnV0aEtpbmQgPT09ICd0ZXN0aW1vbnknICYmICFlbnRpdHkuZGF0YS5zb3VyY2VJZHM/Lmxlbmd0aCkgaXNzdWUoJ2RhdGEuc291cmNlSWRzJywgJ3Rlc3RpbW9ueeOBq+OBr+WHuuaJgOOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnc3Rvcnlib2FyZF9mcmFtZSc6IGlmIChlbnRpdHkuZGF0YS5tZWRpYUVuZE1zICE9IG51bGwgJiYgZW50aXR5LmRhdGEubWVkaWFFbmRNcyA8IGVudGl0eS5kYXRhLm1lZGlhU3RhcnRNcykgaXNzdWUoJ2RhdGEubWVkaWFFbmRNcycsICfmvJTlh7rjga7ntYLkuobjga/plovlp4vku6XkuIrjgafjgZnjgIInKTsgYnJlYWs7XG4gICAgY2FzZSAndHJhdmVsX3JvdXRlJzpcbiAgICAgIGlmICgoZW50aXR5LmRhdGEubWluaW11bVRpY2tzICE9IG51bGwgJiYgcGFyc2VUaWNrKGVudGl0eS5kYXRhLm1pbmltdW1UaWNrcykgPCAwbikgfHwgKGVudGl0eS5kYXRhLm1heGltdW1UaWNrcyAhPSBudWxsICYmIHBhcnNlVGljayhlbnRpdHkuZGF0YS5tYXhpbXVtVGlja3MpIDwgMG4pKSBpc3N1ZSgnZGF0YScsICfnp7vli5XmiYDopoHmmYLplpPjga8w5Lul5LiK44Gn44GZ44CCJyk7XG4gICAgICBpZiAoZW50aXR5LmRhdGEubWluaW11bVRpY2tzICE9IG51bGwgJiYgZW50aXR5LmRhdGEubWF4aW11bVRpY2tzICE9IG51bGwgJiYgY29tcGFyZVRpY2tzKGVudGl0eS5kYXRhLm1pbmltdW1UaWNrcywgZW50aXR5LmRhdGEubWF4aW11bVRpY2tzKSA+IDApIGlzc3VlKCdkYXRhLm1heGltdW1UaWNrcycsICfmnIDlpKfmiYDopoHmmYLplpPjga/mnIDlsI/ku6XkuIrjgafjgZnjgIInKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NvbGxlY3Rpb24nOlxuICAgICAgaWYgKGVudGl0eS5kYXRhLnB1cnBvc2UgPT09ICdyZWdyZXNzaW9uJyAmJiBlbnRpdHkuZGF0YS5tb2RlICE9PSAnZml4ZWQnKSBpc3N1ZSgnZGF0YS5tb2RlJywgJ+WbnuW4sOe1jOi3r+mbhuWQiOOBr+Wuo+iogOOBl+OBn+WbuuWumue1jOi3r+OBrumbhuWQiOOBp+OBmeOAgicpO1xuICAgICAgaWYgKGVudGl0eS5kYXRhLm1vZGUgPT09ICdkeW5hbWljJyAmJiAhZW50aXR5LmRhdGEucXVlcnkpIGlzc3VlKCdkYXRhLnF1ZXJ5JywgJ+WLleeahOS4gOimp+OBq+OBr+Wei+S7mOOBjeaknOe0ouadoeS7tuOBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgaWYgKGVudGl0eS5kYXRhLm1vZGUgPT09ICdmaXhlZCcgJiYgIUFycmF5LmlzQXJyYXkoZW50aXR5LmRhdGEubWVtYmVySWRzKSkgaXNzdWUoJ2RhdGEubWVtYmVySWRzJywgJ+WbuuWumuS4gOimp+OBq+OBr0lE6YWN5YiX44GM5b+F6KaB44Gn44GZ44CCJyk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICd0ZW1wbGF0ZSc6IHtcbiAgICAgIGlzc3Vlcy5wdXNoKC4uLnZhbGlkYXRlVGVtcGxhdGVEZWZpbml0aW9uKGVudGl0eS5kYXRhLCBgJHtwYXRofS5kYXRhYCkpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ3Byb2R1Y3Rpb25fdGFzayc6XG4gICAgICBpZiAoZW50aXR5LmRhdGEuZGVhZGxpbmUpIHsgdHJ5IHsgbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoJ2phJywgeyB0aW1lWm9uZTogZW50aXR5LmRhdGEuZGVhZGxpbmUudGltZVpvbmUgfSk7IH0gY2F0Y2ggeyBpc3N1ZSgnZGF0YS5kZWFkbGluZS50aW1lWm9uZScsICfmnInlirnjgarjgr/jgqTjg6Djgr7jg7zjg7PjgpLmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTsgfSB9XG4gICAgICBpZiAoZW50aXR5LmRhdGEuZXN0aW1hdGUpIHtcbiAgICAgICAgY29uc3QgZXN0aW1hdGUgPSBlbnRpdHkuZGF0YS5lc3RpbWF0ZTtcbiAgICAgICAgaWYgKChlc3RpbWF0ZS52YWx1ZSA9PSBudWxsKSA9PT0gKGVzdGltYXRlLnJhbmdlID09IG51bGwpKSBpc3N1ZSgnZGF0YS5lc3RpbWF0ZScsICfopovnqY3jgoLjgorjga92YWx1ZeOBvuOBn+OBr3Jhbmdl44Gu5LiA44Gk44Gn44GZ44CCJyk7XG4gICAgICAgIGlmIChlc3RpbWF0ZS5yYW5nZSAmJiBlc3RpbWF0ZS5yYW5nZS5taW4gPiBlc3RpbWF0ZS5yYW5nZS5tYXgpIGlzc3VlKCdkYXRhLmVzdGltYXRlLnJhbmdlJywgJ+imi+epjeevhOWbsuOBjOmAhui7ouOBl+OBpuOBhOOBvuOBmeOAgicpO1xuICAgICAgICBpZiAoWydyZWFkaW5nX21pbnV0ZXMnLCAncGxheWluZ19taW51dGVzJ10uaW5jbHVkZXMoZXN0aW1hdGUudW5pdCkgJiYgIWVzdGltYXRlLnNwZWVkKSBpc3N1ZSgnZGF0YS5lc3RpbWF0ZS5zcGVlZCcsICfmnKzmlofph4/jgYvjgonjga7mmYLplpPopovnqY3jgoLjgorjgavjga/pgJ/luqbjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3Jldmlldyc6e1xuICAgICAgY29uc3Qgc291cmNlPWVudGl0eS5kYXRhLnNoYXJlZFNvdXJjZTtpZighc291cmNlKWJyZWFrO1xuICAgICAgdHJ5e2NvbnN0IHVybD1uZXcgVVJMKHNvdXJjZS5jb25uZWN0aW9uKTtpZih1cmwub3JpZ2luIT09c291cmNlLmNvbm5lY3Rpb258fHVybC51c2VybmFtZXx8dXJsLnBhc3N3b3JkfHwhWydodHRwczonLCdodHRwOiddLmluY2x1ZGVzKHVybC5wcm90b2NvbCl8fHVybC5wcm90b2NvbD09PSdodHRwOicmJiFbJ2xvY2FsaG9zdCcsJzEyNy4wLjAuMScsJ1s6OjFdJ10uaW5jbHVkZXModXJsLmhvc3RuYW1lKSlpc3N1ZSgnZGF0YS5zaGFyZWRTb3VyY2UuY29ubmVjdGlvbicsJ+aMh+aRmOOBruWwgueUqOaOpee2muWFiOOBrm9yaWdpbuOCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpO31jYXRjaHtpc3N1ZSgnZGF0YS5zaGFyZWRTb3VyY2UuY29ubmVjdGlvbicsJ+aMh+aRmOOBruaOpee2muWFiOOBjOS4jeato+OBp+OBmeOAgicpO31cbiAgICAgIGlmKCFJRF9QQVRURVJOLnRlc3Qoc291cmNlLnNoYXJlZFNuYXBzaG90KXx8IUlEX1BBVFRFUk4udGVzdChzb3VyY2UuY29tbWVudCl8fCFzb3VyY2UucHVibGljVmVyc2lvbnx8IS9eKFthLWYwLTldezY0fSkkLy50ZXN0KHNvdXJjZS5wcm9qZWN0aW9uSGFzaCl8fCEvXihbYS1mMC05XXs2NH0pJC8udGVzdChzb3VyY2UuY29tbWVudEJvZHlIYXNoKSlpc3N1ZSgnZGF0YS5zaGFyZWRTb3VyY2UnLCflhYPjga7lhazplovniYjjg7vmjIfmkZjjg7toYXNo44GM5LiN5q2j44Gn44GZ44CCJyk7XG4gICAgICBpZigoISFzb3VyY2UucHVibGljRW50aXR5KT09PSghIXNvdXJjZS5wdWJsaWNSZWxhdGlvbil8fHNvdXJjZS5wdWJsaWNSZWxhdGlvbiYmKHNvdXJjZS5wdWJsaWNCbG9jayE9PXVuZGVmaW5lZHx8c291cmNlLnN0YXJ0Q3AhPT11bmRlZmluZWR8fHNvdXJjZS5lbmRDcCE9PXVuZGVmaW5lZCl8fHNvdXJjZS5wdWJsaWNCbG9jayE9PXVuZGVmaW5lZCYmKHNvdXJjZS5zdGFydENwPT09dW5kZWZpbmVkfHxzb3VyY2UuZW5kQ3A9PT11bmRlZmluZWR8fHNvdXJjZS5lbmRDcDw9c291cmNlLnN0YXJ0Q3ApfHxzb3VyY2UucHVibGljQmxvY2s9PT11bmRlZmluZWQmJihzb3VyY2Uuc3RhcnRDcCE9PXVuZGVmaW5lZHx8c291cmNlLmVuZENwIT09dW5kZWZpbmVkKSlpc3N1ZSgnZGF0YS5zaGFyZWRTb3VyY2UnLCflhYPmjIfmkZjjga7lr77osaHjgahVbmljb2Rl5L2N572u44Gu57WE5ZCI44Gb44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY2FzZSAnbG9jYWxpemF0aW9uJzogY2FzZSAncmVjb3JkaW5nJzogaWYgKCEvXlthLXpdezIsM30oPzotW0EtWmEtejAtOV17Miw4fSkqJC8udGVzdChlbnRpdHkuZGF0YS5sYW5ndWFnZSkpIGlzc3VlKCdkYXRhLmxhbmd1YWdlJywgJ+iogOiqnuOCs+ODvOODieOCkuaMh+WumuOBl+OBpuOBj+OBoOOBleOBhO+8iOS+izogamHjgIFlbi1VU++8ieOAgicpOyBicmVhaztcbiAgfVxuICB2YWxpZGF0ZU5lc3RlZFJhbmdlcyhlbnRpdHkuZGF0YSwgYCR7cGF0aH0uZGF0YWAsIGlzc3Vlcyk7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZU5lc3RlZFJhbmdlcyh2YWx1ZTogdW5rbm93biwgcGF0aDogc3RyaW5nLCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdLCBkZXB0aCA9IDApOiB2b2lkIHtcbiAgaWYgKGRlcHRoID4gMzIgfHwgIXZhbHVlIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7IHZhbHVlLmZvckVhY2goKGl0ZW0sIGkpID0+IHZhbGlkYXRlTmVzdGVkUmFuZ2VzKGl0ZW0sIGAke3BhdGh9WyR7aX1dYCwgaXNzdWVzLCBkZXB0aCArIDEpKTsgcmV0dXJuOyB9XG4gIGNvbnN0IG9iamVjdCA9IHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBpZiAoJ3dvcmxkUmFuZ2UnIGluIG9iamVjdCAmJiBpc09iamVjdChvYmplY3Qud29ybGRSYW5nZSkpIHtcbiAgICBjb25zdCByYW5nZSA9IG9iamVjdC53b3JsZFJhbmdlOyBpZiAoaXNUaWNrKHJhbmdlLnN0YXJ0KSAmJiBpc1RpY2socmFuZ2UuZW5kKSAmJiBjb21wYXJlVGlja3MocmFuZ2Uuc3RhcnQsIHJhbmdlLmVuZCkgPj0gMCkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS53b3JsZFJhbmdlYCwgJ+acieWKueacn+mWk+OBr3N0YXJ0IDwgZW5k44Gu5Y2K6ZaL5Yy66ZaT44Gn44GZ44CCJyk7XG4gIH1cbiAgaWYgKCdlbnRpdHlJZCcgaW4gb2JqZWN0ICYmIHR5cGVvZiBvYmplY3Quc3RhcnQgPT09ICdudW1iZXInICYmIHR5cGVvZiBvYmplY3QuZW5kID09PSAnbnVtYmVyJyAmJiBvYmplY3Quc3RhcnQgPj0gb2JqZWN0LmVuZCkgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn5L2N572u44Gu5paH5a2X56+E5Zuy44Gvc3RhcnQgPCBlbmTjgafjgZnjgIInKTtcbiAgZm9yIChjb25zdCBbZmllbGQsIGl0ZW1dIG9mIE9iamVjdC5lbnRyaWVzKG9iamVjdCkpIHZhbGlkYXRlTmVzdGVkUmFuZ2VzKGl0ZW0sIGAke3BhdGh9LiR7ZmllbGR9YCwgaXNzdWVzLCBkZXB0aCArIDEpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNvbGxlY3RSZWZlcmVuY2VzKGVudGl0eTogRW50aXR5KTogRG9tYWluUmVmZXJlbmNlW10geyBjb25zdCByZWZlcmVuY2VzOiBEb21haW5SZWZlcmVuY2VbXSA9IFtdOyB3YWxrKGVudGl0eVNjaGVtYShlbnRpdHkua2luZCksIGVudGl0eSwgJycsIFtdLCByZWZlcmVuY2VzKTsgcmV0dXJuIHJlZmVyZW5jZXMubWFwKHJlZmVyZW5jZSA9PiAoeyAuLi5yZWZlcmVuY2UsIHBhdGg6IHJlZmVyZW5jZS5wYXRoLnJlcGxhY2UoL15cXC4vLCAnJykgfSkpOyB9XG5leHBvcnQgZnVuY3Rpb24gY29sbGVjdFJlbGF0aW9uUmVmZXJlbmNlcyhyZWxhdGlvbjogUmVsYXRpb24pOiBEb21haW5SZWZlcmVuY2VbXSB7IGNvbnN0IHJlZmVyZW5jZXM6IERvbWFpblJlZmVyZW5jZVtdID0gW107IHdhbGsocmVsYXRpb25TY2hlbWEsIHJlbGF0aW9uLCAnJywgW10sIHJlZmVyZW5jZXMpOyByZXR1cm4gcmVmZXJlbmNlcy5tYXAocmVmZXJlbmNlID0+ICh7IC4uLnJlZmVyZW5jZSwgcGF0aDogcmVmZXJlbmNlLnBhdGgucmVwbGFjZSgvXlxcLi8sICcnKSB9KSk7IH1cbmZ1bmN0aW9uIHBhdGhQYXJ0cyhwYXRoOiBzdHJpbmcpOiBzdHJpbmdbXSB7IHJldHVybiBwYXRoLnJlcGxhY2UoL1xcWyhcXGQrKVxcXS9nLCAnLiQxJykuc3BsaXQoJy4nKS5maWx0ZXIoQm9vbGVhbik7IH1cbmZ1bmN0aW9uIHJld3JpdGVQYXRoczxUPihzb3VyY2U6IFQsIHJlZmVyZW5jZXM6IERvbWFpblJlZmVyZW5jZVtdLCBpZE1hcDogTWFwPElELCBJRD4gfCBSZWNvcmQ8SUQsIElEPik6IFQge1xuICBjb25zdCBjb3B5ID0gc3RydWN0dXJlZENsb25lKHNvdXJjZSksIGxvb2t1cCA9IChpZDogSUQpOiBJRCB8IHVuZGVmaW5lZCA9PiBpZE1hcCBpbnN0YW5jZW9mIE1hcCA/IGlkTWFwLmdldChpZCkgOiBPYmplY3QuaGFzT3duKGlkTWFwLCBpZCkgPyBpZE1hcFtpZF0gOiB1bmRlZmluZWQ7XG4gIC8vIFJld3JpdGUgdmFsdWVzIHdoaWxlIHRoZWlyIG9sZCBwYXRocyBzdGlsbCBleGlzdCwgdGhlbiBtb3ZlIGlubmVyIGRpY3Rpb25hcnkga2V5cy5cbiAgY29uc3Qgb3JkZXJlZCA9IFsuLi5yZWZlcmVuY2VzXS5zb3J0KChhLCBiKSA9PiB7XG4gICAgY29uc3QgYUtleSA9IGEucGF0aC5lbmRzV2l0aCgnLiRrZXknKSwgYktleSA9IGIucGF0aC5lbmRzV2l0aCgnLiRrZXknKTtcbiAgICByZXR1cm4gTnVtYmVyKGFLZXkpIC0gTnVtYmVyKGJLZXkpIHx8IChhS2V5ID8gcGF0aFBhcnRzKGIucGF0aCkubGVuZ3RoIC0gcGF0aFBhcnRzKGEucGF0aCkubGVuZ3RoIDogMCk7XG4gIH0pO1xuICBmb3IgKGNvbnN0IHJlZmVyZW5jZSBvZiBvcmRlcmVkKSB7XG4gICAgY29uc3QgcmVwbGFjZW1lbnQgPSBsb29rdXAocmVmZXJlbmNlLmlkKTsgaWYgKCFyZXBsYWNlbWVudCkgY29udGludWU7XG4gICAgY29uc3QgcGFydHMgPSBwYXRoUGFydHMocmVmZXJlbmNlLnBhdGgpLCBkaWN0aW9uYXJ5S2V5ID0gcGFydHMuYXQoLTEpID09PSAnJGtleSc7XG4gICAgaWYgKGRpY3Rpb25hcnlLZXkpIHBhcnRzLnBvcCgpO1xuICAgIGNvbnN0IGZpZWxkID0gcGFydHMucG9wKCk7IGlmICghZmllbGQpIGNvbnRpbnVlO1xuICAgIGxldCBjdXJzb3IgPSBjb3B5IGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSBjdXJzb3IgPSBjdXJzb3JbcGFydF0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgaWYgKGRpY3Rpb25hcnlLZXkpIHtcbiAgICAgIGlmIChyZXBsYWNlbWVudCA9PT0gZmllbGQpIGNvbnRpbnVlO1xuICAgICAgaWYgKE9iamVjdC5oYXNPd24oY3Vyc29yLCByZXBsYWNlbWVudCkpIHRocm93IG5ldyBFcnJvcignUkVGRVJFTkNFX0lOVkFMSUQ6IOWPgueFp+OBrue1seWQiOOBp+i+nuabuOOCreODvOOBjOihneeqgeOBl+OBvuOBmeOAguS/neaMgeOBmeOCi+WGheWuueOCkumBuOOCk+OBp+OBj+OBoOOBleOBhOOAgicpO1xuICAgICAgY3Vyc29yW3JlcGxhY2VtZW50XSA9IGN1cnNvcltmaWVsZF07IGRlbGV0ZSBjdXJzb3JbZmllbGRdO1xuICAgIH1cbiAgICBlbHNlIGN1cnNvcltmaWVsZF0gPSByZXBsYWNlbWVudDtcbiAgfVxuICByZXR1cm4gY29weTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXdyaXRlRW50aXR5UmVmZXJlbmNlczxLIGV4dGVuZHMgRW50aXR5S2luZD4oZW50aXR5OiBFbnRpdHk8Sz4sIGlkTWFwOiBNYXA8SUQsIElEPiB8IFJlY29yZDxJRCwgSUQ+KTogRW50aXR5PEs+IHtcbiAgY29uc3QgY29weSA9IHJld3JpdGVQYXRocyhlbnRpdHksIGNvbGxlY3RSZWZlcmVuY2VzKGVudGl0eSksIGlkTWFwKSwgbG9va3VwID0gKGlkOiBJRCkgPT4gKGlkTWFwIGluc3RhbmNlb2YgTWFwID8gaWRNYXAuZ2V0KGlkKSA6IGlkTWFwW2lkXSkgPz8gaWQ7XG4gIGlmICgoZW50aXR5LmtpbmQgPT09ICdzY2VuZScgfHwgZW50aXR5LmtpbmQgPT09ICdmbG93X25vZGUnKSAmJiBlbnRpdHkuZGF0YS5yZXVzZT8uYmluZGluZ3MgJiYgKGNvcHkua2luZCA9PT0gJ3NjZW5lJyB8fCBjb3B5LmtpbmQgPT09ICdmbG93X25vZGUnKSAmJiBjb3B5LmRhdGEucmV1c2UpIGNvcHkuZGF0YS5yZXVzZS5iaW5kaW5ncyA9IE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhlbnRpdHkuZGF0YS5yZXVzZS5iaW5kaW5ncykubWFwKChbc291cmNlLCB0YXJnZXRdKSA9PiBbbG9va3VwKHNvdXJjZSksIGxvb2t1cCh0YXJnZXQpXSkpO1xuICByZXR1cm4gY29weTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXdyaXRlUmVsYXRpb25SZWZlcmVuY2VzKHJlbGF0aW9uOiBSZWxhdGlvbiwgaWRNYXA6IE1hcDxJRCwgSUQ+IHwgUmVjb3JkPElELCBJRD4pOiBSZWxhdGlvbiB7IHJldHVybiByZXdyaXRlUGF0aHMocmVsYXRpb24sIGNvbGxlY3RSZWxhdGlvblJlZmVyZW5jZXMocmVsYXRpb24pLCBpZE1hcCk7IH1cblxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0VmFsaWRhdGlvbk9wdGlvbnMgeyB3b3JsZHM/OiBQcm9qZWN0Q29udGVudFtdOyB3b3JsZFNuYXBzaG90cz86IFJlY29yZDxJRCwgUHJvamVjdENvbnRlbnQ+OyByZWxhdGlvblR5cGVzPzogUmVsYXRpb25UeXBlRGVmaW5pdGlvbltdOyBydW50aW1lPzogYm9vbGVhbiB9XG5jb25zdCB3b3JsZFJlZmVyZW5jZVNjaGVtYSA9IG9iaih7IHByb2plY3RJZDogcmVxKGlkU2NoZW1hKSwgaW1tdXRhYmxlU25hcHNob3RJZDogcmVxKGlkU2NoZW1hKSwgY29udGVudEhhc2g6IHJlcSh7IHR5cGU6ICdoYXNoJyB9KSB9KTtcbmNvbnN0IHZpZXdTY2hlbWEgPSBvYmooeyBpZDogcmVxKGlkU2NoZW1hKSwgbmFtZTogcmVxKHR4dCgxLCAxMjgpKSwgdmlldzogcmVxKHR4dCgxKSksIGVudGl0eUlkczogcmVxKHJlZnMoKSksIHNldHRpbmdzOiByZXEocmVjb3JkKHVuaW9uKHR4dCgpLCBudW0oKSwgYm9vbCwgZW4obnVsbCkpLCBrZXkpKSB9KTtcbmNvbnN0IHByb2plY3RIZWFkZXJGaWVsZHM6IFJlY29yZDxzdHJpbmcsIEZpZWxkPiA9IHsgcHJvamVjdElkOiByZXEoaWRTY2hlbWEpLCBuYW1lOiByZXEodHh0KDEsIDEyOCkpLCBmb3JtYXRWZXJzaW9uOiByZXEoZW4oRk9STUFUX1ZFUlNJT04pKSwgcmV2aXNpb246IHJlcSh7IHR5cGU6ICdyZXZpc2lvbicgfSksIGNhbGVuZGFySWQ6IHJlcSh0eHQoMSkpLCBtYWluU3RhcnQ6IHJlcSh0aWNrKSwgd29ybGRSZWZlcmVuY2VzOiByZXEoYXJyKHdvcmxkUmVmZXJlbmNlU2NoZW1hKSkgfTtcbmNvbnN0IHByb2plY3RDb250ZW50S2V5cyA9IFsuLi5PYmplY3Qua2V5cyhwcm9qZWN0SGVhZGVyRmllbGRzKSwgJ2NhbGVuZGFycycsICdlbnRpdGllcycsICdyZWxhdGlvbnMnLCAndmlld3MnXTtcbmNvbnN0IHByb2plY3RLZXlzID0gWy4uLnByb2plY3RDb250ZW50S2V5cywgJ2F1dGhvckFsdGVybmF0aXZlcyddO1xuY29uc3QgYWx0ZXJuYXRpdmVzU2NoZW1hOiBTY2hlbWEgPSBhcnIoeyB0eXBlOiAnanNvbicgfSwgZmFsc2UsIDAsIDEwMCk7XG5mdW5jdGlvbiB2YWxpZGF0ZUFjdGl2ZVJlY29yZE5hbWVzcGFjZShwcm9qZWN0OiBQcm9qZWN0Q29udGVudCwgd29ybGRzOiBQcm9qZWN0Q29udGVudFtdLCBwYXRoOiBzdHJpbmcsIGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10pOiB2b2lkIHtcbiAgY29uc3QgcGlubmVkUHJvamVjdHMgPSBuZXcgU2V0PElEPigpLCBhY3RpdmVQcm9qZWN0cyA9IG5ldyBTZXQ8SUQ+KFtwcm9qZWN0LnByb2plY3RJZF0pLCBpZHMgPSBuZXcgU2V0PElEPigpO1xuICBwcm9qZWN0LndvcmxkUmVmZXJlbmNlcy5mb3JFYWNoKChyZWZlcmVuY2UsIGluZGV4KSA9PiB7XG4gICAgaWYgKHBpbm5lZFByb2plY3RzLmhhcyhyZWZlcmVuY2UucHJvamVjdElkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS53b3JsZFJlZmVyZW5jZXNbJHtpbmRleH1dYCwgJ+WQjOOBmOS4lueVjOOBruikh+aVsOOBrueJiOOCkuWQjOaZguOBq+WPgueFp+OBmeOCi+OBqOOAgUlE44Gu5Y+C54Wn5YWI44GM5puW5pin44Gr44Gq44KK44G+44GZ44CC5LiA44Gk44Gu5Zu65a6a54mI44KS6YG444KT44Gn44GP44Gg44GV44GE44CCJywgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgcGlubmVkUHJvamVjdHMuYWRkKHJlZmVyZW5jZS5wcm9qZWN0SWQpO1xuICB9KTtcbiAgY29uc3QgY29udGV4dHMgPSBbeyBjb250ZW50OiBwcm9qZWN0LCBsb2NhdGlvbjogcGF0aCB9LCAuLi53b3JsZHMubWFwKHdvcmxkID0+IHtcbiAgICBjb25zdCByZWZlcmVuY2VJbmRleCA9IHByb2plY3Qud29ybGRSZWZlcmVuY2VzLmZpbmRJbmRleChyZWZlcmVuY2UgPT4gcmVmZXJlbmNlLnByb2plY3RJZCA9PT0gd29ybGQucHJvamVjdElkKTtcbiAgICByZXR1cm4geyBjb250ZW50OiB3b3JsZCwgbG9jYXRpb246IGAke3BhdGh9LndvcmxkUmVmZXJlbmNlc1ske3JlZmVyZW5jZUluZGV4fV1gIH07XG4gIH0pXTtcbiAgY29uc3QgY2FsZW5kYXJzID0gbmV3IE1hcDxzdHJpbmcsIENhbGVuZGFyRGVmaW5pdGlvbj4oKTtcbiAgZm9yIChjb25zdCBbaW5kZXgsIHsgY29udGVudCwgbG9jYXRpb24gfV0gb2YgY29udGV4dHMuZW50cmllcygpKSB7XG4gICAgaWYgKGluZGV4ID4gMCkge1xuICAgICAgaWYgKGFjdGl2ZVByb2plY3RzLmhhcyhjb250ZW50LnByb2plY3RJZCkpIGFkZElzc3VlKGlzc3VlcywgbG9jYXRpb24sICflkIzjgZjkvZzlk4Hjg7vkuJbnlYzjga7opIfmlbDjga7lhoXlrrnjgYznj77lnKjjga7lj4Lnhafnr4Tlm7LjgavlkKvjgb7jgozjgabjgYTjgb7jgZnjgILlm7rlrprniYjjgpLkuIDjgaTjgavjgZfjgabjgY/jgaDjgZXjgYTjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICAgIGFjdGl2ZVByb2plY3RzLmFkZChjb250ZW50LnByb2plY3RJZCk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgW2NhbGVuZGFySW5kZXgsIGNhbGVuZGFyXSBvZiBjb250ZW50LmNhbGVuZGFycy5lbnRyaWVzKCkpIHtcbiAgICAgIGNvbnN0IHByZXZpb3VzID0gY2FsZW5kYXJzLmdldChjYWxlbmRhci5pZCk7XG4gICAgICBpZiAocHJldmlvdXMgJiYgIXNhbWVDYWxlbmRhckRlZmluaXRpb24ocHJldmlvdXMsIGNhbGVuZGFyKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uY2FsZW5kYXJzWyR7Y2FsZW5kYXJJbmRleH1dLmlkYCwgJ+WQjOOBmOaapklE44Gr55Ww44Gq44KL5a6a576p44GM44GC44KK44G+44GZ44CC5Zu65a6a54mI44Gu5pel5pmC44KS6Kqt44G/5pu/44GI44Ga44CB5pqmSUTjgpLmmI7npLrjgZfjgablr77lv5zku5jjgZHjgabjgY/jgaDjgZXjgYTjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICAgIGNhbGVuZGFycy5zZXQoY2FsZW5kYXIuaWQsIGNhbGVuZGFyKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBbY29sbGVjdGlvbiwgcmVjb3Jkc10gb2YgW1snZW50aXRpZXMnLCBjb250ZW50LmVudGl0aWVzXSwgWydyZWxhdGlvbnMnLCBjb250ZW50LnJlbGF0aW9uc11dIGFzIGNvbnN0KSByZWNvcmRzLmZvckVhY2goKHJlY29yZCwgcmVjb3JkSW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHJlY29yZFBhdGggPSBgJHtsb2NhdGlvbn0uJHtjb2xsZWN0aW9ufVske3JlY29yZEluZGV4fV1gO1xuICAgICAgaWYgKGlkcy5oYXMocmVjb3JkLmlkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtyZWNvcmRQYXRofS5pZGAsICfnj77lnKjjga7kvZzlk4Hjgajlj4LnhafkuK3jga7lhbHpgJrkuJbnlYzjgadlbnRpdHnjg7tyZWxhdGlvbuOBrklE44GM6KGd56qB44GX44Gm44GE44G+44GZ44CC5puW5pin44Gq5Y+C54Wn44Gv5L+d5a2Y44Gn44GN44G+44Gb44KT44CCJywgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgICBpZHMuYWRkKHJlY29yZC5pZCk7XG4gICAgICBpZiAocmVjb3JkLnByb2plY3RJZCAhPT0gY29udGVudC5wcm9qZWN0SWQpIGFkZElzc3VlKGlzc3VlcywgYCR7cmVjb3JkUGF0aH0ucHJvamVjdElkYCwgJ+WPgueFp+evhOWbsuOBruODrOOCs+ODvOODieOBjOaJgOWxnuOBmeOCi+S9nOWTgeODu+S4lueVjOOBqOS4gOiHtOOBl+OBvuOBm+OCk+OAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICAgIH0pO1xuICB9XG59XG5pbnRlcmZhY2UgVmFsaWRhdGlvblJldXNlIHsgcHJldmlvdXM6IFByb2plY3REYXRhOyByZWZlcmVuY2VzOiBXZWFrTWFwPEVudGl0eSwgRG9tYWluUmVmZXJlbmNlW10+IH1cbmZ1bmN0aW9uIHZhbGlkYXRlQ29udGVudChpbnB1dDogdW5rbm93biwgcGF0aDogc3RyaW5nLCBvcHRpb25zOiBQcm9qZWN0VmFsaWRhdGlvbk9wdGlvbnMsIHNuYXBzaG90SWRzOiBTZXQ8SUQ+LCB2ZXJzaW9uQ29udGVudHM6IE1hcDxJRCwgUHJvamVjdENvbnRlbnQ+ID0gbmV3IE1hcCgpLCByZXVzZT86IFZhbGlkYXRpb25SZXVzZSk6IFZhbGlkYXRpb25SZXN1bHQ8UHJvamVjdENvbnRlbnQ+IHtcbiAgY29uc3QgaXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSA9IFtdO1xuICBpZiAoIWlzT2JqZWN0KGlucHV0KSkgcmV0dXJuIHsgb2s6IGZhbHNlLCBpc3N1ZXM6IFt7IGNvZGU6ICdWQUxJREFUSU9OX0ZBSUxFRCcsIHBhdGgsIG1lc3NhZ2U6ICfkvZzlk4Hjga/jgqrjg5bjgrjjgqfjgq/jg4jjgafjgZnjgIInIH1dIH07XG4gIGZvciAoY29uc3QgZmllbGQgb2YgT2JqZWN0LmtleXMoaW5wdXQpKSBpZiAoIXByb2plY3RDb250ZW50S2V5cy5pbmNsdWRlcyhmaWVsZCkpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtmaWVsZH1gLCAn5L2c5ZOB44Gr5pyq55+l44Gu6aCF55uu44GM44GC44KK44G+44GZ44CCJyk7XG4gIGNvbnN0IGhlYWRlciA9IE9iamVjdC5mcm9tRW50cmllcyhPYmplY3Qua2V5cyhwcm9qZWN0SGVhZGVyRmllbGRzKS5maWx0ZXIoZmllbGQgPT4gT2JqZWN0Lmhhc093bihpbnB1dCwgZmllbGQpKS5tYXAoZmllbGQgPT4gW2ZpZWxkLCBpbnB1dFtmaWVsZF1dKSk7XG4gIHdhbGsob2JqKHByb2plY3RIZWFkZXJGaWVsZHMpLCBoZWFkZXIsIHBhdGgsIGlzc3VlcywgW10pO1xuICBpZiAoaW5wdXQuZm9ybWF0VmVyc2lvbiAhPT0gRk9STUFUX1ZFUlNJT04pIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uZm9ybWF0VmVyc2lvbmAsICflr77lv5zjgZfjgabjgYTjgarjgYTlvaLlvI/niYjjgafjgZnjgIInLCAnRk9STUFUX1VOU1VQUE9SVEVEJyk7XG4gIGNvbnN0IGFycmF5cyA9IFsnZW50aXRpZXMnLCAncmVsYXRpb25zJywgJ2NhbGVuZGFycycsICd2aWV3cyddO1xuICBmb3IgKGNvbnN0IGZpZWxkIG9mIGFycmF5cykgaWYgKCFBcnJheS5pc0FycmF5KGlucHV0W2ZpZWxkXSkpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtmaWVsZH1gLCAn5b+F6aCI44Gu6YWN5YiX44Gn44GZ44CCJyk7XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlcyB9O1xuICBjb25zdCBlbnRpdGllcyA9IGlucHV0LmVudGl0aWVzIGFzIHVua25vd25bXSwgcmVsYXRpb25zID0gaW5wdXQucmVsYXRpb25zIGFzIHVua25vd25bXSwgY2FsZW5kYXJzID0gaW5wdXQuY2FsZW5kYXJzIGFzIHVua25vd25bXTtcbiAgaWYgKGVudGl0aWVzLmxlbmd0aCArIHJlbGF0aW9ucy5sZW5ndGggPiAxMDBfMDAwKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogW3sgY29kZTogJ0lNUE9SVF9MSU1JVCcsIHBhdGgsIG1lc3NhZ2U6ICdlbnRpdHnjgahyZWxhdGlvbuOBruWQiOioiOOBrzEwMCwwMDDku7bjgb7jgafjgafjgZnjgIInIH1dIH07XG4gIGNvbnN0IHByZXZpb3VzRW50aXRpZXMgPSBuZXcgTWFwKHJldXNlPy5wcmV2aW91cy5lbnRpdGllcy5tYXAoZW50aXR5ID0+IFtlbnRpdHkuaWQsIGVudGl0eV0pKSwgcHJldmlvdXNSZWxhdGlvbnMgPSBuZXcgTWFwKHJldXNlPy5wcmV2aW91cy5yZWxhdGlvbnMubWFwKHJlbGF0aW9uID0+IFtyZWxhdGlvbi5pZCwgcmVsYXRpb25dKSk7XG4gIC8vIFRoZSBzdHJ1Y3R1cmFsIHdhbGsgYWxyZWFkeSBzZWVzIGV2ZXJ5IHR5cGVkIHJlZmVyZW5jZS4gS2VlcCB0aG9zZSBleGFjdFxuICAvLyBvYnNlcnZhdGlvbnMgZm9yIHRoaXMgc3luY2hyb25vdXMgdmFsaWRhdGlvbiBpbnN0ZWFkIG9mIHdhbGtpbmcgaXQgdHdpY2UuXG4gIGNvbnN0IGVudGl0eVJlZmVyZW5jZXM9bmV3IFdlYWtNYXA8RW50aXR5LERvbWFpblJlZmVyZW5jZVtdPigpLHJlbGF0aW9uUmVmZXJlbmNlcz1uZXcgV2Vha01hcDxSZWxhdGlvbixEb21haW5SZWZlcmVuY2VbXT4oKTtcbiAgY29uc3QgcmVsYXRpdmU9KHJlZmVyZW5jZXM6RG9tYWluUmVmZXJlbmNlW10scHJlZml4OnN0cmluZyk9PnJlZmVyZW5jZXMubWFwKHJlZmVyZW5jZT0+KHsuLi5yZWZlcmVuY2UscGF0aDpyZWZlcmVuY2UucGF0aC5zbGljZShwcmVmaXgubGVuZ3RoKzEpfSkpO1xuICBlbnRpdGllcy5mb3JFYWNoKChlbnRpdHksIGkpID0+IHsgaWYgKHJldXNlICYmIGlzT2JqZWN0KGVudGl0eSkgJiYgcHJldmlvdXNFbnRpdGllcy5nZXQoZW50aXR5LmlkIGFzIElEKSA9PT0gZW50aXR5KSByZXR1cm47IGNvbnN0IHByZWZpeD1gJHtwYXRofS5lbnRpdGllc1ske2l9XWAscmVmZXJlbmNlczpEb21haW5SZWZlcmVuY2VbXT1bXTtjb25zdCByZXN1bHQgPSB2YWxpZGF0ZUVudGl0eVJlY29yZChlbnRpdHkscHJlZml4LHJlZmVyZW5jZXMpOyBpZiAoIXJlc3VsdC5vaykgaXNzdWVzLnB1c2goLi4ucmVzdWx0Lmlzc3Vlcyk7ZWxzZSBlbnRpdHlSZWZlcmVuY2VzLnNldChyZXN1bHQudmFsdWUscmVsYXRpdmUocmVmZXJlbmNlcyxwcmVmaXgpKTsgfSk7XG4gIHJlbGF0aW9ucy5mb3JFYWNoKChyZWxhdGlvbiwgaSkgPT4geyBpZiAocmV1c2UgJiYgaXNPYmplY3QocmVsYXRpb24pICYmIE9iamVjdC5pcyhwcmV2aW91c1JlbGF0aW9ucy5nZXQocmVsYXRpb24uaWQgYXMgSUQpLCByZWxhdGlvbikpIHJldHVybjtjb25zdCBwcmVmaXg9YCR7cGF0aH0ucmVsYXRpb25zWyR7aX1dYCxyZWZlcmVuY2VzOkRvbWFpblJlZmVyZW5jZVtdPVtdO2NvbnN0IHJlc3VsdCA9IHNpbXBsZVZhbGlkYXRlPFJlbGF0aW9uPihyZWxhdGlvblNjaGVtYSxyZWxhdGlvbixwcmVmaXgscmVmZXJlbmNlcyk7IGlmICghcmVzdWx0Lm9rKSBpc3N1ZXMucHVzaCguLi5yZXN1bHQuaXNzdWVzKTtlbHNlIHJlbGF0aW9uUmVmZXJlbmNlcy5zZXQocmVzdWx0LnZhbHVlLHJlbGF0aXZlKHJlZmVyZW5jZXMscHJlZml4KSk7IH0pO1xuICBjYWxlbmRhcnMuZm9yRWFjaCgoY2FsZW5kYXIsIGkpID0+IHsgY29uc3QgcmVzdWx0ID0gdmFsaWRhdGVDYWxlbmRhcihjYWxlbmRhciwgYCR7cGF0aH0uY2FsZW5kYXJzWyR7aX1dYCk7IGlmICghcmVzdWx0Lm9rKSBpc3N1ZXMucHVzaCguLi5yZXN1bHQuaXNzdWVzKTsgfSk7XG4gIGNvbnN0IHZpZXdSZWZzOiBEb21haW5SZWZlcmVuY2VbXSA9IFtdOyB3YWxrKGFycih2aWV3U2NoZW1hKSwgaW5wdXQudmlld3MsIGAke3BhdGh9LnZpZXdzYCwgaXNzdWVzLCB2aWV3UmVmcyk7XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogaXNzdWVzLnNsaWNlKDAsIDI1NikgfTtcbiAgY29uc3QgcHJvamVjdCA9IGlucHV0IGFzIHVua25vd24gYXMgUHJvamVjdENvbnRlbnQ7XG4gIGNvbnN0IHJldXNhYmxlU25hcHNob3RzID0gWy4uLnZlcnNpb25Db250ZW50c10ubWFwKChbaWQsIGNvbnRlbnRdKSA9PiAoeyBpZCwgY29udGVudCwgY29udGVudEhhc2g6ICcnLCBjcmVhdGVkQXQ6ICcnLCB2ZXJzaW9uTGFiZWw6ICcnIH0pKTtcbiAgaXNzdWVzLnB1c2goLi4ucmV1c2VWYWxpZGF0aW9uSXNzdWVzKHByb2plY3QsIHJldXNhYmxlU25hcHNob3RzLCBwYXRoKSk7XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogaXNzdWVzLnNsaWNlKDAsIDI1NikgfTtcbiAgY29uc3QgZXhlY3V0aW9uUHJvamVjdCA9IHByb2plY3QuZW50aXRpZXMuc29tZShlbnRpdHkgPT4gKGVudGl0eS5raW5kID09PSAnc2NlbmUnIHx8IGVudGl0eS5raW5kID09PSAnZmxvd19ub2RlJykgJiYgZW50aXR5LmRhdGEucmV1c2U/LmJpbmRpbmdzKSA/IHJlc29sdmVSZXVzZUNvbnRlbnQocHJvamVjdCwgcmV1c2FibGVTbmFwc2hvdHMpIDogcHJvamVjdDtcbiAgY29uc3QgYWxsb3dlZFdvcmxkSWRzID0gbmV3IFNldChleGVjdXRpb25Qcm9qZWN0LndvcmxkUmVmZXJlbmNlcy5tYXAocmVmZXJlbmNlID0+IHJlZmVyZW5jZS5wcm9qZWN0SWQpKTtcbiAgY29uc3QgY2xvc3VyZSA9IG9wdGlvbnMud29ybGRTbmFwc2hvdHMgPyByZXNvbHZlUGlubmVkV29ybGRzKGV4ZWN1dGlvblByb2plY3QsIG9wdGlvbnMud29ybGRTbmFwc2hvdHMpIDogdW5kZWZpbmVkO1xuICBpZiAoY2xvc3VyZSkgZm9yIChjb25zdCBtZXNzYWdlIG9mIGNsb3N1cmUuZXJyb3JzKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9LndvcmxkUmVmZXJlbmNlc2AsIG1lc3NhZ2UsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICBjb25zdCB3b3JsZHMgPSBjbG9zdXJlPy53b3JsZHMgPz8gKG9wdGlvbnMud29ybGRzID8/IFtdKS5maWx0ZXIod29ybGQgPT4gYWxsb3dlZFdvcmxkSWRzLmhhcyh3b3JsZC5wcm9qZWN0SWQpKTtcbiAgaWYgKGVudGl0aWVzLmxlbmd0aCArIHJlbGF0aW9ucy5sZW5ndGggKyB3b3JsZHMucmVkdWNlKChjb3VudCwgd29ybGQpID0+IGNvdW50ICsgd29ybGQuZW50aXRpZXMubGVuZ3RoICsgd29ybGQucmVsYXRpb25zLmxlbmd0aCwgMCkgPiAxMDBfMDAwKSBhZGRJc3N1ZShpc3N1ZXMsIHBhdGgsICflj4LnhafkuJbnlYzjgpLlkKvjgoDjg6zjgrPjg7zjg4nmlbDjgYwxMDAsMDAw5Lu244KS6LaF44GI44Gm44GE44G+44GZ44CCJywgJ0lNUE9SVF9MSU1JVCcpO1xuICAvLyBWYWxpZGF0ZSBiZWZvcmUgY29uc3RydWN0aW5nIG1hcHM6IGEgd29ybGQgcmVjb3JkIG11c3QgbmV2ZXIgb3ZlcndyaXRlIGEgbG9jYWwgSUQuXG4gIC8vIEVhY2ggaGlzdG9yaWNhbCBjb250ZW50IGNhbGxzIHRoaXMgaW5kZXBlbmRlbnRseSB3aXRoIGl0cyBvd24gcGlubmVkIHdvcmxkcy5cbiAgdmFsaWRhdGVBY3RpdmVSZWNvcmROYW1lc3BhY2UocHJvamVjdCwgd29ybGRzLCBwYXRoLCBpc3N1ZXMpO1xuICBpZiAoZXhlY3V0aW9uUHJvamVjdCAhPT0gcHJvamVjdCkgdmFsaWRhdGVBY3RpdmVSZWNvcmROYW1lc3BhY2UoZXhlY3V0aW9uUHJvamVjdCwgd29ybGRzLCBgJHtwYXRofS5yZXVzZWAsIGlzc3Vlcyk7XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogaXNzdWVzLnNsaWNlKDAsIDI1NikgfTtcbiAgY29uc3QgYWxsRW50aXRpZXMgPSBbLi4uZXhlY3V0aW9uUHJvamVjdC5lbnRpdGllcywgLi4ud29ybGRzLmZsYXRNYXAod29ybGQgPT4gd29ybGQuZW50aXRpZXMpXSwgZW50aXR5TWFwID0gbmV3IE1hcChhbGxFbnRpdGllcy5tYXAoZW50aXR5ID0+IFtlbnRpdHkuaWQsIGVudGl0eV0pKTtcbiAgY29uc3QgcmVsYXRpb25NYXAgPSBuZXcgTWFwKFsuLi5wcm9qZWN0LnJlbGF0aW9ucywgLi4ud29ybGRzLmZsYXRNYXAod29ybGQgPT4gd29ybGQucmVsYXRpb25zKV0ubWFwKHJlbGF0aW9uID0+IFtyZWxhdGlvbi5pZCwgcmVsYXRpb25dKSk7XG4gIGNvbnN0IGFsbENhbGVuZGFySWRzID0gbmV3IFNldChbLi4ucHJvamVjdC5jYWxlbmRhcnMsIC4uLndvcmxkcy5mbGF0TWFwKHdvcmxkID0+IHdvcmxkLmNhbGVuZGFycyldLm1hcChjYWxlbmRhciA9PiBjYWxlbmRhci5pZCkpO1xuICBjb25zdCBpZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCBbY29sbGVjdGlvbiwgcmVjb3Jkc10gb2YgW1snZW50aXRpZXMnLCBwcm9qZWN0LmVudGl0aWVzXSwgWydyZWxhdGlvbnMnLCBwcm9qZWN0LnJlbGF0aW9uc11dIGFzIGNvbnN0KSByZWNvcmRzLmZvckVhY2goKHJlY29yZCwgaSkgPT4ge1xuICAgIGlmIChpZHMuaGFzKHJlY29yZC5pZCkpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtjb2xsZWN0aW9ufVske2l9XS5pZGAsICdlbnRpdHnjgahyZWxhdGlvbuOBrklE44Gv5L2c5ZOB5YaF44Gn5LiA5oSP44Gn44GZ44CCJyk7IGlkcy5hZGQocmVjb3JkLmlkKTtcbiAgICBpZiAocmVjb3JkLnByb2plY3RJZCAhPT0gcHJvamVjdC5wcm9qZWN0SWQpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtjb2xsZWN0aW9ufVske2l9XS5wcm9qZWN0SWRgLCAn44Os44Kz44O844OJ44GM5Yil44Gu5L2c5ZOB44Gr5bGe44GX44Gm44GE44G+44GZ44CCJywgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gIH0pO1xuICBjb25zdCBjYWxlbmRhcklkcyA9IHByb2plY3QuY2FsZW5kYXJzLm1hcChjYWxlbmRhciA9PiBjYWxlbmRhci5pZCk7XG4gIGlmIChuZXcgU2V0KGNhbGVuZGFySWRzKS5zaXplICE9PSBjYWxlbmRhcklkcy5sZW5ndGgpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uY2FsZW5kYXJzYCwgJ+aapklE44GM6YeN6KSH44GX44Gm44GE44G+44GZ44CCJyk7XG4gIGlmICghY2FsZW5kYXJJZHMuaW5jbHVkZXMocHJvamVjdC5jYWxlbmRhcklkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5jYWxlbmRhcklkYCwgJ+S9nOWTgeOBruaapuOBjOWumue+qeOBleOCjOOBpuOBhOOBvuOBm+OCk+OAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICBjb25zdCB3b3JsZEtleXMgPSBwcm9qZWN0LndvcmxkUmVmZXJlbmNlcy5tYXAod29ybGQgPT4gYCR7d29ybGQucHJvamVjdElkfS8ke3dvcmxkLmltbXV0YWJsZVNuYXBzaG90SWR9YCk7XG4gIGlmIChuZXcgU2V0KHdvcmxkS2V5cykuc2l6ZSAhPT0gd29ybGRLZXlzLmxlbmd0aCB8fCBwcm9qZWN0LndvcmxkUmVmZXJlbmNlcy5zb21lKHdvcmxkID0+IHdvcmxkLnByb2plY3RJZCA9PT0gcHJvamVjdC5wcm9qZWN0SWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9LndvcmxkUmVmZXJlbmNlc2AsICflhbHpgJrkuJbnlYzlj4Lnhafjga7ph43opIfjgb7jgZ/jga/oh6rlt7Hlj4LnhafjgYzjgYLjgorjgb7jgZnjgIInKTtcbiAgY29uc3QgYmxvY2tzID0gbmV3IE1hcDxJRCwgeyBlbnRpdHlJZDogSUQ7IHRleHQ6IHN0cmluZyB9PigpLCBhbGlhc2VzID0gbmV3IE1hcDxJRCwgeyBlbnRpdHlJZDogSUQ7IGFsaWFzOiBBbGlhcyB9PigpO1xuICBmb3IgKGNvbnN0IGVudGl0eSBvZiBhbGxFbnRpdGllcykgY29sbGVjdENvbnRlbnRJZHMoZW50aXR5LmRhdGEsIGVudGl0eS5pZCwgYmxvY2tzLCBhbGlhc2VzLCBpc3N1ZXMsIGAke3BhdGh9LmVudGl0aWVzLiR7ZW50aXR5LmlkfS5kYXRhYCk7XG4gIGNvbnN0IHByb2plY3Rpb25JZHMgPSBuZXcgU2V0PElEPihbLi4uZW50aXR5TWFwLmtleXMoKSwgLi4ucmVsYXRpb25NYXAua2V5cygpLCAuLi5ibG9ja3Mua2V5cygpXSk7XG4gIGZvciAoY29uc3QgZW50aXR5IG9mIGFsbEVudGl0aWVzKSB7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnZmxvd19ub2RlJyAmJiBlbnRpdHkuZGF0YS50cmlnZ2VyPy5pZCkgcHJvamVjdGlvbklkcy5hZGQoZW50aXR5LmRhdGEudHJpZ2dlci5pZCk7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAncHJvamVjdGlvbl9wcm9maWxlJykgZm9yIChjb25zdCBwdWJsaWNGaWVsZHMgb2YgT2JqZWN0LnZhbHVlcyhlbnRpdHkuZGF0YS5wdWJsaWNUZXh0cyA/PyB7fSkpIGZvciAoY29uc3QgZmllbGQgb2YgT2JqZWN0LnZhbHVlcyhwdWJsaWNGaWVsZHMpKSBpZiAoQXJyYXkuaXNBcnJheShmaWVsZCkpIGZvciAoY29uc3QgYmxvY2sgb2YgZmllbGQpIGlmIChpc09iamVjdChibG9jaykgJiYgdHlwZW9mIGJsb2NrLmlkID09PSAnc3RyaW5nJykgcHJvamVjdGlvbklkcy5hZGQoYmxvY2suaWQpO1xuICB9XG4gIGNvbnN0IHdvcmxkVmVyc2lvbkRlcGVuZGVuY2llcyA9IHdvcmxkcy5mbGF0TWFwKHdvcmxkID0+IFsuLi53b3JsZC5lbnRpdGllcy5mbGF0TWFwKGNvbGxlY3RSZWZlcmVuY2VzKSwgLi4ud29ybGQucmVsYXRpb25zLmZsYXRNYXAoY29sbGVjdFJlbGF0aW9uUmVmZXJlbmNlcyldKVxuICAgIC5maWx0ZXIocmVmZXJlbmNlID0+IHJlZmVyZW5jZS5zY29wZSA9PT0gJ3NuYXBzaG90JyAmJiBvcHRpb25zLndvcmxkU25hcHNob3RzPy5bcmVmZXJlbmNlLmlkXSAmJiB3b3JsZHMuc29tZSh3b3JsZCA9PiB3b3JsZC5wcm9qZWN0SWQgPT09IG9wdGlvbnMud29ybGRTbmFwc2hvdHM/LltyZWZlcmVuY2UuaWRdLnByb2plY3RJZCkpLm1hcChyZWZlcmVuY2UgPT4gcmVmZXJlbmNlLmlkKTtcbiAgY29uc3Qga25vd25WZXJzaW9ucyA9IG5ldyBTZXQoWy4uLnNuYXBzaG90SWRzLCAuLi53b3JsZFZlcnNpb25EZXBlbmRlbmNpZXMsIHByb2plY3QucHJvamVjdElkLCAuLi5hbGxFbnRpdGllcy5maWx0ZXIoZW50aXR5ID0+IGVudGl0eS5raW5kID09PSAnc25hcHNob3QnKS5tYXAoZW50aXR5ID0+IGVudGl0eS5pZCksIC4uLihjbG9zdXJlPy5yZWZlcmVuY2VzID8/IGV4ZWN1dGlvblByb2plY3Qud29ybGRSZWZlcmVuY2VzKS5tYXAod29ybGQgPT4gd29ybGQuaW1tdXRhYmxlU25hcHNob3RJZCldKTtcbiAgY29uc3Qga25vd25Qcm9qZWN0cyA9IG5ldyBTZXQoW3Byb2plY3QucHJvamVjdElkLCAuLi4oY2xvc3VyZT8ucmVmZXJlbmNlcyA/PyBleGVjdXRpb25Qcm9qZWN0LndvcmxkUmVmZXJlbmNlcykubWFwKHdvcmxkID0+IHdvcmxkLnByb2plY3RJZCldKTtcbiAgdHlwZSBSZWZlcmVuY2VJbmRleCA9IHsgZW50aXRpZXM6IE1hcDxJRCwgRW50aXR5PjsgcmVsYXRpb25zOiBNYXA8SUQsIFJlbGF0aW9uPjsgYmxvY2tzOiBNYXA8SUQsIHsgZW50aXR5SWQ6IElEOyB0ZXh0OiBzdHJpbmcgfT47IGNhbGVuZGFyczogU2V0PHN0cmluZz47IHByb2plY3RzOiBTZXQ8SUQ+OyBwcm9qZWN0aW9uSWRzOlNldDxJRD4gfTtcbiAgY29uc3QgY3VycmVudEluZGV4OiBSZWZlcmVuY2VJbmRleCA9IHsgZW50aXRpZXM6IGVudGl0eU1hcCwgcmVsYXRpb25zOiByZWxhdGlvbk1hcCwgYmxvY2tzLCBjYWxlbmRhcnM6IGFsbENhbGVuZGFySWRzLCBwcm9qZWN0czoga25vd25Qcm9qZWN0cyxwcm9qZWN0aW9uSWRzIH0sIHZlcnNpb25JbmRleGVzID0gbmV3IE1hcDxJRCwgUmVmZXJlbmNlSW5kZXg+KCk7XG4gIGZ1bmN0aW9uIHZlcnNpb25JbmRleCh2ZXJzaW9uSWQ6IElEKTogUmVmZXJlbmNlSW5kZXggfCB1bmRlZmluZWQge1xuICAgIGlmICh2ZXJzaW9uSWQgPT09IHByb2plY3QucHJvamVjdElkICYmICFwcm9qZWN0LmVudGl0aWVzLnNvbWUoZW50aXR5ID0+IChlbnRpdHkua2luZCA9PT0gJ3NjZW5lJyB8fCBlbnRpdHkua2luZCA9PT0gJ2Zsb3dfbm9kZScpICYmIGVudGl0eS5kYXRhLnJldXNlPy5iaW5kaW5ncykpIHJldHVybiBjdXJyZW50SW5kZXg7XG4gICAgY29uc3QgY2FjaGVkID0gdmVyc2lvbkluZGV4ZXMuZ2V0KHZlcnNpb25JZCk7IGlmIChjYWNoZWQpIHJldHVybiBjYWNoZWQ7XG4gICAgY29uc3QgcmF3Q29udGVudCA9IHZlcnNpb25JZCA9PT0gcHJvamVjdC5wcm9qZWN0SWQgPyBwcm9qZWN0IDogdmVyc2lvbkNvbnRlbnRzLmdldCh2ZXJzaW9uSWQpID8/IG9wdGlvbnMud29ybGRTbmFwc2hvdHM/Llt2ZXJzaW9uSWRdOyBpZiAoIXJhd0NvbnRlbnQpIHJldHVybiB1bmRlZmluZWQ7XG4gICAgbGV0IGNvbnRlbnQgPSByYXdDb250ZW50O1xuICAgIHRyeSB7IGlmIChjb250ZW50LmVudGl0aWVzLnNvbWUoZW50aXR5ID0+IChlbnRpdHkua2luZCA9PT0gJ3NjZW5lJyB8fCBlbnRpdHkua2luZCA9PT0gJ2Zsb3dfbm9kZScpICYmIGVudGl0eS5kYXRhLnJldXNlPy5iaW5kaW5ncykpIGNvbnRlbnQgPSByZXNvbHZlUmV1c2VDb250ZW50KGNvbnRlbnQsIHJldXNhYmxlU25hcHNob3RzKTsgfSBjYXRjaCB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICBjb25zdCB2ZXJzaW9uQ2xvc3VyZSA9IG9wdGlvbnMud29ybGRTbmFwc2hvdHMgPyByZXNvbHZlUGlubmVkV29ybGRzKGNvbnRlbnQsIG9wdGlvbnMud29ybGRTbmFwc2hvdHMpIDogdW5kZWZpbmVkO1xuICAgIGlmICh2ZXJzaW9uQ2xvc3VyZSkgZm9yIChjb25zdCBtZXNzYWdlIG9mIHZlcnNpb25DbG9zdXJlLmVycm9ycykgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS52ZXJzaW9ucy4ke3ZlcnNpb25JZH0ud29ybGRSZWZlcmVuY2VzYCwgbWVzc2FnZSwgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgY29uc3QgcGlubmVkV29ybGRzID0gdmVyc2lvbkNsb3N1cmU/LndvcmxkcyA/PyAob3B0aW9ucy53b3JsZHMgPz8gW10pLmZpbHRlcih3b3JsZCA9PiBjb250ZW50LndvcmxkUmVmZXJlbmNlcy5zb21lKHJlZmVyZW5jZSA9PiByZWZlcmVuY2UucHJvamVjdElkID09PSB3b3JsZC5wcm9qZWN0SWQpKTtcbiAgICBjb25zdCBiZWZvcmUgPSBpc3N1ZXMubGVuZ3RoOyB2YWxpZGF0ZUFjdGl2ZVJlY29yZE5hbWVzcGFjZShjb250ZW50LCBwaW5uZWRXb3JsZHMsIGAke3BhdGh9LnZlcnNpb25zLiR7dmVyc2lvbklkfWAsIGlzc3Vlcyk7XG4gICAgaWYgKGlzc3Vlcy5sZW5ndGggIT09IGJlZm9yZSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBjb25zdCByZWNvcmRzID0gWy4uLmNvbnRlbnQuZW50aXRpZXMsIC4uLnBpbm5lZFdvcmxkcy5mbGF0TWFwKHdvcmxkID0+IHdvcmxkLmVudGl0aWVzKV0sIHZlcnNpb25CbG9ja3MgPSBuZXcgTWFwPElELCB7IGVudGl0eUlkOiBJRDsgdGV4dDogc3RyaW5nIH0+KCk7XG4gICAgZm9yIChjb25zdCByZWNvcmQgb2YgcmVjb3JkcykgaWYgKGlzT2JqZWN0KHJlY29yZCkpIGNvbGxlY3RDb250ZW50SWRzKHJlY29yZC5kYXRhLCByZWNvcmQuaWQsIHZlcnNpb25CbG9ja3MsIG5ldyBNYXAoKSwgW10sICd2ZXJzaW9uJyk7XG4gICAgY29uc3QgdmVyc2lvblByb2plY3Rpb25JZHM9bmV3IFNldChbLi4ucmVjb3Jkcy5tYXAocmVjb3JkPT5yZWNvcmQuaWQpLC4uLmNvbnRlbnQucmVsYXRpb25zLm1hcChyZWxhdGlvbj0+cmVsYXRpb24uaWQpLC4uLnBpbm5lZFdvcmxkcy5mbGF0TWFwKHdvcmxkPT53b3JsZC5yZWxhdGlvbnMubWFwKHJlbGF0aW9uPT5yZWxhdGlvbi5pZCkpLC4uLnZlcnNpb25CbG9ja3Mua2V5cygpXSk7XG4gICAgZm9yKGNvbnN0IGVudGl0eSBvZiByZWNvcmRzKXtpZihlbnRpdHkua2luZD09PSdmbG93X25vZGUnJiZlbnRpdHkuZGF0YS50cmlnZ2VyPy5pZCl2ZXJzaW9uUHJvamVjdGlvbklkcy5hZGQoZW50aXR5LmRhdGEudHJpZ2dlci5pZCk7aWYoZW50aXR5LmtpbmQ9PT0ncHJvamVjdGlvbl9wcm9maWxlJylmb3IoY29uc3QgZmllbGRzIG9mIE9iamVjdC52YWx1ZXMoZW50aXR5LmRhdGEucHVibGljVGV4dHM/P3t9KSlmb3IoY29uc3QgdmFsdWUgb2YgT2JqZWN0LnZhbHVlcyhmaWVsZHMpKWlmKEFycmF5LmlzQXJyYXkodmFsdWUpKWZvcihjb25zdCBibG9jayBvZiB2YWx1ZSlpZihpc09iamVjdChibG9jaykmJnR5cGVvZiBibG9jay5pZD09PSdzdHJpbmcnKXZlcnNpb25Qcm9qZWN0aW9uSWRzLmFkZChibG9jay5pZCk7fVxuICAgIGNvbnN0IGluZGV4ID0geyBlbnRpdGllczogbmV3IE1hcChyZWNvcmRzLmZpbHRlcihyZWNvcmQgPT4gaXNPYmplY3QocmVjb3JkKSkubWFwKHJlY29yZCA9PiBbcmVjb3JkLmlkLCByZWNvcmRdKSksIHJlbGF0aW9uczogbmV3IE1hcChbLi4uY29udGVudC5yZWxhdGlvbnMsIC4uLnBpbm5lZFdvcmxkcy5mbGF0TWFwKHdvcmxkID0+IHdvcmxkLnJlbGF0aW9ucyldLmZpbHRlcihyZWNvcmQgPT4gaXNPYmplY3QocmVjb3JkKSkubWFwKHJlY29yZCA9PiBbcmVjb3JkLmlkLCByZWNvcmRdKSksIGJsb2NrczogdmVyc2lvbkJsb2NrcywgY2FsZW5kYXJzOiBuZXcgU2V0KFsuLi5jb250ZW50LmNhbGVuZGFycywgLi4ucGlubmVkV29ybGRzLmZsYXRNYXAod29ybGQgPT4gd29ybGQuY2FsZW5kYXJzKV0ubWFwKGNhbGVuZGFyID0+IGNhbGVuZGFyLmlkKSksIHByb2plY3RzOiBuZXcgU2V0KFtjb250ZW50LnByb2plY3RJZCwgLi4ucGlubmVkV29ybGRzLm1hcCh3b3JsZCA9PiB3b3JsZC5wcm9qZWN0SWQpXSkscHJvamVjdGlvbklkczp2ZXJzaW9uUHJvamVjdGlvbklkcyB9O1xuICAgIHZlcnNpb25JbmRleGVzLnNldCh2ZXJzaW9uSWQsIGluZGV4KTsgcmV0dXJuIGluZGV4O1xuICB9XG4gIGZ1bmN0aW9uIGluc3BlY3QocmVmZXJlbmNlOiBEb21haW5SZWZlcmVuY2UsIHByZWZpeCA9ICcnLCBpbmRleCA9IGN1cnJlbnRJbmRleCk6IHZvaWQge1xuICAgIGNvbnN0IGxvY2F0aW9uID0gcHJlZml4ID8gYCR7cHJlZml4fS4ke3JlZmVyZW5jZS5wYXRofWAgOiByZWZlcmVuY2UucGF0aDtcbiAgICBsZXQgZXhpc3RzID0gdHJ1ZTtcbiAgICBpZiAocmVmZXJlbmNlLnNjb3BlID09PSAnZW50aXR5Jykge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gaW5kZXguZW50aXRpZXMuZ2V0KHJlZmVyZW5jZS5pZCk7IGV4aXN0cyA9ICEhdGFyZ2V0O1xuICAgICAgaWYgKHRhcmdldCAmJiByZWZlcmVuY2Uua2luZHMgJiYgIXJlZmVyZW5jZS5raW5kcy5pbmNsdWRlcyh0YXJnZXQua2luZCkpIGFkZElzc3VlKGlzc3VlcywgbG9jYXRpb24sIGDlj4LnhaflhYjjga7nqK7poZ7jga8ke3JlZmVyZW5jZS5raW5kcy5tYXAoa2luZCA9PiBLSU5EX0xBQkVMU1traW5kXSkuam9pbignIC8gJyl944Gn44GZ44CCYCwgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgICBpZiAodGFyZ2V0ICYmIG9wdGlvbnMucnVudGltZSAmJiB0YXJnZXQuZGVsZXRlZEF0KSBhZGRJc3N1ZShpc3N1ZXMsIGxvY2F0aW9uLCAn5YmK6Zmk5riI44G/5oOF5aCx44Gv5a6f6KGM55So5Ye65Yqb44Gn5Y+C54Wn44Gn44GN44G+44Gb44KT44CCJywgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgfSBlbHNlIGlmIChyZWZlcmVuY2Uuc2NvcGUgPT09ICdyZWxhdGlvbicpIGV4aXN0cyA9IGluZGV4LnJlbGF0aW9ucy5oYXMocmVmZXJlbmNlLmlkKTtcbiAgICBlbHNlIGlmIChyZWZlcmVuY2Uuc2NvcGUgPT09ICdyZWNvcmQnKSBleGlzdHMgPSBpbmRleC5lbnRpdGllcy5oYXMocmVmZXJlbmNlLmlkKSB8fCBpbmRleC5yZWxhdGlvbnMuaGFzKHJlZmVyZW5jZS5pZCk7XG4gICAgZWxzZSBpZiAocmVmZXJlbmNlLnNjb3BlID09PSAncHJvamVjdGlvbl9yZWNvcmQnKSBleGlzdHMgPSBpbmRleC5wcm9qZWN0aW9uSWRzLmhhcyhyZWZlcmVuY2UuaWQpO1xuICAgIGVsc2UgaWYgKHJlZmVyZW5jZS5zY29wZSA9PT0gJ3ByZXNlbnRhdGlvbicpIGV4aXN0cyA9IGluZGV4LmVudGl0aWVzLmhhcyhyZWZlcmVuY2UuaWQpIHx8IGluZGV4LmJsb2Nrcy5oYXMocmVmZXJlbmNlLmlkKTtcbiAgICBlbHNlIGlmIChyZWZlcmVuY2Uuc2NvcGUgPT09ICdjYWxlbmRhcicpIGV4aXN0cyA9IGluZGV4LmNhbGVuZGFycy5oYXMocmVmZXJlbmNlLmlkKTtcbiAgICBlbHNlIGlmIChyZWZlcmVuY2Uuc2NvcGUgPT09ICdwcm9qZWN0JykgZXhpc3RzID0gaW5kZXgucHJvamVjdHMuaGFzKHJlZmVyZW5jZS5pZCk7XG4gICAgZWxzZSBpZiAocmVmZXJlbmNlLnNjb3BlID09PSAnc25hcHNob3QnKSBleGlzdHMgPSBrbm93blZlcnNpb25zLmhhcyhyZWZlcmVuY2UuaWQpO1xuICAgIGVsc2UgaWYgKHJlZmVyZW5jZS5zY29wZSA9PT0gJ2Jsb2NrJykgZXhpc3RzID0gaW5kZXguYmxvY2tzLmhhcyhyZWZlcmVuY2UuaWQpO1xuICAgIGVsc2UgaWYgKHJlZmVyZW5jZS5zY29wZSA9PT0gJ2FsaWFzJykgZXhpc3RzID0gYWxpYXNlcy5oYXMocmVmZXJlbmNlLmlkKTtcbiAgICBpZiAoIWV4aXN0cykgYWRkSXNzdWUoaXNzdWVzLCBsb2NhdGlvbiwgJ+WPgueFp+WFiOOBjOWtmOWcqOOBl+OBquOBhOOBi+OAgeaMh+WumuOBl+OBn+S9nOWTgeODu+WFsemAmuS4lueVjOOBruevhOWbsuWkluOBp+OBmeOAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICB9XG4gIGNvbnN0IHJlZmVyZW5jZXNGb3IgPSAoZW50aXR5OiBFbnRpdHkpOiBEb21haW5SZWZlcmVuY2VbXSA9PiB7XG4gICAgY29uc3Qgb2JzZXJ2ZWQ9ZW50aXR5UmVmZXJlbmNlcy5nZXQoZW50aXR5KTtpZihvYnNlcnZlZClyZXR1cm4gb2JzZXJ2ZWQ7XG4gICAgaWYgKCFyZXVzZSB8fCBwcmV2aW91c0VudGl0aWVzLmdldChlbnRpdHkuaWQpICE9PSBlbnRpdHkpIHJldHVybiBjb2xsZWN0UmVmZXJlbmNlcyhlbnRpdHkpO1xuICAgIGNvbnN0IGNhY2hlZCA9IHJldXNlLnJlZmVyZW5jZXMuZ2V0KGVudGl0eSk7XG4gICAgaWYgKGNhY2hlZCkgcmV0dXJuIGNhY2hlZDtcbiAgICBjb25zdCByZWZlcmVuY2VzID0gY29sbGVjdFJlZmVyZW5jZXMoZW50aXR5KTsgcmV1c2UucmVmZXJlbmNlcy5zZXQoZW50aXR5LCByZWZlcmVuY2VzKTsgcmV0dXJuIHJlZmVyZW5jZXM7XG4gIH07XG4gIHByb2plY3QuZW50aXRpZXMuZm9yRWFjaCgoZW50aXR5LCBpKSA9PiB7XG4gICAgY29uc3QgcHJlZml4ID0gYCR7cGF0aH0uZW50aXRpZXNbJHtpfV1gO1xuICAgIGZvciAoY29uc3QgcmVmZXJlbmNlIG9mIHJlZmVyZW5jZXNGb3IoZW50aXR5KSkge1xuICAgICAgY29uc3QgcGFydHMgPSBwYXRoUGFydHMocmVmZXJlbmNlLnBhdGgpLCBwYXJlbnQgPSBwYXJ0cy5zbGljZSgwLCAtMSkucmVkdWNlPHVua25vd24+KChvYmplY3QsIGZpZWxkKSA9PiBvYmplY3QgJiYgdHlwZW9mIG9iamVjdCA9PT0gJ29iamVjdCcgPyAob2JqZWN0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtmaWVsZF0gOiB1bmRlZmluZWQsIGVudGl0eSk7XG4gICAgICBjb25zdCByZXVzZVZlcnNpb24gPSAoZW50aXR5LmtpbmQgPT09ICdzY2VuZScgfHwgZW50aXR5LmtpbmQgPT09ICdmbG93X25vZGUnKSAmJiBlbnRpdHkuZGF0YS5yZXVzZSAmJiByZWZlcmVuY2UucGF0aCA9PT0gJ2RhdGEucmV1c2Uuc291cmNlSWQnID8gZW50aXR5LmRhdGEucmV1c2UucGlubmVkU25hcHNob3RJZCA6IHVuZGVmaW5lZDtcbiAgICAgIGNvbnN0IHByb2ZpbGVWZXJzaW9uPWVudGl0eS5raW5kPT09J3Byb2plY3Rpb25fcHJvZmlsZScmJmVudGl0eS5kYXRhLnNvdXJjZVZlcnNpb25JZCYmL15kYXRhXFwuKD86aW5jbHVkZWRJZHN8cHVibGljVGV4dHN8YmxvY2tTb3VyY2VzfHB1YmxpY0lkc3xwdWJsaWNWYWx1ZXN8bmFtZVBvbGljeXxhbGxvd2VkUmVsYXRpb25JZHN8YXBwcm92ZWRBdHRhY2htZW50SWRzKSg/OlxcLnxcXFspLy50ZXN0KHJlZmVyZW5jZS5wYXRoKT9lbnRpdHkuZGF0YS5zb3VyY2VWZXJzaW9uSWQ6dW5kZWZpbmVkO1xuICAgICAgY29uc3QgZ2FtZVByb2ZpbGVWZXJzaW9uPWVudGl0eS5raW5kPT09J25vdGUnJiZyZWZlcmVuY2UucGF0aD09PSdkYXRhLmhhbmRvZmZSZWNlaXB0LnByb2ZpbGVJZCc/ZW50aXR5LmRhdGEuaGFuZG9mZlJlY2VpcHQ/LnByb2ZpbGVWZXJzaW9uSWQ6dW5kZWZpbmVkO1xuICAgICAgY29uc3QgYW5jaG9yVmVyc2lvbiA9IGdhbWVQcm9maWxlVmVyc2lvbiA/PyByZXVzZVZlcnNpb24gPz8gKGlzT2JqZWN0KHBhcmVudCkgJiYgdHlwZW9mIHBhcmVudC5lbnRpdHlJZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIHBhcmVudC5zb3VyY2VWZXJzaW9uSWQgPT09ICdzdHJpbmcnID8gcGFyZW50LnNvdXJjZVZlcnNpb25JZFxuICAgICAgICA6IGVudGl0eS5raW5kID09PSAncmV2aWV3JyAmJiByZWZlcmVuY2UucGF0aC5zdGFydHNXaXRoKCdkYXRhLnRhcmdldC4nKSA/IGVudGl0eS5kYXRhLnRhcmdldFZlcnNpb25JZCA6IHByb2ZpbGVWZXJzaW9uKTtcbiAgICAgIC8vIEluZGVwZW5kZW50bHkgYXV0aG9yZWQgcHVibGljIHBhcmFncmFwaHMgYmVsb25nIHRvIHRoZSBhcHByb3ZhbCBwb2xpY3ksXG4gICAgICAvLyB3aGlsZSBibG9ja1NvdXJjZXMgdmFsdWVzIHN0aWxsIHJlc29sdmUgaW4gdGhlIGhpc3RvcmljYWwgc291cmNlIGVkaXRpb24uXG4gICAgICBpZihlbnRpdHkua2luZD09PSdwcm9qZWN0aW9uX3Byb2ZpbGUnJiZyZWZlcmVuY2Uuc2NvcGU9PT0ncHJvamVjdGlvbl9yZWNvcmQnJiZyZWZlcmVuY2UucGF0aC5lbmRzV2l0aCgnLiRrZXknKSYmT2JqZWN0LnZhbHVlcyhlbnRpdHkuZGF0YS5wdWJsaWNUZXh0cz8/e30pLnNvbWUoZmllbGRzPT5PYmplY3QudmFsdWVzKGZpZWxkcykuc29tZSh2YWx1ZT0+QXJyYXkuaXNBcnJheSh2YWx1ZSkmJnZhbHVlLnNvbWUoYmxvY2s9PmJsb2NrLmlkPT09cmVmZXJlbmNlLmlkKSkpKXtpbnNwZWN0KHJlZmVyZW5jZSxwcmVmaXgpO2NvbnRpbnVlO31cbiAgICAgIGNvbnN0IHVzZXNWZXJzaW9uID0gZW50aXR5LmtpbmQgPT09ICdjaGVja3BvaW50JyAmJiAocmVmZXJlbmNlLnBhdGguc3RhcnRzV2l0aCgnZGF0YS5ydW50aW1lU3RhdGUuJykgfHwgcmVmZXJlbmNlLnBhdGguc3RhcnRzV2l0aCgnZGF0YS5wcmVzZW50YXRpb25TdGF0ZS4nKSB8fCByZWZlcmVuY2UucGF0aC5zdGFydHNXaXRoKCdkYXRhLnByZXNlbnRhdGlvblJlc3VsdHNbJykpXG4gICAgICAgIHx8IGVudGl0eS5raW5kID09PSAndHJhY2UnICYmIChyZWZlcmVuY2UucGF0aC5zdGFydHNXaXRoKCdkYXRhLnN0ZXBzWycpIHx8IHJlZmVyZW5jZS5wYXRoLnN0YXJ0c1dpdGgoJ2RhdGEuaW5pdGlhbEV4dGVybmFsVmFsdWVzLicpIHx8IHJlZmVyZW5jZS5wYXRoLnN0YXJ0c1dpdGgoJ2RhdGEuaW5pdGlhbFN0dWJWYWx1ZXMuJykgfHwgcmVmZXJlbmNlLnBhdGguc3RhcnRzV2l0aCgnZGF0YS5pbml0aWFsU3R1YkJhc2VTdGF0ZS4nKSB8fCByZWZlcmVuY2UucGF0aC5zdGFydHNXaXRoKCdkYXRhLnJlYWRpbmdQYXRoLicpKTtcbiAgICAgIGlmIChhbmNob3JWZXJzaW9uIHx8IHVzZXNWZXJzaW9uICYmIChlbnRpdHkua2luZCA9PT0gJ2NoZWNrcG9pbnQnIHx8IGVudGl0eS5raW5kID09PSAndHJhY2UnKSkge1xuICAgICAgICBjb25zdCB2ZXJzaW9uID0gYW5jaG9yVmVyc2lvbiA/PyAoKGVudGl0eS5raW5kID09PSAnY2hlY2twb2ludCcgfHwgZW50aXR5LmtpbmQgPT09ICd0cmFjZScpID8gZW50aXR5LmRhdGEuY29udGVudFZlcnNpb25JZCA6IHByb2plY3QucHJvamVjdElkKSwgaW5kZXggPSB2ZXJzaW9uSW5kZXgodmVyc2lvbik7XG4gICAgICAgIGlmICghaW5kZXgpIHsgYWRkSXNzdWUoaXNzdWVzLCBhbmNob3JWZXJzaW9uID8gZW50aXR5LmtpbmQgPT09ICdyZXZpZXcnID8gYCR7cHJlZml4fS5kYXRhLnRhcmdldFZlcnNpb25JZGAgOiBgJHtwcmVmaXh9LiR7cGFydHMuc2xpY2UoMCwgLTEpLmpvaW4oJy4nKX0uc291cmNlVmVyc2lvbklkYCA6IGAke3ByZWZpeH0uZGF0YS5jb250ZW50VmVyc2lvbklkYCwgJ+WPgueFp+OBmeOCi+WbuuWumueJiOOBruacrOaWh+OBjOOBguOCiuOBvuOBm+OCk+OAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpOyBjb250aW51ZTsgfVxuICAgICAgICBpbnNwZWN0KHJlZmVyZW5jZSwgcHJlZml4LCBpbmRleCk7XG4gICAgICB9IGVsc2UgaW5zcGVjdChyZWZlcmVuY2UsIHByZWZpeCk7XG4gICAgfVxuICB9KTtcbiAgcHJvamVjdC5yZWxhdGlvbnMuZm9yRWFjaCgocmVsYXRpb24sIGkpID0+IChyZWxhdGlvblJlZmVyZW5jZXMuZ2V0KHJlbGF0aW9uKT8/Y29sbGVjdFJlbGF0aW9uUmVmZXJlbmNlcyhyZWxhdGlvbikpLmZvckVhY2gocmVmZXJlbmNlID0+IGluc3BlY3QocmVmZXJlbmNlLCBgJHtwYXRofS5yZWxhdGlvbnNbJHtpfV1gKSkpO1xuICB2aWV3UmVmcy5mb3JFYWNoKHJlZmVyZW5jZSA9PiBpbnNwZWN0KHJlZmVyZW5jZSkpO1xuICBjb25zdCByZWxhdGlvblR5cGVzID0gb3B0aW9ucy5yZWxhdGlvblR5cGVzID8/IFJFTEFUSU9OX1RZUEVTO1xuICBwcm9qZWN0LnJlbGF0aW9ucy5mb3JFYWNoKChyZWxhdGlvbiwgaSkgPT4ge1xuICAgIGNvbnN0IGxvY2F0aW9uID0gYCR7cGF0aH0ucmVsYXRpb25zWyR7aX1dYCwgdHlwZSA9IHJlbGF0aW9uVHlwZXMuZmluZChjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmtleSA9PT0gcmVsYXRpb24ucmVsYXRpb25UeXBlKSwgZnJvbSA9IGVudGl0eU1hcC5nZXQocmVsYXRpb24uZnJvbUlkKSwgdG8gPSBlbnRpdHlNYXAuZ2V0KHJlbGF0aW9uLnRvSWQpO1xuICAgIGlmICghdHlwZSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0ucmVsYXRpb25UeXBlYCwgJ+mWouS/guOBrueorumhnuOBjOi+nuabuOOBq+Wumue+qeOBleOCjOOBpuOBhOOBvuOBm+OCk+OAgicpO1xuICAgIGVsc2Uge1xuICAgICAgaWYgKGZyb20gJiYgIXR5cGUuZnJvbUtpbmRzLmluY2x1ZGVzKGZyb20ua2luZCkpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmZyb21JZGAsICfjgZPjga7plqLkv4LjgafoqLHjgZXjgozjgarjgYTlp4vngrnnqK7poZ7jgafjgZnjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICAgIGlmICh0byAmJiAhdHlwZS50b0tpbmRzLmluY2x1ZGVzKHRvLmtpbmQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS50b0lkYCwgJ+OBk+OBrumWouS/guOBp+ioseOBleOCjOOBquOBhOe1gueCueeorumhnuOBp+OBmeOAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICAgICAgaWYgKHJlbGF0aW9uLmZyb21JZCA9PT0gcmVsYXRpb24udG9JZCAmJiAhdHlwZS5hbGxvd1NlbGYpIGFkZElzc3VlKGlzc3VlcywgbG9jYXRpb24sICfjgZPjga7plqLkv4Ljga/oh6rlt7HplqLkv4LjgpLoqLHjgZfjgb7jgZvjgpPjgIInKTtcbiAgICAgIGlmIChyZWxhdGlvbi5kaXJlY3Rpb24gPT09ICdzeW1tZXRyaWMnICYmICF0eXBlLmFsbG93U3ltbWV0cmljKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kaXJlY3Rpb25gLCAn44GT44Gu6Zai5L+C44Gv5a++56ew44Gn44Gv44GC44KK44G+44Gb44KT44CCJyk7XG4gICAgfVxuICAgIGlmIChyZWxhdGlvbi5kZWxldGVkQXQgJiYgIXJlbGF0aW9uLmRlbGV0aW9uT3BlcmF0aW9uSWQpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRlbGV0aW9uT3BlcmF0aW9uSWRgLCAn5YmK6Zmk44Gr44Gv5pON5L2cSUTjgYzlv4XopoHjgafjgZnjgIInKTtcbiAgICB2YWxpZGF0ZU5lc3RlZFJhbmdlcyhyZWxhdGlvbi52YWxpZGl0eSwgYCR7bG9jYXRpb259LnZhbGlkaXR5YCwgaXNzdWVzKTtcbiAgfSk7XG4gIGxldCBhZmZlY3RlZElkczogU2V0PElEPiB8IHVuZGVmaW5lZDtcbiAgaWYgKHJldXNlICYmIEpTT04uc3RyaW5naWZ5KHByb2plY3Qud29ybGRSZWZlcmVuY2VzKSA9PT0gSlNPTi5zdHJpbmdpZnkocmV1c2UucHJldmlvdXMud29ybGRSZWZlcmVuY2VzKSAmJiBKU09OLnN0cmluZ2lmeShwcm9qZWN0LmNhbGVuZGFycykgPT09IEpTT04uc3RyaW5naWZ5KHJldXNlLnByZXZpb3VzLmNhbGVuZGFycykpIHtcbiAgICBhZmZlY3RlZElkcyA9IG5ldyBTZXQoWy4uLnByb2plY3QuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiBwcmV2aW91c0VudGl0aWVzLmdldChlbnRpdHkuaWQpICE9PSBlbnRpdHkpLm1hcChlbnRpdHkgPT4gZW50aXR5LmlkKSwgLi4ucHJvamVjdC5yZWxhdGlvbnMuZmlsdGVyKHJlbGF0aW9uID0+IHByZXZpb3VzUmVsYXRpb25zLmdldChyZWxhdGlvbi5pZCkgIT09IHJlbGF0aW9uKS5tYXAocmVsYXRpb24gPT4gcmVsYXRpb24uaWQpXSk7XG4gICAgZm9yIChjb25zdCBpZCBvZiBwcmV2aW91c0VudGl0aWVzLmtleXMoKSkgaWYgKCFlbnRpdHlNYXAuaGFzKGlkKSkgYWZmZWN0ZWRJZHMuYWRkKGlkKTtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIHByZXZpb3VzUmVsYXRpb25zLmtleXMoKSkgaWYgKCFyZWxhdGlvbk1hcC5oYXMoaWQpKSBhZmZlY3RlZElkcy5hZGQoaWQpO1xuICB9XG4gIHZhbGlkYXRlQ3Jvc3NFbnRpdHlSdWxlcyhwcm9qZWN0LCBlbnRpdHlNYXAsIGFsaWFzZXMsIGtub3duVmVyc2lvbnMsIGJsb2NrcywgaXNzdWVzLCBwYXRoLCBvcHRpb25zLCB2ZXJzaW9uSW5kZXgsIGFmZmVjdGVkSWRzID8gZW50aXR5ID0+IHByZXZpb3VzRW50aXRpZXMuZ2V0KGVudGl0eS5pZCkgIT09IGVudGl0eSB8fCByZWZlcmVuY2VzRm9yKGVudGl0eSkuc29tZShyZWZlcmVuY2UgPT4gYWZmZWN0ZWRJZHMhLmhhcyhyZWZlcmVuY2UuaWQpKSA6IHVuZGVmaW5lZCk7XG4gIHJldHVybiBpc3N1ZXMubGVuZ3RoID8geyBvazogZmFsc2UsIGlzc3VlczogaXNzdWVzLnNsaWNlKDAsIDI1NikgfSA6IHsgb2s6IHRydWUsIHZhbHVlOiBwcm9qZWN0IH07XG59XG5mdW5jdGlvbiBjb2xsZWN0Q29udGVudElkcyh2YWx1ZTogdW5rbm93biwgb3duZXI6IElELCBibG9ja3M6IE1hcDxJRCwgeyBlbnRpdHlJZDogSUQ7IHRleHQ6IHN0cmluZyB9PiwgYWxpYXNlczogTWFwPElELCB7IGVudGl0eUlkOiBJRDsgYWxpYXM6IEFsaWFzIH0+LCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdLCBwYXRoOiBzdHJpbmcsIGRlcHRoID0gMCk6IHZvaWQge1xuICBpZiAoZGVwdGggPiAzMiB8fCAhdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHsgdmFsdWUuZm9yRWFjaCgoY2hpbGQsIGkpID0+IGNvbGxlY3RDb250ZW50SWRzKGNoaWxkLCBvd25lciwgYmxvY2tzLCBhbGlhc2VzLCBpc3N1ZXMsIGAke3BhdGh9WyR7aX1dYCwgZGVwdGggKyAxKSk7IHJldHVybjsgfVxuICBjb25zdCBvYmplY3QgPSB2YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgaWYgKHR5cGVvZiBvYmplY3QuaWQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBvYmplY3QudGV4dCA9PT0gJ3N0cmluZycgJiYgWydwYXJhZ3JhcGgnLCAnaGVhZGluZycsICdsaXN0X2l0ZW0nLCAncXVvdGUnXS5pbmNsdWRlcyhvYmplY3Qua2luZCBhcyBzdHJpbmcpKSB7XG4gICAgaWYgKGJsb2Nrcy5oYXMob2JqZWN0LmlkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5pZGAsICfmnKzmlofjg5bjg63jg4Pjgq9JROOBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicpO1xuICAgIGJsb2Nrcy5zZXQob2JqZWN0LmlkLCB7IGVudGl0eUlkOiBvd25lciwgdGV4dDogb2JqZWN0LnRleHQgfSk7XG4gIH1cbiAgaWYgKHR5cGVvZiBvYmplY3QuaWQgPT09ICdzdHJpbmcnICYmICdpc1B1YmxpY0RlZmF1bHQnIGluIG9iamVjdCkge1xuICAgIGlmIChhbGlhc2VzLmhhcyhvYmplY3QuaWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9LmlkYCwgJ+WIpeWQjUlE44GM6YeN6KSH44GX44Gm44GE44G+44GZ44CCJyk7XG4gICAgYWxpYXNlcy5zZXQob2JqZWN0LmlkLCB7IGVudGl0eUlkOiBvd25lciwgYWxpYXM6IG9iamVjdCBhcyB1bmtub3duIGFzIEFsaWFzIH0pO1xuICB9XG4gIGZvciAoY29uc3QgW2tleSwgY2hpbGRdIG9mIE9iamVjdC5lbnRyaWVzKG9iamVjdCkpIHtcbiAgICAvLyBUcmFjZS9jaGVja3BvaW50IHZhbHVlcyBhbmQgcHJvamVjdGlvbiBwdWJsaWMgdGV4dCBhcmUgY29waWVzLCBub3QgY2Fub25pY2FsIGJsb2Nrcy5cbiAgICBpZiAoWydydW50aW1lU3RhdGUnLCAnYmVmb3JlJywgJ2FmdGVyJywgJ3B1YmxpY1RleHRzJ10uaW5jbHVkZXMoa2V5KSkgY29udGludWU7XG4gICAgY29sbGVjdENvbnRlbnRJZHMoY2hpbGQsIG93bmVyLCBibG9ja3MsIGFsaWFzZXMsIGlzc3VlcywgYCR7cGF0aH0uJHtrZXl9YCwgZGVwdGggKyAxKTtcbiAgfVxufVxuZnVuY3Rpb24gY3ljbGVJc3N1ZXMobm9kZXM6IEVudGl0eVtdLCBlZGdlczogKGVudGl0eTogRW50aXR5KSA9PiBJRFtdLCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdLCBwYXRoOiBzdHJpbmcsIGxhYmVsOiBzdHJpbmcpOiB2b2lkIHtcbiAgY29uc3QgaW5kZXggPSBuZXcgTWFwKG5vZGVzLm1hcChub2RlID0+IFtub2RlLmlkLCBub2RlXSkpLCBjb2xvcnMgPSBuZXcgTWFwPElELCBudW1iZXI+KCk7XG4gIGZvciAoY29uc3Qgbm9kZSBvZiBub2Rlcykge1xuICAgIGlmIChjb2xvcnMuZ2V0KG5vZGUuaWQpKSBjb250aW51ZTtcbiAgICBjb25zdCBzdGFjazogeyBpZDogSUQ7IGlkczogSURbXTsgY3Vyc29yOiBudW1iZXIgfVtdID0gW3sgaWQ6IG5vZGUuaWQsIGlkczogZWRnZXMobm9kZSksIGN1cnNvcjogMCB9XTsgY29sb3JzLnNldChub2RlLmlkLCAxKTtcbiAgICB3aGlsZSAoc3RhY2subGVuZ3RoKSB7XG4gICAgICBjb25zdCBjdXJyZW50ID0gc3RhY2tbc3RhY2subGVuZ3RoIC0gMV07XG4gICAgICBpZiAoY3VycmVudC5jdXJzb3IgPj0gY3VycmVudC5pZHMubGVuZ3RoKSB7IGNvbG9ycy5zZXQoY3VycmVudC5pZCwgMik7IHN0YWNrLnBvcCgpOyBjb250aW51ZTsgfVxuICAgICAgY29uc3QgbmV4dElkID0gY3VycmVudC5pZHNbY3VycmVudC5jdXJzb3IrK10sIG5leHQgPSBpbmRleC5nZXQobmV4dElkKTsgaWYgKCFuZXh0KSBjb250aW51ZTtcbiAgICAgIGlmIChjb2xvcnMuZ2V0KG5leHRJZCkgPT09IDEpIHsgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5lbnRpdGllcy4ke2N1cnJlbnQuaWR9LmRhdGFgLCBgJHtsYWJlbH3jgavlvqrnkrDjgYzjgYLjgorjgb7jgZnjgIJgKTsgY29udGludWU7IH1cbiAgICAgIGlmICghY29sb3JzLmdldChuZXh0SWQpKSB7IGNvbG9ycy5zZXQobmV4dElkLCAxKTsgc3RhY2sucHVzaCh7IGlkOiBuZXh0SWQsIGlkczogZWRnZXMobmV4dCksIGN1cnNvcjogMCB9KTsgfVxuICAgIH1cbiAgfVxufVxudHlwZSBBbmNob3JJbmRleCA9IHsgZW50aXRpZXM6IE1hcDxJRCwgRW50aXR5PjsgYmxvY2tzOiBNYXA8SUQsIHsgZW50aXR5SWQ6IElEOyB0ZXh0OiBzdHJpbmcgfT4gfTtcbmZ1bmN0aW9uIHZhbGlkYXRlQ3Jvc3NFbnRpdHlSdWxlcyhwcm9qZWN0OiBQcm9qZWN0Q29udGVudCwgZW50aXR5TWFwOiBNYXA8SUQsIEVudGl0eT4sIGFsaWFzZXM6IE1hcDxJRCwgeyBlbnRpdHlJZDogSUQ7IGFsaWFzOiBBbGlhcyB9Piwga25vd25WZXJzaW9uczogU2V0PElEPiwgYmxvY2tzOiBNYXA8SUQsIHsgZW50aXR5SWQ6IElEOyB0ZXh0OiBzdHJpbmcgfT4sIGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10sIHBhdGg6IHN0cmluZywgb3B0aW9uczogUHJvamVjdFZhbGlkYXRpb25PcHRpb25zLCByZXNvbHZlVmVyc2lvbjogKHZlcnNpb246IElEKSA9PiBBbmNob3JJbmRleCB8IHVuZGVmaW5lZCwgYWZmZWN0ZWQ/OiAoZW50aXR5OiBFbnRpdHkpID0+IGJvb2xlYW4pOiB2b2lkIHtcbiAgY29uc3Qga2V5cyA9IG5ldyBNYXA8c3RyaW5nLCBJRD4oKSwgdHJhbnNsYXRpb25LZXlzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIC8vIEFzc2lnbm1lbnRzIGFsc28gZGVwZW5kIG9uIGEgdGVtcGxhdGUncyB3aG9sZSBmaWVsZCBzZXQsIGluY2x1ZGluZyBuZXcgZmllbGRzLlxuICAvLyBLZWVwIHRoaXMgY2hlY2sgaWRlbnRpY2FsIGluIGZ1bGwgaW1wb3J0cyBhbmQgaW5jcmVtZW50YWwgbG9jYWwgc2F2ZXMuXG4gIGlmIChwcm9qZWN0LmVudGl0aWVzLnNvbWUoZW50aXR5ID0+ICEhZW50aXR5LnRlbXBsYXRlSWQgJiYgIWVudGl0eS5kZWxldGVkQXQpKSBpc3N1ZXMucHVzaCguLi52YWxpZGF0ZVRlbXBsYXRlQXNzaWdubWVudHMocHJvamVjdCwgcGF0aCwgWy4uLmVudGl0eU1hcC52YWx1ZXMoKV0pKTtcbiAgcHJvamVjdC5lbnRpdGllcy5mb3JFYWNoKChlbnRpdHksIGkpID0+IHtcbiAgICBjb25zdCBsb2NhdGlvbiA9IGAke3BhdGh9LmVudGl0aWVzWyR7aX1dYDtcbiAgICBpZiAoZW50aXR5LmRlbGV0ZWRBdCkgcmV0dXJuO1xuICAgIGlmIChlbnRpdHkua2luZCA9PT0gJ3ZhcmlhYmxlJyB8fCBlbnRpdHkua2luZCA9PT0gJ3F1ZXN0JyB8fCBlbnRpdHkua2luZCA9PT0gJ2V4dGVybmFsX2NvbnRyYWN0Jykge1xuICAgICAgY29uc3QgdW5pcXVlID0gYCR7ZW50aXR5LmtpbmR9LyR7ZW50aXR5LmtpbmQgPT09ICd2YXJpYWJsZScgPyBgJHtlbnRpdHkuZGF0YS5zY29wZX0vJHtlbnRpdHkuZGF0YS5vd25lcklkID8/ICcnfS9gIDogJyd9JHtlbnRpdHkuZGF0YS5rZXl9YDtcbiAgICAgIGlmIChrZXlzLmhhcyh1bmlxdWUpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLmtleWAsICflkIzjgZjjgrnjgrPjg7zjg5fjgafjgq3jg7zjgYzph43opIfjgZfjgabjgYTjgb7jgZnjgIInKTsga2V5cy5zZXQodW5pcXVlLCBlbnRpdHkuaWQpO1xuICAgIH1cbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdsb2NhbGl6YXRpb24nKSB7XG4gICAgICBjb25zdCB1bmlxdWUgPSBgJHtlbnRpdHkuZGF0YS5zb3VyY2VMaW5lSWR9LyR7ZW50aXR5LmRhdGEubGFuZ3VhZ2V9LyR7ZW50aXR5LmRhdGEuc291cmNlSGFzaH1gO1xuICAgICAgaWYgKHRyYW5zbGF0aW9uS2V5cy5oYXModW5pcXVlKSkgYWRkSXNzdWUoaXNzdWVzLCBsb2NhdGlvbiwgJ+WQjOOBmOWPsOipnuODu+iogOiqnuODu+WOn+aWh+eJiOOBrue/u+ios+OBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicpOyB0cmFuc2xhdGlvbktleXMuYWRkKHVuaXF1ZSk7XG4gICAgfVxuICAgIC8vIE5hbWVzcGFjZS9rZXkgdW5pcXVlbmVzcywgcmVmZXJlbmNlIGV4aXN0ZW5jZSBhbmQgZ3JhcGgtd2lkZSBjaGVja3MgYWx3YXlzIHJ1bi5cbiAgICAvLyBWYWx1ZS9hbmNob3IgcnVsZXMgb25seSBuZWVkIHVuY2hhbmdlZCByZWNvcmRzIHdoZW4gb25lIG9mIHRoZWlyIGRlcGVuZGVuY2llcyBjaGFuZ2VkLlxuICAgIC8vIENoZWNrcG9pbnQvdHJhY2UgZXZpZGVuY2UgYWxzbyBkZXBlbmRzIG9uIHRoZSBlbGlnaWJsZSByZWNvcmQgc2V0LCBpbmNsdWRpbmcgbmV3bHkgYWRkZWQgSURzLlxuICAgIGlmIChhZmZlY3RlZCAmJiAhYWZmZWN0ZWQoZW50aXR5KSAmJiBlbnRpdHkua2luZCAhPT0gJ2NoZWNrcG9pbnQnICYmIGVudGl0eS5raW5kICE9PSAndHJhY2UnKSByZXR1cm47XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAndGVtcGxhdGUnKSBpc3N1ZXMucHVzaCguLi52YWxpZGF0ZVRlbXBsYXRlRGVmaW5pdGlvbihlbnRpdHkuZGF0YSwgYCR7bG9jYXRpb259LmRhdGFgLCBlbnRpdHlNYXApKTtcbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdpdGVtJyAmJiBlbnRpdHkuZGF0YS5pdGVtTW9kZSA9PT0gJ2luc3RhbmNlJykge1xuICAgICAgY29uc3QgdHlwZSA9IGVudGl0eS5kYXRhLnR5cGVJZCA/IGVudGl0eU1hcC5nZXQoZW50aXR5LmRhdGEudHlwZUlkKSA6IHVuZGVmaW5lZDtcbiAgICAgIGlmICh0eXBlPy5raW5kID09PSAnaXRlbScgJiYgdHlwZS5kYXRhLml0ZW1Nb2RlICE9PSAndHlwZScpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEudHlwZUlkYCwgJ+WAi+S9k+OBrnR5cGVJZOOBr+eJqeWTgeeorumhnuOCkuWPgueFp+OBl+OBpuOBj+OBoOOBleOBhOOAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICAgIH1cbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdxdWVzdCcpIHtcbiAgICAgIGNvbnN0IHZhcmlhYmxlID0gZW50aXR5TWFwLmdldChlbnRpdHkuZGF0YS5zdGF0ZVZhcmlhYmxlSWQpO1xuICAgICAgaWYgKHZhcmlhYmxlPy5raW5kID09PSAndmFyaWFibGUnKSBmb3IgKGNvbnN0IFtqLCBydWxlXSBvZiAoZW50aXR5LmRhdGEudHJhbnNpdGlvblJ1bGVzID8/IFtdKS5lbnRyaWVzKCkpIGlzc3Vlcy5wdXNoKC4uLnZhbGlkYXRlVmFyaWFibGVWYWx1ZSh2YXJpYWJsZSwgcnVsZS5mcm9tLCBgJHtsb2NhdGlvbn0uZGF0YS50cmFuc2l0aW9uUnVsZXNbJHtqfV0uZnJvbWAsIGZhbHNlKSwgLi4udmFsaWRhdGVWYXJpYWJsZVZhbHVlKHZhcmlhYmxlLCBydWxlLnRvLCBgJHtsb2NhdGlvbn0uZGF0YS50cmFuc2l0aW9uUnVsZXNbJHtqfV0udG9gLCBmYWxzZSkpO1xuICAgIH1cbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICd2YXJpYWJsZScpIGZvciAoY29uc3QgW2osIHJ1bGVdIG9mIChlbnRpdHkuZGF0YS5leGNsdXNpb25zID8/IFtdKS5lbnRyaWVzKCkpIHtcbiAgICAgIGNvbnN0IG90aGVyID0gZW50aXR5TWFwLmdldChydWxlLnZhcmlhYmxlSWQpO1xuICAgICAgaWYgKG90aGVyPy5raW5kID09PSAndmFyaWFibGUnKSBpc3N1ZXMucHVzaCguLi52YWxpZGF0ZVZhcmlhYmxlVmFsdWUob3RoZXIsIHJ1bGUub3RoZXJWYWx1ZSwgYCR7bG9jYXRpb259LmRhdGEuZXhjbHVzaW9uc1ske2p9XS5vdGhlclZhbHVlYCwgZmFsc2UpKTtcbiAgICB9XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnY29sbGVjdGlvbicgJiYgZW50aXR5LmRhdGEucHVycG9zZSA9PT0gJ3JlZ3Jlc3Npb24nKSBmb3IgKGNvbnN0IFtqLCBpZF0gb2YgKGVudGl0eS5kYXRhLm1lbWJlcklkcyA/PyBbXSkuZW50cmllcygpKSB7XG4gICAgICBjb25zdCB0cmFjZSA9IGVudGl0eU1hcC5nZXQoaWQpO1xuICAgICAgaWYgKHRyYWNlICYmIHRyYWNlLmtpbmQgIT09ICd0cmFjZScpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEubWVtYmVySWRzWyR7an1dYCwgJ+WbnuW4sOe1jOi3r+mbhuWQiOOBq+OBr+S/neWtmOOBl+OBn+ippuiqreiomOmMsuOCkuaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICAgIH1cbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdlZmZlY3QnKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBlbnRpdHlNYXAuZ2V0KGVudGl0eS5kYXRhLnRhcmdldElkKSwgb3BlcmF0aW9uID0gZW50aXR5LmRhdGEub3BlcmF0aW9uO1xuICAgICAgaWYgKHRhcmdldCAmJiBbJ3NldCcsICdhZGQnLCAncmVzZXQnXS5pbmNsdWRlcyhvcGVyYXRpb24pKSB7XG4gICAgICAgIGlmICh0YXJnZXQua2luZCAhPT0gJ3ZhcmlhYmxlJykgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uZGF0YS50YXJnZXRJZGAsICfnirbmhYvmm7TmlrDlirnmnpzjga/nirbmhYvlpInmlbDjgpLlj4LnhafjgZfjgabjgY/jgaDjgZXjgYTjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgaWYgKHRhcmdldC5kYXRhLmRlcml2ZWQpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEudGFyZ2V0SWRgLCAn566X5Ye654q25oWL44G455u05o6l5Luj5YWl44Gn44GN44G+44Gb44KT44CCJyk7XG4gICAgICAgICAgaWYgKG9wZXJhdGlvbiA9PT0gJ2FkZCcgJiYgdGFyZ2V0LmRhdGEudmFsdWVUeXBlICE9PSAnaW50ZWdlcicpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEudGFyZ2V0SWRgLCAnYWRk44GvaW50ZWdlcueKtuaFi+OBoOOBkeOBp+OBmeOAgicpO1xuICAgICAgICAgIGlmIChlbnRpdHkuZGF0YS52YWx1ZSAmJiBvcGVyYXRpb24gIT09ICdhZGQnKSBpc3N1ZXMucHVzaCguLi52YWxpZGF0ZVZhcmlhYmxlVmFsdWUodGFyZ2V0LCBlbnRpdHkuZGF0YS52YWx1ZSwgYCR7bG9jYXRpb259LmRhdGEudmFsdWVgKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0YXJnZXQgJiYgWydncmFudCcsICdjb25zdW1lJywgJ21vdmUnXS5pbmNsdWRlcyhvcGVyYXRpb24pICYmIHRhcmdldC5raW5kICE9PSAnaXRlbScpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEudGFyZ2V0SWRgLCAn54mp5ZOB5Yq55p6c44Gv54mp5ZOB44KS5Y+C54Wn44GX44Gm44GP44Gg44GV44GE44CCJywgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgICBpZiAodGFyZ2V0Py5raW5kID09PSAnaXRlbScgJiYgWydncmFudCcsICdjb25zdW1lJywgJ21vdmUnXS5pbmNsdWRlcyhvcGVyYXRpb24pICYmIGVudGl0eS5kYXRhLmluc3RhbmNlSWQpIHtcbiAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBlbnRpdHlNYXAuZ2V0KGVudGl0eS5kYXRhLmluc3RhbmNlSWQpO1xuICAgICAgICBpZiAoaW5zdGFuY2U/LmtpbmQgPT09ICdpdGVtJyAmJiAoaW5zdGFuY2UuZGF0YS5pdGVtTW9kZSAhPT0gJ2luc3RhbmNlJyB8fCAodGFyZ2V0LmRhdGEuaXRlbU1vZGUgPT09ICd0eXBlJyA/IGluc3RhbmNlLmRhdGEudHlwZUlkICE9PSB0YXJnZXQuaWQgOiBpbnN0YW5jZS5pZCAhPT0gdGFyZ2V0LmlkKSkpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEuaW5zdGFuY2VJZGAsICfmjIflrprjgZfjgZ/lgIvkvZPjgYzlirnmnpzjga7lr77osaHnianlk4HjgavlsZ7jgZfjgabjgYTjgb7jgZvjgpPjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICAgIH1cbiAgICAgIGlmICh0YXJnZXQgJiYgb3BlcmF0aW9uID09PSAnYXNzZXJ0JyAmJiB0YXJnZXQua2luZCAhPT0gJ2Fzc2VydGlvbicpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEudGFyZ2V0SWRgLCAn6KqN6K2Y5Yq55p6c44Gv5LqL5a6f44O76KqN6K2Y44KS5Y+C54Wn44GX44Gm44GP44Gg44GV44GE44CCJywgJ1JFRkVSRU5DRV9JTlZBTElEJyk7XG4gICAgICBpZiAob3BlcmF0aW9uID09PSAnbW92ZScgJiYgZW50aXR5LmRhdGEudmFsdWU/LnR5cGUgPT09ICdyZWYnKSB7XG4gICAgICAgIGNvbnN0IGRlc3RpbmF0aW9uID0gZW50aXR5TWFwLmdldChlbnRpdHkuZGF0YS52YWx1ZS52YWx1ZSk7IGlmIChkZXN0aW5hdGlvbiAmJiAhWydjaGFyYWN0ZXInLCAnZ3JvdXAnLCAncGxhY2UnXS5pbmNsdWRlcyhkZXN0aW5hdGlvbi5raW5kKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uZGF0YS52YWx1ZWAsICfnianlk4Hjga7np7vli5XlhYjjga/kurrnianjg7vjgrDjg6vjg7zjg5fjg7vloLTmiYDjgafjgZnjgIInLCAnUkVGRVJFTkNFX0lOVkFMSUQnKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnZmxvd19ncmFwaCcpIHtcbiAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgWy4uLmVudGl0eS5kYXRhLmVudHJ5SWRzLCAuLi5lbnRpdHkuZGF0YS5leGl0SWRzXSkgaWYgKCFlbnRpdHkuZGF0YS5ub2RlSWRzLmluY2x1ZGVzKGVudHJ5KSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uZGF0YWAsICflhaXlj6Pjg7vlh7rlj6Pjga/jgZ3jga7liIblspDlm7Pjga7jg47jg7zjg4npm4blkIjjgavlkKvjgoHjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgICAgIGZvciAoY29uc3QgZWRnZUlkIG9mIGVudGl0eS5kYXRhLmVkZ2VJZHMpIHtcbiAgICAgICAgY29uc3QgZWRnZSA9IGVudGl0eU1hcC5nZXQoZWRnZUlkKTsgaWYgKGVkZ2U/LmtpbmQgIT09ICdmbG93X2VkZ2UnKSBjb250aW51ZTtcbiAgICAgICAgaWYgKCFlbnRpdHkuZGF0YS5ub2RlSWRzLmluY2x1ZGVzKGVkZ2UuZGF0YS5mcm9tSWQpIHx8ICh0eXBlb2YgZWRnZS5kYXRhLnRvSWQgPT09ICdzdHJpbmcnICYmICFlbnRpdHkuZGF0YS5ub2RlSWRzLmluY2x1ZGVzKGVkZ2UuZGF0YS50b0lkKSkpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEuZWRnZUlkc2AsICfpgLLooYznt5rjga7lp4vngrnjg7vntYLngrnjga/lkIzjgZjliIblspDlm7PlhoXjgavnva7jgYTjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHBhcmFtZXRlcktleXMgPSAoZW50aXR5LmRhdGEucGFyYW1ldGVycyA/PyBbXSkubWFwKHBhcmFtZXRlciA9PiBwYXJhbWV0ZXIua2V5KTsgaWYgKG5ldyBTZXQocGFyYW1ldGVyS2V5cykuc2l6ZSAhPT0gcGFyYW1ldGVyS2V5cy5sZW5ndGgpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEucGFyYW1ldGVyc2AsICflvJXmlbDjga7jgq3jg7zjgYzph43opIfjgZfjgabjgYTjgb7jgZnjgIInKTtcbiAgICB9XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnZmxvd19lZGdlJyAmJiBvcHRpb25zLnJ1bnRpbWUgJiYgdHlwZW9mIGVudGl0eS5kYXRhLnRvSWQgIT09ICdzdHJpbmcnKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLnRvSWRgLCAn5pyq5a6M5oiQ44Gu5YiG5bKQ5YWI44Gv5a6f6KGM55So5Ye65Yqb44Gn44GN44G+44Gb44KT44CCJywgJ0VYUE9SVF9VTlNVUFBPUlRFRCcpO1xuICAgIGlmIChlbnRpdHkua2luZCA9PT0gJ3ZhcmlhYmxlJyAmJiBvcHRpb25zLnJ1bnRpbWUgJiYgZW50aXR5LmRhdGEuaW5pdGlhbC50eXBlID09PSAndW5rbm93bicgJiYgIWVudGl0eS5kYXRhLmRlcml2ZWQpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEuaW5pdGlhbGAsICfliJ3mnJ/lgKTjgYzmnKrlrprjgafjgZnjgIInLCAnQ09ORElUSU9OX1VOS05PV04nKTtcbiAgICB2YWxpZGF0ZUNvbmRpdGlvblR5cGVzSW5WYWx1ZShlbnRpdHkuZGF0YSwgbG9jYXRpb24sIGVudGl0eU1hcCwgaXNzdWVzKTtcbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICdyZXZpZXcnICYmIHR5cGVvZiBlbnRpdHkuZGF0YS50YXJnZXQgPT09ICdvYmplY3QnKSB7XG4gICAgICB2YWxpZGF0ZUFuY2hvcnMoZW50aXR5LmRhdGEudGFyZ2V0LCBgJHtsb2NhdGlvbn0uZGF0YS50YXJnZXRgLCBlbnRpdHlNYXAsIGJsb2NrcywgaXNzdWVzLCAwLCByZXNvbHZlVmVyc2lvbiwgZW50aXR5LmRhdGEudGFyZ2V0VmVyc2lvbklkKTtcbiAgICAgIHZhbGlkYXRlQW5jaG9ycyh7IC4uLmVudGl0eS5kYXRhLCB0YXJnZXQ6IG51bGwgfSwgYCR7bG9jYXRpb259LmRhdGFgLCBlbnRpdHlNYXAsIGJsb2NrcywgaXNzdWVzLCAwLCByZXNvbHZlVmVyc2lvbik7XG4gICAgfSBlbHNlIHZhbGlkYXRlQW5jaG9ycyhlbnRpdHkuZGF0YSwgYCR7bG9jYXRpb259LmRhdGFgLCBlbnRpdHlNYXAsIGJsb2NrcywgaXNzdWVzLCAwLCByZXNvbHZlVmVyc2lvbik7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAncHJvamVjdGlvbl9wcm9maWxlJykge1xuICAgICAgY29uc3QgcG9saWN5ID0gZW50aXR5LmRhdGEubmFtZVBvbGljeTtcbiAgICAgIGlmICgnbW9kZScgaW4gcG9saWN5ICYmIHBvbGljeS5tb2RlID09PSAnYWxpYXMnKSB7XG4gICAgICAgIGNvbnN0IGFsaWFzID0gYWxpYXNlcy5nZXQocG9saWN5LmFsaWFzSWQpOyBpZiAoYWxpYXMgJiYgIWVudGl0eS5kYXRhLmluY2x1ZGVkSWRzLmluY2x1ZGVzKGFsaWFzLmVudGl0eUlkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uZGF0YS5uYW1lUG9saWN5YCwgJ+WIpeWQjeOBr+aKleW9seWvvuixoeOBruacrOS9k+OBq+WxnuOBl+OBpuOBhOOCi+W/heimgeOBjOOBguOCiuOBvuOBmeOAgicpO1xuICAgICAgfSBlbHNlIGlmICghKCdtb2RlJyBpbiBwb2xpY3kpKSBmb3IgKGNvbnN0IFt0YXJnZXRJZCwgc3BlY2lmaWNdIG9mIE9iamVjdC5lbnRyaWVzKHBvbGljeS5ieUVudGl0eUlkID8/IHt9KSkge1xuICAgICAgICBpZiAoc3BlY2lmaWMubW9kZSA9PT0gJ2FsaWFzJyAmJiBhbGlhc2VzLmdldChzcGVjaWZpYy5hbGlhc0lkKT8uZW50aXR5SWQgIT09IHRhcmdldElkKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLm5hbWVQb2xpY3kuYnlFbnRpdHlJZC4ke3RhcmdldElkfWAsICfliKXlkI3jgYzmjIflrprjgZfjgZ/mnKzkvZPjgavlsZ7jgZfjgabjgYTjgb7jgZvjgpPjgIInKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnY2hlY2twb2ludCcgJiYgKCFrbm93blZlcnNpb25zLmhhcyhlbnRpdHkuZGF0YS5ydW50aW1lU3RhdGUuY29udGVudFZlcnNpb25JZCkgfHwgZW50aXR5LmRhdGEucnVudGltZVN0YXRlLmNvbnRlbnRWZXJzaW9uSWQgIT09IGVudGl0eS5kYXRhLmNvbnRlbnRWZXJzaW9uSWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLnJ1bnRpbWVTdGF0ZS5jb250ZW50VmVyc2lvbklkYCwgJ+mAlOS4remWi+Wni+OBrueKtuaFi+OBqOWvvuixoeeJiOOBjOS4gOiHtOOBl+OBvuOBm+OCk+OAgicpO1xuICAgIGlmIChlbnRpdHkua2luZCA9PT0gJ2NoZWNrcG9pbnQnKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSB2YWxpZGF0ZVJ1bnRpbWVTdGF0ZShlbnRpdHkuZGF0YS5ydW50aW1lU3RhdGUsIGAke2xvY2F0aW9ufS5kYXRhLnJ1bnRpbWVTdGF0ZWApOyBpZiAoIXJlc3VsdC5vaykgaXNzdWVzLnB1c2goLi4ucmVzdWx0Lmlzc3Vlcyk7XG4gICAgICBpZiAoZW50aXR5LmRhdGEucHJlc2VudGF0aW9uU3RhdGUgJiYgKGVudGl0eS5kYXRhLnByZXNlbnRhdGlvblN0YXRlLmNvbnRlbnRWZXJzaW9uSWQgIT09IGVudGl0eS5kYXRhLmNvbnRlbnRWZXJzaW9uSWQgfHwgZW50aXR5LmRhdGEucHJlc2VudGF0aW9uU3RhdGUucHJlc2VudGF0aW9uUG9zaXRpb24gIT09IGVudGl0eS5kYXRhLnJ1bnRpbWVTdGF0ZS5wcmVzZW50YXRpb25Qb3NpdGlvbiB8fCBlbnRpdHkuZGF0YS5wcmVzZW50YXRpb25TdGF0ZS5wcm92ZW5hbmNlICE9PSBlbnRpdHkuZGF0YS5ydW50aW1lU3RhdGUucHJvdmVuYW5jZSkpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEucHJlc2VudGF0aW9uU3RhdGVgLCAn5o+Q56S65YmN44Gu6Kaz5ris54q25oWL44Go6ZaL5aeL54K544O75a++6LGh54mI44O755Sx5p2l44GM5LiA6Ie044GX44G+44Gb44KT44CCJyk7XG4gICAgICBpZiAoZW50aXR5LmRhdGEucHJlc2VudGF0aW9uUmVzdWx0cyAhPSBudWxsKSB7XG4gICAgICAgIGNvbnN0IHZlcnNpb24gPSByZXNvbHZlVmVyc2lvbihlbnRpdHkuZGF0YS5jb250ZW50VmVyc2lvbklkKTtcbiAgICAgICAgaWYgKHZlcnNpb24pIGlzc3Vlcy5wdXNoKC4uLnZhbGlkYXRlSW5pdGlhbFByZXNlbnRhdGlvblJlc3VsdHMoeyAuLi5lbnRpdHkuZGF0YS5ydW50aW1lU3RhdGUsIHByb3ZlbmFuY2U6IGVudGl0eS5kYXRhLm9yaWdpbiA/PyAncGFydGlhbCcgfSwgZW50aXR5LmRhdGEucHJlc2VudGF0aW9uUmVzdWx0cywgWy4uLnZlcnNpb24uZW50aXRpZXMudmFsdWVzKCldLCBgJHtsb2NhdGlvbn0uZGF0YS5wcmVzZW50YXRpb25SZXN1bHRzYCkpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZW50aXR5LmtpbmQgPT09ICd0cmFjZScpIHtcbiAgICAgIGNvbnN0IHRyYWNlID0gZW50aXR5LmRhdGEgYXMgdHlwZW9mIGVudGl0eS5kYXRhICYgeyBtb2RlPzogJ2Zsb3cnIHwgJ2NoYXB0ZXJzJyB8IG51bGw7IHJlYWRpbmdQYXRoPzogaW1wb3J0KCcuL3R5cGVzJykuUmVhZGluZ1BhdGggfCBudWxsIH07XG4gICAgICBpZiAodHJhY2UuaW5pdGlhbFN0dWJCYXNlU3RhdGUgJiYgIXRyYWNlLmluaXRpYWxTdHViVmFsdWVzKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLmluaXRpYWxTdHViQmFzZVN0YXRlYCwgJ3N0dWLliY3jga7lgIvliKXnirbmhYvjgavjga/liJ3mnJ9zdHVi5YWl5Yqb44Gu6KiY6Yyy44GM5b+F6KaB44Gn44GZ44CCJyk7XG4gICAgICBpZiAodHJhY2UubW9kZSA9PT0gJ2NoYXB0ZXJzJykge1xuICAgICAgICBpZiAodHJhY2UuaW5pdGlhbFN0dWJWYWx1ZXMgfHwgdHJhY2UuaW5pdGlhbFN0dWJCYXNlU3RhdGUpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEuaW5pdGlhbFN0dWJWYWx1ZXNgLCAn56ug57WM6Lev44Gu5YCL5Yil6ZaL5aeL44GvY2hlY2twb2ludOOBuOOAgeWklumDqOS7ruWApOOBr2luaXRpYWxFeHRlcm5hbFZhbHVlc+OBuOiomOmMsuOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgICAgICBpZiAoIXRyYWNlLnJlYWRpbmdQYXRoKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLnJlYWRpbmdQYXRoYCwgJ+eroOiqreOBv+mAmuOBl+OBq+OBr+aPkOekuue1jOi3r+OBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgICBpZiAodHJhY2Uuc3RlcHMubGVuZ3RoKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLnN0ZXBzYCwgJ+eroOiqreOBv+mAmuOBl+OBqOODleODreODvOmBt+enu+OCkua3t+WcqOOBleOBm+OCieOCjOOBvuOBm+OCk+OAgicpO1xuICAgICAgfSBlbHNlIGlmICh0cmFjZS5yZWFkaW5nUGF0aCAhPSBudWxsKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5kYXRhLnJlYWRpbmdQYXRoYCwgJ+aPkOekuue1jOi3r+OBr21vZGU6Y2hhcHRlcnPjga7oqJjpjLLjgavmjIflrprjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgICAgIHRyYWNlLnN0ZXBzLmZvckVhY2goKHN0ZXAsIGluZGV4KSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgW2ZpZWxkLCBzdGF0ZV0gb2YgW1snYmVmb3JlJywgc3RlcC5iZWZvcmVdLCBbJ2FmdGVyJywgc3RlcC5hZnRlcl1dIGFzIGNvbnN0KSB7IGNvbnN0IHJlc3VsdCA9IHZhbGlkYXRlUnVudGltZVN0YXRlKHN0YXRlLCBgJHtsb2NhdGlvbn0uZGF0YS5zdGVwc1ske2luZGV4fV0uJHtmaWVsZH1gKTsgaWYgKCFyZXN1bHQub2spIGlzc3Vlcy5wdXNoKC4uLnJlc3VsdC5pc3N1ZXMpOyB9XG4gICAgICAgIGlmIChzdGVwLnByZXNlbnRhdGlvblN0YXRlICYmIChzdGVwLnByZXNlbnRhdGlvblN0YXRlLmNvbnRlbnRWZXJzaW9uSWQgIT09IHRyYWNlLmNvbnRlbnRWZXJzaW9uSWQgfHwgc3RlcC5wcmVzZW50YXRpb25TdGF0ZS5wcmVzZW50YXRpb25Qb3NpdGlvbiAhPT0gc3RlcC5hZnRlci5wcmVzZW50YXRpb25Qb3NpdGlvbiB8fCBzdGVwLnByZXNlbnRhdGlvblN0YXRlLnByb3ZlbmFuY2UgIT09IHN0ZXAuYWZ0ZXIucHJvdmVuYW5jZSkpIGFkZElzc3VlKGlzc3VlcywgYCR7bG9jYXRpb259LmRhdGEuc3RlcHNbJHtpbmRleH1dLnByZXNlbnRhdGlvblN0YXRlYCwgJ+aPkOekuuWJjeOBruims+a4rOeKtuaFi+OBqOaPkOekuuWFiOODu+WvvuixoeeJiOODu+eUseadpeOBjOS4gOiHtOOBl+OBvuOBm+OCk+OAgicpO1xuICAgICAgfSk7XG4gICAgICB0cmFjZS5yZWFkaW5nUGF0aD8ub2NjdXJyZW5jZXMuZm9yRWFjaCgob2NjdXJyZW5jZSwgaW5kZXgpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBbZmllbGQsIHN0YXRlXSBvZiBbWydiZWZvcmUnLCBvY2N1cnJlbmNlLmJlZm9yZV0sIFsnYWZ0ZXInLCBvY2N1cnJlbmNlLmFmdGVyXV0gYXMgY29uc3QpIHsgY29uc3QgcmVzdWx0ID0gdmFsaWRhdGVSdW50aW1lU3RhdGUoc3RhdGUsIGAke2xvY2F0aW9ufS5kYXRhLnJlYWRpbmdQYXRoLm9jY3VycmVuY2VzWyR7aW5kZXh9XS4ke2ZpZWxkfWApOyBpZiAoIXJlc3VsdC5vaykgaXNzdWVzLnB1c2goLi4ucmVzdWx0Lmlzc3Vlcyk7IH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG4gIGZvciAoY29uc3Qga2luZCBvZiBbJ3BsYWNlJywgJ2dyb3VwJywgJ2Zsb3dfZ3JhcGgnLCAnbWFwJ10gYXMgY29uc3QpIGN5Y2xlSXNzdWVzKHByb2plY3QuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiBlbnRpdHkua2luZCA9PT0ga2luZCAmJiAhZW50aXR5LmRlbGV0ZWRBdCksIGVudGl0eSA9PiB7XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAncGxhY2UnIHx8IGVudGl0eS5raW5kID09PSAnZ3JvdXAnKSByZXR1cm4gZW50aXR5LmRhdGEucGFyZW50SWQgPyBbZW50aXR5LmRhdGEucGFyZW50SWRdIDogW107XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnZmxvd19ncmFwaCcpIHJldHVybiBlbnRpdHkuZGF0YS5wYXJlbnRHcmFwaElkID8gW2VudGl0eS5kYXRhLnBhcmVudEdyYXBoSWRdIDogW107XG4gICAgaWYgKGVudGl0eS5raW5kID09PSAnbWFwJykgcmV0dXJuIGVudGl0eS5kYXRhLnBhcmVudE1hcElkID8gW2VudGl0eS5kYXRhLnBhcmVudE1hcElkXSA6IFtdO1xuICAgIHJldHVybiBbXTtcbiAgfSwgaXNzdWVzLCBwYXRoLCBgJHtLSU5EX0xBQkVMU1traW5kXX3jga7pmo7lsaRgKTtcbiAgY3ljbGVJc3N1ZXMocHJvamVjdC5lbnRpdGllcy5maWx0ZXIoZW50aXR5ID0+IGVudGl0eS5raW5kID09PSAncHJvZHVjdGlvbl90YXNrJyAmJiAhZW50aXR5LmRlbGV0ZWRBdCksIGVudGl0eSA9PiBlbnRpdHkua2luZCA9PT0gJ3Byb2R1Y3Rpb25fdGFzaycgPyBlbnRpdHkuZGF0YS5kZXBlbmRzT24gPz8gW10gOiBbXSwgaXNzdWVzLCBwYXRoLCAn5Yi25L2c5L6d5a2YJyk7XG4gIGN5Y2xlSXNzdWVzKHByb2plY3QuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiBlbnRpdHkua2luZCA9PT0gJ3ZhcmlhYmxlJyAmJiAhZW50aXR5LmRlbGV0ZWRBdCksIGVudGl0eSA9PiBlbnRpdHkua2luZCA9PT0gJ3ZhcmlhYmxlJyAmJiBlbnRpdHkuZGF0YS5kZXJpdmVkID8gZXhwcmVzc2lvblJlZmVyZW5jZXMoZW50aXR5LmRhdGEuZGVyaXZlZCkgOiBbXSwgaXNzdWVzLCBwYXRoLCAn566X5Ye654q25oWLJyk7XG4gIGN5Y2xlSXNzdWVzKHByb2plY3QuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiBlbnRpdHkua2luZCA9PT0gJ2Zsb3dfZ3JhcGgnICYmICFlbnRpdHkuZGVsZXRlZEF0KSwgZW50aXR5ID0+IGVudGl0eS5raW5kID09PSAnZmxvd19ncmFwaCcgPyBlbnRpdHkuZGF0YS5ub2RlSWRzLmZsYXRNYXAobm9kZUlkID0+IHsgY29uc3Qgbm9kZSA9IGVudGl0eU1hcC5nZXQobm9kZUlkKTsgcmV0dXJuIG5vZGU/LmtpbmQgPT09ICdmbG93X25vZGUnICYmIG5vZGUuZGF0YS5jaGlsZEdyYXBoSWQgPyBbbm9kZS5kYXRhLmNoaWxkR3JhcGhJZF0gOiBbXTsgfSkgOiBbXSwgaXNzdWVzLCBwYXRoLCAn5YiG5bKQ5Zuz44Gu5ZG85Ye66ZqO5bGkJyk7XG4gIGlzc3Vlcy5wdXNoKC4uLnZhbGlkYXRlRXZlbnRUaW1lcyhbLi4uZW50aXR5TWFwLnZhbHVlcygpXS5maWx0ZXIoKGVudGl0eSk6IGVudGl0eSBpcyBFbnRpdHk8J2V2ZW50Jz4gPT4gZW50aXR5LmtpbmQgPT09ICdldmVudCcgJiYgIWVudGl0eS5kZWxldGVkQXQpKSk7XG4gIGNvbnN0IGF1dG9tYXRpY1ByaW9yaXR5ID0gbmV3IE1hcDxzdHJpbmcsIElEPigpO1xuICBmb3IgKGNvbnN0IGVudGl0eSBvZiBwcm9qZWN0LmVudGl0aWVzKSBpZiAoZW50aXR5LmtpbmQgPT09ICdmbG93X2VkZ2UnICYmIGVudGl0eS5kYXRhLmVkZ2VUeXBlID09PSAnYXV0b21hdGljJyAmJiAhZW50aXR5LmRlbGV0ZWRBdCkge1xuICAgIGNvbnN0IHByaW9yaXR5S2V5ID0gYCR7ZW50aXR5LmRhdGEuZnJvbUlkfS8ke2VudGl0eS5kYXRhLnByaW9yaXR5ID8/IDB9YDtcbiAgICBpZiAoYXV0b21hdGljUHJpb3JpdHkuaGFzKHByaW9yaXR5S2V5KSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5lbnRpdGllcy4ke2VudGl0eS5pZH0uZGF0YS5wcmlvcml0eWAsICflkIzjgZjlp4vngrnjga7oh6rli5XlgJnoo5zjgaflhKrlhYjpoIbkvY3jgYzph43opIfjgZfjgabjgYTjgb7jgZnjgIInKTsgYXV0b21hdGljUHJpb3JpdHkuc2V0KHByaW9yaXR5S2V5LCBlbnRpdHkuaWQpO1xuICB9XG59XG5mdW5jdGlvbiBleHByZXNzaW9uUmVmZXJlbmNlcyhleHByZXNzaW9uOiBFeHByZXNzaW9uKTogSURbXSB7XG4gIGNvbnN0IHJlZmVyZW5jZXM6IERvbWFpblJlZmVyZW5jZVtdID0gW107IHdhbGsoeyB0eXBlOiAnZXhwcmVzc2lvbicgfSwgZXhwcmVzc2lvbiwgJycsIFtdLCByZWZlcmVuY2VzKTsgcmV0dXJuIHJlZmVyZW5jZXMuZmlsdGVyKHJlZmVyZW5jZSA9PiByZWZlcmVuY2Uua2luZHM/LmluY2x1ZGVzKCd2YXJpYWJsZScpKS5tYXAocmVmZXJlbmNlID0+IHJlZmVyZW5jZS5pZCk7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZUNvbmRpdGlvblR5cGVzSW5WYWx1ZSh2YWx1ZTogdW5rbm93biwgcGF0aDogc3RyaW5nLCBlbnRpdGllczogTWFwPElELCBFbnRpdHk+LCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdLCBkZXB0aCA9IDApOiB2b2lkIHtcbiAgaWYgKGRlcHRoID4gMzIgfHwgIXZhbHVlIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7IHZhbHVlLmZvckVhY2goKGNoaWxkLCBpKSA9PiB2YWxpZGF0ZUNvbmRpdGlvblR5cGVzSW5WYWx1ZShjaGlsZCwgYCR7cGF0aH1bJHtpfV1gLCBlbnRpdGllcywgaXNzdWVzLCBkZXB0aCArIDEpKTsgcmV0dXJuOyB9XG4gIGNvbnN0IG9iamVjdCA9IHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBpZiAob2JqZWN0Lm9wID09PSAnY29tcGFyZScpIHtcbiAgICBjb25zdCB2YXJpYWJsZSA9IGVudGl0aWVzLmdldChvYmplY3QudmFyaWFibGVJZCBhcyBJRCk7XG4gICAgaWYgKHZhcmlhYmxlPy5raW5kID09PSAndmFyaWFibGUnKSB7XG4gICAgICBjb25zdCBjb21wYXJhdG9yID0gb2JqZWN0LmNvbXBhcmF0b3IgYXMgc3RyaW5nLCB2YWx1ZXMgPSAoQXJyYXkuaXNBcnJheShvYmplY3QudmFsdWUpID8gb2JqZWN0LnZhbHVlIDogW29iamVjdC52YWx1ZV0pIGFzIFR5cGVkVmFsdWVbXTtcbiAgICAgIGlmIChbJ2x0JywgJ2xlJywgJ2d0JywgJ2dlJ10uaW5jbHVkZXMoY29tcGFyYXRvcikgJiYgdmFyaWFibGUuZGF0YS52YWx1ZVR5cGUgIT09ICdpbnRlZ2VyJykgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5jb21wYXJhdG9yYCwgJ+mghuW6j+avlOi8g+OBr2ludGVnZXLjgavjgaDjgZHkvb/jgYjjgb7jgZnjgIInKTtcbiAgICAgIHZhbHVlcy5mb3JFYWNoKChpdGVtLCBpKSA9PiB7IGlmIChpdGVtLnR5cGUgIT09ICd1bmtub3duJyAmJiBpdGVtLnR5cGUgIT09IHZhcmlhYmxlLmRhdGEudmFsdWVUeXBlKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9LnZhbHVlJHt2YWx1ZXMubGVuZ3RoID4gMSA/IGBbJHtpfV1gIDogJyd9YCwgJ+avlOi8g+WApOOBruWei+OBjOeKtuaFi+WkieaVsOOBqOS4gOiHtOOBl+OBvuOBm+OCk+OAgicpOyB9KTtcbiAgICB9XG4gIH1cbiAgZm9yIChjb25zdCBbZmllbGQsIGNoaWxkXSBvZiBPYmplY3QuZW50cmllcyhvYmplY3QpKSB2YWxpZGF0ZUNvbmRpdGlvblR5cGVzSW5WYWx1ZShjaGlsZCwgYCR7cGF0aH0uJHtmaWVsZH1gLCBlbnRpdGllcywgaXNzdWVzLCBkZXB0aCArIDEpO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVBbmNob3JzKHZhbHVlOiB1bmtub3duLCBwYXRoOiBzdHJpbmcsIGVudGl0aWVzOiBNYXA8SUQsIEVudGl0eT4sIGJsb2NrczogTWFwPElELCB7IGVudGl0eUlkOiBJRDsgdGV4dDogc3RyaW5nIH0+LCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdLCBkZXB0aCA9IDAsIHJlc29sdmVWZXJzaW9uPzogKHZlcnNpb246IElEKSA9PiBBbmNob3JJbmRleCB8IHVuZGVmaW5lZCwgZGVmYXVsdFZlcnNpb24/OiBJRCk6IHZvaWQge1xuICBpZiAoZGVwdGggPiAzMiB8fCAhdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHsgdmFsdWUuZm9yRWFjaCgoY2hpbGQsIGkpID0+IHZhbGlkYXRlQW5jaG9ycyhjaGlsZCwgYCR7cGF0aH1bJHtpfV1gLCBlbnRpdGllcywgYmxvY2tzLCBpc3N1ZXMsIGRlcHRoICsgMSwgcmVzb2x2ZVZlcnNpb24sIGRlZmF1bHRWZXJzaW9uKSk7IHJldHVybjsgfVxuICBjb25zdCBvYmplY3QgPSB2YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgaWYgKHR5cGVvZiBvYmplY3QuZW50aXR5SWQgPT09ICdzdHJpbmcnKSB7XG4gICAgaWYgKG9iamVjdC5wb3NpdGlvblN0YXR1cyA9PT0gJ3VucmVzb2x2ZWQnICYmICghb2JqZWN0LnBvc2l0aW9uUmVhc29uIHx8IG9iamVjdC5zdGFydCAhPSBudWxsIHx8IG9iamVjdC5lbmQgIT0gbnVsbCkpIGFkZElzc3VlKGlzc3VlcywgcGF0aCwgJ+S9jee9ruS4jeaYjuOBq+OBr+eQhueUseOCkuS7mOOBkeOAgeeiuuWumuOBl+OBn+aWh+Wtl+evhOWbsuOCkuWkluOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgIGlmIChvYmplY3QucG9zaXRpb25TdGF0dXMgIT09ICd1bnJlc29sdmVkJyAmJiAob2JqZWN0LnBvc2l0aW9uUmVhc29uICE9IG51bGwgfHwgb2JqZWN0LnF1b3RlZFRleHQgIT0gbnVsbCkpIGFkZElzc3VlKGlzc3VlcywgcGF0aCwgJ+S9jee9ruS4jeaYjuOBrueQhueUseODu+W8leeUqOOBr+S9jee9ruS4jeaYjueKtuaFi+OBqOS4gOe3kuOBq+S/neWtmOOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgIGNvbnN0IHZlcnNpb24gPSB0eXBlb2Ygb2JqZWN0LnNvdXJjZVZlcnNpb25JZCA9PT0gJ3N0cmluZycgPyBvYmplY3Quc291cmNlVmVyc2lvbklkIDogZGVmYXVsdFZlcnNpb24sIGluZGV4ID0gdmVyc2lvbiAmJiByZXNvbHZlVmVyc2lvbiA/IHJlc29sdmVWZXJzaW9uKHZlcnNpb24pIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IGVudGl0eUluZGV4ID0gaW5kZXg/LmVudGl0aWVzID8/IGVudGl0aWVzLCBibG9ja0luZGV4ID0gaW5kZXg/LmJsb2NrcyA/PyBibG9ja3M7XG4gICAgbGV0IHRhcmdldFRleHQ6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgICBpZiAodHlwZW9mIG9iamVjdC5ibG9ja0lkID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgYmxvY2sgPSBibG9ja0luZGV4LmdldChvYmplY3QuYmxvY2tJZCk7XG4gICAgICBpZiAoYmxvY2sgJiYgYmxvY2suZW50aXR5SWQgIT09IG9iamVjdC5lbnRpdHlJZCkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5ibG9ja0lkYCwgJ+auteiQveOBr+aMh+WumuOBl+OBn+aDheWgseOBq+WxnuOBl+OBpuOBhOOBvuOBm+OCk+OAgicsICdSRUZFUkVOQ0VfSU5WQUxJRCcpO1xuICAgICAgdGFyZ2V0VGV4dCA9IGJsb2NrPy50ZXh0O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG9iamVjdC5saW5lSWQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBsaW5lID0gZW50aXR5SW5kZXguZ2V0KG9iamVjdC5saW5lSWQpOyBpZiAobGluZT8ua2luZCA9PT0gJ2RpYWxvZ3VlX2xpbmUnKSB0YXJnZXRUZXh0ID0gcmljaFRleHRUb1BsYWluVGV4dChsaW5lLmRhdGEudGV4dCk7XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygb2JqZWN0LnN0YXJ0ID09PSAnbnVtYmVyJyB8fCB0eXBlb2Ygb2JqZWN0LmVuZCA9PT0gJ251bWJlcicpIHtcbiAgICAgIGlmICh0eXBlb2Ygb2JqZWN0LnN0YXJ0ICE9PSAnbnVtYmVyJyB8fCB0eXBlb2Ygb2JqZWN0LmVuZCAhPT0gJ251bWJlcicpIGFkZElzc3VlKGlzc3VlcywgcGF0aCwgJ+aWh+Wtl+evhOWbsuOBr3N0YXJ0L2VuZOOCkuWvvuOBp+aMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgICAgaWYgKHRhcmdldFRleHQgPT09IHVuZGVmaW5lZCkgYWRkSXNzdWUoaXNzdWVzLCBwYXRoLCAn5paH5a2X56+E5Zuy44Gr44Gv5pys5paH44OW44Ot44OD44Kv44G+44Gf44Gv5Y+w6Kme44G444Gu5Y+C54Wn44GM5b+F6KaB44Gn44GZ44CCJyk7XG4gICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0LmVuZCA9PT0gJ251bWJlcicgJiYgb2JqZWN0LmVuZCA+IGNvZGVQb2ludExlbmd0aCh0YXJnZXRUZXh0KSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS5lbmRgLCAn5paH5a2X56+E5Zuy44GM5Y+C54Wn5YWD44Gu5pys5paH44KS6LaF44GI44Gm44GE44G+44GZ44CCJyk7XG4gICAgfVxuICB9XG4gIGZvciAoY29uc3QgW2ZpZWxkLCBjaGlsZF0gb2YgT2JqZWN0LmVudHJpZXMob2JqZWN0KSkgaWYgKCFbJ3B1YmxpY1RleHRzJywgJ2JlZm9yZScsICdhZnRlcicsICdydW50aW1lU3RhdGUnXS5pbmNsdWRlcyhmaWVsZCkpIHZhbGlkYXRlQW5jaG9ycyhjaGlsZCwgYCR7cGF0aH0uJHtmaWVsZH1gLCBlbnRpdGllcywgYmxvY2tzLCBpc3N1ZXMsIGRlcHRoICsgMSwgcmVzb2x2ZVZlcnNpb24pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlUHJvamVjdChpbnB1dDogdW5rbm93biwgb3B0aW9uczogUHJvamVjdFZhbGlkYXRpb25PcHRpb25zID0ge30pOiBWYWxpZGF0aW9uUmVzdWx0PFByb2plY3REYXRhPiB7XG4gIGlmICghaXNPYmplY3QoaW5wdXQpKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogW3sgY29kZTogJ1ZBTElEQVRJT05fRkFJTEVEJywgcGF0aDogJ3Byb2plY3QnLCBtZXNzYWdlOiAn5L2c5ZOB44Gv44Kq44OW44K444Kn44Kv44OI44Gn44GZ44CCJyB9XSB9O1xuICBjb25zdCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdID0gW107XG4gIGZvciAoY29uc3QgZmllbGQgb2YgT2JqZWN0LmtleXMoaW5wdXQpKSBpZiAoIVsuLi5wcm9qZWN0S2V5cywgJ3NuYXBzaG90cycsICdoaXN0b3J5J10uaW5jbHVkZXMoZmllbGQpKSBhZGRJc3N1ZShpc3N1ZXMsIGBwcm9qZWN0LiR7ZmllbGR9YCwgJ+S9nOWTgeOBq+acquefpeOBrumgheebruOBjOOBguOCiuOBvuOBmeOAgicpO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoaW5wdXQuc25hcHNob3RzKSkgYWRkSXNzdWUoaXNzdWVzLCAncHJvamVjdC5zbmFwc2hvdHMnLCAn5b+F6aCI44Gu6YWN5YiX44Gn44GZ44CCJyk7XG4gIGlmICghQXJyYXkuaXNBcnJheShpbnB1dC5oaXN0b3J5KSkgYWRkSXNzdWUoaXNzdWVzLCAncHJvamVjdC5oaXN0b3J5JywgJ+W/hemgiOOBrumFjeWIl+OBp+OBmeOAgicpO1xuICBjb25zdCBzbmFwc2hvdElkcyA9IG5ldyBTZXQ8SUQ+KChBcnJheS5pc0FycmF5KGlucHV0LnNuYXBzaG90cykgPyBpbnB1dC5zbmFwc2hvdHMgOiBbXSkuZmxhdE1hcChzbmFwc2hvdCA9PiBpc09iamVjdChzbmFwc2hvdCkgJiYgdHlwZW9mIHNuYXBzaG90LmlkID09PSAnc3RyaW5nJyA/IFtzbmFwc2hvdC5pZF0gOiBbXSkpO1xuICBpZiAoT2JqZWN0Lmhhc093bihpbnB1dCwgJ2F1dGhvckFsdGVybmF0aXZlcycpKSB3YWxrKGFsdGVybmF0aXZlc1NjaGVtYSwgaW5wdXQuYXV0aG9yQWx0ZXJuYXRpdmVzLCAncHJvamVjdC5hdXRob3JBbHRlcm5hdGl2ZXMnLCBpc3N1ZXMsIFtdKTtcbiAgY29uc3QgY29udGVudCA9IE9iamVjdC5mcm9tRW50cmllcyhwcm9qZWN0Q29udGVudEtleXMuZmlsdGVyKGZpZWxkID0+IE9iamVjdC5oYXNPd24oaW5wdXQsIGZpZWxkKSkubWFwKGZpZWxkID0+IFtmaWVsZCwgaW5wdXRbZmllbGRdXSkpO1xuICBjb25zdCB2YWxpZGF0ZWQgPSB2YWxpZGF0ZUNvbnRlbnQoY29udGVudCwgJ3Byb2plY3QnLCBvcHRpb25zLCBzbmFwc2hvdElkcywgc25hcHNob3RDb250ZW50TWFwKGlucHV0LnNuYXBzaG90cykpOyBpZiAoIXZhbGlkYXRlZC5vaykgaXNzdWVzLnB1c2goLi4udmFsaWRhdGVkLmlzc3Vlcyk7XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSByZXR1cm4geyBvazogZmFsc2UsIGlzc3VlczogaXNzdWVzLnNsaWNlKDAsIDI1NikgfTtcbiAgY29uc3QgcHJvamVjdCA9IGlucHV0IGFzIHVua25vd24gYXMgUHJvamVjdERhdGE7XG4gIHZhbGlkYXRlU25hcHNob3RDb2xsZWN0aW9uKHByb2plY3Quc25hcHNob3RzLCAncHJvamVjdC5zbmFwc2hvdHMnLCBwcm9qZWN0LnByb2plY3RJZCwgb3B0aW9ucywgaXNzdWVzKTtcbiAgY29uc3QgaGlzdG9yeUlkcyA9IG5ldyBTZXQ8SUQ+KCk7XG4gIHByb2plY3QuaGlzdG9yeS5mb3JFYWNoKChjb21tYW5kLCBpKSA9PiB7XG4gICAgY29uc3QgcGF0aCA9IGBwcm9qZWN0Lmhpc3RvcnlbJHtpfV1gLCByYXcgPSBjb21tYW5kIGFzIHVua25vd247XG4gICAgaWYgKCFpc09iamVjdChyYXcpKSB7IGFkZElzc3VlKGlzc3VlcywgcGF0aCwgJ+WxpeattOOBr+OCs+ODnuODs+ODieOBp+OBmeOAgicpOyByZXR1cm47IH1cbiAgICBjb25zdCBjb21tYW5kTWV0YSA9IG9iaih7IG9wZXJhdGlvbklkOiByZXEoaWRTY2hlbWEpLCBwcm9qZWN0SWQ6IHJlcShpZFNjaGVtYSksIGJhc2VSZXZpc2lvbjogcmVxKHsgdHlwZTogJ3JldmlzaW9uJyB9KSwgcmV2aXNpb246IHJlcSh7IHR5cGU6ICdyZXZpc2lvbicgfSksIHRhcmdldElkczogcmVxKGFycihpZFNjaGVtYSwgdHJ1ZSkpLCByZWFzb246IHJlcSh0eHQoKSksIGNyZWF0ZWRBdDogcmVxKHsgdHlwZTogJ2RhdGV0aW1lJyB9KSwgY29tcGVuc2F0ZXNPcGVyYXRpb25JZDogb3B0KGlkU2NoZW1hKSwgaWRNYXA6IG9wdChyZWNvcmQoaWRTY2hlbWEsIGlkU2NoZW1hKSksIGltcG9ydE9yaWdpbjogb3B0KG9iaih7IHNvdXJjZVByb2plY3RJZDogcmVxKGlkU2NoZW1hKSwgc291cmNlT3BlcmF0aW9uSWQ6IHJlcShpZFNjaGVtYSksIGltcG9ydE9wZXJhdGlvbklkOiByZXEoaWRTY2hlbWEpIH0pKSB9KTtcbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIE9iamVjdC5rZXlzKHJhdykpIGlmIChmaWVsZCAhPT0gJ2JlZm9yZScgJiYgZmllbGQgIT09ICdhZnRlcicgJiYgY29tbWFuZE1ldGEudHlwZSA9PT0gJ29iamVjdCcgJiYgIU9iamVjdC5oYXNPd24oY29tbWFuZE1ldGEuZmllbGRzLCBmaWVsZCkpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtmaWVsZH1gLCAn44Kz44Oe44Oz44OJ44Gr5pyq55+l44Gu6aCF55uu44GM44GC44KK44G+44GZ44CCJyk7XG4gICAgd2Fsayhjb21tYW5kTWV0YSwgT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKHJhdykuZmlsdGVyKChbZmllbGRdKSA9PiBmaWVsZCAhPT0gJ2JlZm9yZScgJiYgZmllbGQgIT09ICdhZnRlcicpKSwgcGF0aCwgaXNzdWVzLCBbXSk7XG4gICAgaWYgKGhpc3RvcnlJZHMuaGFzKGNvbW1hbmQub3BlcmF0aW9uSWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9Lm9wZXJhdGlvbklkYCwgJ+WxpeattOOBruaTjeS9nElE44GM6YeN6KSH44GX44Gm44GE44G+44GZ44CCJyk7IGhpc3RvcnlJZHMuYWRkKGNvbW1hbmQub3BlcmF0aW9uSWQpO1xuICAgIGlmIChjb21tYW5kLnByb2plY3RJZCAhPT0gcHJvamVjdC5wcm9qZWN0SWQpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0ucHJvamVjdElkYCwgJ+WxpeattOOBjOWIpeOBruS9nOWTgeOBq+WxnuOBl+OBpuOBhOOBvuOBmeOAgicpO1xuICAgIGZvciAoY29uc3QgZmllbGQgb2YgWydiZWZvcmUnLCAnYWZ0ZXInXSBhcyBjb25zdCkge1xuICAgICAgaWYgKCFpc09iamVjdChyYXdbZmllbGRdKSkgeyBhZGRJc3N1ZShpc3N1ZXMsIGAke3BhdGh9LiR7ZmllbGR9YCwgJ+WkieabtOWJjeW+jOOBruWGheWuueOCkuS/neaMgeOBl+OBpuOBj+OBoOOBleOBhOOAgicpOyBjb250aW51ZTsgfVxuICAgICAgY29uc3Qgc3RhdGUgPSByYXdbZmllbGRdIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHN0YXRlLnNuYXBzaG90cykpIGFkZElzc3VlKGlzc3VlcywgYCR7cGF0aH0uJHtmaWVsZH0uc25hcHNob3RzYCwgJ+W+qeWFg+OBq+W/heimgeOBquWFrOmWi+eJiOmFjeWIl+OBjOW/heimgeOBp+OBmeOAgicpO1xuICAgICAgaWYgKE9iamVjdC5oYXNPd24oc3RhdGUsICdhdXRob3JBbHRlcm5hdGl2ZXMnKSkgd2FsayhhbHRlcm5hdGl2ZXNTY2hlbWEsIHN0YXRlLmF1dGhvckFsdGVybmF0aXZlcywgYCR7cGF0aH0uJHtmaWVsZH0uYXV0aG9yQWx0ZXJuYXRpdmVzYCwgaXNzdWVzLCBbXSk7XG4gICAgICBjb25zdCBoaXN0b3JpY2FsID0gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKHN0YXRlKS5maWx0ZXIoKFtrZXldKSA9PiBrZXkgIT09ICdzbmFwc2hvdHMnICYmIGtleSAhPT0gJ2F1dGhvckFsdGVybmF0aXZlcycpKTtcbiAgICAgIGNvbnN0IGhpc3RvcmljYWxJZHMgPSBuZXcgU2V0PElEPigoQXJyYXkuaXNBcnJheShzdGF0ZS5zbmFwc2hvdHMpID8gc3RhdGUuc25hcHNob3RzIDogW10pLmZsYXRNYXAoaXRlbSA9PiBpc09iamVjdChpdGVtKSAmJiB0eXBlb2YgaXRlbS5pZCA9PT0gJ3N0cmluZycgPyBbaXRlbS5pZF0gOiBbXSkpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gdmFsaWRhdGVDb250ZW50KGhpc3RvcmljYWwsIGAke3BhdGh9LiR7ZmllbGR9YCwgb3B0aW9ucywgaGlzdG9yaWNhbElkcywgc25hcHNob3RDb250ZW50TWFwKHN0YXRlLnNuYXBzaG90cykpOyBpZiAoIXJlc3VsdC5vaykgaXNzdWVzLnB1c2goLi4ucmVzdWx0Lmlzc3Vlcyk7XG4gICAgICBlbHNlIGlmIChyZXN1bHQudmFsdWUucHJvamVjdElkICE9PSBwcm9qZWN0LnByb2plY3RJZCkgYWRkSXNzdWUoaXNzdWVzLCBgJHtwYXRofS4ke2ZpZWxkfS5wcm9qZWN0SWRgLCAn5bGl5q2044Gu5YaF5a6544GM5Yil44Gu5L2c5ZOB44Gr5bGe44GX44Gm44GE44G+44GZ44CCJyk7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShzdGF0ZS5zbmFwc2hvdHMpKSB2YWxpZGF0ZVNuYXBzaG90Q29sbGVjdGlvbihzdGF0ZS5zbmFwc2hvdHMsIGAke3BhdGh9LiR7ZmllbGR9LnNuYXBzaG90c2AsIHByb2plY3QucHJvamVjdElkLCBvcHRpb25zLCBpc3N1ZXMpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBpc3N1ZXMubGVuZ3RoID8geyBvazogZmFsc2UsIGlzc3VlczogaXNzdWVzLnNsaWNlKDAsIDI1NikgfSA6IHsgb2s6IHRydWUsIHZhbHVlOiBwcm9qZWN0IH07XG59XG4vKiogQ3VycmVudCBjb250ZW50IGZvciBhbiBlZGl0IG9mIHByZXZpb3VzbHkgdmVyaWZpZWQgc3RvcmFnZS4gSW1wb3J0cyBzdGlsbCB1c2UgdmFsaWRhdGVQcm9qZWN0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlQ3VycmVudFByb2plY3QoaW5wdXQ6IFByb2plY3REYXRhLCBvcHRpb25zOiBQcm9qZWN0VmFsaWRhdGlvbk9wdGlvbnMgPSB7fSwgcmV1c2U/OiBWYWxpZGF0aW9uUmV1c2UpOiBWYWxpZGF0aW9uUmVzdWx0PFByb2plY3REYXRhPiB7XG4gIGNvbnN0IGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10gPSBbXTtcbiAgZm9yIChjb25zdCBmaWVsZCBvZiBPYmplY3Qua2V5cyhpbnB1dCkpIGlmICghWy4uLnByb2plY3RLZXlzLCAnc25hcHNob3RzJywgJ2hpc3RvcnknXS5pbmNsdWRlcyhmaWVsZCkpIGFkZElzc3VlKGlzc3VlcywgYHByb2plY3QuJHtmaWVsZH1gLCAn5L2c5ZOB44Gr5pyq55+l44Gu6aCF55uu44GM44GC44KK44G+44GZ44CCJyk7XG4gIGlmICghQXJyYXkuaXNBcnJheShpbnB1dC5zbmFwc2hvdHMpIHx8ICFBcnJheS5pc0FycmF5KGlucHV0Lmhpc3RvcnkpKSBhZGRJc3N1ZShpc3N1ZXMsICdwcm9qZWN0JywgJ+WFrOmWi+eJiOOBqOWxpeattOOBrumFjeWIl+OBjOW/heimgeOBp+OBmeOAgicpO1xuICBpZiAoT2JqZWN0Lmhhc093bihpbnB1dCwgJ2F1dGhvckFsdGVybmF0aXZlcycpKSB3YWxrKGFsdGVybmF0aXZlc1NjaGVtYSwgaW5wdXQuYXV0aG9yQWx0ZXJuYXRpdmVzLCAncHJvamVjdC5hdXRob3JBbHRlcm5hdGl2ZXMnLCBpc3N1ZXMsIFtdKTtcbiAgaWYgKGlzc3Vlcy5sZW5ndGgpIHJldHVybiB7IG9rOiBmYWxzZSwgaXNzdWVzIH07XG4gIGNvbnN0IGlkcyA9IG5ldyBTZXQoaW5wdXQuc25hcHNob3RzLm1hcChzbmFwc2hvdCA9PiBzbmFwc2hvdC5pZCkpO1xuICBjb25zdCBjb250ZW50ID0gT2JqZWN0LmZyb21FbnRyaWVzKHByb2plY3RDb250ZW50S2V5cy5maWx0ZXIoZmllbGQgPT4gT2JqZWN0Lmhhc093bihpbnB1dCwgZmllbGQpKS5tYXAoZmllbGQgPT4gW2ZpZWxkLCAoaW5wdXQgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilbZmllbGRdXSkpO1xuICBjb25zdCByZXN1bHQgPSB2YWxpZGF0ZUNvbnRlbnQoY29udGVudCwgJ3Byb2plY3QnLCBvcHRpb25zLCBpZHMsIHNuYXBzaG90Q29udGVudE1hcChpbnB1dC5zbmFwc2hvdHMpLCByZXVzZSk7XG4gIHJldHVybiByZXN1bHQub2sgPyB7IG9rOiB0cnVlLCB2YWx1ZTogaW5wdXQgfSA6IHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlU25hcHNob3RDb2xsZWN0aW9uKHNuYXBzaG90czogdW5rbm93bltdLCBwYXRoOiBzdHJpbmcsIHByb2plY3RJZDogSUQsIG9wdGlvbnM6IFByb2plY3RWYWxpZGF0aW9uT3B0aW9ucywgaXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSk6IHZvaWQge1xuICBjb25zdCBpZHMgPSBuZXcgU2V0PElEPihzbmFwc2hvdHMuZmxhdE1hcChzbmFwc2hvdCA9PiBpc09iamVjdChzbmFwc2hvdCkgJiYgdHlwZW9mIHNuYXBzaG90LmlkID09PSAnc3RyaW5nJyA/IFtzbmFwc2hvdC5pZF0gOiBbXSkpLCBkdXBsaWNhdGVzID0gbmV3IFNldDxJRD4oKSwgY29udGVudHMgPSBzbmFwc2hvdENvbnRlbnRNYXAoc25hcHNob3RzKTtcbiAgc25hcHNob3RzLmZvckVhY2goKHNuYXBzaG90LCBpKSA9PiB7XG4gICAgY29uc3QgbG9jYXRpb24gPSBgJHtwYXRofVske2l9XWA7XG4gICAgaWYgKCFpc09iamVjdChzbmFwc2hvdCkpIHsgYWRkSXNzdWUoaXNzdWVzLCBsb2NhdGlvbiwgJ+WFrOmWi+eJiOOBr+OCquODluOCuOOCp+OCr+ODiOOBp+OBmeOAgicpOyByZXR1cm47IH1cbiAgICBjb25zdCBtZXRhZGF0YSA9IG9iaih7IGlkOiByZXEoaWRTY2hlbWEpLCB2ZXJzaW9uTGFiZWw6IHJlcSh0eHQoMSwgMTI4KSksIGNvbnRlbnRIYXNoOiByZXEoeyB0eXBlOiAnaGFzaCcgfSksIGNyZWF0ZWRBdDogcmVxKHsgdHlwZTogJ2RhdGV0aW1lJyB9KSB9KTtcbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIE9iamVjdC5rZXlzKHNuYXBzaG90KSkgaWYgKCFbJ2lkJywgJ3ZlcnNpb25MYWJlbCcsICdjb250ZW50SGFzaCcsICdjcmVhdGVkQXQnLCAnY29udGVudCddLmluY2x1ZGVzKGZpZWxkKSkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uJHtmaWVsZH1gLCAn5YWs6ZaL54mI44Gr5pyq55+l44Gu6aCF55uu44GM44GC44KK44G+44GZ44CCJyk7XG4gICAgd2FsayhtZXRhZGF0YSwgT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKHNuYXBzaG90KS5maWx0ZXIoKFtmaWVsZF0pID0+IGZpZWxkICE9PSAnY29udGVudCcpKSwgbG9jYXRpb24sIGlzc3VlcywgW10pO1xuICAgIGlmICh0eXBlb2Ygc25hcHNob3QuaWQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBpZiAoZHVwbGljYXRlcy5oYXMoc25hcHNob3QuaWQpKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5pZGAsICflhazplovniYjjga5JROOBjOmHjeikh+OBl+OBpuOBhOOBvuOBmeOAgicpOyBkdXBsaWNhdGVzLmFkZChzbmFwc2hvdC5pZCk7XG4gICAgICBpZiAoc25hcHNob3QuaWQgPT09IHByb2plY3RJZCkgYWRkSXNzdWUoaXNzdWVzLCBgJHtsb2NhdGlvbn0uaWRgLCAn5YWs6ZaL54mISUTjga/kvZzlk4FJROOBqOWIpeOBq+OBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSB2YWxpZGF0ZUNvbnRlbnQoc25hcHNob3QuY29udGVudCwgYCR7bG9jYXRpb259LmNvbnRlbnRgLCBvcHRpb25zLCBpZHMsIGNvbnRlbnRzKTtcbiAgICBpZiAoIXJlc3VsdC5vaykgaXNzdWVzLnB1c2goLi4ucmVzdWx0Lmlzc3Vlcyk7XG4gICAgZWxzZSBpZiAocmVzdWx0LnZhbHVlLnByb2plY3RJZCAhPT0gcHJvamVjdElkKSBhZGRJc3N1ZShpc3N1ZXMsIGAke2xvY2F0aW9ufS5jb250ZW50LnByb2plY3RJZGAsICflhazplovniYjjgYzliKXjga7kvZzlk4HjgavlsZ7jgZfjgabjgYTjgb7jgZnjgIInKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBzbmFwc2hvdENvbnRlbnRNYXAoc25hcHNob3RzOiB1bmtub3duKTogTWFwPElELCBQcm9qZWN0Q29udGVudD4ge1xuICBpZiAoIUFycmF5LmlzQXJyYXkoc25hcHNob3RzKSkgcmV0dXJuIG5ldyBNYXAoKTtcbiAgcmV0dXJuIG5ldyBNYXAoc25hcHNob3RzLmZsYXRNYXAoc25hcHNob3QgPT4gaXNPYmplY3Qoc25hcHNob3QpICYmIHR5cGVvZiBzbmFwc2hvdC5pZCA9PT0gJ3N0cmluZycgJiYgaXNPYmplY3Qoc25hcHNob3QuY29udGVudCkgJiYgWydlbnRpdGllcycsICdyZWxhdGlvbnMnLCAnY2FsZW5kYXJzJywgJ3dvcmxkUmVmZXJlbmNlcyddLmV2ZXJ5KGtleSA9PiBBcnJheS5pc0FycmF5KChzbmFwc2hvdC5jb250ZW50IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtrZXldKSAmJiAoKHNuYXBzaG90LmNvbnRlbnQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW2tleV0gYXMgdW5rbm93bltdKS5ldmVyeShpc09iamVjdCkpID8gW1tzbmFwc2hvdC5pZCwgc25hcHNob3QuY29udGVudCBhcyB1bmtub3duIGFzIFByb2plY3RDb250ZW50XV0gOiBbXSkpO1xufVxuXG50eXBlIEpzb25TY2hlbWEgPSBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbi8qKiBQb3J0YWJsZSBzdHJ1Y3R1cmFsIHNjaGVtYS4gQ3Jvc3MtcmVjb3JkIHJ1bGVzIHJlbWFpbiBpbiB2YWxpZGF0ZVByb2plY3QuICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uU2NoZW1hKCk6IEpzb25TY2hlbWEge1xuICBjb25zdCByZWZlcmVuY2UgPSAobmFtZTogc3RyaW5nKTogSnNvblNjaGVtYSA9PiAoeyAkcmVmOiBgIy8kZGVmcy8ke25hbWV9YCB9KTtcbiAgZnVuY3Rpb24gY29udmVydChzY2hlbWE6IFNjaGVtYSk6IEpzb25TY2hlbWEge1xuICAgIHN3aXRjaCAoc2NoZW1hLnR5cGUpIHtcbiAgICAgIGNhc2UgJ3RleHQnOiByZXR1cm4geyB0eXBlOiAnc3RyaW5nJywgLi4uKHNjaGVtYS5taW4gIT0gbnVsbCA/IHsgbWluTGVuZ3RoOiBzY2hlbWEubWluIH0gOiB7fSksIC4uLihzY2hlbWEubWF4ICE9IG51bGwgPyB7IG1heExlbmd0aDogc2NoZW1hLm1heCB9IDoge30pIH07XG4gICAgICBjYXNlICdudW1iZXInOiByZXR1cm4geyB0eXBlOiBzY2hlbWEuaW50ZWdlciA/ICdpbnRlZ2VyJyA6ICdudW1iZXInLCAuLi4oc2NoZW1hLm1pbiAhPSBudWxsID8geyBtaW5pbXVtOiBzY2hlbWEubWluIH0gOiBzY2hlbWEuaW50ZWdlciA/IHsgbWluaW11bTogTnVtYmVyLk1JTl9TQUZFX0lOVEVHRVIgfSA6IHt9KSwgLi4uKHNjaGVtYS5tYXggIT0gbnVsbCA/IHsgbWF4aW11bTogc2NoZW1hLm1heCB9IDogc2NoZW1hLmludGVnZXIgPyB7IG1heGltdW06IE51bWJlci5NQVhfU0FGRV9JTlRFR0VSIH0gOiB7fSkgfTtcbiAgICAgIGNhc2UgJ2Jvb2xlYW4nOiByZXR1cm4geyB0eXBlOiAnYm9vbGVhbicgfTtcbiAgICAgIGNhc2UgJ2pzb24nOiByZXR1cm4ge307XG4gICAgICBjYXNlICdlbnVtJzogcmV0dXJuIHsgZW51bTogc2NoZW1hLnZhbHVlcyB9O1xuICAgICAgY2FzZSAnaWQnOiByZXR1cm4gcmVmZXJlbmNlKCdJRCcpO1xuICAgICAgY2FzZSAncmVmJzogcmV0dXJuIHsgLi4uKHNjaGVtYS5zY29wZSA9PT0gJ2NhbGVuZGFyJyA/IHsgdHlwZTogJ3N0cmluZycsIG1pbkxlbmd0aDogMSB9IDogcmVmZXJlbmNlKCdJRCcpKSwgLi4uKHNjaGVtYS5raW5kcyB8fCBzY2hlbWEuc2NvcGUgPyB7ICRjb21tZW50OiBKU09OLnN0cmluZ2lmeSh7IC4uLihzY2hlbWEua2luZHMgPyB7IHRhcmdldEtpbmRzOiBzY2hlbWEua2luZHMgfSA6IHt9KSwgLi4uKHNjaGVtYS5zY29wZSA/IHsgcmVmZXJlbmNlU2NvcGU6IHNjaGVtYS5zY29wZSB9IDoge30pIH0pIH0gOiB7fSkgfTtcbiAgICAgIGNhc2UgJ3RpY2snOiByZXR1cm4gcmVmZXJlbmNlKCdUaWNrJyk7XG4gICAgICBjYXNlICdyZXZpc2lvbic6IHJldHVybiByZWZlcmVuY2UoJ1JldmlzaW9uJyk7XG4gICAgICBjYXNlICdkYXRldGltZSc6IHJldHVybiB7IHR5cGU6ICdzdHJpbmcnLCBmb3JtYXQ6ICdkYXRlLXRpbWUnLCBwYXR0ZXJuOiAnXlxcXFxkezR9LVxcXFxkezJ9LVxcXFxkezJ9VCg/OlswMV1bMC05XXwyWzAtM10pOlswLTVdWzAtOV06WzAtNV1bMC05XSg/OlxcXFwuXFxcXGQrKT8oPzpafFxcXFwrMDA6MDApJCcgfTtcbiAgICAgIGNhc2UgJ2RhdGUnOiByZXR1cm4geyB0eXBlOiAnc3RyaW5nJywgZm9ybWF0OiAnZGF0ZScgfTtcbiAgICAgIGNhc2UgJ2hhc2gnOiByZXR1cm4geyB0eXBlOiAnc3RyaW5nJywgcGF0dGVybjogJ15bMC05YS1mXXs2NH0kJyB9O1xuICAgICAgY2FzZSAnc2FmZV9wYXRoJzogcmV0dXJuIHsgdHlwZTogJ3N0cmluZycsIG1pbkxlbmd0aDogMSwgcGF0dGVybjogJ14oPyEvKSg/IVthLXpBLVpdOikoPyEuKltcXFxcXFxcXFxcXFx1MDAwMC1cXFxcdTAwMWZcXFxcdTAwN2ZdKSg/IS4qKD86XnwvKVxcXFwuXFxcXC4/KD86L3wkKSkoPyEuKi8vKSg/IS4qXFxcXC8kKS4rJCcgfTtcbiAgICAgIGNhc2UgJ2FycmF5JzogcmV0dXJuIHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IGNvbnZlcnQoc2NoZW1hLml0ZW0pLCAuLi4oc2NoZW1hLm1pbiAhPSBudWxsID8geyBtaW5JdGVtczogc2NoZW1hLm1pbiB9IDoge30pLCBtYXhJdGVtczogc2NoZW1hLm1heCA/PyAxMDBfMDAwLCAuLi4oc2NoZW1hLnVuaXF1ZSA/IHsgdW5pcXVlSXRlbXM6IHRydWUgfSA6IHt9KSB9O1xuICAgICAgY2FzZSAnb2JqZWN0JzogcmV0dXJuIHsgdHlwZTogJ29iamVjdCcsIHByb3BlcnRpZXM6IE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhzY2hlbWEuZmllbGRzKS5tYXAoKFtuYW1lLCBmaWVsZF0pID0+IFtuYW1lLCBmaWVsZC5udWxsYWJsZSA/IHsgYW55T2Y6IFtjb252ZXJ0KGZpZWxkLnNjaGVtYSksIHsgdHlwZTogJ251bGwnIH1dIH0gOiBjb252ZXJ0KGZpZWxkLnNjaGVtYSldKSksIHJlcXVpcmVkOiBPYmplY3QuZW50cmllcyhzY2hlbWEuZmllbGRzKS5maWx0ZXIoKFssIGZpZWxkXSkgPT4gZmllbGQucmVxdWlyZWQpLm1hcCgoW25hbWVdKSA9PiBuYW1lKSwgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlIH07XG4gICAgICBjYXNlICdyZWNvcmQnOiByZXR1cm4geyB0eXBlOiAnb2JqZWN0JywgYWRkaXRpb25hbFByb3BlcnRpZXM6IGNvbnZlcnQoc2NoZW1hLnZhbHVlKSwgLi4uKHNjaGVtYS5rZXkgPyB7IHByb3BlcnR5TmFtZXM6IGNvbnZlcnQoc2NoZW1hLmtleSkgfSA6IHt9KSB9O1xuICAgICAgY2FzZSAndW5pb24nOiByZXR1cm4geyBhbnlPZjogc2NoZW1hLmNob2ljZXMubWFwKGNvbnZlcnQpIH07XG4gICAgICBjYXNlICdyaWNodGV4dCc6IHJldHVybiByZWZlcmVuY2UoJ1JpY2hUZXh0Jyk7XG4gICAgICBjYXNlICdjdXN0b20nOiByZXR1cm4gcmVmZXJlbmNlKCdDdXN0b21WYWx1ZScpO1xuICAgICAgY2FzZSAndHlwZWQnOiByZXR1cm4gcmVmZXJlbmNlKCdUeXBlZFZhbHVlJyk7XG4gICAgICBjYXNlICd0aW1lJzogcmV0dXJuIHJlZmVyZW5jZSgnVGltZVNwZWMnKTtcbiAgICAgIGNhc2UgJ2NvbmRpdGlvbic6IHJldHVybiByZWZlcmVuY2UoJ0NvbmRpdGlvbicpO1xuICAgICAgY2FzZSAnZXhwcmVzc2lvbic6IHJldHVybiByZWZlcmVuY2UoJ0V4cHJlc3Npb24nKTtcbiAgICAgIGNhc2UgJ25hbWVfcG9saWN5JzogcmV0dXJuIHJlZmVyZW5jZSgnTmFtZVBvbGljeScpO1xuICAgICAgY2FzZSAncXVlcnknOiByZXR1cm4gcmVmZXJlbmNlKCdRdWVyeScpO1xuICAgIH1cbiAgfVxuICBjb25zdCBjb25kaXRpb25hbERlZmluaXRpb25zID0gWydjb25zdGFudCcsICdhbGwnLCAnYW55JywgJ25vdCcsICdjb21wYXJlJywgJ2l0ZW0nLCAna25vd24nLCAndmlzaXRlZCcsICdleHRlcm5hbCddLm1hcChvcCA9PiB7XG4gICAgY29uc3QgZGVmaW5pdGlvbiA9IGNvbnZlcnQoY29uZGl0aW9uU2NoZW1hKHsgb3AsIGNvbXBhcmF0b3I6ICdlcScgfSkhKTsgKGRlZmluaXRpb24ucHJvcGVydGllcyBhcyBSZWNvcmQ8c3RyaW5nLCBKc29uU2NoZW1hPikub3AgPSB7IGNvbnN0OiBvcCB9OyByZXR1cm4gZGVmaW5pdGlvbjtcbiAgfSk7XG4gIGNvbmRpdGlvbmFsRGVmaW5pdGlvbnMucHVzaChjb252ZXJ0KGNvbmRpdGlvblNjaGVtYSh7IG9wOiAnY29tcGFyZScsIGNvbXBhcmF0b3I6ICdpbicgfSkhKSk7XG4gIC8vIFNlcGFyYXRlIGNvbXBhcmlzb24gb3BlcmF0b3JzIHRvIGF2b2lkIGFuIGFtYmlndW91cyBvbmVPZiBicmFuY2ggZm9yIGBpbmAuXG4gIGNvbnN0IGNvbXBhcmVEZWZpbml0aW9uID0gY29uZGl0aW9uYWxEZWZpbml0aW9uc1s0XSBhcyB7IHByb3BlcnRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IH07IGNvbXBhcmVEZWZpbml0aW9uLnByb3BlcnRpZXMuY29tcGFyYXRvciA9IHsgZW51bTogWydlcScsICduZScsICdsdCcsICdsZScsICdndCcsICdnZSddIH07XG4gIGNvbnN0IGluRGVmaW5pdGlvbiA9IGNvbmRpdGlvbmFsRGVmaW5pdGlvbnMuYXQoLTEpIGFzIHsgcHJvcGVydGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfTsgaW5EZWZpbml0aW9uLnByb3BlcnRpZXMuY29tcGFyYXRvciA9IHsgY29uc3Q6ICdpbicgfTtcbiAgY29uc3Qgc3BhbiA9IHsgc3RhcnQ6IHJlcShudW0oMCwgdW5kZWZpbmVkLCB0cnVlKSksIGVuZDogcmVxKG51bSgwLCB1bmRlZmluZWQsIHRydWUpKSB9O1xuICBjb25zdCBibG9jayA9IG9iaih7IGlkOiByZXEoaWRTY2hlbWEpLCBraW5kOiByZXEoZW4oJ3BhcmFncmFwaCcsICdoZWFkaW5nJywgJ2xpc3RfaXRlbScsICdxdW90ZScpKSwgdGV4dDogcmVxKHR4dCgpKSwgcnVieTogb3B0KGFycihvYmooeyAuLi5zcGFuLCB0ZXh0OiByZXEodHh0KCkpIH0pKSksIGxpbmtzOiBvcHQoYXJyKG9iaih7IC4uLnNwYW4sIHRhcmdldDogcmVxKGFuY2hvcikgfSkpKSwgdW5yZXNvbHZlZEFubm90YXRpb25zOiBvcHQoYXJyKHVucmVzb2x2ZWRUZXh0QW5ub3RhdGlvbikpIH0pO1xuICBjb25zdCBjYWxlbmRhckNvbW1vbiA9IHsgaWQ6IHJlcSh0eHQoMSkpLCBuYW1lOiByZXEodHh0KDEpKSwgb3JpZ2luTGFiZWw6IHJlcSh0eHQoKSksIHRpY2tzUGVyRGF5OiByZXEodGljaykgfTtcbiAgY29uc3QgY2FsZW5kYXIgPSB1bmlvbihvYmooeyAuLi5jYWxlbmRhckNvbW1vbiwga2luZDogcmVxKGVuKCdncmVnb3JpYW4nKSkgfSksIG9iaih7IC4uLmNhbGVuZGFyQ29tbW9uLCBraW5kOiByZXEoZW4oJ3JlcGVhdGluZycpKSwgeWVhcnM6IHJlcShhcnIob2JqKHsgbW9udGhzOiByZXEoYXJyKG9iaih7IG5hbWU6IHJlcSh0eHQoMSkpLCBkYXlzOiByZXEobnVtKDEsIDQwMCwgdHJ1ZSkpIH0pLCBmYWxzZSwgMSwgMjQpKSB9KSwgZmFsc2UsIDEsIDQwMCkpIH0pKTtcbiAgY29uc3QgZGVmczogUmVjb3JkPHN0cmluZywgSnNvblNjaGVtYT4gPSB7XG4gICAgSUQ6IHsgdHlwZTogJ3N0cmluZycsIHBhdHRlcm46IElEX1BBVFRFUk4uc291cmNlIH0sIFRpY2s6IHsgdHlwZTogJ3N0cmluZycsIHBhdHRlcm46ICdeKD86MHwtWzEtOV1bMC05XXswLDM3fXxbMS05XVswLTldezAsMzd9KSQnIH0sIFJldmlzaW9uOiB7IHR5cGU6ICdzdHJpbmcnLCBwYXR0ZXJuOiBSRVZJU0lPTl9QQVRURVJOLnNvdXJjZSB9LFxuICAgIFJpY2hUZXh0OiBjb252ZXJ0KGFycihibG9jaykpLCBDdXN0b21WYWx1ZTogeyBhbnlPZjogW3sgdHlwZTogWydzdHJpbmcnLCAnbnVtYmVyJywgJ2Jvb2xlYW4nLCAnbnVsbCddIH0sIGNvbnZlcnQob2JqKHsgdHlwZTogcmVxKGVuKCdyZWYnKSksIHZhbHVlOiByZXEocmVmKCkpIH0pKSwgY29udmVydChvYmooeyB0eXBlOiByZXEoZW4oJ2RhdGUnKSksIHZhbHVlOiByZXEoeyB0eXBlOiAnZGF0ZScgfSkgfSkpXSB9LFxuICAgIFR5cGVkVmFsdWU6IHsgb25lT2Y6IFtjb252ZXJ0KG9iaih7IHR5cGU6IHJlcShlbignYm9vbGVhbicpKSwgdmFsdWU6IHJlcShib29sKSB9KSksIGNvbnZlcnQob2JqKHsgdHlwZTogcmVxKGVuKCdpbnRlZ2VyJykpLCB2YWx1ZTogcmVxKG51bSh1bmRlZmluZWQsIHVuZGVmaW5lZCwgdHJ1ZSkpIH0pKSwgY29udmVydChvYmooeyB0eXBlOiByZXEoZW4oJ2VudW0nLCAndGV4dCcpKSwgdmFsdWU6IHJlcSh0eHQoKSkgfSkpLCBjb252ZXJ0KG9iaih7IHR5cGU6IHJlcShlbigncmVmJykpLCB2YWx1ZTogcmVxKHJlZigpKSB9KSksIGNvbnZlcnQob2JqKHsgdHlwZTogcmVxKGVuKCd1bmtub3duJykpLCB2YWx1ZTogcmVxKGVuKG51bGwpKSwgcmVhc29uOiByZXEodHh0KCkpIH0pKV0gfSxcbiAgICBUaW1lU3BlYzogeyBvbmVPZjogWydpbnN0YW50JywgJ2ludGVydmFsJywgJ3VuY2VydGFpbicsICdyZWxhdGl2ZScsICd1bmtub3duJ10ubWFwKG1vZGUgPT4gY29udmVydCh0aW1lU2NoZW1hKHsgbW9kZSB9KSEpKSB9LFxuICAgIENvbmRpdGlvbjogeyBvbmVPZjogY29uZGl0aW9uYWxEZWZpbml0aW9ucyB9LCBFeHByZXNzaW9uOiB7IGFueU9mOiBbcmVmZXJlbmNlKCdDb25kaXRpb24nKSwgLi4uWyd2YWx1ZScsICd2YXJpYWJsZScsICdhZGQnLCAnc3VidHJhY3QnLCAnbXVsdGlwbHknLCAnaWYnXS5tYXAob3AgPT4gY29udmVydChleHByZXNzaW9uU2NoZW1hKHsgb3AgfSkhKSldIH0sXG4gICAgTmFtZVBvbGljeTogeyBhbnlPZjogWy4uLlsnYWxpYXMnLCAncmVwbGFjZScsICdleGNsdWRlJywgJ2Fub255bWl6ZSddLm1hcChtb2RlID0+IGNvbnZlcnQobmFtZVBvbGljeVNjaGVtYSh7IG1vZGUgfSkhKSksIGNvbnZlcnQobmFtZVBvbGljeVNjaGVtYSh7fSkhKV0gfSxcbiAgICBRdWVyeTogeyBvbmVPZjogWydhbGwnLCAnYW55JywgJ2tpbmQnLCAndGV4dCcsICdzdGF0dXMnLCAncGFydGljaXBhbnQnLCAncHJvZHVjdGlvbicsICdjaGFwdGVyJywgJ2ZvcmVzaGFkb3cnXS5tYXAob3AgPT4ge1xuICAgICAgY29uc3QgZGVmaW5pdGlvbiA9IGNvbnZlcnQocXVlcnlTY2hlbWEoeyBvcCB9KSEpOyAoZGVmaW5pdGlvbi5wcm9wZXJ0aWVzIGFzIFJlY29yZDxzdHJpbmcsIEpzb25TY2hlbWE+KS5vcCA9IHsgY29uc3Q6IG9wIH07XG4gICAgICAvLyBBanYgc3RyaWN0UmVxdWlyZWQgY2hlY2tzIHJlcXVpcmVkIGtleXMgYWdhaW5zdCBwcm9wZXJ0aWVzIGRlY2xhcmVkIGluXG4gICAgICAvLyB0aGUgc2FtZSBzdWJzY2hlbWEuIFRoZSB2YWx1ZSBjb25zdHJhaW50cyBsaXZlIG9uIHRoZSBxdWVyeSBicmFuY2gsXG4gICAgICAvLyBzbyByZXBlYXQgYW4gdW5jb25zdHJhaW5lZCBkZWNsYXJhdGlvbiBoZXJlIHNvbGVseSBmb3IgdGhhdCBjaGVjay5cbiAgICAgIGlmIChvcCA9PT0gJ2ZvcmVzaGFkb3cnKSBkZWZpbml0aW9uLmFueU9mID0gWydmb3Jlc2hhZG93SWQnLCAncmVzb2x1dGlvblBvbGljeScsICdyb2xlJywgJ3N0YWdlJ10ubWFwKGZpZWxkID0+ICh7IHByb3BlcnRpZXM6IHsgW2ZpZWxkXToge30gfSwgcmVxdWlyZWQ6IFtmaWVsZF0gfSkpO1xuICAgICAgcmV0dXJuIGRlZmluaXRpb247XG4gICAgfSkgfSxcbiAgICBDYWxlbmRhcjogY29udmVydChjYWxlbmRhciksIFJlbGF0aW9uOiBjb252ZXJ0KHJlbGF0aW9uU2NoZW1hKSwgV29ybGRSZWZlcmVuY2U6IGNvbnZlcnQod29ybGRSZWZlcmVuY2VTY2hlbWEpLCBTYXZlZFZpZXc6IGNvbnZlcnQodmlld1NjaGVtYSksXG4gICAgRW50aXR5OiB7IG9uZU9mOiBFTlRJVFlfS0lORFMubWFwKGtpbmQgPT4gcmVmZXJlbmNlKGBFbnRpdHlfJHtraW5kfWApKSB9LFxuICB9O1xuICBmb3IgKGNvbnN0IGtpbmQgb2YgRU5USVRZX0tJTkRTKSBkZWZzW2BFbnRpdHlfJHtraW5kfWBdID0gY29udmVydChlbnRpdHlTY2hlbWEoa2luZCkpO1xuICBjb25zdCBhcmJpdHJhcnlWYWx1ZSA9IHt9O1xuICBjb25zdCB2YWx1ZVNuYXBzaG90ID0geyB0eXBlOiAnb2JqZWN0JywgcHJvcGVydGllczogeyBwcmVzZW50OiB7IHR5cGU6ICdib29sZWFuJyB9LCB2YWx1ZTogYXJiaXRyYXJ5VmFsdWUgfSwgcmVxdWlyZWQ6IFsncHJlc2VudCddLCBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UgfTtcbiAgZGVmcy5BbHRlcm5hdGl2ZVBhdGNoID0geyB0eXBlOiAnb2JqZWN0JywgcHJvcGVydGllczogeyBrZXk6IHsgdHlwZTogJ3N0cmluZycsIG1pbkxlbmd0aDogMSB9LCBzY29wZTogeyBlbnVtOiBbJ3Byb2plY3QnLCAnZW50aXR5JywgJ3JlbGF0aW9uJywgJ3ByZXNlbnRhdGlvbiddIH0sIGl0ZW1JZDogcmVmZXJlbmNlKCdJRCcpLCBwYXRoOiB7IHR5cGU6ICdhcnJheScsIGl0ZW1zOiB7IHR5cGU6ICdzdHJpbmcnIH0gfSwgbGFiZWw6IHsgdHlwZTogJ3N0cmluZycgfSwgYmVmb3JlOiB2YWx1ZVNuYXBzaG90LCBhZnRlcjogdmFsdWVTbmFwc2hvdCB9LCByZXF1aXJlZDogWydrZXknLCAnc2NvcGUnLCAncGF0aCcsICdsYWJlbCcsICdiZWZvcmUnLCAnYWZ0ZXInXSwgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlIH07XG4gIGRlZnMuQWx0ZXJuYXRpdmVBcHBseVJlY2VpcHQgPSB7IHR5cGU6ICdvYmplY3QnLCBwcm9wZXJ0aWVzOiB7IGlkOiByZWZlcmVuY2UoJ0lEJyksIGNyZWF0ZWRBdDogeyB0eXBlOiAnc3RyaW5nJywgZm9ybWF0OiAnZGF0ZS10aW1lJyB9LCBhbHRlcm5hdGl2ZVZlcnNpb25JZDogcmVmZXJlbmNlKCdJRCcpLCBzb3VyY2VTbmFwc2hvdElkOiB7IGFueU9mOiBbcmVmZXJlbmNlKCdJRCcpLCB7IHR5cGU6ICdudWxsJyB9XSB9LCBzZWxlY3RlZENoYW5nZUtleXM6IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHsgdHlwZTogJ3N0cmluZycgfSwgbWluSXRlbXM6IDEsIHVuaXF1ZUl0ZW1zOiB0cnVlIH0sIGZyb21DYW5vbmljYWxSZXZpc2lvbjogcmVmZXJlbmNlKCdSZXZpc2lvbicpLCBhcHBsaWVkUmV2aXNpb246IHJlZmVyZW5jZSgnUmV2aXNpb24nKSwgcGF0Y2hlczogeyB0eXBlOiAnYXJyYXknLCBpdGVtczogcmVmZXJlbmNlKCdBbHRlcm5hdGl2ZVBhdGNoJyksIG1pbkl0ZW1zOiAxIH0gfSwgcmVxdWlyZWQ6IFsnaWQnLCAnY3JlYXRlZEF0JywgJ2FsdGVybmF0aXZlVmVyc2lvbklkJywgJ3NvdXJjZVNuYXBzaG90SWQnLCAnc2VsZWN0ZWRDaGFuZ2VLZXlzJywgJ2Zyb21DYW5vbmljYWxSZXZpc2lvbicsICdhcHBsaWVkUmV2aXNpb24nLCAncGF0Y2hlcyddLCBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UgfTtcbiAgZGVmcy5TdHJ1Y3R1cmVQbGFuID0geyB0eXBlOiAnb2JqZWN0JywgcHJvcGVydGllczogeyBjaGFwdGVySWQ6IHJlZmVyZW5jZSgnSUQnKSwgdGVtcGxhdGVJZDogeyB0eXBlOiAnc3RyaW5nJywgbWluTGVuZ3RoOiAxIH0sIGJlYXRMYWJlbHM6IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHsgdHlwZTogJ3N0cmluZycsIG1pbkxlbmd0aDogMSB9LCBtYXhJdGVtczogMTAwIH0sIGFzc2lnbm1lbnRzOiB7IHR5cGU6ICdvYmplY3QnLCBhZGRpdGlvbmFsUHJvcGVydGllczogcmVmZXJlbmNlKCdJRCcpIH0gfSwgcmVxdWlyZWQ6IFsnY2hhcHRlcklkJywgJ3RlbXBsYXRlSWQnLCAnYmVhdExhYmVscycsICdhc3NpZ25tZW50cyddLCBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UgfTtcbiAgZGVmcy5BbHRlcm5hdGl2ZVZlcnNpb24gPSB7IHR5cGU6ICdvYmplY3QnLCBwcm9wZXJ0aWVzOiB7IGlkOiByZWZlcmVuY2UoJ0lEJyksIHBhcmVudFZlcnNpb25JZDogeyBhbnlPZjogW3JlZmVyZW5jZSgnSUQnKSwgeyB0eXBlOiAnbnVsbCcgfV0gfSwgbGFiZWw6IHsgdHlwZTogJ3N0cmluZycsIG1pbkxlbmd0aDogMSB9LCBjcmVhdGVkQXQ6IHsgdHlwZTogJ3N0cmluZycsIGZvcm1hdDogJ2RhdGUtdGltZScgfSwgY29udGVudDogcmVmZXJlbmNlKCdQcm9qZWN0Q29udGVudCcpLCBjb250ZW50SGFzaDogeyB0eXBlOiAnc3RyaW5nJywgcGF0dGVybjogJ15bMC05YS1mXXs2NH0kJyB9LCBzdHJ1Y3R1cmVQbGFuOiByZWZlcmVuY2UoJ1N0cnVjdHVyZVBsYW4nKSB9LCByZXF1aXJlZDogWydpZCcsICdwYXJlbnRWZXJzaW9uSWQnLCAnbGFiZWwnLCAnY3JlYXRlZEF0JywgJ2NvbnRlbnQnLCAnY29udGVudEhhc2gnXSwgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlIH07XG4gIGRlZnMuQXV0aG9yQWx0ZXJuYXRpdmUgPSB7IHR5cGU6ICdvYmplY3QnLCBwcm9wZXJ0aWVzOiB7IGlkOiByZWZlcmVuY2UoJ0lEJyksIHByb2plY3RJZDogcmVmZXJlbmNlKCdJRCcpLCBuYW1lOiB7IHR5cGU6ICdzdHJpbmcnLCBtaW5MZW5ndGg6IDEgfSwgc3RhdHVzOiB7IGVudW06IFsnYWN0aXZlJywgJ3Byb3Zpc2lvbmFsJywgJ25lZWRzX3JldmlldycsICdyZWplY3RlZCcsICdhY2NlcHRlZCddIH0sIGJhc2VSZXZpc2lvbjogcmVmZXJlbmNlKCdSZXZpc2lvbicpLCBzb3VyY2VTbmFwc2hvdElkOiB7IGFueU9mOiBbcmVmZXJlbmNlKCdJRCcpLCB7IHR5cGU6ICdudWxsJyB9XSB9LCBiYXNlQ29udGVudDogcmVmZXJlbmNlKCdQcm9qZWN0Q29udGVudCcpLCBiYXNlQ29udGVudEhhc2g6IHsgdHlwZTogJ3N0cmluZycsIHBhdHRlcm46ICdeWzAtOWEtZl17NjR9JCcgfSwgdmVyc2lvbnM6IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHJlZmVyZW5jZSgnQWx0ZXJuYXRpdmVWZXJzaW9uJyksIG1pbkl0ZW1zOiAxLCBtYXhJdGVtczogNTAwIH0sIGhlYWRWZXJzaW9uSWQ6IHJlZmVyZW5jZSgnSUQnKSwgYXBwbHlSZWNlaXB0czogeyB0eXBlOiAnYXJyYXknLCBpdGVtczogcmVmZXJlbmNlKCdBbHRlcm5hdGl2ZUFwcGx5UmVjZWlwdCcpIH0sIGludGVncml0eUhhc2g6IHsgdHlwZTogJ3N0cmluZycsIHBhdHRlcm46ICdeWzAtOWEtZl17NjR9JCcgfSwgY3JlYXRlZEF0OiB7IHR5cGU6ICdzdHJpbmcnLCBmb3JtYXQ6ICdkYXRlLXRpbWUnIH0sIHVwZGF0ZWRBdDogeyB0eXBlOiAnc3RyaW5nJywgZm9ybWF0OiAnZGF0ZS10aW1lJyB9IH0sIHJlcXVpcmVkOiBbJ2lkJywgJ3Byb2plY3RJZCcsICduYW1lJywgJ3N0YXR1cycsICdiYXNlUmV2aXNpb24nLCAnc291cmNlU25hcHNob3RJZCcsICdiYXNlQ29udGVudCcsICdiYXNlQ29udGVudEhhc2gnLCAndmVyc2lvbnMnLCAnaGVhZFZlcnNpb25JZCcsICdhcHBseVJlY2VpcHRzJywgJ2ludGVncml0eUhhc2gnLCAnY3JlYXRlZEF0JywgJ3VwZGF0ZWRBdCddLCBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UgfTtcbiAgY29uc3QgdHJhY2VTY2hlbWEgPSBkZWZzLkVudGl0eV90cmFjZSBhcyBKc29uU2NoZW1hO1xuICB0cmFjZVNjaGVtYS5hbGxPZiA9IFt7IGlmOiB7IHByb3BlcnRpZXM6IHsgZGF0YTogeyB0eXBlOiAnb2JqZWN0JywgcHJvcGVydGllczogeyBtb2RlOiB7IGNvbnN0OiAnY2hhcHRlcnMnIH0gfSwgcmVxdWlyZWQ6IFsnbW9kZSddIH0gfSwgcmVxdWlyZWQ6IFsnZGF0YSddIH0sIHRoZW46IHsgcHJvcGVydGllczogeyBkYXRhOiB7IHR5cGU6ICdvYmplY3QnLCBwcm9wZXJ0aWVzOiB7IHJlYWRpbmdQYXRoOiB7IG5vdDogeyB0eXBlOiAnbnVsbCcgfSB9LCBzdGVwczogeyB0eXBlOiAnYXJyYXknLCBtYXhJdGVtczogMCB9IH0sIHJlcXVpcmVkOiBbJ3JlYWRpbmdQYXRoJ10gfSB9LCByZXF1aXJlZDogWydkYXRhJ10gfSwgZWxzZTogeyBwcm9wZXJ0aWVzOiB7IGRhdGE6IHsgdHlwZTogJ29iamVjdCcsIHByb3BlcnRpZXM6IHsgcmVhZGluZ1BhdGg6IHsgdHlwZTogJ251bGwnIH0gfSB9IH0sIHJlcXVpcmVkOiBbJ2RhdGEnXSB9IH1dO1xuICBjb25zdCBjb250ZW50ID0gY29udmVydChvYmooeyAuLi5wcm9qZWN0SGVhZGVyRmllbGRzLCBjYWxlbmRhcnM6IHJlcShhcnIoY2FsZW5kYXIpKSwgZW50aXRpZXM6IHJlcShhcnIocmVmKCkpKSwgcmVsYXRpb25zOiByZXEoYXJyKHJlbGF0aW9uU2NoZW1hKSksIHZpZXdzOiByZXEoYXJyKHZpZXdTY2hlbWEpKSB9KSk7XG4gIGNvbnN0IGNvbnRlbnRQcm9wZXJ0aWVzID0gY29udGVudC5wcm9wZXJ0aWVzIGFzIFJlY29yZDxzdHJpbmcsIEpzb25TY2hlbWE+OyBjb250ZW50UHJvcGVydGllcy5lbnRpdGllcyA9IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHJlZmVyZW5jZSgnRW50aXR5JyksIG1heEl0ZW1zOiAxMDBfMDAwIH07XG4gIGRlZnMuUHJvamVjdENvbnRlbnQgPSBjb250ZW50O1xuICBkZWZzLlByb2plY3RTbmFwc2hvdCA9IGNvbnZlcnQob2JqKHsgaWQ6IHJlcShpZFNjaGVtYSksIHZlcnNpb25MYWJlbDogcmVxKHR4dCgxLCAxMjgpKSwgY29udGVudEhhc2g6IHJlcSh7IHR5cGU6ICdoYXNoJyB9KSwgY3JlYXRlZEF0OiByZXEoeyB0eXBlOiAnZGF0ZXRpbWUnIH0pIH0pKTtcbiAgKGRlZnMuUHJvamVjdFNuYXBzaG90LnByb3BlcnRpZXMgYXMgUmVjb3JkPHN0cmluZywgSnNvblNjaGVtYT4pLmNvbnRlbnQgPSByZWZlcmVuY2UoJ1Byb2plY3RDb250ZW50Jyk7IChkZWZzLlByb2plY3RTbmFwc2hvdC5yZXF1aXJlZCBhcyBzdHJpbmdbXSkucHVzaCgnY29udGVudCcpO1xuICBkZWZzLkNvbnRlbnRTdGF0ZSA9IHsgLi4uY29udGVudCwgcHJvcGVydGllczogeyAuLi5jb250ZW50UHJvcGVydGllcywgc25hcHNob3RzOiB7IHR5cGU6ICdhcnJheScsIGl0ZW1zOiByZWZlcmVuY2UoJ1Byb2plY3RTbmFwc2hvdCcpIH0sIGF1dGhvckFsdGVybmF0aXZlczogeyB0eXBlOiAnYXJyYXknLCBpdGVtczogcmVmZXJlbmNlKCdBdXRob3JBbHRlcm5hdGl2ZScpLCBtYXhJdGVtczogMTAwIH0gfSwgcmVxdWlyZWQ6IFsuLi5jb250ZW50LnJlcXVpcmVkIGFzIHN0cmluZ1tdLCAnc25hcHNob3RzJ10gfTtcbiAgZGVmcy5Db21tYW5kUmVjb3JkID0gY29udmVydChvYmooeyBvcGVyYXRpb25JZDogcmVxKGlkU2NoZW1hKSwgcHJvamVjdElkOiByZXEoaWRTY2hlbWEpLCBiYXNlUmV2aXNpb246IHJlcSh7IHR5cGU6ICdyZXZpc2lvbicgfSksIHJldmlzaW9uOiByZXEoeyB0eXBlOiAncmV2aXNpb24nIH0pLCB0YXJnZXRJZHM6IHJlcShhcnIoaWRTY2hlbWEsIHRydWUpKSwgcmVhc29uOiByZXEodHh0KCkpLCBjcmVhdGVkQXQ6IHJlcSh7IHR5cGU6ICdkYXRldGltZScgfSksIGNvbXBlbnNhdGVzT3BlcmF0aW9uSWQ6IG9wdChpZFNjaGVtYSksIGlkTWFwOiBvcHQocmVjb3JkKGlkU2NoZW1hLCBpZFNjaGVtYSkpLCBpbXBvcnRPcmlnaW46IG9wdChvYmooeyBzb3VyY2VQcm9qZWN0SWQ6IHJlcShpZFNjaGVtYSksIHNvdXJjZU9wZXJhdGlvbklkOiByZXEoaWRTY2hlbWEpLCBpbXBvcnRPcGVyYXRpb25JZDogcmVxKGlkU2NoZW1hKSB9KSkgfSkpO1xuICBPYmplY3QuYXNzaWduKGRlZnMuQ29tbWFuZFJlY29yZC5wcm9wZXJ0aWVzIGFzIFJlY29yZDxzdHJpbmcsIEpzb25TY2hlbWE+LCB7IGJlZm9yZTogcmVmZXJlbmNlKCdDb250ZW50U3RhdGUnKSwgYWZ0ZXI6IHJlZmVyZW5jZSgnQ29udGVudFN0YXRlJykgfSk7IChkZWZzLkNvbW1hbmRSZWNvcmQucmVxdWlyZWQgYXMgc3RyaW5nW10pLnB1c2goJ2JlZm9yZScsICdhZnRlcicpO1xuICByZXR1cm4geyAkc2NoZW1hOiAnaHR0cHM6Ly9qc29uLXNjaGVtYS5vcmcvZHJhZnQvMjAyMC0xMi9zY2hlbWEnLCAkaWQ6IGBodHRwczovL3NoaW5hcmlva2FucmkubG9jYWwvc2NoZW1hL3Byb2plY3QtJHtGT1JNQVRfVkVSU0lPTn0uanNvbmAsIHRpdGxlOiAnU2NlbmFyaW8gcHJvamVjdCAxLjAuMCcsIGRlc2NyaXB0aW9uOiAnU3RydWN0dXJhbCBjb250cmFjdC4gdmFsaWRhdGVQcm9qZWN0IGFkZGl0aW9uYWxseSBjaGVja3MgcmVmZXJlbmNlcywgc2NvcGVzLCBjeWNsZXMsIHJhbmdlcywgVW5pY29kZSBzcGFucywgY29tcGFyaXNvbiB0eXBlcyBhbmQgZWZmZWN0IGlucHV0cy4gVVRGLTggYnl0ZSBsaW1pdHMgYW5kIFNIQS0yNTYgaW50ZWdyaXR5IHJlcXVpcmUgZXhlY3V0YWJsZSB2YWxpZGF0b3JzLicsIC4uLmNvbnRlbnQsIHByb3BlcnRpZXM6IHsgLi4uY29udGVudFByb3BlcnRpZXMsIHNuYXBzaG90czogeyB0eXBlOiAnYXJyYXknLCBpdGVtczogcmVmZXJlbmNlKCdQcm9qZWN0U25hcHNob3QnKSB9LCBoaXN0b3J5OiB7IHR5cGU6ICdhcnJheScsIGl0ZW1zOiByZWZlcmVuY2UoJ0NvbW1hbmRSZWNvcmQnKSB9LCBhdXRob3JBbHRlcm5hdGl2ZXM6IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHJlZmVyZW5jZSgnQXV0aG9yQWx0ZXJuYXRpdmUnKSwgbWF4SXRlbXM6IDEwMCB9IH0sIHJlcXVpcmVkOiBbLi4uY29udGVudC5yZXF1aXJlZCBhcyBzdHJpbmdbXSwgJ3NuYXBzaG90cycsICdoaXN0b3J5J10sICRkZWZzOiBkZWZzIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLG1CQUFtQixRQUFRLGdCQUFnQjtBQUNwRCxTQUFTQyxtQkFBbUIsRUFBRUMscUJBQXFCLFFBQVEsU0FBUztBQUNwRSxTQUFTQyxjQUFjLFFBQVEsU0FBUztBQUV4QyxTQUFTQyxrQkFBa0IsRUFBRUMsWUFBWSxFQUFFQyxNQUFNLEVBQUVDLFNBQVMsRUFBRUMsZ0JBQWdCLEVBQUVDLGtCQUFrQixFQUFFQyxzQkFBc0IsUUFBUSxRQUFRO0FBQzFJLFNBQVNDLDJCQUEyQixFQUFFQywwQkFBMEIsUUFBUSxhQUFhO0FBRXJGLE9BQU8sTUFBTUMsV0FBdUMsR0FBRztFQUNyREMsU0FBUyxFQUFFLElBQUk7RUFBRUMsS0FBSyxFQUFFLE1BQU07RUFBRUMsS0FBSyxFQUFFLEtBQUs7RUFBRUMsS0FBSyxFQUFFLElBQUk7RUFBRUMsSUFBSSxFQUFFLElBQUk7RUFBRUMsSUFBSSxFQUFFLElBQUk7RUFBRUMsT0FBTyxFQUFFLEdBQUc7RUFBRUMsS0FBSyxFQUFFLElBQUk7RUFBRUMsSUFBSSxFQUFFLElBQUk7RUFDeEhDLFNBQVMsRUFBRSxPQUFPO0VBQUVDLFNBQVMsRUFBRSxLQUFLO0VBQUVDLFVBQVUsRUFBRSxLQUFLO0VBQUVDLGFBQWEsRUFBRSxJQUFJO0VBQUVDLEtBQUssRUFBRSxNQUFNO0VBQUVDLElBQUksRUFBRSxJQUFJO0VBQUVDLFFBQVEsRUFBRSxNQUFNO0VBQ3pIQyxNQUFNLEVBQUUsSUFBSTtFQUFFQyxTQUFTLEVBQUUsT0FBTztFQUFFQyxVQUFVLEVBQUUsSUFBSTtFQUFFQyxVQUFVLEVBQUUsU0FBUztFQUFFQyxVQUFVLEVBQUUsT0FBTztFQUFFQyxLQUFLLEVBQUUsTUFBTTtFQUFFQyxVQUFVLEVBQUUsTUFBTTtFQUNqSUMsTUFBTSxFQUFFLE9BQU87RUFBRUMsR0FBRyxFQUFFLElBQUk7RUFBRUMsZ0JBQWdCLEVBQUUsTUFBTTtFQUFFQyxZQUFZLEVBQUUsSUFBSTtFQUFFQyxTQUFTLEVBQUUsSUFBSTtFQUFFQyxXQUFXLEVBQUUsSUFBSTtFQUFFQyxHQUFHLEVBQUUsSUFBSTtFQUFFQyxZQUFZLEVBQUUsTUFBTTtFQUM3SUMsUUFBUSxFQUFFLElBQUk7RUFBRUMsVUFBVSxFQUFFLElBQUk7RUFBRUMsTUFBTSxFQUFFLE1BQU07RUFBRUMsY0FBYyxFQUFFLElBQUk7RUFBRUMsUUFBUSxFQUFFLE1BQU07RUFBRUMsYUFBYSxFQUFFLE9BQU87RUFBRUMsZUFBZSxFQUFFLE9BQU87RUFDMUlDLGFBQWEsRUFBRSxLQUFLO0VBQUVDLFVBQVUsRUFBRSxJQUFJO0VBQUVDLGlCQUFpQixFQUFFLE1BQU07RUFBRUMsUUFBUSxFQUFFLEtBQUs7RUFBRUMsa0JBQWtCLEVBQUU7QUFDMUcsQ0FBQztBQUNELE9BQU8sTUFBTUMsWUFBWSxHQUFHQyxNQUFNLENBQUNDLElBQUksQ0FBQzlDLFdBQVcsQ0FBaUI7QUFDcEUsT0FBTyxNQUFNK0MsUUFBUSxHQUFHLENBQUMsV0FBVyxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsVUFBVSxFQUFFLFdBQVcsQ0FBVTtBQUN0RyxPQUFPLE1BQU1DLE1BQU0sR0FBRyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxhQUFhLENBQVU7QUFDdEYsT0FBTyxNQUFNQyxjQUF3QyxHQUFHLENBQ3REO0VBQUVDLEdBQUcsRUFBRSxPQUFPO0VBQUVDLEtBQUssRUFBRSxJQUFJO0VBQUVDLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQztFQUFFQyxPQUFPLEVBQUUsQ0FBQyxXQUFXLENBQUM7RUFBRUMsU0FBUyxFQUFFLEtBQUs7RUFBRUMsY0FBYyxFQUFFO0FBQU0sQ0FBQyxFQUN4SDtFQUFFTCxHQUFHLEVBQUUsUUFBUTtFQUFFQyxLQUFLLEVBQUUsSUFBSTtFQUFFQyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUM7RUFBRUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDO0VBQUVDLFNBQVMsRUFBRSxLQUFLO0VBQUVDLGNBQWMsRUFBRTtBQUFNLENBQUMsRUFDakg7RUFBRUwsR0FBRyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLElBQUk7RUFBRUMsU0FBUyxFQUFFUixZQUFZO0VBQUVTLE9BQU8sRUFBRVQsWUFBWTtFQUFFVSxTQUFTLEVBQUUsS0FBSztFQUFFQyxjQUFjLEVBQUU7QUFBTSxDQUFDLEVBQ3pIO0VBQUVMLEdBQUcsRUFBRSxtQkFBbUI7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRUMsU0FBUyxFQUFFLENBQUMsWUFBWSxDQUFDO0VBQUVDLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQztFQUFFQyxTQUFTLEVBQUUsS0FBSztFQUFFQyxjQUFjLEVBQUU7QUFBTSxDQUFDLEVBQzNJO0VBQUVMLEdBQUcsRUFBRSxXQUFXO0VBQUVDLEtBQUssRUFBRSxJQUFJO0VBQUVDLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQztFQUFFQyxPQUFPLEVBQUUsQ0FBQyxXQUFXLENBQUM7RUFBRUMsU0FBUyxFQUFFLEtBQUs7RUFBRUMsY0FBYyxFQUFFO0FBQU0sQ0FBQyxFQUM1SDtFQUFFTCxHQUFHLEVBQUUsa0JBQWtCO0VBQUVDLEtBQUssRUFBRSxRQUFRO0VBQUVDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQztFQUFFQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUM7RUFBRUMsU0FBUyxFQUFFLEtBQUs7RUFBRUMsY0FBYyxFQUFFO0FBQU0sQ0FBQyxFQUMvSDtFQUFFTCxHQUFHLEVBQUUsY0FBYztFQUFFQyxLQUFLLEVBQUUsUUFBUTtFQUFFQyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUM7RUFBRUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDO0VBQUVDLFNBQVMsRUFBRSxLQUFLO0VBQUVDLGNBQWMsRUFBRTtBQUFNLENBQUMsRUFDM0g7RUFBRUwsR0FBRyxFQUFFLFdBQVc7RUFBRUMsS0FBSyxFQUFFLElBQUk7RUFBRUMsU0FBUyxFQUFFLENBQUMsV0FBVyxDQUFDO0VBQUVDLE9BQU8sRUFBRSxDQUFDLFdBQVcsQ0FBQztFQUFFQyxTQUFTLEVBQUUsS0FBSztFQUFFQyxjQUFjLEVBQUU7QUFBTSxDQUFDLEVBQzVIO0VBQUVMLEdBQUcsRUFBRSxXQUFXO0VBQUVDLEtBQUssRUFBRSxJQUFJO0VBQUVDLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQztFQUFFQyxPQUFPLEVBQUUsQ0FBQyxXQUFXLENBQUM7RUFBRUMsU0FBUyxFQUFFLEtBQUs7RUFBRUMsY0FBYyxFQUFFO0FBQU0sQ0FBQyxFQUM1SDtFQUFFTCxHQUFHLEVBQUUsU0FBUztFQUFFQyxLQUFLLEVBQUUsSUFBSTtFQUFFQyxTQUFTLEVBQUVSLFlBQVk7RUFBRVMsT0FBTyxFQUFFVCxZQUFZO0VBQUVVLFNBQVMsRUFBRSxLQUFLO0VBQUVDLGNBQWMsRUFBRTtBQUFLLENBQUMsRUFDdkg7RUFBRUwsR0FBRyxFQUFFLFdBQVc7RUFBRUMsS0FBSyxFQUFFLElBQUk7RUFBRUMsU0FBUyxFQUFFUixZQUFZO0VBQUVTLE9BQU8sRUFBRVQsWUFBWTtFQUFFVSxTQUFTLEVBQUUsSUFBSTtFQUFFQyxjQUFjLEVBQUU7QUFBTSxDQUFDLENBQzFIO0FBQ0QsT0FBTyxNQUFNQyxlQUFlLEdBQUdYLE1BQU0sQ0FBQ1ksV0FBVyxDQUFDUixjQUFjLENBQUNuQixHQUFHLENBQUM0QixJQUFJLElBQUksQ0FBQ0EsSUFBSSxDQUFDUixHQUFHLEVBQUVRLElBQUksQ0FBQ1AsS0FBSyxDQUFDLENBQUMsQ0FBMkI7QUFDL0gsT0FBTyxNQUFNUSxVQUFVLEdBQUcsZ0VBQWdFO0FBQzFGLE9BQU8sTUFBTUMsZ0JBQWdCLEdBQUcscUJBQXFCO0FBQ3JELE9BQU8sTUFBTUMsYUFBYSxHQUFHQSxDQUFBLE1BQWlCO0VBQUVDLFVBQVUsRUFBRSxJQUFJO0VBQUVDLGNBQWMsRUFBRSxJQUFJO0VBQUVDLGtCQUFrQixFQUFFO0FBQUssQ0FBQyxDQUFDO0FBQ25ILE9BQU8sTUFBTUMsS0FBSyxHQUFHQSxDQUFBLEtBQVVDLE1BQU0sQ0FBQ0MsVUFBVSxDQUFDLENBQUM7QUFDbEQsT0FBTyxTQUFTQyxjQUFjQSxDQUFDQyxJQUFZLEVBQVk7RUFBRSxPQUFPQSxJQUFJLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBR0EsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUN4QyxHQUFHLENBQUN5QyxJQUFJLEtBQUs7SUFBRUMsRUFBRSxFQUFFUCxLQUFLLENBQUMsQ0FBQztJQUFFUSxJQUFJLEVBQUUsV0FBVztJQUFFSixJQUFJLEVBQUVFO0VBQUssQ0FBQyxDQUFDLENBQUM7QUFBRTtBQUNuSyxPQUFPLFNBQVNHLG1CQUFtQkEsQ0FBQ0wsSUFBaUMsRUFBVTtFQUFFLE9BQU8sQ0FBQ0EsSUFBSSxhQUFKQSxJQUFJLGNBQUpBLElBQUksR0FBSSxFQUFFLEVBQUV2QyxHQUFHLENBQUM2QyxLQUFLLElBQUlBLEtBQUssQ0FBQ04sSUFBSSxDQUFDLENBQUNPLElBQUksQ0FBQyxJQUFJLENBQUM7QUFBRTtBQUMxSSxPQUFPLFNBQVNDLFNBQVNBLENBQW9DQyxPQUFzQyxFQUFFTixFQUFNLEVBQXlCO0VBQUUsT0FBT00sT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsTUFBTSxJQUFJQSxNQUFNLENBQUNULEVBQUUsS0FBS0EsRUFBRSxJQUFJLENBQUNTLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDO0FBQTJCO0FBQzlPLE9BQU8sU0FBU0MsaUJBQWlCQSxDQUF1QkwsT0FBc0MsRUFBRUwsSUFBTyxFQUFlO0VBQUUsT0FBT0ssT0FBTyxDQUFDQyxRQUFRLENBQUNLLE1BQU0sQ0FBQ0gsTUFBTSxJQUFJQSxNQUFNLENBQUNSLElBQUksS0FBS0EsSUFBSSxJQUFJLENBQUNRLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDO0FBQWlCO0FBQzVOLE9BQU8sU0FBU0csV0FBV0EsQ0FBdUJaLElBQU8sRUFBb0I7RUFDM0U7RUFDQSxNQUFNYSxPQUFtQixHQUFHO0lBQUU1QixJQUFJLEVBQUUsU0FBUztJQUFFNkIsS0FBSyxFQUFFLElBQUk7SUFBRUMsTUFBTSxFQUFFO0VBQU0sQ0FBQztFQUMzRSxNQUFNQyxJQUFpQyxHQUFHO0lBQ3hDeEYsU0FBUyxFQUFFO01BQUV5RixPQUFPLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxJQUFJLEVBQUUsRUFBRTtNQUFFQyxXQUFXLEVBQUUsRUFBRTtNQUFFQyxLQUFLLEVBQUUsRUFBRTtNQUFFQyxVQUFVLEVBQUU7SUFBRyxDQUFDO0lBQzFHOUYsS0FBSyxFQUFFO01BQUUrRixTQUFTLEVBQUUsU0FBUztNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxRQUFRLEVBQUUsSUFBSTtNQUFFUCxPQUFPLEVBQUU7SUFBRyxDQUFDO0lBQ3pFekYsS0FBSyxFQUFFO01BQUV5RixPQUFPLEVBQUUsRUFBRTtNQUFFUSxJQUFJLEVBQUU7UUFBRUMsSUFBSSxFQUFFLFNBQVM7UUFBRWIsTUFBTSxFQUFFO01BQUcsQ0FBQztNQUFFYyxRQUFRLEVBQUUsUUFBUTtNQUFFQyxZQUFZLEVBQUUsRUFBRTtNQUFFQyxVQUFVLEVBQUUsSUFBSTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFWCxXQUFXLEVBQUUsRUFBRTtNQUFFWSxXQUFXLEVBQUU7SUFBRyxDQUFDO0lBQ3BLdEcsS0FBSyxFQUFFO01BQUUrRixRQUFRLEVBQUUsSUFBSTtNQUFFVCxPQUFPLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFRSxJQUFJLEVBQUUsRUFBRTtNQUFFYyxNQUFNLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUU7SUFBRyxDQUFDO0lBQ3RGdkcsSUFBSSxFQUFFO01BQUV3RyxRQUFRLEVBQUUsTUFBTTtNQUFFQyxNQUFNLEVBQUUsSUFBSTtNQUFFakIsSUFBSSxFQUFFLEVBQUU7TUFBRWtCLFVBQVUsRUFBRSxJQUFJO01BQUVILE9BQU8sRUFBRTtJQUFHLENBQUM7SUFDakZ0RyxJQUFJLEVBQUU7TUFBRXVGLElBQUksRUFBRSxFQUFFO01BQUVtQixhQUFhLEVBQUUsRUFBRTtNQUFFQyxjQUFjLEVBQUUsRUFBRTtNQUFFQyxZQUFZLEVBQUU7SUFBSyxDQUFDO0lBQzdFM0csT0FBTyxFQUFFO01BQUU0RyxRQUFRLEVBQUUsRUFBRTtNQUFFdkIsT0FBTyxFQUFFLEVBQUU7TUFBRUUsV0FBVyxFQUFFLEVBQUU7TUFBRXNCLGFBQWEsRUFBRTtJQUFHLENBQUM7SUFDMUU1RyxLQUFLLEVBQUU7TUFBRW9GLE9BQU8sRUFBRSxFQUFFO01BQUVDLElBQUksRUFBRSxFQUFFO01BQUVDLFdBQVcsRUFBRSxFQUFFO01BQUV1QixRQUFRLEVBQUUsRUFBRTtNQUFFQyxTQUFTLEVBQUUsSUFBSTtNQUFFQyxTQUFTLEVBQUUsRUFBRTtNQUFFQyxLQUFLLEVBQUUsSUFBSTtNQUFFekIsS0FBSyxFQUFFLEVBQUU7TUFBRTBCLFNBQVMsRUFBRSxFQUFFO01BQUVDLE9BQU8sRUFBRSxFQUFFO01BQUVDLGNBQWMsRUFBRSxFQUFFO01BQUVDLE9BQU8sRUFBRSxJQUFJO01BQUVDLFVBQVUsRUFBRSxJQUFJO01BQUVDLFFBQVEsRUFBRTtJQUFHLENBQUM7SUFDdE5ySCxJQUFJLEVBQUU7TUFBRXNILE9BQU8sRUFBRSxJQUFJO01BQUVDLFdBQVcsRUFBRSxFQUFFO01BQUVwQixPQUFPLEVBQUUsRUFBRTtNQUFFcUIsZ0JBQWdCLEVBQUUsRUFBRTtNQUFFQyxRQUFRLEVBQUVyRSxhQUFhLENBQUM7SUFBRSxDQUFDO0lBQ3RHbkQsU0FBUyxFQUFFO01BQUV5SCxRQUFRLEVBQUUsUUFBUTtNQUFFQyxPQUFPLEVBQUUsSUFBSTtNQUFFQyxZQUFZLEVBQUUsSUFBSTtNQUFFQyxjQUFjLEVBQUUsRUFBRTtNQUFFQyxJQUFJLEVBQUU7UUFBRUMsRUFBRSxFQUFFLFVBQVU7UUFBRWpELEtBQUssRUFBRTtNQUFLLENBQUM7TUFBRWtELGVBQWUsRUFBRSxlQUFlO01BQUVDLFVBQVUsRUFBRTtJQUFLLENBQUM7SUFDbkwvSCxTQUFTLEVBQUU7TUFBRWdJLE1BQU0sRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRTtRQUFFQyxVQUFVLEVBQUU7VUFBRTFGLEtBQUssRUFBRSxFQUFFO1VBQUVxQyxNQUFNLEVBQUU7UUFBTTtNQUFFLENBQUM7TUFBRXNELFFBQVEsRUFBRSxRQUFRO01BQUUzRixLQUFLLEVBQUUsRUFBRTtNQUFFNEYsU0FBUyxFQUFFO1FBQUVQLEVBQUUsRUFBRSxVQUFVO1FBQUVqRCxLQUFLLEVBQUU7TUFBSyxDQUFDO01BQUV5RCxTQUFTLEVBQUUsRUFBRTtNQUFFQyxRQUFRLEVBQUUsQ0FBQztNQUFFQyxZQUFZLEVBQUU7SUFBSyxDQUFDO0lBQzFNdEksVUFBVSxFQUFFO01BQUV1SSxPQUFPLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxRQUFRLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxhQUFhLEVBQUUsSUFBSTtNQUFFQyxVQUFVLEVBQUU7SUFBRyxDQUFDO0lBQ3hHM0ksYUFBYSxFQUFFO01BQUV3RCxJQUFJLEVBQUUsRUFBRTtNQUFFb0YsU0FBUyxFQUFFLElBQUk7TUFBRUMsWUFBWSxFQUFFLElBQUk7TUFBRUMsTUFBTSxFQUFFLEVBQUU7TUFBRUMsYUFBYSxFQUFFO0lBQUcsQ0FBQztJQUMvRjlJLEtBQUssRUFBRTtNQUFFb0MsR0FBRyxFQUFFLEVBQUU7TUFBRTJHLGVBQWUsRUFBRSxJQUFJO01BQUU3QixXQUFXLEVBQUUsRUFBRTtNQUFFOEIsT0FBTyxFQUFFLEVBQUU7TUFBRUMsZUFBZSxFQUFFLEVBQUU7TUFBRUMsZUFBZSxFQUFFO0lBQUcsQ0FBQztJQUNqSGpKLElBQUksRUFBRTtNQUFFOEUsSUFBSSxFQUFFLEVBQUU7TUFBRW9FLFlBQVksRUFBRSxFQUFFO01BQUVDLFNBQVMsRUFBRSxFQUFFO01BQUV4RSxPQUFPLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUU7SUFBRyxDQUFDO0lBQzdFM0UsUUFBUSxFQUFFO01BQUVrQyxHQUFHLEVBQUUsRUFBRTtNQUFFaUgsU0FBUyxFQUFFLFNBQVM7TUFBRUMsS0FBSyxFQUFFLEtBQUs7TUFBRUMsT0FBTyxFQUFFL0UsT0FBTztNQUFFZ0YsT0FBTyxFQUFFO1FBQUVDLE1BQU0sRUFBRSxDQUFDLEtBQUssRUFBRSxJQUFJO01BQUUsQ0FBQztNQUFFdkMsV0FBVyxFQUFFLEVBQUU7TUFBRUQsT0FBTyxFQUFFLElBQUk7TUFBRXlDLGtCQUFrQixFQUFFLElBQUk7TUFBRUMsVUFBVSxFQUFFLEVBQUU7TUFBRVYsZUFBZSxFQUFFLEVBQUU7TUFBRVcsbUJBQW1CLEVBQUU7SUFBTSxDQUFDO0lBQzFPekosTUFBTSxFQUFFO01BQUUwSixTQUFTLEVBQUUsS0FBSztNQUFFQyxRQUFRLEVBQUUsSUFBSTtNQUFFckYsS0FBSyxFQUFFRCxPQUFPO01BQUV5RCxTQUFTLEVBQUU7UUFBRVAsRUFBRSxFQUFFLFVBQVU7UUFBRWpELEtBQUssRUFBRTtNQUFLLENBQUM7TUFBRXNGLFVBQVUsRUFBRSxJQUFJO01BQUVyRixNQUFNLEVBQUU7SUFBRyxDQUFDO0lBQ3RJdEUsU0FBUyxFQUFFO01BQUU0SixTQUFTLEVBQUUsSUFBSTtNQUFFQyxTQUFTLEVBQUUsRUFBRTtNQUFFeEYsS0FBSyxFQUFFRCxPQUFPO01BQUUwRixTQUFTLEVBQUUsY0FBYztNQUFFQyxRQUFRLEVBQUUsSUFBSTtNQUFFZixTQUFTLEVBQUUsRUFBRTtNQUFFZ0IsZ0JBQWdCLEVBQUUsSUFBSTtNQUFFaEQsUUFBUSxFQUFFckUsYUFBYSxDQUFDLENBQUM7TUFBRTJCLE1BQU0sRUFBRTtJQUFHLENBQUM7SUFDdExyRSxVQUFVLEVBQUU7TUFBRWdLLFFBQVEsRUFBRSxFQUFFO01BQUVDLE1BQU0sRUFBRSxFQUFFO01BQUVDLGdCQUFnQixFQUFFLFdBQVc7TUFBRUMsaUJBQWlCLEVBQUUsRUFBRTtNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxTQUFTLEVBQUUsRUFBRTtNQUFFQyxZQUFZLEVBQUUsRUFBRTtNQUFFQyxRQUFRLEVBQUUsSUFBSTtNQUFFQyxVQUFVLEVBQUU7SUFBRyxDQUFDO0lBQzVLdkssVUFBVSxFQUFFO01BQUV3SyxZQUFZLEVBQUUsSUFBSTtNQUFFQyxNQUFNLEVBQUU7UUFBRUMsUUFBUSxFQUFFO01BQUssQ0FBQztNQUFFQyxLQUFLLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFakQsU0FBUyxFQUFFO1FBQUVQLEVBQUUsRUFBRSxVQUFVO1FBQUVqRCxLQUFLLEVBQUU7TUFBSyxDQUFDO01BQUUwRyxnQkFBZ0IsRUFBRSxFQUFFO01BQUVDLFdBQVcsRUFBRTtJQUFLLENBQUM7SUFDaEw3SyxVQUFVLEVBQUU7TUFBRThLLGdCQUFnQixFQUFFLElBQUk7TUFBRUMsWUFBWSxFQUFFQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7TUFBRUMsTUFBTSxFQUFFLFNBQVM7TUFBRUMsT0FBTyxFQUFFO0lBQUssQ0FBQztJQUM3R2pMLEtBQUssRUFBRTtNQUFFNkssZ0JBQWdCLEVBQUUsSUFBSTtNQUFFSyxpQkFBaUIsRUFBRSxJQUFJO01BQUVDLEtBQUssRUFBRSxFQUFFO01BQUVDLElBQUksRUFBRSxFQUFFO01BQUVDLGFBQWEsRUFBRSxPQUFPO01BQUVDLFlBQVksRUFBRTtJQUFPLENBQUM7SUFDN0hyTCxVQUFVLEVBQUU7TUFBRXNMLFNBQVMsRUFBRSxFQUFFO01BQUVDLFdBQVcsRUFBRSxFQUFFO01BQUVDLFFBQVEsRUFBRSxDQUFDO01BQUVDLFNBQVMsRUFBRSxFQUFFO01BQUVDLFdBQVcsRUFBRSxFQUFFO01BQUVsQixLQUFLLEVBQUUsV0FBVztNQUFFbUIsZUFBZSxFQUFFO0lBQUcsQ0FBQztJQUNwSTFMLE1BQU0sRUFBRTtNQUFFMkwsVUFBVSxFQUFFLEtBQUs7TUFBRUMsT0FBTyxFQUFFLEVBQUU7TUFBRUMsVUFBVSxFQUFFLElBQUk7TUFBRUMsZUFBZSxFQUFFLEVBQUU7TUFBRUMsY0FBYyxFQUFFLEVBQUU7TUFBRUMsWUFBWSxFQUFFLElBQUk7TUFBRUMscUJBQXFCLEVBQUU7SUFBTSxDQUFDO0lBQ3ZKaE0sR0FBRyxFQUFFO01BQUVvSyxNQUFNLEVBQUU7UUFBRUMsUUFBUSxFQUFFO01BQUssQ0FBQztNQUFFNEIsT0FBTyxFQUFFLEVBQUU7TUFBRUYsWUFBWSxFQUFFLElBQUk7TUFBRS9ELFNBQVMsRUFBRSxJQUFJO01BQUVrRSxVQUFVLEVBQUUsRUFBRTtNQUFFQyxNQUFNLEVBQUUsSUFBSTtNQUFFQyxNQUFNLEVBQUUsSUFBSTtNQUFFQyxTQUFTLEVBQUUsSUFBSTtNQUFFL0IsS0FBSyxFQUFFO0lBQUcsQ0FBQztJQUM3SnJLLGdCQUFnQixFQUFFO01BQUVtSyxNQUFNLEVBQUU7UUFBRUMsUUFBUSxFQUFFO01BQUssQ0FBQztNQUFFaUMsWUFBWSxFQUFFLENBQUM7TUFBRUMsVUFBVSxFQUFFLElBQUk7TUFBRUMsZ0JBQWdCLEVBQUUsSUFBSTtNQUFFQyxZQUFZLEVBQUUsSUFBSTtNQUFFdkUsTUFBTSxFQUFFLEVBQUU7TUFBRXdFLE9BQU8sRUFBRTtJQUFHLENBQUM7SUFDeEp4TSxZQUFZLEVBQUU7TUFBRXlNLFlBQVksRUFBRSxJQUFJO01BQUVDLFFBQVEsRUFBRSxFQUFFO01BQUVDLFVBQVUsRUFBRSxFQUFFO01BQUVqSyxJQUFJLEVBQUUsRUFBRTtNQUFFMEgsS0FBSyxFQUFFLE9BQU87TUFBRXdDLFVBQVUsRUFBRSxJQUFJO01BQUVDLFlBQVksRUFBRTtJQUFHLENBQUM7SUFDaEk1TSxTQUFTLEVBQUU7TUFBRXdNLFlBQVksRUFBRSxJQUFJO01BQUVDLFFBQVEsRUFBRSxFQUFFO01BQUVDLFVBQVUsRUFBRSxFQUFFO01BQUVHLGFBQWEsRUFBRSxJQUFJO01BQUVqQixZQUFZLEVBQUUsSUFBSTtNQUFFa0IsS0FBSyxFQUFFLEVBQUU7TUFBRTNDLEtBQUssRUFBRSxTQUFTO01BQUV3QyxVQUFVLEVBQUU7SUFBSyxDQUFDO0lBQ3ZKMU0sV0FBVyxFQUFFO01BQUU4TSxTQUFTLEVBQUUsRUFBRTtNQUFFakosT0FBTyxFQUFFLEVBQUU7TUFBRWtKLFFBQVEsRUFBRSxFQUFFO01BQUVQLFFBQVEsRUFBRSxJQUFJO01BQUVRLFVBQVUsRUFBRSxFQUFFO01BQUUzRyxRQUFRLEVBQUVyRSxhQUFhLENBQUMsQ0FBQztNQUFFOEgsVUFBVSxFQUFFLEVBQUU7TUFBRW1ELFlBQVksRUFBRTtJQUFLLENBQUM7SUFDeEpoTixHQUFHLEVBQUU7TUFBRWlOLE9BQU8sRUFBRSxJQUFJO01BQUVDLGdCQUFnQixFQUFFLFlBQVk7TUFBRXhCLFlBQVksRUFBRSxJQUFJO01BQUV5QixXQUFXLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUU7SUFBRyxDQUFDO0lBQ3ZHbk4sWUFBWSxFQUFFO01BQUVvTixXQUFXLEVBQUUsSUFBSTtNQUFFQyxTQUFTLEVBQUUsSUFBSTtNQUFFQyxTQUFTLEVBQUUsU0FBUztNQUFFQyxNQUFNLEVBQUUsRUFBRTtNQUFFQyxZQUFZLEVBQUUsSUFBSTtNQUFFQyxZQUFZLEVBQUUsSUFBSTtNQUFFQyxRQUFRLEVBQUUsRUFBRTtNQUFFdkgsUUFBUSxFQUFFckUsYUFBYSxDQUFDO0lBQUUsQ0FBQztJQUN2SzdCLFFBQVEsRUFBRTtNQUFFME4sVUFBVSxFQUFFLFdBQVc7TUFBRUMsTUFBTSxFQUFFLEVBQUU7TUFBRTNILFdBQVcsRUFBRSxFQUFFO01BQUU0SCxPQUFPLEVBQUUsR0FBRztNQUFFQyxRQUFRLEVBQUUsQ0FBQztJQUFFLENBQUM7SUFDOUY1TixVQUFVLEVBQUU7TUFBRW9FLElBQUksRUFBRSxPQUFPO01BQUV5SixTQUFTLEVBQUUsRUFBRTtNQUFFQyxLQUFLLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUU7UUFBRUMsS0FBSyxFQUFFLE1BQU07UUFBRVosU0FBUyxFQUFFO01BQU07SUFBRSxDQUFDO0lBQ3BHbk4sTUFBTSxFQUFFO01BQUVnTyxNQUFNLEVBQUUsSUFBSTtNQUFFQyxlQUFlLEVBQUUsSUFBSTtNQUFFdEssSUFBSSxFQUFFLEVBQUU7TUFBRWtHLEtBQUssRUFBRSxNQUFNO01BQUVxRSxVQUFVLEVBQUUsSUFBSTtNQUFFQyxVQUFVLEVBQUUsRUFBRTtNQUFFQyxVQUFVLEVBQUU7SUFBRyxDQUFDO0lBQzFIbk8sY0FBYyxFQUFFO01BQUVvTyxjQUFjLEVBQUUsRUFBRTtNQUFFQyxVQUFVLEVBQUUsRUFBRTtNQUFFQyxLQUFLLEVBQUUsRUFBRTtNQUFFQyxJQUFJLEVBQUUsRUFBRTtNQUFFdEcsS0FBSyxFQUFFLEVBQUU7TUFBRXVHLGNBQWMsRUFBRSxFQUFFO01BQUVDLFdBQVcsRUFBRTtJQUFHLENBQUM7SUFDM0h4TyxRQUFRLEVBQUU7TUFBRXlPLE9BQU8sRUFBRSxFQUFFO01BQUVyTCxNQUFNLEVBQUUsRUFBRTtNQUFFMkssZUFBZSxFQUFFLElBQUk7TUFBRVcsT0FBTyxFQUFFLFVBQVU7TUFBRTdILFFBQVEsRUFBRSxFQUFFO01BQUU4SCxjQUFjLEVBQUUsRUFBRTtNQUFFQyxTQUFTLEVBQUU7SUFBRyxDQUFDO0lBQ2xJM08sYUFBYSxFQUFFO01BQUUrRixPQUFPLEVBQUUsSUFBSTtNQUFFNkksTUFBTSxFQUFFLEVBQUU7TUFBRUMsUUFBUSxFQUFFLEVBQUU7TUFBRUMsUUFBUSxFQUFFLEVBQUU7TUFBRUMsTUFBTSxFQUFFLElBQUk7TUFBRUMsT0FBTyxFQUFFLElBQUk7TUFBRUMsT0FBTyxFQUFFLEVBQUU7TUFBRUMscUJBQXFCLEVBQUU7SUFBRyxDQUFDO0lBQzdJalAsZUFBZSxFQUFFO01BQUVrUCxTQUFTLEVBQUUsRUFBRTtNQUFFekYsS0FBSyxFQUFFLFNBQVM7TUFBRTBGLFFBQVEsRUFBRSxNQUFNO01BQUVyQixVQUFVLEVBQUUsSUFBSTtNQUFFMUUsUUFBUSxFQUFFLElBQUk7TUFBRWdHLFNBQVMsRUFBRSxFQUFFO01BQUVDLFFBQVEsRUFBRSxJQUFJO01BQUVDLGNBQWMsRUFBRTtJQUFHLENBQUM7SUFDM0pyUCxhQUFhLEVBQUU7TUFBRXNQLE1BQU0sRUFBRSxPQUFPO01BQUVDLGNBQWMsRUFBRSxJQUFJO01BQUVqTSxJQUFJLEVBQUUsRUFBRTtNQUFFa00sU0FBUyxFQUFFLElBQUk7TUFBRUMsbUJBQW1CLEVBQUUsSUFBSTtNQUFFOUgsU0FBUyxFQUFFLEVBQUU7TUFBRStILFdBQVcsRUFBRTtJQUFNLENBQUM7SUFDakp6UCxVQUFVLEVBQUU7TUFBRTBQLFdBQVcsRUFBRSxJQUFJO01BQUVoSyxRQUFRLEVBQUVyRSxhQUFhLENBQUMsQ0FBQztNQUFFc08sV0FBVyxFQUFFLEVBQUU7TUFBRUMsVUFBVSxFQUFFLEVBQUU7TUFBRUMsUUFBUSxFQUFFLEVBQUU7TUFBRUMsUUFBUSxFQUFFLEVBQUU7TUFBRTNHLFVBQVUsRUFBRTtJQUFHLENBQUM7SUFDeklsSixpQkFBaUIsRUFBRTtNQUFFUyxHQUFHLEVBQUUsRUFBRTtNQUFFcVAsS0FBSyxFQUFFLE1BQU07TUFBRUMsU0FBUyxFQUFFLFNBQVM7TUFBRUMsVUFBVSxFQUFFLFNBQVM7TUFBRUMsYUFBYSxFQUFFLFNBQVM7TUFBRTFLLFdBQVcsRUFBRSxFQUFFO01BQUUySyxVQUFVLEVBQUUsRUFBRTtNQUFFQyxpQkFBaUIsRUFBRSxFQUFFO01BQUVoRCxPQUFPLEVBQUU7SUFBUSxDQUFDO0lBQzlMbE4sUUFBUSxFQUFFO01BQUVtUSxZQUFZLEVBQUUsRUFBRTtNQUFFL0YsV0FBVyxFQUFFLEVBQUU7TUFBRWdHLFNBQVMsRUFBRSxJQUFJO01BQUVDLGdCQUFnQixFQUFFLEVBQUU7TUFBRUMsVUFBVSxFQUFFLElBQUk7TUFBRUMseUJBQXlCLEVBQUU7SUFBRyxDQUFDO0lBQ3ZJdFEsa0JBQWtCLEVBQUU7TUFBRXVRLFFBQVEsRUFBRSxFQUFFO01BQUVDLFdBQVcsRUFBRSxFQUFFO01BQUVDLFVBQVUsRUFBRTtRQUFFL00sSUFBSSxFQUFFO01BQVUsQ0FBQztNQUFFZ04sWUFBWSxFQUFFLEVBQUU7TUFBRUMsY0FBYyxFQUFFLENBQUMsYUFBYSxDQUFDO01BQUVDLFVBQVUsRUFBRSxJQUFJO01BQUVDLGtCQUFrQixFQUFFLEtBQUs7TUFBRUMsV0FBVyxFQUFFLEVBQUU7TUFBRUMsV0FBVyxFQUFFLENBQUMsQ0FBQztNQUFFQyxrQkFBa0IsRUFBRSxFQUFFO01BQUVDLFFBQVEsRUFBRTtJQUFRO0VBQ3BRLENBQUM7RUFDRCxJQUFJLEVBQUVuUCxJQUFJLElBQUlnQixJQUFJLENBQUMsRUFBRSxNQUFNLElBQUlvTyxVQUFVLENBQUMsYUFBYSxDQUFDO0VBQ3hELE9BQU9wTyxJQUFJLENBQUNoQixJQUFJLENBQUM7QUFDbkI7QUFDQSxPQUFPLFNBQVNxUCxZQUFZQSxDQUF1QkMsU0FBYSxFQUFFdFAsSUFBTyxFQUFFdVAsSUFBSSxHQUFHLEVBQUUsRUFBRXZPLElBQWdDLEVBQWE7RUFDakksTUFBTXdPLEdBQUcsR0FBRyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztFQUNwQyxPQUFPO0lBQUUzUCxFQUFFLEVBQUVQLEtBQUssQ0FBQyxDQUFDO0lBQUU4UCxTQUFTO0lBQUV0UCxJQUFJO0lBQUUyUCxRQUFRLEVBQUUsR0FBRztJQUFFSixJQUFJO0lBQUVLLE1BQU0sRUFBRSxhQUFhO0lBQUVDLFVBQVUsRUFBRSxTQUFTO0lBQUVDLFNBQVMsRUFBRU4sR0FBRztJQUFFTyxTQUFTLEVBQUVQLEdBQUc7SUFBRVEsWUFBWSxFQUFFLENBQUMsQ0FBQztJQUFFaFAsSUFBSSxFQUFFO01BQUUsR0FBR0osV0FBVyxDQUFDWixJQUFJLENBQUM7TUFBRSxHQUFHZ0I7SUFBSztFQUFFLENBQUM7QUFDdk07QUFDQSxPQUFPLFNBQVNpUCxhQUFhQSxDQUFDVixJQUFJLEdBQUcsT0FBTyxFQUFlO0VBQ3pELE9BQU87SUFBRUQsU0FBUyxFQUFFOVAsS0FBSyxDQUFDLENBQUM7SUFBRStQLElBQUk7SUFBRVcsYUFBYSxFQUFFclYsY0FBYztJQUFFOFUsUUFBUSxFQUFFLEdBQUc7SUFBRVEsVUFBVSxFQUFFclYsa0JBQWtCLENBQUNpRixFQUFFO0lBQUVxUSxTQUFTLEVBQUUsR0FBRztJQUFFQyxTQUFTLEVBQUUsQ0FBQ0MsZUFBZSxDQUFDeFYsa0JBQWtCLENBQUMsQ0FBQztJQUFFeVYsZUFBZSxFQUFFLEVBQUU7SUFBRWpRLFFBQVEsRUFBRSxFQUFFO0lBQUVrUSxTQUFTLEVBQUUsRUFBRTtJQUFFQyxTQUFTLEVBQUUsRUFBRTtJQUFFQyxPQUFPLEVBQUUsRUFBRTtJQUFFQyxLQUFLLEVBQUU7RUFBRyxDQUFDO0FBQ2pSO0FBQ0EsT0FBTyxTQUFTL0ksaUJBQWlCQSxDQUFDRixnQkFBb0IsRUFBZ0I7RUFBRSxPQUFPO0lBQUVBLGdCQUFnQjtJQUFFa0osY0FBYyxFQUFFLENBQUMsQ0FBQztJQUFFQyxhQUFhLEVBQUUsRUFBRTtJQUFFQyxVQUFVLEVBQUUsRUFBRTtJQUFFQyxPQUFPLEVBQUUsRUFBRTtJQUFFQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO0lBQUVDLFlBQVksRUFBRSxFQUFFO0lBQUVDLE9BQU8sRUFBRSxZQUFZO0lBQUVDLFdBQVcsRUFBRSxDQUFDO0lBQUVDLFNBQVMsRUFBRSxFQUFFO0lBQUVDLG9CQUFvQixFQUFFLElBQUk7SUFBRUMsVUFBVSxFQUFFLENBQUM7SUFBRUMsVUFBVSxFQUFFO0VBQVksQ0FBQztBQUFFO0FBQ3RVLE9BQU8sU0FBU0MsaUJBQWlCQSxDQUFBLEVBQWdCO0VBQy9DLE1BQU1uUixPQUFPLEdBQUc0UCxhQUFhLENBQUMsY0FBYyxDQUFDO0lBQUVsUSxFQUFFLEdBQUdNLE9BQU8sQ0FBQ2lQLFNBQVM7RUFDckUsTUFBTW1DLEVBQUUsR0FBR3BDLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFO0lBQUVrQixPQUFPLEVBQUUsSUFBSTtJQUFFRSxPQUFPLEVBQUV4QixjQUFjLENBQUMsaUJBQWlCO0VBQUUsQ0FBQyxDQUFDO0VBQzdHLE1BQU0rUixLQUFLLEdBQUdyQyxZQUFZLENBQUN0UCxFQUFFLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRTtJQUFFa0IsT0FBTyxFQUFFLE1BQU07SUFBRUUsT0FBTyxFQUFFeEIsY0FBYyxDQUFDLHlCQUF5QjtFQUFFLENBQUMsQ0FBQztFQUMxSCxNQUFNbUUsSUFBSSxHQUFHdUwsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7SUFBRWtCLE9BQU8sRUFBRSxPQUFPO0lBQUVHLElBQUksRUFBRXpCLGNBQWMsQ0FBQyx3QkFBd0I7RUFBRSxDQUFDLENBQUM7RUFDbkgsTUFBTWpFLEtBQUssR0FBRzJULFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFO0lBQUVvQixPQUFPLEVBQUV4QixjQUFjLENBQUMsZ0JBQWdCLENBQUM7SUFBRWdDLElBQUksRUFBRTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFK1AsRUFBRSxFQUFFLEtBQUs7TUFBRXhCLFVBQVUsRUFBRTlQLE9BQU8sQ0FBQzhQO0lBQVcsQ0FBQztJQUFFdE8sUUFBUSxFQUFFLFFBQVE7SUFBRUUsVUFBVSxFQUFFK0IsSUFBSSxDQUFDL0Q7RUFBRyxDQUFDLENBQUM7RUFDak4sTUFBTXRCLEdBQUcsR0FBRzRRLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFO0lBQUV0QixHQUFHLEVBQUUsU0FBUztJQUFFaUgsU0FBUyxFQUFFLFNBQVM7SUFBRUUsT0FBTyxFQUFFO01BQUUzRyxJQUFJLEVBQUUsU0FBUztNQUFFNkIsS0FBSyxFQUFFO0lBQU07RUFBRSxDQUFDLENBQUM7RUFDekksTUFBTThRLFNBQVMsR0FBR3ZDLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFO0lBQUV0QixHQUFHLEVBQUUsYUFBYTtJQUFFaUgsU0FBUyxFQUFFLFNBQVM7SUFBRUUsT0FBTyxFQUFFO01BQUUzRyxJQUFJLEVBQUUsU0FBUztNQUFFNkIsS0FBSyxFQUFFO0lBQUUsQ0FBQztJQUFFK0UsT0FBTyxFQUFFO01BQUVnTSxHQUFHLEVBQUUsQ0FBQyxFQUFFO01BQUVDLEdBQUcsRUFBRTtJQUFHO0VBQUUsQ0FBQyxDQUFDO0VBQy9LLE1BQU1DLE1BQU0sR0FBRzFDLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFO0lBQUVvQixPQUFPLEVBQUV4QixjQUFjLENBQUMsb0JBQW9CLENBQUM7SUFBRXlCLElBQUksRUFBRXpCLGNBQWMsQ0FBQyxzQ0FBc0MsQ0FBQztJQUFFaUQsUUFBUSxFQUFFLENBQUNsSCxLQUFLLENBQUNxRSxFQUFFLENBQUM7SUFBRWdELEtBQUssRUFBRTBPLEVBQUUsQ0FBQzFSLEVBQUU7SUFBRW9ELE9BQU8sRUFBRTtFQUFFLENBQUMsQ0FBQztFQUNqTixNQUFNNk8sTUFBTSxHQUFHM0MsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7SUFBRW9CLE9BQU8sRUFBRXhCLGNBQWMsQ0FBQyx1QkFBdUIsQ0FBQztJQUFFeUIsSUFBSSxFQUFFekIsY0FBYyxDQUFDLGlDQUFpQyxDQUFDO0lBQUVvRCxLQUFLLEVBQUUwTyxFQUFFLENBQUMxUixFQUFFO0lBQUVvRCxPQUFPLEVBQUU7RUFBRSxDQUFDLENBQUM7RUFDeEwsTUFBTXJILE9BQU8sR0FBR3VULFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFO0lBQUUyQyxRQUFRLEVBQUUsQ0FBQ3FQLE1BQU0sQ0FBQ2hTLEVBQUUsRUFBRWlTLE1BQU0sQ0FBQ2pTLEVBQUUsQ0FBQztJQUFFb0IsT0FBTyxFQUFFeEIsY0FBYyxDQUFDLDRCQUE0QjtFQUFFLENBQUMsQ0FBQztFQUN0Sm9TLE1BQU0sQ0FBQy9RLElBQUksQ0FBQzZCLFNBQVMsR0FBRy9HLE9BQU8sQ0FBQ2lFLEVBQUU7RUFBRWlTLE1BQU0sQ0FBQ2hSLElBQUksQ0FBQzZCLFNBQVMsR0FBRy9HLE9BQU8sQ0FBQ2lFLEVBQUU7RUFDdEUsTUFBTWtTLEtBQUssR0FBRzVDLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFO0lBQUUyRCxRQUFRLEVBQUUsUUFBUTtJQUFFTSxlQUFlLEVBQUU7RUFBZ0IsQ0FBQyxDQUFDO0VBQy9HLE1BQU1rTyxJQUFJLEdBQUc3QyxZQUFZLENBQUN0UCxFQUFFLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRTtJQUFFMkQsUUFBUSxFQUFFLFdBQVc7SUFBRUMsT0FBTyxFQUFFb08sTUFBTSxDQUFDaFMsRUFBRTtJQUFFaUUsZUFBZSxFQUFFO0VBQWMsQ0FBQyxDQUFDO0VBQ3BJLE1BQU1tTyxLQUFLLEdBQUc5QyxZQUFZLENBQUN0UCxFQUFFLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRTtJQUFFMkQsUUFBUSxFQUFFLFFBQVE7SUFBRUMsT0FBTyxFQUFFcU8sTUFBTSxDQUFDalMsRUFBRTtJQUFFaUUsZUFBZSxFQUFFO0VBQWdCLENBQUMsQ0FBQztFQUNuSSxNQUFNb08sTUFBTSxHQUFHL0MsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUU7SUFBRTJELFFBQVEsRUFBRSxVQUFVO0lBQUVHLGNBQWMsRUFBRTtFQUFpQixDQUFDLENBQUM7RUFDaEgsTUFBTXdPLElBQUksR0FBR2hELFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxXQUFXLEVBQUUsTUFBTSxFQUFFO0lBQUUyRCxRQUFRLEVBQUUsVUFBVTtJQUFFRyxjQUFjLEVBQUU7RUFBc0IsQ0FBQyxDQUFDO0VBQ25ILE1BQU15TyxNQUFNLEdBQUdqRCxZQUFZLENBQUN0UCxFQUFFLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRTtJQUFFbUcsU0FBUyxFQUFFLEtBQUs7SUFBRUMsUUFBUSxFQUFFMUgsR0FBRyxDQUFDc0IsRUFBRTtJQUFFZSxLQUFLLEVBQUU7TUFBRTdCLElBQUksRUFBRSxTQUFTO01BQUU2QixLQUFLLEVBQUU7SUFBSztFQUFFLENBQUMsQ0FBQztFQUNsSSxNQUFNeVIsU0FBUyxHQUFHbEQsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7SUFBRW1HLFNBQVMsRUFBRSxLQUFLO0lBQUVDLFFBQVEsRUFBRXlMLFNBQVMsQ0FBQzdSLEVBQUU7SUFBRWUsS0FBSyxFQUFFO01BQUU3QixJQUFJLEVBQUUsU0FBUztNQUFFNkIsS0FBSyxFQUFFO0lBQUU7RUFBRSxDQUFDLENBQUM7RUFDMUksTUFBTTRGLFFBQVEsR0FBRzJJLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFO0lBQUUyRyxRQUFRLEVBQUUvRyxjQUFjLENBQUMsWUFBWSxDQUFDO0lBQUVnSCxNQUFNLEVBQUVoSCxjQUFjLENBQUMsZUFBZSxDQUFDO0lBQUVpSCxnQkFBZ0IsRUFBRTtFQUFZLENBQUMsQ0FBQztFQUNoTCxNQUFNNEwsSUFBSSxHQUFHbkQsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUU7SUFBRW9ILFlBQVksRUFBRVQsUUFBUSxDQUFDM0csRUFBRTtJQUFFcUgsTUFBTSxFQUFFO01BQUVDLFFBQVEsRUFBRTZLLElBQUksQ0FBQ25TO0lBQUcsQ0FBQztJQUFFd0gsSUFBSSxFQUFFLE1BQU07SUFBRUQsS0FBSyxFQUFFO0VBQU8sQ0FBQyxDQUFDO0VBQzlJLE1BQU1tTCxNQUFNLEdBQUdwRCxZQUFZLENBQUN0UCxFQUFFLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRTtJQUFFb0gsWUFBWSxFQUFFVCxRQUFRLENBQUMzRyxFQUFFO0lBQUVxSCxNQUFNLEVBQUU7TUFBRUMsUUFBUSxFQUFFK0ssTUFBTSxDQUFDclM7SUFBRyxDQUFDO0lBQUV3SCxJQUFJLEVBQUUsUUFBUTtJQUFFRCxLQUFLLEVBQUU7RUFBUyxDQUFDLENBQUM7RUFDdEpaLFFBQVEsQ0FBQzFGLElBQUksQ0FBQzhGLE9BQU8sR0FBRyxDQUFDMEwsSUFBSSxDQUFDelMsRUFBRSxDQUFDO0VBQUUyRyxRQUFRLENBQUMxRixJQUFJLENBQUMrRixTQUFTLEdBQUcsQ0FBQzBMLE1BQU0sQ0FBQzFTLEVBQUUsQ0FBQztFQUFFMkcsUUFBUSxDQUFDMUYsSUFBSSxDQUFDZ0csWUFBWSxHQUFHLENBQUN3TCxJQUFJLENBQUN6UyxFQUFFLENBQUM7RUFDaEgsTUFBTTJTLE9BQU8sR0FBR3JELFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFO0lBQUVtRyxTQUFTLEVBQUUsV0FBVztJQUFFQyxRQUFRLEVBQUVxTSxJQUFJLENBQUN6UyxFQUFFO0lBQUVlLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQztFQUNqSCxNQUFNNlIsU0FBUyxHQUFHdEQsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUU7SUFBRW1HLFNBQVMsRUFBRSxXQUFXO0lBQUVDLFFBQVEsRUFBRXNNLE1BQU0sQ0FBQzFTLEVBQUU7SUFBRWUsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQ25ILE1BQU04UixLQUE0QixHQUFHLENBQ25DdkQsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUU7SUFBRW1FLE1BQU0sRUFBRStOLEtBQUssQ0FBQ2xTLEVBQUU7SUFBRW9FLElBQUksRUFBRStOLElBQUksQ0FBQ25TLEVBQUU7SUFBRXJCLEtBQUssRUFBRSxVQUFVO0lBQUU2RixTQUFTLEVBQUUsQ0FBQytOLE1BQU0sQ0FBQ3ZTLEVBQUUsRUFBRXdTLFNBQVMsQ0FBQ3hTLEVBQUUsRUFBRTJTLE9BQU8sQ0FBQzNTLEVBQUU7RUFBRSxDQUFDLENBQUMsRUFDbkpzUCxZQUFZLENBQUN0UCxFQUFFLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRTtJQUFFbUUsTUFBTSxFQUFFK04sS0FBSyxDQUFDbFMsRUFBRTtJQUFFb0UsSUFBSSxFQUFFZ08sS0FBSyxDQUFDcFMsRUFBRTtJQUFFckIsS0FBSyxFQUFFO0VBQVMsQ0FBQyxDQUFDLEVBQzlGMlEsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUU7SUFBRW1FLE1BQU0sRUFBRWdPLElBQUksQ0FBQ25TLEVBQUU7SUFBRW9FLElBQUksRUFBRWdPLEtBQUssQ0FBQ3BTLEVBQUU7SUFBRXNFLFFBQVEsRUFBRSxXQUFXO0lBQUVHLFFBQVEsRUFBRTtFQUFFLENBQUMsQ0FBQyxFQUMvRzZLLFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFO0lBQUVtRSxNQUFNLEVBQUVpTyxLQUFLLENBQUNwUyxFQUFFO0lBQUVvRSxJQUFJLEVBQUVpTyxNQUFNLENBQUNyUyxFQUFFO0lBQUVyQixLQUFLLEVBQUUsUUFBUTtJQUFFNEYsU0FBUyxFQUFFO01BQUVQLEVBQUUsRUFBRSxTQUFTO01BQUU4TyxVQUFVLEVBQUVwVSxHQUFHLENBQUNzQixFQUFFO01BQUUrUyxVQUFVLEVBQUUsSUFBSTtNQUFFaFMsS0FBSyxFQUFFO1FBQUU3QixJQUFJLEVBQUUsU0FBUztRQUFFNkIsS0FBSyxFQUFFO01BQUs7SUFBRSxDQUFDO0lBQUV5RCxTQUFTLEVBQUUsQ0FBQ29PLFNBQVMsQ0FBQzVTLEVBQUU7RUFBRSxDQUFDLENBQUMsRUFDdk9zUCxZQUFZLENBQUN0UCxFQUFFLEVBQUUsV0FBVyxFQUFFLE1BQU0sRUFBRTtJQUFFbUUsTUFBTSxFQUFFaU8sS0FBSyxDQUFDcFMsRUFBRTtJQUFFb0UsSUFBSSxFQUFFa08sSUFBSSxDQUFDdFMsRUFBRTtJQUFFckIsS0FBSyxFQUFFO0VBQU8sQ0FBQyxDQUFDLENBQzFGO0VBQ0QsTUFBTXFVLEtBQUssR0FBRzFELFlBQVksQ0FBQ3RQLEVBQUUsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFO0lBQUUyRSxPQUFPLEVBQUUsQ0FBQ3VOLEtBQUssQ0FBQ2xTLEVBQUUsRUFBRW1TLElBQUksQ0FBQ25TLEVBQUUsRUFBRW9TLEtBQUssQ0FBQ3BTLEVBQUUsRUFBRXFTLE1BQU0sQ0FBQ3JTLEVBQUUsRUFBRXNTLElBQUksQ0FBQ3RTLEVBQUUsQ0FBQztJQUFFNEUsT0FBTyxFQUFFaU8sS0FBSyxDQUFDdlYsR0FBRyxDQUFDMlYsQ0FBQyxJQUFJQSxDQUFDLENBQUNqVCxFQUFFLENBQUM7SUFBRTZFLFFBQVEsRUFBRSxDQUFDcU4sS0FBSyxDQUFDbFMsRUFBRSxDQUFDO0lBQUU4RSxPQUFPLEVBQUUsQ0FBQ3VOLE1BQU0sQ0FBQ3JTLEVBQUUsRUFBRXNTLElBQUksQ0FBQ3RTLEVBQUU7RUFBRSxDQUFDLENBQUM7RUFDMU0sTUFBTUQsSUFBSSxHQUFHdVAsWUFBWSxDQUFDdFAsRUFBRSxFQUFFLGVBQWUsRUFBRSxFQUFFLEVBQUU7SUFBRWlGLFNBQVMsRUFBRTBNLEtBQUssQ0FBQzNSLEVBQUU7SUFBRUgsSUFBSSxFQUFFRCxjQUFjLENBQUMsbUJBQW1CO0VBQUUsQ0FBQyxDQUFDO0VBQ3RILE1BQU1zVCxJQUFJLEdBQUc1RCxZQUFZLENBQUN0UCxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsVUFBVSxFQUFFO0lBQUVnTixTQUFTLEVBQUUsQ0FBQ2lGLE1BQU0sQ0FBQ2pTLEVBQUUsQ0FBQztJQUFFdUgsS0FBSyxFQUFFLFFBQVE7SUFBRTBGLFFBQVEsRUFBRTtFQUFPLENBQUMsQ0FBQztFQUMzSDNNLE9BQU8sQ0FBQ0MsUUFBUSxHQUFHLENBQUNtUixFQUFFLEVBQUVDLEtBQUssRUFBRTVOLElBQUksRUFBRXBJLEtBQUssRUFBRStDLEdBQUcsRUFBRW1ULFNBQVMsRUFBRUcsTUFBTSxFQUFFQyxNQUFNLEVBQUVsVyxPQUFPLEVBQUVtVyxLQUFLLEVBQUVDLElBQUksRUFBRUMsS0FBSyxFQUFFQyxNQUFNLEVBQUVDLElBQUksRUFBRUMsTUFBTSxFQUFFQyxTQUFTLEVBQUU3TCxRQUFRLEVBQUU4TCxJQUFJLEVBQUVDLE1BQU0sRUFBRUMsT0FBTyxFQUFFQyxTQUFTLEVBQUUsR0FBR0MsS0FBSyxFQUFFRyxLQUFLLEVBQUVqVCxJQUFJLEVBQUVtVCxJQUFJLENBQUM7RUFDbE41UyxPQUFPLENBQUNDLFFBQVEsQ0FBQzRTLE9BQU8sQ0FBQzFTLE1BQU0sSUFBSTtJQUFFQSxNQUFNLENBQUNvUCxNQUFNLEdBQUcsV0FBVztFQUFFLENBQUMsQ0FBQztFQUNwRXZQLE9BQU8sQ0FBQ21RLFNBQVMsR0FBRyxDQUFDO0lBQUV6USxFQUFFLEVBQUVQLEtBQUssQ0FBQyxDQUFDO0lBQUU4UCxTQUFTLEVBQUV2UCxFQUFFO0lBQUU0UCxRQUFRLEVBQUUsR0FBRztJQUFFekwsTUFBTSxFQUFFdU4sRUFBRSxDQUFDMVIsRUFBRTtJQUFFb0UsSUFBSSxFQUFFdU4sS0FBSyxDQUFDM1IsRUFBRTtJQUFFb1QsWUFBWSxFQUFFLE9BQU87SUFBRXZJLFNBQVMsRUFBRSxTQUFTO0lBQUVuSCxRQUFRLEVBQUVyRSxhQUFhLENBQUMsQ0FBQztJQUFFZ1UsV0FBVyxFQUFFLENBQUNwQixNQUFNLENBQUNqUyxFQUFFLENBQUM7SUFBRTZQLE1BQU0sRUFBRSxhQUFhO0lBQUVDLFVBQVUsRUFBRTtFQUFVLENBQUMsQ0FBQztFQUNsUCxPQUFPeFAsT0FBTztBQUNoQjtBQWdCQSxNQUFNZ1QsR0FBRyxHQUFHQSxDQUFDeEIsR0FBRyxHQUFHLENBQUMsRUFBRUMsR0FBWSxNQUFjO0VBQUU3UyxJQUFJLEVBQUUsTUFBTTtFQUFFNFMsR0FBRztFQUFFQyxHQUFHO0VBQUV3QixRQUFRLEVBQUUsSUFBSSxHQUFHO0FBQUssQ0FBQyxDQUFDO0FBQ2xHLE1BQU1DLEtBQWEsR0FBR0YsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUM7RUFBRTVVLEdBQVcsR0FBRzRVLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDO0FBQzVELE1BQU1HLEdBQUcsR0FBR0EsQ0FBQzNCLEdBQVksRUFBRUMsR0FBWSxFQUFFMkIsT0FBTyxHQUFHLEtBQUssTUFBYztFQUFFeFUsSUFBSSxFQUFFLFFBQVE7RUFBRTRTLEdBQUc7RUFBRUMsR0FBRztFQUFFMkI7QUFBUSxDQUFDLENBQUM7QUFDNUcsTUFBTUMsSUFBWSxHQUFHO0lBQUV6VSxJQUFJLEVBQUU7RUFBVSxDQUFDO0VBQUUwVSxRQUFnQixHQUFHO0lBQUUxVSxJQUFJLEVBQUU7RUFBSyxDQUFDO0VBQUUyVSxJQUFZLEdBQUc7SUFBRTNVLElBQUksRUFBRTtFQUFPLENBQUM7RUFBRTRVLEtBQWEsR0FBRztJQUFFNVUsSUFBSSxFQUFFO0VBQVEsQ0FBQztBQUMvSSxNQUFNNlUsRUFBRSxHQUFHQSxDQUFDLEdBQUdoTyxNQUFtQyxNQUFjO0VBQUU3RyxJQUFJLEVBQUUsTUFBTTtFQUFFNkc7QUFBTyxDQUFDLENBQUM7QUFDekYsTUFBTWlPLEdBQUcsR0FBR0EsQ0FBQyxHQUFHQyxLQUFtQixNQUFjO0VBQUUvVSxJQUFJLEVBQUUsS0FBSztFQUFFK1UsS0FBSyxFQUFFQSxLQUFLLENBQUNDLE1BQU0sR0FBR0QsS0FBSyxHQUFHRSxTQUFTO0VBQUV2TyxLQUFLLEVBQUU7QUFBUyxDQUFDLENBQUM7QUFDM0gsTUFBTXdPLFNBQVMsR0FBSXhPLEtBQStCLEtBQWM7RUFBRTFHLElBQUksRUFBRSxLQUFLO0VBQUUwRztBQUFNLENBQUMsQ0FBQztBQUN2RixNQUFNeU8sR0FBRyxHQUFHQSxDQUFDeFksSUFBWSxFQUFFeVksTUFBTSxHQUFHLEtBQUssRUFBRXhDLEdBQVksRUFBRUMsR0FBWSxNQUFjO0VBQUU3UyxJQUFJLEVBQUUsT0FBTztFQUFFckQsSUFBSTtFQUFFeVksTUFBTTtFQUFFeEMsR0FBRztFQUFFQztBQUFJLENBQUMsQ0FBQztBQUM3SCxNQUFNd0MsSUFBSSxHQUFHQSxDQUFDLEdBQUdOLEtBQW1CLEtBQWFJLEdBQUcsQ0FBQ0wsR0FBRyxDQUFDLEdBQUdDLEtBQUssQ0FBQyxFQUFFLElBQUksQ0FBQztBQUN6RSxNQUFNTyxHQUFHLEdBQUlySixNQUE2QixLQUFjO0VBQUVqTSxJQUFJLEVBQUUsUUFBUTtFQUFFaU07QUFBTyxDQUFDLENBQUM7QUFDbkYsTUFBTXNKLEdBQUcsR0FBSUMsTUFBYyxLQUFhO0VBQUVBLE1BQU07RUFBRUMsUUFBUSxFQUFFO0FBQUssQ0FBQyxDQUFDO0FBQ25FLE1BQU1DLEdBQUcsR0FBSUYsTUFBYyxLQUFhO0VBQUVBLE1BQU07RUFBRUcsUUFBUSxFQUFFO0FBQUssQ0FBQyxDQUFDO0FBQ25FLE1BQU1DLGFBQWEsR0FBSUosTUFBYyxLQUFhO0VBQUVBLE1BQU07RUFBRUcsUUFBUSxFQUFFO0FBQU0sQ0FBQyxDQUFDO0FBQzlFLE1BQU1FLElBQVksR0FBRztJQUFFN1YsSUFBSSxFQUFFO0VBQVcsQ0FBQztFQUFFa0MsT0FBZSxHQUFHO0lBQUVsQyxJQUFJLEVBQUUsVUFBVTtJQUFFNlMsR0FBRyxFQUFFO0VBQUssQ0FBQztBQUM1RixNQUFNaUQsSUFBWSxHQUFHO0lBQUU5VixJQUFJLEVBQUU7RUFBWSxDQUFDO0VBQUUwQyxJQUFZLEdBQUc7SUFBRTFDLElBQUksRUFBRTtFQUFPLENBQUM7QUFDM0UsTUFBTStWLE1BQU0sR0FBR0EsQ0FBQ2xVLEtBQWEsRUFBRW1VLFNBQWtCLE1BQWM7RUFBRWhXLElBQUksRUFBRSxRQUFRO0VBQUU2QixLQUFLO0VBQUVyQyxHQUFHLEVBQUV3VztBQUFVLENBQUMsQ0FBQztBQUN6RyxNQUFNQyxLQUFLLEdBQUdBLENBQUMsR0FBR0MsT0FBaUIsTUFBYztFQUFFbFcsSUFBSSxFQUFFLE9BQU87RUFBRWtXO0FBQVEsQ0FBQyxDQUFDO0FBQzVFLE1BQU0vTixNQUFNLEdBQUdtTixHQUFHLENBQUM7RUFBRWxOLFFBQVEsRUFBRW1OLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFFcUIsT0FBTyxFQUFFVCxHQUFHLENBQUNSLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztFQUFFa0IsTUFBTSxFQUFFVixHQUFHLENBQUNaLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztFQUFFdUIsS0FBSyxFQUFFWCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFBRXFCLEdBQUcsRUFBRVosR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUVzQixlQUFlLEVBQUViLEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQUVzQixjQUFjLEVBQUVkLEdBQUcsQ0FBQ2IsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQUU0QixjQUFjLEVBQUVmLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFekgsVUFBVSxFQUFFK0ksR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDbFUsTUFBTXNDLHdCQUF3QixHQUFHVCxLQUFLLENBQUNYLEdBQUcsQ0FBQztFQUFFdlUsSUFBSSxFQUFFd1UsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7RUFBRThCLFlBQVksRUFBRXBCLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRXRTLE1BQU0sRUFBRXlULEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFcFMsT0FBTyxFQUFFdVQsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUM7QUFBRSxDQUFDLENBQUMsRUFBRWtCLEdBQUcsQ0FBQztFQUFFdlUsSUFBSSxFQUFFd1UsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7RUFBRThCLFlBQVksRUFBRXBCLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRXRTLE1BQU0sRUFBRXlULEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFNUgsTUFBTSxFQUFFK0ksR0FBRyxDQUFDcE4sTUFBTTtBQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlPLE1BQU15TyxnQkFBZ0IsR0FBR3RCLEdBQUcsQ0FBQztFQUFFbFYsVUFBVSxFQUFFO0lBQUVvVixNQUFNLEVBQUVGLEdBQUcsQ0FBQztNQUFFZSxLQUFLLEVBQUU7UUFBRWIsTUFBTSxFQUFFYixJQUFJO1FBQUVjLFFBQVEsRUFBRSxJQUFJO1FBQUVFLFFBQVEsRUFBRTtNQUFLLENBQUM7TUFBRVcsR0FBRyxFQUFFO1FBQUVkLE1BQU0sRUFBRWIsSUFBSTtRQUFFYyxRQUFRLEVBQUUsSUFBSTtRQUFFRSxRQUFRLEVBQUU7TUFBSztJQUFFLENBQUMsQ0FBQztJQUFFRixRQUFRLEVBQUUsSUFBSTtJQUFFRSxRQUFRLEVBQUU7RUFBSyxDQUFDO0VBQUV0VixjQUFjLEVBQUU7SUFBRW1WLE1BQU0sRUFBRU0sSUFBSTtJQUFFTCxRQUFRLEVBQUUsSUFBSTtJQUFFRSxRQUFRLEVBQUU7RUFBSyxDQUFDO0VBQUVyVixrQkFBa0IsRUFBRTtJQUFFa1YsTUFBTSxFQUFFck4sTUFBTTtJQUFFc04sUUFBUSxFQUFFLElBQUk7SUFBRUUsUUFBUSxFQUFFO0VBQUs7QUFBRSxDQUFDLENBQUM7QUFDM1YsTUFBTW5OLFdBQVcsR0FBRzhNLEdBQUcsQ0FBQztFQUFFakYsU0FBUyxFQUFFa0YsR0FBRyxDQUFDTCxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7RUFBRTJCLE9BQU8sRUFBRW5CLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQUVsUixTQUFTLEVBQUU4UixHQUFHLENBQUNaLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztFQUFFelUsY0FBYyxFQUFFcVYsR0FBRyxDQUFDSSxJQUFJLENBQUM7RUFBRWdCLGdCQUFnQixFQUFFcEIsR0FBRyxDQUFDUixTQUFTLENBQUMsVUFBVSxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQzNNLE1BQU02QixLQUFLLEdBQUd6QixHQUFHLENBQUM7RUFBRXhVLEVBQUUsRUFBRXlVLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0VBQUUvVCxJQUFJLEVBQUU0VSxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQUVwUyxPQUFPLEVBQUV1VCxHQUFHLENBQUNqQixLQUFLLENBQUM7RUFBRTlQLFFBQVEsRUFBRStRLEdBQUcsQ0FBQ3FCLGdCQUFnQixDQUFDO0VBQUVJLGlCQUFpQixFQUFFekIsR0FBRyxDQUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7RUFBRTRCLGVBQWUsRUFBRTFCLEdBQUcsQ0FBQ2QsSUFBSTtBQUFFLENBQUMsQ0FBQztBQUM3TCxNQUFNeUMsU0FBUyxHQUFHNUIsR0FBRyxDQUFDO0VBQUV4VCxNQUFNLEVBQUV5VCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFBRTVMLFdBQVcsRUFBRStNLEdBQUcsQ0FBQy9NLFdBQVcsQ0FBQztFQUFFaEUsUUFBUSxFQUFFK1EsR0FBRyxDQUFDcUIsZ0JBQWdCLENBQUM7RUFBRXpDLFdBQVcsRUFBRW9CLEdBQUcsQ0FBQ0YsSUFBSSxDQUFDLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDeEksTUFBTThCLFVBQVUsR0FBRzdCLEdBQUcsQ0FBQztFQUFFOEIsSUFBSSxFQUFFN0IsR0FBRyxDQUFDWCxLQUFLLENBQUM7RUFBRXlDLEVBQUUsRUFBRTlCLEdBQUcsQ0FBQ1gsS0FBSyxDQUFDO0VBQUU5UyxNQUFNLEVBQUU0VCxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQUU4QyxTQUFTLEVBQUV4QixHQUFHLENBQUNqQixJQUFJLENBQUM7RUFBRTZDLGdCQUFnQixFQUFFNUIsR0FBRyxDQUFDd0IsU0FBUztBQUFFLENBQUMsQ0FBQztBQUN4SSxNQUFNSyxTQUFTLEdBQUdqQyxHQUFHLENBQUM7RUFBRWtDLEVBQUUsRUFBRWpDLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUMsQ0FBQztFQUFFaFQsS0FBSyxFQUFFMFQsR0FBRyxDQUFDWCxLQUFLLENBQUM7RUFBRTlTLE1BQU0sRUFBRTRULEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQzlJLE1BQU14TixPQUFPLEdBQUcwTyxHQUFHLENBQUM7RUFBRTFDLEdBQUcsRUFBRThDLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQ1UsU0FBUyxFQUFFQSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFBRXBDLEdBQUcsRUFBRTZDLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQ1UsU0FBUyxFQUFFQSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFBRXBPLE1BQU0sRUFBRTZPLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDYyxLQUFLLENBQUM3QixHQUFHLENBQUMsQ0FBQyxFQUFFSyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDekosTUFBTWdELE9BQU8sR0FBR25DLEdBQUcsQ0FBQztFQUFFeFUsRUFBRSxFQUFFNFUsR0FBRyxDQUFDaEIsUUFBUSxDQUFDO0VBQUVqWSxLQUFLLEVBQUU4WSxHQUFHLENBQUNWLEVBQUUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLGVBQWUsRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7RUFBRTZDLFFBQVEsRUFBRW5DLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRXVELE1BQU0sRUFBRXBDLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztFQUFFbk8sS0FBSyxFQUFFZ1AsR0FBRyxDQUFDYixFQUFFLENBQUMsR0FBR3ZWLE1BQU0sQ0FBQyxDQUFDO0VBQUUwSSxRQUFRLEVBQUUwTixHQUFHLENBQUNoVCxJQUFJO0FBQUUsQ0FBQyxDQUFDO0FBQzdOLE1BQU1rVixLQUFLLEdBQUd0QyxHQUFHLENBQUM7RUFBRTNTLElBQUksRUFBRTRTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUM7RUFBRWdELFFBQVEsRUFBRXRDLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFFZ0QsZ0JBQWdCLEVBQUV2QyxHQUFHLENBQUNMLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztFQUFFNkMsY0FBYyxFQUFFeEMsR0FBRyxDQUFDSixHQUFHLENBQUNmLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztFQUFFNEQsUUFBUSxFQUFFdEMsR0FBRyxDQUFDSyxNQUFNLENBQUNyQixRQUFRLEVBQUVBLFFBQVEsQ0FBQztBQUFFLENBQUMsQ0FBQztBQUM3TixNQUFNdlAsVUFBVSxHQUFHbVEsR0FBRyxDQUFDO0VBQUVuUSxVQUFVLEVBQUVvUSxHQUFHLENBQUNELEdBQUcsQ0FBQztJQUFFN1YsS0FBSyxFQUFFOFYsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFdFMsTUFBTSxFQUFFeVQsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztBQUFFLENBQUMsQ0FBQztBQUM1RixNQUFNNkQsV0FBVyxHQUFHM0MsR0FBRyxDQUFDO0VBQUVuTyxVQUFVLEVBQUVvTyxHQUFHLENBQUNiLFFBQVEsQ0FBQztFQUFFdFIsTUFBTSxFQUFFbVMsR0FBRyxDQUFDVCxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7RUFBRW9ELFFBQVEsRUFBRTNDLEdBQUcsQ0FBQ2hCLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztFQUFFNVEsT0FBTyxFQUFFcVIsR0FBRyxDQUFDWixHQUFHLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0VBQUVoUyxVQUFVLEVBQUU0UyxHQUFHLENBQUNaLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztFQUFFcUQsUUFBUSxFQUFFNUMsR0FBRyxDQUFDZCxJQUFJLENBQUM7RUFBRTNTLE1BQU0sRUFBRTRULEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQ3pPLE1BQU1nRSxnQkFBZ0IsR0FBRzlDLEdBQUcsQ0FBQztFQUFFK0MsV0FBVyxFQUFFOUMsR0FBRyxDQUFDVCxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7RUFBRXZOLFFBQVEsRUFBRW1PLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0VBQUV3RCxLQUFLLEVBQUUvQyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQUUwRCxjQUFjLEVBQUU3QyxHQUFHLENBQUNaLEdBQUcsQ0FBQyxRQUFRLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDckwsTUFBTTBELGtCQUFrQixHQUFHbEQsR0FBRyxDQUFDO0VBQUVwTyxRQUFRLEVBQUVxTyxHQUFHLENBQUNULEdBQUcsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLFlBQVksQ0FBQyxDQUFDO0VBQUVqVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQUU0RCxPQUFPLEVBQUVsRCxHQUFHLENBQUNKLEdBQUcsQ0FBQ2YsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUFFLENBQUMsQ0FBQztBQUNwSyxNQUFNc0UsU0FBUyxHQUFHcEQsR0FBRyxDQUFDO0VBQUV1QixPQUFPLEVBQUV0QixHQUFHLENBQUNULEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUFFNkQsWUFBWSxFQUFFcEQsR0FBRyxDQUFDVCxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7RUFBRWhQLFVBQVUsRUFBRXlQLEdBQUcsQ0FBQ1EsTUFBTSxDQUFDbkIsS0FBSyxFQUFFcFYsR0FBRyxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQ3BJLE1BQU1vWixPQUFPLEdBQUd0RCxHQUFHLENBQUM7RUFBRTdNLGdCQUFnQixFQUFFOE0sR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7RUFBRXZELGNBQWMsRUFBRTRELEdBQUcsQ0FBQ1EsTUFBTSxDQUFDbkIsS0FBSyxFQUFFRSxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztFQUFFbEQsYUFBYSxFQUFFMkQsR0FBRyxDQUFDSixHQUFHLENBQUM4QyxXQUFXLENBQUMsQ0FBQztFQUFFcEcsVUFBVSxFQUFFMEQsR0FBRyxDQUFDSixHQUFHLENBQUNpRCxnQkFBZ0IsQ0FBQyxDQUFDO0VBQUV0RyxPQUFPLEVBQUV5RCxHQUFHLENBQUNKLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDLGNBQWMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUVuRCxXQUFXLEVBQUV3RCxHQUFHLENBQUNRLE1BQU0sQ0FBQ3hCLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFBRUgsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUU5QyxZQUFZLEVBQUV1RCxHQUFHLENBQUNKLEdBQUcsQ0FBQ2YsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUVuQyxPQUFPLEVBQUVzRCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFBRWxDLFdBQVcsRUFBRXFELEdBQUcsQ0FBQ2hCLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztFQUFFOUMsU0FBUyxFQUFFb0QsR0FBRyxDQUFDSixHQUFHLENBQUN1RCxTQUFTLENBQUMsQ0FBQztFQUFFdEcsb0JBQW9CLEVBQUVzRCxHQUFHLENBQUNaLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztFQUFFekMsVUFBVSxFQUFFa0QsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUUzQyxVQUFVLEVBQUVpRCxHQUFHLENBQUNWLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztFQUFFZ0UsV0FBVyxFQUFFbkQsR0FBRyxDQUFDUCxHQUFHLENBQUNHLEdBQUcsQ0FBQztJQUFFMUIsVUFBVSxFQUFFMkIsR0FBRyxDQUFDVCxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRTBDLEVBQUUsRUFBRWpDLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUFFaUUsTUFBTSxFQUFFdkQsR0FBRyxDQUFDWCxLQUFLLENBQUM7SUFBRW1FLEtBQUssRUFBRXhELEdBQUcsQ0FBQ1gsS0FBSyxDQUFDO0lBQUU5UyxNQUFNLEVBQUV5VCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQ2h5QixNQUFNNEUsaUJBQWlCLEdBQUcxRCxHQUFHLENBQUM7RUFBRWxOLFFBQVEsRUFBRW1OLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0VBQUVtRSxZQUFZLEVBQUUxRCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQUUwRSxNQUFNLEVBQUV2RCxHQUFHLENBQUNxRCxPQUFPLENBQUM7RUFBRUcsS0FBSyxFQUFFeEQsR0FBRyxDQUFDcUQsT0FBTyxDQUFDO0VBQUVNLGlCQUFpQixFQUFFeEQsR0FBRyxDQUFDa0QsT0FBTyxDQUFDO0VBQUVPLGdCQUFnQixFQUFFNUQsR0FBRyxDQUFDSixHQUFHLENBQUNxRCxrQkFBa0IsQ0FBQyxDQUFDO0VBQUVZLGNBQWMsRUFBRTFELEdBQUcsQ0FBQ0ssTUFBTSxDQUFDbkIsS0FBSyxFQUFFRSxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0VBQUV1RSxTQUFTLEVBQUUzRCxHQUFHLENBQUNmLElBQUk7QUFBRSxDQUFDLENBQUM7QUFDOVMsTUFBTTJFLFdBQVcsR0FBR2hFLEdBQUcsQ0FBQztFQUFFaUUsVUFBVSxFQUFFaEUsR0FBRyxDQUFDRixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7RUFBRTVSLFFBQVEsRUFBRThSLEdBQUcsQ0FBQ0osR0FBRyxDQUFDTCxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztFQUFFMEUsU0FBUyxFQUFFOUQsR0FBRyxDQUFDYixFQUFFLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0VBQUU0RSxXQUFXLEVBQUVsRSxHQUFHLENBQUNKLEdBQUcsQ0FBQzZELGlCQUFpQixDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQ25MLE1BQU1VLGFBQWEsR0FBR3BFLEdBQUcsQ0FBQztFQUFFcUUsT0FBTyxFQUFFcEUsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUUyRSxLQUFLLEVBQUVyRSxHQUFHLENBQUNoQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQ3pHLE1BQU00RSxhQUFhLEdBQUd2RSxHQUFHLENBQUM7RUFBRXdFLFlBQVksRUFBRXBFLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDMkQsYUFBYSxFQUFFN0UsRUFBRSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFBRWtGLGNBQWMsRUFBRXJFLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDMkQsYUFBYSxFQUFFN0UsRUFBRSxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFBRThFLE9BQU8sRUFBRXBFLEdBQUcsQ0FBQ2hCLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztFQUFFMkUsS0FBSyxFQUFFckUsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUUrRSxRQUFRLEVBQUV0RSxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFBRXJULE9BQU8sRUFBRThULEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDelcsTUFBTWdGLFFBQVEsR0FBRzNFLEdBQUcsQ0FBQ25XLE1BQU0sQ0FBQ1ksV0FBVyxDQUFDLENBQUMsUUFBUSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLGVBQWUsQ0FBQyxDQUFDM0IsR0FBRyxDQUFDbU8sS0FBSyxJQUFJLENBQUNBLEtBQUssRUFBRWdKLEdBQUcsQ0FBQ3NFLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pLLE1BQU1LLGVBQWUsR0FBRzVFLEdBQUcsQ0FBQztFQUFFOVYsR0FBRyxFQUFFK1YsR0FBRyxDQUFDL1YsR0FBRyxDQUFDO0VBQUVDLEtBQUssRUFBRThWLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7RUFBRXBVLElBQUksRUFBRXVWLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7RUFBRVksUUFBUSxFQUFFRixHQUFHLENBQUNkLElBQUksQ0FBQztFQUFFa0IsUUFBUSxFQUFFSixHQUFHLENBQUNkLElBQUksQ0FBQztFQUFFMEYsT0FBTyxFQUFFO0lBQUUzRSxNQUFNLEVBQUU7TUFBRXhWLElBQUksRUFBRTtJQUFTLENBQUM7SUFBRXlWLFFBQVEsRUFBRSxJQUFJO0lBQUVFLFFBQVEsRUFBRTtFQUFLLENBQUM7RUFBRXlFLGFBQWEsRUFBRTFFLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDZixHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQUVpRyxXQUFXLEVBQUUzRSxHQUFHLENBQUNQLEdBQUcsQ0FBQ04sRUFBRSxDQUFDLEdBQUczVixZQUFZLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztFQUFFb2IsSUFBSSxFQUFFNUUsR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDdlcsTUFBTW5HLFFBQVEsR0FBR3FILEdBQUcsQ0FBQztFQUFFelQsS0FBSyxFQUFFNlQsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUVnRyxLQUFLLEVBQUU3RSxHQUFHLENBQUNKLEdBQUcsQ0FBQztJQUFFMUMsR0FBRyxFQUFFMkMsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUUxQixHQUFHLEVBQUUwQyxHQUFHLENBQUNoQixHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDLENBQUM7RUFBRWlHLElBQUksRUFBRWpGLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFcUcsV0FBVyxFQUFFbEYsR0FBRyxDQUFDSixHQUFHLENBQUNmLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFMU4sS0FBSyxFQUFFNk8sR0FBRyxDQUFDL00sV0FBVyxDQUFDO0VBQUVrUyxZQUFZLEVBQUVuRixHQUFHLENBQUNoQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFBRW5YLE1BQU0sRUFBRXlYLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRXVHLEtBQUssRUFBRWpGLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQ3FHLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDO0FBQUUsQ0FBQyxDQUFDO0FBQ2xSLE1BQU1DLFVBQVUsR0FBR3hGLEdBQUcsQ0FBQztFQUNyQixHQUFHblcsTUFBTSxDQUFDWSxXQUFXLENBQUMsQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLGdCQUFnQixFQUFDLFVBQVUsRUFBQyxRQUFRLEVBQUMsVUFBVSxDQUFDLENBQUMzQixHQUFHLENBQUNtTyxLQUFLLElBQUksQ0FBQ0EsS0FBSyxFQUFFbUosR0FBRyxDQUFDRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDbE0sR0FBRzFXLE1BQU0sQ0FBQ1ksV0FBVyxDQUFDLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLFVBQVUsRUFBRSxhQUFhLEVBQUUsaUJBQWlCLEVBQUUsaUJBQWlCLEVBQUUsUUFBUSxFQUFDLFlBQVksRUFBQyxVQUFVLEVBQUMscUJBQXFCLEVBQUMsZ0JBQWdCLEVBQUMsZ0JBQWdCLEVBQUMsVUFBVSxFQUFDLHVCQUF1QixFQUFDLGlCQUFpQixFQUFDLGNBQWMsRUFBQyxhQUFhLEVBQUMsWUFBWSxFQUFDLFVBQVUsQ0FBQyxDQUFDM0IsR0FBRyxDQUFDbU8sS0FBSyxJQUFJLENBQUNBLEtBQUssRUFBRW1KLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlnQixDQUFDLENBQUM7O0FBRUY7QUFDQSxPQUFPLE1BQU0yRyxjQUEwQyxHQUFHO0VBQ3hEeGUsU0FBUyxFQUFFK1ksR0FBRyxDQUFDO0lBQUV0VCxPQUFPLEVBQUUwVCxHQUFHLENBQUNwQixLQUFLLENBQUM7SUFBRXJTLE9BQU8sRUFBRXlULEdBQUcsQ0FBQ1AsR0FBRyxDQUFDNEIsS0FBSyxDQUFDLENBQUM7SUFBRTdVLE9BQU8sRUFBRXdULEdBQUcsQ0FBQ3hULE9BQU8sQ0FBQztJQUFFQyxJQUFJLEVBQUV1VCxHQUFHLENBQUNHLElBQUksQ0FBQztJQUFFelQsV0FBVyxFQUFFc1QsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRW1GLEtBQUssRUFBRXRGLEdBQUcsQ0FBQ2hULElBQUksQ0FBQztJQUFFdVksS0FBSyxFQUFFdkYsR0FBRyxDQUFDaFQsSUFBSSxDQUFDO0lBQUVMLEtBQUssRUFBRXFULEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQUUvUyxVQUFVLEVBQUVvVCxHQUFHLENBQUNMLElBQUksQ0FBQyxZQUFZLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDcE83WSxLQUFLLEVBQUU4WSxHQUFHLENBQUM7SUFBRS9TLFNBQVMsRUFBRWdULEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQUVyUyxPQUFPLEVBQUVrVCxHQUFHLENBQUNMLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBRTVTLFFBQVEsRUFBRWlULEdBQUcsQ0FBQ1osR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQUU1UyxPQUFPLEVBQUV3VCxHQUFHLENBQUN4VCxPQUFPO0VBQUUsQ0FBQyxDQUFDO0VBQzdKekYsS0FBSyxFQUFFNlksR0FBRyxDQUFDO0lBQUVwVCxPQUFPLEVBQUVxVCxHQUFHLENBQUNyVCxPQUFPLENBQUM7SUFBRVEsSUFBSSxFQUFFNlMsR0FBRyxDQUFDN1MsSUFBSSxDQUFDO0lBQUVFLFFBQVEsRUFBRTJTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFFBQVEsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFBRWhTLFlBQVksRUFBRTZTLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDRyxHQUFHLENBQUM7TUFBRTlHLFdBQVcsRUFBRStHLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO01BQUV4TSxJQUFJLEVBQUVpTixHQUFHLENBQUNWLEVBQUUsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7TUFBRVYsV0FBVyxFQUFFdUIsR0FBRyxDQUFDTCxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQUU2RixrQkFBa0IsRUFBRXhGLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBRXZTLFVBQVUsRUFBRTRTLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQUUvUixPQUFPLEVBQUUyUyxHQUFHLENBQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUFFalQsV0FBVyxFQUFFc1QsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRTdTLFdBQVcsRUFBRTBTLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDYyxLQUFLLENBQUNYLEdBQUcsQ0FBQztNQUFFdFYsSUFBSSxFQUFFdVYsR0FBRyxDQUFDVixFQUFFLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO01BQUVzRyxhQUFhLEVBQUU1RixHQUFHLENBQUNULEdBQUcsQ0FBQyxPQUFPLENBQUM7SUFBRSxDQUFDLENBQUMsRUFBRVEsR0FBRyxDQUFDO01BQUV0VixJQUFJLEVBQUV1VixHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztNQUFFc0csYUFBYSxFQUFFNUYsR0FBRyxDQUFDVCxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7TUFBRWpKLFlBQVksRUFBRTBKLEdBQUcsQ0FBQ1osSUFBSSxDQUFDO01BQUU3SSxZQUFZLEVBQUV5SixHQUFHLENBQUNaLElBQUk7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ25uQmpZLEtBQUssRUFBRTRZLEdBQUcsQ0FBQztJQUFFN1MsUUFBUSxFQUFFaVQsR0FBRyxDQUFDWixHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRTlTLE9BQU8sRUFBRTBULEdBQUcsQ0FBQ3BCLEtBQUssQ0FBQztJQUFFclMsT0FBTyxFQUFFeVQsR0FBRyxDQUFDUCxHQUFHLENBQUM0QixLQUFLLENBQUMsQ0FBQztJQUFFNVUsSUFBSSxFQUFFdVQsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRTVTLE1BQU0sRUFBRXlTLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQUVuUyxPQUFPLEVBQUV3UyxHQUFHLENBQUNMLElBQUksQ0FBQyxXQUFXLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDdEsxWSxJQUFJLEVBQUUyWSxHQUFHLENBQUM7SUFBRW5TLFFBQVEsRUFBRW9TLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztJQUFFelIsTUFBTSxFQUFFc1MsR0FBRyxDQUFDWixHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7SUFBRTNTLElBQUksRUFBRXVULEdBQUcsQ0FBQ0csSUFBSSxDQUFDO0lBQUV4UyxVQUFVLEVBQUVxUyxHQUFHLENBQUM7TUFBRTFWLElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQztJQUFFa0QsT0FBTyxFQUFFd1MsR0FBRyxDQUFDTCxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3JLelksSUFBSSxFQUFFMFksR0FBRyxDQUFDO0lBQUU4RixjQUFjLEVBQUUxRixHQUFHLENBQUNKLEdBQUcsQ0FBQztNQUFDK0YsUUFBUSxFQUFDOUYsR0FBRyxDQUFDRCxHQUFHLENBQUM7UUFBQ2xOLFFBQVEsRUFBQ21OLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQUNxQixlQUFlLEVBQUNoQixHQUFHLENBQUNMLFNBQVMsQ0FBQyxVQUFVLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQztNQUFDcUIsZUFBZSxFQUFDaEIsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7TUFBQ29HLHFCQUFxQixFQUFDL0YsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7TUFBQ3FHLGdCQUFnQixFQUFDaEcsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7TUFBQ3NHLGNBQWMsRUFBQ2pHLEdBQUcsQ0FBQztRQUFDdlYsSUFBSSxFQUFDO01BQVUsQ0FBQyxDQUFDO01BQUN5YixTQUFTLEVBQUNsRyxHQUFHLENBQUNULEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO01BQUM0RyxXQUFXLEVBQUNuRyxHQUFHLENBQUM7UUFBQ3ZWLElBQUksRUFBQztNQUFNLENBQUMsQ0FBQztNQUFDMmIsV0FBVyxFQUFDcEcsR0FBRyxDQUFDO1FBQUN2VixJQUFJLEVBQUM7TUFBTSxDQUFDLENBQUM7TUFBQzJDLElBQUksRUFBQzRTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBQyxRQUFRLEVBQUMsT0FBTyxDQUFDLENBQUM7TUFBQytHLE9BQU8sRUFBQ3JHLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxHQUFDLElBQUksQ0FBQyxDQUFDO01BQUN5SCxVQUFVLEVBQUN0RyxHQUFHLENBQUNKLEdBQUcsQ0FBQ0csR0FBRyxDQUFDO1FBQUNsTixRQUFRLEVBQUNtTixHQUFHLENBQUNMLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUFDcUIsZUFBZSxFQUFDaEIsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFBQzRHLFFBQVEsRUFBQ3ZHLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDO01BQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDMkgsa0JBQWtCLEVBQUN4RyxHQUFHLENBQUNKLEdBQUcsQ0FBQ0csR0FBRyxDQUFDO1FBQUNsTixRQUFRLEVBQUNtTixHQUFHLENBQUNMLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQUNxQixlQUFlLEVBQUNoQixHQUFHLENBQUNMLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUFDOEcsZ0JBQWdCLEVBQUN6RyxHQUFHLENBQUNMLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUFDNEcsUUFBUSxFQUFDdkcsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBQyxHQUFHLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUM2SCxnQkFBZ0IsRUFBQzFHLEdBQUcsQ0FBQ0osR0FBRyxDQUFDRyxHQUFHLENBQUM7UUFBQ2lCLGVBQWUsRUFBQ2hCLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQUNnSCxlQUFlLEVBQUMzRyxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQztNQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQytILGFBQWEsRUFBQzVHLEdBQUcsQ0FBQ0osR0FBRyxDQUFDRyxHQUFHLENBQUM7UUFBQ2lCLGVBQWUsRUFBQ2hCLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQUM5TCxXQUFXLEVBQUNtTSxHQUFHLENBQUM7VUFBQ3ZWLElBQUksRUFBQztRQUFNLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQUVtQyxJQUFJLEVBQUVvVCxHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFdlMsYUFBYSxFQUFFb1MsR0FBRyxDQUFDTCxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRTlSLGNBQWMsRUFBRW1TLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUFFN1IsWUFBWSxFQUFFa1MsR0FBRyxDQUFDWixHQUFHLENBQUMsTUFBTSxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3JuQ2pZLE9BQU8sRUFBRXlZLEdBQUcsQ0FBQztJQUFFN1IsUUFBUSxFQUFFOFIsR0FBRyxDQUFDRixJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRW5ULE9BQU8sRUFBRXdULEdBQUcsQ0FBQ3hULE9BQU8sQ0FBQztJQUFFRSxXQUFXLEVBQUVzVCxHQUFHLENBQUNHLElBQUksQ0FBQztJQUFFblMsYUFBYSxFQUFFZ1MsR0FBRyxDQUFDcEIsS0FBSztFQUFFLENBQUMsQ0FBQztFQUN4SHhYLEtBQUssRUFBRXdZLEdBQUcsQ0FBQztJQUFFcFQsT0FBTyxFQUFFcVQsR0FBRyxDQUFDclQsT0FBTyxDQUFDO0lBQUVDLElBQUksRUFBRW9ULEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0lBQUV6VCxXQUFXLEVBQUVtVCxHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFbFMsUUFBUSxFQUFFNFIsR0FBRyxDQUFDRixJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRStHLGVBQWUsRUFBRTFHLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQUV6UixTQUFTLEVBQUU4UixHQUFHLENBQUNaLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUFFalIsU0FBUyxFQUFFNlIsR0FBRyxDQUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRXZSLEtBQUssRUFBRTRSLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUV6UyxLQUFLLEVBQUVxVCxHQUFHLENBQUNHLElBQUksQ0FBQztJQUFFOVIsU0FBUyxFQUFFMlIsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRTdSLE9BQU8sRUFBRTBSLEdBQUcsQ0FBQ0csSUFBSSxDQUFDO0lBQUU1UixjQUFjLEVBQUV5UixHQUFHLENBQUNHLElBQUksQ0FBQztJQUFFM1IsT0FBTyxFQUFFd1IsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUFFcFEsVUFBVSxFQUFFdVIsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUFFblEsUUFBUSxFQUFFc1IsR0FBRyxDQUFDUCxHQUFHLENBQUNELFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUFFMEMsS0FBSyxFQUFFbEMsR0FBRyxDQUFDa0MsS0FBSztFQUFFLENBQUMsQ0FBQztFQUNyYzdhLElBQUksRUFBRXVZLEdBQUcsQ0FBQztJQUFFalIsT0FBTyxFQUFFa1IsR0FBRyxDQUFDVCxHQUFHLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQUV4USxXQUFXLEVBQUVpUixHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFM1MsT0FBTyxFQUFFd1MsR0FBRyxDQUFDTCxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFBRTlRLGdCQUFnQixFQUFFbVIsR0FBRyxDQUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRTdRLFFBQVEsRUFBRWtSLEdBQUcsQ0FBQ2tCLGdCQUFnQjtFQUFFLENBQUMsQ0FBQztFQUN0TDVaLFNBQVMsRUFBRXNZLEdBQUcsQ0FBQztJQUFFN1EsUUFBUSxFQUFFOFEsR0FBRyxDQUFDVixFQUFFLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFBRW5RLE9BQU8sRUFBRWdSLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQUVuUSxZQUFZLEVBQUUrUSxHQUFHLENBQUNaLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUFFbFEsY0FBYyxFQUFFOFEsR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFcUQsT0FBTyxFQUFFL0IsR0FBRyxDQUFDK0IsT0FBTyxDQUFDO0lBQUU1UyxJQUFJLEVBQUU2USxHQUFHLENBQUNJLElBQUksQ0FBQztJQUFFL1EsZUFBZSxFQUFFMlEsR0FBRyxDQUFDYixFQUFFLENBQUMsZUFBZSxFQUFFLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUFFN1AsVUFBVSxFQUFFMFEsR0FBRyxDQUFDWixHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFBRThDLEtBQUssRUFBRWxDLEdBQUcsQ0FBQ2tDLEtBQUs7RUFBRSxDQUFDLENBQUM7RUFDN1czYSxTQUFTLEVBQUVxWSxHQUFHLENBQUM7SUFBRXJRLE1BQU0sRUFBRXNRLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUU1UCxJQUFJLEVBQUVxUSxHQUFHLENBQUNVLEtBQUssQ0FBQ25CLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTNQLFVBQVUsQ0FBQyxDQUFDO0lBQUVDLFFBQVEsRUFBRW1RLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFBRXBWLEtBQUssRUFBRWlXLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRS9PLFNBQVMsRUFBRXFRLEdBQUcsQ0FBQ0ksSUFBSSxDQUFDO0lBQUV4USxTQUFTLEVBQUVvUSxHQUFHLENBQUNMLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUFFOVAsUUFBUSxFQUFFbVEsR0FBRyxDQUFDbkIsR0FBRyxDQUFDVSxTQUFTLEVBQUVBLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUFFelAsWUFBWSxFQUFFa1EsR0FBRyxDQUFDWixHQUFHLENBQUMsZUFBZSxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQzVUNVgsVUFBVSxFQUFFb1ksR0FBRyxDQUFDO0lBQUU3UCxPQUFPLEVBQUU4UCxHQUFHLENBQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUFFM1AsT0FBTyxFQUFFNlAsR0FBRyxDQUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFBRTFQLFFBQVEsRUFBRTRQLEdBQUcsQ0FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUV6UCxPQUFPLEVBQUUyUCxHQUFHLENBQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUFFeFAsYUFBYSxFQUFFNlAsR0FBRyxDQUFDWixHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRWhQLFVBQVUsRUFBRTRQLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDRyxHQUFHLENBQUM7TUFBRTlWLEdBQUcsRUFBRStWLEdBQUcsQ0FBQy9WLEdBQUcsQ0FBQztNQUFFUSxJQUFJLEVBQUV1VixHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO01BQUVzRixPQUFPLEVBQUV6RSxHQUFHLENBQUNkLEtBQUs7SUFBRSxDQUFDLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUMvU3pYLGFBQWEsRUFBRW1ZLEdBQUcsQ0FBQztJQUFFM1UsSUFBSSxFQUFFNFUsR0FBRyxDQUFDTSxJQUFJLENBQUM7SUFBRTlQLFNBQVMsRUFBRTJQLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUU5TyxZQUFZLEVBQUUwUCxHQUFHLENBQUNaLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUFFN08sTUFBTSxFQUFFeVAsR0FBRyxDQUFDTCxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFBRW5QLGFBQWEsRUFBRXdQLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQUVnSCxpQkFBaUIsRUFBRTNHLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQUVpSCxPQUFPLEVBQUU1RyxHQUFHLENBQUNKLEdBQUcsQ0FBQztNQUFFM1MsSUFBSSxFQUFFNFMsR0FBRyxDQUFDVixFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztNQUFFMEgsWUFBWSxFQUFFaEgsR0FBRyxDQUFDO1FBQUV2VixJQUFJLEVBQUU7TUFBVyxDQUFDLENBQUM7TUFBRThCLE1BQU0sRUFBRXlULEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFFb0ksUUFBUSxFQUFFakgsR0FBRyxDQUFDSixHQUFHLENBQUNHLEdBQUcsQ0FBQztRQUFFeFgsTUFBTSxFQUFFeVgsR0FBRyxDQUFDcE4sTUFBTSxDQUFDO1FBQUVxRSxNQUFNLEVBQUUrSSxHQUFHLENBQUNwTixNQUFNO01BQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQUVzVSxpQkFBaUIsRUFBRS9HLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUVxSCxlQUFlLEVBQUVoSCxHQUFHLENBQUNiLEVBQUUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxFQUFFLGtCQUFrQixFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQUU4SCxlQUFlLEVBQUVqSCxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUN4a0JoWCxLQUFLLEVBQUVrWSxHQUFHLENBQUM7SUFBRTlWLEdBQUcsRUFBRStWLEdBQUcsQ0FBQy9WLEdBQUcsQ0FBQztJQUFFMkcsZUFBZSxFQUFFb1AsR0FBRyxDQUFDVCxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRXhRLFdBQVcsRUFBRW9SLEdBQUcsQ0FBQ0csSUFBSSxDQUFDO0lBQUV6UCxPQUFPLEVBQUVzUCxHQUFHLENBQUNMLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUFFaFAsZUFBZSxFQUFFcVAsR0FBRyxDQUFDUCxHQUFHLENBQUNnQyxVQUFVLENBQUMsQ0FBQztJQUFFN1EsZUFBZSxFQUFFb1AsR0FBRyxDQUFDTCxJQUFJLENBQUMsZUFBZSxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ2xOaFksSUFBSSxFQUFFaVksR0FBRyxDQUFDO0lBQUVuVCxJQUFJLEVBQUVvVCxHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFdFAsWUFBWSxFQUFFbVAsR0FBRyxDQUFDTCxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFBRTdPLFNBQVMsRUFBRWtQLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQUVyVCxPQUFPLEVBQUUwVCxHQUFHLENBQUNwQixLQUFLLENBQUM7SUFBRXJTLE9BQU8sRUFBRXlULEdBQUcsQ0FBQ1AsR0FBRyxDQUFDNEIsS0FBSyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ25KelosUUFBUSxFQUFFZ1ksR0FBRyxDQUFDO0lBQUU5VixHQUFHLEVBQUUrVixHQUFHLENBQUMvVixHQUFHLENBQUM7SUFBRWlILFNBQVMsRUFBRThPLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFBRW5PLEtBQUssRUFBRTZPLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEdBQUd2VixNQUFNLENBQUMsQ0FBQztJQUFFcUgsT0FBTyxFQUFFNE8sR0FBRyxDQUFDWCxLQUFLLENBQUM7SUFBRWhPLE9BQU8sRUFBRTJPLEdBQUcsQ0FBQzNPLE9BQU8sQ0FBQztJQUFFdEMsV0FBVyxFQUFFb1IsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRXhSLE9BQU8sRUFBRXFSLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUU4SCxPQUFPLEVBQUVsSCxHQUFHLENBQUM7TUFBRTFWLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUFFOEcsa0JBQWtCLEVBQUU0TyxHQUFHLENBQUNaLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQUUvTixVQUFVLEVBQUUyTyxHQUFHLENBQUNQLEdBQUcsQ0FBQ29DLFNBQVMsQ0FBQyxDQUFDO0lBQUVsUixlQUFlLEVBQUVxUCxHQUFHLENBQUNQLEdBQUcsQ0FBQ2dDLFVBQVUsQ0FBQyxDQUFDO0lBQUUwRixVQUFVLEVBQUVuSCxHQUFHLENBQUNQLEdBQUcsQ0FBQ0csR0FBRyxDQUFDO01BQUUxQixVQUFVLEVBQUUyQixHQUFHLENBQUNULEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztNQUFFalQsS0FBSyxFQUFFMFQsR0FBRyxDQUFDWCxLQUFLLENBQUM7TUFBRWtJLFVBQVUsRUFBRXZILEdBQUcsQ0FBQ1gsS0FBSyxDQUFDO01BQUU5UyxNQUFNLEVBQUV5VCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBRW5NLFVBQVUsRUFBRXlOLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDK0IsU0FBUyxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFbFEsbUJBQW1CLEVBQUUwTyxHQUFHLENBQUNqQixJQUFJO0VBQUUsQ0FBQyxDQUFDO0VBQ3BqQmxYLE1BQU0sRUFBRStYLEdBQUcsQ0FBQztJQUFFck8sU0FBUyxFQUFFc08sR0FBRyxDQUFDVixFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQUUzTixRQUFRLEVBQUVxTyxHQUFHLENBQUNULEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRWpULEtBQUssRUFBRTZULEdBQUcsQ0FBQ2QsS0FBSyxDQUFDO0lBQUV2UCxTQUFTLEVBQUVxUSxHQUFHLENBQUNJLElBQUksQ0FBQztJQUFFM08sVUFBVSxFQUFFdU8sR0FBRyxDQUFDWixHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7SUFBRWhULE1BQU0sRUFBRTRULEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRWtELGdCQUFnQixFQUFFNUIsR0FBRyxDQUFDd0IsU0FBUztFQUFFLENBQUMsQ0FBQztFQUNoUTFaLFNBQVMsRUFBRThYLEdBQUcsQ0FBQztJQUFFbE8sU0FBUyxFQUFFbU8sR0FBRyxDQUFDVCxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUV6TixTQUFTLEVBQUVrTyxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQUV2UyxLQUFLLEVBQUUwVCxHQUFHLENBQUNVLEtBQUssQ0FBQ3JCLEtBQUssRUFBRUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUV4TixTQUFTLEVBQUVpTyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxjQUFjLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUFFdE4sUUFBUSxFQUFFbU8sR0FBRyxDQUFDWixHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFBRXRPLFNBQVMsRUFBRWtQLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUMsQ0FBQztJQUFFN04sZ0JBQWdCLEVBQUVrTyxHQUFHLENBQUN2TixNQUFNLENBQUM7SUFBRTNELFFBQVEsRUFBRWtSLEdBQUcsQ0FBQ2tCLGdCQUFnQixDQUFDO0lBQUU5VSxNQUFNLEVBQUU0VCxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUNyWDNXLFVBQVUsRUFBRTZYLEdBQUcsQ0FBQztJQUFFN04sUUFBUSxFQUFFOE4sR0FBRyxDQUFDTSxJQUFJLENBQUM7SUFBRW5PLE1BQU0sRUFBRTZOLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0lBQUVsTyxnQkFBZ0IsRUFBRTROLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUUsa0JBQWtCLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUFFak4saUJBQWlCLEVBQUU4TixHQUFHLENBQUNMLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUFFeE4sT0FBTyxFQUFFNk4sR0FBRyxDQUFDTCxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRXZOLFNBQVMsRUFBRTROLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQUV0TixZQUFZLEVBQUUyTixHQUFHLENBQUNMLElBQUksQ0FBQyxZQUFZLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFBRTBILGVBQWUsRUFBRXJILEdBQUcsQ0FBQ0ssTUFBTSxDQUFDVixJQUFJLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxFQUFFUCxHQUFHLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFBRTlNLFFBQVEsRUFBRTBOLEdBQUcsQ0FBQ2xOLFdBQVcsQ0FBQztJQUFFd1Usb0JBQW9CLEVBQUV0SCxHQUFHLENBQUN2TixNQUFNLENBQUM7SUFBRUYsVUFBVSxFQUFFeU4sR0FBRyxDQUFDUCxHQUFHLENBQUMrQixTQUFTLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDN2dCeFosVUFBVSxFQUFFNFgsR0FBRyxDQUFDO0lBQUVwTixZQUFZLEVBQUVxTixHQUFHLENBQUNULEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUFFM00sTUFBTSxFQUFFb04sR0FBRyxDQUFDcE4sTUFBTSxDQUFDO0lBQUVFLEtBQUssRUFBRWtOLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUFFdk0sSUFBSSxFQUFFaU4sR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQUV4UCxTQUFTLEVBQUVxUSxHQUFHLENBQUNJLElBQUksQ0FBQztJQUFFdk4sZ0JBQWdCLEVBQUVtTixHQUFHLENBQUNMLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUFFN00sV0FBVyxFQUFFa04sR0FBRyxDQUFDbE4sV0FBVztFQUFFLENBQUMsQ0FBQztFQUN0UjdLLFVBQVUsRUFBRTJYLEdBQUcsQ0FBQztJQUFFK0QsU0FBUyxFQUFFM0QsR0FBRyxDQUFDZixJQUFJLENBQUM7SUFBRWxNLGdCQUFnQixFQUFFOE0sR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRXhNLFlBQVksRUFBRTZNLEdBQUcsQ0FBQ3FELE9BQU8sQ0FBQztJQUFFTSxpQkFBaUIsRUFBRXhELEdBQUcsQ0FBQ2tELE9BQU8sQ0FBQztJQUFFcUUsbUJBQW1CLEVBQUV2SCxHQUFHLENBQUNQLEdBQUcsQ0FBQ3FELGtCQUFrQixDQUFDLENBQUM7SUFBRTBFLGVBQWUsRUFBRXhILEdBQUcsQ0FBQztNQUFFMVYsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDO0lBQUU0SSxNQUFNLEVBQUU4TSxHQUFHLENBQUNiLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQUVoTSxPQUFPLEVBQUU2TSxHQUFHLENBQUNaLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUFFcUksU0FBUyxFQUFFekgsR0FBRyxDQUFDSixHQUFHLENBQUM7TUFBRThILGtCQUFrQixFQUFFN0gsR0FBRyxDQUFDVCxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7TUFBRXlCLGVBQWUsRUFBRWhCLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO01BQUVxSCxZQUFZLEVBQUVoSCxHQUFHLENBQUM7UUFBRXZWLElBQUksRUFBRTtNQUFXLENBQUMsQ0FBQztNQUFFNEwsTUFBTSxFQUFFMkosR0FBRyxDQUFDVixFQUFFLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQztJQUFFLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUN2Z0JqWCxLQUFLLEVBQUUwWCxHQUFHLENBQUM7SUFBRTdNLGdCQUFnQixFQUFFOE0sR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRXBNLGlCQUFpQixFQUFFeU0sR0FBRyxDQUFDVCxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRS9MLEtBQUssRUFBRXdNLEdBQUcsQ0FBQ0osR0FBRyxDQUFDRyxHQUFHLENBQUM7TUFBRStILE1BQU0sRUFBRTlILEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO01BQUVwUCxPQUFPLEVBQUU2UCxHQUFHLENBQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztNQUFFeUQsTUFBTSxFQUFFdkQsR0FBRyxDQUFDcUQsT0FBTyxDQUFDO01BQUVHLEtBQUssRUFBRXhELEdBQUcsQ0FBQ3FELE9BQU8sQ0FBQztNQUFFTSxpQkFBaUIsRUFBRXhELEdBQUcsQ0FBQ2tELE9BQU8sQ0FBQztNQUFFTyxnQkFBZ0IsRUFBRXpELEdBQUcsQ0FBQ1AsR0FBRyxDQUFDcUQsa0JBQWtCLENBQUMsQ0FBQztNQUFFdlIsU0FBUyxFQUFFeU8sR0FBRyxDQUFDYixFQUFFLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO01BQUVvRSxZQUFZLEVBQUV2RCxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO01BQUVpRixTQUFTLEVBQUUzRCxHQUFHLENBQUNmLElBQUksQ0FBQztNQUFFekwsWUFBWSxFQUFFd00sR0FBRyxDQUFDYixFQUFFLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztNQUFFdUUsY0FBYyxFQUFFMUQsR0FBRyxDQUFDSyxNQUFNLENBQUNuQixLQUFLLEVBQUVFLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFb0ksZUFBZSxFQUFFeEgsR0FBRyxDQUFDO01BQUUxVixJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7SUFBRXNkLHFCQUFxQixFQUFFNUgsR0FBRyxDQUFDSyxNQUFNLENBQUNuQixLQUFLLEVBQUVFLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7SUFBRXlJLG9CQUFvQixFQUFFN0gsR0FBRyxDQUFDa0QsT0FBTyxDQUFDO0lBQUU0RSxpQkFBaUIsRUFBRTlILEdBQUcsQ0FBQ0osR0FBRyxDQUFDO01BQUVtSSxTQUFTLEVBQUUvSCxHQUFHLENBQUNLLE1BQU0sQ0FBQ25CLEtBQUssRUFBRUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7TUFBRTRJLFFBQVEsRUFBRWhJLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDbkIsS0FBSyxFQUFFRSxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQUU2SSxnQkFBZ0IsRUFBRWpJLEdBQUcsQ0FBQ2YsSUFBSSxDQUFDO0lBQUUzTCxJQUFJLEVBQUUwTSxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUVuTCxhQUFhLEVBQUV5TSxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUVsTCxZQUFZLEVBQUV3TSxHQUFHLENBQUNiLEVBQUUsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQUVvRixRQUFRLEVBQUV2RSxHQUFHLENBQUN1RSxRQUFRLENBQUM7SUFBRTJELHNCQUFzQixFQUFFbEksR0FBRyxDQUFDSixHQUFHLENBQUM7TUFBRXVJLGVBQWUsRUFBRXRJLEdBQUcsQ0FBQztRQUFFdlYsSUFBSSxFQUFFO01BQVcsQ0FBQyxDQUFDO01BQUU4ZCxRQUFRLEVBQUV2SSxHQUFHLENBQUNGLElBQUksQ0FBQyxPQUFPLENBQUM7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUFFMEksY0FBYyxFQUFFckksR0FBRyxDQUFDSixHQUFHLENBQUM7TUFBRTBJLGFBQWEsRUFBRXpJLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO01BQUV5QixlQUFlLEVBQUVoQixHQUFHLENBQUNMLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztNQUFFcUgsWUFBWSxFQUFFaEgsR0FBRyxDQUFDO1FBQUV2VixJQUFJLEVBQUU7TUFBVyxDQUFDLENBQUM7TUFBRThJLGlCQUFpQixFQUFFNE0sR0FBRyxDQUFDWixHQUFHLENBQUMsWUFBWSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFBRW5TLElBQUksRUFBRStTLEdBQUcsQ0FBQ2IsRUFBRSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRXlFLFdBQVcsRUFBRTVELEdBQUcsQ0FBQ08sS0FBSyxDQUFDcUQsV0FBVyxFQUFFekUsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ2owQ2hYLFVBQVUsRUFBRXlYLEdBQUcsQ0FBQztJQUFFbk0sU0FBUyxFQUFFb00sR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUFFaEwsV0FBVyxFQUFFbU0sR0FBRyxDQUFDO01BQUV2VixJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUM7SUFBRXFKLFFBQVEsRUFBRWtNLEdBQUcsQ0FBQ2hCLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRWpMLFNBQVMsRUFBRWlNLEdBQUcsQ0FBQztNQUFFdlYsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDO0lBQUV1SixXQUFXLEVBQUVtTSxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUU2SixZQUFZLEVBQUV2SSxHQUFHLENBQUNaLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUFFb0osV0FBVyxFQUFFeEksR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFL0wsS0FBSyxFQUFFcU4sR0FBRyxDQUFDYixFQUFFLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUFFckwsZUFBZSxFQUFFa00sR0FBRyxDQUFDTCxJQUFJLENBQUMsWUFBWSxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQzNWdlgsTUFBTSxFQUFFd1gsR0FBRyxDQUFDO0lBQUU3TCxVQUFVLEVBQUU4TCxHQUFHLENBQUNWLEVBQUUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztJQUFFbkwsT0FBTyxFQUFFNkwsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUV6SyxVQUFVLEVBQUUrTCxHQUFHLENBQUM7TUFBRTFWLElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQztJQUFFNEosZUFBZSxFQUFFOEwsR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFdkssY0FBYyxFQUFFNkwsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRS9MLFlBQVksRUFBRTRMLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQUUvSyxxQkFBcUIsRUFBRTJMLEdBQUcsQ0FBQ2pCLElBQUk7RUFBRSxDQUFDLENBQUM7RUFDdlExVyxHQUFHLEVBQUV1WCxHQUFHLENBQUM7SUFBRW5OLE1BQU0sRUFBRW9OLEdBQUcsQ0FBQ3BOLE1BQU0sQ0FBQztJQUFFNkIsT0FBTyxFQUFFdUwsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUFFdEssWUFBWSxFQUFFNEwsR0FBRyxDQUFDWixHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRS9PLFNBQVMsRUFBRTJQLEdBQUcsQ0FBQ1osR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUU3SyxVQUFVLEVBQUV5TCxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUVsSyxNQUFNLEVBQUV3TCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRTlLLE1BQU0sRUFBRXVMLEdBQUcsQ0FBQztNQUFFMVYsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDO0lBQUVvSyxTQUFTLEVBQUVzTCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRTVNLEtBQUssRUFBRXFOLEdBQUcsQ0FBQ3BCLEtBQUs7RUFBRSxDQUFDLENBQUM7RUFDL1J0VyxnQkFBZ0IsRUFBRXNYLEdBQUcsQ0FBQztJQUFFbk4sTUFBTSxFQUFFb04sR0FBRyxDQUFDcE4sTUFBTSxDQUFDO0lBQUVrQyxZQUFZLEVBQUVrTCxHQUFHLENBQUNoQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRTNLLFVBQVUsRUFBRW9MLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUFFMUssZ0JBQWdCLEVBQUVtTCxHQUFHLENBQUNaLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUFFdEssWUFBWSxFQUFFa0wsR0FBRyxDQUFDWixHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRTdPLE1BQU0sRUFBRXlQLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQUU1SyxPQUFPLEVBQUVpTCxHQUFHLENBQUNHLElBQUk7RUFBRSxDQUFDLENBQUM7RUFDbFE1WCxZQUFZLEVBQUVxWCxHQUFHLENBQUM7SUFBRTVLLFlBQVksRUFBRTZLLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQUVuSyxRQUFRLEVBQUU0SyxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQUV4SixVQUFVLEVBQUUySyxHQUFHLENBQUM7TUFBRXZWLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQztJQUFFVyxJQUFJLEVBQUU0VSxHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFeE4sS0FBSyxFQUFFcU4sR0FBRyxDQUFDYixFQUFFLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQztJQUFFaEssVUFBVSxFQUFFNkssR0FBRyxDQUFDUixTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRXBLLFlBQVksRUFBRTRLLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFdBQVcsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUNqUm5YLFNBQVMsRUFBRW9YLEdBQUcsQ0FBQztJQUFFNUssWUFBWSxFQUFFNkssR0FBRyxDQUFDVCxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7SUFBRW5LLFFBQVEsRUFBRTRLLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFBRXhKLFVBQVUsRUFBRTJLLEdBQUcsQ0FBQztNQUFFdlYsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDO0lBQUUrSyxhQUFhLEVBQUUySyxHQUFHLENBQUNaLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUFFaEwsWUFBWSxFQUFFNEwsR0FBRyxDQUFDWixHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRTlKLEtBQUssRUFBRTBLLEdBQUcsQ0FBQ0csSUFBSSxDQUFDO0lBQUV4TixLQUFLLEVBQUVxTixHQUFHLENBQUNiLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQztJQUFFaEssVUFBVSxFQUFFNkssR0FBRyxDQUFDUixTQUFTLENBQUMsVUFBVSxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3RVL1csV0FBVyxFQUFFbVgsR0FBRyxDQUFDO0lBQUVySyxTQUFTLEVBQUVzSyxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQUVwUyxPQUFPLEVBQUV1VCxHQUFHLENBQUNqQixLQUFLLENBQUM7SUFBRXBKLFFBQVEsRUFBRXdLLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDYixLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRTNKLFFBQVEsRUFBRStLLEdBQUcsQ0FBQ3BCLEtBQUssQ0FBQztJQUFFbkosVUFBVSxFQUFFdUssR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRXJSLFFBQVEsRUFBRWtSLEdBQUcsQ0FBQ2tCLGdCQUFnQixDQUFDO0lBQUUzTyxVQUFVLEVBQUV5TixHQUFHLENBQUNQLEdBQUcsQ0FBQytCLFNBQVMsQ0FBQyxDQUFDO0lBQUU5TCxZQUFZLEVBQUVzSyxHQUFHLENBQUNaLEdBQUcsQ0FBQyxXQUFXLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDM1AxVyxHQUFHLEVBQUVrWCxHQUFHLENBQUM7SUFBRWpLLE9BQU8sRUFBRWtLLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQUV4SixnQkFBZ0IsRUFBRWlLLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQUUvSyxZQUFZLEVBQUU0TCxHQUFHLENBQUNaLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUFFdkosV0FBVyxFQUFFbUssR0FBRyxDQUFDWixHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7SUFBRXRKLElBQUksRUFBRWtLLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDRyxHQUFHLENBQUM7TUFBRXhVLEVBQUUsRUFBRXlVLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO01BQUVySixPQUFPLEVBQUVrSyxHQUFHLENBQUNULEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztNQUFFcUosQ0FBQyxFQUFFNUksR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztNQUFFNkosQ0FBQyxFQUFFN0ksR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztNQUFFOVUsS0FBSyxFQUFFaVcsR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUN0Ui9WLFlBQVksRUFBRWlYLEdBQUcsQ0FBQztJQUFFN0osV0FBVyxFQUFFOEosR0FBRyxDQUFDVCxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRXBKLFNBQVMsRUFBRTZKLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQUVuSixTQUFTLEVBQUU0SixHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFBRWpKLE1BQU0sRUFBRThKLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRXZJLFlBQVksRUFBRTZKLEdBQUcsQ0FBQ2YsSUFBSSxDQUFDO0lBQUU3SSxZQUFZLEVBQUU0SixHQUFHLENBQUNmLElBQUksQ0FBQztJQUFFNUksUUFBUSxFQUFFMkosR0FBRyxDQUFDTCxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUU3USxRQUFRLEVBQUVrUixHQUFHLENBQUNrQixnQkFBZ0I7RUFBRSxDQUFDLENBQUM7RUFDM1B0WSxRQUFRLEVBQUVnWCxHQUFHLENBQUM7SUFBRXRKLFVBQVUsRUFBRXVKLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEdBQUczVixZQUFZLENBQUMsQ0FBQztJQUFFK00sTUFBTSxFQUFFc0osR0FBRyxDQUFDSixHQUFHLENBQUMrRSxlQUFlLENBQUMsQ0FBQztJQUFFNVYsV0FBVyxFQUFFb1IsR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFbEksT0FBTyxFQUFFd0osR0FBRyxDQUFDO01BQUUxVixJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7SUFBRW1NLFFBQVEsRUFBRXVKLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDO01BQUUvVixJQUFJLEVBQUU7SUFBUyxDQUFDLEVBQUVSLEdBQUcsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUN2TWpCLFVBQVUsRUFBRStXLEdBQUcsQ0FBQztJQUFFK0ksT0FBTyxFQUFFM0ksR0FBRyxDQUFDYixFQUFFLENBQUMsWUFBWSxDQUFDLENBQUM7SUFBRWxTLElBQUksRUFBRTRTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUFFeEksS0FBSyxFQUFFcUosR0FBRyxDQUFDO01BQUUxVixJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUM7SUFBRW9NLFNBQVMsRUFBRXNKLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUFFL0ksSUFBSSxFQUFFb0osR0FBRyxDQUFDSixHQUFHLENBQUM7TUFBRS9JLEtBQUssRUFBRWdKLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDO01BQUVsSixTQUFTLEVBQUU0SixHQUFHLENBQUNWLEVBQUUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQzlQclcsTUFBTSxFQUFFOFcsR0FBRyxDQUFDO0lBQUU5SSxNQUFNLEVBQUUrSSxHQUFHLENBQUNVLEtBQUssQ0FBQzlOLE1BQU0sRUFBRTJNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFckksZUFBZSxFQUFFOEksR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRS9TLElBQUksRUFBRW9ULEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0lBQUV4TixLQUFLLEVBQUVrTixHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQUVuSSxVQUFVLEVBQUVnSixHQUFHLENBQUNSLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUFFdkksVUFBVSxFQUFFK0ksR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFeEgsVUFBVSxFQUFFOEksR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBQ3lJLFlBQVksRUFBQzVJLEdBQUcsQ0FBQ0osR0FBRyxDQUFDO01BQUNpSixVQUFVLEVBQUNoSixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQ29LLGNBQWMsRUFBQ2pKLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDcUssT0FBTyxFQUFDbEosR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUNzSyxhQUFhLEVBQUNuSixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQ3VLLFlBQVksRUFBQ2pKLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDd0ssY0FBYyxFQUFDbEosR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUN5SyxXQUFXLEVBQUNuSixHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQzBLLE9BQU8sRUFBQ3BKLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUNVLFNBQVMsRUFBQyxJQUFJLENBQUMsQ0FBQztNQUFDOEosS0FBSyxFQUFDckosR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBQ1UsU0FBUyxFQUFDLElBQUksQ0FBQyxDQUFDO01BQUMrSixjQUFjLEVBQUN6SixHQUFHLENBQUNuQixHQUFHLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxDQUFDO01BQUM2SyxlQUFlLEVBQUMxSixHQUFHLENBQUNuQixHQUFHLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxDQUFDO01BQUN6SCxVQUFVLEVBQUM0SSxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDO01BQUM4SyxhQUFhLEVBQUMzSixHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLEVBQUMsT0FBTyxFQUFDLFVBQVUsQ0FBQztJQUFDLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUNub0JwVyxjQUFjLEVBQUU2VyxHQUFHLENBQUM7SUFBRXpJLGNBQWMsRUFBRTBJLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0lBQUUvSSxVQUFVLEVBQUV5SSxHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFOUksS0FBSyxFQUFFd0ksR0FBRyxDQUFDTSxJQUFJLENBQUM7SUFBRTdJLElBQUksRUFBRXVJLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0lBQUVuUCxLQUFLLEVBQUU2TyxHQUFHLENBQUNNLElBQUksQ0FBQztJQUFFNUksY0FBYyxFQUFFeUksR0FBRyxDQUFDTCxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUVuSSxXQUFXLEVBQUV3SSxHQUFHLENBQUNMLElBQUksQ0FBQyxVQUFVLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDL0wzVyxRQUFRLEVBQUU0VyxHQUFHLENBQUM7SUFBRW5JLE9BQU8sRUFBRW9JLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFdFMsTUFBTSxFQUFFeVQsR0FBRyxDQUFDTSxJQUFJLENBQUM7SUFBRXBKLGVBQWUsRUFBRThJLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQUU5SCxPQUFPLEVBQUVtSSxHQUFHLENBQUNWLEVBQUUsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQUV0UCxRQUFRLEVBQUVtUSxHQUFHLENBQUNwQixLQUFLLENBQUM7SUFBRWpILGNBQWMsRUFBRXFJLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDYixLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRWhILFNBQVMsRUFBRW9JLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDLFFBQVEsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUMxUDFXLGFBQWEsRUFBRTJXLEdBQUcsQ0FBQztJQUFFNVEsT0FBTyxFQUFFNlEsR0FBRyxDQUFDVCxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7SUFBRXZILE1BQU0sRUFBRWdJLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0lBQUVySSxRQUFRLEVBQUVrSSxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUUzRyxRQUFRLEVBQUVpSSxHQUFHLENBQUNHLElBQUksQ0FBQztJQUFFbkksTUFBTSxFQUFFZ0ksR0FBRyxDQUFDZCxLQUFLLENBQUM7SUFBRWpILE9BQU8sRUFBRStILEdBQUcsQ0FBQ1osR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQUVsSCxPQUFPLEVBQUU4SCxHQUFHLENBQUNMLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQUV4SCxxQkFBcUIsRUFBRTZILEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQzFPeFYsZUFBZSxFQUFFMFcsR0FBRyxDQUFDO0lBQUV4SCxTQUFTLEVBQUV5SCxHQUFHLENBQUNGLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBRWhOLEtBQUssRUFBRWtOLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRSxjQUFjLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFBRTlHLFFBQVEsRUFBRXdILEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBQUVuSSxVQUFVLEVBQUVnSixHQUFHLENBQUNSLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUFFbE4sUUFBUSxFQUFFME4sR0FBRyxDQUFDSixHQUFHLENBQUM7TUFBRTZKLElBQUksRUFBRTVKLEdBQUcsQ0FBQztRQUFFdlYsSUFBSSxFQUFFO01BQU8sQ0FBQyxDQUFDO01BQUVvZixRQUFRLEVBQUU3SixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQUVwRyxTQUFTLEVBQUUwSCxHQUFHLENBQUNMLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQUVwSCxRQUFRLEVBQUV5SCxHQUFHLENBQUN6SCxRQUFRLENBQUM7SUFBRUMsY0FBYyxFQUFFd0gsR0FBRyxDQUFDdEIsR0FBRyxDQUFDLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDcmJ2VixhQUFhLEVBQUV5VyxHQUFHLENBQUM7SUFBRStKLGlCQUFpQixFQUFFM0osR0FBRyxDQUFDWixHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7SUFBRXdLLHdCQUF3QixFQUFFNUosR0FBRyxDQUFDUCxHQUFHLENBQUNELFNBQVMsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUFFL0csTUFBTSxFQUFFb0gsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQztJQUFFekcsY0FBYyxFQUFFbUgsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFBRS9TLElBQUksRUFBRXVULEdBQUcsQ0FBQ0csSUFBSSxDQUFDO0lBQUV4SCxTQUFTLEVBQUVxSCxHQUFHLENBQUM7TUFBRTFWLElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQztJQUFFc08sbUJBQW1CLEVBQUVvSCxHQUFHLENBQUNaLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQUV0TyxTQUFTLEVBQUVrUCxHQUFHLENBQUNMLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBRTlHLFdBQVcsRUFBRW1ILEdBQUcsQ0FBQ2pCLElBQUk7RUFBRSxDQUFDLENBQUM7RUFDeFozVixVQUFVLEVBQUV3VyxHQUFHLENBQUM7SUFBRTlHLFdBQVcsRUFBRStHLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUV0USxRQUFRLEVBQUUrUSxHQUFHLENBQUNxQixnQkFBZ0IsQ0FBQztJQUFFbkksV0FBVyxFQUFFaUgsR0FBRyxDQUFDcEIsS0FBSyxDQUFDO0lBQUU1RixVQUFVLEVBQUVnSCxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUV6RixRQUFRLEVBQUUrRyxHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUV4RixRQUFRLEVBQUU4RyxHQUFHLENBQUNHLElBQUksQ0FBQztJQUFFNU4sVUFBVSxFQUFFeU4sR0FBRyxDQUFDUCxHQUFHLENBQUMrQixTQUFTLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDck5uWSxpQkFBaUIsRUFBRXVXLEdBQUcsQ0FBQztJQUFFOVYsR0FBRyxFQUFFK1YsR0FBRyxDQUFDL1YsR0FBRyxDQUFDO0lBQUVxUCxLQUFLLEVBQUUwRyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFBRS9GLFNBQVMsRUFBRXlHLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFBRXJGLFVBQVUsRUFBRXdHLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFBRXBGLGFBQWEsRUFBRXVHLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUFFdlEsV0FBVyxFQUFFb1IsR0FBRyxDQUFDRyxJQUFJLENBQUM7SUFBRTVHLFVBQVUsRUFBRXlHLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDUCxLQUFLLENBQUMsQ0FBQztJQUFFMUYsaUJBQWlCLEVBQUV3RyxHQUFHLENBQUNMLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQUVuSixPQUFPLEVBQUV3SixHQUFHLENBQUNwQixLQUFLO0VBQUUsQ0FBQyxDQUFDO0VBQzlTdFYsUUFBUSxFQUFFc1csR0FBRyxDQUFDO0lBQUVuRyxZQUFZLEVBQUVvRyxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQUVoTCxXQUFXLEVBQUVtTSxHQUFHLENBQUM7TUFBRXZWLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQztJQUFFb1AsU0FBUyxFQUFFbUcsR0FBRyxDQUFDVixFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7SUFBRXhGLGdCQUFnQixFQUFFcUcsR0FBRyxDQUFDUCxHQUFHLENBQUNELFNBQVMsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUFFNUYsVUFBVSxFQUFFb0csR0FBRyxDQUFDO01BQUUxVixJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7SUFBRXVQLHlCQUF5QixFQUFFbUcsR0FBRyxDQUFDUCxHQUFHLENBQUNELFNBQVMsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDalJqVyxrQkFBa0IsRUFBRXFXLEdBQUcsQ0FBQztJQUFFaUssWUFBWSxFQUFDN0osR0FBRyxDQUFDSyxNQUFNLENBQUNiLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBQ0EsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztJQUFDc0ssYUFBYSxFQUFDOUosR0FBRyxDQUFDUCxHQUFHLENBQUNHLEdBQUcsQ0FBQztNQUFDaUIsZUFBZSxFQUFDaEIsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7TUFBQ3VHLFNBQVMsRUFBQ2xHLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7TUFBQ29ILGVBQWUsRUFBQzNHLEdBQUcsQ0FBQ2IsUUFBUTtJQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQ2xGLFFBQVEsRUFBRStGLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFBRTNFLFdBQVcsRUFBRThGLEdBQUcsQ0FBQ0YsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUFFM0YsVUFBVSxFQUFFNkYsR0FBRyxDQUFDO01BQUV2VixJQUFJLEVBQUU7SUFBYyxDQUFDLENBQUM7SUFBRTJQLFlBQVksRUFBRStGLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDTixFQUFFLENBQUMsR0FBRzNWLFlBQVksQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQUUwUSxjQUFjLEVBQUU4RixHQUFHLENBQUNQLEdBQUcsQ0FBQ2YsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQUV2RSxVQUFVLEVBQUU2RixHQUFHLENBQUNsTixXQUFXLENBQUM7SUFBRXNILGtCQUFrQixFQUFFNEYsR0FBRyxDQUFDakIsSUFBSSxDQUFDO0lBQUUxRSxXQUFXLEVBQUUyRixHQUFHLENBQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUVwRSxXQUFXLEVBQUUwRixHQUFHLENBQUNLLE1BQU0sQ0FBQytFLFVBQVUsRUFBRTVGLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQUV1SyxhQUFhLEVBQUUvSixHQUFHLENBQUNLLE1BQU0sQ0FBQ1osR0FBRyxDQUFDZixHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEVBQUVTLEVBQUUsQ0FBQyxHQUFHM1YsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUFFK1Esa0JBQWtCLEVBQUV5RixHQUFHLENBQUNQLEdBQUcsQ0FBQ0QsU0FBUyxDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQUVoRixRQUFRLEVBQUV3RixHQUFHLENBQUNiLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFBRTZLLFNBQVMsRUFBRWhLLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDckIsUUFBUSxFQUFFUSxTQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0lBQUVxQixlQUFlLEVBQUViLEdBQUcsQ0FBQ1IsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQUV5SyxZQUFZLEVBQUVqSyxHQUFHLENBQUNLLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDM0IsR0FBRyxDQUFDLENBQUMsRUFBRUEsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFVSxHQUFHLENBQUMsVUFBVSxFQUFFLG1CQUFtQixFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFBRThLLGdCQUFnQixFQUFFbEssR0FBRyxDQUFDUCxHQUFHLENBQUNOLEVBQUUsQ0FBQyxHQUFHeFYsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFBRXdnQixrQkFBa0IsRUFBRW5LLEdBQUcsQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRTBMLHFCQUFxQixFQUFFcEssR0FBRyxDQUFDTCxJQUFJLENBQUMsWUFBWSxDQUFDO0VBQUUsQ0FBQztBQUNsa0MsQ0FBQztBQUVELE1BQU0wSyxRQUFRLEdBQUlsZSxLQUFjLElBQXVDLENBQUMsQ0FBQ0EsS0FBSyxJQUFJLE9BQU9BLEtBQUssS0FBSyxRQUFRLElBQUksQ0FBQ21lLEtBQUssQ0FBQ0MsT0FBTyxDQUFDcGUsS0FBSyxDQUFDLEtBQUsxQyxNQUFNLENBQUMrZ0IsY0FBYyxDQUFDcmUsS0FBSyxDQUFDLEtBQUsxQyxNQUFNLENBQUNnaEIsU0FBUyxJQUFJaGhCLE1BQU0sQ0FBQytnQixjQUFjLENBQUNyZSxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUM7QUFDcE8sTUFBTXVlLFdBQVcsR0FBRyxJQUFJQyxXQUFXLENBQUMsQ0FBQztBQUNyQyxNQUFNQyxTQUFTLEdBQUl6ZSxLQUFhLElBQWF1ZSxXQUFXLENBQUNHLE1BQU0sQ0FBQzFlLEtBQUssQ0FBQyxDQUFDMmUsVUFBVTtBQUNqRjtBQUNBO0FBQ0EsU0FBU0MsZUFBZUEsQ0FBQzVlLEtBQWEsRUFBVTtFQUM5QyxJQUFJNmUsS0FBSyxHQUFHLENBQUM7RUFDYixLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRzllLEtBQUssQ0FBQ21ULE1BQU0sRUFBRTJMLENBQUMsRUFBRSxFQUFFRCxLQUFLLEVBQUUsRUFBRTtJQUM5QyxNQUFNRSxJQUFJLEdBQUcvZSxLQUFLLENBQUNnZixVQUFVLENBQUNGLENBQUMsQ0FBQztNQUFFRyxJQUFJLEdBQUdqZixLQUFLLENBQUNnZixVQUFVLENBQUNGLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDaEUsSUFBSUMsSUFBSSxJQUFJLE1BQU0sSUFBSUEsSUFBSSxJQUFJLE1BQU0sSUFBSUUsSUFBSSxJQUFJLE1BQU0sSUFBSUEsSUFBSSxJQUFJLE1BQU0sRUFBRUgsQ0FBQyxFQUFFO0VBQy9FO0VBQ0EsT0FBT0QsS0FBSztBQUNkO0FBQ0EsU0FBU0ssWUFBWUEsQ0FBQ2xmLEtBQWEsRUFBVztFQUM1QyxLQUFLLElBQUk4ZSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc5ZSxLQUFLLENBQUNtVCxNQUFNLEVBQUUyTCxDQUFDLEVBQUUsRUFBRTtJQUNyQyxNQUFNQyxJQUFJLEdBQUcvZSxLQUFLLENBQUNnZixVQUFVLENBQUNGLENBQUMsQ0FBQztJQUNoQyxJQUFJQyxJQUFJLElBQUksTUFBTSxJQUFJQSxJQUFJLElBQUksTUFBTSxFQUFFO01BQUUsTUFBTUUsSUFBSSxHQUFHamYsS0FBSyxDQUFDZ2YsVUFBVSxDQUFDLEVBQUVGLENBQUMsQ0FBQztNQUFFLElBQUksRUFBRUcsSUFBSSxJQUFJLE1BQU0sSUFBSUEsSUFBSSxJQUFJLE1BQU0sQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUFFLENBQUMsTUFDL0gsSUFBSUYsSUFBSSxJQUFJLE1BQU0sSUFBSUEsSUFBSSxJQUFJLE1BQU0sRUFBRSxPQUFPLEtBQUs7RUFDekQ7RUFDQSxPQUFPLElBQUk7QUFDYjtBQUNBLFNBQVNJLFFBQVFBLENBQUNDLE1BQXlCLEVBQUVDLElBQVksRUFBRUMsT0FBZSxFQUFFUCxJQUE2QixHQUFHLG1CQUFtQixFQUFRO0VBQUUsSUFBSUssTUFBTSxDQUFDak0sTUFBTSxHQUFHLEdBQUcsRUFBRWlNLE1BQU0sQ0FBQ0csSUFBSSxDQUFDO0lBQUVSLElBQUk7SUFBRU0sSUFBSTtJQUFFQztFQUFRLENBQUMsQ0FBQztBQUFFO0FBQ3hNLFNBQVNFLFNBQVNBLENBQUN4ZixLQUFhLEVBQVc7RUFDekMsSUFBSSxDQUFDLHFCQUFxQixDQUFDeWYsSUFBSSxDQUFDemYsS0FBSyxDQUFDLEVBQUUsT0FBTyxLQUFLO0VBQ3BELE1BQU1zZCxJQUFJLEdBQUcsSUFBSTNPLElBQUksQ0FBQyxHQUFHM08sS0FBSyxZQUFZLENBQUM7RUFBRSxPQUFPK1ksTUFBTSxDQUFDMkcsUUFBUSxDQUFDcEMsSUFBSSxDQUFDcUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJckMsSUFBSSxDQUFDMU8sV0FBVyxDQUFDLENBQUMsQ0FBQ2dSLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUs1ZixLQUFLO0FBQ2xJO0FBQ0EsU0FBUzZmLGVBQWVBLENBQUM3ZixLQUE4QixFQUFzQjtFQUMzRSxRQUFRQSxLQUFLLENBQUNpRCxFQUFFO0lBQ2QsS0FBSyxVQUFVO01BQUUsT0FBT3dRLEdBQUcsQ0FBQztRQUFFeFEsRUFBRSxFQUFFeVEsR0FBRyxDQUFDVixFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7UUFBRWhULEtBQUssRUFBRTBULEdBQUcsQ0FBQ2QsSUFBSTtNQUFFLENBQUMsQ0FBQztJQUMxRSxLQUFLLEtBQUs7SUFBRSxLQUFLLEtBQUs7TUFBRSxPQUFPYSxHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztRQUFFOE0sUUFBUSxFQUFFcE0sR0FBRyxDQUFDSixHQUFHLENBQUNXLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUMxRyxLQUFLLEtBQUs7TUFBRSxPQUFPUixHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQUUrTSxLQUFLLEVBQUVyTSxHQUFHLENBQUNPLElBQUk7TUFBRSxDQUFDLENBQUM7SUFDaEUsS0FBSyxTQUFTO01BQUUsT0FBT1IsR0FBRyxDQUFDO1FBQUV4USxFQUFFLEVBQUV5USxHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUFFakIsVUFBVSxFQUFFMkIsR0FBRyxDQUFDVCxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFBRWpCLFVBQVUsRUFBRTBCLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUMxVCxLQUFLLENBQUNnUyxVQUFVLEtBQUssSUFBSSxHQUFHc0IsR0FBRyxDQUFDUCxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBR0EsS0FBSztNQUFFLENBQUMsQ0FBQztJQUNsTyxLQUFLLE1BQU07TUFBRSxPQUFPVSxHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQUVnTixNQUFNLEVBQUV0TSxHQUFHLENBQUNULEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUFFb0QsUUFBUSxFQUFFM0MsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQztNQUFFLENBQUMsQ0FBQztJQUNsSCxLQUFLLE9BQU87TUFBRSxPQUFPSyxHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQUV3RCxXQUFXLEVBQUU5QyxHQUFHLENBQUNULEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUFFdk4sUUFBUSxFQUFFZ08sR0FBRyxDQUFDVCxHQUFHLENBQUMsV0FBVyxDQUFDO01BQUUsQ0FBQyxDQUFDO0lBQ3ZILEtBQUssU0FBUztNQUFFLE9BQU9RLEdBQUcsQ0FBQztRQUFFeFEsRUFBRSxFQUFFeVEsR0FBRyxDQUFDVixFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7UUFBRXpNLFFBQVEsRUFBRW1OLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUFFNEwsS0FBSyxFQUFFbkwsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQztNQUFFLENBQUMsQ0FBQztJQUNqSCxLQUFLLFVBQVU7TUFBRSxPQUFPSyxHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQUVpTixVQUFVLEVBQUV2TSxHQUFHLENBQUNULEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUNuRztNQUFTLE9BQU9HLFNBQVM7RUFDM0I7QUFDRjtBQUNBLFNBQVM4TSxnQkFBZ0JBLENBQUNsZ0IsS0FBOEIsRUFBc0I7RUFDNUUsTUFBTW9JLFVBQWtCLEdBQUc7SUFBRWpLLElBQUksRUFBRTtFQUFhLENBQUM7RUFDakQsUUFBUTZCLEtBQUssQ0FBQ2lELEVBQUU7SUFDZCxLQUFLLE9BQU87TUFBRSxPQUFPd1EsR0FBRyxDQUFDO1FBQUV4USxFQUFFLEVBQUV5USxHQUFHLENBQUNWLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUFFaFQsS0FBSyxFQUFFMFQsR0FBRyxDQUFDWCxLQUFLO01BQUUsQ0FBQyxDQUFDO0lBQ3JFLEtBQUssVUFBVTtNQUFFLE9BQU9VLEdBQUcsQ0FBQztRQUFFeFEsRUFBRSxFQUFFeVEsR0FBRyxDQUFDVixFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7UUFBRWpCLFVBQVUsRUFBRTJCLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLFVBQVUsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUMxRixLQUFLLEtBQUs7SUFBRSxLQUFLLFVBQVU7SUFBRSxLQUFLLFVBQVU7TUFBRSxPQUFPUSxHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFBRW1OLElBQUksRUFBRXpNLEdBQUcsQ0FBQ3RMLFVBQVUsQ0FBQztRQUFFZ1ksS0FBSyxFQUFFMU0sR0FBRyxDQUFDdEwsVUFBVTtNQUFFLENBQUMsQ0FBQztJQUN2SixLQUFLLElBQUk7TUFBRSxPQUFPcUwsR0FBRyxDQUFDO1FBQUV4USxFQUFFLEVBQUV5USxHQUFHLENBQUNWLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUFFeFAsU0FBUyxFQUFFa1EsR0FBRyxDQUFDTyxJQUFJLENBQUM7UUFBRW9NLElBQUksRUFBRTNNLEdBQUcsQ0FBQ3RMLFVBQVUsQ0FBQztRQUFFa1ksSUFBSSxFQUFFNU0sR0FBRyxDQUFDdEwsVUFBVTtNQUFFLENBQUMsQ0FBQztJQUNoSDtNQUFTLE9BQU95WCxlQUFlLENBQUM3ZixLQUFLLENBQUM7RUFDeEM7QUFDRjtBQUNBLFNBQVN1Z0IsVUFBVUEsQ0FBQ3ZnQixLQUE4QixFQUFzQjtFQUN0RSxNQUFNcVAsVUFBVSxHQUFHcUUsR0FBRyxDQUFDTCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7RUFDN0MsUUFBUXJULEtBQUssQ0FBQ2MsSUFBSTtJQUNoQixLQUFLLFNBQVM7TUFBRSxPQUFPMlMsR0FBRyxDQUFDO1FBQUUzUyxJQUFJLEVBQUU0UyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUFFbkMsRUFBRSxFQUFFNkMsR0FBRyxDQUFDWixJQUFJLENBQUM7UUFBRXpEO01BQVcsQ0FBQyxDQUFDO0lBQ25GLEtBQUssVUFBVTtNQUFFLE9BQU9vRSxHQUFHLENBQUM7UUFBRTNTLElBQUksRUFBRTRTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQUV3QixLQUFLLEVBQUVkLEdBQUcsQ0FBQ1osSUFBSSxDQUFDO1FBQUUyQixHQUFHLEVBQUVmLEdBQUcsQ0FBQ1osSUFBSSxDQUFDO1FBQUV6RDtNQUFXLENBQUMsQ0FBQztJQUN4RyxLQUFLLFdBQVc7TUFBRSxPQUFPb0UsR0FBRyxDQUFDO1FBQUUzUyxJQUFJLEVBQUU0UyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUFFd04sUUFBUSxFQUFFOU0sR0FBRyxDQUFDWixJQUFJLENBQUM7UUFBRTJOLE1BQU0sRUFBRS9NLEdBQUcsQ0FBQ1osSUFBSSxDQUFDO1FBQUV6RCxVQUFVO1FBQUVxUixTQUFTLEVBQUVoTixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUN2SSxLQUFLLFVBQVU7TUFBRSxPQUFPa0IsR0FBRyxDQUFDO1FBQUUzUyxJQUFJLEVBQUU0UyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUFFMk4sYUFBYSxFQUFFak4sR0FBRyxDQUFDVCxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFBRTJOLFdBQVcsRUFBRWxOLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUFFNk4sU0FBUyxFQUFFbk4sR0FBRyxDQUFDWixJQUFJLENBQUM7UUFBRWdPLFNBQVMsRUFBRXBOLEdBQUcsQ0FBQ1osSUFBSTtNQUFFLENBQUMsQ0FBQztJQUM5SyxLQUFLLFNBQVM7TUFBRSxPQUFPVyxHQUFHLENBQUM7UUFBRTNTLElBQUksRUFBRTRTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQUUvUyxNQUFNLEVBQUV5VCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUM1RTtNQUFTLE9BQU9hLFNBQVM7RUFDM0I7QUFDRjtBQUNBLFNBQVMyTixXQUFXQSxDQUFDL2dCLEtBQThCLEVBQXNCO0VBQ3ZFLFFBQVFBLEtBQUssQ0FBQ2lELEVBQUU7SUFDZCxLQUFLLEtBQUs7SUFBRSxLQUFLLEtBQUs7TUFBRSxPQUFPd1EsR0FBRyxDQUFDO1FBQUV4USxFQUFFLEVBQUV5USxHQUFHLENBQUNWLEVBQUUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFBRThNLFFBQVEsRUFBRXBNLEdBQUcsQ0FBQ0osR0FBRyxDQUFDO1VBQUVuVixJQUFJLEVBQUU7UUFBUSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUM7TUFBRSxDQUFDLENBQUM7SUFDdkgsS0FBSyxNQUFNO01BQUUsT0FBT3NWLEdBQUcsQ0FBQztRQUFFeFEsRUFBRSxFQUFFeVEsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFBRWhULEtBQUssRUFBRTBULEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEdBQUczVixZQUFZLENBQUM7TUFBRSxDQUFDLENBQUM7SUFDakYsS0FBSyxNQUFNO01BQUUsT0FBT29XLEdBQUcsQ0FBQztRQUFFeFEsRUFBRSxFQUFFeVEsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFBRWhULEtBQUssRUFBRTBULEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDO01BQUUsQ0FBQyxDQUFDO0lBQ25FLEtBQUssUUFBUTtNQUFFLE9BQU9rQixHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNWLEVBQUUsQ0FBQyxHQUFHeFYsUUFBUSxDQUFDO01BQUUsQ0FBQyxDQUFDO0lBQ2pGLEtBQUssYUFBYTtNQUFFLE9BQU9pVyxHQUFHLENBQUM7UUFBRXhRLEVBQUUsRUFBRXlRLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQUVyRyxXQUFXLEVBQUUrRyxHQUFHLENBQUNULEdBQUcsQ0FBQyxXQUFXLENBQUM7TUFBRSxDQUFDLENBQUM7SUFDbEcsS0FBSyxZQUFZO01BQUUsT0FBT1EsR0FBRyxDQUFDO1FBQUV4USxFQUFFLEVBQUV5USxHQUFHLENBQUNWLEVBQUUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUFFaFQsS0FBSyxFQUFFMFQsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxDQUFDO01BQUUsQ0FBQyxDQUFDO0lBQ3JILEtBQUssU0FBUztNQUFFLE9BQU9TLEdBQUcsQ0FBQztRQUFFeFEsRUFBRSxFQUFFeVEsR0FBRyxDQUFDVixFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7UUFBRWpSLFNBQVMsRUFBRTJSLEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLFNBQVMsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUN0RixLQUFLLFlBQVk7TUFBRSxPQUFPUSxHQUFHLENBQUM7UUFDNUJ4USxFQUFFLEVBQUV5USxHQUFHLENBQUNWLEVBQUUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN6QjNNLFlBQVksRUFBRTBOLGFBQWEsQ0FBQ2QsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzlDbk4sZ0JBQWdCLEVBQUVpTyxhQUFhLENBQUNmLEVBQUUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFFLGtCQUFrQixFQUFFLGFBQWEsRUFBRSxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDdEh2TSxJQUFJLEVBQUVzTixhQUFhLENBQUNmLEVBQUUsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDekN4TSxLQUFLLEVBQUV1TixhQUFhLENBQUNmLEVBQUUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsYUFBYSxDQUFDO01BQ3BGLENBQUMsQ0FBQztJQUNGO01BQVMsT0FBT0ksU0FBUztFQUMzQjtBQUNGO0FBQ0EsU0FBUzROLGdCQUFnQkEsQ0FBQ2hoQixLQUE4QixFQUFzQjtFQUM1RSxJQUFJLEVBQUUsTUFBTSxJQUFJQSxLQUFLLENBQUMsRUFBRTtJQUN0QixNQUFNaWhCLE1BQU0sR0FBRzdNLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM3WCxHQUFHLENBQUN1RSxJQUFJLElBQUlrZ0IsZ0JBQWdCLENBQUM7TUFBRWxnQjtJQUFLLENBQUMsQ0FBRSxDQUFDLENBQUM7SUFDOUcsT0FBTzJTLEdBQUcsQ0FBQztNQUFFeU4sYUFBYSxFQUFFck4sR0FBRyxDQUFDb04sTUFBTSxDQUFDO01BQUVFLFVBQVUsRUFBRXROLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDK00sTUFBTSxFQUFFaE8sR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQztFQUNwRjtFQUNBLFFBQVFqVCxLQUFLLENBQUNjLElBQUk7SUFDaEIsS0FBSyxPQUFPO01BQUUsT0FBTzJTLEdBQUcsQ0FBQztRQUFFM1MsSUFBSSxFQUFFNFMsR0FBRyxDQUFDVixFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7UUFBRW9PLE9BQU8sRUFBRTFOLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLE9BQU8sQ0FBQztNQUFFLENBQUMsQ0FBQztJQUN0RixLQUFLLFNBQVM7TUFBRSxPQUFPSSxHQUFHLENBQUM7UUFBRTNTLElBQUksRUFBRTRTLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQUVxTyxXQUFXLEVBQUUzTixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztNQUFFLENBQUMsQ0FBQztJQUN2RixLQUFLLFNBQVM7TUFBRSxPQUFPa0IsR0FBRyxDQUFDO1FBQUUzUyxJQUFJLEVBQUU0UyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLENBQUM7TUFBRSxDQUFDLENBQUM7SUFDeEQsS0FBSyxXQUFXO01BQUUsT0FBT1MsR0FBRyxDQUFDO1FBQUUzUyxJQUFJLEVBQUU0UyxHQUFHLENBQUNWLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUFFaUgsUUFBUSxFQUFFdkcsR0FBRyxDQUFDYixRQUFRLENBQUM7UUFBRXlPLFVBQVUsRUFBRTVOLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDO01BQUUsQ0FBQyxDQUFDO0lBQ25IO01BQVMsT0FBT2EsU0FBUztFQUMzQjtBQUNGO0FBRUEsTUFBTW1PLFFBQVEsR0FBRztFQUFFL00sS0FBSyxFQUFFZCxHQUFHLENBQUNoQixHQUFHLENBQUMsQ0FBQyxFQUFFVSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFBRXFCLEdBQUcsRUFBRWYsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQztBQUFFLENBQUM7QUFDM0YsTUFBTW9PLGNBQWMsR0FBR2xPLEdBQUcsQ0FBQ0csR0FBRyxDQUFDO0VBQUV4VSxFQUFFLEVBQUV5VSxHQUFHLENBQUNiLFFBQVEsQ0FBQztFQUFFM1QsSUFBSSxFQUFFd1UsR0FBRyxDQUFDVixFQUFFLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7RUFBRWxVLElBQUksRUFBRTRVLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRWtQLElBQUksRUFBRTVOLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDRyxHQUFHLENBQUM7SUFBRSxHQUFHOE4sUUFBUTtJQUFFemlCLElBQUksRUFBRTRVLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFbVAsS0FBSyxFQUFFN04sR0FBRyxDQUFDUCxHQUFHLENBQUNHLEdBQUcsQ0FBQztJQUFFLEdBQUc4TixRQUFRO0lBQUU1VyxNQUFNLEVBQUUrSSxHQUFHLENBQUNwTixNQUFNO0VBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFFcWIscUJBQXFCLEVBQUU5TixHQUFHLENBQUNQLEdBQUcsQ0FBQ3VCLHdCQUF3QixDQUFDO0FBQUUsQ0FBQyxDQUFDLENBQUM7QUFDcFQsU0FBUytNLElBQUlBLENBQUNqTyxNQUFjLEVBQUUzVCxLQUFjLEVBQUVxZixJQUFZLEVBQUVELE1BQXlCLEVBQUV5QyxVQUE2QixFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQyxHQUFlLEVBQVE7RUFDdEosSUFBSTNDLE1BQU0sQ0FBQ2pNLE1BQU0sSUFBSSxHQUFHLEVBQUU7RUFDMUIsSUFBSTJPLEtBQUssR0FBRyxFQUFFLEVBQUU7SUFBRTNDLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFQyxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsY0FBYyxDQUFDO0lBQUU7RUFBUTtFQUN4RixNQUFNMkMsSUFBSSxHQUFJMUMsT0FBZSxJQUFXSCxRQUFRLENBQUNDLE1BQU0sRUFBRUMsSUFBSSxFQUFFQyxPQUFPLENBQUM7RUFDdkUsUUFBUTNMLE1BQU0sQ0FBQ3hWLElBQUk7SUFDakIsS0FBSyxNQUFNO01BQUU7UUFDWCxNQUFNOGpCLEtBQUssR0FBR0EsQ0FBQ25uQixJQUFhLEVBQUVvbkIsUUFBZ0IsRUFBRUMsS0FBYSxFQUFFQyxJQUFpQixLQUFXO1VBQ3pGLElBQUlELEtBQUssR0FBRyxHQUFHLEVBQUU7WUFBRWhELFFBQVEsQ0FBQ0MsTUFBTSxFQUFFOEMsUUFBUSxFQUFFLG1CQUFtQixFQUFFLGNBQWMsQ0FBQztZQUFFO1VBQVE7VUFDNUYsSUFBSXBuQixJQUFJLEtBQUssSUFBSSxJQUFJLE9BQU9BLElBQUksS0FBSyxRQUFRLElBQUksT0FBT0EsSUFBSSxLQUFLLFNBQVMsRUFBRTtVQUM1RSxJQUFJLE9BQU9BLElBQUksS0FBSyxRQUFRLElBQUlpZSxNQUFNLENBQUMyRyxRQUFRLENBQUM1a0IsSUFBSSxDQUFDLEVBQUU7VUFDdkQsSUFBSSxDQUFDQSxJQUFJLElBQUksT0FBT0EsSUFBSSxLQUFLLFFBQVEsSUFBSXNuQixJQUFJLENBQUNDLEdBQUcsQ0FBQ3ZuQixJQUFJLENBQUMsRUFBRTtZQUFFcWtCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFOEMsUUFBUSxFQUFFLG9CQUFvQixDQUFDO1lBQUU7VUFBUTtVQUNySEUsSUFBSSxDQUFDRSxHQUFHLENBQUN4bkIsSUFBSSxDQUFDO1VBQ2QsSUFBSXFqQixLQUFLLENBQUNDLE9BQU8sQ0FBQ3RqQixJQUFJLENBQUMsRUFBRUEsSUFBSSxDQUFDc1gsT0FBTyxDQUFDLENBQUMyTixLQUFLLEVBQUV3QyxLQUFLLEtBQUtOLEtBQUssQ0FBQ2xDLEtBQUssRUFBRSxHQUFHbUMsUUFBUSxJQUFJSyxLQUFLLEdBQUcsRUFBRUosS0FBSyxHQUFHLENBQUMsRUFBRUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUMzRyxJQUFJOWtCLE1BQU0sQ0FBQytnQixjQUFjLENBQUN2akIsSUFBSSxDQUFDLEtBQUt3QyxNQUFNLENBQUNnaEIsU0FBUyxJQUFJaGhCLE1BQU0sQ0FBQytnQixjQUFjLENBQUN2akIsSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2pHLEtBQUssTUFBTSxDQUFDNkMsR0FBRyxFQUFFb2lCLEtBQUssQ0FBQyxJQUFJemlCLE1BQU0sQ0FBQ2tsQixPQUFPLENBQUMxbkIsSUFBSSxDQUFDLEVBQUU7Y0FDL0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUMybkIsUUFBUSxDQUFDOWtCLEdBQUcsQ0FBQyxFQUFFd2hCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc4QyxRQUFRLElBQUl2a0IsR0FBRyxFQUFFLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxLQUNqSHNrQixLQUFLLENBQUNsQyxLQUFLLEVBQUUsR0FBR21DLFFBQVEsSUFBSXZrQixHQUFHLEVBQUUsRUFBRXdrQixLQUFLLEdBQUcsQ0FBQyxFQUFFQyxJQUFJLENBQUM7WUFDMUQ7VUFDRixDQUFDLE1BQU1qRCxRQUFRLENBQUNDLE1BQU0sRUFBRThDLFFBQVEsRUFBRSx5QkFBeUIsQ0FBQztVQUM1REUsSUFBSSxDQUFDTSxNQUFNLENBQUM1bkIsSUFBSSxDQUFDO1FBQ25CLENBQUM7UUFDRG1uQixLQUFLLENBQUNqaUIsS0FBSyxFQUFFcWYsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJc0QsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUFFO01BQ3BDO0lBQ0EsS0FBSyxNQUFNO01BQUU7UUFDWCxJQUFJLE9BQU8zaUIsS0FBSyxLQUFLLFFBQVEsRUFBRTtVQUFFZ2lCLElBQUksQ0FBQyxlQUFlLENBQUM7VUFBRTtRQUFRO1FBQ2hFLElBQUksQ0FBQzlDLFlBQVksQ0FBQ2xmLEtBQUssQ0FBQyxFQUFFZ2lCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztRQUN0RCxNQUFNbkQsS0FBSyxHQUFHRCxlQUFlLENBQUM1ZSxLQUFLLENBQUM7UUFDcEMsSUFBSTJULE1BQU0sQ0FBQzVDLEdBQUcsS0FBS3FDLFNBQVMsSUFBSXlMLEtBQUssR0FBR2xMLE1BQU0sQ0FBQzVDLEdBQUcsRUFBRWlSLElBQUksQ0FBQyxHQUFHck8sTUFBTSxDQUFDNUMsR0FBRyxnQkFBZ0IsQ0FBQztRQUN2RixJQUFJNEMsTUFBTSxDQUFDM0MsR0FBRyxLQUFLb0MsU0FBUyxJQUFJeUwsS0FBSyxHQUFHbEwsTUFBTSxDQUFDM0MsR0FBRyxFQUFFZ1IsSUFBSSxDQUFDLEdBQUdyTyxNQUFNLENBQUMzQyxHQUFHLGdCQUFnQixDQUFDO1FBQ3ZGLElBQUkyQyxNQUFNLENBQUNuQixRQUFRLEtBQUtZLFNBQVMsSUFBSXFMLFNBQVMsQ0FBQ3plLEtBQUssQ0FBQyxHQUFHMlQsTUFBTSxDQUFDbkIsUUFBUSxFQUFFd1AsSUFBSSxDQUFDLHFCQUFxQixDQUFDO1FBQ3BHO01BQ0Y7SUFDQSxLQUFLLFFBQVE7TUFDWCxJQUFJLE9BQU9oaUIsS0FBSyxLQUFLLFFBQVEsSUFBSSxDQUFDK1ksTUFBTSxDQUFDMkcsUUFBUSxDQUFDMWYsS0FBSyxDQUFDLElBQUsyVCxNQUFNLENBQUNoQixPQUFPLElBQUksQ0FBQ29HLE1BQU0sQ0FBQzZKLGFBQWEsQ0FBQzVpQixLQUFLLENBQUUsRUFBRWdpQixJQUFJLENBQUNyTyxNQUFNLENBQUNoQixPQUFPLEdBQUcsb0JBQW9CLEdBQUcsaUJBQWlCLENBQUMsQ0FBQyxLQUN6SyxJQUFLZ0IsTUFBTSxDQUFDNUMsR0FBRyxLQUFLcUMsU0FBUyxJQUFJcFQsS0FBSyxHQUFHMlQsTUFBTSxDQUFDNUMsR0FBRyxJQUFNNEMsTUFBTSxDQUFDM0MsR0FBRyxLQUFLb0MsU0FBUyxJQUFJcFQsS0FBSyxHQUFHMlQsTUFBTSxDQUFDM0MsR0FBSSxFQUFFZ1IsSUFBSSxDQUFDLGFBQWEsQ0FBQztNQUNsSTtJQUNGLEtBQUssU0FBUztNQUFFLElBQUksT0FBT2hpQixLQUFLLEtBQUssU0FBUyxFQUFFZ2lCLElBQUksQ0FBQyxlQUFlLENBQUM7TUFBRTtJQUN2RSxLQUFLLE1BQU07TUFBRSxJQUFJLENBQUNyTyxNQUFNLENBQUMzTyxNQUFNLENBQUN5ZCxRQUFRLENBQUN6aUIsS0FBZ0MsQ0FBQyxFQUFFZ2lCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztNQUFFO0lBQ3JHLEtBQUssSUFBSTtNQUFFLElBQUksT0FBT2hpQixLQUFLLEtBQUssUUFBUSxJQUFJLENBQUM1QixVQUFVLENBQUNxaEIsSUFBSSxDQUFDemYsS0FBSyxDQUFDLEVBQUVnaUIsSUFBSSxDQUFDLG9CQUFvQixDQUFDO01BQUU7SUFDakcsS0FBSyxLQUFLO01BQUU7UUFBQSxJQUFBYSxhQUFBO1FBQ1YsTUFBTUMsS0FBSyxHQUFHLE9BQU85aUIsS0FBSyxLQUFLLFFBQVEsS0FBSzJULE1BQU0sQ0FBQzlPLEtBQUssS0FBSyxVQUFVLEdBQUc3RSxLQUFLLENBQUNtVCxNQUFNLEdBQUcsQ0FBQyxHQUFHL1UsVUFBVSxDQUFDcWhCLElBQUksQ0FBQ3pmLEtBQUssQ0FBQyxDQUFDO1FBQ3BILElBQUksQ0FBQzhpQixLQUFLLEVBQUVkLElBQUksQ0FBQ3JPLE1BQU0sQ0FBQzlPLEtBQUssS0FBSyxVQUFVLEdBQUcsV0FBVyxHQUFHLGdCQUFnQixDQUFDO1FBQzlFO1FBQ0E7UUFDQSxJQUFHLE9BQU83RSxLQUFLLEtBQUcsUUFBUSxFQUFDNmhCLFVBQVUsQ0FBQ3RDLElBQUksQ0FBQztVQUFFdGdCLEVBQUUsRUFBRWUsS0FBSztVQUFFcWYsSUFBSTtVQUFFbk0sS0FBSyxFQUFFUyxNQUFNLENBQUNULEtBQUs7VUFBRXJPLEtBQUssR0FBQWdlLGFBQUEsR0FBRWxQLE1BQU0sQ0FBQzlPLEtBQUssY0FBQWdlLGFBQUEsY0FBQUEsYUFBQSxHQUFJO1FBQVMsQ0FBQyxDQUFDO1FBQ3JIO01BQ0Y7SUFDQSxLQUFLLE1BQU07TUFBRSxJQUFJLENBQUMzb0IsTUFBTSxDQUFDOEYsS0FBSyxDQUFDLEVBQUVnaUIsSUFBSSxDQUFDLHVCQUF1QixDQUFDO01BQUU7SUFDaEUsS0FBSyxVQUFVO01BQUUsSUFBSSxPQUFPaGlCLEtBQUssS0FBSyxRQUFRLElBQUksQ0FBQzNCLGdCQUFnQixDQUFDb2hCLElBQUksQ0FBQ3pmLEtBQUssQ0FBQyxFQUFFZ2lCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztNQUFFO0lBQ2hILEtBQUssVUFBVTtNQUNiLElBQUksT0FBT2hpQixLQUFLLEtBQUssUUFBUSxJQUFJLENBQUMsdUZBQXVGLENBQUN5ZixJQUFJLENBQUN6ZixLQUFLLENBQUMsSUFBSSxDQUFDK1ksTUFBTSxDQUFDMkcsUUFBUSxDQUFDL1EsSUFBSSxDQUFDb1UsS0FBSyxDQUFDL2lCLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQ3dmLFNBQVMsQ0FBQ3hmLEtBQUssQ0FBQzRmLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRW9DLElBQUksQ0FBQywwQkFBMEIsQ0FBQztNQUNoUDtJQUNGLEtBQUssTUFBTTtNQUFFLElBQUksT0FBT2hpQixLQUFLLEtBQUssUUFBUSxJQUFJLENBQUN3ZixTQUFTLENBQUN4ZixLQUFLLENBQUMsRUFBRWdpQixJQUFJLENBQUMsK0JBQStCLENBQUM7TUFBRTtJQUN4RyxLQUFLLE1BQU07TUFBRSxJQUFJLE9BQU9oaUIsS0FBSyxLQUFLLFFBQVEsSUFBSSxDQUFDLGdCQUFnQixDQUFDeWYsSUFBSSxDQUFDemYsS0FBSyxDQUFDLEVBQUVnaUIsSUFBSSxDQUFDLHdCQUF3QixDQUFDO01BQUU7SUFDN0csS0FBSyxXQUFXO01BQ2QsSUFBSSxPQUFPaGlCLEtBQUssS0FBSyxRQUFRLElBQUksQ0FBQ0EsS0FBSyxJQUFJQSxLQUFLLENBQUNnakIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJaGpCLEtBQUssQ0FBQ3lpQixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUl6aUIsS0FBSyxDQUFDeWlCLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUNoRCxJQUFJLENBQUN6ZixLQUFLLENBQUMsSUFBSUEsS0FBSyxDQUFDakIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDa2tCLElBQUksQ0FBQ0MsSUFBSSxJQUFJLENBQUNBLElBQUksSUFBSUEsSUFBSSxLQUFLLEdBQUcsSUFBSUEsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLHVCQUF1QixDQUFDekQsSUFBSSxDQUFDemYsS0FBSyxDQUFDLEVBQUVnaUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDO01BQ3ZSO0lBQ0YsS0FBSyxPQUFPO01BQUU7UUFBQSxJQUFBbUIsV0FBQTtRQUNaLElBQUksQ0FBQ2hGLEtBQUssQ0FBQ0MsT0FBTyxDQUFDcGUsS0FBSyxDQUFDLEVBQUU7VUFBRWdpQixJQUFJLENBQUMsY0FBYyxDQUFDO1VBQUU7UUFBUTtRQUMzRCxJQUFJaGlCLEtBQUssQ0FBQ21ULE1BQU0sS0FBQWdRLFdBQUEsR0FBSXhQLE1BQU0sQ0FBQzNDLEdBQUcsY0FBQW1TLFdBQUEsY0FBQUEsV0FBQSxHQUFJLE1BQU8sQ0FBQyxJQUFLeFAsTUFBTSxDQUFDNUMsR0FBRyxLQUFLcUMsU0FBUyxJQUFJcFQsS0FBSyxDQUFDbVQsTUFBTSxHQUFHUSxNQUFNLENBQUM1QyxHQUFJLEVBQUU7VUFBRWlSLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztVQUFFO1FBQVE7UUFDekksSUFBSXJPLE1BQU0sQ0FBQ0osTUFBTSxJQUFJLElBQUlvUCxHQUFHLENBQUMzaUIsS0FBSyxDQUFDekQsR0FBRyxDQUFDekIsSUFBSSxJQUFJLE9BQU9BLElBQUksS0FBSyxRQUFRLEdBQUdzb0IsSUFBSSxDQUFDQyxTQUFTLENBQUN2b0IsSUFBSSxDQUFDLEdBQUdBLElBQUksQ0FBQyxDQUFDLENBQUN3b0IsSUFBSSxLQUFLdGpCLEtBQUssQ0FBQ21ULE1BQU0sRUFBRTZPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztRQUN6SmhpQixLQUFLLENBQUNvUyxPQUFPLENBQUMsQ0FBQ3RYLElBQUksRUFBRWdrQixDQUFDLEtBQUs4QyxJQUFJLENBQUNqTyxNQUFNLENBQUM3WSxJQUFJLEVBQUVBLElBQUksRUFBRSxHQUFHdWtCLElBQUksSUFBSVAsQ0FBQyxHQUFHLEVBQUVNLE1BQU0sRUFBRXlDLFVBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDLENBQUM7UUFBRTtNQUM1RztJQUNBLEtBQUssUUFBUTtNQUFFO1FBQ2IsSUFBSSxDQUFDN0QsUUFBUSxDQUFDbGUsS0FBSyxDQUFDLEVBQUU7VUFBRWdpQixJQUFJLENBQUMsa0JBQWtCLENBQUM7VUFBRTtRQUFRO1FBQzFELEtBQUssTUFBTXRYLEtBQUssSUFBSXBOLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDeUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDMUMsTUFBTSxDQUFDaW1CLE1BQU0sQ0FBQzVQLE1BQU0sQ0FBQ3ZKLE1BQU0sRUFBRU0sS0FBSyxDQUFDLEVBQUV5VSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLElBQUkzVSxLQUFLLEVBQUUsRUFBRSxnQkFBZ0IsQ0FBQztRQUN4SSxLQUFLLE1BQU1BLEtBQUssSUFBSXBOLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDb1csTUFBTSxDQUFDdkosTUFBTSxDQUFDLEVBQUU7VUFDOUMsTUFBTW9aLFVBQVUsR0FBRzdQLE1BQU0sQ0FBQ3ZKLE1BQU0sQ0FBQ00sS0FBSyxDQUFFO1VBQ3hDLE1BQU01UCxJQUFJLEdBQUdrRixLQUFLLENBQUMwSyxLQUFLLENBQUM7WUFBRStZLFNBQVMsR0FBRyxHQUFHcEUsSUFBSSxJQUFJM1UsS0FBSyxFQUFFO1VBQ3pELElBQUk1UCxJQUFJLEtBQUtzWSxTQUFTLEVBQUU7WUFBRSxJQUFJb1EsVUFBVSxDQUFDNVAsUUFBUSxFQUFFdUwsUUFBUSxDQUFDQyxNQUFNLEVBQUVxRSxTQUFTLEVBQUUsU0FBUyxDQUFDO1lBQUU7VUFBVTtVQUNyRyxJQUFJM29CLElBQUksS0FBSyxJQUFJLElBQUkwb0IsVUFBVSxDQUFDMVAsUUFBUSxFQUFFO1VBQzFDOE4sSUFBSSxDQUFDNEIsVUFBVSxDQUFDN1AsTUFBTSxFQUFFN1ksSUFBSSxFQUFFMm9CLFNBQVMsRUFBRXJFLE1BQU0sRUFBRXlDLFVBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDO1FBQzlFO1FBQ0E7TUFDRjtJQUNBLEtBQUssUUFBUTtNQUNYLElBQUksQ0FBQzdELFFBQVEsQ0FBQ2xlLEtBQUssQ0FBQyxFQUFFO1FBQUVnaUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1FBQUU7TUFBUTtNQUN6RCxLQUFLLE1BQU0sQ0FBQ3RYLEtBQUssRUFBRTVQLElBQUksQ0FBQyxJQUFJd0MsTUFBTSxDQUFDa2xCLE9BQU8sQ0FBQ3hpQixLQUFLLENBQUMsRUFBRTtRQUNqRCxJQUFJLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxhQUFhLENBQUMsQ0FBQ3lpQixRQUFRLENBQUMvWCxLQUFLLENBQUMsRUFBRTtVQUFFeVUsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxJQUFJM1UsS0FBSyxFQUFFLEVBQUUsZ0JBQWdCLENBQUM7VUFBRTtRQUFVO1FBQ25JLElBQUlpSixNQUFNLENBQUNoVyxHQUFHLEVBQUVpa0IsSUFBSSxDQUFDak8sTUFBTSxDQUFDaFcsR0FBRyxFQUFFK00sS0FBSyxFQUFFLEdBQUcyVSxJQUFJLElBQUkzVSxLQUFLLE9BQU8sRUFBRTBVLE1BQU0sRUFBRXlDLFVBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDO1FBQ3BHSCxJQUFJLENBQUNqTyxNQUFNLENBQUMzVCxLQUFLLEVBQUVsRixJQUFJLEVBQUUsR0FBR3VrQixJQUFJLElBQUkzVSxLQUFLLEVBQUUsRUFBRTBVLE1BQU0sRUFBRXlDLFVBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDO01BQ2xGO01BQ0E7SUFDRixLQUFLLE9BQU87TUFBRTtRQUNaLElBQUkyQixRQUF1QztRQUMzQyxLQUFLLE1BQU1DLE1BQU0sSUFBSWhRLE1BQU0sQ0FBQ1UsT0FBTyxFQUFFO1VBQ25DLE1BQU11UCxZQUErQixHQUFHLEVBQUU7WUFBRUMsVUFBNkIsR0FBRyxFQUFFO1VBQzlFakMsSUFBSSxDQUFDK0IsTUFBTSxFQUFFM2pCLEtBQUssRUFBRXFmLElBQUksRUFBRXVFLFlBQVksRUFBRUMsVUFBVSxFQUFFL0IsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDO1VBQ25FLElBQUksQ0FBQzZCLFlBQVksQ0FBQ3pRLE1BQU0sRUFBRTtZQUFFME8sVUFBVSxDQUFDdEMsSUFBSSxDQUFDLEdBQUdzRSxVQUFVLENBQUM7WUFBRTtVQUFRO1VBQ3BFLElBQUksQ0FBQ0gsUUFBUSxJQUFJRSxZQUFZLENBQUN6USxNQUFNLEdBQUd1USxRQUFRLENBQUN2USxNQUFNLEVBQUV1USxRQUFRLEdBQUdFLFlBQVk7UUFDakY7UUFDQXhFLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLElBQUltRSxRQUFRLGFBQVJBLFFBQVEsY0FBUkEsUUFBUSxHQUFJLENBQUM7VUFBRTNFLElBQUksRUFBRSxtQkFBNEI7VUFBRU0sSUFBSTtVQUFFQyxPQUFPLEVBQUU7UUFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFFO01BQzFHO0lBQ0EsS0FBSyxPQUFPO01BQUU7UUFDWixJQUFJLENBQUNwQixRQUFRLENBQUNsZSxLQUFLLENBQUMsRUFBRTtVQUFFZ2lCLElBQUksQ0FBQyxlQUFlLENBQUM7VUFBRTtRQUFRO1FBQ3ZELElBQUk4QixXQUFtQjtRQUN2QixRQUFROWpCLEtBQUssQ0FBQzdCLElBQUk7VUFDaEIsS0FBSyxTQUFTO1lBQUUybEIsV0FBVyxHQUFHbFIsSUFBSTtZQUFFO1VBQ3BDLEtBQUssU0FBUztZQUFFa1IsV0FBVyxHQUFHcFIsR0FBRyxDQUFDVSxTQUFTLEVBQUVBLFNBQVMsRUFBRSxJQUFJLENBQUM7WUFBRTtVQUMvRCxLQUFLLE1BQU07VUFBRSxLQUFLLE1BQU07WUFBRTBRLFdBQVcsR0FBR3ZSLEdBQUcsQ0FBQyxDQUFDO1lBQUU7VUFDL0MsS0FBSyxLQUFLO1lBQUV1UixXQUFXLEdBQUc3USxHQUFHLENBQUMsQ0FBQztZQUFFO1VBQ2pDLEtBQUssU0FBUztZQUFFMk8sSUFBSSxDQUFDbk8sR0FBRyxDQUFDO2NBQUV0VixJQUFJLEVBQUV1VixHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztjQUFFaFQsS0FBSyxFQUFFO2dCQUFFMlQsTUFBTSxFQUFFcEIsR0FBRyxDQUFDLENBQUM7Z0JBQUVxQixRQUFRLEVBQUUsSUFBSTtnQkFBRUUsUUFBUSxFQUFFO2NBQUssQ0FBQztjQUFFN1QsTUFBTSxFQUFFeVQsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUM7WUFBRSxDQUFDLENBQUMsRUFBRXZTLEtBQUssRUFBRXFmLElBQUksRUFBRUQsTUFBTSxFQUFFeUMsVUFBVSxFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQyxHQUFHLENBQUM7WUFBRSxJQUFJL2hCLEtBQUssQ0FBQ0EsS0FBSyxLQUFLLElBQUksRUFBRWdpQixJQUFJLENBQUMsbUJBQW1CLENBQUM7WUFBRTtVQUM3TztZQUFTQSxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQUU7UUFDN0I7UUFDQUosSUFBSSxDQUFDbk8sR0FBRyxDQUFDO1VBQUV0VixJQUFJLEVBQUV1VixHQUFHLENBQUNWLEVBQUUsQ0FBQ2hULEtBQUssQ0FBQzdCLElBQWMsQ0FBQyxDQUFDO1VBQUU2QixLQUFLLEVBQUUwVCxHQUFHLENBQUNvUSxXQUFXO1FBQUUsQ0FBQyxDQUFDLEVBQUU5akIsS0FBSyxFQUFFcWYsSUFBSSxFQUFFRCxNQUFNLEVBQUV5QyxVQUFVLEVBQUVDLEtBQUssR0FBRyxDQUFDLEVBQUVDLEdBQUcsQ0FBQztRQUFFO01BQ2hJO0lBQ0EsS0FBSyxRQUFRO01BQ1gsSUFBSS9oQixLQUFLLEtBQUssSUFBSSxFQUFFO01BQ3BCLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsRUFBRTRoQixJQUFJLENBQUNyUCxHQUFHLENBQUMsQ0FBQyxFQUFFdlMsS0FBSyxFQUFFcWYsSUFBSSxFQUFFRCxNQUFNLEVBQUV5QyxVQUFVLEVBQUVDLEtBQUssRUFBRUMsR0FBRyxDQUFDLENBQUMsS0FDbkYsSUFBSSxPQUFPL2hCLEtBQUssS0FBSyxRQUFRLEVBQUU0aEIsSUFBSSxDQUFDbFAsR0FBRyxDQUFDLENBQUMsRUFBRTFTLEtBQUssRUFBRXFmLElBQUksRUFBRUQsTUFBTSxFQUFFeUMsVUFBVSxFQUFFQyxLQUFLLEVBQUVDLEdBQUcsQ0FBQyxDQUFDLEtBQ3hGLElBQUksT0FBTy9oQixLQUFLLEtBQUssU0FBUyxFQUFFLE9BQU8sS0FDdkMsSUFBSWtlLFFBQVEsQ0FBQ2xlLEtBQUssQ0FBQyxJQUFJQSxLQUFLLENBQUM3QixJQUFJLEtBQUssS0FBSyxFQUFFeWpCLElBQUksQ0FBQ25PLEdBQUcsQ0FBQztRQUFFdFYsSUFBSSxFQUFFdVYsR0FBRyxDQUFDVixFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7UUFBRWhULEtBQUssRUFBRTBULEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLENBQUM7TUFBRSxDQUFDLENBQUMsRUFBRWpULEtBQUssRUFBRXFmLElBQUksRUFBRUQsTUFBTSxFQUFFeUMsVUFBVSxFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQyxHQUFHLENBQUMsQ0FBQyxLQUNySixJQUFJN0QsUUFBUSxDQUFDbGUsS0FBSyxDQUFDLElBQUlBLEtBQUssQ0FBQzdCLElBQUksS0FBSyxNQUFNLEVBQUV5akIsSUFBSSxDQUFDbk8sR0FBRyxDQUFDO1FBQUV0VixJQUFJLEVBQUV1VixHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUFFaFQsS0FBSyxFQUFFMFQsR0FBRyxDQUFDO1VBQUV2VixJQUFJLEVBQUU7UUFBTyxDQUFDO01BQUUsQ0FBQyxDQUFDLEVBQUU2QixLQUFLLEVBQUVxZixJQUFJLEVBQUVELE1BQU0sRUFBRXlDLFVBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDLENBQUMsS0FDbEtDLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQztNQUM1QztJQUNGLEtBQUssVUFBVTtNQUFFO1FBQ2ZKLElBQUksQ0FBQ0osY0FBYyxFQUFFeGhCLEtBQUssRUFBRXFmLElBQUksRUFBRUQsTUFBTSxFQUFFeUMsVUFBVSxFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQyxHQUFHLENBQUM7UUFDckUsSUFBSSxDQUFDNUQsS0FBSyxDQUFDQyxPQUFPLENBQUNwZSxLQUFLLENBQUMsRUFBRTtRQUMzQixJQUFJK2pCLEtBQUssR0FBRyxDQUFDO1VBQUVDLEtBQUssR0FBRyxDQUFDO1FBQUUsTUFBTXpoQixRQUFRLEdBQUcsSUFBSW9nQixHQUFHLENBQVMsQ0FBQztRQUM1RDNpQixLQUFLLENBQUNvUyxPQUFPLENBQUMsQ0FBQ2hULEtBQWMsRUFBRTBmLENBQUMsS0FBSztVQUNuQyxJQUFJLENBQUNaLFFBQVEsQ0FBQzllLEtBQUssQ0FBQyxJQUFJLE9BQU9BLEtBQUssQ0FBQ04sSUFBSSxLQUFLLFFBQVEsRUFBRTtVQUN4RCxNQUFNcVUsTUFBTSxHQUFHeUwsZUFBZSxDQUFDeGYsS0FBSyxDQUFDTixJQUFJLENBQUM7VUFDMUNpbEIsS0FBSyxJQUFJdEYsU0FBUyxDQUFDcmYsS0FBSyxDQUFDTixJQUFJLENBQUM7VUFBRWtsQixLQUFLLElBQUk3USxNQUFNO1VBQy9DLElBQUksT0FBTy9ULEtBQUssQ0FBQ0gsRUFBRSxLQUFLLFFBQVEsRUFBRTtZQUFFLElBQUlzRCxRQUFRLENBQUM4ZixHQUFHLENBQUNqakIsS0FBSyxDQUFDSCxFQUFFLENBQUMsRUFBRWtnQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLElBQUlQLENBQUMsTUFBTSxFQUFFLGVBQWUsQ0FBQztZQUFFdmMsUUFBUSxDQUFDK2YsR0FBRyxDQUFDbGpCLEtBQUssQ0FBQ0gsRUFBRSxDQUFDO1VBQUU7VUFDL0ksSUFBSWtmLEtBQUssQ0FBQ0MsT0FBTyxDQUFDaGYsS0FBSyxDQUFDdWlCLHFCQUFxQixDQUFDLEVBQUUsS0FBSyxNQUFNc0MsVUFBVSxJQUFJN2tCLEtBQUssQ0FBQ3VpQixxQkFBcUIsRUFBRSxJQUFJekQsUUFBUSxDQUFDK0YsVUFBVSxDQUFDLEVBQUUsS0FBSyxNQUFNdlosS0FBSyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsRUFBRSxJQUFJLE9BQU91WixVQUFVLENBQUN2WixLQUFLLENBQUMsS0FBSyxRQUFRLEVBQUVxWixLQUFLLElBQUl0RixTQUFTLENBQUN3RixVQUFVLENBQUN2WixLQUFLLENBQVcsQ0FBQztVQUNyUixLQUFLLE1BQU1BLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxJQUFJeVQsS0FBSyxDQUFDQyxPQUFPLENBQUNoZixLQUFLLENBQUNzTCxLQUFLLENBQUMsQ0FBQyxFQUFHdEwsS0FBSyxDQUFDc0wsS0FBSyxDQUFDLENBQWUwSCxPQUFPLENBQUMsQ0FBQ3NHLEtBQUssRUFBRXdMLENBQUMsS0FBSztZQUN4SCxJQUFJLENBQUNoRyxRQUFRLENBQUN4RixLQUFLLENBQUMsRUFBRTtZQUN0QixJQUFJLE9BQU9BLEtBQUssQ0FBQ2xFLEtBQUssS0FBSyxRQUFRLElBQUksT0FBT2tFLEtBQUssQ0FBQ2pFLEdBQUcsS0FBSyxRQUFRLEtBQUtpRSxLQUFLLENBQUNsRSxLQUFLLElBQUlrRSxLQUFLLENBQUNqRSxHQUFHLElBQUlpRSxLQUFLLENBQUNqRSxHQUFHLEdBQUd0QixNQUFNLENBQUMsRUFBRWdNLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksSUFBSVAsQ0FBQyxLQUFLcFUsS0FBSyxJQUFJd1osQ0FBQyxHQUFHLEVBQUUsb0NBQW9DLENBQUM7WUFDaE4sSUFBSSxPQUFPeEwsS0FBSyxDQUFDNVosSUFBSSxLQUFLLFFBQVEsRUFBRWlsQixLQUFLLElBQUl0RixTQUFTLENBQUMvRixLQUFLLENBQUM1WixJQUFJLENBQUM7VUFDcEUsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO1FBQ0YsSUFBSWlsQixLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRS9CLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUN0RCxJQUFJck8sTUFBTSxDQUFDM0MsR0FBRyxLQUFLb0MsU0FBUyxJQUFJNFEsS0FBSyxHQUFHclEsTUFBTSxDQUFDM0MsR0FBRyxFQUFFZ1IsSUFBSSxDQUFDLE1BQU1yTyxNQUFNLENBQUMzQyxHQUFHLFNBQVMsQ0FBQztRQUNuRjtNQUNGO0lBQ0EsS0FBSyxXQUFXO0lBQUUsS0FBSyxZQUFZO01BQUU7UUFDbkMsTUFBTW1ULE1BQU0sR0FBR3BDLEdBQUcsYUFBSEEsR0FBRyxjQUFIQSxHQUFHLEdBQUk7VUFBRXFDLE9BQU8sRUFBRTtZQUFFdkYsS0FBSyxFQUFFO1VBQUUsQ0FBQztVQUFFaUQsS0FBSyxFQUFFO1FBQUUsQ0FBQztRQUFFcUMsTUFBTSxDQUFDQyxPQUFPLENBQUN2RixLQUFLLEVBQUU7UUFDakYsSUFBSXNGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDdkYsS0FBSyxHQUFHLEdBQUcsSUFBSXNGLE1BQU0sQ0FBQ3JDLEtBQUssSUFBSSxFQUFFLEVBQUU7VUFBRUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1VBQUU7UUFBUTtRQUMvRixJQUFJLENBQUM5RCxRQUFRLENBQUNsZSxLQUFLLENBQUMsRUFBRTtVQUFFZ2lCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztVQUFFO1FBQVE7UUFDL0QsTUFBTXdCLFVBQVUsR0FBRzdQLE1BQU0sQ0FBQ3hWLElBQUksS0FBSyxXQUFXLEdBQUcwaEIsZUFBZSxDQUFDN2YsS0FBSyxDQUFDLEdBQUdrZ0IsZ0JBQWdCLENBQUNsZ0IsS0FBSyxDQUFDO1FBQ2pHLElBQUksQ0FBQ3dqQixVQUFVLEVBQUU7VUFBRXhCLElBQUksQ0FBQyxjQUFjLENBQUM7VUFBRTtRQUFRO1FBQ2pESixJQUFJLENBQUM0QixVQUFVLEVBQUV4akIsS0FBSyxFQUFFcWYsSUFBSSxFQUFFRCxNQUFNLEVBQUV5QyxVQUFVLEVBQUUsQ0FBQyxFQUFFO1VBQUV1QyxPQUFPLEVBQUVELE1BQU0sQ0FBQ0MsT0FBTztVQUFFdEMsS0FBSyxFQUFFcUMsTUFBTSxDQUFDckMsS0FBSyxHQUFHO1FBQUUsQ0FBQyxDQUFDO1FBQUU7TUFDOUc7SUFDQSxLQUFLLE1BQU07TUFBRTtRQUNYLElBQUksQ0FBQzVELFFBQVEsQ0FBQ2xlLEtBQUssQ0FBQyxFQUFFO1VBQUVnaUIsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1VBQUU7UUFBUTtRQUMvRCxNQUFNd0IsVUFBVSxHQUFHakQsVUFBVSxDQUFDdmdCLEtBQUssQ0FBQztRQUFFLElBQUksQ0FBQ3dqQixVQUFVLEVBQUU7VUFBRXhCLElBQUksQ0FBQyxjQUFjLENBQUM7VUFBRTtRQUFRO1FBQ3ZGLE1BQU0vSyxNQUFNLEdBQUdtSSxNQUFNLENBQUNqTSxNQUFNO1FBQUV5TyxJQUFJLENBQUM0QixVQUFVLEVBQUV4akIsS0FBSyxFQUFFcWYsSUFBSSxFQUFFRCxNQUFNLEVBQUV5QyxVQUFVLEVBQUVDLEtBQUssR0FBRyxDQUFDLEVBQUVDLEdBQUcsQ0FBQztRQUMvRixJQUFJM0MsTUFBTSxDQUFDak0sTUFBTSxLQUFLOEQsTUFBTSxFQUFFO1VBQzVCLElBQUlqWCxLQUFLLENBQUNjLElBQUksS0FBSyxVQUFVLElBQUk3RyxZQUFZLENBQUMrRixLQUFLLENBQUN3VSxLQUFLLEVBQVl4VSxLQUFLLENBQUN5VSxHQUFhLENBQUMsSUFBSSxDQUFDLEVBQUV1TixJQUFJLENBQUMsd0JBQXdCLENBQUM7VUFDOUgsSUFBSWhpQixLQUFLLENBQUNjLElBQUksS0FBSyxXQUFXLElBQUk3RyxZQUFZLENBQUMrRixLQUFLLENBQUN3Z0IsUUFBUSxFQUFZeGdCLEtBQUssQ0FBQ3lnQixNQUFnQixDQUFDLEdBQUcsQ0FBQyxFQUFFdUIsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1VBQ2xJLElBQUloaUIsS0FBSyxDQUFDYyxJQUFJLEtBQUssVUFBVSxJQUFJN0csWUFBWSxDQUFDK0YsS0FBSyxDQUFDNmdCLFNBQVMsRUFBWTdnQixLQUFLLENBQUM4Z0IsU0FBbUIsQ0FBQyxHQUFHLENBQUMsRUFBRWtCLElBQUksQ0FBQywwQkFBMEIsQ0FBQztRQUMzSTtRQUNBO01BQ0Y7SUFDQSxLQUFLLE9BQU87SUFBRSxLQUFLLGFBQWE7TUFBRTtRQUNoQyxJQUFJLENBQUM5RCxRQUFRLENBQUNsZSxLQUFLLENBQUMsRUFBRTtVQUFFZ2lCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztVQUFFO1FBQVE7UUFDOUQsTUFBTXdCLFVBQVUsR0FBRzdQLE1BQU0sQ0FBQ3hWLElBQUksS0FBSyxPQUFPLEdBQUc0aUIsV0FBVyxDQUFDL2dCLEtBQUssQ0FBQyxHQUFHZ2hCLGdCQUFnQixDQUFDaGhCLEtBQUssQ0FBQztRQUN6RixJQUFJLENBQUN3akIsVUFBVSxFQUFFO1VBQUV4QixJQUFJLENBQUMsVUFBVSxDQUFDO1VBQUU7UUFBUTtRQUM3QyxNQUFNL0ssTUFBTSxHQUFHbUksTUFBTSxDQUFDak0sTUFBTTtRQUM1QnlPLElBQUksQ0FBQzRCLFVBQVUsRUFBRXhqQixLQUFLLEVBQUVxZixJQUFJLEVBQUVELE1BQU0sRUFBRXlDLFVBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUMsR0FBRyxDQUFDO1FBQ2pFLElBQUlwTyxNQUFNLENBQUN4VixJQUFJLEtBQUssT0FBTyxJQUFJNkIsS0FBSyxDQUFDaUQsRUFBRSxLQUFLLFlBQVksSUFBSW1jLE1BQU0sQ0FBQ2pNLE1BQU0sS0FBSzhELE1BQU0sSUFDL0UsQ0FBQyxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUNnTSxJQUFJLENBQUN2WSxLQUFLLElBQUkxSyxLQUFLLENBQUMwSyxLQUFLLENBQUMsS0FBSzBJLFNBQVMsSUFBSXBULEtBQUssQ0FBQzBLLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFO1VBQzlIeVUsUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSxzQ0FBc0MsQ0FBQztRQUNoRTtRQUNBO01BQ0Y7RUFDRjtBQUNGO0FBRUEsTUFBTWdGLFlBQW1DLEdBQUc7RUFBRXBsQixFQUFFLEVBQUV5VSxHQUFHLENBQUNiLFFBQVEsQ0FBQztFQUFFckUsU0FBUyxFQUFFa0YsR0FBRyxDQUFDTCxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7RUFBRW5VLElBQUksRUFBRXdVLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEdBQUczVixZQUFZLENBQUMsQ0FBQztFQUFFd1IsUUFBUSxFQUFFNkUsR0FBRyxDQUFDO0lBQUV2VixJQUFJLEVBQUU7RUFBVyxDQUFDLENBQUM7RUFBRXNRLElBQUksRUFBRWlGLEdBQUcsQ0FBQ2pCLEtBQUssQ0FBQztFQUFFM0QsTUFBTSxFQUFFNEUsR0FBRyxDQUFDVixFQUFFLENBQUMsR0FBR3hWLFFBQVEsQ0FBQyxDQUFDO0VBQUV1UixVQUFVLEVBQUUyRSxHQUFHLENBQUNWLEVBQUUsQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0VBQUVzUixvQkFBb0IsRUFBRXpRLEdBQUcsQ0FBQ2pCLElBQUksQ0FBQztFQUFFbkcsbUJBQW1CLEVBQUVvSCxHQUFHLENBQUNaLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0VBQUVzUixVQUFVLEVBQUUxUSxHQUFHLENBQUNaLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztFQUFFakUsU0FBUyxFQUFFMEUsR0FBRyxDQUFDO0lBQUV2VixJQUFJLEVBQUU7RUFBVyxDQUFDLENBQUM7RUFBRThRLFNBQVMsRUFBRXlFLEdBQUcsQ0FBQztJQUFFdlYsSUFBSSxFQUFFO0VBQVcsQ0FBQyxDQUFDO0VBQUV3QixTQUFTLEVBQUVrVSxHQUFHLENBQUM7SUFBRTFWLElBQUksRUFBRTtFQUFXLENBQUMsQ0FBQztFQUFFcW1CLG1CQUFtQixFQUFFM1EsR0FBRyxDQUFDaEIsUUFBUSxDQUFDO0VBQUUzRCxZQUFZLEVBQUV3RSxHQUFHLENBQUNRLE1BQU0sQ0FBQztJQUFFL1YsSUFBSSxFQUFFO0VBQVMsQ0FBQyxFQUFFUixHQUFHLENBQUM7QUFBRSxDQUFDO0FBQ3BsQixNQUFNOG1CLGNBQWMsR0FBR2hSLEdBQUcsQ0FBQztFQUFFeFUsRUFBRSxFQUFFeVUsR0FBRyxDQUFDYixRQUFRLENBQUM7RUFBRXJFLFNBQVMsRUFBRWtGLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0VBQUV4RSxRQUFRLEVBQUU2RSxHQUFHLENBQUM7SUFBRXZWLElBQUksRUFBRTtFQUFXLENBQUMsQ0FBQztFQUFFaUYsTUFBTSxFQUFFc1EsR0FBRyxDQUFDVCxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQUU1UCxJQUFJLEVBQUVxUSxHQUFHLENBQUNULEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRVosWUFBWSxFQUFFcUIsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztFQUFFekksU0FBUyxFQUFFNEosR0FBRyxDQUFDVixFQUFFLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0VBQUVyUSxRQUFRLEVBQUUrUSxHQUFHLENBQUNxQixnQkFBZ0IsQ0FBQztFQUFFekMsV0FBVyxFQUFFb0IsR0FBRyxDQUFDRixJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQUUxRSxNQUFNLEVBQUU0RSxHQUFHLENBQUNWLEVBQUUsQ0FBQyxHQUFHeFYsUUFBUSxDQUFDLENBQUM7RUFBRXVSLFVBQVUsRUFBRTJFLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7RUFBRXZHLG1CQUFtQixFQUFFb0gsR0FBRyxDQUFDWixHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztFQUFFdFQsU0FBUyxFQUFFa1UsR0FBRyxDQUFDO0lBQUUxVixJQUFJLEVBQUU7RUFBVyxDQUFDLENBQUM7RUFBRXFtQixtQkFBbUIsRUFBRTNRLEdBQUcsQ0FBQ2hCLFFBQVE7QUFBRSxDQUFDLENBQUM7QUFDNWYsTUFBTTZSLG1CQUFtQixHQUFHLElBQUlDLEdBQUcsQ0FBK0MsQ0FBQztBQUNuRixTQUFTQyxZQUFZQSxDQUFDMWxCLElBQWdCLEVBQVU7RUFDOUMsTUFBTWdCLElBQUksR0FBR2daLGNBQWMsQ0FBQ2hhLElBQUksQ0FBQztJQUFFMmxCLE1BQU0sR0FBR0gsbUJBQW1CLENBQUNJLEdBQUcsQ0FBQzVsQixJQUFJLENBQUM7RUFDekUsSUFBSSxDQUFBMmxCLE1BQU0sYUFBTkEsTUFBTSx1QkFBTkEsTUFBTSxDQUFFM2tCLElBQUksTUFBS0EsSUFBSSxFQUFFLE9BQU8ya0IsTUFBTSxDQUFDM1EsTUFBTTtFQUMvQyxNQUFNQSxNQUFNLEdBQUdULEdBQUcsQ0FBQztJQUFFLEdBQUc0USxZQUFZO0lBQUVubEIsSUFBSSxFQUFFd1UsR0FBRyxDQUFDVixFQUFFLENBQUM5VCxJQUFJLENBQUMsQ0FBQztJQUFFZ0IsSUFBSSxFQUFFd1QsR0FBRyxDQUFDeFQsSUFBSTtFQUFFLENBQUMsQ0FBQztFQUM3RXdrQixtQkFBbUIsQ0FBQ0ssR0FBRyxDQUFDN2xCLElBQUksRUFBRTtJQUFFZ0IsSUFBSTtJQUFFZ1U7RUFBTyxDQUFDLENBQUM7RUFDL0MsT0FBT0EsTUFBTTtBQUNmO0FBQ0EsU0FBUzhRLGNBQWNBLENBQUlyUixNQUFjLEVBQUUzVCxLQUFjLEVBQUVxZixJQUFZLEVBQUV3QyxVQUE0QixHQUFDLEVBQUUsRUFBdUI7RUFBRSxNQUFNekMsTUFBeUIsR0FBRyxFQUFFO0VBQUV3QyxJQUFJLENBQUNqTyxNQUFNLEVBQUUzVCxLQUFLLEVBQUVxZixJQUFJLEVBQUVELE1BQU0sRUFBRXlDLFVBQVUsQ0FBQztFQUFFLE9BQU96QyxNQUFNLENBQUNqTSxNQUFNLEdBQUc7SUFBRThSLEVBQUUsRUFBRSxLQUFLO0lBQUU3RjtFQUFPLENBQUMsR0FBRztJQUFFNkYsRUFBRSxFQUFFLElBQUk7SUFBRWpsQixLQUFLLEVBQUVBO0VBQVcsQ0FBQztBQUFFO0FBQ3RTLE9BQU8sU0FBU2tsQixpQkFBaUJBLENBQUNDLEtBQWMsRUFBRTlGLElBQUksR0FBRyxXQUFXLEVBQStCO0VBQUUsT0FBTzJGLGNBQWMsQ0FBQy9RLElBQUksRUFBRWtSLEtBQUssRUFBRTlGLElBQUksQ0FBQztBQUFFO0FBQy9JLE9BQU8sU0FBUytGLGtCQUFrQkEsQ0FBQ0QsS0FBYyxFQUFFOUYsSUFBSSxHQUFHLFlBQVksRUFBZ0M7RUFBRSxPQUFPMkYsY0FBYyxDQUFDO0lBQUU3bUIsSUFBSSxFQUFFO0VBQWEsQ0FBQyxFQUFFZ25CLEtBQUssRUFBRTlGLElBQUksQ0FBQztBQUFFO0FBQ3BLLE9BQU8sU0FBU2dHLGtCQUFrQkEsQ0FBQ0YsS0FBYyxFQUFFOUYsSUFBSSxHQUFHLE9BQU8sRUFBZ0M7RUFBRSxPQUFPMkYsY0FBYyxDQUFDalMsS0FBSyxFQUFFb1MsS0FBSyxFQUFFOUYsSUFBSSxDQUFDO0FBQUU7QUFDOUksT0FBTyxTQUFTaUcsZ0JBQWdCQSxDQUFDSCxLQUFjLEVBQUU5RixJQUFJLEdBQUcsTUFBTSxFQUE4QjtFQUFFLE9BQU8yRixjQUFjLENBQUNua0IsSUFBSSxFQUFFc2tCLEtBQUssRUFBRTlGLElBQUksQ0FBQztBQUFFO0FBQ3hJLE9BQU8sU0FBU2tHLG9CQUFvQkEsQ0FBQ0osS0FBYyxFQUFFOUYsSUFBSSxHQUFHLGNBQWMsRUFBa0M7RUFDMUcsTUFBTW1HLE1BQU0sR0FBR1IsY0FBYyxDQUFlak8sT0FBTyxFQUFFb08sS0FBSyxFQUFFOUYsSUFBSSxDQUFDO0VBQUUsSUFBSSxDQUFDbUcsTUFBTSxDQUFDUCxFQUFFLEVBQUUsT0FBT08sTUFBTTtFQUNoRyxNQUFNcEcsTUFBeUIsR0FBRyxFQUFFO0lBQUVxRyxHQUFHLEdBQUcsSUFBSTlDLEdBQUcsQ0FBSyxDQUFDO0lBQUUzUyxVQUFVLEdBQUcsSUFBSTJTLEdBQUcsQ0FBUyxDQUFDO0VBQ3pGNkMsTUFBTSxDQUFDeGxCLEtBQUssQ0FBQytQLGFBQWEsQ0FBQ3FDLE9BQU8sQ0FBQyxDQUFDdFgsSUFBSSxFQUFFZ2tCLENBQUMsS0FBSztJQUM5QyxJQUFJMkcsR0FBRyxDQUFDcEQsR0FBRyxDQUFDdm5CLElBQUksQ0FBQ3dLLFVBQVUsQ0FBQyxFQUFFNlosUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxrQkFBa0JQLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDO0lBQUUyRyxHQUFHLENBQUNuRCxHQUFHLENBQUN4bkIsSUFBSSxDQUFDd0ssVUFBVSxDQUFDO0lBQ3RJLElBQUt4SyxJQUFJLENBQUMwSCxPQUFPLElBQUkxSCxJQUFJLENBQUNtRyxVQUFVLElBQU1uRyxJQUFJLENBQUN3YixRQUFRLElBQUl4YixJQUFJLENBQUN1YixRQUFRLEtBQUssQ0FBRSxJQUFLLENBQUN2YixJQUFJLENBQUN3YixRQUFRLElBQUl4YixJQUFJLENBQUN1YixRQUFRLEdBQUcsQ0FBRSxFQUFFOEksUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxrQkFBa0JQLENBQUMsR0FBRyxFQUFFLHlCQUF5QixDQUFDO0VBQ3RNLENBQUMsQ0FBQztFQUNGMEcsTUFBTSxDQUFDeGxCLEtBQUssQ0FBQ2dRLFVBQVUsQ0FBQ29DLE9BQU8sQ0FBQyxDQUFDelcsU0FBUyxFQUFFbWpCLENBQUMsS0FBSztJQUFFLE1BQU1uaEIsR0FBRyxHQUFHLEdBQUdoQyxTQUFTLENBQUM2YSxXQUFXLElBQUk3YSxTQUFTLENBQUMrSixRQUFRLEVBQUU7SUFBRSxJQUFJc0ssVUFBVSxDQUFDcVMsR0FBRyxDQUFDMWtCLEdBQUcsQ0FBQyxFQUFFd2hCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksZUFBZVAsQ0FBQyxHQUFHLEVBQUUscUJBQXFCLENBQUM7SUFBRTlPLFVBQVUsQ0FBQ3NTLEdBQUcsQ0FBQzNrQixHQUFHLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDdk8sT0FBT3loQixNQUFNLENBQUNqTSxNQUFNLEdBQUc7SUFBRThSLEVBQUUsRUFBRSxLQUFLO0lBQUU3RjtFQUFPLENBQUMsR0FBR29HLE1BQU07QUFDdkQ7QUFDQTtBQUNBLE9BQU8sU0FBU0Usa0NBQWtDQSxDQUFDQyxLQUFtQixFQUFFUixLQUFjLEVBQUUzbEIsUUFBMkIsRUFBRTZmLElBQUksR0FBRyxxQkFBcUIsRUFBcUI7RUFDcEssTUFBTXZILE9BQU8sR0FBR2tOLGNBQWMsQ0FBZ0MxUixHQUFHLENBQUNxRCxrQkFBa0IsQ0FBQyxFQUFFd08sS0FBSyxFQUFFOUYsSUFBSSxDQUFDO0VBQ25HLElBQUksQ0FBQ3ZILE9BQU8sQ0FBQ21OLEVBQUUsRUFBRSxPQUFPbk4sT0FBTyxDQUFDc0gsTUFBTTtFQUN0QyxNQUFNQSxNQUF5QixHQUFHLEVBQUU7SUFBRWdELElBQUksR0FBRyxJQUFJTyxHQUFHLENBQUNnRCxLQUFLLENBQUMxVixPQUFPLENBQUM7SUFBRTJWLFFBQVEsR0FBRyxJQUFJakQsR0FBRyxDQUFLLENBQUM7RUFDN0YsTUFBTWtELElBQUksR0FBR3JtQixRQUFRLENBQUNDLElBQUksQ0FBRUMsTUFBTSxJQUFvQ0EsTUFBTSxDQUFDUixJQUFJLEtBQUssV0FBVyxJQUFJUSxNQUFNLENBQUNULEVBQUUsS0FBSzBtQixLQUFLLENBQUNwVixvQkFBb0IsSUFBSSxDQUFDN1EsTUFBTSxDQUFDQyxTQUFTLElBQUlELE1BQU0sQ0FBQ29QLE1BQU0sS0FBSyxVQUFVLENBQUM7RUFDbk0sTUFBTWdYLFFBQVEsR0FBR3RtQixRQUFRLENBQUNLLE1BQU0sQ0FBRUgsTUFBTSxJQUFxQztJQUMzRSxJQUFJQSxNQUFNLENBQUNSLElBQUksS0FBSyxZQUFZLElBQUlRLE1BQU0sQ0FBQ0MsU0FBUyxJQUFJRCxNQUFNLENBQUNvUCxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUMrVyxJQUFJLElBQUksQ0FBQ3pELElBQUksQ0FBQ0MsR0FBRyxDQUFDd0QsSUFBSSxDQUFDNW1CLEVBQUUsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNqSSxNQUFNcUgsTUFBTSxHQUFHNUcsTUFBTSxDQUFDUSxJQUFJLENBQUNvRyxNQUFNO0lBQ2pDLE9BQU9BLE1BQU0sQ0FBQ3FPLGNBQWMsS0FBSyxZQUFZLEtBQUtyTyxNQUFNLENBQUNDLFFBQVEsS0FBS3NmLElBQUksQ0FBQzVtQixFQUFFLElBQUlxSCxNQUFNLENBQUNDLFFBQVEsS0FBS3NmLElBQUksQ0FBQzNsQixJQUFJLENBQUMyQyxPQUFPLENBQUMsS0FDakgsQ0FBQ3lELE1BQU0sQ0FBQ2dPLE9BQU8sSUFBSThOLElBQUksQ0FBQ0MsR0FBRyxDQUFDL2IsTUFBTSxDQUFDZ08sT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDaE8sTUFBTSxDQUFDaU8sTUFBTSxJQUFJNk4sSUFBSSxDQUFDQyxHQUFHLENBQUMvYixNQUFNLENBQUNpTyxNQUFNLENBQUMsQ0FBQztFQUNuRyxDQUFDLENBQUM7RUFDRixNQUFNd1IsT0FBTyxHQUFHLElBQUlwRCxHQUFHLENBQUNtRCxRQUFRLENBQUN2cEIsR0FBRyxDQUFDVixVQUFVLElBQUlBLFVBQVUsQ0FBQ29ELEVBQUUsQ0FBQyxDQUFDO0VBQ2xFNlksT0FBTyxDQUFDOVgsS0FBSyxDQUFDb1MsT0FBTyxDQUFDLENBQUNvVCxNQUFNLEVBQUVqRCxLQUFLLEtBQUs7SUFDdkMsTUFBTXlELFFBQVEsR0FBRyxHQUFHM0csSUFBSSxJQUFJa0QsS0FBSyxHQUFHO0lBQ3BDLElBQUlxRCxRQUFRLENBQUN2RCxHQUFHLENBQUNtRCxNQUFNLENBQUNuZ0IsUUFBUSxDQUFDLEVBQUU4WixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxXQUFXLEVBQUUsb0JBQW9CLENBQUM7SUFDakdKLFFBQVEsQ0FBQ3RELEdBQUcsQ0FBQ2tELE1BQU0sQ0FBQ25nQixRQUFRLENBQUM7SUFDN0IsSUFBSSxDQUFDMGdCLE9BQU8sQ0FBQzFELEdBQUcsQ0FBQ21ELE1BQU0sQ0FBQ25nQixRQUFRLENBQUMsRUFBRThaLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLFdBQVcsRUFBRSx1QkFBdUIsRUFBRSxtQkFBbUIsQ0FBQztJQUN6SCxJQUFJUixNQUFNLENBQUN4bEIsS0FBSyxLQUFLLFNBQVMsRUFBRW1mLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLFFBQVEsRUFBRSx5QkFBeUIsQ0FBQztJQUNoRyxJQUFJUixNQUFNLENBQUN4bEIsS0FBSyxLQUFLLE1BQU0sSUFBSSxDQUFDb2lCLElBQUksQ0FBQ0MsR0FBRyxDQUFDbUQsTUFBTSxDQUFDbmdCLFFBQVEsQ0FBQyxFQUFFOFosUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsUUFBUSxFQUFFLHdCQUF3QixDQUFDO0lBQzFILElBQUlSLE1BQU0sQ0FBQ3hsQixLQUFLLEtBQUssT0FBTyxJQUFJb2lCLElBQUksQ0FBQ0MsR0FBRyxDQUFDbUQsTUFBTSxDQUFDbmdCLFFBQVEsQ0FBQyxJQUFJc2dCLEtBQUssQ0FBQ2xWLFVBQVUsS0FBSyxXQUFXLEVBQUUwTyxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxRQUFRLEVBQUUsa0NBQWtDLENBQUM7RUFDMUssQ0FBQyxDQUFDO0VBQ0YsS0FBSyxNQUFNbnFCLFVBQVUsSUFBSWlxQixRQUFRLEVBQUUsSUFBSSxDQUFDRixRQUFRLENBQUN2RCxHQUFHLENBQUN4bUIsVUFBVSxDQUFDb0QsRUFBRSxDQUFDLEVBQUVrZ0IsUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSxzQkFBc0IsQ0FBQztFQUNuSCxPQUFPRCxNQUFNO0FBQ2Y7QUFDQSxPQUFPLFNBQVM2RyxrQkFBa0JBLENBQUNkLEtBQWMsRUFBRTlGLElBQUksR0FBRyxRQUFRLEVBQTZDO0VBQUUsT0FBTzJGLGNBQWMsQ0FBQzlMLGNBQWMsQ0FBQ3hkLE1BQU0sRUFBRXlwQixLQUFLLEVBQUU5RixJQUFJLENBQUM7QUFBRTtBQUM1SyxTQUFTNkcsb0JBQW9CQSxDQUFDZixLQUFjLEVBQUU5RixJQUFZLEVBQUV3QyxVQUE2QixFQUE0QjtFQUNuSCxJQUFJLENBQUMzRCxRQUFRLENBQUNpSCxLQUFLLENBQUMsSUFBSSxDQUFDOW5CLFlBQVksQ0FBQ29sQixRQUFRLENBQUMwQyxLQUFLLENBQUNqbUIsSUFBa0IsQ0FBQyxFQUFFLE9BQU87SUFBRStsQixFQUFFLEVBQUUsS0FBSztJQUFFN0YsTUFBTSxFQUFFLENBQUM7TUFBRUwsSUFBSSxFQUFFLG1CQUFtQjtNQUFFTSxJQUFJLEVBQUUsR0FBR0EsSUFBSSxPQUFPO01BQUVDLE9BQU8sRUFBRTtJQUFjLENBQUM7RUFBRSxDQUFDO0VBQ3JMLE1BQU1rRyxNQUFNLEdBQUdSLGNBQWMsQ0FBU0osWUFBWSxDQUFDTyxLQUFLLENBQUNqbUIsSUFBa0IsQ0FBQyxFQUFFaW1CLEtBQUssRUFBRTlGLElBQUksRUFBQ3dDLFVBQVUsQ0FBQztFQUNyRyxJQUFJLENBQUMyRCxNQUFNLENBQUNQLEVBQUUsRUFBRSxPQUFPTyxNQUFNO0VBQzdCLE1BQU1wRyxNQUF5QixHQUFHLEVBQUU7RUFBRStHLGtCQUFrQixDQUFDWCxNQUFNLENBQUN4bEIsS0FBSyxFQUFFcWYsSUFBSSxFQUFFRCxNQUFNLENBQUM7RUFDcEYsT0FBT0EsTUFBTSxDQUFDak0sTUFBTSxHQUFHO0lBQUU4UixFQUFFLEVBQUUsS0FBSztJQUFFN0Y7RUFBTyxDQUFDLEdBQUdvRyxNQUFNO0FBQ3ZEO0FBQ0EsT0FBTyxTQUFTWSxjQUFjQSxDQUFDakIsS0FBYyxFQUFFOUYsSUFBSSxHQUFHLFFBQVEsRUFBNEI7RUFBQyxPQUFPNkcsb0JBQW9CLENBQUNmLEtBQUssRUFBQzlGLElBQUksQ0FBQztBQUFDO0FBQ25JLE9BQU8sU0FBU2dILGdCQUFnQkEsQ0FBQ2xCLEtBQWMsRUFBRTlGLElBQUksR0FBRyxVQUFVLEVBQThCO0VBQUUsT0FBTzJGLGNBQWMsQ0FBQ1AsY0FBYyxFQUFFVSxLQUFLLEVBQUU5RixJQUFJLENBQUM7QUFBRTtBQUV0SixPQUFPLFNBQVNpSCxxQkFBcUJBLENBQUM3cUIsUUFBNEIsRUFBRXVFLEtBQWlCLEVBQUVxZixJQUFJLEdBQUcsT0FBTyxFQUFFa0gsWUFBWSxHQUFHLElBQUksRUFBcUI7RUFDN0ksTUFBTW5ILE1BQXlCLEdBQUcsRUFBRTtJQUFFbGYsSUFBSSxHQUFHekUsUUFBUSxDQUFDeUUsSUFBSTtFQUMxRCxJQUFJRixLQUFLLENBQUM3QixJQUFJLEtBQUssU0FBUyxFQUFFO0lBQUUsSUFBSSxDQUFDb29CLFlBQVksRUFBRXBILFFBQVEsQ0FBQ0MsTUFBTSxFQUFFQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsbUJBQW1CLENBQUM7SUFBRSxPQUFPRCxNQUFNO0VBQUU7RUFDbkksSUFBSXBmLEtBQUssQ0FBQzdCLElBQUksS0FBSytCLElBQUksQ0FBQzBFLFNBQVMsRUFBRTtJQUFFdWEsUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSxzQkFBc0IsQ0FBQztJQUFFLE9BQU9ELE1BQU07RUFBRTtFQUNwRyxJQUFJcGYsS0FBSyxDQUFDN0IsSUFBSSxLQUFLLFNBQVMsRUFBRTtJQUFBLElBQUFxb0IsaUJBQUEsRUFBQUMsaUJBQUE7SUFDNUIsTUFBTTFWLEdBQUcsSUFBQXlWLGlCQUFBLEdBQUd0bUIsSUFBSSxDQUFDNkUsT0FBTyxDQUFDZ00sR0FBRyxjQUFBeVYsaUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxDQUFDLFVBQWE7TUFBRXhWLEdBQUcsSUFBQXlWLGlCQUFBLEdBQUd2bUIsSUFBSSxDQUFDNkUsT0FBTyxDQUFDaU0sR0FBRyxjQUFBeVYsaUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxVQUFhO0lBQ3ZGLElBQUksQ0FBQzFOLE1BQU0sQ0FBQzZKLGFBQWEsQ0FBQzVpQixLQUFLLENBQUNBLEtBQUssQ0FBQyxJQUFJQSxLQUFLLENBQUNBLEtBQUssR0FBRytRLEdBQUcsSUFBSS9RLEtBQUssQ0FBQ0EsS0FBSyxHQUFHZ1IsR0FBRyxFQUFFbU8sUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSxxQkFBcUIsQ0FBQztFQUNqSTtFQUNBLElBQUksQ0FBQ3JmLEtBQUssQ0FBQzdCLElBQUksS0FBSyxNQUFNLElBQUk2QixLQUFLLENBQUM3QixJQUFJLEtBQUssU0FBUyxLQUFLK0IsSUFBSSxDQUFDNkUsT0FBTyxDQUFDQyxNQUFNLElBQUksQ0FBQzlFLElBQUksQ0FBQzZFLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDeWQsUUFBUSxDQUFDemlCLEtBQUssQ0FBQ0EsS0FBSyxDQUFDLEVBQUVtZixRQUFRLENBQUNDLE1BQU0sRUFBRUMsSUFBSSxFQUFFLG9CQUFvQixDQUFDO0VBQzFLLE9BQU9ELE1BQU07QUFDZjtBQUNBLFNBQVMrRyxrQkFBa0JBLENBQUN6bUIsTUFBYyxFQUFFMmYsSUFBWSxFQUFFRCxNQUF5QixFQUFRO0VBQUEsSUFBQXNILHFCQUFBLEVBQUFDLGtCQUFBLEVBQUFDLG1CQUFBLEVBQUFDLG1CQUFBLEVBQUFDLHFCQUFBO0VBQ3pGLE1BQU1DLEtBQUssR0FBR0EsQ0FBQ3JjLEtBQWEsRUFBRTRVLE9BQWUsS0FBV0gsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxJQUFJM1UsS0FBSyxFQUFFLEVBQUU0VSxPQUFPLENBQUM7RUFDckcsTUFBTTBILE9BQXFCLEdBQUcsQ0FBQyxlQUFlLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLGtCQUFrQixFQUFFLGNBQWMsRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQztFQUNuSyxJQUFJLENBQUNBLE9BQU8sQ0FBQ3ZFLFFBQVEsQ0FBQy9pQixNQUFNLENBQUNSLElBQUksQ0FBQyxJQUFJLENBQUNRLE1BQU0sQ0FBQytPLElBQUksQ0FBQ3dZLElBQUksQ0FBQyxDQUFDLEVBQUU7SUFDekQsSUFBSXZuQixNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLEVBQUU2bkIsS0FBSyxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQyxLQUN0RCxJQUFJLENBQUM1bkIsbUJBQW1CLENBQUNPLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDRyxPQUFPLENBQUMsQ0FBQzRtQixJQUFJLENBQUMsQ0FBQyxFQUFFRixLQUFLLENBQUMsY0FBYyxFQUFFLG1CQUFtQixDQUFDO0VBQ3ZHO0VBQ0EsSUFBSXJuQixNQUFNLENBQUNxUCxVQUFVLEtBQUssWUFBWSxJQUFJLENBQUNyUCxNQUFNLENBQUMrTSxtQkFBbUIsRUFBRXNhLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSx5QkFBeUIsQ0FBQztFQUM5SCxJQUFJcm5CLE1BQU0sQ0FBQ0MsU0FBUyxJQUFJLENBQUNELE1BQU0sQ0FBQzhrQixtQkFBbUIsRUFBRXVDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxrQkFBa0IsQ0FBQztFQUNyRyxJQUFJLENBQUNybkIsTUFBTSxDQUFDQyxTQUFTLElBQUlELE1BQU0sQ0FBQzhrQixtQkFBbUIsRUFBRXVDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSw0QkFBNEIsQ0FBQztFQUMvRyxLQUFLLE1BQU1HLFNBQVMsSUFBSTVwQixNQUFNLENBQUNDLElBQUksQ0FBQ21DLE1BQU0sQ0FBQ3dQLFlBQVksQ0FBQyxFQUFFO0lBQ3hELE1BQU15RSxNQUFNLEdBQUd1RixjQUFjLENBQUN4WixNQUFNLENBQUNSLElBQUksQ0FBQztJQUMxQyxJQUFJNUIsTUFBTSxDQUFDaW1CLE1BQU0sQ0FBQ2MsWUFBWSxFQUFFNkMsU0FBUyxDQUFDLElBQUt2VCxNQUFNLENBQUN4VixJQUFJLEtBQUssUUFBUSxJQUFJYixNQUFNLENBQUNpbUIsTUFBTSxDQUFDNVAsTUFBTSxDQUFDdkosTUFBTSxFQUFFOGMsU0FBUyxDQUFFLEVBQUVILEtBQUssQ0FBQyxnQkFBZ0JHLFNBQVMsRUFBRSxFQUFFLHlCQUF5QixDQUFDO0VBQ3BMO0VBQ0EsUUFBUXhuQixNQUFNLENBQUNSLElBQUk7SUFDakIsS0FBSyxPQUFPO01BQ1YsS0FBSyxNQUFNLENBQUNxakIsS0FBSyxFQUFFNEUsVUFBVSxDQUFDLElBQUksRUFBQUMscUJBQUEsR0FBQzFuQixNQUFNLENBQUNRLElBQUksQ0FBQ2lCLFdBQVcsY0FBQWltQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUUsRUFBRTVFLE9BQU8sQ0FBQyxDQUFDO1FBQUEsSUFBQTRFLHFCQUFBO1FBQUUsSUFBSUQsVUFBVSxDQUFDaHBCLElBQUksS0FBSyxTQUFTLElBQUlsRSxZQUFZLENBQUNrdEIsVUFBVSxDQUFDbmQsWUFBWSxFQUFFbWQsVUFBVSxDQUFDbGQsWUFBWSxDQUFDLEdBQUcsQ0FBQyxFQUFFOGMsS0FBSyxDQUFDLG9CQUFvQnhFLEtBQUssR0FBRyxFQUFFLGtCQUFrQixDQUFDO01BQUM7TUFDOU87SUFDRixLQUFLLE1BQU07TUFBRSxJQUFJN2lCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDb0IsUUFBUSxLQUFLLFVBQVUsSUFBSSxDQUFDNUIsTUFBTSxDQUFDUSxJQUFJLENBQUNxQixNQUFNLEVBQUV3bEIsS0FBSyxDQUFDLGFBQWEsRUFBRSxxQkFBcUIsQ0FBQztNQUFFO0lBQzFILEtBQUssV0FBVztNQUNkLElBQUlybkIsTUFBTSxDQUFDUSxJQUFJLENBQUMwQyxRQUFRLEtBQUssVUFBVSxJQUFJLEdBQUE4akIscUJBQUEsR0FBQ2huQixNQUFNLENBQUNRLElBQUksQ0FBQzZDLGNBQWMsY0FBQTJqQixxQkFBQSxlQUExQkEscUJBQUEsQ0FBNEJPLElBQUksQ0FBQyxDQUFDLEdBQUVGLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxvQkFBb0IsQ0FBQztNQUNsSSxJQUFJcm5CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMEMsUUFBUSxLQUFLLE1BQU0sSUFBSSxDQUFDbEQsTUFBTSxDQUFDUSxJQUFJLENBQUM0QyxZQUFZLEVBQUVpa0IsS0FBSyxDQUFDLG1CQUFtQixFQUFFLG1CQUFtQixDQUFDO01BQ2pIO0lBQ0YsS0FBSyxVQUFVO01BQUU7UUFBQSxJQUFBTSxpQkFBQSxFQUFBQyxpQkFBQTtRQUNmLE1BQU1wbkIsSUFBSSxHQUFHUixNQUFNLENBQUNRLElBQUk7UUFDeEIsSUFBSUEsSUFBSSxDQUFDMkUsS0FBSyxLQUFLLFdBQVcsSUFBSSxDQUFDM0UsSUFBSSxDQUFDc0MsT0FBTyxFQUFFdWtCLEtBQUssQ0FBQyxjQUFjLEVBQUUscUJBQXFCLENBQUM7UUFDN0YsSUFBSTdtQixJQUFJLENBQUMwRSxTQUFTLEtBQUssU0FBUyxFQUFFO1VBQUEsSUFBQTJpQixrQkFBQSxFQUFBQyxrQkFBQTtVQUNoQyxJQUFJdG5CLElBQUksQ0FBQzZFLE9BQU8sQ0FBQ0MsTUFBTSxFQUFFK2hCLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSw2QkFBNkIsQ0FBQztVQUNwRixJQUFJLEVBQUFRLGtCQUFBLEdBQUNybkIsSUFBSSxDQUFDNkUsT0FBTyxDQUFDZ00sR0FBRyxjQUFBd1csa0JBQUEsY0FBQUEsa0JBQUEsR0FBSSxDQUFDLFVBQWEsTUFBQUMsa0JBQUEsR0FBS3RuQixJQUFJLENBQUM2RSxPQUFPLENBQUNpTSxHQUFHLGNBQUF3VyxrQkFBQSxjQUFBQSxrQkFBQSxHQUFJLFVBQWEsQ0FBQyxFQUFFVCxLQUFLLENBQUMsY0FBYyxFQUFFLGlCQUFpQixDQUFDO1FBQzFILENBQUMsTUFBTTtVQUFBLElBQUFVLG9CQUFBLEVBQUFDLHFCQUFBO1VBQ0wsSUFBSXhuQixJQUFJLENBQUM2RSxPQUFPLENBQUNnTSxHQUFHLElBQUksSUFBSSxJQUFJN1EsSUFBSSxDQUFDNkUsT0FBTyxDQUFDaU0sR0FBRyxJQUFJLElBQUksRUFBRStWLEtBQUssQ0FBQyxjQUFjLEVBQUUsbUJBQW1CLENBQUM7VUFDcEcsSUFBSTdtQixJQUFJLENBQUMwRSxTQUFTLEtBQUssTUFBTSxLQUFLLEdBQUE2aUIsb0JBQUEsR0FBQ3ZuQixJQUFJLENBQUM2RSxPQUFPLENBQUNDLE1BQU0sY0FBQXlpQixvQkFBQSxlQUFuQkEsb0JBQUEsQ0FBcUJ0VSxNQUFNLEtBQUlqVCxJQUFJLENBQUM2RSxPQUFPLENBQUNDLE1BQU0sQ0FBQ2llLElBQUksQ0FBQ2pqQixLQUFLLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSSxDQUFDQSxLQUFLLENBQUMsQ0FBQyxFQUFFK21CLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSwwQkFBMEIsQ0FBQztVQUNuTSxJQUFJN21CLElBQUksQ0FBQzBFLFNBQVMsS0FBSyxTQUFTLEtBQUE4aUIscUJBQUEsR0FBSXhuQixJQUFJLENBQUM2RSxPQUFPLENBQUNDLE1BQU0sY0FBQTBpQixxQkFBQSxlQUFuQkEscUJBQUEsQ0FBcUJ6RSxJQUFJLENBQUNqakIsS0FBSyxJQUFJLE9BQU9BLEtBQUssS0FBSyxTQUFTLENBQUMsRUFBRSttQixLQUFLLENBQUMscUJBQXFCLEVBQUUsbUJBQW1CLENBQUM7UUFDdko7UUFDQTNILE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUcrRyxxQkFBcUIsQ0FBQzVtQixNQUFNLEVBQUVRLElBQUksQ0FBQzRFLE9BQU8sRUFBRSxHQUFHdWEsSUFBSSxlQUFlLENBQUMsQ0FBQztRQUNuRixLQUFLLE1BQU0sQ0FBQ1AsQ0FBQyxFQUFFNkksSUFBSSxDQUFDLElBQUksRUFBQUMsZ0JBQUEsR0FBQzFuQixJQUFJLENBQUNnRixVQUFVLGNBQUEwaUIsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxFQUFFLEVBQUVwRixPQUFPLENBQUMsQ0FBQztVQUFBLElBQUFvRixnQkFBQTtVQUFFeEksTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBRytHLHFCQUFxQixDQUFDNW1CLE1BQU0sRUFBRWlvQixJQUFJLENBQUMzbkIsS0FBSyxFQUFFLEdBQUdxZixJQUFJLG9CQUFvQlAsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUFDO1FBQzVKLElBQUksSUFBSTZELEdBQUcsQ0FBQyxFQUFBMEUsaUJBQUEsR0FBQ25uQixJQUFJLENBQUNnRixVQUFVLGNBQUFtaUIsaUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxFQUFFLEVBQUU5cUIsR0FBRyxDQUFDb3JCLElBQUksSUFBSUEsSUFBSSxDQUFDaFMsRUFBRSxDQUFDLENBQUMsQ0FBQzJOLElBQUksS0FBSyxFQUFBZ0UsaUJBQUEsR0FBQ3BuQixJQUFJLENBQUNnRixVQUFVLGNBQUFvaUIsaUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxFQUFFLEVBQUVuVSxNQUFNLEVBQUU0VCxLQUFLLENBQUMsaUJBQWlCLEVBQUUseUJBQXlCLENBQUM7UUFDdEosS0FBSyxNQUFNLENBQUNqSSxDQUFDLEVBQUU2SSxJQUFJLENBQUMsSUFBSSxFQUFBRSxxQkFBQSxHQUFDM25CLElBQUksQ0FBQ3NFLGVBQWUsY0FBQXFqQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUUsRUFBRXJGLE9BQU8sQ0FBQyxDQUFDLEVBQUU7VUFBQSxJQUFBcUYscUJBQUEsRUFBQUMsWUFBQTtVQUM5RDFJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUcrRyxxQkFBcUIsQ0FBQzVtQixNQUFNLEVBQUVpb0IsSUFBSSxDQUFDcFMsSUFBSSxFQUFFLEdBQUc4SixJQUFJLHlCQUF5QlAsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUUsR0FBR3dILHFCQUFxQixDQUFDNW1CLE1BQU0sRUFBRWlvQixJQUFJLENBQUNuUyxFQUFFLEVBQUUsR0FBRzZKLElBQUkseUJBQXlCUCxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztVQUNyTSxJQUFJNkksSUFBSSxDQUFDdFMsU0FBUyxJQUFJLEdBQUF5UyxZQUFBLEdBQUNILElBQUksQ0FBQzFuQixNQUFNLGNBQUE2bkIsWUFBQSxlQUFYQSxZQUFBLENBQWFiLElBQUksQ0FBQyxDQUFDLEdBQUVGLEtBQUssQ0FBQyx3QkFBd0JqSSxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQztRQUMxRztRQUNBLEtBQUssTUFBTSxDQUFDQSxDQUFDLEVBQUU2SSxJQUFJLENBQUMsSUFBSSxFQUFBSSxnQkFBQSxHQUFDN25CLElBQUksQ0FBQzhhLFVBQVUsY0FBQStNLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUksRUFBRSxFQUFFdkYsT0FBTyxDQUFDLENBQUMsRUFBRTtVQUFBLElBQUF1RixnQkFBQTtVQUN6RDNJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUcrRyxxQkFBcUIsQ0FBQzVtQixNQUFNLEVBQUVpb0IsSUFBSSxDQUFDM25CLEtBQUssRUFBRSxHQUFHcWYsSUFBSSxvQkFBb0JQLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO1VBQ3ZHLElBQUksQ0FBQzZJLElBQUksQ0FBQzFuQixNQUFNLENBQUNnbkIsSUFBSSxDQUFDLENBQUMsRUFBRUYsS0FBSyxDQUFDLG1CQUFtQmpJLENBQUMsVUFBVSxFQUFFLGdCQUFnQixDQUFDO1FBQ2xGO1FBQ0E7TUFDRjtJQUNBLEtBQUssUUFBUTtNQUNYLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDMkQsUUFBUSxDQUFDL2lCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa0YsU0FBUyxDQUFDLEtBQUssQ0FBQzFGLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDRixLQUFLLElBQUlOLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDRixLQUFLLENBQUM3QixJQUFJLEtBQUssU0FBUyxDQUFDLEVBQUU0b0IsS0FBSyxDQUFDLFlBQVksRUFBRSxvQkFBb0IsQ0FBQztNQUNySyxJQUFJcm5CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa0YsU0FBUyxLQUFLLEtBQUssSUFBSSxFQUFBdWhCLGtCQUFBLEdBQUFqbkIsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssY0FBQTJtQixrQkFBQSx1QkFBakJBLGtCQUFBLENBQW1CeG9CLElBQUksTUFBSyxTQUFTLEVBQUU0b0IsS0FBSyxDQUFDLFlBQVksRUFBRSxzQkFBc0IsQ0FBQztNQUN6SCxJQUFJcm5CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa0YsU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFBd2hCLG1CQUFBLEdBQUFsbkIsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssY0FBQTRtQixtQkFBQSx1QkFBakJBLG1CQUFBLENBQW1Cem9CLElBQUksTUFBSyxLQUFLLEVBQUU0b0IsS0FBSyxDQUFDLFlBQVksRUFBRSx5QkFBeUIsQ0FBQztNQUN6SCxJQUFJcm5CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa0YsU0FBUyxLQUFLLFNBQVMsSUFBSSxHQUFBeWhCLG1CQUFBLEdBQUNubkIsTUFBTSxDQUFDUSxJQUFJLENBQUNELE1BQU0sY0FBQTRtQixtQkFBQSxlQUFsQkEsbUJBQUEsQ0FBb0JJLElBQUksQ0FBQyxDQUFDLEdBQUVGLEtBQUssQ0FBQyxhQUFhLEVBQUUsaUJBQWlCLENBQUM7TUFDL0csSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQ3RFLFFBQVEsQ0FBQy9pQixNQUFNLENBQUNRLElBQUksQ0FBQ2tGLFNBQVMsQ0FBQyxJQUFJMUYsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssSUFBSSxJQUFJLEtBQUtOLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDRixLQUFLLENBQUM3QixJQUFJLEtBQUssU0FBUyxJQUFJdUIsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssQ0FBQ0EsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFK21CLEtBQUssQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLENBQUM7TUFDeE0sSUFBSXJuQixNQUFNLENBQUNRLElBQUksQ0FBQ2tGLFNBQVMsS0FBSyxRQUFRLElBQUkxRixNQUFNLENBQUNRLElBQUksQ0FBQ0YsS0FBSyxJQUFJLElBQUksSUFBSU4sTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssQ0FBQzdCLElBQUksS0FBSyxTQUFTLEVBQUU0b0IsS0FBSyxDQUFDLFlBQVksRUFBRSx3QkFBd0IsQ0FBQztNQUMxSjtJQUNGLEtBQUssV0FBVztNQUNkLElBQUlybkIsTUFBTSxDQUFDUSxJQUFJLENBQUN1RixTQUFTLEtBQUssUUFBUSxJQUFJLENBQUMvRixNQUFNLENBQUNRLElBQUksQ0FBQ3dGLFFBQVEsRUFBRXFoQixLQUFLLENBQUMsZUFBZSxFQUFFLHVCQUF1QixDQUFDO01BQ2hILElBQUlybkIsTUFBTSxDQUFDUSxJQUFJLENBQUN1RixTQUFTLEtBQUssV0FBVyxJQUFJLEdBQUFxaEIscUJBQUEsR0FBQ3BuQixNQUFNLENBQUNRLElBQUksQ0FBQ3lFLFNBQVMsY0FBQW1pQixxQkFBQSxlQUFyQkEscUJBQUEsQ0FBdUIzVCxNQUFNLEdBQUU0VCxLQUFLLENBQUMsZ0JBQWdCLEVBQUUscUJBQXFCLENBQUM7TUFDM0g7SUFDRixLQUFLLGtCQUFrQjtNQUFFLElBQUlybkIsTUFBTSxDQUFDUSxJQUFJLENBQUN1SSxVQUFVLElBQUksSUFBSSxJQUFJL0ksTUFBTSxDQUFDUSxJQUFJLENBQUN1SSxVQUFVLEdBQUcvSSxNQUFNLENBQUNRLElBQUksQ0FBQ3NJLFlBQVksRUFBRXVlLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxlQUFlLENBQUM7TUFBRTtJQUM3SixLQUFLLGNBQWM7TUFDakIsSUFBS3JuQixNQUFNLENBQUNRLElBQUksQ0FBQzhKLFlBQVksSUFBSSxJQUFJLElBQUk3UCxTQUFTLENBQUN1RixNQUFNLENBQUNRLElBQUksQ0FBQzhKLFlBQVksQ0FBQyxHQUFHLEVBQUUsSUFBTXRLLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDK0osWUFBWSxJQUFJLElBQUksSUFBSTlQLFNBQVMsQ0FBQ3VGLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDK0osWUFBWSxDQUFDLEdBQUcsRUFBRyxFQUFFOGMsS0FBSyxDQUFDLE1BQU0sRUFBRSxlQUFlLENBQUM7TUFDcE0sSUFBSXJuQixNQUFNLENBQUNRLElBQUksQ0FBQzhKLFlBQVksSUFBSSxJQUFJLElBQUl0SyxNQUFNLENBQUNRLElBQUksQ0FBQytKLFlBQVksSUFBSSxJQUFJLElBQUloUSxZQUFZLENBQUN5RixNQUFNLENBQUNRLElBQUksQ0FBQzhKLFlBQVksRUFBRXRLLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDK0osWUFBWSxDQUFDLEdBQUcsQ0FBQyxFQUFFOGMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixDQUFDO01BQzlMO0lBQ0YsS0FBSyxZQUFZO01BQ2YsSUFBSXJuQixNQUFNLENBQUNRLElBQUksQ0FBQ3NjLE9BQU8sS0FBSyxZQUFZLElBQUk5YyxNQUFNLENBQUNRLElBQUksQ0FBQ1ksSUFBSSxLQUFLLE9BQU8sRUFBRWltQixLQUFLLENBQUMsV0FBVyxFQUFFLHVCQUF1QixDQUFDO01BQ3JILElBQUlybkIsTUFBTSxDQUFDUSxJQUFJLENBQUNZLElBQUksS0FBSyxTQUFTLElBQUksQ0FBQ3BCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDc0ssS0FBSyxFQUFFdWMsS0FBSyxDQUFDLFlBQVksRUFBRSxxQkFBcUIsQ0FBQztNQUNwRyxJQUFJcm5CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDWSxJQUFJLEtBQUssT0FBTyxJQUFJLENBQUNxZCxLQUFLLENBQUNDLE9BQU8sQ0FBQzFlLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDcUssU0FBUyxDQUFDLEVBQUV3YyxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsa0JBQWtCLENBQUM7TUFDdEg7SUFDRixLQUFLLFVBQVU7TUFBRTtRQUNmM0gsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBRy9rQiwwQkFBMEIsQ0FBQ2tGLE1BQU0sQ0FBQ1EsSUFBSSxFQUFFLEdBQUdtZixJQUFJLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZFO01BQ0Y7SUFDQSxLQUFLLGlCQUFpQjtNQUNwQixJQUFJM2YsTUFBTSxDQUFDUSxJQUFJLENBQUNpRyxRQUFRLEVBQUU7UUFBRSxJQUFJO1VBQUUsSUFBSTZoQixJQUFJLENBQUNDLGNBQWMsQ0FBQyxJQUFJLEVBQUU7WUFBRTFLLFFBQVEsRUFBRTdkLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDaUcsUUFBUSxDQUFDb1g7VUFBUyxDQUFDLENBQUM7UUFBRSxDQUFDLENBQUMsTUFBTTtVQUFFd0osS0FBSyxDQUFDLHdCQUF3QixFQUFFLHFCQUFxQixDQUFDO1FBQUU7TUFBRTtNQUNsTCxJQUFJcm5CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa00sUUFBUSxFQUFFO1FBQ3hCLE1BQU1BLFFBQVEsR0FBRzFNLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa00sUUFBUTtRQUNyQyxJQUFLQSxRQUFRLENBQUNwTSxLQUFLLElBQUksSUFBSSxNQUFPb00sUUFBUSxDQUFDc00sS0FBSyxJQUFJLElBQUksQ0FBQyxFQUFFcU8sS0FBSyxDQUFDLGVBQWUsRUFBRSwwQkFBMEIsQ0FBQztRQUM3RyxJQUFJM2EsUUFBUSxDQUFDc00sS0FBSyxJQUFJdE0sUUFBUSxDQUFDc00sS0FBSyxDQUFDM0gsR0FBRyxHQUFHM0UsUUFBUSxDQUFDc00sS0FBSyxDQUFDMUgsR0FBRyxFQUFFK1YsS0FBSyxDQUFDLHFCQUFxQixFQUFFLGVBQWUsQ0FBQztRQUM1RyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQ3RFLFFBQVEsQ0FBQ3JXLFFBQVEsQ0FBQ3VNLElBQUksQ0FBQyxJQUFJLENBQUN2TSxRQUFRLENBQUMwTSxLQUFLLEVBQUVpTyxLQUFLLENBQUMscUJBQXFCLEVBQUUsd0JBQXdCLENBQUM7TUFDL0k7TUFDQTtJQUNGLEtBQUssUUFBUTtNQUFDO1FBQ1osTUFBTTlxQixNQUFNLEdBQUN5RCxNQUFNLENBQUNRLElBQUksQ0FBQ3VjLFlBQVk7UUFBQyxJQUFHLENBQUN4Z0IsTUFBTSxFQUFDO1FBQ2pELElBQUc7VUFBQyxNQUFNaXNCLEdBQUcsR0FBQyxJQUFJQyxHQUFHLENBQUNsc0IsTUFBTSxDQUFDeWdCLFVBQVUsQ0FBQztVQUFDLElBQUd3TCxHQUFHLENBQUNuaEIsTUFBTSxLQUFHOUssTUFBTSxDQUFDeWdCLFVBQVUsSUFBRXdMLEdBQUcsQ0FBQ0UsUUFBUSxJQUFFRixHQUFHLENBQUNHLFFBQVEsSUFBRSxDQUFDLENBQUMsUUFBUSxFQUFDLE9BQU8sQ0FBQyxDQUFDNUYsUUFBUSxDQUFDeUYsR0FBRyxDQUFDSSxRQUFRLENBQUMsSUFBRUosR0FBRyxDQUFDSSxRQUFRLEtBQUcsT0FBTyxJQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUMsV0FBVyxFQUFDLE9BQU8sQ0FBQyxDQUFDN0YsUUFBUSxDQUFDeUYsR0FBRyxDQUFDSyxRQUFRLENBQUMsRUFBQ3hCLEtBQUssQ0FBQyw4QkFBOEIsRUFBQywyQkFBMkIsQ0FBQztRQUFDLENBQUMsT0FBSztVQUFDQSxLQUFLLENBQUMsOEJBQThCLEVBQUMsY0FBYyxDQUFDO1FBQUM7UUFDcFcsSUFBRyxDQUFDM29CLFVBQVUsQ0FBQ3FoQixJQUFJLENBQUN4akIsTUFBTSxDQUFDMGdCLGNBQWMsQ0FBQyxJQUFFLENBQUN2ZSxVQUFVLENBQUNxaEIsSUFBSSxDQUFDeGpCLE1BQU0sQ0FBQzJnQixPQUFPLENBQUMsSUFBRSxDQUFDM2dCLE1BQU0sQ0FBQzRnQixhQUFhLElBQUUsQ0FBQyxrQkFBa0IsQ0FBQzRDLElBQUksQ0FBQ3hqQixNQUFNLENBQUNraEIsY0FBYyxDQUFDLElBQUUsQ0FBQyxrQkFBa0IsQ0FBQ3NDLElBQUksQ0FBQ3hqQixNQUFNLENBQUNtaEIsZUFBZSxDQUFDLEVBQUMySixLQUFLLENBQUMsbUJBQW1CLEVBQUMscUJBQXFCLENBQUM7UUFDdlAsSUFBSSxDQUFDLENBQUM5cUIsTUFBTSxDQUFDNmdCLFlBQVksS0FBSyxDQUFDLENBQUM3Z0IsTUFBTSxDQUFDOGdCLGNBQWUsSUFBRTlnQixNQUFNLENBQUM4Z0IsY0FBYyxLQUFHOWdCLE1BQU0sQ0FBQytnQixXQUFXLEtBQUc1SixTQUFTLElBQUVuWCxNQUFNLENBQUNnaEIsT0FBTyxLQUFHN0osU0FBUyxJQUFFblgsTUFBTSxDQUFDaWhCLEtBQUssS0FBRzlKLFNBQVMsQ0FBQyxJQUFFblgsTUFBTSxDQUFDK2dCLFdBQVcsS0FBRzVKLFNBQVMsS0FBR25YLE1BQU0sQ0FBQ2doQixPQUFPLEtBQUc3SixTQUFTLElBQUVuWCxNQUFNLENBQUNpaEIsS0FBSyxLQUFHOUosU0FBUyxJQUFFblgsTUFBTSxDQUFDaWhCLEtBQUssSUFBRWpoQixNQUFNLENBQUNnaEIsT0FBTyxDQUFDLElBQUVoaEIsTUFBTSxDQUFDK2dCLFdBQVcsS0FBRzVKLFNBQVMsS0FBR25YLE1BQU0sQ0FBQ2doQixPQUFPLEtBQUc3SixTQUFTLElBQUVuWCxNQUFNLENBQUNpaEIsS0FBSyxLQUFHOUosU0FBUyxDQUFDLEVBQUMyVCxLQUFLLENBQUMsbUJBQW1CLEVBQUMsZ0NBQWdDLENBQUM7UUFDL2E7TUFDRjtJQUNBLEtBQUssY0FBYztJQUFFLEtBQUssV0FBVztNQUFFLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQ3RILElBQUksQ0FBQy9mLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDNEksUUFBUSxDQUFDLEVBQUVpZSxLQUFLLENBQUMsZUFBZSxFQUFFLDhCQUE4QixDQUFDO01BQUU7RUFDdks7RUFDQXlCLG9CQUFvQixDQUFDOW9CLE1BQU0sQ0FBQ1EsSUFBSSxFQUFFLEdBQUdtZixJQUFJLE9BQU8sRUFBRUQsTUFBTSxDQUFDO0FBQzNEO0FBQ0EsU0FBU29KLG9CQUFvQkEsQ0FBQ3hvQixLQUFjLEVBQUVxZixJQUFZLEVBQUVELE1BQXlCLEVBQUUwQyxLQUFLLEdBQUcsQ0FBQyxFQUFRO0VBQ3RHLElBQUlBLEtBQUssR0FBRyxFQUFFLElBQUksQ0FBQzloQixLQUFLLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsRUFBRTtFQUN2RCxJQUFJbWUsS0FBSyxDQUFDQyxPQUFPLENBQUNwZSxLQUFLLENBQUMsRUFBRTtJQUFFQSxLQUFLLENBQUNvUyxPQUFPLENBQUMsQ0FBQ3RYLElBQUksRUFBRWdrQixDQUFDLEtBQUswSixvQkFBb0IsQ0FBQzF0QixJQUFJLEVBQUUsR0FBR3VrQixJQUFJLElBQUlQLENBQUMsR0FBRyxFQUFFTSxNQUFNLEVBQUUwQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFBRTtFQUFRO0VBQ2hJLE1BQU0yRyxNQUFNLEdBQUd6b0IsS0FBZ0M7RUFDL0MsSUFBSSxZQUFZLElBQUl5b0IsTUFBTSxJQUFJdkssUUFBUSxDQUFDdUssTUFBTSxDQUFDbHFCLFVBQVUsQ0FBQyxFQUFFO0lBQ3pELE1BQU1tYSxLQUFLLEdBQUcrUCxNQUFNLENBQUNscUIsVUFBVTtJQUFFLElBQUlyRSxNQUFNLENBQUN3ZSxLQUFLLENBQUNsRSxLQUFLLENBQUMsSUFBSXRhLE1BQU0sQ0FBQ3dlLEtBQUssQ0FBQ2pFLEdBQUcsQ0FBQyxJQUFJeGEsWUFBWSxDQUFDeWUsS0FBSyxDQUFDbEUsS0FBSyxFQUFFa0UsS0FBSyxDQUFDakUsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFMEssUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxhQUFhLEVBQUUsMEJBQTBCLENBQUM7RUFDaE07RUFDQSxJQUFJLFVBQVUsSUFBSW9KLE1BQU0sSUFBSSxPQUFPQSxNQUFNLENBQUNqVSxLQUFLLEtBQUssUUFBUSxJQUFJLE9BQU9pVSxNQUFNLENBQUNoVSxHQUFHLEtBQUssUUFBUSxJQUFJZ1UsTUFBTSxDQUFDalUsS0FBSyxJQUFJaVUsTUFBTSxDQUFDaFUsR0FBRyxFQUFFMEssUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSx3QkFBd0IsQ0FBQztFQUM5SyxLQUFLLE1BQU0sQ0FBQzNVLEtBQUssRUFBRTVQLElBQUksQ0FBQyxJQUFJd0MsTUFBTSxDQUFDa2xCLE9BQU8sQ0FBQ2lHLE1BQU0sQ0FBQyxFQUFFRCxvQkFBb0IsQ0FBQzF0QixJQUFJLEVBQUUsR0FBR3VrQixJQUFJLElBQUkzVSxLQUFLLEVBQUUsRUFBRTBVLE1BQU0sRUFBRTBDLEtBQUssR0FBRyxDQUFDLENBQUM7QUFDdkg7QUFDQSxPQUFPLFNBQVM0RyxpQkFBaUJBLENBQUNocEIsTUFBYyxFQUFxQjtFQUFFLE1BQU1taUIsVUFBNkIsR0FBRyxFQUFFO0VBQUVELElBQUksQ0FBQ2dELFlBQVksQ0FBQ2xsQixNQUFNLENBQUNSLElBQUksQ0FBQyxFQUFFUSxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRW1pQixVQUFVLENBQUM7RUFBRSxPQUFPQSxVQUFVLENBQUN0bEIsR0FBRyxDQUFDb3NCLFNBQVMsS0FBSztJQUFFLEdBQUdBLFNBQVM7SUFBRXRKLElBQUksRUFBRXNKLFNBQVMsQ0FBQ3RKLElBQUksQ0FBQ3VKLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRTtFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUU7QUFDL1EsT0FBTyxTQUFTQyx5QkFBeUJBLENBQUNDLFFBQWtCLEVBQXFCO0VBQUUsTUFBTWpILFVBQTZCLEdBQUcsRUFBRTtFQUFFRCxJQUFJLENBQUM2QyxjQUFjLEVBQUVxRSxRQUFRLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRWpILFVBQVUsQ0FBQztFQUFFLE9BQU9BLFVBQVUsQ0FBQ3RsQixHQUFHLENBQUNvc0IsU0FBUyxLQUFLO0lBQUUsR0FBR0EsU0FBUztJQUFFdEosSUFBSSxFQUFFc0osU0FBUyxDQUFDdEosSUFBSSxDQUFDdUosT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFO0VBQUUsQ0FBQyxDQUFDLENBQUM7QUFBRTtBQUNsUixTQUFTRyxTQUFTQSxDQUFDMUosSUFBWSxFQUFZO0VBQUUsT0FBT0EsSUFBSSxDQUFDdUosT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQzdwQixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNjLE1BQU0sQ0FBQ21wQixPQUFPLENBQUM7QUFBRTtBQUNsSCxTQUFTQyxZQUFZQSxDQUFJaHRCLE1BQVMsRUFBRTRsQixVQUE2QixFQUFFcUgsS0FBbUMsRUFBSztFQUN6RyxNQUFNQyxJQUFJLEdBQUczWixlQUFlLENBQUN2VCxNQUFNLENBQUM7SUFBRW10QixNQUFNLEdBQUlucUIsRUFBTSxJQUFxQmlxQixLQUFLLFlBQVl2RSxHQUFHLEdBQUd1RSxLQUFLLENBQUNwRSxHQUFHLENBQUM3bEIsRUFBRSxDQUFDLEdBQUczQixNQUFNLENBQUNpbUIsTUFBTSxDQUFDMkYsS0FBSyxFQUFFanFCLEVBQUUsQ0FBQyxHQUFHaXFCLEtBQUssQ0FBQ2pxQixFQUFFLENBQUMsR0FBR21VLFNBQVM7RUFDbEs7RUFDQSxNQUFNaVcsT0FBTyxHQUFHLENBQUMsR0FBR3hILFVBQVUsQ0FBQyxDQUFDcFgsSUFBSSxDQUFDLENBQUM2ZSxDQUFDLEVBQUVDLENBQUMsS0FBSztJQUM3QyxNQUFNQyxJQUFJLEdBQUdGLENBQUMsQ0FBQ2pLLElBQUksQ0FBQ29LLFFBQVEsQ0FBQyxPQUFPLENBQUM7TUFBRUMsSUFBSSxHQUFHSCxDQUFDLENBQUNsSyxJQUFJLENBQUNvSyxRQUFRLENBQUMsT0FBTyxDQUFDO0lBQ3RFLE9BQU8xUSxNQUFNLENBQUN5USxJQUFJLENBQUMsR0FBR3pRLE1BQU0sQ0FBQzJRLElBQUksQ0FBQyxLQUFLRixJQUFJLEdBQUdULFNBQVMsQ0FBQ1EsQ0FBQyxDQUFDbEssSUFBSSxDQUFDLENBQUNsTSxNQUFNLEdBQUc0VixTQUFTLENBQUNPLENBQUMsQ0FBQ2pLLElBQUksQ0FBQyxDQUFDbE0sTUFBTSxHQUFHLENBQUMsQ0FBQztFQUN4RyxDQUFDLENBQUM7RUFDRixLQUFLLE1BQU13VixTQUFTLElBQUlVLE9BQU8sRUFBRTtJQUMvQixNQUFNaEksV0FBVyxHQUFHK0gsTUFBTSxDQUFDVCxTQUFTLENBQUMxcEIsRUFBRSxDQUFDO0lBQUUsSUFBSSxDQUFDb2lCLFdBQVcsRUFBRTtJQUM1RCxNQUFNc0ksS0FBSyxHQUFHWixTQUFTLENBQUNKLFNBQVMsQ0FBQ3RKLElBQUksQ0FBQztNQUFFdUssYUFBYSxHQUFHRCxLQUFLLENBQUM5WSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNO0lBQ2hGLElBQUkrWSxhQUFhLEVBQUVELEtBQUssQ0FBQ0UsR0FBRyxDQUFDLENBQUM7SUFDOUIsTUFBTW5mLEtBQUssR0FBR2lmLEtBQUssQ0FBQ0UsR0FBRyxDQUFDLENBQUM7SUFBRSxJQUFJLENBQUNuZixLQUFLLEVBQUU7SUFDdkMsSUFBSW9mLE1BQU0sR0FBR1gsSUFBMEM7SUFDdkQsS0FBSyxNQUFNakcsSUFBSSxJQUFJeUcsS0FBSyxFQUFFRyxNQUFNLEdBQUdBLE1BQU0sQ0FBQzVHLElBQUksQ0FBNEI7SUFDMUUsSUFBSTBHLGFBQWEsRUFBRTtNQUNqQixJQUFJdkksV0FBVyxLQUFLM1csS0FBSyxFQUFFO01BQzNCLElBQUlwTixNQUFNLENBQUNpbUIsTUFBTSxDQUFDdUcsTUFBTSxFQUFFekksV0FBVyxDQUFDLEVBQUUsTUFBTSxJQUFJMEksS0FBSyxDQUFDLHFEQUFxRCxDQUFDO01BQzlHRCxNQUFNLENBQUN6SSxXQUFXLENBQUMsR0FBR3lJLE1BQU0sQ0FBQ3BmLEtBQUssQ0FBQztNQUFFLE9BQU9vZixNQUFNLENBQUNwZixLQUFLLENBQUM7SUFDM0QsQ0FBQyxNQUNJb2YsTUFBTSxDQUFDcGYsS0FBSyxDQUFDLEdBQUcyVyxXQUFXO0VBQ2xDO0VBQ0EsT0FBTzhILElBQUk7QUFDYjtBQUNBLE9BQU8sU0FBU2EsdUJBQXVCQSxDQUF1QnRxQixNQUFpQixFQUFFd3BCLEtBQW1DLEVBQWE7RUFBQSxJQUFBZSxrQkFBQTtFQUMvSCxNQUFNZCxJQUFJLEdBQUdGLFlBQVksQ0FBQ3ZwQixNQUFNLEVBQUVncEIsaUJBQWlCLENBQUNocEIsTUFBTSxDQUFDLEVBQUV3cEIsS0FBSyxDQUFDO0lBQUVFLE1BQU0sR0FBSW5xQixFQUFNO01BQUEsSUFBQWlyQixJQUFBO01BQUEsUUFBQUEsSUFBQSxHQUFNaEIsS0FBSyxZQUFZdkUsR0FBRyxHQUFHdUUsS0FBSyxDQUFDcEUsR0FBRyxDQUFDN2xCLEVBQUUsQ0FBQyxHQUFHaXFCLEtBQUssQ0FBQ2pxQixFQUFFLENBQUMsY0FBQWlyQixJQUFBLGNBQUFBLElBQUEsR0FBS2pyQixFQUFFO0lBQUE7RUFDbEosSUFBSSxDQUFDUyxNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLElBQUlRLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLFdBQVcsTUFBQStxQixrQkFBQSxHQUFLdnFCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDNlYsS0FBSyxjQUFBa1Usa0JBQUEsZUFBakJBLGtCQUFBLENBQW1COVQsUUFBUSxLQUFLZ1QsSUFBSSxDQUFDanFCLElBQUksS0FBSyxPQUFPLElBQUlpcUIsSUFBSSxDQUFDanFCLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSWlxQixJQUFJLENBQUNqcEIsSUFBSSxDQUFDNlYsS0FBSyxFQUFFb1QsSUFBSSxDQUFDanBCLElBQUksQ0FBQzZWLEtBQUssQ0FBQ0ksUUFBUSxHQUFHN1ksTUFBTSxDQUFDWSxXQUFXLENBQUNaLE1BQU0sQ0FBQ2tsQixPQUFPLENBQUM5aUIsTUFBTSxDQUFDUSxJQUFJLENBQUM2VixLQUFLLENBQUNJLFFBQVEsQ0FBQyxDQUFDNVosR0FBRyxDQUFDLENBQUMsQ0FBQ04sTUFBTSxFQUFFME8sTUFBTSxDQUFDLEtBQUssQ0FBQ3llLE1BQU0sQ0FBQ250QixNQUFNLENBQUMsRUFBRW10QixNQUFNLENBQUN6ZSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDN1QsT0FBT3dlLElBQUk7QUFDYjtBQUNBLE9BQU8sU0FBU2dCLHlCQUF5QkEsQ0FBQ3JCLFFBQWtCLEVBQUVJLEtBQW1DLEVBQVk7RUFBRSxPQUFPRCxZQUFZLENBQUNILFFBQVEsRUFBRUQseUJBQXlCLENBQUNDLFFBQVEsQ0FBQyxFQUFFSSxLQUFLLENBQUM7QUFBRTtBQUcxTCxNQUFNa0Isb0JBQW9CLEdBQUczVyxHQUFHLENBQUM7RUFBRWpGLFNBQVMsRUFBRWtGLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0VBQUV3WCxtQkFBbUIsRUFBRTNXLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0VBQUV0TCxXQUFXLEVBQUVtTSxHQUFHLENBQUM7SUFBRXZWLElBQUksRUFBRTtFQUFPLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDdEksTUFBTW1zQixVQUFVLEdBQUc3VyxHQUFHLENBQUM7RUFBRXhVLEVBQUUsRUFBRXlVLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0VBQUVwRSxJQUFJLEVBQUVpRixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQUVnWSxJQUFJLEVBQUU3VyxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFBRWlZLFNBQVMsRUFBRTlXLEdBQUcsQ0FBQ0YsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUFFaVgsUUFBUSxFQUFFL1csR0FBRyxDQUFDUSxNQUFNLENBQUNFLEtBQUssQ0FBQzdCLEdBQUcsQ0FBQyxDQUFDLEVBQUVHLEdBQUcsQ0FBQyxDQUFDLEVBQUVFLElBQUksRUFBRUksRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUVyVixHQUFHLENBQUM7QUFBRSxDQUFDLENBQUM7QUFDakwsTUFBTStzQixtQkFBMEMsR0FBRztFQUFFbGMsU0FBUyxFQUFFa0YsR0FBRyxDQUFDYixRQUFRLENBQUM7RUFBRXBFLElBQUksRUFBRWlGLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7RUFBRW5ELGFBQWEsRUFBRXNFLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDalosY0FBYyxDQUFDLENBQUM7RUFBRThVLFFBQVEsRUFBRTZFLEdBQUcsQ0FBQztJQUFFdlYsSUFBSSxFQUFFO0VBQVcsQ0FBQyxDQUFDO0VBQUVrUixVQUFVLEVBQUVxRSxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFBRWpELFNBQVMsRUFBRW9FLEdBQUcsQ0FBQ1osSUFBSSxDQUFDO0VBQUVyRCxlQUFlLEVBQUVpRSxHQUFHLENBQUNKLEdBQUcsQ0FBQzhXLG9CQUFvQixDQUFDO0FBQUUsQ0FBQztBQUNwUixNQUFNTyxrQkFBa0IsR0FBRyxDQUFDLEdBQUdydEIsTUFBTSxDQUFDQyxJQUFJLENBQUNtdEIsbUJBQW1CLENBQUMsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUM7QUFDL0csTUFBTUUsV0FBVyxHQUFHLENBQUMsR0FBR0Qsa0JBQWtCLEVBQUUsb0JBQW9CLENBQUM7QUFDakUsTUFBTUUsa0JBQTBCLEdBQUd2WCxHQUFHLENBQUM7RUFBRW5WLElBQUksRUFBRTtBQUFPLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQztBQUN2RSxTQUFTMnNCLDZCQUE2QkEsQ0FBQ3ZyQixPQUF1QixFQUFFd3JCLE1BQXdCLEVBQUUxTCxJQUFZLEVBQUVELE1BQXlCLEVBQVE7RUFDdkksTUFBTTRMLGNBQWMsR0FBRyxJQUFJckksR0FBRyxDQUFLLENBQUM7SUFBRXNJLGNBQWMsR0FBRyxJQUFJdEksR0FBRyxDQUFLLENBQUNwakIsT0FBTyxDQUFDaVAsU0FBUyxDQUFDLENBQUM7SUFBRWlYLEdBQUcsR0FBRyxJQUFJOUMsR0FBRyxDQUFLLENBQUM7RUFDNUdwakIsT0FBTyxDQUFDa1EsZUFBZSxDQUFDMkMsT0FBTyxDQUFDLENBQUN1VyxTQUFTLEVBQUVwRyxLQUFLLEtBQUs7SUFDcEQsSUFBSXlJLGNBQWMsQ0FBQzNJLEdBQUcsQ0FBQ3NHLFNBQVMsQ0FBQ25hLFNBQVMsQ0FBQyxFQUFFMlEsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxvQkFBb0JrRCxLQUFLLEdBQUcsRUFBRSxtREFBbUQsRUFBRSxtQkFBbUIsQ0FBQztJQUM1S3lJLGNBQWMsQ0FBQzFJLEdBQUcsQ0FBQ3FHLFNBQVMsQ0FBQ25hLFNBQVMsQ0FBQztFQUN6QyxDQUFDLENBQUM7RUFDRixNQUFNMGMsUUFBUSxHQUFHLENBQUM7SUFBRUMsT0FBTyxFQUFFNXJCLE9BQU87SUFBRXltQixRQUFRLEVBQUUzRztFQUFLLENBQUMsRUFBRSxHQUFHMEwsTUFBTSxDQUFDeHVCLEdBQUcsQ0FBQzZ1QixLQUFLLElBQUk7SUFDN0UsTUFBTUMsY0FBYyxHQUFHOXJCLE9BQU8sQ0FBQ2tRLGVBQWUsQ0FBQzZiLFNBQVMsQ0FBQzNDLFNBQVMsSUFBSUEsU0FBUyxDQUFDbmEsU0FBUyxLQUFLNGMsS0FBSyxDQUFDNWMsU0FBUyxDQUFDO0lBQzlHLE9BQU87TUFBRTJjLE9BQU8sRUFBRUMsS0FBSztNQUFFcEYsUUFBUSxFQUFFLEdBQUczRyxJQUFJLG9CQUFvQmdNLGNBQWM7SUFBSSxDQUFDO0VBQ25GLENBQUMsQ0FBQyxDQUFDO0VBQ0gsTUFBTTliLFNBQVMsR0FBRyxJQUFJb1YsR0FBRyxDQUE2QixDQUFDO0VBQ3ZELEtBQUssTUFBTSxDQUFDcEMsS0FBSyxFQUFFO0lBQUU0SSxPQUFPO0lBQUVuRjtFQUFTLENBQUMsQ0FBQyxJQUFJa0YsUUFBUSxDQUFDMUksT0FBTyxDQUFDLENBQUMsRUFBRTtJQUMvRCxJQUFJRCxLQUFLLEdBQUcsQ0FBQyxFQUFFO01BQ2IsSUFBSTBJLGNBQWMsQ0FBQzVJLEdBQUcsQ0FBQzhJLE9BQU8sQ0FBQzNjLFNBQVMsQ0FBQyxFQUFFMlEsUUFBUSxDQUFDQyxNQUFNLEVBQUU0RyxRQUFRLEVBQUUsOENBQThDLEVBQUUsbUJBQW1CLENBQUM7TUFDMUlpRixjQUFjLENBQUMzSSxHQUFHLENBQUM2SSxPQUFPLENBQUMzYyxTQUFTLENBQUM7SUFDdkM7SUFDQSxLQUFLLE1BQU0sQ0FBQytjLGFBQWEsRUFBRUMsUUFBUSxDQUFDLElBQUlMLE9BQU8sQ0FBQzViLFNBQVMsQ0FBQ2lULE9BQU8sQ0FBQyxDQUFDLEVBQUU7TUFDbkUsTUFBTWlKLFFBQVEsR0FBR2xjLFNBQVMsQ0FBQ3VWLEdBQUcsQ0FBQzBHLFFBQVEsQ0FBQ3ZzQixFQUFFLENBQUM7TUFDM0MsSUFBSXdzQixRQUFRLElBQUksQ0FBQ254QixzQkFBc0IsQ0FBQ214QixRQUFRLEVBQUVELFFBQVEsQ0FBQyxFQUFFck0sUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsY0FBY3VGLGFBQWEsTUFBTSxFQUFFLGtEQUFrRCxFQUFFLG1CQUFtQixDQUFDO01BQ3BNaGMsU0FBUyxDQUFDd1YsR0FBRyxDQUFDeUcsUUFBUSxDQUFDdnNCLEVBQUUsRUFBRXVzQixRQUFRLENBQUM7SUFDdEM7SUFDQSxLQUFLLE1BQU0sQ0FBQzl1QixVQUFVLEVBQUVndkIsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRVAsT0FBTyxDQUFDM3JCLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFMnJCLE9BQU8sQ0FBQ3piLFNBQVMsQ0FBQyxDQUFDLEVBQVdnYyxPQUFPLENBQUN0WixPQUFPLENBQUMsQ0FBQzhCLE1BQU0sRUFBRXlYLFdBQVcsS0FBSztNQUN4SixNQUFNQyxVQUFVLEdBQUcsR0FBRzVGLFFBQVEsSUFBSXRwQixVQUFVLElBQUlpdkIsV0FBVyxHQUFHO01BQzlELElBQUlsRyxHQUFHLENBQUNwRCxHQUFHLENBQUNuTyxNQUFNLENBQUNqVixFQUFFLENBQUMsRUFBRWtnQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHd00sVUFBVSxLQUFLLEVBQUUsMERBQTBELEVBQUUsbUJBQW1CLENBQUM7TUFDN0luRyxHQUFHLENBQUNuRCxHQUFHLENBQUNwTyxNQUFNLENBQUNqVixFQUFFLENBQUM7TUFDbEIsSUFBSWlWLE1BQU0sQ0FBQzFGLFNBQVMsS0FBSzJjLE9BQU8sQ0FBQzNjLFNBQVMsRUFBRTJRLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUd3TSxVQUFVLFlBQVksRUFBRSw2QkFBNkIsRUFBRSxtQkFBbUIsQ0FBQztJQUM3SSxDQUFDLENBQUM7RUFDSjtBQUNGO0FBRUEsU0FBU0MsZUFBZUEsQ0FBQzFHLEtBQWMsRUFBRTlGLElBQVksRUFBRXlNLE9BQWlDLEVBQUVDLFdBQW9CLEVBQUVDLGVBQXdDLEdBQUcsSUFBSXJILEdBQUcsQ0FBQyxDQUFDLEVBQUU1TyxLQUF1QixFQUFvQztFQUFBLElBQUFrVyxlQUFBLEVBQUFDLGVBQUEsRUFBQUMsbUJBQUEsRUFBQUMsb0JBQUEsRUFBQUMscUJBQUE7RUFDL04sTUFBTWpOLE1BQXlCLEdBQUcsRUFBRTtFQUNwQyxJQUFJLENBQUNsQixRQUFRLENBQUNpSCxLQUFLLENBQUMsRUFBRSxPQUFPO0lBQUVGLEVBQUUsRUFBRSxLQUFLO0lBQUU3RixNQUFNLEVBQUUsQ0FBQztNQUFFTCxJQUFJLEVBQUUsbUJBQW1CO01BQUVNLElBQUk7TUFBRUMsT0FBTyxFQUFFO0lBQWUsQ0FBQztFQUFFLENBQUM7RUFDbEgsS0FBSyxNQUFNNVUsS0FBSyxJQUFJcE4sTUFBTSxDQUFDQyxJQUFJLENBQUM0bkIsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDd0Ysa0JBQWtCLENBQUNsSSxRQUFRLENBQUMvWCxLQUFLLENBQUMsRUFBRXlVLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksSUFBSTNVLEtBQUssRUFBRSxFQUFFLGdCQUFnQixDQUFDO0VBQ3ZJLE1BQU00aEIsTUFBTSxHQUFHaHZCLE1BQU0sQ0FBQ1ksV0FBVyxDQUFDWixNQUFNLENBQUNDLElBQUksQ0FBQ210QixtQkFBbUIsQ0FBQyxDQUFDN3FCLE1BQU0sQ0FBQzZLLEtBQUssSUFBSXBOLE1BQU0sQ0FBQ2ltQixNQUFNLENBQUM0QixLQUFLLEVBQUV6YSxLQUFLLENBQUMsQ0FBQyxDQUFDbk8sR0FBRyxDQUFDbU8sS0FBSyxJQUFJLENBQUNBLEtBQUssRUFBRXlhLEtBQUssQ0FBQ3phLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNwSmtYLElBQUksQ0FBQ25PLEdBQUcsQ0FBQ2lYLG1CQUFtQixDQUFDLEVBQUU0QixNQUFNLEVBQUVqTixJQUFJLEVBQUVELE1BQU0sRUFBRSxFQUFFLENBQUM7RUFDeEQsSUFBSStGLEtBQUssQ0FBQy9WLGFBQWEsS0FBS3JWLGNBQWMsRUFBRW9sQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGdCQUFnQixFQUFFLGVBQWUsRUFBRSxvQkFBb0IsQ0FBQztFQUM1SCxNQUFNa04sTUFBTSxHQUFHLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDO0VBQzlELEtBQUssTUFBTTdoQixLQUFLLElBQUk2aEIsTUFBTSxFQUFFLElBQUksQ0FBQ3BPLEtBQUssQ0FBQ0MsT0FBTyxDQUFDK0csS0FBSyxDQUFDemEsS0FBSyxDQUFDLENBQUMsRUFBRXlVLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksSUFBSTNVLEtBQUssRUFBRSxFQUFFLFVBQVUsQ0FBQztFQUM5RyxJQUFJMFUsTUFBTSxDQUFDak0sTUFBTSxFQUFFLE9BQU87SUFBRThSLEVBQUUsRUFBRSxLQUFLO0lBQUU3RjtFQUFPLENBQUM7RUFDL0MsTUFBTTVmLFFBQVEsR0FBRzJsQixLQUFLLENBQUMzbEIsUUFBcUI7SUFBRWtRLFNBQVMsR0FBR3lWLEtBQUssQ0FBQ3pWLFNBQXNCO0lBQUVILFNBQVMsR0FBRzRWLEtBQUssQ0FBQzVWLFNBQXNCO0VBQ2hJLElBQUkvUCxRQUFRLENBQUMyVCxNQUFNLEdBQUd6RCxTQUFTLENBQUN5RCxNQUFNLEdBQUcsTUFBTyxFQUFFLE9BQU87SUFBRThSLEVBQUUsRUFBRSxLQUFLO0lBQUU3RixNQUFNLEVBQUUsQ0FBQztNQUFFTCxJQUFJLEVBQUUsY0FBYztNQUFFTSxJQUFJO01BQUVDLE9BQU8sRUFBRTtJQUFtQyxDQUFDO0VBQUUsQ0FBQztFQUM3SixNQUFNa04sZ0JBQWdCLEdBQUcsSUFBSTdILEdBQUcsQ0FBQzVPLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFMFYsUUFBUSxDQUFDanNCLFFBQVEsQ0FBQ2pELEdBQUcsQ0FBQ21ELE1BQU0sSUFBSSxDQUFDQSxNQUFNLENBQUNULEVBQUUsRUFBRVMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUFFK3NCLGlCQUFpQixHQUFHLElBQUk5SCxHQUFHLENBQUM1TyxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRTBWLFFBQVEsQ0FBQy9iLFNBQVMsQ0FBQ25ULEdBQUcsQ0FBQ3VzQixRQUFRLElBQUksQ0FBQ0EsUUFBUSxDQUFDN3BCLEVBQUUsRUFBRTZwQixRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQzlMO0VBQ0E7RUFDQSxNQUFNNEQsZ0JBQWdCLEdBQUMsSUFBSUMsT0FBTyxDQUEyQixDQUFDO0lBQUNDLGtCQUFrQixHQUFDLElBQUlELE9BQU8sQ0FBNkIsQ0FBQztFQUMzSCxNQUFNRSxRQUFRLEdBQUNBLENBQUNoTCxVQUE0QixFQUFDaUwsTUFBYSxLQUFHakwsVUFBVSxDQUFDdGxCLEdBQUcsQ0FBQ29zQixTQUFTLEtBQUc7SUFBQyxHQUFHQSxTQUFTO0lBQUN0SixJQUFJLEVBQUNzSixTQUFTLENBQUN0SixJQUFJLENBQUNPLEtBQUssQ0FBQ2tOLE1BQU0sQ0FBQzNaLE1BQU0sR0FBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDLENBQUM7RUFDbkozVCxRQUFRLENBQUM0UyxPQUFPLENBQUMsQ0FBQzFTLE1BQU0sRUFBRW9mLENBQUMsS0FBSztJQUFFLElBQUkvSSxLQUFLLElBQUltSSxRQUFRLENBQUN4ZSxNQUFNLENBQUMsSUFBSThzQixnQkFBZ0IsQ0FBQzFILEdBQUcsQ0FBQ3BsQixNQUFNLENBQUNULEVBQVEsQ0FBQyxLQUFLUyxNQUFNLEVBQUU7SUFBUSxNQUFNb3RCLE1BQU0sR0FBQyxHQUFHek4sSUFBSSxhQUFhUCxDQUFDLEdBQUc7TUFBQytDLFVBQTRCLEdBQUMsRUFBRTtJQUFDLE1BQU0yRCxNQUFNLEdBQUdVLG9CQUFvQixDQUFDeG1CLE1BQU0sRUFBQ290QixNQUFNLEVBQUNqTCxVQUFVLENBQUM7SUFBRSxJQUFJLENBQUMyRCxNQUFNLENBQUNQLEVBQUUsRUFBRTdGLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUdpRyxNQUFNLENBQUNwRyxNQUFNLENBQUMsQ0FBQyxLQUFLc04sZ0JBQWdCLENBQUMzSCxHQUFHLENBQUNTLE1BQU0sQ0FBQ3hsQixLQUFLLEVBQUM2c0IsUUFBUSxDQUFDaEwsVUFBVSxFQUFDaUwsTUFBTSxDQUFDLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDdlhwZCxTQUFTLENBQUMwQyxPQUFPLENBQUMsQ0FBQzBXLFFBQVEsRUFBRWhLLENBQUMsS0FBSztJQUFFLElBQUkvSSxLQUFLLElBQUltSSxRQUFRLENBQUM0SyxRQUFRLENBQUMsSUFBSXhyQixNQUFNLENBQUN5dkIsRUFBRSxDQUFDTixpQkFBaUIsQ0FBQzNILEdBQUcsQ0FBQ2dFLFFBQVEsQ0FBQzdwQixFQUFRLENBQUMsRUFBRTZwQixRQUFRLENBQUMsRUFBRTtJQUFPLE1BQU1nRSxNQUFNLEdBQUMsR0FBR3pOLElBQUksY0FBY1AsQ0FBQyxHQUFHO01BQUMrQyxVQUE0QixHQUFDLEVBQUU7SUFBQyxNQUFNMkQsTUFBTSxHQUFHUixjQUFjLENBQVdQLGNBQWMsRUFBQ3FFLFFBQVEsRUFBQ2dFLE1BQU0sRUFBQ2pMLFVBQVUsQ0FBQztJQUFFLElBQUksQ0FBQzJELE1BQU0sQ0FBQ1AsRUFBRSxFQUFFN0YsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR2lHLE1BQU0sQ0FBQ3BHLE1BQU0sQ0FBQyxDQUFDLEtBQUt3TixrQkFBa0IsQ0FBQzdILEdBQUcsQ0FBQ1MsTUFBTSxDQUFDeGxCLEtBQUssRUFBQzZzQixRQUFRLENBQUNoTCxVQUFVLEVBQUNpTCxNQUFNLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUNoYXZkLFNBQVMsQ0FBQzZDLE9BQU8sQ0FBQyxDQUFDb1osUUFBUSxFQUFFMU0sQ0FBQyxLQUFLO0lBQUUsTUFBTTBHLE1BQU0sR0FBR3ByQixnQkFBZ0IsQ0FBQ294QixRQUFRLEVBQUUsR0FBR25NLElBQUksY0FBY1AsQ0FBQyxHQUFHLENBQUM7SUFBRSxJQUFJLENBQUMwRyxNQUFNLENBQUNQLEVBQUUsRUFBRTdGLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUdpRyxNQUFNLENBQUNwRyxNQUFNLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDNUosTUFBTTROLFFBQTJCLEdBQUcsRUFBRTtFQUFFcEwsSUFBSSxDQUFDdE8sR0FBRyxDQUFDZ1gsVUFBVSxDQUFDLEVBQUVuRixLQUFLLENBQUN0VixLQUFLLEVBQUUsR0FBR3dQLElBQUksUUFBUSxFQUFFRCxNQUFNLEVBQUU0TixRQUFRLENBQUM7RUFDN0csSUFBSTVOLE1BQU0sQ0FBQ2pNLE1BQU0sRUFBRSxPQUFPO0lBQUU4UixFQUFFLEVBQUUsS0FBSztJQUFFN0YsTUFBTSxFQUFFQSxNQUFNLENBQUNRLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRztFQUFFLENBQUM7RUFDckUsTUFBTXJnQixPQUFPLEdBQUc0bEIsS0FBa0M7RUFDbEQsTUFBTThILGlCQUFpQixHQUFHLENBQUMsR0FBR2pCLGVBQWUsQ0FBQyxDQUFDenZCLEdBQUcsQ0FBQyxDQUFDLENBQUMwQyxFQUFFLEVBQUVrc0IsT0FBTyxDQUFDLE1BQU07SUFBRWxzQixFQUFFO0lBQUVrc0IsT0FBTztJQUFFNWpCLFdBQVcsRUFBRSxFQUFFO0lBQUV5SCxTQUFTLEVBQUUsRUFBRTtJQUFFMUIsWUFBWSxFQUFFO0VBQUcsQ0FBQyxDQUFDLENBQUM7RUFDMUk4UixNQUFNLENBQUNHLElBQUksQ0FBQyxHQUFHemxCLHFCQUFxQixDQUFDeUYsT0FBTyxFQUFFMHRCLGlCQUFpQixFQUFFNU4sSUFBSSxDQUFDLENBQUM7RUFDdkUsSUFBSUQsTUFBTSxDQUFDak0sTUFBTSxFQUFFLE9BQU87SUFBRThSLEVBQUUsRUFBRSxLQUFLO0lBQUU3RixNQUFNLEVBQUVBLE1BQU0sQ0FBQ1EsS0FBSyxDQUFDLENBQUMsRUFBRSxHQUFHO0VBQUUsQ0FBQztFQUNyRSxNQUFNc04sZ0JBQWdCLEdBQUczdEIsT0FBTyxDQUFDQyxRQUFRLENBQUN5akIsSUFBSSxDQUFDdmpCLE1BQU07SUFBQSxJQUFBeXRCLG1CQUFBO0lBQUEsT0FBSSxDQUFDenRCLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sSUFBSVEsTUFBTSxDQUFDUixJQUFJLEtBQUssV0FBVyxPQUFBaXVCLG1CQUFBLEdBQUt6dEIsTUFBTSxDQUFDUSxJQUFJLENBQUM2VixLQUFLLGNBQUFvWCxtQkFBQSx1QkFBakJBLG1CQUFBLENBQW1CaFgsUUFBUTtFQUFBLEVBQUMsR0FBR3RjLG1CQUFtQixDQUFDMEYsT0FBTyxFQUFFMHRCLGlCQUFpQixDQUFDLEdBQUcxdEIsT0FBTztFQUM3TSxNQUFNNnRCLGVBQWUsR0FBRyxJQUFJekssR0FBRyxDQUFDdUssZ0JBQWdCLENBQUN6ZCxlQUFlLENBQUNsVCxHQUFHLENBQUNvc0IsU0FBUyxJQUFJQSxTQUFTLENBQUNuYSxTQUFTLENBQUMsQ0FBQztFQUN2RyxNQUFNNmUsT0FBTyxHQUFHdkIsT0FBTyxDQUFDd0IsY0FBYyxHQUFHMXpCLG1CQUFtQixDQUFDc3pCLGdCQUFnQixFQUFFcEIsT0FBTyxDQUFDd0IsY0FBYyxDQUFDLEdBQUdsYSxTQUFTO0VBQ2xILElBQUlpYSxPQUFPLEVBQUUsS0FBSyxNQUFNL04sT0FBTyxJQUFJK04sT0FBTyxDQUFDRSxNQUFNLEVBQUVwTyxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGtCQUFrQixFQUFFQyxPQUFPLEVBQUUsbUJBQW1CLENBQUM7RUFDNUgsTUFBTXlMLE1BQU0sSUFBQWtCLGVBQUEsR0FBR29CLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFdEMsTUFBTSxjQUFBa0IsZUFBQSxjQUFBQSxlQUFBLEdBQUksRUFBQUMsZUFBQSxHQUFDSixPQUFPLENBQUNmLE1BQU0sY0FBQW1CLGVBQUEsY0FBQUEsZUFBQSxHQUFJLEVBQUUsRUFBRXJzQixNQUFNLENBQUN1ckIsS0FBSyxJQUFJZ0MsZUFBZSxDQUFDL0ssR0FBRyxDQUFDK0ksS0FBSyxDQUFDNWMsU0FBUyxDQUFDLENBQUM7RUFDOUcsSUFBSWhQLFFBQVEsQ0FBQzJULE1BQU0sR0FBR3pELFNBQVMsQ0FBQ3lELE1BQU0sR0FBRzRYLE1BQU0sQ0FBQ3lDLE1BQU0sQ0FBQyxDQUFDM08sS0FBSyxFQUFFdU0sS0FBSyxLQUFLdk0sS0FBSyxHQUFHdU0sS0FBSyxDQUFDNXJCLFFBQVEsQ0FBQzJULE1BQU0sR0FBR2lZLEtBQUssQ0FBQzFiLFNBQVMsQ0FBQ3lELE1BQU0sRUFBRSxDQUFDLENBQUMsR0FBRyxNQUFPLEVBQUVnTSxRQUFRLENBQUNDLE1BQU0sRUFBRUMsSUFBSSxFQUFFLCtCQUErQixFQUFFLGNBQWMsQ0FBQztFQUN0TjtFQUNBO0VBQ0F5TCw2QkFBNkIsQ0FBQ3ZyQixPQUFPLEVBQUV3ckIsTUFBTSxFQUFFMUwsSUFBSSxFQUFFRCxNQUFNLENBQUM7RUFDNUQsSUFBSThOLGdCQUFnQixLQUFLM3RCLE9BQU8sRUFBRXVyQiw2QkFBNkIsQ0FBQ29DLGdCQUFnQixFQUFFbkMsTUFBTSxFQUFFLEdBQUcxTCxJQUFJLFFBQVEsRUFBRUQsTUFBTSxDQUFDO0VBQ2xILElBQUlBLE1BQU0sQ0FBQ2pNLE1BQU0sRUFBRSxPQUFPO0lBQUU4UixFQUFFLEVBQUUsS0FBSztJQUFFN0YsTUFBTSxFQUFFQSxNQUFNLENBQUNRLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRztFQUFFLENBQUM7RUFDckUsTUFBTTZOLFdBQVcsR0FBRyxDQUFDLEdBQUdQLGdCQUFnQixDQUFDMXRCLFFBQVEsRUFBRSxHQUFHdXJCLE1BQU0sQ0FBQzJDLE9BQU8sQ0FBQ3RDLEtBQUssSUFBSUEsS0FBSyxDQUFDNXJCLFFBQVEsQ0FBQyxDQUFDO0lBQUVtdUIsU0FBUyxHQUFHLElBQUloSixHQUFHLENBQUM4SSxXQUFXLENBQUNseEIsR0FBRyxDQUFDbUQsTUFBTSxJQUFJLENBQUNBLE1BQU0sQ0FBQ1QsRUFBRSxFQUFFUyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25LLE1BQU1rdUIsV0FBVyxHQUFHLElBQUlqSixHQUFHLENBQUMsQ0FBQyxHQUFHcGxCLE9BQU8sQ0FBQ21RLFNBQVMsRUFBRSxHQUFHcWIsTUFBTSxDQUFDMkMsT0FBTyxDQUFDdEMsS0FBSyxJQUFJQSxLQUFLLENBQUMxYixTQUFTLENBQUMsQ0FBQyxDQUFDblQsR0FBRyxDQUFDdXNCLFFBQVEsSUFBSSxDQUFDQSxRQUFRLENBQUM3cEIsRUFBRSxFQUFFNnBCLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDekksTUFBTStFLGNBQWMsR0FBRyxJQUFJbEwsR0FBRyxDQUFDLENBQUMsR0FBR3BqQixPQUFPLENBQUNnUSxTQUFTLEVBQUUsR0FBR3diLE1BQU0sQ0FBQzJDLE9BQU8sQ0FBQ3RDLEtBQUssSUFBSUEsS0FBSyxDQUFDN2IsU0FBUyxDQUFDLENBQUMsQ0FBQ2hULEdBQUcsQ0FBQ2l2QixRQUFRLElBQUlBLFFBQVEsQ0FBQ3ZzQixFQUFFLENBQUMsQ0FBQztFQUNoSSxNQUFNd21CLEdBQUcsR0FBRyxJQUFJOUMsR0FBRyxDQUFTLENBQUM7RUFDN0IsS0FBSyxNQUFNLENBQUNqbUIsVUFBVSxFQUFFZ3ZCLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUVuc0IsT0FBTyxDQUFDQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRUQsT0FBTyxDQUFDbVEsU0FBUyxDQUFDLENBQUMsRUFBV2djLE9BQU8sQ0FBQ3RaLE9BQU8sQ0FBQyxDQUFDOEIsTUFBTSxFQUFFNEssQ0FBQyxLQUFLO0lBQzlJLElBQUkyRyxHQUFHLENBQUNwRCxHQUFHLENBQUNuTyxNQUFNLENBQUNqVixFQUFFLENBQUMsRUFBRWtnQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLElBQUkzaUIsVUFBVSxJQUFJb2lCLENBQUMsTUFBTSxFQUFFLDhCQUE4QixDQUFDO0lBQUUyRyxHQUFHLENBQUNuRCxHQUFHLENBQUNwTyxNQUFNLENBQUNqVixFQUFFLENBQUM7SUFDOUgsSUFBSWlWLE1BQU0sQ0FBQzFGLFNBQVMsS0FBS2pQLE9BQU8sQ0FBQ2lQLFNBQVMsRUFBRTJRLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksSUFBSTNpQixVQUFVLElBQUlvaUIsQ0FBQyxhQUFhLEVBQUUsbUJBQW1CLEVBQUUsbUJBQW1CLENBQUM7RUFDakosQ0FBQyxDQUFDO0VBQ0YsTUFBTWdQLFdBQVcsR0FBR3Z1QixPQUFPLENBQUNnUSxTQUFTLENBQUNoVCxHQUFHLENBQUNpdkIsUUFBUSxJQUFJQSxRQUFRLENBQUN2c0IsRUFBRSxDQUFDO0VBQ2xFLElBQUksSUFBSTBqQixHQUFHLENBQUNtTCxXQUFXLENBQUMsQ0FBQ3hLLElBQUksS0FBS3dLLFdBQVcsQ0FBQzNhLE1BQU0sRUFBRWdNLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksWUFBWSxFQUFFLGNBQWMsQ0FBQztFQUMzRyxJQUFJLENBQUN5TyxXQUFXLENBQUNyTCxRQUFRLENBQUNsakIsT0FBTyxDQUFDOFAsVUFBVSxDQUFDLEVBQUU4UCxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGFBQWEsRUFBRSxpQkFBaUIsRUFBRSxtQkFBbUIsQ0FBQztFQUM3SCxNQUFNME8sU0FBUyxHQUFHeHVCLE9BQU8sQ0FBQ2tRLGVBQWUsQ0FBQ2xULEdBQUcsQ0FBQzZ1QixLQUFLLElBQUksR0FBR0EsS0FBSyxDQUFDNWMsU0FBUyxJQUFJNGMsS0FBSyxDQUFDZixtQkFBbUIsRUFBRSxDQUFDO0VBQ3pHLElBQUksSUFBSTFILEdBQUcsQ0FBQ29MLFNBQVMsQ0FBQyxDQUFDekssSUFBSSxLQUFLeUssU0FBUyxDQUFDNWEsTUFBTSxJQUFJNVQsT0FBTyxDQUFDa1EsZUFBZSxDQUFDd1QsSUFBSSxDQUFDbUksS0FBSyxJQUFJQSxLQUFLLENBQUM1YyxTQUFTLEtBQUtqUCxPQUFPLENBQUNpUCxTQUFTLENBQUMsRUFBRTJRLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksa0JBQWtCLEVBQUUsd0JBQXdCLENBQUM7RUFDdk0sTUFBTTJPLE1BQU0sR0FBRyxJQUFJckosR0FBRyxDQUFxQyxDQUFDO0lBQUV2a0IsT0FBTyxHQUFHLElBQUl1a0IsR0FBRyxDQUFxQyxDQUFDO0VBQ3JILEtBQUssTUFBTWpsQixNQUFNLElBQUkrdEIsV0FBVyxFQUFFUSxpQkFBaUIsQ0FBQ3Z1QixNQUFNLENBQUNRLElBQUksRUFBRVIsTUFBTSxDQUFDVCxFQUFFLEVBQUUrdUIsTUFBTSxFQUFFNXRCLE9BQU8sRUFBRWdmLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGFBQWEzZixNQUFNLENBQUNULEVBQUUsT0FBTyxDQUFDO0VBQzFJLE1BQU1pdkIsYUFBYSxHQUFHLElBQUl2TCxHQUFHLENBQUssQ0FBQyxHQUFHZ0wsU0FBUyxDQUFDcHdCLElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBR3F3QixXQUFXLENBQUNyd0IsSUFBSSxDQUFDLENBQUMsRUFBRSxHQUFHeXdCLE1BQU0sQ0FBQ3p3QixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDakcsS0FBSyxNQUFNbUMsTUFBTSxJQUFJK3RCLFdBQVcsRUFBRTtJQUFBLElBQUFVLG9CQUFBO0lBQ2hDLElBQUl6dUIsTUFBTSxDQUFDUixJQUFJLEtBQUssV0FBVyxLQUFBaXZCLG9CQUFBLEdBQUl6dUIsTUFBTSxDQUFDUSxJQUFJLENBQUMwVixPQUFPLGNBQUF1WSxvQkFBQSxlQUFuQkEsb0JBQUEsQ0FBcUJsdkIsRUFBRSxFQUFFaXZCLGFBQWEsQ0FBQzVMLEdBQUcsQ0FBQzVpQixNQUFNLENBQUNRLElBQUksQ0FBQzBWLE9BQU8sQ0FBQzNXLEVBQUUsQ0FBQztJQUNyRyxJQUFJUyxNQUFNLENBQUNSLElBQUksS0FBSyxvQkFBb0IsRUFBRSxLQUFLLE1BQU1rdkIsWUFBWSxJQUFJOXdCLE1BQU0sQ0FBQzBILE1BQU0sRUFBQXFwQixxQkFBQSxHQUFDM3VCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDaU8sV0FBVyxjQUFBa2dCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxDQUFDLENBQUM7TUFBQSxJQUFBQSxxQkFBQTtNQUFFLEtBQUssTUFBTTNqQixLQUFLLElBQUlwTixNQUFNLENBQUMwSCxNQUFNLENBQUNvcEIsWUFBWSxDQUFDLEVBQUUsSUFBSWpRLEtBQUssQ0FBQ0MsT0FBTyxDQUFDMVQsS0FBSyxDQUFDLEVBQUUsS0FBSyxNQUFNdEwsS0FBSyxJQUFJc0wsS0FBSyxFQUFFLElBQUl3VCxRQUFRLENBQUM5ZSxLQUFLLENBQUMsSUFBSSxPQUFPQSxLQUFLLENBQUNILEVBQUUsS0FBSyxRQUFRLEVBQUVpdkIsYUFBYSxDQUFDNUwsR0FBRyxDQUFDbGpCLEtBQUssQ0FBQ0gsRUFBRSxDQUFDO0lBQUM7RUFDNVM7RUFDQSxNQUFNcXZCLHdCQUF3QixHQUFHdkQsTUFBTSxDQUFDMkMsT0FBTyxDQUFDdEMsS0FBSyxJQUFJLENBQUMsR0FBR0EsS0FBSyxDQUFDNXJCLFFBQVEsQ0FBQ2t1QixPQUFPLENBQUNoRixpQkFBaUIsQ0FBQyxFQUFFLEdBQUcwQyxLQUFLLENBQUMxYixTQUFTLENBQUNnZSxPQUFPLENBQUM3RSx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FDNUpocEIsTUFBTSxDQUFDOG9CLFNBQVM7SUFBQSxJQUFBNEYscUJBQUE7SUFBQSxPQUFJNUYsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxVQUFVLE1BQUEwcEIscUJBQUEsR0FBSXpDLE9BQU8sQ0FBQ3dCLGNBQWMsY0FBQWlCLHFCQUFBLHVCQUF0QkEscUJBQUEsQ0FBeUI1RixTQUFTLENBQUMxcEIsRUFBRSxDQUFDLEtBQUk4ckIsTUFBTSxDQUFDOUgsSUFBSSxDQUFDbUksS0FBSztNQUFBLElBQUFvRCxzQkFBQTtNQUFBLE9BQUlwRCxLQUFLLENBQUM1YyxTQUFTLE9BQUFnZ0Isc0JBQUEsR0FBSzFDLE9BQU8sQ0FBQ3dCLGNBQWMsY0FBQWtCLHNCQUFBLHVCQUF0QkEsc0JBQUEsQ0FBeUI3RixTQUFTLENBQUMxcEIsRUFBRSxDQUFDLENBQUN1UCxTQUFTO0lBQUEsRUFBQztFQUFBLEVBQUMsQ0FBQ2pTLEdBQUcsQ0FBQ29zQixTQUFTLElBQUlBLFNBQVMsQ0FBQzFwQixFQUFFLENBQUM7RUFDN04sTUFBTXd2QixhQUFhLEdBQUcsSUFBSTlMLEdBQUcsQ0FBQyxDQUFDLEdBQUdvSixXQUFXLEVBQUUsR0FBR3VDLHdCQUF3QixFQUFFL3VCLE9BQU8sQ0FBQ2lQLFNBQVMsRUFBRSxHQUFHaWYsV0FBVyxDQUFDNXRCLE1BQU0sQ0FBQ0gsTUFBTSxJQUFJQSxNQUFNLENBQUNSLElBQUksS0FBSyxVQUFVLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ21ELE1BQU0sSUFBSUEsTUFBTSxDQUFDVCxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUFrdEIsbUJBQUEsR0FBQ2tCLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFeEwsVUFBVSxjQUFBc0ssbUJBQUEsY0FBQUEsbUJBQUEsR0FBSWUsZ0JBQWdCLENBQUN6ZCxlQUFlLEVBQUVsVCxHQUFHLENBQUM2dUIsS0FBSyxJQUFJQSxLQUFLLENBQUNmLG1CQUFtQixDQUFDLENBQUMsQ0FBQztFQUMzUixNQUFNcUUsYUFBYSxHQUFHLElBQUkvTCxHQUFHLENBQUMsQ0FBQ3BqQixPQUFPLENBQUNpUCxTQUFTLEVBQUUsR0FBRyxFQUFBNGQsb0JBQUEsR0FBQ2lCLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFeEwsVUFBVSxjQUFBdUssb0JBQUEsY0FBQUEsb0JBQUEsR0FBSWMsZ0JBQWdCLENBQUN6ZCxlQUFlLEVBQUVsVCxHQUFHLENBQUM2dUIsS0FBSyxJQUFJQSxLQUFLLENBQUM1YyxTQUFTLENBQUMsQ0FBQyxDQUFDO0VBRTlJLE1BQU1tZ0IsWUFBNEIsR0FBRztNQUFFbnZCLFFBQVEsRUFBRW11QixTQUFTO01BQUVqZSxTQUFTLEVBQUVrZSxXQUFXO01BQUVJLE1BQU07TUFBRXplLFNBQVMsRUFBRXNlLGNBQWM7TUFBRWUsUUFBUSxFQUFFRixhQUFhO01BQUNSO0lBQWMsQ0FBQztJQUFFVyxjQUFjLEdBQUcsSUFBSWxLLEdBQUcsQ0FBcUIsQ0FBQztFQUM5TSxTQUFTbUssWUFBWUEsQ0FBQ0MsU0FBYSxFQUE4QjtJQUFBLElBQUFDLG9CQUFBLEVBQUFDLHNCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGdCQUFBO0lBQy9ELElBQUlKLFNBQVMsS0FBS3h2QixPQUFPLENBQUNpUCxTQUFTLElBQUksQ0FBQ2pQLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDeWpCLElBQUksQ0FBQ3ZqQixNQUFNO01BQUEsSUFBQTB2QixtQkFBQTtNQUFBLE9BQUksQ0FBQzF2QixNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLElBQUlRLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLFdBQVcsT0FBQWt3QixtQkFBQSxHQUFLMXZCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDNlYsS0FBSyxjQUFBcVosbUJBQUEsdUJBQWpCQSxtQkFBQSxDQUFtQmpaLFFBQVE7SUFBQSxFQUFDLEVBQUUsT0FBT3dZLFlBQVk7SUFDckwsTUFBTTlKLE1BQU0sR0FBR2dLLGNBQWMsQ0FBQy9KLEdBQUcsQ0FBQ2lLLFNBQVMsQ0FBQztJQUFFLElBQUlsSyxNQUFNLEVBQUUsT0FBT0EsTUFBTTtJQUN2RSxNQUFNd0ssVUFBVSxHQUFHTixTQUFTLEtBQUt4dkIsT0FBTyxDQUFDaVAsU0FBUyxHQUFHalAsT0FBTyxJQUFBeXZCLG9CQUFBLEdBQUdoRCxlQUFlLENBQUNsSCxHQUFHLENBQUNpSyxTQUFTLENBQUMsY0FBQUMsb0JBQUEsY0FBQUEsb0JBQUEsSUFBQUMsc0JBQUEsR0FBSW5ELE9BQU8sQ0FBQ3dCLGNBQWMsY0FBQTJCLHNCQUFBLHVCQUF0QkEsc0JBQUEsQ0FBeUJGLFNBQVMsQ0FBQztJQUFFLElBQUksQ0FBQ00sVUFBVSxFQUFFLE9BQU9qYyxTQUFTO0lBQ3ZLLElBQUkrWCxPQUFPLEdBQUdrRSxVQUFVO0lBQ3hCLElBQUk7TUFBRSxJQUFJbEUsT0FBTyxDQUFDM3JCLFFBQVEsQ0FBQ3lqQixJQUFJLENBQUN2akIsTUFBTTtRQUFBLElBQUE0dkIsbUJBQUE7UUFBQSxPQUFJLENBQUM1dkIsTUFBTSxDQUFDUixJQUFJLEtBQUssT0FBTyxJQUFJUSxNQUFNLENBQUNSLElBQUksS0FBSyxXQUFXLE9BQUFvd0IsbUJBQUEsR0FBSzV2QixNQUFNLENBQUNRLElBQUksQ0FBQzZWLEtBQUssY0FBQXVaLG1CQUFBLHVCQUFqQkEsbUJBQUEsQ0FBbUJuWixRQUFRO01BQUEsRUFBQyxFQUFFZ1YsT0FBTyxHQUFHdHhCLG1CQUFtQixDQUFDc3hCLE9BQU8sRUFBRThCLGlCQUFpQixDQUFDO0lBQUUsQ0FBQyxDQUFDLE1BQU07TUFBRSxPQUFPN1osU0FBUztJQUFFO0lBQzNOLE1BQU1tYyxjQUFjLEdBQUd6RCxPQUFPLENBQUN3QixjQUFjLEdBQUcxekIsbUJBQW1CLENBQUN1eEIsT0FBTyxFQUFFVyxPQUFPLENBQUN3QixjQUFjLENBQUMsR0FBR2xhLFNBQVM7SUFDaEgsSUFBSW1jLGNBQWMsRUFBRSxLQUFLLE1BQU1qUSxPQUFPLElBQUlpUSxjQUFjLENBQUNoQyxNQUFNLEVBQUVwTyxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGFBQWEwUCxTQUFTLGtCQUFrQixFQUFFelAsT0FBTyxFQUFFLG1CQUFtQixDQUFDO0lBQ2hLLE1BQU1rUSxZQUFZLElBQUFOLHFCQUFBLEdBQUdLLGNBQWMsYUFBZEEsY0FBYyx1QkFBZEEsY0FBYyxDQUFFeEUsTUFBTSxjQUFBbUUscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFBQyxnQkFBQSxHQUFDckQsT0FBTyxDQUFDZixNQUFNLGNBQUFvRSxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEVBQUUsRUFBRXR2QixNQUFNLENBQUN1ckIsS0FBSyxJQUFJRCxPQUFPLENBQUMxYixlQUFlLENBQUN3VCxJQUFJLENBQUMwRixTQUFTLElBQUlBLFNBQVMsQ0FBQ25hLFNBQVMsS0FBSzRjLEtBQUssQ0FBQzVjLFNBQVMsQ0FBQyxDQUFDO0lBQ3pLLE1BQU15SSxNQUFNLEdBQUdtSSxNQUFNLENBQUNqTSxNQUFNO0lBQUUyWCw2QkFBNkIsQ0FBQ0ssT0FBTyxFQUFFcUUsWUFBWSxFQUFFLEdBQUduUSxJQUFJLGFBQWEwUCxTQUFTLEVBQUUsRUFBRTNQLE1BQU0sQ0FBQztJQUMzSCxJQUFJQSxNQUFNLENBQUNqTSxNQUFNLEtBQUs4RCxNQUFNLEVBQUUsT0FBTzdELFNBQVM7SUFDOUMsTUFBTXNZLE9BQU8sR0FBRyxDQUFDLEdBQUdQLE9BQU8sQ0FBQzNyQixRQUFRLEVBQUUsR0FBR2d3QixZQUFZLENBQUM5QixPQUFPLENBQUN0QyxLQUFLLElBQUlBLEtBQUssQ0FBQzVyQixRQUFRLENBQUMsQ0FBQztNQUFFaXdCLGFBQWEsR0FBRyxJQUFJOUssR0FBRyxDQUFxQyxDQUFDO0lBQ3RKLEtBQUssTUFBTXpRLE1BQU0sSUFBSXdYLE9BQU8sRUFBRSxJQUFJeE4sUUFBUSxDQUFDaEssTUFBTSxDQUFDLEVBQUUrWixpQkFBaUIsQ0FBQy9aLE1BQU0sQ0FBQ2hVLElBQUksRUFBRWdVLE1BQU0sQ0FBQ2pWLEVBQUUsRUFBRXd3QixhQUFhLEVBQUUsSUFBSTlLLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLFNBQVMsQ0FBQztJQUN0SSxNQUFNK0ssb0JBQW9CLEdBQUMsSUFBSS9NLEdBQUcsQ0FBQyxDQUFDLEdBQUcrSSxPQUFPLENBQUNudkIsR0FBRyxDQUFDMlgsTUFBTSxJQUFFQSxNQUFNLENBQUNqVixFQUFFLENBQUMsRUFBQyxHQUFHa3NCLE9BQU8sQ0FBQ3piLFNBQVMsQ0FBQ25ULEdBQUcsQ0FBQ3VzQixRQUFRLElBQUVBLFFBQVEsQ0FBQzdwQixFQUFFLENBQUMsRUFBQyxHQUFHdXdCLFlBQVksQ0FBQzlCLE9BQU8sQ0FBQ3RDLEtBQUssSUFBRUEsS0FBSyxDQUFDMWIsU0FBUyxDQUFDblQsR0FBRyxDQUFDdXNCLFFBQVEsSUFBRUEsUUFBUSxDQUFDN3BCLEVBQUUsQ0FBQyxDQUFDLEVBQUMsR0FBR3d3QixhQUFhLENBQUNseUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFOLEtBQUksTUFBTW1DLE1BQU0sSUFBSWdzQixPQUFPLEVBQUM7TUFBQSxJQUFBaUUscUJBQUE7TUFBQyxJQUFHandCLE1BQU0sQ0FBQ1IsSUFBSSxLQUFHLFdBQVcsS0FBQXl3QixxQkFBQSxHQUFFandCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMFYsT0FBTyxjQUFBK1oscUJBQUEsZUFBbkJBLHFCQUFBLENBQXFCMXdCLEVBQUUsRUFBQ3l3QixvQkFBb0IsQ0FBQ3BOLEdBQUcsQ0FBQzVpQixNQUFNLENBQUNRLElBQUksQ0FBQzBWLE9BQU8sQ0FBQzNXLEVBQUUsQ0FBQztNQUFDLElBQUdTLE1BQU0sQ0FBQ1IsSUFBSSxLQUFHLG9CQUFvQixFQUFDLEtBQUksTUFBTWtMLE1BQU0sSUFBSTlNLE1BQU0sQ0FBQzBILE1BQU0sRUFBQTRxQixzQkFBQSxHQUFDbHdCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDaU8sV0FBVyxjQUFBeWhCLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUUsQ0FBQyxDQUFDLENBQUM7UUFBQSxJQUFBQSxzQkFBQTtRQUFDLEtBQUksTUFBTTV2QixLQUFLLElBQUkxQyxNQUFNLENBQUMwSCxNQUFNLENBQUNvRixNQUFNLENBQUMsRUFBQyxJQUFHK1QsS0FBSyxDQUFDQyxPQUFPLENBQUNwZSxLQUFLLENBQUMsRUFBQyxLQUFJLE1BQU1aLEtBQUssSUFBSVksS0FBSyxFQUFDLElBQUdrZSxRQUFRLENBQUM5ZSxLQUFLLENBQUMsSUFBRSxPQUFPQSxLQUFLLENBQUNILEVBQUUsS0FBRyxRQUFRLEVBQUN5d0Isb0JBQW9CLENBQUNwTixHQUFHLENBQUNsakIsS0FBSyxDQUFDSCxFQUFFLENBQUM7TUFBQztJQUFBO0lBQ3JaLE1BQU1zakIsS0FBSyxHQUFHO01BQUUvaUIsUUFBUSxFQUFFLElBQUltbEIsR0FBRyxDQUFDK0csT0FBTyxDQUFDN3JCLE1BQU0sQ0FBQ3FVLE1BQU0sSUFBSWdLLFFBQVEsQ0FBQ2hLLE1BQU0sQ0FBQyxDQUFDLENBQUMzWCxHQUFHLENBQUMyWCxNQUFNLElBQUksQ0FBQ0EsTUFBTSxDQUFDalYsRUFBRSxFQUFFaVYsTUFBTSxDQUFDLENBQUMsQ0FBQztNQUFFeEUsU0FBUyxFQUFFLElBQUlpVixHQUFHLENBQUMsQ0FBQyxHQUFHd0csT0FBTyxDQUFDemIsU0FBUyxFQUFFLEdBQUc4ZixZQUFZLENBQUM5QixPQUFPLENBQUN0QyxLQUFLLElBQUlBLEtBQUssQ0FBQzFiLFNBQVMsQ0FBQyxDQUFDLENBQUM3UCxNQUFNLENBQUNxVSxNQUFNLElBQUlnSyxRQUFRLENBQUNoSyxNQUFNLENBQUMsQ0FBQyxDQUFDM1gsR0FBRyxDQUFDMlgsTUFBTSxJQUFJLENBQUNBLE1BQU0sQ0FBQ2pWLEVBQUUsRUFBRWlWLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFBRThaLE1BQU0sRUFBRXlCLGFBQWE7TUFBRWxnQixTQUFTLEVBQUUsSUFBSW9ULEdBQUcsQ0FBQyxDQUFDLEdBQUd3SSxPQUFPLENBQUM1YixTQUFTLEVBQUUsR0FBR2lnQixZQUFZLENBQUM5QixPQUFPLENBQUN0QyxLQUFLLElBQUlBLEtBQUssQ0FBQzdiLFNBQVMsQ0FBQyxDQUFDLENBQUNoVCxHQUFHLENBQUNpdkIsUUFBUSxJQUFJQSxRQUFRLENBQUN2c0IsRUFBRSxDQUFDLENBQUM7TUFBRTJ2QixRQUFRLEVBQUUsSUFBSWpNLEdBQUcsQ0FBQyxDQUFDd0ksT0FBTyxDQUFDM2MsU0FBUyxFQUFFLEdBQUdnaEIsWUFBWSxDQUFDanpCLEdBQUcsQ0FBQzZ1QixLQUFLLElBQUlBLEtBQUssQ0FBQzVjLFNBQVMsQ0FBQyxDQUFDLENBQUM7TUFBQzBmLGFBQWEsRUFBQ3dCO0lBQXFCLENBQUM7SUFDcGlCYixjQUFjLENBQUM5SixHQUFHLENBQUNnSyxTQUFTLEVBQUV4TSxLQUFLLENBQUM7SUFBRSxPQUFPQSxLQUFLO0VBQ3BEO0VBQ0EsU0FBU3NOLE9BQU9BLENBQUNsSCxTQUEwQixFQUFFbUUsTUFBTSxHQUFHLEVBQUUsRUFBRXZLLEtBQUssR0FBR29NLFlBQVksRUFBUTtJQUNwRixNQUFNM0ksUUFBUSxHQUFHOEcsTUFBTSxHQUFHLEdBQUdBLE1BQU0sSUFBSW5FLFNBQVMsQ0FBQ3RKLElBQUksRUFBRSxHQUFHc0osU0FBUyxDQUFDdEosSUFBSTtJQUN4RSxJQUFJeVEsTUFBTSxHQUFHLElBQUk7SUFDakIsSUFBSW5ILFNBQVMsQ0FBQzlqQixLQUFLLEtBQUssUUFBUSxFQUFFO01BQ2hDLE1BQU04RixNQUFNLEdBQUc0WCxLQUFLLENBQUMvaUIsUUFBUSxDQUFDc2xCLEdBQUcsQ0FBQzZELFNBQVMsQ0FBQzFwQixFQUFFLENBQUM7TUFBRTZ3QixNQUFNLEdBQUcsQ0FBQyxDQUFDbmxCLE1BQU07TUFDbEUsSUFBSUEsTUFBTSxJQUFJZ2UsU0FBUyxDQUFDelYsS0FBSyxJQUFJLENBQUN5VixTQUFTLENBQUN6VixLQUFLLENBQUN1UCxRQUFRLENBQUM5WCxNQUFNLENBQUN6TCxJQUFJLENBQUMsRUFBRWlnQixRQUFRLENBQUNDLE1BQU0sRUFBRTRHLFFBQVEsRUFBRSxVQUFVMkMsU0FBUyxDQUFDelYsS0FBSyxDQUFDM1csR0FBRyxDQUFDMkMsSUFBSSxJQUFJekUsV0FBVyxDQUFDeUUsSUFBSSxDQUFDLENBQUMsQ0FBQ0csSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsbUJBQW1CLENBQUM7TUFDbk0sSUFBSXNMLE1BQU0sSUFBSW1oQixPQUFPLENBQUMvVSxPQUFPLElBQUlwTSxNQUFNLENBQUNoTCxTQUFTLEVBQUV3ZixRQUFRLENBQUNDLE1BQU0sRUFBRTRHLFFBQVEsRUFBRSx1QkFBdUIsRUFBRSxtQkFBbUIsQ0FBQztJQUM3SCxDQUFDLE1BQU0sSUFBSTJDLFNBQVMsQ0FBQzlqQixLQUFLLEtBQUssVUFBVSxFQUFFaXJCLE1BQU0sR0FBR3ZOLEtBQUssQ0FBQzdTLFNBQVMsQ0FBQzJTLEdBQUcsQ0FBQ3NHLFNBQVMsQ0FBQzFwQixFQUFFLENBQUMsQ0FBQyxLQUNqRixJQUFJMHBCLFNBQVMsQ0FBQzlqQixLQUFLLEtBQUssUUFBUSxFQUFFaXJCLE1BQU0sR0FBR3ZOLEtBQUssQ0FBQy9pQixRQUFRLENBQUM2aUIsR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxJQUFJc2pCLEtBQUssQ0FBQzdTLFNBQVMsQ0FBQzJTLEdBQUcsQ0FBQ3NHLFNBQVMsQ0FBQzFwQixFQUFFLENBQUMsQ0FBQyxLQUNqSCxJQUFJMHBCLFNBQVMsQ0FBQzlqQixLQUFLLEtBQUssbUJBQW1CLEVBQUVpckIsTUFBTSxHQUFHdk4sS0FBSyxDQUFDMkwsYUFBYSxDQUFDN0wsR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLEtBQzVGLElBQUkwcEIsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxjQUFjLEVBQUVpckIsTUFBTSxHQUFHdk4sS0FBSyxDQUFDL2lCLFFBQVEsQ0FBQzZpQixHQUFHLENBQUNzRyxTQUFTLENBQUMxcEIsRUFBRSxDQUFDLElBQUlzakIsS0FBSyxDQUFDeUwsTUFBTSxDQUFDM0wsR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLEtBQ3BILElBQUkwcEIsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxVQUFVLEVBQUVpckIsTUFBTSxHQUFHdk4sS0FBSyxDQUFDaFQsU0FBUyxDQUFDOFMsR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLEtBQy9FLElBQUkwcEIsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxTQUFTLEVBQUVpckIsTUFBTSxHQUFHdk4sS0FBSyxDQUFDcU0sUUFBUSxDQUFDdk0sR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLEtBQzdFLElBQUkwcEIsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxVQUFVLEVBQUVpckIsTUFBTSxHQUFHckIsYUFBYSxDQUFDcE0sR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLEtBQzdFLElBQUkwcEIsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxPQUFPLEVBQUVpckIsTUFBTSxHQUFHdk4sS0FBSyxDQUFDeUwsTUFBTSxDQUFDM0wsR0FBRyxDQUFDc0csU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLEtBQ3pFLElBQUkwcEIsU0FBUyxDQUFDOWpCLEtBQUssS0FBSyxPQUFPLEVBQUVpckIsTUFBTSxHQUFHMXZCLE9BQU8sQ0FBQ2lpQixHQUFHLENBQUNzRyxTQUFTLENBQUMxcEIsRUFBRSxDQUFDO0lBQ3hFLElBQUksQ0FBQzZ3QixNQUFNLEVBQUUzUSxRQUFRLENBQUNDLE1BQU0sRUFBRTRHLFFBQVEsRUFBRSwrQkFBK0IsRUFBRSxtQkFBbUIsQ0FBQztFQUMvRjtFQUNBLE1BQU0rSixhQUFhLEdBQUlyd0IsTUFBYyxJQUF3QjtJQUMzRCxNQUFNa21CLFFBQVEsR0FBQzhHLGdCQUFnQixDQUFDNUgsR0FBRyxDQUFDcGxCLE1BQU0sQ0FBQztJQUFDLElBQUdrbUIsUUFBUSxFQUFDLE9BQU9BLFFBQVE7SUFDdkUsSUFBSSxDQUFDN1AsS0FBSyxJQUFJeVcsZ0JBQWdCLENBQUMxSCxHQUFHLENBQUNwbEIsTUFBTSxDQUFDVCxFQUFFLENBQUMsS0FBS1MsTUFBTSxFQUFFLE9BQU9ncEIsaUJBQWlCLENBQUNocEIsTUFBTSxDQUFDO0lBQzFGLE1BQU1tbEIsTUFBTSxHQUFHOU8sS0FBSyxDQUFDOEwsVUFBVSxDQUFDaUQsR0FBRyxDQUFDcGxCLE1BQU0sQ0FBQztJQUMzQyxJQUFJbWxCLE1BQU0sRUFBRSxPQUFPQSxNQUFNO0lBQ3pCLE1BQU1oRCxVQUFVLEdBQUc2RyxpQkFBaUIsQ0FBQ2hwQixNQUFNLENBQUM7SUFBRXFXLEtBQUssQ0FBQzhMLFVBQVUsQ0FBQ2tELEdBQUcsQ0FBQ3JsQixNQUFNLEVBQUVtaUIsVUFBVSxDQUFDO0lBQUUsT0FBT0EsVUFBVTtFQUMzRyxDQUFDO0VBQ0R0aUIsT0FBTyxDQUFDQyxRQUFRLENBQUM0UyxPQUFPLENBQUMsQ0FBQzFTLE1BQU0sRUFBRW9mLENBQUMsS0FBSztJQUN0QyxNQUFNZ08sTUFBTSxHQUFHLEdBQUd6TixJQUFJLGFBQWFQLENBQUMsR0FBRztJQUN2QyxLQUFLLE1BQU02SixTQUFTLElBQUlvSCxhQUFhLENBQUNyd0IsTUFBTSxDQUFDLEVBQUU7TUFBQSxJQUFBc3dCLHFCQUFBLEVBQUFDLEtBQUEsRUFBQUMsc0JBQUE7TUFDN0MsTUFBTXZHLEtBQUssR0FBR1osU0FBUyxDQUFDSixTQUFTLENBQUN0SixJQUFJLENBQUM7UUFBRThRLE1BQU0sR0FBR3hHLEtBQUssQ0FBQy9KLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzROLE1BQU0sQ0FBVSxDQUFDL0UsTUFBTSxFQUFFL2QsS0FBSyxLQUFLK2QsTUFBTSxJQUFJLE9BQU9BLE1BQU0sS0FBSyxRQUFRLEdBQUlBLE1BQU0sQ0FBNkIvZCxLQUFLLENBQUMsR0FBRzBJLFNBQVMsRUFBRTFULE1BQU0sQ0FBQztNQUM5TSxNQUFNMHdCLFlBQVksR0FBRyxDQUFDMXdCLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sSUFBSVEsTUFBTSxDQUFDUixJQUFJLEtBQUssV0FBVyxLQUFLUSxNQUFNLENBQUNRLElBQUksQ0FBQzZWLEtBQUssSUFBSTRTLFNBQVMsQ0FBQ3RKLElBQUksS0FBSyxxQkFBcUIsR0FBRzNmLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDNlYsS0FBSyxDQUFDRSxnQkFBZ0IsR0FBRzdDLFNBQVM7TUFDL0wsTUFBTWlkLGNBQWMsR0FBQzN3QixNQUFNLENBQUNSLElBQUksS0FBRyxvQkFBb0IsSUFBRVEsTUFBTSxDQUFDUSxJQUFJLENBQUN3VSxlQUFlLElBQUUscUlBQXFJLENBQUMrSyxJQUFJLENBQUNrSixTQUFTLENBQUN0SixJQUFJLENBQUMsR0FBQzNmLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDd1UsZUFBZSxHQUFDdEIsU0FBUztNQUN0UixNQUFNa2Qsa0JBQWtCLEdBQUM1d0IsTUFBTSxDQUFDUixJQUFJLEtBQUcsTUFBTSxJQUFFeXBCLFNBQVMsQ0FBQ3RKLElBQUksS0FBRywrQkFBK0IsSUFBQTJRLHFCQUFBLEdBQUN0d0IsTUFBTSxDQUFDUSxJQUFJLENBQUNxWixjQUFjLGNBQUF5VyxxQkFBQSx1QkFBMUJBLHFCQUFBLENBQTRCdFcsZ0JBQWdCLEdBQUN0RyxTQUFTO01BQ3RKLE1BQU1tZCxhQUFhLElBQUFOLEtBQUEsR0FBR0ssa0JBQWtCLGFBQWxCQSxrQkFBa0IsY0FBbEJBLGtCQUFrQixHQUFJRixZQUFZLGNBQUFILEtBQUEsY0FBQUEsS0FBQSxHQUFLL1IsUUFBUSxDQUFDaVMsTUFBTSxDQUFDLElBQUksT0FBT0EsTUFBTSxDQUFDNXBCLFFBQVEsS0FBSyxRQUFRLElBQUksT0FBTzRwQixNQUFNLENBQUN6YixlQUFlLEtBQUssUUFBUSxHQUFHeWIsTUFBTSxDQUFDemIsZUFBZSxHQUN2TGhWLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLFFBQVEsSUFBSXlwQixTQUFTLENBQUN0SixJQUFJLENBQUMyRCxVQUFVLENBQUMsY0FBYyxDQUFDLEdBQUd0akIsTUFBTSxDQUFDUSxJQUFJLENBQUMwSyxlQUFlLEdBQUd5bEIsY0FBZTtNQUN6SDtNQUNBO01BQ0EsSUFBRzN3QixNQUFNLENBQUNSLElBQUksS0FBRyxvQkFBb0IsSUFBRXlwQixTQUFTLENBQUM5akIsS0FBSyxLQUFHLG1CQUFtQixJQUFFOGpCLFNBQVMsQ0FBQ3RKLElBQUksQ0FBQ29LLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBRW5zQixNQUFNLENBQUMwSCxNQUFNLEVBQUFrckIsc0JBQUEsR0FBQ3h3QixNQUFNLENBQUNRLElBQUksQ0FBQ2lPLFdBQVcsY0FBQStoQixzQkFBQSxjQUFBQSxzQkFBQSxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNqTixJQUFJLENBQUM3WSxNQUFNLElBQUU5TSxNQUFNLENBQUMwSCxNQUFNLENBQUNvRixNQUFNLENBQUMsQ0FBQzZZLElBQUksQ0FBQ2pqQixLQUFLLElBQUVtZSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3BlLEtBQUssQ0FBQyxJQUFFQSxLQUFLLENBQUNpakIsSUFBSSxDQUFDN2pCLEtBQUssSUFBRUEsS0FBSyxDQUFDSCxFQUFFLEtBQUcwcEIsU0FBUyxDQUFDMXBCLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQztRQUFDNHdCLE9BQU8sQ0FBQ2xILFNBQVMsRUFBQ21FLE1BQU0sQ0FBQztRQUFDO01BQVM7TUFDalQsTUFBTTBELFdBQVcsR0FBRzl3QixNQUFNLENBQUNSLElBQUksS0FBSyxZQUFZLEtBQUt5cEIsU0FBUyxDQUFDdEosSUFBSSxDQUFDMkQsVUFBVSxDQUFDLG9CQUFvQixDQUFDLElBQUkyRixTQUFTLENBQUN0SixJQUFJLENBQUMyRCxVQUFVLENBQUMseUJBQXlCLENBQUMsSUFBSTJGLFNBQVMsQ0FBQ3RKLElBQUksQ0FBQzJELFVBQVUsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLElBQ2xOdGpCLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sS0FBS3lwQixTQUFTLENBQUN0SixJQUFJLENBQUMyRCxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUkyRixTQUFTLENBQUN0SixJQUFJLENBQUMyRCxVQUFVLENBQUMsNkJBQTZCLENBQUMsSUFBSTJGLFNBQVMsQ0FBQ3RKLElBQUksQ0FBQzJELFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJMkYsU0FBUyxDQUFDdEosSUFBSSxDQUFDMkQsVUFBVSxDQUFDLDRCQUE0QixDQUFDLElBQUkyRixTQUFTLENBQUN0SixJQUFJLENBQUMyRCxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztNQUMzUyxJQUFJdU4sYUFBYSxJQUFJQyxXQUFXLEtBQUs5d0IsTUFBTSxDQUFDUixJQUFJLEtBQUssWUFBWSxJQUFJUSxNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLENBQUMsRUFBRTtRQUM3RixNQUFNbUwsT0FBTyxHQUFHa21CLGFBQWEsYUFBYkEsYUFBYSxjQUFiQSxhQUFhLEdBQU03d0IsTUFBTSxDQUFDUixJQUFJLEtBQUssWUFBWSxJQUFJUSxNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLEdBQUlRLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMEcsZ0JBQWdCLEdBQUdySCxPQUFPLENBQUNpUCxTQUFVO1VBQUUrVCxLQUFLLEdBQUd1TSxZQUFZLENBQUN6a0IsT0FBTyxDQUFDO1FBQzlLLElBQUksQ0FBQ2tZLEtBQUssRUFBRTtVQUFFcEQsUUFBUSxDQUFDQyxNQUFNLEVBQUVtUixhQUFhLEdBQUc3d0IsTUFBTSxDQUFDUixJQUFJLEtBQUssUUFBUSxHQUFHLEdBQUc0dEIsTUFBTSx1QkFBdUIsR0FBRyxHQUFHQSxNQUFNLElBQUluRCxLQUFLLENBQUMvSixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUN2Z0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsR0FBRyxHQUFHeXRCLE1BQU0sd0JBQXdCLEVBQUUsbUJBQW1CLEVBQUUsbUJBQW1CLENBQUM7VUFBRTtRQUFVO1FBQ25RK0MsT0FBTyxDQUFDbEgsU0FBUyxFQUFFbUUsTUFBTSxFQUFFdkssS0FBSyxDQUFDO01BQ25DLENBQUMsTUFBTXNOLE9BQU8sQ0FBQ2xILFNBQVMsRUFBRW1FLE1BQU0sQ0FBQztJQUNuQztFQUNGLENBQUMsQ0FBQztFQUNGdnRCLE9BQU8sQ0FBQ21RLFNBQVMsQ0FBQzBDLE9BQU8sQ0FBQyxDQUFDMFcsUUFBUSxFQUFFaEssQ0FBQztJQUFBLElBQUEyUixxQkFBQTtJQUFBLE9BQUssRUFBQUEscUJBQUEsR0FBQzdELGtCQUFrQixDQUFDOUgsR0FBRyxDQUFDZ0UsUUFBUSxDQUFDLGNBQUEySCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFFNUgseUJBQXlCLENBQUNDLFFBQVEsQ0FBQyxFQUFFMVcsT0FBTyxDQUFDdVcsU0FBUyxJQUFJa0gsT0FBTyxDQUFDbEgsU0FBUyxFQUFFLEdBQUd0SixJQUFJLGNBQWNQLENBQUMsR0FBRyxDQUFDLENBQUM7RUFBQSxFQUFDO0VBQ3ZMa08sUUFBUSxDQUFDNWEsT0FBTyxDQUFDdVcsU0FBUyxJQUFJa0gsT0FBTyxDQUFDbEgsU0FBUyxDQUFDLENBQUM7RUFDakQsTUFBTStILGFBQWEsSUFBQXJFLHFCQUFBLEdBQUdQLE9BQU8sQ0FBQzRFLGFBQWEsY0FBQXJFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUkzdUIsY0FBYztFQUM3RDZCLE9BQU8sQ0FBQ21RLFNBQVMsQ0FBQzBDLE9BQU8sQ0FBQyxDQUFDMFcsUUFBUSxFQUFFaEssQ0FBQyxLQUFLO0lBQ3pDLE1BQU1rSCxRQUFRLEdBQUcsR0FBRzNHLElBQUksY0FBY1AsQ0FBQyxHQUFHO01BQUUzZ0IsSUFBSSxHQUFHdXlCLGFBQWEsQ0FBQ2p4QixJQUFJLENBQUNreEIsU0FBUyxJQUFJQSxTQUFTLENBQUNoekIsR0FBRyxLQUFLbXJCLFFBQVEsQ0FBQ3pXLFlBQVksQ0FBQztNQUFFa0QsSUFBSSxHQUFHb1ksU0FBUyxDQUFDN0ksR0FBRyxDQUFDZ0UsUUFBUSxDQUFDMWxCLE1BQU0sQ0FBQztNQUFFb1MsRUFBRSxHQUFHbVksU0FBUyxDQUFDN0ksR0FBRyxDQUFDZ0UsUUFBUSxDQUFDemxCLElBQUksQ0FBQztJQUNyTSxJQUFJLENBQUNsRixJQUFJLEVBQUVnaEIsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsZUFBZSxFQUFFLHFCQUFxQixDQUFDLENBQUMsS0FDMUU7TUFDSCxJQUFJelEsSUFBSSxJQUFJLENBQUNwWCxJQUFJLENBQUNOLFNBQVMsQ0FBQzRrQixRQUFRLENBQUNsTixJQUFJLENBQUNyVyxJQUFJLENBQUMsRUFBRWlnQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxTQUFTLEVBQUUsbUJBQW1CLEVBQUUsbUJBQW1CLENBQUM7TUFDakksSUFBSXhRLEVBQUUsSUFBSSxDQUFDclgsSUFBSSxDQUFDTCxPQUFPLENBQUMya0IsUUFBUSxDQUFDak4sRUFBRSxDQUFDdFcsSUFBSSxDQUFDLEVBQUVpZ0IsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsT0FBTyxFQUFFLG1CQUFtQixFQUFFLG1CQUFtQixDQUFDO01BQ3pILElBQUk4QyxRQUFRLENBQUMxbEIsTUFBTSxLQUFLMGxCLFFBQVEsQ0FBQ3psQixJQUFJLElBQUksQ0FBQ2xGLElBQUksQ0FBQ0osU0FBUyxFQUFFb2hCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFNEcsUUFBUSxFQUFFLGtCQUFrQixDQUFDO01BQ3hHLElBQUk4QyxRQUFRLENBQUNoZixTQUFTLEtBQUssV0FBVyxJQUFJLENBQUMzTCxJQUFJLENBQUNILGNBQWMsRUFBRW1oQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxZQUFZLEVBQUUsaUJBQWlCLENBQUM7SUFDOUg7SUFDQSxJQUFJOEMsUUFBUSxDQUFDbnBCLFNBQVMsSUFBSSxDQUFDbXBCLFFBQVEsQ0FBQ3RFLG1CQUFtQixFQUFFckYsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsc0JBQXNCLEVBQUUsZ0JBQWdCLENBQUM7SUFDOUh3QyxvQkFBb0IsQ0FBQ00sUUFBUSxDQUFDbm1CLFFBQVEsRUFBRSxHQUFHcWpCLFFBQVEsV0FBVyxFQUFFNUcsTUFBTSxDQUFDO0VBQ3pFLENBQUMsQ0FBQztFQUNGLElBQUl3UixXQUFnQztFQUNwQyxJQUFJN2EsS0FBSyxJQUFJcU4sSUFBSSxDQUFDQyxTQUFTLENBQUM5akIsT0FBTyxDQUFDa1EsZUFBZSxDQUFDLEtBQUsyVCxJQUFJLENBQUNDLFNBQVMsQ0FBQ3ROLEtBQUssQ0FBQzBWLFFBQVEsQ0FBQ2hjLGVBQWUsQ0FBQyxJQUFJMlQsSUFBSSxDQUFDQyxTQUFTLENBQUM5akIsT0FBTyxDQUFDZ1EsU0FBUyxDQUFDLEtBQUs2VCxJQUFJLENBQUNDLFNBQVMsQ0FBQ3ROLEtBQUssQ0FBQzBWLFFBQVEsQ0FBQ2xjLFNBQVMsQ0FBQyxFQUFFO0lBQ3pMcWhCLFdBQVcsR0FBRyxJQUFJak8sR0FBRyxDQUFDLENBQUMsR0FBR3BqQixPQUFPLENBQUNDLFFBQVEsQ0FBQ0ssTUFBTSxDQUFDSCxNQUFNLElBQUk4c0IsZ0JBQWdCLENBQUMxSCxHQUFHLENBQUNwbEIsTUFBTSxDQUFDVCxFQUFFLENBQUMsS0FBS1MsTUFBTSxDQUFDLENBQUNuRCxHQUFHLENBQUNtRCxNQUFNLElBQUlBLE1BQU0sQ0FBQ1QsRUFBRSxDQUFDLEVBQUUsR0FBR00sT0FBTyxDQUFDbVEsU0FBUyxDQUFDN1AsTUFBTSxDQUFDaXBCLFFBQVEsSUFBSTJELGlCQUFpQixDQUFDM0gsR0FBRyxDQUFDZ0UsUUFBUSxDQUFDN3BCLEVBQUUsQ0FBQyxLQUFLNnBCLFFBQVEsQ0FBQyxDQUFDdnNCLEdBQUcsQ0FBQ3VzQixRQUFRLElBQUlBLFFBQVEsQ0FBQzdwQixFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3pQLEtBQUssTUFBTUEsRUFBRSxJQUFJdXRCLGdCQUFnQixDQUFDanZCLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDb3dCLFNBQVMsQ0FBQ3RMLEdBQUcsQ0FBQ3BqQixFQUFFLENBQUMsRUFBRTJ4QixXQUFXLENBQUN0TyxHQUFHLENBQUNyakIsRUFBRSxDQUFDO0lBQ3JGLEtBQUssTUFBTUEsRUFBRSxJQUFJd3RCLGlCQUFpQixDQUFDbHZCLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDcXdCLFdBQVcsQ0FBQ3ZMLEdBQUcsQ0FBQ3BqQixFQUFFLENBQUMsRUFBRTJ4QixXQUFXLENBQUN0TyxHQUFHLENBQUNyakIsRUFBRSxDQUFDO0VBQzFGO0VBQ0E0eEIsd0JBQXdCLENBQUN0eEIsT0FBTyxFQUFFb3VCLFNBQVMsRUFBRXZ0QixPQUFPLEVBQUVxdUIsYUFBYSxFQUFFVCxNQUFNLEVBQUU1TyxNQUFNLEVBQUVDLElBQUksRUFBRXlNLE9BQU8sRUFBRWdELFlBQVksRUFBRThCLFdBQVcsR0FBR2x4QixNQUFNLElBQUk4c0IsZ0JBQWdCLENBQUMxSCxHQUFHLENBQUNwbEIsTUFBTSxDQUFDVCxFQUFFLENBQUMsS0FBS1MsTUFBTSxJQUFJcXdCLGFBQWEsQ0FBQ3J3QixNQUFNLENBQUMsQ0FBQ3VqQixJQUFJLENBQUMwRixTQUFTLElBQUlpSSxXQUFXLENBQUV2TyxHQUFHLENBQUNzRyxTQUFTLENBQUMxcEIsRUFBRSxDQUFDLENBQUMsR0FBR21VLFNBQVMsQ0FBQztFQUM1USxPQUFPZ00sTUFBTSxDQUFDak0sTUFBTSxHQUFHO0lBQUU4UixFQUFFLEVBQUUsS0FBSztJQUFFN0YsTUFBTSxFQUFFQSxNQUFNLENBQUNRLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRztFQUFFLENBQUMsR0FBRztJQUFFcUYsRUFBRSxFQUFFLElBQUk7SUFBRWpsQixLQUFLLEVBQUVUO0VBQVEsQ0FBQztBQUNuRztBQUNBLFNBQVMwdUIsaUJBQWlCQSxDQUFDanVCLEtBQWMsRUFBRWdOLEtBQVMsRUFBRWdoQixNQUErQyxFQUFFNXRCLE9BQWdELEVBQUVnZixNQUF5QixFQUFFQyxJQUFZLEVBQUV5QyxLQUFLLEdBQUcsQ0FBQyxFQUFRO0VBQ2pOLElBQUlBLEtBQUssR0FBRyxFQUFFLElBQUksQ0FBQzloQixLQUFLLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsRUFBRTtFQUN2RCxJQUFJbWUsS0FBSyxDQUFDQyxPQUFPLENBQUNwZSxLQUFLLENBQUMsRUFBRTtJQUFFQSxLQUFLLENBQUNvUyxPQUFPLENBQUMsQ0FBQzJOLEtBQUssRUFBRWpCLENBQUMsS0FBS21QLGlCQUFpQixDQUFDbE8sS0FBSyxFQUFFL1MsS0FBSyxFQUFFZ2hCLE1BQU0sRUFBRTV0QixPQUFPLEVBQUVnZixNQUFNLEVBQUUsR0FBR0MsSUFBSSxJQUFJUCxDQUFDLEdBQUcsRUFBRWdELEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFO0VBQVE7RUFDdkosTUFBTTJHLE1BQU0sR0FBR3pvQixLQUFnQztFQUMvQyxJQUFJLE9BQU95b0IsTUFBTSxDQUFDeHBCLEVBQUUsS0FBSyxRQUFRLElBQUksT0FBT3dwQixNQUFNLENBQUMzcEIsSUFBSSxLQUFLLFFBQVEsSUFBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDMmpCLFFBQVEsQ0FBQ2dHLE1BQU0sQ0FBQ3ZwQixJQUFjLENBQUMsRUFBRTtJQUN0SixJQUFJOHVCLE1BQU0sQ0FBQzNMLEdBQUcsQ0FBQ29HLE1BQU0sQ0FBQ3hwQixFQUFFLENBQUMsRUFBRWtnQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLEtBQUssRUFBRSxtQkFBbUIsQ0FBQztJQUM5RTJPLE1BQU0sQ0FBQ2pKLEdBQUcsQ0FBQzBELE1BQU0sQ0FBQ3hwQixFQUFFLEVBQUU7TUFBRXNILFFBQVEsRUFBRXlHLEtBQUs7TUFBRWxPLElBQUksRUFBRTJwQixNQUFNLENBQUMzcEI7SUFBSyxDQUFDLENBQUM7RUFDL0Q7RUFDQSxJQUFJLE9BQU8ycEIsTUFBTSxDQUFDeHBCLEVBQUUsS0FBSyxRQUFRLElBQUksaUJBQWlCLElBQUl3cEIsTUFBTSxFQUFFO0lBQ2hFLElBQUlyb0IsT0FBTyxDQUFDaWlCLEdBQUcsQ0FBQ29HLE1BQU0sQ0FBQ3hwQixFQUFFLENBQUMsRUFBRWtnQixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLEtBQUssRUFBRSxlQUFlLENBQUM7SUFDM0VqZixPQUFPLENBQUMya0IsR0FBRyxDQUFDMEQsTUFBTSxDQUFDeHBCLEVBQUUsRUFBRTtNQUFFc0gsUUFBUSxFQUFFeUcsS0FBSztNQUFFa0ksS0FBSyxFQUFFdVQ7SUFBMkIsQ0FBQyxDQUFDO0VBQ2hGO0VBQ0EsS0FBSyxNQUFNLENBQUM5cUIsR0FBRyxFQUFFb2lCLEtBQUssQ0FBQyxJQUFJemlCLE1BQU0sQ0FBQ2tsQixPQUFPLENBQUNpRyxNQUFNLENBQUMsRUFBRTtJQUNqRDtJQUNBLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQ2hHLFFBQVEsQ0FBQzlrQixHQUFHLENBQUMsRUFBRTtJQUN0RXN3QixpQkFBaUIsQ0FBQ2xPLEtBQUssRUFBRS9TLEtBQUssRUFBRWdoQixNQUFNLEVBQUU1dEIsT0FBTyxFQUFFZ2YsTUFBTSxFQUFFLEdBQUdDLElBQUksSUFBSTFoQixHQUFHLEVBQUUsRUFBRW1rQixLQUFLLEdBQUcsQ0FBQyxDQUFDO0VBQ3ZGO0FBQ0Y7QUFDQSxTQUFTZ1AsV0FBV0EsQ0FBQ0MsS0FBZSxFQUFFamYsS0FBK0IsRUFBRXNOLE1BQXlCLEVBQUVDLElBQVksRUFBRXpoQixLQUFhLEVBQVE7RUFDbkksTUFBTTJrQixLQUFLLEdBQUcsSUFBSW9DLEdBQUcsQ0FBQ29NLEtBQUssQ0FBQ3gwQixHQUFHLENBQUNzcEIsSUFBSSxJQUFJLENBQUNBLElBQUksQ0FBQzVtQixFQUFFLEVBQUU0bUIsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUFFbUwsTUFBTSxHQUFHLElBQUlyTSxHQUFHLENBQWEsQ0FBQztFQUN6RixLQUFLLE1BQU1rQixJQUFJLElBQUlrTCxLQUFLLEVBQUU7SUFDeEIsSUFBSUMsTUFBTSxDQUFDbE0sR0FBRyxDQUFDZSxJQUFJLENBQUM1bUIsRUFBRSxDQUFDLEVBQUU7SUFDekIsTUFBTWd5QixLQUE4QyxHQUFHLENBQUM7TUFBRWh5QixFQUFFLEVBQUU0bUIsSUFBSSxDQUFDNW1CLEVBQUU7TUFBRXdtQixHQUFHLEVBQUUzVCxLQUFLLENBQUMrVCxJQUFJLENBQUM7TUFBRWlFLE1BQU0sRUFBRTtJQUFFLENBQUMsQ0FBQztJQUFFa0gsTUFBTSxDQUFDak0sR0FBRyxDQUFDYyxJQUFJLENBQUM1bUIsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUM3SCxPQUFPZ3lCLEtBQUssQ0FBQzlkLE1BQU0sRUFBRTtNQUNuQixNQUFNK2QsT0FBTyxHQUFHRCxLQUFLLENBQUNBLEtBQUssQ0FBQzlkLE1BQU0sR0FBRyxDQUFDLENBQUM7TUFDdkMsSUFBSStkLE9BQU8sQ0FBQ3BILE1BQU0sSUFBSW9ILE9BQU8sQ0FBQ3pMLEdBQUcsQ0FBQ3RTLE1BQU0sRUFBRTtRQUFFNmQsTUFBTSxDQUFDak0sR0FBRyxDQUFDbU0sT0FBTyxDQUFDanlCLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFBRWd5QixLQUFLLENBQUNwSCxHQUFHLENBQUMsQ0FBQztRQUFFO01BQVU7TUFDOUYsTUFBTXNILE1BQU0sR0FBR0QsT0FBTyxDQUFDekwsR0FBRyxDQUFDeUwsT0FBTyxDQUFDcEgsTUFBTSxFQUFFLENBQUM7UUFBRTdLLElBQUksR0FBR3NELEtBQUssQ0FBQ3VDLEdBQUcsQ0FBQ3FNLE1BQU0sQ0FBQztNQUFFLElBQUksQ0FBQ2xTLElBQUksRUFBRTtNQUNuRixJQUFJK1IsTUFBTSxDQUFDbE0sR0FBRyxDQUFDcU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQUVoUyxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGFBQWE2UixPQUFPLENBQUNqeUIsRUFBRSxPQUFPLEVBQUUsR0FBR3JCLEtBQUssV0FBVyxDQUFDO1FBQUU7TUFBVTtNQUN4SCxJQUFJLENBQUNvekIsTUFBTSxDQUFDbE0sR0FBRyxDQUFDcU0sTUFBTSxDQUFDLEVBQUU7UUFBRUgsTUFBTSxDQUFDak0sR0FBRyxDQUFDb00sTUFBTSxFQUFFLENBQUMsQ0FBQztRQUFFRixLQUFLLENBQUMxUixJQUFJLENBQUM7VUFBRXRnQixFQUFFLEVBQUVreUIsTUFBTTtVQUFFMUwsR0FBRyxFQUFFM1QsS0FBSyxDQUFDbU4sSUFBSSxDQUFDO1VBQUU2SyxNQUFNLEVBQUU7UUFBRSxDQUFDLENBQUM7TUFBRTtJQUM3RztFQUNGO0FBQ0Y7QUFFQSxTQUFTK0csd0JBQXdCQSxDQUFDdHhCLE9BQXVCLEVBQUVvdUIsU0FBMEIsRUFBRXZ0QixPQUFnRCxFQUFFcXVCLGFBQXNCLEVBQUVULE1BQStDLEVBQUU1TyxNQUF5QixFQUFFQyxJQUFZLEVBQUV5TSxPQUFpQyxFQUFFc0YsY0FBd0QsRUFBRUMsUUFBc0MsRUFBUTtFQUNwWSxNQUFNOXpCLElBQUksR0FBRyxJQUFJb25CLEdBQUcsQ0FBYSxDQUFDO0lBQUUyTSxlQUFlLEdBQUcsSUFBSTNPLEdBQUcsQ0FBUyxDQUFDO0VBQ3ZFO0VBQ0E7RUFDQSxJQUFJcGpCLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDeWpCLElBQUksQ0FBQ3ZqQixNQUFNLElBQUksQ0FBQyxDQUFDQSxNQUFNLENBQUM2a0IsVUFBVSxJQUFJLENBQUM3a0IsTUFBTSxDQUFDQyxTQUFTLENBQUMsRUFBRXlmLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUdobEIsMkJBQTJCLENBQUNnRixPQUFPLEVBQUU4ZixJQUFJLEVBQUUsQ0FBQyxHQUFHc08sU0FBUyxDQUFDM29CLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ2xLekYsT0FBTyxDQUFDQyxRQUFRLENBQUM0UyxPQUFPLENBQUMsQ0FBQzFTLE1BQU0sRUFBRW9mLENBQUMsS0FBSztJQUN0QyxNQUFNa0gsUUFBUSxHQUFHLEdBQUczRyxJQUFJLGFBQWFQLENBQUMsR0FBRztJQUN6QyxJQUFJcGYsTUFBTSxDQUFDQyxTQUFTLEVBQUU7SUFDdEIsSUFBSUQsTUFBTSxDQUFDUixJQUFJLEtBQUssVUFBVSxJQUFJUSxNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLElBQUlRLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLG1CQUFtQixFQUFFO01BQUEsSUFBQXF5QixvQkFBQTtNQUNoRyxNQUFNaGUsTUFBTSxHQUFHLEdBQUc3VCxNQUFNLENBQUNSLElBQUksSUFBSVEsTUFBTSxDQUFDUixJQUFJLEtBQUssVUFBVSxHQUFHLEdBQUdRLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMkUsS0FBSyxLQUFBMHNCLG9CQUFBLEdBQUk3eEIsTUFBTSxDQUFDUSxJQUFJLENBQUNzQyxPQUFPLGNBQUErdUIsb0JBQUEsY0FBQUEsb0JBQUEsR0FBSSxFQUFFLEdBQUcsR0FBRyxFQUFFLEdBQUc3eEIsTUFBTSxDQUFDUSxJQUFJLENBQUN2QyxHQUFHLEVBQUU7TUFDM0ksSUFBSUosSUFBSSxDQUFDOGtCLEdBQUcsQ0FBQzlPLE1BQU0sQ0FBQyxFQUFFNEwsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsV0FBVyxFQUFFLG9CQUFvQixDQUFDO01BQUV6b0IsSUFBSSxDQUFDd25CLEdBQUcsQ0FBQ3hSLE1BQU0sRUFBRTdULE1BQU0sQ0FBQ1QsRUFBRSxDQUFDO0lBQ25IO0lBQ0EsSUFBSVMsTUFBTSxDQUFDUixJQUFJLEtBQUssY0FBYyxFQUFFO01BQ2xDLE1BQU1xVSxNQUFNLEdBQUcsR0FBRzdULE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMkksWUFBWSxJQUFJbkosTUFBTSxDQUFDUSxJQUFJLENBQUM0SSxRQUFRLElBQUlwSixNQUFNLENBQUNRLElBQUksQ0FBQzZJLFVBQVUsRUFBRTtNQUM5RixJQUFJdW9CLGVBQWUsQ0FBQ2pQLEdBQUcsQ0FBQzlPLE1BQU0sQ0FBQyxFQUFFNEwsUUFBUSxDQUFDQyxNQUFNLEVBQUU0RyxRQUFRLEVBQUUseUJBQXlCLENBQUM7TUFBRXNMLGVBQWUsQ0FBQ2hQLEdBQUcsQ0FBQy9PLE1BQU0sQ0FBQztJQUNySDtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUk4ZCxRQUFRLElBQUksQ0FBQ0EsUUFBUSxDQUFDM3hCLE1BQU0sQ0FBQyxJQUFJQSxNQUFNLENBQUNSLElBQUksS0FBSyxZQUFZLElBQUlRLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sRUFBRTtJQUM5RixJQUFJUSxNQUFNLENBQUNSLElBQUksS0FBSyxVQUFVLEVBQUVrZ0IsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBRy9rQiwwQkFBMEIsQ0FBQ2tGLE1BQU0sQ0FBQ1EsSUFBSSxFQUFFLEdBQUc4bEIsUUFBUSxPQUFPLEVBQUUySCxTQUFTLENBQUMsQ0FBQztJQUN0SCxJQUFJanVCLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE1BQU0sSUFBSVEsTUFBTSxDQUFDUSxJQUFJLENBQUNvQixRQUFRLEtBQUssVUFBVSxFQUFFO01BQ2pFLE1BQU1uRCxJQUFJLEdBQUd1QixNQUFNLENBQUNRLElBQUksQ0FBQ3FCLE1BQU0sR0FBR29zQixTQUFTLENBQUM3SSxHQUFHLENBQUNwbEIsTUFBTSxDQUFDUSxJQUFJLENBQUNxQixNQUFNLENBQUMsR0FBRzZSLFNBQVM7TUFDL0UsSUFBSSxDQUFBalYsSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVlLElBQUksTUFBSyxNQUFNLElBQUlmLElBQUksQ0FBQytCLElBQUksQ0FBQ29CLFFBQVEsS0FBSyxNQUFNLEVBQUU2ZCxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxjQUFjLEVBQUUsMEJBQTBCLEVBQUUsbUJBQW1CLENBQUM7SUFDMUo7SUFDQSxJQUFJdG1CLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sRUFBRTtNQUMzQixNQUFNekQsUUFBUSxHQUFHa3lCLFNBQVMsQ0FBQzdJLEdBQUcsQ0FBQ3BsQixNQUFNLENBQUNRLElBQUksQ0FBQ29FLGVBQWUsQ0FBQztNQUMzRCxJQUFJLENBQUE3SSxRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRXlELElBQUksTUFBSyxVQUFVLEVBQUUsS0FBSyxNQUFNLENBQUNnbEIsQ0FBQyxFQUFFeUQsSUFBSSxDQUFDLElBQUksRUFBQTZKLHFCQUFBLEdBQUM5eEIsTUFBTSxDQUFDUSxJQUFJLENBQUNzRSxlQUFlLGNBQUFndEIscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLEVBQUVoUCxPQUFPLENBQUMsQ0FBQztRQUFBLElBQUFnUCxxQkFBQTtRQUFFcFMsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBRytHLHFCQUFxQixDQUFDN3FCLFFBQVEsRUFBRWtzQixJQUFJLENBQUNwUyxJQUFJLEVBQUUsR0FBR3lRLFFBQVEseUJBQXlCOUIsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUUsR0FBR29DLHFCQUFxQixDQUFDN3FCLFFBQVEsRUFBRWtzQixJQUFJLENBQUNuUyxFQUFFLEVBQUUsR0FBR3dRLFFBQVEseUJBQXlCOUIsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7TUFBQztJQUM5VDtJQUNBLElBQUl4a0IsTUFBTSxDQUFDUixJQUFJLEtBQUssVUFBVSxFQUFFLEtBQUssTUFBTSxDQUFDZ2xCLENBQUMsRUFBRXlELElBQUksQ0FBQyxJQUFJLEVBQUE4SixxQkFBQSxHQUFDL3hCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDOGEsVUFBVSxjQUFBeVcscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLEVBQUVqUCxPQUFPLENBQUMsQ0FBQyxFQUFFO01BQUEsSUFBQWlQLHFCQUFBO01BQ2hHLE1BQU1DLEtBQUssR0FBRy9ELFNBQVMsQ0FBQzdJLEdBQUcsQ0FBQzZDLElBQUksQ0FBQzVWLFVBQVUsQ0FBQztNQUM1QyxJQUFJLENBQUEyZixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRXh5QixJQUFJLE1BQUssVUFBVSxFQUFFa2dCLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUcrRyxxQkFBcUIsQ0FBQ29MLEtBQUssRUFBRS9KLElBQUksQ0FBQzFNLFVBQVUsRUFBRSxHQUFHK0ssUUFBUSxvQkFBb0I5QixDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0SjtJQUNBLElBQUl4a0IsTUFBTSxDQUFDUixJQUFJLEtBQUssWUFBWSxJQUFJUSxNQUFNLENBQUNRLElBQUksQ0FBQ3NjLE9BQU8sS0FBSyxZQUFZLEVBQUUsS0FBSyxNQUFNLENBQUMwSCxDQUFDLEVBQUVqbEIsRUFBRSxDQUFDLElBQUksRUFBQTB5QixxQkFBQSxHQUFDanlCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDcUssU0FBUyxjQUFBb25CLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFblAsT0FBTyxDQUFDLENBQUMsRUFBRTtNQUFBLElBQUFtUCxxQkFBQTtNQUN2SSxNQUFNNTFCLEtBQUssR0FBRzR4QixTQUFTLENBQUM3SSxHQUFHLENBQUM3bEIsRUFBRSxDQUFDO01BQy9CLElBQUlsRCxLQUFLLElBQUlBLEtBQUssQ0FBQ21ELElBQUksS0FBSyxPQUFPLEVBQUVpZ0IsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsbUJBQW1COUIsQ0FBQyxHQUFHLEVBQUUsNEJBQTRCLEVBQUUsbUJBQW1CLENBQUM7SUFDOUk7SUFDQSxJQUFJeGtCLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLFFBQVEsRUFBRTtNQUFBLElBQUEweUIsbUJBQUE7TUFDNUIsTUFBTWpuQixNQUFNLEdBQUdnakIsU0FBUyxDQUFDN0ksR0FBRyxDQUFDcGxCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDbUYsUUFBUSxDQUFDO1FBQUVELFNBQVMsR0FBRzFGLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa0YsU0FBUztNQUNyRixJQUFJdUYsTUFBTSxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQzhYLFFBQVEsQ0FBQ3JkLFNBQVMsQ0FBQyxFQUFFO1FBQ3pELElBQUl1RixNQUFNLENBQUN6TCxJQUFJLEtBQUssVUFBVSxFQUFFaWdCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLGdCQUFnQixFQUFFLHVCQUF1QixFQUFFLG1CQUFtQixDQUFDLENBQUMsS0FDdkg7VUFDSCxJQUFJcmIsTUFBTSxDQUFDekssSUFBSSxDQUFDNmEsT0FBTyxFQUFFb0UsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsZ0JBQWdCLEVBQUUsaUJBQWlCLENBQUM7VUFDekYsSUFBSTVnQixTQUFTLEtBQUssS0FBSyxJQUFJdUYsTUFBTSxDQUFDekssSUFBSSxDQUFDMEUsU0FBUyxLQUFLLFNBQVMsRUFBRXVhLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLGdCQUFnQixFQUFFLG9CQUFvQixDQUFDO1VBQ25JLElBQUl0bUIsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssSUFBSW9GLFNBQVMsS0FBSyxLQUFLLEVBQUVnYSxNQUFNLENBQUNHLElBQUksQ0FBQyxHQUFHK0cscUJBQXFCLENBQUMzYixNQUFNLEVBQUVqTCxNQUFNLENBQUNRLElBQUksQ0FBQ0YsS0FBSyxFQUFFLEdBQUdnbUIsUUFBUSxhQUFhLENBQUMsQ0FBQztRQUMxSTtNQUNGO01BQ0EsSUFBSXJiLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM4WCxRQUFRLENBQUNyZCxTQUFTLENBQUMsSUFBSXVGLE1BQU0sQ0FBQ3pMLElBQUksS0FBSyxNQUFNLEVBQUVpZ0IsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsZ0JBQWdCLEVBQUUsbUJBQW1CLEVBQUUsbUJBQW1CLENBQUM7TUFDakwsSUFBSSxDQUFBcmIsTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUV6TCxJQUFJLE1BQUssTUFBTSxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQ3VqQixRQUFRLENBQUNyZCxTQUFTLENBQUMsSUFBSTFGLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDb0YsVUFBVSxFQUFFO1FBQ3pHLE1BQU11c0IsUUFBUSxHQUFHbEUsU0FBUyxDQUFDN0ksR0FBRyxDQUFDcGxCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDb0YsVUFBVSxDQUFDO1FBQ3RELElBQUksQ0FBQXVzQixRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRTN5QixJQUFJLE1BQUssTUFBTSxLQUFLMnlCLFFBQVEsQ0FBQzN4QixJQUFJLENBQUNvQixRQUFRLEtBQUssVUFBVSxLQUFLcUosTUFBTSxDQUFDekssSUFBSSxDQUFDb0IsUUFBUSxLQUFLLE1BQU0sR0FBR3V3QixRQUFRLENBQUMzeEIsSUFBSSxDQUFDcUIsTUFBTSxLQUFLb0osTUFBTSxDQUFDMUwsRUFBRSxHQUFHNHlCLFFBQVEsQ0FBQzV5QixFQUFFLEtBQUswTCxNQUFNLENBQUMxTCxFQUFFLENBQUMsQ0FBQyxFQUFFa2dCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLGtCQUFrQixFQUFFLHlCQUF5QixFQUFFLG1CQUFtQixDQUFDO01BQ2pSO01BQ0EsSUFBSXJiLE1BQU0sSUFBSXZGLFNBQVMsS0FBSyxRQUFRLElBQUl1RixNQUFNLENBQUN6TCxJQUFJLEtBQUssV0FBVyxFQUFFaWdCLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLGdCQUFnQixFQUFFLHNCQUFzQixFQUFFLG1CQUFtQixDQUFDO01BQy9KLElBQUk1Z0IsU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFBd3NCLG1CQUFBLEdBQUFseUIsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssY0FBQTR4QixtQkFBQSx1QkFBakJBLG1CQUFBLENBQW1CenpCLElBQUksTUFBSyxLQUFLLEVBQUU7UUFDN0QsTUFBTTJ6QixXQUFXLEdBQUduRSxTQUFTLENBQUM3SSxHQUFHLENBQUNwbEIsTUFBTSxDQUFDUSxJQUFJLENBQUNGLEtBQUssQ0FBQ0EsS0FBSyxDQUFDO1FBQUUsSUFBSTh4QixXQUFXLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUNyUCxRQUFRLENBQUNxUCxXQUFXLENBQUM1eUIsSUFBSSxDQUFDLEVBQUVpZ0IsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsYUFBYSxFQUFFLHNCQUFzQixFQUFFLG1CQUFtQixDQUFDO01BQ3JPO0lBQ0Y7SUFDQSxJQUFJdG1CLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLFlBQVksRUFBRTtNQUFBLElBQUE2eUIscUJBQUE7TUFDaEMsS0FBSyxNQUFNNWdCLEtBQUssSUFBSSxDQUFDLEdBQUd6UixNQUFNLENBQUNRLElBQUksQ0FBQzRELFFBQVEsRUFBRSxHQUFHcEUsTUFBTSxDQUFDUSxJQUFJLENBQUM2RCxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUNyRSxNQUFNLENBQUNRLElBQUksQ0FBQzBELE9BQU8sQ0FBQzZlLFFBQVEsQ0FBQ3RSLEtBQUssQ0FBQyxFQUFFZ08sUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsT0FBTyxFQUFFLDRCQUE0QixDQUFDO01BQ25MLEtBQUssTUFBTWdNLE1BQU0sSUFBSXR5QixNQUFNLENBQUNRLElBQUksQ0FBQzJELE9BQU8sRUFBRTtRQUN4QyxNQUFNb3VCLElBQUksR0FBR3RFLFNBQVMsQ0FBQzdJLEdBQUcsQ0FBQ2tOLE1BQU0sQ0FBQztRQUFFLElBQUksQ0FBQUMsSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUUveUIsSUFBSSxNQUFLLFdBQVcsRUFBRTtRQUNwRSxJQUFJLENBQUNRLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMEQsT0FBTyxDQUFDNmUsUUFBUSxDQUFDd1AsSUFBSSxDQUFDL3hCLElBQUksQ0FBQ2tELE1BQU0sQ0FBQyxJQUFLLE9BQU82dUIsSUFBSSxDQUFDL3hCLElBQUksQ0FBQ21ELElBQUksS0FBSyxRQUFRLElBQUksQ0FBQzNELE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMEQsT0FBTyxDQUFDNmUsUUFBUSxDQUFDd1AsSUFBSSxDQUFDL3hCLElBQUksQ0FBQ21ELElBQUksQ0FBRSxFQUFFOGIsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsZUFBZSxFQUFFLDJCQUEyQixDQUFDO01BQ3pOO01BQ0EsTUFBTWtNLGFBQWEsR0FBRyxFQUFBSCxxQkFBQSxHQUFDcnlCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDK0QsVUFBVSxjQUFBOHRCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFeDFCLEdBQUcsQ0FBQzQxQixTQUFTLElBQUlBLFNBQVMsQ0FBQ3gwQixHQUFHLENBQUM7TUFBRSxJQUFJLElBQUlnbEIsR0FBRyxDQUFDdVAsYUFBYSxDQUFDLENBQUM1TyxJQUFJLEtBQUs0TyxhQUFhLENBQUMvZSxNQUFNLEVBQUVnTSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxrQkFBa0IsRUFBRSxnQkFBZ0IsQ0FBQztJQUNuTjtJQUNBLElBQUl0bUIsTUFBTSxDQUFDUixJQUFJLEtBQUssV0FBVyxJQUFJNHNCLE9BQU8sQ0FBQy9VLE9BQU8sSUFBSSxPQUFPclgsTUFBTSxDQUFDUSxJQUFJLENBQUNtRCxJQUFJLEtBQUssUUFBUSxFQUFFOGIsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsWUFBWSxFQUFFLHFCQUFxQixFQUFFLG9CQUFvQixDQUFDO0lBQ2xMLElBQUl0bUIsTUFBTSxDQUFDUixJQUFJLEtBQUssVUFBVSxJQUFJNHNCLE9BQU8sQ0FBQy9VLE9BQU8sSUFBSXJYLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDNEUsT0FBTyxDQUFDM0csSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDdUIsTUFBTSxDQUFDUSxJQUFJLENBQUM2YSxPQUFPLEVBQUVvRSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxlQUFlLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixDQUFDO0lBQ25Nb00sNkJBQTZCLENBQUMxeUIsTUFBTSxDQUFDUSxJQUFJLEVBQUU4bEIsUUFBUSxFQUFFMkgsU0FBUyxFQUFFdk8sTUFBTSxDQUFDO0lBQ3ZFLElBQUkxZixNQUFNLENBQUNSLElBQUksS0FBSyxRQUFRLElBQUksT0FBT1EsTUFBTSxDQUFDUSxJQUFJLENBQUN5SyxNQUFNLEtBQUssUUFBUSxFQUFFO01BQ3RFMG5CLGVBQWUsQ0FBQzN5QixNQUFNLENBQUNRLElBQUksQ0FBQ3lLLE1BQU0sRUFBRSxHQUFHcWIsUUFBUSxjQUFjLEVBQUUySCxTQUFTLEVBQUVLLE1BQU0sRUFBRTVPLE1BQU0sRUFBRSxDQUFDLEVBQUVnUyxjQUFjLEVBQUUxeEIsTUFBTSxDQUFDUSxJQUFJLENBQUMwSyxlQUFlLENBQUM7TUFDekl5bkIsZUFBZSxDQUFDO1FBQUUsR0FBRzN5QixNQUFNLENBQUNRLElBQUk7UUFBRXlLLE1BQU0sRUFBRTtNQUFLLENBQUMsRUFBRSxHQUFHcWIsUUFBUSxPQUFPLEVBQUUySCxTQUFTLEVBQUVLLE1BQU0sRUFBRTVPLE1BQU0sRUFBRSxDQUFDLEVBQUVnUyxjQUFjLENBQUM7SUFDckgsQ0FBQyxNQUFNaUIsZUFBZSxDQUFDM3lCLE1BQU0sQ0FBQ1EsSUFBSSxFQUFFLEdBQUc4bEIsUUFBUSxPQUFPLEVBQUUySCxTQUFTLEVBQUVLLE1BQU0sRUFBRTVPLE1BQU0sRUFBRSxDQUFDLEVBQUVnUyxjQUFjLENBQUM7SUFDckcsSUFBSTF4QixNQUFNLENBQUNSLElBQUksS0FBSyxvQkFBb0IsRUFBRTtNQUN4QyxNQUFNK2hCLE1BQU0sR0FBR3ZoQixNQUFNLENBQUNRLElBQUksQ0FBQzJOLFVBQVU7TUFDckMsSUFBSSxNQUFNLElBQUlvVCxNQUFNLElBQUlBLE1BQU0sQ0FBQ25nQixJQUFJLEtBQUssT0FBTyxFQUFFO1FBQy9DLE1BQU1vVSxLQUFLLEdBQUc5VSxPQUFPLENBQUMwa0IsR0FBRyxDQUFDN0QsTUFBTSxDQUFDRyxPQUFPLENBQUM7UUFBRSxJQUFJbE0sS0FBSyxJQUFJLENBQUN4VixNQUFNLENBQUNRLElBQUksQ0FBQzBOLFdBQVcsQ0FBQzZVLFFBQVEsQ0FBQ3ZOLEtBQUssQ0FBQzNPLFFBQVEsQ0FBQyxFQUFFNFksUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsa0JBQWtCLEVBQUUsMEJBQTBCLENBQUM7TUFDeEwsQ0FBQyxNQUFNLElBQUksRUFBRSxNQUFNLElBQUkvRSxNQUFNLENBQUMsRUFBRSxLQUFLLE1BQU0sQ0FBQzViLFFBQVEsRUFBRWl0QixRQUFRLENBQUMsSUFBSWgxQixNQUFNLENBQUNrbEIsT0FBTyxFQUFBK1Asa0JBQUEsR0FBQ3RSLE1BQU0sQ0FBQ0UsVUFBVSxjQUFBb1Isa0JBQUEsY0FBQUEsa0JBQUEsR0FBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQUEsSUFBQUEsa0JBQUEsRUFBQUMsWUFBQTtRQUMxRyxJQUFJRixRQUFRLENBQUN4eEIsSUFBSSxLQUFLLE9BQU8sSUFBSSxFQUFBMHhCLFlBQUEsR0FBQXB5QixPQUFPLENBQUMwa0IsR0FBRyxDQUFDd04sUUFBUSxDQUFDbFIsT0FBTyxDQUFDLGNBQUFvUixZQUFBLHVCQUE3QkEsWUFBQSxDQUErQmpzQixRQUFRLE1BQUtsQixRQUFRLEVBQUU4WixRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSwrQkFBK0IzZ0IsUUFBUSxFQUFFLEVBQUUsb0JBQW9CLENBQUM7TUFDckw7SUFDRjtJQUNBLElBQUkzRixNQUFNLENBQUNSLElBQUksS0FBSyxZQUFZLEtBQUssQ0FBQ3V2QixhQUFhLENBQUNwTSxHQUFHLENBQUMzaUIsTUFBTSxDQUFDUSxJQUFJLENBQUMyRyxZQUFZLENBQUNELGdCQUFnQixDQUFDLElBQUlsSCxNQUFNLENBQUNRLElBQUksQ0FBQzJHLFlBQVksQ0FBQ0QsZ0JBQWdCLEtBQUtsSCxNQUFNLENBQUNRLElBQUksQ0FBQzBHLGdCQUFnQixDQUFDLEVBQUV1WSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxxQ0FBcUMsRUFBRSxxQkFBcUIsQ0FBQztJQUM1USxJQUFJdG1CLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLFlBQVksRUFBRTtNQUNoQyxNQUFNc21CLE1BQU0sR0FBR0Qsb0JBQW9CLENBQUM3bEIsTUFBTSxDQUFDUSxJQUFJLENBQUMyRyxZQUFZLEVBQUUsR0FBR21mLFFBQVEsb0JBQW9CLENBQUM7TUFBRSxJQUFJLENBQUNSLE1BQU0sQ0FBQ1AsRUFBRSxFQUFFN0YsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR2lHLE1BQU0sQ0FBQ3BHLE1BQU0sQ0FBQztNQUM3SSxJQUFJMWYsTUFBTSxDQUFDUSxJQUFJLENBQUNtWCxpQkFBaUIsS0FBSzNYLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDbVgsaUJBQWlCLENBQUN6USxnQkFBZ0IsS0FBS2xILE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMEcsZ0JBQWdCLElBQUlsSCxNQUFNLENBQUNRLElBQUksQ0FBQ21YLGlCQUFpQixDQUFDOUcsb0JBQW9CLEtBQUs3USxNQUFNLENBQUNRLElBQUksQ0FBQzJHLFlBQVksQ0FBQzBKLG9CQUFvQixJQUFJN1EsTUFBTSxDQUFDUSxJQUFJLENBQUNtWCxpQkFBaUIsQ0FBQzVHLFVBQVUsS0FBSy9RLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMkcsWUFBWSxDQUFDNEosVUFBVSxDQUFDLEVBQUUwTyxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSx5QkFBeUIsRUFBRSw2QkFBNkIsQ0FBQztNQUN6WSxJQUFJdG1CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDa2IsbUJBQW1CLElBQUksSUFBSSxFQUFFO1FBQUEsSUFBQXFYLG1CQUFBO1FBQzNDLE1BQU1wb0IsT0FBTyxHQUFHK21CLGNBQWMsQ0FBQzF4QixNQUFNLENBQUNRLElBQUksQ0FBQzBHLGdCQUFnQixDQUFDO1FBQzVELElBQUl5RCxPQUFPLEVBQUUrVSxNQUFNLENBQUNHLElBQUksQ0FBQyxHQUFHbUcsa0NBQWtDLENBQUM7VUFBRSxHQUFHaG1CLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDMkcsWUFBWTtVQUFFNEosVUFBVSxHQUFBZ2lCLG1CQUFBLEdBQUUveUIsTUFBTSxDQUFDUSxJQUFJLENBQUM2RyxNQUFNLGNBQUEwckIsbUJBQUEsY0FBQUEsbUJBQUEsR0FBSTtRQUFVLENBQUMsRUFBRS95QixNQUFNLENBQUNRLElBQUksQ0FBQ2tiLG1CQUFtQixFQUFFLENBQUMsR0FBRy9RLE9BQU8sQ0FBQzdLLFFBQVEsQ0FBQ3dGLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHZ2hCLFFBQVEsMkJBQTJCLENBQUMsQ0FBQztNQUN4UDtJQUNGO0lBQ0EsSUFBSXRtQixNQUFNLENBQUNSLElBQUksS0FBSyxPQUFPLEVBQUU7TUFBQSxJQUFBd3pCLGtCQUFBO01BQzNCLE1BQU0zMkIsS0FBSyxHQUFHMkQsTUFBTSxDQUFDUSxJQUFzSDtNQUMzSSxJQUFJbkUsS0FBSyxDQUFDMmYsb0JBQW9CLElBQUksQ0FBQzNmLEtBQUssQ0FBQzRmLGlCQUFpQixFQUFFd0QsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsNEJBQTRCLEVBQUUsK0JBQStCLENBQUM7TUFDdEosSUFBSWpxQixLQUFLLENBQUMrRSxJQUFJLEtBQUssVUFBVSxFQUFFO1FBQzdCLElBQUkvRSxLQUFLLENBQUM0ZixpQkFBaUIsSUFBSTVmLEtBQUssQ0FBQzJmLG9CQUFvQixFQUFFeUQsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEseUJBQXlCLEVBQUUsMkRBQTJELENBQUM7UUFDOUssSUFBSSxDQUFDanFCLEtBQUssQ0FBQzBiLFdBQVcsRUFBRTBILFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLG1CQUFtQixFQUFFLG1CQUFtQixDQUFDO1FBQzdGLElBQUlqcUIsS0FBSyxDQUFDbUwsS0FBSyxDQUFDaU0sTUFBTSxFQUFFZ00sUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsYUFBYSxFQUFFLHdCQUF3QixDQUFDO01BQzlGLENBQUMsTUFBTSxJQUFJanFCLEtBQUssQ0FBQzBiLFdBQVcsSUFBSSxJQUFJLEVBQUUwSCxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxtQkFBbUIsRUFBRSxpQ0FBaUMsQ0FBQztNQUN6SGpxQixLQUFLLENBQUNtTCxLQUFLLENBQUNrTCxPQUFPLENBQUMsQ0FBQ3VnQixJQUFJLEVBQUVwUSxLQUFLLEtBQUs7UUFDbkMsS0FBSyxNQUFNLENBQUM3WCxLQUFLLEVBQUVpYixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFZ04sSUFBSSxDQUFDMWIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUwYixJQUFJLENBQUN6YixLQUFLLENBQUMsQ0FBQyxFQUFXO1VBQUUsTUFBTXNPLE1BQU0sR0FBR0Qsb0JBQW9CLENBQUNJLEtBQUssRUFBRSxHQUFHSyxRQUFRLGVBQWV6RCxLQUFLLEtBQUs3WCxLQUFLLEVBQUUsQ0FBQztVQUFFLElBQUksQ0FBQzhhLE1BQU0sQ0FBQ1AsRUFBRSxFQUFFN0YsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR2lHLE1BQU0sQ0FBQ3BHLE1BQU0sQ0FBQztRQUFFO1FBQ2xPLElBQUl1VCxJQUFJLENBQUN0YixpQkFBaUIsS0FBS3NiLElBQUksQ0FBQ3RiLGlCQUFpQixDQUFDelEsZ0JBQWdCLEtBQUs3SyxLQUFLLENBQUM2SyxnQkFBZ0IsSUFBSStyQixJQUFJLENBQUN0YixpQkFBaUIsQ0FBQzlHLG9CQUFvQixLQUFLb2lCLElBQUksQ0FBQ3piLEtBQUssQ0FBQzNHLG9CQUFvQixJQUFJb2lCLElBQUksQ0FBQ3RiLGlCQUFpQixDQUFDNUcsVUFBVSxLQUFLa2lCLElBQUksQ0FBQ3piLEtBQUssQ0FBQ3pHLFVBQVUsQ0FBQyxFQUFFME8sUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsZUFBZXpELEtBQUsscUJBQXFCLEVBQUUsNkJBQTZCLENBQUM7TUFDN1YsQ0FBQyxDQUFDO01BQ0YsQ0FBQW1RLGtCQUFBLEdBQUEzMkIsS0FBSyxDQUFDMGIsV0FBVyxjQUFBaWIsa0JBQUEsZUFBakJBLGtCQUFBLENBQW1COWEsV0FBVyxDQUFDeEYsT0FBTyxDQUFDLENBQUN3Z0IsVUFBVSxFQUFFclEsS0FBSyxLQUFLO1FBQzVELEtBQUssTUFBTSxDQUFDN1gsS0FBSyxFQUFFaWIsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRWlOLFVBQVUsQ0FBQzNiLE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFMmIsVUFBVSxDQUFDMWIsS0FBSyxDQUFDLENBQUMsRUFBVztVQUFFLE1BQU1zTyxNQUFNLEdBQUdELG9CQUFvQixDQUFDSSxLQUFLLEVBQUUsR0FBR0ssUUFBUSxpQ0FBaUN6RCxLQUFLLEtBQUs3WCxLQUFLLEVBQUUsQ0FBQztVQUFFLElBQUksQ0FBQzhhLE1BQU0sQ0FBQ1AsRUFBRSxFQUFFN0YsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR2lHLE1BQU0sQ0FBQ3BHLE1BQU0sQ0FBQztRQUFFO01BQ2xRLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsS0FBSyxNQUFNbGdCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQyxFQUFXNHhCLFdBQVcsQ0FBQ3Z4QixPQUFPLENBQUNDLFFBQVEsQ0FBQ0ssTUFBTSxDQUFDSCxNQUFNLElBQUlBLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLQSxJQUFJLElBQUksQ0FBQ1EsTUFBTSxDQUFDQyxTQUFTLENBQUMsRUFBRUQsTUFBTSxJQUFJO0lBQ3ZLLElBQUlBLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sSUFBSVEsTUFBTSxDQUFDUixJQUFJLEtBQUssT0FBTyxFQUFFLE9BQU9RLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDVSxRQUFRLEdBQUcsQ0FBQ2xCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDVSxRQUFRLENBQUMsR0FBRyxFQUFFO0lBQ2pILElBQUlsQixNQUFNLENBQUNSLElBQUksS0FBSyxZQUFZLEVBQUUsT0FBT1EsTUFBTSxDQUFDUSxJQUFJLENBQUM4RCxhQUFhLEdBQUcsQ0FBQ3RFLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDOEQsYUFBYSxDQUFDLEdBQUcsRUFBRTtJQUNyRyxJQUFJdEUsTUFBTSxDQUFDUixJQUFJLEtBQUssS0FBSyxFQUFFLE9BQU9RLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDd0osV0FBVyxHQUFHLENBQUNoSyxNQUFNLENBQUNRLElBQUksQ0FBQ3dKLFdBQVcsQ0FBQyxHQUFHLEVBQUU7SUFDMUYsT0FBTyxFQUFFO0VBQ1gsQ0FBQyxFQUFFMFYsTUFBTSxFQUFFQyxJQUFJLEVBQUUsR0FBRzVrQixXQUFXLENBQUN5RSxJQUFJLENBQUMsS0FBSyxDQUFDO0VBQzNDNHhCLFdBQVcsQ0FBQ3Z4QixPQUFPLENBQUNDLFFBQVEsQ0FBQ0ssTUFBTSxDQUFDSCxNQUFNLElBQUlBLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLGlCQUFpQixJQUFJLENBQUNRLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDLEVBQUVELE1BQU07SUFBQSxJQUFBbXpCLHFCQUFBO0lBQUEsT0FBSW56QixNQUFNLENBQUNSLElBQUksS0FBSyxpQkFBaUIsSUFBQTJ6QixxQkFBQSxHQUFHbnpCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDaU0sU0FBUyxjQUFBMG1CLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxHQUFHLEVBQUU7RUFBQSxHQUFFelQsTUFBTSxFQUFFQyxJQUFJLEVBQUUsTUFBTSxDQUFDO0VBQzVNeVIsV0FBVyxDQUFDdnhCLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDSyxNQUFNLENBQUNILE1BQU0sSUFBSUEsTUFBTSxDQUFDUixJQUFJLEtBQUssVUFBVSxJQUFJLENBQUNRLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDLEVBQUVELE1BQU0sSUFBSUEsTUFBTSxDQUFDUixJQUFJLEtBQUssVUFBVSxJQUFJUSxNQUFNLENBQUNRLElBQUksQ0FBQzZhLE9BQU8sR0FBRytYLG9CQUFvQixDQUFDcHpCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDNmEsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFcUUsTUFBTSxFQUFFQyxJQUFJLEVBQUUsTUFBTSxDQUFDO0VBQ25PeVIsV0FBVyxDQUFDdnhCLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDSyxNQUFNLENBQUNILE1BQU0sSUFBSUEsTUFBTSxDQUFDUixJQUFJLEtBQUssWUFBWSxJQUFJLENBQUNRLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDLEVBQUVELE1BQU0sSUFBSUEsTUFBTSxDQUFDUixJQUFJLEtBQUssWUFBWSxHQUFHUSxNQUFNLENBQUNRLElBQUksQ0FBQzBELE9BQU8sQ0FBQzhwQixPQUFPLENBQUNsUyxNQUFNLElBQUk7SUFBRSxNQUFNcUssSUFBSSxHQUFHOEgsU0FBUyxDQUFDN0ksR0FBRyxDQUFDdEosTUFBTSxDQUFDO0lBQUUsT0FBTyxDQUFBcUssSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUUzbUIsSUFBSSxNQUFLLFdBQVcsSUFBSTJtQixJQUFJLENBQUMzbEIsSUFBSSxDQUFDNEMsWUFBWSxHQUFHLENBQUMraUIsSUFBSSxDQUFDM2xCLElBQUksQ0FBQzRDLFlBQVksQ0FBQyxHQUFHLEVBQUU7RUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUVzYyxNQUFNLEVBQUVDLElBQUksRUFBRSxVQUFVLENBQUM7RUFDdFZELE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUdsbEIsa0JBQWtCLENBQUMsQ0FBQyxHQUFHc3pCLFNBQVMsQ0FBQzNvQixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNuRixNQUFNLENBQUVILE1BQU0sSUFBZ0NBLE1BQU0sQ0FBQ1IsSUFBSSxLQUFLLE9BQU8sSUFBSSxDQUFDUSxNQUFNLENBQUNDLFNBQVMsQ0FBQyxDQUFDLENBQUM7RUFDdkosTUFBTW96QixpQkFBaUIsR0FBRyxJQUFJcE8sR0FBRyxDQUFhLENBQUM7RUFDL0MsS0FBSyxNQUFNamxCLE1BQU0sSUFBSUgsT0FBTyxDQUFDQyxRQUFRLEVBQUUsSUFBSUUsTUFBTSxDQUFDUixJQUFJLEtBQUssV0FBVyxJQUFJUSxNQUFNLENBQUNRLElBQUksQ0FBQ3FELFFBQVEsS0FBSyxXQUFXLElBQUksQ0FBQzdELE1BQU0sQ0FBQ0MsU0FBUyxFQUFFO0lBQUEsSUFBQXF6QixxQkFBQTtJQUNuSSxNQUFNQyxXQUFXLEdBQUcsR0FBR3Z6QixNQUFNLENBQUNRLElBQUksQ0FBQ2tELE1BQU0sS0FBQTR2QixxQkFBQSxHQUFJdHpCLE1BQU0sQ0FBQ1EsSUFBSSxDQUFDd0QsUUFBUSxjQUFBc3ZCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxFQUFFO0lBQ3hFLElBQUlELGlCQUFpQixDQUFDMVEsR0FBRyxDQUFDNFEsV0FBVyxDQUFDLEVBQUU5VCxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGFBQWEzZixNQUFNLENBQUNULEVBQUUsZ0JBQWdCLEVBQUUseUJBQXlCLENBQUM7SUFBRTh6QixpQkFBaUIsQ0FBQ2hPLEdBQUcsQ0FBQ2tPLFdBQVcsRUFBRXZ6QixNQUFNLENBQUNULEVBQUUsQ0FBQztFQUNuTDtBQUNGO0FBQ0EsU0FBUzZ6QixvQkFBb0JBLENBQUMxcUIsVUFBc0IsRUFBUTtFQUMxRCxNQUFNeVosVUFBNkIsR0FBRyxFQUFFO0VBQUVELElBQUksQ0FBQztJQUFFempCLElBQUksRUFBRTtFQUFhLENBQUMsRUFBRWlLLFVBQVUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFeVosVUFBVSxDQUFDO0VBQUUsT0FBT0EsVUFBVSxDQUFDaGlCLE1BQU0sQ0FBQzhvQixTQUFTO0lBQUEsSUFBQXVLLGdCQUFBO0lBQUEsUUFBQUEsZ0JBQUEsR0FBSXZLLFNBQVMsQ0FBQ3pWLEtBQUssY0FBQWdnQixnQkFBQSx1QkFBZkEsZ0JBQUEsQ0FBaUJ6USxRQUFRLENBQUMsVUFBVSxDQUFDO0VBQUEsRUFBQyxDQUFDbG1CLEdBQUcsQ0FBQ29zQixTQUFTLElBQUlBLFNBQVMsQ0FBQzFwQixFQUFFLENBQUM7QUFDck47QUFDQSxTQUFTbXpCLDZCQUE2QkEsQ0FBQ3B5QixLQUFjLEVBQUVxZixJQUFZLEVBQUU3ZixRQUF5QixFQUFFNGYsTUFBeUIsRUFBRTBDLEtBQUssR0FBRyxDQUFDLEVBQVE7RUFDMUksSUFBSUEsS0FBSyxHQUFHLEVBQUUsSUFBSSxDQUFDOWhCLEtBQUssSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxFQUFFO0VBQ3ZELElBQUltZSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3BlLEtBQUssQ0FBQyxFQUFFO0lBQUVBLEtBQUssQ0FBQ29TLE9BQU8sQ0FBQyxDQUFDMk4sS0FBSyxFQUFFakIsQ0FBQyxLQUFLc1QsNkJBQTZCLENBQUNyUyxLQUFLLEVBQUUsR0FBR1YsSUFBSSxJQUFJUCxDQUFDLEdBQUcsRUFBRXRmLFFBQVEsRUFBRTRmLE1BQU0sRUFBRTBDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFO0VBQVE7RUFDckosTUFBTTJHLE1BQU0sR0FBR3pvQixLQUFnQztFQUMvQyxJQUFJeW9CLE1BQU0sQ0FBQ3hsQixFQUFFLEtBQUssU0FBUyxFQUFFO0lBQzNCLE1BQU14SCxRQUFRLEdBQUcrRCxRQUFRLENBQUNzbEIsR0FBRyxDQUFDMkQsTUFBTSxDQUFDMVcsVUFBZ0IsQ0FBQztJQUN0RCxJQUFJLENBQUF0VyxRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRXlELElBQUksTUFBSyxVQUFVLEVBQUU7TUFDakMsTUFBTThTLFVBQVUsR0FBR3lXLE1BQU0sQ0FBQ3pXLFVBQW9CO1FBQUVoTixNQUFNLEdBQUltWixLQUFLLENBQUNDLE9BQU8sQ0FBQ3FLLE1BQU0sQ0FBQ3pvQixLQUFLLENBQUMsR0FBR3lvQixNQUFNLENBQUN6b0IsS0FBSyxHQUFHLENBQUN5b0IsTUFBTSxDQUFDem9CLEtBQUssQ0FBa0I7TUFDdEksSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDeWlCLFFBQVEsQ0FBQ3pRLFVBQVUsQ0FBQyxJQUFJdlcsUUFBUSxDQUFDeUUsSUFBSSxDQUFDMEUsU0FBUyxLQUFLLFNBQVMsRUFBRXVhLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksYUFBYSxFQUFFLHNCQUFzQixDQUFDO01BQzFKcmEsTUFBTSxDQUFDb04sT0FBTyxDQUFDLENBQUN0WCxJQUFJLEVBQUVna0IsQ0FBQyxLQUFLO1FBQUUsSUFBSWhrQixJQUFJLENBQUNxRCxJQUFJLEtBQUssU0FBUyxJQUFJckQsSUFBSSxDQUFDcUQsSUFBSSxLQUFLMUMsUUFBUSxDQUFDeUUsSUFBSSxDQUFDMEUsU0FBUyxFQUFFdWEsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxTQUFTcmEsTUFBTSxDQUFDbU8sTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJMkwsQ0FBQyxHQUFHLEdBQUcsRUFBRSxFQUFFLEVBQUUsb0JBQW9CLENBQUM7TUFBRSxDQUFDLENBQUM7SUFDck07RUFDRjtFQUNBLEtBQUssTUFBTSxDQUFDcFUsS0FBSyxFQUFFcVYsS0FBSyxDQUFDLElBQUl6aUIsTUFBTSxDQUFDa2xCLE9BQU8sQ0FBQ2lHLE1BQU0sQ0FBQyxFQUFFMkosNkJBQTZCLENBQUNyUyxLQUFLLEVBQUUsR0FBR1YsSUFBSSxJQUFJM1UsS0FBSyxFQUFFLEVBQUVsTCxRQUFRLEVBQUU0ZixNQUFNLEVBQUUwQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBQzVJO0FBQ0EsU0FBU3VRLGVBQWVBLENBQUNyeUIsS0FBYyxFQUFFcWYsSUFBWSxFQUFFN2YsUUFBeUIsRUFBRXd1QixNQUErQyxFQUFFNU8sTUFBeUIsRUFBRTBDLEtBQUssR0FBRyxDQUFDLEVBQUVzUCxjQUF5RCxFQUFFK0IsY0FBbUIsRUFBUTtFQUM3UCxJQUFJclIsS0FBSyxHQUFHLEVBQUUsSUFBSSxDQUFDOWhCLEtBQUssSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxFQUFFO0VBQ3ZELElBQUltZSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3BlLEtBQUssQ0FBQyxFQUFFO0lBQUVBLEtBQUssQ0FBQ29TLE9BQU8sQ0FBQyxDQUFDMk4sS0FBSyxFQUFFakIsQ0FBQyxLQUFLdVQsZUFBZSxDQUFDdFMsS0FBSyxFQUFFLEdBQUdWLElBQUksSUFBSVAsQ0FBQyxHQUFHLEVBQUV0ZixRQUFRLEVBQUV3dUIsTUFBTSxFQUFFNU8sTUFBTSxFQUFFMEMsS0FBSyxHQUFHLENBQUMsRUFBRXNQLGNBQWMsRUFBRStCLGNBQWMsQ0FBQyxDQUFDO0lBQUU7RUFBUTtFQUMvSyxNQUFNMUssTUFBTSxHQUFHem9CLEtBQWdDO0VBQy9DLElBQUksT0FBT3lvQixNQUFNLENBQUNsaUIsUUFBUSxLQUFLLFFBQVEsRUFBRTtJQUFBLElBQUE2c0IsZUFBQSxFQUFBQyxhQUFBO0lBQ3ZDLElBQUk1SyxNQUFNLENBQUM5VCxjQUFjLEtBQUssWUFBWSxLQUFLLENBQUM4VCxNQUFNLENBQUM3VCxjQUFjLElBQUk2VCxNQUFNLENBQUNqVSxLQUFLLElBQUksSUFBSSxJQUFJaVUsTUFBTSxDQUFDaFUsR0FBRyxJQUFJLElBQUksQ0FBQyxFQUFFMEssUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSwrQkFBK0IsQ0FBQztJQUM3SyxJQUFJb0osTUFBTSxDQUFDOVQsY0FBYyxLQUFLLFlBQVksS0FBSzhULE1BQU0sQ0FBQzdULGNBQWMsSUFBSSxJQUFJLElBQUk2VCxNQUFNLENBQUMzZCxVQUFVLElBQUksSUFBSSxDQUFDLEVBQUVxVSxRQUFRLENBQUNDLE1BQU0sRUFBRUMsSUFBSSxFQUFFLGdDQUFnQyxDQUFDO0lBQ3BLLE1BQU1oVixPQUFPLEdBQUcsT0FBT29lLE1BQU0sQ0FBQy9ULGVBQWUsS0FBSyxRQUFRLEdBQUcrVCxNQUFNLENBQUMvVCxlQUFlLEdBQUd5ZSxjQUFjO01BQUU1USxLQUFLLEdBQUdsWSxPQUFPLElBQUkrbUIsY0FBYyxHQUFHQSxjQUFjLENBQUMvbUIsT0FBTyxDQUFDLEdBQUcrSSxTQUFTO0lBQzdLLE1BQU1rZ0IsV0FBVyxJQUFBRixlQUFBLEdBQUc3USxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRS9pQixRQUFRLGNBQUE0ekIsZUFBQSxjQUFBQSxlQUFBLEdBQUk1ekIsUUFBUTtNQUFFK3pCLFVBQVUsSUFBQUYsYUFBQSxHQUFHOVEsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUV5TCxNQUFNLGNBQUFxRixhQUFBLGNBQUFBLGFBQUEsR0FBSXJGLE1BQU07SUFDckYsSUFBSXdGLFVBQThCO0lBQ2xDLElBQUksT0FBTy9LLE1BQU0sQ0FBQ25VLE9BQU8sS0FBSyxRQUFRLEVBQUU7TUFDdEMsTUFBTWxWLEtBQUssR0FBR20wQixVQUFVLENBQUN6TyxHQUFHLENBQUMyRCxNQUFNLENBQUNuVSxPQUFPLENBQUM7TUFDNUMsSUFBSWxWLEtBQUssSUFBSUEsS0FBSyxDQUFDbUgsUUFBUSxLQUFLa2lCLE1BQU0sQ0FBQ2xpQixRQUFRLEVBQUU0WSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLFVBQVUsRUFBRSxvQkFBb0IsRUFBRSxtQkFBbUIsQ0FBQztNQUMvSG1VLFVBQVUsR0FBR3AwQixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRU4sSUFBSTtJQUMxQjtJQUNBLElBQUksT0FBTzJwQixNQUFNLENBQUNsVSxNQUFNLEtBQUssUUFBUSxFQUFFO01BQ3JDLE1BQU12VixJQUFJLEdBQUdzMEIsV0FBVyxDQUFDeE8sR0FBRyxDQUFDMkQsTUFBTSxDQUFDbFUsTUFBTSxDQUFDO01BQUUsSUFBSSxDQUFBdlYsSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVFLElBQUksTUFBSyxlQUFlLEVBQUVzMEIsVUFBVSxHQUFHcjBCLG1CQUFtQixDQUFDSCxJQUFJLENBQUNrQixJQUFJLENBQUNwQixJQUFJLENBQUM7SUFDbkk7SUFDQSxJQUFJLE9BQU8ycEIsTUFBTSxDQUFDalUsS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPaVUsTUFBTSxDQUFDaFUsR0FBRyxLQUFLLFFBQVEsRUFBRTtNQUN0RSxJQUFJLE9BQU9nVSxNQUFNLENBQUNqVSxLQUFLLEtBQUssUUFBUSxJQUFJLE9BQU9pVSxNQUFNLENBQUNoVSxHQUFHLEtBQUssUUFBUSxFQUFFMEssUUFBUSxDQUFDQyxNQUFNLEVBQUVDLElBQUksRUFBRSw0QkFBNEIsQ0FBQztNQUM1SCxJQUFJbVUsVUFBVSxLQUFLcGdCLFNBQVMsRUFBRStMLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFQyxJQUFJLEVBQUUsNkJBQTZCLENBQUMsQ0FBQyxLQUMvRSxJQUFJLE9BQU9vSixNQUFNLENBQUNoVSxHQUFHLEtBQUssUUFBUSxJQUFJZ1UsTUFBTSxDQUFDaFUsR0FBRyxHQUFHbUssZUFBZSxDQUFDNFUsVUFBVSxDQUFDLEVBQUVyVSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztJQUM3STtFQUNGO0VBQ0EsS0FBSyxNQUFNLENBQUMzVSxLQUFLLEVBQUVxVixLQUFLLENBQUMsSUFBSXppQixNQUFNLENBQUNrbEIsT0FBTyxDQUFDaUcsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsYUFBYSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUNoRyxRQUFRLENBQUMvWCxLQUFLLENBQUMsRUFBRTJuQixlQUFlLENBQUN0UyxLQUFLLEVBQUUsR0FBR1YsSUFBSSxJQUFJM1UsS0FBSyxFQUFFLEVBQUVsTCxRQUFRLEVBQUV3dUIsTUFBTSxFQUFFNU8sTUFBTSxFQUFFMEMsS0FBSyxHQUFHLENBQUMsRUFBRXNQLGNBQWMsQ0FBQztBQUMvTjtBQUNBLE9BQU8sU0FBU3FDLGVBQWVBLENBQUN0TyxLQUFjLEVBQUUyRyxPQUFpQyxHQUFHLENBQUMsQ0FBQyxFQUFpQztFQUNySCxJQUFJLENBQUM1TixRQUFRLENBQUNpSCxLQUFLLENBQUMsRUFBRSxPQUFPO0lBQUVGLEVBQUUsRUFBRSxLQUFLO0lBQUU3RixNQUFNLEVBQUUsQ0FBQztNQUFFTCxJQUFJLEVBQUUsbUJBQW1CO01BQUVNLElBQUksRUFBRSxTQUFTO01BQUVDLE9BQU8sRUFBRTtJQUFlLENBQUM7RUFBRSxDQUFDO0VBQzdILE1BQU1GLE1BQXlCLEdBQUcsRUFBRTtFQUNwQyxLQUFLLE1BQU0xVSxLQUFLLElBQUlwTixNQUFNLENBQUNDLElBQUksQ0FBQzRuQixLQUFLLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHeUYsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQ25JLFFBQVEsQ0FBQy9YLEtBQUssQ0FBQyxFQUFFeVUsUUFBUSxDQUFDQyxNQUFNLEVBQUUsV0FBVzFVLEtBQUssRUFBRSxFQUFFLGdCQUFnQixDQUFDO0VBQzdKLElBQUksQ0FBQ3lULEtBQUssQ0FBQ0MsT0FBTyxDQUFDK0csS0FBSyxDQUFDeFYsU0FBUyxDQUFDLEVBQUV3UCxRQUFRLENBQUNDLE1BQU0sRUFBRSxtQkFBbUIsRUFBRSxVQUFVLENBQUM7RUFDdEYsSUFBSSxDQUFDakIsS0FBSyxDQUFDQyxPQUFPLENBQUMrRyxLQUFLLENBQUN2VixPQUFPLENBQUMsRUFBRXVQLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLGlCQUFpQixFQUFFLFVBQVUsQ0FBQztFQUNsRixNQUFNMk0sV0FBVyxHQUFHLElBQUlwSixHQUFHLENBQUssQ0FBQ3hFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDK0csS0FBSyxDQUFDeFYsU0FBUyxDQUFDLEdBQUd3VixLQUFLLENBQUN4VixTQUFTLEdBQUcsRUFBRSxFQUFFK2QsT0FBTyxDQUFDdndCLFFBQVEsSUFBSStnQixRQUFRLENBQUMvZ0IsUUFBUSxDQUFDLElBQUksT0FBT0EsUUFBUSxDQUFDOEIsRUFBRSxLQUFLLFFBQVEsR0FBRyxDQUFDOUIsUUFBUSxDQUFDOEIsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7RUFDeEwsSUFBSTNCLE1BQU0sQ0FBQ2ltQixNQUFNLENBQUM0QixLQUFLLEVBQUUsb0JBQW9CLENBQUMsRUFBRXZELElBQUksQ0FBQ2lKLGtCQUFrQixFQUFFMUYsS0FBSyxDQUFDdU8sa0JBQWtCLEVBQUUsNEJBQTRCLEVBQUV0VSxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQzVJLE1BQU0rTCxPQUFPLEdBQUc3dEIsTUFBTSxDQUFDWSxXQUFXLENBQUN5c0Isa0JBQWtCLENBQUM5cUIsTUFBTSxDQUFDNkssS0FBSyxJQUFJcE4sTUFBTSxDQUFDaW1CLE1BQU0sQ0FBQzRCLEtBQUssRUFBRXphLEtBQUssQ0FBQyxDQUFDLENBQUNuTyxHQUFHLENBQUNtTyxLQUFLLElBQUksQ0FBQ0EsS0FBSyxFQUFFeWEsS0FBSyxDQUFDemEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3ZJLE1BQU1pcEIsU0FBUyxHQUFHOUgsZUFBZSxDQUFDVixPQUFPLEVBQUUsU0FBUyxFQUFFVyxPQUFPLEVBQUVDLFdBQVcsRUFBRTZILGtCQUFrQixDQUFDek8sS0FBSyxDQUFDeFYsU0FBUyxDQUFDLENBQUM7RUFBRSxJQUFJLENBQUNna0IsU0FBUyxDQUFDMU8sRUFBRSxFQUFFN0YsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR29VLFNBQVMsQ0FBQ3ZVLE1BQU0sQ0FBQztFQUNySyxJQUFJQSxNQUFNLENBQUNqTSxNQUFNLEVBQUUsT0FBTztJQUFFOFIsRUFBRSxFQUFFLEtBQUs7SUFBRTdGLE1BQU0sRUFBRUEsTUFBTSxDQUFDUSxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUc7RUFBRSxDQUFDO0VBQ3JFLE1BQU1yZ0IsT0FBTyxHQUFHNGxCLEtBQStCO0VBQy9DME8sMEJBQTBCLENBQUN0MEIsT0FBTyxDQUFDb1EsU0FBUyxFQUFFLG1CQUFtQixFQUFFcFEsT0FBTyxDQUFDaVAsU0FBUyxFQUFFc2QsT0FBTyxFQUFFMU0sTUFBTSxDQUFDO0VBQ3RHLE1BQU0wVSxVQUFVLEdBQUcsSUFBSW5SLEdBQUcsQ0FBSyxDQUFDO0VBQ2hDcGpCLE9BQU8sQ0FBQ3FRLE9BQU8sQ0FBQ3dDLE9BQU8sQ0FBQyxDQUFDMmhCLE9BQU8sRUFBRWpWLENBQUMsS0FBSztJQUN0QyxNQUFNTyxJQUFJLEdBQUcsbUJBQW1CUCxDQUFDLEdBQUc7TUFBRWtWLEdBQUcsR0FBR0QsT0FBa0I7SUFDOUQsSUFBSSxDQUFDN1YsUUFBUSxDQUFDOFYsR0FBRyxDQUFDLEVBQUU7TUFBRTdVLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFQyxJQUFJLEVBQUUsWUFBWSxDQUFDO01BQUU7SUFBUTtJQUNwRSxNQUFNNFUsV0FBVyxHQUFHeGdCLEdBQUcsQ0FBQztNQUFFeWdCLFdBQVcsRUFBRXhnQixHQUFHLENBQUNiLFFBQVEsQ0FBQztNQUFFckUsU0FBUyxFQUFFa0YsR0FBRyxDQUFDYixRQUFRLENBQUM7TUFBRTZILFlBQVksRUFBRWhILEdBQUcsQ0FBQztRQUFFdlYsSUFBSSxFQUFFO01BQVcsQ0FBQyxDQUFDO01BQUUwUSxRQUFRLEVBQUU2RSxHQUFHLENBQUM7UUFBRXZWLElBQUksRUFBRTtNQUFXLENBQUMsQ0FBQztNQUFFOE4sU0FBUyxFQUFFeUgsR0FBRyxDQUFDSixHQUFHLENBQUNULFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztNQUFFNVMsTUFBTSxFQUFFeVQsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUFFdkQsU0FBUyxFQUFFMEUsR0FBRyxDQUFDO1FBQUV2VixJQUFJLEVBQUU7TUFBVyxDQUFDLENBQUM7TUFBRWcyQixzQkFBc0IsRUFBRXRnQixHQUFHLENBQUNoQixRQUFRLENBQUM7TUFBRXFXLEtBQUssRUFBRXJWLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDckIsUUFBUSxFQUFFQSxRQUFRLENBQUMsQ0FBQztNQUFFdWhCLFlBQVksRUFBRXZnQixHQUFHLENBQUNKLEdBQUcsQ0FBQztRQUFFNGdCLGVBQWUsRUFBRTNnQixHQUFHLENBQUNiLFFBQVEsQ0FBQztRQUFFeWhCLGlCQUFpQixFQUFFNWdCLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO1FBQUUwaEIsaUJBQWlCLEVBQUU3Z0IsR0FBRyxDQUFDYixRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzdjLEtBQUssTUFBTW5JLEtBQUssSUFBSXBOLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDeTJCLEdBQUcsQ0FBQyxFQUFFLElBQUl0cEIsS0FBSyxLQUFLLFFBQVEsSUFBSUEsS0FBSyxLQUFLLE9BQU8sSUFBSXVwQixXQUFXLENBQUM5MUIsSUFBSSxLQUFLLFFBQVEsSUFBSSxDQUFDYixNQUFNLENBQUNpbUIsTUFBTSxDQUFDMFEsV0FBVyxDQUFDN3BCLE1BQU0sRUFBRU0sS0FBSyxDQUFDLEVBQUV5VSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLElBQUkzVSxLQUFLLEVBQUUsRUFBRSxrQkFBa0IsQ0FBQztJQUN6TmtYLElBQUksQ0FBQ3FTLFdBQVcsRUFBRTMyQixNQUFNLENBQUNZLFdBQVcsQ0FBQ1osTUFBTSxDQUFDa2xCLE9BQU8sQ0FBQ3dSLEdBQUcsQ0FBQyxDQUFDbjBCLE1BQU0sQ0FBQyxDQUFDLENBQUM2SyxLQUFLLENBQUMsS0FBS0EsS0FBSyxLQUFLLFFBQVEsSUFBSUEsS0FBSyxLQUFLLE9BQU8sQ0FBQyxDQUFDLEVBQUUyVSxJQUFJLEVBQUVELE1BQU0sRUFBRSxFQUFFLENBQUM7SUFDekksSUFBSTBVLFVBQVUsQ0FBQ3pSLEdBQUcsQ0FBQzBSLE9BQU8sQ0FBQ0csV0FBVyxDQUFDLEVBQUUvVSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHQyxJQUFJLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQztJQUFFeVUsVUFBVSxDQUFDeFIsR0FBRyxDQUFDeVIsT0FBTyxDQUFDRyxXQUFXLENBQUM7SUFDekksSUFBSUgsT0FBTyxDQUFDdmxCLFNBQVMsS0FBS2pQLE9BQU8sQ0FBQ2lQLFNBQVMsRUFBRTJRLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUdDLElBQUksWUFBWSxFQUFFLGlCQUFpQixDQUFDO0lBQ3JHLEtBQUssTUFBTTNVLEtBQUssSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBVztNQUNoRCxJQUFJLENBQUN3VCxRQUFRLENBQUM4VixHQUFHLENBQUN0cEIsS0FBSyxDQUFDLENBQUMsRUFBRTtRQUFFeVUsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxJQUFJM1UsS0FBSyxFQUFFLEVBQUUsbUJBQW1CLENBQUM7UUFBRTtNQUFVO01BQ2xHLE1BQU1pYixLQUFLLEdBQUdxTyxHQUFHLENBQUN0cEIsS0FBSyxDQUE0QjtNQUNuRCxJQUFJLENBQUN5VCxLQUFLLENBQUNDLE9BQU8sQ0FBQ3VILEtBQUssQ0FBQ2hXLFNBQVMsQ0FBQyxFQUFFd1AsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxJQUFJM1UsS0FBSyxZQUFZLEVBQUUsbUJBQW1CLENBQUM7TUFDeEcsSUFBSXBOLE1BQU0sQ0FBQ2ltQixNQUFNLENBQUNvQyxLQUFLLEVBQUUsb0JBQW9CLENBQUMsRUFBRS9ELElBQUksQ0FBQ2lKLGtCQUFrQixFQUFFbEYsS0FBSyxDQUFDK04sa0JBQWtCLEVBQUUsR0FBR3JVLElBQUksSUFBSTNVLEtBQUsscUJBQXFCLEVBQUUwVSxNQUFNLEVBQUUsRUFBRSxDQUFDO01BQ3JKLE1BQU1vVixVQUFVLEdBQUdsM0IsTUFBTSxDQUFDWSxXQUFXLENBQUNaLE1BQU0sQ0FBQ2tsQixPQUFPLENBQUNtRCxLQUFLLENBQUMsQ0FBQzlsQixNQUFNLENBQUMsQ0FBQyxDQUFDbEMsR0FBRyxDQUFDLEtBQUtBLEdBQUcsS0FBSyxXQUFXLElBQUlBLEdBQUcsS0FBSyxvQkFBb0IsQ0FBQyxDQUFDO01BQ25JLE1BQU04MkIsYUFBYSxHQUFHLElBQUk5UixHQUFHLENBQUssQ0FBQ3hFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDdUgsS0FBSyxDQUFDaFcsU0FBUyxDQUFDLEdBQUdnVyxLQUFLLENBQUNoVyxTQUFTLEdBQUcsRUFBRSxFQUFFK2QsT0FBTyxDQUFDNXlCLElBQUksSUFBSW9qQixRQUFRLENBQUNwakIsSUFBSSxDQUFDLElBQUksT0FBT0EsSUFBSSxDQUFDbUUsRUFBRSxLQUFLLFFBQVEsR0FBRyxDQUFDbkUsSUFBSSxDQUFDbUUsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7TUFDMUssTUFBTXVtQixNQUFNLEdBQUdxRyxlQUFlLENBQUMySSxVQUFVLEVBQUUsR0FBR25WLElBQUksSUFBSTNVLEtBQUssRUFBRSxFQUFFb2hCLE9BQU8sRUFBRTJJLGFBQWEsRUFBRWIsa0JBQWtCLENBQUNqTyxLQUFLLENBQUNoVyxTQUFTLENBQUMsQ0FBQztNQUFFLElBQUksQ0FBQzZWLE1BQU0sQ0FBQ1AsRUFBRSxFQUFFN0YsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR2lHLE1BQU0sQ0FBQ3BHLE1BQU0sQ0FBQyxDQUFDLEtBQ3RLLElBQUlvRyxNQUFNLENBQUN4bEIsS0FBSyxDQUFDd08sU0FBUyxLQUFLalAsT0FBTyxDQUFDaVAsU0FBUyxFQUFFMlEsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBR0MsSUFBSSxJQUFJM1UsS0FBSyxZQUFZLEVBQUUsb0JBQW9CLENBQUM7TUFDM0gsSUFBSXlULEtBQUssQ0FBQ0MsT0FBTyxDQUFDdUgsS0FBSyxDQUFDaFcsU0FBUyxDQUFDLEVBQUVra0IsMEJBQTBCLENBQUNsTyxLQUFLLENBQUNoVyxTQUFTLEVBQUUsR0FBRzBQLElBQUksSUFBSTNVLEtBQUssWUFBWSxFQUFFbkwsT0FBTyxDQUFDaVAsU0FBUyxFQUFFc2QsT0FBTyxFQUFFMU0sTUFBTSxDQUFDO0lBQ25KO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsT0FBT0EsTUFBTSxDQUFDak0sTUFBTSxHQUFHO0lBQUU4UixFQUFFLEVBQUUsS0FBSztJQUFFN0YsTUFBTSxFQUFFQSxNQUFNLENBQUNRLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRztFQUFFLENBQUMsR0FBRztJQUFFcUYsRUFBRSxFQUFFLElBQUk7SUFBRWpsQixLQUFLLEVBQUVUO0VBQVEsQ0FBQztBQUNuRztBQUNBO0FBQ0EsT0FBTyxTQUFTbTFCLHNCQUFzQkEsQ0FBQ3ZQLEtBQWtCLEVBQUUyRyxPQUFpQyxHQUFHLENBQUMsQ0FBQyxFQUFFL1YsS0FBdUIsRUFBaUM7RUFDekosTUFBTXFKLE1BQXlCLEdBQUcsRUFBRTtFQUNwQyxLQUFLLE1BQU0xVSxLQUFLLElBQUlwTixNQUFNLENBQUNDLElBQUksQ0FBQzRuQixLQUFLLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHeUYsV0FBVyxFQUFFLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQ25JLFFBQVEsQ0FBQy9YLEtBQUssQ0FBQyxFQUFFeVUsUUFBUSxDQUFDQyxNQUFNLEVBQUUsV0FBVzFVLEtBQUssRUFBRSxFQUFFLGdCQUFnQixDQUFDO0VBQzdKLElBQUksQ0FBQ3lULEtBQUssQ0FBQ0MsT0FBTyxDQUFDK0csS0FBSyxDQUFDeFYsU0FBUyxDQUFDLElBQUksQ0FBQ3dPLEtBQUssQ0FBQ0MsT0FBTyxDQUFDK0csS0FBSyxDQUFDdlYsT0FBTyxDQUFDLEVBQUV1UCxRQUFRLENBQUNDLE1BQU0sRUFBRSxTQUFTLEVBQUUsaUJBQWlCLENBQUM7RUFDcEgsSUFBSTloQixNQUFNLENBQUNpbUIsTUFBTSxDQUFDNEIsS0FBSyxFQUFFLG9CQUFvQixDQUFDLEVBQUV2RCxJQUFJLENBQUNpSixrQkFBa0IsRUFBRTFGLEtBQUssQ0FBQ3VPLGtCQUFrQixFQUFFLDRCQUE0QixFQUFFdFUsTUFBTSxFQUFFLEVBQUUsQ0FBQztFQUM1SSxJQUFJQSxNQUFNLENBQUNqTSxNQUFNLEVBQUUsT0FBTztJQUFFOFIsRUFBRSxFQUFFLEtBQUs7SUFBRTdGO0VBQU8sQ0FBQztFQUMvQyxNQUFNcUcsR0FBRyxHQUFHLElBQUk5QyxHQUFHLENBQUN3QyxLQUFLLENBQUN4VixTQUFTLENBQUNwVCxHQUFHLENBQUNZLFFBQVEsSUFBSUEsUUFBUSxDQUFDOEIsRUFBRSxDQUFDLENBQUM7RUFDakUsTUFBTWtzQixPQUFPLEdBQUc3dEIsTUFBTSxDQUFDWSxXQUFXLENBQUN5c0Isa0JBQWtCLENBQUM5cUIsTUFBTSxDQUFDNkssS0FBSyxJQUFJcE4sTUFBTSxDQUFDaW1CLE1BQU0sQ0FBQzRCLEtBQUssRUFBRXphLEtBQUssQ0FBQyxDQUFDLENBQUNuTyxHQUFHLENBQUNtTyxLQUFLLElBQUksQ0FBQ0EsS0FBSyxFQUFHeWEsS0FBSyxDQUF3Q3phLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUMvSyxNQUFNOGEsTUFBTSxHQUFHcUcsZUFBZSxDQUFDVixPQUFPLEVBQUUsU0FBUyxFQUFFVyxPQUFPLEVBQUVyRyxHQUFHLEVBQUVtTyxrQkFBa0IsQ0FBQ3pPLEtBQUssQ0FBQ3hWLFNBQVMsQ0FBQyxFQUFFb0csS0FBSyxDQUFDO0VBQzVHLE9BQU95UCxNQUFNLENBQUNQLEVBQUUsR0FBRztJQUFFQSxFQUFFLEVBQUUsSUFBSTtJQUFFamxCLEtBQUssRUFBRW1sQjtFQUFNLENBQUMsR0FBR0ssTUFBTTtBQUN4RDtBQUNBLFNBQVNxTywwQkFBMEJBLENBQUNsa0IsU0FBb0IsRUFBRTBQLElBQVksRUFBRTdRLFNBQWEsRUFBRXNkLE9BQWlDLEVBQUUxTSxNQUF5QixFQUFRO0VBQ3pKLE1BQU1xRyxHQUFHLEdBQUcsSUFBSTlDLEdBQUcsQ0FBS2hULFNBQVMsQ0FBQytkLE9BQU8sQ0FBQ3Z3QixRQUFRLElBQUkrZ0IsUUFBUSxDQUFDL2dCLFFBQVEsQ0FBQyxJQUFJLE9BQU9BLFFBQVEsQ0FBQzhCLEVBQUUsS0FBSyxRQUFRLEdBQUcsQ0FBQzlCLFFBQVEsQ0FBQzhCLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQUUwMUIsVUFBVSxHQUFHLElBQUloUyxHQUFHLENBQUssQ0FBQztJQUFFaVMsUUFBUSxHQUFHaEIsa0JBQWtCLENBQUNqa0IsU0FBUyxDQUFDO0VBQ3hNQSxTQUFTLENBQUN5QyxPQUFPLENBQUMsQ0FBQ2pWLFFBQVEsRUFBRTJoQixDQUFDLEtBQUs7SUFDakMsTUFBTWtILFFBQVEsR0FBRyxHQUFHM0csSUFBSSxJQUFJUCxDQUFDLEdBQUc7SUFDaEMsSUFBSSxDQUFDWixRQUFRLENBQUMvZ0IsUUFBUSxDQUFDLEVBQUU7TUFBRWdpQixRQUFRLENBQUNDLE1BQU0sRUFBRTRHLFFBQVEsRUFBRSxlQUFlLENBQUM7TUFBRTtJQUFRO0lBQ2hGLE1BQU02TyxRQUFRLEdBQUdwaEIsR0FBRyxDQUFDO01BQUV4VSxFQUFFLEVBQUV5VSxHQUFHLENBQUNiLFFBQVEsQ0FBQztNQUFFdkYsWUFBWSxFQUFFb0csR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztNQUFFaEwsV0FBVyxFQUFFbU0sR0FBRyxDQUFDO1FBQUV2VixJQUFJLEVBQUU7TUFBTyxDQUFDLENBQUM7TUFBRTZRLFNBQVMsRUFBRTBFLEdBQUcsQ0FBQztRQUFFdlYsSUFBSSxFQUFFO01BQVcsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUNySixLQUFLLE1BQU11TSxLQUFLLElBQUlwTixNQUFNLENBQUNDLElBQUksQ0FBQ0osUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDc2xCLFFBQVEsQ0FBQy9YLEtBQUssQ0FBQyxFQUFFeVUsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsSUFBSXRiLEtBQUssRUFBRSxFQUFFLGlCQUFpQixDQUFDO0lBQzFMa1gsSUFBSSxDQUFDaVQsUUFBUSxFQUFFdjNCLE1BQU0sQ0FBQ1ksV0FBVyxDQUFDWixNQUFNLENBQUNrbEIsT0FBTyxDQUFDcmxCLFFBQVEsQ0FBQyxDQUFDMEMsTUFBTSxDQUFDLENBQUMsQ0FBQzZLLEtBQUssQ0FBQyxLQUFLQSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsRUFBRXNiLFFBQVEsRUFBRTVHLE1BQU0sRUFBRSxFQUFFLENBQUM7SUFDM0gsSUFBSSxPQUFPamlCLFFBQVEsQ0FBQzhCLEVBQUUsS0FBSyxRQUFRLEVBQUU7TUFDbkMsSUFBSTAxQixVQUFVLENBQUN0UyxHQUFHLENBQUNsbEIsUUFBUSxDQUFDOEIsRUFBRSxDQUFDLEVBQUVrZ0IsUUFBUSxDQUFDQyxNQUFNLEVBQUUsR0FBRzRHLFFBQVEsS0FBSyxFQUFFLGlCQUFpQixDQUFDO01BQUUyTyxVQUFVLENBQUNyUyxHQUFHLENBQUNubEIsUUFBUSxDQUFDOEIsRUFBRSxDQUFDO01BQ25ILElBQUk5QixRQUFRLENBQUM4QixFQUFFLEtBQUt1UCxTQUFTLEVBQUUyUSxRQUFRLENBQUNDLE1BQU0sRUFBRSxHQUFHNEcsUUFBUSxLQUFLLEVBQUUsc0JBQXNCLENBQUM7SUFDM0Y7SUFDQSxNQUFNUixNQUFNLEdBQUdxRyxlQUFlLENBQUMxdUIsUUFBUSxDQUFDZ3VCLE9BQU8sRUFBRSxHQUFHbkYsUUFBUSxVQUFVLEVBQUU4RixPQUFPLEVBQUVyRyxHQUFHLEVBQUVtUCxRQUFRLENBQUM7SUFDL0YsSUFBSSxDQUFDcFAsTUFBTSxDQUFDUCxFQUFFLEVBQUU3RixNQUFNLENBQUNHLElBQUksQ0FBQyxHQUFHaUcsTUFBTSxDQUFDcEcsTUFBTSxDQUFDLENBQUMsS0FDekMsSUFBSW9HLE1BQU0sQ0FBQ3hsQixLQUFLLENBQUN3TyxTQUFTLEtBQUtBLFNBQVMsRUFBRTJRLFFBQVEsQ0FBQ0MsTUFBTSxFQUFFLEdBQUc0RyxRQUFRLG9CQUFvQixFQUFFLGtCQUFrQixDQUFDO0VBQ3RILENBQUMsQ0FBQztBQUNKO0FBQ0EsU0FBUzROLGtCQUFrQkEsQ0FBQ2prQixTQUFrQixFQUEyQjtFQUN2RSxJQUFJLENBQUN3TyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3pPLFNBQVMsQ0FBQyxFQUFFLE9BQU8sSUFBSWdWLEdBQUcsQ0FBQyxDQUFDO0VBQy9DLE9BQU8sSUFBSUEsR0FBRyxDQUFDaFYsU0FBUyxDQUFDK2QsT0FBTyxDQUFDdndCLFFBQVEsSUFBSStnQixRQUFRLENBQUMvZ0IsUUFBUSxDQUFDLElBQUksT0FBT0EsUUFBUSxDQUFDOEIsRUFBRSxLQUFLLFFBQVEsSUFBSWlmLFFBQVEsQ0FBQy9nQixRQUFRLENBQUNndUIsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDMkosS0FBSyxDQUFDbjNCLEdBQUcsSUFBSXdnQixLQUFLLENBQUNDLE9BQU8sQ0FBRWpoQixRQUFRLENBQUNndUIsT0FBTyxDQUE2Qnh0QixHQUFHLENBQUMsQ0FBQyxJQUFNUixRQUFRLENBQUNndUIsT0FBTyxDQUE2Qnh0QixHQUFHLENBQUMsQ0FBZW0zQixLQUFLLENBQUM1VyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQy9nQixRQUFRLENBQUM4QixFQUFFLEVBQUU5QixRQUFRLENBQUNndUIsT0FBTyxDQUE4QixDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDNWE7QUFHQTtBQUNBLE9BQU8sU0FBUzRKLFlBQVlBLENBQUEsRUFBZTtFQUN6QyxNQUFNcE0sU0FBUyxHQUFJbGEsSUFBWSxLQUFrQjtJQUFFdW1CLElBQUksRUFBRSxXQUFXdm1CLElBQUk7RUFBRyxDQUFDLENBQUM7RUFDN0UsU0FBU3dtQixPQUFPQSxDQUFDdGhCLE1BQWMsRUFBYztJQUFBLElBQUF1aEIsWUFBQTtJQUMzQyxRQUFRdmhCLE1BQU0sQ0FBQ3hWLElBQUk7TUFDakIsS0FBSyxNQUFNO1FBQUUsT0FBTztVQUFFQSxJQUFJLEVBQUUsUUFBUTtVQUFFLElBQUl3VixNQUFNLENBQUM1QyxHQUFHLElBQUksSUFBSSxHQUFHO1lBQUVva0IsU0FBUyxFQUFFeGhCLE1BQU0sQ0FBQzVDO1VBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1VBQUUsSUFBSTRDLE1BQU0sQ0FBQzNDLEdBQUcsSUFBSSxJQUFJLEdBQUc7WUFBRW9rQixTQUFTLEVBQUV6aEIsTUFBTSxDQUFDM0M7VUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQUUsQ0FBQztNQUMxSixLQUFLLFFBQVE7UUFBRSxPQUFPO1VBQUU3UyxJQUFJLEVBQUV3VixNQUFNLENBQUNoQixPQUFPLEdBQUcsU0FBUyxHQUFHLFFBQVE7VUFBRSxJQUFJZ0IsTUFBTSxDQUFDNUMsR0FBRyxJQUFJLElBQUksR0FBRztZQUFFc2tCLE9BQU8sRUFBRTFoQixNQUFNLENBQUM1QztVQUFJLENBQUMsR0FBRzRDLE1BQU0sQ0FBQ2hCLE9BQU8sR0FBRztZQUFFMGlCLE9BQU8sRUFBRXRjLE1BQU0sQ0FBQ3VjO1VBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztVQUFFLElBQUkzaEIsTUFBTSxDQUFDM0MsR0FBRyxJQUFJLElBQUksR0FBRztZQUFFdWtCLE9BQU8sRUFBRTVoQixNQUFNLENBQUMzQztVQUFJLENBQUMsR0FBRzJDLE1BQU0sQ0FBQ2hCLE9BQU8sR0FBRztZQUFFNGlCLE9BQU8sRUFBRXhjLE1BQU0sQ0FBQ3ljO1VBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFBRSxDQUFDO01BQ3JTLEtBQUssU0FBUztRQUFFLE9BQU87VUFBRXIzQixJQUFJLEVBQUU7UUFBVSxDQUFDO01BQzFDLEtBQUssTUFBTTtRQUFFLE9BQU8sQ0FBQyxDQUFDO01BQ3RCLEtBQUssTUFBTTtRQUFFLE9BQU87VUFBRXMzQixJQUFJLEVBQUU5aEIsTUFBTSxDQUFDM087UUFBTyxDQUFDO01BQzNDLEtBQUssSUFBSTtRQUFFLE9BQU8yakIsU0FBUyxDQUFDLElBQUksQ0FBQztNQUNqQyxLQUFLLEtBQUs7UUFBRSxPQUFPO1VBQUUsSUFBSWhWLE1BQU0sQ0FBQzlPLEtBQUssS0FBSyxVQUFVLEdBQUc7WUFBRTFHLElBQUksRUFBRSxRQUFRO1lBQUVnM0IsU0FBUyxFQUFFO1VBQUUsQ0FBQyxHQUFHeE0sU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1VBQUUsSUFBSWhWLE1BQU0sQ0FBQ1QsS0FBSyxJQUFJUyxNQUFNLENBQUM5TyxLQUFLLEdBQUc7WUFBRTZ3QixRQUFRLEVBQUV0UyxJQUFJLENBQUNDLFNBQVMsQ0FBQztjQUFFLElBQUkxUCxNQUFNLENBQUNULEtBQUssR0FBRztnQkFBRXNGLFdBQVcsRUFBRTdFLE1BQU0sQ0FBQ1Q7Y0FBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Y0FBRSxJQUFJUyxNQUFNLENBQUM5TyxLQUFLLEdBQUc7Z0JBQUU4d0IsY0FBYyxFQUFFaGlCLE1BQU0sQ0FBQzlPO2NBQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUFFLENBQUM7VUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQUUsQ0FBQztNQUMxUyxLQUFLLE1BQU07UUFBRSxPQUFPOGpCLFNBQVMsQ0FBQyxNQUFNLENBQUM7TUFDckMsS0FBSyxVQUFVO1FBQUUsT0FBT0EsU0FBUyxDQUFDLFVBQVUsQ0FBQztNQUM3QyxLQUFLLFVBQVU7UUFBRSxPQUFPO1VBQUV4cUIsSUFBSSxFQUFFLFFBQVE7VUFBRXkzQixNQUFNLEVBQUUsV0FBVztVQUFFQyxPQUFPLEVBQUU7UUFBOEYsQ0FBQztNQUN2SyxLQUFLLE1BQU07UUFBRSxPQUFPO1VBQUUxM0IsSUFBSSxFQUFFLFFBQVE7VUFBRXkzQixNQUFNLEVBQUU7UUFBTyxDQUFDO01BQ3RELEtBQUssTUFBTTtRQUFFLE9BQU87VUFBRXozQixJQUFJLEVBQUUsUUFBUTtVQUFFMDNCLE9BQU8sRUFBRTtRQUFpQixDQUFDO01BQ2pFLEtBQUssV0FBVztRQUFFLE9BQU87VUFBRTEzQixJQUFJLEVBQUUsUUFBUTtVQUFFZzNCLFNBQVMsRUFBRSxDQUFDO1VBQUVVLE9BQU8sRUFBRTtRQUF3RyxDQUFDO01BQzNLLEtBQUssT0FBTztRQUFFLE9BQU87VUFBRTEzQixJQUFJLEVBQUUsT0FBTztVQUFFMjNCLEtBQUssRUFBRWIsT0FBTyxDQUFDdGhCLE1BQU0sQ0FBQzdZLElBQUksQ0FBQztVQUFFLElBQUk2WSxNQUFNLENBQUM1QyxHQUFHLElBQUksSUFBSSxHQUFHO1lBQUVnbEIsUUFBUSxFQUFFcGlCLE1BQU0sQ0FBQzVDO1VBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1VBQUVpbEIsUUFBUSxHQUFBZCxZQUFBLEdBQUV2aEIsTUFBTSxDQUFDM0MsR0FBRyxjQUFBa2tCLFlBQUEsY0FBQUEsWUFBQSxHQUFJLE1BQU87VUFBRSxJQUFJdmhCLE1BQU0sQ0FBQ0osTUFBTSxHQUFHO1lBQUUwaUIsV0FBVyxFQUFFO1VBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUFFLENBQUM7TUFDOU0sS0FBSyxRQUFRO1FBQUUsT0FBTztVQUFFOTNCLElBQUksRUFBRSxRQUFRO1VBQUVxRCxVQUFVLEVBQUVsRSxNQUFNLENBQUNZLFdBQVcsQ0FBQ1osTUFBTSxDQUFDa2xCLE9BQU8sQ0FBQzdPLE1BQU0sQ0FBQ3ZKLE1BQU0sQ0FBQyxDQUFDN04sR0FBRyxDQUFDLENBQUMsQ0FBQ2tTLElBQUksRUFBRS9ELEtBQUssQ0FBQyxLQUFLLENBQUMrRCxJQUFJLEVBQUUvRCxLQUFLLENBQUNvSixRQUFRLEdBQUc7WUFBRW9pQixLQUFLLEVBQUUsQ0FBQ2pCLE9BQU8sQ0FBQ3ZxQixLQUFLLENBQUNpSixNQUFNLENBQUMsRUFBRTtjQUFFeFYsSUFBSSxFQUFFO1lBQU8sQ0FBQztVQUFFLENBQUMsR0FBRzgyQixPQUFPLENBQUN2cUIsS0FBSyxDQUFDaUosTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUVDLFFBQVEsRUFBRXRXLE1BQU0sQ0FBQ2tsQixPQUFPLENBQUM3TyxNQUFNLENBQUN2SixNQUFNLENBQUMsQ0FBQ3ZLLE1BQU0sQ0FBQyxDQUFDLEdBQUc2SyxLQUFLLENBQUMsS0FBS0EsS0FBSyxDQUFDa0osUUFBUSxDQUFDLENBQUNyWCxHQUFHLENBQUMsQ0FBQyxDQUFDa1MsSUFBSSxDQUFDLEtBQUtBLElBQUksQ0FBQztVQUFFMG5CLG9CQUFvQixFQUFFO1FBQU0sQ0FBQztNQUN2VyxLQUFLLFFBQVE7UUFBRSxPQUFPO1VBQUVoNEIsSUFBSSxFQUFFLFFBQVE7VUFBRWc0QixvQkFBb0IsRUFBRWxCLE9BQU8sQ0FBQ3RoQixNQUFNLENBQUMzVCxLQUFLLENBQUM7VUFBRSxJQUFJMlQsTUFBTSxDQUFDaFcsR0FBRyxHQUFHO1lBQUV5NEIsYUFBYSxFQUFFbkIsT0FBTyxDQUFDdGhCLE1BQU0sQ0FBQ2hXLEdBQUc7VUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQUUsQ0FBQztNQUNwSixLQUFLLE9BQU87UUFBRSxPQUFPO1VBQUV1NEIsS0FBSyxFQUFFdmlCLE1BQU0sQ0FBQ1UsT0FBTyxDQUFDOVgsR0FBRyxDQUFDMDRCLE9BQU87UUFBRSxDQUFDO01BQzNELEtBQUssVUFBVTtRQUFFLE9BQU90TSxTQUFTLENBQUMsVUFBVSxDQUFDO01BQzdDLEtBQUssUUFBUTtRQUFFLE9BQU9BLFNBQVMsQ0FBQyxhQUFhLENBQUM7TUFDOUMsS0FBSyxPQUFPO1FBQUUsT0FBT0EsU0FBUyxDQUFDLFlBQVksQ0FBQztNQUM1QyxLQUFLLE1BQU07UUFBRSxPQUFPQSxTQUFTLENBQUMsVUFBVSxDQUFDO01BQ3pDLEtBQUssV0FBVztRQUFFLE9BQU9BLFNBQVMsQ0FBQyxXQUFXLENBQUM7TUFDL0MsS0FBSyxZQUFZO1FBQUUsT0FBT0EsU0FBUyxDQUFDLFlBQVksQ0FBQztNQUNqRCxLQUFLLGFBQWE7UUFBRSxPQUFPQSxTQUFTLENBQUMsWUFBWSxDQUFDO01BQ2xELEtBQUssT0FBTztRQUFFLE9BQU9BLFNBQVMsQ0FBQyxPQUFPLENBQUM7SUFDekM7RUFDRjtFQUNBLE1BQU0wTixzQkFBc0IsR0FBRyxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM5NUIsR0FBRyxDQUFDMEcsRUFBRSxJQUFJO0lBQzVILE1BQU11Z0IsVUFBVSxHQUFHeVIsT0FBTyxDQUFDcFYsZUFBZSxDQUFDO01BQUU1YyxFQUFFO01BQUUrTyxVQUFVLEVBQUU7SUFBSyxDQUFDLENBQUUsQ0FBQztJQUFHd1IsVUFBVSxDQUFDaGlCLFVBQVUsQ0FBZ0N5QixFQUFFLEdBQUc7TUFBRXF6QixLQUFLLEVBQUVyekI7SUFBRyxDQUFDO0lBQUUsT0FBT3VnQixVQUFVO0VBQ3JLLENBQUMsQ0FBQztFQUNGNlMsc0JBQXNCLENBQUM5VyxJQUFJLENBQUMwVixPQUFPLENBQUNwVixlQUFlLENBQUM7SUFBRTVjLEVBQUUsRUFBRSxTQUFTO0lBQUUrTyxVQUFVLEVBQUU7RUFBSyxDQUFDLENBQUUsQ0FBQyxDQUFDO0VBQzNGO0VBQ0EsTUFBTXVrQixpQkFBaUIsR0FBR0Ysc0JBQXNCLENBQUMsQ0FBQyxDQUE0QztFQUFFRSxpQkFBaUIsQ0FBQy8wQixVQUFVLENBQUN3USxVQUFVLEdBQUc7SUFBRXlqQixJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUk7RUFBRSxDQUFDO0VBQ3hMLE1BQU1lLFlBQVksR0FBR0gsc0JBQXNCLENBQUN4bEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUE0QztFQUFFMmxCLFlBQVksQ0FBQ2gxQixVQUFVLENBQUN3USxVQUFVLEdBQUc7SUFBRXNrQixLQUFLLEVBQUU7RUFBSyxDQUFDO0VBQ25KLE1BQU1HLElBQUksR0FBRztJQUFFamlCLEtBQUssRUFBRWQsR0FBRyxDQUFDaEIsR0FBRyxDQUFDLENBQUMsRUFBRVUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQUVxQixHQUFHLEVBQUVmLEdBQUcsQ0FBQ2hCLEdBQUcsQ0FBQyxDQUFDLEVBQUVVLFNBQVMsRUFBRSxJQUFJLENBQUM7RUFBRSxDQUFDO0VBQ3ZGLE1BQU1oVSxLQUFLLEdBQUdxVSxHQUFHLENBQUM7SUFBRXhVLEVBQUUsRUFBRXlVLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0lBQUUzVCxJQUFJLEVBQUV3VSxHQUFHLENBQUNWLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUFFbFUsSUFBSSxFQUFFNFUsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUFFa1AsSUFBSSxFQUFFNU4sR0FBRyxDQUFDUCxHQUFHLENBQUNHLEdBQUcsQ0FBQztNQUFFLEdBQUdnakIsSUFBSTtNQUFFMzNCLElBQUksRUFBRTRVLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFbVAsS0FBSyxFQUFFN04sR0FBRyxDQUFDUCxHQUFHLENBQUNHLEdBQUcsQ0FBQztNQUFFLEdBQUdnakIsSUFBSTtNQUFFOXJCLE1BQU0sRUFBRStJLEdBQUcsQ0FBQ3BOLE1BQU07SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUVxYixxQkFBcUIsRUFBRTlOLEdBQUcsQ0FBQ1AsR0FBRyxDQUFDdUIsd0JBQXdCLENBQUM7RUFBRSxDQUFDLENBQUM7RUFDOVIsTUFBTTZoQixjQUFjLEdBQUc7SUFBRXozQixFQUFFLEVBQUV5VSxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBRTlELElBQUksRUFBRWlGLEdBQUcsQ0FBQ25CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFb2tCLFdBQVcsRUFBRWpqQixHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUVxa0IsV0FBVyxFQUFFbGpCLEdBQUcsQ0FBQ1osSUFBSTtFQUFFLENBQUM7RUFDOUcsTUFBTTBZLFFBQVEsR0FBR3BYLEtBQUssQ0FBQ1gsR0FBRyxDQUFDO0lBQUUsR0FBR2lqQixjQUFjO0lBQUV4M0IsSUFBSSxFQUFFd1UsR0FBRyxDQUFDVixFQUFFLENBQUMsV0FBVyxDQUFDO0VBQUUsQ0FBQyxDQUFDLEVBQUVTLEdBQUcsQ0FBQztJQUFFLEdBQUdpakIsY0FBYztJQUFFeDNCLElBQUksRUFBRXdVLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQUU2akIsS0FBSyxFQUFFbmpCLEdBQUcsQ0FBQ0osR0FBRyxDQUFDRyxHQUFHLENBQUM7TUFBRXFqQixNQUFNLEVBQUVwakIsR0FBRyxDQUFDSixHQUFHLENBQUNHLEdBQUcsQ0FBQztRQUFFaEYsSUFBSSxFQUFFaUYsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUV3a0IsSUFBSSxFQUFFcmpCLEdBQUcsQ0FBQ2hCLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQztNQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUM7RUFBRSxDQUFDLENBQUMsQ0FBQztFQUN6USxNQUFNc2tCLElBQWdDLEdBQUc7SUFDdkNDLEVBQUUsRUFBRTtNQUFFOTRCLElBQUksRUFBRSxRQUFRO01BQUUwM0IsT0FBTyxFQUFFejNCLFVBQVUsQ0FBQ25DO0lBQU8sQ0FBQztJQUFFaTdCLElBQUksRUFBRTtNQUFFLzRCLElBQUksRUFBRSxRQUFRO01BQUUwM0IsT0FBTyxFQUFFO0lBQTZDLENBQUM7SUFBRXNCLFFBQVEsRUFBRTtNQUFFaDVCLElBQUksRUFBRSxRQUFRO01BQUUwM0IsT0FBTyxFQUFFeDNCLGdCQUFnQixDQUFDcEM7SUFBTyxDQUFDO0lBQ25NbTdCLFFBQVEsRUFBRW5DLE9BQU8sQ0FBQzNoQixHQUFHLENBQUNsVSxLQUFLLENBQUMsQ0FBQztJQUFFaTRCLFdBQVcsRUFBRTtNQUFFbkIsS0FBSyxFQUFFLENBQUM7UUFBRS8zQixJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxNQUFNO01BQUUsQ0FBQyxFQUFFODJCLE9BQU8sQ0FBQ3hoQixHQUFHLENBQUM7UUFBRXRWLElBQUksRUFBRXVWLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNULEdBQUcsQ0FBQyxDQUFDO01BQUUsQ0FBQyxDQUFDLENBQUMsRUFBRWdpQixPQUFPLENBQUN4aEIsR0FBRyxDQUFDO1FBQUV0VixJQUFJLEVBQUV1VixHQUFHLENBQUNWLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUFFaFQsS0FBSyxFQUFFMFQsR0FBRyxDQUFDO1VBQUV2VixJQUFJLEVBQUU7UUFBTyxDQUFDO01BQUUsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDO0lBQzVPbTVCLFVBQVUsRUFBRTtNQUFFQyxLQUFLLEVBQUUsQ0FBQ3RDLE9BQU8sQ0FBQ3hoQixHQUFHLENBQUM7UUFBRXRWLElBQUksRUFBRXVWLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNkLElBQUk7TUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFcWlCLE9BQU8sQ0FBQ3hoQixHQUFHLENBQUM7UUFBRXRWLElBQUksRUFBRXVWLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNoQixHQUFHLENBQUNVLFNBQVMsRUFBRUEsU0FBUyxFQUFFLElBQUksQ0FBQztNQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU2aEIsT0FBTyxDQUFDeGhCLEdBQUcsQ0FBQztRQUFFdFYsSUFBSSxFQUFFdVYsR0FBRyxDQUFDVixFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQztNQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUwaUIsT0FBTyxDQUFDeGhCLEdBQUcsQ0FBQztRQUFFdFYsSUFBSSxFQUFFdVYsR0FBRyxDQUFDVixFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7UUFBRWhULEtBQUssRUFBRTBULEdBQUcsQ0FBQ1QsR0FBRyxDQUFDLENBQUM7TUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFZ2lCLE9BQU8sQ0FBQ3hoQixHQUFHLENBQUM7UUFBRXRWLElBQUksRUFBRXVWLEdBQUcsQ0FBQ1YsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQUVoVCxLQUFLLEVBQUUwVCxHQUFHLENBQUNWLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUFFL1MsTUFBTSxFQUFFeVQsR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUM7TUFBRSxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUM7SUFDbllpbEIsUUFBUSxFQUFFO01BQUVELEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQ2g3QixHQUFHLENBQUN1RSxJQUFJLElBQUltMEIsT0FBTyxDQUFDMVUsVUFBVSxDQUFDO1FBQUV6ZjtNQUFLLENBQUMsQ0FBRSxDQUFDO0lBQUUsQ0FBQztJQUM1SDIyQixTQUFTLEVBQUU7TUFBRUYsS0FBSyxFQUFFbEI7SUFBdUIsQ0FBQztJQUFFcUIsVUFBVSxFQUFFO01BQUV4QixLQUFLLEVBQUUsQ0FBQ3ZOLFNBQVMsQ0FBQyxXQUFXLENBQUMsRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQ3BzQixHQUFHLENBQUMwRyxFQUFFLElBQUlneUIsT0FBTyxDQUFDL1UsZ0JBQWdCLENBQUM7UUFBRWpkO01BQUcsQ0FBQyxDQUFFLENBQUMsQ0FBQztJQUFFLENBQUM7SUFDMU0wMEIsVUFBVSxFQUFFO01BQUV6QixLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUMzNUIsR0FBRyxDQUFDdUUsSUFBSSxJQUFJbTBCLE9BQU8sQ0FBQ2pVLGdCQUFnQixDQUFDO1FBQUVsZ0I7TUFBSyxDQUFDLENBQUUsQ0FBQyxDQUFDLEVBQUVtMEIsT0FBTyxDQUFDalUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUUsQ0FBQztJQUFFLENBQUM7SUFDMUo0VyxLQUFLLEVBQUU7TUFBRUwsS0FBSyxFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQ2g3QixHQUFHLENBQUMwRyxFQUFFLElBQUk7UUFDdkgsTUFBTXVnQixVQUFVLEdBQUd5UixPQUFPLENBQUNsVSxXQUFXLENBQUM7VUFBRTlkO1FBQUcsQ0FBQyxDQUFFLENBQUM7UUFBR3VnQixVQUFVLENBQUNoaUIsVUFBVSxDQUFnQ3lCLEVBQUUsR0FBRztVQUFFcXpCLEtBQUssRUFBRXJ6QjtRQUFHLENBQUM7UUFDMUg7UUFDQTtRQUNBO1FBQ0EsSUFBSUEsRUFBRSxLQUFLLFlBQVksRUFBRXVnQixVQUFVLENBQUMwUyxLQUFLLEdBQUcsQ0FBQyxjQUFjLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDMzVCLEdBQUcsQ0FBQ21PLEtBQUssS0FBSztVQUFFbEosVUFBVSxFQUFFO1lBQUUsQ0FBQ2tKLEtBQUssR0FBRyxDQUFDO1VBQUUsQ0FBQztVQUFFa0osUUFBUSxFQUFFLENBQUNsSixLQUFLO1FBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEssT0FBTzhZLFVBQVU7TUFDbkIsQ0FBQztJQUFFLENBQUM7SUFDSnFVLFFBQVEsRUFBRTVDLE9BQU8sQ0FBQ3pKLFFBQVEsQ0FBQztJQUFFc00sUUFBUSxFQUFFN0MsT0FBTyxDQUFDeFEsY0FBYyxDQUFDO0lBQUVzVCxjQUFjLEVBQUU5QyxPQUFPLENBQUM3SyxvQkFBb0IsQ0FBQztJQUFFNE4sU0FBUyxFQUFFL0MsT0FBTyxDQUFDM0ssVUFBVSxDQUFDO0lBQzdJMk4sTUFBTSxFQUFFO01BQUVWLEtBQUssRUFBRWw2QixZQUFZLENBQUNkLEdBQUcsQ0FBQzJDLElBQUksSUFBSXlwQixTQUFTLENBQUMsVUFBVXpwQixJQUFJLEVBQUUsQ0FBQztJQUFFO0VBQ3pFLENBQUM7RUFDRCxLQUFLLE1BQU1BLElBQUksSUFBSTdCLFlBQVksRUFBRTI1QixJQUFJLENBQUMsVUFBVTkzQixJQUFJLEVBQUUsQ0FBQyxHQUFHKzFCLE9BQU8sQ0FBQ3JRLFlBQVksQ0FBQzFsQixJQUFJLENBQUMsQ0FBQztFQUNyRixNQUFNZzVCLGNBQWMsR0FBRyxDQUFDLENBQUM7RUFDekIsTUFBTUMsYUFBYSxHQUFHO0lBQUVoNkIsSUFBSSxFQUFFLFFBQVE7SUFBRXFELFVBQVUsRUFBRTtNQUFFNDJCLE9BQU8sRUFBRTtRQUFFajZCLElBQUksRUFBRTtNQUFVLENBQUM7TUFBRTZCLEtBQUssRUFBRWs0QjtJQUFlLENBQUM7SUFBRXRrQixRQUFRLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFBRXVpQixvQkFBb0IsRUFBRTtFQUFNLENBQUM7RUFDakthLElBQUksQ0FBQ3FCLGdCQUFnQixHQUFHO0lBQUVsNkIsSUFBSSxFQUFFLFFBQVE7SUFBRXFELFVBQVUsRUFBRTtNQUFFN0QsR0FBRyxFQUFFO1FBQUVRLElBQUksRUFBRSxRQUFRO1FBQUVnM0IsU0FBUyxFQUFFO01BQUUsQ0FBQztNQUFFdHdCLEtBQUssRUFBRTtRQUFFNHdCLElBQUksRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLGNBQWM7TUFBRSxDQUFDO01BQUV6VixNQUFNLEVBQUUySSxTQUFTLENBQUMsSUFBSSxDQUFDO01BQUV0SixJQUFJLEVBQUU7UUFBRWxoQixJQUFJLEVBQUUsT0FBTztRQUFFMjNCLEtBQUssRUFBRTtVQUFFMzNCLElBQUksRUFBRTtRQUFTO01BQUUsQ0FBQztNQUFFUCxLQUFLLEVBQUU7UUFBRU8sSUFBSSxFQUFFO01BQVMsQ0FBQztNQUFFOFksTUFBTSxFQUFFa2hCLGFBQWE7TUFBRWpoQixLQUFLLEVBQUVpaEI7SUFBYyxDQUFDO0lBQUV2a0IsUUFBUSxFQUFFLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUM7SUFBRXVpQixvQkFBb0IsRUFBRTtFQUFNLENBQUM7RUFDdlphLElBQUksQ0FBQ3NCLHVCQUF1QixHQUFHO0lBQUVuNkIsSUFBSSxFQUFFLFFBQVE7SUFBRXFELFVBQVUsRUFBRTtNQUFFdkMsRUFBRSxFQUFFMHBCLFNBQVMsQ0FBQyxJQUFJLENBQUM7TUFBRTNaLFNBQVMsRUFBRTtRQUFFN1EsSUFBSSxFQUFFLFFBQVE7UUFBRXkzQixNQUFNLEVBQUU7TUFBWSxDQUFDO01BQUUyQyxvQkFBb0IsRUFBRTVQLFNBQVMsQ0FBQyxJQUFJLENBQUM7TUFBRTZQLGdCQUFnQixFQUFFO1FBQUV0QyxLQUFLLEVBQUUsQ0FBQ3ZOLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtVQUFFeHFCLElBQUksRUFBRTtRQUFPLENBQUM7TUFBRSxDQUFDO01BQUVzNkIsa0JBQWtCLEVBQUU7UUFBRXQ2QixJQUFJLEVBQUUsT0FBTztRQUFFMjNCLEtBQUssRUFBRTtVQUFFMzNCLElBQUksRUFBRTtRQUFTLENBQUM7UUFBRTQzQixRQUFRLEVBQUUsQ0FBQztRQUFFRSxXQUFXLEVBQUU7TUFBSyxDQUFDO01BQUV5QyxxQkFBcUIsRUFBRS9QLFNBQVMsQ0FBQyxVQUFVLENBQUM7TUFBRWdRLGVBQWUsRUFBRWhRLFNBQVMsQ0FBQyxVQUFVLENBQUM7TUFBRWlRLE9BQU8sRUFBRTtRQUFFejZCLElBQUksRUFBRSxPQUFPO1FBQUUyM0IsS0FBSyxFQUFFbk4sU0FBUyxDQUFDLGtCQUFrQixDQUFDO1FBQUVvTixRQUFRLEVBQUU7TUFBRTtJQUFFLENBQUM7SUFBRW5pQixRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLHNCQUFzQixFQUFFLGtCQUFrQixFQUFFLG9CQUFvQixFQUFFLHVCQUF1QixFQUFFLGlCQUFpQixFQUFFLFNBQVMsQ0FBQztJQUFFdWlCLG9CQUFvQixFQUFFO0VBQU0sQ0FBQztFQUMvcUJhLElBQUksQ0FBQzZCLGFBQWEsR0FBRztJQUFFMTZCLElBQUksRUFBRSxRQUFRO0lBQUVxRCxVQUFVLEVBQUU7TUFBRU8sU0FBUyxFQUFFNG1CLFNBQVMsQ0FBQyxJQUFJLENBQUM7TUFBRXBFLFVBQVUsRUFBRTtRQUFFcG1CLElBQUksRUFBRSxRQUFRO1FBQUVnM0IsU0FBUyxFQUFFO01BQUUsQ0FBQztNQUFFMkQsVUFBVSxFQUFFO1FBQUUzNkIsSUFBSSxFQUFFLE9BQU87UUFBRTIzQixLQUFLLEVBQUU7VUFBRTMzQixJQUFJLEVBQUUsUUFBUTtVQUFFZzNCLFNBQVMsRUFBRTtRQUFFLENBQUM7UUFBRWEsUUFBUSxFQUFFO01BQUksQ0FBQztNQUFFK0MsV0FBVyxFQUFFO1FBQUU1NkIsSUFBSSxFQUFFLFFBQVE7UUFBRWc0QixvQkFBb0IsRUFBRXhOLFNBQVMsQ0FBQyxJQUFJO01BQUU7SUFBRSxDQUFDO0lBQUUvVSxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxhQUFhLENBQUM7SUFBRXVpQixvQkFBb0IsRUFBRTtFQUFNLENBQUM7RUFDallhLElBQUksQ0FBQ2dDLGtCQUFrQixHQUFHO0lBQUU3NkIsSUFBSSxFQUFFLFFBQVE7SUFBRXFELFVBQVUsRUFBRTtNQUFFdkMsRUFBRSxFQUFFMHBCLFNBQVMsQ0FBQyxJQUFJLENBQUM7TUFBRXNRLGVBQWUsRUFBRTtRQUFFL0MsS0FBSyxFQUFFLENBQUN2TixTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7VUFBRXhxQixJQUFJLEVBQUU7UUFBTyxDQUFDO01BQUUsQ0FBQztNQUFFUCxLQUFLLEVBQUU7UUFBRU8sSUFBSSxFQUFFLFFBQVE7UUFBRWczQixTQUFTLEVBQUU7TUFBRSxDQUFDO01BQUVubUIsU0FBUyxFQUFFO1FBQUU3USxJQUFJLEVBQUUsUUFBUTtRQUFFeTNCLE1BQU0sRUFBRTtNQUFZLENBQUM7TUFBRXpLLE9BQU8sRUFBRXhDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztNQUFFcGhCLFdBQVcsRUFBRTtRQUFFcEosSUFBSSxFQUFFLFFBQVE7UUFBRTAzQixPQUFPLEVBQUU7TUFBaUIsQ0FBQztNQUFFcUQsYUFBYSxFQUFFdlEsU0FBUyxDQUFDLGVBQWU7SUFBRSxDQUFDO0lBQUUvVSxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsYUFBYSxDQUFDO0lBQUV1aUIsb0JBQW9CLEVBQUU7RUFBTSxDQUFDO0VBQzllYSxJQUFJLENBQUNtQyxpQkFBaUIsR0FBRztJQUFFaDdCLElBQUksRUFBRSxRQUFRO0lBQUVxRCxVQUFVLEVBQUU7TUFBRXZDLEVBQUUsRUFBRTBwQixTQUFTLENBQUMsSUFBSSxDQUFDO01BQUVuYSxTQUFTLEVBQUVtYSxTQUFTLENBQUMsSUFBSSxDQUFDO01BQUVsYSxJQUFJLEVBQUU7UUFBRXRRLElBQUksRUFBRSxRQUFRO1FBQUVnM0IsU0FBUyxFQUFFO01BQUUsQ0FBQztNQUFFcm1CLE1BQU0sRUFBRTtRQUFFMm1CLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLFVBQVUsRUFBRSxVQUFVO01BQUUsQ0FBQztNQUFFL2EsWUFBWSxFQUFFaU8sU0FBUyxDQUFDLFVBQVUsQ0FBQztNQUFFNlAsZ0JBQWdCLEVBQUU7UUFBRXRDLEtBQUssRUFBRSxDQUFDdk4sU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO1VBQUV4cUIsSUFBSSxFQUFFO1FBQU8sQ0FBQztNQUFFLENBQUM7TUFBRWk3QixXQUFXLEVBQUV6USxTQUFTLENBQUMsZ0JBQWdCLENBQUM7TUFBRTBRLGVBQWUsRUFBRTtRQUFFbDdCLElBQUksRUFBRSxRQUFRO1FBQUUwM0IsT0FBTyxFQUFFO01BQWlCLENBQUM7TUFBRXlELFFBQVEsRUFBRTtRQUFFbjdCLElBQUksRUFBRSxPQUFPO1FBQUUyM0IsS0FBSyxFQUFFbk4sU0FBUyxDQUFDLG9CQUFvQixDQUFDO1FBQUVvTixRQUFRLEVBQUUsQ0FBQztRQUFFQyxRQUFRLEVBQUU7TUFBSSxDQUFDO01BQUV1RCxhQUFhLEVBQUU1USxTQUFTLENBQUMsSUFBSSxDQUFDO01BQUU2USxhQUFhLEVBQUU7UUFBRXI3QixJQUFJLEVBQUUsT0FBTztRQUFFMjNCLEtBQUssRUFBRW5OLFNBQVMsQ0FBQyx5QkFBeUI7TUFBRSxDQUFDO01BQUU4USxhQUFhLEVBQUU7UUFBRXQ3QixJQUFJLEVBQUUsUUFBUTtRQUFFMDNCLE9BQU8sRUFBRTtNQUFpQixDQUFDO01BQUU3bUIsU0FBUyxFQUFFO1FBQUU3USxJQUFJLEVBQUUsUUFBUTtRQUFFeTNCLE1BQU0sRUFBRTtNQUFZLENBQUM7TUFBRTNtQixTQUFTLEVBQUU7UUFBRTlRLElBQUksRUFBRSxRQUFRO1FBQUV5M0IsTUFBTSxFQUFFO01BQVk7SUFBRSxDQUFDO0lBQUVoaUIsUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxrQkFBa0IsRUFBRSxhQUFhLEVBQUUsaUJBQWlCLEVBQUUsVUFBVSxFQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUM7SUFBRXVpQixvQkFBb0IsRUFBRTtFQUFNLENBQUM7RUFDN2hDLE1BQU11RCxXQUFXLEdBQUcxQyxJQUFJLENBQUMyQyxZQUEwQjtFQUNuREQsV0FBVyxDQUFDRSxLQUFLLEdBQUcsQ0FBQztJQUFFQyxFQUFFLEVBQUU7TUFBRXI0QixVQUFVLEVBQUU7UUFBRXRCLElBQUksRUFBRTtVQUFFL0IsSUFBSSxFQUFFLFFBQVE7VUFBRXFELFVBQVUsRUFBRTtZQUFFVixJQUFJLEVBQUU7Y0FBRXcxQixLQUFLLEVBQUU7WUFBVztVQUFFLENBQUM7VUFBRTFpQixRQUFRLEVBQUUsQ0FBQyxNQUFNO1FBQUU7TUFBRSxDQUFDO01BQUVBLFFBQVEsRUFBRSxDQUFDLE1BQU07SUFBRSxDQUFDO0lBQUV5TSxJQUFJLEVBQUU7TUFBRTdlLFVBQVUsRUFBRTtRQUFFdEIsSUFBSSxFQUFFO1VBQUUvQixJQUFJLEVBQUUsUUFBUTtVQUFFcUQsVUFBVSxFQUFFO1lBQUVpVyxXQUFXLEVBQUU7Y0FBRXFpQixHQUFHLEVBQUU7Z0JBQUUzN0IsSUFBSSxFQUFFO2NBQU87WUFBRSxDQUFDO1lBQUUrSSxLQUFLLEVBQUU7Y0FBRS9JLElBQUksRUFBRSxPQUFPO2NBQUU2M0IsUUFBUSxFQUFFO1lBQUU7VUFBRSxDQUFDO1VBQUVwaUIsUUFBUSxFQUFFLENBQUMsYUFBYTtRQUFFO01BQUUsQ0FBQztNQUFFQSxRQUFRLEVBQUUsQ0FBQyxNQUFNO0lBQUUsQ0FBQztJQUFFME0sSUFBSSxFQUFFO01BQUU5ZSxVQUFVLEVBQUU7UUFBRXRCLElBQUksRUFBRTtVQUFFL0IsSUFBSSxFQUFFLFFBQVE7VUFBRXFELFVBQVUsRUFBRTtZQUFFaVcsV0FBVyxFQUFFO2NBQUV0WixJQUFJLEVBQUU7WUFBTztVQUFFO1FBQUU7TUFBRSxDQUFDO01BQUV5VixRQUFRLEVBQUUsQ0FBQyxNQUFNO0lBQUU7RUFBRSxDQUFDLENBQUM7RUFDeGQsTUFBTXVYLE9BQU8sR0FBRzhKLE9BQU8sQ0FBQ3hoQixHQUFHLENBQUM7SUFBRSxHQUFHaVgsbUJBQW1CO0lBQUVuYixTQUFTLEVBQUVtRSxHQUFHLENBQUNKLEdBQUcsQ0FBQ2tZLFFBQVEsQ0FBQyxDQUFDO0lBQUVoc0IsUUFBUSxFQUFFa1UsR0FBRyxDQUFDSixHQUFHLENBQUNMLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFFdkQsU0FBUyxFQUFFZ0UsR0FBRyxDQUFDSixHQUFHLENBQUNtUixjQUFjLENBQUMsQ0FBQztJQUFFNVUsS0FBSyxFQUFFNkQsR0FBRyxDQUFDSixHQUFHLENBQUNnWCxVQUFVLENBQUM7RUFBRSxDQUFDLENBQUMsQ0FBQztFQUNwTCxNQUFNeVAsaUJBQWlCLEdBQUc1TyxPQUFPLENBQUMzcEIsVUFBd0M7RUFBRXU0QixpQkFBaUIsQ0FBQ3Y2QixRQUFRLEdBQUc7SUFBRXJCLElBQUksRUFBRSxPQUFPO0lBQUUyM0IsS0FBSyxFQUFFbk4sU0FBUyxDQUFDLFFBQVEsQ0FBQztJQUFFcU4sUUFBUSxFQUFFO0VBQVEsQ0FBQztFQUN6S2dCLElBQUksQ0FBQ2dELGNBQWMsR0FBRzdPLE9BQU87RUFDN0I2TCxJQUFJLENBQUNpRCxlQUFlLEdBQUdoRixPQUFPLENBQUN4aEIsR0FBRyxDQUFDO0lBQUV4VSxFQUFFLEVBQUV5VSxHQUFHLENBQUNiLFFBQVEsQ0FBQztJQUFFdkYsWUFBWSxFQUFFb0csR0FBRyxDQUFDbkIsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUFFaEwsV0FBVyxFQUFFbU0sR0FBRyxDQUFDO01BQUV2VixJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUM7SUFBRTZRLFNBQVMsRUFBRTBFLEdBQUcsQ0FBQztNQUFFdlYsSUFBSSxFQUFFO0lBQVcsQ0FBQztFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ25LNjRCLElBQUksQ0FBQ2lELGVBQWUsQ0FBQ3o0QixVQUFVLENBQWdDMnBCLE9BQU8sR0FBR3hDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztFQUFHcU8sSUFBSSxDQUFDaUQsZUFBZSxDQUFDcm1CLFFBQVEsQ0FBYzJMLElBQUksQ0FBQyxTQUFTLENBQUM7RUFDbEt5WCxJQUFJLENBQUNrRCxZQUFZLEdBQUc7SUFBRSxHQUFHL08sT0FBTztJQUFFM3BCLFVBQVUsRUFBRTtNQUFFLEdBQUd1NEIsaUJBQWlCO01BQUVwcUIsU0FBUyxFQUFFO1FBQUV4UixJQUFJLEVBQUUsT0FBTztRQUFFMjNCLEtBQUssRUFBRW5OLFNBQVMsQ0FBQyxpQkFBaUI7TUFBRSxDQUFDO01BQUUrSyxrQkFBa0IsRUFBRTtRQUFFdjFCLElBQUksRUFBRSxPQUFPO1FBQUUyM0IsS0FBSyxFQUFFbk4sU0FBUyxDQUFDLG1CQUFtQixDQUFDO1FBQUVxTixRQUFRLEVBQUU7TUFBSTtJQUFFLENBQUM7SUFBRXBpQixRQUFRLEVBQUUsQ0FBQyxHQUFHdVgsT0FBTyxDQUFDdlgsUUFBb0IsRUFBRSxXQUFXO0VBQUUsQ0FBQztFQUNsU29qQixJQUFJLENBQUNtRCxhQUFhLEdBQUdsRixPQUFPLENBQUN4aEIsR0FBRyxDQUFDO0lBQUV5Z0IsV0FBVyxFQUFFeGdCLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0lBQUVyRSxTQUFTLEVBQUVrRixHQUFHLENBQUNiLFFBQVEsQ0FBQztJQUFFNkgsWUFBWSxFQUFFaEgsR0FBRyxDQUFDO01BQUV2VixJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUM7SUFBRTBRLFFBQVEsRUFBRTZFLEdBQUcsQ0FBQztNQUFFdlYsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDO0lBQUU4TixTQUFTLEVBQUV5SCxHQUFHLENBQUNKLEdBQUcsQ0FBQ1QsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQUU1UyxNQUFNLEVBQUV5VCxHQUFHLENBQUNuQixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUV2RCxTQUFTLEVBQUUwRSxHQUFHLENBQUM7TUFBRXZWLElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQztJQUFFZzJCLHNCQUFzQixFQUFFdGdCLEdBQUcsQ0FBQ2hCLFFBQVEsQ0FBQztJQUFFcVcsS0FBSyxFQUFFclYsR0FBRyxDQUFDSyxNQUFNLENBQUNyQixRQUFRLEVBQUVBLFFBQVEsQ0FBQyxDQUFDO0lBQUV1aEIsWUFBWSxFQUFFdmdCLEdBQUcsQ0FBQ0osR0FBRyxDQUFDO01BQUU0Z0IsZUFBZSxFQUFFM2dCLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO01BQUV5aEIsaUJBQWlCLEVBQUU1Z0IsR0FBRyxDQUFDYixRQUFRLENBQUM7TUFBRTBoQixpQkFBaUIsRUFBRTdnQixHQUFHLENBQUNiLFFBQVE7SUFBRSxDQUFDLENBQUM7RUFBRSxDQUFDLENBQUMsQ0FBQztFQUN2ZHZWLE1BQU0sQ0FBQzg4QixNQUFNLENBQUNwRCxJQUFJLENBQUNtRCxhQUFhLENBQUMzNEIsVUFBVSxFQUFnQztJQUFFeVYsTUFBTSxFQUFFMFIsU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUFFelIsS0FBSyxFQUFFeVIsU0FBUyxDQUFDLGNBQWM7RUFBRSxDQUFDLENBQUM7RUFBR3FPLElBQUksQ0FBQ21ELGFBQWEsQ0FBQ3ZtQixRQUFRLENBQWMyTCxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQztFQUN0TixPQUFPO0lBQUU4YSxPQUFPLEVBQUUsOENBQThDO0lBQUVDLEdBQUcsRUFBRSw4Q0FBOEN2Z0MsY0FBYyxPQUFPO0lBQUV3Z0MsS0FBSyxFQUFFLHdCQUF3QjtJQUFFOTNCLFdBQVcsRUFBRSx3TkFBd047SUFBRSxHQUFHMG9CLE9BQU87SUFBRTNwQixVQUFVLEVBQUU7TUFBRSxHQUFHdTRCLGlCQUFpQjtNQUFFcHFCLFNBQVMsRUFBRTtRQUFFeFIsSUFBSSxFQUFFLE9BQU87UUFBRTIzQixLQUFLLEVBQUVuTixTQUFTLENBQUMsaUJBQWlCO01BQUUsQ0FBQztNQUFFL1ksT0FBTyxFQUFFO1FBQUV6UixJQUFJLEVBQUUsT0FBTztRQUFFMjNCLEtBQUssRUFBRW5OLFNBQVMsQ0FBQyxlQUFlO01BQUUsQ0FBQztNQUFFK0ssa0JBQWtCLEVBQUU7UUFBRXYxQixJQUFJLEVBQUUsT0FBTztRQUFFMjNCLEtBQUssRUFBRW5OLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQztRQUFFcU4sUUFBUSxFQUFFO01BQUk7SUFBRSxDQUFDO0lBQUVwaUIsUUFBUSxFQUFFLENBQUMsR0FBR3VYLE9BQU8sQ0FBQ3ZYLFFBQW9CLEVBQUUsV0FBVyxFQUFFLFNBQVMsQ0FBQztJQUFFNG1CLEtBQUssRUFBRXhEO0VBQUssQ0FBQztBQUN6dkIiLCJpZ25vcmVMaXN0IjpbXX0=