# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: literal-reuse.spec.ts >> original AT-F19 common conversation C: S reference / T independent clone / U dialogue-only override, actual line revision dependency diff+only S update, archive-impact/cold/oldpins/newclone
- Location: harness/literal-reuse.spec.ts:10:1

# Error details

```
Test timeout of 240000ms exceeded.
```

```
Error: locator.click: Test timeout of 240000ms exceeded.
Call log:
  - waiting for getByRole('dialog').getByRole('button', { name: /取消|取り消|キャンセル/ }).last()

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - button "アカウント・専用同期" [ref=e6] [cursor=pointer]
      - generic [ref=e7]: この端末の作品
    - group "任意持出し診断" [ref=e8]:
      - generic "この作業の診断を確認・持出し" [ref=e9]
  - generic [ref=e11]:
    - link "本文へ移動" [ref=e12] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "主要ナビゲーション" [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]: S
        - generic [ref=e16]: シナリオ管理
      - button "原F19 共通会話Cと3方式 作品一覧へ ⌄" [ref=e17] [cursor=pointer]:
        - generic [ref=e19]:
          - strong [ref=e20]: 原F19 共通会話Cと3方式
          - generic [ref=e21]: 作品一覧へ
        - generic [ref=e22]: ⌄
      - generic [ref=e23]: WORKSPACE
      - navigation [ref=e24]:
        - button "年表" [ref=e25] [cursor=pointer]
        - button "構成" [ref=e26] [cursor=pointer]
        - button "資料 0" [ref=e27] [cursor=pointer]:
          - text: 資料
          - generic [ref=e28]: "0"
        - button "検索" [ref=e29] [cursor=pointer]
      - generic [ref=e30]:
        - generic [ref=e31]: QUICK NOTE
        - button "アイデアを残す" [ref=e32] [cursor=pointer]
      - generic [ref=e34]:
        - button "作品・保存" [ref=e35] [cursor=pointer]
        - generic [ref=e38]:
          - strong [ref=e39]: この端末に保存
          - generic [ref=e40]: 同期接続先は未設定
        - button "暗い配色にする" [ref=e41] [cursor=pointer]
    - generic [ref=e42]:
      - banner [ref=e43]:
        - generic [ref=e44]:
          - generic "原F19 共通会話Cと3方式" [ref=e45]
          - generic [ref=e46]: /
          - generic [ref=e47]: 資料
        - status [ref=e48]:
          - generic [ref=e50]: 端末内保存済み
          - generic [ref=e51]: LOCAL
      - main [ref=e52]:
        - generic [ref=e53]:
          - generic [ref=e54]:
            - generic [ref=e55]: STORY ELEMENTS
            - heading "資料" [level=1] [ref=e56]
            - paragraph [ref=e57]: 人物と世界の情報を、ひとつの作品に。
          - button "場面を追加" [ref=e58] [cursor=pointer]
        - generic [ref=e59]:
          - generic [ref=e60]:
            - button "人物 0" [ref=e61] [cursor=pointer]:
              - text: 人物
              - generic [ref=e62]: "0"
            - button "グループ 0" [ref=e63] [cursor=pointer]:
              - text: グループ
              - generic [ref=e64]: "0"
            - button "場所 0" [ref=e65] [cursor=pointer]:
              - text: 場所
              - generic [ref=e66]: "0"
            - button "物品 0" [ref=e67] [cursor=pointer]:
              - text: 物品
              - generic [ref=e68]: "0"
            - button "設定 0" [ref=e69] [cursor=pointer]:
              - text: 設定
              - generic [ref=e70]: "0"
            - button "メモ 0" [ref=e71] [cursor=pointer]:
              - text: メモ
              - generic [ref=e72]: "0"
          - combobox "情報の種類" [ref=e73]:
            - option "人物"
            - option "グループ"
            - option "場所"
            - option "物品"
            - option "設定"
            - option "メモ"
            - option "目標"
            - option "地図"
            - option "移動経路"
            - option "口調"
            - option "用語"
            - option "章"
            - option "場面" [selected]
            - option "台詞"
            - option "出来事"
            - option "分岐図"
            - option "進行ノード"
            - option "進行線"
            - option "クエスト"
            - option "状態変数"
            - option "効果"
            - option "事実・認識"
            - option "伏線"
            - option "手掛かり・回収"
            - option "途中開始点"
            - option "試読記録"
            - option "外部契約"
            - option "制作タスク"
            - option "企画"
            - option "制作判断"
            - option "ゲーム仕様"
            - option "媒体版"
            - option "資料・出所"
            - option "添付素材"
            - option "演出"
            - option "絵コンテ"
            - option "翻訳"
            - option "収録"
            - option "レビュー"
            - option "一覧"
            - option "雛形"
            - option "公開版"
            - option "公開投影"
        - group [ref=e74]:
          - generic "最近開いた情報・お気に入り" [ref=e75] [cursor=pointer]
        - generic [ref=e76]:
          - generic [ref=e77]:
            - generic [ref=e78]:
              - heading "場面" [level=2] [ref=e79]
              - generic [ref=e80]: 4件
            - generic [ref=e81]:
              - button "01 共通会話C 確定 Cの共通説明。 場面" [ref=e82] [cursor=pointer]:
                - generic [ref=e83]: "01"
                - generic [ref=e85]:
                  - generic [ref=e86]:
                    - heading "共通会話C" [level=3] [ref=e87]
                    - generic [ref=e88]: 確定
                  - paragraph [ref=e89]: Cの共通説明。
                  - generic [ref=e90]: 場面
              - button "02 S固定参照 確定 S作者用入力。 場面" [ref=e93] [cursor=pointer]:
                - generic [ref=e94]: "02"
                - generic [ref=e96]:
                  - generic [ref=e97]:
                    - heading "S固定参照" [level=3] [ref=e98]
                    - generic [ref=e99]: 確定
                  - paragraph [ref=e100]: S作者用入力。
                  - generic [ref=e101]: 場面
              - button "03 T独立複製 確定 Cの共通説明。 場面" [ref=e104] [cursor=pointer]:
                - generic [ref=e105]: "03"
                - generic [ref=e107]:
                  - generic [ref=e108]:
                    - heading "T独立複製" [level=3] [ref=e109]
                    - generic [ref=e110]: 確定
                  - paragraph [ref=e111]: Cの共通説明。
                  - generic [ref=e112]: 場面
              - button "04 U台詞だけoverride 確定 U作者用入力。 場面" [ref=e115] [cursor=pointer]:
                - generic [ref=e116]: "04"
                - generic [ref=e118]:
                  - generic [ref=e119]:
                    - heading "U台詞だけoverride" [level=3] [ref=e120]
                    - generic [ref=e121]: 確定
                  - paragraph [ref=e122]: U作者用入力。
                  - generic [ref=e123]: 場面
          - complementary "場面の詳細" [ref=e126]:
            - generic [ref=e127]:
              - generic [ref=e128]:
                - generic [ref=e129]: 場面
                - heading "共通会話C" [level=2] [ref=e130]
              - button "詳細を閉じる" [ref=e131] [cursor=pointer]
            - status [ref=e132]:
              - text: 端末内保存済み
              - generic [ref=e134]: 版 0
            - group [ref=e136]:
              - generic [ref=e137]:
                - generic [ref=e138]: 名前
                - textbox "名前" [ref=e139]:
                  - /placeholder: 場面の名前
                  - text: 共通会話C
              - generic [ref=e140]:
                - generic [ref=e141]:
                  - generic [ref=e142]: 情報の状態
                  - combobox "情報の状態" [ref=e143]:
                    - option "確定" [selected]
                    - option "下書き"
                    - option "確認待ち"
                    - option "不採用"
                    - option "別案"
                - generic [ref=e144]:
                  - generic [ref=e145]: 公開範囲
                  - combobox "公開範囲" [ref=e146]:
                    - option "自分だけ" [selected]
                    - option "作品の編集者"
                    - option "投影プロファイル"
              - generic [ref=e147]:
                - generic [ref=e148] [cursor=pointer]:
                  - checkbox "未参照でも保持する" [ref=e149]
                  - text: 未参照でも保持する
                - generic [ref=e150]: 背景設定など、参照がなくても残す情報を指定できます。確認候補からの除外は保存後に反映します。
              - group [ref=e151]:
                - generic "共通元の固定参照・複製・部分上書き" [ref=e152]
                - option "現在稿を新しい固定版にする" [selected]
                - option "共通会話C旧固定版 · 0"
                - option "共通元の固定版 4 · 4"
                - option "固定版を参照" [selected]
                - option "独立した複製"
                - option "指定項目だけ上書き"
              - tablist "編集内容" [ref=e153]:
                - tab "要約" [selected] [ref=e154] [cursor=pointer]
                - tab "本文" [ref=e155] [cursor=pointer]
                - tab "作者メモ" [ref=e156] [cursor=pointer]
                - tab "詳細" [ref=e157] [cursor=pointer]
                - tab "確認表示" [ref=e158] [cursor=pointer]
              - group [ref=e159]:
                - generic [ref=e160]:
                  - generic [ref=e161]: 要約
                  - generic [ref=e162]:
                    - textbox "要約" [ref=e163]:
                      - /placeholder: あとから詳しく書くこともできます
                    - region "要約のルビとリンク" [ref=e164]:
                      - generic [ref=e165]:
                        - heading "本文のルビ・リンク" [level=3] [ref=e166]
                        - generic [ref=e167]: 段落と語句を選んで追加
                      - paragraph [ref=e168]: 先に本文を入力すると、段落内の語句にルビやリンクを付けられます。
                      - generic [ref=e169]:
                        - strong [ref=e170]: 設定済みの注記
                        - paragraph [ref=e171]: まだありません。
              - group [ref=e172]:
                - generic "› この端末での項目と画面の表示" [ref=e173] [cursor=pointer]
              - generic [ref=e175]:
                - text: 使用する雛形
                - combobox "使用する雛形" [ref=e176]:
                  - option "雛形を適用しない" [selected]
              - group [ref=e177]:
                - generic "› 詳細データ・ルビ・本文リンクを編集" [ref=e178] [cursor=pointer]
              - group [ref=e179]:
                - generic "› カスタム項目を編集" [ref=e180] [cursor=pointer]
              - generic [ref=e181]:
                - heading "この情報への参照" [level=3] [ref=e182]
                - button "本文からの参照位置を表示" [ref=e183] [cursor=pointer]
                - generic [ref=e184]:
                  - button "S固定参照 場面" [ref=e185] [cursor=pointer]:
                    - text: S固定参照
                    - generic [ref=e186]: 場面
                  - button "T独立複製 場面" [ref=e187] [cursor=pointer]:
                    - text: T独立複製
                    - generic [ref=e188]: 場面
                  - button "U台詞だけoverride 場面" [ref=e189] [cursor=pointer]:
                    - text: U台詞だけoverride
                    - generic [ref=e190]: 場面
                  - 'button "変更確認: 共通会話C レビュー" [ref=e191] [cursor=pointer]':
                    - text: "変更確認: 共通会話C"
                    - generic [ref=e192]: レビュー
              - group [ref=e193]:
                - generic "› IDと履歴情報" [ref=e194] [cursor=pointer]
            - generic [ref=e195]:
              - button "アーカイブ" [ref=e196] [cursor=pointer]
              - button "保存する" [ref=e197] [cursor=pointer]
            - dialog [ref=e198]:
              - generic [ref=e199]:
                - heading "アーカイブの確認" [level=2] [ref=e200]
                - button "閉じる" [active] [ref=e201] [cursor=pointer]
              - generic [ref=e202]:
                - paragraph [ref=e203]: 「共通会話C」を通常の一覧から外します。履歴に保存され、作品画面から復元できます。
                - paragraph [ref=e204]: 参照と固定版への影響 6件。参照先の情報は個別に確認できます。
                - alert [ref=e205]: 現在の情報からの参照が4件あります。参照元を修正してからアーカイブしてください。
                - list [ref=e206]:
                  - listitem [ref=e207]:
                    - strong [ref=e208]: S固定参照
                    - generic [ref=e209]: "参照元の項目: data.reuse.sourceId"
                    - button "参照元を開く" [ref=e210] [cursor=pointer]
                  - listitem [ref=e211]:
                    - strong [ref=e212]: T独立複製
                    - generic [ref=e213]: "参照元の項目: data.reuse.sourceId"
                    - button "参照元を開く" [ref=e214] [cursor=pointer]
                  - listitem [ref=e215]:
                    - strong [ref=e216]: U台詞だけoverride
                    - generic [ref=e217]: "参照元の項目: data.reuse.sourceId"
                    - button "参照元を開く" [ref=e218] [cursor=pointer]
                  - listitem [ref=e219]:
                    - strong [ref=e220]: "変更確認: 共通会話C"
                    - generic [ref=e221]: "参照元の項目: 確認対象"
                    - button "参照元を開く" [ref=e222] [cursor=pointer]
                  - listitem [ref=e223]:
                    - strong [ref=e224]: 共通会話C旧固定版
                    - generic [ref=e225]: 固定版は保持します。保存された本文・参照先は変更しません。
                    - generic [ref=e226]: 固定版 8c145727-e7cb-4a17-a099-5fff8789df24
                  - listitem [ref=e227]:
                    - strong [ref=e228]: 共通元の固定版 4
                    - generic [ref=e229]: 固定版は保持します。保存された本文・参照先は変更しません。
                    - generic [ref=e230]: 固定版 bcf5cd52-3084-49ab-a44f-08e12cb067cb
                - generic [ref=e231]:
                  - button "中止" [ref=e232] [cursor=pointer]
                  - button "アーカイブする" [disabled] [ref=e233]
      - contentinfo [ref=e234]:
        - generic [ref=e235]: 端末内の作品 · 版 5
        - generic [ref=e236]: 21件の情報 · 0件の関係
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {createEntity,createProject,textToRichText} from '../candidate/src/domain/model';
  3  | import {createWorldSnapshot} from '../candidate/src/domain/world';
  4  | import type {Entity,EntityDataMap,EntityKind,ProjectData} from '../candidate/src/domain/types';
  5  | import {seed,backup,durable,injectQuota,evidence,digest,nav} from './common';
  6  | import {openRecord,reader,begin,editData,saveEditor,freshRoundtrip} from './extended-support';
  7  | function add<K extends EntityKind>(p:ProjectData,kind:K,name:string,data:Partial<EntityDataMap[K]>={}):Entity<K>{const e=createEntity(p.projectId,kind,name,data);e.status='confirmed';p.entities.push(e);return e;}
  8  | async function reuseEditor(page:Page,name:string){await openRecord(page,'scene',name);const panel=page.locator('details.settings-card').filter({has:page.locator('summary').filter({hasText:'共通元の固定参照・複製・部分上書き'})});await panel.locator('summary').click();return panel;}
  9  | 
  10 | test('original AT-F19 common conversation C: S reference / T independent clone / U dialogue-only override, actual line revision dependency diff+only S update, archive-impact/cold/oldpins/newclone',async({page,browser},info)=>{
  11 |  test.setTimeout(240000);let p=createProject('原F19 共通会話Cと3方式');
  12 |  const cLine=add(p,'dialogue_line','共通元Cの台詞',{text:textToRichText('C旧版の共通会話😀。')}),uLine=add(p,'dialogue_line','Uだけの上書き台詞',{text:textToRichText('U固有の台詞は自分で決める。')}),c=add(p,'scene','共通会話C',{body:textToRichText('Cの共通説明。'),dialogueLineIds:[cLine.id]}),s=add(p,'scene','S固定参照',{body:textToRichText('S作者用入力。')}),t=add(p,'scene','T独立複製',{body:textToRichText('T作者用入力。')}),u=add(p,'scene','U台詞だけoverride',{body:textToRichText('U作者用入力。'),dialogueLineIds:[uLine.id]});
  13 |  const end=add(p,'flow_node','再利用の終端',{nodeType:'terminal',terminalReason:'共通元の適用版を確認した'}),entries=[s,t,u].map(owner=>add(p,'flow_node',owner.name+'の入口',{nodeType:'entry',sceneId:owner.id})),edges=entries.map(entry=>add(p,'flow_edge',entry.name+'から終了',{fromId:entry.id,toId:end.id,label:entry.name+'から終了'}));add(p,'flow_graph','3使用先の図',{nodeIds:[...entries.map(e=>e.id),end.id],edgeIds:edges.map(e=>e.id),entryIds:entries.map(e=>e.id),exitIds:[end.id]});p=await createWorldSnapshot(p,'共通会話C旧固定版');const oldPin=p.snapshots.at(-1)!,input=await seed(page,p);
  14 |  for(const [owner,mode] of [[s,'reference'],[t,'clone'],[u,'override']] as const){const panel=await reuseEditor(page,owner.name);await panel.getByLabel('共通元の版',{exact:true}).selectOption(oldPin.id);await panel.getByRole('radio',{name:c.name,exact:true}).check();await panel.getByLabel('再利用方式',{exact:true}).selectOption(mode);if(mode==='override')await panel.getByRole('group',{name:'使用先の入力で上書きする項目',exact:true}).getByRole('checkbox',{name:/台詞|dialogueLineIds/}).check();await panel.getByRole('button',{name:'共通元の更新差分と影響を確認',exact:true}).click();await panel.getByRole('button',{name:'確認した再利用を保存',exact:true}).click();await expect(panel).toContainText('固定版と再利用を端末内に保存しました。');}
  15 |  const configured=await backup(page),configuredProject=configured.parsed.project;
  16 |  const storedS=configuredProject.entities.find((e):e is Entity<'scene'>=>e.id===s.id&&e.kind==='scene')!,storedT=configuredProject.entities.find((e):e is Entity<'scene'>=>e.id===t.id&&e.kind==='scene')!,storedU=configuredProject.entities.find((e):e is Entity<'scene'>=>e.id===u.id&&e.kind==='scene')!;
  17 |  expect(storedS.data.reuse).toMatchObject({mode:'reference',sourceId:c.id,pinnedSnapshotId:oldPin.id});expect(storedT.data.reuse).toMatchObject({mode:'clone',sourceId:c.id,pinnedSnapshotId:oldPin.id});expect(storedU.data.reuse).toMatchObject({mode:'override',sourceId:c.id,pinnedSnapshotId:oldPin.id,overrideFields:['dialogueLineIds']});expect(storedS.data.body).toEqual(s.data.body);expect(storedT.data.dialogueLineIds).toHaveLength(1);expect(storedT.data.dialogueLineIds).not.toContain(cLine.id);expect(storedU.data.dialogueLineIds).toEqual([uLine.id]);
  18 |  await nav(page,/^検索/);await page.getByRole('tab',{name:'五十音・分類索引',exact:true}).click();await page.getByLabel('作品内を検索',{exact:true}).fill(cLine.name);const originalIndex=page.locator('.search-page button.reference-link').filter({hasText:cLine.id.slice(0,8)});await expect(originalIndex).toHaveCount(1);await originalIndex.click();const indexModal=page.getByRole('dialog',{name:'索引の項目を編集',exact:true});await indexModal.getByRole('button',{name:'通常フォームの名前欄を開く',exact:true}).click();await indexModal.getByRole('button',{name:'索引編集を閉じる',exact:true}).click();await expect(page.locator('#entity-name')).toHaveValue(cLine.name);await editData(page,data=>{data.text=textToRichText('C改訂後の共通会話😀。');});await saveEditor(page);
  19 |  for(let i=0;i<entries.length;i++){await reader(page);await begin(page,entries[i].id);await expect(page.locator('.reader-sheet')).toContainText(i===2?'U固有の台詞は自分で決める。':'C旧版の共通会話😀。');await expect(page.locator('.reader-sheet')).not.toContainText('C改訂後の共通会話😀。');}
  20 |  const beforeUpdate=await backup(page),beforeUpdateProject=beforeUpdate.parsed.project,unchangedT=structuredClone(beforeUpdateProject.entities.find(e=>e.id===t.id)),unchangedU=structuredClone(beforeUpdateProject.entities.find(e=>e.id===u.id));
  21 |  const panel=await reuseEditor(page,s.name);await panel.getByLabel('共通元の版',{exact:true}).selectOption('');await panel.getByRole('button',{name:'共通元の更新差分と影響を確認',exact:true}).click();await expect(panel).toContainText('依存情報の変更 1件');await panel.locator('summary').filter({hasText:cLine.name+'の依存差分'}).click();await expect(panel).toContainText('C旧版の共通会話😀。');await expect(panel).toContainText('C改訂後の共通会話😀。');await expect(panel).toContainText('再利用先 3件');await expect(panel).toContainText('選択中の使用先だけを更新');const preview=await panel.innerText(),nativeBefore=await durable(page);
  22 |  await panel.getByRole('button',{name:'差分確認を取り消す',exact:true}).click();expect(await durable(page)).toEqual(nativeBefore);await panel.getByRole('button',{name:'共通元の更新差分と影響を確認',exact:true}).click();await injectQuota(page);await panel.getByRole('button',{name:'確認した再利用を保存',exact:true}).click();await expect(panel.getByRole('alert')).toContainText('容量');expect(await durable(page)).toEqual(nativeBefore);await expect(panel.getByLabel('再利用方式',{exact:true})).toHaveValue('reference');await panel.getByRole('button',{name:'確認した再利用を保存',exact:true}).click();await expect(panel).toContainText('固定版と再利用を端末内に保存しました。');
  23 |  const updated=await backup(page),updatedS=updated.parsed.project.entities.find((e):e is Entity<'scene'>=>e.id===s.id&&e.kind==='scene')!;expect(updatedS.data.reuse!.pinnedSnapshotId).not.toBe(oldPin.id);expect(updated.parsed.project.entities.find(e=>e.id===t.id)).toEqual(unchangedT);expect(updated.parsed.project.entities.find(e=>e.id===u.id)).toEqual(unchangedU);expect(updated.parsed.project.snapshots.find(s=>s.id===oldPin.id)).toEqual(oldPin);
  24 |  for(let i=0;i<entries.length;i++){await reader(page);await begin(page,entries[i].id);await expect(page.locator('.reader-sheet')).toContainText(i===0?'C改訂後の共通会話😀。':i===1?'C旧版の共通会話😀。':'U固有の台詞は自分で決める。');}
> 25 |  await openRecord(page,'scene',c.name);const beforeArchive=await durable(page);await page.locator('.editor-footer').getByRole('button',{name:'アーカイブ',exact:true}).click();const archive=page.getByRole('dialog');for(const owner of [s,t,u])await expect(archive).toContainText(owner.name);const archiveImpact=await archive.innerText();await archive.getByRole('button',{name:/取消|取り消|キャンセル/}).last().click();expect(await durable(page)).toEqual(beforeArchive);
     |                                                                                                                                                                                                                                                                                                                                                                                                          ^ Error: locator.click: Test timeout of 240000ms exceeded.
  26 |  await page.reload();const cold=await backup(page),fresh=await freshRoundtrip(browser,cold.bytes),clone=await freshRoundtrip(browser,cold.bytes,'clone');expect(cold.parsed.project.snapshots.find(s=>s.id===oldPin.id)).toEqual(oldPin);expect(fresh.parsed.project).toEqual(cold.parsed.project);expect(clone.parsed.project.entities.filter(e=>e.kind==='scene'&&e.data.reuse).map(e=>e.kind==='scene'?e.data.reuse!.mode:null).sort()).toEqual(['clone','override','reference']);
  27 |  await evidence(info,'F19-original-reuse',{originalAcceptance:'AT-F19',fixtureSHA256:digest(input),given:{commonConversation:c.id,reference:s.id,independentClone:t.id,dialogueOnlyOverride:u.id},when:{normalAllThreeModesSaved:true,actualCommonLineEdit:cLine.id,dependencyBeforeAfterShown:true,appliedOnlyS:true},then:{SExplicitNewEdition:true,TAndUUnchanged:true,referenceAuthorBodyNotBorrowedCopy:true},negative:{cloneNewLineIDs:storedT.data.dialogueLineIds,dialogueOnlyOverride:['dialogueLineIds'],allThreeUsersInDeletionImpact:true,cancelNativeUnchanged:true,quotaNativeUnchanged:true,inputRetainedAndRetry:true,oldPinUnchanged:true},preview,archiveImpact,oldPinHash:oldPin.contentHash,newPin:updatedS.data.reuse!.pinnedSnapshotId,coldNewClone:true,physical:'not_run',wholeCasePassInferred:false});
  28 | });
  29 | 
```