// 76563096739494402b35839c54caed8efb1198dc
import { test, expect } from '@playwright/test';
import { originalStateWork } from './literal-runtime-fixtures';
import { seed, backup, durable, evidence, digest } from './common';
import { reader, begin, recordTrial, openRecord, editData, saveEditor, freshRoundtrip } from './extended-support';
test('original AT-F38/F41 scope lifecycle and prohibited quest transition: original reset/cycle and atomic money/item batch, finite exception, cold/newclone', async ({
  page,
  browser
}, info) => {
  var _cold$parsed$project$, _cold$parsed$project$2;
  test.setTimeout(240000);
  const f = originalStateWork();
  const input = await seed(page, f.p);
  await openRecord(page, 'variable', f.alive.name);
  await expect(page.getByRole('region', {
    name: '同義語・反対語の状態候補',
    exact: true
  })).toContainText('存命／死亡');
  const savedBeforeWrongType = await durable(page);
  await editData(page, data => {
    data.initial = {
      type: 'integer',
      value: 1
    };
  });
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  await page.locator('.editor-footer').getByRole('button', {
    name: /^(保存する|保存を再試行)$/
  }).click();
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  expect(await durable(page)).toEqual(savedBeforeWrongType);
  await editData(page, data => {
    data.initial = {
      type: 'enum',
      value: '未定義の値'
    };
  });
  await page.locator('.editor-footer').getByRole('button', {
    name: /^(保存する|保存を再試行)$/
  }).click();
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/許容|候補|値/);
  expect(await durable(page)).toEqual(savedBeforeWrongType);
  await editData(page, data => {
    data.initial = {
      type: 'enum',
      value: '存命'
    };
  });
  await saveEditor(page);
  await openRecord(page, 'effect', f.derivedWrite.name);
  const derivedBefore = await durable(page);
  await editData(page, data => {
    data.targetId = f.derived.id;
    data.value = {
      type: 'boolean',
      value: true
    };
  });
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('算出状態へ直接代入できません');
  expect(await durable(page)).toEqual(derivedBefore);
  await editData(page, data => {
    data.targetId = f.memory.id;
    data.value = {
      type: 'boolean',
      value: false
    };
  });
  await saveEditor(page);
  await openRecord(page, 'variable', f.derived.name);
  const cycleBefore = await durable(page);
  await editData(page, data => {
    data.derived = {
      op: 'variable',
      variableId: f.derived.id
    };
  });
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/循環/);
  expect(await durable(page)).toEqual(cycleBefore);
  await editData(page, data => {
    data.derived = {
      op: 'compare',
      variableId: f.affinity.id,
      comparator: 'ge',
      value: {
        type: 'integer',
        value: 5
      }
    };
  });
  await saveEditor(page);
  await reader(page);
  await begin(page, f.entry.id);
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.unsettled.name
  })).toContainText(/未定|未設定|不明/);
  await expect(page.locator('summary').filter({
    hasText: new RegExp('^' + f.memory.name + ' · across_runs ·')
  })).toBeVisible();
  await expect(page.locator('summary').filter({
    hasText: new RegExp('^' + f.money.name + ' · run ·')
  })).toBeVisible();
  const uses = page.locator('details').filter({
    has: page.locator('summary').filter({
      hasText: new RegExp('^' + f.affinity.name + ' · run ·')
    })
  });
  await uses.locator('summary').first().click();
  await expect(uses).toContainText('read');
  await expect(uses).toContainText('update');
  await expect(uses).toContainText('reset');
  await uses.getByRole('button', {
    name: f.setAffinity.name,
    exact: true
  }).click();
  await expect(page.locator('.detail-heading')).toContainText(f.setAffinity.name);
  await reader(page);
  await page.locator('.reader-choices').getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  for (const [name, value] of [[f.affinity.name, '5'], [f.money.name, '11'], [f.memory.name, 'true'], [f.derived.name, 'true']]) await expect(page.locator('.runtime-variable').filter({
    has: page.getByText(name, {
      exact: true
    })
  })).toContainText(value);
  const beforeBatch = await durable(page);
  await page.locator('.reader-choices').getByRole('button', {
    name: f.invalid.data.label,
    exact: true
  }).click();
  await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移/);
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.money.name
  })).toContainText('11');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.questState.name
  })).toContainText('完了');
  expect(await durable(page)).toEqual(beforeBatch);
  // The whole-batch rejection cannot be repaired by an ordinary reason field.
  await begin(page, f.entry.id);
  await page.locator('.reader-choices').getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  await page.locator('.reader-choices').getByRole('button', {
    name: f.finish.data.label,
    exact: true
  }).click();
  await recordTrial(page);
  const one = await backup(page),
    trace1 = one.parsed.project.entities.find(e => e.kind === 'trace');
  expect(trace1.data.steps.at(-1).after.variableValues[f.affinity.id]).toEqual({
    type: 'integer',
    value: 5
  });
  expect(trace1.data.steps.at(-1).after.variableValues[f.money.id]).toEqual({
    type: 'integer',
    value: 11
  });
  await reader(page);
  await page.getByRole('button', {
    name: '次の周回',
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.money.name
  })).toContainText('10');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.memory.name
  })).toContainText('true');
  await page.getByRole('button', {
    name: 'すべて初期化',
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.memory.name
  })).toContainText('false');
  await begin(page, f.entry.id);
  await page.locator('.reader-choices').getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  await page.locator('.reader-choices').getByRole('button', {
    name: f.resetPath.data.label,
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.questState.name
  })).toContainText('未受注');
  await expect(page.locator('.runtime-variable').filter({
    has: page.getByText(f.affinity.name, {
      exact: true
    })
  })).toContainText('0');
  await recordTrial(page);
  const resetArchive = await backup(page),
    resetTrace = resetArchive.parsed.project.entities.filter(e => e.kind === 'trace').at(-1);
  expect(resetTrace.data.steps.at(-1).before.variableValues[f.questState.id]).toEqual({
    type: 'enum',
    value: '完了'
  });
  expect(resetTrace.data.steps.at(-1).after.variableValues[f.questState.id]).toEqual({
    type: 'enum',
    value: '未受注'
  });
  expect(resetTrace.data.steps.at(-1).edgeIds).toEqual([f.resetPath.id]);
  await openRecord(page, 'effect', f.prohibited.name);
  await editData(page, data => {
    data.exceptionDetails = {
      reason: 'この経路のtick0–10に限り確認済み根拠に従って再受注する',
      targetScope: {
        projectId: f.p.projectId,
        graphId: f.graph.id,
        routeCondition: {
          op: 'constant',
          value: true
        }
      },
      validity: {
        worldRange: {
          start: '0',
          end: '10'
        },
        routeCondition: {
          op: 'constant',
          value: true
        },
        presentationAnchor: null
      },
      evidenceIds: [f.exceptionEvidence.id]
    };
  });
  await saveEditor(page);
  await reader(page);
  await page.getByLabel('試読開始時点の世界内tick', {
    exact: true
  }).fill('5');
  await begin(page, f.entry.id);
  await page.locator('.reader-choices').getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  await page.locator('.reader-choices').getByRole('button', {
    name: f.invalid.data.label,
    exact: true
  }).click();
  await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.questState.name
  })).toContainText('未受注');
  await recordTrial(page);
  const acceptedException = await backup(page),
    exceptionTrace = acceptedException.parsed.project.entities.filter(e => e.kind === 'trace').at(-1);
  expect(exceptionTrace.data.steps.at(-1).after.itemInstances.some(i => i.instanceId === f.key.id && i.quantity === 1)).toBe(true);
  await reader(page);
  for (const tick of ['11', '']) {
    await page.getByLabel('試読開始時点の世界内tick', {
      exact: true
    }).fill(tick);
    await begin(page, f.entry.id);
    await page.locator('.reader-choices').getByRole('button', {
      name: f.get.data.label,
      exact: true
    }).click();
    const rejectedNative = await durable(page);
    await page.locator('.reader-choices').getByRole('button', {
      name: f.invalid.data.label,
      exact: true
    }).click();
    await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移|期限|時点|例外/);
    await expect(page.locator('.runtime-variable').filter({
      hasText: f.money.name
    })).toContainText('11');
    await expect(page.locator('.runtime-variable').filter({
      hasText: f.questState.name
    })).toContainText('完了');
    expect(await durable(page)).toEqual(rejectedNative);
  }
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page);
  expect((_cold$parsed$project$ = cold.parsed.project.entities.find(e => e.id === f.unused.id)) === null || _cold$parsed$project$ === void 0 ? void 0 : _cold$parsed$project$.deletedAt).toBeFalsy();
  expect((_cold$parsed$project$2 = cold.parsed.project.entities.find(e => e.id === f.unsettled.id)) === null || _cold$parsed$project$2 === void 0 ? void 0 : _cold$parsed$project$2.data).toMatchObject({
    initial: {
      type: 'unknown',
      value: null
    }
  });
  const restored = await freshRoundtrip(browser, cold.bytes),
    clone = await freshRoundtrip(browser, cold.bytes, 'clone');
  expect(restored.parsed.project).toEqual(cold.parsed.project);
  expect(clone.parsed.project.entities.filter(e => e.kind === 'trace')).toHaveLength(3);
  await evidence(info, 'F38-F41-original-lifecycle-and-atomic-transition', {
    fixtureSHA256: digest(input),
    sourceValues: {
      enum: ['存命', '死亡'],
      affinityInitial: 0,
      runMoney: 10,
      unknownBoolean: true,
      acrossRunMemory: true,
      derivedFrom: f.affinity.id
    },
    rejectedWrongTypeAndOutsideAllowed: true,
    derivedDirectWriteRejected: true,
    derivedCycleRejected: true,
    prohibitedQuestTransition: {
      from: '完了',
      to: '未受注',
      reason: '備考だけ',
      wholeMoneyAndItemBatchRejected: true
    },
    explicitResetTrace: resetTrace.data,
    exceptionTrace: exceptionTrace.data,
    exceptionInsideTick5Accepted: true,
    expiredTick11AndUnknownTickWholeBatchRefused: true,
    ordinaryUnchangedYExternalRetention: true,
    coldAndNewAndClone: true,
    archiveSHA256: digest(cold.bytes),
    fullCasesClaimed: []
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0Iiwib3JpZ2luYWxTdGF0ZVdvcmsiLCJzZWVkIiwiYmFja3VwIiwiZHVyYWJsZSIsImV2aWRlbmNlIiwiZGlnZXN0IiwicmVhZGVyIiwiYmVnaW4iLCJyZWNvcmRUcmlhbCIsIm9wZW5SZWNvcmQiLCJlZGl0RGF0YSIsInNhdmVFZGl0b3IiLCJmcmVzaFJvdW5kdHJpcCIsInBhZ2UiLCJicm93c2VyIiwiaW5mbyIsIl9jb2xkJHBhcnNlZCRwcm9qZWN0JCIsIl9jb2xkJHBhcnNlZCRwcm9qZWN0JDIiLCJzZXRUaW1lb3V0IiwiZiIsImlucHV0IiwicCIsImFsaXZlIiwibmFtZSIsImdldEJ5Um9sZSIsImV4YWN0IiwidG9Db250YWluVGV4dCIsInNhdmVkQmVmb3JlV3JvbmdUeXBlIiwiZGF0YSIsImluaXRpYWwiLCJ0eXBlIiwidmFsdWUiLCJsb2NhdG9yIiwiY2xpY2siLCJ0b0VxdWFsIiwiZGVyaXZlZFdyaXRlIiwiZGVyaXZlZEJlZm9yZSIsInRhcmdldElkIiwiZGVyaXZlZCIsImlkIiwibWVtb3J5IiwiY3ljbGVCZWZvcmUiLCJvcCIsInZhcmlhYmxlSWQiLCJhZmZpbml0eSIsImNvbXBhcmF0b3IiLCJlbnRyeSIsImZpbHRlciIsImhhc1RleHQiLCJ1bnNldHRsZWQiLCJSZWdFeHAiLCJ0b0JlVmlzaWJsZSIsIm1vbmV5IiwidXNlcyIsImhhcyIsImZpcnN0Iiwic2V0QWZmaW5pdHkiLCJnZXQiLCJsYWJlbCIsImdldEJ5VGV4dCIsImJlZm9yZUJhdGNoIiwiaW52YWxpZCIsInF1ZXN0U3RhdGUiLCJmaW5pc2giLCJvbmUiLCJ0cmFjZTEiLCJwYXJzZWQiLCJwcm9qZWN0IiwiZW50aXRpZXMiLCJmaW5kIiwiZSIsImtpbmQiLCJzdGVwcyIsImF0IiwiYWZ0ZXIiLCJ2YXJpYWJsZVZhbHVlcyIsInJlc2V0UGF0aCIsInJlc2V0QXJjaGl2ZSIsInJlc2V0VHJhY2UiLCJiZWZvcmUiLCJlZGdlSWRzIiwicHJvaGliaXRlZCIsImV4Y2VwdGlvbkRldGFpbHMiLCJyZWFzb24iLCJ0YXJnZXRTY29wZSIsInByb2plY3RJZCIsImdyYXBoSWQiLCJncmFwaCIsInJvdXRlQ29uZGl0aW9uIiwidmFsaWRpdHkiLCJ3b3JsZFJhbmdlIiwic3RhcnQiLCJlbmQiLCJwcmVzZW50YXRpb25BbmNob3IiLCJldmlkZW5jZUlkcyIsImV4Y2VwdGlvbkV2aWRlbmNlIiwiZ2V0QnlMYWJlbCIsImZpbGwiLCJhY2NlcHRlZEV4Y2VwdGlvbiIsImV4Y2VwdGlvblRyYWNlIiwiaXRlbUluc3RhbmNlcyIsInNvbWUiLCJpIiwiaW5zdGFuY2VJZCIsImtleSIsInF1YW50aXR5IiwidG9CZSIsInRpY2siLCJyZWplY3RlZE5hdGl2ZSIsInJlbG9hZCIsImNvbGQiLCJ1bnVzZWQiLCJkZWxldGVkQXQiLCJ0b0JlRmFsc3kiLCJ0b01hdGNoT2JqZWN0IiwicmVzdG9yZWQiLCJieXRlcyIsImNsb25lIiwidG9IYXZlTGVuZ3RoIiwiZml4dHVyZVNIQTI1NiIsInNvdXJjZVZhbHVlcyIsImVudW0iLCJhZmZpbml0eUluaXRpYWwiLCJydW5Nb25leSIsInVua25vd25Cb29sZWFuIiwiYWNyb3NzUnVuTWVtb3J5IiwiZGVyaXZlZEZyb20iLCJyZWplY3RlZFdyb25nVHlwZUFuZE91dHNpZGVBbGxvd2VkIiwiZGVyaXZlZERpcmVjdFdyaXRlUmVqZWN0ZWQiLCJkZXJpdmVkQ3ljbGVSZWplY3RlZCIsInByb2hpYml0ZWRRdWVzdFRyYW5zaXRpb24iLCJmcm9tIiwidG8iLCJ3aG9sZU1vbmV5QW5kSXRlbUJhdGNoUmVqZWN0ZWQiLCJleHBsaWNpdFJlc2V0VHJhY2UiLCJleGNlcHRpb25JbnNpZGVUaWNrNUFjY2VwdGVkIiwiZXhwaXJlZFRpY2sxMUFuZFVua25vd25UaWNrV2hvbGVCYXRjaFJlZnVzZWQiLCJvcmRpbmFyeVVuY2hhbmdlZFlFeHRlcm5hbFJldGVudGlvbiIsImNvbGRBbmROZXdBbmRDbG9uZSIsImFyY2hpdmVTSEEyNTYiLCJmdWxsQ2FzZXNDbGFpbWVkIl0sInNvdXJjZXMiOlsibGl0ZXJhbC1zdGF0ZS1saWZlY3ljbGUuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3Rlc3QsZXhwZWN0fSBmcm9tICdAcGxheXdyaWdodC90ZXN0JztcbmltcG9ydCB0eXBlIHtFbnRpdHl9IGZyb20gJy4uL2NhbmRpZGF0ZS9zcmMvZG9tYWluL3R5cGVzJztcbmltcG9ydCB7b3JpZ2luYWxTdGF0ZVdvcmssb3JpZ2luYWxDb3ZlcmFnZVdvcmssb3JpZ2luYWxDaGVja3BvaW50V29ya30gZnJvbSAnLi9saXRlcmFsLXJ1bnRpbWUtZml4dHVyZXMnO1xuaW1wb3J0IHtuYXYsc2VlZCxiYWNrdXAsZHVyYWJsZSxldmlkZW5jZSxkaWdlc3R9IGZyb20gJy4vY29tbW9uJztcbmltcG9ydCB7cmVhZGVyLGJlZ2luLHJlY29yZFRyaWFsLG9wZW5SZWNvcmQsZWRpdERhdGEsc2F2ZUVkaXRvcixmcmVzaFJvdW5kdHJpcH0gZnJvbSAnLi9leHRlbmRlZC1zdXBwb3J0JztcblxudGVzdCgnb3JpZ2luYWwgQVQtRjM4L0Y0MSBzY29wZSBsaWZlY3ljbGUgYW5kIHByb2hpYml0ZWQgcXVlc3QgdHJhbnNpdGlvbjogb3JpZ2luYWwgcmVzZXQvY3ljbGUgYW5kIGF0b21pYyBtb25leS9pdGVtIGJhdGNoLCBmaW5pdGUgZXhjZXB0aW9uLCBjb2xkL25ld2Nsb25lJyxhc3luYyh7cGFnZSxicm93c2VyfSxpbmZvKT0+e1xuICB0ZXN0LnNldFRpbWVvdXQoMjQwMDAwKTtcbiAgY29uc3QgZj1vcmlnaW5hbFN0YXRlV29yaygpO2NvbnN0IGlucHV0PWF3YWl0IHNlZWQocGFnZSxmLnApO1xuICBhd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ3ZhcmlhYmxlJyxmLmFsaXZlLm5hbWUpO1xuICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ3JlZ2lvbicse25hbWU6J+WQjOe+qeiqnuODu+WPjeWvvuiqnuOBrueKtuaFi+WAmeijnCcsZXhhY3Q6dHJ1ZX0pKS50b0NvbnRhaW5UZXh0KCflrZjlkb3vvI/mrbvkuqEnKTtcbiAgY29uc3Qgc2F2ZWRCZWZvcmVXcm9uZ1R5cGU9YXdhaXQgZHVyYWJsZShwYWdlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5pbml0aWFsPXt0eXBlOidpbnRlZ2VyJyx2YWx1ZToxfTt9KTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmRldGFpbC1wYW5lbCcpLmdldEJ5Um9sZSgnYWxlcnQnKSkudG9Db250YWluVGV4dCgv5Z6LfOWIneacny8pO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJy5lZGl0b3ItZm9vdGVyJykuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOi9eKOS/neWtmOOBmeOCi3zkv53lrZjjgpLlho3oqabooYwpJC99KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuZGV0YWlsLXBhbmVsJykuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0NvbnRhaW5UZXh0KC/lnot85Yid5pyfLyk7XG4gIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKHNhdmVkQmVmb3JlV3JvbmdUeXBlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5pbml0aWFsPXt0eXBlOidlbnVtJyx2YWx1ZTon5pyq5a6a576p44Gu5YCkJ307fSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignLmVkaXRvci1mb290ZXInKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6L14o5L+d5a2Y44GZ44KLfOS/neWtmOOCkuWGjeippuihjCkkL30pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtcGFuZWwnKS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoL+ioseWuuXzlgJnoo5x85YCkLyk7XG4gIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKHNhdmVkQmVmb3JlV3JvbmdUeXBlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5pbml0aWFsPXt0eXBlOidlbnVtJyx2YWx1ZTon5a2Y5ZG9J307fSk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiAgYXdhaXQgb3BlblJlY29yZChwYWdlLCdlZmZlY3QnLGYuZGVyaXZlZFdyaXRlLm5hbWUpO2NvbnN0IGRlcml2ZWRCZWZvcmU9YXdhaXQgZHVyYWJsZShwYWdlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS50YXJnZXRJZD1mLmRlcml2ZWQuaWQ7ZGF0YS52YWx1ZT17dHlwZTonYm9vbGVhbicsdmFsdWU6dHJ1ZX07fSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtcGFuZWwnKS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ+eul+WHuueKtuaFi+OBuOebtOaOpeS7o+WFpeOBp+OBjeOBvuOBm+OCkycpO1xuICBleHBlY3QoYXdhaXQgZHVyYWJsZShwYWdlKSkudG9FcXVhbChkZXJpdmVkQmVmb3JlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS50YXJnZXRJZD1mLm1lbW9yeS5pZDtkYXRhLnZhbHVlPXt0eXBlOidib29sZWFuJyx2YWx1ZTpmYWxzZX07fSk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiAgYXdhaXQgb3BlblJlY29yZChwYWdlLCd2YXJpYWJsZScsZi5kZXJpdmVkLm5hbWUpO2NvbnN0IGN5Y2xlQmVmb3JlPWF3YWl0IGR1cmFibGUocGFnZSk7XG4gIGF3YWl0IGVkaXREYXRhKHBhZ2UsZGF0YT0+e2RhdGEuZGVyaXZlZD17b3A6J3ZhcmlhYmxlJyx2YXJpYWJsZUlkOmYuZGVyaXZlZC5pZH07fSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtcGFuZWwnKS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoL+W+queSsC8pO1xuICBleHBlY3QoYXdhaXQgZHVyYWJsZShwYWdlKSkudG9FcXVhbChjeWNsZUJlZm9yZSk7XG4gIGF3YWl0IGVkaXREYXRhKHBhZ2UsZGF0YT0+e2RhdGEuZGVyaXZlZD17b3A6J2NvbXBhcmUnLHZhcmlhYmxlSWQ6Zi5hZmZpbml0eS5pZCxjb21wYXJhdG9yOidnZScsdmFsdWU6e3R5cGU6J2ludGVnZXInLHZhbHVlOjV9fTt9KTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO1xuICBhd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgYmVnaW4ocGFnZSxmLmVudHJ5LmlkKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi51bnNldHRsZWQubmFtZX0pKS50b0NvbnRhaW5UZXh0KC/mnKrlrpp85pyq6Kit5a6afOS4jeaYji8pO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCdzdW1tYXJ5JykuZmlsdGVyKHtoYXNUZXh0Om5ldyBSZWdFeHAoJ14nK2YubWVtb3J5Lm5hbWUrJyDCtyBhY3Jvc3NfcnVucyDCtycpfSkpLnRvQmVWaXNpYmxlKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJ3N1bW1hcnknKS5maWx0ZXIoe2hhc1RleHQ6bmV3IFJlZ0V4cCgnXicrZi5tb25leS5uYW1lKycgwrcgcnVuIMK3Jyl9KSkudG9CZVZpc2libGUoKTtcbiAgY29uc3QgdXNlcz1wYWdlLmxvY2F0b3IoJ2RldGFpbHMnKS5maWx0ZXIoe2hhczpwYWdlLmxvY2F0b3IoJ3N1bW1hcnknKS5maWx0ZXIoe2hhc1RleHQ6bmV3IFJlZ0V4cCgnXicrZi5hZmZpbml0eS5uYW1lKycgwrcgcnVuIMK3Jyl9KX0pO1xuICBhd2FpdCB1c2VzLmxvY2F0b3IoJ3N1bW1hcnknKS5maXJzdCgpLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHVzZXMpLnRvQ29udGFpblRleHQoJ3JlYWQnKTthd2FpdCBleHBlY3QodXNlcykudG9Db250YWluVGV4dCgndXBkYXRlJyk7YXdhaXQgZXhwZWN0KHVzZXMpLnRvQ29udGFpblRleHQoJ3Jlc2V0Jyk7XG4gIGF3YWl0IHVzZXMuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuc2V0QWZmaW5pdHkubmFtZSxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuZGV0YWlsLWhlYWRpbmcnKSkudG9Db250YWluVGV4dChmLnNldEFmZmluaXR5Lm5hbWUpO2F3YWl0IHJlYWRlcihwYWdlKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcucmVhZGVyLWNob2ljZXMnKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5nZXQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGZvcihjb25zdCBbbmFtZSx2YWx1ZV0gb2YgW1tmLmFmZmluaXR5Lm5hbWUsJzUnXSxbZi5tb25leS5uYW1lLCcxMSddLFtmLm1lbW9yeS5uYW1lLCd0cnVlJ10sW2YuZGVyaXZlZC5uYW1lLCd0cnVlJ11dIGFzIGNvbnN0KWF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXM6cGFnZS5nZXRCeVRleHQobmFtZSx7ZXhhY3Q6dHJ1ZX0pfSkpLnRvQ29udGFpblRleHQodmFsdWUpO1xuICBjb25zdCBiZWZvcmVCYXRjaD1hd2FpdCBkdXJhYmxlKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJy5yZWFkZXItY2hvaWNlcycpLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmludmFsaWQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItaXNzdWUnKSkudG9Db250YWluVGV4dCgv56aB5q2ifOmBt+enuy8pO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpmLm1vbmV5Lm5hbWV9KSkudG9Db250YWluVGV4dCgnMTEnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi5xdWVzdFN0YXRlLm5hbWV9KSkudG9Db250YWluVGV4dCgn5a6M5LqGJyk7XG4gIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKGJlZm9yZUJhdGNoKTtcbiAgLy8gVGhlIHdob2xlLWJhdGNoIHJlamVjdGlvbiBjYW5ub3QgYmUgcmVwYWlyZWQgYnkgYW4gb3JkaW5hcnkgcmVhc29uIGZpZWxkLlxuICBhd2FpdCBiZWdpbihwYWdlLGYuZW50cnkuaWQpO2F3YWl0IHBhZ2UubG9jYXRvcignLnJlYWRlci1jaG9pY2VzJykuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuZ2V0LmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJy5yZWFkZXItY2hvaWNlcycpLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmZpbmlzaC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCByZWNvcmRUcmlhbChwYWdlKTtcbiAgY29uc3Qgb25lPWF3YWl0IGJhY2t1cChwYWdlKSx0cmFjZTE9b25lLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoKGUpOmUgaXMgRW50aXR5PCd0cmFjZSc+PT5lLmtpbmQ9PT0ndHJhY2UnKSE7XG4gIGV4cGVjdCh0cmFjZTEuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnZhcmlhYmxlVmFsdWVzW2YuYWZmaW5pdHkuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZTo1fSk7XG4gIGV4cGVjdCh0cmFjZTEuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnZhcmlhYmxlVmFsdWVzW2YubW9uZXkuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZToxMX0pO1xuICBhd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+asoeOBruWRqOWbnicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYubW9uZXkubmFtZX0pKS50b0NvbnRhaW5UZXh0KCcxMCcpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpmLm1lbW9yeS5uYW1lfSkpLnRvQ29udGFpblRleHQoJ3RydWUnKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+OBmeOBueOBpuWIneacn+WMlicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYubWVtb3J5Lm5hbWV9KSkudG9Db250YWluVGV4dCgnZmFsc2UnKTtcbiAgYXdhaXQgYmVnaW4ocGFnZSxmLmVudHJ5LmlkKTthd2FpdCBwYWdlLmxvY2F0b3IoJy5yZWFkZXItY2hvaWNlcycpLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmdldC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcucmVhZGVyLWNob2ljZXMnKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5yZXNldFBhdGguZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYucXVlc3RTdGF0ZS5uYW1lfSkpLnRvQ29udGFpblRleHQoJ+acquWPl+azqCcpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzOnBhZ2UuZ2V0QnlUZXh0KGYuYWZmaW5pdHkubmFtZSx7ZXhhY3Q6dHJ1ZX0pfSkpLnRvQ29udGFpblRleHQoJzAnKTtcbiAgYXdhaXQgcmVjb3JkVHJpYWwocGFnZSk7Y29uc3QgcmVzZXRBcmNoaXZlPWF3YWl0IGJhY2t1cChwYWdlKSxyZXNldFRyYWNlPXJlc2V0QXJjaGl2ZS5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maWx0ZXIoKGUpOmUgaXMgRW50aXR5PCd0cmFjZSc+PT5lLmtpbmQ9PT0ndHJhY2UnKS5hdCgtMSkhO1xuICBleHBlY3QocmVzZXRUcmFjZS5kYXRhLnN0ZXBzLmF0KC0xKSEuYmVmb3JlLnZhcmlhYmxlVmFsdWVzW2YucXVlc3RTdGF0ZS5pZF0pLnRvRXF1YWwoe3R5cGU6J2VudW0nLHZhbHVlOiflrozkuoYnfSk7XG4gIGV4cGVjdChyZXNldFRyYWNlLmRhdGEuc3RlcHMuYXQoLTEpIS5hZnRlci52YXJpYWJsZVZhbHVlc1tmLnF1ZXN0U3RhdGUuaWRdKS50b0VxdWFsKHt0eXBlOidlbnVtJyx2YWx1ZTon5pyq5Y+X5rOoJ30pO1xuICBleHBlY3QocmVzZXRUcmFjZS5kYXRhLnN0ZXBzLmF0KC0xKSEuZWRnZUlkcykudG9FcXVhbChbZi5yZXNldFBhdGguaWRdKTtcbiAgYXdhaXQgb3BlblJlY29yZChwYWdlLCdlZmZlY3QnLGYucHJvaGliaXRlZC5uYW1lKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5leGNlcHRpb25EZXRhaWxzPXtyZWFzb246J+OBk+OBrue1jOi3r+OBrnRpY2sw4oCTMTDjgavpmZDjgornorroqo3muIjjgb/moLnmi6DjgavlvpPjgaPjgablho3lj5fms6jjgZnjgosnLHRhcmdldFNjb3BlOntwcm9qZWN0SWQ6Zi5wLnByb2plY3RJZCxncmFwaElkOmYuZ3JhcGguaWQscm91dGVDb25kaXRpb246e29wOidjb25zdGFudCcsdmFsdWU6dHJ1ZX19LHZhbGlkaXR5Ont3b3JsZFJhbmdlOntzdGFydDonMCcsZW5kOicxMCd9LHJvdXRlQ29uZGl0aW9uOntvcDonY29uc3RhbnQnLHZhbHVlOnRydWV9LHByZXNlbnRhdGlvbkFuY2hvcjpudWxsfSxldmlkZW5jZUlkczpbZi5leGNlcHRpb25FdmlkZW5jZS5pZF19O30pO2F3YWl0IHNhdmVFZGl0b3IocGFnZSk7XG4gIGF3YWl0IHJlYWRlcihwYWdlKTthd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+ippuiqremWi+Wni+aZgueCueOBruS4lueVjOWGhXRpY2snLHtleGFjdDp0cnVlfSkuZmlsbCgnNScpO2F3YWl0IGJlZ2luKHBhZ2UsZi5lbnRyeS5pZCk7YXdhaXQgcGFnZS5sb2NhdG9yKCcucmVhZGVyLWNob2ljZXMnKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5nZXQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcGFnZS5sb2NhdG9yKCcucmVhZGVyLWNob2ljZXMnKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5pbnZhbGlkLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucmVhZGVyLXRyaWFsLWhlYWRpbmcnKSkudG9Db250YWluVGV4dCgn5oSP5Zuz44GX44Gf57WC56uvJyk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi5xdWVzdFN0YXRlLm5hbWV9KSkudG9Db250YWluVGV4dCgn5pyq5Y+X5rOoJyk7YXdhaXQgcmVjb3JkVHJpYWwocGFnZSk7XG4gIGNvbnN0IGFjY2VwdGVkRXhjZXB0aW9uPWF3YWl0IGJhY2t1cChwYWdlKSxleGNlcHRpb25UcmFjZT1hY2NlcHRlZEV4Y2VwdGlvbi5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maWx0ZXIoKGUpOmUgaXMgRW50aXR5PCd0cmFjZSc+PT5lLmtpbmQ9PT0ndHJhY2UnKS5hdCgtMSkhO1xuICBleHBlY3QoZXhjZXB0aW9uVHJhY2UuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLml0ZW1JbnN0YW5jZXMuc29tZShpPT5pLmluc3RhbmNlSWQ9PT1mLmtleS5pZCYmaS5xdWFudGl0eT09PTEpKS50b0JlKHRydWUpO1xuICBhd2FpdCByZWFkZXIocGFnZSk7Zm9yKGNvbnN0IHRpY2sgb2YgWycxMScsJyddKXtcbiAgICBhd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+ippuiqremWi+Wni+aZgueCueOBruS4lueVjOWGhXRpY2snLHtleGFjdDp0cnVlfSkuZmlsbCh0aWNrKTthd2FpdCBiZWdpbihwYWdlLGYuZW50cnkuaWQpO2F3YWl0IHBhZ2UubG9jYXRvcignLnJlYWRlci1jaG9pY2VzJykuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuZ2V0LmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO2NvbnN0IHJlamVjdGVkTmF0aXZlPWF3YWl0IGR1cmFibGUocGFnZSk7XG4gICAgYXdhaXQgcGFnZS5sb2NhdG9yKCcucmVhZGVyLWNob2ljZXMnKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5pbnZhbGlkLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItaXNzdWUnKSkudG9Db250YWluVGV4dCgv56aB5q2ifOmBt+enu3zmnJ/pmZB85pmC54K5fOS+i+Wkli8pO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYubW9uZXkubmFtZX0pKS50b0NvbnRhaW5UZXh0KCcxMScpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYucXVlc3RTdGF0ZS5uYW1lfSkpLnRvQ29udGFpblRleHQoJ+WujOS6hicpO2V4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKHJlamVjdGVkTmF0aXZlKTtcbiAgfVxuICBhd2FpdCBwYWdlLnJlbG9hZCgpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5hcHAtc2hlbGwnKSkudG9CZVZpc2libGUoKTtjb25zdCBjb2xkPWF3YWl0IGJhY2t1cChwYWdlKTtcbiAgZXhwZWN0KGNvbGQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmluZChlPT5lLmlkPT09Zi51bnVzZWQuaWQpPy5kZWxldGVkQXQpLnRvQmVGYWxzeSgpO1xuICBleHBlY3QoY29sZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLnVuc2V0dGxlZC5pZCk/LmRhdGEpLnRvTWF0Y2hPYmplY3Qoe2luaXRpYWw6e3R5cGU6J3Vua25vd24nLHZhbHVlOm51bGx9fSk7XG4gIGNvbnN0IHJlc3RvcmVkPWF3YWl0IGZyZXNoUm91bmR0cmlwKGJyb3dzZXIsY29sZC5ieXRlcyksY2xvbmU9YXdhaXQgZnJlc2hSb3VuZHRyaXAoYnJvd3Nlcixjb2xkLmJ5dGVzLCdjbG9uZScpO1xuICBleHBlY3QocmVzdG9yZWQucGFyc2VkLnByb2plY3QpLnRvRXF1YWwoY29sZC5wYXJzZWQucHJvamVjdCk7ZXhwZWN0KGNsb25lLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbHRlcihlPT5lLmtpbmQ9PT0ndHJhY2UnKSkudG9IYXZlTGVuZ3RoKDMpO1xuICBhd2FpdCBldmlkZW5jZShpbmZvLCdGMzgtRjQxLW9yaWdpbmFsLWxpZmVjeWNsZS1hbmQtYXRvbWljLXRyYW5zaXRpb24nLHtmaXh0dXJlU0hBMjU2OmRpZ2VzdChpbnB1dCksc291cmNlVmFsdWVzOntlbnVtOlsn5a2Y5ZG9Jywn5q275LqhJ10sYWZmaW5pdHlJbml0aWFsOjAscnVuTW9uZXk6MTAsdW5rbm93bkJvb2xlYW46dHJ1ZSxhY3Jvc3NSdW5NZW1vcnk6dHJ1ZSxkZXJpdmVkRnJvbTpmLmFmZmluaXR5LmlkfSxyZWplY3RlZFdyb25nVHlwZUFuZE91dHNpZGVBbGxvd2VkOnRydWUsZGVyaXZlZERpcmVjdFdyaXRlUmVqZWN0ZWQ6dHJ1ZSxkZXJpdmVkQ3ljbGVSZWplY3RlZDp0cnVlLHByb2hpYml0ZWRRdWVzdFRyYW5zaXRpb246e2Zyb206J+WujOS6hicsdG86J+acquWPl+azqCcscmVhc29uOiflgpnogIPjgaDjgZEnLHdob2xlTW9uZXlBbmRJdGVtQmF0Y2hSZWplY3RlZDp0cnVlfSxleHBsaWNpdFJlc2V0VHJhY2U6cmVzZXRUcmFjZS5kYXRhLGV4Y2VwdGlvblRyYWNlOmV4Y2VwdGlvblRyYWNlLmRhdGEsZXhjZXB0aW9uSW5zaWRlVGljazVBY2NlcHRlZDp0cnVlLGV4cGlyZWRUaWNrMTFBbmRVbmtub3duVGlja1dob2xlQmF0Y2hSZWZ1c2VkOnRydWUsb3JkaW5hcnlVbmNoYW5nZWRZRXh0ZXJuYWxSZXRlbnRpb246dHJ1ZSxjb2xkQW5kTmV3QW5kQ2xvbmU6dHJ1ZSxhcmNoaXZlU0hBMjU2OmRpZ2VzdChjb2xkLmJ5dGVzKSxmdWxsQ2FzZXNDbGFpbWVkOltdfSk7XG59KTtcblxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFRQSxJQUFJLEVBQUNDLE1BQU0sUUFBTyxrQkFBa0I7QUFFNUMsU0FBUUMsaUJBQWlCLFFBQW1ELDRCQUE0QjtBQUN4RyxTQUFZQyxJQUFJLEVBQUNDLE1BQU0sRUFBQ0MsT0FBTyxFQUFDQyxRQUFRLEVBQUNDLE1BQU0sUUFBTyxVQUFVO0FBQ2hFLFNBQVFDLE1BQU0sRUFBQ0MsS0FBSyxFQUFDQyxXQUFXLEVBQUNDLFVBQVUsRUFBQ0MsUUFBUSxFQUFDQyxVQUFVLEVBQUNDLGNBQWMsUUFBTyxvQkFBb0I7QUFFekdkLElBQUksQ0FBQyx3SkFBd0osRUFBQyxPQUFNO0VBQUNlLElBQUk7RUFBQ0M7QUFBTyxDQUFDLEVBQUNDLElBQUksS0FBRztFQUFBLElBQUFDLHFCQUFBLEVBQUFDLHNCQUFBO0VBQ3hMbkIsSUFBSSxDQUFDb0IsVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUN2QixNQUFNQyxDQUFDLEdBQUNuQixpQkFBaUIsQ0FBQyxDQUFDO0VBQUMsTUFBTW9CLEtBQUssR0FBQyxNQUFNbkIsSUFBSSxDQUFDWSxJQUFJLEVBQUNNLENBQUMsQ0FBQ0UsQ0FBQyxDQUFDO0VBQzVELE1BQU1aLFVBQVUsQ0FBQ0ksSUFBSSxFQUFDLFVBQVUsRUFBQ00sQ0FBQyxDQUFDRyxLQUFLLENBQUNDLElBQUksQ0FBQztFQUM5QyxNQUFNeEIsTUFBTSxDQUFDYyxJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDLGNBQWM7SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUM5RixNQUFNQyxvQkFBb0IsR0FBQyxNQUFNeEIsT0FBTyxDQUFDVSxJQUFJLENBQUM7RUFDOUMsTUFBTUgsUUFBUSxDQUFDRyxJQUFJLEVBQUNlLElBQUksSUFBRTtJQUFDQSxJQUFJLENBQUNDLE9BQU8sR0FBQztNQUFDQyxJQUFJLEVBQUMsU0FBUztNQUFDQyxLQUFLLEVBQUM7SUFBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQ25FLE1BQU1oQyxNQUFNLENBQUNjLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQ1IsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNFLGFBQWEsQ0FBQyxNQUFNLENBQUM7RUFDcEYsTUFBTWIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUNSLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDO0VBQWlCLENBQUMsQ0FBQyxDQUFDVSxLQUFLLENBQUMsQ0FBQztFQUN6RixNQUFNbEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNSLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDRSxhQUFhLENBQUMsTUFBTSxDQUFDO0VBQ3BGM0IsTUFBTSxDQUFDLE1BQU1JLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQ1Asb0JBQW9CLENBQUM7RUFDekQsTUFBTWpCLFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDQyxPQUFPLEdBQUM7TUFBQ0MsSUFBSSxFQUFDLE1BQU07TUFBQ0MsS0FBSyxFQUFDO0lBQU8sQ0FBQztFQUFDLENBQUMsQ0FBQztFQUN0RSxNQUFNbEIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUNSLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDO0VBQWlCLENBQUMsQ0FBQyxDQUFDVSxLQUFLLENBQUMsQ0FBQztFQUN6RixNQUFNbEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNSLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDRSxhQUFhLENBQUMsU0FBUyxDQUFDO0VBQ3ZGM0IsTUFBTSxDQUFDLE1BQU1JLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQ1Asb0JBQW9CLENBQUM7RUFDekQsTUFBTWpCLFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDQyxPQUFPLEdBQUM7TUFBQ0MsSUFBSSxFQUFDLE1BQU07TUFBQ0MsS0FBSyxFQUFDO0lBQUksQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1wQixVQUFVLENBQUNFLElBQUksQ0FBQztFQUMxRixNQUFNSixVQUFVLENBQUNJLElBQUksRUFBQyxRQUFRLEVBQUNNLENBQUMsQ0FBQ2dCLFlBQVksQ0FBQ1osSUFBSSxDQUFDO0VBQUMsTUFBTWEsYUFBYSxHQUFDLE1BQU1qQyxPQUFPLENBQUNVLElBQUksQ0FBQztFQUMzRixNQUFNSCxRQUFRLENBQUNHLElBQUksRUFBQ2UsSUFBSSxJQUFFO0lBQUNBLElBQUksQ0FBQ1MsUUFBUSxHQUFDbEIsQ0FBQyxDQUFDbUIsT0FBTyxDQUFDQyxFQUFFO0lBQUNYLElBQUksQ0FBQ0csS0FBSyxHQUFDO01BQUNELElBQUksRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQztJQUFJLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDL0YsTUFBTWhDLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDUixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDLGdCQUFnQixDQUFDO0VBQzlGM0IsTUFBTSxDQUFDLE1BQU1JLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQ0UsYUFBYSxDQUFDO0VBQ2xELE1BQU0xQixRQUFRLENBQUNHLElBQUksRUFBQ2UsSUFBSSxJQUFFO0lBQUNBLElBQUksQ0FBQ1MsUUFBUSxHQUFDbEIsQ0FBQyxDQUFDcUIsTUFBTSxDQUFDRCxFQUFFO0lBQUNYLElBQUksQ0FBQ0csS0FBSyxHQUFDO01BQUNELElBQUksRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQztJQUFLLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNcEIsVUFBVSxDQUFDRSxJQUFJLENBQUM7RUFDdEgsTUFBTUosVUFBVSxDQUFDSSxJQUFJLEVBQUMsVUFBVSxFQUFDTSxDQUFDLENBQUNtQixPQUFPLENBQUNmLElBQUksQ0FBQztFQUFDLE1BQU1rQixXQUFXLEdBQUMsTUFBTXRDLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDO0VBQ3RGLE1BQU1ILFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDVSxPQUFPLEdBQUM7TUFBQ0ksRUFBRSxFQUFDLFVBQVU7TUFBQ0MsVUFBVSxFQUFDeEIsQ0FBQyxDQUFDbUIsT0FBTyxDQUFDQztJQUFFLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDbEYsTUFBTXhDLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDUixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDLElBQUksQ0FBQztFQUNsRjNCLE1BQU0sQ0FBQyxNQUFNSSxPQUFPLENBQUNVLElBQUksQ0FBQyxDQUFDLENBQUNxQixPQUFPLENBQUNPLFdBQVcsQ0FBQztFQUNoRCxNQUFNL0IsUUFBUSxDQUFDRyxJQUFJLEVBQUNlLElBQUksSUFBRTtJQUFDQSxJQUFJLENBQUNVLE9BQU8sR0FBQztNQUFDSSxFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUN4QixDQUFDLENBQUN5QixRQUFRLENBQUNMLEVBQUU7TUFBQ00sVUFBVSxFQUFDLElBQUk7TUFBQ2QsS0FBSyxFQUFDO1FBQUNELElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFDO0lBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1wQixVQUFVLENBQUNFLElBQUksQ0FBQztFQUN4SixNQUFNUCxNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU1OLEtBQUssQ0FBQ00sSUFBSSxFQUFDTSxDQUFDLENBQUMyQixLQUFLLENBQUNQLEVBQUUsQ0FBQztFQUMvQyxNQUFNeEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQzhCLFNBQVMsQ0FBQzFCO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLFdBQVcsQ0FBQztFQUM3RyxNQUFNM0IsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUMsSUFBSUUsTUFBTSxDQUFDLEdBQUcsR0FBQy9CLENBQUMsQ0FBQ3FCLE1BQU0sQ0FBQ2pCLElBQUksR0FBQyxrQkFBa0I7RUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDNEIsV0FBVyxDQUFDLENBQUM7RUFDdEgsTUFBTXBELE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDLElBQUlFLE1BQU0sQ0FBQyxHQUFHLEdBQUMvQixDQUFDLENBQUNpQyxLQUFLLENBQUM3QixJQUFJLEdBQUMsVUFBVTtFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM0QixXQUFXLENBQUMsQ0FBQztFQUM3RyxNQUFNRSxJQUFJLEdBQUN4QyxJQUFJLENBQUNtQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDTyxHQUFHLEVBQUN6QyxJQUFJLENBQUNtQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUNlLE1BQU0sQ0FBQztNQUFDQyxPQUFPLEVBQUMsSUFBSUUsTUFBTSxDQUFDLEdBQUcsR0FBQy9CLENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQ3JCLElBQUksR0FBQyxVQUFVO0lBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUNySSxNQUFNOEIsSUFBSSxDQUFDckIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDdUIsS0FBSyxDQUFDLENBQUMsQ0FBQ3RCLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxDLE1BQU0sQ0FBQ3NELElBQUksQ0FBQyxDQUFDM0IsYUFBYSxDQUFDLE1BQU0sQ0FBQztFQUFDLE1BQU0zQixNQUFNLENBQUNzRCxJQUFJLENBQUMsQ0FBQzNCLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFBQyxNQUFNM0IsTUFBTSxDQUFDc0QsSUFBSSxDQUFDLENBQUMzQixhQUFhLENBQUMsT0FBTyxDQUFDO0VBQzNLLE1BQU0yQixJQUFJLENBQUM3QixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDcUMsV0FBVyxDQUFDakMsSUFBSTtJQUFDRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNbEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDTixhQUFhLENBQUNQLENBQUMsQ0FBQ3FDLFdBQVcsQ0FBQ2pDLElBQUksQ0FBQztFQUFDLE1BQU1qQixNQUFNLENBQUNPLElBQUksQ0FBQztFQUM5SyxNQUFNQSxJQUFJLENBQUNtQixPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ1IsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUNKLENBQUMsQ0FBQ3NDLEdBQUcsQ0FBQzdCLElBQUksQ0FBQzhCLEtBQU07SUFBQ2pDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUNyRyxLQUFJLE1BQU0sQ0FBQ1YsSUFBSSxFQUFDUSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUNaLENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQ3JCLElBQUksRUFBQyxHQUFHLENBQUMsRUFBQyxDQUFDSixDQUFDLENBQUNpQyxLQUFLLENBQUM3QixJQUFJLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQ0osQ0FBQyxDQUFDcUIsTUFBTSxDQUFDakIsSUFBSSxFQUFDLE1BQU0sQ0FBQyxFQUFDLENBQUNKLENBQUMsQ0FBQ21CLE9BQU8sQ0FBQ2YsSUFBSSxFQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQVUsTUFBTXhCLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDTyxHQUFHLEVBQUN6QyxJQUFJLENBQUM4QyxTQUFTLENBQUNwQyxJQUFJLEVBQUM7TUFBQ0UsS0FBSyxFQUFDO0lBQUksQ0FBQztFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNDLGFBQWEsQ0FBQ0ssS0FBSyxDQUFDO0VBQ2xQLE1BQU02QixXQUFXLEdBQUMsTUFBTXpELE9BQU8sQ0FBQ1UsSUFBSSxDQUFDO0VBQ3JDLE1BQU1BLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDMEMsT0FBTyxDQUFDakMsSUFBSSxDQUFDOEIsS0FBTTtJQUFDakMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQ3pHLE1BQU1sQyxNQUFNLENBQUNjLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDTixhQUFhLENBQUMsT0FBTyxDQUFDO0VBQ2xFLE1BQU0zQixNQUFNLENBQUNjLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDN0IsQ0FBQyxDQUFDaUMsS0FBSyxDQUFDN0I7RUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDRyxhQUFhLENBQUMsSUFBSSxDQUFDO0VBQ2xHLE1BQU0zQixNQUFNLENBQUNjLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDN0IsQ0FBQyxDQUFDMkMsVUFBVSxDQUFDdkM7RUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDRyxhQUFhLENBQUMsSUFBSSxDQUFDO0VBQ3ZHM0IsTUFBTSxDQUFDLE1BQU1JLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQzBCLFdBQVcsQ0FBQztFQUNoRDtFQUNBLE1BQU1yRCxLQUFLLENBQUNNLElBQUksRUFBQ00sQ0FBQyxDQUFDMkIsS0FBSyxDQUFDUCxFQUFFLENBQUM7RUFBQyxNQUFNMUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNSLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUNzQyxHQUFHLENBQUM3QixJQUFJLENBQUM4QixLQUFNO0lBQUNqQyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFDbEksTUFBTXBCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDNEMsTUFBTSxDQUFDbkMsSUFBSSxDQUFDOEIsS0FBTTtJQUFDakMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXpCLFdBQVcsQ0FBQ0ssSUFBSSxDQUFDO0VBQ2hJLE1BQU1tRCxHQUFHLEdBQUMsTUFBTTlELE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0lBQUNvRCxNQUFNLEdBQUNELEdBQUcsQ0FBQ0UsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQXdCQSxDQUFDLENBQUNDLElBQUksS0FBRyxPQUFPLENBQUU7RUFDakh4RSxNQUFNLENBQUNrRSxNQUFNLENBQUNyQyxJQUFJLENBQUM0QyxLQUFLLENBQUNDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFQyxLQUFLLENBQUNDLGNBQWMsQ0FBQ3hELENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQ0wsRUFBRSxDQUFDLENBQUMsQ0FBQ0wsT0FBTyxDQUFDO0lBQUNKLElBQUksRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQztFQUFDLENBQUMsQ0FBQztFQUN2R2hDLE1BQU0sQ0FBQ2tFLE1BQU0sQ0FBQ3JDLElBQUksQ0FBQzRDLEtBQUssQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVDLEtBQUssQ0FBQ0MsY0FBYyxDQUFDeEQsQ0FBQyxDQUFDaUMsS0FBSyxDQUFDYixFQUFFLENBQUMsQ0FBQyxDQUFDTCxPQUFPLENBQUM7SUFBQ0osSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3JHLE1BQU16QixNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU1BLElBQUksQ0FBQ1csU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUMsTUFBTTtJQUFDRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFDbEYsTUFBTWxDLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUNpQyxLQUFLLENBQUM3QjtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxJQUFJLENBQUM7RUFDbEcsTUFBTTNCLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUNxQixNQUFNLENBQUNqQjtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxNQUFNLENBQUM7RUFDckcsTUFBTWIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxRQUFRO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUNqRSxNQUFNbEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQ3FCLE1BQU0sQ0FBQ2pCO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUN0RyxNQUFNbkIsS0FBSyxDQUFDTSxJQUFJLEVBQUNNLENBQUMsQ0FBQzJCLEtBQUssQ0FBQ1AsRUFBRSxDQUFDO0VBQUMsTUFBTTFCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDc0MsR0FBRyxDQUFDN0IsSUFBSSxDQUFDOEIsS0FBTTtJQUFDakMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQ2xJLE1BQU1wQixJQUFJLENBQUNtQixPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ1IsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUNKLENBQUMsQ0FBQ3lELFNBQVMsQ0FBQ2hELElBQUksQ0FBQzhCLEtBQU07SUFBQ2pDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUMzRyxNQUFNbEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQzJDLFVBQVUsQ0FBQ3ZDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLEtBQUssQ0FBQztFQUN4RyxNQUFNM0IsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNPLEdBQUcsRUFBQ3pDLElBQUksQ0FBQzhDLFNBQVMsQ0FBQ3hDLENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQ3JCLElBQUksRUFBQztNQUFDRSxLQUFLLEVBQUM7SUFBSSxDQUFDO0VBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsYUFBYSxDQUFDLEdBQUcsQ0FBQztFQUM3SCxNQUFNbEIsV0FBVyxDQUFDSyxJQUFJLENBQUM7RUFBQyxNQUFNZ0UsWUFBWSxHQUFDLE1BQU0zRSxNQUFNLENBQUNXLElBQUksQ0FBQztJQUFDaUUsVUFBVSxHQUFDRCxZQUFZLENBQUNYLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNyQixNQUFNLENBQUV1QixDQUFDLElBQXdCQSxDQUFDLENBQUNDLElBQUksS0FBRyxPQUFPLENBQUMsQ0FBQ0UsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFFO0VBQ3hLMUUsTUFBTSxDQUFDK0UsVUFBVSxDQUFDbEQsSUFBSSxDQUFDNEMsS0FBSyxDQUFDQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRU0sTUFBTSxDQUFDSixjQUFjLENBQUN4RCxDQUFDLENBQUMyQyxVQUFVLENBQUN2QixFQUFFLENBQUMsQ0FBQyxDQUFDTCxPQUFPLENBQUM7SUFBQ0osSUFBSSxFQUFDLE1BQU07SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDO0VBQzlHaEMsTUFBTSxDQUFDK0UsVUFBVSxDQUFDbEQsSUFBSSxDQUFDNEMsS0FBSyxDQUFDQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRUMsS0FBSyxDQUFDQyxjQUFjLENBQUN4RCxDQUFDLENBQUMyQyxVQUFVLENBQUN2QixFQUFFLENBQUMsQ0FBQyxDQUFDTCxPQUFPLENBQUM7SUFBQ0osSUFBSSxFQUFDLE1BQU07SUFBQ0MsS0FBSyxFQUFDO0VBQUssQ0FBQyxDQUFDO0VBQzlHaEMsTUFBTSxDQUFDK0UsVUFBVSxDQUFDbEQsSUFBSSxDQUFDNEMsS0FBSyxDQUFDQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRU8sT0FBTyxDQUFDLENBQUM5QyxPQUFPLENBQUMsQ0FBQ2YsQ0FBQyxDQUFDeUQsU0FBUyxDQUFDckMsRUFBRSxDQUFDLENBQUM7RUFDdkUsTUFBTTlCLFVBQVUsQ0FBQ0ksSUFBSSxFQUFDLFFBQVEsRUFBQ00sQ0FBQyxDQUFDOEQsVUFBVSxDQUFDMUQsSUFBSSxDQUFDO0VBQ2pELE1BQU1iLFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDc0QsZ0JBQWdCLEdBQUM7TUFBQ0MsTUFBTSxFQUFDLGlDQUFpQztNQUFDQyxXQUFXLEVBQUM7UUFBQ0MsU0FBUyxFQUFDbEUsQ0FBQyxDQUFDRSxDQUFDLENBQUNnRSxTQUFTO1FBQUNDLE9BQU8sRUFBQ25FLENBQUMsQ0FBQ29FLEtBQUssQ0FBQ2hELEVBQUU7UUFBQ2lELGNBQWMsRUFBQztVQUFDOUMsRUFBRSxFQUFDLFVBQVU7VUFBQ1gsS0FBSyxFQUFDO1FBQUk7TUFBQyxDQUFDO01BQUMwRCxRQUFRLEVBQUM7UUFBQ0MsVUFBVSxFQUFDO1VBQUNDLEtBQUssRUFBQyxHQUFHO1VBQUNDLEdBQUcsRUFBQztRQUFJLENBQUM7UUFBQ0osY0FBYyxFQUFDO1VBQUM5QyxFQUFFLEVBQUMsVUFBVTtVQUFDWCxLQUFLLEVBQUM7UUFBSSxDQUFDO1FBQUM4RCxrQkFBa0IsRUFBQztNQUFJLENBQUM7TUFBQ0MsV0FBVyxFQUFDLENBQUMzRSxDQUFDLENBQUM0RSxpQkFBaUIsQ0FBQ3hELEVBQUU7SUFBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTTVCLFVBQVUsQ0FBQ0UsSUFBSSxDQUFDO0VBQzFXLE1BQU1QLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDbUYsVUFBVSxDQUFDLGdCQUFnQixFQUFDO0lBQUN2RSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ3dFLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNMUYsS0FBSyxDQUFDTSxJQUFJLEVBQUNNLENBQUMsQ0FBQzJCLEtBQUssQ0FBQ1AsRUFBRSxDQUFDO0VBQUMsTUFBTTFCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDc0MsR0FBRyxDQUFDN0IsSUFBSSxDQUFDOEIsS0FBTTtJQUFDakMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDMEMsT0FBTyxDQUFDakMsSUFBSSxDQUFDOEIsS0FBTTtJQUFDakMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQzlULE1BQU1sQyxNQUFNLENBQUNjLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUNOLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFBQyxNQUFNM0IsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQzJDLFVBQVUsQ0FBQ3ZDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLEtBQUssQ0FBQztFQUFDLE1BQU1sQixXQUFXLENBQUNLLElBQUksQ0FBQztFQUM1TSxNQUFNcUYsaUJBQWlCLEdBQUMsTUFBTWhHLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0lBQUNzRixjQUFjLEdBQUNELGlCQUFpQixDQUFDaEMsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ3JCLE1BQU0sQ0FBRXVCLENBQUMsSUFBd0JBLENBQUMsQ0FBQ0MsSUFBSSxLQUFHLE9BQU8sQ0FBQyxDQUFDRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUU7RUFDOUoxRSxNQUFNLENBQUNvRyxjQUFjLENBQUN2RSxJQUFJLENBQUM0QyxLQUFLLENBQUNDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFQyxLQUFLLENBQUMwQixhQUFhLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNDLFVBQVUsS0FBR3BGLENBQUMsQ0FBQ3FGLEdBQUcsQ0FBQ2pFLEVBQUUsSUFBRStELENBQUMsQ0FBQ0csUUFBUSxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDekgsTUFBTXBHLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO0VBQUMsS0FBSSxNQUFNOEYsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFDLEVBQUUsQ0FBQyxFQUFDO0lBQzdDLE1BQU05RixJQUFJLENBQUNtRixVQUFVLENBQUMsZ0JBQWdCLEVBQUM7TUFBQ3ZFLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDd0UsSUFBSSxDQUFDVSxJQUFJLENBQUM7SUFBQyxNQUFNcEcsS0FBSyxDQUFDTSxJQUFJLEVBQUNNLENBQUMsQ0FBQzJCLEtBQUssQ0FBQ1AsRUFBRSxDQUFDO0lBQUMsTUFBTTFCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO01BQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDc0MsR0FBRyxDQUFDN0IsSUFBSSxDQUFDOEIsS0FBTTtNQUFDakMsS0FBSyxFQUFDO0lBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0lBQUMsTUFBTTJFLGNBQWMsR0FBQyxNQUFNekcsT0FBTyxDQUFDVSxJQUFJLENBQUM7SUFDM08sTUFBTUEsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNSLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUMwQyxPQUFPLENBQUNqQyxJQUFJLENBQUM4QixLQUFNO01BQUNqQyxLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7SUFBQyxNQUFNbEMsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ04sYUFBYSxDQUFDLGdCQUFnQixDQUFDO0lBQUMsTUFBTTNCLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztNQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUNpQyxLQUFLLENBQUM3QjtJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxJQUFJLENBQUM7SUFBQyxNQUFNM0IsTUFBTSxDQUFDYyxJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO01BQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQzJDLFVBQVUsQ0FBQ3ZDO0lBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLElBQUksQ0FBQztJQUFDM0IsTUFBTSxDQUFDLE1BQU1JLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQzBFLGNBQWMsQ0FBQztFQUN0YjtFQUNBLE1BQU0vRixJQUFJLENBQUNnRyxNQUFNLENBQUMsQ0FBQztFQUFDLE1BQU05RyxNQUFNLENBQUNjLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDbUIsV0FBVyxDQUFDLENBQUM7RUFBQyxNQUFNMkQsSUFBSSxHQUFDLE1BQU01RyxNQUFNLENBQUNXLElBQUksQ0FBQztFQUN4R2QsTUFBTSxFQUFBaUIscUJBQUEsR0FBQzhGLElBQUksQ0FBQzVDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUMvQixFQUFFLEtBQUdwQixDQUFDLENBQUM0RixNQUFNLENBQUN4RSxFQUFFLENBQUMsY0FBQXZCLHFCQUFBLHVCQUF4REEscUJBQUEsQ0FBMERnRyxTQUFTLENBQUMsQ0FBQ0MsU0FBUyxDQUFDLENBQUM7RUFDdkZsSCxNQUFNLEVBQUFrQixzQkFBQSxHQUFDNkYsSUFBSSxDQUFDNUMsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQy9CLEVBQUUsS0FBR3BCLENBQUMsQ0FBQzhCLFNBQVMsQ0FBQ1YsRUFBRSxDQUFDLGNBQUF0QixzQkFBQSx1QkFBM0RBLHNCQUFBLENBQTZEVyxJQUFJLENBQUMsQ0FBQ3NGLGFBQWEsQ0FBQztJQUFDckYsT0FBTyxFQUFDO01BQUNDLElBQUksRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQztJQUFJO0VBQUMsQ0FBQyxDQUFDO0VBQzlILE1BQU1vRixRQUFRLEdBQUMsTUFBTXZHLGNBQWMsQ0FBQ0UsT0FBTyxFQUFDZ0csSUFBSSxDQUFDTSxLQUFLLENBQUM7SUFBQ0MsS0FBSyxHQUFDLE1BQU16RyxjQUFjLENBQUNFLE9BQU8sRUFBQ2dHLElBQUksQ0FBQ00sS0FBSyxFQUFDLE9BQU8sQ0FBQztFQUM5R3JILE1BQU0sQ0FBQ29ILFFBQVEsQ0FBQ2pELE1BQU0sQ0FBQ0MsT0FBTyxDQUFDLENBQUNqQyxPQUFPLENBQUM0RSxJQUFJLENBQUM1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztFQUFDcEUsTUFBTSxDQUFDc0gsS0FBSyxDQUFDbkQsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ3JCLE1BQU0sQ0FBQ3VCLENBQUMsSUFBRUEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQytDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDOUksTUFBTWxILFFBQVEsQ0FBQ1csSUFBSSxFQUFDLGtEQUFrRCxFQUFDO0lBQUN3RyxhQUFhLEVBQUNsSCxNQUFNLENBQUNlLEtBQUssQ0FBQztJQUFDb0csWUFBWSxFQUFDO01BQUNDLElBQUksRUFBQyxDQUFDLElBQUksRUFBQyxJQUFJLENBQUM7TUFBQ0MsZUFBZSxFQUFDLENBQUM7TUFBQ0MsUUFBUSxFQUFDLEVBQUU7TUFBQ0MsY0FBYyxFQUFDLElBQUk7TUFBQ0MsZUFBZSxFQUFDLElBQUk7TUFBQ0MsV0FBVyxFQUFDM0csQ0FBQyxDQUFDeUIsUUFBUSxDQUFDTDtJQUFFLENBQUM7SUFBQ3dGLGtDQUFrQyxFQUFDLElBQUk7SUFBQ0MsMEJBQTBCLEVBQUMsSUFBSTtJQUFDQyxvQkFBb0IsRUFBQyxJQUFJO0lBQUNDLHlCQUF5QixFQUFDO01BQUNDLElBQUksRUFBQyxJQUFJO01BQUNDLEVBQUUsRUFBQyxLQUFLO01BQUNqRCxNQUFNLEVBQUMsTUFBTTtNQUFDa0QsOEJBQThCLEVBQUM7SUFBSSxDQUFDO0lBQUNDLGtCQUFrQixFQUFDeEQsVUFBVSxDQUFDbEQsSUFBSTtJQUFDdUUsY0FBYyxFQUFDQSxjQUFjLENBQUN2RSxJQUFJO0lBQUMyRyw0QkFBNEIsRUFBQyxJQUFJO0lBQUNDLDRDQUE0QyxFQUFDLElBQUk7SUFBQ0MsbUNBQW1DLEVBQUMsSUFBSTtJQUFDQyxrQkFBa0IsRUFBQyxJQUFJO0lBQUNDLGFBQWEsRUFBQ3RJLE1BQU0sQ0FBQ3lHLElBQUksQ0FBQ00sS0FBSyxDQUFDO0lBQUN3QixnQkFBZ0IsRUFBQztFQUFFLENBQUMsQ0FBQztBQUMzckIsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119