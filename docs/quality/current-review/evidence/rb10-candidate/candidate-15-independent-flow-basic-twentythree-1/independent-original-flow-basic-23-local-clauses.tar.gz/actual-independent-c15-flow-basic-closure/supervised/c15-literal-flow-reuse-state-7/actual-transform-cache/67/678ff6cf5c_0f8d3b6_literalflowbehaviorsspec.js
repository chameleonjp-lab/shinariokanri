// d4ff4139e8a040e961239f31894bac58d213983e
import { test, expect } from '@playwright/test';
import { createEntity, createProject, newId, textToRichText, validateProject } from '../candidate/src/domain/model';
import { createWorldSnapshot } from '../candidate/src/domain/world';
import { startTrial, stepTrial } from '../candidate/src/domain/runtime';
import { evaluateCondition } from '../candidate/src/domain/conditions';
import { prepareReactions } from '../candidate/src/domain/reactions';
import { seed, backup, durable, digest, evidence } from './common';
import { reader, begin, recordTrial, openRecord, freshRoundtrip, editData, saveEditor } from './extended-support';
function add(p, kind, name, data = {}) {
  const e = createEntity(p.projectId, kind, name, data);
  e.status = 'confirmed';
  p.entities.push(e);
  return e;
}
function variable(page, name) {
  return page.locator('.runtime-variables .runtime-variable').filter({
    has: page.getByText(name, {
      exact: true
    })
  });
}
async function lastTrace(page) {
  const file = await backup(page),
    trace = file.parsed.project.entities.filter(e => e.kind === 'trace').at(-1);
  return {
    file,
    trace
  };
}
test('original AT-F14 key gate + enter trigger once=run: state-only update/evaluation do not fire; same occurrence duplicate + revisit are stopped; normal saved trace/cold/newclone', async ({
  page,
  browser
}, info) => {
  test.setTimeout(240000);
  let p = createProject('原F14 鍵と入室once=run');
  const key = add(p, 'variable', '鍵あり', {
      key: 'has_key',
      valueType: 'boolean',
      scope: 'run',
      initial: {
        type: 'boolean',
        value: false
      }
    }),
    count = add(p, 'variable', '入室出来事の効果回数', {
      key: 'entered',
      valueType: 'integer',
      scope: 'run',
      initial: {
        type: 'integer',
        value: 0
      },
      allowed: {
        min: 0,
        max: 100
      }
    }),
    roomScene = add(p, 'scene', '鍵だけでは出来事を実行しない部屋', {
      body: textToRichText('入室という明示したきっかけを待つ😀。')
    });
  const entry = add(p, 'flow_node', '鍵を得る状態更新の入口', {
      nodeType: 'entry'
    }),
    room = add(p, 'flow_node', 'once=runの入室出来事', {
      nodeType: 'scene',
      sceneId: roomScene.id,
      gate: {
        op: 'compare',
        variableId: key.id,
        comparator: 'eq',
        value: {
          type: 'boolean',
          value: true
        }
      },
      trigger: {
        id: newId(),
        event: 'enter',
        eventKey: '入室',
        repeat: 'once',
        scope: 'run'
      }
    }),
    end = add(p, 'flow_node', '入室の確認終端', {
      nodeType: 'terminal',
      terminalReason: '入室と重複拒否を確認した'
    }),
    getKey = add(p, 'effect', '鍵を得るだけ', {
      operation: 'set',
      targetId: key.id,
      value: {
        type: 'boolean',
        value: true
      }
    }),
    enterEffect = add(p, 'effect', '明示入室時だけ加算', {
      operation: 'add',
      targetId: count.id,
      value: {
        type: 'integer',
        value: 1
      }
    });
  const get = add(p, 'flow_edge', '鍵の状態だけを更新', {
      fromId: entry.id,
      toId: room.id,
      label: '鍵の状態だけを更新',
      effectIds: [getKey.id]
    }),
    leave = add(p, 'flow_edge', '入室を実行して入口へ戻る', {
      fromId: room.id,
      toId: entry.id,
      label: '入室を実行して入口へ戻る',
      effectIds: [enterEffect.id]
    }),
    finish = add(p, 'flow_edge', '一回だけの結果を保存する', {
      fromId: entry.id,
      toId: end.id,
      label: '一回だけの結果を保存する'
    });
  add(p, 'flow_graph', '鍵と入室の図', {
    nodeIds: [entry.id, room.id, end.id],
    edgeIds: [get.id, leave.id, finish.id],
    entryIds: [entry.id],
    exitIds: [end.id]
  });
  expect(validateProject(p).ok).toBe(true);
  p = await createWorldSnapshot(p, '鍵と入室の固定版');
  const pin = p.snapshots.at(-1);
  // Exactly the declared duplicate occurrence is checked against the same normal fixture, separately from the UI's one-operation guard.
  const started = startTrial(p, {
      entryId: entry.id,
      contentVersionId: pin.id,
      seed: 'original-enter'
    }),
    gained = stepTrial(p, started, {
      edgeId: get.id
    });
  expect(gained.state.variableValues[count.id]).toEqual({
    type: 'integer',
    value: 0
  });
  const evaluated = evaluateCondition(room.data.gate, {
    state: gained.state,
    variables: p.entities.filter(e => e.kind === 'variable'),
    entities: p.entities
  });
  expect(evaluated.value).toBe('true');
  expect(gained.state.variableValues[count.id]).toEqual({
    type: 'integer',
    value: 0
  });
  const noTrigger = stepTrial(p, gained, {
    edgeId: leave.id
  });
  expect(noTrigger.state.variableValues[count.id]).toEqual({
    type: 'integer',
    value: 0
  });
  const event = {
    triggerId: room.data.trigger.id,
    event: 'enter',
    eventKey: '入室',
    occurrenceId: 'original-same-occurrence'
  };
  const fired = stepTrial(p, gained, {
      edgeId: leave.id,
      event
    }),
    duplicate = stepTrial(p, fired, {
      edgeId: leave.id,
      event
    });
  expect(duplicate.state).toEqual(fired.state);
  expect(duplicate.trace).toEqual(fired.trace);
  expect(duplicate.history).toEqual(fired.history);
  expect(fired.state.variableValues[count.id]).toEqual({
    type: 'integer',
    value: 1
  });
  const reentered = stepTrial(p, fired, {
      edgeId: get.id
    }),
    again = stepTrial(p, reentered, {
      edgeId: leave.id,
      event: {
        ...event,
        occurrenceId: 'new-reentry'
      }
    });
  expect(again.status).toBe('blocked');
  expect(again.state.variableValues[count.id]).toEqual({
    type: 'integer',
    value: 1
  });
  const input = await seed(page, p);
  await reader(page);
  await begin(page, entry.id, pin.id, 'original-enter');
  await expect(variable(page, count.name)).toContainText('0');
  await page.getByRole('button', {
    name: get.data.label,
    exact: true
  }).click();
  await expect(variable(page, key.name)).toContainText('true');
  await expect(variable(page, count.name)).toContainText('0');
  await expect(page.getByRole('button', {
    name: leave.data.label,
    exact: true
  })).toBeDisabled();
  const nativeBefore = await durable(page);
  await page.getByLabel('宣言したきっかけ「入室」で進む', {
    exact: true
  }).check();
  await page.getByRole('button', {
    name: leave.data.label,
    exact: true
  }).click();
  await expect(variable(page, count.name)).toContainText('1');
  await page.getByRole('button', {
    name: get.data.label,
    exact: true
  }).click();
  await page.getByLabel('宣言したきっかけ「入室」で進む', {
    exact: true
  }).check();
  await page.getByRole('button', {
    name: leave.data.label,
    exact: true
  }).click();
  await expect(page.locator('.reader-issue')).toContainText('一回限り');
  await expect(variable(page, count.name)).toContainText('1');
  expect(await durable(page)).toEqual(nativeBefore);
  await page.getByRole('button', {
    name: '一手戻る',
    exact: true
  }).click();
  await page.getByRole('button', {
    name: finish.data.label,
    exact: true
  }).click();
  await recordTrial(page);
  const saved = await lastTrace(page);
  expect(saved.trace.data.steps.filter(s => s.edgeIds.includes(leave.id))).toHaveLength(1);
  expect(saved.trace.data.steps.at(-1).after.variableValues[count.id]).toEqual({
    type: 'integer',
    value: 1
  });
  expect(saved.trace.data.steps.at(-1).after.onceTriggers.some(k => k.startsWith('trigger:run:'))).toBe(true);
  await page.reload();
  await reader(page);
  await page.locator('.saved-traces').getByRole('button', {
    name: new RegExp('^' + saved.trace.name)
  }).click();
  await expect(variable(page, count.name)).toContainText('1');
  const cold = await backup(page),
    fresh = await freshRoundtrip(browser, cold.bytes),
    clone = await freshRoundtrip(browser, cold.bytes, 'clone');
  expect(fresh.parsed.project.entities.find(e => e.id === saved.trace.id)).toEqual(saved.trace);
  expect(clone.parsed.project.entities.filter(e => e.kind === 'trace')).toHaveLength(1);
  await evidence(info, 'F14-original-trigger', {
    originalAcceptance: 'AT-F14',
    fixtureSHA256: digest(input),
    given: {
      gate: '鍵あり',
      trigger: '入室',
      once: 'run'
    },
    when: {
      stateOnlyUpdateNoEffect: true,
      evaluateOnlyNoEffect: true,
      explicitEnterExactlyOne: true,
      sameOccurrenceId: 'original-same-occurrence',
      duplicateStateTraceAndHistoryUnchanged: true,
      reentryNewOccurrenceBlocked: true
    },
    then: {
      noImplicitAutomaticEvent: true
    },
    negative: {
      normalTriggerRequired: true,
      duplicateAndOnceRunSafe: true,
      nativeTrialReadOnly: true
    },
    exactDuplicateState: fired.state,
    trace: saved.trace.data,
    coldNewClone: true,
    physical: 'not_run',
    wholeCasePassInferred: false
  });
});
test('original AT-F16 two key/no-key routes merge with initial affinity0, causes reopen; no implicit reset vs explicit reset; same fixed trace comparison/cold/newclone', async ({
  page,
  browser
}, info) => {
  test.setTimeout(300000);
  let p = createProject('原F16 鍵二経路と明示reset');
  const key = add(p, 'variable', '鍵あり', {
      key: 'key',
      valueType: 'boolean',
      scope: 'run',
      initial: {
        type: 'boolean',
        value: false
      }
    }),
    affinity = add(p, 'variable', '好感度0', {
      key: 'affinity',
      valueType: 'integer',
      scope: 'run',
      initial: {
        type: 'integer',
        value: 0
      },
      allowed: {
        min: 0,
        max: 10
      }
    }),
    scene = add(p, 'scene', '同じ合流後の場面', {
      body: textToRichText('鍵と好感度の差を消すか、会話へ反映するか作者が決める。')
    });
  const entry = add(p, 'flow_node', '二経路の入口', {
      nodeType: 'entry'
    }),
    merge = add(p, 'flow_node', '二経路が合流する点', {
      nodeType: 'choice',
      sceneId: scene.id
    }),
    end = add(p, 'flow_node', '合流の同じ終点', {
      nodeType: 'terminal',
      terminalReason: '合流の差と明示効果を記録した'
    }),
    keyEffect = add(p, 'effect', '鍵を得た変更元', {
      operation: 'set',
      targetId: key.id,
      value: {
        type: 'boolean',
        value: true
      }
    }),
    affEffect = add(p, 'effect', '好感度を5へ変更した元', {
      operation: 'add',
      targetId: affinity.id,
      value: {
        type: 'integer',
        value: 5
      }
    }),
    resetKey = add(p, 'effect', '鍵の差を明示reset', {
      operation: 'reset',
      targetId: key.id,
      value: {
        type: 'boolean',
        value: false
      },
      reason: '作者が合流後の差を明示して解消する'
    }),
    resetAff = add(p, 'effect', '好感度の差を明示reset', {
      operation: 'reset',
      targetId: affinity.id,
      value: {
        type: 'integer',
        value: 0
      },
      reason: '好感度を初期0へ戻すと作者が決めた'
    });
  const got = add(p, 'flow_edge', '鍵を取得して好感度5の経路', {
      fromId: entry.id,
      toId: merge.id,
      label: '鍵を取得して好感度5の経路',
      effectIds: [keyEffect.id, affEffect.id]
    }),
    none = add(p, 'flow_edge', '鍵未取得で好感度0の経路', {
      fromId: entry.id,
      toId: merge.id,
      label: '鍵未取得で好感度0の経路'
    }),
    keep = add(p, 'flow_edge', '合流の差を保って終える', {
      fromId: merge.id,
      toId: end.id,
      label: '合流の差を保って終える'
    }),
    reset = add(p, 'flow_edge', '作者が明示したresetで終える', {
      fromId: merge.id,
      toId: end.id,
      label: '作者が明示したresetで終える',
      effectIds: [resetKey.id, resetAff.id]
    });
  add(p, 'flow_graph', '鍵取得と未取得の図', {
    nodeIds: [entry.id, merge.id, end.id],
    edgeIds: [got.id, none.id, keep.id, reset.id],
    entryIds: [entry.id],
    exitIds: [end.id]
  });
  p = await createWorldSnapshot(p, '二経路の同じ固定版');
  const pin = p.snapshots.at(-1);
  const input = await seed(page, p),
    traces = [],
    tracePins = [];
  for (const route of [got, none]) {
    await reader(page);
    await begin(page, entry.id, pin.id, 'merge-seed');
    await expect(variable(page, affinity.name)).toContainText('0');
    await page.getByRole('button', {
      name: route.data.label,
      exact: true
    }).click();
    await expect(page.locator('.reader-sheet-heading h2')).toHaveText(scene.name);
    await expect(variable(page, affinity.name)).toContainText(route === got ? '5' : '0');
    await expect(variable(page, key.name)).toContainText(route === got ? 'true' : 'false');
    await page.getByRole('button', {
      name: keep.data.label,
      exact: true
    }).click();
    await recordTrial(page);
    const saved = await lastTrace(page);
    traces.push(saved.trace);
    const savedPin = saved.file.parsed.project.snapshots.find(p => p.id === saved.trace.data.contentVersionId);
    expect(savedPin.content).toEqual(pin.content);
    expect(savedPin.contentHash).toBe(pin.contentHash);
    tracePins.push(savedPin);
  }
  expect(traces[0].data.steps.at(-1).after.variableValues[affinity.id]).toEqual({
    type: 'integer',
    value: 5
  });
  expect(traces[1].data.steps.at(-1).after.variableValues[affinity.id]).toEqual({
    type: 'integer',
    value: 0
  });
  expect(tracePins.every(p => p.contentHash === pin.contentHash)).toBe(true);
  await reader(page);
  const comparison = page.locator('.regression-paths');
  const compareChecks = comparison.getByRole('checkbox');
  await expect(compareChecks).toHaveCount(2);
  for (let i = 0; i < traces.length; i++) {
    await expect(compareChecks.nth(i).locator('..')).toContainText(traces[i].name);
    await compareChecks.nth(i).check();
  }
  await comparison.getByRole('button', {
    name: '選んだ二経路を再生して比較',
    exact: true
  }).click();
  await expect(comparison).toContainText('同じ合流点の状態');
  await expect(comparison).toContainText('異なる作品版・改訂差を含む');
  await expect(comparison).toContainText('variableValues.' + affinity.id);
  await expect(comparison).toContainText('variableValues.' + key.id);
  const comparisonText = await comparison.innerText();
  const usage = page.locator('details').filter({
    has: page.locator('summary').filter({
      hasText: new RegExp('^' + affinity.name + ' · run ·')
    })
  });
  await usage.locator('summary').first().click();
  await usage.getByRole('button', {
    name: affEffect.name,
    exact: true
  }).click();
  const fixedCause = page.getByRole('dialog', {
    name: '固定版の参照先',
    exact: true
  });
  await expect(fixedCause).toContainText(affEffect.name);
  await expect(fixedCause).toContainText(tracePins[1].versionLabel);
  await fixedCause.getByRole('button', {
    name: /閉じる/
  }).last().click();
  const resetTraces = [];
  for (const route of [got, none]) {
    await reader(page);
    await begin(page, entry.id, pin.id, 'merge-seed');
    await page.getByRole('button', {
      name: route.data.label,
      exact: true
    }).click();
    await page.getByRole('button', {
      name: reset.data.label,
      exact: true
    }).click();
    await expect(variable(page, affinity.name)).toContainText('0');
    await expect(variable(page, key.name)).toContainText('false');
    await recordTrial(page);
    const saved = await lastTrace(page);
    resetTraces.push(saved.trace);
  }
  for (const trace of resetTraces) expect(trace.data.steps.at(-1).after.variableValues).toEqual(traces[1].data.steps.at(-1).after.variableValues);
  expect(resetTraces[0].data.steps.at(-1).before.variableValues[affinity.id]).toEqual({
    type: 'integer',
    value: 5
  });
  expect(resetTraces[0].data.steps.at(-1).edgeIds).toContain(reset.id);
  expect(reset.data.effectIds).toContain(resetAff.id);
  await page.reload();
  const cold = await backup(page),
    fresh = await freshRoundtrip(browser, cold.bytes),
    clone = await freshRoundtrip(browser, cold.bytes, 'clone');
  expect(cold.parsed.project.snapshots.find(s => s.id === pin.id)).toEqual(pin);
  expect(fresh.parsed.project.entities.filter(e => e.kind === 'trace')).toEqual(cold.parsed.project.entities.filter(e => e.kind === 'trace'));
  expect(clone.parsed.project.entities.filter(e => e.kind === 'trace')).toHaveLength(4);
  await evidence(info, 'F16-original-merge', {
    originalAcceptance: 'AT-F16',
    fixtureSHA256: digest(input),
    given: {
      twoKeyPaths: true,
      initialAffinity: 0,
      sameEdition: pin.id,
      contentHash: pin.contentHash
    },
    when: {
      normalBothPathsReachedSameMerge: true,
      normalSavedComparison: true,
      changeSourceOpened: affEffect.id,
      explicitResetBothPaths: true
    },
    then: {
      got5VsNone0PreservedWithoutReset: true,
      explicitResetVariableValuesSame: true
    },
    negative: {
      noImplicitMergeReset: true,
      sourceReasonsAndTraceChangesPreserved: true,
      originalFixedEditionUnchanged: true
    },
    comparisonText,
    savedPinBindings: tracePins.map(p => ({
      id: p.id,
      contentHash: p.contentHash,
      fullContentEqualOriginal: true
    })),
    sameHashedSourceEditionDespiteNewSavePinIDs: true,
    traces: traces.map(t => t.data),
    resetTraces: resetTraces.map(t => t.data),
    coldNewClone: true,
    physical: 'not_run',
    wholeCasePassInferred: false
  });
});
test('original AT-F20 first/revisit and exactly3 random candidates: seed/back/read position→record/replay→run money/across memory/newloop/fullreset→zero false fallback/cold/newclone', async ({
  page,
  browser
}, info) => {
  test.setTimeout(300000);
  let p = createProject('原F20 初回・再訪と抽選3候補');
  const money = add(p, 'variable', 'run所持金10', {
      key: 'money',
      valueType: 'integer',
      scope: 'run',
      initial: {
        type: 'integer',
        value: 10
      },
      allowed: {
        min: 0,
        max: 100
      }
    }),
    memory = add(p, 'variable', 'across_runs記憶', {
      key: 'remembered',
      valueType: 'boolean',
      scope: 'across_runs',
      initial: {
        type: 'boolean',
        value: false
      }
    });
  const scenes = ['初回の重要な説明', '再訪の短い反応', '抽選候補1', '抽選候補2', '抽選候補3'].map(name => add(p, 'scene', name, {
    body: textToRichText(name + 'の本文😀')
  }));
  const first = prepareReactions(p, {
    mode: 'first_revisit',
    sceneIds: scenes.slice(0, 2).map(s => s.id),
    name: '初回・再訪の原系列'
  });
  p = first.candidate;
  const random = prepareReactions(p, {
    mode: 'random',
    sceneIds: scenes.slice(2).map(s => s.id),
    name: '抽選3候補の原系列'
  });
  p = random.candidate;
  const addMoney = add(p, 'effect', '抽選反応で所持金15', {
      operation: 'add',
      targetId: money.id,
      value: {
        type: 'integer',
        value: 5
      }
    }),
    remember = add(p, 'effect', '重要情報の周回記憶', {
      operation: 'set',
      targetId: memory.id,
      value: {
        type: 'boolean',
        value: true
      }
    });
  for (const e of p.entities) if (e.kind === 'flow_edge' && e.data.fromId === random.entryId) e.data.effectIds = [addMoney.id, remember.id];
  for (const e of p.entities) e.status = 'confirmed';
  const zero = add(p, 'flow_node', '抽選候補ゼロの入口', {
      nodeType: 'entry'
    }),
    zeroEnd = add(p, 'flow_node', 'ゼロ候補の明示fallback終端', {
      nodeType: 'terminal',
      terminalReason: '作者が不成立時の代替終了を設定した'
    }),
    falseEdge = add(p, 'flow_edge', '常に不成立の候補', {
      fromId: zero.id,
      toId: zeroEnd.id,
      label: '常に不成立の候補',
      condition: {
        op: 'constant',
        value: false
      }
    });
  add(p, 'flow_graph', '候補ゼロの図', {
    nodeIds: [zero.id, zeroEnd.id],
    edgeIds: [falseEdge.id],
    entryIds: [zero.id],
    exitIds: [zeroEnd.id]
  });
  expect(validateProject(p).ok).toBe(true);
  p = await createWorldSnapshot(p, '反応3候補の固定版');
  const pin = p.snapshots.at(-1),
    input = await seed(page, p);
  await reader(page);
  await begin(page, first.entryId, pin.id, 'original-three');
  await page.getByRole('button', {
    name: '進行規則に従って次へ',
    exact: true
  }).click();
  await expect(page.locator('.reader-sheet')).toContainText('初回の重要な説明の本文');
  await page.getByRole('button', {
    name: 'もう一度反応を見る',
    exact: true
  }).click();
  await page.getByRole('button', {
    name: '進行規則に従って次へ',
    exact: true
  }).click();
  await expect(page.locator('.reader-sheet')).toContainText('再訪の短い反応の本文');
  await page.getByRole('button', {
    name: '一手戻る',
    exact: true
  }).click();
  await page.getByRole('button', {
    name: '一手戻る',
    exact: true
  }).click();
  await expect(page.locator('.reader-sheet')).toContainText('初回の重要な説明の本文');
  await page.getByRole('button', {
    name: '反応の試読を終了する',
    exact: true
  }).click();
  await recordTrial(page);
  const firstSaved = await lastTrace(page);
  expect(firstSaved.trace.data.steps.at(-1).after.seenIds).toContain(scenes[0].id);
  await reader(page);
  await begin(page, random.entryId, pin.id, 'original-three');
  await expect(page.locator('.reader-choices .reader-choice')).toHaveCount(3);
  await page.getByRole('button', {
    name: '真の選択肢から抽選',
    exact: true
  }).click();
  const firstRandomHeading = await page.locator('.reader-sheet-heading h2').innerText();
  expect(scenes.slice(2).map(s => s.name)).toContain(firstRandomHeading);
  await expect(variable(page, money.name)).toContainText('15');
  await expect(variable(page, memory.name)).toContainText('true');
  await expect(page.locator('.reader-state-counts')).toContainText('抽選位置');
  const observedDraw = await page.locator('.reader-state-counts').innerText();
  await page.getByRole('button', {
    name: '一手戻る',
    exact: true
  }).click();
  await expect(variable(page, money.name)).toContainText('10');
  await expect(variable(page, memory.name)).toContainText('false');
  await page.getByRole('button', {
    name: '真の選択肢から抽選',
    exact: true
  }).click();
  await expect(page.locator('.reader-sheet-heading h2')).toHaveText(firstRandomHeading);
  expect(await page.locator('.reader-state-counts').innerText()).toBe(observedDraw);
  await page.getByRole('button', {
    name: '反応の試読を終了する',
    exact: true
  }).click();
  await recordTrial(page);
  const randomSaved = await lastTrace(page),
    randomTrace = randomSaved.trace;
  expect(randomTrace.data.seed).toBe('original-three');
  expect(randomTrace.data.steps[0].before.rngPosition).toBe(0);
  expect(randomTrace.data.steps[0].after.rngPosition).toBeGreaterThan(0);
  expect(randomTrace.data.steps[0].after.seenIds.some(id => scenes.slice(2).some(s => s.id === id))).toBe(true);
  await reader(page);
  await page.getByRole('button', {
    name: '次の周回',
    exact: true
  }).click();
  await expect(variable(page, money.name)).toContainText('10');
  await expect(variable(page, memory.name)).toContainText('true');
  await expect(page.locator('.reader-trial-heading')).toContainText('周回 ' + (randomTrace.data.steps.at(-1).after.loopNumber + 1));
  await page.getByRole('button', {
    name: 'すべて初期化',
    exact: true
  }).click();
  await expect(variable(page, money.name)).toContainText('10');
  await expect(variable(page, memory.name)).toContainText('false');
  await begin(page, zero.id, pin.id, 'original-three');
  await expect(page.locator('.reader-trial-heading')).toContainText('進行不可');
  await expect(page.locator('.reader-choice').filter({
    has: page.getByText(falseEdge.data.label, {
      exact: true
    })
  })).toBeDisabled();
  await expect(page.locator('.reader-trial-heading')).not.toContainText('意図した終端');
  await openRecord(page, 'flow_node', zero.name);
  await editData(page, data => {
    data.fallbackId = zeroEnd.id;
  });
  await saveEditor(page);
  await reader(page);
  await begin(page, zero.id, '', 'original-three');
  await page.getByRole('button', {
    name: '代替の進行先へ：' + zeroEnd.name,
    exact: true
  }).click();
  await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  await page.reload();
  await reader(page);
  const replayButtons = page.locator('.saved-traces button.reference-link');
  await expect(replayButtons).toHaveCount(2);
  await expect(replayButtons.nth(1)).toContainText(randomTrace.name);
  await replayButtons.nth(1).click();
  await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  await expect(variable(page, money.name)).toContainText('15');
  await expect(variable(page, memory.name)).toContainText('true');
  const cold = await backup(page),
    fresh = await freshRoundtrip(browser, cold.bytes),
    clone = await freshRoundtrip(browser, cold.bytes, 'clone');
  expect(fresh.parsed.project.entities.find(e => e.id === randomTrace.id)).toEqual(randomTrace);
  expect(clone.parsed.project.entities.filter(e => e.kind === 'trace')).toHaveLength(2);
  await evidence(info, 'F20-original-three-reactions', {
    originalAcceptance: 'AT-F20',
    fixtureSHA256: digest(input),
    given: {
      firstRevisit: scenes.slice(0, 2).map(s => s.id),
      randomCandidateCount: 3,
      runMoney: 10,
      acrossRunsMemory: true
    },
    when: {
      firstThenRevisitThenTwoUndo: true,
      seed: 'original-three',
      randomThenUndoThenSameDraw: true,
      nextLoopMoney10MemoryTrue: true,
      allResetMoney10MemoryFalse: true
    },
    then: {
      importantFirstInformationPreserved: true,
      savedRngPositionAndSeenIdsReplayed: true
    },
    negative: {
      zeroFalseCandidatesBlockedNotTerminal: true,
      explicitFallbackNormalEditAndAdvance: true,
      fixedOldEditionUnchanged: true
    },
    randomTrace: randomTrace.data,
    firstTrace: firstSaved.trace.data,
    firstRandomHeading,
    coldNewClone: true,
    physical: 'not_run',
    wholeCasePassInferred: false
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0IiwiY3JlYXRlRW50aXR5IiwiY3JlYXRlUHJvamVjdCIsIm5ld0lkIiwidGV4dFRvUmljaFRleHQiLCJ2YWxpZGF0ZVByb2plY3QiLCJjcmVhdGVXb3JsZFNuYXBzaG90Iiwic3RhcnRUcmlhbCIsInN0ZXBUcmlhbCIsImV2YWx1YXRlQ29uZGl0aW9uIiwicHJlcGFyZVJlYWN0aW9ucyIsInNlZWQiLCJiYWNrdXAiLCJkdXJhYmxlIiwiZGlnZXN0IiwiZXZpZGVuY2UiLCJyZWFkZXIiLCJiZWdpbiIsInJlY29yZFRyaWFsIiwib3BlblJlY29yZCIsImZyZXNoUm91bmR0cmlwIiwiZWRpdERhdGEiLCJzYXZlRWRpdG9yIiwiYWRkIiwicCIsImtpbmQiLCJuYW1lIiwiZGF0YSIsImUiLCJwcm9qZWN0SWQiLCJzdGF0dXMiLCJlbnRpdGllcyIsInB1c2giLCJ2YXJpYWJsZSIsInBhZ2UiLCJsb2NhdG9yIiwiZmlsdGVyIiwiaGFzIiwiZ2V0QnlUZXh0IiwiZXhhY3QiLCJsYXN0VHJhY2UiLCJmaWxlIiwidHJhY2UiLCJwYXJzZWQiLCJwcm9qZWN0IiwiYXQiLCJicm93c2VyIiwiaW5mbyIsInNldFRpbWVvdXQiLCJrZXkiLCJ2YWx1ZVR5cGUiLCJzY29wZSIsImluaXRpYWwiLCJ0eXBlIiwidmFsdWUiLCJjb3VudCIsImFsbG93ZWQiLCJtaW4iLCJtYXgiLCJyb29tU2NlbmUiLCJib2R5IiwiZW50cnkiLCJub2RlVHlwZSIsInJvb20iLCJzY2VuZUlkIiwiaWQiLCJnYXRlIiwib3AiLCJ2YXJpYWJsZUlkIiwiY29tcGFyYXRvciIsInRyaWdnZXIiLCJldmVudCIsImV2ZW50S2V5IiwicmVwZWF0IiwiZW5kIiwidGVybWluYWxSZWFzb24iLCJnZXRLZXkiLCJvcGVyYXRpb24iLCJ0YXJnZXRJZCIsImVudGVyRWZmZWN0IiwiZ2V0IiwiZnJvbUlkIiwidG9JZCIsImxhYmVsIiwiZWZmZWN0SWRzIiwibGVhdmUiLCJmaW5pc2giLCJub2RlSWRzIiwiZWRnZUlkcyIsImVudHJ5SWRzIiwiZXhpdElkcyIsIm9rIiwidG9CZSIsInBpbiIsInNuYXBzaG90cyIsInN0YXJ0ZWQiLCJlbnRyeUlkIiwiY29udGVudFZlcnNpb25JZCIsImdhaW5lZCIsImVkZ2VJZCIsInN0YXRlIiwidmFyaWFibGVWYWx1ZXMiLCJ0b0VxdWFsIiwiZXZhbHVhdGVkIiwidmFyaWFibGVzIiwibm9UcmlnZ2VyIiwidHJpZ2dlcklkIiwib2NjdXJyZW5jZUlkIiwiZmlyZWQiLCJkdXBsaWNhdGUiLCJoaXN0b3J5IiwicmVlbnRlcmVkIiwiYWdhaW4iLCJpbnB1dCIsInRvQ29udGFpblRleHQiLCJnZXRCeVJvbGUiLCJjbGljayIsInRvQmVEaXNhYmxlZCIsIm5hdGl2ZUJlZm9yZSIsImdldEJ5TGFiZWwiLCJjaGVjayIsInNhdmVkIiwic3RlcHMiLCJzIiwiaW5jbHVkZXMiLCJ0b0hhdmVMZW5ndGgiLCJhZnRlciIsIm9uY2VUcmlnZ2VycyIsInNvbWUiLCJrIiwic3RhcnRzV2l0aCIsInJlbG9hZCIsIlJlZ0V4cCIsImNvbGQiLCJmcmVzaCIsImJ5dGVzIiwiY2xvbmUiLCJmaW5kIiwib3JpZ2luYWxBY2NlcHRhbmNlIiwiZml4dHVyZVNIQTI1NiIsImdpdmVuIiwib25jZSIsIndoZW4iLCJzdGF0ZU9ubHlVcGRhdGVOb0VmZmVjdCIsImV2YWx1YXRlT25seU5vRWZmZWN0IiwiZXhwbGljaXRFbnRlckV4YWN0bHlPbmUiLCJzYW1lT2NjdXJyZW5jZUlkIiwiZHVwbGljYXRlU3RhdGVUcmFjZUFuZEhpc3RvcnlVbmNoYW5nZWQiLCJyZWVudHJ5TmV3T2NjdXJyZW5jZUJsb2NrZWQiLCJ0aGVuIiwibm9JbXBsaWNpdEF1dG9tYXRpY0V2ZW50IiwibmVnYXRpdmUiLCJub3JtYWxUcmlnZ2VyUmVxdWlyZWQiLCJkdXBsaWNhdGVBbmRPbmNlUnVuU2FmZSIsIm5hdGl2ZVRyaWFsUmVhZE9ubHkiLCJleGFjdER1cGxpY2F0ZVN0YXRlIiwiY29sZE5ld0Nsb25lIiwicGh5c2ljYWwiLCJ3aG9sZUNhc2VQYXNzSW5mZXJyZWQiLCJhZmZpbml0eSIsInNjZW5lIiwibWVyZ2UiLCJrZXlFZmZlY3QiLCJhZmZFZmZlY3QiLCJyZXNldEtleSIsInJlYXNvbiIsInJlc2V0QWZmIiwiZ290Iiwibm9uZSIsImtlZXAiLCJyZXNldCIsInRyYWNlcyIsInRyYWNlUGlucyIsInJvdXRlIiwidG9IYXZlVGV4dCIsInNhdmVkUGluIiwiY29udGVudCIsImNvbnRlbnRIYXNoIiwiZXZlcnkiLCJjb21wYXJpc29uIiwiY29tcGFyZUNoZWNrcyIsInRvSGF2ZUNvdW50IiwiaSIsImxlbmd0aCIsIm50aCIsImNvbXBhcmlzb25UZXh0IiwiaW5uZXJUZXh0IiwidXNhZ2UiLCJoYXNUZXh0IiwiZmlyc3QiLCJmaXhlZENhdXNlIiwidmVyc2lvbkxhYmVsIiwibGFzdCIsInJlc2V0VHJhY2VzIiwiYmVmb3JlIiwidG9Db250YWluIiwidHdvS2V5UGF0aHMiLCJpbml0aWFsQWZmaW5pdHkiLCJzYW1lRWRpdGlvbiIsIm5vcm1hbEJvdGhQYXRoc1JlYWNoZWRTYW1lTWVyZ2UiLCJub3JtYWxTYXZlZENvbXBhcmlzb24iLCJjaGFuZ2VTb3VyY2VPcGVuZWQiLCJleHBsaWNpdFJlc2V0Qm90aFBhdGhzIiwiZ290NVZzTm9uZTBQcmVzZXJ2ZWRXaXRob3V0UmVzZXQiLCJleHBsaWNpdFJlc2V0VmFyaWFibGVWYWx1ZXNTYW1lIiwibm9JbXBsaWNpdE1lcmdlUmVzZXQiLCJzb3VyY2VSZWFzb25zQW5kVHJhY2VDaGFuZ2VzUHJlc2VydmVkIiwib3JpZ2luYWxGaXhlZEVkaXRpb25VbmNoYW5nZWQiLCJzYXZlZFBpbkJpbmRpbmdzIiwibWFwIiwiZnVsbENvbnRlbnRFcXVhbE9yaWdpbmFsIiwic2FtZUhhc2hlZFNvdXJjZUVkaXRpb25EZXNwaXRlTmV3U2F2ZVBpbklEcyIsInQiLCJtb25leSIsIm1lbW9yeSIsInNjZW5lcyIsIm1vZGUiLCJzY2VuZUlkcyIsInNsaWNlIiwiY2FuZGlkYXRlIiwicmFuZG9tIiwiYWRkTW9uZXkiLCJyZW1lbWJlciIsInplcm8iLCJ6ZXJvRW5kIiwiZmFsc2VFZGdlIiwiY29uZGl0aW9uIiwiZmlyc3RTYXZlZCIsInNlZW5JZHMiLCJmaXJzdFJhbmRvbUhlYWRpbmciLCJvYnNlcnZlZERyYXciLCJyYW5kb21TYXZlZCIsInJhbmRvbVRyYWNlIiwicm5nUG9zaXRpb24iLCJ0b0JlR3JlYXRlclRoYW4iLCJsb29wTnVtYmVyIiwibm90IiwiZmFsbGJhY2tJZCIsInJlcGxheUJ1dHRvbnMiLCJmaXJzdFJldmlzaXQiLCJyYW5kb21DYW5kaWRhdGVDb3VudCIsInJ1bk1vbmV5IiwiYWNyb3NzUnVuc01lbW9yeSIsImZpcnN0VGhlblJldmlzaXRUaGVuVHdvVW5kbyIsInJhbmRvbVRoZW5VbmRvVGhlblNhbWVEcmF3IiwibmV4dExvb3BNb25leTEwTWVtb3J5VHJ1ZSIsImFsbFJlc2V0TW9uZXkxME1lbW9yeUZhbHNlIiwiaW1wb3J0YW50Rmlyc3RJbmZvcm1hdGlvblByZXNlcnZlZCIsInNhdmVkUm5nUG9zaXRpb25BbmRTZWVuSWRzUmVwbGF5ZWQiLCJ6ZXJvRmFsc2VDYW5kaWRhdGVzQmxvY2tlZE5vdFRlcm1pbmFsIiwiZXhwbGljaXRGYWxsYmFja05vcm1hbEVkaXRBbmRBZHZhbmNlIiwiZml4ZWRPbGRFZGl0aW9uVW5jaGFuZ2VkIiwiZmlyc3RUcmFjZSJdLCJzb3VyY2VzIjpbImxpdGVyYWwtZmxvdy1iZWhhdmlvcnMuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3Rlc3QsZXhwZWN0LHR5cGUgUGFnZX0gZnJvbSAnQHBsYXl3cmlnaHQvdGVzdCc7XG5pbXBvcnQge2NyZWF0ZUVudGl0eSxjcmVhdGVQcm9qZWN0LG5ld0lkLHRleHRUb1JpY2hUZXh0LHZhbGlkYXRlUHJvamVjdH0gZnJvbSAnLi4vY2FuZGlkYXRlL3NyYy9kb21haW4vbW9kZWwnO1xuaW1wb3J0IHtjcmVhdGVXb3JsZFNuYXBzaG90fSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL2RvbWFpbi93b3JsZCc7XG5pbXBvcnQge3N0YXJ0VHJpYWwsc3RlcFRyaWFsfSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL2RvbWFpbi9ydW50aW1lJztcbmltcG9ydCB7ZXZhbHVhdGVDb25kaXRpb259IGZyb20gJy4uL2NhbmRpZGF0ZS9zcmMvZG9tYWluL2NvbmRpdGlvbnMnO1xuaW1wb3J0IHtwcmVwYXJlUmVhY3Rpb25zfSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL2RvbWFpbi9yZWFjdGlvbnMnO1xuaW1wb3J0IHR5cGUge0VudGl0eSxFbnRpdHlLaW5kLEVudGl0eURhdGFNYXAsUHJvamVjdERhdGF9IGZyb20gJy4uL2NhbmRpZGF0ZS9zcmMvZG9tYWluL3R5cGVzJztcbmltcG9ydCB7c2VlZCxuYXYsYmFja3VwLGR1cmFibGUsZGlnZXN0LGV2aWRlbmNlfSBmcm9tICcuL2NvbW1vbic7XG5pbXBvcnQge3JlYWRlcixiZWdpbixyZWNvcmRUcmlhbCxvcGVuUmVjb3JkLGZyZXNoUm91bmR0cmlwLGVkaXREYXRhLHNhdmVFZGl0b3J9IGZyb20gJy4vZXh0ZW5kZWQtc3VwcG9ydCc7XG5mdW5jdGlvbiBhZGQ8SyBleHRlbmRzIEVudGl0eUtpbmQ+KHA6UHJvamVjdERhdGEsa2luZDpLLG5hbWU6c3RyaW5nLGRhdGE6UGFydGlhbDxFbnRpdHlEYXRhTWFwW0tdPj17fSk6RW50aXR5PEs+e2NvbnN0IGU9Y3JlYXRlRW50aXR5KHAucHJvamVjdElkLGtpbmQsbmFtZSxkYXRhKTtlLnN0YXR1cz0nY29uZmlybWVkJztwLmVudGl0aWVzLnB1c2goZSk7cmV0dXJuIGU7fVxuZnVuY3Rpb24gdmFyaWFibGUocGFnZTpQYWdlLG5hbWU6c3RyaW5nKXtyZXR1cm4gcGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZXMgLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhczpwYWdlLmdldEJ5VGV4dChuYW1lLHtleGFjdDp0cnVlfSl9KTt9XG5hc3luYyBmdW5jdGlvbiBsYXN0VHJhY2UocGFnZTpQYWdlKXtjb25zdCBmaWxlPWF3YWl0IGJhY2t1cChwYWdlKSx0cmFjZT1maWxlLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbHRlcigoZSk6ZSBpcyBFbnRpdHk8J3RyYWNlJz49PmUua2luZD09PSd0cmFjZScpLmF0KC0xKSE7cmV0dXJuIHtmaWxlLHRyYWNlfTt9XG5cbnRlc3QoJ29yaWdpbmFsIEFULUYxNCBrZXkgZ2F0ZSArIGVudGVyIHRyaWdnZXIgb25jZT1ydW46IHN0YXRlLW9ubHkgdXBkYXRlL2V2YWx1YXRpb24gZG8gbm90IGZpcmU7IHNhbWUgb2NjdXJyZW5jZSBkdXBsaWNhdGUgKyByZXZpc2l0IGFyZSBzdG9wcGVkOyBub3JtYWwgc2F2ZWQgdHJhY2UvY29sZC9uZXdjbG9uZScsYXN5bmMoe3BhZ2UsYnJvd3Nlcn0saW5mbyk9PntcbiB0ZXN0LnNldFRpbWVvdXQoMjQwMDAwKTtsZXQgcD1jcmVhdGVQcm9qZWN0KCfljp9GMTQg6Y2144Go5YWl5a6kb25jZT1ydW4nKTtcbiBjb25zdCBrZXk9YWRkKHAsJ3ZhcmlhYmxlJywn6Y2144GC44KKJyx7a2V5OidoYXNfa2V5Jyx2YWx1ZVR5cGU6J2Jvb2xlYW4nLHNjb3BlOidydW4nLGluaXRpYWw6e3R5cGU6J2Jvb2xlYW4nLHZhbHVlOmZhbHNlfX0pLGNvdW50PWFkZChwLCd2YXJpYWJsZScsJ+WFpeWupOWHuuadpeS6i+OBruWKueaenOWbnuaVsCcse2tleTonZW50ZXJlZCcsdmFsdWVUeXBlOidpbnRlZ2VyJyxzY29wZToncnVuJyxpbml0aWFsOnt0eXBlOidpbnRlZ2VyJyx2YWx1ZTowfSxhbGxvd2VkOnttaW46MCxtYXg6MTAwfX0pLHJvb21TY2VuZT1hZGQocCwnc2NlbmUnLCfpjbXjgaDjgZHjgafjga/lh7rmnaXkuovjgpLlrp/ooYzjgZfjgarjgYTpg6jlsYsnLHtib2R5OnRleHRUb1JpY2hUZXh0KCflhaXlrqTjgajjgYTjgYbmmI7npLrjgZfjgZ/jgY3jgaPjgYvjgZHjgpLlvoXjgaTwn5iA44CCJyl9KTtcbiBjb25zdCBlbnRyeT1hZGQocCwnZmxvd19ub2RlJywn6Y2144KS5b6X44KL54q25oWL5pu05paw44Gu5YWl5Y+jJyx7bm9kZVR5cGU6J2VudHJ5J30pLHJvb209YWRkKHAsJ2Zsb3dfbm9kZScsJ29uY2U9cnVu44Gu5YWl5a6k5Ye65p2l5LqLJyx7bm9kZVR5cGU6J3NjZW5lJyxzY2VuZUlkOnJvb21TY2VuZS5pZCxnYXRlOntvcDonY29tcGFyZScsdmFyaWFibGVJZDprZXkuaWQsY29tcGFyYXRvcjonZXEnLHZhbHVlOnt0eXBlOidib29sZWFuJyx2YWx1ZTp0cnVlfX0sdHJpZ2dlcjp7aWQ6bmV3SWQoKSxldmVudDonZW50ZXInLGV2ZW50S2V5OiflhaXlrqQnLHJlcGVhdDonb25jZScsc2NvcGU6J3J1bid9fSksZW5kPWFkZChwLCdmbG93X25vZGUnLCflhaXlrqTjga7norroqo3ntYLnq68nLHtub2RlVHlwZTondGVybWluYWwnLHRlcm1pbmFsUmVhc29uOiflhaXlrqTjgajph43opIfmi5LlkKbjgpLnorroqo3jgZfjgZ8nfSksZ2V0S2V5PWFkZChwLCdlZmZlY3QnLCfpjbXjgpLlvpfjgovjgaDjgZEnLHtvcGVyYXRpb246J3NldCcsdGFyZ2V0SWQ6a2V5LmlkLHZhbHVlOnt0eXBlOidib29sZWFuJyx2YWx1ZTp0cnVlfX0pLGVudGVyRWZmZWN0PWFkZChwLCdlZmZlY3QnLCfmmI7npLrlhaXlrqTmmYLjgaDjgZHliqDnrpcnLHtvcGVyYXRpb246J2FkZCcsdGFyZ2V0SWQ6Y291bnQuaWQsdmFsdWU6e3R5cGU6J2ludGVnZXInLHZhbHVlOjF9fSk7XG4gY29uc3QgZ2V0PWFkZChwLCdmbG93X2VkZ2UnLCfpjbXjga7nirbmhYvjgaDjgZHjgpLmm7TmlrAnLHtmcm9tSWQ6ZW50cnkuaWQsdG9JZDpyb29tLmlkLGxhYmVsOifpjbXjga7nirbmhYvjgaDjgZHjgpLmm7TmlrAnLGVmZmVjdElkczpbZ2V0S2V5LmlkXX0pLGxlYXZlPWFkZChwLCdmbG93X2VkZ2UnLCflhaXlrqTjgpLlrp/ooYzjgZfjgablhaXlj6PjgbjmiLvjgosnLHtmcm9tSWQ6cm9vbS5pZCx0b0lkOmVudHJ5LmlkLGxhYmVsOiflhaXlrqTjgpLlrp/ooYzjgZfjgablhaXlj6PjgbjmiLvjgosnLGVmZmVjdElkczpbZW50ZXJFZmZlY3QuaWRdfSksZmluaXNoPWFkZChwLCdmbG93X2VkZ2UnLCfkuIDlm57jgaDjgZHjga7ntZDmnpzjgpLkv53lrZjjgZnjgosnLHtmcm9tSWQ6ZW50cnkuaWQsdG9JZDplbmQuaWQsbGFiZWw6J+S4gOWbnuOBoOOBkeOBrue1kOaenOOCkuS/neWtmOOBmeOCiyd9KTthZGQocCwnZmxvd19ncmFwaCcsJ+mNteOBqOWFpeWupOOBruWbsycse25vZGVJZHM6W2VudHJ5LmlkLHJvb20uaWQsZW5kLmlkXSxlZGdlSWRzOltnZXQuaWQsbGVhdmUuaWQsZmluaXNoLmlkXSxlbnRyeUlkczpbZW50cnkuaWRdLGV4aXRJZHM6W2VuZC5pZF19KTtleHBlY3QodmFsaWRhdGVQcm9qZWN0KHApLm9rKS50b0JlKHRydWUpO3A9YXdhaXQgY3JlYXRlV29ybGRTbmFwc2hvdChwLCfpjbXjgajlhaXlrqTjga7lm7rlrprniYgnKTtjb25zdCBwaW49cC5zbmFwc2hvdHMuYXQoLTEpITtcbiAvLyBFeGFjdGx5IHRoZSBkZWNsYXJlZCBkdXBsaWNhdGUgb2NjdXJyZW5jZSBpcyBjaGVja2VkIGFnYWluc3QgdGhlIHNhbWUgbm9ybWFsIGZpeHR1cmUsIHNlcGFyYXRlbHkgZnJvbSB0aGUgVUkncyBvbmUtb3BlcmF0aW9uIGd1YXJkLlxuIGNvbnN0IHN0YXJ0ZWQ9c3RhcnRUcmlhbChwLHtlbnRyeUlkOmVudHJ5LmlkLGNvbnRlbnRWZXJzaW9uSWQ6cGluLmlkLHNlZWQ6J29yaWdpbmFsLWVudGVyJ30pLGdhaW5lZD1zdGVwVHJpYWwocCxzdGFydGVkLHtlZGdlSWQ6Z2V0LmlkfSk7ZXhwZWN0KGdhaW5lZC5zdGF0ZS52YXJpYWJsZVZhbHVlc1tjb3VudC5pZF0pLnRvRXF1YWwoe3R5cGU6J2ludGVnZXInLHZhbHVlOjB9KTtjb25zdCBldmFsdWF0ZWQ9ZXZhbHVhdGVDb25kaXRpb24ocm9vbS5kYXRhLmdhdGUhLHtzdGF0ZTpnYWluZWQuc3RhdGUsdmFyaWFibGVzOnAuZW50aXRpZXMuZmlsdGVyKChlKTplIGlzIEVudGl0eTwndmFyaWFibGUnPj0+ZS5raW5kPT09J3ZhcmlhYmxlJyksZW50aXRpZXM6cC5lbnRpdGllc30pO2V4cGVjdChldmFsdWF0ZWQudmFsdWUpLnRvQmUoJ3RydWUnKTtleHBlY3QoZ2FpbmVkLnN0YXRlLnZhcmlhYmxlVmFsdWVzW2NvdW50LmlkXSkudG9FcXVhbCh7dHlwZTonaW50ZWdlcicsdmFsdWU6MH0pO2NvbnN0IG5vVHJpZ2dlcj1zdGVwVHJpYWwocCxnYWluZWQse2VkZ2VJZDpsZWF2ZS5pZH0pO2V4cGVjdChub1RyaWdnZXIuc3RhdGUudmFyaWFibGVWYWx1ZXNbY291bnQuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZTowfSk7Y29uc3QgZXZlbnQ9e3RyaWdnZXJJZDpyb29tLmRhdGEudHJpZ2dlciEuaWQhLGV2ZW50OidlbnRlcicgYXMgY29uc3QsZXZlbnRLZXk6J+WFpeWupCcsb2NjdXJyZW5jZUlkOidvcmlnaW5hbC1zYW1lLW9jY3VycmVuY2UnfTtjb25zdCBmaXJlZD1zdGVwVHJpYWwocCxnYWluZWQse2VkZ2VJZDpsZWF2ZS5pZCxldmVudH0pLGR1cGxpY2F0ZT1zdGVwVHJpYWwocCxmaXJlZCx7ZWRnZUlkOmxlYXZlLmlkLGV2ZW50fSk7ZXhwZWN0KGR1cGxpY2F0ZS5zdGF0ZSkudG9FcXVhbChmaXJlZC5zdGF0ZSk7ZXhwZWN0KGR1cGxpY2F0ZS50cmFjZSkudG9FcXVhbChmaXJlZC50cmFjZSk7ZXhwZWN0KGR1cGxpY2F0ZS5oaXN0b3J5KS50b0VxdWFsKGZpcmVkLmhpc3RvcnkpO2V4cGVjdChmaXJlZC5zdGF0ZS52YXJpYWJsZVZhbHVlc1tjb3VudC5pZF0pLnRvRXF1YWwoe3R5cGU6J2ludGVnZXInLHZhbHVlOjF9KTtjb25zdCByZWVudGVyZWQ9c3RlcFRyaWFsKHAsZmlyZWQse2VkZ2VJZDpnZXQuaWR9KSxhZ2Fpbj1zdGVwVHJpYWwocCxyZWVudGVyZWQse2VkZ2VJZDpsZWF2ZS5pZCxldmVudDp7Li4uZXZlbnQsb2NjdXJyZW5jZUlkOiduZXctcmVlbnRyeSd9fSk7ZXhwZWN0KGFnYWluLnN0YXR1cykudG9CZSgnYmxvY2tlZCcpO2V4cGVjdChhZ2Fpbi5zdGF0ZS52YXJpYWJsZVZhbHVlc1tjb3VudC5pZF0pLnRvRXF1YWwoe3R5cGU6J2ludGVnZXInLHZhbHVlOjF9KTtcbiBjb25zdCBpbnB1dD1hd2FpdCBzZWVkKHBhZ2UscCk7YXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IGJlZ2luKHBhZ2UsZW50cnkuaWQscGluLmlkLCdvcmlnaW5hbC1lbnRlcicpO2F3YWl0IGV4cGVjdCh2YXJpYWJsZShwYWdlLGNvdW50Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCcwJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Z2V0LmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdCh2YXJpYWJsZShwYWdlLGtleS5uYW1lKSkudG9Db250YWluVGV4dCgndHJ1ZScpO2F3YWl0IGV4cGVjdCh2YXJpYWJsZShwYWdlLGNvdW50Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCcwJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmxlYXZlLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KSkudG9CZURpc2FibGVkKCk7Y29uc3QgbmF0aXZlQmVmb3JlPWF3YWl0IGR1cmFibGUocGFnZSk7YXdhaXQgcGFnZS5nZXRCeUxhYmVsKCflrqPoqIDjgZfjgZ/jgY3jgaPjgYvjgZHjgIzlhaXlrqTjgI3jgafpgLLjgoAnLHtleGFjdDp0cnVlfSkuY2hlY2soKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpsZWF2ZS5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QodmFyaWFibGUocGFnZSxjb3VudC5uYW1lKSkudG9Db250YWluVGV4dCgnMScpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmdldC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+Wuo+iogOOBl+OBn+OBjeOBo+OBi+OBkeOAjOWFpeWupOOAjeOBp+mAsuOCgCcse2V4YWN0OnRydWV9KS5jaGVjaygpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmxlYXZlLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItaXNzdWUnKSkudG9Db250YWluVGV4dCgn5LiA5Zue6ZmQ44KKJyk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsY291bnQubmFtZSkpLnRvQ29udGFpblRleHQoJzEnKTtleHBlY3QoYXdhaXQgZHVyYWJsZShwYWdlKSkudG9FcXVhbChuYXRpdmVCZWZvcmUpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifkuIDmiYvmiLvjgosnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmZpbmlzaC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCByZWNvcmRUcmlhbChwYWdlKTtjb25zdCBzYXZlZD1hd2FpdCBsYXN0VHJhY2UocGFnZSk7ZXhwZWN0KHNhdmVkLnRyYWNlLmRhdGEuc3RlcHMuZmlsdGVyKHM9PnMuZWRnZUlkcy5pbmNsdWRlcyhsZWF2ZS5pZCkpKS50b0hhdmVMZW5ndGgoMSk7ZXhwZWN0KHNhdmVkLnRyYWNlLmRhdGEuc3RlcHMuYXQoLTEpIS5hZnRlci52YXJpYWJsZVZhbHVlc1tjb3VudC5pZF0pLnRvRXF1YWwoe3R5cGU6J2ludGVnZXInLHZhbHVlOjF9KTtleHBlY3Qoc2F2ZWQudHJhY2UuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLm9uY2VUcmlnZ2Vycy5zb21lKGs9Pmsuc3RhcnRzV2l0aCgndHJpZ2dlcjpydW46JykpKS50b0JlKHRydWUpO1xuIGF3YWl0IHBhZ2UucmVsb2FkKCk7YXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IHBhZ2UubG9jYXRvcignLnNhdmVkLXRyYWNlcycpLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpuZXcgUmVnRXhwKCdeJytzYXZlZC50cmFjZS5uYW1lKX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsY291bnQubmFtZSkpLnRvQ29udGFpblRleHQoJzEnKTtjb25zdCBjb2xkPWF3YWl0IGJhY2t1cChwYWdlKSxmcmVzaD1hd2FpdCBmcmVzaFJvdW5kdHJpcChicm93c2VyLGNvbGQuYnl0ZXMpLGNsb25lPWF3YWl0IGZyZXNoUm91bmR0cmlwKGJyb3dzZXIsY29sZC5ieXRlcywnY2xvbmUnKTtleHBlY3QoZnJlc2gucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmluZChlPT5lLmlkPT09c2F2ZWQudHJhY2UuaWQpKS50b0VxdWFsKHNhdmVkLnRyYWNlKTtleHBlY3QoY2xvbmUucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmlsdGVyKGU9PmUua2luZD09PSd0cmFjZScpKS50b0hhdmVMZW5ndGgoMSk7XG4gYXdhaXQgZXZpZGVuY2UoaW5mbywnRjE0LW9yaWdpbmFsLXRyaWdnZXInLHtvcmlnaW5hbEFjY2VwdGFuY2U6J0FULUYxNCcsZml4dHVyZVNIQTI1NjpkaWdlc3QoaW5wdXQpLGdpdmVuOntnYXRlOifpjbXjgYLjgoonLHRyaWdnZXI6J+WFpeWupCcsb25jZToncnVuJ30sd2hlbjp7c3RhdGVPbmx5VXBkYXRlTm9FZmZlY3Q6dHJ1ZSxldmFsdWF0ZU9ubHlOb0VmZmVjdDp0cnVlLGV4cGxpY2l0RW50ZXJFeGFjdGx5T25lOnRydWUsc2FtZU9jY3VycmVuY2VJZDonb3JpZ2luYWwtc2FtZS1vY2N1cnJlbmNlJyxkdXBsaWNhdGVTdGF0ZVRyYWNlQW5kSGlzdG9yeVVuY2hhbmdlZDp0cnVlLHJlZW50cnlOZXdPY2N1cnJlbmNlQmxvY2tlZDp0cnVlfSx0aGVuOntub0ltcGxpY2l0QXV0b21hdGljRXZlbnQ6dHJ1ZX0sbmVnYXRpdmU6e25vcm1hbFRyaWdnZXJSZXF1aXJlZDp0cnVlLGR1cGxpY2F0ZUFuZE9uY2VSdW5TYWZlOnRydWUsbmF0aXZlVHJpYWxSZWFkT25seTp0cnVlfSxleGFjdER1cGxpY2F0ZVN0YXRlOmZpcmVkLnN0YXRlLHRyYWNlOnNhdmVkLnRyYWNlLmRhdGEsY29sZE5ld0Nsb25lOnRydWUscGh5c2ljYWw6J25vdF9ydW4nLHdob2xlQ2FzZVBhc3NJbmZlcnJlZDpmYWxzZX0pO1xufSk7XG5cbnRlc3QoJ29yaWdpbmFsIEFULUYxNiB0d28ga2V5L25vLWtleSByb3V0ZXMgbWVyZ2Ugd2l0aCBpbml0aWFsIGFmZmluaXR5MCwgY2F1c2VzIHJlb3Blbjsgbm8gaW1wbGljaXQgcmVzZXQgdnMgZXhwbGljaXQgcmVzZXQ7IHNhbWUgZml4ZWQgdHJhY2UgY29tcGFyaXNvbi9jb2xkL25ld2Nsb25lJyxhc3luYyh7cGFnZSxicm93c2VyfSxpbmZvKT0+e1xuIHRlc3Quc2V0VGltZW91dCgzMDAwMDApO2xldCBwPWNyZWF0ZVByb2plY3QoJ+WOn0YxNiDpjbXkuozntYzot6/jgajmmI7npLpyZXNldCcpO2NvbnN0IGtleT1hZGQocCwndmFyaWFibGUnLCfpjbXjgYLjgoonLHtrZXk6J2tleScsdmFsdWVUeXBlOidib29sZWFuJyxzY29wZToncnVuJyxpbml0aWFsOnt0eXBlOidib29sZWFuJyx2YWx1ZTpmYWxzZX19KSxhZmZpbml0eT1hZGQocCwndmFyaWFibGUnLCflpb3mhJ/luqYwJyx7a2V5OidhZmZpbml0eScsdmFsdWVUeXBlOidpbnRlZ2VyJyxzY29wZToncnVuJyxpbml0aWFsOnt0eXBlOidpbnRlZ2VyJyx2YWx1ZTowfSxhbGxvd2VkOnttaW46MCxtYXg6MTB9fSksc2NlbmU9YWRkKHAsJ3NjZW5lJywn5ZCM44GY5ZCI5rWB5b6M44Gu5aC06Z2iJyx7Ym9keTp0ZXh0VG9SaWNoVGV4dCgn6Y2144Go5aW95oSf5bqm44Gu5beu44KS5raI44GZ44GL44CB5Lya6Kmx44G45Y+N5pig44GZ44KL44GL5L2c6ICF44GM5rG644KB44KL44CCJyl9KTtjb25zdCBlbnRyeT1hZGQocCwnZmxvd19ub2RlJywn5LqM57WM6Lev44Gu5YWl5Y+jJyx7bm9kZVR5cGU6J2VudHJ5J30pLG1lcmdlPWFkZChwLCdmbG93X25vZGUnLCfkuozntYzot6/jgYzlkIjmtYHjgZnjgovngrknLHtub2RlVHlwZTonY2hvaWNlJyxzY2VuZUlkOnNjZW5lLmlkfSksZW5kPWFkZChwLCdmbG93X25vZGUnLCflkIjmtYHjga7lkIzjgZjntYLngrknLHtub2RlVHlwZTondGVybWluYWwnLHRlcm1pbmFsUmVhc29uOiflkIjmtYHjga7lt67jgajmmI7npLrlirnmnpzjgpLoqJjpjLLjgZfjgZ8nfSksa2V5RWZmZWN0PWFkZChwLCdlZmZlY3QnLCfpjbXjgpLlvpfjgZ/lpInmm7TlhYMnLHtvcGVyYXRpb246J3NldCcsdGFyZ2V0SWQ6a2V5LmlkLHZhbHVlOnt0eXBlOidib29sZWFuJyx2YWx1ZTp0cnVlfX0pLGFmZkVmZmVjdD1hZGQocCwnZWZmZWN0Jywn5aW95oSf5bqm44KSNeOBuOWkieabtOOBl+OBn+WFgycse29wZXJhdGlvbjonYWRkJyx0YXJnZXRJZDphZmZpbml0eS5pZCx2YWx1ZTp7dHlwZTonaW50ZWdlcicsdmFsdWU6NX19KSxyZXNldEtleT1hZGQocCwnZWZmZWN0Jywn6Y2144Gu5beu44KS5piO56S6cmVzZXQnLHtvcGVyYXRpb246J3Jlc2V0Jyx0YXJnZXRJZDprZXkuaWQsdmFsdWU6e3R5cGU6J2Jvb2xlYW4nLHZhbHVlOmZhbHNlfSxyZWFzb246J+S9nOiAheOBjOWQiOa1geW+jOOBruW3ruOCkuaYjuekuuOBl+OBpuino+a2iOOBmeOCiyd9KSxyZXNldEFmZj1hZGQocCwnZWZmZWN0Jywn5aW95oSf5bqm44Gu5beu44KS5piO56S6cmVzZXQnLHtvcGVyYXRpb246J3Jlc2V0Jyx0YXJnZXRJZDphZmZpbml0eS5pZCx2YWx1ZTp7dHlwZTonaW50ZWdlcicsdmFsdWU6MH0scmVhc29uOiflpb3mhJ/luqbjgpLliJ3mnJ8w44G45oi744GZ44Go5L2c6ICF44GM5rG644KB44GfJ30pO1xuIGNvbnN0IGdvdD1hZGQocCwnZmxvd19lZGdlJywn6Y2144KS5Y+W5b6X44GX44Gm5aW95oSf5bqmNeOBrue1jOi3rycse2Zyb21JZDplbnRyeS5pZCx0b0lkOm1lcmdlLmlkLGxhYmVsOifpjbXjgpLlj5blvpfjgZfjgablpb3mhJ/luqY144Gu57WM6LevJyxlZmZlY3RJZHM6W2tleUVmZmVjdC5pZCxhZmZFZmZlY3QuaWRdfSksbm9uZT1hZGQocCwnZmxvd19lZGdlJywn6Y215pyq5Y+W5b6X44Gn5aW95oSf5bqmMOOBrue1jOi3rycse2Zyb21JZDplbnRyeS5pZCx0b0lkOm1lcmdlLmlkLGxhYmVsOifpjbXmnKrlj5blvpfjgaflpb3mhJ/luqYw44Gu57WM6LevJ30pLGtlZXA9YWRkKHAsJ2Zsb3dfZWRnZScsJ+WQiOa1geOBruW3ruOCkuS/neOBo+OBpue1guOBiOOCiycse2Zyb21JZDptZXJnZS5pZCx0b0lkOmVuZC5pZCxsYWJlbDon5ZCI5rWB44Gu5beu44KS5L+d44Gj44Gm57WC44GI44KLJ30pLHJlc2V0PWFkZChwLCdmbG93X2VkZ2UnLCfkvZzogIXjgYzmmI7npLrjgZfjgZ9yZXNldOOBp+e1guOBiOOCiycse2Zyb21JZDptZXJnZS5pZCx0b0lkOmVuZC5pZCxsYWJlbDon5L2c6ICF44GM5piO56S644GX44GfcmVzZXTjgafntYLjgYjjgosnLGVmZmVjdElkczpbcmVzZXRLZXkuaWQscmVzZXRBZmYuaWRdfSk7YWRkKHAsJ2Zsb3dfZ3JhcGgnLCfpjbXlj5blvpfjgajmnKrlj5blvpfjga7lm7MnLHtub2RlSWRzOltlbnRyeS5pZCxtZXJnZS5pZCxlbmQuaWRdLGVkZ2VJZHM6W2dvdC5pZCxub25lLmlkLGtlZXAuaWQscmVzZXQuaWRdLGVudHJ5SWRzOltlbnRyeS5pZF0sZXhpdElkczpbZW5kLmlkXX0pO3A9YXdhaXQgY3JlYXRlV29ybGRTbmFwc2hvdChwLCfkuozntYzot6/jga7lkIzjgZjlm7rlrprniYgnKTtjb25zdCBwaW49cC5zbmFwc2hvdHMuYXQoLTEpITtjb25zdCBpbnB1dD1hd2FpdCBzZWVkKHBhZ2UscCksdHJhY2VzOkVudGl0eTwndHJhY2UnPltdPVtdLHRyYWNlUGluczp0eXBlb2YgcGluW109W107XG4gZm9yKGNvbnN0IHJvdXRlIG9mIFtnb3Qsbm9uZV0pe2F3YWl0IHJlYWRlcihwYWdlKTthd2FpdCBiZWdpbihwYWdlLGVudHJ5LmlkLHBpbi5pZCwnbWVyZ2Utc2VlZCcpO2F3YWl0IGV4cGVjdCh2YXJpYWJsZShwYWdlLGFmZmluaXR5Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCcwJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6cm91dGUuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci1zaGVldC1oZWFkaW5nIGgyJykpLnRvSGF2ZVRleHQoc2NlbmUubmFtZSk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsYWZmaW5pdHkubmFtZSkpLnRvQ29udGFpblRleHQocm91dGU9PT1nb3Q/JzUnOicwJyk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2Usa2V5Lm5hbWUpKS50b0NvbnRhaW5UZXh0KHJvdXRlPT09Z290Pyd0cnVlJzonZmFsc2UnKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTprZWVwLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IHJlY29yZFRyaWFsKHBhZ2UpO2NvbnN0IHNhdmVkPWF3YWl0IGxhc3RUcmFjZShwYWdlKTt0cmFjZXMucHVzaChzYXZlZC50cmFjZSk7Y29uc3Qgc2F2ZWRQaW49c2F2ZWQuZmlsZS5wYXJzZWQucHJvamVjdC5zbmFwc2hvdHMuZmluZChwPT5wLmlkPT09c2F2ZWQudHJhY2UuZGF0YS5jb250ZW50VmVyc2lvbklkKSE7ZXhwZWN0KHNhdmVkUGluLmNvbnRlbnQpLnRvRXF1YWwocGluLmNvbnRlbnQpO2V4cGVjdChzYXZlZFBpbi5jb250ZW50SGFzaCkudG9CZShwaW4uY29udGVudEhhc2gpO3RyYWNlUGlucy5wdXNoKHNhdmVkUGluKTt9XG4gZXhwZWN0KHRyYWNlc1swXS5kYXRhLnN0ZXBzLmF0KC0xKSEuYWZ0ZXIudmFyaWFibGVWYWx1ZXNbYWZmaW5pdHkuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZTo1fSk7ZXhwZWN0KHRyYWNlc1sxXS5kYXRhLnN0ZXBzLmF0KC0xKSEuYWZ0ZXIudmFyaWFibGVWYWx1ZXNbYWZmaW5pdHkuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZTowfSk7ZXhwZWN0KHRyYWNlUGlucy5ldmVyeShwPT5wLmNvbnRlbnRIYXNoPT09cGluLmNvbnRlbnRIYXNoKSkudG9CZSh0cnVlKTthd2FpdCByZWFkZXIocGFnZSk7Y29uc3QgY29tcGFyaXNvbj1wYWdlLmxvY2F0b3IoJy5yZWdyZXNzaW9uLXBhdGhzJyk7Y29uc3QgY29tcGFyZUNoZWNrcz1jb21wYXJpc29uLmdldEJ5Um9sZSgnY2hlY2tib3gnKTthd2FpdCBleHBlY3QoY29tcGFyZUNoZWNrcykudG9IYXZlQ291bnQoMik7Zm9yKGxldCBpPTA7aTx0cmFjZXMubGVuZ3RoO2krKyl7YXdhaXQgZXhwZWN0KGNvbXBhcmVDaGVja3MubnRoKGkpLmxvY2F0b3IoJy4uJykpLnRvQ29udGFpblRleHQodHJhY2VzW2ldLm5hbWUpO2F3YWl0IGNvbXBhcmVDaGVja3MubnRoKGkpLmNoZWNrKCk7fWF3YWl0IGNvbXBhcmlzb24uZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifpgbjjgpPjgaDkuozntYzot6/jgpLlho3nlJ/jgZfjgabmr5TovIMnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChjb21wYXJpc29uKS50b0NvbnRhaW5UZXh0KCflkIzjgZjlkIjmtYHngrnjga7nirbmhYsnKTthd2FpdCBleHBlY3QoY29tcGFyaXNvbikudG9Db250YWluVGV4dCgn55Ww44Gq44KL5L2c5ZOB54mI44O75pS56KiC5beu44KS5ZCr44KAJyk7YXdhaXQgZXhwZWN0KGNvbXBhcmlzb24pLnRvQ29udGFpblRleHQoJ3ZhcmlhYmxlVmFsdWVzLicrYWZmaW5pdHkuaWQpO2F3YWl0IGV4cGVjdChjb21wYXJpc29uKS50b0NvbnRhaW5UZXh0KCd2YXJpYWJsZVZhbHVlcy4nK2tleS5pZCk7Y29uc3QgY29tcGFyaXNvblRleHQ9YXdhaXQgY29tcGFyaXNvbi5pbm5lclRleHQoKTtcbiBjb25zdCB1c2FnZT1wYWdlLmxvY2F0b3IoJ2RldGFpbHMnKS5maWx0ZXIoe2hhczpwYWdlLmxvY2F0b3IoJ3N1bW1hcnknKS5maWx0ZXIoe2hhc1RleHQ6bmV3IFJlZ0V4cCgnXicrYWZmaW5pdHkubmFtZSsnIMK3IHJ1biDCtycpfSl9KTthd2FpdCB1c2FnZS5sb2NhdG9yKCdzdW1tYXJ5JykuZmlyc3QoKS5jbGljaygpO2F3YWl0IHVzYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTphZmZFZmZlY3QubmFtZSxleGFjdDp0cnVlfSkuY2xpY2soKTtjb25zdCBmaXhlZENhdXNlPXBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnLHtuYW1lOiflm7rlrprniYjjga7lj4LnhaflhYgnLGV4YWN0OnRydWV9KTthd2FpdCBleHBlY3QoZml4ZWRDYXVzZSkudG9Db250YWluVGV4dChhZmZFZmZlY3QubmFtZSk7YXdhaXQgZXhwZWN0KGZpeGVkQ2F1c2UpLnRvQ29udGFpblRleHQodHJhY2VQaW5zWzFdLnZlcnNpb25MYWJlbCk7YXdhaXQgZml4ZWRDYXVzZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6L+mWieOBmOOCiy99KS5sYXN0KCkuY2xpY2soKTtcbiBjb25zdCByZXNldFRyYWNlczpFbnRpdHk8J3RyYWNlJz5bXT1bXTtmb3IoY29uc3Qgcm91dGUgb2YgW2dvdCxub25lXSl7YXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IGJlZ2luKHBhZ2UsZW50cnkuaWQscGluLmlkLCdtZXJnZS1zZWVkJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6cm91dGUuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6cmVzZXQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsYWZmaW5pdHkubmFtZSkpLnRvQ29udGFpblRleHQoJzAnKTthd2FpdCBleHBlY3QodmFyaWFibGUocGFnZSxrZXkubmFtZSkpLnRvQ29udGFpblRleHQoJ2ZhbHNlJyk7YXdhaXQgcmVjb3JkVHJpYWwocGFnZSk7Y29uc3Qgc2F2ZWQ9YXdhaXQgbGFzdFRyYWNlKHBhZ2UpO3Jlc2V0VHJhY2VzLnB1c2goc2F2ZWQudHJhY2UpO31mb3IoY29uc3QgdHJhY2Ugb2YgcmVzZXRUcmFjZXMpZXhwZWN0KHRyYWNlLmRhdGEuc3RlcHMuYXQoLTEpIS5hZnRlci52YXJpYWJsZVZhbHVlcykudG9FcXVhbCh0cmFjZXNbMV0uZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnZhcmlhYmxlVmFsdWVzKTtleHBlY3QocmVzZXRUcmFjZXNbMF0uZGF0YS5zdGVwcy5hdCgtMSkhLmJlZm9yZS52YXJpYWJsZVZhbHVlc1thZmZpbml0eS5pZF0pLnRvRXF1YWwoe3R5cGU6J2ludGVnZXInLHZhbHVlOjV9KTtleHBlY3QocmVzZXRUcmFjZXNbMF0uZGF0YS5zdGVwcy5hdCgtMSkhLmVkZ2VJZHMpLnRvQ29udGFpbihyZXNldC5pZCk7ZXhwZWN0KHJlc2V0LmRhdGEuZWZmZWN0SWRzKS50b0NvbnRhaW4ocmVzZXRBZmYuaWQpO1xuIGF3YWl0IHBhZ2UucmVsb2FkKCk7Y29uc3QgY29sZD1hd2FpdCBiYWNrdXAocGFnZSksZnJlc2g9YXdhaXQgZnJlc2hSb3VuZHRyaXAoYnJvd3Nlcixjb2xkLmJ5dGVzKSxjbG9uZT1hd2FpdCBmcmVzaFJvdW5kdHJpcChicm93c2VyLGNvbGQuYnl0ZXMsJ2Nsb25lJyk7ZXhwZWN0KGNvbGQucGFyc2VkLnByb2plY3Quc25hcHNob3RzLmZpbmQocz0+cy5pZD09PXBpbi5pZCkpLnRvRXF1YWwocGluKTtleHBlY3QoZnJlc2gucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmlsdGVyKGU9PmUua2luZD09PSd0cmFjZScpKS50b0VxdWFsKGNvbGQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmlsdGVyKGU9PmUua2luZD09PSd0cmFjZScpKTtleHBlY3QoY2xvbmUucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmlsdGVyKGU9PmUua2luZD09PSd0cmFjZScpKS50b0hhdmVMZW5ndGgoNCk7YXdhaXQgZXZpZGVuY2UoaW5mbywnRjE2LW9yaWdpbmFsLW1lcmdlJyx7b3JpZ2luYWxBY2NlcHRhbmNlOidBVC1GMTYnLGZpeHR1cmVTSEEyNTY6ZGlnZXN0KGlucHV0KSxnaXZlbjp7dHdvS2V5UGF0aHM6dHJ1ZSxpbml0aWFsQWZmaW5pdHk6MCxzYW1lRWRpdGlvbjpwaW4uaWQsY29udGVudEhhc2g6cGluLmNvbnRlbnRIYXNofSx3aGVuOntub3JtYWxCb3RoUGF0aHNSZWFjaGVkU2FtZU1lcmdlOnRydWUsbm9ybWFsU2F2ZWRDb21wYXJpc29uOnRydWUsY2hhbmdlU291cmNlT3BlbmVkOmFmZkVmZmVjdC5pZCxleHBsaWNpdFJlc2V0Qm90aFBhdGhzOnRydWV9LHRoZW46e2dvdDVWc05vbmUwUHJlc2VydmVkV2l0aG91dFJlc2V0OnRydWUsZXhwbGljaXRSZXNldFZhcmlhYmxlVmFsdWVzU2FtZTp0cnVlfSxuZWdhdGl2ZTp7bm9JbXBsaWNpdE1lcmdlUmVzZXQ6dHJ1ZSxzb3VyY2VSZWFzb25zQW5kVHJhY2VDaGFuZ2VzUHJlc2VydmVkOnRydWUsb3JpZ2luYWxGaXhlZEVkaXRpb25VbmNoYW5nZWQ6dHJ1ZX0sY29tcGFyaXNvblRleHQsc2F2ZWRQaW5CaW5kaW5nczp0cmFjZVBpbnMubWFwKHA9Pih7aWQ6cC5pZCxjb250ZW50SGFzaDpwLmNvbnRlbnRIYXNoLGZ1bGxDb250ZW50RXF1YWxPcmlnaW5hbDp0cnVlfSkpLHNhbWVIYXNoZWRTb3VyY2VFZGl0aW9uRGVzcGl0ZU5ld1NhdmVQaW5JRHM6dHJ1ZSx0cmFjZXM6dHJhY2VzLm1hcCh0PT50LmRhdGEpLHJlc2V0VHJhY2VzOnJlc2V0VHJhY2VzLm1hcCh0PT50LmRhdGEpLGNvbGROZXdDbG9uZTp0cnVlLHBoeXNpY2FsOidub3RfcnVuJyx3aG9sZUNhc2VQYXNzSW5mZXJyZWQ6ZmFsc2V9KTtcbn0pO1xuXG50ZXN0KCdvcmlnaW5hbCBBVC1GMjAgZmlyc3QvcmV2aXNpdCBhbmQgZXhhY3RseTMgcmFuZG9tIGNhbmRpZGF0ZXM6IHNlZWQvYmFjay9yZWFkIHBvc2l0aW9u4oaScmVjb3JkL3JlcGxheeKGknJ1biBtb25leS9hY3Jvc3MgbWVtb3J5L25ld2xvb3AvZnVsbHJlc2V04oaSemVybyBmYWxzZSBmYWxsYmFjay9jb2xkL25ld2Nsb25lJyxhc3luYyh7cGFnZSxicm93c2VyfSxpbmZvKT0+e1xuIHRlc3Quc2V0VGltZW91dCgzMDAwMDApO2xldCBwPWNyZWF0ZVByb2plY3QoJ+WOn0YyMCDliJ3lm57jg7vlho3oqKrjgajmir3pgbgz5YCZ6KOcJyk7Y29uc3QgbW9uZXk9YWRkKHAsJ3ZhcmlhYmxlJywncnVu5omA5oyB6YeRMTAnLHtrZXk6J21vbmV5Jyx2YWx1ZVR5cGU6J2ludGVnZXInLHNjb3BlOidydW4nLGluaXRpYWw6e3R5cGU6J2ludGVnZXInLHZhbHVlOjEwfSxhbGxvd2VkOnttaW46MCxtYXg6MTAwfX0pLG1lbW9yeT1hZGQocCwndmFyaWFibGUnLCdhY3Jvc3NfcnVuc+iomOaGticse2tleToncmVtZW1iZXJlZCcsdmFsdWVUeXBlOidib29sZWFuJyxzY29wZTonYWNyb3NzX3J1bnMnLGluaXRpYWw6e3R5cGU6J2Jvb2xlYW4nLHZhbHVlOmZhbHNlfX0pO2NvbnN0IHNjZW5lcz1bJ+WIneWbnuOBrumHjeimgeOBquiqrOaYjicsJ+WGjeioquOBruefreOBhOWPjeW/nCcsJ+aKvemBuOWAmeijnDEnLCfmir3pgbjlgJnoo5wyJywn5oq96YG45YCZ6KOcMyddLm1hcChuYW1lPT5hZGQocCwnc2NlbmUnLG5hbWUse2JvZHk6dGV4dFRvUmljaFRleHQobmFtZSsn44Gu5pys5paH8J+YgCcpfSkpO2NvbnN0IGZpcnN0PXByZXBhcmVSZWFjdGlvbnMocCx7bW9kZTonZmlyc3RfcmV2aXNpdCcsc2NlbmVJZHM6c2NlbmVzLnNsaWNlKDAsMikubWFwKHM9PnMuaWQpLG5hbWU6J+WIneWbnuODu+WGjeioquOBruWOn+ezu+WIlyd9KTtwPWZpcnN0LmNhbmRpZGF0ZTtjb25zdCByYW5kb209cHJlcGFyZVJlYWN0aW9ucyhwLHttb2RlOidyYW5kb20nLHNjZW5lSWRzOnNjZW5lcy5zbGljZSgyKS5tYXAocz0+cy5pZCksbmFtZTon5oq96YG4M+WAmeijnOOBruWOn+ezu+WIlyd9KTtwPXJhbmRvbS5jYW5kaWRhdGU7Y29uc3QgYWRkTW9uZXk9YWRkKHAsJ2VmZmVjdCcsJ+aKvemBuOWPjeW/nOOBp+aJgOaMgemHkTE1Jyx7b3BlcmF0aW9uOidhZGQnLHRhcmdldElkOm1vbmV5LmlkLHZhbHVlOnt0eXBlOidpbnRlZ2VyJyx2YWx1ZTo1fX0pLHJlbWVtYmVyPWFkZChwLCdlZmZlY3QnLCfph43opoHmg4XloLHjga7lkajlm57oqJjmhrYnLHtvcGVyYXRpb246J3NldCcsdGFyZ2V0SWQ6bWVtb3J5LmlkLHZhbHVlOnt0eXBlOidib29sZWFuJyx2YWx1ZTp0cnVlfX0pO2Zvcihjb25zdCBlIG9mIHAuZW50aXRpZXMpaWYoZS5raW5kPT09J2Zsb3dfZWRnZScmJmUuZGF0YS5mcm9tSWQ9PT1yYW5kb20uZW50cnlJZCllLmRhdGEuZWZmZWN0SWRzPVthZGRNb25leS5pZCxyZW1lbWJlci5pZF07Zm9yKGNvbnN0IGUgb2YgcC5lbnRpdGllcyllLnN0YXR1cz0nY29uZmlybWVkJztcbiBjb25zdCB6ZXJvPWFkZChwLCdmbG93X25vZGUnLCfmir3pgbjlgJnoo5zjgrzjg63jga7lhaXlj6MnLHtub2RlVHlwZTonZW50cnknfSksemVyb0VuZD1hZGQocCwnZmxvd19ub2RlJywn44K844Ot5YCZ6KOc44Gu5piO56S6ZmFsbGJhY2vntYLnq68nLHtub2RlVHlwZTondGVybWluYWwnLHRlcm1pbmFsUmVhc29uOifkvZzogIXjgYzkuI3miJDnq4vmmYLjga7ku6Pmm7/ntYLkuobjgpLoqK3lrprjgZfjgZ8nfSksZmFsc2VFZGdlPWFkZChwLCdmbG93X2VkZ2UnLCfluLjjgavkuI3miJDnq4vjga7lgJnoo5wnLHtmcm9tSWQ6emVyby5pZCx0b0lkOnplcm9FbmQuaWQsbGFiZWw6J+W4uOOBq+S4jeaIkOeri+OBruWAmeijnCcsY29uZGl0aW9uOntvcDonY29uc3RhbnQnLHZhbHVlOmZhbHNlfX0pO2FkZChwLCdmbG93X2dyYXBoJywn5YCZ6KOc44K844Ot44Gu5ZuzJyx7bm9kZUlkczpbemVyby5pZCx6ZXJvRW5kLmlkXSxlZGdlSWRzOltmYWxzZUVkZ2UuaWRdLGVudHJ5SWRzOlt6ZXJvLmlkXSxleGl0SWRzOlt6ZXJvRW5kLmlkXX0pO2V4cGVjdCh2YWxpZGF0ZVByb2plY3QocCkub2spLnRvQmUodHJ1ZSk7cD1hd2FpdCBjcmVhdGVXb3JsZFNuYXBzaG90KHAsJ+WPjeW/nDPlgJnoo5zjga7lm7rlrprniYgnKTtjb25zdCBwaW49cC5zbmFwc2hvdHMuYXQoLTEpISxpbnB1dD1hd2FpdCBzZWVkKHBhZ2UscCk7XG4gYXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IGJlZ2luKHBhZ2UsZmlyc3QuZW50cnlJZCxwaW4uaWQsJ29yaWdpbmFsLXRocmVlJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+mAsuihjOimj+WJh+OBq+W+k+OBo+OBpuasoeOBuCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci1zaGVldCcpKS50b0NvbnRhaW5UZXh0KCfliJ3lm57jga7ph43opoHjgaroqqzmmI7jga7mnKzmlocnKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon44KC44GG5LiA5bqm5Y+N5b+c44KS6KaL44KLJyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon6YCy6KGM6KaP5YmH44Gr5b6T44Gj44Gm5qyh44G4JyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucmVhZGVyLXNoZWV0JykpLnRvQ29udGFpblRleHQoJ+WGjeioquOBruefreOBhOWPjeW/nOOBruacrOaWhycpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifkuIDmiYvmiLvjgosnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifkuIDmiYvmiLvjgosnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItc2hlZXQnKSkudG9Db250YWluVGV4dCgn5Yid5Zue44Gu6YeN6KaB44Gq6Kqs5piO44Gu5pys5paHJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+WPjeW/nOOBruippuiqreOCkue1guS6huOBmeOCiycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcmVjb3JkVHJpYWwocGFnZSk7Y29uc3QgZmlyc3RTYXZlZD1hd2FpdCBsYXN0VHJhY2UocGFnZSk7ZXhwZWN0KGZpcnN0U2F2ZWQudHJhY2UuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnNlZW5JZHMpLnRvQ29udGFpbihzY2VuZXNbMF0uaWQpO1xuIGF3YWl0IHJlYWRlcihwYWdlKTthd2FpdCBiZWdpbihwYWdlLHJhbmRvbS5lbnRyeUlkLHBpbi5pZCwnb3JpZ2luYWwtdGhyZWUnKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucmVhZGVyLWNob2ljZXMgLnJlYWRlci1jaG9pY2UnKSkudG9IYXZlQ291bnQoMyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+ecn+OBrumBuOaKnuiCouOBi+OCieaKvemBuCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7Y29uc3QgZmlyc3RSYW5kb21IZWFkaW5nPWF3YWl0IHBhZ2UubG9jYXRvcignLnJlYWRlci1zaGVldC1oZWFkaW5nIGgyJykuaW5uZXJUZXh0KCk7ZXhwZWN0KHNjZW5lcy5zbGljZSgyKS5tYXAocz0+cy5uYW1lKSkudG9Db250YWluKGZpcnN0UmFuZG9tSGVhZGluZyk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsbW9uZXkubmFtZSkpLnRvQ29udGFpblRleHQoJzE1Jyk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsbWVtb3J5Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCd0cnVlJyk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci1zdGF0ZS1jb3VudHMnKSkudG9Db250YWluVGV4dCgn5oq96YG45L2N572uJyk7Y29uc3Qgb2JzZXJ2ZWREcmF3PWF3YWl0IHBhZ2UubG9jYXRvcignLnJlYWRlci1zdGF0ZS1jb3VudHMnKS5pbm5lclRleHQoKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon5LiA5omL5oi744KLJyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QodmFyaWFibGUocGFnZSxtb25leS5uYW1lKSkudG9Db250YWluVGV4dCgnMTAnKTthd2FpdCBleHBlY3QodmFyaWFibGUocGFnZSxtZW1vcnkubmFtZSkpLnRvQ29udGFpblRleHQoJ2ZhbHNlJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+ecn+OBrumBuOaKnuiCouOBi+OCieaKvemBuCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci1zaGVldC1oZWFkaW5nIGgyJykpLnRvSGF2ZVRleHQoZmlyc3RSYW5kb21IZWFkaW5nKTtleHBlY3QoYXdhaXQgcGFnZS5sb2NhdG9yKCcucmVhZGVyLXN0YXRlLWNvdW50cycpLmlubmVyVGV4dCgpKS50b0JlKG9ic2VydmVkRHJhdyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+WPjeW/nOOBruippuiqreOCkue1guS6huOBmeOCiycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcmVjb3JkVHJpYWwocGFnZSk7Y29uc3QgcmFuZG9tU2F2ZWQ9YXdhaXQgbGFzdFRyYWNlKHBhZ2UpLHJhbmRvbVRyYWNlPXJhbmRvbVNhdmVkLnRyYWNlO2V4cGVjdChyYW5kb21UcmFjZS5kYXRhLnNlZWQpLnRvQmUoJ29yaWdpbmFsLXRocmVlJyk7ZXhwZWN0KHJhbmRvbVRyYWNlLmRhdGEuc3RlcHNbMF0uYmVmb3JlLnJuZ1Bvc2l0aW9uKS50b0JlKDApO2V4cGVjdChyYW5kb21UcmFjZS5kYXRhLnN0ZXBzWzBdLmFmdGVyLnJuZ1Bvc2l0aW9uKS50b0JlR3JlYXRlclRoYW4oMCk7ZXhwZWN0KHJhbmRvbVRyYWNlLmRhdGEuc3RlcHNbMF0uYWZ0ZXIuc2Vlbklkcy5zb21lKGlkPT5zY2VuZXMuc2xpY2UoMikuc29tZShzPT5zLmlkPT09aWQpKSkudG9CZSh0cnVlKTtcbiBhd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+asoeOBruWRqOWbnicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsbW9uZXkubmFtZSkpLnRvQ29udGFpblRleHQoJzEwJyk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsbWVtb3J5Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCd0cnVlJyk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci10cmlhbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQoJ+WRqOWbniAnKyhyYW5kb21UcmFjZS5kYXRhLnN0ZXBzLmF0KC0xKSEuYWZ0ZXIubG9vcE51bWJlcisxKSk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+OBmeOBueOBpuWIneacn+WMlicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsbW9uZXkubmFtZSkpLnRvQ29udGFpblRleHQoJzEwJyk7YXdhaXQgZXhwZWN0KHZhcmlhYmxlKHBhZ2UsbWVtb3J5Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCdmYWxzZScpO1xuIGF3YWl0IGJlZ2luKHBhZ2UsemVyby5pZCxwaW4uaWQsJ29yaWdpbmFsLXRocmVlJyk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci10cmlhbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQoJ+mAsuihjOS4jeWPrycpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItY2hvaWNlJykuZmlsdGVyKHtoYXM6cGFnZS5nZXRCeVRleHQoZmFsc2VFZGdlLmRhdGEubGFiZWwhLHtleGFjdDp0cnVlfSl9KSkudG9CZURpc2FibGVkKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci10cmlhbC1oZWFkaW5nJykpLm5vdC50b0NvbnRhaW5UZXh0KCfmhI/lm7PjgZfjgZ/ntYLnq68nKTthd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ2Zsb3dfbm9kZScsemVyby5uYW1lKTthd2FpdCBlZGl0RGF0YShwYWdlLGRhdGE9PntkYXRhLmZhbGxiYWNrSWQ9emVyb0VuZC5pZDt9KTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO2F3YWl0IHJlYWRlcihwYWdlKTthd2FpdCBiZWdpbihwYWdlLHplcm8uaWQsJycsJ29yaWdpbmFsLXRocmVlJyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+S7o+abv+OBrumAsuihjOWFiOOBuO+8micremVyb0VuZC5uYW1lLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItdHJpYWwtaGVhZGluZycpKS50b0NvbnRhaW5UZXh0KCfmhI/lm7PjgZfjgZ/ntYLnq68nKTtcbiBhd2FpdCBwYWdlLnJlbG9hZCgpO2F3YWl0IHJlYWRlcihwYWdlKTtjb25zdCByZXBsYXlCdXR0b25zPXBhZ2UubG9jYXRvcignLnNhdmVkLXRyYWNlcyBidXR0b24ucmVmZXJlbmNlLWxpbmsnKTthd2FpdCBleHBlY3QocmVwbGF5QnV0dG9ucykudG9IYXZlQ291bnQoMik7YXdhaXQgZXhwZWN0KHJlcGxheUJ1dHRvbnMubnRoKDEpKS50b0NvbnRhaW5UZXh0KHJhbmRvbVRyYWNlLm5hbWUpO2F3YWl0IHJlcGxheUJ1dHRvbnMubnRoKDEpLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci10cmlhbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQoJ+aEj+Wbs+OBl+OBn+e1guerrycpO2F3YWl0IGV4cGVjdCh2YXJpYWJsZShwYWdlLG1vbmV5Lm5hbWUpKS50b0NvbnRhaW5UZXh0KCcxNScpO2F3YWl0IGV4cGVjdCh2YXJpYWJsZShwYWdlLG1lbW9yeS5uYW1lKSkudG9Db250YWluVGV4dCgndHJ1ZScpO2NvbnN0IGNvbGQ9YXdhaXQgYmFja3VwKHBhZ2UpLGZyZXNoPWF3YWl0IGZyZXNoUm91bmR0cmlwKGJyb3dzZXIsY29sZC5ieXRlcyksY2xvbmU9YXdhaXQgZnJlc2hSb3VuZHRyaXAoYnJvd3Nlcixjb2xkLmJ5dGVzLCdjbG9uZScpO2V4cGVjdChmcmVzaC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1yYW5kb21UcmFjZS5pZCkpLnRvRXF1YWwocmFuZG9tVHJhY2UpO2V4cGVjdChjbG9uZS5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maWx0ZXIoZT0+ZS5raW5kPT09J3RyYWNlJykpLnRvSGF2ZUxlbmd0aCgyKTthd2FpdCBldmlkZW5jZShpbmZvLCdGMjAtb3JpZ2luYWwtdGhyZWUtcmVhY3Rpb25zJyx7b3JpZ2luYWxBY2NlcHRhbmNlOidBVC1GMjAnLGZpeHR1cmVTSEEyNTY6ZGlnZXN0KGlucHV0KSxnaXZlbjp7Zmlyc3RSZXZpc2l0OnNjZW5lcy5zbGljZSgwLDIpLm1hcChzPT5zLmlkKSxyYW5kb21DYW5kaWRhdGVDb3VudDozLHJ1bk1vbmV5OjEwLGFjcm9zc1J1bnNNZW1vcnk6dHJ1ZX0sd2hlbjp7Zmlyc3RUaGVuUmV2aXNpdFRoZW5Ud29VbmRvOnRydWUsc2VlZDonb3JpZ2luYWwtdGhyZWUnLHJhbmRvbVRoZW5VbmRvVGhlblNhbWVEcmF3OnRydWUsbmV4dExvb3BNb25leTEwTWVtb3J5VHJ1ZTp0cnVlLGFsbFJlc2V0TW9uZXkxME1lbW9yeUZhbHNlOnRydWV9LHRoZW46e2ltcG9ydGFudEZpcnN0SW5mb3JtYXRpb25QcmVzZXJ2ZWQ6dHJ1ZSxzYXZlZFJuZ1Bvc2l0aW9uQW5kU2Vlbklkc1JlcGxheWVkOnRydWV9LG5lZ2F0aXZlOnt6ZXJvRmFsc2VDYW5kaWRhdGVzQmxvY2tlZE5vdFRlcm1pbmFsOnRydWUsZXhwbGljaXRGYWxsYmFja05vcm1hbEVkaXRBbmRBZHZhbmNlOnRydWUsZml4ZWRPbGRFZGl0aW9uVW5jaGFuZ2VkOnRydWV9LHJhbmRvbVRyYWNlOnJhbmRvbVRyYWNlLmRhdGEsZmlyc3RUcmFjZTpmaXJzdFNhdmVkLnRyYWNlLmRhdGEsZmlyc3RSYW5kb21IZWFkaW5nLGNvbGROZXdDbG9uZTp0cnVlLHBoeXNpY2FsOidub3RfcnVuJyx3aG9sZUNhc2VQYXNzSW5mZXJyZWQ6ZmFsc2V9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFRQSxJQUFJLEVBQUNDLE1BQU0sUUFBaUIsa0JBQWtCO0FBQ3RELFNBQVFDLFlBQVksRUFBQ0MsYUFBYSxFQUFDQyxLQUFLLEVBQUNDLGNBQWMsRUFBQ0MsZUFBZSxRQUFPLCtCQUErQjtBQUM3RyxTQUFRQyxtQkFBbUIsUUFBTywrQkFBK0I7QUFDakUsU0FBUUMsVUFBVSxFQUFDQyxTQUFTLFFBQU8saUNBQWlDO0FBQ3BFLFNBQVFDLGlCQUFpQixRQUFPLG9DQUFvQztBQUNwRSxTQUFRQyxnQkFBZ0IsUUFBTyxtQ0FBbUM7QUFFbEUsU0FBUUMsSUFBSSxFQUFLQyxNQUFNLEVBQUNDLE9BQU8sRUFBQ0MsTUFBTSxFQUFDQyxRQUFRLFFBQU8sVUFBVTtBQUNoRSxTQUFRQyxNQUFNLEVBQUNDLEtBQUssRUFBQ0MsV0FBVyxFQUFDQyxVQUFVLEVBQUNDLGNBQWMsRUFBQ0MsUUFBUSxFQUFDQyxVQUFVLFFBQU8sb0JBQW9CO0FBQ3pHLFNBQVNDLEdBQUdBLENBQXVCQyxDQUFhLEVBQUNDLElBQU0sRUFBQ0MsSUFBVyxFQUFDQyxJQUE4QixHQUFDLENBQUMsQ0FBQyxFQUFXO0VBQUMsTUFBTUMsQ0FBQyxHQUFDM0IsWUFBWSxDQUFDdUIsQ0FBQyxDQUFDSyxTQUFTLEVBQUNKLElBQUksRUFBQ0MsSUFBSSxFQUFDQyxJQUFJLENBQUM7RUFBQ0MsQ0FBQyxDQUFDRSxNQUFNLEdBQUMsV0FBVztFQUFDTixDQUFDLENBQUNPLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDSixDQUFDLENBQUM7RUFBQyxPQUFPQSxDQUFDO0FBQUM7QUFDbk4sU0FBU0ssUUFBUUEsQ0FBQ0MsSUFBUyxFQUFDUixJQUFXLEVBQUM7RUFBQyxPQUFPUSxJQUFJLENBQUNDLE9BQU8sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDQyxNQUFNLENBQUM7SUFBQ0MsR0FBRyxFQUFDSCxJQUFJLENBQUNJLFNBQVMsQ0FBQ1osSUFBSSxFQUFDO01BQUNhLEtBQUssRUFBQztJQUFJLENBQUM7RUFBQyxDQUFDLENBQUM7QUFBQztBQUNySixlQUFlQyxTQUFTQSxDQUFDTixJQUFTLEVBQUM7RUFBQyxNQUFNTyxJQUFJLEdBQUMsTUFBTTdCLE1BQU0sQ0FBQ3NCLElBQUksQ0FBQztJQUFDUSxLQUFLLEdBQUNELElBQUksQ0FBQ0UsTUFBTSxDQUFDQyxPQUFPLENBQUNiLFFBQVEsQ0FBQ0ssTUFBTSxDQUFFUixDQUFDLElBQXdCQSxDQUFDLENBQUNILElBQUksS0FBRyxPQUFPLENBQUMsQ0FBQ29CLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRTtFQUFDLE9BQU87SUFBQ0osSUFBSTtJQUFDQztFQUFLLENBQUM7QUFBQztBQUVwTDNDLElBQUksQ0FBQyxnTEFBZ0wsRUFBQyxPQUFNO0VBQUNtQyxJQUFJO0VBQUNZO0FBQU8sQ0FBQyxFQUFDQyxJQUFJLEtBQUc7RUFDak5oRCxJQUFJLENBQUNpRCxVQUFVLENBQUMsTUFBTSxDQUFDO0VBQUMsSUFBSXhCLENBQUMsR0FBQ3RCLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztFQUNoRSxNQUFNK0MsR0FBRyxHQUFDMUIsR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLEtBQUssRUFBQztNQUFDeUIsR0FBRyxFQUFDLFNBQVM7TUFBQ0MsU0FBUyxFQUFDLFNBQVM7TUFBQ0MsS0FBSyxFQUFDLEtBQUs7TUFBQ0MsT0FBTyxFQUFDO1FBQUNDLElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFLO0lBQUMsQ0FBQyxDQUFDO0lBQUNDLEtBQUssR0FBQ2hDLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFVBQVUsRUFBQyxZQUFZLEVBQUM7TUFBQ3lCLEdBQUcsRUFBQyxTQUFTO01BQUNDLFNBQVMsRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQyxLQUFLO01BQUNDLE9BQU8sRUFBQztRQUFDQyxJQUFJLEVBQUMsU0FBUztRQUFDQyxLQUFLLEVBQUM7TUFBQyxDQUFDO01BQUNFLE9BQU8sRUFBQztRQUFDQyxHQUFHLEVBQUMsQ0FBQztRQUFDQyxHQUFHLEVBQUM7TUFBRztJQUFDLENBQUMsQ0FBQztJQUFDQyxTQUFTLEdBQUNwQyxHQUFHLENBQUNDLENBQUMsRUFBQyxPQUFPLEVBQUMsa0JBQWtCLEVBQUM7TUFBQ29DLElBQUksRUFBQ3hELGNBQWMsQ0FBQyxxQkFBcUI7SUFBQyxDQUFDLENBQUM7RUFDN1YsTUFBTXlELEtBQUssR0FBQ3RDLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxhQUFhLEVBQUM7TUFBQ3NDLFFBQVEsRUFBQztJQUFPLENBQUMsQ0FBQztJQUFDQyxJQUFJLEdBQUN4QyxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsZ0JBQWdCLEVBQUM7TUFBQ3NDLFFBQVEsRUFBQyxPQUFPO01BQUNFLE9BQU8sRUFBQ0wsU0FBUyxDQUFDTSxFQUFFO01BQUNDLElBQUksRUFBQztRQUFDQyxFQUFFLEVBQUMsU0FBUztRQUFDQyxVQUFVLEVBQUNuQixHQUFHLENBQUNnQixFQUFFO1FBQUNJLFVBQVUsRUFBQyxJQUFJO1FBQUNmLEtBQUssRUFBQztVQUFDRCxJQUFJLEVBQUMsU0FBUztVQUFDQyxLQUFLLEVBQUM7UUFBSTtNQUFDLENBQUM7TUFBQ2dCLE9BQU8sRUFBQztRQUFDTCxFQUFFLEVBQUM5RCxLQUFLLENBQUMsQ0FBQztRQUFDb0UsS0FBSyxFQUFDLE9BQU87UUFBQ0MsUUFBUSxFQUFDLElBQUk7UUFBQ0MsTUFBTSxFQUFDLE1BQU07UUFBQ3RCLEtBQUssRUFBQztNQUFLO0lBQUMsQ0FBQyxDQUFDO0lBQUN1QixHQUFHLEdBQUNuRCxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsU0FBUyxFQUFDO01BQUNzQyxRQUFRLEVBQUMsVUFBVTtNQUFDYSxjQUFjLEVBQUM7SUFBYyxDQUFDLENBQUM7SUFBQ0MsTUFBTSxHQUFDckQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsUUFBUSxFQUFDLFFBQVEsRUFBQztNQUFDcUQsU0FBUyxFQUFDLEtBQUs7TUFBQ0MsUUFBUSxFQUFDN0IsR0FBRyxDQUFDZ0IsRUFBRTtNQUFDWCxLQUFLLEVBQUM7UUFBQ0QsSUFBSSxFQUFDLFNBQVM7UUFBQ0MsS0FBSyxFQUFDO01BQUk7SUFBQyxDQUFDLENBQUM7SUFBQ3lCLFdBQVcsR0FBQ3hELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFFBQVEsRUFBQyxXQUFXLEVBQUM7TUFBQ3FELFNBQVMsRUFBQyxLQUFLO01BQUNDLFFBQVEsRUFBQ3ZCLEtBQUssQ0FBQ1UsRUFBRTtNQUFDWCxLQUFLLEVBQUM7UUFBQ0QsSUFBSSxFQUFDLFNBQVM7UUFBQ0MsS0FBSyxFQUFDO01BQUM7SUFBQyxDQUFDLENBQUM7RUFDdmxCLE1BQU0wQixHQUFHLEdBQUN6RCxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsV0FBVyxFQUFDO01BQUN5RCxNQUFNLEVBQUNwQixLQUFLLENBQUNJLEVBQUU7TUFBQ2lCLElBQUksRUFBQ25CLElBQUksQ0FBQ0UsRUFBRTtNQUFDa0IsS0FBSyxFQUFDLFdBQVc7TUFBQ0MsU0FBUyxFQUFDLENBQUNSLE1BQU0sQ0FBQ1gsRUFBRTtJQUFDLENBQUMsQ0FBQztJQUFDb0IsS0FBSyxHQUFDOUQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLGNBQWMsRUFBQztNQUFDeUQsTUFBTSxFQUFDbEIsSUFBSSxDQUFDRSxFQUFFO01BQUNpQixJQUFJLEVBQUNyQixLQUFLLENBQUNJLEVBQUU7TUFBQ2tCLEtBQUssRUFBQyxjQUFjO01BQUNDLFNBQVMsRUFBQyxDQUFDTCxXQUFXLENBQUNkLEVBQUU7SUFBQyxDQUFDLENBQUM7SUFBQ3FCLE1BQU0sR0FBQy9ELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxjQUFjLEVBQUM7TUFBQ3lELE1BQU0sRUFBQ3BCLEtBQUssQ0FBQ0ksRUFBRTtNQUFDaUIsSUFBSSxFQUFDUixHQUFHLENBQUNULEVBQUU7TUFBQ2tCLEtBQUssRUFBQztJQUFjLENBQUMsQ0FBQztFQUFDNUQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsWUFBWSxFQUFDLFFBQVEsRUFBQztJQUFDK0QsT0FBTyxFQUFDLENBQUMxQixLQUFLLENBQUNJLEVBQUUsRUFBQ0YsSUFBSSxDQUFDRSxFQUFFLEVBQUNTLEdBQUcsQ0FBQ1QsRUFBRSxDQUFDO0lBQUN1QixPQUFPLEVBQUMsQ0FBQ1IsR0FBRyxDQUFDZixFQUFFLEVBQUNvQixLQUFLLENBQUNwQixFQUFFLEVBQUNxQixNQUFNLENBQUNyQixFQUFFLENBQUM7SUFBQ3dCLFFBQVEsRUFBQyxDQUFDNUIsS0FBSyxDQUFDSSxFQUFFLENBQUM7SUFBQ3lCLE9BQU8sRUFBQyxDQUFDaEIsR0FBRyxDQUFDVCxFQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQUNqRSxNQUFNLENBQUNLLGVBQWUsQ0FBQ21CLENBQUMsQ0FBQyxDQUFDbUUsRUFBRSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7RUFBQ3BFLENBQUMsR0FBQyxNQUFNbEIsbUJBQW1CLENBQUNrQixDQUFDLEVBQUMsVUFBVSxDQUFDO0VBQUMsTUFBTXFFLEdBQUcsR0FBQ3JFLENBQUMsQ0FBQ3NFLFNBQVMsQ0FBQ2pELEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRTtFQUM3akI7RUFDQSxNQUFNa0QsT0FBTyxHQUFDeEYsVUFBVSxDQUFDaUIsQ0FBQyxFQUFDO01BQUN3RSxPQUFPLEVBQUNuQyxLQUFLLENBQUNJLEVBQUU7TUFBQ2dDLGdCQUFnQixFQUFDSixHQUFHLENBQUM1QixFQUFFO01BQUN0RCxJQUFJLEVBQUM7SUFBZ0IsQ0FBQyxDQUFDO0lBQUN1RixNQUFNLEdBQUMxRixTQUFTLENBQUNnQixDQUFDLEVBQUN1RSxPQUFPLEVBQUM7TUFBQ0ksTUFBTSxFQUFDbkIsR0FBRyxDQUFDZjtJQUFFLENBQUMsQ0FBQztFQUFDakUsTUFBTSxDQUFDa0csTUFBTSxDQUFDRSxLQUFLLENBQUNDLGNBQWMsQ0FBQzlDLEtBQUssQ0FBQ1UsRUFBRSxDQUFDLENBQUMsQ0FBQ3FDLE9BQU8sQ0FBQztJQUFDakQsSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTWlELFNBQVMsR0FBQzlGLGlCQUFpQixDQUFDc0QsSUFBSSxDQUFDcEMsSUFBSSxDQUFDdUMsSUFBSSxFQUFFO0lBQUNrQyxLQUFLLEVBQUNGLE1BQU0sQ0FBQ0UsS0FBSztJQUFDSSxTQUFTLEVBQUNoRixDQUFDLENBQUNPLFFBQVEsQ0FBQ0ssTUFBTSxDQUFFUixDQUFDLElBQTJCQSxDQUFDLENBQUNILElBQUksS0FBRyxVQUFVLENBQUM7SUFBQ00sUUFBUSxFQUFDUCxDQUFDLENBQUNPO0VBQVEsQ0FBQyxDQUFDO0VBQUMvQixNQUFNLENBQUN1RyxTQUFTLENBQUNqRCxLQUFLLENBQUMsQ0FBQ3NDLElBQUksQ0FBQyxNQUFNLENBQUM7RUFBQzVGLE1BQU0sQ0FBQ2tHLE1BQU0sQ0FBQ0UsS0FBSyxDQUFDQyxjQUFjLENBQUM5QyxLQUFLLENBQUNVLEVBQUUsQ0FBQyxDQUFDLENBQUNxQyxPQUFPLENBQUM7SUFBQ2pELElBQUksRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1tRCxTQUFTLEdBQUNqRyxTQUFTLENBQUNnQixDQUFDLEVBQUMwRSxNQUFNLEVBQUM7SUFBQ0MsTUFBTSxFQUFDZCxLQUFLLENBQUNwQjtFQUFFLENBQUMsQ0FBQztFQUFDakUsTUFBTSxDQUFDeUcsU0FBUyxDQUFDTCxLQUFLLENBQUNDLGNBQWMsQ0FBQzlDLEtBQUssQ0FBQ1UsRUFBRSxDQUFDLENBQUMsQ0FBQ3FDLE9BQU8sQ0FBQztJQUFDakQsSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTWlCLEtBQUssR0FBQztJQUFDbUMsU0FBUyxFQUFDM0MsSUFBSSxDQUFDcEMsSUFBSSxDQUFDMkMsT0FBTyxDQUFFTCxFQUFHO0lBQUNNLEtBQUssRUFBQyxPQUFnQjtJQUFDQyxRQUFRLEVBQUMsSUFBSTtJQUFDbUMsWUFBWSxFQUFDO0VBQTBCLENBQUM7RUFBQyxNQUFNQyxLQUFLLEdBQUNwRyxTQUFTLENBQUNnQixDQUFDLEVBQUMwRSxNQUFNLEVBQUM7TUFBQ0MsTUFBTSxFQUFDZCxLQUFLLENBQUNwQixFQUFFO01BQUNNO0lBQUssQ0FBQyxDQUFDO0lBQUNzQyxTQUFTLEdBQUNyRyxTQUFTLENBQUNnQixDQUFDLEVBQUNvRixLQUFLLEVBQUM7TUFBQ1QsTUFBTSxFQUFDZCxLQUFLLENBQUNwQixFQUFFO01BQUNNO0lBQUssQ0FBQyxDQUFDO0VBQUN2RSxNQUFNLENBQUM2RyxTQUFTLENBQUNULEtBQUssQ0FBQyxDQUFDRSxPQUFPLENBQUNNLEtBQUssQ0FBQ1IsS0FBSyxDQUFDO0VBQUNwRyxNQUFNLENBQUM2RyxTQUFTLENBQUNuRSxLQUFLLENBQUMsQ0FBQzRELE9BQU8sQ0FBQ00sS0FBSyxDQUFDbEUsS0FBSyxDQUFDO0VBQUMxQyxNQUFNLENBQUM2RyxTQUFTLENBQUNDLE9BQU8sQ0FBQyxDQUFDUixPQUFPLENBQUNNLEtBQUssQ0FBQ0UsT0FBTyxDQUFDO0VBQUM5RyxNQUFNLENBQUM0RyxLQUFLLENBQUNSLEtBQUssQ0FBQ0MsY0FBYyxDQUFDOUMsS0FBSyxDQUFDVSxFQUFFLENBQUMsQ0FBQyxDQUFDcUMsT0FBTyxDQUFDO0lBQUNqRCxJQUFJLEVBQUMsU0FBUztJQUFDQyxLQUFLLEVBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNeUQsU0FBUyxHQUFDdkcsU0FBUyxDQUFDZ0IsQ0FBQyxFQUFDb0YsS0FBSyxFQUFDO01BQUNULE1BQU0sRUFBQ25CLEdBQUcsQ0FBQ2Y7SUFBRSxDQUFDLENBQUM7SUFBQytDLEtBQUssR0FBQ3hHLFNBQVMsQ0FBQ2dCLENBQUMsRUFBQ3VGLFNBQVMsRUFBQztNQUFDWixNQUFNLEVBQUNkLEtBQUssQ0FBQ3BCLEVBQUU7TUFBQ00sS0FBSyxFQUFDO1FBQUMsR0FBR0EsS0FBSztRQUFDb0MsWUFBWSxFQUFDO01BQWE7SUFBQyxDQUFDLENBQUM7RUFBQzNHLE1BQU0sQ0FBQ2dILEtBQUssQ0FBQ2xGLE1BQU0sQ0FBQyxDQUFDOEQsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUFDNUYsTUFBTSxDQUFDZ0gsS0FBSyxDQUFDWixLQUFLLENBQUNDLGNBQWMsQ0FBQzlDLEtBQUssQ0FBQ1UsRUFBRSxDQUFDLENBQUMsQ0FBQ3FDLE9BQU8sQ0FBQztJQUFDakQsSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQ3IwQyxNQUFNMkQsS0FBSyxHQUFDLE1BQU10RyxJQUFJLENBQUN1QixJQUFJLEVBQUNWLENBQUMsQ0FBQztFQUFDLE1BQU1SLE1BQU0sQ0FBQ2tCLElBQUksQ0FBQztFQUFDLE1BQU1qQixLQUFLLENBQUNpQixJQUFJLEVBQUMyQixLQUFLLENBQUNJLEVBQUUsRUFBQzRCLEdBQUcsQ0FBQzVCLEVBQUUsRUFBQyxnQkFBZ0IsQ0FBQztFQUFDLE1BQU1qRSxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ3FCLEtBQUssQ0FBQzdCLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsR0FBRyxDQUFDO0VBQUMsTUFBTWhGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQ3NELEdBQUcsQ0FBQ3JELElBQUksQ0FBQ3dELEtBQU07SUFBQzVDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNlLEdBQUcsQ0FBQ3ZCLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsTUFBTSxDQUFDO0VBQUMsTUFBTWxILE1BQU0sQ0FBQ2lDLFFBQVEsQ0FBQ0MsSUFBSSxFQUFDcUIsS0FBSyxDQUFDN0IsSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLGFBQWEsQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDaUYsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDekYsSUFBSSxFQUFDMkQsS0FBSyxDQUFDMUQsSUFBSSxDQUFDd0QsS0FBTTtJQUFDNUMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzhFLFlBQVksQ0FBQyxDQUFDO0VBQUMsTUFBTUMsWUFBWSxHQUFDLE1BQU16RyxPQUFPLENBQUNxQixJQUFJLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNxRixVQUFVLENBQUMsaUJBQWlCLEVBQUM7SUFBQ2hGLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDaUYsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNdEYsSUFBSSxDQUFDaUYsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDekYsSUFBSSxFQUFDMkQsS0FBSyxDQUFDMUQsSUFBSSxDQUFDd0QsS0FBTTtJQUFDNUMsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM2RSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1wSCxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ3FCLEtBQUssQ0FBQzdCLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsR0FBRyxDQUFDO0VBQUMsTUFBTWhGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQ3NELEdBQUcsQ0FBQ3JELElBQUksQ0FBQ3dELEtBQU07SUFBQzVDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNbEYsSUFBSSxDQUFDcUYsVUFBVSxDQUFDLGlCQUFpQixFQUFDO0lBQUNoRixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ2lGLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXRGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQzJELEtBQUssQ0FBQzFELElBQUksQ0FBQ3dELEtBQU07SUFBQzVDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQytFLGFBQWEsQ0FBQyxNQUFNLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNxQixLQUFLLENBQUM3QixJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLEdBQUcsQ0FBQztFQUFDbEgsTUFBTSxDQUFDLE1BQU1hLE9BQU8sQ0FBQ3FCLElBQUksQ0FBQyxDQUFDLENBQUNvRSxPQUFPLENBQUNnQixZQUFZLENBQUM7RUFBQyxNQUFNcEYsSUFBSSxDQUFDaUYsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDekYsSUFBSSxFQUFDLE1BQU07SUFBQ2EsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM2RSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1sRixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUM0RCxNQUFNLENBQUMzRCxJQUFJLENBQUN3RCxLQUFNO0lBQUM1QyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxHLFdBQVcsQ0FBQ2dCLElBQUksQ0FBQztFQUFDLE1BQU11RixLQUFLLEdBQUMsTUFBTWpGLFNBQVMsQ0FBQ04sSUFBSSxDQUFDO0VBQUNsQyxNQUFNLENBQUN5SCxLQUFLLENBQUMvRSxLQUFLLENBQUNmLElBQUksQ0FBQytGLEtBQUssQ0FBQ3RGLE1BQU0sQ0FBQ3VGLENBQUMsSUFBRUEsQ0FBQyxDQUFDbkMsT0FBTyxDQUFDb0MsUUFBUSxDQUFDdkMsS0FBSyxDQUFDcEIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDNEQsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUFDN0gsTUFBTSxDQUFDeUgsS0FBSyxDQUFDL0UsS0FBSyxDQUFDZixJQUFJLENBQUMrRixLQUFLLENBQUM3RSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRWlGLEtBQUssQ0FBQ3pCLGNBQWMsQ0FBQzlDLEtBQUssQ0FBQ1UsRUFBRSxDQUFDLENBQUMsQ0FBQ3FDLE9BQU8sQ0FBQztJQUFDakQsSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQUN0RCxNQUFNLENBQUN5SCxLQUFLLENBQUMvRSxLQUFLLENBQUNmLElBQUksQ0FBQytGLEtBQUssQ0FBQzdFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFaUYsS0FBSyxDQUFDQyxZQUFZLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3JoRCxNQUFNMUQsSUFBSSxDQUFDaUcsTUFBTSxDQUFDLENBQUM7RUFBQyxNQUFNbkgsTUFBTSxDQUFDa0IsSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNnRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsSUFBSTBHLE1BQU0sQ0FBQyxHQUFHLEdBQUNYLEtBQUssQ0FBQy9FLEtBQUssQ0FBQ2hCLElBQUk7RUFBQyxDQUFDLENBQUMsQ0FBQzBGLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBILE1BQU0sQ0FBQ2lDLFFBQVEsQ0FBQ0MsSUFBSSxFQUFDcUIsS0FBSyxDQUFDN0IsSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLGFBQWEsQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNbUIsSUFBSSxHQUFDLE1BQU16SCxNQUFNLENBQUNzQixJQUFJLENBQUM7SUFBQ29HLEtBQUssR0FBQyxNQUFNbEgsY0FBYyxDQUFDMEIsT0FBTyxFQUFDdUYsSUFBSSxDQUFDRSxLQUFLLENBQUM7SUFBQ0MsS0FBSyxHQUFDLE1BQU1wSCxjQUFjLENBQUMwQixPQUFPLEVBQUN1RixJQUFJLENBQUNFLEtBQUssRUFBQyxPQUFPLENBQUM7RUFBQ3ZJLE1BQU0sQ0FBQ3NJLEtBQUssQ0FBQzNGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDYixRQUFRLENBQUMwRyxJQUFJLENBQUM3RyxDQUFDLElBQUVBLENBQUMsQ0FBQ3FDLEVBQUUsS0FBR3dELEtBQUssQ0FBQy9FLEtBQUssQ0FBQ3VCLEVBQUUsQ0FBQyxDQUFDLENBQUNxQyxPQUFPLENBQUNtQixLQUFLLENBQUMvRSxLQUFLLENBQUM7RUFBQzFDLE1BQU0sQ0FBQ3dJLEtBQUssQ0FBQzdGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDYixRQUFRLENBQUNLLE1BQU0sQ0FBQ1IsQ0FBQyxJQUFFQSxDQUFDLENBQUNILElBQUksS0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDb0csWUFBWSxDQUFDLENBQUMsQ0FBQztFQUN6ZixNQUFNOUcsUUFBUSxDQUFDZ0MsSUFBSSxFQUFDLHNCQUFzQixFQUFDO0lBQUMyRixrQkFBa0IsRUFBQyxRQUFRO0lBQUNDLGFBQWEsRUFBQzdILE1BQU0sQ0FBQ21HLEtBQUssQ0FBQztJQUFDMkIsS0FBSyxFQUFDO01BQUMxRSxJQUFJLEVBQUMsS0FBSztNQUFDSSxPQUFPLEVBQUMsSUFBSTtNQUFDdUUsSUFBSSxFQUFDO0lBQUssQ0FBQztJQUFDQyxJQUFJLEVBQUM7TUFBQ0MsdUJBQXVCLEVBQUMsSUFBSTtNQUFDQyxvQkFBb0IsRUFBQyxJQUFJO01BQUNDLHVCQUF1QixFQUFDLElBQUk7TUFBQ0MsZ0JBQWdCLEVBQUMsMEJBQTBCO01BQUNDLHNDQUFzQyxFQUFDLElBQUk7TUFBQ0MsMkJBQTJCLEVBQUM7SUFBSSxDQUFDO0lBQUNDLElBQUksRUFBQztNQUFDQyx3QkFBd0IsRUFBQztJQUFJLENBQUM7SUFBQ0MsUUFBUSxFQUFDO01BQUNDLHFCQUFxQixFQUFDLElBQUk7TUFBQ0MsdUJBQXVCLEVBQUMsSUFBSTtNQUFDQyxtQkFBbUIsRUFBQztJQUFJLENBQUM7SUFBQ0MsbUJBQW1CLEVBQUMvQyxLQUFLLENBQUNSLEtBQUs7SUFBQzFELEtBQUssRUFBQytFLEtBQUssQ0FBQy9FLEtBQUssQ0FBQ2YsSUFBSTtJQUFDaUksWUFBWSxFQUFDLElBQUk7SUFBQ0MsUUFBUSxFQUFDLFNBQVM7SUFBQ0MscUJBQXFCLEVBQUM7RUFBSyxDQUFDLENBQUM7QUFDOWxCLENBQUMsQ0FBQztBQUVGL0osSUFBSSxDQUFDLG1LQUFtSyxFQUFDLE9BQU07RUFBQ21DLElBQUk7RUFBQ1k7QUFBTyxDQUFDLEVBQUNDLElBQUksS0FBRztFQUNwTWhELElBQUksQ0FBQ2lELFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFBQyxJQUFJeEIsQ0FBQyxHQUFDdEIsYUFBYSxDQUFDLG1CQUFtQixDQUFDO0VBQUMsTUFBTStDLEdBQUcsR0FBQzFCLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFVBQVUsRUFBQyxLQUFLLEVBQUM7TUFBQ3lCLEdBQUcsRUFBQyxLQUFLO01BQUNDLFNBQVMsRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQyxLQUFLO01BQUNDLE9BQU8sRUFBQztRQUFDQyxJQUFJLEVBQUMsU0FBUztRQUFDQyxLQUFLLEVBQUM7TUFBSztJQUFDLENBQUMsQ0FBQztJQUFDeUcsUUFBUSxHQUFDeEksR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLE1BQU0sRUFBQztNQUFDeUIsR0FBRyxFQUFDLFVBQVU7TUFBQ0MsU0FBUyxFQUFDLFNBQVM7TUFBQ0MsS0FBSyxFQUFDLEtBQUs7TUFBQ0MsT0FBTyxFQUFDO1FBQUNDLElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFDLENBQUM7TUFBQ0UsT0FBTyxFQUFDO1FBQUNDLEdBQUcsRUFBQyxDQUFDO1FBQUNDLEdBQUcsRUFBQztNQUFFO0lBQUMsQ0FBQyxDQUFDO0lBQUNzRyxLQUFLLEdBQUN6SSxHQUFHLENBQUNDLENBQUMsRUFBQyxPQUFPLEVBQUMsVUFBVSxFQUFDO01BQUNvQyxJQUFJLEVBQUN4RCxjQUFjLENBQUMsNkJBQTZCO0lBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTXlELEtBQUssR0FBQ3RDLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxRQUFRLEVBQUM7TUFBQ3NDLFFBQVEsRUFBQztJQUFPLENBQUMsQ0FBQztJQUFDbUcsS0FBSyxHQUFDMUksR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFdBQVcsRUFBQztNQUFDc0MsUUFBUSxFQUFDLFFBQVE7TUFBQ0UsT0FBTyxFQUFDZ0csS0FBSyxDQUFDL0Y7SUFBRSxDQUFDLENBQUM7SUFBQ1MsR0FBRyxHQUFDbkQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFNBQVMsRUFBQztNQUFDc0MsUUFBUSxFQUFDLFVBQVU7TUFBQ2EsY0FBYyxFQUFDO0lBQWdCLENBQUMsQ0FBQztJQUFDdUYsU0FBUyxHQUFDM0ksR0FBRyxDQUFDQyxDQUFDLEVBQUMsUUFBUSxFQUFDLFNBQVMsRUFBQztNQUFDcUQsU0FBUyxFQUFDLEtBQUs7TUFBQ0MsUUFBUSxFQUFDN0IsR0FBRyxDQUFDZ0IsRUFBRTtNQUFDWCxLQUFLLEVBQUM7UUFBQ0QsSUFBSSxFQUFDLFNBQVM7UUFBQ0MsS0FBSyxFQUFDO01BQUk7SUFBQyxDQUFDLENBQUM7SUFBQzZHLFNBQVMsR0FBQzVJLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFFBQVEsRUFBQyxhQUFhLEVBQUM7TUFBQ3FELFNBQVMsRUFBQyxLQUFLO01BQUNDLFFBQVEsRUFBQ2lGLFFBQVEsQ0FBQzlGLEVBQUU7TUFBQ1gsS0FBSyxFQUFDO1FBQUNELElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFDO0lBQUMsQ0FBQyxDQUFDO0lBQUM4RyxRQUFRLEdBQUM3SSxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsYUFBYSxFQUFDO01BQUNxRCxTQUFTLEVBQUMsT0FBTztNQUFDQyxRQUFRLEVBQUM3QixHQUFHLENBQUNnQixFQUFFO01BQUNYLEtBQUssRUFBQztRQUFDRCxJQUFJLEVBQUMsU0FBUztRQUFDQyxLQUFLLEVBQUM7TUFBSyxDQUFDO01BQUMrRyxNQUFNLEVBQUM7SUFBbUIsQ0FBQyxDQUFDO0lBQUNDLFFBQVEsR0FBQy9JLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFFBQVEsRUFBQyxlQUFlLEVBQUM7TUFBQ3FELFNBQVMsRUFBQyxPQUFPO01BQUNDLFFBQVEsRUFBQ2lGLFFBQVEsQ0FBQzlGLEVBQUU7TUFBQ1gsS0FBSyxFQUFDO1FBQUNELElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFDLENBQUM7TUFBQytHLE1BQU0sRUFBQztJQUFtQixDQUFDLENBQUM7RUFDMWxDLE1BQU1FLEdBQUcsR0FBQ2hKLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxlQUFlLEVBQUM7TUFBQ3lELE1BQU0sRUFBQ3BCLEtBQUssQ0FBQ0ksRUFBRTtNQUFDaUIsSUFBSSxFQUFDK0UsS0FBSyxDQUFDaEcsRUFBRTtNQUFDa0IsS0FBSyxFQUFDLGVBQWU7TUFBQ0MsU0FBUyxFQUFDLENBQUM4RSxTQUFTLENBQUNqRyxFQUFFLEVBQUNrRyxTQUFTLENBQUNsRyxFQUFFO0lBQUMsQ0FBQyxDQUFDO0lBQUN1RyxJQUFJLEdBQUNqSixHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsY0FBYyxFQUFDO01BQUN5RCxNQUFNLEVBQUNwQixLQUFLLENBQUNJLEVBQUU7TUFBQ2lCLElBQUksRUFBQytFLEtBQUssQ0FBQ2hHLEVBQUU7TUFBQ2tCLEtBQUssRUFBQztJQUFjLENBQUMsQ0FBQztJQUFDc0YsSUFBSSxHQUFDbEosR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLGFBQWEsRUFBQztNQUFDeUQsTUFBTSxFQUFDZ0YsS0FBSyxDQUFDaEcsRUFBRTtNQUFDaUIsSUFBSSxFQUFDUixHQUFHLENBQUNULEVBQUU7TUFBQ2tCLEtBQUssRUFBQztJQUFhLENBQUMsQ0FBQztJQUFDdUYsS0FBSyxHQUFDbkosR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLGtCQUFrQixFQUFDO01BQUN5RCxNQUFNLEVBQUNnRixLQUFLLENBQUNoRyxFQUFFO01BQUNpQixJQUFJLEVBQUNSLEdBQUcsQ0FBQ1QsRUFBRTtNQUFDa0IsS0FBSyxFQUFDLGtCQUFrQjtNQUFDQyxTQUFTLEVBQUMsQ0FBQ2dGLFFBQVEsQ0FBQ25HLEVBQUUsRUFBQ3FHLFFBQVEsQ0FBQ3JHLEVBQUU7SUFBQyxDQUFDLENBQUM7RUFBQzFDLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFlBQVksRUFBQyxXQUFXLEVBQUM7SUFBQytELE9BQU8sRUFBQyxDQUFDMUIsS0FBSyxDQUFDSSxFQUFFLEVBQUNnRyxLQUFLLENBQUNoRyxFQUFFLEVBQUNTLEdBQUcsQ0FBQ1QsRUFBRSxDQUFDO0lBQUN1QixPQUFPLEVBQUMsQ0FBQytFLEdBQUcsQ0FBQ3RHLEVBQUUsRUFBQ3VHLElBQUksQ0FBQ3ZHLEVBQUUsRUFBQ3dHLElBQUksQ0FBQ3hHLEVBQUUsRUFBQ3lHLEtBQUssQ0FBQ3pHLEVBQUUsQ0FBQztJQUFDd0IsUUFBUSxFQUFDLENBQUM1QixLQUFLLENBQUNJLEVBQUUsQ0FBQztJQUFDeUIsT0FBTyxFQUFDLENBQUNoQixHQUFHLENBQUNULEVBQUU7RUFBQyxDQUFDLENBQUM7RUFBQ3pDLENBQUMsR0FBQyxNQUFNbEIsbUJBQW1CLENBQUNrQixDQUFDLEVBQUMsV0FBVyxDQUFDO0VBQUMsTUFBTXFFLEdBQUcsR0FBQ3JFLENBQUMsQ0FBQ3NFLFNBQVMsQ0FBQ2pELEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRTtFQUFDLE1BQU1vRSxLQUFLLEdBQUMsTUFBTXRHLElBQUksQ0FBQ3VCLElBQUksRUFBQ1YsQ0FBQyxDQUFDO0lBQUNtSixNQUF3QixHQUFDLEVBQUU7SUFBQ0MsU0FBc0IsR0FBQyxFQUFFO0VBQ3J2QixLQUFJLE1BQU1DLEtBQUssSUFBSSxDQUFDTixHQUFHLEVBQUNDLElBQUksQ0FBQyxFQUFDO0lBQUMsTUFBTXhKLE1BQU0sQ0FBQ2tCLElBQUksQ0FBQztJQUFDLE1BQU1qQixLQUFLLENBQUNpQixJQUFJLEVBQUMyQixLQUFLLENBQUNJLEVBQUUsRUFBQzRCLEdBQUcsQ0FBQzVCLEVBQUUsRUFBQyxZQUFZLENBQUM7SUFBQyxNQUFNakUsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUM2SCxRQUFRLENBQUNySSxJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLEdBQUcsQ0FBQztJQUFDLE1BQU1oRixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO01BQUN6RixJQUFJLEVBQUNtSixLQUFLLENBQUNsSixJQUFJLENBQUN3RCxLQUFNO01BQUM1QyxLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0lBQUMsTUFBTXBILE1BQU0sQ0FBQ2tDLElBQUksQ0FBQ0MsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQzJJLFVBQVUsQ0FBQ2QsS0FBSyxDQUFDdEksSUFBSSxDQUFDO0lBQUMsTUFBTTFCLE1BQU0sQ0FBQ2lDLFFBQVEsQ0FBQ0MsSUFBSSxFQUFDNkgsUUFBUSxDQUFDckksSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLGFBQWEsQ0FBQzJELEtBQUssS0FBR04sR0FBRyxHQUFDLEdBQUcsR0FBQyxHQUFHLENBQUM7SUFBQyxNQUFNdkssTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNlLEdBQUcsQ0FBQ3ZCLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMyRCxLQUFLLEtBQUdOLEdBQUcsR0FBQyxNQUFNLEdBQUMsT0FBTyxDQUFDO0lBQUMsTUFBTXJJLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ3pGLElBQUksRUFBQytJLElBQUksQ0FBQzlJLElBQUksQ0FBQ3dELEtBQU07TUFBQzVDLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7SUFBQyxNQUFNbEcsV0FBVyxDQUFDZ0IsSUFBSSxDQUFDO0lBQUMsTUFBTXVGLEtBQUssR0FBQyxNQUFNakYsU0FBUyxDQUFDTixJQUFJLENBQUM7SUFBQ3lJLE1BQU0sQ0FBQzNJLElBQUksQ0FBQ3lGLEtBQUssQ0FBQy9FLEtBQUssQ0FBQztJQUFDLE1BQU1xSSxRQUFRLEdBQUN0RCxLQUFLLENBQUNoRixJQUFJLENBQUNFLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDa0QsU0FBUyxDQUFDMkMsSUFBSSxDQUFDakgsQ0FBQyxJQUFFQSxDQUFDLENBQUN5QyxFQUFFLEtBQUd3RCxLQUFLLENBQUMvRSxLQUFLLENBQUNmLElBQUksQ0FBQ3NFLGdCQUFnQixDQUFFO0lBQUNqRyxNQUFNLENBQUMrSyxRQUFRLENBQUNDLE9BQU8sQ0FBQyxDQUFDMUUsT0FBTyxDQUFDVCxHQUFHLENBQUNtRixPQUFPLENBQUM7SUFBQ2hMLE1BQU0sQ0FBQytLLFFBQVEsQ0FBQ0UsV0FBVyxDQUFDLENBQUNyRixJQUFJLENBQUNDLEdBQUcsQ0FBQ29GLFdBQVcsQ0FBQztJQUFDTCxTQUFTLENBQUM1SSxJQUFJLENBQUMrSSxRQUFRLENBQUM7RUFBQztFQUNuMUIvSyxNQUFNLENBQUMySyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNoSixJQUFJLENBQUMrRixLQUFLLENBQUM3RSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRWlGLEtBQUssQ0FBQ3pCLGNBQWMsQ0FBQzBELFFBQVEsQ0FBQzlGLEVBQUUsQ0FBQyxDQUFDLENBQUNxQyxPQUFPLENBQUM7SUFBQ2pELElBQUksRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQztFQUFDLENBQUMsQ0FBQztFQUFDdEQsTUFBTSxDQUFDMkssTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDaEosSUFBSSxDQUFDK0YsS0FBSyxDQUFDN0UsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVpRixLQUFLLENBQUN6QixjQUFjLENBQUMwRCxRQUFRLENBQUM5RixFQUFFLENBQUMsQ0FBQyxDQUFDcUMsT0FBTyxDQUFDO0lBQUNqRCxJQUFJLEVBQUMsU0FBUztJQUFDQyxLQUFLLEVBQUM7RUFBQyxDQUFDLENBQUM7RUFBQ3RELE1BQU0sQ0FBQzRLLFNBQVMsQ0FBQ00sS0FBSyxDQUFDMUosQ0FBQyxJQUFFQSxDQUFDLENBQUN5SixXQUFXLEtBQUdwRixHQUFHLENBQUNvRixXQUFXLENBQUMsQ0FBQyxDQUFDckYsSUFBSSxDQUFDLElBQUksQ0FBQztFQUFDLE1BQU01RSxNQUFNLENBQUNrQixJQUFJLENBQUM7RUFBQyxNQUFNaUosVUFBVSxHQUFDakosSUFBSSxDQUFDQyxPQUFPLENBQUMsbUJBQW1CLENBQUM7RUFBQyxNQUFNaUosYUFBYSxHQUFDRCxVQUFVLENBQUNoRSxTQUFTLENBQUMsVUFBVSxDQUFDO0VBQUMsTUFBTW5ILE1BQU0sQ0FBQ29MLGFBQWEsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQUMsS0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUNYLE1BQU0sQ0FBQ1ksTUFBTSxFQUFDRCxDQUFDLEVBQUUsRUFBQztJQUFDLE1BQU10TCxNQUFNLENBQUNvTCxhQUFhLENBQUNJLEdBQUcsQ0FBQ0YsQ0FBQyxDQUFDLENBQUNuSixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQytFLGFBQWEsQ0FBQ3lELE1BQU0sQ0FBQ1csQ0FBQyxDQUFDLENBQUM1SixJQUFJLENBQUM7SUFBQyxNQUFNMEosYUFBYSxDQUFDSSxHQUFHLENBQUNGLENBQUMsQ0FBQyxDQUFDOUQsS0FBSyxDQUFDLENBQUM7RUFBQztFQUFDLE1BQU0yRCxVQUFVLENBQUNoRSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsZUFBZTtJQUFDYSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBILE1BQU0sQ0FBQ21MLFVBQVUsQ0FBQyxDQUFDakUsYUFBYSxDQUFDLFVBQVUsQ0FBQztFQUFDLE1BQU1sSCxNQUFNLENBQUNtTCxVQUFVLENBQUMsQ0FBQ2pFLGFBQWEsQ0FBQyxlQUFlLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDbUwsVUFBVSxDQUFDLENBQUNqRSxhQUFhLENBQUMsaUJBQWlCLEdBQUM2QyxRQUFRLENBQUM5RixFQUFFLENBQUM7RUFBQyxNQUFNakUsTUFBTSxDQUFDbUwsVUFBVSxDQUFDLENBQUNqRSxhQUFhLENBQUMsaUJBQWlCLEdBQUNqRSxHQUFHLENBQUNnQixFQUFFLENBQUM7RUFBQyxNQUFNd0gsY0FBYyxHQUFDLE1BQU1OLFVBQVUsQ0FBQ08sU0FBUyxDQUFDLENBQUM7RUFDcjhCLE1BQU1DLEtBQUssR0FBQ3pKLElBQUksQ0FBQ0MsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDQyxNQUFNLENBQUM7SUFBQ0MsR0FBRyxFQUFDSCxJQUFJLENBQUNDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQ0MsTUFBTSxDQUFDO01BQUN3SixPQUFPLEVBQUMsSUFBSXhELE1BQU0sQ0FBQyxHQUFHLEdBQUMyQixRQUFRLENBQUNySSxJQUFJLEdBQUMsVUFBVTtJQUFDLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNaUssS0FBSyxDQUFDeEosT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDMEosS0FBSyxDQUFDLENBQUMsQ0FBQ3pFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXVFLEtBQUssQ0FBQ3hFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQ3lJLFNBQVMsQ0FBQ3pJLElBQUk7SUFBQ2EsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM2RSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU0wRSxVQUFVLEdBQUM1SixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsU0FBUztJQUFDYSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUM7RUFBQyxNQUFNdkMsTUFBTSxDQUFDOEwsVUFBVSxDQUFDLENBQUM1RSxhQUFhLENBQUNpRCxTQUFTLENBQUN6SSxJQUFJLENBQUM7RUFBQyxNQUFNMUIsTUFBTSxDQUFDOEwsVUFBVSxDQUFDLENBQUM1RSxhQUFhLENBQUMwRCxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUNtQixZQUFZLENBQUM7RUFBQyxNQUFNRCxVQUFVLENBQUMzRSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUM7RUFBSyxDQUFDLENBQUMsQ0FBQ3NLLElBQUksQ0FBQyxDQUFDLENBQUM1RSxLQUFLLENBQUMsQ0FBQztFQUM1ZixNQUFNNkUsV0FBNkIsR0FBQyxFQUFFO0VBQUMsS0FBSSxNQUFNcEIsS0FBSyxJQUFJLENBQUNOLEdBQUcsRUFBQ0MsSUFBSSxDQUFDLEVBQUM7SUFBQyxNQUFNeEosTUFBTSxDQUFDa0IsSUFBSSxDQUFDO0lBQUMsTUFBTWpCLEtBQUssQ0FBQ2lCLElBQUksRUFBQzJCLEtBQUssQ0FBQ0ksRUFBRSxFQUFDNEIsR0FBRyxDQUFDNUIsRUFBRSxFQUFDLFlBQVksQ0FBQztJQUFDLE1BQU0vQixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO01BQUN6RixJQUFJLEVBQUNtSixLQUFLLENBQUNsSixJQUFJLENBQUN3RCxLQUFNO01BQUM1QyxLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0lBQUMsTUFBTWxGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ3pGLElBQUksRUFBQ2dKLEtBQUssQ0FBQy9JLElBQUksQ0FBQ3dELEtBQU07TUFBQzVDLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7SUFBQyxNQUFNcEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUM2SCxRQUFRLENBQUNySSxJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLEdBQUcsQ0FBQztJQUFDLE1BQU1sSCxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ2UsR0FBRyxDQUFDdkIsSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLGFBQWEsQ0FBQyxPQUFPLENBQUM7SUFBQyxNQUFNaEcsV0FBVyxDQUFDZ0IsSUFBSSxDQUFDO0lBQUMsTUFBTXVGLEtBQUssR0FBQyxNQUFNakYsU0FBUyxDQUFDTixJQUFJLENBQUM7SUFBQytKLFdBQVcsQ0FBQ2pLLElBQUksQ0FBQ3lGLEtBQUssQ0FBQy9FLEtBQUssQ0FBQztFQUFDO0VBQUMsS0FBSSxNQUFNQSxLQUFLLElBQUl1SixXQUFXLEVBQUNqTSxNQUFNLENBQUMwQyxLQUFLLENBQUNmLElBQUksQ0FBQytGLEtBQUssQ0FBQzdFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFaUYsS0FBSyxDQUFDekIsY0FBYyxDQUFDLENBQUNDLE9BQU8sQ0FBQ3FFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ2hKLElBQUksQ0FBQytGLEtBQUssQ0FBQzdFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFaUYsS0FBSyxDQUFDekIsY0FBYyxDQUFDO0VBQUNyRyxNQUFNLENBQUNpTSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUN0SyxJQUFJLENBQUMrRixLQUFLLENBQUM3RSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRXFKLE1BQU0sQ0FBQzdGLGNBQWMsQ0FBQzBELFFBQVEsQ0FBQzlGLEVBQUUsQ0FBQyxDQUFDLENBQUNxQyxPQUFPLENBQUM7SUFBQ2pELElBQUksRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQztFQUFDLENBQUMsQ0FBQztFQUFDdEQsTUFBTSxDQUFDaU0sV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDdEssSUFBSSxDQUFDK0YsS0FBSyxDQUFDN0UsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUUyQyxPQUFPLENBQUMsQ0FBQzJHLFNBQVMsQ0FBQ3pCLEtBQUssQ0FBQ3pHLEVBQUUsQ0FBQztFQUFDakUsTUFBTSxDQUFDMEssS0FBSyxDQUFDL0ksSUFBSSxDQUFDeUQsU0FBUyxDQUFDLENBQUMrRyxTQUFTLENBQUM3QixRQUFRLENBQUNyRyxFQUFFLENBQUM7RUFDMTJCLE1BQU0vQixJQUFJLENBQUNpRyxNQUFNLENBQUMsQ0FBQztFQUFDLE1BQU1FLElBQUksR0FBQyxNQUFNekgsTUFBTSxDQUFDc0IsSUFBSSxDQUFDO0lBQUNvRyxLQUFLLEdBQUMsTUFBTWxILGNBQWMsQ0FBQzBCLE9BQU8sRUFBQ3VGLElBQUksQ0FBQ0UsS0FBSyxDQUFDO0lBQUNDLEtBQUssR0FBQyxNQUFNcEgsY0FBYyxDQUFDMEIsT0FBTyxFQUFDdUYsSUFBSSxDQUFDRSxLQUFLLEVBQUMsT0FBTyxDQUFDO0VBQUN2SSxNQUFNLENBQUNxSSxJQUFJLENBQUMxRixNQUFNLENBQUNDLE9BQU8sQ0FBQ2tELFNBQVMsQ0FBQzJDLElBQUksQ0FBQ2QsQ0FBQyxJQUFFQSxDQUFDLENBQUMxRCxFQUFFLEtBQUc0QixHQUFHLENBQUM1QixFQUFFLENBQUMsQ0FBQyxDQUFDcUMsT0FBTyxDQUFDVCxHQUFHLENBQUM7RUFBQzdGLE1BQU0sQ0FBQ3NJLEtBQUssQ0FBQzNGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDYixRQUFRLENBQUNLLE1BQU0sQ0FBQ1IsQ0FBQyxJQUFFQSxDQUFDLENBQUNILElBQUksS0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDNkUsT0FBTyxDQUFDK0IsSUFBSSxDQUFDMUYsTUFBTSxDQUFDQyxPQUFPLENBQUNiLFFBQVEsQ0FBQ0ssTUFBTSxDQUFDUixDQUFDLElBQUVBLENBQUMsQ0FBQ0gsSUFBSSxLQUFHLE9BQU8sQ0FBQyxDQUFDO0VBQUN6QixNQUFNLENBQUN3SSxLQUFLLENBQUM3RixNQUFNLENBQUNDLE9BQU8sQ0FBQ2IsUUFBUSxDQUFDSyxNQUFNLENBQUNSLENBQUMsSUFBRUEsQ0FBQyxDQUFDSCxJQUFJLEtBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQ29HLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFBQyxNQUFNOUcsUUFBUSxDQUFDZ0MsSUFBSSxFQUFDLG9CQUFvQixFQUFDO0lBQUMyRixrQkFBa0IsRUFBQyxRQUFRO0lBQUNDLGFBQWEsRUFBQzdILE1BQU0sQ0FBQ21HLEtBQUssQ0FBQztJQUFDMkIsS0FBSyxFQUFDO01BQUN3RCxXQUFXLEVBQUMsSUFBSTtNQUFDQyxlQUFlLEVBQUMsQ0FBQztNQUFDQyxXQUFXLEVBQUN6RyxHQUFHLENBQUM1QixFQUFFO01BQUNnSCxXQUFXLEVBQUNwRixHQUFHLENBQUNvRjtJQUFXLENBQUM7SUFBQ25DLElBQUksRUFBQztNQUFDeUQsK0JBQStCLEVBQUMsSUFBSTtNQUFDQyxxQkFBcUIsRUFBQyxJQUFJO01BQUNDLGtCQUFrQixFQUFDdEMsU0FBUyxDQUFDbEcsRUFBRTtNQUFDeUksc0JBQXNCLEVBQUM7SUFBSSxDQUFDO0lBQUNyRCxJQUFJLEVBQUM7TUFBQ3NELGdDQUFnQyxFQUFDLElBQUk7TUFBQ0MsK0JBQStCLEVBQUM7SUFBSSxDQUFDO0lBQUNyRCxRQUFRLEVBQUM7TUFBQ3NELG9CQUFvQixFQUFDLElBQUk7TUFBQ0MscUNBQXFDLEVBQUMsSUFBSTtNQUFDQyw2QkFBNkIsRUFBQztJQUFJLENBQUM7SUFBQ3RCLGNBQWM7SUFBQ3VCLGdCQUFnQixFQUFDcEMsU0FBUyxDQUFDcUMsR0FBRyxDQUFDekwsQ0FBQyxLQUFHO01BQUN5QyxFQUFFLEVBQUN6QyxDQUFDLENBQUN5QyxFQUFFO01BQUNnSCxXQUFXLEVBQUN6SixDQUFDLENBQUN5SixXQUFXO01BQUNpQyx3QkFBd0IsRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUNDLDJDQUEyQyxFQUFDLElBQUk7SUFBQ3hDLE1BQU0sRUFBQ0EsTUFBTSxDQUFDc0MsR0FBRyxDQUFDRyxDQUFDLElBQUVBLENBQUMsQ0FBQ3pMLElBQUksQ0FBQztJQUFDc0ssV0FBVyxFQUFDQSxXQUFXLENBQUNnQixHQUFHLENBQUNHLENBQUMsSUFBRUEsQ0FBQyxDQUFDekwsSUFBSSxDQUFDO0lBQUNpSSxZQUFZLEVBQUMsSUFBSTtJQUFDQyxRQUFRLEVBQUMsU0FBUztJQUFDQyxxQkFBcUIsRUFBQztFQUFLLENBQUMsQ0FBQztBQUMxdUMsQ0FBQyxDQUFDO0FBRUYvSixJQUFJLENBQUMsaUxBQWlMLEVBQUMsT0FBTTtFQUFDbUMsSUFBSTtFQUFDWTtBQUFPLENBQUMsRUFBQ0MsSUFBSSxLQUFHO0VBQ2xOaEQsSUFBSSxDQUFDaUQsVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUFDLElBQUl4QixDQUFDLEdBQUN0QixhQUFhLENBQUMsa0JBQWtCLENBQUM7RUFBQyxNQUFNbU4sS0FBSyxHQUFDOUwsR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLFVBQVUsRUFBQztNQUFDeUIsR0FBRyxFQUFDLE9BQU87TUFBQ0MsU0FBUyxFQUFDLFNBQVM7TUFBQ0MsS0FBSyxFQUFDLEtBQUs7TUFBQ0MsT0FBTyxFQUFDO1FBQUNDLElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFFLENBQUM7TUFBQ0UsT0FBTyxFQUFDO1FBQUNDLEdBQUcsRUFBQyxDQUFDO1FBQUNDLEdBQUcsRUFBQztNQUFHO0lBQUMsQ0FBQyxDQUFDO0lBQUM0SixNQUFNLEdBQUMvTCxHQUFHLENBQUNDLENBQUMsRUFBQyxVQUFVLEVBQUMsZUFBZSxFQUFDO01BQUN5QixHQUFHLEVBQUMsWUFBWTtNQUFDQyxTQUFTLEVBQUMsU0FBUztNQUFDQyxLQUFLLEVBQUMsYUFBYTtNQUFDQyxPQUFPLEVBQUM7UUFBQ0MsSUFBSSxFQUFDLFNBQVM7UUFBQ0MsS0FBSyxFQUFDO01BQUs7SUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNaUssTUFBTSxHQUFDLENBQUMsVUFBVSxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsT0FBTyxFQUFDLE9BQU8sQ0FBQyxDQUFDTixHQUFHLENBQUN2TCxJQUFJLElBQUVILEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLE9BQU8sRUFBQ0UsSUFBSSxFQUFDO0lBQUNrQyxJQUFJLEVBQUN4RCxjQUFjLENBQUNzQixJQUFJLEdBQUMsT0FBTztFQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTW1LLEtBQUssR0FBQ25MLGdCQUFnQixDQUFDYyxDQUFDLEVBQUM7SUFBQ2dNLElBQUksRUFBQyxlQUFlO0lBQUNDLFFBQVEsRUFBQ0YsTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDVCxHQUFHLENBQUN0RixDQUFDLElBQUVBLENBQUMsQ0FBQzFELEVBQUUsQ0FBQztJQUFDdkMsSUFBSSxFQUFDO0VBQVcsQ0FBQyxDQUFDO0VBQUNGLENBQUMsR0FBQ3FLLEtBQUssQ0FBQzhCLFNBQVM7RUFBQyxNQUFNQyxNQUFNLEdBQUNsTixnQkFBZ0IsQ0FBQ2MsQ0FBQyxFQUFDO0lBQUNnTSxJQUFJLEVBQUMsUUFBUTtJQUFDQyxRQUFRLEVBQUNGLE1BQU0sQ0FBQ0csS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDVCxHQUFHLENBQUN0RixDQUFDLElBQUVBLENBQUMsQ0FBQzFELEVBQUUsQ0FBQztJQUFDdkMsSUFBSSxFQUFDO0VBQVcsQ0FBQyxDQUFDO0VBQUNGLENBQUMsR0FBQ29NLE1BQU0sQ0FBQ0QsU0FBUztFQUFDLE1BQU1FLFFBQVEsR0FBQ3RNLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFFBQVEsRUFBQyxZQUFZLEVBQUM7TUFBQ3FELFNBQVMsRUFBQyxLQUFLO01BQUNDLFFBQVEsRUFBQ3VJLEtBQUssQ0FBQ3BKLEVBQUU7TUFBQ1gsS0FBSyxFQUFDO1FBQUNELElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFDO0lBQUMsQ0FBQyxDQUFDO0lBQUN3SyxRQUFRLEdBQUN2TSxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsV0FBVyxFQUFDO01BQUNxRCxTQUFTLEVBQUMsS0FBSztNQUFDQyxRQUFRLEVBQUN3SSxNQUFNLENBQUNySixFQUFFO01BQUNYLEtBQUssRUFBQztRQUFDRCxJQUFJLEVBQUMsU0FBUztRQUFDQyxLQUFLLEVBQUM7TUFBSTtJQUFDLENBQUMsQ0FBQztFQUFDLEtBQUksTUFBTTFCLENBQUMsSUFBSUosQ0FBQyxDQUFDTyxRQUFRLEVBQUMsSUFBR0gsQ0FBQyxDQUFDSCxJQUFJLEtBQUcsV0FBVyxJQUFFRyxDQUFDLENBQUNELElBQUksQ0FBQ3NELE1BQU0sS0FBRzJJLE1BQU0sQ0FBQzVILE9BQU8sRUFBQ3BFLENBQUMsQ0FBQ0QsSUFBSSxDQUFDeUQsU0FBUyxHQUFDLENBQUN5SSxRQUFRLENBQUM1SixFQUFFLEVBQUM2SixRQUFRLENBQUM3SixFQUFFLENBQUM7RUFBQyxLQUFJLE1BQU1yQyxDQUFDLElBQUlKLENBQUMsQ0FBQ08sUUFBUSxFQUFDSCxDQUFDLENBQUNFLE1BQU0sR0FBQyxXQUFXO0VBQzVsQyxNQUFNaU0sSUFBSSxHQUFDeE0sR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFdBQVcsRUFBQztNQUFDc0MsUUFBUSxFQUFDO0lBQU8sQ0FBQyxDQUFDO0lBQUNrSyxPQUFPLEdBQUN6TSxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsbUJBQW1CLEVBQUM7TUFBQ3NDLFFBQVEsRUFBQyxVQUFVO01BQUNhLGNBQWMsRUFBQztJQUFtQixDQUFDLENBQUM7SUFBQ3NKLFNBQVMsR0FBQzFNLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxVQUFVLEVBQUM7TUFBQ3lELE1BQU0sRUFBQzhJLElBQUksQ0FBQzlKLEVBQUU7TUFBQ2lCLElBQUksRUFBQzhJLE9BQU8sQ0FBQy9KLEVBQUU7TUFBQ2tCLEtBQUssRUFBQyxVQUFVO01BQUMrSSxTQUFTLEVBQUM7UUFBQy9KLEVBQUUsRUFBQyxVQUFVO1FBQUNiLEtBQUssRUFBQztNQUFLO0lBQUMsQ0FBQyxDQUFDO0VBQUMvQixHQUFHLENBQUNDLENBQUMsRUFBQyxZQUFZLEVBQUMsUUFBUSxFQUFDO0lBQUMrRCxPQUFPLEVBQUMsQ0FBQ3dJLElBQUksQ0FBQzlKLEVBQUUsRUFBQytKLE9BQU8sQ0FBQy9KLEVBQUUsQ0FBQztJQUFDdUIsT0FBTyxFQUFDLENBQUN5SSxTQUFTLENBQUNoSyxFQUFFLENBQUM7SUFBQ3dCLFFBQVEsRUFBQyxDQUFDc0ksSUFBSSxDQUFDOUosRUFBRSxDQUFDO0lBQUN5QixPQUFPLEVBQUMsQ0FBQ3NJLE9BQU8sQ0FBQy9KLEVBQUU7RUFBQyxDQUFDLENBQUM7RUFBQ2pFLE1BQU0sQ0FBQ0ssZUFBZSxDQUFDbUIsQ0FBQyxDQUFDLENBQUNtRSxFQUFFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztFQUFDcEUsQ0FBQyxHQUFDLE1BQU1sQixtQkFBbUIsQ0FBQ2tCLENBQUMsRUFBQyxXQUFXLENBQUM7RUFBQyxNQUFNcUUsR0FBRyxHQUFDckUsQ0FBQyxDQUFDc0UsU0FBUyxDQUFDakQsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFFO0lBQUNvRSxLQUFLLEdBQUMsTUFBTXRHLElBQUksQ0FBQ3VCLElBQUksRUFBQ1YsQ0FBQyxDQUFDO0VBQzFpQixNQUFNUixNQUFNLENBQUNrQixJQUFJLENBQUM7RUFBQyxNQUFNakIsS0FBSyxDQUFDaUIsSUFBSSxFQUFDMkosS0FBSyxDQUFDN0YsT0FBTyxFQUFDSCxHQUFHLENBQUM1QixFQUFFLEVBQUMsZ0JBQWdCLENBQUM7RUFBQyxNQUFNL0IsSUFBSSxDQUFDaUYsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDekYsSUFBSSxFQUFDLFlBQVk7SUFBQ2EsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM2RSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1wSCxNQUFNLENBQUNrQyxJQUFJLENBQUNDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDK0UsYUFBYSxDQUFDLGFBQWEsQ0FBQztFQUFDLE1BQU1oRixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsV0FBVztJQUFDYSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQyxZQUFZO0lBQUNhLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQytFLGFBQWEsQ0FBQyxZQUFZLENBQUM7RUFBQyxNQUFNaEYsSUFBSSxDQUFDaUYsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDekYsSUFBSSxFQUFDLE1BQU07SUFBQ2EsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM2RSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1sRixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsTUFBTTtJQUFDYSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBILE1BQU0sQ0FBQ2tDLElBQUksQ0FBQ0MsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMrRSxhQUFhLENBQUMsYUFBYSxDQUFDO0VBQUMsTUFBTWhGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQyxZQUFZO0lBQUNhLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNbEcsV0FBVyxDQUFDZ0IsSUFBSSxDQUFDO0VBQUMsTUFBTWlNLFVBQVUsR0FBQyxNQUFNM0wsU0FBUyxDQUFDTixJQUFJLENBQUM7RUFBQ2xDLE1BQU0sQ0FBQ21PLFVBQVUsQ0FBQ3pMLEtBQUssQ0FBQ2YsSUFBSSxDQUFDK0YsS0FBSyxDQUFDN0UsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVpRixLQUFLLENBQUNzRyxPQUFPLENBQUMsQ0FBQ2pDLFNBQVMsQ0FBQ29CLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3RKLEVBQUUsQ0FBQztFQUM1MEIsTUFBTWpELE1BQU0sQ0FBQ2tCLElBQUksQ0FBQztFQUFDLE1BQU1qQixLQUFLLENBQUNpQixJQUFJLEVBQUMwTCxNQUFNLENBQUM1SCxPQUFPLEVBQUNILEdBQUcsQ0FBQzVCLEVBQUUsRUFBQyxnQkFBZ0IsQ0FBQztFQUFDLE1BQU1qRSxNQUFNLENBQUNrQyxJQUFJLENBQUNDLE9BQU8sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUNrSixXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTW5KLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQyxXQUFXO0lBQUNhLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNaUgsa0JBQWtCLEdBQUMsTUFBTW5NLElBQUksQ0FBQ0MsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUN1SixTQUFTLENBQUMsQ0FBQztFQUFDMUwsTUFBTSxDQUFDdU4sTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNULEdBQUcsQ0FBQ3RGLENBQUMsSUFBRUEsQ0FBQyxDQUFDakcsSUFBSSxDQUFDLENBQUMsQ0FBQ3lLLFNBQVMsQ0FBQ2tDLGtCQUFrQixDQUFDO0VBQUMsTUFBTXJPLE1BQU0sQ0FBQ2lDLFFBQVEsQ0FBQ0MsSUFBSSxFQUFDbUwsS0FBSyxDQUFDM0wsSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLGFBQWEsQ0FBQyxJQUFJLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNvTCxNQUFNLENBQUM1TCxJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLE1BQU0sQ0FBQztFQUFDLE1BQU1sSCxNQUFNLENBQUNrQyxJQUFJLENBQUNDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMrRSxhQUFhLENBQUMsTUFBTSxDQUFDO0VBQUMsTUFBTW9ILFlBQVksR0FBQyxNQUFNcE0sSUFBSSxDQUFDQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQ3VKLFNBQVMsQ0FBQyxDQUFDO0VBQUMsTUFBTXhKLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQyxNQUFNO0lBQUNhLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNtTCxLQUFLLENBQUMzTCxJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLElBQUksQ0FBQztFQUFDLE1BQU1sSCxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ29MLE1BQU0sQ0FBQzVMLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsT0FBTyxDQUFDO0VBQUMsTUFBTWhGLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQyxXQUFXO0lBQUNhLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDMkksVUFBVSxDQUFDdUQsa0JBQWtCLENBQUM7RUFBQ3JPLE1BQU0sQ0FBQyxNQUFNa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQ3VKLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzlGLElBQUksQ0FBQzBJLFlBQVksQ0FBQztFQUFDLE1BQU1wTSxJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsWUFBWTtJQUFDYSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxHLFdBQVcsQ0FBQ2dCLElBQUksQ0FBQztFQUFDLE1BQU1xTSxXQUFXLEdBQUMsTUFBTS9MLFNBQVMsQ0FBQ04sSUFBSSxDQUFDO0lBQUNzTSxXQUFXLEdBQUNELFdBQVcsQ0FBQzdMLEtBQUs7RUFBQzFDLE1BQU0sQ0FBQ3dPLFdBQVcsQ0FBQzdNLElBQUksQ0FBQ2hCLElBQUksQ0FBQyxDQUFDaUYsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0VBQUM1RixNQUFNLENBQUN3TyxXQUFXLENBQUM3TSxJQUFJLENBQUMrRixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUN3RSxNQUFNLENBQUN1QyxXQUFXLENBQUMsQ0FBQzdJLElBQUksQ0FBQyxDQUFDLENBQUM7RUFBQzVGLE1BQU0sQ0FBQ3dPLFdBQVcsQ0FBQzdNLElBQUksQ0FBQytGLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksS0FBSyxDQUFDMkcsV0FBVyxDQUFDLENBQUNDLGVBQWUsQ0FBQyxDQUFDLENBQUM7RUFBQzFPLE1BQU0sQ0FBQ3dPLFdBQVcsQ0FBQzdNLElBQUksQ0FBQytGLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksS0FBSyxDQUFDc0csT0FBTyxDQUFDcEcsSUFBSSxDQUFDL0QsRUFBRSxJQUFFc0osTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMxRixJQUFJLENBQUNMLENBQUMsSUFBRUEsQ0FBQyxDQUFDMUQsRUFBRSxLQUFHQSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMyQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2ovQyxNQUFNNUUsTUFBTSxDQUFDa0IsSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDaUYsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDekYsSUFBSSxFQUFDLE1BQU07SUFBQ2EsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM2RSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1wSCxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ21MLEtBQUssQ0FBQzNMLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsSUFBSSxDQUFDO0VBQUMsTUFBTWxILE1BQU0sQ0FBQ2lDLFFBQVEsQ0FBQ0MsSUFBSSxFQUFDb0wsTUFBTSxDQUFDNUwsSUFBSSxDQUFDLENBQUMsQ0FBQ3dGLGFBQWEsQ0FBQyxNQUFNLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDK0UsYUFBYSxDQUFDLEtBQUssSUFBRXNILFdBQVcsQ0FBQzdNLElBQUksQ0FBQytGLEtBQUssQ0FBQzdFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFaUYsS0FBSyxDQUFDNkcsVUFBVSxHQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTXpNLElBQUksQ0FBQ2lGLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ3pGLElBQUksRUFBQyxRQUFRO0lBQUNhLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNtTCxLQUFLLENBQUMzTCxJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLElBQUksQ0FBQztFQUFDLE1BQU1sSCxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ29MLE1BQU0sQ0FBQzVMLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsT0FBTyxDQUFDO0VBQ3hnQixNQUFNakcsS0FBSyxDQUFDaUIsSUFBSSxFQUFDNkwsSUFBSSxDQUFDOUosRUFBRSxFQUFDNEIsR0FBRyxDQUFDNUIsRUFBRSxFQUFDLGdCQUFnQixDQUFDO0VBQUMsTUFBTWpFLE1BQU0sQ0FBQ2tDLElBQUksQ0FBQ0MsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQytFLGFBQWEsQ0FBQyxNQUFNLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQ0MsTUFBTSxDQUFDO0lBQUNDLEdBQUcsRUFBQ0gsSUFBSSxDQUFDSSxTQUFTLENBQUMyTCxTQUFTLENBQUN0TSxJQUFJLENBQUN3RCxLQUFLLEVBQUU7TUFBQzVDLEtBQUssRUFBQztJQUFJLENBQUM7RUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOEUsWUFBWSxDQUFDLENBQUM7RUFBQyxNQUFNckgsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDeU0sR0FBRyxDQUFDMUgsYUFBYSxDQUFDLFFBQVEsQ0FBQztFQUFDLE1BQU0vRixVQUFVLENBQUNlLElBQUksRUFBQyxXQUFXLEVBQUM2TCxJQUFJLENBQUNyTSxJQUFJLENBQUM7RUFBQyxNQUFNTCxRQUFRLENBQUNhLElBQUksRUFBQ1AsSUFBSSxJQUFFO0lBQUNBLElBQUksQ0FBQ2tOLFVBQVUsR0FBQ2IsT0FBTyxDQUFDL0osRUFBRTtFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU0zQyxVQUFVLENBQUNZLElBQUksQ0FBQztFQUFDLE1BQU1sQixNQUFNLENBQUNrQixJQUFJLENBQUM7RUFBQyxNQUFNakIsS0FBSyxDQUFDaUIsSUFBSSxFQUFDNkwsSUFBSSxDQUFDOUosRUFBRSxFQUFDLEVBQUUsRUFBQyxnQkFBZ0IsQ0FBQztFQUFDLE1BQU0vQixJQUFJLENBQUNpRixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUN6RixJQUFJLEVBQUMsVUFBVSxHQUFDc00sT0FBTyxDQUFDdE0sSUFBSTtJQUFDYSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzZFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBILE1BQU0sQ0FBQ2tDLElBQUksQ0FBQ0MsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQytFLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFDbnFCLE1BQU1oRixJQUFJLENBQUNpRyxNQUFNLENBQUMsQ0FBQztFQUFDLE1BQU1uSCxNQUFNLENBQUNrQixJQUFJLENBQUM7RUFBQyxNQUFNNE0sYUFBYSxHQUFDNU0sSUFBSSxDQUFDQyxPQUFPLENBQUMscUNBQXFDLENBQUM7RUFBQyxNQUFNbkMsTUFBTSxDQUFDOE8sYUFBYSxDQUFDLENBQUN6RCxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTXJMLE1BQU0sQ0FBQzhPLGFBQWEsQ0FBQ3RELEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDdEUsYUFBYSxDQUFDc0gsV0FBVyxDQUFDOU0sSUFBSSxDQUFDO0VBQUMsTUFBTW9OLGFBQWEsQ0FBQ3RELEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ3BFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBILE1BQU0sQ0FBQ2tDLElBQUksQ0FBQ0MsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQytFLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFBQyxNQUFNbEgsTUFBTSxDQUFDaUMsUUFBUSxDQUFDQyxJQUFJLEVBQUNtTCxLQUFLLENBQUMzTCxJQUFJLENBQUMsQ0FBQyxDQUFDd0YsYUFBYSxDQUFDLElBQUksQ0FBQztFQUFDLE1BQU1sSCxNQUFNLENBQUNpQyxRQUFRLENBQUNDLElBQUksRUFBQ29MLE1BQU0sQ0FBQzVMLElBQUksQ0FBQyxDQUFDLENBQUN3RixhQUFhLENBQUMsTUFBTSxDQUFDO0VBQUMsTUFBTW1CLElBQUksR0FBQyxNQUFNekgsTUFBTSxDQUFDc0IsSUFBSSxDQUFDO0lBQUNvRyxLQUFLLEdBQUMsTUFBTWxILGNBQWMsQ0FBQzBCLE9BQU8sRUFBQ3VGLElBQUksQ0FBQ0UsS0FBSyxDQUFDO0lBQUNDLEtBQUssR0FBQyxNQUFNcEgsY0FBYyxDQUFDMEIsT0FBTyxFQUFDdUYsSUFBSSxDQUFDRSxLQUFLLEVBQUMsT0FBTyxDQUFDO0VBQUN2SSxNQUFNLENBQUNzSSxLQUFLLENBQUMzRixNQUFNLENBQUNDLE9BQU8sQ0FBQ2IsUUFBUSxDQUFDMEcsSUFBSSxDQUFDN0csQ0FBQyxJQUFFQSxDQUFDLENBQUNxQyxFQUFFLEtBQUd1SyxXQUFXLENBQUN2SyxFQUFFLENBQUMsQ0FBQyxDQUFDcUMsT0FBTyxDQUFDa0ksV0FBVyxDQUFDO0VBQUN4TyxNQUFNLENBQUN3SSxLQUFLLENBQUM3RixNQUFNLENBQUNDLE9BQU8sQ0FBQ2IsUUFBUSxDQUFDSyxNQUFNLENBQUNSLENBQUMsSUFBRUEsQ0FBQyxDQUFDSCxJQUFJLEtBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQ29HLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFBQyxNQUFNOUcsUUFBUSxDQUFDZ0MsSUFBSSxFQUFDLDhCQUE4QixFQUFDO0lBQUMyRixrQkFBa0IsRUFBQyxRQUFRO0lBQUNDLGFBQWEsRUFBQzdILE1BQU0sQ0FBQ21HLEtBQUssQ0FBQztJQUFDMkIsS0FBSyxFQUFDO01BQUNtRyxZQUFZLEVBQUN4QixNQUFNLENBQUNHLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUNULEdBQUcsQ0FBQ3RGLENBQUMsSUFBRUEsQ0FBQyxDQUFDMUQsRUFBRSxDQUFDO01BQUMrSyxvQkFBb0IsRUFBQyxDQUFDO01BQUNDLFFBQVEsRUFBQyxFQUFFO01BQUNDLGdCQUFnQixFQUFDO0lBQUksQ0FBQztJQUFDcEcsSUFBSSxFQUFDO01BQUNxRywyQkFBMkIsRUFBQyxJQUFJO01BQUN4TyxJQUFJLEVBQUMsZ0JBQWdCO01BQUN5TywwQkFBMEIsRUFBQyxJQUFJO01BQUNDLHlCQUF5QixFQUFDLElBQUk7TUFBQ0MsMEJBQTBCLEVBQUM7SUFBSSxDQUFDO0lBQUNqRyxJQUFJLEVBQUM7TUFBQ2tHLGtDQUFrQyxFQUFDLElBQUk7TUFBQ0Msa0NBQWtDLEVBQUM7SUFBSSxDQUFDO0lBQUNqRyxRQUFRLEVBQUM7TUFBQ2tHLHFDQUFxQyxFQUFDLElBQUk7TUFBQ0Msb0NBQW9DLEVBQUMsSUFBSTtNQUFDQyx3QkFBd0IsRUFBQztJQUFJLENBQUM7SUFBQ25CLFdBQVcsRUFBQ0EsV0FBVyxDQUFDN00sSUFBSTtJQUFDaU8sVUFBVSxFQUFDekIsVUFBVSxDQUFDekwsS0FBSyxDQUFDZixJQUFJO0lBQUMwTSxrQkFBa0I7SUFBQ3pFLFlBQVksRUFBQyxJQUFJO0lBQUNDLFFBQVEsRUFBQyxTQUFTO0lBQUNDLHFCQUFxQixFQUFDO0VBQUssQ0FBQyxDQUFDO0FBQ3Q5QyxDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=