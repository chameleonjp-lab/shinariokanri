// c5501d35ad893f3060b8ecc1c5d7a3c3b2f287ff
import { expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { unzipSync, zipSync, strFromU8, strToU8 } from 'fflate';
import { exportScenario } from '../candidate/src/storage/archive';
import { sha256, jsonBytes } from '../candidate/src/storage/json';
import { appURL, nav, importBytes, backup, durable, evidence, digest, captureProofFile } from './common';
export async function openRecord(page, kind, name) {
  await nav(page, /^資料/);
  await page.getByLabel('情報の種類', {
    exact: true
  }).selectOption(kind);
  await page.locator('.entity-card').filter({
    has: page.getByRole('heading', {
      name,
      exact: true
    })
  }).click();
  await expect(page.locator('.detail-heading')).toContainText(name);
}
export async function saveEditor(page) {
  const button = page.locator('.editor-footer').getByRole('button', {
    name: /^(保存する|保存を再試行)$/
  });
  await button.click();
  await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
}
export async function editData(page, change) {
  const advanced = page.locator('details.advanced-details').filter({
    has: page.getByText('詳細データ・ルビ・本文リンクを編集', {
      exact: true
    })
  });
  if ((await advanced.getAttribute('open')) === null) await advanced.locator('summary').click();
  const input = advanced.getByRole('textbox', {
      name: '詳細データ',
      exact: true
    }),
    data = JSON.parse(await input.inputValue());
  change(data);
  await input.fill(JSON.stringify(data));
  return input;
}
export async function reader(page) {
  await nav(page, /^構成/);
  await page.getByRole('tab', {
    name: '試読・検査',
    exact: true
  }).click();
}
export async function production(page) {
  await nav(page, /^構成/);
  await page.getByRole('tab', {
    name: '制作',
    exact: true
  }).click();
}
export async function output(page) {
  await nav(page, /^作品・保存/);
  await page.getByRole('tab', {
    name: '目的別出力',
    exact: true
  }).click();
}
export async function settings(page) {
  await nav(page, /^作品・保存/);
  await page.getByRole('tab', {
    name: '作品の設定',
    exact: true
  }).click();
}
export async function begin(page, entryId, version = '', seed = 'original-acceptance-seed') {
  await page.getByLabel('試読する作品版', {
    exact: true
  }).selectOption(version);
  await page.getByLabel('試読の開始点', {
    exact: true
  }).selectOption(entryId);
  await page.getByLabel('抽選種', {
    exact: true
  }).fill(seed);
  await page.getByRole('button', {
    name: /^(試読を始める|この状態から開始し直す)$/
  }).click();
}
export async function recordTrial(page) {
  await page.getByRole('button', {
    name: '経路を記録',
    exact: true
  }).click();
  await expect(page.getByText('開始状態と経路を端末内に保存しました。', {
    exact: true
  })).toBeVisible();
}
export async function downloadArtifact(page, filename) {
  var _filename$split$at;
  const item = page.locator('.export-artifact').filter({
    hasText: filename
  });
  await expect(item).toBeVisible();
  const pending = page.waitForEvent('download');
  await item.getByRole('button', {
    name: 'この内容を保存',
    exact: true
  }).click();
  const file = await pending;
  expect(await file.failure()).toBeNull();
  const bytes = new Uint8Array(await readFile(await file.path()));
  await captureProofFile(bytes, `purpose-${filename}`, (_filename$split$at = filename.split('.').at(-1)) !== null && _filename$split$at !== void 0 ? _filename$split$at : 'bin');
  return bytes;
}
export async function freshRoundtrip(browser, bytes, mode = 'new') {
  const fresh = await browser.newContext();
  try {
    const p = await fresh.newPage();
    await importBytes(p, bytes, appURL, mode);
    await p.reload();
    await expect(p.locator('.project-switch')).toBeVisible();
    return await backup(p);
  } finally {
    await fresh.close();
  }
}
export function equalArchiveAssets(before, after) {
  const canonical = v => v.assets.map(a => ({
    path: a.path,
    hash: a.contentHash,
    mediaType: a.mediaType,
    byteSHA256: digest(a.bytes),
    bytes: a.bytes.length
  })).sort((a, b) => a.path.localeCompare(b.path));
  expect(canonical(after)).toEqual(canonical(before));
  expect(after.worlds).toEqual(before.worlds);
}
export async function fullFixtureBytes(f) {
  return exportScenario(f.p, {
    worker: false,
    worlds: f.worlds,
    exportedAt: '2026-10-08T12:00:00.000Z',
    loadAsset: h => {
      var _f$assets;
      return (_f$assets = f.assets) === null || _f$assets === void 0 ? void 0 : _f$assets[h];
    }
  });
}
async function reseal(files, path) {
  const m = JSON.parse(strFromU8(files['manifest.json'])),
    file = m.files.find(f => f.path === path);
  if (!file) throw Error('missing manifest fixture path ' + path);
  file.byteSize = files[path].length;
  file.sha256 = await sha256(files[path]);
  files['manifest.json'] = jsonBytes(m);
}
export async function badArchives(good) {
  const original = unzipSync(good),
    out = [];
  const fresh = () => Object.fromEntries(Object.entries(original).map(([k, v]) => [k, v.slice()]));
  {
    const f = fresh();
    f['data/project.json'][4] ^= 1;
    out.push({
      name: 'project hash mismatch',
      bytes: zipSync(f),
      expected: /hash|ハッシュ|一致|破損/,
      expectedPath: 'data/project.json',
      explanation: 'One private project byte changes; manifest SHA remains original.'
    });
  }
  {
    const f = fresh(),
      m = JSON.parse(strFromU8(f['manifest.json']));
    m.formatVersion = '99.0.0';
    f['manifest.json'] = jsonBytes(m);
    out.push({
      name: 'unknown major format',
      bytes: zipSync(f),
      expected: /版|未対応|形式/,
      expectedPath: 'manifest.json',
      explanation: 'Unsupported major version is not migrated or partially imported.'
    });
  }
  {
    const f = fresh();
    f['../project.json'] = strToU8('{}');
    out.push({
      name: 'dangerous path',
      bytes: zipSync(f),
      expected: /パス|path|危険|禁止/,
      expectedPath: '../project.json',
      explanation: 'Explicit traversal path in the ZIP container.'
    });
  }
  {
    const f = fresh(),
      p = JSON.parse(strFromU8(f['data/project.json']));
    const event = p.entities.find(e => e.kind === 'event');
    if (!event) throw Error('reference fixture requires event');
    event.data.locationId = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
    f['data/project.json'] = jsonBytes(p);
    await reseal(f, 'data/project.json');
    out.push({
      name: 'broken typed reference',
      bytes: zipSync(f),
      expected: /参照|REFERENCE|見つか|存在/,
      expectedPath: 'data/project.json',
      explanation: 'Correct file SHA but a nonexistent typed event.locationId.'
    });
  }
  {
    const f = fresh(),
      p = JSON.parse(strFromU8(f['data/project.json']));
    p.entities.push(structuredClone(p.entities[0]));
    f['data/project.json'] = jsonBytes(p);
    await reseal(f, 'data/project.json');
    out.push({
      name: 'owned ID collision',
      bytes: zipSync(f),
      expected: /ID|重複|衝突/,
      expectedPath: 'data/project.json',
      explanation: 'Correct SHA but duplicate owned entity ID.'
    });
  }
  {
    const f = fresh(),
      p = JSON.parse(strFromU8(f['data/project.json']));
    p.entities.find(e => e.kind === 'note').data.body = [{
      id: 'dd000000-0000-4000-8000-000000000001',
      kind: 'paragraph',
      text: 'X'.repeat(100000)
    }];
    f['data/project.json'] = jsonBytes(p);
    await reseal(f, 'data/project.json');
    const zipped = zipSync(f, {
        level: 9
      }),
      v = new DataView(zipped.buffer, zipped.byteOffset, zipped.byteLength);
    for (let i = 0; i < zipped.length - 46; i++) {
      if (v.getUint32(i, true) !== 0x02014b50) continue;
      const n = v.getUint16(i + 28, true),
        name = strFromU8(zipped.subarray(i + 46, i + 46 + n));
      if (name !== 'data/project.json') continue;
      const local = v.getUint32(i + 42, true);
      v.setUint32(i + 24, 100, true);
      v.setUint32(local + 22, 100, true);
    }
    out.push({
      name: 'understated compressed payload',
      bytes: zipped,
      expected: /上限|LIMIT|展開|宣言/,
      expectedPath: 'data/project.json',
      explanation: 'Compressed text is bounded at100KB but central/local expanded sizes understate100B; reject before partial import.'
    });
  }
  {
    const f = fresh(),
      zipped = zipSync(f),
      paths = Object.keys(f).filter(k => k.startsWith('assets/'));
    if (paths.length >= 2 && paths[0].length === paths[1].length) {
      const from = strToU8(paths[1]),
        to = strToU8(paths[0]);
      for (let i = 0; i <= zipped.length - from.length; i++) if (from.every((b, j) => zipped[i + j] === b)) zipped.set(to, i);
      out.push({
        name: 'duplicate attachment ZIP path',
        bytes: zipped,
        expected: /重複|ファイル名/,
        expectedPath: paths[0],
        explanation: 'Both central and local names of the second attachment become the first attachment name.'
      });
    }
  }
  return out;
}
export async function rejectFileAtomic(page, bad, info) {
  await captureProofFile(bad.bytes, `rejected-${bad.name}`);
  await nav(page, /^作品・保存/);
  await page.getByRole('tab', {
    name: '完全保存・復元',
    exact: true
  }).click();
  const before = await durable(page),
    beforeSHA = digest(JSON.stringify(before));
  await page.getByLabel('保存ファイルを選ぶ', {
    exact: true
  }).setInputFiles({
    name: 'negative.scenario',
    mimeType: 'application/zip',
    buffer: Buffer.from(bad.bytes)
  });
  const alert = page.locator('.backup-page').getByRole('alert').first();
  await expect(alert).toContainText(bad.expected);
  if (bad.expectedPath) await expect.soft(alert).toContainText(bad.expectedPath, {
    timeout: 100
  });
  const after = await durable(page);
  expect(after).toEqual(before);
  await evidence(info, bad.name.replace(/\W/g, '-'), {
    inputSHA256: digest(bad.bytes),
    expectedPath: bad.expectedPath,
    expected: bad.expected.source,
    actualAlert: await alert.innerText(),
    beforeSHA,
    afterSHA: digest(JSON.stringify(after)),
    allDurableRowsUnchanged: true,
    explanation: bad.explanation
  });
}
export async function noPageOverflow(page) {
  const difference = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  if (difference > 1) {
    console.log('INDEPENDENT_OVERFLOW_DIAGNOSTIC ' + JSON.stringify(await page.evaluate(() => ({
      innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      scrollX,
      offenders: Array.from(document.querySelectorAll('*')).flatMap(element => {
        var _element$textContent;
        if (!(element instanceof HTMLElement)) return [];
        const rect = element.getBoundingClientRect(),
          style = getComputedStyle(element);
        if (rect.right <= innerWidth + 1 || rect.width <= 0 || style.display === 'none' || style.visibility === 'hidden') return [];
        return [{
          tag: element.tagName,
          className: element.getAttribute('class'),
          id: element.id,
          text: ((_element$textContent = element.textContent) !== null && _element$textContent !== void 0 ? _element$textContent : '').slice(0, 100),
          left: rect.left,
          right: rect.right,
          width: rect.width,
          minWidth: style.minWidth,
          whiteSpace: style.whiteSpace,
          scrollWidth: element.scrollWidth,
          clientWidth: element.clientWidth,
          overflowX: style.overflowX,
          position: style.position,
          ancestors: Array.from(function* (current) {
            for (let i = 0; current && i < 4; i++, current = current.parentElement) yield current;
          }(element.parentElement)).map(parent => ({
            tag: parent.tagName,
            className: parent.getAttribute('class'),
            overflowX: getComputedStyle(parent).overflowX,
            right: parent.getBoundingClientRect().right
          }))
        }];
      }).slice(0, 60)
    }))));
  }
  expect(difference).toBeLessThanOrEqual(1);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJyZWFkRmlsZSIsInVuemlwU3luYyIsInppcFN5bmMiLCJzdHJGcm9tVTgiLCJzdHJUb1U4IiwiZXhwb3J0U2NlbmFyaW8iLCJzaGEyNTYiLCJqc29uQnl0ZXMiLCJhcHBVUkwiLCJuYXYiLCJpbXBvcnRCeXRlcyIsImJhY2t1cCIsImR1cmFibGUiLCJldmlkZW5jZSIsImRpZ2VzdCIsImNhcHR1cmVQcm9vZkZpbGUiLCJvcGVuUmVjb3JkIiwicGFnZSIsImtpbmQiLCJuYW1lIiwiZ2V0QnlMYWJlbCIsImV4YWN0Iiwic2VsZWN0T3B0aW9uIiwibG9jYXRvciIsImZpbHRlciIsImhhcyIsImdldEJ5Um9sZSIsImNsaWNrIiwidG9Db250YWluVGV4dCIsInNhdmVFZGl0b3IiLCJidXR0b24iLCJlZGl0RGF0YSIsImNoYW5nZSIsImFkdmFuY2VkIiwiZ2V0QnlUZXh0IiwiZ2V0QXR0cmlidXRlIiwiaW5wdXQiLCJkYXRhIiwiSlNPTiIsInBhcnNlIiwiaW5wdXRWYWx1ZSIsImZpbGwiLCJzdHJpbmdpZnkiLCJyZWFkZXIiLCJwcm9kdWN0aW9uIiwib3V0cHV0Iiwic2V0dGluZ3MiLCJiZWdpbiIsImVudHJ5SWQiLCJ2ZXJzaW9uIiwic2VlZCIsInJlY29yZFRyaWFsIiwidG9CZVZpc2libGUiLCJkb3dubG9hZEFydGlmYWN0IiwiZmlsZW5hbWUiLCJfZmlsZW5hbWUkc3BsaXQkYXQiLCJpdGVtIiwiaGFzVGV4dCIsInBlbmRpbmciLCJ3YWl0Rm9yRXZlbnQiLCJmaWxlIiwiZmFpbHVyZSIsInRvQmVOdWxsIiwiYnl0ZXMiLCJVaW50OEFycmF5IiwicGF0aCIsInNwbGl0IiwiYXQiLCJmcmVzaFJvdW5kdHJpcCIsImJyb3dzZXIiLCJtb2RlIiwiZnJlc2giLCJuZXdDb250ZXh0IiwicCIsIm5ld1BhZ2UiLCJyZWxvYWQiLCJjbG9zZSIsImVxdWFsQXJjaGl2ZUFzc2V0cyIsImJlZm9yZSIsImFmdGVyIiwiY2Fub25pY2FsIiwidiIsImFzc2V0cyIsIm1hcCIsImEiLCJoYXNoIiwiY29udGVudEhhc2giLCJtZWRpYVR5cGUiLCJieXRlU0hBMjU2IiwibGVuZ3RoIiwic29ydCIsImIiLCJsb2NhbGVDb21wYXJlIiwidG9FcXVhbCIsIndvcmxkcyIsImZ1bGxGaXh0dXJlQnl0ZXMiLCJmIiwid29ya2VyIiwiZXhwb3J0ZWRBdCIsImxvYWRBc3NldCIsImgiLCJfZiRhc3NldHMiLCJyZXNlYWwiLCJmaWxlcyIsIm0iLCJmaW5kIiwiRXJyb3IiLCJieXRlU2l6ZSIsImJhZEFyY2hpdmVzIiwiZ29vZCIsIm9yaWdpbmFsIiwib3V0IiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJlbnRyaWVzIiwiayIsInNsaWNlIiwicHVzaCIsImV4cGVjdGVkIiwiZXhwZWN0ZWRQYXRoIiwiZXhwbGFuYXRpb24iLCJmb3JtYXRWZXJzaW9uIiwiZXZlbnQiLCJlbnRpdGllcyIsImUiLCJsb2NhdGlvbklkIiwic3RydWN0dXJlZENsb25lIiwiYm9keSIsImlkIiwidGV4dCIsInJlcGVhdCIsInppcHBlZCIsImxldmVsIiwiRGF0YVZpZXciLCJidWZmZXIiLCJieXRlT2Zmc2V0IiwiYnl0ZUxlbmd0aCIsImkiLCJnZXRVaW50MzIiLCJuIiwiZ2V0VWludDE2Iiwic3ViYXJyYXkiLCJsb2NhbCIsInNldFVpbnQzMiIsInBhdGhzIiwia2V5cyIsInN0YXJ0c1dpdGgiLCJmcm9tIiwidG8iLCJldmVyeSIsImoiLCJzZXQiLCJyZWplY3RGaWxlQXRvbWljIiwiYmFkIiwiaW5mbyIsImJlZm9yZVNIQSIsInNldElucHV0RmlsZXMiLCJtaW1lVHlwZSIsIkJ1ZmZlciIsImFsZXJ0IiwiZmlyc3QiLCJzb2Z0IiwidGltZW91dCIsInJlcGxhY2UiLCJpbnB1dFNIQTI1NiIsInNvdXJjZSIsImFjdHVhbEFsZXJ0IiwiaW5uZXJUZXh0IiwiYWZ0ZXJTSEEiLCJhbGxEdXJhYmxlUm93c1VuY2hhbmdlZCIsIm5vUGFnZU92ZXJmbG93IiwiZGlmZmVyZW5jZSIsImV2YWx1YXRlIiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJzY3JvbGxXaWR0aCIsImNsaWVudFdpZHRoIiwiY29uc29sZSIsImxvZyIsImlubmVyV2lkdGgiLCJzY3JvbGxYIiwib2ZmZW5kZXJzIiwiQXJyYXkiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZmxhdE1hcCIsImVsZW1lbnQiLCJfZWxlbWVudCR0ZXh0Q29udGVudCIsIkhUTUxFbGVtZW50IiwicmVjdCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsInN0eWxlIiwiZ2V0Q29tcHV0ZWRTdHlsZSIsInJpZ2h0Iiwid2lkdGgiLCJkaXNwbGF5IiwidmlzaWJpbGl0eSIsInRhZyIsInRhZ05hbWUiLCJjbGFzc05hbWUiLCJ0ZXh0Q29udGVudCIsImxlZnQiLCJtaW5XaWR0aCIsIndoaXRlU3BhY2UiLCJvdmVyZmxvd1giLCJwb3NpdGlvbiIsImFuY2VzdG9ycyIsImN1cnJlbnQiLCJwYXJlbnRFbGVtZW50IiwicGFyZW50IiwidG9CZUxlc3NUaGFuT3JFcXVhbCJdLCJzb3VyY2VzIjpbImV4dGVuZGVkLXN1cHBvcnQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtleHBlY3QsdHlwZSBQYWdlLHR5cGUgQnJvd3Nlcix0eXBlIFRlc3RJbmZvfSBmcm9tICdAcGxheXdyaWdodC90ZXN0JztcbmltcG9ydCB7cmVhZEZpbGV9IGZyb20gJ25vZGU6ZnMvcHJvbWlzZXMnO1xuaW1wb3J0IHt1bnppcFN5bmMsemlwU3luYyxzdHJGcm9tVTgsc3RyVG9VOH0gZnJvbSAnZmZsYXRlJztcbmltcG9ydCB7ZXhwb3J0U2NlbmFyaW8sdHlwZSBTY2VuYXJpb01hbmlmZXN0LHR5cGUgUHJlcGFyZWRTY2VuYXJpb30gZnJvbSAnLi4vY2FuZGlkYXRlL3NyYy9zdG9yYWdlL2FyY2hpdmUnO1xuaW1wb3J0IHtzaGEyNTYsanNvbkJ5dGVzfSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL3N0b3JhZ2UvanNvbic7XG5pbXBvcnQgdHlwZSB7RW50aXR5S2luZCxQcm9qZWN0RGF0YX0gZnJvbSAnLi4vY2FuZGlkYXRlL3NyYy9kb21haW4vdHlwZXMnO1xuaW1wb3J0IHthcHBVUkwsbmF2LGltcG9ydEJ5dGVzLGJhY2t1cCxkdXJhYmxlLGV2aWRlbmNlLGRpZ2VzdCxjYXB0dXJlUHJvb2ZGaWxlfSBmcm9tICcuL2NvbW1vbic7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuUmVjb3JkKHBhZ2U6UGFnZSxraW5kOkVudGl0eUtpbmQsbmFtZTpzdHJpbmcpe1xuIGF3YWl0IG5hdihwYWdlLC9e6LOH5paZLyk7YXdhaXQgcGFnZS5nZXRCeUxhYmVsKCfmg4XloLHjga7nqK7poZ4nLHtleGFjdDp0cnVlfSkuc2VsZWN0T3B0aW9uKGtpbmQpO1xuIGF3YWl0IHBhZ2UubG9jYXRvcignLmVudGl0eS1jYXJkJykuZmlsdGVyKHtoYXM6cGFnZS5nZXRCeVJvbGUoJ2hlYWRpbmcnLHtuYW1lLGV4YWN0OnRydWV9KX0pLmNsaWNrKCk7XG4gYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmRldGFpbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQobmFtZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2F2ZUVkaXRvcihwYWdlOlBhZ2Upe1xuIGNvbnN0IGJ1dHRvbj1wYWdlLmxvY2F0b3IoJy5lZGl0b3ItZm9vdGVyJykuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOi9eKOS/neWtmOOBmeOCi3zkv53lrZjjgpLlho3oqabooYwpJC99KTtcbiBhd2FpdCBidXR0b24uY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuZWRpdG9yLXNhdmUtc3RhdGUnKSkudG9Db250YWluVGV4dCgn56uv5pyr5YaF5L+d5a2Y5riI44G/Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZWRpdERhdGEocGFnZTpQYWdlLGNoYW5nZTooZGF0YTpSZWNvcmQ8c3RyaW5nLHVua25vd24+KT0+dm9pZCl7XG4gY29uc3QgYWR2YW5jZWQ9cGFnZS5sb2NhdG9yKCdkZXRhaWxzLmFkdmFuY2VkLWRldGFpbHMnKS5maWx0ZXIoe2hhczpwYWdlLmdldEJ5VGV4dCgn6Kmz57Sw44OH44O844K/44O744Or44OT44O75pys5paH44Oq44Oz44Kv44KS57eo6ZuGJyx7ZXhhY3Q6dHJ1ZX0pfSk7XG4gaWYoYXdhaXQgYWR2YW5jZWQuZ2V0QXR0cmlidXRlKCdvcGVuJyk9PT1udWxsKWF3YWl0IGFkdmFuY2VkLmxvY2F0b3IoJ3N1bW1hcnknKS5jbGljaygpO1xuIGNvbnN0IGlucHV0PWFkdmFuY2VkLmdldEJ5Um9sZSgndGV4dGJveCcse25hbWU6J+ips+e0sOODh+ODvOOCvycsZXhhY3Q6dHJ1ZX0pLGRhdGE9SlNPTi5wYXJzZShhd2FpdCBpbnB1dC5pbnB1dFZhbHVlKCkpO1xuIGNoYW5nZShkYXRhKTthd2FpdCBpbnB1dC5maWxsKEpTT04uc3RyaW5naWZ5KGRhdGEpKTtyZXR1cm4gaW5wdXQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVhZGVyKHBhZ2U6UGFnZSl7YXdhaXQgbmF2KHBhZ2UsL17mp4vmiJAvKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGFiJyx7bmFtZTon6Kmm6Kqt44O75qSc5p+7JyxleGFjdDp0cnVlfSkuY2xpY2soKTt9XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvZHVjdGlvbihwYWdlOlBhZ2Upe2F3YWl0IG5hdihwYWdlLC9e5qeL5oiQLyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+WItuS9nCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7fVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG91dHB1dChwYWdlOlBhZ2Upe2F3YWl0IG5hdihwYWdlLC9e5L2c5ZOB44O75L+d5a2YLyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+ebrueahOWIpeWHuuWKmycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7fVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldHRpbmdzKHBhZ2U6UGFnZSl7YXdhaXQgbmF2KHBhZ2UsL17kvZzlk4Hjg7vkv53lrZgvKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGFiJyx7bmFtZTon5L2c5ZOB44Gu6Kit5a6aJyxleGFjdDp0cnVlfSkuY2xpY2soKTt9XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYmVnaW4ocGFnZTpQYWdlLGVudHJ5SWQ6c3RyaW5nLHZlcnNpb249Jycsc2VlZD0nb3JpZ2luYWwtYWNjZXB0YW5jZS1zZWVkJyl7XG4gYXdhaXQgcGFnZS5nZXRCeUxhYmVsKCfoqaboqq3jgZnjgovkvZzlk4HniYgnLHtleGFjdDp0cnVlfSkuc2VsZWN0T3B0aW9uKHZlcnNpb24pO1xuIGF3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn6Kmm6Kqt44Gu6ZaL5aeL54K5Jyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbihlbnRyeUlkKTthd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+aKvemBuOeoricse2V4YWN0OnRydWV9KS5maWxsKHNlZWQpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOi9eKOippuiqreOCkuWni+OCgeOCi3zjgZPjga7nirbmhYvjgYvjgonplovlp4vjgZfnm7TjgZkpJC99KS5jbGljaygpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlY29yZFRyaWFsKHBhZ2U6UGFnZSl7XG4gYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+e1jOi3r+OCkuiomOmMsicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXh0KCfplovlp4vnirbmhYvjgajntYzot6/jgpLnq6/mnKvlhoXjgavkv53lrZjjgZfjgb7jgZfjgZ/jgIInLHtleGFjdDp0cnVlfSkpLnRvQmVWaXNpYmxlKCk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZG93bmxvYWRBcnRpZmFjdChwYWdlOlBhZ2UsZmlsZW5hbWU6c3RyaW5nKXtcbiBjb25zdCBpdGVtPXBhZ2UubG9jYXRvcignLmV4cG9ydC1hcnRpZmFjdCcpLmZpbHRlcih7aGFzVGV4dDpmaWxlbmFtZX0pO2F3YWl0IGV4cGVjdChpdGVtKS50b0JlVmlzaWJsZSgpO1xuIGNvbnN0IHBlbmRpbmc9cGFnZS53YWl0Rm9yRXZlbnQoJ2Rvd25sb2FkJyk7YXdhaXQgaXRlbS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+OBk+OBruWGheWuueOCkuS/neWtmCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gY29uc3QgZmlsZT1hd2FpdCBwZW5kaW5nO2V4cGVjdChhd2FpdCBmaWxlLmZhaWx1cmUoKSkudG9CZU51bGwoKTtjb25zdCBieXRlcz1uZXcgVWludDhBcnJheShhd2FpdCByZWFkRmlsZSgoYXdhaXQgZmlsZS5wYXRoKCkpISkpO2F3YWl0IGNhcHR1cmVQcm9vZkZpbGUoYnl0ZXMsYHB1cnBvc2UtJHtmaWxlbmFtZX1gLGZpbGVuYW1lLnNwbGl0KCcuJykuYXQoLTEpPz8nYmluJyk7cmV0dXJuIGJ5dGVzO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZyZXNoUm91bmR0cmlwKGJyb3dzZXI6QnJvd3NlcixieXRlczpVaW50OEFycmF5LG1vZGU6J25ldyd8J2Nsb25lJz0nbmV3Jyl7XG4gY29uc3QgZnJlc2g9YXdhaXQgYnJvd3Nlci5uZXdDb250ZXh0KCk7dHJ5e2NvbnN0IHA9YXdhaXQgZnJlc2gubmV3UGFnZSgpO2F3YWl0IGltcG9ydEJ5dGVzKHAsYnl0ZXMsYXBwVVJMLG1vZGUpO2F3YWl0IHAucmVsb2FkKCk7YXdhaXQgZXhwZWN0KHAubG9jYXRvcignLnByb2plY3Qtc3dpdGNoJykpLnRvQmVWaXNpYmxlKCk7cmV0dXJuIGF3YWl0IGJhY2t1cChwKTt9ZmluYWxseXthd2FpdCBmcmVzaC5jbG9zZSgpO31cbn1cbmV4cG9ydCBmdW5jdGlvbiBlcXVhbEFyY2hpdmVBc3NldHMoYmVmb3JlOlByZXBhcmVkU2NlbmFyaW8sYWZ0ZXI6UHJlcGFyZWRTY2VuYXJpbyl7XG4gY29uc3QgY2Fub25pY2FsPSh2OlByZXBhcmVkU2NlbmFyaW8pPT52LmFzc2V0cy5tYXAoYT0+KHtwYXRoOmEucGF0aCxoYXNoOmEuY29udGVudEhhc2gsbWVkaWFUeXBlOmEubWVkaWFUeXBlLGJ5dGVTSEEyNTY6ZGlnZXN0KGEuYnl0ZXMpLGJ5dGVzOmEuYnl0ZXMubGVuZ3RofSkpLnNvcnQoKGEsYik9PmEucGF0aC5sb2NhbGVDb21wYXJlKGIucGF0aCkpO1xuIGV4cGVjdChjYW5vbmljYWwoYWZ0ZXIpKS50b0VxdWFsKGNhbm9uaWNhbChiZWZvcmUpKTtleHBlY3QoYWZ0ZXIud29ybGRzKS50b0VxdWFsKGJlZm9yZS53b3JsZHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZ1bGxGaXh0dXJlQnl0ZXMoZjp7cDpQcm9qZWN0RGF0YTt3b3JsZHM/OlJlY29yZDxzdHJpbmcsUHJvamVjdERhdGE+O2Fzc2V0cz86UmVjb3JkPHN0cmluZyxVaW50OEFycmF5Pn0pe1xuIHJldHVybiBleHBvcnRTY2VuYXJpbyhmLnAse3dvcmtlcjpmYWxzZSx3b3JsZHM6Zi53b3JsZHMsZXhwb3J0ZWRBdDonMjAyNi0xMC0wOFQxMjowMDowMC4wMDBaJyxsb2FkQXNzZXQ6aD0+Zi5hc3NldHM/LltoXX0pO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJhZEFyY2hpdmUge25hbWU6c3RyaW5nO2J5dGVzOlVpbnQ4QXJyYXk7ZXhwZWN0ZWQ6UmVnRXhwO2V4cGVjdGVkUGF0aD86c3RyaW5nO2V4cGxhbmF0aW9uOnN0cmluZ31cbmFzeW5jIGZ1bmN0aW9uIHJlc2VhbChmaWxlczpSZWNvcmQ8c3RyaW5nLFVpbnQ4QXJyYXk+LHBhdGg6c3RyaW5nKXtcbiBjb25zdCBtPUpTT04ucGFyc2Uoc3RyRnJvbVU4KGZpbGVzWydtYW5pZmVzdC5qc29uJ10pKSBhcyBTY2VuYXJpb01hbmlmZXN0LGZpbGU9bS5maWxlcy5maW5kKGY9PmYucGF0aD09PXBhdGgpO2lmKCFmaWxlKXRocm93IEVycm9yKCdtaXNzaW5nIG1hbmlmZXN0IGZpeHR1cmUgcGF0aCAnK3BhdGgpO1xuIGZpbGUuYnl0ZVNpemU9ZmlsZXNbcGF0aF0ubGVuZ3RoO2ZpbGUuc2hhMjU2PWF3YWl0IHNoYTI1NihmaWxlc1twYXRoXSk7ZmlsZXNbJ21hbmlmZXN0Lmpzb24nXT1qc29uQnl0ZXMobSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYmFkQXJjaGl2ZXMoZ29vZDpVaW50OEFycmF5KTpQcm9taXNlPEJhZEFyY2hpdmVbXT57XG4gY29uc3Qgb3JpZ2luYWw9dW56aXBTeW5jKGdvb2QpLG91dDpCYWRBcmNoaXZlW109W107XG4gY29uc3QgZnJlc2g9KCk6UmVjb3JkPHN0cmluZyxVaW50OEFycmF5Pj0+T2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKG9yaWdpbmFsKS5tYXAoKFtrLHZdKT0+W2ssdi5zbGljZSgpXSkpO1xuIHtjb25zdCBmPWZyZXNoKCk7ZlsnZGF0YS9wcm9qZWN0Lmpzb24nXVs0XV49MTtvdXQucHVzaCh7bmFtZToncHJvamVjdCBoYXNoIG1pc21hdGNoJyxieXRlczp6aXBTeW5jKGYpLGV4cGVjdGVkOi9oYXNofOODj+ODg+OCt+ODpXzkuIDoh7R856C05pCNLyxleHBlY3RlZFBhdGg6J2RhdGEvcHJvamVjdC5qc29uJyxleHBsYW5hdGlvbjonT25lIHByaXZhdGUgcHJvamVjdCBieXRlIGNoYW5nZXM7IG1hbmlmZXN0IFNIQSByZW1haW5zIG9yaWdpbmFsLid9KTt9XG4ge2NvbnN0IGY9ZnJlc2goKSxtPUpTT04ucGFyc2Uoc3RyRnJvbVU4KGZbJ21hbmlmZXN0Lmpzb24nXSkpO20uZm9ybWF0VmVyc2lvbj0nOTkuMC4wJztmWydtYW5pZmVzdC5qc29uJ109anNvbkJ5dGVzKG0pO291dC5wdXNoKHtuYW1lOid1bmtub3duIG1ham9yIGZvcm1hdCcsYnl0ZXM6emlwU3luYyhmKSxleHBlY3RlZDov54mIfOacquWvvuW/nHzlvaLlvI8vLGV4cGVjdGVkUGF0aDonbWFuaWZlc3QuanNvbicsZXhwbGFuYXRpb246J1Vuc3VwcG9ydGVkIG1ham9yIHZlcnNpb24gaXMgbm90IG1pZ3JhdGVkIG9yIHBhcnRpYWxseSBpbXBvcnRlZC4nfSk7fVxuIHtjb25zdCBmPWZyZXNoKCk7ZlsnLi4vcHJvamVjdC5qc29uJ109c3RyVG9VOCgne30nKTtvdXQucHVzaCh7bmFtZTonZGFuZ2Vyb3VzIHBhdGgnLGJ5dGVzOnppcFN5bmMoZiksZXhwZWN0ZWQ6L+ODkeOCuXxwYXRofOWNsemZunznpoHmraIvLGV4cGVjdGVkUGF0aDonLi4vcHJvamVjdC5qc29uJyxleHBsYW5hdGlvbjonRXhwbGljaXQgdHJhdmVyc2FsIHBhdGggaW4gdGhlIFpJUCBjb250YWluZXIuJ30pO31cbiB7Y29uc3QgZj1mcmVzaCgpLHA9SlNPTi5wYXJzZShzdHJGcm9tVTgoZlsnZGF0YS9wcm9qZWN0Lmpzb24nXSkpO2NvbnN0IGV2ZW50PXAuZW50aXRpZXMuZmluZCgoZTp7a2luZDpzdHJpbmd9KT0+ZS5raW5kPT09J2V2ZW50Jyk7aWYoIWV2ZW50KXRocm93IEVycm9yKCdyZWZlcmVuY2UgZml4dHVyZSByZXF1aXJlcyBldmVudCcpO2V2ZW50LmRhdGEubG9jYXRpb25JZD0nZWVlZWVlZWUtZWVlZS00ZWVlLThlZWUtZWVlZWVlZWVlZWVlJztmWydkYXRhL3Byb2plY3QuanNvbiddPWpzb25CeXRlcyhwKTthd2FpdCByZXNlYWwoZiwnZGF0YS9wcm9qZWN0Lmpzb24nKTtvdXQucHVzaCh7bmFtZTonYnJva2VuIHR5cGVkIHJlZmVyZW5jZScsYnl0ZXM6emlwU3luYyhmKSxleHBlY3RlZDov5Y+C54WnfFJFRkVSRU5DRXzopovjgaTjgYt85a2Y5ZyoLyxleHBlY3RlZFBhdGg6J2RhdGEvcHJvamVjdC5qc29uJyxleHBsYW5hdGlvbjonQ29ycmVjdCBmaWxlIFNIQSBidXQgYSBub25leGlzdGVudCB0eXBlZCBldmVudC5sb2NhdGlvbklkLid9KTt9XG4ge2NvbnN0IGY9ZnJlc2goKSxwPUpTT04ucGFyc2Uoc3RyRnJvbVU4KGZbJ2RhdGEvcHJvamVjdC5qc29uJ10pKTtwLmVudGl0aWVzLnB1c2goc3RydWN0dXJlZENsb25lKHAuZW50aXRpZXNbMF0pKTtmWydkYXRhL3Byb2plY3QuanNvbiddPWpzb25CeXRlcyhwKTthd2FpdCByZXNlYWwoZiwnZGF0YS9wcm9qZWN0Lmpzb24nKTtvdXQucHVzaCh7bmFtZTonb3duZWQgSUQgY29sbGlzaW9uJyxieXRlczp6aXBTeW5jKGYpLGV4cGVjdGVkOi9JRHzph43opId86KGd56qBLyxleHBlY3RlZFBhdGg6J2RhdGEvcHJvamVjdC5qc29uJyxleHBsYW5hdGlvbjonQ29ycmVjdCBTSEEgYnV0IGR1cGxpY2F0ZSBvd25lZCBlbnRpdHkgSUQuJ30pO31cbiB7Y29uc3QgZj1mcmVzaCgpLHA9SlNPTi5wYXJzZShzdHJGcm9tVTgoZlsnZGF0YS9wcm9qZWN0Lmpzb24nXSkpO3AuZW50aXRpZXMuZmluZCgoZTp7a2luZDpzdHJpbmd9KT0+ZS5raW5kPT09J25vdGUnKS5kYXRhLmJvZHk9W3tpZDonZGQwMDAwMDAtMDAwMC00MDAwLTgwMDAtMDAwMDAwMDAwMDAxJyxraW5kOidwYXJhZ3JhcGgnLHRleHQ6J1gnLnJlcGVhdCgxMDAwMDApfV07ZlsnZGF0YS9wcm9qZWN0Lmpzb24nXT1qc29uQnl0ZXMocCk7YXdhaXQgcmVzZWFsKGYsJ2RhdGEvcHJvamVjdC5qc29uJyk7Y29uc3QgemlwcGVkPXppcFN5bmMoZix7bGV2ZWw6OX0pLHY9bmV3IERhdGFWaWV3KHppcHBlZC5idWZmZXIsemlwcGVkLmJ5dGVPZmZzZXQsemlwcGVkLmJ5dGVMZW5ndGgpO2ZvcihsZXQgaT0wO2k8emlwcGVkLmxlbmd0aC00NjtpKyspe2lmKHYuZ2V0VWludDMyKGksdHJ1ZSkhPT0weDAyMDE0YjUwKWNvbnRpbnVlO2NvbnN0IG49di5nZXRVaW50MTYoaSsyOCx0cnVlKSxuYW1lPXN0ckZyb21VOCh6aXBwZWQuc3ViYXJyYXkoaSs0NixpKzQ2K24pKTtpZihuYW1lIT09J2RhdGEvcHJvamVjdC5qc29uJyljb250aW51ZTtjb25zdCBsb2NhbD12LmdldFVpbnQzMihpKzQyLHRydWUpO3Yuc2V0VWludDMyKGkrMjQsMTAwLHRydWUpO3Yuc2V0VWludDMyKGxvY2FsKzIyLDEwMCx0cnVlKTt9b3V0LnB1c2goe25hbWU6J3VuZGVyc3RhdGVkIGNvbXByZXNzZWQgcGF5bG9hZCcsYnl0ZXM6emlwcGVkLGV4cGVjdGVkOi/kuIrpmZB8TElNSVR85bGV6ZaLfOWuo+iogC8sZXhwZWN0ZWRQYXRoOidkYXRhL3Byb2plY3QuanNvbicsZXhwbGFuYXRpb246J0NvbXByZXNzZWQgdGV4dCBpcyBib3VuZGVkIGF0MTAwS0IgYnV0IGNlbnRyYWwvbG9jYWwgZXhwYW5kZWQgc2l6ZXMgdW5kZXJzdGF0ZTEwMEI7IHJlamVjdCBiZWZvcmUgcGFydGlhbCBpbXBvcnQuJ30pO31cbiB7Y29uc3QgZj1mcmVzaCgpLHppcHBlZD16aXBTeW5jKGYpLHBhdGhzPU9iamVjdC5rZXlzKGYpLmZpbHRlcihrPT5rLnN0YXJ0c1dpdGgoJ2Fzc2V0cy8nKSk7aWYocGF0aHMubGVuZ3RoPj0yJiZwYXRoc1swXS5sZW5ndGg9PT1wYXRoc1sxXS5sZW5ndGgpe2NvbnN0IGZyb209c3RyVG9VOChwYXRoc1sxXSksdG89c3RyVG9VOChwYXRoc1swXSk7Zm9yKGxldCBpPTA7aTw9emlwcGVkLmxlbmd0aC1mcm9tLmxlbmd0aDtpKyspaWYoZnJvbS5ldmVyeSgoYixqKT0+emlwcGVkW2kral09PT1iKSl6aXBwZWQuc2V0KHRvLGkpO291dC5wdXNoKHtuYW1lOidkdXBsaWNhdGUgYXR0YWNobWVudCBaSVAgcGF0aCcsYnl0ZXM6emlwcGVkLGV4cGVjdGVkOi/ph43opId844OV44Kh44Kk44Or5ZCNLyxleHBlY3RlZFBhdGg6cGF0aHNbMF0sZXhwbGFuYXRpb246J0JvdGggY2VudHJhbCBhbmQgbG9jYWwgbmFtZXMgb2YgdGhlIHNlY29uZCBhdHRhY2htZW50IGJlY29tZSB0aGUgZmlyc3QgYXR0YWNobWVudCBuYW1lLid9KTt9fVxuIHJldHVybiBvdXQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVqZWN0RmlsZUF0b21pYyhwYWdlOlBhZ2UsYmFkOkJhZEFyY2hpdmUsaW5mbzpUZXN0SW5mbyl7XG4gYXdhaXQgY2FwdHVyZVByb29mRmlsZShiYWQuYnl0ZXMsYHJlamVjdGVkLSR7YmFkLm5hbWV9YCk7XG4gYXdhaXQgbmF2KHBhZ2UsL17kvZzlk4Hjg7vkv53lrZgvKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGFiJyx7bmFtZTon5a6M5YWo5L+d5a2Y44O75b6p5YWDJyxleGFjdDp0cnVlfSkuY2xpY2soKTtjb25zdCBiZWZvcmU9YXdhaXQgZHVyYWJsZShwYWdlKSxiZWZvcmVTSEE9ZGlnZXN0KEpTT04uc3RyaW5naWZ5KGJlZm9yZSkpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn5L+d5a2Y44OV44Kh44Kk44Or44KS6YG444G2Jyx7ZXhhY3Q6dHJ1ZX0pLnNldElucHV0RmlsZXMoe25hbWU6J25lZ2F0aXZlLnNjZW5hcmlvJyxtaW1lVHlwZTonYXBwbGljYXRpb24vemlwJyxidWZmZXI6QnVmZmVyLmZyb20oYmFkLmJ5dGVzKX0pO1xuIGNvbnN0IGFsZXJ0PXBhZ2UubG9jYXRvcignLmJhY2t1cC1wYWdlJykuZ2V0QnlSb2xlKCdhbGVydCcpLmZpcnN0KCk7YXdhaXQgZXhwZWN0KGFsZXJ0KS50b0NvbnRhaW5UZXh0KGJhZC5leHBlY3RlZCk7XG4gaWYoYmFkLmV4cGVjdGVkUGF0aClhd2FpdCBleHBlY3Quc29mdChhbGVydCkudG9Db250YWluVGV4dChiYWQuZXhwZWN0ZWRQYXRoLHt0aW1lb3V0OjEwMH0pO1xuIGNvbnN0IGFmdGVyPWF3YWl0IGR1cmFibGUocGFnZSk7ZXhwZWN0KGFmdGVyKS50b0VxdWFsKGJlZm9yZSk7XG4gYXdhaXQgZXZpZGVuY2UoaW5mbyxiYWQubmFtZS5yZXBsYWNlKC9cXFcvZywnLScpLHtpbnB1dFNIQTI1NjpkaWdlc3QoYmFkLmJ5dGVzKSxleHBlY3RlZFBhdGg6YmFkLmV4cGVjdGVkUGF0aCxleHBlY3RlZDpiYWQuZXhwZWN0ZWQuc291cmNlLGFjdHVhbEFsZXJ0OmF3YWl0IGFsZXJ0LmlubmVyVGV4dCgpLGJlZm9yZVNIQSxhZnRlclNIQTpkaWdlc3QoSlNPTi5zdHJpbmdpZnkoYWZ0ZXIpKSxhbGxEdXJhYmxlUm93c1VuY2hhbmdlZDp0cnVlLGV4cGxhbmF0aW9uOmJhZC5leHBsYW5hdGlvbn0pO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5vUGFnZU92ZXJmbG93KHBhZ2U6UGFnZSl7Y29uc3QgZGlmZmVyZW5jZT1hd2FpdCBwYWdlLmV2YWx1YXRlKCgpPT5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsV2lkdGgtZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoKTtpZihkaWZmZXJlbmNlPjEpe2NvbnNvbGUubG9nKCdJTkRFUEVOREVOVF9PVkVSRkxPV19ESUFHTk9TVElDICcrSlNPTi5zdHJpbmdpZnkoYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKT0+KHtpbm5lcldpZHRoLHNjcm9sbFdpZHRoOmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxXaWR0aCxjbGllbnRXaWR0aDpkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGgsc2Nyb2xsWCxvZmZlbmRlcnM6QXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcqJykpLmZsYXRNYXAoZWxlbWVudD0+e2lmKCEoZWxlbWVudCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KSlyZXR1cm4gW107Y29uc3QgcmVjdD1lbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLHN0eWxlPWdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7aWYocmVjdC5yaWdodDw9aW5uZXJXaWR0aCsxfHxyZWN0LndpZHRoPD0wfHxzdHlsZS5kaXNwbGF5PT09J25vbmUnfHxzdHlsZS52aXNpYmlsaXR5PT09J2hpZGRlbicpcmV0dXJuIFtdO3JldHVybiBbe3RhZzplbGVtZW50LnRhZ05hbWUsY2xhc3NOYW1lOmVsZW1lbnQuZ2V0QXR0cmlidXRlKCdjbGFzcycpLGlkOmVsZW1lbnQuaWQsdGV4dDooZWxlbWVudC50ZXh0Q29udGVudD8/JycpLnNsaWNlKDAsMTAwKSxsZWZ0OnJlY3QubGVmdCxyaWdodDpyZWN0LnJpZ2h0LHdpZHRoOnJlY3Qud2lkdGgsbWluV2lkdGg6c3R5bGUubWluV2lkdGgsd2hpdGVTcGFjZTpzdHlsZS53aGl0ZVNwYWNlLHNjcm9sbFdpZHRoOmVsZW1lbnQuc2Nyb2xsV2lkdGgsY2xpZW50V2lkdGg6ZWxlbWVudC5jbGllbnRXaWR0aCxvdmVyZmxvd1g6c3R5bGUub3ZlcmZsb3dYLHBvc2l0aW9uOnN0eWxlLnBvc2l0aW9uLGFuY2VzdG9yczpBcnJheS5mcm9tKChmdW5jdGlvbiooY3VycmVudDpFbGVtZW50fG51bGwpe2ZvcihsZXQgaT0wO2N1cnJlbnQmJmk8NDtpKyssY3VycmVudD1jdXJyZW50LnBhcmVudEVsZW1lbnQpeWllbGQgY3VycmVudDt9KShlbGVtZW50LnBhcmVudEVsZW1lbnQpKS5tYXAocGFyZW50PT4oe3RhZzpwYXJlbnQudGFnTmFtZSxjbGFzc05hbWU6cGFyZW50LmdldEF0dHJpYnV0ZSgnY2xhc3MnKSxvdmVyZmxvd1g6Z2V0Q29tcHV0ZWRTdHlsZShwYXJlbnQpLm92ZXJmbG93WCxyaWdodDpwYXJlbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkucmlnaHR9KSl9XTt9KS5zbGljZSgwLDYwKX0pKSkpO31leHBlY3QoZGlmZmVyZW5jZSkudG9CZUxlc3NUaGFuT3JFcXVhbCgxKTt9XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVFBLE1BQU0sUUFBNEMsa0JBQWtCO0FBQzVFLFNBQVFDLFFBQVEsUUFBTyxrQkFBa0I7QUFDekMsU0FBUUMsU0FBUyxFQUFDQyxPQUFPLEVBQUNDLFNBQVMsRUFBQ0MsT0FBTyxRQUFPLFFBQVE7QUFDMUQsU0FBUUMsY0FBYyxRQUFtRCxrQ0FBa0M7QUFDM0csU0FBUUMsTUFBTSxFQUFDQyxTQUFTLFFBQU8sK0JBQStCO0FBRTlELFNBQVFDLE1BQU0sRUFBQ0MsR0FBRyxFQUFDQyxXQUFXLEVBQUNDLE1BQU0sRUFBQ0MsT0FBTyxFQUFDQyxRQUFRLEVBQUNDLE1BQU0sRUFBQ0MsZ0JBQWdCLFFBQU8sVUFBVTtBQUUvRixPQUFPLGVBQWVDLFVBQVVBLENBQUNDLElBQVMsRUFBQ0MsSUFBZSxFQUFDQyxJQUFXLEVBQUM7RUFDdEUsTUFBTVYsR0FBRyxDQUFDUSxJQUFJLEVBQUMsS0FBSyxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDRyxVQUFVLENBQUMsT0FBTyxFQUFDO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxZQUFZLENBQUNKLElBQUksQ0FBQztFQUNwRixNQUFNRCxJQUFJLENBQUNNLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0MsTUFBTSxDQUFDO0lBQUNDLEdBQUcsRUFBQ1IsSUFBSSxDQUFDUyxTQUFTLENBQUMsU0FBUyxFQUFDO01BQUNQLElBQUk7TUFBQ0UsS0FBSyxFQUFDO0lBQUksQ0FBQztFQUFDLENBQUMsQ0FBQyxDQUFDTSxLQUFLLENBQUMsQ0FBQztFQUNwRyxNQUFNNUIsTUFBTSxDQUFDa0IsSUFBSSxDQUFDTSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDSyxhQUFhLENBQUNULElBQUksQ0FBQztBQUNsRTtBQUNBLE9BQU8sZUFBZVUsVUFBVUEsQ0FBQ1osSUFBUyxFQUFDO0VBQzFDLE1BQU1hLE1BQU0sR0FBQ2IsSUFBSSxDQUFDTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQ0csU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDUCxJQUFJLEVBQUM7RUFBaUIsQ0FBQyxDQUFDO0VBQ3hGLE1BQU1XLE1BQU0sQ0FBQ0gsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNNUIsTUFBTSxDQUFDa0IsSUFBSSxDQUFDTSxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDSyxhQUFhLENBQUMsU0FBUyxDQUFDO0FBQy9GO0FBQ0EsT0FBTyxlQUFlRyxRQUFRQSxDQUFDZCxJQUFTLEVBQUNlLE1BQTBDLEVBQUM7RUFDbkYsTUFBTUMsUUFBUSxHQUFDaEIsSUFBSSxDQUFDTSxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQ0MsTUFBTSxDQUFDO0lBQUNDLEdBQUcsRUFBQ1IsSUFBSSxDQUFDaUIsU0FBUyxDQUFDLG1CQUFtQixFQUFDO01BQUNiLEtBQUssRUFBQztJQUFJLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDdEgsSUFBRyxPQUFNWSxRQUFRLENBQUNFLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBRyxJQUFJLEVBQUMsTUFBTUYsUUFBUSxDQUFDVixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUNJLEtBQUssQ0FBQyxDQUFDO0VBQ3ZGLE1BQU1TLEtBQUssR0FBQ0gsUUFBUSxDQUFDUCxTQUFTLENBQUMsU0FBUyxFQUFDO01BQUNQLElBQUksRUFBQyxPQUFPO01BQUNFLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQztJQUFDZ0IsSUFBSSxHQUFDQyxJQUFJLENBQUNDLEtBQUssQ0FBQyxNQUFNSCxLQUFLLENBQUNJLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDN0dSLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDO0VBQUMsTUFBTUQsS0FBSyxDQUFDSyxJQUFJLENBQUNILElBQUksQ0FBQ0ksU0FBUyxDQUFDTCxJQUFJLENBQUMsQ0FBQztFQUFDLE9BQU9ELEtBQUs7QUFDakU7QUFDQSxPQUFPLGVBQWVPLE1BQU1BLENBQUMxQixJQUFTLEVBQUM7RUFBQyxNQUFNUixHQUFHLENBQUNRLElBQUksRUFBQyxLQUFLLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNTLFNBQVMsQ0FBQyxLQUFLLEVBQUM7SUFBQ1AsSUFBSSxFQUFDLE9BQU87SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNNLEtBQUssQ0FBQyxDQUFDO0FBQUM7QUFDNUgsT0FBTyxlQUFlaUIsVUFBVUEsQ0FBQzNCLElBQVMsRUFBQztFQUFDLE1BQU1SLEdBQUcsQ0FBQ1EsSUFBSSxFQUFDLEtBQUssQ0FBQztFQUFDLE1BQU1BLElBQUksQ0FBQ1MsU0FBUyxDQUFDLEtBQUssRUFBQztJQUFDUCxJQUFJLEVBQUMsSUFBSTtJQUFDRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ00sS0FBSyxDQUFDLENBQUM7QUFBQztBQUM3SCxPQUFPLGVBQWVrQixNQUFNQSxDQUFDNUIsSUFBUyxFQUFDO0VBQUMsTUFBTVIsR0FBRyxDQUFDUSxJQUFJLEVBQUMsUUFBUSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDUyxTQUFTLENBQUMsS0FBSyxFQUFDO0lBQUNQLElBQUksRUFBQyxPQUFPO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDTSxLQUFLLENBQUMsQ0FBQztBQUFDO0FBQy9ILE9BQU8sZUFBZW1CLFFBQVFBLENBQUM3QixJQUFTLEVBQUM7RUFBQyxNQUFNUixHQUFHLENBQUNRLElBQUksRUFBQyxRQUFRLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNTLFNBQVMsQ0FBQyxLQUFLLEVBQUM7SUFBQ1AsSUFBSSxFQUFDLE9BQU87SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNNLEtBQUssQ0FBQyxDQUFDO0FBQUM7QUFDakksT0FBTyxlQUFlb0IsS0FBS0EsQ0FBQzlCLElBQVMsRUFBQytCLE9BQWMsRUFBQ0MsT0FBTyxHQUFDLEVBQUUsRUFBQ0MsSUFBSSxHQUFDLDBCQUEwQixFQUFDO0VBQy9GLE1BQU1qQyxJQUFJLENBQUNHLFVBQVUsQ0FBQyxTQUFTLEVBQUM7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQzJCLE9BQU8sQ0FBQztFQUNuRSxNQUFNaEMsSUFBSSxDQUFDRyxVQUFVLENBQUMsUUFBUSxFQUFDO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxZQUFZLENBQUMwQixPQUFPLENBQUM7RUFBQyxNQUFNL0IsSUFBSSxDQUFDRyxVQUFVLENBQUMsS0FBSyxFQUFDO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDUyxJQUFJLENBQUM7RUFDdkgsTUFBTWpDLElBQUksQ0FBQ1MsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDUCxJQUFJLEVBQUM7RUFBd0IsQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0FBQ3ZFO0FBQ0EsT0FBTyxlQUFld0IsV0FBV0EsQ0FBQ2xDLElBQVMsRUFBQztFQUMzQyxNQUFNQSxJQUFJLENBQUNTLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ1AsSUFBSSxFQUFDLE9BQU87SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNNLEtBQUssQ0FBQyxDQUFDO0VBQ2hFLE1BQU01QixNQUFNLENBQUNrQixJQUFJLENBQUNpQixTQUFTLENBQUMscUJBQXFCLEVBQUM7SUFBQ2IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQytCLFdBQVcsQ0FBQyxDQUFDO0FBQy9FO0FBQ0EsT0FBTyxlQUFlQyxnQkFBZ0JBLENBQUNwQyxJQUFTLEVBQUNxQyxRQUFlLEVBQUM7RUFBQSxJQUFBQyxrQkFBQTtFQUNoRSxNQUFNQyxJQUFJLEdBQUN2QyxJQUFJLENBQUNNLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDQyxNQUFNLENBQUM7SUFBQ2lDLE9BQU8sRUFBQ0g7RUFBUSxDQUFDLENBQUM7RUFBQyxNQUFNdkQsTUFBTSxDQUFDeUQsSUFBSSxDQUFDLENBQUNKLFdBQVcsQ0FBQyxDQUFDO0VBQ3ZHLE1BQU1NLE9BQU8sR0FBQ3pDLElBQUksQ0FBQzBDLFlBQVksQ0FBQyxVQUFVLENBQUM7RUFBQyxNQUFNSCxJQUFJLENBQUM5QixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNQLElBQUksRUFBQyxTQUFTO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDTSxLQUFLLENBQUMsQ0FBQztFQUM5RyxNQUFNaUMsSUFBSSxHQUFDLE1BQU1GLE9BQU87RUFBQzNELE1BQU0sQ0FBQyxNQUFNNkQsSUFBSSxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0VBQUMsTUFBTUMsS0FBSyxHQUFDLElBQUlDLFVBQVUsQ0FBQyxNQUFNaEUsUUFBUSxDQUFFLE1BQU00RCxJQUFJLENBQUNLLElBQUksQ0FBQyxDQUFHLENBQUMsQ0FBQztFQUFDLE1BQU1sRCxnQkFBZ0IsQ0FBQ2dELEtBQUssRUFBQyxXQUFXVCxRQUFRLEVBQUUsR0FBQUMsa0JBQUEsR0FBQ0QsUUFBUSxDQUFDWSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFBWixrQkFBQSxjQUFBQSxrQkFBQSxHQUFFLEtBQUssQ0FBQztFQUFDLE9BQU9RLEtBQUs7QUFDck87QUFDQSxPQUFPLGVBQWVLLGNBQWNBLENBQUNDLE9BQWUsRUFBQ04sS0FBZ0IsRUFBQ08sSUFBa0IsR0FBQyxLQUFLLEVBQUM7RUFDOUYsTUFBTUMsS0FBSyxHQUFDLE1BQU1GLE9BQU8sQ0FBQ0csVUFBVSxDQUFDLENBQUM7RUFBQyxJQUFHO0lBQUMsTUFBTUMsQ0FBQyxHQUFDLE1BQU1GLEtBQUssQ0FBQ0csT0FBTyxDQUFDLENBQUM7SUFBQyxNQUFNaEUsV0FBVyxDQUFDK0QsQ0FBQyxFQUFDVixLQUFLLEVBQUN2RCxNQUFNLEVBQUM4RCxJQUFJLENBQUM7SUFBQyxNQUFNRyxDQUFDLENBQUNFLE1BQU0sQ0FBQyxDQUFDO0lBQUMsTUFBTTVFLE1BQU0sQ0FBQzBFLENBQUMsQ0FBQ2xELE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUMsQ0FBQztJQUFDLE9BQU8sTUFBTXpDLE1BQU0sQ0FBQzhELENBQUMsQ0FBQztFQUFDLENBQUMsU0FBTztJQUFDLE1BQU1GLEtBQUssQ0FBQ0ssS0FBSyxDQUFDLENBQUM7RUFBQztBQUMvTztBQUNBLE9BQU8sU0FBU0Msa0JBQWtCQSxDQUFDQyxNQUF1QixFQUFDQyxLQUFzQixFQUFDO0VBQ2pGLE1BQU1DLFNBQVMsR0FBRUMsQ0FBa0IsSUFBR0EsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLEdBQUcsQ0FBQ0MsQ0FBQyxLQUFHO0lBQUNuQixJQUFJLEVBQUNtQixDQUFDLENBQUNuQixJQUFJO0lBQUNvQixJQUFJLEVBQUNELENBQUMsQ0FBQ0UsV0FBVztJQUFDQyxTQUFTLEVBQUNILENBQUMsQ0FBQ0csU0FBUztJQUFDQyxVQUFVLEVBQUMxRSxNQUFNLENBQUNzRSxDQUFDLENBQUNyQixLQUFLLENBQUM7SUFBQ0EsS0FBSyxFQUFDcUIsQ0FBQyxDQUFDckIsS0FBSyxDQUFDMEI7RUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQ04sQ0FBQyxFQUFDTyxDQUFDLEtBQUdQLENBQUMsQ0FBQ25CLElBQUksQ0FBQzJCLGFBQWEsQ0FBQ0QsQ0FBQyxDQUFDMUIsSUFBSSxDQUFDLENBQUM7RUFDek1sRSxNQUFNLENBQUNpRixTQUFTLENBQUNELEtBQUssQ0FBQyxDQUFDLENBQUNjLE9BQU8sQ0FBQ2IsU0FBUyxDQUFDRixNQUFNLENBQUMsQ0FBQztFQUFDL0UsTUFBTSxDQUFDZ0YsS0FBSyxDQUFDZSxNQUFNLENBQUMsQ0FBQ0QsT0FBTyxDQUFDZixNQUFNLENBQUNnQixNQUFNLENBQUM7QUFDaEc7QUFDQSxPQUFPLGVBQWVDLGdCQUFnQkEsQ0FBQ0MsQ0FBc0YsRUFBQztFQUM3SCxPQUFPM0YsY0FBYyxDQUFDMkYsQ0FBQyxDQUFDdkIsQ0FBQyxFQUFDO0lBQUN3QixNQUFNLEVBQUMsS0FBSztJQUFDSCxNQUFNLEVBQUNFLENBQUMsQ0FBQ0YsTUFBTTtJQUFDSSxVQUFVLEVBQUMsMEJBQTBCO0lBQUNDLFNBQVMsRUFBQ0MsQ0FBQztNQUFBLElBQUFDLFNBQUE7TUFBQSxRQUFBQSxTQUFBLEdBQUVMLENBQUMsQ0FBQ2QsTUFBTSxjQUFBbUIsU0FBQSx1QkFBUkEsU0FBQSxDQUFXRCxDQUFDLENBQUM7SUFBQTtFQUFBLENBQUMsQ0FBQztBQUMzSDtBQUdBLGVBQWVFLE1BQU1BLENBQUNDLEtBQStCLEVBQUN0QyxJQUFXLEVBQUM7RUFDakUsTUFBTXVDLENBQUMsR0FBQ2xFLElBQUksQ0FBQ0MsS0FBSyxDQUFDcEMsU0FBUyxDQUFDb0csS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQXFCO0lBQUMzQyxJQUFJLEdBQUM0QyxDQUFDLENBQUNELEtBQUssQ0FBQ0UsSUFBSSxDQUFDVCxDQUFDLElBQUVBLENBQUMsQ0FBQy9CLElBQUksS0FBR0EsSUFBSSxDQUFDO0VBQUMsSUFBRyxDQUFDTCxJQUFJLEVBQUMsTUFBTThDLEtBQUssQ0FBQyxnQ0FBZ0MsR0FBQ3pDLElBQUksQ0FBQztFQUN6S0wsSUFBSSxDQUFDK0MsUUFBUSxHQUFDSixLQUFLLENBQUN0QyxJQUFJLENBQUMsQ0FBQ3dCLE1BQU07RUFBQzdCLElBQUksQ0FBQ3RELE1BQU0sR0FBQyxNQUFNQSxNQUFNLENBQUNpRyxLQUFLLENBQUN0QyxJQUFJLENBQUMsQ0FBQztFQUFDc0MsS0FBSyxDQUFDLGVBQWUsQ0FBQyxHQUFDaEcsU0FBUyxDQUFDaUcsQ0FBQyxDQUFDO0FBQzNHO0FBQ0EsT0FBTyxlQUFlSSxXQUFXQSxDQUFDQyxJQUFlLEVBQXVCO0VBQ3ZFLE1BQU1DLFFBQVEsR0FBQzdHLFNBQVMsQ0FBQzRHLElBQUksQ0FBQztJQUFDRSxHQUFnQixHQUFDLEVBQUU7RUFDbEQsTUFBTXhDLEtBQUssR0FBQ0EsQ0FBQSxLQUE4QnlDLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ0osUUFBUSxDQUFDLENBQUMzQixHQUFHLENBQUMsQ0FBQyxDQUFDZ0MsQ0FBQyxFQUFDbEMsQ0FBQyxDQUFDLEtBQUcsQ0FBQ2tDLENBQUMsRUFBQ2xDLENBQUMsQ0FBQ21DLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ2xIO0lBQUMsTUFBTXBCLENBQUMsR0FBQ3pCLEtBQUssQ0FBQyxDQUFDO0lBQUN5QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDO0lBQUNlLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO01BQUNsRyxJQUFJLEVBQUMsdUJBQXVCO01BQUM0QyxLQUFLLEVBQUM3RCxPQUFPLENBQUM4RixDQUFDLENBQUM7TUFBQ3NCLFFBQVEsRUFBQyxpQkFBaUI7TUFBQ0MsWUFBWSxFQUFDLG1CQUFtQjtNQUFDQyxXQUFXLEVBQUM7SUFBa0UsQ0FBQyxDQUFDO0VBQUM7RUFDblA7SUFBQyxNQUFNeEIsQ0FBQyxHQUFDekIsS0FBSyxDQUFDLENBQUM7TUFBQ2lDLENBQUMsR0FBQ2xFLElBQUksQ0FBQ0MsS0FBSyxDQUFDcEMsU0FBUyxDQUFDNkYsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7SUFBQ1EsQ0FBQyxDQUFDaUIsYUFBYSxHQUFDLFFBQVE7SUFBQ3pCLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBQ3pGLFNBQVMsQ0FBQ2lHLENBQUMsQ0FBQztJQUFDTyxHQUFHLENBQUNNLElBQUksQ0FBQztNQUFDbEcsSUFBSSxFQUFDLHNCQUFzQjtNQUFDNEMsS0FBSyxFQUFDN0QsT0FBTyxDQUFDOEYsQ0FBQyxDQUFDO01BQUNzQixRQUFRLEVBQUMsVUFBVTtNQUFDQyxZQUFZLEVBQUMsZUFBZTtNQUFDQyxXQUFXLEVBQUM7SUFBa0UsQ0FBQyxDQUFDO0VBQUM7RUFDL1M7SUFBQyxNQUFNeEIsQ0FBQyxHQUFDekIsS0FBSyxDQUFDLENBQUM7SUFBQ3lCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFDNUYsT0FBTyxDQUFDLElBQUksQ0FBQztJQUFDMkcsR0FBRyxDQUFDTSxJQUFJLENBQUM7TUFBQ2xHLElBQUksRUFBQyxnQkFBZ0I7TUFBQzRDLEtBQUssRUFBQzdELE9BQU8sQ0FBQzhGLENBQUMsQ0FBQztNQUFDc0IsUUFBUSxFQUFDLGVBQWU7TUFBQ0MsWUFBWSxFQUFDLGlCQUFpQjtNQUFDQyxXQUFXLEVBQUM7SUFBK0MsQ0FBQyxDQUFDO0VBQUM7RUFDM047SUFBQyxNQUFNeEIsQ0FBQyxHQUFDekIsS0FBSyxDQUFDLENBQUM7TUFBQ0UsQ0FBQyxHQUFDbkMsSUFBSSxDQUFDQyxLQUFLLENBQUNwQyxTQUFTLENBQUM2RixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0lBQUMsTUFBTTBCLEtBQUssR0FBQ2pELENBQUMsQ0FBQ2tELFFBQVEsQ0FBQ2xCLElBQUksQ0FBRW1CLENBQWUsSUFBR0EsQ0FBQyxDQUFDMUcsSUFBSSxLQUFHLE9BQU8sQ0FBQztJQUFDLElBQUcsQ0FBQ3dHLEtBQUssRUFBQyxNQUFNaEIsS0FBSyxDQUFDLGtDQUFrQyxDQUFDO0lBQUNnQixLQUFLLENBQUNyRixJQUFJLENBQUN3RixVQUFVLEdBQUMsc0NBQXNDO0lBQUM3QixDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBQ3pGLFNBQVMsQ0FBQ2tFLENBQUMsQ0FBQztJQUFDLE1BQU02QixNQUFNLENBQUNOLENBQUMsRUFBQyxtQkFBbUIsQ0FBQztJQUFDZSxHQUFHLENBQUNNLElBQUksQ0FBQztNQUFDbEcsSUFBSSxFQUFDLHdCQUF3QjtNQUFDNEMsS0FBSyxFQUFDN0QsT0FBTyxDQUFDOEYsQ0FBQyxDQUFDO01BQUNzQixRQUFRLEVBQUMscUJBQXFCO01BQUNDLFlBQVksRUFBQyxtQkFBbUI7TUFBQ0MsV0FBVyxFQUFDO0lBQTRELENBQUMsQ0FBQztFQUFDO0VBQ3JnQjtJQUFDLE1BQU14QixDQUFDLEdBQUN6QixLQUFLLENBQUMsQ0FBQztNQUFDRSxDQUFDLEdBQUNuQyxJQUFJLENBQUNDLEtBQUssQ0FBQ3BDLFNBQVMsQ0FBQzZGLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7SUFBQ3ZCLENBQUMsQ0FBQ2tELFFBQVEsQ0FBQ04sSUFBSSxDQUFDUyxlQUFlLENBQUNyRCxDQUFDLENBQUNrRCxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFDM0IsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUN6RixTQUFTLENBQUNrRSxDQUFDLENBQUM7SUFBQyxNQUFNNkIsTUFBTSxDQUFDTixDQUFDLEVBQUMsbUJBQW1CLENBQUM7SUFBQ2UsR0FBRyxDQUFDTSxJQUFJLENBQUM7TUFBQ2xHLElBQUksRUFBQyxvQkFBb0I7TUFBQzRDLEtBQUssRUFBQzdELE9BQU8sQ0FBQzhGLENBQUMsQ0FBQztNQUFDc0IsUUFBUSxFQUFDLFVBQVU7TUFBQ0MsWUFBWSxFQUFDLG1CQUFtQjtNQUFDQyxXQUFXLEVBQUM7SUFBNEMsQ0FBQyxDQUFDO0VBQUM7RUFDOVY7SUFBQyxNQUFNeEIsQ0FBQyxHQUFDekIsS0FBSyxDQUFDLENBQUM7TUFBQ0UsQ0FBQyxHQUFDbkMsSUFBSSxDQUFDQyxLQUFLLENBQUNwQyxTQUFTLENBQUM2RixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0lBQUN2QixDQUFDLENBQUNrRCxRQUFRLENBQUNsQixJQUFJLENBQUVtQixDQUFlLElBQUdBLENBQUMsQ0FBQzFHLElBQUksS0FBRyxNQUFNLENBQUMsQ0FBQ21CLElBQUksQ0FBQzBGLElBQUksR0FBQyxDQUFDO01BQUNDLEVBQUUsRUFBQyxzQ0FBc0M7TUFBQzlHLElBQUksRUFBQyxXQUFXO01BQUMrRyxJQUFJLEVBQUMsR0FBRyxDQUFDQyxNQUFNLENBQUMsTUFBTTtJQUFDLENBQUMsQ0FBQztJQUFDbEMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUN6RixTQUFTLENBQUNrRSxDQUFDLENBQUM7SUFBQyxNQUFNNkIsTUFBTSxDQUFDTixDQUFDLEVBQUMsbUJBQW1CLENBQUM7SUFBQyxNQUFNbUMsTUFBTSxHQUFDakksT0FBTyxDQUFDOEYsQ0FBQyxFQUFDO1FBQUNvQyxLQUFLLEVBQUM7TUFBQyxDQUFDLENBQUM7TUFBQ25ELENBQUMsR0FBQyxJQUFJb0QsUUFBUSxDQUFDRixNQUFNLENBQUNHLE1BQU0sRUFBQ0gsTUFBTSxDQUFDSSxVQUFVLEVBQUNKLE1BQU0sQ0FBQ0ssVUFBVSxDQUFDO0lBQUMsS0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUNOLE1BQU0sQ0FBQzFDLE1BQU0sR0FBQyxFQUFFLEVBQUNnRCxDQUFDLEVBQUUsRUFBQztNQUFDLElBQUd4RCxDQUFDLENBQUN5RCxTQUFTLENBQUNELENBQUMsRUFBQyxJQUFJLENBQUMsS0FBRyxVQUFVLEVBQUM7TUFBUyxNQUFNRSxDQUFDLEdBQUMxRCxDQUFDLENBQUMyRCxTQUFTLENBQUNILENBQUMsR0FBQyxFQUFFLEVBQUMsSUFBSSxDQUFDO1FBQUN0SCxJQUFJLEdBQUNoQixTQUFTLENBQUNnSSxNQUFNLENBQUNVLFFBQVEsQ0FBQ0osQ0FBQyxHQUFDLEVBQUUsRUFBQ0EsQ0FBQyxHQUFDLEVBQUUsR0FBQ0UsQ0FBQyxDQUFDLENBQUM7TUFBQyxJQUFHeEgsSUFBSSxLQUFHLG1CQUFtQixFQUFDO01BQVMsTUFBTTJILEtBQUssR0FBQzdELENBQUMsQ0FBQ3lELFNBQVMsQ0FBQ0QsQ0FBQyxHQUFDLEVBQUUsRUFBQyxJQUFJLENBQUM7TUFBQ3hELENBQUMsQ0FBQzhELFNBQVMsQ0FBQ04sQ0FBQyxHQUFDLEVBQUUsRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDO01BQUN4RCxDQUFDLENBQUM4RCxTQUFTLENBQUNELEtBQUssR0FBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLElBQUksQ0FBQztJQUFDO0lBQUMvQixHQUFHLENBQUNNLElBQUksQ0FBQztNQUFDbEcsSUFBSSxFQUFDLGdDQUFnQztNQUFDNEMsS0FBSyxFQUFDb0UsTUFBTTtNQUFDYixRQUFRLEVBQUMsZ0JBQWdCO01BQUNDLFlBQVksRUFBQyxtQkFBbUI7TUFBQ0MsV0FBVyxFQUFDO0lBQW1ILENBQUMsQ0FBQztFQUFDO0VBQzk1QjtJQUFDLE1BQU14QixDQUFDLEdBQUN6QixLQUFLLENBQUMsQ0FBQztNQUFDNEQsTUFBTSxHQUFDakksT0FBTyxDQUFDOEYsQ0FBQyxDQUFDO01BQUNnRCxLQUFLLEdBQUNoQyxNQUFNLENBQUNpQyxJQUFJLENBQUNqRCxDQUFDLENBQUMsQ0FBQ3hFLE1BQU0sQ0FBQzJGLENBQUMsSUFBRUEsQ0FBQyxDQUFDK0IsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQUMsSUFBR0YsS0FBSyxDQUFDdkQsTUFBTSxJQUFFLENBQUMsSUFBRXVELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZELE1BQU0sS0FBR3VELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZELE1BQU0sRUFBQztNQUFDLE1BQU0wRCxJQUFJLEdBQUMvSSxPQUFPLENBQUM0SSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQ0ksRUFBRSxHQUFDaEosT0FBTyxDQUFDNEksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsS0FBSSxJQUFJUCxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLElBQUVOLE1BQU0sQ0FBQzFDLE1BQU0sR0FBQzBELElBQUksQ0FBQzFELE1BQU0sRUFBQ2dELENBQUMsRUFBRSxFQUFDLElBQUdVLElBQUksQ0FBQ0UsS0FBSyxDQUFDLENBQUMxRCxDQUFDLEVBQUMyRCxDQUFDLEtBQUduQixNQUFNLENBQUNNLENBQUMsR0FBQ2EsQ0FBQyxDQUFDLEtBQUczRCxDQUFDLENBQUMsRUFBQ3dDLE1BQU0sQ0FBQ29CLEdBQUcsQ0FBQ0gsRUFBRSxFQUFDWCxDQUFDLENBQUM7TUFBQzFCLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO1FBQUNsRyxJQUFJLEVBQUMsK0JBQStCO1FBQUM0QyxLQUFLLEVBQUNvRSxNQUFNO1FBQUNiLFFBQVEsRUFBQyxVQUFVO1FBQUNDLFlBQVksRUFBQ3lCLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFBQ3hCLFdBQVcsRUFBQztNQUF5RixDQUFDLENBQUM7SUFBQztFQUFDO0VBQ3ZmLE9BQU9ULEdBQUc7QUFDWDtBQUNBLE9BQU8sZUFBZXlDLGdCQUFnQkEsQ0FBQ3ZJLElBQVMsRUFBQ3dJLEdBQWMsRUFBQ0MsSUFBYSxFQUFDO0VBQzdFLE1BQU0zSSxnQkFBZ0IsQ0FBQzBJLEdBQUcsQ0FBQzFGLEtBQUssRUFBQyxZQUFZMEYsR0FBRyxDQUFDdEksSUFBSSxFQUFFLENBQUM7RUFDeEQsTUFBTVYsR0FBRyxDQUFDUSxJQUFJLEVBQUMsUUFBUSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDUyxTQUFTLENBQUMsS0FBSyxFQUFDO0lBQUNQLElBQUksRUFBQyxTQUFTO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDTSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1tRCxNQUFNLEdBQUMsTUFBTWxFLE9BQU8sQ0FBQ0ssSUFBSSxDQUFDO0lBQUMwSSxTQUFTLEdBQUM3SSxNQUFNLENBQUN3QixJQUFJLENBQUNJLFNBQVMsQ0FBQ29DLE1BQU0sQ0FBQyxDQUFDO0VBQ2xLLE1BQU03RCxJQUFJLENBQUNHLFVBQVUsQ0FBQyxXQUFXLEVBQUM7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUN1SSxhQUFhLENBQUM7SUFBQ3pJLElBQUksRUFBQyxtQkFBbUI7SUFBQzBJLFFBQVEsRUFBQyxpQkFBaUI7SUFBQ3ZCLE1BQU0sRUFBQ3dCLE1BQU0sQ0FBQ1gsSUFBSSxDQUFDTSxHQUFHLENBQUMxRixLQUFLO0VBQUMsQ0FBQyxDQUFDO0VBQ2xKLE1BQU1nRyxLQUFLLEdBQUM5SSxJQUFJLENBQUNNLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0csU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDc0ksS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNakssTUFBTSxDQUFDZ0ssS0FBSyxDQUFDLENBQUNuSSxhQUFhLENBQUM2SCxHQUFHLENBQUNuQyxRQUFRLENBQUM7RUFDbkgsSUFBR21DLEdBQUcsQ0FBQ2xDLFlBQVksRUFBQyxNQUFNeEgsTUFBTSxDQUFDa0ssSUFBSSxDQUFDRixLQUFLLENBQUMsQ0FBQ25JLGFBQWEsQ0FBQzZILEdBQUcsQ0FBQ2xDLFlBQVksRUFBQztJQUFDMkMsT0FBTyxFQUFDO0VBQUcsQ0FBQyxDQUFDO0VBQzFGLE1BQU1uRixLQUFLLEdBQUMsTUFBTW5FLE9BQU8sQ0FBQ0ssSUFBSSxDQUFDO0VBQUNsQixNQUFNLENBQUNnRixLQUFLLENBQUMsQ0FBQ2MsT0FBTyxDQUFDZixNQUFNLENBQUM7RUFDN0QsTUFBTWpFLFFBQVEsQ0FBQzZJLElBQUksRUFBQ0QsR0FBRyxDQUFDdEksSUFBSSxDQUFDZ0osT0FBTyxDQUFDLEtBQUssRUFBQyxHQUFHLENBQUMsRUFBQztJQUFDQyxXQUFXLEVBQUN0SixNQUFNLENBQUMySSxHQUFHLENBQUMxRixLQUFLLENBQUM7SUFBQ3dELFlBQVksRUFBQ2tDLEdBQUcsQ0FBQ2xDLFlBQVk7SUFBQ0QsUUFBUSxFQUFDbUMsR0FBRyxDQUFDbkMsUUFBUSxDQUFDK0MsTUFBTTtJQUFDQyxXQUFXLEVBQUMsTUFBTVAsS0FBSyxDQUFDUSxTQUFTLENBQUMsQ0FBQztJQUFDWixTQUFTO0lBQUNhLFFBQVEsRUFBQzFKLE1BQU0sQ0FBQ3dCLElBQUksQ0FBQ0ksU0FBUyxDQUFDcUMsS0FBSyxDQUFDLENBQUM7SUFBQzBGLHVCQUF1QixFQUFDLElBQUk7SUFBQ2pELFdBQVcsRUFBQ2lDLEdBQUcsQ0FBQ2pDO0VBQVcsQ0FBQyxDQUFDO0FBQzFSO0FBQ0EsT0FBTyxlQUFla0QsY0FBY0EsQ0FBQ3pKLElBQVMsRUFBQztFQUFDLE1BQU0wSixVQUFVLEdBQUMsTUFBTTFKLElBQUksQ0FBQzJKLFFBQVEsQ0FBQyxNQUFJQyxRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsV0FBVyxHQUFDRixRQUFRLENBQUNDLGVBQWUsQ0FBQ0UsV0FBVyxDQUFDO0VBQUMsSUFBR0wsVUFBVSxHQUFDLENBQUMsRUFBQztJQUFDTSxPQUFPLENBQUNDLEdBQUcsQ0FBQyxrQ0FBa0MsR0FBQzVJLElBQUksQ0FBQ0ksU0FBUyxDQUFDLE1BQU16QixJQUFJLENBQUMySixRQUFRLENBQUMsT0FBSztNQUFDTyxVQUFVO01BQUNKLFdBQVcsRUFBQ0YsUUFBUSxDQUFDQyxlQUFlLENBQUNDLFdBQVc7TUFBQ0MsV0FBVyxFQUFDSCxRQUFRLENBQUNDLGVBQWUsQ0FBQ0UsV0FBVztNQUFDSSxPQUFPO01BQUNDLFNBQVMsRUFBQ0MsS0FBSyxDQUFDbkMsSUFBSSxDQUFDMEIsUUFBUSxDQUFDVSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUNDLE9BQU8sSUFBRTtRQUFBLElBQUFDLG9CQUFBO1FBQUMsSUFBRyxFQUFFRCxPQUFPLFlBQVlFLFdBQVcsQ0FBQyxFQUFDLE9BQU8sRUFBRTtRQUFDLE1BQU1DLElBQUksR0FBQ0gsT0FBTyxDQUFDSSxxQkFBcUIsQ0FBQyxDQUFDO1VBQUNDLEtBQUssR0FBQ0MsZ0JBQWdCLENBQUNOLE9BQU8sQ0FBQztRQUFDLElBQUdHLElBQUksQ0FBQ0ksS0FBSyxJQUFFYixVQUFVLEdBQUMsQ0FBQyxJQUFFUyxJQUFJLENBQUNLLEtBQUssSUFBRSxDQUFDLElBQUVILEtBQUssQ0FBQ0ksT0FBTyxLQUFHLE1BQU0sSUFBRUosS0FBSyxDQUFDSyxVQUFVLEtBQUcsUUFBUSxFQUFDLE9BQU8sRUFBRTtRQUFDLE9BQU8sQ0FBQztVQUFDQyxHQUFHLEVBQUNYLE9BQU8sQ0FBQ1ksT0FBTztVQUFDQyxTQUFTLEVBQUNiLE9BQU8sQ0FBQ3RKLFlBQVksQ0FBQyxPQUFPLENBQUM7VUFBQzZGLEVBQUUsRUFBQ3lELE9BQU8sQ0FBQ3pELEVBQUU7VUFBQ0MsSUFBSSxFQUFDLEVBQUF5RCxvQkFBQSxHQUFDRCxPQUFPLENBQUNjLFdBQVcsY0FBQWIsb0JBQUEsY0FBQUEsb0JBQUEsR0FBRSxFQUFFLEVBQUV0RSxLQUFLLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQztVQUFDb0YsSUFBSSxFQUFDWixJQUFJLENBQUNZLElBQUk7VUFBQ1IsS0FBSyxFQUFDSixJQUFJLENBQUNJLEtBQUs7VUFBQ0MsS0FBSyxFQUFDTCxJQUFJLENBQUNLLEtBQUs7VUFBQ1EsUUFBUSxFQUFDWCxLQUFLLENBQUNXLFFBQVE7VUFBQ0MsVUFBVSxFQUFDWixLQUFLLENBQUNZLFVBQVU7VUFBQzNCLFdBQVcsRUFBQ1UsT0FBTyxDQUFDVixXQUFXO1VBQUNDLFdBQVcsRUFBQ1MsT0FBTyxDQUFDVCxXQUFXO1VBQUMyQixTQUFTLEVBQUNiLEtBQUssQ0FBQ2EsU0FBUztVQUFDQyxRQUFRLEVBQUNkLEtBQUssQ0FBQ2MsUUFBUTtVQUFDQyxTQUFTLEVBQUN2QixLQUFLLENBQUNuQyxJQUFJLENBQUUsV0FBVTJELE9BQW9CLEVBQUM7WUFBQyxLQUFJLElBQUlyRSxDQUFDLEdBQUMsQ0FBQyxFQUFDcUUsT0FBTyxJQUFFckUsQ0FBQyxHQUFDLENBQUMsRUFBQ0EsQ0FBQyxFQUFFLEVBQUNxRSxPQUFPLEdBQUNBLE9BQU8sQ0FBQ0MsYUFBYSxFQUFDLE1BQU1ELE9BQU87VUFBQyxDQUFDLENBQUVyQixPQUFPLENBQUNzQixhQUFhLENBQUMsQ0FBQyxDQUFDNUgsR0FBRyxDQUFDNkgsTUFBTSxLQUFHO1lBQUNaLEdBQUcsRUFBQ1ksTUFBTSxDQUFDWCxPQUFPO1lBQUNDLFNBQVMsRUFBQ1UsTUFBTSxDQUFDN0ssWUFBWSxDQUFDLE9BQU8sQ0FBQztZQUFDd0ssU0FBUyxFQUFDWixnQkFBZ0IsQ0FBQ2lCLE1BQU0sQ0FBQyxDQUFDTCxTQUFTO1lBQUNYLEtBQUssRUFBQ2dCLE1BQU0sQ0FBQ25CLHFCQUFxQixDQUFDLENBQUMsQ0FBQ0c7VUFBSyxDQUFDLENBQUM7UUFBQyxDQUFDLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQzVFLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTtJQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFDO0VBQUNySCxNQUFNLENBQUM0SyxVQUFVLENBQUMsQ0FBQ3NDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztBQUFDIiwiaWdub3JlTGlzdCI6W119