// 3bb6951695788d8acfa6401c67e02f90430f1337
import { test, expect } from '@playwright/test';
import { seed, nav, backup, durable, digest, evidence } from './common';
import { openRecord, saveEditor, editData, freshRoundtrip } from './extended-support';
import { originalFundamentalsFixture } from './remaining-original-fundamentals-fixtures';
import { createEntity } from '../candidate/src/domain/model';
async function timeline(page) {
  await nav(page, /^年表/);
  await page.getByRole('tab', {
    name: '世界内年表',
    exact: true
  }).click();
}
async function writing(page) {
  await nav(page, /^構成/);
  await page.getByRole('tab', {
    name: '章・本文',
    exact: true
  }).click();
}
async function closeDetail(page) {
  const close = page.getByRole('button', {
    name: '詳細を閉じる',
    exact: true
  });
  if (await close.isVisible()) await close.click();
}
test('AT-B02 original common/two-person events: edit from common lane, reopen identical ID in each person lane, no implicit participation/knowledge; cold and complete roundtrip', async ({
  page,
  browser
}, info) => {
  var _cold$parsed$project$, _restored$parsed$proj;
  test.setTimeout(180000);
  const f = await originalFundamentalsFixture();
  await seed(page, f.p);
  await timeline(page);
  const before = await durable(page);
  await page.locator('[data-lane-id="common"] [data-event-id="' + f.common.id + '"]').click();
  await expect(page.locator('[data-field="summary"] textarea[data-rich-text-editor]')).toHaveValue(f.common.data.summary[0].text);
  await closeDetail(page);
  expect(await durable(page)).toEqual(before);
  await page.locator('[data-lane-id="common"] [data-event-id="' + f.both.id + '"]').click();
  await page.locator('[data-field="summary"] textarea[data-rich-text-editor]').fill('原B02 共通から変更した同一本文😀');
  await saveEditor(page);
  await closeDetail(page);
  for (const person of [f.a, f.b]) {
    const lane = page.locator('[data-lane-id="member:' + f.g1.id + ':' + person.id + '"]');
    await lane.locator('[data-event-id="' + f.both.id + '"]').click();
    await expect(page.locator('[data-field="summary"] textarea[data-rich-text-editor]')).toHaveValue('原B02 共通から変更した同一本文😀');
    await closeDetail(page);
  }
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page),
    common = cold.parsed.project.entities.find(e => e.id === f.common.id),
    both = cold.parsed.project.entities.find(e => e.id === f.both.id);
  expect(common.kind === 'event' && common.data.participants).toEqual([]);
  expect(both.kind === 'event' && both.data.participants).toEqual(f.both.data.participants);
  expect(cold.parsed.project.entities.filter(e => e.kind === 'assertion' || e.kind === 'effect')).toHaveLength(0);
  expect((_cold$parsed$project$ = cold.parsed.project.snapshots.find(s => s.id === f.pin.id)) === null || _cold$parsed$project$ === void 0 ? void 0 : _cold$parsed$project$.contentHash).toBe(f.pin.contentHash);
  const restored = await freshRoundtrip(browser, cold.bytes);
  expect((_restored$parsed$proj = restored.parsed.project.entities.find(e => e.id === f.both.id)) === null || _restored$parsed$proj === void 0 ? void 0 : _restored$parsed$proj.data).toEqual(both.data);
  await evidence(info, 'B02-original-clauses', {
    given: {
      common: f.common.id,
      twoPersonEvent: f.both.id
    },
    when: {
      editedFromCommonLane: true
    },
    then: {
      sameEventIDs: [f.both.id],
      reopenedFromBothPersonLanes: true,
      coldSameBody: true
    },
    negative: {
      commonParticipationUnchanged: true,
      noAssertionsOrKnowledgeEffectsAdded: true
    },
    nativeBeforeViewSHA: digest(JSON.stringify(before)),
    completeArchiveSHA: digest(cold.bytes),
    physical: 'not_run'
  });
});
test('AT-B03 original same person in two groups: collapse/reorder preserves person/member/event IDs; explicit archive impact keeps bodies; cold', async ({
  page
}, info) => {
  var _p$entities$find, _p$entities$find2, _p$entities$find3;
  test.setTimeout(180000);
  const f = await originalFundamentalsFixture();
  await seed(page, f.p);
  await timeline(page);
  await page.getByRole('button', {
    name: 'グループ・人物レーン',
    exact: true
  }).click();
  const modal = page.getByRole('dialog', {
      name: 'グループ・人物レーンを編集',
      exact: true
    }),
    row = modal.locator('.timeline-group-editor-row').filter({
      has: page.getByText(f.g1.name, {
        exact: true
      })
    });
  const before = await durable(page);
  await row.getByRole('button', {
    name: '折りたたむ',
    exact: true
  }).click();
  await expect(row.getByRole('button', {
    name: '展開',
    exact: true
  })).toBeVisible();
  expect(await durable(page)).toEqual(before);
  await modal.getByRole('button', {
    name: f.g2.name + 'を前へ',
    exact: true
  }).click();
  await expect(modal.locator('.timeline-group-editor-row').first()).toContainText(f.g2.name);
  const reordered = await durable(page);
  for (const store of ['entities', 'relations', 'blocks', 'snapshots', 'assets', 'worlds']) expect(reordered[store]).toEqual(before[store]);
  await modal.getByRole('button', {
    name: '閉じる',
    exact: true
  }).click();
  const ordered = await backup(page);
  for (const e of [f.a, f.b, f.g1, f.g2, f.common, f.both, f.unset]) expect(ordered.parsed.project.entities.find(c => c.id === e.id)).toEqual(e);
  await timeline(page);
  await page.getByRole('button', {
    name: 'グループ・人物レーン',
    exact: true
  }).click();
  await row.getByRole('button', {
    name: '改名・階層・人物を編集',
    exact: true
  }).click();
  await modal.getByRole('button', {
    name: 'グループを外す前に確認',
    exact: true
  }).click();
  await expect(modal.locator('.timeline-delete-impact')).toContainText('人物と出来事の本体・IDは保持します');
  await modal.getByRole('button', {
    name: '影響を確認してグループを外す',
    exact: true
  }).click();
  await expect(modal.locator('.timeline-group-editor-row').filter({
    hasText: f.g1.name
  })).toHaveCount(0);
  await modal.getByRole('button', {
    name: '閉じる',
    exact: true
  }).click();
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page),
    p = cold.parsed.project;
  expect((_p$entities$find = p.entities.find(e => e.id === f.g1.id)) === null || _p$entities$find === void 0 ? void 0 : _p$entities$find.deletedAt).toBeTruthy();
  expect((_p$entities$find2 = p.entities.find(e => e.id === f.g1.id)) === null || _p$entities$find2 === void 0 ? void 0 : _p$entities$find2.data).toEqual(f.g1.data);
  expect((_p$entities$find3 = p.entities.find(e => e.id === f.g2.id)) === null || _p$entities$find3 === void 0 ? void 0 : _p$entities$find3.data).toEqual(f.g2.data);
  for (const e of [f.a, f.b, f.common, f.both, f.unset]) expect(p.entities.find(c => c.id === e.id)).toEqual(e);
  await evidence(info, 'B03-original-clauses', {
    given: {
      person: f.a.id,
      groups: [f.g1.id, f.g2.id]
    },
    when: {
      foldedOne: true,
      reorderedExplicitly: true
    },
    then: {
      samePersonBodiesAndIDs: true,
      remainingMembershipAndAllEventIDsUnchanged: true
    },
    negative: {
      impactShownBeforeArchive: true,
      personAndEventsNotCascadeDeleted: true
    },
    coldArchiveSHA: digest(cold.bytes)
  });
});
test('AT-B07 original tap source/target creates a typed event relation, timeline/list edit same ID; empty or wrong-kind targets safely refused; cold', async ({
  page
}, info) => {
  test.setTimeout(180000);
  const f = await originalFundamentalsFixture();
  await seed(page, f.p);
  await timeline(page);
  await page.getByRole('button', {
    name: '始点 → 終点をタップで結ぶ',
    exact: true
  }).click();
  await page.locator('[data-lane-id="common"] [data-event-id="' + f.common.id + '"]').click();
  await page.locator('[data-lane-id="common"] [data-event-id="' + f.both.id + '"]').click();
  const modal = page.getByRole('dialog', {
    name: '年表の関係を編集',
    exact: true
  });
  await expect(modal.getByLabel('年表の関係の始点', {
    exact: true
  })).toHaveValue(f.common.id);
  await expect(modal.getByLabel('年表の関係の終点', {
    exact: true
  })).toHaveValue(f.both.id);
  await modal.getByLabel('年表の関係の種類', {
    exact: true
  }).selectOption('causes');
  await modal.getByRole('button', {
    name: '関係を保存',
    exact: true
  }).click();
  await expect(modal).toHaveCount(0);
  const first = await backup(page),
    relation = first.parsed.project.relations.find(r => r.fromId === f.common.id && r.toId === f.both.id);
  expect(relation).toBeTruthy();
  await timeline(page);
  await page.locator('.timeline-relation-row [data-relation-id="' + relation.id + '"]').click();
  await expect(modal).toContainText(relation.id);
  const beforeInvalid = await durable(page);
  await modal.getByLabel('年表の関係の終点', {
    exact: true
  }).selectOption('');
  await modal.getByRole('button', {
    name: '関係を保存',
    exact: true
  }).click();
  await expect(modal.getByRole('alert')).toContainText('存在する出来事を始点と終点に選んでください');
  expect(await durable(page)).toEqual(beforeInvalid);
  await expect(modal.getByLabel('年表の関係の終点', {
    exact: true
  })).toHaveValue('');
  // A typed boundary cannot be entered through the filtered ordinary picker.
  // Submit it through that same change handler as a synthetic invalid input;
  // the persisted value must still be refused with the original reason.
  const target = modal.getByLabel('年表の関係の終点', {
    exact: true
  });
  const missing = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
  await target.evaluate((select, id) => {
    const o = document.createElement('option');
    o.value = id;
    o.text = '存在しない出来事';
    select.append(o);
  }, missing);
  await target.selectOption(missing);
  await modal.getByRole('button', {
    name: '関係を保存',
    exact: true
  }).click();
  await expect(modal.getByRole('alert')).toContainText('存在する出来事を始点と終点に選んでください');
  await expect(target).toHaveValue(missing);
  expect(await durable(page)).toEqual(beforeInvalid);
  await target.evaluate((select, id) => {
    const o = document.createElement('option');
    o.value = id;
    o.text = '不正型の人物';
    select.append(o);
  }, f.a.id);
  await target.selectOption(f.a.id);
  await modal.getByRole('button', {
    name: '関係を保存',
    exact: true
  }).click();
  await expect(modal.getByRole('alert')).toContainText('存在する出来事を始点と終点に選んでください');
  expect(await durable(page)).toEqual(beforeInvalid);
  await target.selectOption(f.both.id);
  await modal.getByLabel('年表の関係の種類', {
    exact: true
  }).selectOption('event_payoff');
  await modal.getByRole('button', {
    name: '関係を保存',
    exact: true
  }).click();
  await expect(modal).toHaveCount(0);
  await expect(page.locator('.timeline-relation-row [data-relation-id="' + relation.id + '"]').filter({
    hasText: '出来事の回収'
  })).toBeVisible();
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page);
  expect(cold.parsed.project.relations.find(r => r.id === relation.id)).toMatchObject({
    fromId: f.common.id,
    toId: f.both.id,
    relationType: 'event_payoff'
  });
  await evidence(info, 'B07-original-clauses', {
    given: {
      twoEvents: [f.common.id, f.both.id]
    },
    when: {
      tapSourceAndTarget: true,
      typedMeaning: 'causes'
    },
    then: {
      relationID: relation.id,
      reopenedAndEditedFromTimelineRelationList: true,
      coldMeaning: 'event_payoff'
    },
    negative: {
      emptyTargetRejectedWithReason: true,
      nonexistentUUID: missing,
      nonexistentUUIDRejectedWithReasonAndInputRetained: true,
      wrongKindRejectedWithReason: true,
      canonicalNativeRowsUnchanged: true,
      wrongKindSubmissionLayer: 'DOM-invalid option through ordinary typed change handler; not natural picker availability'
    }
  });
});
test('AT-B08 original empty participants: register two different roles and memo, reverse references same event, roles and knowledge remain distinct; cold', async ({
  page
}, info) => {
  var _beforeExplicit$parse, _heard$parsed$project;
  test.setTimeout(180000);
  const f = await originalFundamentalsFixture();
  const source = createEntity(f.p.projectId, 'source', '原B08 伝聞の出所', {
      sourceType: 'web',
      locator: 'https://example.invalid/hearsay',
      excerptLocation: '目撃者から聞いた箇所'
    }),
    testimony = createEntity(f.p.projectId, 'assertion', '原B08 伝聞の証言', {
      subjectId: f.place.id,
      predicate: 'heard_door_open',
      value: {
        type: 'boolean',
        value: true
      },
      truthKind: 'testimony',
      holderId: f.b.id,
      sourceIds: [source.id]
    }),
    belief = createEntity(f.p.projectId, 'assertion', '原B08 人物の認識', {
      subjectId: f.place.id,
      predicate: 'door_open',
      value: {
        type: 'boolean',
        value: true
      },
      truthKind: 'belief',
      holderId: f.b.id,
      sourceIds: [source.id]
    }),
    knowledge = createEntity(f.p.projectId, 'effect', '原B08 明示した知識取得', {
      operation: 'assert',
      targetId: belief.id,
      value: {
        type: 'boolean',
        value: true
      }
    });
  for (const e of [source, testimony, belief, knowledge]) {
    e.status = 'confirmed';
    f.p.entities.push(e);
  }
  await seed(page, f.p);
  await openRecord(page, 'event', f.unset.name);
  const fields = page.locator('[data-field="participants"]');
  await expect(fields.locator('.participant-row')).toHaveCount(0);
  for (const [i, person, role] of [[1, f.a, 'actor'], [2, f.b, 'witness']]) {
    await fields.getByRole('button', {
      name: '参加者を追加',
      exact: true
    }).click();
    await fields.getByLabel('参加者' + i, {
      exact: true
    }).selectOption(person.id);
    await fields.getByLabel('参加者' + i + 'の役割', {
      exact: true
    }).selectOption(role);
  }
  await page.locator('[data-field="authorNotes"] textarea[data-rich-text-editor]').fill('原B08 当事者と目撃者の作者メモ😀');
  await saveEditor(page);
  for (const person of [f.a, f.b]) {
    await openRecord(page, 'character', person.name);
    await expect(page.locator('.references-section').getByRole('button', {
      name: new RegExp('^' + f.unset.name)
    })).toBeVisible();
    await page.locator('.references-section').getByRole('button', {
      name: new RegExp('^' + f.unset.name)
    }).click();
    await expect(page.locator('.detail-heading')).toContainText(f.unset.name);
    await expect(page.getByLabel('参加者1の役割', {
      exact: true
    })).toHaveValue('actor');
    await expect(page.getByLabel('参加者2の役割', {
      exact: true
    })).toHaveValue('witness');
  }
  for (const role of ['mentioned', 'informed']) {
    await page.getByLabel('参加者2の役割', {
      exact: true
    }).selectOption(role);
    await saveEditor(page);
    await expect(page.getByLabel('参加者1の役割', {
      exact: true
    })).toHaveValue('actor');
  }
  const beforeExplicit = await backup(page);
  expect(beforeExplicit.parsed.project.entities.filter(e => e.kind === 'assertion' || e.kind === 'effect')).toEqual(f.p.entities.filter(e => e.kind === 'assertion' || e.kind === 'effect'));
  expect((_beforeExplicit$parse = beforeExplicit.parsed.project.entities.find(e => e.id === f.unset.id)) === null || _beforeExplicit$parse === void 0 ? void 0 : _beforeExplicit$parse.data).toMatchObject({
    participants: [{
      characterId: f.a.id,
      role: 'actor'
    }, {
      characterId: f.b.id,
      role: 'informed'
    }]
  });
  await openRecord(page, 'event', f.unset.name);
  await editData(page, data => {
    data.participants = [{
      characterId: f.a.id,
      role: 'actor'
    }, {
      characterId: f.b.id,
      role: 'custom',
      evidenceIds: [testimony.id]
    }];
  });
  await saveEditor(page);
  const heard = await backup(page);
  expect((_heard$parsed$project = heard.parsed.project.entities.find(e => e.id === f.unset.id)) === null || _heard$parsed$project === void 0 ? void 0 : _heard$parsed$project.data).toMatchObject({
    participants: [{
      characterId: f.a.id,
      role: 'actor'
    }, {
      characterId: f.b.id,
      role: 'custom',
      evidenceIds: [testimony.id]
    }]
  });
  await openRecord(page, 'event', f.unset.name);
  await editData(page, data => {
    data.participants = [{
      characterId: f.a.id,
      role: 'actor'
    }, {
      characterId: f.b.id,
      role: 'informed',
      evidenceIds: [source.id],
      knowledgeEffectIds: [knowledge.id]
    }];
  });
  await saveEditor(page);
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page),
    saved = cold.parsed.project.entities.find(e => e.id === f.unset.id);
  expect(saved.kind === 'event' && saved.data.participants).toEqual([{
    characterId: f.a.id,
    role: 'actor'
  }, {
    characterId: f.b.id,
    role: 'informed',
    evidenceIds: [source.id],
    knowledgeEffectIds: [knowledge.id]
  }]);
  expect(cold.parsed.project.entities.filter(e => e.kind === 'assertion' || e.kind === 'effect')).toEqual(f.p.entities.filter(e => e.kind === 'assertion' || e.kind === 'effect'));
  await evidence(info, 'B08-original-clauses', {
    given: {
      event: f.unset.id,
      initialParticipants: 0
    },
    when: {
      people: [f.a.id, f.b.id],
      differentRolesInitially: ['actor', 'witness'],
      memoSaved: true
    },
    then: {
      sameEventFromBothPersonReverseReferences: true
    },
    negative: {
      actorWitnessMentionedInformedDistinctStoredRoles: true,
      heardTestimonyAsCustomEvidence: testimony.id,
      explicitKnowledgeEffectID: knowledge.id,
      roleAloneAddsNoKnowledgeEvidenceOrEffect: true,
      noAutomaticKnowledgeAssertionOrEffect: true,
      explicitEvidenceLayer: 'ordinary advanced typed JSON fields, while normal participant role selector remains separate'
    },
    coldArchiveSHA: digest(cold.bytes)
  });
});
test('AT-F03 original one scene in romance/war lanes: ordinary edit shares body, remove one thread preserves body and actual participation; cold', async ({
  page,
  browser
}, info) => {
  var _cold$parsed$project$2, _cold$parsed$project$3, _restored$parsed$proj2;
  test.setTimeout(180000);
  const f = await originalFundamentalsFixture();
  const oldSceneData = structuredClone(f.pin.content.entities.find(e => e.id === f.scene.id).data);
  const unassigned = f.p.entities.find(e => e.id === f.scene.id);
  if (unassigned.kind !== 'scene') throw Error('scene fixture kind');
  unassigned.data.threadIds = [];
  await seed(page, f.p);
  await openRecord(page, 'scene', f.scene.name);
  await page.getByRole('tab', {
    name: '詳細',
    exact: true
  }).click();
  for (const group of [f.romance, f.war]) await page.locator('[data-field="threadIds"]').getByLabel('追加する対象', {
    exact: true
  }).selectOption(group.id);
  await saveEditor(page);
  await writing(page);
  await page.getByLabel('物語の並べ方', {
    exact: true
  }).selectOption('thread');
  const romance = page.locator('.story-lane[data-lane-id="' + f.romance.id + '"]'),
    war = page.locator('.story-lane[data-lane-id="' + f.war.id + '"]');
  await romance.locator('.story-scene-link').click();
  await page.getByRole('tab', {
    name: '本文',
    exact: true
  }).click();
  await page.locator('[data-field="body"] textarea[data-rich-text-editor]').fill('原F03 一方から変更した共有本文😀');
  await saveEditor(page);
  await closeDetail(page);
  await war.locator('.story-scene-link').click();
  await page.getByRole('tab', {
    name: '本文',
    exact: true
  }).click();
  await expect(page.locator('[data-field="body"] textarea[data-rich-text-editor]')).toHaveValue('原F03 一方から変更した共有本文😀');
  await closeDetail(page);
  await romance.getByRole('button', {
    name: 'この筋から外す',
    exact: true
  }).click();
  await expect(romance.locator('[data-scene-id="' + f.scene.id + '"]')).toHaveCount(0);
  await expect(war.locator('[data-scene-id="' + f.scene.id + '"]')).toHaveCount(1);
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page),
    scene = cold.parsed.project.entities.find(e => e.id === f.scene.id);
  expect(cold.parsed.project.entities.filter(e => e.kind === 'scene' && e.id === f.scene.id)).toHaveLength(1);
  expect(scene.kind === 'scene' && scene.data.threadIds).toEqual([f.war.id]);
  expect(scene.kind === 'scene' && scene.data.body[0].text).toBe('原F03 一方から変更した共有本文😀');
  expect((_cold$parsed$project$2 = cold.parsed.project.entities.find(e => e.id === f.both.id)) === null || _cold$parsed$project$2 === void 0 ? void 0 : _cold$parsed$project$2.data).toEqual(f.both.data);
  expect((_cold$parsed$project$3 = cold.parsed.project.snapshots.find(s => s.id === f.pin.id)) === null || _cold$parsed$project$3 === void 0 || (_cold$parsed$project$3 = _cold$parsed$project$3.content.entities.find(e => e.id === f.scene.id)) === null || _cold$parsed$project$3 === void 0 ? void 0 : _cold$parsed$project$3.data).toEqual(oldSceneData);
  const restored = await freshRoundtrip(browser, cold.bytes);
  expect((_restored$parsed$proj2 = restored.parsed.project.entities.find(e => e.id === f.scene.id)) === null || _restored$parsed$proj2 === void 0 ? void 0 : _restored$parsed$proj2.data).toEqual(scene.data);
  await evidence(info, 'F03-original-clauses', {
    given: {
      sameScene: f.scene.id,
      twoThreads: [f.romance.id, f.war.id]
    },
    when: {
      registeredTwoThreadsThroughNormalTypedControls: true,
      editedOneCardAndOpenedOther: true
    },
    then: {
      oneSceneIDAndSharedBody: true
    },
    negative: {
      removedOneThreadNotBody: true,
      actualEventParticipantsUnchanged: true
    },
    coldAndOldSnapshotAndFullRestore: true
  });
});
test('AT-F04 original authored scene reason, and AT-B20 changed purpose: register scene/goal evidence, show before/after and reopen it; empty role scene saves without author grading; cold', async ({
  page
}, info) => {
  var _cold$parsed$project$4;
  test.setTimeout(180000);
  const f = await originalFundamentalsFixture();
  await seed(page, f.p);
  await openRecord(page, 'scene', f.scene.name);
  await page.getByRole('tab', {
    name: '詳細',
    exact: true
  }).click();
  await page.getByLabel('視点人物', {
    exact: true
  }).selectOption(f.a.id);
  for (const [key, text] of [['goals', '原F04 鍵を探す'], ['conflicts', '原F04 敵と対立する'], ['results', '原F04 仲間を守る目的へ変わった'], ['newInformation', '原F04 鍵の真実を知った']]) await page.locator('[data-field="' + key + '"] textarea[data-rich-text-editor]').fill(text);
  await saveEditor(page);
  await openRecord(page, 'goal', f.goal.name);
  await page.locator('[data-field="evidenceSceneIds"]').getByLabel('追加する対象', {
    exact: true
  }).selectOption(f.scene.id);
  await saveEditor(page);
  await openRecord(page, 'scene', f.t.name);
  await page.getByRole('tab', {
    name: '本文',
    exact: true
  }).click();
  await page.locator('[data-field="body"] textarea[data-rich-text-editor]').fill('原F04 役割を空のまま保存したT');
  await saveEditor(page);
  await writing(page);
  await page.getByLabel('物語の並べ方', {
    exact: true
  }).selectOption('character');
  const lane = page.locator('.story-lane[data-lane-id="' + f.a.id + '"]');
  for (const text of ['原F04 鍵を探す', '原F04 敵と対立する', '原F04 仲間を守る目的へ変わった', '原F04 鍵の真実を知った']) await expect(lane.locator('.character-arc-record')).toContainText(text);
  await lane.getByRole('button', {
    name: f.goal.name + 'の根拠場面 ' + f.scene.name + 'を開く',
    exact: true
  }).click();
  await expect(page.locator('.detail-heading')).toContainText(f.scene.name);
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page),
    s = cold.parsed.project.entities.find(e => e.id === f.scene.id),
    t = cold.parsed.project.entities.find(e => e.id === f.t.id);
  expect(s.kind === 'scene' && s.data.povId).toBe(f.a.id);
  for (const key of ['goals', 'conflicts', 'results', 'newInformation']) expect(t.kind === 'scene' && t.data[key]).toEqual([]);
  expect(t.status).toBe('confirmed');
  expect((_cold$parsed$project$4 = cold.parsed.project.entities.find(e => e.id === f.goal.id)) === null || _cold$parsed$project$4 === void 0 ? void 0 : _cold$parsed$project$4.data).toMatchObject({
    evidenceSceneIds: [f.scene.id]
  });
  await evidence(info, 'F04-and-B20-original-clauses', {
    F04: {
      given: {
        searchingCharacter: f.a.id,
        S: f.scene.id,
        emptyRoleT: f.t.id
      },
      when: {
        povAndGoalConflictResultInformationRegistered: true,
        TEmptyRolesSaved: true
      },
      then: {
        authoredReasonAndChangeVisible: true
      },
      negative: {
        emptyRoleAllowed: true,
        noAutomaticCorrectnessGrade: true
      }
    },
    B20: {
      given: {
        changingPurposeCharacter: f.a.id
      },
      when: {
        evidenceSceneRegistered: f.scene.id
      },
      then: {
        beforeAfterAndEvidenceNavigation: true
      },
      negative: {
        emptyRoleTStillSaved: true
      }
    },
    coldArchiveSHA: digest(cold.bytes)
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0Iiwic2VlZCIsIm5hdiIsImJhY2t1cCIsImR1cmFibGUiLCJkaWdlc3QiLCJldmlkZW5jZSIsIm9wZW5SZWNvcmQiLCJzYXZlRWRpdG9yIiwiZWRpdERhdGEiLCJmcmVzaFJvdW5kdHJpcCIsIm9yaWdpbmFsRnVuZGFtZW50YWxzRml4dHVyZSIsImNyZWF0ZUVudGl0eSIsInRpbWVsaW5lIiwicGFnZSIsImdldEJ5Um9sZSIsIm5hbWUiLCJleGFjdCIsImNsaWNrIiwid3JpdGluZyIsImNsb3NlRGV0YWlsIiwiY2xvc2UiLCJpc1Zpc2libGUiLCJicm93c2VyIiwiaW5mbyIsIl9jb2xkJHBhcnNlZCRwcm9qZWN0JCIsIl9yZXN0b3JlZCRwYXJzZWQkcHJvaiIsInNldFRpbWVvdXQiLCJmIiwicCIsImJlZm9yZSIsImxvY2F0b3IiLCJjb21tb24iLCJpZCIsInRvSGF2ZVZhbHVlIiwiZGF0YSIsInN1bW1hcnkiLCJ0ZXh0IiwidG9FcXVhbCIsImJvdGgiLCJmaWxsIiwicGVyc29uIiwiYSIsImIiLCJsYW5lIiwiZzEiLCJyZWxvYWQiLCJ0b0JlVmlzaWJsZSIsImNvbGQiLCJwYXJzZWQiLCJwcm9qZWN0IiwiZW50aXRpZXMiLCJmaW5kIiwiZSIsImtpbmQiLCJwYXJ0aWNpcGFudHMiLCJmaWx0ZXIiLCJ0b0hhdmVMZW5ndGgiLCJzbmFwc2hvdHMiLCJzIiwicGluIiwiY29udGVudEhhc2giLCJ0b0JlIiwicmVzdG9yZWQiLCJieXRlcyIsImdpdmVuIiwidHdvUGVyc29uRXZlbnQiLCJ3aGVuIiwiZWRpdGVkRnJvbUNvbW1vbkxhbmUiLCJ0aGVuIiwic2FtZUV2ZW50SURzIiwicmVvcGVuZWRGcm9tQm90aFBlcnNvbkxhbmVzIiwiY29sZFNhbWVCb2R5IiwibmVnYXRpdmUiLCJjb21tb25QYXJ0aWNpcGF0aW9uVW5jaGFuZ2VkIiwibm9Bc3NlcnRpb25zT3JLbm93bGVkZ2VFZmZlY3RzQWRkZWQiLCJuYXRpdmVCZWZvcmVWaWV3U0hBIiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbXBsZXRlQXJjaGl2ZVNIQSIsInBoeXNpY2FsIiwiX3AkZW50aXRpZXMkZmluZCIsIl9wJGVudGl0aWVzJGZpbmQyIiwiX3AkZW50aXRpZXMkZmluZDMiLCJtb2RhbCIsInJvdyIsImhhcyIsImdldEJ5VGV4dCIsImcyIiwiZmlyc3QiLCJ0b0NvbnRhaW5UZXh0IiwicmVvcmRlcmVkIiwic3RvcmUiLCJvcmRlcmVkIiwidW5zZXQiLCJjIiwiaGFzVGV4dCIsInRvSGF2ZUNvdW50IiwiZGVsZXRlZEF0IiwidG9CZVRydXRoeSIsImdyb3VwcyIsImZvbGRlZE9uZSIsInJlb3JkZXJlZEV4cGxpY2l0bHkiLCJzYW1lUGVyc29uQm9kaWVzQW5kSURzIiwicmVtYWluaW5nTWVtYmVyc2hpcEFuZEFsbEV2ZW50SURzVW5jaGFuZ2VkIiwiaW1wYWN0U2hvd25CZWZvcmVBcmNoaXZlIiwicGVyc29uQW5kRXZlbnRzTm90Q2FzY2FkZURlbGV0ZWQiLCJjb2xkQXJjaGl2ZVNIQSIsImdldEJ5TGFiZWwiLCJzZWxlY3RPcHRpb24iLCJyZWxhdGlvbiIsInJlbGF0aW9ucyIsInIiLCJmcm9tSWQiLCJ0b0lkIiwiYmVmb3JlSW52YWxpZCIsInRhcmdldCIsIm1pc3NpbmciLCJldmFsdWF0ZSIsInNlbGVjdCIsIm8iLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJ2YWx1ZSIsImFwcGVuZCIsInRvTWF0Y2hPYmplY3QiLCJyZWxhdGlvblR5cGUiLCJ0d29FdmVudHMiLCJ0YXBTb3VyY2VBbmRUYXJnZXQiLCJ0eXBlZE1lYW5pbmciLCJyZWxhdGlvbklEIiwicmVvcGVuZWRBbmRFZGl0ZWRGcm9tVGltZWxpbmVSZWxhdGlvbkxpc3QiLCJjb2xkTWVhbmluZyIsImVtcHR5VGFyZ2V0UmVqZWN0ZWRXaXRoUmVhc29uIiwibm9uZXhpc3RlbnRVVUlEIiwibm9uZXhpc3RlbnRVVUlEUmVqZWN0ZWRXaXRoUmVhc29uQW5kSW5wdXRSZXRhaW5lZCIsIndyb25nS2luZFJlamVjdGVkV2l0aFJlYXNvbiIsImNhbm9uaWNhbE5hdGl2ZVJvd3NVbmNoYW5nZWQiLCJ3cm9uZ0tpbmRTdWJtaXNzaW9uTGF5ZXIiLCJfYmVmb3JlRXhwbGljaXQkcGFyc2UiLCJfaGVhcmQkcGFyc2VkJHByb2plY3QiLCJzb3VyY2UiLCJwcm9qZWN0SWQiLCJzb3VyY2VUeXBlIiwiZXhjZXJwdExvY2F0aW9uIiwidGVzdGltb255Iiwic3ViamVjdElkIiwicGxhY2UiLCJwcmVkaWNhdGUiLCJ0eXBlIiwidHJ1dGhLaW5kIiwiaG9sZGVySWQiLCJzb3VyY2VJZHMiLCJiZWxpZWYiLCJrbm93bGVkZ2UiLCJvcGVyYXRpb24iLCJ0YXJnZXRJZCIsInN0YXR1cyIsInB1c2giLCJmaWVsZHMiLCJpIiwicm9sZSIsIlJlZ0V4cCIsImJlZm9yZUV4cGxpY2l0IiwiY2hhcmFjdGVySWQiLCJldmlkZW5jZUlkcyIsImhlYXJkIiwia25vd2xlZGdlRWZmZWN0SWRzIiwic2F2ZWQiLCJldmVudCIsImluaXRpYWxQYXJ0aWNpcGFudHMiLCJwZW9wbGUiLCJkaWZmZXJlbnRSb2xlc0luaXRpYWxseSIsIm1lbW9TYXZlZCIsInNhbWVFdmVudEZyb21Cb3RoUGVyc29uUmV2ZXJzZVJlZmVyZW5jZXMiLCJhY3RvcldpdG5lc3NNZW50aW9uZWRJbmZvcm1lZERpc3RpbmN0U3RvcmVkUm9sZXMiLCJoZWFyZFRlc3RpbW9ueUFzQ3VzdG9tRXZpZGVuY2UiLCJleHBsaWNpdEtub3dsZWRnZUVmZmVjdElEIiwicm9sZUFsb25lQWRkc05vS25vd2xlZGdlRXZpZGVuY2VPckVmZmVjdCIsIm5vQXV0b21hdGljS25vd2xlZGdlQXNzZXJ0aW9uT3JFZmZlY3QiLCJleHBsaWNpdEV2aWRlbmNlTGF5ZXIiLCJfY29sZCRwYXJzZWQkcHJvamVjdCQyIiwiX2NvbGQkcGFyc2VkJHByb2plY3QkMyIsIl9yZXN0b3JlZCRwYXJzZWQkcHJvajIiLCJvbGRTY2VuZURhdGEiLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJjb250ZW50Iiwic2NlbmUiLCJ1bmFzc2lnbmVkIiwiRXJyb3IiLCJ0aHJlYWRJZHMiLCJncm91cCIsInJvbWFuY2UiLCJ3YXIiLCJib2R5Iiwic2FtZVNjZW5lIiwidHdvVGhyZWFkcyIsInJlZ2lzdGVyZWRUd29UaHJlYWRzVGhyb3VnaE5vcm1hbFR5cGVkQ29udHJvbHMiLCJlZGl0ZWRPbmVDYXJkQW5kT3BlbmVkT3RoZXIiLCJvbmVTY2VuZUlEQW5kU2hhcmVkQm9keSIsInJlbW92ZWRPbmVUaHJlYWROb3RCb2R5IiwiYWN0dWFsRXZlbnRQYXJ0aWNpcGFudHNVbmNoYW5nZWQiLCJjb2xkQW5kT2xkU25hcHNob3RBbmRGdWxsUmVzdG9yZSIsIl9jb2xkJHBhcnNlZCRwcm9qZWN0JDQiLCJrZXkiLCJnb2FsIiwidCIsInBvdklkIiwiZXZpZGVuY2VTY2VuZUlkcyIsIkYwNCIsInNlYXJjaGluZ0NoYXJhY3RlciIsIlMiLCJlbXB0eVJvbGVUIiwicG92QW5kR29hbENvbmZsaWN0UmVzdWx0SW5mb3JtYXRpb25SZWdpc3RlcmVkIiwiVEVtcHR5Um9sZXNTYXZlZCIsImF1dGhvcmVkUmVhc29uQW5kQ2hhbmdlVmlzaWJsZSIsImVtcHR5Um9sZUFsbG93ZWQiLCJub0F1dG9tYXRpY0NvcnJlY3RuZXNzR3JhZGUiLCJCMjAiLCJjaGFuZ2luZ1B1cnBvc2VDaGFyYWN0ZXIiLCJldmlkZW5jZVNjZW5lUmVnaXN0ZXJlZCIsImJlZm9yZUFmdGVyQW5kRXZpZGVuY2VOYXZpZ2F0aW9uIiwiZW1wdHlSb2xlVFN0aWxsU2F2ZWQiXSwic291cmNlcyI6WyJyZW1haW5pbmctb3JpZ2luYWwtZnVuZGFtZW50YWxzLnNwZWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt0ZXN0LGV4cGVjdCx0eXBlIFBhZ2V9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuaW1wb3J0IHtzZWVkLG5hdixiYWNrdXAsZHVyYWJsZSxkaWdlc3QsZXZpZGVuY2V9IGZyb20gJy4vY29tbW9uJztcbmltcG9ydCB7b3BlblJlY29yZCxzYXZlRWRpdG9yLGVkaXREYXRhLGZyZXNoUm91bmR0cmlwfSBmcm9tICcuL2V4dGVuZGVkLXN1cHBvcnQnO1xuaW1wb3J0IHtvcmlnaW5hbEZ1bmRhbWVudGFsc0ZpeHR1cmV9IGZyb20gJy4vcmVtYWluaW5nLW9yaWdpbmFsLWZ1bmRhbWVudGFscy1maXh0dXJlcyc7XG5pbXBvcnQge2NyZWF0ZUVudGl0eX0gZnJvbSAnLi4vY2FuZGlkYXRlL3NyYy9kb21haW4vbW9kZWwnO1xuXG5hc3luYyBmdW5jdGlvbiB0aW1lbGluZShwYWdlOlBhZ2Upe2F3YWl0IG5hdihwYWdlLC9e5bm06KGoLyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+S4lueVjOWGheW5tOihqCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7fVxuYXN5bmMgZnVuY3Rpb24gd3JpdGluZyhwYWdlOlBhZ2Upe2F3YWl0IG5hdihwYWdlLC9e5qeL5oiQLyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+eroOODu+acrOaWhycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7fVxuYXN5bmMgZnVuY3Rpb24gY2xvc2VEZXRhaWwocGFnZTpQYWdlKXtjb25zdCBjbG9zZT1wYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon6Kmz57Sw44KS6ZaJ44GY44KLJyxleGFjdDp0cnVlfSk7aWYoYXdhaXQgY2xvc2UuaXNWaXNpYmxlKCkpYXdhaXQgY2xvc2UuY2xpY2soKTt9XG5cbnRlc3QoJ0FULUIwMiBvcmlnaW5hbCBjb21tb24vdHdvLXBlcnNvbiBldmVudHM6IGVkaXQgZnJvbSBjb21tb24gbGFuZSwgcmVvcGVuIGlkZW50aWNhbCBJRCBpbiBlYWNoIHBlcnNvbiBsYW5lLCBubyBpbXBsaWNpdCBwYXJ0aWNpcGF0aW9uL2tub3dsZWRnZTsgY29sZCBhbmQgY29tcGxldGUgcm91bmR0cmlwJyxhc3luYyh7cGFnZSxicm93c2VyfSxpbmZvKT0+e1xuIHRlc3Quc2V0VGltZW91dCgxODBfMDAwKTtjb25zdCBmPWF3YWl0IG9yaWdpbmFsRnVuZGFtZW50YWxzRml4dHVyZSgpO2F3YWl0IHNlZWQocGFnZSxmLnApO2F3YWl0IHRpbWVsaW5lKHBhZ2UpO1xuIGNvbnN0IGJlZm9yZT1hd2FpdCBkdXJhYmxlKHBhZ2UpO2F3YWl0IHBhZ2UubG9jYXRvcignW2RhdGEtbGFuZS1pZD1cImNvbW1vblwiXSBbZGF0YS1ldmVudC1pZD1cIicrZi5jb21tb24uaWQrJ1wiXScpLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignW2RhdGEtZmllbGQ9XCJzdW1tYXJ5XCJdIHRleHRhcmVhW2RhdGEtcmljaC10ZXh0LWVkaXRvcl0nKSkudG9IYXZlVmFsdWUoZi5jb21tb24uZGF0YS5zdW1tYXJ5WzBdLnRleHQpO2F3YWl0IGNsb3NlRGV0YWlsKHBhZ2UpO1xuIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKGJlZm9yZSk7XG4gYXdhaXQgcGFnZS5sb2NhdG9yKCdbZGF0YS1sYW5lLWlkPVwiY29tbW9uXCJdIFtkYXRhLWV2ZW50LWlkPVwiJytmLmJvdGguaWQrJ1wiXScpLmNsaWNrKCk7YXdhaXQgcGFnZS5sb2NhdG9yKCdbZGF0YS1maWVsZD1cInN1bW1hcnlcIl0gdGV4dGFyZWFbZGF0YS1yaWNoLXRleHQtZWRpdG9yXScpLmZpbGwoJ+WOn0IwMiDlhbHpgJrjgYvjgonlpInmm7TjgZfjgZ/lkIzkuIDmnKzmlofwn5iAJyk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTthd2FpdCBjbG9zZURldGFpbChwYWdlKTtcbiBmb3IoY29uc3QgcGVyc29uIG9mIFtmLmEsZi5iXSl7XG4gIGNvbnN0IGxhbmU9cGFnZS5sb2NhdG9yKCdbZGF0YS1sYW5lLWlkPVwibWVtYmVyOicrZi5nMS5pZCsnOicrcGVyc29uLmlkKydcIl0nKTthd2FpdCBsYW5lLmxvY2F0b3IoJ1tkYXRhLWV2ZW50LWlkPVwiJytmLmJvdGguaWQrJ1wiXScpLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignW2RhdGEtZmllbGQ9XCJzdW1tYXJ5XCJdIHRleHRhcmVhW2RhdGEtcmljaC10ZXh0LWVkaXRvcl0nKSkudG9IYXZlVmFsdWUoJ+WOn0IwMiDlhbHpgJrjgYvjgonlpInmm7TjgZfjgZ/lkIzkuIDmnKzmlofwn5iAJyk7YXdhaXQgY2xvc2VEZXRhaWwocGFnZSk7XG4gfVxuIGF3YWl0IHBhZ2UucmVsb2FkKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmFwcC1zaGVsbCcpKS50b0JlVmlzaWJsZSgpO2NvbnN0IGNvbGQ9YXdhaXQgYmFja3VwKHBhZ2UpLGNvbW1vbj1jb2xkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuY29tbW9uLmlkKSEsYm90aD1jb2xkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuYm90aC5pZCkhO1xuIGV4cGVjdChjb21tb24ua2luZD09PSdldmVudCcmJmNvbW1vbi5kYXRhLnBhcnRpY2lwYW50cykudG9FcXVhbChbXSk7ZXhwZWN0KGJvdGgua2luZD09PSdldmVudCcmJmJvdGguZGF0YS5wYXJ0aWNpcGFudHMpLnRvRXF1YWwoZi5ib3RoLmRhdGEucGFydGljaXBhbnRzKTtleHBlY3QoY29sZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maWx0ZXIoZT0+ZS5raW5kPT09J2Fzc2VydGlvbid8fGUua2luZD09PSdlZmZlY3QnKSkudG9IYXZlTGVuZ3RoKDApO2V4cGVjdChjb2xkLnBhcnNlZC5wcm9qZWN0LnNuYXBzaG90cy5maW5kKHM9PnMuaWQ9PT1mLnBpbi5pZCk/LmNvbnRlbnRIYXNoKS50b0JlKGYucGluLmNvbnRlbnRIYXNoKTtcbiBjb25zdCByZXN0b3JlZD1hd2FpdCBmcmVzaFJvdW5kdHJpcChicm93c2VyLGNvbGQuYnl0ZXMpO2V4cGVjdChyZXN0b3JlZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLmJvdGguaWQpPy5kYXRhKS50b0VxdWFsKGJvdGguZGF0YSk7XG4gYXdhaXQgZXZpZGVuY2UoaW5mbywnQjAyLW9yaWdpbmFsLWNsYXVzZXMnLHtnaXZlbjp7Y29tbW9uOmYuY29tbW9uLmlkLHR3b1BlcnNvbkV2ZW50OmYuYm90aC5pZH0sd2hlbjp7ZWRpdGVkRnJvbUNvbW1vbkxhbmU6dHJ1ZX0sdGhlbjp7c2FtZUV2ZW50SURzOltmLmJvdGguaWRdLHJlb3BlbmVkRnJvbUJvdGhQZXJzb25MYW5lczp0cnVlLGNvbGRTYW1lQm9keTp0cnVlfSxuZWdhdGl2ZTp7Y29tbW9uUGFydGljaXBhdGlvblVuY2hhbmdlZDp0cnVlLG5vQXNzZXJ0aW9uc09yS25vd2xlZGdlRWZmZWN0c0FkZGVkOnRydWV9LG5hdGl2ZUJlZm9yZVZpZXdTSEE6ZGlnZXN0KEpTT04uc3RyaW5naWZ5KGJlZm9yZSkpLGNvbXBsZXRlQXJjaGl2ZVNIQTpkaWdlc3QoY29sZC5ieXRlcykscGh5c2ljYWw6J25vdF9ydW4nfSk7XG59KTtcblxudGVzdCgnQVQtQjAzIG9yaWdpbmFsIHNhbWUgcGVyc29uIGluIHR3byBncm91cHM6IGNvbGxhcHNlL3Jlb3JkZXIgcHJlc2VydmVzIHBlcnNvbi9tZW1iZXIvZXZlbnQgSURzOyBleHBsaWNpdCBhcmNoaXZlIGltcGFjdCBrZWVwcyBib2RpZXM7IGNvbGQnLGFzeW5jKHtwYWdlfSxpbmZvKT0+e1xuIHRlc3Quc2V0VGltZW91dCgxODBfMDAwKTtjb25zdCBmPWF3YWl0IG9yaWdpbmFsRnVuZGFtZW50YWxzRml4dHVyZSgpO2F3YWl0IHNlZWQocGFnZSxmLnApO2F3YWl0IHRpbWVsaW5lKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifjgrDjg6vjg7zjg5fjg7vkurrnianjg6zjg7zjg7MnLGV4YWN0OnRydWV9KS5jbGljaygpO1xuIGNvbnN0IG1vZGFsPXBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnLHtuYW1lOifjgrDjg6vjg7zjg5fjg7vkurrnianjg6zjg7zjg7PjgpLnt6jpm4YnLGV4YWN0OnRydWV9KSxyb3c9bW9kYWwubG9jYXRvcignLnRpbWVsaW5lLWdyb3VwLWVkaXRvci1yb3cnKS5maWx0ZXIoe2hhczpwYWdlLmdldEJ5VGV4dChmLmcxLm5hbWUse2V4YWN0OnRydWV9KX0pO2NvbnN0IGJlZm9yZT1hd2FpdCBkdXJhYmxlKHBhZ2UpO1xuIGF3YWl0IHJvdy5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+aKmOOCiuOBn+OBn+OCgCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHJvdy5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+WxlemWiycsZXhhY3Q6dHJ1ZX0pKS50b0JlVmlzaWJsZSgpO2V4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKGJlZm9yZSk7XG4gYXdhaXQgbW9kYWwuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuZzIubmFtZSsn44KS5YmN44G4JyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QobW9kYWwubG9jYXRvcignLnRpbWVsaW5lLWdyb3VwLWVkaXRvci1yb3cnKS5maXJzdCgpKS50b0NvbnRhaW5UZXh0KGYuZzIubmFtZSk7Y29uc3QgcmVvcmRlcmVkPWF3YWl0IGR1cmFibGUocGFnZSk7Zm9yKGNvbnN0IHN0b3JlIG9mIFsnZW50aXRpZXMnLCdyZWxhdGlvbnMnLCdibG9ja3MnLCdzbmFwc2hvdHMnLCdhc3NldHMnLCd3b3JsZHMnXSlleHBlY3QocmVvcmRlcmVkW3N0b3JlXSkudG9FcXVhbChiZWZvcmVbc3RvcmVdKTthd2FpdCBtb2RhbC5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+mWieOBmOOCiycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7Y29uc3Qgb3JkZXJlZD1hd2FpdCBiYWNrdXAocGFnZSk7Zm9yKGNvbnN0IGUgb2YgW2YuYSxmLmIsZi5nMSxmLmcyLGYuY29tbW9uLGYuYm90aCxmLnVuc2V0XSlleHBlY3Qob3JkZXJlZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGM9PmMuaWQ9PT1lLmlkKSkudG9FcXVhbChlKTthd2FpdCB0aW1lbGluZShwYWdlKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon44Kw44Or44O844OX44O75Lq654mp44Os44O844OzJyxleGFjdDp0cnVlfSkuY2xpY2soKTtcbiBhd2FpdCByb3cuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifmlLnlkI3jg7vpmo7lsaTjg7vkurrnianjgpLnt6jpm4YnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IG1vZGFsLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon44Kw44Or44O844OX44KS5aSW44GZ5YmN44Gr56K66KqNJyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QobW9kYWwubG9jYXRvcignLnRpbWVsaW5lLWRlbGV0ZS1pbXBhY3QnKSkudG9Db250YWluVGV4dCgn5Lq654mp44Go5Ye65p2l5LqL44Gu5pys5L2T44O7SUTjga/kv53mjIHjgZfjgb7jgZknKTthd2FpdCBtb2RhbC5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+W9semfv+OCkueiuuiqjeOBl+OBpuOCsOODq+ODvOODl+OCkuWkluOBmScsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KG1vZGFsLmxvY2F0b3IoJy50aW1lbGluZS1ncm91cC1lZGl0b3Itcm93JykuZmlsdGVyKHtoYXNUZXh0OmYuZzEubmFtZX0pKS50b0hhdmVDb3VudCgwKTthd2FpdCBtb2RhbC5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+mWieOBmOOCiycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gYXdhaXQgcGFnZS5yZWxvYWQoKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuYXBwLXNoZWxsJykpLnRvQmVWaXNpYmxlKCk7Y29uc3QgY29sZD1hd2FpdCBiYWNrdXAocGFnZSkscD1jb2xkLnBhcnNlZC5wcm9qZWN0O1xuIGV4cGVjdChwLmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuZzEuaWQpPy5kZWxldGVkQXQpLnRvQmVUcnV0aHkoKTtleHBlY3QocC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLmcxLmlkKT8uZGF0YSkudG9FcXVhbChmLmcxLmRhdGEpO2V4cGVjdChwLmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuZzIuaWQpPy5kYXRhKS50b0VxdWFsKGYuZzIuZGF0YSk7XG4gZm9yKGNvbnN0IGUgb2YgW2YuYSxmLmIsZi5jb21tb24sZi5ib3RoLGYudW5zZXRdKWV4cGVjdChwLmVudGl0aWVzLmZpbmQoYz0+Yy5pZD09PWUuaWQpKS50b0VxdWFsKGUpO1xuIGF3YWl0IGV2aWRlbmNlKGluZm8sJ0IwMy1vcmlnaW5hbC1jbGF1c2VzJyx7Z2l2ZW46e3BlcnNvbjpmLmEuaWQsZ3JvdXBzOltmLmcxLmlkLGYuZzIuaWRdfSx3aGVuOntmb2xkZWRPbmU6dHJ1ZSxyZW9yZGVyZWRFeHBsaWNpdGx5OnRydWV9LHRoZW46e3NhbWVQZXJzb25Cb2RpZXNBbmRJRHM6dHJ1ZSxyZW1haW5pbmdNZW1iZXJzaGlwQW5kQWxsRXZlbnRJRHNVbmNoYW5nZWQ6dHJ1ZX0sbmVnYXRpdmU6e2ltcGFjdFNob3duQmVmb3JlQXJjaGl2ZTp0cnVlLHBlcnNvbkFuZEV2ZW50c05vdENhc2NhZGVEZWxldGVkOnRydWV9LGNvbGRBcmNoaXZlU0hBOmRpZ2VzdChjb2xkLmJ5dGVzKX0pO1xufSk7XG5cbnRlc3QoJ0FULUIwNyBvcmlnaW5hbCB0YXAgc291cmNlL3RhcmdldCBjcmVhdGVzIGEgdHlwZWQgZXZlbnQgcmVsYXRpb24sIHRpbWVsaW5lL2xpc3QgZWRpdCBzYW1lIElEOyBlbXB0eSBvciB3cm9uZy1raW5kIHRhcmdldHMgc2FmZWx5IHJlZnVzZWQ7IGNvbGQnLGFzeW5jKHtwYWdlfSxpbmZvKT0+e1xuIHRlc3Quc2V0VGltZW91dCgxODBfMDAwKTtjb25zdCBmPWF3YWl0IG9yaWdpbmFsRnVuZGFtZW50YWxzRml4dHVyZSgpO2F3YWl0IHNlZWQocGFnZSxmLnApO2F3YWl0IHRpbWVsaW5lKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOiflp4vngrkg4oaSIOe1gueCueOCkuOCv+ODg+ODl+OBp+e1kOOBticsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcGFnZS5sb2NhdG9yKCdbZGF0YS1sYW5lLWlkPVwiY29tbW9uXCJdIFtkYXRhLWV2ZW50LWlkPVwiJytmLmNvbW1vbi5pZCsnXCJdJykuY2xpY2soKTthd2FpdCBwYWdlLmxvY2F0b3IoJ1tkYXRhLWxhbmUtaWQ9XCJjb21tb25cIl0gW2RhdGEtZXZlbnQtaWQ9XCInK2YuYm90aC5pZCsnXCJdJykuY2xpY2soKTtcbiBjb25zdCBtb2RhbD1wYWdlLmdldEJ5Um9sZSgnZGlhbG9nJyx7bmFtZTon5bm06KGo44Gu6Zai5L+C44KS57eo6ZuGJyxleGFjdDp0cnVlfSk7YXdhaXQgZXhwZWN0KG1vZGFsLmdldEJ5TGFiZWwoJ+W5tOihqOOBrumWouS/guOBruWni+eCuScse2V4YWN0OnRydWV9KSkudG9IYXZlVmFsdWUoZi5jb21tb24uaWQpO2F3YWl0IGV4cGVjdChtb2RhbC5nZXRCeUxhYmVsKCflubTooajjga7plqLkv4Ljga7ntYLngrknLHtleGFjdDp0cnVlfSkpLnRvSGF2ZVZhbHVlKGYuYm90aC5pZCk7YXdhaXQgbW9kYWwuZ2V0QnlMYWJlbCgn5bm06KGo44Gu6Zai5L+C44Gu56iu6aGeJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbignY2F1c2VzJyk7YXdhaXQgbW9kYWwuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifplqLkv4LjgpLkv53lrZgnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChtb2RhbCkudG9IYXZlQ291bnQoMCk7XG4gY29uc3QgZmlyc3Q9YXdhaXQgYmFja3VwKHBhZ2UpLHJlbGF0aW9uPWZpcnN0LnBhcnNlZC5wcm9qZWN0LnJlbGF0aW9ucy5maW5kKHI9PnIuZnJvbUlkPT09Zi5jb21tb24uaWQmJnIudG9JZD09PWYuYm90aC5pZCkhO2V4cGVjdChyZWxhdGlvbikudG9CZVRydXRoeSgpO2F3YWl0IHRpbWVsaW5lKHBhZ2UpO2F3YWl0IHBhZ2UubG9jYXRvcignLnRpbWVsaW5lLXJlbGF0aW9uLXJvdyBbZGF0YS1yZWxhdGlvbi1pZD1cIicrcmVsYXRpb24uaWQrJ1wiXScpLmNsaWNrKCk7YXdhaXQgZXhwZWN0KG1vZGFsKS50b0NvbnRhaW5UZXh0KHJlbGF0aW9uLmlkKTtcbiBjb25zdCBiZWZvcmVJbnZhbGlkPWF3YWl0IGR1cmFibGUocGFnZSk7YXdhaXQgbW9kYWwuZ2V0QnlMYWJlbCgn5bm06KGo44Gu6Zai5L+C44Gu57WC54K5Jyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbignJyk7YXdhaXQgbW9kYWwuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifplqLkv4LjgpLkv53lrZgnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChtb2RhbC5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ+WtmOWcqOOBmeOCi+WHuuadpeS6i+OCkuWni+eCueOBqOe1gueCueOBq+mBuOOCk+OBp+OBj+OBoOOBleOBhCcpO2V4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKGJlZm9yZUludmFsaWQpO2F3YWl0IGV4cGVjdChtb2RhbC5nZXRCeUxhYmVsKCflubTooajjga7plqLkv4Ljga7ntYLngrknLHtleGFjdDp0cnVlfSkpLnRvSGF2ZVZhbHVlKCcnKTtcbiAvLyBBIHR5cGVkIGJvdW5kYXJ5IGNhbm5vdCBiZSBlbnRlcmVkIHRocm91Z2ggdGhlIGZpbHRlcmVkIG9yZGluYXJ5IHBpY2tlci5cbiAvLyBTdWJtaXQgaXQgdGhyb3VnaCB0aGF0IHNhbWUgY2hhbmdlIGhhbmRsZXIgYXMgYSBzeW50aGV0aWMgaW52YWxpZCBpbnB1dDtcbiAvLyB0aGUgcGVyc2lzdGVkIHZhbHVlIG11c3Qgc3RpbGwgYmUgcmVmdXNlZCB3aXRoIHRoZSBvcmlnaW5hbCByZWFzb24uXG4gY29uc3QgdGFyZ2V0PW1vZGFsLmdldEJ5TGFiZWwoJ+W5tOihqOOBrumWouS/guOBrue1gueCuScse2V4YWN0OnRydWV9KTtjb25zdCBtaXNzaW5nPSdlZWVlZWVlZS1lZWVlLTRlZWUtOGVlZS1lZWVlZWVlZWVlZWUnO2F3YWl0IHRhcmdldC5ldmFsdWF0ZSgoc2VsZWN0LGlkKT0+e2NvbnN0IG89ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnb3B0aW9uJyk7by52YWx1ZT1pZDtvLnRleHQ9J+WtmOWcqOOBl+OBquOBhOWHuuadpeS6iyc7c2VsZWN0LmFwcGVuZChvKTt9LG1pc3NpbmcpO2F3YWl0IHRhcmdldC5zZWxlY3RPcHRpb24obWlzc2luZyk7YXdhaXQgbW9kYWwuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifplqLkv4LjgpLkv53lrZgnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChtb2RhbC5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ+WtmOWcqOOBmeOCi+WHuuadpeS6i+OCkuWni+eCueOBqOe1gueCueOBq+mBuOOCk+OBp+OBj+OBoOOBleOBhCcpO2F3YWl0IGV4cGVjdCh0YXJnZXQpLnRvSGF2ZVZhbHVlKG1pc3NpbmcpO2V4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKGJlZm9yZUludmFsaWQpO1xuIGF3YWl0IHRhcmdldC5ldmFsdWF0ZSgoc2VsZWN0LGlkKT0+e2NvbnN0IG89ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnb3B0aW9uJyk7by52YWx1ZT1pZDtvLnRleHQ9J+S4jeato+Wei+OBruS6uueJqSc7c2VsZWN0LmFwcGVuZChvKTt9LGYuYS5pZCk7YXdhaXQgdGFyZ2V0LnNlbGVjdE9wdGlvbihmLmEuaWQpO2F3YWl0IG1vZGFsLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon6Zai5L+C44KS5L+d5a2YJyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBleHBlY3QobW9kYWwuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0NvbnRhaW5UZXh0KCflrZjlnKjjgZnjgovlh7rmnaXkuovjgpLlp4vngrnjgajntYLngrnjgavpgbjjgpPjgafjgY/jgaDjgZXjgYQnKTtleHBlY3QoYXdhaXQgZHVyYWJsZShwYWdlKSkudG9FcXVhbChiZWZvcmVJbnZhbGlkKTtcbiBhd2FpdCB0YXJnZXQuc2VsZWN0T3B0aW9uKGYuYm90aC5pZCk7YXdhaXQgbW9kYWwuZ2V0QnlMYWJlbCgn5bm06KGo44Gu6Zai5L+C44Gu56iu6aGeJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbignZXZlbnRfcGF5b2ZmJyk7YXdhaXQgbW9kYWwuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifplqLkv4LjgpLkv53lrZgnLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChtb2RhbCkudG9IYXZlQ291bnQoMCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnRpbWVsaW5lLXJlbGF0aW9uLXJvdyBbZGF0YS1yZWxhdGlvbi1pZD1cIicrcmVsYXRpb24uaWQrJ1wiXScpLmZpbHRlcih7aGFzVGV4dDon5Ye65p2l5LqL44Gu5Zue5Y+OJ30pKS50b0JlVmlzaWJsZSgpO2F3YWl0IHBhZ2UucmVsb2FkKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmFwcC1zaGVsbCcpKS50b0JlVmlzaWJsZSgpO2NvbnN0IGNvbGQ9YXdhaXQgYmFja3VwKHBhZ2UpO2V4cGVjdChjb2xkLnBhcnNlZC5wcm9qZWN0LnJlbGF0aW9ucy5maW5kKHI9PnIuaWQ9PT1yZWxhdGlvbi5pZCkpLnRvTWF0Y2hPYmplY3Qoe2Zyb21JZDpmLmNvbW1vbi5pZCx0b0lkOmYuYm90aC5pZCxyZWxhdGlvblR5cGU6J2V2ZW50X3BheW9mZid9KTtcbiBhd2FpdCBldmlkZW5jZShpbmZvLCdCMDctb3JpZ2luYWwtY2xhdXNlcycse2dpdmVuOnt0d29FdmVudHM6W2YuY29tbW9uLmlkLGYuYm90aC5pZF19LHdoZW46e3RhcFNvdXJjZUFuZFRhcmdldDp0cnVlLHR5cGVkTWVhbmluZzonY2F1c2VzJ30sdGhlbjp7cmVsYXRpb25JRDpyZWxhdGlvbi5pZCxyZW9wZW5lZEFuZEVkaXRlZEZyb21UaW1lbGluZVJlbGF0aW9uTGlzdDp0cnVlLGNvbGRNZWFuaW5nOidldmVudF9wYXlvZmYnfSxuZWdhdGl2ZTp7ZW1wdHlUYXJnZXRSZWplY3RlZFdpdGhSZWFzb246dHJ1ZSxub25leGlzdGVudFVVSUQ6bWlzc2luZyxub25leGlzdGVudFVVSURSZWplY3RlZFdpdGhSZWFzb25BbmRJbnB1dFJldGFpbmVkOnRydWUsd3JvbmdLaW5kUmVqZWN0ZWRXaXRoUmVhc29uOnRydWUsY2Fub25pY2FsTmF0aXZlUm93c1VuY2hhbmdlZDp0cnVlLHdyb25nS2luZFN1Ym1pc3Npb25MYXllcjonRE9NLWludmFsaWQgb3B0aW9uIHRocm91Z2ggb3JkaW5hcnkgdHlwZWQgY2hhbmdlIGhhbmRsZXI7IG5vdCBuYXR1cmFsIHBpY2tlciBhdmFpbGFiaWxpdHknfX0pO1xufSk7XG5cbnRlc3QoJ0FULUIwOCBvcmlnaW5hbCBlbXB0eSBwYXJ0aWNpcGFudHM6IHJlZ2lzdGVyIHR3byBkaWZmZXJlbnQgcm9sZXMgYW5kIG1lbW8sIHJldmVyc2UgcmVmZXJlbmNlcyBzYW1lIGV2ZW50LCByb2xlcyBhbmQga25vd2xlZGdlIHJlbWFpbiBkaXN0aW5jdDsgY29sZCcsYXN5bmMoe3BhZ2V9LGluZm8pPT57XG4gdGVzdC5zZXRUaW1lb3V0KDE4MF8wMDApO2NvbnN0IGY9YXdhaXQgb3JpZ2luYWxGdW5kYW1lbnRhbHNGaXh0dXJlKCk7Y29uc3Qgc291cmNlPWNyZWF0ZUVudGl0eShmLnAucHJvamVjdElkLCdzb3VyY2UnLCfljp9CMDgg5Lyd6IGe44Gu5Ye65omAJyx7c291cmNlVHlwZTond2ViJyxsb2NhdG9yOidodHRwczovL2V4YW1wbGUuaW52YWxpZC9oZWFyc2F5JyxleGNlcnB0TG9jYXRpb246J+ebruaSg+iAheOBi+OCieiBnuOBhOOBn+euh+aJgCd9KSx0ZXN0aW1vbnk9Y3JlYXRlRW50aXR5KGYucC5wcm9qZWN0SWQsJ2Fzc2VydGlvbicsJ+WOn0IwOCDkvJ3ogZ7jga7oqLzoqIAnLHtzdWJqZWN0SWQ6Zi5wbGFjZS5pZCxwcmVkaWNhdGU6J2hlYXJkX2Rvb3Jfb3BlbicsdmFsdWU6e3R5cGU6J2Jvb2xlYW4nLHZhbHVlOnRydWV9LHRydXRoS2luZDondGVzdGltb255Jyxob2xkZXJJZDpmLmIuaWQsc291cmNlSWRzOltzb3VyY2UuaWRdfSksYmVsaWVmPWNyZWF0ZUVudGl0eShmLnAucHJvamVjdElkLCdhc3NlcnRpb24nLCfljp9CMDgg5Lq654mp44Gu6KqN6K2YJyx7c3ViamVjdElkOmYucGxhY2UuaWQscHJlZGljYXRlOidkb29yX29wZW4nLHZhbHVlOnt0eXBlOidib29sZWFuJyx2YWx1ZTp0cnVlfSx0cnV0aEtpbmQ6J2JlbGllZicsaG9sZGVySWQ6Zi5iLmlkLHNvdXJjZUlkczpbc291cmNlLmlkXX0pLGtub3dsZWRnZT1jcmVhdGVFbnRpdHkoZi5wLnByb2plY3RJZCwnZWZmZWN0Jywn5Y6fQjA4IOaYjuekuuOBl+OBn+efpeitmOWPluW+lycse29wZXJhdGlvbjonYXNzZXJ0Jyx0YXJnZXRJZDpiZWxpZWYuaWQsdmFsdWU6e3R5cGU6J2Jvb2xlYW4nLHZhbHVlOnRydWV9fSk7Zm9yKGNvbnN0IGUgb2YgW3NvdXJjZSx0ZXN0aW1vbnksYmVsaWVmLGtub3dsZWRnZV0pe2Uuc3RhdHVzPSdjb25maXJtZWQnO2YucC5lbnRpdGllcy5wdXNoKGUpO31hd2FpdCBzZWVkKHBhZ2UsZi5wKTthd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ2V2ZW50JyxmLnVuc2V0Lm5hbWUpO2NvbnN0IGZpZWxkcz1wYWdlLmxvY2F0b3IoJ1tkYXRhLWZpZWxkPVwicGFydGljaXBhbnRzXCJdJyk7YXdhaXQgZXhwZWN0KGZpZWxkcy5sb2NhdG9yKCcucGFydGljaXBhbnQtcm93JykpLnRvSGF2ZUNvdW50KDApO1xuIGZvcihjb25zdCBbaSxwZXJzb24scm9sZV0gb2YgW1sxLGYuYSwnYWN0b3InXSxbMixmLmIsJ3dpdG5lc3MnXV0gYXMgY29uc3Qpe2F3YWl0IGZpZWxkcy5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+WPguWKoOiAheOCkui/veWKoCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZmllbGRzLmdldEJ5TGFiZWwoJ+WPguWKoOiAhScraSx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbihwZXJzb24uaWQpO2F3YWl0IGZpZWxkcy5nZXRCeUxhYmVsKCflj4LliqDogIUnK2krJ+OBruW9ueWJsicse2V4YWN0OnRydWV9KS5zZWxlY3RPcHRpb24ocm9sZSk7fVxuIGF3YWl0IHBhZ2UubG9jYXRvcignW2RhdGEtZmllbGQ9XCJhdXRob3JOb3Rlc1wiXSB0ZXh0YXJlYVtkYXRhLXJpY2gtdGV4dC1lZGl0b3JdJykuZmlsbCgn5Y6fQjA4IOW9k+S6i+iAheOBqOebruaSg+iAheOBruS9nOiAheODoeODovCfmIAnKTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO1xuIGZvcihjb25zdCBwZXJzb24gb2YgW2YuYSxmLmJdKXthd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ2NoYXJhY3RlcicscGVyc29uLm5hbWUpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWZlcmVuY2VzLXNlY3Rpb24nKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6bmV3IFJlZ0V4cCgnXicrZi51bnNldC5uYW1lKX0pKS50b0JlVmlzaWJsZSgpO2F3YWl0IHBhZ2UubG9jYXRvcignLnJlZmVyZW5jZXMtc2VjdGlvbicpLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpuZXcgUmVnRXhwKCdeJytmLnVuc2V0Lm5hbWUpfSkuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuZGV0YWlsLWhlYWRpbmcnKSkudG9Db250YWluVGV4dChmLnVuc2V0Lm5hbWUpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5TGFiZWwoJ+WPguWKoOiAhTHjga7lvbnlibInLHtleGFjdDp0cnVlfSkpLnRvSGF2ZVZhbHVlKCdhY3RvcicpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5TGFiZWwoJ+WPguWKoOiAhTLjga7lvbnlibInLHtleGFjdDp0cnVlfSkpLnRvSGF2ZVZhbHVlKCd3aXRuZXNzJyk7fVxuIGZvcihjb25zdCByb2xlIG9mIFsnbWVudGlvbmVkJywnaW5mb3JtZWQnXSl7YXdhaXQgcGFnZS5nZXRCeUxhYmVsKCflj4LliqDogIUy44Gu5b255YmyJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbihyb2xlKTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5TGFiZWwoJ+WPguWKoOiAhTHjga7lvbnlibInLHtleGFjdDp0cnVlfSkpLnRvSGF2ZVZhbHVlKCdhY3RvcicpO31cbiBjb25zdCBiZWZvcmVFeHBsaWNpdD1hd2FpdCBiYWNrdXAocGFnZSk7ZXhwZWN0KGJlZm9yZUV4cGxpY2l0LnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbHRlcihlPT5lLmtpbmQ9PT0nYXNzZXJ0aW9uJ3x8ZS5raW5kPT09J2VmZmVjdCcpKS50b0VxdWFsKGYucC5lbnRpdGllcy5maWx0ZXIoZT0+ZS5raW5kPT09J2Fzc2VydGlvbid8fGUua2luZD09PSdlZmZlY3QnKSk7ZXhwZWN0KGJlZm9yZUV4cGxpY2l0LnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYudW5zZXQuaWQpPy5kYXRhKS50b01hdGNoT2JqZWN0KHtwYXJ0aWNpcGFudHM6W3tjaGFyYWN0ZXJJZDpmLmEuaWQscm9sZTonYWN0b3InfSx7Y2hhcmFjdGVySWQ6Zi5iLmlkLHJvbGU6J2luZm9ybWVkJ31dfSk7XG4gYXdhaXQgb3BlblJlY29yZChwYWdlLCdldmVudCcsZi51bnNldC5uYW1lKTthd2FpdCBlZGl0RGF0YShwYWdlLGRhdGE9PntkYXRhLnBhcnRpY2lwYW50cz1be2NoYXJhY3RlcklkOmYuYS5pZCxyb2xlOidhY3Rvcid9LHtjaGFyYWN0ZXJJZDpmLmIuaWQscm9sZTonY3VzdG9tJyxldmlkZW5jZUlkczpbdGVzdGltb255LmlkXX1dO30pO2F3YWl0IHNhdmVFZGl0b3IocGFnZSk7Y29uc3QgaGVhcmQ9YXdhaXQgYmFja3VwKHBhZ2UpO2V4cGVjdChoZWFyZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLnVuc2V0LmlkKT8uZGF0YSkudG9NYXRjaE9iamVjdCh7cGFydGljaXBhbnRzOlt7Y2hhcmFjdGVySWQ6Zi5hLmlkLHJvbGU6J2FjdG9yJ30se2NoYXJhY3RlcklkOmYuYi5pZCxyb2xlOidjdXN0b20nLGV2aWRlbmNlSWRzOlt0ZXN0aW1vbnkuaWRdfV19KTtcbiBhd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ2V2ZW50JyxmLnVuc2V0Lm5hbWUpO2F3YWl0IGVkaXREYXRhKHBhZ2UsZGF0YT0+e2RhdGEucGFydGljaXBhbnRzPVt7Y2hhcmFjdGVySWQ6Zi5hLmlkLHJvbGU6J2FjdG9yJ30se2NoYXJhY3RlcklkOmYuYi5pZCxyb2xlOidpbmZvcm1lZCcsZXZpZGVuY2VJZHM6W3NvdXJjZS5pZF0sa25vd2xlZGdlRWZmZWN0SWRzOltrbm93bGVkZ2UuaWRdfV07fSk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTthd2FpdCBwYWdlLnJlbG9hZCgpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5hcHAtc2hlbGwnKSkudG9CZVZpc2libGUoKTtjb25zdCBjb2xkPWF3YWl0IGJhY2t1cChwYWdlKSxzYXZlZD1jb2xkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYudW5zZXQuaWQpITtleHBlY3Qoc2F2ZWQua2luZD09PSdldmVudCcmJnNhdmVkLmRhdGEucGFydGljaXBhbnRzKS50b0VxdWFsKFt7Y2hhcmFjdGVySWQ6Zi5hLmlkLHJvbGU6J2FjdG9yJ30se2NoYXJhY3RlcklkOmYuYi5pZCxyb2xlOidpbmZvcm1lZCcsZXZpZGVuY2VJZHM6W3NvdXJjZS5pZF0sa25vd2xlZGdlRWZmZWN0SWRzOltrbm93bGVkZ2UuaWRdfV0pO2V4cGVjdChjb2xkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbHRlcihlPT5lLmtpbmQ9PT0nYXNzZXJ0aW9uJ3x8ZS5raW5kPT09J2VmZmVjdCcpKS50b0VxdWFsKGYucC5lbnRpdGllcy5maWx0ZXIoZT0+ZS5raW5kPT09J2Fzc2VydGlvbid8fGUua2luZD09PSdlZmZlY3QnKSk7XG4gYXdhaXQgZXZpZGVuY2UoaW5mbywnQjA4LW9yaWdpbmFsLWNsYXVzZXMnLHtnaXZlbjp7ZXZlbnQ6Zi51bnNldC5pZCxpbml0aWFsUGFydGljaXBhbnRzOjB9LHdoZW46e3Blb3BsZTpbZi5hLmlkLGYuYi5pZF0sZGlmZmVyZW50Um9sZXNJbml0aWFsbHk6WydhY3RvcicsJ3dpdG5lc3MnXSxtZW1vU2F2ZWQ6dHJ1ZX0sdGhlbjp7c2FtZUV2ZW50RnJvbUJvdGhQZXJzb25SZXZlcnNlUmVmZXJlbmNlczp0cnVlfSxuZWdhdGl2ZTp7YWN0b3JXaXRuZXNzTWVudGlvbmVkSW5mb3JtZWREaXN0aW5jdFN0b3JlZFJvbGVzOnRydWUsaGVhcmRUZXN0aW1vbnlBc0N1c3RvbUV2aWRlbmNlOnRlc3RpbW9ueS5pZCxleHBsaWNpdEtub3dsZWRnZUVmZmVjdElEOmtub3dsZWRnZS5pZCxyb2xlQWxvbmVBZGRzTm9Lbm93bGVkZ2VFdmlkZW5jZU9yRWZmZWN0OnRydWUsbm9BdXRvbWF0aWNLbm93bGVkZ2VBc3NlcnRpb25PckVmZmVjdDp0cnVlLGV4cGxpY2l0RXZpZGVuY2VMYXllcjonb3JkaW5hcnkgYWR2YW5jZWQgdHlwZWQgSlNPTiBmaWVsZHMsIHdoaWxlIG5vcm1hbCBwYXJ0aWNpcGFudCByb2xlIHNlbGVjdG9yIHJlbWFpbnMgc2VwYXJhdGUnfSxjb2xkQXJjaGl2ZVNIQTpkaWdlc3QoY29sZC5ieXRlcyl9KTtcbn0pO1xuXG50ZXN0KCdBVC1GMDMgb3JpZ2luYWwgb25lIHNjZW5lIGluIHJvbWFuY2Uvd2FyIGxhbmVzOiBvcmRpbmFyeSBlZGl0IHNoYXJlcyBib2R5LCByZW1vdmUgb25lIHRocmVhZCBwcmVzZXJ2ZXMgYm9keSBhbmQgYWN0dWFsIHBhcnRpY2lwYXRpb247IGNvbGQnLGFzeW5jKHtwYWdlLGJyb3dzZXJ9LGluZm8pPT57XG4gdGVzdC5zZXRUaW1lb3V0KDE4MF8wMDApO2NvbnN0IGY9YXdhaXQgb3JpZ2luYWxGdW5kYW1lbnRhbHNGaXh0dXJlKCk7Y29uc3Qgb2xkU2NlbmVEYXRhPXN0cnVjdHVyZWRDbG9uZShmLnBpbi5jb250ZW50LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuc2NlbmUuaWQpIS5kYXRhKTtjb25zdCB1bmFzc2lnbmVkPWYucC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLnNjZW5lLmlkKSE7aWYodW5hc3NpZ25lZC5raW5kIT09J3NjZW5lJyl0aHJvdyBFcnJvcignc2NlbmUgZml4dHVyZSBraW5kJyk7dW5hc3NpZ25lZC5kYXRhLnRocmVhZElkcz1bXTthd2FpdCBzZWVkKHBhZ2UsZi5wKTthd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ3NjZW5lJyxmLnNjZW5lLm5hbWUpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCd0YWInLHtuYW1lOifoqbPntLAnLGV4YWN0OnRydWV9KS5jbGljaygpO2Zvcihjb25zdCBncm91cCBvZiBbZi5yb21hbmNlLGYud2FyXSlhd2FpdCBwYWdlLmxvY2F0b3IoJ1tkYXRhLWZpZWxkPVwidGhyZWFkSWRzXCJdJykuZ2V0QnlMYWJlbCgn6L+95Yqg44GZ44KL5a++6LGhJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbihncm91cC5pZCk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTthd2FpdCB3cml0aW5nKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn54mp6Kqe44Gu5Lim44G55pa5Jyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbigndGhyZWFkJyk7Y29uc3Qgcm9tYW5jZT1wYWdlLmxvY2F0b3IoJy5zdG9yeS1sYW5lW2RhdGEtbGFuZS1pZD1cIicrZi5yb21hbmNlLmlkKydcIl0nKSx3YXI9cGFnZS5sb2NhdG9yKCcuc3RvcnktbGFuZVtkYXRhLWxhbmUtaWQ9XCInK2Yud2FyLmlkKydcIl0nKTtcbiBhd2FpdCByb21hbmNlLmxvY2F0b3IoJy5zdG9yeS1zY2VuZS1saW5rJykuY2xpY2soKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGFiJyx7bmFtZTon5pys5paHJyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLmxvY2F0b3IoJ1tkYXRhLWZpZWxkPVwiYm9keVwiXSB0ZXh0YXJlYVtkYXRhLXJpY2gtdGV4dC1lZGl0b3JdJykuZmlsbCgn5Y6fRjAzIOS4gOaWueOBi+OCieWkieabtOOBl+OBn+WFseacieacrOaWh/CfmIAnKTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO2F3YWl0IGNsb3NlRGV0YWlsKHBhZ2UpO2F3YWl0IHdhci5sb2NhdG9yKCcuc3Rvcnktc2NlbmUtbGluaycpLmNsaWNrKCk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+acrOaWhycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignW2RhdGEtZmllbGQ9XCJib2R5XCJdIHRleHRhcmVhW2RhdGEtcmljaC10ZXh0LWVkaXRvcl0nKSkudG9IYXZlVmFsdWUoJ+WOn0YwMyDkuIDmlrnjgYvjgonlpInmm7TjgZfjgZ/lhbHmnInmnKzmlofwn5iAJyk7YXdhaXQgY2xvc2VEZXRhaWwocGFnZSk7XG4gYXdhaXQgcm9tYW5jZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+OBk+OBrueti+OBi+OCieWkluOBmScsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHJvbWFuY2UubG9jYXRvcignW2RhdGEtc2NlbmUtaWQ9XCInK2Yuc2NlbmUuaWQrJ1wiXScpKS50b0hhdmVDb3VudCgwKTthd2FpdCBleHBlY3Qod2FyLmxvY2F0b3IoJ1tkYXRhLXNjZW5lLWlkPVwiJytmLnNjZW5lLmlkKydcIl0nKSkudG9IYXZlQ291bnQoMSk7XG4gYXdhaXQgcGFnZS5yZWxvYWQoKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuYXBwLXNoZWxsJykpLnRvQmVWaXNpYmxlKCk7Y29uc3QgY29sZD1hd2FpdCBiYWNrdXAocGFnZSksc2NlbmU9Y29sZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLnNjZW5lLmlkKSE7ZXhwZWN0KGNvbGQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmlsdGVyKGU9PmUua2luZD09PSdzY2VuZScmJmUuaWQ9PT1mLnNjZW5lLmlkKSkudG9IYXZlTGVuZ3RoKDEpO2V4cGVjdChzY2VuZS5raW5kPT09J3NjZW5lJyYmc2NlbmUuZGF0YS50aHJlYWRJZHMpLnRvRXF1YWwoW2Yud2FyLmlkXSk7ZXhwZWN0KHNjZW5lLmtpbmQ9PT0nc2NlbmUnJiZzY2VuZS5kYXRhLmJvZHlbMF0udGV4dCkudG9CZSgn5Y6fRjAzIOS4gOaWueOBi+OCieWkieabtOOBl+OBn+WFseacieacrOaWh/CfmIAnKTtleHBlY3QoY29sZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLmJvdGguaWQpPy5kYXRhKS50b0VxdWFsKGYuYm90aC5kYXRhKTtleHBlY3QoY29sZC5wYXJzZWQucHJvamVjdC5zbmFwc2hvdHMuZmluZChzPT5zLmlkPT09Zi5waW4uaWQpPy5jb250ZW50LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuc2NlbmUuaWQpPy5kYXRhKS50b0VxdWFsKG9sZFNjZW5lRGF0YSk7XG4gY29uc3QgcmVzdG9yZWQ9YXdhaXQgZnJlc2hSb3VuZHRyaXAoYnJvd3Nlcixjb2xkLmJ5dGVzKTtleHBlY3QocmVzdG9yZWQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmluZChlPT5lLmlkPT09Zi5zY2VuZS5pZCk/LmRhdGEpLnRvRXF1YWwoc2NlbmUuZGF0YSk7XG4gYXdhaXQgZXZpZGVuY2UoaW5mbywnRjAzLW9yaWdpbmFsLWNsYXVzZXMnLHtnaXZlbjp7c2FtZVNjZW5lOmYuc2NlbmUuaWQsdHdvVGhyZWFkczpbZi5yb21hbmNlLmlkLGYud2FyLmlkXX0sd2hlbjp7cmVnaXN0ZXJlZFR3b1RocmVhZHNUaHJvdWdoTm9ybWFsVHlwZWRDb250cm9sczp0cnVlLGVkaXRlZE9uZUNhcmRBbmRPcGVuZWRPdGhlcjp0cnVlfSx0aGVuOntvbmVTY2VuZUlEQW5kU2hhcmVkQm9keTp0cnVlfSxuZWdhdGl2ZTp7cmVtb3ZlZE9uZVRocmVhZE5vdEJvZHk6dHJ1ZSxhY3R1YWxFdmVudFBhcnRpY2lwYW50c1VuY2hhbmdlZDp0cnVlfSxjb2xkQW5kT2xkU25hcHNob3RBbmRGdWxsUmVzdG9yZTp0cnVlfSk7XG59KTtcblxudGVzdCgnQVQtRjA0IG9yaWdpbmFsIGF1dGhvcmVkIHNjZW5lIHJlYXNvbiwgYW5kIEFULUIyMCBjaGFuZ2VkIHB1cnBvc2U6IHJlZ2lzdGVyIHNjZW5lL2dvYWwgZXZpZGVuY2UsIHNob3cgYmVmb3JlL2FmdGVyIGFuZCByZW9wZW4gaXQ7IGVtcHR5IHJvbGUgc2NlbmUgc2F2ZXMgd2l0aG91dCBhdXRob3IgZ3JhZGluZzsgY29sZCcsYXN5bmMoe3BhZ2V9LGluZm8pPT57XG4gdGVzdC5zZXRUaW1lb3V0KDE4MF8wMDApO2NvbnN0IGY9YXdhaXQgb3JpZ2luYWxGdW5kYW1lbnRhbHNGaXh0dXJlKCk7YXdhaXQgc2VlZChwYWdlLGYucCk7YXdhaXQgb3BlblJlY29yZChwYWdlLCdzY2VuZScsZi5zY2VuZS5uYW1lKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGFiJyx7bmFtZTon6Kmz57SwJyxleGFjdDp0cnVlfSkuY2xpY2soKTtcbiBhd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+imlueCueS6uueJqScse2V4YWN0OnRydWV9KS5zZWxlY3RPcHRpb24oZi5hLmlkKTtcbiBmb3IoY29uc3QgW2tleSx0ZXh0XSBvZiBbWydnb2FscycsJ+WOn0YwNCDpjbXjgpLmjqLjgZknXSxbJ2NvbmZsaWN0cycsJ+WOn0YwNCDmlbXjgajlr77nq4vjgZnjgosnXSxbJ3Jlc3VsdHMnLCfljp9GMDQg5Luy6ZaT44KS5a6I44KL55uu55qE44G45aSJ44KP44Gj44GfJ10sWyduZXdJbmZvcm1hdGlvbicsJ+WOn0YwNCDpjbXjga7nnJ/lrp/jgpLnn6XjgaPjgZ8nXV0gYXMgY29uc3QpYXdhaXQgcGFnZS5sb2NhdG9yKCdbZGF0YS1maWVsZD1cIicra2V5KydcIl0gdGV4dGFyZWFbZGF0YS1yaWNoLXRleHQtZWRpdG9yXScpLmZpbGwodGV4dCk7XG4gYXdhaXQgc2F2ZUVkaXRvcihwYWdlKTthd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ2dvYWwnLGYuZ29hbC5uYW1lKTthd2FpdCBwYWdlLmxvY2F0b3IoJ1tkYXRhLWZpZWxkPVwiZXZpZGVuY2VTY2VuZUlkc1wiXScpLmdldEJ5TGFiZWwoJ+i/veWKoOOBmeOCi+WvvuixoScse2V4YWN0OnRydWV9KS5zZWxlY3RPcHRpb24oZi5zY2VuZS5pZCk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiBhd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ3NjZW5lJyxmLnQubmFtZSk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+acrOaWhycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcGFnZS5sb2NhdG9yKCdbZGF0YS1maWVsZD1cImJvZHlcIl0gdGV4dGFyZWFbZGF0YS1yaWNoLXRleHQtZWRpdG9yXScpLmZpbGwoJ+WOn0YwNCDlvbnlibLjgpLnqbrjga7jgb7jgb7kv53lrZjjgZfjgZ9UJyk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTthd2FpdCB3cml0aW5nKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn54mp6Kqe44Gu5Lim44G55pa5Jyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbignY2hhcmFjdGVyJyk7Y29uc3QgbGFuZT1wYWdlLmxvY2F0b3IoJy5zdG9yeS1sYW5lW2RhdGEtbGFuZS1pZD1cIicrZi5hLmlkKydcIl0nKTtmb3IoY29uc3QgdGV4dCBvZiBbJ+WOn0YwNCDpjbXjgpLmjqLjgZknLCfljp9GMDQg5pW144Go5a++56uL44GZ44KLJywn5Y6fRjA0IOS7sumWk+OCkuWuiOOCi+ebrueahOOBuOWkieOCj+OBo+OBnycsJ+WOn0YwNCDpjbXjga7nnJ/lrp/jgpLnn6XjgaPjgZ8nXSlhd2FpdCBleHBlY3QobGFuZS5sb2NhdG9yKCcuY2hhcmFjdGVyLWFyYy1yZWNvcmQnKSkudG9Db250YWluVGV4dCh0ZXh0KTthd2FpdCBsYW5lLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmdvYWwubmFtZSsn44Gu5qC55oug5aC06Z2iICcrZi5zY2VuZS5uYW1lKyfjgpLplovjgY8nLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtaGVhZGluZycpKS50b0NvbnRhaW5UZXh0KGYuc2NlbmUubmFtZSk7XG4gYXdhaXQgcGFnZS5yZWxvYWQoKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuYXBwLXNoZWxsJykpLnRvQmVWaXNpYmxlKCk7Y29uc3QgY29sZD1hd2FpdCBiYWNrdXAocGFnZSkscz1jb2xkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYuc2NlbmUuaWQpISx0PWNvbGQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmluZChlPT5lLmlkPT09Zi50LmlkKSE7ZXhwZWN0KHMua2luZD09PSdzY2VuZScmJnMuZGF0YS5wb3ZJZCkudG9CZShmLmEuaWQpO2Zvcihjb25zdCBrZXkgb2YgWydnb2FscycsJ2NvbmZsaWN0cycsJ3Jlc3VsdHMnLCduZXdJbmZvcm1hdGlvbiddIGFzIGNvbnN0KWV4cGVjdCh0LmtpbmQ9PT0nc2NlbmUnJiZ0LmRhdGFba2V5XSkudG9FcXVhbChbXSk7ZXhwZWN0KHQuc3RhdHVzKS50b0JlKCdjb25maXJtZWQnKTtleHBlY3QoY29sZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLmdvYWwuaWQpPy5kYXRhKS50b01hdGNoT2JqZWN0KHtldmlkZW5jZVNjZW5lSWRzOltmLnNjZW5lLmlkXX0pO1xuIGF3YWl0IGV2aWRlbmNlKGluZm8sJ0YwNC1hbmQtQjIwLW9yaWdpbmFsLWNsYXVzZXMnLHtGMDQ6e2dpdmVuOntzZWFyY2hpbmdDaGFyYWN0ZXI6Zi5hLmlkLFM6Zi5zY2VuZS5pZCxlbXB0eVJvbGVUOmYudC5pZH0sd2hlbjp7cG92QW5kR29hbENvbmZsaWN0UmVzdWx0SW5mb3JtYXRpb25SZWdpc3RlcmVkOnRydWUsVEVtcHR5Um9sZXNTYXZlZDp0cnVlfSx0aGVuOnthdXRob3JlZFJlYXNvbkFuZENoYW5nZVZpc2libGU6dHJ1ZX0sbmVnYXRpdmU6e2VtcHR5Um9sZUFsbG93ZWQ6dHJ1ZSxub0F1dG9tYXRpY0NvcnJlY3RuZXNzR3JhZGU6dHJ1ZX19LEIyMDp7Z2l2ZW46e2NoYW5naW5nUHVycG9zZUNoYXJhY3RlcjpmLmEuaWR9LHdoZW46e2V2aWRlbmNlU2NlbmVSZWdpc3RlcmVkOmYuc2NlbmUuaWR9LHRoZW46e2JlZm9yZUFmdGVyQW5kRXZpZGVuY2VOYXZpZ2F0aW9uOnRydWV9LG5lZ2F0aXZlOntlbXB0eVJvbGVUU3RpbGxTYXZlZDp0cnVlfX0sY29sZEFyY2hpdmVTSEE6ZGlnZXN0KGNvbGQuYnl0ZXMpfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUUEsSUFBSSxFQUFDQyxNQUFNLFFBQWlCLGtCQUFrQjtBQUN0RCxTQUFRQyxJQUFJLEVBQUNDLEdBQUcsRUFBQ0MsTUFBTSxFQUFDQyxPQUFPLEVBQUNDLE1BQU0sRUFBQ0MsUUFBUSxRQUFPLFVBQVU7QUFDaEUsU0FBUUMsVUFBVSxFQUFDQyxVQUFVLEVBQUNDLFFBQVEsRUFBQ0MsY0FBYyxRQUFPLG9CQUFvQjtBQUNoRixTQUFRQywyQkFBMkIsUUFBTyw0Q0FBNEM7QUFDdEYsU0FBUUMsWUFBWSxRQUFPLCtCQUErQjtBQUUxRCxlQUFlQyxRQUFRQSxDQUFDQyxJQUFTLEVBQUM7RUFBQyxNQUFNWixHQUFHLENBQUNZLElBQUksRUFBQyxLQUFLLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNDLFNBQVMsQ0FBQyxLQUFLLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLE9BQU87SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0FBQUM7QUFDdkgsZUFBZUMsT0FBT0EsQ0FBQ0wsSUFBUyxFQUFDO0VBQUMsTUFBTVosR0FBRyxDQUFDWSxJQUFJLEVBQUMsS0FBSyxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDQyxTQUFTLENBQUMsS0FBSyxFQUFDO0lBQUNDLElBQUksRUFBQyxNQUFNO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztBQUFDO0FBQ3JILGVBQWVFLFdBQVdBLENBQUNOLElBQVMsRUFBQztFQUFDLE1BQU1PLEtBQUssR0FBQ1AsSUFBSSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxRQUFRO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQztFQUFDLElBQUcsTUFBTUksS0FBSyxDQUFDQyxTQUFTLENBQUMsQ0FBQyxFQUFDLE1BQU1ELEtBQUssQ0FBQ0gsS0FBSyxDQUFDLENBQUM7QUFBQztBQUVySm5CLElBQUksQ0FBQyw0S0FBNEssRUFBQyxPQUFNO0VBQUNlLElBQUk7RUFBQ1M7QUFBTyxDQUFDLEVBQUNDLElBQUksS0FBRztFQUFBLElBQUFDLHFCQUFBLEVBQUFDLHFCQUFBO0VBQzdNM0IsSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE1BQU8sQ0FBQztFQUFDLE1BQU1DLENBQUMsR0FBQyxNQUFNakIsMkJBQTJCLENBQUMsQ0FBQztFQUFDLE1BQU1WLElBQUksQ0FBQ2EsSUFBSSxFQUFDYyxDQUFDLENBQUNDLENBQUMsQ0FBQztFQUFDLE1BQU1oQixRQUFRLENBQUNDLElBQUksQ0FBQztFQUM5RyxNQUFNZ0IsTUFBTSxHQUFDLE1BQU0xQixPQUFPLENBQUNVLElBQUksQ0FBQztFQUFDLE1BQU1BLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQywwQ0FBMEMsR0FBQ0gsQ0FBQyxDQUFDSSxNQUFNLENBQUNDLEVBQUUsR0FBQyxJQUFJLENBQUMsQ0FBQ2YsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNbEIsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMsd0RBQXdELENBQUMsQ0FBQyxDQUFDRyxXQUFXLENBQUNOLENBQUMsQ0FBQ0ksTUFBTSxDQUFDRyxJQUFJLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDO0VBQUMsTUFBTWpCLFdBQVcsQ0FBQ04sSUFBSSxDQUFDO0VBQ2hSZCxNQUFNLENBQUMsTUFBTUksT0FBTyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsT0FBTyxDQUFDUixNQUFNLENBQUM7RUFDM0MsTUFBTWhCLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQywwQ0FBMEMsR0FBQ0gsQ0FBQyxDQUFDVyxJQUFJLENBQUNOLEVBQUUsR0FBQyxJQUFJLENBQUMsQ0FBQ2YsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNSixJQUFJLENBQUNpQixPQUFPLENBQUMsd0RBQXdELENBQUMsQ0FBQ1MsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0VBQUMsTUFBTWhDLFVBQVUsQ0FBQ00sSUFBSSxDQUFDO0VBQUMsTUFBTU0sV0FBVyxDQUFDTixJQUFJLENBQUM7RUFDN08sS0FBSSxNQUFNMkIsTUFBTSxJQUFJLENBQUNiLENBQUMsQ0FBQ2MsQ0FBQyxFQUFDZCxDQUFDLENBQUNlLENBQUMsQ0FBQyxFQUFDO0lBQzdCLE1BQU1DLElBQUksR0FBQzlCLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyx3QkFBd0IsR0FBQ0gsQ0FBQyxDQUFDaUIsRUFBRSxDQUFDWixFQUFFLEdBQUMsR0FBRyxHQUFDUSxNQUFNLENBQUNSLEVBQUUsR0FBQyxJQUFJLENBQUM7SUFBQyxNQUFNVyxJQUFJLENBQUNiLE9BQU8sQ0FBQyxrQkFBa0IsR0FBQ0gsQ0FBQyxDQUFDVyxJQUFJLENBQUNOLEVBQUUsR0FBQyxJQUFJLENBQUMsQ0FBQ2YsS0FBSyxDQUFDLENBQUM7SUFBQyxNQUFNbEIsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMsd0RBQXdELENBQUMsQ0FBQyxDQUFDRyxXQUFXLENBQUMscUJBQXFCLENBQUM7SUFBQyxNQUFNZCxXQUFXLENBQUNOLElBQUksQ0FBQztFQUMzUjtFQUNBLE1BQU1BLElBQUksQ0FBQ2dDLE1BQU0sQ0FBQyxDQUFDO0VBQUMsTUFBTTlDLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDaUIsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNnQixXQUFXLENBQUMsQ0FBQztFQUFDLE1BQU1DLElBQUksR0FBQyxNQUFNN0MsTUFBTSxDQUFDVyxJQUFJLENBQUM7SUFBQ2tCLE1BQU0sR0FBQ2dCLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ3BCLEVBQUUsS0FBR0wsQ0FBQyxDQUFDSSxNQUFNLENBQUNDLEVBQUUsQ0FBRTtJQUFDTSxJQUFJLEdBQUNTLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ3BCLEVBQUUsS0FBR0wsQ0FBQyxDQUFDVyxJQUFJLENBQUNOLEVBQUUsQ0FBRTtFQUN0T2pDLE1BQU0sQ0FBQ2dDLE1BQU0sQ0FBQ3NCLElBQUksS0FBRyxPQUFPLElBQUV0QixNQUFNLENBQUNHLElBQUksQ0FBQ29CLFlBQVksQ0FBQyxDQUFDakIsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUFDdEMsTUFBTSxDQUFDdUMsSUFBSSxDQUFDZSxJQUFJLEtBQUcsT0FBTyxJQUFFZixJQUFJLENBQUNKLElBQUksQ0FBQ29CLFlBQVksQ0FBQyxDQUFDakIsT0FBTyxDQUFDVixDQUFDLENBQUNXLElBQUksQ0FBQ0osSUFBSSxDQUFDb0IsWUFBWSxDQUFDO0VBQUN2RCxNQUFNLENBQUNnRCxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNLLE1BQU0sQ0FBQ0gsQ0FBQyxJQUFFQSxDQUFDLENBQUNDLElBQUksS0FBRyxXQUFXLElBQUVELENBQUMsQ0FBQ0MsSUFBSSxLQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUNHLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFBQ3pELE1BQU0sRUFBQXlCLHFCQUFBLEdBQUN1QixJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUSxTQUFTLENBQUNOLElBQUksQ0FBQ08sQ0FBQyxJQUFFQSxDQUFDLENBQUMxQixFQUFFLEtBQUdMLENBQUMsQ0FBQ2dDLEdBQUcsQ0FBQzNCLEVBQUUsQ0FBQyxjQUFBUixxQkFBQSx1QkFBdERBLHFCQUFBLENBQXdEb0MsV0FBVyxDQUFDLENBQUNDLElBQUksQ0FBQ2xDLENBQUMsQ0FBQ2dDLEdBQUcsQ0FBQ0MsV0FBVyxDQUFDO0VBQ3JXLE1BQU1FLFFBQVEsR0FBQyxNQUFNckQsY0FBYyxDQUFDYSxPQUFPLEVBQUN5QixJQUFJLENBQUNnQixLQUFLLENBQUM7RUFBQ2hFLE1BQU0sRUFBQTBCLHFCQUFBLEdBQUNxQyxRQUFRLENBQUNkLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNwQixFQUFFLEtBQUdMLENBQUMsQ0FBQ1csSUFBSSxDQUFDTixFQUFFLENBQUMsY0FBQVAscUJBQUEsdUJBQTFEQSxxQkFBQSxDQUE0RFMsSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDSixJQUFJLENBQUM7RUFDbkosTUFBTTdCLFFBQVEsQ0FBQ2tCLElBQUksRUFBQyxzQkFBc0IsRUFBQztJQUFDeUMsS0FBSyxFQUFDO01BQUNqQyxNQUFNLEVBQUNKLENBQUMsQ0FBQ0ksTUFBTSxDQUFDQyxFQUFFO01BQUNpQyxjQUFjLEVBQUN0QyxDQUFDLENBQUNXLElBQUksQ0FBQ047SUFBRSxDQUFDO0lBQUNrQyxJQUFJLEVBQUM7TUFBQ0Msb0JBQW9CLEVBQUM7SUFBSSxDQUFDO0lBQUNDLElBQUksRUFBQztNQUFDQyxZQUFZLEVBQUMsQ0FBQzFDLENBQUMsQ0FBQ1csSUFBSSxDQUFDTixFQUFFLENBQUM7TUFBQ3NDLDJCQUEyQixFQUFDLElBQUk7TUFBQ0MsWUFBWSxFQUFDO0lBQUksQ0FBQztJQUFDQyxRQUFRLEVBQUM7TUFBQ0MsNEJBQTRCLEVBQUMsSUFBSTtNQUFDQyxtQ0FBbUMsRUFBQztJQUFJLENBQUM7SUFBQ0MsbUJBQW1CLEVBQUN2RSxNQUFNLENBQUN3RSxJQUFJLENBQUNDLFNBQVMsQ0FBQ2hELE1BQU0sQ0FBQyxDQUFDO0lBQUNpRCxrQkFBa0IsRUFBQzFFLE1BQU0sQ0FBQzJDLElBQUksQ0FBQ2dCLEtBQUssQ0FBQztJQUFDZ0IsUUFBUSxFQUFDO0VBQVMsQ0FBQyxDQUFDO0FBQ3haLENBQUMsQ0FBQztBQUVGakYsSUFBSSxDQUFDLDJJQUEySSxFQUFDLE9BQU07RUFBQ2U7QUFBSSxDQUFDLEVBQUNVLElBQUksS0FBRztFQUFBLElBQUF5RCxnQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxpQkFBQTtFQUNwS3BGLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxNQUFPLENBQUM7RUFBQyxNQUFNQyxDQUFDLEdBQUMsTUFBTWpCLDJCQUEyQixDQUFDLENBQUM7RUFBQyxNQUFNVixJQUFJLENBQUNhLElBQUksRUFBQ2MsQ0FBQyxDQUFDQyxDQUFDLENBQUM7RUFBQyxNQUFNaEIsUUFBUSxDQUFDQyxJQUFJLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLFlBQVk7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQ3BMLE1BQU1rRSxLQUFLLEdBQUN0RSxJQUFJLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ0MsSUFBSSxFQUFDLGVBQWU7TUFBQ0MsS0FBSyxFQUFDO0lBQUksQ0FBQyxDQUFDO0lBQUNvRSxHQUFHLEdBQUNELEtBQUssQ0FBQ3JELE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDeUIsTUFBTSxDQUFDO01BQUM4QixHQUFHLEVBQUN4RSxJQUFJLENBQUN5RSxTQUFTLENBQUMzRCxDQUFDLENBQUNpQixFQUFFLENBQUM3QixJQUFJLEVBQUM7UUFBQ0MsS0FBSyxFQUFDO01BQUksQ0FBQztJQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1hLE1BQU0sR0FBQyxNQUFNMUIsT0FBTyxDQUFDVSxJQUFJLENBQUM7RUFDNU0sTUFBTXVFLEdBQUcsQ0FBQ3RFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLE9BQU87SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ3FGLEdBQUcsQ0FBQ3RFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLElBQUk7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzhCLFdBQVcsQ0FBQyxDQUFDO0VBQUMvQyxNQUFNLENBQUMsTUFBTUksT0FBTyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsT0FBTyxDQUFDUixNQUFNLENBQUM7RUFDdEwsTUFBTXNELEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDWSxDQUFDLENBQUM0RCxFQUFFLENBQUN4RSxJQUFJLEdBQUMsS0FBSztJQUFDQyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNbEIsTUFBTSxDQUFDb0YsS0FBSyxDQUFDckQsT0FBTyxDQUFDLDRCQUE0QixDQUFDLENBQUMwRCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNDLGFBQWEsQ0FBQzlELENBQUMsQ0FBQzRELEVBQUUsQ0FBQ3hFLElBQUksQ0FBQztFQUFDLE1BQU0yRSxTQUFTLEdBQUMsTUFBTXZGLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDO0VBQUMsS0FBSSxNQUFNOEUsS0FBSyxJQUFJLENBQUMsVUFBVSxFQUFDLFdBQVcsRUFBQyxRQUFRLEVBQUMsV0FBVyxFQUFDLFFBQVEsRUFBQyxRQUFRLENBQUMsRUFBQzVGLE1BQU0sQ0FBQzJGLFNBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ3RELE9BQU8sQ0FBQ1IsTUFBTSxDQUFDOEQsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNUixLQUFLLENBQUNyRSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxLQUFLO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU0yRSxPQUFPLEdBQUMsTUFBTTFGLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0VBQUMsS0FBSSxNQUFNdUMsQ0FBQyxJQUFJLENBQUN6QixDQUFDLENBQUNjLENBQUMsRUFBQ2QsQ0FBQyxDQUFDZSxDQUFDLEVBQUNmLENBQUMsQ0FBQ2lCLEVBQUUsRUFBQ2pCLENBQUMsQ0FBQzRELEVBQUUsRUFBQzVELENBQUMsQ0FBQ0ksTUFBTSxFQUFDSixDQUFDLENBQUNXLElBQUksRUFBQ1gsQ0FBQyxDQUFDa0UsS0FBSyxDQUFDLEVBQUM5RixNQUFNLENBQUM2RixPQUFPLENBQUM1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUMyQyxDQUFDLElBQUVBLENBQUMsQ0FBQzlELEVBQUUsS0FBR29CLENBQUMsQ0FBQ3BCLEVBQUUsQ0FBQyxDQUFDLENBQUNLLE9BQU8sQ0FBQ2UsQ0FBQyxDQUFDO0VBQUMsTUFBTXhDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxZQUFZO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUMxb0IsTUFBTW1FLEdBQUcsQ0FBQ3RFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLGFBQWE7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWtFLEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLGFBQWE7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ29GLEtBQUssQ0FBQ3JELE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUMsb0JBQW9CLENBQUM7RUFBQyxNQUFNTixLQUFLLENBQUNyRSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxnQkFBZ0I7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ29GLEtBQUssQ0FBQ3JELE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDeUIsTUFBTSxDQUFDO0lBQUN3QyxPQUFPLEVBQUNwRSxDQUFDLENBQUNpQixFQUFFLENBQUM3QjtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNpRixXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTWIsS0FBSyxDQUFDckUsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDQyxJQUFJLEVBQUMsS0FBSztJQUFDQyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFDeGQsTUFBTUosSUFBSSxDQUFDZ0MsTUFBTSxDQUFDLENBQUM7RUFBQyxNQUFNOUMsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQ2dCLFdBQVcsQ0FBQyxDQUFDO0VBQUMsTUFBTUMsSUFBSSxHQUFDLE1BQU03QyxNQUFNLENBQUNXLElBQUksQ0FBQztJQUFDZSxDQUFDLEdBQUNtQixJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTztFQUM5SGxELE1BQU0sRUFBQWlGLGdCQUFBLEdBQUNwRCxDQUFDLENBQUNzQixRQUFRLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNwQixFQUFFLEtBQUdMLENBQUMsQ0FBQ2lCLEVBQUUsQ0FBQ1osRUFBRSxDQUFDLGNBQUFnRCxnQkFBQSx1QkFBbENBLGdCQUFBLENBQW9DaUIsU0FBUyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxDQUFDO0VBQUNuRyxNQUFNLEVBQUFrRixpQkFBQSxHQUFDckQsQ0FBQyxDQUFDc0IsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUNpQixFQUFFLENBQUNaLEVBQUUsQ0FBQyxjQUFBaUQsaUJBQUEsdUJBQWxDQSxpQkFBQSxDQUFvQy9DLElBQUksQ0FBQyxDQUFDRyxPQUFPLENBQUNWLENBQUMsQ0FBQ2lCLEVBQUUsQ0FBQ1YsSUFBSSxDQUFDO0VBQUNuQyxNQUFNLEVBQUFtRixpQkFBQSxHQUFDdEQsQ0FBQyxDQUFDc0IsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUM0RCxFQUFFLENBQUN2RCxFQUFFLENBQUMsY0FBQWtELGlCQUFBLHVCQUFsQ0EsaUJBQUEsQ0FBb0NoRCxJQUFJLENBQUMsQ0FBQ0csT0FBTyxDQUFDVixDQUFDLENBQUM0RCxFQUFFLENBQUNyRCxJQUFJLENBQUM7RUFDMU0sS0FBSSxNQUFNa0IsQ0FBQyxJQUFJLENBQUN6QixDQUFDLENBQUNjLENBQUMsRUFBQ2QsQ0FBQyxDQUFDZSxDQUFDLEVBQUNmLENBQUMsQ0FBQ0ksTUFBTSxFQUFDSixDQUFDLENBQUNXLElBQUksRUFBQ1gsQ0FBQyxDQUFDa0UsS0FBSyxDQUFDLEVBQUM5RixNQUFNLENBQUM2QixDQUFDLENBQUNzQixRQUFRLENBQUNDLElBQUksQ0FBQzJDLENBQUMsSUFBRUEsQ0FBQyxDQUFDOUQsRUFBRSxLQUFHb0IsQ0FBQyxDQUFDcEIsRUFBRSxDQUFDLENBQUMsQ0FBQ0ssT0FBTyxDQUFDZSxDQUFDLENBQUM7RUFDbkcsTUFBTS9DLFFBQVEsQ0FBQ2tCLElBQUksRUFBQyxzQkFBc0IsRUFBQztJQUFDeUMsS0FBSyxFQUFDO01BQUN4QixNQUFNLEVBQUNiLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFO01BQUNtRSxNQUFNLEVBQUMsQ0FBQ3hFLENBQUMsQ0FBQ2lCLEVBQUUsQ0FBQ1osRUFBRSxFQUFDTCxDQUFDLENBQUM0RCxFQUFFLENBQUN2RCxFQUFFO0lBQUMsQ0FBQztJQUFDa0MsSUFBSSxFQUFDO01BQUNrQyxTQUFTLEVBQUMsSUFBSTtNQUFDQyxtQkFBbUIsRUFBQztJQUFJLENBQUM7SUFBQ2pDLElBQUksRUFBQztNQUFDa0Msc0JBQXNCLEVBQUMsSUFBSTtNQUFDQywwQ0FBMEMsRUFBQztJQUFJLENBQUM7SUFBQy9CLFFBQVEsRUFBQztNQUFDZ0Msd0JBQXdCLEVBQUMsSUFBSTtNQUFDQyxnQ0FBZ0MsRUFBQztJQUFJLENBQUM7SUFBQ0MsY0FBYyxFQUFDdEcsTUFBTSxDQUFDMkMsSUFBSSxDQUFDZ0IsS0FBSztFQUFDLENBQUMsQ0FBQztBQUNoVixDQUFDLENBQUM7QUFFRmpFLElBQUksQ0FBQyxnSkFBZ0osRUFBQyxPQUFNO0VBQUNlO0FBQUksQ0FBQyxFQUFDVSxJQUFJLEtBQUc7RUFDekt6QixJQUFJLENBQUM0QixVQUFVLENBQUMsTUFBTyxDQUFDO0VBQUMsTUFBTUMsQ0FBQyxHQUFDLE1BQU1qQiwyQkFBMkIsQ0FBQyxDQUFDO0VBQUMsTUFBTVYsSUFBSSxDQUFDYSxJQUFJLEVBQUNjLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDO0VBQUMsTUFBTWhCLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxnQkFBZ0I7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTUosSUFBSSxDQUFDaUIsT0FBTyxDQUFDLDBDQUEwQyxHQUFDSCxDQUFDLENBQUNJLE1BQU0sQ0FBQ0MsRUFBRSxHQUFDLElBQUksQ0FBQyxDQUFDZixLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1KLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQywwQ0FBMEMsR0FBQ0gsQ0FBQyxDQUFDVyxJQUFJLENBQUNOLEVBQUUsR0FBQyxJQUFJLENBQUMsQ0FBQ2YsS0FBSyxDQUFDLENBQUM7RUFDdFcsTUFBTWtFLEtBQUssR0FBQ3RFLElBQUksQ0FBQ0MsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDQyxJQUFJLEVBQUMsVUFBVTtJQUFDQyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUM7RUFBQyxNQUFNakIsTUFBTSxDQUFDb0YsS0FBSyxDQUFDd0IsVUFBVSxDQUFDLFVBQVUsRUFBQztJQUFDM0YsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2lCLFdBQVcsQ0FBQ04sQ0FBQyxDQUFDSSxNQUFNLENBQUNDLEVBQUUsQ0FBQztFQUFDLE1BQU1qQyxNQUFNLENBQUNvRixLQUFLLENBQUN3QixVQUFVLENBQUMsVUFBVSxFQUFDO0lBQUMzRixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDaUIsV0FBVyxDQUFDTixDQUFDLENBQUNXLElBQUksQ0FBQ04sRUFBRSxDQUFDO0VBQUMsTUFBTW1ELEtBQUssQ0FBQ3dCLFVBQVUsQ0FBQyxVQUFVLEVBQUM7SUFBQzNGLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNEYsWUFBWSxDQUFDLFFBQVEsQ0FBQztFQUFDLE1BQU16QixLQUFLLENBQUNyRSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxPQUFPO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1sQixNQUFNLENBQUNvRixLQUFLLENBQUMsQ0FBQ2EsV0FBVyxDQUFDLENBQUMsQ0FBQztFQUM3WSxNQUFNUixLQUFLLEdBQUMsTUFBTXRGLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0lBQUNnRyxRQUFRLEdBQUNyQixLQUFLLENBQUN4QyxNQUFNLENBQUNDLE9BQU8sQ0FBQzZELFNBQVMsQ0FBQzNELElBQUksQ0FBQzRELENBQUMsSUFBRUEsQ0FBQyxDQUFDQyxNQUFNLEtBQUdyRixDQUFDLENBQUNJLE1BQU0sQ0FBQ0MsRUFBRSxJQUFFK0UsQ0FBQyxDQUFDRSxJQUFJLEtBQUd0RixDQUFDLENBQUNXLElBQUksQ0FBQ04sRUFBRSxDQUFFO0VBQUNqQyxNQUFNLENBQUM4RyxRQUFRLENBQUMsQ0FBQ1gsVUFBVSxDQUFDLENBQUM7RUFBQyxNQUFNdEYsUUFBUSxDQUFDQyxJQUFJLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNpQixPQUFPLENBQUMsNENBQTRDLEdBQUMrRSxRQUFRLENBQUM3RSxFQUFFLEdBQUMsSUFBSSxDQUFDLENBQUNmLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ29GLEtBQUssQ0FBQyxDQUFDTSxhQUFhLENBQUNvQixRQUFRLENBQUM3RSxFQUFFLENBQUM7RUFDdlQsTUFBTWtGLGFBQWEsR0FBQyxNQUFNL0csT0FBTyxDQUFDVSxJQUFJLENBQUM7RUFBQyxNQUFNc0UsS0FBSyxDQUFDd0IsVUFBVSxDQUFDLFVBQVUsRUFBQztJQUFDM0YsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM0RixZQUFZLENBQUMsRUFBRSxDQUFDO0VBQUMsTUFBTXpCLEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLE9BQU87SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ29GLEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDMkUsYUFBYSxDQUFDLHVCQUF1QixDQUFDO0VBQUMxRixNQUFNLENBQUMsTUFBTUksT0FBTyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsT0FBTyxDQUFDNkUsYUFBYSxDQUFDO0VBQUMsTUFBTW5ILE1BQU0sQ0FBQ29GLEtBQUssQ0FBQ3dCLFVBQVUsQ0FBQyxVQUFVLEVBQUM7SUFBQzNGLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNpQixXQUFXLENBQUMsRUFBRSxDQUFDO0VBQ25YO0VBQ0E7RUFDQTtFQUNBLE1BQU1rRixNQUFNLEdBQUNoQyxLQUFLLENBQUN3QixVQUFVLENBQUMsVUFBVSxFQUFDO0lBQUMzRixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUM7RUFBQyxNQUFNb0csT0FBTyxHQUFDLHNDQUFzQztFQUFDLE1BQU1ELE1BQU0sQ0FBQ0UsUUFBUSxDQUFDLENBQUNDLE1BQU0sRUFBQ3RGLEVBQUUsS0FBRztJQUFDLE1BQU11RixDQUFDLEdBQUNDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLFFBQVEsQ0FBQztJQUFDRixDQUFDLENBQUNHLEtBQUssR0FBQzFGLEVBQUU7SUFBQ3VGLENBQUMsQ0FBQ25GLElBQUksR0FBQyxVQUFVO0lBQUNrRixNQUFNLENBQUNLLE1BQU0sQ0FBQ0osQ0FBQyxDQUFDO0VBQUMsQ0FBQyxFQUFDSCxPQUFPLENBQUM7RUFBQyxNQUFNRCxNQUFNLENBQUNQLFlBQVksQ0FBQ1EsT0FBTyxDQUFDO0VBQUMsTUFBTWpDLEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLE9BQU87SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ29GLEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDMkUsYUFBYSxDQUFDLHVCQUF1QixDQUFDO0VBQUMsTUFBTTFGLE1BQU0sQ0FBQ29ILE1BQU0sQ0FBQyxDQUFDbEYsV0FBVyxDQUFDbUYsT0FBTyxDQUFDO0VBQUNySCxNQUFNLENBQUMsTUFBTUksT0FBTyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsT0FBTyxDQUFDNkUsYUFBYSxDQUFDO0VBQ2pnQixNQUFNQyxNQUFNLENBQUNFLFFBQVEsQ0FBQyxDQUFDQyxNQUFNLEVBQUN0RixFQUFFLEtBQUc7SUFBQyxNQUFNdUYsQ0FBQyxHQUFDQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxRQUFRLENBQUM7SUFBQ0YsQ0FBQyxDQUFDRyxLQUFLLEdBQUMxRixFQUFFO0lBQUN1RixDQUFDLENBQUNuRixJQUFJLEdBQUMsUUFBUTtJQUFDa0YsTUFBTSxDQUFDSyxNQUFNLENBQUNKLENBQUMsQ0FBQztFQUFDLENBQUMsRUFBQzVGLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFLENBQUM7RUFBQyxNQUFNbUYsTUFBTSxDQUFDUCxZQUFZLENBQUNqRixDQUFDLENBQUNjLENBQUMsQ0FBQ1QsRUFBRSxDQUFDO0VBQUMsTUFBTW1ELEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLE9BQU87SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ29GLEtBQUssQ0FBQ3JFLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDMkUsYUFBYSxDQUFDLHVCQUF1QixDQUFDO0VBQUMxRixNQUFNLENBQUMsTUFBTUksT0FBTyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsT0FBTyxDQUFDNkUsYUFBYSxDQUFDO0VBQ3ZXLE1BQU1DLE1BQU0sQ0FBQ1AsWUFBWSxDQUFDakYsQ0FBQyxDQUFDVyxJQUFJLENBQUNOLEVBQUUsQ0FBQztFQUFDLE1BQU1tRCxLQUFLLENBQUN3QixVQUFVLENBQUMsVUFBVSxFQUFDO0lBQUMzRixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzRGLFlBQVksQ0FBQyxjQUFjLENBQUM7RUFBQyxNQUFNekIsS0FBSyxDQUFDckUsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDQyxJQUFJLEVBQUMsT0FBTztJQUFDQyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNbEIsTUFBTSxDQUFDb0YsS0FBSyxDQUFDLENBQUNhLFdBQVcsQ0FBQyxDQUFDLENBQUM7RUFBQyxNQUFNakcsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMsNENBQTRDLEdBQUMrRSxRQUFRLENBQUM3RSxFQUFFLEdBQUMsSUFBSSxDQUFDLENBQUN1QixNQUFNLENBQUM7SUFBQ3dDLE9BQU8sRUFBQztFQUFRLENBQUMsQ0FBQyxDQUFDLENBQUNqRCxXQUFXLENBQUMsQ0FBQztFQUFDLE1BQU1qQyxJQUFJLENBQUNnQyxNQUFNLENBQUMsQ0FBQztFQUFDLE1BQU05QyxNQUFNLENBQUNjLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDZ0IsV0FBVyxDQUFDLENBQUM7RUFBQyxNQUFNQyxJQUFJLEdBQUMsTUFBTTdDLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0VBQUNkLE1BQU0sQ0FBQ2dELElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxPQUFPLENBQUM2RCxTQUFTLENBQUMzRCxJQUFJLENBQUM0RCxDQUFDLElBQUVBLENBQUMsQ0FBQy9FLEVBQUUsS0FBRzZFLFFBQVEsQ0FBQzdFLEVBQUUsQ0FBQyxDQUFDLENBQUM0RixhQUFhLENBQUM7SUFBQ1osTUFBTSxFQUFDckYsQ0FBQyxDQUFDSSxNQUFNLENBQUNDLEVBQUU7SUFBQ2lGLElBQUksRUFBQ3RGLENBQUMsQ0FBQ1csSUFBSSxDQUFDTixFQUFFO0lBQUM2RixZQUFZLEVBQUM7RUFBYyxDQUFDLENBQUM7RUFDbmxCLE1BQU14SCxRQUFRLENBQUNrQixJQUFJLEVBQUMsc0JBQXNCLEVBQUM7SUFBQ3lDLEtBQUssRUFBQztNQUFDOEQsU0FBUyxFQUFDLENBQUNuRyxDQUFDLENBQUNJLE1BQU0sQ0FBQ0MsRUFBRSxFQUFDTCxDQUFDLENBQUNXLElBQUksQ0FBQ04sRUFBRTtJQUFDLENBQUM7SUFBQ2tDLElBQUksRUFBQztNQUFDNkQsa0JBQWtCLEVBQUMsSUFBSTtNQUFDQyxZQUFZLEVBQUM7SUFBUSxDQUFDO0lBQUM1RCxJQUFJLEVBQUM7TUFBQzZELFVBQVUsRUFBQ3BCLFFBQVEsQ0FBQzdFLEVBQUU7TUFBQ2tHLHlDQUF5QyxFQUFDLElBQUk7TUFBQ0MsV0FBVyxFQUFDO0lBQWMsQ0FBQztJQUFDM0QsUUFBUSxFQUFDO01BQUM0RCw2QkFBNkIsRUFBQyxJQUFJO01BQUNDLGVBQWUsRUFBQ2pCLE9BQU87TUFBQ2tCLGlEQUFpRCxFQUFDLElBQUk7TUFBQ0MsMkJBQTJCLEVBQUMsSUFBSTtNQUFDQyw0QkFBNEIsRUFBQyxJQUFJO01BQUNDLHdCQUF3QixFQUFDO0lBQTJGO0VBQUMsQ0FBQyxDQUFDO0FBQzFpQixDQUFDLENBQUM7QUFFRjNJLElBQUksQ0FBQyxxSkFBcUosRUFBQyxPQUFNO0VBQUNlO0FBQUksQ0FBQyxFQUFDVSxJQUFJLEtBQUc7RUFBQSxJQUFBbUgscUJBQUEsRUFBQUMscUJBQUE7RUFDOUs3SSxJQUFJLENBQUM0QixVQUFVLENBQUMsTUFBTyxDQUFDO0VBQUMsTUFBTUMsQ0FBQyxHQUFDLE1BQU1qQiwyQkFBMkIsQ0FBQyxDQUFDO0VBQUMsTUFBTWtJLE1BQU0sR0FBQ2pJLFlBQVksQ0FBQ2dCLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDaUgsU0FBUyxFQUFDLFFBQVEsRUFBQyxZQUFZLEVBQUM7TUFBQ0MsVUFBVSxFQUFDLEtBQUs7TUFBQ2hILE9BQU8sRUFBQyxpQ0FBaUM7TUFBQ2lILGVBQWUsRUFBQztJQUFZLENBQUMsQ0FBQztJQUFDQyxTQUFTLEdBQUNySSxZQUFZLENBQUNnQixDQUFDLENBQUNDLENBQUMsQ0FBQ2lILFNBQVMsRUFBQyxXQUFXLEVBQUMsWUFBWSxFQUFDO01BQUNJLFNBQVMsRUFBQ3RILENBQUMsQ0FBQ3VILEtBQUssQ0FBQ2xILEVBQUU7TUFBQ21ILFNBQVMsRUFBQyxpQkFBaUI7TUFBQ3pCLEtBQUssRUFBQztRQUFDMEIsSUFBSSxFQUFDLFNBQVM7UUFBQzFCLEtBQUssRUFBQztNQUFJLENBQUM7TUFBQzJCLFNBQVMsRUFBQyxXQUFXO01BQUNDLFFBQVEsRUFBQzNILENBQUMsQ0FBQ2UsQ0FBQyxDQUFDVixFQUFFO01BQUN1SCxTQUFTLEVBQUMsQ0FBQ1gsTUFBTSxDQUFDNUcsRUFBRTtJQUFDLENBQUMsQ0FBQztJQUFDd0gsTUFBTSxHQUFDN0ksWUFBWSxDQUFDZ0IsQ0FBQyxDQUFDQyxDQUFDLENBQUNpSCxTQUFTLEVBQUMsV0FBVyxFQUFDLFlBQVksRUFBQztNQUFDSSxTQUFTLEVBQUN0SCxDQUFDLENBQUN1SCxLQUFLLENBQUNsSCxFQUFFO01BQUNtSCxTQUFTLEVBQUMsV0FBVztNQUFDekIsS0FBSyxFQUFDO1FBQUMwQixJQUFJLEVBQUMsU0FBUztRQUFDMUIsS0FBSyxFQUFDO01BQUksQ0FBQztNQUFDMkIsU0FBUyxFQUFDLFFBQVE7TUFBQ0MsUUFBUSxFQUFDM0gsQ0FBQyxDQUFDZSxDQUFDLENBQUNWLEVBQUU7TUFBQ3VILFNBQVMsRUFBQyxDQUFDWCxNQUFNLENBQUM1RyxFQUFFO0lBQUMsQ0FBQyxDQUFDO0lBQUN5SCxTQUFTLEdBQUM5SSxZQUFZLENBQUNnQixDQUFDLENBQUNDLENBQUMsQ0FBQ2lILFNBQVMsRUFBQyxRQUFRLEVBQUMsZUFBZSxFQUFDO01BQUNhLFNBQVMsRUFBQyxRQUFRO01BQUNDLFFBQVEsRUFBQ0gsTUFBTSxDQUFDeEgsRUFBRTtNQUFDMEYsS0FBSyxFQUFDO1FBQUMwQixJQUFJLEVBQUMsU0FBUztRQUFDMUIsS0FBSyxFQUFDO01BQUk7SUFBQyxDQUFDLENBQUM7RUFBQyxLQUFJLE1BQU10RSxDQUFDLElBQUksQ0FBQ3dGLE1BQU0sRUFBQ0ksU0FBUyxFQUFDUSxNQUFNLEVBQUNDLFNBQVMsQ0FBQyxFQUFDO0lBQUNyRyxDQUFDLENBQUN3RyxNQUFNLEdBQUMsV0FBVztJQUFDakksQ0FBQyxDQUFDQyxDQUFDLENBQUNzQixRQUFRLENBQUMyRyxJQUFJLENBQUN6RyxDQUFDLENBQUM7RUFBQztFQUFDLE1BQU1wRCxJQUFJLENBQUNhLElBQUksRUFBQ2MsQ0FBQyxDQUFDQyxDQUFDLENBQUM7RUFBQyxNQUFNdEIsVUFBVSxDQUFDTyxJQUFJLEVBQUMsT0FBTyxFQUFDYyxDQUFDLENBQUNrRSxLQUFLLENBQUM5RSxJQUFJLENBQUM7RUFBQyxNQUFNK0ksTUFBTSxHQUFDakosSUFBSSxDQUFDaUIsT0FBTyxDQUFDLDZCQUE2QixDQUFDO0VBQUMsTUFBTS9CLE1BQU0sQ0FBQytKLE1BQU0sQ0FBQ2hJLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNrRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQ25oQyxLQUFJLE1BQU0sQ0FBQytELENBQUMsRUFBQ3ZILE1BQU0sRUFBQ3dILElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUNySSxDQUFDLENBQUNjLENBQUMsRUFBQyxPQUFPLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQ2QsQ0FBQyxDQUFDZSxDQUFDLEVBQUMsU0FBUyxDQUFDLENBQUMsRUFBVTtJQUFDLE1BQU1vSCxNQUFNLENBQUNoSixTQUFTLENBQUMsUUFBUSxFQUFDO01BQUNDLElBQUksRUFBQyxRQUFRO01BQUNDLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUFDLE1BQU02SSxNQUFNLENBQUNuRCxVQUFVLENBQUMsS0FBSyxHQUFDb0QsQ0FBQyxFQUFDO01BQUMvSSxLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQzRGLFlBQVksQ0FBQ3BFLE1BQU0sQ0FBQ1IsRUFBRSxDQUFDO0lBQUMsTUFBTThILE1BQU0sQ0FBQ25ELFVBQVUsQ0FBQyxLQUFLLEdBQUNvRCxDQUFDLEdBQUMsS0FBSyxFQUFDO01BQUMvSSxLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQzRGLFlBQVksQ0FBQ29ELElBQUksQ0FBQztFQUFDO0VBQzVSLE1BQU1uSixJQUFJLENBQUNpQixPQUFPLENBQUMsNERBQTRELENBQUMsQ0FBQ1MsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0VBQUMsTUFBTWhDLFVBQVUsQ0FBQ00sSUFBSSxDQUFDO0VBQ25JLEtBQUksTUFBTTJCLE1BQU0sSUFBSSxDQUFDYixDQUFDLENBQUNjLENBQUMsRUFBQ2QsQ0FBQyxDQUFDZSxDQUFDLENBQUMsRUFBQztJQUFDLE1BQU1wQyxVQUFVLENBQUNPLElBQUksRUFBQyxXQUFXLEVBQUMyQixNQUFNLENBQUN6QixJQUFJLENBQUM7SUFBQyxNQUFNaEIsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQ2hCLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ0MsSUFBSSxFQUFDLElBQUlrSixNQUFNLENBQUMsR0FBRyxHQUFDdEksQ0FBQyxDQUFDa0UsS0FBSyxDQUFDOUUsSUFBSTtJQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMrQixXQUFXLENBQUMsQ0FBQztJQUFDLE1BQU1qQyxJQUFJLENBQUNpQixPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQ2hCLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ0MsSUFBSSxFQUFDLElBQUlrSixNQUFNLENBQUMsR0FBRyxHQUFDdEksQ0FBQyxDQUFDa0UsS0FBSyxDQUFDOUUsSUFBSTtJQUFDLENBQUMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztJQUFDLE1BQU1sQixNQUFNLENBQUNjLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUM5RCxDQUFDLENBQUNrRSxLQUFLLENBQUM5RSxJQUFJLENBQUM7SUFBQyxNQUFNaEIsTUFBTSxDQUFDYyxJQUFJLENBQUM4RixVQUFVLENBQUMsU0FBUyxFQUFDO01BQUMzRixLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDaUIsV0FBVyxDQUFDLE9BQU8sQ0FBQztJQUFDLE1BQU1sQyxNQUFNLENBQUNjLElBQUksQ0FBQzhGLFVBQVUsQ0FBQyxTQUFTLEVBQUM7TUFBQzNGLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNpQixXQUFXLENBQUMsU0FBUyxDQUFDO0VBQUM7RUFDbGhCLEtBQUksTUFBTStILElBQUksSUFBSSxDQUFDLFdBQVcsRUFBQyxVQUFVLENBQUMsRUFBQztJQUFDLE1BQU1uSixJQUFJLENBQUM4RixVQUFVLENBQUMsU0FBUyxFQUFDO01BQUMzRixLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQzRGLFlBQVksQ0FBQ29ELElBQUksQ0FBQztJQUFDLE1BQU16SixVQUFVLENBQUNNLElBQUksQ0FBQztJQUFDLE1BQU1kLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDOEYsVUFBVSxDQUFDLFNBQVMsRUFBQztNQUFDM0YsS0FBSyxFQUFDO0lBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2lCLFdBQVcsQ0FBQyxPQUFPLENBQUM7RUFBQztFQUMvTSxNQUFNaUksY0FBYyxHQUFDLE1BQU1oSyxNQUFNLENBQUNXLElBQUksQ0FBQztFQUFDZCxNQUFNLENBQUNtSyxjQUFjLENBQUNsSCxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDSyxNQUFNLENBQUNILENBQUMsSUFBRUEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsV0FBVyxJQUFFRCxDQUFDLENBQUNDLElBQUksS0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDaEIsT0FBTyxDQUFDVixDQUFDLENBQUNDLENBQUMsQ0FBQ3NCLFFBQVEsQ0FBQ0ssTUFBTSxDQUFDSCxDQUFDLElBQUVBLENBQUMsQ0FBQ0MsSUFBSSxLQUFHLFdBQVcsSUFBRUQsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsUUFBUSxDQUFDLENBQUM7RUFBQ3RELE1BQU0sRUFBQTJJLHFCQUFBLEdBQUN3QixjQUFjLENBQUNsSCxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUNrRSxLQUFLLENBQUM3RCxFQUFFLENBQUMsY0FBQTBHLHFCQUFBLHVCQUFqRUEscUJBQUEsQ0FBbUV4RyxJQUFJLENBQUMsQ0FBQzBGLGFBQWEsQ0FBQztJQUFDdEUsWUFBWSxFQUFDLENBQUM7TUFBQzZHLFdBQVcsRUFBQ3hJLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFO01BQUNnSSxJQUFJLEVBQUM7SUFBTyxDQUFDLEVBQUM7TUFBQ0csV0FBVyxFQUFDeEksQ0FBQyxDQUFDZSxDQUFDLENBQUNWLEVBQUU7TUFBQ2dJLElBQUksRUFBQztJQUFVLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDelksTUFBTTFKLFVBQVUsQ0FBQ08sSUFBSSxFQUFDLE9BQU8sRUFBQ2MsQ0FBQyxDQUFDa0UsS0FBSyxDQUFDOUUsSUFBSSxDQUFDO0VBQUMsTUFBTVAsUUFBUSxDQUFDSyxJQUFJLEVBQUNxQixJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDb0IsWUFBWSxHQUFDLENBQUM7TUFBQzZHLFdBQVcsRUFBQ3hJLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFO01BQUNnSSxJQUFJLEVBQUM7SUFBTyxDQUFDLEVBQUM7TUFBQ0csV0FBVyxFQUFDeEksQ0FBQyxDQUFDZSxDQUFDLENBQUNWLEVBQUU7TUFBQ2dJLElBQUksRUFBQyxRQUFRO01BQUNJLFdBQVcsRUFBQyxDQUFDcEIsU0FBUyxDQUFDaEgsRUFBRTtJQUFDLENBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU16QixVQUFVLENBQUNNLElBQUksQ0FBQztFQUFDLE1BQU13SixLQUFLLEdBQUMsTUFBTW5LLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0VBQUNkLE1BQU0sRUFBQTRJLHFCQUFBLEdBQUMwQixLQUFLLENBQUNySCxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUNrRSxLQUFLLENBQUM3RCxFQUFFLENBQUMsY0FBQTJHLHFCQUFBLHVCQUF4REEscUJBQUEsQ0FBMER6RyxJQUFJLENBQUMsQ0FBQzBGLGFBQWEsQ0FBQztJQUFDdEUsWUFBWSxFQUFDLENBQUM7TUFBQzZHLFdBQVcsRUFBQ3hJLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFO01BQUNnSSxJQUFJLEVBQUM7SUFBTyxDQUFDLEVBQUM7TUFBQ0csV0FBVyxFQUFDeEksQ0FBQyxDQUFDZSxDQUFDLENBQUNWLEVBQUU7TUFBQ2dJLElBQUksRUFBQyxRQUFRO01BQUNJLFdBQVcsRUFBQyxDQUFDcEIsU0FBUyxDQUFDaEgsRUFBRTtJQUFDLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDMWIsTUFBTTFCLFVBQVUsQ0FBQ08sSUFBSSxFQUFDLE9BQU8sRUFBQ2MsQ0FBQyxDQUFDa0UsS0FBSyxDQUFDOUUsSUFBSSxDQUFDO0VBQUMsTUFBTVAsUUFBUSxDQUFDSyxJQUFJLEVBQUNxQixJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDb0IsWUFBWSxHQUFDLENBQUM7TUFBQzZHLFdBQVcsRUFBQ3hJLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFO01BQUNnSSxJQUFJLEVBQUM7SUFBTyxDQUFDLEVBQUM7TUFBQ0csV0FBVyxFQUFDeEksQ0FBQyxDQUFDZSxDQUFDLENBQUNWLEVBQUU7TUFBQ2dJLElBQUksRUFBQyxVQUFVO01BQUNJLFdBQVcsRUFBQyxDQUFDeEIsTUFBTSxDQUFDNUcsRUFBRSxDQUFDO01BQUNzSSxrQkFBa0IsRUFBQyxDQUFDYixTQUFTLENBQUN6SCxFQUFFO0lBQUMsQ0FBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTXpCLFVBQVUsQ0FBQ00sSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDZ0MsTUFBTSxDQUFDLENBQUM7RUFBQyxNQUFNOUMsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQ2dCLFdBQVcsQ0FBQyxDQUFDO0VBQUMsTUFBTUMsSUFBSSxHQUFDLE1BQU03QyxNQUFNLENBQUNXLElBQUksQ0FBQztJQUFDMEosS0FBSyxHQUFDeEgsSUFBSSxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUNrRSxLQUFLLENBQUM3RCxFQUFFLENBQUU7RUFBQ2pDLE1BQU0sQ0FBQ3dLLEtBQUssQ0FBQ2xILElBQUksS0FBRyxPQUFPLElBQUVrSCxLQUFLLENBQUNySSxJQUFJLENBQUNvQixZQUFZLENBQUMsQ0FBQ2pCLE9BQU8sQ0FBQyxDQUFDO0lBQUM4SCxXQUFXLEVBQUN4SSxDQUFDLENBQUNjLENBQUMsQ0FBQ1QsRUFBRTtJQUFDZ0ksSUFBSSxFQUFDO0VBQU8sQ0FBQyxFQUFDO0lBQUNHLFdBQVcsRUFBQ3hJLENBQUMsQ0FBQ2UsQ0FBQyxDQUFDVixFQUFFO0lBQUNnSSxJQUFJLEVBQUMsVUFBVTtJQUFDSSxXQUFXLEVBQUMsQ0FBQ3hCLE1BQU0sQ0FBQzVHLEVBQUUsQ0FBQztJQUFDc0ksa0JBQWtCLEVBQUMsQ0FBQ2IsU0FBUyxDQUFDekgsRUFBRTtFQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUNqQyxNQUFNLENBQUNnRCxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNLLE1BQU0sQ0FBQ0gsQ0FBQyxJQUFFQSxDQUFDLENBQUNDLElBQUksS0FBRyxXQUFXLElBQUVELENBQUMsQ0FBQ0MsSUFBSSxLQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUNoQixPQUFPLENBQUNWLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDc0IsUUFBUSxDQUFDSyxNQUFNLENBQUNILENBQUMsSUFBRUEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsV0FBVyxJQUFFRCxDQUFDLENBQUNDLElBQUksS0FBRyxRQUFRLENBQUMsQ0FBQztFQUNod0IsTUFBTWhELFFBQVEsQ0FBQ2tCLElBQUksRUFBQyxzQkFBc0IsRUFBQztJQUFDeUMsS0FBSyxFQUFDO01BQUN3RyxLQUFLLEVBQUM3SSxDQUFDLENBQUNrRSxLQUFLLENBQUM3RCxFQUFFO01BQUN5SSxtQkFBbUIsRUFBQztJQUFDLENBQUM7SUFBQ3ZHLElBQUksRUFBQztNQUFDd0csTUFBTSxFQUFDLENBQUMvSSxDQUFDLENBQUNjLENBQUMsQ0FBQ1QsRUFBRSxFQUFDTCxDQUFDLENBQUNlLENBQUMsQ0FBQ1YsRUFBRSxDQUFDO01BQUMySSx1QkFBdUIsRUFBQyxDQUFDLE9BQU8sRUFBQyxTQUFTLENBQUM7TUFBQ0MsU0FBUyxFQUFDO0lBQUksQ0FBQztJQUFDeEcsSUFBSSxFQUFDO01BQUN5Ryx3Q0FBd0MsRUFBQztJQUFJLENBQUM7SUFBQ3JHLFFBQVEsRUFBQztNQUFDc0csZ0RBQWdELEVBQUMsSUFBSTtNQUFDQyw4QkFBOEIsRUFBQy9CLFNBQVMsQ0FBQ2hILEVBQUU7TUFBQ2dKLHlCQUF5QixFQUFDdkIsU0FBUyxDQUFDekgsRUFBRTtNQUFDaUosd0NBQXdDLEVBQUMsSUFBSTtNQUFDQyxxQ0FBcUMsRUFBQyxJQUFJO01BQUNDLHFCQUFxQixFQUFDO0lBQThGLENBQUM7SUFBQ3pFLGNBQWMsRUFBQ3RHLE1BQU0sQ0FBQzJDLElBQUksQ0FBQ2dCLEtBQUs7RUFBQyxDQUFDLENBQUM7QUFDL21CLENBQUMsQ0FBQztBQUVGakUsSUFBSSxDQUFDLDRJQUE0SSxFQUFDLE9BQU07RUFBQ2UsSUFBSTtFQUFDUztBQUFPLENBQUMsRUFBQ0MsSUFBSSxLQUFHO0VBQUEsSUFBQTZKLHNCQUFBLEVBQUFDLHNCQUFBLEVBQUFDLHNCQUFBO0VBQzdLeEwsSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE1BQU8sQ0FBQztFQUFDLE1BQU1DLENBQUMsR0FBQyxNQUFNakIsMkJBQTJCLENBQUMsQ0FBQztFQUFDLE1BQU02SyxZQUFZLEdBQUNDLGVBQWUsQ0FBQzdKLENBQUMsQ0FBQ2dDLEdBQUcsQ0FBQzhILE9BQU8sQ0FBQ3ZJLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ3BCLEVBQUUsS0FBR0wsQ0FBQyxDQUFDK0osS0FBSyxDQUFDMUosRUFBRSxDQUFDLENBQUVFLElBQUksQ0FBQztFQUFDLE1BQU15SixVQUFVLEdBQUNoSyxDQUFDLENBQUNDLENBQUMsQ0FBQ3NCLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ3BCLEVBQUUsS0FBR0wsQ0FBQyxDQUFDK0osS0FBSyxDQUFDMUosRUFBRSxDQUFFO0VBQUMsSUFBRzJKLFVBQVUsQ0FBQ3RJLElBQUksS0FBRyxPQUFPLEVBQUMsTUFBTXVJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztFQUFDRCxVQUFVLENBQUN6SixJQUFJLENBQUMySixTQUFTLEdBQUMsRUFBRTtFQUFDLE1BQU03TCxJQUFJLENBQUNhLElBQUksRUFBQ2MsQ0FBQyxDQUFDQyxDQUFDLENBQUM7RUFBQyxNQUFNdEIsVUFBVSxDQUFDTyxJQUFJLEVBQUMsT0FBTyxFQUFDYyxDQUFDLENBQUMrSixLQUFLLENBQUMzSyxJQUFJLENBQUM7RUFBQyxNQUFNRixJQUFJLENBQUNDLFNBQVMsQ0FBQyxLQUFLLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLElBQUk7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsS0FBSSxNQUFNNkssS0FBSyxJQUFJLENBQUNuSyxDQUFDLENBQUNvSyxPQUFPLEVBQUNwSyxDQUFDLENBQUNxSyxHQUFHLENBQUMsRUFBQyxNQUFNbkwsSUFBSSxDQUFDaUIsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUM2RSxVQUFVLENBQUMsUUFBUSxFQUFDO0lBQUMzRixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQzRGLFlBQVksQ0FBQ2tGLEtBQUssQ0FBQzlKLEVBQUUsQ0FBQztFQUFDLE1BQU16QixVQUFVLENBQUNNLElBQUksQ0FBQztFQUFDLE1BQU1LLE9BQU8sQ0FBQ0wsSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDOEYsVUFBVSxDQUFDLFFBQVEsRUFBQztJQUFDM0YsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM0RixZQUFZLENBQUMsUUFBUSxDQUFDO0VBQUMsTUFBTW1GLE9BQU8sR0FBQ2xMLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyw0QkFBNEIsR0FBQ0gsQ0FBQyxDQUFDb0ssT0FBTyxDQUFDL0osRUFBRSxHQUFDLElBQUksQ0FBQztJQUFDZ0ssR0FBRyxHQUFDbkwsSUFBSSxDQUFDaUIsT0FBTyxDQUFDLDRCQUE0QixHQUFDSCxDQUFDLENBQUNxSyxHQUFHLENBQUNoSyxFQUFFLEdBQUMsSUFBSSxDQUFDO0VBQ3R6QixNQUFNK0osT0FBTyxDQUFDakssT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNiLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTUosSUFBSSxDQUFDQyxTQUFTLENBQUMsS0FBSyxFQUFDO0lBQUNDLElBQUksRUFBQyxJQUFJO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1KLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyxxREFBcUQsQ0FBQyxDQUFDUyxJQUFJLENBQUMscUJBQXFCLENBQUM7RUFBQyxNQUFNaEMsVUFBVSxDQUFDTSxJQUFJLENBQUM7RUFBQyxNQUFNTSxXQUFXLENBQUNOLElBQUksQ0FBQztFQUFDLE1BQU1tTCxHQUFHLENBQUNsSyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2IsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNSixJQUFJLENBQUNDLFNBQVMsQ0FBQyxLQUFLLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLElBQUk7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDaUIsT0FBTyxDQUFDLHFEQUFxRCxDQUFDLENBQUMsQ0FBQ0csV0FBVyxDQUFDLHFCQUFxQixDQUFDO0VBQUMsTUFBTWQsV0FBVyxDQUFDTixJQUFJLENBQUM7RUFDemYsTUFBTWtMLE9BQU8sQ0FBQ2pMLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ2dNLE9BQU8sQ0FBQ2pLLE9BQU8sQ0FBQyxrQkFBa0IsR0FBQ0gsQ0FBQyxDQUFDK0osS0FBSyxDQUFDMUosRUFBRSxHQUFDLElBQUksQ0FBQyxDQUFDLENBQUNnRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTWpHLE1BQU0sQ0FBQ2lNLEdBQUcsQ0FBQ2xLLE9BQU8sQ0FBQyxrQkFBa0IsR0FBQ0gsQ0FBQyxDQUFDK0osS0FBSyxDQUFDMUosRUFBRSxHQUFDLElBQUksQ0FBQyxDQUFDLENBQUNnRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQ25PLE1BQU1uRixJQUFJLENBQUNnQyxNQUFNLENBQUMsQ0FBQztFQUFDLE1BQU05QyxNQUFNLENBQUNjLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDZ0IsV0FBVyxDQUFDLENBQUM7RUFBQyxNQUFNQyxJQUFJLEdBQUMsTUFBTTdDLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0lBQUM2SyxLQUFLLEdBQUMzSSxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNwQixFQUFFLEtBQUdMLENBQUMsQ0FBQytKLEtBQUssQ0FBQzFKLEVBQUUsQ0FBRTtFQUFDakMsTUFBTSxDQUFDZ0QsSUFBSSxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDSyxNQUFNLENBQUNILENBQUMsSUFBRUEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsT0FBTyxJQUFFRCxDQUFDLENBQUNwQixFQUFFLEtBQUdMLENBQUMsQ0FBQytKLEtBQUssQ0FBQzFKLEVBQUUsQ0FBQyxDQUFDLENBQUN3QixZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQUN6RCxNQUFNLENBQUMyTCxLQUFLLENBQUNySSxJQUFJLEtBQUcsT0FBTyxJQUFFcUksS0FBSyxDQUFDeEosSUFBSSxDQUFDMkosU0FBUyxDQUFDLENBQUN4SixPQUFPLENBQUMsQ0FBQ1YsQ0FBQyxDQUFDcUssR0FBRyxDQUFDaEssRUFBRSxDQUFDLENBQUM7RUFBQ2pDLE1BQU0sQ0FBQzJMLEtBQUssQ0FBQ3JJLElBQUksS0FBRyxPQUFPLElBQUVxSSxLQUFLLENBQUN4SixJQUFJLENBQUMrSixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM3SixJQUFJLENBQUMsQ0FBQ3lCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztFQUFDOUQsTUFBTSxFQUFBcUwsc0JBQUEsR0FBQ3JJLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ3BCLEVBQUUsS0FBR0wsQ0FBQyxDQUFDVyxJQUFJLENBQUNOLEVBQUUsQ0FBQyxjQUFBb0osc0JBQUEsdUJBQXREQSxzQkFBQSxDQUF3RGxKLElBQUksQ0FBQyxDQUFDRyxPQUFPLENBQUNWLENBQUMsQ0FBQ1csSUFBSSxDQUFDSixJQUFJLENBQUM7RUFBQ25DLE1BQU0sRUFBQXNMLHNCQUFBLEdBQUN0SSxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUSxTQUFTLENBQUNOLElBQUksQ0FBQ08sQ0FBQyxJQUFFQSxDQUFDLENBQUMxQixFQUFFLEtBQUdMLENBQUMsQ0FBQ2dDLEdBQUcsQ0FBQzNCLEVBQUUsQ0FBQyxjQUFBcUosc0JBQUEsZ0JBQUFBLHNCQUFBLEdBQXREQSxzQkFBQSxDQUF3REksT0FBTyxDQUFDdkksUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUMrSixLQUFLLENBQUMxSixFQUFFLENBQUMsY0FBQXFKLHNCQUFBLHVCQUFuR0Esc0JBQUEsQ0FBcUduSixJQUFJLENBQUMsQ0FBQ0csT0FBTyxDQUFDa0osWUFBWSxDQUFDO0VBQ3RvQixNQUFNekgsUUFBUSxHQUFDLE1BQU1yRCxjQUFjLENBQUNhLE9BQU8sRUFBQ3lCLElBQUksQ0FBQ2dCLEtBQUssQ0FBQztFQUFDaEUsTUFBTSxFQUFBdUwsc0JBQUEsR0FBQ3hILFFBQVEsQ0FBQ2QsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ3BCLEVBQUUsS0FBR0wsQ0FBQyxDQUFDK0osS0FBSyxDQUFDMUosRUFBRSxDQUFDLGNBQUFzSixzQkFBQSx1QkFBM0RBLHNCQUFBLENBQTZEcEosSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQ3FKLEtBQUssQ0FBQ3hKLElBQUksQ0FBQztFQUNySixNQUFNN0IsUUFBUSxDQUFDa0IsSUFBSSxFQUFDLHNCQUFzQixFQUFDO0lBQUN5QyxLQUFLLEVBQUM7TUFBQ2tJLFNBQVMsRUFBQ3ZLLENBQUMsQ0FBQytKLEtBQUssQ0FBQzFKLEVBQUU7TUFBQ21LLFVBQVUsRUFBQyxDQUFDeEssQ0FBQyxDQUFDb0ssT0FBTyxDQUFDL0osRUFBRSxFQUFDTCxDQUFDLENBQUNxSyxHQUFHLENBQUNoSyxFQUFFO0lBQUMsQ0FBQztJQUFDa0MsSUFBSSxFQUFDO01BQUNrSSw4Q0FBOEMsRUFBQyxJQUFJO01BQUNDLDJCQUEyQixFQUFDO0lBQUksQ0FBQztJQUFDakksSUFBSSxFQUFDO01BQUNrSSx1QkFBdUIsRUFBQztJQUFJLENBQUM7SUFBQzlILFFBQVEsRUFBQztNQUFDK0gsdUJBQXVCLEVBQUMsSUFBSTtNQUFDQyxnQ0FBZ0MsRUFBQztJQUFJLENBQUM7SUFBQ0MsZ0NBQWdDLEVBQUM7RUFBSSxDQUFDLENBQUM7QUFDbFcsQ0FBQyxDQUFDO0FBRUYzTSxJQUFJLENBQUMsdUxBQXVMLEVBQUMsT0FBTTtFQUFDZTtBQUFJLENBQUMsRUFBQ1UsSUFBSSxLQUFHO0VBQUEsSUFBQW1MLHNCQUFBO0VBQ2hONU0sSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE1BQU8sQ0FBQztFQUFDLE1BQU1DLENBQUMsR0FBQyxNQUFNakIsMkJBQTJCLENBQUMsQ0FBQztFQUFDLE1BQU1WLElBQUksQ0FBQ2EsSUFBSSxFQUFDYyxDQUFDLENBQUNDLENBQUMsQ0FBQztFQUFDLE1BQU10QixVQUFVLENBQUNPLElBQUksRUFBQyxPQUFPLEVBQUNjLENBQUMsQ0FBQytKLEtBQUssQ0FBQzNLLElBQUksQ0FBQztFQUFDLE1BQU1GLElBQUksQ0FBQ0MsU0FBUyxDQUFDLEtBQUssRUFBQztJQUFDQyxJQUFJLEVBQUMsSUFBSTtJQUFDQyxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFDaE0sTUFBTUosSUFBSSxDQUFDOEYsVUFBVSxDQUFDLE1BQU0sRUFBQztJQUFDM0YsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUM0RixZQUFZLENBQUNqRixDQUFDLENBQUNjLENBQUMsQ0FBQ1QsRUFBRSxDQUFDO0VBQy9ELEtBQUksTUFBTSxDQUFDMkssR0FBRyxFQUFDdkssSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBQyxXQUFXLENBQUMsRUFBQyxDQUFDLFdBQVcsRUFBQyxhQUFhLENBQUMsRUFBQyxDQUFDLFNBQVMsRUFBQyxtQkFBbUIsQ0FBQyxFQUFDLENBQUMsZ0JBQWdCLEVBQUMsZUFBZSxDQUFDLENBQUMsRUFBVSxNQUFNdkIsSUFBSSxDQUFDaUIsT0FBTyxDQUFDLGVBQWUsR0FBQzZLLEdBQUcsR0FBQyxvQ0FBb0MsQ0FBQyxDQUFDcEssSUFBSSxDQUFDSCxJQUFJLENBQUM7RUFDL08sTUFBTTdCLFVBQVUsQ0FBQ00sSUFBSSxDQUFDO0VBQUMsTUFBTVAsVUFBVSxDQUFDTyxJQUFJLEVBQUMsTUFBTSxFQUFDYyxDQUFDLENBQUNpTCxJQUFJLENBQUM3TCxJQUFJLENBQUM7RUFBQyxNQUFNRixJQUFJLENBQUNpQixPQUFPLENBQUMsaUNBQWlDLENBQUMsQ0FBQzZFLFVBQVUsQ0FBQyxRQUFRLEVBQUM7SUFBQzNGLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNEYsWUFBWSxDQUFDakYsQ0FBQyxDQUFDK0osS0FBSyxDQUFDMUosRUFBRSxDQUFDO0VBQUMsTUFBTXpCLFVBQVUsQ0FBQ00sSUFBSSxDQUFDO0VBQ3hNLE1BQU1QLFVBQVUsQ0FBQ08sSUFBSSxFQUFDLE9BQU8sRUFBQ2MsQ0FBQyxDQUFDa0wsQ0FBQyxDQUFDOUwsSUFBSSxDQUFDO0VBQUMsTUFBTUYsSUFBSSxDQUFDQyxTQUFTLENBQUMsS0FBSyxFQUFDO0lBQUNDLElBQUksRUFBQyxJQUFJO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1KLElBQUksQ0FBQ2lCLE9BQU8sQ0FBQyxxREFBcUQsQ0FBQyxDQUFDUyxJQUFJLENBQUMsbUJBQW1CLENBQUM7RUFBQyxNQUFNaEMsVUFBVSxDQUFDTSxJQUFJLENBQUM7RUFBQyxNQUFNSyxPQUFPLENBQUNMLElBQUksQ0FBQztFQUFDLE1BQU1BLElBQUksQ0FBQzhGLFVBQVUsQ0FBQyxRQUFRLEVBQUM7SUFBQzNGLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDNEYsWUFBWSxDQUFDLFdBQVcsQ0FBQztFQUFDLE1BQU1qRSxJQUFJLEdBQUM5QixJQUFJLENBQUNpQixPQUFPLENBQUMsNEJBQTRCLEdBQUNILENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFLEdBQUMsSUFBSSxDQUFDO0VBQUMsS0FBSSxNQUFNSSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUMsYUFBYSxFQUFDLG1CQUFtQixFQUFDLGVBQWUsQ0FBQyxFQUFDLE1BQU1yQyxNQUFNLENBQUM0QyxJQUFJLENBQUNiLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUNyRCxJQUFJLENBQUM7RUFBQyxNQUFNTyxJQUFJLENBQUM3QixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQ1ksQ0FBQyxDQUFDaUwsSUFBSSxDQUFDN0wsSUFBSSxHQUFDLFFBQVEsR0FBQ1ksQ0FBQyxDQUFDK0osS0FBSyxDQUFDM0ssSUFBSSxHQUFDLEtBQUs7SUFBQ0MsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ2MsSUFBSSxDQUFDaUIsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQzJELGFBQWEsQ0FBQzlELENBQUMsQ0FBQytKLEtBQUssQ0FBQzNLLElBQUksQ0FBQztFQUMvckIsTUFBTUYsSUFBSSxDQUFDZ0MsTUFBTSxDQUFDLENBQUM7RUFBQyxNQUFNOUMsTUFBTSxDQUFDYyxJQUFJLENBQUNpQixPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQ2dCLFdBQVcsQ0FBQyxDQUFDO0VBQUMsTUFBTUMsSUFBSSxHQUFDLE1BQU03QyxNQUFNLENBQUNXLElBQUksQ0FBQztJQUFDNkMsQ0FBQyxHQUFDWCxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNwQixFQUFFLEtBQUdMLENBQUMsQ0FBQytKLEtBQUssQ0FBQzFKLEVBQUUsQ0FBRTtJQUFDNkssQ0FBQyxHQUFDOUosSUFBSSxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUNrTCxDQUFDLENBQUM3SyxFQUFFLENBQUU7RUFBQ2pDLE1BQU0sQ0FBQzJELENBQUMsQ0FBQ0wsSUFBSSxLQUFHLE9BQU8sSUFBRUssQ0FBQyxDQUFDeEIsSUFBSSxDQUFDNEssS0FBSyxDQUFDLENBQUNqSixJQUFJLENBQUNsQyxDQUFDLENBQUNjLENBQUMsQ0FBQ1QsRUFBRSxDQUFDO0VBQUMsS0FBSSxNQUFNMkssR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFDLFdBQVcsRUFBQyxTQUFTLEVBQUMsZ0JBQWdCLENBQUMsRUFBVTVNLE1BQU0sQ0FBQzhNLENBQUMsQ0FBQ3hKLElBQUksS0FBRyxPQUFPLElBQUV3SixDQUFDLENBQUMzSyxJQUFJLENBQUN5SyxHQUFHLENBQUMsQ0FBQyxDQUFDdEssT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUFDdEMsTUFBTSxDQUFDOE0sQ0FBQyxDQUFDakQsTUFBTSxDQUFDLENBQUMvRixJQUFJLENBQUMsV0FBVyxDQUFDO0VBQUM5RCxNQUFNLEVBQUEyTSxzQkFBQSxHQUFDM0osSUFBSSxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDcEIsRUFBRSxLQUFHTCxDQUFDLENBQUNpTCxJQUFJLENBQUM1SyxFQUFFLENBQUMsY0FBQTBLLHNCQUFBLHVCQUF0REEsc0JBQUEsQ0FBd0R4SyxJQUFJLENBQUMsQ0FBQzBGLGFBQWEsQ0FBQztJQUFDbUYsZ0JBQWdCLEVBQUMsQ0FBQ3BMLENBQUMsQ0FBQytKLEtBQUssQ0FBQzFKLEVBQUU7RUFBQyxDQUFDLENBQUM7RUFDbGlCLE1BQU0zQixRQUFRLENBQUNrQixJQUFJLEVBQUMsOEJBQThCLEVBQUM7SUFBQ3lMLEdBQUcsRUFBQztNQUFDaEosS0FBSyxFQUFDO1FBQUNpSixrQkFBa0IsRUFBQ3RMLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDVCxFQUFFO1FBQUNrTCxDQUFDLEVBQUN2TCxDQUFDLENBQUMrSixLQUFLLENBQUMxSixFQUFFO1FBQUNtTCxVQUFVLEVBQUN4TCxDQUFDLENBQUNrTCxDQUFDLENBQUM3SztNQUFFLENBQUM7TUFBQ2tDLElBQUksRUFBQztRQUFDa0osNkNBQTZDLEVBQUMsSUFBSTtRQUFDQyxnQkFBZ0IsRUFBQztNQUFJLENBQUM7TUFBQ2pKLElBQUksRUFBQztRQUFDa0osOEJBQThCLEVBQUM7TUFBSSxDQUFDO01BQUM5SSxRQUFRLEVBQUM7UUFBQytJLGdCQUFnQixFQUFDLElBQUk7UUFBQ0MsMkJBQTJCLEVBQUM7TUFBSTtJQUFDLENBQUM7SUFBQ0MsR0FBRyxFQUFDO01BQUN6SixLQUFLLEVBQUM7UUFBQzBKLHdCQUF3QixFQUFDL0wsQ0FBQyxDQUFDYyxDQUFDLENBQUNUO01BQUUsQ0FBQztNQUFDa0MsSUFBSSxFQUFDO1FBQUN5Six1QkFBdUIsRUFBQ2hNLENBQUMsQ0FBQytKLEtBQUssQ0FBQzFKO01BQUUsQ0FBQztNQUFDb0MsSUFBSSxFQUFDO1FBQUN3SixnQ0FBZ0MsRUFBQztNQUFJLENBQUM7TUFBQ3BKLFFBQVEsRUFBQztRQUFDcUosb0JBQW9CLEVBQUM7TUFBSTtJQUFDLENBQUM7SUFBQ25ILGNBQWMsRUFBQ3RHLE1BQU0sQ0FBQzJDLElBQUksQ0FBQ2dCLEtBQUs7RUFBQyxDQUFDLENBQUM7QUFDdGdCLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==