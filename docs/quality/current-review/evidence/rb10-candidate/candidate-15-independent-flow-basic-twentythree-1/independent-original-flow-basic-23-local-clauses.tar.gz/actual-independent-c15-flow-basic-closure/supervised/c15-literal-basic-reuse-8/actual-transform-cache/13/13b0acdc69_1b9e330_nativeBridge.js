// b1fd6b84dfe623edaa8fc15f68fd1b16f81a936e
import { newId, validateProject } from '../domain/model';
import { toSyncDocument } from './adapter';
import { clone, createSyncOperation, sameValue, SyncProtocolError } from './protocol';
import { threeWayMerge } from './merge';
/** Server record revisions and local save revisions have different meanings. */
export function nativeDocuments(project, revision) {
  const {
    entities,
    relations,
    history: _history,
    ...header
  } = project;
  return [toSyncDocument({
    ...header,
    id: project.projectId,
    kind: 'project',
    visibility: 'private',
    revision,
    entityIds: entities.map(e => e.id),
    relationIds: relations.map(r => r.id)
  }), ...entities.map(e => {
    const doc = toSyncDocument({
      ...e,
      revision
    });
    doc.fields.createdAt = e.createdAt;
    return doc;
  }), ...relations.map(r => toSyncDocument({
    ...r,
    revision
  }))];
}
export function sameDocumentContent(a, b) {
  return sameValue(a ? {
    fields: a.fields,
    tombstone: a.tombstone
  } : null, b ? {
    fields: b.fields,
    tombstone: b.tombstone
  } : null);
}
function inflate(doc) {
  const result = {
    id: doc.id,
    projectId: doc.projectId,
    revision: doc.revision
  };
  for (const [key, value] of Object.entries(doc.fields)) {
    if (key.startsWith('data.')) {
      var _result$data;
      const nested = key.slice(5);
      if (!nested || nested.includes('.') || ['__proto__', 'prototype', 'constructor'].includes(nested)) throw new SyncProtocolError('PROTOCOL_INVALID');
      (_result$data = result.data) !== null && _result$data !== void 0 ? _result$data : result.data = {};
      result.data[nested] = clone(value);
    } else {
      if (['id', 'projectId', 'revision', 'updatedAt', 'deletedAt', 'deletionOperationId', '__proto__', 'prototype', 'constructor'].includes(key)) throw new SyncProtocolError('PROTOCOL_INVALID');
      result[key] = clone(value);
    }
  }
  if (doc.tombstone) {
    result.deletedAt = doc.tombstone.deletedAt;
    result.deletionOperationId = doc.tombstone.operationId;
  }
  return result;
}
/** Construct a native candidate; validation and durable integrity are performed before the transaction. */
export function nativeFromDocuments(previous, documents, now) {
  const byId = new Map(documents.map(doc => [doc.id, doc]));
  if (byId.size !== documents.length) throw new SyncProtocolError('PROTOCOL_INVALID');
  const head = byId.get(previous.projectId);
  if (!head || head.fields.kind !== 'project' || head.tombstone) throw new SyncProtocolError('PROTOCOL_INVALID');
  const raw = inflate(head),
    {
      id: _id,
      kind: _kind,
      visibility: _visibility,
      entityIds,
      relationIds,
      ...header
    } = raw;
  if (!Array.isArray(entityIds) || !Array.isArray(relationIds) || [...entityIds, ...relationIds].some(id => typeof id !== 'string') || new Set([...entityIds, ...relationIds, head.id]).size !== documents.length) throw new SyncProtocolError('PROTOCOL_INVALID');
  const records = new Map([...previous.entities, ...previous.relations].map(record => [record.id, record]));
  const get = (id, entity) => {
    var _old$revision;
    const doc = byId.get(id);
    if (!doc || doc.projectId !== previous.projectId) throw new SyncProtocolError('PROTOCOL_INVALID');
    const record = inflate(doc),
      old = records.get(doc.id);
    if (entity) {
      var _record$createdAt;
      record.createdAt = (_record$createdAt = record.createdAt) !== null && _record$createdAt !== void 0 ? _record$createdAt : old && 'createdAt' in old ? old.createdAt : now;
      if (old && 'createdAt' in old && old.createdAt !== record.createdAt) throw new SyncProtocolError('PROTOCOL_INVALID');
      record.updatedAt = old && 'updatedAt' in old ? old.updatedAt : now;
    }
    record.revision = (_old$revision = old === null || old === void 0 ? void 0 : old.revision) !== null && _old$revision !== void 0 ? _old$revision : '0';
    if (!doc.tombstone) {
      delete record.deletedAt;
      delete record.deletionOperationId;
    }
    return record;
  };
  return {
    ...header,
    projectId: previous.projectId,
    revision: previous.revision,
    entities: entityIds.map(id => get(id, true)),
    relations: relationIds.map(id => get(id, false)),
    history: previous.history
  };
}
export async function prepareNativeOperation(scope, base, project, outboxIds, reason) {
  scope = clone(scope);
  const captured = clone(project),
    confirmed = clone(base),
    ids = clone(outboxIds),
    local = nativeDocuments(captured, confirmed.serverRevision),
    old = new Map(confirmed.documents.map(doc => [doc.id, doc]));
  const targets = local.filter(doc => !sameDocumentContent(old.get(doc.id), doc)).map(doc => {
    var _old$get;
    return {
      base: (_old$get = old.get(doc.id)) !== null && _old$get !== void 0 ? _old$get : null,
      local: doc
    };
  });
  // Physical removal must already be represented by a native tombstone; silently losing records is forbidden.
  if (confirmed.documents.some(doc => !local.some(value => value.id === doc.id))) throw new SyncProtocolError('PROTOCOL_INVALID');
  if (!targets.length) return null;
  const operation = await createSyncOperation({
    scope: clone(scope),
    baseRevision: confirmed.serverRevision,
    operationId: newId(),
    targets,
    reason
  });
  return {
    operationId: operation.operationId,
    projectId: scope.projectId,
    operation,
    localRevision: captured.revision,
    localDocuments: local,
    outboxIds: ids,
    createdAt: new Date().toISOString()
  };
}
/** Reapply edits made after preparation. A contested new edit remains local and becomes a new conflict. */
export function acknowledgeNativeDocuments(prepared, base, ack, current) {
  if (BigInt(ack.serverRevision) < BigInt(base.serverRevision) || !ack.confirmedDocuments) throw new SyncProtocolError('PROTOCOL_INVALID');
  const confirmed = new Map(ack.confirmedDocuments.map(doc => [doc.id, clone(doc)]));
  const latest = Array.isArray(current) ? current : nativeDocuments(current, ack.serverRevision),
    before = new Map(prepared.localDocuments.map(doc => [doc.id, doc])),
    conflicts = [],
    next = [];
  for (const local of latest) {
    var _confirmed$get, _before$get;
    const server = (_confirmed$get = confirmed.get(local.id)) !== null && _confirmed$get !== void 0 ? _confirmed$get : null,
      prior = (_before$get = before.get(local.id)) !== null && _before$get !== void 0 ? _before$get : null;
    if (!prior && !server) {
      next.push(clone(local));
      continue;
    }
    const merged = threeWayMerge(prior, local, server);
    if (merged.status === 'conflict') {
      conflicts.push(merged.conflict);
      next.push(clone(local));
    } else next.push(merged.document);
  }
  for (const server of confirmed.values()) if (!next.some(doc => doc.id === server.id)) next.push(clone(server));
  return {
    confirmed: [...confirmed.values()],
    documents: next,
    conflicts
  };
}
export function resolveNativeConflict(saved, choices, latest) {
  const byId = new Map(latest.map(doc => [doc.id, doc]));
  if (!sameValue(Object.keys(choices).sort(), saved.conflicts.map(c => c.targetId).sort())) throw new SyncProtocolError('PROTOCOL_INVALID');
  return saved.prepared.operation.targets.map((target, index) => {
    var _byId$get;
    const base = saved.ack.documents[index],
      server = (_byId$get = byId.get(target.targetId)) !== null && _byId$get !== void 0 ? _byId$get : null;
    if (!sameValue(base, server)) throw new SyncProtocolError('REVISION_CHANGED');
    const conflict = saved.conflicts.find(c => c.targetId === target.targetId);
    let local;
    if (!conflict) {
      const merged = threeWayMerge(target.base, target.local, server);
      if (merged.status !== 'merged') throw new SyncProtocolError('REVISION_CHANGED');
      local = merged.document;
    } else {
      const choice = choices[target.targetId];
      if (choice.strategy === 'fields') {
        if (conflict.reasons.some(reason => reason !== 'same-field') || !sameValue(Object.keys(choice.choices).sort(), conflict.fields.map(field => field.field).sort()) || !server) throw new SyncProtocolError('PROTOCOL_INVALID');
        local = clone(server);
        local.fields = {};
        for (const [field, slot] of Object.entries(conflict.automaticFields)) if (slot.present) local.fields[field] = clone(slot.value);
        for (const field of conflict.fields) {
          const selected = choice.choices[field.field],
            slot = selected === 'local' ? field.local : selected === 'server' ? field.server : selected.value;
          if (slot.present) local.fields[field.field] = clone(slot.value);
        }
      } else {
        local = clone(choice.strategy === 'local' ? conflict.local : server !== null && server !== void 0 ? server : (() => {
          throw new SyncProtocolError('BASE_UNAVAILABLE');
        })());
      }
    }
    return {
      base,
      local
    };
  });
}
/** Resolve the current local image. New uncontested edits and targets outside the sent batch stay present. */
export function resolveCurrentNativeConflict(saved, choices, serverDocuments, current) {
  const server = new Map(serverDocuments.map(doc => [doc.id, doc])),
    local = new Map((Array.isArray(current) ? current : nativeDocuments(current, saved.ack.serverRevision)).map(doc => [doc.id, doc]));
  if (!sameValue(Object.keys(choices).sort(), saved.conflicts.map(c => c.targetId).sort())) throw new SyncProtocolError('PROTOCOL_INVALID');
  const ids = new Set([...saved.prepared.operation.targets.map(t => t.targetId), ...saved.conflicts.map(c => c.targetId), ...local.keys()]);
  const targets = [];
  for (const id of ids) {
    var _server$get;
    const remote = (_server$get = server.get(id)) !== null && _server$get !== void 0 ? _server$get : null,
      now = local.get(id),
      old = saved.prepared.operation.targets.find(t => t.targetId === id),
      captured = saved.conflicts.find(c => c.targetId === id);
    if (!now) throw new SyncProtocolError('PROTOCOL_INVALID');
    let resolved = clone(now);
    if (captured) {
      if (!sameValue(captured.server, remote)) throw new SyncProtocolError('REVISION_CHANGED');
      const fresh = threeWayMerge(captured.base, now, remote),
        choice = choices[id];
      if (fresh.status === 'merged') resolved = fresh.document;else if (choice.strategy === 'fields') {
        if (fresh.conflict.reasons.some(r => r !== 'same-field') || !sameValue(Object.keys(choice.choices).sort(), fresh.conflict.fields.map(f => f.field).sort()) || !remote) throw new SyncProtocolError('REVISION_CHANGED');
        resolved = clone(remote);
        resolved.fields = {};
        for (const [field, slot] of Object.entries(fresh.conflict.automaticFields)) if (slot.present) resolved.fields[field] = clone(slot.value);
        for (const field of fresh.conflict.fields) {
          const pick = choice.choices[field.field],
            slot = pick === 'local' ? field.local : pick === 'server' ? field.server : pick.value;
          if (slot.present) resolved.fields[field.field] = clone(slot.value);
        }
      } else if (fresh.conflict.reasons.every(r => r === 'same-field') && remote) {
        resolved = clone(remote);
        resolved.fields = {};
        for (const [field, slot] of Object.entries(fresh.conflict.automaticFields)) if (slot.present) resolved.fields[field] = clone(slot.value);
        for (const field of fresh.conflict.fields) {
          const slot = choice.strategy === 'local' ? field.local : field.server;
          if (slot.present) resolved.fields[field.field] = clone(slot.value);
        }
      } else resolved = clone(choice.strategy === 'local' ? now : remote !== null && remote !== void 0 ? remote : (() => {
        throw new SyncProtocolError('BASE_UNAVAILABLE');
      })());
    } else if (saved.ack.status === 'conflict' && old) {
      const fresh = threeWayMerge(old.base, now, remote);
      if (fresh.status === 'conflict') throw new SyncProtocolError('REVISION_CHANGED');
      resolved = fresh.document;
    }
    if (old || captured || !sameDocumentContent(remote, resolved)) targets.push({
      base: clone(remote),
      local: resolved
    });
  }
  return targets;
}
export function validateNativeSyncImage(project, worlds = {}) {
  const result = validateProject(project, {
    worldSnapshots: worlds
  });
  if (!result.ok) throw new SyncProtocolError('PROTOCOL_INVALID');
  return result.value;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJuZXdJZCIsInZhbGlkYXRlUHJvamVjdCIsInRvU3luY0RvY3VtZW50IiwiY2xvbmUiLCJjcmVhdGVTeW5jT3BlcmF0aW9uIiwic2FtZVZhbHVlIiwiU3luY1Byb3RvY29sRXJyb3IiLCJ0aHJlZVdheU1lcmdlIiwibmF0aXZlRG9jdW1lbnRzIiwicHJvamVjdCIsInJldmlzaW9uIiwiZW50aXRpZXMiLCJyZWxhdGlvbnMiLCJoaXN0b3J5IiwiX2hpc3RvcnkiLCJoZWFkZXIiLCJpZCIsInByb2plY3RJZCIsImtpbmQiLCJ2aXNpYmlsaXR5IiwiZW50aXR5SWRzIiwibWFwIiwiZSIsInJlbGF0aW9uSWRzIiwiciIsImRvYyIsImZpZWxkcyIsImNyZWF0ZWRBdCIsInNhbWVEb2N1bWVudENvbnRlbnQiLCJhIiwiYiIsInRvbWJzdG9uZSIsImluZmxhdGUiLCJyZXN1bHQiLCJrZXkiLCJ2YWx1ZSIsIk9iamVjdCIsImVudHJpZXMiLCJzdGFydHNXaXRoIiwiX3Jlc3VsdCRkYXRhIiwibmVzdGVkIiwic2xpY2UiLCJpbmNsdWRlcyIsImRhdGEiLCJkZWxldGVkQXQiLCJkZWxldGlvbk9wZXJhdGlvbklkIiwib3BlcmF0aW9uSWQiLCJuYXRpdmVGcm9tRG9jdW1lbnRzIiwicHJldmlvdXMiLCJkb2N1bWVudHMiLCJub3ciLCJieUlkIiwiTWFwIiwic2l6ZSIsImxlbmd0aCIsImhlYWQiLCJnZXQiLCJyYXciLCJfaWQiLCJfa2luZCIsIl92aXNpYmlsaXR5IiwiQXJyYXkiLCJpc0FycmF5Iiwic29tZSIsIlNldCIsInJlY29yZHMiLCJyZWNvcmQiLCJlbnRpdHkiLCJfb2xkJHJldmlzaW9uIiwib2xkIiwiX3JlY29yZCRjcmVhdGVkQXQiLCJ1cGRhdGVkQXQiLCJwcmVwYXJlTmF0aXZlT3BlcmF0aW9uIiwic2NvcGUiLCJiYXNlIiwib3V0Ym94SWRzIiwicmVhc29uIiwiY2FwdHVyZWQiLCJjb25maXJtZWQiLCJpZHMiLCJsb2NhbCIsInNlcnZlclJldmlzaW9uIiwidGFyZ2V0cyIsImZpbHRlciIsIl9vbGQkZ2V0Iiwib3BlcmF0aW9uIiwiYmFzZVJldmlzaW9uIiwibG9jYWxSZXZpc2lvbiIsImxvY2FsRG9jdW1lbnRzIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwiYWNrbm93bGVkZ2VOYXRpdmVEb2N1bWVudHMiLCJwcmVwYXJlZCIsImFjayIsImN1cnJlbnQiLCJCaWdJbnQiLCJjb25maXJtZWREb2N1bWVudHMiLCJsYXRlc3QiLCJiZWZvcmUiLCJjb25mbGljdHMiLCJuZXh0IiwiX2NvbmZpcm1lZCRnZXQiLCJfYmVmb3JlJGdldCIsInNlcnZlciIsInByaW9yIiwicHVzaCIsIm1lcmdlZCIsInN0YXR1cyIsImNvbmZsaWN0IiwiZG9jdW1lbnQiLCJ2YWx1ZXMiLCJyZXNvbHZlTmF0aXZlQ29uZmxpY3QiLCJzYXZlZCIsImNob2ljZXMiLCJrZXlzIiwic29ydCIsImMiLCJ0YXJnZXRJZCIsInRhcmdldCIsImluZGV4IiwiX2J5SWQkZ2V0IiwiZmluZCIsImNob2ljZSIsInN0cmF0ZWd5IiwicmVhc29ucyIsImZpZWxkIiwic2xvdCIsImF1dG9tYXRpY0ZpZWxkcyIsInByZXNlbnQiLCJzZWxlY3RlZCIsInJlc29sdmVDdXJyZW50TmF0aXZlQ29uZmxpY3QiLCJzZXJ2ZXJEb2N1bWVudHMiLCJ0IiwiX3NlcnZlciRnZXQiLCJyZW1vdGUiLCJyZXNvbHZlZCIsImZyZXNoIiwiZiIsInBpY2siLCJldmVyeSIsInZhbGlkYXRlTmF0aXZlU3luY0ltYWdlIiwid29ybGRzIiwid29ybGRTbmFwc2hvdHMiLCJvayJdLCJzb3VyY2VzIjpbIm5hdGl2ZUJyaWRnZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEVudGl0eSwgUmVsYXRpb24sIFByb2plY3REYXRhIH0gZnJvbSAnLi4vZG9tYWluL3R5cGVzJztcbmltcG9ydCB7IG5ld0lkLCB2YWxpZGF0ZVByb2plY3QgfSBmcm9tICcuLi9kb21haW4vbW9kZWwnO1xuaW1wb3J0IHsgdG9TeW5jRG9jdW1lbnQgfSBmcm9tICcuL2FkYXB0ZXInO1xuaW1wb3J0IHsgY2xvbmUsIGNyZWF0ZVN5bmNPcGVyYXRpb24sIHNhbWVWYWx1ZSwgU3luY1Byb3RvY29sRXJyb3IsIHR5cGUgU3luY0FjaywgdHlwZSBTeW5jQ29uZmxpY3QsIHR5cGUgU3luY0RvY3VtZW50LCB0eXBlIFN5bmNPcGVyYXRpb24sIHR5cGUgU3luY1Njb3BlIH0gZnJvbSAnLi9wcm90b2NvbCc7XG5pbXBvcnQgeyB0aHJlZVdheU1lcmdlLCB0eXBlIENvbmZsaWN0UmVzb2x1dGlvbiB9IGZyb20gJy4vbWVyZ2UnO1xuXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpcm1lZFN5bmNCYXNlIHsgcHJvamVjdElkOnN0cmluZzsgc2VydmVyUmV2aXNpb246c3RyaW5nOyBkb2N1bWVudHM6U3luY0RvY3VtZW50W107IGNvbnRlbnRIYXNoOnN0cmluZyB9XG5leHBvcnQgaW50ZXJmYWNlIFByZXBhcmVkTmF0aXZlT3BlcmF0aW9uIHsgb3BlcmF0aW9uSWQ6c3RyaW5nOyBwcm9qZWN0SWQ6c3RyaW5nOyBvcGVyYXRpb246U3luY09wZXJhdGlvbjsgbG9jYWxSZXZpc2lvbjpzdHJpbmc7IGxvY2FsRG9jdW1lbnRzOlN5bmNEb2N1bWVudFtdOyBvdXRib3hJZHM6c3RyaW5nW107IG9yaWdpbj86J3ByZXBhcmVkX29wZXJhdGlvbid8J3JlY2VpdmVkX2ltYWdlJzsgY3JlYXRlZEF0OnN0cmluZyB9XG5leHBvcnQgaW50ZXJmYWNlIFByZXNlcnZlZE5hdGl2ZUNvbmZsaWN0IHsgb3BlcmF0aW9uSWQ6c3RyaW5nOyBwcm9qZWN0SWQ6c3RyaW5nOyBwcmVwYXJlZDpQcmVwYXJlZE5hdGl2ZU9wZXJhdGlvbjsgYWNrOlN5bmNBY2s7IGNvbmZsaWN0czpTeW5jQ29uZmxpY3RbXTsgY3JlYXRlZEF0OnN0cmluZyB9XG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZVN5bmNBY2sgeyBvcGVyYXRpb25JZDpzdHJpbmc7IHByb2plY3RJZDpzdHJpbmc7IG9wZXJhdGlvbjpTeW5jT3BlcmF0aW9uOyBhY2s6U3luY0Fjazsgb3JpZ2luPzoncHJlcGFyZWRfb3BlcmF0aW9uJ3wncmVjZWl2ZWRfaW1hZ2UnOyBjcmVhdGVkQXQ6c3RyaW5nIH1cblxuLyoqIFNlcnZlciByZWNvcmQgcmV2aXNpb25zIGFuZCBsb2NhbCBzYXZlIHJldmlzaW9ucyBoYXZlIGRpZmZlcmVudCBtZWFuaW5ncy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuYXRpdmVEb2N1bWVudHMocHJvamVjdDpQcm9qZWN0RGF0YSxyZXZpc2lvbjpzdHJpbmcpOlN5bmNEb2N1bWVudFtde1xuIGNvbnN0IHtlbnRpdGllcyxyZWxhdGlvbnMsaGlzdG9yeTpfaGlzdG9yeSwuLi5oZWFkZXJ9PXByb2plY3Q7XG4gcmV0dXJuIFt0b1N5bmNEb2N1bWVudCh7Li4uaGVhZGVyLGlkOnByb2plY3QucHJvamVjdElkLGtpbmQ6J3Byb2plY3QnLHZpc2liaWxpdHk6J3ByaXZhdGUnLHJldmlzaW9uLGVudGl0eUlkczplbnRpdGllcy5tYXAoZT0+ZS5pZCkscmVsYXRpb25JZHM6cmVsYXRpb25zLm1hcChyPT5yLmlkKX0pLC4uLmVudGl0aWVzLm1hcChlPT57Y29uc3QgZG9jPXRvU3luY0RvY3VtZW50KHsuLi5lLHJldmlzaW9ufSk7ZG9jLmZpZWxkcy5jcmVhdGVkQXQ9ZS5jcmVhdGVkQXQ7cmV0dXJuIGRvYzt9KSwuLi5yZWxhdGlvbnMubWFwKHI9PnRvU3luY0RvY3VtZW50KHsuLi5yLHJldmlzaW9ufSkpXTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBzYW1lRG9jdW1lbnRDb250ZW50KGE6U3luY0RvY3VtZW50fG51bGx8dW5kZWZpbmVkLGI6U3luY0RvY3VtZW50fG51bGx8dW5kZWZpbmVkKXtyZXR1cm4gc2FtZVZhbHVlKGE/e2ZpZWxkczphLmZpZWxkcyx0b21ic3RvbmU6YS50b21ic3RvbmV9Om51bGwsYj97ZmllbGRzOmIuZmllbGRzLHRvbWJzdG9uZTpiLnRvbWJzdG9uZX06bnVsbCk7fVxuZnVuY3Rpb24gaW5mbGF0ZShkb2M6U3luY0RvY3VtZW50KTpSZWNvcmQ8c3RyaW5nLHVua25vd24+e1xuIGNvbnN0IHJlc3VsdDpSZWNvcmQ8c3RyaW5nLHVua25vd24+PXtpZDpkb2MuaWQscHJvamVjdElkOmRvYy5wcm9qZWN0SWQscmV2aXNpb246ZG9jLnJldmlzaW9ufTtcbiBmb3IoY29uc3QgW2tleSx2YWx1ZV1vZiBPYmplY3QuZW50cmllcyhkb2MuZmllbGRzKSl7aWYoa2V5LnN0YXJ0c1dpdGgoJ2RhdGEuJykpe2NvbnN0IG5lc3RlZD1rZXkuc2xpY2UoNSk7aWYoIW5lc3RlZHx8bmVzdGVkLmluY2x1ZGVzKCcuJyl8fFsnX19wcm90b19fJywncHJvdG90eXBlJywnY29uc3RydWN0b3InXS5pbmNsdWRlcyhuZXN0ZWQpKXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUFJPVE9DT0xfSU5WQUxJRCcpO3Jlc3VsdC5kYXRhPz89e307KHJlc3VsdC5kYXRhIGFzIFJlY29yZDxzdHJpbmcsdW5rbm93bj4pW25lc3RlZF09Y2xvbmUodmFsdWUpO31lbHNle2lmKFsnaWQnLCdwcm9qZWN0SWQnLCdyZXZpc2lvbicsJ3VwZGF0ZWRBdCcsJ2RlbGV0ZWRBdCcsJ2RlbGV0aW9uT3BlcmF0aW9uSWQnLCdfX3Byb3RvX18nLCdwcm90b3R5cGUnLCdjb25zdHJ1Y3RvciddLmluY2x1ZGVzKGtleSkpdGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdQUk9UT0NPTF9JTlZBTElEJyk7cmVzdWx0W2tleV09Y2xvbmUodmFsdWUpO319XG4gaWYoZG9jLnRvbWJzdG9uZSl7cmVzdWx0LmRlbGV0ZWRBdD1kb2MudG9tYnN0b25lLmRlbGV0ZWRBdDtyZXN1bHQuZGVsZXRpb25PcGVyYXRpb25JZD1kb2MudG9tYnN0b25lLm9wZXJhdGlvbklkO31yZXR1cm4gcmVzdWx0O1xufVxuLyoqIENvbnN0cnVjdCBhIG5hdGl2ZSBjYW5kaWRhdGU7IHZhbGlkYXRpb24gYW5kIGR1cmFibGUgaW50ZWdyaXR5IGFyZSBwZXJmb3JtZWQgYmVmb3JlIHRoZSB0cmFuc2FjdGlvbi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuYXRpdmVGcm9tRG9jdW1lbnRzKHByZXZpb3VzOlByb2plY3REYXRhLGRvY3VtZW50czpTeW5jRG9jdW1lbnRbXSxub3c6c3RyaW5nKTpQcm9qZWN0RGF0YXtcbiBjb25zdCBieUlkPW5ldyBNYXAoZG9jdW1lbnRzLm1hcChkb2M9Pltkb2MuaWQsZG9jXSkpO2lmKGJ5SWQuc2l6ZSE9PWRvY3VtZW50cy5sZW5ndGgpdGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdQUk9UT0NPTF9JTlZBTElEJyk7XG4gY29uc3QgaGVhZD1ieUlkLmdldChwcmV2aW91cy5wcm9qZWN0SWQpO2lmKCFoZWFkfHxoZWFkLmZpZWxkcy5raW5kIT09J3Byb2plY3QnfHxoZWFkLnRvbWJzdG9uZSl0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ1BST1RPQ09MX0lOVkFMSUQnKTtcbiBjb25zdCByYXc9aW5mbGF0ZShoZWFkKSx7aWQ6X2lkLGtpbmQ6X2tpbmQsdmlzaWJpbGl0eTpfdmlzaWJpbGl0eSxlbnRpdHlJZHMscmVsYXRpb25JZHMsLi4uaGVhZGVyfT1yYXc7XG4gaWYoIUFycmF5LmlzQXJyYXkoZW50aXR5SWRzKXx8IUFycmF5LmlzQXJyYXkocmVsYXRpb25JZHMpfHxbLi4uZW50aXR5SWRzLC4uLnJlbGF0aW9uSWRzXS5zb21lKGlkPT50eXBlb2YgaWQhPT0nc3RyaW5nJyl8fG5ldyBTZXQoWy4uLmVudGl0eUlkcywuLi5yZWxhdGlvbklkcyxoZWFkLmlkXSkuc2l6ZSE9PWRvY3VtZW50cy5sZW5ndGgpdGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdQUk9UT0NPTF9JTlZBTElEJyk7XG4gY29uc3QgcmVjb3Jkcz1uZXcgTWFwKFsuLi5wcmV2aW91cy5lbnRpdGllcywuLi5wcmV2aW91cy5yZWxhdGlvbnNdLm1hcChyZWNvcmQ9PltyZWNvcmQuaWQscmVjb3JkXSkpO1xuIGNvbnN0IGdldD0oaWQ6dW5rbm93bixlbnRpdHk6Ym9vbGVhbik9Pntjb25zdCBkb2M9YnlJZC5nZXQoaWQgYXMgc3RyaW5nKTtpZighZG9jfHxkb2MucHJvamVjdElkIT09cHJldmlvdXMucHJvamVjdElkKXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUFJPVE9DT0xfSU5WQUxJRCcpO2NvbnN0IHJlY29yZD1pbmZsYXRlKGRvYyksb2xkPXJlY29yZHMuZ2V0KGRvYy5pZCk7aWYoZW50aXR5KXtyZWNvcmQuY3JlYXRlZEF0PXJlY29yZC5jcmVhdGVkQXQ/PyhvbGQmJidjcmVhdGVkQXQnaW4gb2xkP29sZC5jcmVhdGVkQXQ6bm93KTtpZihvbGQmJidjcmVhdGVkQXQnaW4gb2xkJiZvbGQuY3JlYXRlZEF0IT09cmVjb3JkLmNyZWF0ZWRBdCl0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ1BST1RPQ09MX0lOVkFMSUQnKTtyZWNvcmQudXBkYXRlZEF0PW9sZCYmJ3VwZGF0ZWRBdCdpbiBvbGQ/b2xkLnVwZGF0ZWRBdDpub3c7fXJlY29yZC5yZXZpc2lvbj1vbGQ/LnJldmlzaW9uPz8nMCc7aWYoIWRvYy50b21ic3RvbmUpe2RlbGV0ZSByZWNvcmQuZGVsZXRlZEF0O2RlbGV0ZSByZWNvcmQuZGVsZXRpb25PcGVyYXRpb25JZDt9cmV0dXJuIHJlY29yZDt9O1xuIHJldHVybiB7Li4uaGVhZGVyLHByb2plY3RJZDpwcmV2aW91cy5wcm9qZWN0SWQscmV2aXNpb246cHJldmlvdXMucmV2aXNpb24sZW50aXRpZXM6ZW50aXR5SWRzLm1hcChpZD0+Z2V0KGlkLHRydWUpKSBhcyBFbnRpdHlbXSxyZWxhdGlvbnM6cmVsYXRpb25JZHMubWFwKGlkPT5nZXQoaWQsZmFsc2UpKSBhcyB1bmtub3duIGFzIFJlbGF0aW9uW10saGlzdG9yeTpwcmV2aW91cy5oaXN0b3J5fSBhcyBQcm9qZWN0RGF0YTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwYXJlTmF0aXZlT3BlcmF0aW9uKHNjb3BlOlN5bmNTY29wZSxiYXNlOkNvbmZpcm1lZFN5bmNCYXNlLHByb2plY3Q6UHJvamVjdERhdGEsb3V0Ym94SWRzOnN0cmluZ1tdLHJlYXNvbjpzdHJpbmcpOlByb21pc2U8UHJlcGFyZWROYXRpdmVPcGVyYXRpb258bnVsbD57XG4gc2NvcGU9Y2xvbmUoc2NvcGUpO2NvbnN0IGNhcHR1cmVkPWNsb25lKHByb2plY3QpLGNvbmZpcm1lZD1jbG9uZShiYXNlKSxpZHM9Y2xvbmUob3V0Ym94SWRzKSxsb2NhbD1uYXRpdmVEb2N1bWVudHMoY2FwdHVyZWQsY29uZmlybWVkLnNlcnZlclJldmlzaW9uKSxvbGQ9bmV3IE1hcChjb25maXJtZWQuZG9jdW1lbnRzLm1hcChkb2M9Pltkb2MuaWQsZG9jXSkpO1xuIGNvbnN0IHRhcmdldHM9bG9jYWwuZmlsdGVyKGRvYz0+IXNhbWVEb2N1bWVudENvbnRlbnQob2xkLmdldChkb2MuaWQpLGRvYykpLm1hcChkb2M9Pih7YmFzZTpvbGQuZ2V0KGRvYy5pZCk/P251bGwsbG9jYWw6ZG9jfSkpO1xuIC8vIFBoeXNpY2FsIHJlbW92YWwgbXVzdCBhbHJlYWR5IGJlIHJlcHJlc2VudGVkIGJ5IGEgbmF0aXZlIHRvbWJzdG9uZTsgc2lsZW50bHkgbG9zaW5nIHJlY29yZHMgaXMgZm9yYmlkZGVuLlxuIGlmKGNvbmZpcm1lZC5kb2N1bWVudHMuc29tZShkb2M9PiFsb2NhbC5zb21lKHZhbHVlPT52YWx1ZS5pZD09PWRvYy5pZCkpKXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUFJPVE9DT0xfSU5WQUxJRCcpO1xuIGlmKCF0YXJnZXRzLmxlbmd0aClyZXR1cm4gbnVsbDtcbiBjb25zdCBvcGVyYXRpb249YXdhaXQgY3JlYXRlU3luY09wZXJhdGlvbih7c2NvcGU6Y2xvbmUoc2NvcGUpLGJhc2VSZXZpc2lvbjpjb25maXJtZWQuc2VydmVyUmV2aXNpb24sb3BlcmF0aW9uSWQ6bmV3SWQoKSx0YXJnZXRzLHJlYXNvbn0pO1xuIHJldHVybiB7b3BlcmF0aW9uSWQ6b3BlcmF0aW9uLm9wZXJhdGlvbklkLHByb2plY3RJZDpzY29wZS5wcm9qZWN0SWQsb3BlcmF0aW9uLGxvY2FsUmV2aXNpb246Y2FwdHVyZWQucmV2aXNpb24sbG9jYWxEb2N1bWVudHM6bG9jYWwsb3V0Ym94SWRzOmlkcyxjcmVhdGVkQXQ6bmV3IERhdGUoKS50b0lTT1N0cmluZygpfTtcbn1cbi8qKiBSZWFwcGx5IGVkaXRzIG1hZGUgYWZ0ZXIgcHJlcGFyYXRpb24uIEEgY29udGVzdGVkIG5ldyBlZGl0IHJlbWFpbnMgbG9jYWwgYW5kIGJlY29tZXMgYSBuZXcgY29uZmxpY3QuICovXG5leHBvcnQgZnVuY3Rpb24gYWNrbm93bGVkZ2VOYXRpdmVEb2N1bWVudHMocHJlcGFyZWQ6UHJlcGFyZWROYXRpdmVPcGVyYXRpb24sYmFzZTpDb25maXJtZWRTeW5jQmFzZSxhY2s6U3luY0FjayxjdXJyZW50OlByb2plY3REYXRhfFN5bmNEb2N1bWVudFtdKXtcbiBpZihCaWdJbnQoYWNrLnNlcnZlclJldmlzaW9uKTxCaWdJbnQoYmFzZS5zZXJ2ZXJSZXZpc2lvbil8fCFhY2suY29uZmlybWVkRG9jdW1lbnRzKXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUFJPVE9DT0xfSU5WQUxJRCcpO1xuIGNvbnN0IGNvbmZpcm1lZD1uZXcgTWFwKGFjay5jb25maXJtZWREb2N1bWVudHMubWFwKGRvYz0+W2RvYy5pZCxjbG9uZShkb2MpXSkpO1xuIGNvbnN0IGxhdGVzdD1BcnJheS5pc0FycmF5KGN1cnJlbnQpP2N1cnJlbnQ6bmF0aXZlRG9jdW1lbnRzKGN1cnJlbnQsYWNrLnNlcnZlclJldmlzaW9uKSxiZWZvcmU9bmV3IE1hcChwcmVwYXJlZC5sb2NhbERvY3VtZW50cy5tYXAoZG9jPT5bZG9jLmlkLGRvY10pKSxjb25mbGljdHM6U3luY0NvbmZsaWN0W109W10sbmV4dDpTeW5jRG9jdW1lbnRbXT1bXTtcbiBmb3IoY29uc3QgbG9jYWwgb2YgbGF0ZXN0KXtjb25zdCBzZXJ2ZXI9Y29uZmlybWVkLmdldChsb2NhbC5pZCk/P251bGwscHJpb3I9YmVmb3JlLmdldChsb2NhbC5pZCk/P251bGw7XG4gIGlmKCFwcmlvciYmIXNlcnZlcil7bmV4dC5wdXNoKGNsb25lKGxvY2FsKSk7Y29udGludWU7fVxuICBjb25zdCBtZXJnZWQ9dGhyZWVXYXlNZXJnZShwcmlvcixsb2NhbCxzZXJ2ZXIpO2lmKG1lcmdlZC5zdGF0dXM9PT0nY29uZmxpY3QnKXtjb25mbGljdHMucHVzaChtZXJnZWQuY29uZmxpY3QpO25leHQucHVzaChjbG9uZShsb2NhbCkpO31lbHNlIG5leHQucHVzaChtZXJnZWQuZG9jdW1lbnQpO1xuIH1cbiBmb3IoY29uc3Qgc2VydmVyIG9mIGNvbmZpcm1lZC52YWx1ZXMoKSlpZighbmV4dC5zb21lKGRvYz0+ZG9jLmlkPT09c2VydmVyLmlkKSluZXh0LnB1c2goY2xvbmUoc2VydmVyKSk7XG4gcmV0dXJuIHtjb25maXJtZWQ6Wy4uLmNvbmZpcm1lZC52YWx1ZXMoKV0sZG9jdW1lbnRzOm5leHQsY29uZmxpY3RzfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTmF0aXZlQ29uZmxpY3Qoc2F2ZWQ6UHJlc2VydmVkTmF0aXZlQ29uZmxpY3QsY2hvaWNlczpSZWNvcmQ8c3RyaW5nLENvbmZsaWN0UmVzb2x1dGlvbj4sbGF0ZXN0OlN5bmNEb2N1bWVudFtdKXtcbiBjb25zdCBieUlkPW5ldyBNYXAobGF0ZXN0Lm1hcChkb2M9Pltkb2MuaWQsZG9jXSkpO1xuIGlmKCFzYW1lVmFsdWUoT2JqZWN0LmtleXMoY2hvaWNlcykuc29ydCgpLHNhdmVkLmNvbmZsaWN0cy5tYXAoYz0+Yy50YXJnZXRJZCkuc29ydCgpKSl0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ1BST1RPQ09MX0lOVkFMSUQnKTtcbiByZXR1cm4gc2F2ZWQucHJlcGFyZWQub3BlcmF0aW9uLnRhcmdldHMubWFwKCh0YXJnZXQsaW5kZXgpPT57XG4gIGNvbnN0IGJhc2U9c2F2ZWQuYWNrLmRvY3VtZW50c1tpbmRleF0sc2VydmVyPWJ5SWQuZ2V0KHRhcmdldC50YXJnZXRJZCk/P251bGw7aWYoIXNhbWVWYWx1ZShiYXNlLHNlcnZlcikpdGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdSRVZJU0lPTl9DSEFOR0VEJyk7XG4gIGNvbnN0IGNvbmZsaWN0PXNhdmVkLmNvbmZsaWN0cy5maW5kKGM9PmMudGFyZ2V0SWQ9PT10YXJnZXQudGFyZ2V0SWQpO2xldCBsb2NhbDpTeW5jRG9jdW1lbnQ7XG4gIGlmKCFjb25mbGljdCl7Y29uc3QgbWVyZ2VkPXRocmVlV2F5TWVyZ2UodGFyZ2V0LmJhc2UsdGFyZ2V0LmxvY2FsLHNlcnZlcik7aWYobWVyZ2VkLnN0YXR1cyE9PSdtZXJnZWQnKXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUkVWSVNJT05fQ0hBTkdFRCcpO2xvY2FsPW1lcmdlZC5kb2N1bWVudDt9XG4gIGVsc2V7Y29uc3QgY2hvaWNlPWNob2ljZXNbdGFyZ2V0LnRhcmdldElkXTtpZihjaG9pY2Uuc3RyYXRlZ3k9PT0nZmllbGRzJyl7XG4gICBpZihjb25mbGljdC5yZWFzb25zLnNvbWUocmVhc29uPT5yZWFzb24hPT0nc2FtZS1maWVsZCcpfHwhc2FtZVZhbHVlKE9iamVjdC5rZXlzKGNob2ljZS5jaG9pY2VzKS5zb3J0KCksY29uZmxpY3QuZmllbGRzLm1hcChmaWVsZD0+ZmllbGQuZmllbGQpLnNvcnQoKSl8fCFzZXJ2ZXIpdGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdQUk9UT0NPTF9JTlZBTElEJyk7XG4gICBsb2NhbD1jbG9uZShzZXJ2ZXIpO2xvY2FsLmZpZWxkcz17fTtmb3IoY29uc3QgW2ZpZWxkLHNsb3Rdb2YgT2JqZWN0LmVudHJpZXMoY29uZmxpY3QuYXV0b21hdGljRmllbGRzKSlpZihzbG90LnByZXNlbnQpbG9jYWwuZmllbGRzW2ZpZWxkXT1jbG9uZShzbG90LnZhbHVlKTtcbiAgIGZvcihjb25zdCBmaWVsZCBvZiBjb25mbGljdC5maWVsZHMpe2NvbnN0IHNlbGVjdGVkPWNob2ljZS5jaG9pY2VzW2ZpZWxkLmZpZWxkXSxzbG90PXNlbGVjdGVkPT09J2xvY2FsJz9maWVsZC5sb2NhbDpzZWxlY3RlZD09PSdzZXJ2ZXInP2ZpZWxkLnNlcnZlcjpzZWxlY3RlZC52YWx1ZTtpZihzbG90LnByZXNlbnQpbG9jYWwuZmllbGRzW2ZpZWxkLmZpZWxkXT1jbG9uZShzbG90LnZhbHVlKTt9XG4gIH1lbHNle2xvY2FsPWNsb25lKGNob2ljZS5zdHJhdGVneT09PSdsb2NhbCc/Y29uZmxpY3QubG9jYWw6c2VydmVyPz8oKCk9Pnt0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ0JBU0VfVU5BVkFJTEFCTEUnKTt9KSgpKTt9fVxuICByZXR1cm4ge2Jhc2UsbG9jYWx9O1xuIH0pO1xufVxuLyoqIFJlc29sdmUgdGhlIGN1cnJlbnQgbG9jYWwgaW1hZ2UuIE5ldyB1bmNvbnRlc3RlZCBlZGl0cyBhbmQgdGFyZ2V0cyBvdXRzaWRlIHRoZSBzZW50IGJhdGNoIHN0YXkgcHJlc2VudC4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQ3VycmVudE5hdGl2ZUNvbmZsaWN0KHNhdmVkOlByZXNlcnZlZE5hdGl2ZUNvbmZsaWN0LGNob2ljZXM6UmVjb3JkPHN0cmluZyxDb25mbGljdFJlc29sdXRpb24+LHNlcnZlckRvY3VtZW50czpTeW5jRG9jdW1lbnRbXSxjdXJyZW50OlByb2plY3REYXRhfFN5bmNEb2N1bWVudFtdKXtcbiBjb25zdCBzZXJ2ZXI9bmV3IE1hcChzZXJ2ZXJEb2N1bWVudHMubWFwKGRvYz0+W2RvYy5pZCxkb2NdKSksbG9jYWw9bmV3IE1hcCgoQXJyYXkuaXNBcnJheShjdXJyZW50KT9jdXJyZW50Om5hdGl2ZURvY3VtZW50cyhjdXJyZW50LHNhdmVkLmFjay5zZXJ2ZXJSZXZpc2lvbikpLm1hcChkb2M9Pltkb2MuaWQsZG9jXSkpO1xuIGlmKCFzYW1lVmFsdWUoT2JqZWN0LmtleXMoY2hvaWNlcykuc29ydCgpLHNhdmVkLmNvbmZsaWN0cy5tYXAoYz0+Yy50YXJnZXRJZCkuc29ydCgpKSl0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ1BST1RPQ09MX0lOVkFMSUQnKTtcbiBjb25zdCBpZHM9bmV3IFNldChbLi4uc2F2ZWQucHJlcGFyZWQub3BlcmF0aW9uLnRhcmdldHMubWFwKHQ9PnQudGFyZ2V0SWQpLC4uLnNhdmVkLmNvbmZsaWN0cy5tYXAoYz0+Yy50YXJnZXRJZCksLi4ubG9jYWwua2V5cygpXSk7XG4gY29uc3QgdGFyZ2V0czp7YmFzZTpTeW5jRG9jdW1lbnR8bnVsbDtsb2NhbDpTeW5jRG9jdW1lbnR9W109W107XG4gZm9yKGNvbnN0IGlkIG9mIGlkcyl7Y29uc3QgcmVtb3RlPXNlcnZlci5nZXQoaWQpPz9udWxsLG5vdz1sb2NhbC5nZXQoaWQpLG9sZD1zYXZlZC5wcmVwYXJlZC5vcGVyYXRpb24udGFyZ2V0cy5maW5kKHQ9PnQudGFyZ2V0SWQ9PT1pZCksY2FwdHVyZWQ9c2F2ZWQuY29uZmxpY3RzLmZpbmQoYz0+Yy50YXJnZXRJZD09PWlkKTtpZighbm93KXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUFJPVE9DT0xfSU5WQUxJRCcpO2xldCByZXNvbHZlZD1jbG9uZShub3cpO1xuICBpZihjYXB0dXJlZCl7aWYoIXNhbWVWYWx1ZShjYXB0dXJlZC5zZXJ2ZXIscmVtb3RlKSl0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ1JFVklTSU9OX0NIQU5HRUQnKTtjb25zdCBmcmVzaD10aHJlZVdheU1lcmdlKGNhcHR1cmVkLmJhc2Usbm93LHJlbW90ZSksY2hvaWNlPWNob2ljZXNbaWRdO1xuICAgaWYoZnJlc2guc3RhdHVzPT09J21lcmdlZCcpcmVzb2x2ZWQ9ZnJlc2guZG9jdW1lbnQ7XG4gICBlbHNlIGlmKGNob2ljZS5zdHJhdGVneT09PSdmaWVsZHMnKXtcbiAgICBpZihmcmVzaC5jb25mbGljdC5yZWFzb25zLnNvbWUocj0+ciE9PSdzYW1lLWZpZWxkJyl8fCFzYW1lVmFsdWUoT2JqZWN0LmtleXMoY2hvaWNlLmNob2ljZXMpLnNvcnQoKSxmcmVzaC5jb25mbGljdC5maWVsZHMubWFwKGY9PmYuZmllbGQpLnNvcnQoKSl8fCFyZW1vdGUpdGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdSRVZJU0lPTl9DSEFOR0VEJyk7XG4gICAgcmVzb2x2ZWQ9Y2xvbmUocmVtb3RlKTtyZXNvbHZlZC5maWVsZHM9e307Zm9yKGNvbnN0IFtmaWVsZCxzbG90XW9mIE9iamVjdC5lbnRyaWVzKGZyZXNoLmNvbmZsaWN0LmF1dG9tYXRpY0ZpZWxkcykpaWYoc2xvdC5wcmVzZW50KXJlc29sdmVkLmZpZWxkc1tmaWVsZF09Y2xvbmUoc2xvdC52YWx1ZSk7XG4gICAgZm9yKGNvbnN0IGZpZWxkIG9mIGZyZXNoLmNvbmZsaWN0LmZpZWxkcyl7Y29uc3QgcGljaz1jaG9pY2UuY2hvaWNlc1tmaWVsZC5maWVsZF0sc2xvdD1waWNrPT09J2xvY2FsJz9maWVsZC5sb2NhbDpwaWNrPT09J3NlcnZlcic/ZmllbGQuc2VydmVyOnBpY2sudmFsdWU7aWYoc2xvdC5wcmVzZW50KXJlc29sdmVkLmZpZWxkc1tmaWVsZC5maWVsZF09Y2xvbmUoc2xvdC52YWx1ZSk7fVxuICAgfWVsc2UgaWYoZnJlc2guY29uZmxpY3QucmVhc29ucy5ldmVyeShyPT5yPT09J3NhbWUtZmllbGQnKSYmcmVtb3RlKXtcbiAgICByZXNvbHZlZD1jbG9uZShyZW1vdGUpO3Jlc29sdmVkLmZpZWxkcz17fTtmb3IoY29uc3QgW2ZpZWxkLHNsb3Rdb2YgT2JqZWN0LmVudHJpZXMoZnJlc2guY29uZmxpY3QuYXV0b21hdGljRmllbGRzKSlpZihzbG90LnByZXNlbnQpcmVzb2x2ZWQuZmllbGRzW2ZpZWxkXT1jbG9uZShzbG90LnZhbHVlKTtcbiAgICBmb3IoY29uc3QgZmllbGQgb2YgZnJlc2guY29uZmxpY3QuZmllbGRzKXtjb25zdCBzbG90PWNob2ljZS5zdHJhdGVneT09PSdsb2NhbCc/ZmllbGQubG9jYWw6ZmllbGQuc2VydmVyO2lmKHNsb3QucHJlc2VudClyZXNvbHZlZC5maWVsZHNbZmllbGQuZmllbGRdPWNsb25lKHNsb3QudmFsdWUpO31cbiAgIH1lbHNlIHJlc29sdmVkPWNsb25lKGNob2ljZS5zdHJhdGVneT09PSdsb2NhbCc/bm93OnJlbW90ZT8/KCgpPT57dGhyb3cgbmV3IFN5bmNQcm90b2NvbEVycm9yKCdCQVNFX1VOQVZBSUxBQkxFJyk7fSkoKSk7XG4gIH1lbHNlIGlmKHNhdmVkLmFjay5zdGF0dXM9PT0nY29uZmxpY3QnJiZvbGQpe2NvbnN0IGZyZXNoPXRocmVlV2F5TWVyZ2Uob2xkLmJhc2Usbm93LHJlbW90ZSk7aWYoZnJlc2guc3RhdHVzPT09J2NvbmZsaWN0Jyl0aHJvdyBuZXcgU3luY1Byb3RvY29sRXJyb3IoJ1JFVklTSU9OX0NIQU5HRUQnKTtyZXNvbHZlZD1mcmVzaC5kb2N1bWVudDt9XG4gIGlmKG9sZHx8Y2FwdHVyZWR8fCFzYW1lRG9jdW1lbnRDb250ZW50KHJlbW90ZSxyZXNvbHZlZCkpdGFyZ2V0cy5wdXNoKHtiYXNlOmNsb25lKHJlbW90ZSksbG9jYWw6cmVzb2x2ZWR9KTtcbiB9XG4gcmV0dXJuIHRhcmdldHM7XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVOYXRpdmVTeW5jSW1hZ2UocHJvamVjdDpQcm9qZWN0RGF0YSx3b3JsZHM6UmVjb3JkPHN0cmluZyxpbXBvcnQoJy4uL2RvbWFpbi90eXBlcycpLlByb2plY3RDb250ZW50Pj17fSl7Y29uc3QgcmVzdWx0PXZhbGlkYXRlUHJvamVjdChwcm9qZWN0LHt3b3JsZFNuYXBzaG90czp3b3JsZHN9KTtpZighcmVzdWx0Lm9rKXRocm93IG5ldyBTeW5jUHJvdG9jb2xFcnJvcignUFJPVE9DT0xfSU5WQUxJRCcpO3JldHVybiByZXN1bHQudmFsdWU7fVxuIl0sIm1hcHBpbmdzIjoiQUFDQSxTQUFTQSxLQUFLLEVBQUVDLGVBQWUsUUFBUSxpQkFBaUI7QUFDeEQsU0FBU0MsY0FBYyxRQUFRLFdBQVc7QUFDMUMsU0FBU0MsS0FBSyxFQUFFQyxtQkFBbUIsRUFBRUMsU0FBUyxFQUFFQyxpQkFBaUIsUUFBZ0csWUFBWTtBQUM3SyxTQUFTQyxhQUFhLFFBQWlDLFNBQVM7QUFPaEU7QUFDQSxPQUFPLFNBQVNDLGVBQWVBLENBQUNDLE9BQW1CLEVBQUNDLFFBQWUsRUFBZ0I7RUFDbEYsTUFBTTtJQUFDQyxRQUFRO0lBQUNDLFNBQVM7SUFBQ0MsT0FBTyxFQUFDQyxRQUFRO0lBQUMsR0FBR0M7RUFBTSxDQUFDLEdBQUNOLE9BQU87RUFDN0QsT0FBTyxDQUFDUCxjQUFjLENBQUM7SUFBQyxHQUFHYSxNQUFNO0lBQUNDLEVBQUUsRUFBQ1AsT0FBTyxDQUFDUSxTQUFTO0lBQUNDLElBQUksRUFBQyxTQUFTO0lBQUNDLFVBQVUsRUFBQyxTQUFTO0lBQUNULFFBQVE7SUFBQ1UsU0FBUyxFQUFDVCxRQUFRLENBQUNVLEdBQUcsQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNOLEVBQUUsQ0FBQztJQUFDTyxXQUFXLEVBQUNYLFNBQVMsQ0FBQ1MsR0FBRyxDQUFDRyxDQUFDLElBQUVBLENBQUMsQ0FBQ1IsRUFBRTtFQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUdMLFFBQVEsQ0FBQ1UsR0FBRyxDQUFDQyxDQUFDLElBQUU7SUFBQyxNQUFNRyxHQUFHLEdBQUN2QixjQUFjLENBQUM7TUFBQyxHQUFHb0IsQ0FBQztNQUFDWjtJQUFRLENBQUMsQ0FBQztJQUFDZSxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsU0FBUyxHQUFDTCxDQUFDLENBQUNLLFNBQVM7SUFBQyxPQUFPRixHQUFHO0VBQUMsQ0FBQyxDQUFDLEVBQUMsR0FBR2IsU0FBUyxDQUFDUyxHQUFHLENBQUNHLENBQUMsSUFBRXRCLGNBQWMsQ0FBQztJQUFDLEdBQUdzQixDQUFDO0lBQUNkO0VBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1VTtBQUNBLE9BQU8sU0FBU2tCLG1CQUFtQkEsQ0FBQ0MsQ0FBNkIsRUFBQ0MsQ0FBNkIsRUFBQztFQUFDLE9BQU96QixTQUFTLENBQUN3QixDQUFDLEdBQUM7SUFBQ0gsTUFBTSxFQUFDRyxDQUFDLENBQUNILE1BQU07SUFBQ0ssU0FBUyxFQUFDRixDQUFDLENBQUNFO0VBQVMsQ0FBQyxHQUFDLElBQUksRUFBQ0QsQ0FBQyxHQUFDO0lBQUNKLE1BQU0sRUFBQ0ksQ0FBQyxDQUFDSixNQUFNO0lBQUNLLFNBQVMsRUFBQ0QsQ0FBQyxDQUFDQztFQUFTLENBQUMsR0FBQyxJQUFJLENBQUM7QUFBQztBQUNqTixTQUFTQyxPQUFPQSxDQUFDUCxHQUFnQixFQUF3QjtFQUN4RCxNQUFNUSxNQUE2QixHQUFDO0lBQUNqQixFQUFFLEVBQUNTLEdBQUcsQ0FBQ1QsRUFBRTtJQUFDQyxTQUFTLEVBQUNRLEdBQUcsQ0FBQ1IsU0FBUztJQUFDUCxRQUFRLEVBQUNlLEdBQUcsQ0FBQ2Y7RUFBUSxDQUFDO0VBQzdGLEtBQUksTUFBTSxDQUFDd0IsR0FBRyxFQUFDQyxLQUFLLENBQUMsSUFBR0MsTUFBTSxDQUFDQyxPQUFPLENBQUNaLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDLEVBQUM7SUFBQyxJQUFHUSxHQUFHLENBQUNJLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBQztNQUFBLElBQUFDLFlBQUE7TUFBQyxNQUFNQyxNQUFNLEdBQUNOLEdBQUcsQ0FBQ08sS0FBSyxDQUFDLENBQUMsQ0FBQztNQUFDLElBQUcsQ0FBQ0QsTUFBTSxJQUFFQSxNQUFNLENBQUNFLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBRSxDQUFDLFdBQVcsRUFBQyxXQUFXLEVBQUMsYUFBYSxDQUFDLENBQUNBLFFBQVEsQ0FBQ0YsTUFBTSxDQUFDLEVBQUMsTUFBTSxJQUFJbEMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7TUFBQyxDQUFBaUMsWUFBQSxHQUFBTixNQUFNLENBQUNVLElBQUksY0FBQUosWUFBQSxjQUFBQSxZQUFBLEdBQVhOLE1BQU0sQ0FBQ1UsSUFBSSxHQUFHLENBQUMsQ0FBQztNQUFFVixNQUFNLENBQUNVLElBQUksQ0FBNEJILE1BQU0sQ0FBQyxHQUFDckMsS0FBSyxDQUFDZ0MsS0FBSyxDQUFDO0lBQUMsQ0FBQyxNQUFJO01BQUMsSUFBRyxDQUFDLElBQUksRUFBQyxXQUFXLEVBQUMsVUFBVSxFQUFDLFdBQVcsRUFBQyxXQUFXLEVBQUMscUJBQXFCLEVBQUMsV0FBVyxFQUFDLFdBQVcsRUFBQyxhQUFhLENBQUMsQ0FBQ08sUUFBUSxDQUFDUixHQUFHLENBQUMsRUFBQyxNQUFNLElBQUk1QixpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztNQUFDMkIsTUFBTSxDQUFDQyxHQUFHLENBQUMsR0FBQy9CLEtBQUssQ0FBQ2dDLEtBQUssQ0FBQztJQUFDO0VBQUM7RUFDdGhCLElBQUdWLEdBQUcsQ0FBQ00sU0FBUyxFQUFDO0lBQUNFLE1BQU0sQ0FBQ1csU0FBUyxHQUFDbkIsR0FBRyxDQUFDTSxTQUFTLENBQUNhLFNBQVM7SUFBQ1gsTUFBTSxDQUFDWSxtQkFBbUIsR0FBQ3BCLEdBQUcsQ0FBQ00sU0FBUyxDQUFDZSxXQUFXO0VBQUM7RUFBQyxPQUFPYixNQUFNO0FBQy9IO0FBQ0E7QUFDQSxPQUFPLFNBQVNjLG1CQUFtQkEsQ0FBQ0MsUUFBb0IsRUFBQ0MsU0FBd0IsRUFBQ0MsR0FBVSxFQUFhO0VBQ3hHLE1BQU1DLElBQUksR0FBQyxJQUFJQyxHQUFHLENBQUNILFNBQVMsQ0FBQzVCLEdBQUcsQ0FBQ0ksR0FBRyxJQUFFLENBQUNBLEdBQUcsQ0FBQ1QsRUFBRSxFQUFDUyxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQUMsSUFBRzBCLElBQUksQ0FBQ0UsSUFBSSxLQUFHSixTQUFTLENBQUNLLE1BQU0sRUFBQyxNQUFNLElBQUloRCxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUNwSSxNQUFNaUQsSUFBSSxHQUFDSixJQUFJLENBQUNLLEdBQUcsQ0FBQ1IsUUFBUSxDQUFDL0IsU0FBUyxDQUFDO0VBQUMsSUFBRyxDQUFDc0MsSUFBSSxJQUFFQSxJQUFJLENBQUM3QixNQUFNLENBQUNSLElBQUksS0FBRyxTQUFTLElBQUVxQyxJQUFJLENBQUN4QixTQUFTLEVBQUMsTUFBTSxJQUFJekIsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7RUFDOUksTUFBTW1ELEdBQUcsR0FBQ3pCLE9BQU8sQ0FBQ3VCLElBQUksQ0FBQztJQUFDO01BQUN2QyxFQUFFLEVBQUMwQyxHQUFHO01BQUN4QyxJQUFJLEVBQUN5QyxLQUFLO01BQUN4QyxVQUFVLEVBQUN5QyxXQUFXO01BQUN4QyxTQUFTO01BQUNHLFdBQVc7TUFBQyxHQUFHUjtJQUFNLENBQUMsR0FBQzBDLEdBQUc7RUFDdEcsSUFBRyxDQUFDSSxLQUFLLENBQUNDLE9BQU8sQ0FBQzFDLFNBQVMsQ0FBQyxJQUFFLENBQUN5QyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3ZDLFdBQVcsQ0FBQyxJQUFFLENBQUMsR0FBR0gsU0FBUyxFQUFDLEdBQUdHLFdBQVcsQ0FBQyxDQUFDd0MsSUFBSSxDQUFDL0MsRUFBRSxJQUFFLE9BQU9BLEVBQUUsS0FBRyxRQUFRLENBQUMsSUFBRSxJQUFJZ0QsR0FBRyxDQUFDLENBQUMsR0FBRzVDLFNBQVMsRUFBQyxHQUFHRyxXQUFXLEVBQUNnQyxJQUFJLENBQUN2QyxFQUFFLENBQUMsQ0FBQyxDQUFDcUMsSUFBSSxLQUFHSixTQUFTLENBQUNLLE1BQU0sRUFBQyxNQUFNLElBQUloRCxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUMvTyxNQUFNMkQsT0FBTyxHQUFDLElBQUliLEdBQUcsQ0FBQyxDQUFDLEdBQUdKLFFBQVEsQ0FBQ3JDLFFBQVEsRUFBQyxHQUFHcUMsUUFBUSxDQUFDcEMsU0FBUyxDQUFDLENBQUNTLEdBQUcsQ0FBQzZDLE1BQU0sSUFBRSxDQUFDQSxNQUFNLENBQUNsRCxFQUFFLEVBQUNrRCxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25HLE1BQU1WLEdBQUcsR0FBQ0EsQ0FBQ3hDLEVBQVUsRUFBQ21ELE1BQWMsS0FBRztJQUFBLElBQUFDLGFBQUE7SUFBQyxNQUFNM0MsR0FBRyxHQUFDMEIsSUFBSSxDQUFDSyxHQUFHLENBQUN4QyxFQUFZLENBQUM7SUFBQyxJQUFHLENBQUNTLEdBQUcsSUFBRUEsR0FBRyxDQUFDUixTQUFTLEtBQUcrQixRQUFRLENBQUMvQixTQUFTLEVBQUMsTUFBTSxJQUFJWCxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztJQUFDLE1BQU00RCxNQUFNLEdBQUNsQyxPQUFPLENBQUNQLEdBQUcsQ0FBQztNQUFDNEMsR0FBRyxHQUFDSixPQUFPLENBQUNULEdBQUcsQ0FBQy9CLEdBQUcsQ0FBQ1QsRUFBRSxDQUFDO0lBQUMsSUFBR21ELE1BQU0sRUFBQztNQUFBLElBQUFHLGlCQUFBO01BQUNKLE1BQU0sQ0FBQ3ZDLFNBQVMsSUFBQTJDLGlCQUFBLEdBQUNKLE1BQU0sQ0FBQ3ZDLFNBQVMsY0FBQTJDLGlCQUFBLGNBQUFBLGlCQUFBLEdBQUdELEdBQUcsSUFBRSxXQUFXLElBQUdBLEdBQUcsR0FBQ0EsR0FBRyxDQUFDMUMsU0FBUyxHQUFDdUIsR0FBSTtNQUFDLElBQUdtQixHQUFHLElBQUUsV0FBVyxJQUFHQSxHQUFHLElBQUVBLEdBQUcsQ0FBQzFDLFNBQVMsS0FBR3VDLE1BQU0sQ0FBQ3ZDLFNBQVMsRUFBQyxNQUFNLElBQUlyQixpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztNQUFDNEQsTUFBTSxDQUFDSyxTQUFTLEdBQUNGLEdBQUcsSUFBRSxXQUFXLElBQUdBLEdBQUcsR0FBQ0EsR0FBRyxDQUFDRSxTQUFTLEdBQUNyQixHQUFHO0lBQUM7SUFBQ2dCLE1BQU0sQ0FBQ3hELFFBQVEsSUFBQTBELGFBQUEsR0FBQ0MsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUUzRCxRQUFRLGNBQUEwRCxhQUFBLGNBQUFBLGFBQUEsR0FBRSxHQUFHO0lBQUMsSUFBRyxDQUFDM0MsR0FBRyxDQUFDTSxTQUFTLEVBQUM7TUFBQyxPQUFPbUMsTUFBTSxDQUFDdEIsU0FBUztNQUFDLE9BQU9zQixNQUFNLENBQUNyQixtQkFBbUI7SUFBQztJQUFDLE9BQU9xQixNQUFNO0VBQUMsQ0FBQztFQUN2bEIsT0FBTztJQUFDLEdBQUduRCxNQUFNO0lBQUNFLFNBQVMsRUFBQytCLFFBQVEsQ0FBQy9CLFNBQVM7SUFBQ1AsUUFBUSxFQUFDc0MsUUFBUSxDQUFDdEMsUUFBUTtJQUFDQyxRQUFRLEVBQUNTLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDTCxFQUFFLElBQUV3QyxHQUFHLENBQUN4QyxFQUFFLEVBQUMsSUFBSSxDQUFDLENBQWE7SUFBQ0osU0FBUyxFQUFDVyxXQUFXLENBQUNGLEdBQUcsQ0FBQ0wsRUFBRSxJQUFFd0MsR0FBRyxDQUFDeEMsRUFBRSxFQUFDLEtBQUssQ0FBQyxDQUEwQjtJQUFDSCxPQUFPLEVBQUNtQyxRQUFRLENBQUNuQztFQUFPLENBQUM7QUFDL047QUFDQSxPQUFPLGVBQWUyRCxzQkFBc0JBLENBQUNDLEtBQWUsRUFBQ0MsSUFBc0IsRUFBQ2pFLE9BQW1CLEVBQUNrRSxTQUFrQixFQUFDQyxNQUFhLEVBQXVDO0VBQzlLSCxLQUFLLEdBQUN0RSxLQUFLLENBQUNzRSxLQUFLLENBQUM7RUFBQyxNQUFNSSxRQUFRLEdBQUMxRSxLQUFLLENBQUNNLE9BQU8sQ0FBQztJQUFDcUUsU0FBUyxHQUFDM0UsS0FBSyxDQUFDdUUsSUFBSSxDQUFDO0lBQUNLLEdBQUcsR0FBQzVFLEtBQUssQ0FBQ3dFLFNBQVMsQ0FBQztJQUFDSyxLQUFLLEdBQUN4RSxlQUFlLENBQUNxRSxRQUFRLEVBQUNDLFNBQVMsQ0FBQ0csY0FBYyxDQUFDO0lBQUNaLEdBQUcsR0FBQyxJQUFJakIsR0FBRyxDQUFDMEIsU0FBUyxDQUFDN0IsU0FBUyxDQUFDNUIsR0FBRyxDQUFDSSxHQUFHLElBQUUsQ0FBQ0EsR0FBRyxDQUFDVCxFQUFFLEVBQUNTLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDNU0sTUFBTXlELE9BQU8sR0FBQ0YsS0FBSyxDQUFDRyxNQUFNLENBQUMxRCxHQUFHLElBQUUsQ0FBQ0csbUJBQW1CLENBQUN5QyxHQUFHLENBQUNiLEdBQUcsQ0FBQy9CLEdBQUcsQ0FBQ1QsRUFBRSxDQUFDLEVBQUNTLEdBQUcsQ0FBQyxDQUFDLENBQUNKLEdBQUcsQ0FBQ0ksR0FBRztJQUFBLElBQUEyRCxRQUFBO0lBQUEsT0FBRztNQUFDVixJQUFJLEdBQUFVLFFBQUEsR0FBQ2YsR0FBRyxDQUFDYixHQUFHLENBQUMvQixHQUFHLENBQUNULEVBQUUsQ0FBQyxjQUFBb0UsUUFBQSxjQUFBQSxRQUFBLEdBQUUsSUFBSTtNQUFDSixLQUFLLEVBQUN2RDtJQUFHLENBQUM7RUFBQSxDQUFDLENBQUM7RUFDN0g7RUFDQSxJQUFHcUQsU0FBUyxDQUFDN0IsU0FBUyxDQUFDYyxJQUFJLENBQUN0QyxHQUFHLElBQUUsQ0FBQ3VELEtBQUssQ0FBQ2pCLElBQUksQ0FBQzVCLEtBQUssSUFBRUEsS0FBSyxDQUFDbkIsRUFBRSxLQUFHUyxHQUFHLENBQUNULEVBQUUsQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJVixpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUN2SCxJQUFHLENBQUM0RSxPQUFPLENBQUM1QixNQUFNLEVBQUMsT0FBTyxJQUFJO0VBQzlCLE1BQU0rQixTQUFTLEdBQUMsTUFBTWpGLG1CQUFtQixDQUFDO0lBQUNxRSxLQUFLLEVBQUN0RSxLQUFLLENBQUNzRSxLQUFLLENBQUM7SUFBQ2EsWUFBWSxFQUFDUixTQUFTLENBQUNHLGNBQWM7SUFBQ25DLFdBQVcsRUFBQzlDLEtBQUssQ0FBQyxDQUFDO0lBQUNrRixPQUFPO0lBQUNOO0VBQU0sQ0FBQyxDQUFDO0VBQ3hJLE9BQU87SUFBQzlCLFdBQVcsRUFBQ3VDLFNBQVMsQ0FBQ3ZDLFdBQVc7SUFBQzdCLFNBQVMsRUFBQ3dELEtBQUssQ0FBQ3hELFNBQVM7SUFBQ29FLFNBQVM7SUFBQ0UsYUFBYSxFQUFDVixRQUFRLENBQUNuRSxRQUFRO0lBQUM4RSxjQUFjLEVBQUNSLEtBQUs7SUFBQ0wsU0FBUyxFQUFDSSxHQUFHO0lBQUNwRCxTQUFTLEVBQUMsSUFBSThELElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztFQUFDLENBQUM7QUFDckw7QUFDQTtBQUNBLE9BQU8sU0FBU0MsMEJBQTBCQSxDQUFDQyxRQUFnQyxFQUFDbEIsSUFBc0IsRUFBQ21CLEdBQVcsRUFBQ0MsT0FBa0MsRUFBQztFQUNqSixJQUFHQyxNQUFNLENBQUNGLEdBQUcsQ0FBQ1osY0FBYyxDQUFDLEdBQUNjLE1BQU0sQ0FBQ3JCLElBQUksQ0FBQ08sY0FBYyxDQUFDLElBQUUsQ0FBQ1ksR0FBRyxDQUFDRyxrQkFBa0IsRUFBQyxNQUFNLElBQUkxRixpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUNsSSxNQUFNd0UsU0FBUyxHQUFDLElBQUkxQixHQUFHLENBQUN5QyxHQUFHLENBQUNHLGtCQUFrQixDQUFDM0UsR0FBRyxDQUFDSSxHQUFHLElBQUUsQ0FBQ0EsR0FBRyxDQUFDVCxFQUFFLEVBQUNiLEtBQUssQ0FBQ3NCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM3RSxNQUFNd0UsTUFBTSxHQUFDcEMsS0FBSyxDQUFDQyxPQUFPLENBQUNnQyxPQUFPLENBQUMsR0FBQ0EsT0FBTyxHQUFDdEYsZUFBZSxDQUFDc0YsT0FBTyxFQUFDRCxHQUFHLENBQUNaLGNBQWMsQ0FBQztJQUFDaUIsTUFBTSxHQUFDLElBQUk5QyxHQUFHLENBQUN3QyxRQUFRLENBQUNKLGNBQWMsQ0FBQ25FLEdBQUcsQ0FBQ0ksR0FBRyxJQUFFLENBQUNBLEdBQUcsQ0FBQ1QsRUFBRSxFQUFDUyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUMwRSxTQUF3QixHQUFDLEVBQUU7SUFBQ0MsSUFBbUIsR0FBQyxFQUFFO0VBQ3pNLEtBQUksTUFBTXBCLEtBQUssSUFBSWlCLE1BQU0sRUFBQztJQUFBLElBQUFJLGNBQUEsRUFBQUMsV0FBQTtJQUFDLE1BQU1DLE1BQU0sSUFBQUYsY0FBQSxHQUFDdkIsU0FBUyxDQUFDdEIsR0FBRyxDQUFDd0IsS0FBSyxDQUFDaEUsRUFBRSxDQUFDLGNBQUFxRixjQUFBLGNBQUFBLGNBQUEsR0FBRSxJQUFJO01BQUNHLEtBQUssSUFBQUYsV0FBQSxHQUFDSixNQUFNLENBQUMxQyxHQUFHLENBQUN3QixLQUFLLENBQUNoRSxFQUFFLENBQUMsY0FBQXNGLFdBQUEsY0FBQUEsV0FBQSxHQUFFLElBQUk7SUFDckcsSUFBRyxDQUFDRSxLQUFLLElBQUUsQ0FBQ0QsTUFBTSxFQUFDO01BQUNILElBQUksQ0FBQ0ssSUFBSSxDQUFDdEcsS0FBSyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7TUFBQztJQUFTO0lBQ3JELE1BQU0wQixNQUFNLEdBQUNuRyxhQUFhLENBQUNpRyxLQUFLLEVBQUN4QixLQUFLLEVBQUN1QixNQUFNLENBQUM7SUFBQyxJQUFHRyxNQUFNLENBQUNDLE1BQU0sS0FBRyxVQUFVLEVBQUM7TUFBQ1IsU0FBUyxDQUFDTSxJQUFJLENBQUNDLE1BQU0sQ0FBQ0UsUUFBUSxDQUFDO01BQUNSLElBQUksQ0FBQ0ssSUFBSSxDQUFDdEcsS0FBSyxDQUFDNkUsS0FBSyxDQUFDLENBQUM7SUFBQyxDQUFDLE1BQUtvQixJQUFJLENBQUNLLElBQUksQ0FBQ0MsTUFBTSxDQUFDRyxRQUFRLENBQUM7RUFDdks7RUFDQSxLQUFJLE1BQU1OLE1BQU0sSUFBSXpCLFNBQVMsQ0FBQ2dDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsSUFBRyxDQUFDVixJQUFJLENBQUNyQyxJQUFJLENBQUN0QyxHQUFHLElBQUVBLEdBQUcsQ0FBQ1QsRUFBRSxLQUFHdUYsTUFBTSxDQUFDdkYsRUFBRSxDQUFDLEVBQUNvRixJQUFJLENBQUNLLElBQUksQ0FBQ3RHLEtBQUssQ0FBQ29HLE1BQU0sQ0FBQyxDQUFDO0VBQ3RHLE9BQU87SUFBQ3pCLFNBQVMsRUFBQyxDQUFDLEdBQUdBLFNBQVMsQ0FBQ2dDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFBQzdELFNBQVMsRUFBQ21ELElBQUk7SUFBQ0Q7RUFBUyxDQUFDO0FBQ3BFO0FBQ0EsT0FBTyxTQUFTWSxxQkFBcUJBLENBQUNDLEtBQTZCLEVBQUNDLE9BQXlDLEVBQUNoQixNQUFxQixFQUFDO0VBQ25JLE1BQU05QyxJQUFJLEdBQUMsSUFBSUMsR0FBRyxDQUFDNkMsTUFBTSxDQUFDNUUsR0FBRyxDQUFDSSxHQUFHLElBQUUsQ0FBQ0EsR0FBRyxDQUFDVCxFQUFFLEVBQUNTLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDakQsSUFBRyxDQUFDcEIsU0FBUyxDQUFDK0IsTUFBTSxDQUFDOEUsSUFBSSxDQUFDRCxPQUFPLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsRUFBQ0gsS0FBSyxDQUFDYixTQUFTLENBQUM5RSxHQUFHLENBQUMrRixDQUFDLElBQUVBLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLENBQUNGLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxNQUFNLElBQUk3RyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUNwSSxPQUFPMEcsS0FBSyxDQUFDcEIsUUFBUSxDQUFDUCxTQUFTLENBQUNILE9BQU8sQ0FBQzdELEdBQUcsQ0FBQyxDQUFDaUcsTUFBTSxFQUFDQyxLQUFLLEtBQUc7SUFBQSxJQUFBQyxTQUFBO0lBQzNELE1BQU05QyxJQUFJLEdBQUNzQyxLQUFLLENBQUNuQixHQUFHLENBQUM1QyxTQUFTLENBQUNzRSxLQUFLLENBQUM7TUFBQ2hCLE1BQU0sSUFBQWlCLFNBQUEsR0FBQ3JFLElBQUksQ0FBQ0ssR0FBRyxDQUFDOEQsTUFBTSxDQUFDRCxRQUFRLENBQUMsY0FBQUcsU0FBQSxjQUFBQSxTQUFBLEdBQUUsSUFBSTtJQUFDLElBQUcsQ0FBQ25ILFNBQVMsQ0FBQ3FFLElBQUksRUFBQzZCLE1BQU0sQ0FBQyxFQUFDLE1BQU0sSUFBSWpHLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0lBQ3ZKLE1BQU1zRyxRQUFRLEdBQUNJLEtBQUssQ0FBQ2IsU0FBUyxDQUFDc0IsSUFBSSxDQUFDTCxDQUFDLElBQUVBLENBQUMsQ0FBQ0MsUUFBUSxLQUFHQyxNQUFNLENBQUNELFFBQVEsQ0FBQztJQUFDLElBQUlyQyxLQUFrQjtJQUMzRixJQUFHLENBQUM0QixRQUFRLEVBQUM7TUFBQyxNQUFNRixNQUFNLEdBQUNuRyxhQUFhLENBQUMrRyxNQUFNLENBQUM1QyxJQUFJLEVBQUM0QyxNQUFNLENBQUN0QyxLQUFLLEVBQUN1QixNQUFNLENBQUM7TUFBQyxJQUFHRyxNQUFNLENBQUNDLE1BQU0sS0FBRyxRQUFRLEVBQUMsTUFBTSxJQUFJckcsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7TUFBQzBFLEtBQUssR0FBQzBCLE1BQU0sQ0FBQ0csUUFBUTtJQUFDLENBQUMsTUFDeks7TUFBQyxNQUFNYSxNQUFNLEdBQUNULE9BQU8sQ0FBQ0ssTUFBTSxDQUFDRCxRQUFRLENBQUM7TUFBQyxJQUFHSyxNQUFNLENBQUNDLFFBQVEsS0FBRyxRQUFRLEVBQUM7UUFDeEUsSUFBR2YsUUFBUSxDQUFDZ0IsT0FBTyxDQUFDN0QsSUFBSSxDQUFDYSxNQUFNLElBQUVBLE1BQU0sS0FBRyxZQUFZLENBQUMsSUFBRSxDQUFDdkUsU0FBUyxDQUFDK0IsTUFBTSxDQUFDOEUsSUFBSSxDQUFDUSxNQUFNLENBQUNULE9BQU8sQ0FBQyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxFQUFDUCxRQUFRLENBQUNsRixNQUFNLENBQUNMLEdBQUcsQ0FBQ3dHLEtBQUssSUFBRUEsS0FBSyxDQUFDQSxLQUFLLENBQUMsQ0FBQ1YsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUNaLE1BQU0sRUFBQyxNQUFNLElBQUlqRyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztRQUMvTTBFLEtBQUssR0FBQzdFLEtBQUssQ0FBQ29HLE1BQU0sQ0FBQztRQUFDdkIsS0FBSyxDQUFDdEQsTUFBTSxHQUFDLENBQUMsQ0FBQztRQUFDLEtBQUksTUFBTSxDQUFDbUcsS0FBSyxFQUFDQyxJQUFJLENBQUMsSUFBRzFGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDdUUsUUFBUSxDQUFDbUIsZUFBZSxDQUFDLEVBQUMsSUFBR0QsSUFBSSxDQUFDRSxPQUFPLEVBQUNoRCxLQUFLLENBQUN0RCxNQUFNLENBQUNtRyxLQUFLLENBQUMsR0FBQzFILEtBQUssQ0FBQzJILElBQUksQ0FBQzNGLEtBQUssQ0FBQztRQUMzSixLQUFJLE1BQU0wRixLQUFLLElBQUlqQixRQUFRLENBQUNsRixNQUFNLEVBQUM7VUFBQyxNQUFNdUcsUUFBUSxHQUFDUCxNQUFNLENBQUNULE9BQU8sQ0FBQ1ksS0FBSyxDQUFDQSxLQUFLLENBQUM7WUFBQ0MsSUFBSSxHQUFDRyxRQUFRLEtBQUcsT0FBTyxHQUFDSixLQUFLLENBQUM3QyxLQUFLLEdBQUNpRCxRQUFRLEtBQUcsUUFBUSxHQUFDSixLQUFLLENBQUN0QixNQUFNLEdBQUMwQixRQUFRLENBQUM5RixLQUFLO1VBQUMsSUFBRzJGLElBQUksQ0FBQ0UsT0FBTyxFQUFDaEQsS0FBSyxDQUFDdEQsTUFBTSxDQUFDbUcsS0FBSyxDQUFDQSxLQUFLLENBQUMsR0FBQzFILEtBQUssQ0FBQzJILElBQUksQ0FBQzNGLEtBQUssQ0FBQztRQUFDO01BQ2hPLENBQUMsTUFBSTtRQUFDNkMsS0FBSyxHQUFDN0UsS0FBSyxDQUFDdUgsTUFBTSxDQUFDQyxRQUFRLEtBQUcsT0FBTyxHQUFDZixRQUFRLENBQUM1QixLQUFLLEdBQUN1QixNQUFNLGFBQU5BLE1BQU0sY0FBTkEsTUFBTSxHQUFFLENBQUMsTUFBSTtVQUFDLE1BQU0sSUFBSWpHLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO1FBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztNQUFDO0lBQUM7SUFDaEksT0FBTztNQUFDb0UsSUFBSTtNQUFDTTtJQUFLLENBQUM7RUFDcEIsQ0FBQyxDQUFDO0FBQ0g7QUFDQTtBQUNBLE9BQU8sU0FBU2tELDRCQUE0QkEsQ0FBQ2xCLEtBQTZCLEVBQUNDLE9BQXlDLEVBQUNrQixlQUE4QixFQUFDckMsT0FBa0MsRUFBQztFQUN0TCxNQUFNUyxNQUFNLEdBQUMsSUFBSW5ELEdBQUcsQ0FBQytFLGVBQWUsQ0FBQzlHLEdBQUcsQ0FBQ0ksR0FBRyxJQUFFLENBQUNBLEdBQUcsQ0FBQ1QsRUFBRSxFQUFDUyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUN1RCxLQUFLLEdBQUMsSUFBSTVCLEdBQUcsQ0FBQyxDQUFDUyxLQUFLLENBQUNDLE9BQU8sQ0FBQ2dDLE9BQU8sQ0FBQyxHQUFDQSxPQUFPLEdBQUN0RixlQUFlLENBQUNzRixPQUFPLEVBQUNrQixLQUFLLENBQUNuQixHQUFHLENBQUNaLGNBQWMsQ0FBQyxFQUFFNUQsR0FBRyxDQUFDSSxHQUFHLElBQUUsQ0FBQ0EsR0FBRyxDQUFDVCxFQUFFLEVBQUNTLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDckwsSUFBRyxDQUFDcEIsU0FBUyxDQUFDK0IsTUFBTSxDQUFDOEUsSUFBSSxDQUFDRCxPQUFPLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsRUFBQ0gsS0FBSyxDQUFDYixTQUFTLENBQUM5RSxHQUFHLENBQUMrRixDQUFDLElBQUVBLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLENBQUNGLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxNQUFNLElBQUk3RyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUNwSSxNQUFNeUUsR0FBRyxHQUFDLElBQUlmLEdBQUcsQ0FBQyxDQUFDLEdBQUdnRCxLQUFLLENBQUNwQixRQUFRLENBQUNQLFNBQVMsQ0FBQ0gsT0FBTyxDQUFDN0QsR0FBRyxDQUFDK0csQ0FBQyxJQUFFQSxDQUFDLENBQUNmLFFBQVEsQ0FBQyxFQUFDLEdBQUdMLEtBQUssQ0FBQ2IsU0FBUyxDQUFDOUUsR0FBRyxDQUFDK0YsQ0FBQyxJQUFFQSxDQUFDLENBQUNDLFFBQVEsQ0FBQyxFQUFDLEdBQUdyQyxLQUFLLENBQUNrQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDakksTUFBTWhDLE9BQXFELEdBQUMsRUFBRTtFQUM5RCxLQUFJLE1BQU1sRSxFQUFFLElBQUkrRCxHQUFHLEVBQUM7SUFBQSxJQUFBc0QsV0FBQTtJQUFDLE1BQU1DLE1BQU0sSUFBQUQsV0FBQSxHQUFDOUIsTUFBTSxDQUFDL0MsR0FBRyxDQUFDeEMsRUFBRSxDQUFDLGNBQUFxSCxXQUFBLGNBQUFBLFdBQUEsR0FBRSxJQUFJO01BQUNuRixHQUFHLEdBQUM4QixLQUFLLENBQUN4QixHQUFHLENBQUN4QyxFQUFFLENBQUM7TUFBQ3FELEdBQUcsR0FBQzJDLEtBQUssQ0FBQ3BCLFFBQVEsQ0FBQ1AsU0FBUyxDQUFDSCxPQUFPLENBQUN1QyxJQUFJLENBQUNXLENBQUMsSUFBRUEsQ0FBQyxDQUFDZixRQUFRLEtBQUdyRyxFQUFFLENBQUM7TUFBQzZELFFBQVEsR0FBQ21DLEtBQUssQ0FBQ2IsU0FBUyxDQUFDc0IsSUFBSSxDQUFDTCxDQUFDLElBQUVBLENBQUMsQ0FBQ0MsUUFBUSxLQUFHckcsRUFBRSxDQUFDO0lBQUMsSUFBRyxDQUFDa0MsR0FBRyxFQUFDLE1BQU0sSUFBSTVDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0lBQUMsSUFBSWlJLFFBQVEsR0FBQ3BJLEtBQUssQ0FBQytDLEdBQUcsQ0FBQztJQUN2USxJQUFHMkIsUUFBUSxFQUFDO01BQUMsSUFBRyxDQUFDeEUsU0FBUyxDQUFDd0UsUUFBUSxDQUFDMEIsTUFBTSxFQUFDK0IsTUFBTSxDQUFDLEVBQUMsTUFBTSxJQUFJaEksaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7TUFBQyxNQUFNa0ksS0FBSyxHQUFDakksYUFBYSxDQUFDc0UsUUFBUSxDQUFDSCxJQUFJLEVBQUN4QixHQUFHLEVBQUNvRixNQUFNLENBQUM7UUFBQ1osTUFBTSxHQUFDVCxPQUFPLENBQUNqRyxFQUFFLENBQUM7TUFDeEssSUFBR3dILEtBQUssQ0FBQzdCLE1BQU0sS0FBRyxRQUFRLEVBQUM0QixRQUFRLEdBQUNDLEtBQUssQ0FBQzNCLFFBQVEsQ0FBQyxLQUM5QyxJQUFHYSxNQUFNLENBQUNDLFFBQVEsS0FBRyxRQUFRLEVBQUM7UUFDbEMsSUFBR2EsS0FBSyxDQUFDNUIsUUFBUSxDQUFDZ0IsT0FBTyxDQUFDN0QsSUFBSSxDQUFDdkMsQ0FBQyxJQUFFQSxDQUFDLEtBQUcsWUFBWSxDQUFDLElBQUUsQ0FBQ25CLFNBQVMsQ0FBQytCLE1BQU0sQ0FBQzhFLElBQUksQ0FBQ1EsTUFBTSxDQUFDVCxPQUFPLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsRUFBQ3FCLEtBQUssQ0FBQzVCLFFBQVEsQ0FBQ2xGLE1BQU0sQ0FBQ0wsR0FBRyxDQUFDb0gsQ0FBQyxJQUFFQSxDQUFDLENBQUNaLEtBQUssQ0FBQyxDQUFDVixJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQ21CLE1BQU0sRUFBQyxNQUFNLElBQUloSSxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztRQUN6TWlJLFFBQVEsR0FBQ3BJLEtBQUssQ0FBQ21JLE1BQU0sQ0FBQztRQUFDQyxRQUFRLENBQUM3RyxNQUFNLEdBQUMsQ0FBQyxDQUFDO1FBQUMsS0FBSSxNQUFNLENBQUNtRyxLQUFLLEVBQUNDLElBQUksQ0FBQyxJQUFHMUYsTUFBTSxDQUFDQyxPQUFPLENBQUNtRyxLQUFLLENBQUM1QixRQUFRLENBQUNtQixlQUFlLENBQUMsRUFBQyxJQUFHRCxJQUFJLENBQUNFLE9BQU8sRUFBQ08sUUFBUSxDQUFDN0csTUFBTSxDQUFDbUcsS0FBSyxDQUFDLEdBQUMxSCxLQUFLLENBQUMySCxJQUFJLENBQUMzRixLQUFLLENBQUM7UUFDMUssS0FBSSxNQUFNMEYsS0FBSyxJQUFJVyxLQUFLLENBQUM1QixRQUFRLENBQUNsRixNQUFNLEVBQUM7VUFBQyxNQUFNZ0gsSUFBSSxHQUFDaEIsTUFBTSxDQUFDVCxPQUFPLENBQUNZLEtBQUssQ0FBQ0EsS0FBSyxDQUFDO1lBQUNDLElBQUksR0FBQ1ksSUFBSSxLQUFHLE9BQU8sR0FBQ2IsS0FBSyxDQUFDN0MsS0FBSyxHQUFDMEQsSUFBSSxLQUFHLFFBQVEsR0FBQ2IsS0FBSyxDQUFDdEIsTUFBTSxHQUFDbUMsSUFBSSxDQUFDdkcsS0FBSztVQUFDLElBQUcyRixJQUFJLENBQUNFLE9BQU8sRUFBQ08sUUFBUSxDQUFDN0csTUFBTSxDQUFDbUcsS0FBSyxDQUFDQSxLQUFLLENBQUMsR0FBQzFILEtBQUssQ0FBQzJILElBQUksQ0FBQzNGLEtBQUssQ0FBQztRQUFDO01BQ3pOLENBQUMsTUFBSyxJQUFHcUcsS0FBSyxDQUFDNUIsUUFBUSxDQUFDZ0IsT0FBTyxDQUFDZSxLQUFLLENBQUNuSCxDQUFDLElBQUVBLENBQUMsS0FBRyxZQUFZLENBQUMsSUFBRThHLE1BQU0sRUFBQztRQUNsRUMsUUFBUSxHQUFDcEksS0FBSyxDQUFDbUksTUFBTSxDQUFDO1FBQUNDLFFBQVEsQ0FBQzdHLE1BQU0sR0FBQyxDQUFDLENBQUM7UUFBQyxLQUFJLE1BQU0sQ0FBQ21HLEtBQUssRUFBQ0MsSUFBSSxDQUFDLElBQUcxRixNQUFNLENBQUNDLE9BQU8sQ0FBQ21HLEtBQUssQ0FBQzVCLFFBQVEsQ0FBQ21CLGVBQWUsQ0FBQyxFQUFDLElBQUdELElBQUksQ0FBQ0UsT0FBTyxFQUFDTyxRQUFRLENBQUM3RyxNQUFNLENBQUNtRyxLQUFLLENBQUMsR0FBQzFILEtBQUssQ0FBQzJILElBQUksQ0FBQzNGLEtBQUssQ0FBQztRQUMxSyxLQUFJLE1BQU0wRixLQUFLLElBQUlXLEtBQUssQ0FBQzVCLFFBQVEsQ0FBQ2xGLE1BQU0sRUFBQztVQUFDLE1BQU1vRyxJQUFJLEdBQUNKLE1BQU0sQ0FBQ0MsUUFBUSxLQUFHLE9BQU8sR0FBQ0UsS0FBSyxDQUFDN0MsS0FBSyxHQUFDNkMsS0FBSyxDQUFDdEIsTUFBTTtVQUFDLElBQUd1QixJQUFJLENBQUNFLE9BQU8sRUFBQ08sUUFBUSxDQUFDN0csTUFBTSxDQUFDbUcsS0FBSyxDQUFDQSxLQUFLLENBQUMsR0FBQzFILEtBQUssQ0FBQzJILElBQUksQ0FBQzNGLEtBQUssQ0FBQztRQUFDO01BQ3hLLENBQUMsTUFBS29HLFFBQVEsR0FBQ3BJLEtBQUssQ0FBQ3VILE1BQU0sQ0FBQ0MsUUFBUSxLQUFHLE9BQU8sR0FBQ3pFLEdBQUcsR0FBQ29GLE1BQU0sYUFBTkEsTUFBTSxjQUFOQSxNQUFNLEdBQUUsQ0FBQyxNQUFJO1FBQUMsTUFBTSxJQUFJaEksaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7TUFBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZILENBQUMsTUFBSyxJQUFHMEcsS0FBSyxDQUFDbkIsR0FBRyxDQUFDYyxNQUFNLEtBQUcsVUFBVSxJQUFFdEMsR0FBRyxFQUFDO01BQUMsTUFBTW1FLEtBQUssR0FBQ2pJLGFBQWEsQ0FBQzhELEdBQUcsQ0FBQ0ssSUFBSSxFQUFDeEIsR0FBRyxFQUFDb0YsTUFBTSxDQUFDO01BQUMsSUFBR0UsS0FBSyxDQUFDN0IsTUFBTSxLQUFHLFVBQVUsRUFBQyxNQUFNLElBQUlyRyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztNQUFDaUksUUFBUSxHQUFDQyxLQUFLLENBQUMzQixRQUFRO0lBQUM7SUFDak0sSUFBR3hDLEdBQUcsSUFBRVEsUUFBUSxJQUFFLENBQUNqRCxtQkFBbUIsQ0FBQzBHLE1BQU0sRUFBQ0MsUUFBUSxDQUFDLEVBQUNyRCxPQUFPLENBQUN1QixJQUFJLENBQUM7TUFBQy9CLElBQUksRUFBQ3ZFLEtBQUssQ0FBQ21JLE1BQU0sQ0FBQztNQUFDdEQsS0FBSyxFQUFDdUQ7SUFBUSxDQUFDLENBQUM7RUFDMUc7RUFDQSxPQUFPckQsT0FBTztBQUNmO0FBQ0EsT0FBTyxTQUFTMEQsdUJBQXVCQSxDQUFDbkksT0FBbUIsRUFBQ29JLE1BQThELEdBQUMsQ0FBQyxDQUFDLEVBQUM7RUFBQyxNQUFNNUcsTUFBTSxHQUFDaEMsZUFBZSxDQUFDUSxPQUFPLEVBQUM7SUFBQ3FJLGNBQWMsRUFBQ0Q7RUFBTSxDQUFDLENBQUM7RUFBQyxJQUFHLENBQUM1RyxNQUFNLENBQUM4RyxFQUFFLEVBQUMsTUFBTSxJQUFJekksaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7RUFBQyxPQUFPMkIsTUFBTSxDQUFDRSxLQUFLO0FBQUMiLCJpZ25vcmVMaXN0IjpbXX0=