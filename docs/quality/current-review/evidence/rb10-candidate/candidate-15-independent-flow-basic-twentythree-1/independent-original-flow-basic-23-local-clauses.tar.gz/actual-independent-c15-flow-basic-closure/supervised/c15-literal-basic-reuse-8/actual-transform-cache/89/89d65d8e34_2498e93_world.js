// 6b1c506200889e0782e2029257db565661f6705e
import { collectReferences, collectRelationReferences, createEntity, emptyRuntimeState, newId } from './model';
import { immutableReferenceVersion } from './maintenance';
import { evaluateCondition } from './conditions';
import { compareTicks, isTick, parseTick, sameCalendarDefinition } from './time';
import { equalJson, jsonBytes, sha256 } from '../storage/json';
import { adoptedRecord, adoptionAssessment } from './adoption';

/** These predicates are authored explicitly by the world-history form, never guessed from prose. */
export const WORLD_PREDICATES = {
  location: 'location',
  ownership: 'owner',
  membership: 'member_of',
  displayName: 'display_name',
  placeState: 'place_state',
  control: 'controlled_by',
  identity: 'identity',
  appearance: 'appearance_exception'
};
export const WORLD_PREDICATE_LABELS = {
  location: '現在地',
  owner: '所有者',
  member_of: '所属',
  display_name: '場所の名称',
  place_state: '破壊・再建などの状態',
  controlled_by: '支配組織',
  identity: '正体',
  appearance_exception: '回想・記録・復活などの意図'
};
function combine(values) {
  return values.includes('false') ? 'false' : values.includes('unknown') ? 'unknown' : 'true';
}
function hasRuntimeInput(condition) {
  if (condition.op === 'constant') return false;
  if (condition.op === 'not') return hasRuntimeInput(condition.child);
  if (condition.op === 'all' || condition.op === 'any') return condition.children.some(hasRuntimeInput);
  return true;
}
/** Half-open world periods and three-valued route/presentation assessment used by all RB03 views. */
export function assessWorldValidity(validity, point = {}) {
  if (!validity) return {
    value: 'true',
    reasons: []
  };
  const values = [],
    reasons = [];
  if (validity.worldRange && (validity.worldRange.start !== null || validity.worldRange.end !== null)) {
    if (!point.at || !isTick(point.at)) {
      values.push('unknown');
      reasons.push('世界時点が未選択です。');
    } else {
      const range = validity.worldRange;
      values.push(range.start && compareTicks(point.at, range.start) < 0 || range.end && compareTicks(point.at, range.end) >= 0 ? 'false' : 'true');
    }
  }
  if (validity.routeCondition) {
    if (!point.context && hasRuntimeInput(validity.routeCondition)) {
      values.push('unknown');
      reasons.push('経路・状態の値が未選択です。');
    } else try {
      var _point$context;
      const result = evaluateCondition(validity.routeCondition, (_point$context = point.context) !== null && _point$context !== void 0 ? _point$context : {
        state: emptyRuntimeState('world-view')
      });
      values.push(result.value);
      reasons.push(...result.reasons);
    } catch (error) {
      values.push('unknown');
      reasons.push(error instanceof Error ? error.message : '経路条件を確認できません。');
    }
  }
  if (validity.presentationAnchor) {
    if (!point.presentationIds) {
      values.push('unknown');
      reasons.push('提示位置が未選択です。');
    } else values.push(point.presentationIds.includes(validity.presentationAnchor.entityId) ? 'true' : 'false');
  }
  return {
    value: combine(values),
    reasons: [...new Set(reasons)]
  };
}
export function assertionReference(value) {
  return typeof value === 'string' ? value : value.type === 'ref' ? value.value : undefined;
}
export function assertionValueLabel(value, index) {
  var _index$get;
  const reference = assertionReference(value);
  if (reference) return ((_index$get = index.get(reference)) === null || _index$get === void 0 ? void 0 : _index$get.name) || '参照先未確認';
  return typeof value !== 'string' && value.type === 'unknown' ? `不明 · ${value.reason}` : typeof value !== 'string' ? String(value.value) : value;
}
function assessStateCandidates(assertions, point, holderId) {
  const candidates = assertions.filter(entity => adoptedRecord(entity) && (holderId ? entity.data.truthKind !== 'author_truth' && entity.data.holderId === holderId : entity.data.truthKind === 'author_truth')).map(assertion => ({
    assertion,
    assessment: adoptionAssessment(assertion, assessWorldValidity(assertion.data.validity, point)),
    targetId: assertionReference(assertion.data.value)
  })).filter(candidate => candidate.assessment.value !== 'false');
  const definite = candidates.filter(candidate => candidate.assessment.value === 'true');
  const unique = new Set(definite.map(candidate => candidate.targetId ? `ref:${candidate.targetId}` : JSON.stringify(candidate.assertion.data.value)));
  return {
    candidates,
    definite,
    status: !candidates.length ? 'unknown' : unique.size > 1 ? 'multiple' : candidates.some(candidate => candidate.assessment.value === 'unknown') ? 'possible' : 'known',
    ...(!candidates.length ? {
      reason: 'この時点・経路の情報は登録されていません。'
    } : {})
  };
}
/** Testimony/beliefs remain separate from author truth unless an explicit holder is requested. */
export function worldStateCandidates(project, subjectId, predicate, point = {}, holderId) {
  return assessStateCandidates(project.entities.filter(entity => entity.kind === 'assertion' && !entity.deletedAt && entity.data.subjectId === subjectId && entity.data.predicate === predicate), point, holderId);
}
/** Index once for maps/history lists instead of repeatedly scanning an 88,000-record world. */
export function createWorldAssessment(project, point = {}) {
  const index = new Map(),
    cache = new Map();
  for (const entity of project.entities) if (entity.kind === 'assertion' && !entity.deletedAt) {
    var _index$get2;
    const key = `${entity.data.subjectId}:${entity.data.predicate}`,
      entries = (_index$get2 = index.get(key)) !== null && _index$get2 !== void 0 ? _index$get2 : [];
    entries.push(entity);
    index.set(key, entries);
  }
  return {
    stateCandidates(subjectId, predicate, holderId, selectedPoint = point) {
      var _index$get3;
      const key = `${subjectId}:${predicate}:${holderId !== null && holderId !== void 0 ? holderId : ''}`,
        previous = selectedPoint === point ? cache.get(key) : undefined;
      if (previous) return previous;
      const result = assessStateCandidates((_index$get3 = index.get(`${subjectId}:${predicate}`)) !== null && _index$get3 !== void 0 ? _index$get3 : [], selectedPoint, holderId);
      if (selectedPoint === point) cache.set(key, result);
      return result;
    }
  };
}
/** Reader labels never fall back to the author's real name or reveal a count of withheld aliases. */
export function worldDisplayName(entity, point = {}) {
  var _entity$data$aliases;
  if (!point.holderId && !point.publicOnly) return {
    name: entity.name,
    candidates: [],
    status: 'known',
    reasons: []
  };
  const aliases = 'aliases' in entity.data ? (_entity$data$aliases = entity.data.aliases) !== null && _entity$data$aliases !== void 0 ? _entity$data$aliases : [] : [];
  const allowed = aliases.filter(alias => point.publicOnly ? alias.isPublicDefault && alias.audienceHolderIds.length === 0 : alias.isPublicDefault && alias.audienceHolderIds.length === 0 || !!point.holderId && alias.audienceHolderIds.includes(point.holderId));
  const active = allowed.filter(alias => assessWorldValidity(alias.validity, point).value === 'true');
  const names = [...new Set(active.map(alias => alias.text))];
  return names.length === 1 ? {
    name: names[0],
    candidates: active,
    status: 'known',
    reasons: []
  } : names.length > 1 ? {
    name: '表示名を選択してください',
    candidates: active,
    status: 'multiple',
    reasons: ['この時点と認識者で複数の表示名が有効です。']
  } : {
    name: '公開名未選択',
    candidates: [],
    status: 'unknown',
    reasons: ['公開する名前を作者が指定してください。']
  };
}
/** The canonical projection remains responsible for secret stripping; this only authors its policy. */
export function setPublicAliasPolicy(profile, targetId, aliasId) {
  const current = profile.data.namePolicy;
  const policy = 'mode' in current ? {
    defaultPolicy: current,
    byEntityId: {}
  } : {
    ...current,
    byEntityId: {
      ...current.byEntityId
    }
  };
  return {
    ...profile,
    data: {
      ...profile.data,
      namePolicy: {
        ...policy,
        byEntityId: {
          ...policy.byEntityId,
          [targetId]: {
            mode: 'alias',
            aliasId
          }
        }
      }
    }
  };
}
function pinnedKey(reference) {
  return JSON.stringify([reference.projectId, reference.immutableSnapshotId, reference.contentHash]);
}
function pinnedSnapshotIndex(worlds) {
  const index = new Map();
  for (const world of worlds) for (const snapshot of world.snapshots) if (snapshot.content.projectId === world.projectId) {
    const key = pinnedKey({
      projectId: world.projectId,
      immutableSnapshotId: snapshot.id,
      contentHash: snapshot.contentHash
    });
    if (!index.has(key)) index.set(key, snapshot);
  }
  return index;
}
/** Resolve the exact immutable version across drafts and separately stored registry envelopes. */
export function findPinnedWorldSnapshot(worlds, reference) {
  return pinnedSnapshotIndex(worlds).get(pinnedKey(reference));
}
function pinnedClosure(references, index) {
  const snapshots = [],
    missing = [],
    seen = new Set(),
    queue = [...references];
  for (let cursor = 0; cursor < queue.length; cursor++) {
    const reference = queue[cursor],
      key = pinnedKey(reference);
    if (seen.has(key)) continue;
    seen.add(key);
    const snapshot = index.get(key);
    if (!snapshot) {
      missing.push(reference);
      continue;
    }
    snapshots.push(snapshot);
    queue.push(...snapshot.content.worldReferences);
  }
  return {
    snapshots,
    missing
  };
}
function mergePinnedContent(project, snapshots) {
  const entities = [...project.entities],
    relations = [...project.relations],
    calendars = [...project.calendars];
  const seenEntities = new Set(entities.map(entity => entity.id)),
    seenRelations = new Set(relations.map(relation => relation.id)),
    seenCalendars = new Set(calendars.map(calendar => calendar.id));
  for (const snapshot of snapshots) {
    for (const entity of snapshot.content.entities) if (!seenEntities.has(entity.id)) {
      entities.push(entity);
      seenEntities.add(entity.id);
    }
    for (const relation of snapshot.content.relations) if (!seenRelations.has(relation.id)) {
      relations.push(relation);
      seenRelations.add(relation.id);
    }
    for (const calendar of snapshot.content.calendars) if (!seenCalendars.has(calendar.id)) {
      calendars.push(calendar);
      seenCalendars.add(calendar.id);
    }
  }
  return {
    ...project,
    entities,
    relations,
    calendars
  };
}
/** Follow frozen references transitively. Current editing drafts never replace pinned content. */
export function effectiveWorldContent(project, worlds) {
  const {
    history: _history,
    snapshots: _snapshots,
    authorAlternatives: _authorAlternatives,
    ...content
  } = project;
  return mergePinnedContent(content, pinnedClosure(project.worldReferences, pinnedSnapshotIndex(worlds)).snapshots);
}
export async function previewWorldVersion(project, world, snapshotId, adoptedIds = [], worlds = []) {
  var _previous$content$wor, _existingView$id;
  if (world.projectId === project.projectId) throw new Error('作品自身を共通世界として参照できません。');
  const sources = [world, ...worlds],
    index = pinnedSnapshotIndex(sources),
    next = sources.filter(source => source.projectId === world.projectId).flatMap(source => source.snapshots).find(snapshot => snapshot.id === snapshotId);
  if (!next || next.content.projectId !== world.projectId || (await sha256(jsonBytes(next.content))) !== next.contentHash) throw new Error('選択した共通世界版が存在しないか、内容のhashが一致しません。');
  const current = project.worldReferences.find(reference => reference.projectId === world.projectId),
    previous = current ? index.get(pinnedKey(current)) : undefined;
  if (current && !previous) throw new Error('現在固定している共通世界版がありません。改訂差分を確認するため、旧版を保持してください。');
  if (previous && (await sha256(jsonBytes(previous.content))) !== previous.contentHash) throw new Error('旧世界版の内容のhashが一致しません。差分を確定できません。');
  const previousClosure = pinnedClosure((_previous$content$wor = previous === null || previous === void 0 ? void 0 : previous.content.worldReferences) !== null && _previous$content$wor !== void 0 ? _previous$content$wor : [], index),
    nextClosure = pinnedClosure(next.content.worldReferences, index);
  if (previousClosure.missing.length || nextClosure.missing.length) throw new Error('共通世界が固定して参照する別の世界版がありません。改訂差分を確認するため、すべての固定版を保持してください。');
  for (const snapshot of [...previousClosure.snapshots, ...nextClosure.snapshots]) if ((await sha256(jsonBytes(snapshot.content))) !== snapshot.contentHash) throw new Error('参照先の固定世界版の内容のhashが一致しません。');
  const calendarDefinitions = new Map(project.calendars.map(calendar => [calendar.id, calendar]));
  for (const snapshot of [next, ...nextClosure.snapshots]) for (const calendar of snapshot.content.calendars) {
    const existing = calendarDefinitions.get(calendar.id);
    if (existing && !sameCalendarDefinition(existing, calendar)) throw new Error(`同じ暦ID「${calendar.id}」に異なる規則があります。作品と固定世界の暦ID・規則を確認してください。`);
    calendarDefinitions.set(calendar.id, calendar);
  }
  const beforeContent = previous ? mergePinnedContent(previous.content, previousClosure.snapshots) : undefined,
    afterContent = mergePinnedContent(next.content, nextClosure.snapshots);
  const versionIds = snapshots => {
    const versions = new Map();
    for (const snapshot of snapshots) for (const [kind, records] of [['entity', snapshot.content.entities], ['relation', snapshot.content.relations], ['calendar', snapshot.content.calendars]]) for (const record of records) if (!versions.has(`${kind}:${record.id}`)) versions.set(`${kind}:${record.id}`, snapshot.id);
    return versions;
  };
  const beforeVersions = versionIds(previous ? [previous, ...previousClosure.snapshots] : []),
    afterVersions = versionIds([next, ...nextClosure.snapshots]);
  const differences = [];
  for (const [kind, before, after] of [['entity', (_beforeContent$entiti = beforeContent === null || beforeContent === void 0 ? void 0 : beforeContent.entities) !== null && _beforeContent$entiti !== void 0 ? _beforeContent$entiti : [], afterContent.entities], ['relation', (_beforeContent$relati = beforeContent === null || beforeContent === void 0 ? void 0 : beforeContent.relations) !== null && _beforeContent$relati !== void 0 ? _beforeContent$relati : [], afterContent.relations], ['calendar', (_beforeContent$calend = beforeContent === null || beforeContent === void 0 ? void 0 : beforeContent.calendars) !== null && _beforeContent$calend !== void 0 ? _beforeContent$calend : [], afterContent.calendars]]) {
    var _beforeContent$entiti, _beforeContent$relati, _beforeContent$calend;
    const a = new Map(before.filter(value => !('deletedAt' in value) || !value.deletedAt).map(value => [value.id, value])),
      b = new Map(after.filter(value => !('deletedAt' in value) || !value.deletedAt).map(value => [value.id, value]));
    for (const [id, value] of b) if (!a.has(id) || !equalJson(a.get(id), value)) differences.push({
      id,
      kind,
      change: a.has(id) ? 'changed' : 'added',
      before: a.get(id),
      after: value,
      beforeSnapshotId: beforeVersions.get(`${kind}:${id}`),
      afterSnapshotId: afterVersions.get(`${kind}:${id}`)
    });
    for (const [id, value] of a) if (!b.has(id)) differences.push({
      id,
      kind,
      change: 'removed',
      before: value,
      beforeSnapshotId: beforeVersions.get(`${kind}:${id}`)
    });
  }
  const changed = new Set(differences.map(difference => difference.id)),
    removed = new Set(differences.filter(difference => difference.change === 'removed').map(difference => difference.id)),
    affectedIds = new Set(),
    broken = new Set();
  for (const entity of project.entities) if (!entity.deletedAt) for (const reference of collectReferences(entity)) {
    if (immutableReferenceVersion(entity, reference)) continue;
    if (changed.has(reference.id)) affectedIds.add(entity.id);
    if (removed.has(reference.id)) broken.add(entity.id);
  }
  for (const relation of project.relations) if (!relation.deletedAt) for (const reference of collectRelationReferences(relation)) {
    if (immutableReferenceVersion(relation, reference)) continue;
    if (changed.has(reference.id)) affectedIds.add(relation.id);
    if (removed.has(reference.id)) broken.add(relation.id);
  }
  const ids = new Set(next.content.entities.filter(entity => !entity.deletedAt).map(entity => entity.id));
  if (adoptedIds.some(id => !ids.has(id))) throw new Error('採用する設定・人物は選択した世界版から選んでください。');
  const reference = {
    projectId: world.projectId,
    immutableSnapshotId: next.id,
    contentHash: next.contentHash
  };
  const viewKey = `world-adoption:${world.projectId}`,
    existingView = project.views.find(view => view.view === viewKey);
  const adoption = {
    id: (_existingView$id = existingView === null || existingView === void 0 ? void 0 : existingView.id) !== null && _existingView$id !== void 0 ? _existingView$id : newId(),
    name: `${world.name}の採用設定`,
    view: viewKey,
    entityIds: [...new Set(adoptedIds)],
    settings: {
      worldProjectId: world.projectId,
      snapshotId: next.id
    }
  };
  const candidate = {
    ...project,
    worldReferences: [...project.worldReferences.filter(item => item.projectId !== world.projectId), reference],
    views: existingView ? project.views.map(view => view.id === existingView.id ? adoption : view) : [...project.views, adoption]
  };
  for (const view of candidate.views) for (const id of view.entityIds) {
    if (changed.has(id)) affectedIds.add(view.id);
    if (removed.has(id)) broken.add(view.id);
  }
  return {
    candidate,
    reference,
    differences,
    affectedIds: [...affectedIds],
    brokenReferenceIds: [...broken],
    canApply: broken.size === 0
  };
}
export async function createWorldSnapshot(project, label) {
  const {
    history: _history,
    snapshots: _snapshots,
    authorAlternatives: _authorAlternatives,
    ...content
  } = structuredClone(project);
  const id = newId(),
    contentHash = await sha256(jsonBytes(content)),
    versionLabel = label.trim() || `世界版 ${project.revision}`;
  const snapshot = {
    id,
    contentHash,
    versionLabel,
    createdAt: new Date().toISOString(),
    content
  };
  const metadata = {
    ...createEntity(project.projectId, 'snapshot', versionLabel, {
      versionLabel,
      contentHash,
      immutable: true
    }),
    id
  };
  return {
    ...project,
    snapshots: [...project.snapshots, snapshot],
    entities: [...project.entities, metadata]
  };
}

/** A place and one of its containing areas describe compatible locations. */
export function compatibleLocations(a, b, index) {
  const contains = (child, parent) => {
    const visited = new Set();
    let current = child;
    while (current && !visited.has(current)) {
      var _entity$data$parentId;
      if (current === parent) return true;
      visited.add(current);
      const entity = index.get(current);
      current = (entity === null || entity === void 0 ? void 0 : entity.kind) === 'place' ? (_entity$data$parentId = entity.data.parentId) !== null && _entity$data$parentId !== void 0 ? _entity$data$parentId : undefined : undefined;
    }
    return false;
  };
  return contains(a, b) || contains(b, a);
}
export function worldPeriodsOverlap(a, b) {
  const x = a === null || a === void 0 ? void 0 : a.worldRange,
    y = b === null || b === void 0 ? void 0 : b.worldRange;
  return !(x !== null && x !== void 0 && x.end && y !== null && y !== void 0 && y.start && parseTick(x.end) <= parseTick(y.start) || y !== null && y !== void 0 && y.end && x !== null && x !== void 0 && x.start && parseTick(y.end) <= parseTick(x.start));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjb2xsZWN0UmVmZXJlbmNlcyIsImNvbGxlY3RSZWxhdGlvblJlZmVyZW5jZXMiLCJjcmVhdGVFbnRpdHkiLCJlbXB0eVJ1bnRpbWVTdGF0ZSIsIm5ld0lkIiwiaW1tdXRhYmxlUmVmZXJlbmNlVmVyc2lvbiIsImV2YWx1YXRlQ29uZGl0aW9uIiwiY29tcGFyZVRpY2tzIiwiaXNUaWNrIiwicGFyc2VUaWNrIiwic2FtZUNhbGVuZGFyRGVmaW5pdGlvbiIsImVxdWFsSnNvbiIsImpzb25CeXRlcyIsInNoYTI1NiIsImFkb3B0ZWRSZWNvcmQiLCJhZG9wdGlvbkFzc2Vzc21lbnQiLCJXT1JMRF9QUkVESUNBVEVTIiwibG9jYXRpb24iLCJvd25lcnNoaXAiLCJtZW1iZXJzaGlwIiwiZGlzcGxheU5hbWUiLCJwbGFjZVN0YXRlIiwiY29udHJvbCIsImlkZW50aXR5IiwiYXBwZWFyYW5jZSIsIldPUkxEX1BSRURJQ0FURV9MQUJFTFMiLCJvd25lciIsIm1lbWJlcl9vZiIsImRpc3BsYXlfbmFtZSIsInBsYWNlX3N0YXRlIiwiY29udHJvbGxlZF9ieSIsImFwcGVhcmFuY2VfZXhjZXB0aW9uIiwiY29tYmluZSIsInZhbHVlcyIsImluY2x1ZGVzIiwiaGFzUnVudGltZUlucHV0IiwiY29uZGl0aW9uIiwib3AiLCJjaGlsZCIsImNoaWxkcmVuIiwic29tZSIsImFzc2Vzc1dvcmxkVmFsaWRpdHkiLCJ2YWxpZGl0eSIsInBvaW50IiwidmFsdWUiLCJyZWFzb25zIiwid29ybGRSYW5nZSIsInN0YXJ0IiwiZW5kIiwiYXQiLCJwdXNoIiwicmFuZ2UiLCJyb3V0ZUNvbmRpdGlvbiIsImNvbnRleHQiLCJfcG9pbnQkY29udGV4dCIsInJlc3VsdCIsInN0YXRlIiwiZXJyb3IiLCJFcnJvciIsIm1lc3NhZ2UiLCJwcmVzZW50YXRpb25BbmNob3IiLCJwcmVzZW50YXRpb25JZHMiLCJlbnRpdHlJZCIsIlNldCIsImFzc2VydGlvblJlZmVyZW5jZSIsInR5cGUiLCJ1bmRlZmluZWQiLCJhc3NlcnRpb25WYWx1ZUxhYmVsIiwiaW5kZXgiLCJfaW5kZXgkZ2V0IiwicmVmZXJlbmNlIiwiZ2V0IiwibmFtZSIsInJlYXNvbiIsIlN0cmluZyIsImFzc2Vzc1N0YXRlQ2FuZGlkYXRlcyIsImFzc2VydGlvbnMiLCJob2xkZXJJZCIsImNhbmRpZGF0ZXMiLCJmaWx0ZXIiLCJlbnRpdHkiLCJkYXRhIiwidHJ1dGhLaW5kIiwibWFwIiwiYXNzZXJ0aW9uIiwiYXNzZXNzbWVudCIsInRhcmdldElkIiwiY2FuZGlkYXRlIiwiZGVmaW5pdGUiLCJ1bmlxdWUiLCJKU09OIiwic3RyaW5naWZ5Iiwic3RhdHVzIiwibGVuZ3RoIiwic2l6ZSIsIndvcmxkU3RhdGVDYW5kaWRhdGVzIiwicHJvamVjdCIsInN1YmplY3RJZCIsInByZWRpY2F0ZSIsImVudGl0aWVzIiwia2luZCIsImRlbGV0ZWRBdCIsImNyZWF0ZVdvcmxkQXNzZXNzbWVudCIsIk1hcCIsImNhY2hlIiwiX2luZGV4JGdldDIiLCJrZXkiLCJlbnRyaWVzIiwic2V0Iiwic3RhdGVDYW5kaWRhdGVzIiwic2VsZWN0ZWRQb2ludCIsIl9pbmRleCRnZXQzIiwicHJldmlvdXMiLCJ3b3JsZERpc3BsYXlOYW1lIiwiX2VudGl0eSRkYXRhJGFsaWFzZXMiLCJwdWJsaWNPbmx5IiwiYWxpYXNlcyIsImFsbG93ZWQiLCJhbGlhcyIsImlzUHVibGljRGVmYXVsdCIsImF1ZGllbmNlSG9sZGVySWRzIiwiYWN0aXZlIiwibmFtZXMiLCJ0ZXh0Iiwic2V0UHVibGljQWxpYXNQb2xpY3kiLCJwcm9maWxlIiwiYWxpYXNJZCIsImN1cnJlbnQiLCJuYW1lUG9saWN5IiwicG9saWN5IiwiZGVmYXVsdFBvbGljeSIsImJ5RW50aXR5SWQiLCJtb2RlIiwicGlubmVkS2V5IiwicHJvamVjdElkIiwiaW1tdXRhYmxlU25hcHNob3RJZCIsImNvbnRlbnRIYXNoIiwicGlubmVkU25hcHNob3RJbmRleCIsIndvcmxkcyIsIndvcmxkIiwic25hcHNob3QiLCJzbmFwc2hvdHMiLCJjb250ZW50IiwiaWQiLCJoYXMiLCJmaW5kUGlubmVkV29ybGRTbmFwc2hvdCIsInBpbm5lZENsb3N1cmUiLCJyZWZlcmVuY2VzIiwibWlzc2luZyIsInNlZW4iLCJxdWV1ZSIsImN1cnNvciIsImFkZCIsIndvcmxkUmVmZXJlbmNlcyIsIm1lcmdlUGlubmVkQ29udGVudCIsInJlbGF0aW9ucyIsImNhbGVuZGFycyIsInNlZW5FbnRpdGllcyIsInNlZW5SZWxhdGlvbnMiLCJyZWxhdGlvbiIsInNlZW5DYWxlbmRhcnMiLCJjYWxlbmRhciIsImVmZmVjdGl2ZVdvcmxkQ29udGVudCIsImhpc3RvcnkiLCJfaGlzdG9yeSIsIl9zbmFwc2hvdHMiLCJhdXRob3JBbHRlcm5hdGl2ZXMiLCJfYXV0aG9yQWx0ZXJuYXRpdmVzIiwicHJldmlld1dvcmxkVmVyc2lvbiIsInNuYXBzaG90SWQiLCJhZG9wdGVkSWRzIiwiX3ByZXZpb3VzJGNvbnRlbnQkd29yIiwiX2V4aXN0aW5nVmlldyRpZCIsInNvdXJjZXMiLCJuZXh0Iiwic291cmNlIiwiZmxhdE1hcCIsImZpbmQiLCJwcmV2aW91c0Nsb3N1cmUiLCJuZXh0Q2xvc3VyZSIsImNhbGVuZGFyRGVmaW5pdGlvbnMiLCJleGlzdGluZyIsImJlZm9yZUNvbnRlbnQiLCJhZnRlckNvbnRlbnQiLCJ2ZXJzaW9uSWRzIiwidmVyc2lvbnMiLCJyZWNvcmRzIiwicmVjb3JkIiwiYmVmb3JlVmVyc2lvbnMiLCJhZnRlclZlcnNpb25zIiwiZGlmZmVyZW5jZXMiLCJiZWZvcmUiLCJhZnRlciIsIl9iZWZvcmVDb250ZW50JGVudGl0aSIsIl9iZWZvcmVDb250ZW50JHJlbGF0aSIsIl9iZWZvcmVDb250ZW50JGNhbGVuZCIsImEiLCJiIiwiY2hhbmdlIiwiYmVmb3JlU25hcHNob3RJZCIsImFmdGVyU25hcHNob3RJZCIsImNoYW5nZWQiLCJkaWZmZXJlbmNlIiwicmVtb3ZlZCIsImFmZmVjdGVkSWRzIiwiYnJva2VuIiwiaWRzIiwidmlld0tleSIsImV4aXN0aW5nVmlldyIsInZpZXdzIiwidmlldyIsImFkb3B0aW9uIiwiZW50aXR5SWRzIiwic2V0dGluZ3MiLCJ3b3JsZFByb2plY3RJZCIsIml0ZW0iLCJicm9rZW5SZWZlcmVuY2VJZHMiLCJjYW5BcHBseSIsImNyZWF0ZVdvcmxkU25hcHNob3QiLCJsYWJlbCIsInN0cnVjdHVyZWRDbG9uZSIsInZlcnNpb25MYWJlbCIsInRyaW0iLCJyZXZpc2lvbiIsImNyZWF0ZWRBdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsIm1ldGFkYXRhIiwiaW1tdXRhYmxlIiwiY29tcGF0aWJsZUxvY2F0aW9ucyIsImNvbnRhaW5zIiwicGFyZW50IiwidmlzaXRlZCIsIl9lbnRpdHkkZGF0YSRwYXJlbnRJZCIsInBhcmVudElkIiwid29ybGRQZXJpb2RzT3ZlcmxhcCIsIngiLCJ5Il0sInNvdXJjZXMiOlsid29ybGQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBbGlhcywgQ29uZGl0aW9uLCBFbnRpdHksIElELCBOYW1lUG9saWN5TWFwLCBQcm9qZWN0Q29udGVudCwgUHJvamVjdERhdGEsIFByb2plY3RTbmFwc2hvdCwgUnVudGltZUNvbnRleHQsIFRpY2ssIFRydXRoVmFsdWUsIFR5cGVkVmFsdWUsIFZhbGlkaXR5LCBXb3JsZFJlZmVyZW5jZSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgY29sbGVjdFJlZmVyZW5jZXMsIGNvbGxlY3RSZWxhdGlvblJlZmVyZW5jZXMsIGNyZWF0ZUVudGl0eSwgZW1wdHlSdW50aW1lU3RhdGUsIG5ld0lkIH0gZnJvbSAnLi9tb2RlbCc7XG5pbXBvcnQgeyBpbW11dGFibGVSZWZlcmVuY2VWZXJzaW9uIH0gZnJvbSAnLi9tYWludGVuYW5jZSc7XG5pbXBvcnQgeyBldmFsdWF0ZUNvbmRpdGlvbiB9IGZyb20gJy4vY29uZGl0aW9ucyc7XG5pbXBvcnQgeyBjb21wYXJlVGlja3MsIGlzVGljaywgcGFyc2VUaWNrLCBzYW1lQ2FsZW5kYXJEZWZpbml0aW9uIH0gZnJvbSAnLi90aW1lJztcbmltcG9ydCB7IGVxdWFsSnNvbiwganNvbkJ5dGVzLCBzaGEyNTYgfSBmcm9tICcuLi9zdG9yYWdlL2pzb24nO1xuaW1wb3J0IHsgYWRvcHRlZFJlY29yZCwgYWRvcHRpb25Bc3Nlc3NtZW50IH0gZnJvbSAnLi9hZG9wdGlvbic7XG5cbi8qKiBUaGVzZSBwcmVkaWNhdGVzIGFyZSBhdXRob3JlZCBleHBsaWNpdGx5IGJ5IHRoZSB3b3JsZC1oaXN0b3J5IGZvcm0sIG5ldmVyIGd1ZXNzZWQgZnJvbSBwcm9zZS4gKi9cbmV4cG9ydCBjb25zdCBXT1JMRF9QUkVESUNBVEVTID0ge1xuICBsb2NhdGlvbjogJ2xvY2F0aW9uJywgb3duZXJzaGlwOiAnb3duZXInLCBtZW1iZXJzaGlwOiAnbWVtYmVyX29mJywgZGlzcGxheU5hbWU6ICdkaXNwbGF5X25hbWUnLFxuICBwbGFjZVN0YXRlOiAncGxhY2Vfc3RhdGUnLCBjb250cm9sOiAnY29udHJvbGxlZF9ieScsIGlkZW50aXR5OiAnaWRlbnRpdHknLCBhcHBlYXJhbmNlOiAnYXBwZWFyYW5jZV9leGNlcHRpb24nLFxufSBhcyBjb25zdDtcbmV4cG9ydCBjb25zdCBXT1JMRF9QUkVESUNBVEVfTEFCRUxTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0geyBsb2NhdGlvbjogJ+ePvuWcqOWcsCcsIG93bmVyOiAn5omA5pyJ6ICFJywgbWVtYmVyX29mOiAn5omA5bGeJywgZGlzcGxheV9uYW1lOiAn5aC05omA44Gu5ZCN56ewJywgcGxhY2Vfc3RhdGU6ICfnoLTlo4rjg7vlho3lu7rjgarjganjga7nirbmhYsnLCBjb250cm9sbGVkX2J5OiAn5pSv6YWN57WE57mUJywgaWRlbnRpdHk6ICfmraPkvZMnLCBhcHBlYXJhbmNlX2V4Y2VwdGlvbjogJ+WbnuaDs+ODu+iomOmMsuODu+W+qea0u+OBquOBqeOBruaEj+WbsycgfTtcbmV4cG9ydCBpbnRlcmZhY2UgV29ybGRQb2ludCB7IGF0PzogVGljayB8IG51bGw7IGNvbnRleHQ/OiBSdW50aW1lQ29udGV4dDsgcHJlc2VudGF0aW9uSWRzPzogSURbXSB9XG5leHBvcnQgaW50ZXJmYWNlIFZhbGlkaXR5QXNzZXNzbWVudCB7IHZhbHVlOiBUcnV0aFZhbHVlOyByZWFzb25zOiBzdHJpbmdbXSB9XG5mdW5jdGlvbiBjb21iaW5lKHZhbHVlczogVHJ1dGhWYWx1ZVtdKTogVHJ1dGhWYWx1ZSB7IHJldHVybiB2YWx1ZXMuaW5jbHVkZXMoJ2ZhbHNlJykgPyAnZmFsc2UnIDogdmFsdWVzLmluY2x1ZGVzKCd1bmtub3duJykgPyAndW5rbm93bicgOiAndHJ1ZSc7IH1cbmZ1bmN0aW9uIGhhc1J1bnRpbWVJbnB1dChjb25kaXRpb246IENvbmRpdGlvbik6IGJvb2xlYW4ge1xuICBpZiAoY29uZGl0aW9uLm9wID09PSAnY29uc3RhbnQnKSByZXR1cm4gZmFsc2U7XG4gIGlmIChjb25kaXRpb24ub3AgPT09ICdub3QnKSByZXR1cm4gaGFzUnVudGltZUlucHV0KGNvbmRpdGlvbi5jaGlsZCk7XG4gIGlmIChjb25kaXRpb24ub3AgPT09ICdhbGwnIHx8IGNvbmRpdGlvbi5vcCA9PT0gJ2FueScpIHJldHVybiBjb25kaXRpb24uY2hpbGRyZW4uc29tZShoYXNSdW50aW1lSW5wdXQpO1xuICByZXR1cm4gdHJ1ZTtcbn1cbi8qKiBIYWxmLW9wZW4gd29ybGQgcGVyaW9kcyBhbmQgdGhyZWUtdmFsdWVkIHJvdXRlL3ByZXNlbnRhdGlvbiBhc3Nlc3NtZW50IHVzZWQgYnkgYWxsIFJCMDMgdmlld3MuICovXG5leHBvcnQgZnVuY3Rpb24gYXNzZXNzV29ybGRWYWxpZGl0eSh2YWxpZGl0eTogVmFsaWRpdHkgfCBudWxsIHwgdW5kZWZpbmVkLCBwb2ludDogV29ybGRQb2ludCA9IHt9KTogVmFsaWRpdHlBc3Nlc3NtZW50IHtcbiAgaWYgKCF2YWxpZGl0eSkgcmV0dXJuIHsgdmFsdWU6ICd0cnVlJywgcmVhc29uczogW10gfTtcbiAgY29uc3QgdmFsdWVzOiBUcnV0aFZhbHVlW10gPSBbXSwgcmVhc29uczogc3RyaW5nW10gPSBbXTtcbiAgaWYgKHZhbGlkaXR5LndvcmxkUmFuZ2UgJiYgKHZhbGlkaXR5LndvcmxkUmFuZ2Uuc3RhcnQgIT09IG51bGwgfHwgdmFsaWRpdHkud29ybGRSYW5nZS5lbmQgIT09IG51bGwpKSB7XG4gICAgaWYgKCFwb2ludC5hdCB8fCAhaXNUaWNrKHBvaW50LmF0KSkgeyB2YWx1ZXMucHVzaCgndW5rbm93bicpOyByZWFzb25zLnB1c2goJ+S4lueVjOaZgueCueOBjOacqumBuOaKnuOBp+OBmeOAgicpOyB9XG4gICAgZWxzZSB7IGNvbnN0IHJhbmdlID0gdmFsaWRpdHkud29ybGRSYW5nZTsgdmFsdWVzLnB1c2gocmFuZ2Uuc3RhcnQgJiYgY29tcGFyZVRpY2tzKHBvaW50LmF0LCByYW5nZS5zdGFydCkgPCAwIHx8IHJhbmdlLmVuZCAmJiBjb21wYXJlVGlja3MocG9pbnQuYXQsIHJhbmdlLmVuZCkgPj0gMCA/ICdmYWxzZScgOiAndHJ1ZScpOyB9XG4gIH1cbiAgaWYgKHZhbGlkaXR5LnJvdXRlQ29uZGl0aW9uKSB7XG4gICAgaWYgKCFwb2ludC5jb250ZXh0ICYmIGhhc1J1bnRpbWVJbnB1dCh2YWxpZGl0eS5yb3V0ZUNvbmRpdGlvbikpIHsgdmFsdWVzLnB1c2goJ3Vua25vd24nKTsgcmVhc29ucy5wdXNoKCfntYzot6/jg7vnirbmhYvjga7lgKTjgYzmnKrpgbjmip7jgafjgZnjgIInKTsgfVxuICAgIGVsc2UgdHJ5IHsgY29uc3QgcmVzdWx0ID0gZXZhbHVhdGVDb25kaXRpb24odmFsaWRpdHkucm91dGVDb25kaXRpb24sIHBvaW50LmNvbnRleHQgPz8geyBzdGF0ZTogZW1wdHlSdW50aW1lU3RhdGUoJ3dvcmxkLXZpZXcnKSB9KTsgdmFsdWVzLnB1c2gocmVzdWx0LnZhbHVlKTsgcmVhc29ucy5wdXNoKC4uLnJlc3VsdC5yZWFzb25zKTsgfVxuICAgIGNhdGNoIChlcnJvcikgeyB2YWx1ZXMucHVzaCgndW5rbm93bicpOyByZWFzb25zLnB1c2goZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAn57WM6Lev5p2h5Lu244KS56K66KqN44Gn44GN44G+44Gb44KT44CCJyk7IH1cbiAgfVxuICBpZiAodmFsaWRpdHkucHJlc2VudGF0aW9uQW5jaG9yKSB7XG4gICAgaWYgKCFwb2ludC5wcmVzZW50YXRpb25JZHMpIHsgdmFsdWVzLnB1c2goJ3Vua25vd24nKTsgcmVhc29ucy5wdXNoKCfmj5DnpLrkvY3nva7jgYzmnKrpgbjmip7jgafjgZnjgIInKTsgfVxuICAgIGVsc2UgdmFsdWVzLnB1c2gocG9pbnQucHJlc2VudGF0aW9uSWRzLmluY2x1ZGVzKHZhbGlkaXR5LnByZXNlbnRhdGlvbkFuY2hvci5lbnRpdHlJZCkgPyAndHJ1ZScgOiAnZmFsc2UnKTtcbiAgfVxuICByZXR1cm4geyB2YWx1ZTogY29tYmluZSh2YWx1ZXMpLCByZWFzb25zOiBbLi4ubmV3IFNldChyZWFzb25zKV0gfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFzc2VydGlvblJlZmVyZW5jZSh2YWx1ZTogVHlwZWRWYWx1ZSB8IElEKTogSUQgfCB1bmRlZmluZWQgeyByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlIDogdmFsdWUudHlwZSA9PT0gJ3JlZicgPyB2YWx1ZS52YWx1ZSA6IHVuZGVmaW5lZDsgfVxuZXhwb3J0IGZ1bmN0aW9uIGFzc2VydGlvblZhbHVlTGFiZWwodmFsdWU6IFR5cGVkVmFsdWUgfCBJRCwgaW5kZXg6IE1hcDxJRCwgRW50aXR5Pik6IHN0cmluZyB7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IGFzc2VydGlvblJlZmVyZW5jZSh2YWx1ZSk7XG4gIGlmIChyZWZlcmVuY2UpIHJldHVybiBpbmRleC5nZXQocmVmZXJlbmNlKT8ubmFtZSB8fCAn5Y+C54Wn5YWI5pyq56K66KqNJztcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgJiYgdmFsdWUudHlwZSA9PT0gJ3Vua25vd24nID8gYOS4jeaYjiDCtyAke3ZhbHVlLnJlYXNvbn1gIDogdHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJyA/IFN0cmluZyh2YWx1ZS52YWx1ZSkgOiB2YWx1ZTtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgV29ybGRTdGF0ZUNhbmRpZGF0ZSB7IGFzc2VydGlvbjogRW50aXR5PCdhc3NlcnRpb24nPjsgYXNzZXNzbWVudDogVmFsaWRpdHlBc3Nlc3NtZW50OyB0YXJnZXRJZD86IElEIH1cbmV4cG9ydCBpbnRlcmZhY2UgV29ybGRTdGF0ZVJlc3VsdCB7IGNhbmRpZGF0ZXM6IFdvcmxkU3RhdGVDYW5kaWRhdGVbXTsgZGVmaW5pdGU6IFdvcmxkU3RhdGVDYW5kaWRhdGVbXTsgc3RhdHVzOiAna25vd24nIHwgJ211bHRpcGxlJyB8ICdwb3NzaWJsZScgfCAndW5rbm93bic7IHJlYXNvbj86IHN0cmluZyB9XG5mdW5jdGlvbiBhc3Nlc3NTdGF0ZUNhbmRpZGF0ZXMoYXNzZXJ0aW9uczogRW50aXR5PCdhc3NlcnRpb24nPltdLCBwb2ludDogV29ybGRQb2ludCwgaG9sZGVySWQ/OiBJRCk6IFdvcmxkU3RhdGVSZXN1bHQge1xuICBjb25zdCBjYW5kaWRhdGVzID0gYXNzZXJ0aW9ucy5maWx0ZXIoZW50aXR5ID0+IGFkb3B0ZWRSZWNvcmQoZW50aXR5KSAmJiAoaG9sZGVySWQgPyBlbnRpdHkuZGF0YS50cnV0aEtpbmQgIT09ICdhdXRob3JfdHJ1dGgnICYmIGVudGl0eS5kYXRhLmhvbGRlcklkID09PSBob2xkZXJJZCA6IGVudGl0eS5kYXRhLnRydXRoS2luZCA9PT0gJ2F1dGhvcl90cnV0aCcpKS5tYXAoYXNzZXJ0aW9uID0+ICh7IGFzc2VydGlvbiwgYXNzZXNzbWVudDogYWRvcHRpb25Bc3Nlc3NtZW50KGFzc2VydGlvbiwgYXNzZXNzV29ybGRWYWxpZGl0eShhc3NlcnRpb24uZGF0YS52YWxpZGl0eSwgcG9pbnQpKSwgdGFyZ2V0SWQ6IGFzc2VydGlvblJlZmVyZW5jZShhc3NlcnRpb24uZGF0YS52YWx1ZSkgfSkpLmZpbHRlcihjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmFzc2Vzc21lbnQudmFsdWUgIT09ICdmYWxzZScpO1xuICBjb25zdCBkZWZpbml0ZSA9IGNhbmRpZGF0ZXMuZmlsdGVyKGNhbmRpZGF0ZSA9PiBjYW5kaWRhdGUuYXNzZXNzbWVudC52YWx1ZSA9PT0gJ3RydWUnKTtcbiAgY29uc3QgdW5pcXVlID0gbmV3IFNldChkZWZpbml0ZS5tYXAoY2FuZGlkYXRlID0+IGNhbmRpZGF0ZS50YXJnZXRJZCA/IGByZWY6JHtjYW5kaWRhdGUudGFyZ2V0SWR9YCA6IEpTT04uc3RyaW5naWZ5KGNhbmRpZGF0ZS5hc3NlcnRpb24uZGF0YS52YWx1ZSkpKTtcbiAgcmV0dXJuIHsgY2FuZGlkYXRlcywgZGVmaW5pdGUsIHN0YXR1czogIWNhbmRpZGF0ZXMubGVuZ3RoID8gJ3Vua25vd24nIDogdW5pcXVlLnNpemUgPiAxID8gJ211bHRpcGxlJyA6IGNhbmRpZGF0ZXMuc29tZShjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmFzc2Vzc21lbnQudmFsdWUgPT09ICd1bmtub3duJykgPyAncG9zc2libGUnIDogJ2tub3duJywgLi4uKCFjYW5kaWRhdGVzLmxlbmd0aCA/IHsgcmVhc29uOiAn44GT44Gu5pmC54K544O757WM6Lev44Gu5oOF5aCx44Gv55m76Yyy44GV44KM44Gm44GE44G+44Gb44KT44CCJyB9IDoge30pIH07XG59XG4vKiogVGVzdGltb255L2JlbGllZnMgcmVtYWluIHNlcGFyYXRlIGZyb20gYXV0aG9yIHRydXRoIHVubGVzcyBhbiBleHBsaWNpdCBob2xkZXIgaXMgcmVxdWVzdGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdvcmxkU3RhdGVDYW5kaWRhdGVzKHByb2plY3Q6IFBpY2s8UHJvamVjdENvbnRlbnQsICdlbnRpdGllcyc+LCBzdWJqZWN0SWQ6IElELCBwcmVkaWNhdGU6IHN0cmluZywgcG9pbnQ6IFdvcmxkUG9pbnQgPSB7fSwgaG9sZGVySWQ/OiBJRCk6IFdvcmxkU3RhdGVSZXN1bHQge1xuICByZXR1cm4gYXNzZXNzU3RhdGVDYW5kaWRhdGVzKHByb2plY3QuZW50aXRpZXMuZmlsdGVyKChlbnRpdHkpOiBlbnRpdHkgaXMgRW50aXR5PCdhc3NlcnRpb24nPiA9PiBlbnRpdHkua2luZCA9PT0gJ2Fzc2VydGlvbicgJiYgIWVudGl0eS5kZWxldGVkQXQgJiYgZW50aXR5LmRhdGEuc3ViamVjdElkID09PSBzdWJqZWN0SWQgJiYgZW50aXR5LmRhdGEucHJlZGljYXRlID09PSBwcmVkaWNhdGUpLCBwb2ludCwgaG9sZGVySWQpO1xufVxuLyoqIEluZGV4IG9uY2UgZm9yIG1hcHMvaGlzdG9yeSBsaXN0cyBpbnN0ZWFkIG9mIHJlcGVhdGVkbHkgc2Nhbm5pbmcgYW4gODgsMDAwLXJlY29yZCB3b3JsZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVXb3JsZEFzc2Vzc21lbnQocHJvamVjdDogUGljazxQcm9qZWN0Q29udGVudCwgJ2VudGl0aWVzJz4sIHBvaW50OiBXb3JsZFBvaW50ID0ge30pIHtcbiAgY29uc3QgaW5kZXggPSBuZXcgTWFwPHN0cmluZywgRW50aXR5PCdhc3NlcnRpb24nPltdPigpLCBjYWNoZSA9IG5ldyBNYXA8c3RyaW5nLCBXb3JsZFN0YXRlUmVzdWx0PigpO1xuICBmb3IgKGNvbnN0IGVudGl0eSBvZiBwcm9qZWN0LmVudGl0aWVzKSBpZiAoZW50aXR5LmtpbmQgPT09ICdhc3NlcnRpb24nICYmICFlbnRpdHkuZGVsZXRlZEF0KSB7IGNvbnN0IGtleSA9IGAke2VudGl0eS5kYXRhLnN1YmplY3RJZH06JHtlbnRpdHkuZGF0YS5wcmVkaWNhdGV9YCwgZW50cmllcyA9IGluZGV4LmdldChrZXkpID8/IFtdOyBlbnRyaWVzLnB1c2goZW50aXR5KTsgaW5kZXguc2V0KGtleSwgZW50cmllcyk7IH1cbiAgcmV0dXJuIHsgc3RhdGVDYW5kaWRhdGVzKHN1YmplY3RJZDogSUQsIHByZWRpY2F0ZTogc3RyaW5nLCBob2xkZXJJZD86IElELCBzZWxlY3RlZFBvaW50OiBXb3JsZFBvaW50ID0gcG9pbnQpOiBXb3JsZFN0YXRlUmVzdWx0IHsgY29uc3Qga2V5ID0gYCR7c3ViamVjdElkfToke3ByZWRpY2F0ZX06JHtob2xkZXJJZCA/PyAnJ31gLCBwcmV2aW91cyA9IHNlbGVjdGVkUG9pbnQgPT09IHBvaW50ID8gY2FjaGUuZ2V0KGtleSkgOiB1bmRlZmluZWQ7IGlmIChwcmV2aW91cykgcmV0dXJuIHByZXZpb3VzOyBjb25zdCByZXN1bHQgPSBhc3Nlc3NTdGF0ZUNhbmRpZGF0ZXMoaW5kZXguZ2V0KGAke3N1YmplY3RJZH06JHtwcmVkaWNhdGV9YCkgPz8gW10sIHNlbGVjdGVkUG9pbnQsIGhvbGRlcklkKTsgaWYgKHNlbGVjdGVkUG9pbnQgPT09IHBvaW50KSBjYWNoZS5zZXQoa2V5LCByZXN1bHQpOyByZXR1cm4gcmVzdWx0OyB9IH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGlzcGxheU5hbWVBc3Nlc3NtZW50IHsgbmFtZTogc3RyaW5nOyBjYW5kaWRhdGVzOiBBbGlhc1tdOyBzdGF0dXM6ICdrbm93bicgfCAnbXVsdGlwbGUnIHwgJ3Vua25vd24nOyByZWFzb25zOiBzdHJpbmdbXSB9XG4vKiogUmVhZGVyIGxhYmVscyBuZXZlciBmYWxsIGJhY2sgdG8gdGhlIGF1dGhvcidzIHJlYWwgbmFtZSBvciByZXZlYWwgYSBjb3VudCBvZiB3aXRoaGVsZCBhbGlhc2VzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdvcmxkRGlzcGxheU5hbWUoZW50aXR5OiBFbnRpdHksIHBvaW50OiBXb3JsZFBvaW50ICYgeyBob2xkZXJJZD86IElEOyBwdWJsaWNPbmx5PzogYm9vbGVhbiB9ID0ge30pOiBEaXNwbGF5TmFtZUFzc2Vzc21lbnQge1xuICBpZiAoIXBvaW50LmhvbGRlcklkICYmICFwb2ludC5wdWJsaWNPbmx5KSByZXR1cm4geyBuYW1lOiBlbnRpdHkubmFtZSwgY2FuZGlkYXRlczogW10sIHN0YXR1czogJ2tub3duJywgcmVhc29uczogW10gfTtcbiAgY29uc3QgYWxpYXNlcyA9ICdhbGlhc2VzJyBpbiBlbnRpdHkuZGF0YSA/IGVudGl0eS5kYXRhLmFsaWFzZXMgPz8gW10gOiBbXTtcbiAgY29uc3QgYWxsb3dlZCA9IGFsaWFzZXMuZmlsdGVyKGFsaWFzID0+IHBvaW50LnB1YmxpY09ubHkgPyBhbGlhcy5pc1B1YmxpY0RlZmF1bHQgJiYgYWxpYXMuYXVkaWVuY2VIb2xkZXJJZHMubGVuZ3RoID09PSAwIDogYWxpYXMuaXNQdWJsaWNEZWZhdWx0ICYmIGFsaWFzLmF1ZGllbmNlSG9sZGVySWRzLmxlbmd0aCA9PT0gMCB8fCAhIXBvaW50LmhvbGRlcklkICYmIGFsaWFzLmF1ZGllbmNlSG9sZGVySWRzLmluY2x1ZGVzKHBvaW50LmhvbGRlcklkKSk7XG4gIGNvbnN0IGFjdGl2ZSA9IGFsbG93ZWQuZmlsdGVyKGFsaWFzID0+IGFzc2Vzc1dvcmxkVmFsaWRpdHkoYWxpYXMudmFsaWRpdHksIHBvaW50KS52YWx1ZSA9PT0gJ3RydWUnKTtcbiAgY29uc3QgbmFtZXMgPSBbLi4ubmV3IFNldChhY3RpdmUubWFwKGFsaWFzID0+IGFsaWFzLnRleHQpKV07XG4gIHJldHVybiBuYW1lcy5sZW5ndGggPT09IDEgPyB7IG5hbWU6IG5hbWVzWzBdLCBjYW5kaWRhdGVzOiBhY3RpdmUsIHN0YXR1czogJ2tub3duJywgcmVhc29uczogW10gfSA6IG5hbWVzLmxlbmd0aCA+IDEgPyB7IG5hbWU6ICfooajnpLrlkI3jgpLpgbjmip7jgZfjgabjgY/jgaDjgZXjgYQnLCBjYW5kaWRhdGVzOiBhY3RpdmUsIHN0YXR1czogJ211bHRpcGxlJywgcmVhc29uczogWyfjgZPjga7mmYLngrnjgajoqo3orZjogIXjgafopIfmlbDjga7ooajnpLrlkI3jgYzmnInlirnjgafjgZnjgIInXSB9IDogeyBuYW1lOiAn5YWs6ZaL5ZCN5pyq6YG45oqeJywgY2FuZGlkYXRlczogW10sIHN0YXR1czogJ3Vua25vd24nLCByZWFzb25zOiBbJ+WFrOmWi+OBmeOCi+WQjeWJjeOCkuS9nOiAheOBjOaMh+WumuOBl+OBpuOBj+OBoOOBleOBhOOAgiddIH07XG59XG4vKiogVGhlIGNhbm9uaWNhbCBwcm9qZWN0aW9uIHJlbWFpbnMgcmVzcG9uc2libGUgZm9yIHNlY3JldCBzdHJpcHBpbmc7IHRoaXMgb25seSBhdXRob3JzIGl0cyBwb2xpY3kuICovXG5leHBvcnQgZnVuY3Rpb24gc2V0UHVibGljQWxpYXNQb2xpY3kocHJvZmlsZTogRW50aXR5PCdwcm9qZWN0aW9uX3Byb2ZpbGUnPiwgdGFyZ2V0SWQ6IElELCBhbGlhc0lkOiBJRCk6IEVudGl0eTwncHJvamVjdGlvbl9wcm9maWxlJz4ge1xuICBjb25zdCBjdXJyZW50ID0gcHJvZmlsZS5kYXRhLm5hbWVQb2xpY3k7XG4gIGNvbnN0IHBvbGljeTogTmFtZVBvbGljeU1hcCA9ICdtb2RlJyBpbiBjdXJyZW50ID8geyBkZWZhdWx0UG9saWN5OiBjdXJyZW50LCBieUVudGl0eUlkOiB7fSB9IDogeyAuLi5jdXJyZW50LCBieUVudGl0eUlkOiB7IC4uLmN1cnJlbnQuYnlFbnRpdHlJZCB9IH07XG4gIHJldHVybiB7IC4uLnByb2ZpbGUsIGRhdGE6IHsgLi4ucHJvZmlsZS5kYXRhLCBuYW1lUG9saWN5OiB7IC4uLnBvbGljeSwgYnlFbnRpdHlJZDogeyAuLi5wb2xpY3kuYnlFbnRpdHlJZCwgW3RhcmdldElkXTogeyBtb2RlOiAnYWxpYXMnLCBhbGlhc0lkIH0gfSB9IH0gfTtcbn1cblxuZnVuY3Rpb24gcGlubmVkS2V5KHJlZmVyZW5jZTogV29ybGRSZWZlcmVuY2UpOiBzdHJpbmcgeyByZXR1cm4gSlNPTi5zdHJpbmdpZnkoW3JlZmVyZW5jZS5wcm9qZWN0SWQsIHJlZmVyZW5jZS5pbW11dGFibGVTbmFwc2hvdElkLCByZWZlcmVuY2UuY29udGVudEhhc2hdKTsgfVxuZnVuY3Rpb24gcGlubmVkU25hcHNob3RJbmRleCh3b3JsZHM6IFByb2plY3REYXRhW10pOiBNYXA8c3RyaW5nLCBQcm9qZWN0U25hcHNob3Q+IHtcbiAgY29uc3QgaW5kZXggPSBuZXcgTWFwPHN0cmluZywgUHJvamVjdFNuYXBzaG90PigpO1xuICBmb3IgKGNvbnN0IHdvcmxkIG9mIHdvcmxkcykgZm9yIChjb25zdCBzbmFwc2hvdCBvZiB3b3JsZC5zbmFwc2hvdHMpIGlmIChzbmFwc2hvdC5jb250ZW50LnByb2plY3RJZCA9PT0gd29ybGQucHJvamVjdElkKSB7XG4gICAgY29uc3Qga2V5ID0gcGlubmVkS2V5KHsgcHJvamVjdElkOiB3b3JsZC5wcm9qZWN0SWQsIGltbXV0YWJsZVNuYXBzaG90SWQ6IHNuYXBzaG90LmlkLCBjb250ZW50SGFzaDogc25hcHNob3QuY29udGVudEhhc2ggfSk7XG4gICAgaWYgKCFpbmRleC5oYXMoa2V5KSkgaW5kZXguc2V0KGtleSwgc25hcHNob3QpO1xuICB9XG4gIHJldHVybiBpbmRleDtcbn1cbi8qKiBSZXNvbHZlIHRoZSBleGFjdCBpbW11dGFibGUgdmVyc2lvbiBhY3Jvc3MgZHJhZnRzIGFuZCBzZXBhcmF0ZWx5IHN0b3JlZCByZWdpc3RyeSBlbnZlbG9wZXMuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFBpbm5lZFdvcmxkU25hcHNob3Qod29ybGRzOiBQcm9qZWN0RGF0YVtdLCByZWZlcmVuY2U6IFdvcmxkUmVmZXJlbmNlKTogUHJvamVjdFNuYXBzaG90IHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIHBpbm5lZFNuYXBzaG90SW5kZXgod29ybGRzKS5nZXQocGlubmVkS2V5KHJlZmVyZW5jZSkpO1xufVxuZnVuY3Rpb24gcGlubmVkQ2xvc3VyZShyZWZlcmVuY2VzOiBXb3JsZFJlZmVyZW5jZVtdLCBpbmRleDogTWFwPHN0cmluZywgUHJvamVjdFNuYXBzaG90Pik6IHsgc25hcHNob3RzOiBQcm9qZWN0U25hcHNob3RbXTsgbWlzc2luZzogV29ybGRSZWZlcmVuY2VbXSB9IHtcbiAgY29uc3Qgc25hcHNob3RzOiBQcm9qZWN0U25hcHNob3RbXSA9IFtdLCBtaXNzaW5nOiBXb3JsZFJlZmVyZW5jZVtdID0gW10sIHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKSwgcXVldWUgPSBbLi4ucmVmZXJlbmNlc107XG4gIGZvciAobGV0IGN1cnNvciA9IDA7IGN1cnNvciA8IHF1ZXVlLmxlbmd0aDsgY3Vyc29yKyspIHtcbiAgICBjb25zdCByZWZlcmVuY2UgPSBxdWV1ZVtjdXJzb3JdLCBrZXkgPSBwaW5uZWRLZXkocmVmZXJlbmNlKTsgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlOyBzZWVuLmFkZChrZXkpO1xuICAgIGNvbnN0IHNuYXBzaG90ID0gaW5kZXguZ2V0KGtleSk7IGlmICghc25hcHNob3QpIHsgbWlzc2luZy5wdXNoKHJlZmVyZW5jZSk7IGNvbnRpbnVlOyB9XG4gICAgc25hcHNob3RzLnB1c2goc25hcHNob3QpOyBxdWV1ZS5wdXNoKC4uLnNuYXBzaG90LmNvbnRlbnQud29ybGRSZWZlcmVuY2VzKTtcbiAgfVxuICByZXR1cm4geyBzbmFwc2hvdHMsIG1pc3NpbmcgfTtcbn1cbmZ1bmN0aW9uIG1lcmdlUGlubmVkQ29udGVudChwcm9qZWN0OiBQcm9qZWN0Q29udGVudCwgc25hcHNob3RzOiBQcm9qZWN0U25hcHNob3RbXSk6IFByb2plY3RDb250ZW50IHtcbiAgY29uc3QgZW50aXRpZXMgPSBbLi4ucHJvamVjdC5lbnRpdGllc10sIHJlbGF0aW9ucyA9IFsuLi5wcm9qZWN0LnJlbGF0aW9uc10sIGNhbGVuZGFycyA9IFsuLi5wcm9qZWN0LmNhbGVuZGFyc107XG4gIGNvbnN0IHNlZW5FbnRpdGllcyA9IG5ldyBTZXQoZW50aXRpZXMubWFwKGVudGl0eSA9PiBlbnRpdHkuaWQpKSwgc2VlblJlbGF0aW9ucyA9IG5ldyBTZXQocmVsYXRpb25zLm1hcChyZWxhdGlvbiA9PiByZWxhdGlvbi5pZCkpLCBzZWVuQ2FsZW5kYXJzID0gbmV3IFNldChjYWxlbmRhcnMubWFwKGNhbGVuZGFyID0+IGNhbGVuZGFyLmlkKSk7XG4gIGZvciAoY29uc3Qgc25hcHNob3Qgb2Ygc25hcHNob3RzKSB7XG4gICAgZm9yIChjb25zdCBlbnRpdHkgb2Ygc25hcHNob3QuY29udGVudC5lbnRpdGllcykgaWYgKCFzZWVuRW50aXRpZXMuaGFzKGVudGl0eS5pZCkpIHsgZW50aXRpZXMucHVzaChlbnRpdHkpOyBzZWVuRW50aXRpZXMuYWRkKGVudGl0eS5pZCk7IH1cbiAgICBmb3IgKGNvbnN0IHJlbGF0aW9uIG9mIHNuYXBzaG90LmNvbnRlbnQucmVsYXRpb25zKSBpZiAoIXNlZW5SZWxhdGlvbnMuaGFzKHJlbGF0aW9uLmlkKSkgeyByZWxhdGlvbnMucHVzaChyZWxhdGlvbik7IHNlZW5SZWxhdGlvbnMuYWRkKHJlbGF0aW9uLmlkKTsgfVxuICAgIGZvciAoY29uc3QgY2FsZW5kYXIgb2Ygc25hcHNob3QuY29udGVudC5jYWxlbmRhcnMpIGlmICghc2VlbkNhbGVuZGFycy5oYXMoY2FsZW5kYXIuaWQpKSB7IGNhbGVuZGFycy5wdXNoKGNhbGVuZGFyKTsgc2VlbkNhbGVuZGFycy5hZGQoY2FsZW5kYXIuaWQpOyB9XG4gIH1cbiAgcmV0dXJuIHsgLi4ucHJvamVjdCwgZW50aXRpZXMsIHJlbGF0aW9ucywgY2FsZW5kYXJzIH07XG59XG4vKiogRm9sbG93IGZyb3plbiByZWZlcmVuY2VzIHRyYW5zaXRpdmVseS4gQ3VycmVudCBlZGl0aW5nIGRyYWZ0cyBuZXZlciByZXBsYWNlIHBpbm5lZCBjb250ZW50LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVmZmVjdGl2ZVdvcmxkQ29udGVudChwcm9qZWN0OiBQcm9qZWN0RGF0YSwgd29ybGRzOiBQcm9qZWN0RGF0YVtdKTogUHJvamVjdENvbnRlbnQge1xuICBjb25zdCB7IGhpc3Rvcnk6IF9oaXN0b3J5LCBzbmFwc2hvdHM6IF9zbmFwc2hvdHMsIGF1dGhvckFsdGVybmF0aXZlczogX2F1dGhvckFsdGVybmF0aXZlcywgLi4uY29udGVudCB9ID0gcHJvamVjdDtcbiAgcmV0dXJuIG1lcmdlUGlubmVkQ29udGVudChjb250ZW50LCBwaW5uZWRDbG9zdXJlKHByb2plY3Qud29ybGRSZWZlcmVuY2VzLCBwaW5uZWRTbmFwc2hvdEluZGV4KHdvcmxkcykpLnNuYXBzaG90cyk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgV29ybGRWZXJzaW9uRGlmZmVyZW5jZSB7IGlkOiBJRDsga2luZDogJ2VudGl0eScgfCAncmVsYXRpb24nIHwgJ2NhbGVuZGFyJzsgY2hhbmdlOiAnYWRkZWQnIHwgJ2NoYW5nZWQnIHwgJ3JlbW92ZWQnOyBiZWZvcmU/OiB1bmtub3duOyBhZnRlcj86IHVua25vd247IGJlZm9yZVNuYXBzaG90SWQ/OiBJRDsgYWZ0ZXJTbmFwc2hvdElkPzogSUQgfVxuZXhwb3J0IGludGVyZmFjZSBXb3JsZFZlcnNpb25QcmV2aWV3IHsgY2FuZGlkYXRlOiBQcm9qZWN0RGF0YTsgcmVmZXJlbmNlOiBXb3JsZFJlZmVyZW5jZTsgZGlmZmVyZW5jZXM6IFdvcmxkVmVyc2lvbkRpZmZlcmVuY2VbXTsgYWZmZWN0ZWRJZHM6IElEW107IGJyb2tlblJlZmVyZW5jZUlkczogSURbXTsgY2FuQXBwbHk6IGJvb2xlYW4gfVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXZpZXdXb3JsZFZlcnNpb24ocHJvamVjdDogUHJvamVjdERhdGEsIHdvcmxkOiBQcm9qZWN0RGF0YSwgc25hcHNob3RJZDogSUQsIGFkb3B0ZWRJZHM6IElEW10gPSBbXSwgd29ybGRzOiBQcm9qZWN0RGF0YVtdID0gW10pOiBQcm9taXNlPFdvcmxkVmVyc2lvblByZXZpZXc+IHtcbiAgaWYgKHdvcmxkLnByb2plY3RJZCA9PT0gcHJvamVjdC5wcm9qZWN0SWQpIHRocm93IG5ldyBFcnJvcign5L2c5ZOB6Ieq6Lqr44KS5YWx6YCa5LiW55WM44Go44GX44Gm5Y+C54Wn44Gn44GN44G+44Gb44KT44CCJyk7XG4gIGNvbnN0IHNvdXJjZXMgPSBbd29ybGQsIC4uLndvcmxkc10sIGluZGV4ID0gcGlubmVkU25hcHNob3RJbmRleChzb3VyY2VzKSwgbmV4dCA9IHNvdXJjZXMuZmlsdGVyKHNvdXJjZSA9PiBzb3VyY2UucHJvamVjdElkID09PSB3b3JsZC5wcm9qZWN0SWQpLmZsYXRNYXAoc291cmNlID0+IHNvdXJjZS5zbmFwc2hvdHMpLmZpbmQoc25hcHNob3QgPT4gc25hcHNob3QuaWQgPT09IHNuYXBzaG90SWQpO1xuICBpZiAoIW5leHQgfHwgbmV4dC5jb250ZW50LnByb2plY3RJZCAhPT0gd29ybGQucHJvamVjdElkIHx8IGF3YWl0IHNoYTI1Nihqc29uQnl0ZXMobmV4dC5jb250ZW50KSkgIT09IG5leHQuY29udGVudEhhc2gpIHRocm93IG5ldyBFcnJvcign6YG45oqe44GX44Gf5YWx6YCa5LiW55WM54mI44GM5a2Y5Zyo44GX44Gq44GE44GL44CB5YaF5a6544GuaGFzaOOBjOS4gOiHtOOBl+OBvuOBm+OCk+OAgicpO1xuICBjb25zdCBjdXJyZW50ID0gcHJvamVjdC53b3JsZFJlZmVyZW5jZXMuZmluZChyZWZlcmVuY2UgPT4gcmVmZXJlbmNlLnByb2plY3RJZCA9PT0gd29ybGQucHJvamVjdElkKSwgcHJldmlvdXMgPSBjdXJyZW50ID8gaW5kZXguZ2V0KHBpbm5lZEtleShjdXJyZW50KSkgOiB1bmRlZmluZWQ7XG4gIGlmIChjdXJyZW50ICYmICFwcmV2aW91cykgdGhyb3cgbmV3IEVycm9yKCfnj77lnKjlm7rlrprjgZfjgabjgYTjgovlhbHpgJrkuJbnlYzniYjjgYzjgYLjgorjgb7jgZvjgpPjgILmlLnoqILlt67liIbjgpLnorroqo3jgZnjgovjgZ/jgoHjgIHml6fniYjjgpLkv53mjIHjgZfjgabjgY/jgaDjgZXjgYTjgIInKTtcbiAgaWYgKHByZXZpb3VzICYmIGF3YWl0IHNoYTI1Nihqc29uQnl0ZXMocHJldmlvdXMuY29udGVudCkpICE9PSBwcmV2aW91cy5jb250ZW50SGFzaCkgdGhyb3cgbmV3IEVycm9yKCfml6fkuJbnlYzniYjjga7lhoXlrrnjga5oYXNo44GM5LiA6Ie044GX44G+44Gb44KT44CC5beu5YiG44KS56K65a6a44Gn44GN44G+44Gb44KT44CCJyk7XG4gIGNvbnN0IHByZXZpb3VzQ2xvc3VyZSA9IHBpbm5lZENsb3N1cmUocHJldmlvdXM/LmNvbnRlbnQud29ybGRSZWZlcmVuY2VzID8/IFtdLCBpbmRleCksIG5leHRDbG9zdXJlID0gcGlubmVkQ2xvc3VyZShuZXh0LmNvbnRlbnQud29ybGRSZWZlcmVuY2VzLCBpbmRleCk7XG4gIGlmIChwcmV2aW91c0Nsb3N1cmUubWlzc2luZy5sZW5ndGggfHwgbmV4dENsb3N1cmUubWlzc2luZy5sZW5ndGgpIHRocm93IG5ldyBFcnJvcign5YWx6YCa5LiW55WM44GM5Zu65a6a44GX44Gm5Y+C54Wn44GZ44KL5Yil44Gu5LiW55WM54mI44GM44GC44KK44G+44Gb44KT44CC5pS56KiC5beu5YiG44KS56K66KqN44GZ44KL44Gf44KB44CB44GZ44G544Gm44Gu5Zu65a6a54mI44KS5L+d5oyB44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gIGZvciAoY29uc3Qgc25hcHNob3Qgb2YgWy4uLnByZXZpb3VzQ2xvc3VyZS5zbmFwc2hvdHMsIC4uLm5leHRDbG9zdXJlLnNuYXBzaG90c10pIGlmIChhd2FpdCBzaGEyNTYoanNvbkJ5dGVzKHNuYXBzaG90LmNvbnRlbnQpKSAhPT0gc25hcHNob3QuY29udGVudEhhc2gpIHRocm93IG5ldyBFcnJvcign5Y+C54Wn5YWI44Gu5Zu65a6a5LiW55WM54mI44Gu5YaF5a6544GuaGFzaOOBjOS4gOiHtOOBl+OBvuOBm+OCk+OAgicpO1xuICBjb25zdCBjYWxlbmRhckRlZmluaXRpb25zID0gbmV3IE1hcChwcm9qZWN0LmNhbGVuZGFycy5tYXAoY2FsZW5kYXIgPT4gW2NhbGVuZGFyLmlkLCBjYWxlbmRhcl0pKTtcbiAgZm9yIChjb25zdCBzbmFwc2hvdCBvZiBbbmV4dCwgLi4ubmV4dENsb3N1cmUuc25hcHNob3RzXSkgZm9yIChjb25zdCBjYWxlbmRhciBvZiBzbmFwc2hvdC5jb250ZW50LmNhbGVuZGFycykgeyBjb25zdCBleGlzdGluZyA9IGNhbGVuZGFyRGVmaW5pdGlvbnMuZ2V0KGNhbGVuZGFyLmlkKTsgaWYgKGV4aXN0aW5nICYmICFzYW1lQ2FsZW5kYXJEZWZpbml0aW9uKGV4aXN0aW5nLCBjYWxlbmRhcikpIHRocm93IG5ldyBFcnJvcihg5ZCM44GY5pqmSUTjgIwke2NhbGVuZGFyLmlkfeOAjeOBq+eVsOOBquOCi+imj+WJh+OBjOOBguOCiuOBvuOBmeOAguS9nOWTgeOBqOWbuuWumuS4lueVjOOBruaapklE44O76KaP5YmH44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCYCk7IGNhbGVuZGFyRGVmaW5pdGlvbnMuc2V0KGNhbGVuZGFyLmlkLCBjYWxlbmRhcik7IH1cbiAgY29uc3QgYmVmb3JlQ29udGVudCA9IHByZXZpb3VzID8gbWVyZ2VQaW5uZWRDb250ZW50KHByZXZpb3VzLmNvbnRlbnQsIHByZXZpb3VzQ2xvc3VyZS5zbmFwc2hvdHMpIDogdW5kZWZpbmVkLCBhZnRlckNvbnRlbnQgPSBtZXJnZVBpbm5lZENvbnRlbnQobmV4dC5jb250ZW50LCBuZXh0Q2xvc3VyZS5zbmFwc2hvdHMpO1xuICBjb25zdCB2ZXJzaW9uSWRzID0gKHNuYXBzaG90czogUHJvamVjdFNuYXBzaG90W10pID0+IHsgY29uc3QgdmVyc2lvbnMgPSBuZXcgTWFwPHN0cmluZywgSUQ+KCk7IGZvciAoY29uc3Qgc25hcHNob3Qgb2Ygc25hcHNob3RzKSBmb3IgKGNvbnN0IFtraW5kLCByZWNvcmRzXSBvZiBbWydlbnRpdHknLCBzbmFwc2hvdC5jb250ZW50LmVudGl0aWVzXSwgWydyZWxhdGlvbicsIHNuYXBzaG90LmNvbnRlbnQucmVsYXRpb25zXSwgWydjYWxlbmRhcicsIHNuYXBzaG90LmNvbnRlbnQuY2FsZW5kYXJzXV0gYXMgY29uc3QpIGZvciAoY29uc3QgcmVjb3JkIG9mIHJlY29yZHMpIGlmICghdmVyc2lvbnMuaGFzKGAke2tpbmR9OiR7cmVjb3JkLmlkfWApKSB2ZXJzaW9ucy5zZXQoYCR7a2luZH06JHtyZWNvcmQuaWR9YCwgc25hcHNob3QuaWQpOyByZXR1cm4gdmVyc2lvbnM7IH07XG4gIGNvbnN0IGJlZm9yZVZlcnNpb25zID0gdmVyc2lvbklkcyhwcmV2aW91cyA/IFtwcmV2aW91cywgLi4ucHJldmlvdXNDbG9zdXJlLnNuYXBzaG90c10gOiBbXSksIGFmdGVyVmVyc2lvbnMgPSB2ZXJzaW9uSWRzKFtuZXh0LCAuLi5uZXh0Q2xvc3VyZS5zbmFwc2hvdHNdKTtcbiAgY29uc3QgZGlmZmVyZW5jZXM6IFdvcmxkVmVyc2lvbkRpZmZlcmVuY2VbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtraW5kLCBiZWZvcmUsIGFmdGVyXSBvZiBbWydlbnRpdHknLCBiZWZvcmVDb250ZW50Py5lbnRpdGllcyA/PyBbXSwgYWZ0ZXJDb250ZW50LmVudGl0aWVzXSwgWydyZWxhdGlvbicsIGJlZm9yZUNvbnRlbnQ/LnJlbGF0aW9ucyA/PyBbXSwgYWZ0ZXJDb250ZW50LnJlbGF0aW9uc10sIFsnY2FsZW5kYXInLCBiZWZvcmVDb250ZW50Py5jYWxlbmRhcnMgPz8gW10sIGFmdGVyQ29udGVudC5jYWxlbmRhcnNdXSBhcyBjb25zdCkge1xuICAgIGNvbnN0IGEgPSBuZXcgTWFwPHN0cmluZywgdW5rbm93bj4oYmVmb3JlLmZpbHRlcih2YWx1ZSA9PiAhKCdkZWxldGVkQXQnIGluIHZhbHVlKSB8fCAhdmFsdWUuZGVsZXRlZEF0KS5tYXAodmFsdWUgPT4gW3ZhbHVlLmlkLCB2YWx1ZV0pKSwgYiA9IG5ldyBNYXA8c3RyaW5nLCB1bmtub3duPihhZnRlci5maWx0ZXIodmFsdWUgPT4gISgnZGVsZXRlZEF0JyBpbiB2YWx1ZSkgfHwgIXZhbHVlLmRlbGV0ZWRBdCkubWFwKHZhbHVlID0+IFt2YWx1ZS5pZCwgdmFsdWVdKSk7XG4gICAgZm9yIChjb25zdCBbaWQsIHZhbHVlXSBvZiBiKSBpZiAoIWEuaGFzKGlkKSB8fCAhZXF1YWxKc29uKGEuZ2V0KGlkKSwgdmFsdWUpKSBkaWZmZXJlbmNlcy5wdXNoKHsgaWQsIGtpbmQsIGNoYW5nZTogYS5oYXMoaWQpID8gJ2NoYW5nZWQnIDogJ2FkZGVkJywgYmVmb3JlOiBhLmdldChpZCksIGFmdGVyOiB2YWx1ZSwgYmVmb3JlU25hcHNob3RJZDogYmVmb3JlVmVyc2lvbnMuZ2V0KGAke2tpbmR9OiR7aWR9YCksIGFmdGVyU25hcHNob3RJZDogYWZ0ZXJWZXJzaW9ucy5nZXQoYCR7a2luZH06JHtpZH1gKSB9KTtcbiAgICBmb3IgKGNvbnN0IFtpZCwgdmFsdWVdIG9mIGEpIGlmICghYi5oYXMoaWQpKSBkaWZmZXJlbmNlcy5wdXNoKHsgaWQsIGtpbmQsIGNoYW5nZTogJ3JlbW92ZWQnLCBiZWZvcmU6IHZhbHVlLCBiZWZvcmVTbmFwc2hvdElkOiBiZWZvcmVWZXJzaW9ucy5nZXQoYCR7a2luZH06JHtpZH1gKSB9KTtcbiAgfVxuICBjb25zdCBjaGFuZ2VkID0gbmV3IFNldChkaWZmZXJlbmNlcy5tYXAoZGlmZmVyZW5jZSA9PiBkaWZmZXJlbmNlLmlkKSksIHJlbW92ZWQgPSBuZXcgU2V0KGRpZmZlcmVuY2VzLmZpbHRlcihkaWZmZXJlbmNlID0+IGRpZmZlcmVuY2UuY2hhbmdlID09PSAncmVtb3ZlZCcpLm1hcChkaWZmZXJlbmNlID0+IGRpZmZlcmVuY2UuaWQpKSwgYWZmZWN0ZWRJZHMgPSBuZXcgU2V0PElEPigpLCBicm9rZW4gPSBuZXcgU2V0PElEPigpO1xuICBmb3IgKGNvbnN0IGVudGl0eSBvZiBwcm9qZWN0LmVudGl0aWVzKSBpZiAoIWVudGl0eS5kZWxldGVkQXQpIGZvciAoY29uc3QgcmVmZXJlbmNlIG9mIGNvbGxlY3RSZWZlcmVuY2VzKGVudGl0eSkpIHtcbiAgICBpZiAoaW1tdXRhYmxlUmVmZXJlbmNlVmVyc2lvbihlbnRpdHksIHJlZmVyZW5jZSkpIGNvbnRpbnVlO1xuICAgIGlmIChjaGFuZ2VkLmhhcyhyZWZlcmVuY2UuaWQpKSBhZmZlY3RlZElkcy5hZGQoZW50aXR5LmlkKTtcbiAgICBpZiAocmVtb3ZlZC5oYXMocmVmZXJlbmNlLmlkKSkgYnJva2VuLmFkZChlbnRpdHkuaWQpO1xuICB9XG4gIGZvciAoY29uc3QgcmVsYXRpb24gb2YgcHJvamVjdC5yZWxhdGlvbnMpIGlmICghcmVsYXRpb24uZGVsZXRlZEF0KSBmb3IgKGNvbnN0IHJlZmVyZW5jZSBvZiBjb2xsZWN0UmVsYXRpb25SZWZlcmVuY2VzKHJlbGF0aW9uKSkgeyBpZiAoaW1tdXRhYmxlUmVmZXJlbmNlVmVyc2lvbihyZWxhdGlvbiwgcmVmZXJlbmNlKSkgY29udGludWU7IGlmIChjaGFuZ2VkLmhhcyhyZWZlcmVuY2UuaWQpKSBhZmZlY3RlZElkcy5hZGQocmVsYXRpb24uaWQpOyBpZiAocmVtb3ZlZC5oYXMocmVmZXJlbmNlLmlkKSkgYnJva2VuLmFkZChyZWxhdGlvbi5pZCk7IH1cbiAgY29uc3QgaWRzID0gbmV3IFNldChuZXh0LmNvbnRlbnQuZW50aXRpZXMuZmlsdGVyKGVudGl0eSA9PiAhZW50aXR5LmRlbGV0ZWRBdCkubWFwKGVudGl0eSA9PiBlbnRpdHkuaWQpKTtcbiAgaWYgKGFkb3B0ZWRJZHMuc29tZShpZCA9PiAhaWRzLmhhcyhpZCkpKSB0aHJvdyBuZXcgRXJyb3IoJ+aOoeeUqOOBmeOCi+ioreWumuODu+S6uueJqeOBr+mBuOaKnuOBl+OBn+S4lueVjOeJiOOBi+OCiemBuOOCk+OBp+OBj+OBoOOBleOBhOOAgicpO1xuICBjb25zdCByZWZlcmVuY2U6IFdvcmxkUmVmZXJlbmNlID0geyBwcm9qZWN0SWQ6IHdvcmxkLnByb2plY3RJZCwgaW1tdXRhYmxlU25hcHNob3RJZDogbmV4dC5pZCwgY29udGVudEhhc2g6IG5leHQuY29udGVudEhhc2ggfTtcbiAgY29uc3Qgdmlld0tleSA9IGB3b3JsZC1hZG9wdGlvbjoke3dvcmxkLnByb2plY3RJZH1gLCBleGlzdGluZ1ZpZXcgPSBwcm9qZWN0LnZpZXdzLmZpbmQodmlldyA9PiB2aWV3LnZpZXcgPT09IHZpZXdLZXkpO1xuICBjb25zdCBhZG9wdGlvbiA9IHsgaWQ6IGV4aXN0aW5nVmlldz8uaWQgPz8gbmV3SWQoKSwgbmFtZTogYCR7d29ybGQubmFtZX3jga7mjqHnlKjoqK3lrppgLCB2aWV3OiB2aWV3S2V5LCBlbnRpdHlJZHM6IFsuLi5uZXcgU2V0KGFkb3B0ZWRJZHMpXSwgc2V0dGluZ3M6IHsgd29ybGRQcm9qZWN0SWQ6IHdvcmxkLnByb2plY3RJZCwgc25hcHNob3RJZDogbmV4dC5pZCB9IH07XG4gIGNvbnN0IGNhbmRpZGF0ZSA9IHsgLi4ucHJvamVjdCwgd29ybGRSZWZlcmVuY2VzOiBbLi4ucHJvamVjdC53b3JsZFJlZmVyZW5jZXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5wcm9qZWN0SWQgIT09IHdvcmxkLnByb2plY3RJZCksIHJlZmVyZW5jZV0sIHZpZXdzOiBleGlzdGluZ1ZpZXcgPyBwcm9qZWN0LnZpZXdzLm1hcCh2aWV3ID0+IHZpZXcuaWQgPT09IGV4aXN0aW5nVmlldy5pZCA/IGFkb3B0aW9uIDogdmlldykgOiBbLi4ucHJvamVjdC52aWV3cywgYWRvcHRpb25dIH07XG4gIGZvciAoY29uc3QgdmlldyBvZiBjYW5kaWRhdGUudmlld3MpIGZvciAoY29uc3QgaWQgb2Ygdmlldy5lbnRpdHlJZHMpIHsgaWYgKGNoYW5nZWQuaGFzKGlkKSkgYWZmZWN0ZWRJZHMuYWRkKHZpZXcuaWQpOyBpZiAocmVtb3ZlZC5oYXMoaWQpKSBicm9rZW4uYWRkKHZpZXcuaWQpOyB9XG4gIHJldHVybiB7IGNhbmRpZGF0ZSwgcmVmZXJlbmNlLCBkaWZmZXJlbmNlcywgYWZmZWN0ZWRJZHM6IFsuLi5hZmZlY3RlZElkc10sIGJyb2tlblJlZmVyZW5jZUlkczogWy4uLmJyb2tlbl0sIGNhbkFwcGx5OiBicm9rZW4uc2l6ZSA9PT0gMCB9O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVdvcmxkU25hcHNob3QocHJvamVjdDogUHJvamVjdERhdGEsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPFByb2plY3REYXRhPiB7XG4gIGNvbnN0IHsgaGlzdG9yeTogX2hpc3RvcnksIHNuYXBzaG90czogX3NuYXBzaG90cywgYXV0aG9yQWx0ZXJuYXRpdmVzOiBfYXV0aG9yQWx0ZXJuYXRpdmVzLCAuLi5jb250ZW50IH0gPSBzdHJ1Y3R1cmVkQ2xvbmUocHJvamVjdCk7XG4gIGNvbnN0IGlkID0gbmV3SWQoKSwgY29udGVudEhhc2ggPSBhd2FpdCBzaGEyNTYoanNvbkJ5dGVzKGNvbnRlbnQpKSwgdmVyc2lvbkxhYmVsID0gbGFiZWwudHJpbSgpIHx8IGDkuJbnlYzniYggJHtwcm9qZWN0LnJldmlzaW9ufWA7XG4gIGNvbnN0IHNuYXBzaG90OiBQcm9qZWN0U25hcHNob3QgPSB7IGlkLCBjb250ZW50SGFzaCwgdmVyc2lvbkxhYmVsLCBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSwgY29udGVudCB9O1xuICBjb25zdCBtZXRhZGF0YSA9IHsgLi4uY3JlYXRlRW50aXR5KHByb2plY3QucHJvamVjdElkLCAnc25hcHNob3QnLCB2ZXJzaW9uTGFiZWwsIHsgdmVyc2lvbkxhYmVsLCBjb250ZW50SGFzaCwgaW1tdXRhYmxlOiB0cnVlIH0pLCBpZCB9O1xuICByZXR1cm4geyAuLi5wcm9qZWN0LCBzbmFwc2hvdHM6IFsuLi5wcm9qZWN0LnNuYXBzaG90cywgc25hcHNob3RdLCBlbnRpdGllczogWy4uLnByb2plY3QuZW50aXRpZXMsIG1ldGFkYXRhXSB9O1xufVxuXG4vKiogQSBwbGFjZSBhbmQgb25lIG9mIGl0cyBjb250YWluaW5nIGFyZWFzIGRlc2NyaWJlIGNvbXBhdGlibGUgbG9jYXRpb25zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbXBhdGlibGVMb2NhdGlvbnMoYTogSUQsIGI6IElELCBpbmRleDogTWFwPElELCBFbnRpdHk+KTogYm9vbGVhbiB7XG4gIGNvbnN0IGNvbnRhaW5zID0gKGNoaWxkOiBJRCwgcGFyZW50OiBJRCkgPT4geyBjb25zdCB2aXNpdGVkID0gbmV3IFNldDxJRD4oKTsgbGV0IGN1cnJlbnQ6IElEIHwgdW5kZWZpbmVkID0gY2hpbGQ7IHdoaWxlIChjdXJyZW50ICYmICF2aXNpdGVkLmhhcyhjdXJyZW50KSkgeyBpZiAoY3VycmVudCA9PT0gcGFyZW50KSByZXR1cm4gdHJ1ZTsgdmlzaXRlZC5hZGQoY3VycmVudCk7IGNvbnN0IGVudGl0eSA9IGluZGV4LmdldChjdXJyZW50KTsgY3VycmVudCA9IGVudGl0eT8ua2luZCA9PT0gJ3BsYWNlJyA/IGVudGl0eS5kYXRhLnBhcmVudElkID8/IHVuZGVmaW5lZCA6IHVuZGVmaW5lZDsgfSByZXR1cm4gZmFsc2U7IH07XG4gIHJldHVybiBjb250YWlucyhhLCBiKSB8fCBjb250YWlucyhiLCBhKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3b3JsZFBlcmlvZHNPdmVybGFwKGE6IFZhbGlkaXR5IHwgbnVsbCB8IHVuZGVmaW5lZCwgYjogVmFsaWRpdHkgfCBudWxsIHwgdW5kZWZpbmVkKTogYm9vbGVhbiB7XG4gIGNvbnN0IHggPSBhPy53b3JsZFJhbmdlLCB5ID0gYj8ud29ybGRSYW5nZTtcbiAgcmV0dXJuICEoeD8uZW5kICYmIHk/LnN0YXJ0ICYmIHBhcnNlVGljayh4LmVuZCkgPD0gcGFyc2VUaWNrKHkuc3RhcnQpIHx8IHk/LmVuZCAmJiB4Py5zdGFydCAmJiBwYXJzZVRpY2soeS5lbmQpIDw9IHBhcnNlVGljayh4LnN0YXJ0KSk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUNBLFNBQVNBLGlCQUFpQixFQUFFQyx5QkFBeUIsRUFBRUMsWUFBWSxFQUFFQyxpQkFBaUIsRUFBRUMsS0FBSyxRQUFRLFNBQVM7QUFDOUcsU0FBU0MseUJBQXlCLFFBQVEsZUFBZTtBQUN6RCxTQUFTQyxpQkFBaUIsUUFBUSxjQUFjO0FBQ2hELFNBQVNDLFlBQVksRUFBRUMsTUFBTSxFQUFFQyxTQUFTLEVBQUVDLHNCQUFzQixRQUFRLFFBQVE7QUFDaEYsU0FBU0MsU0FBUyxFQUFFQyxTQUFTLEVBQUVDLE1BQU0sUUFBUSxpQkFBaUI7QUFDOUQsU0FBU0MsYUFBYSxFQUFFQyxrQkFBa0IsUUFBUSxZQUFZOztBQUU5RDtBQUNBLE9BQU8sTUFBTUMsZ0JBQWdCLEdBQUc7RUFDOUJDLFFBQVEsRUFBRSxVQUFVO0VBQUVDLFNBQVMsRUFBRSxPQUFPO0VBQUVDLFVBQVUsRUFBRSxXQUFXO0VBQUVDLFdBQVcsRUFBRSxjQUFjO0VBQzlGQyxVQUFVLEVBQUUsYUFBYTtFQUFFQyxPQUFPLEVBQUUsZUFBZTtFQUFFQyxRQUFRLEVBQUUsVUFBVTtFQUFFQyxVQUFVLEVBQUU7QUFDekYsQ0FBVTtBQUNWLE9BQU8sTUFBTUMsc0JBQThDLEdBQUc7RUFBRVIsUUFBUSxFQUFFLEtBQUs7RUFBRVMsS0FBSyxFQUFFLEtBQUs7RUFBRUMsU0FBUyxFQUFFLElBQUk7RUFBRUMsWUFBWSxFQUFFLE9BQU87RUFBRUMsV0FBVyxFQUFFLFlBQVk7RUFBRUMsYUFBYSxFQUFFLE1BQU07RUFBRVAsUUFBUSxFQUFFLElBQUk7RUFBRVEsb0JBQW9CLEVBQUU7QUFBZ0IsQ0FBQztBQUdoUCxTQUFTQyxPQUFPQSxDQUFDQyxNQUFvQixFQUFjO0VBQUUsT0FBT0EsTUFBTSxDQUFDQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsT0FBTyxHQUFHRCxNQUFNLENBQUNDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsTUFBTTtBQUFFO0FBQ2xKLFNBQVNDLGVBQWVBLENBQUNDLFNBQW9CLEVBQVc7RUFDdEQsSUFBSUEsU0FBUyxDQUFDQyxFQUFFLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztFQUM3QyxJQUFJRCxTQUFTLENBQUNDLEVBQUUsS0FBSyxLQUFLLEVBQUUsT0FBT0YsZUFBZSxDQUFDQyxTQUFTLENBQUNFLEtBQUssQ0FBQztFQUNuRSxJQUFJRixTQUFTLENBQUNDLEVBQUUsS0FBSyxLQUFLLElBQUlELFNBQVMsQ0FBQ0MsRUFBRSxLQUFLLEtBQUssRUFBRSxPQUFPRCxTQUFTLENBQUNHLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDTCxlQUFlLENBQUM7RUFDckcsT0FBTyxJQUFJO0FBQ2I7QUFDQTtBQUNBLE9BQU8sU0FBU00sbUJBQW1CQSxDQUFDQyxRQUFxQyxFQUFFQyxLQUFpQixHQUFHLENBQUMsQ0FBQyxFQUFzQjtFQUNySCxJQUFJLENBQUNELFFBQVEsRUFBRSxPQUFPO0lBQUVFLEtBQUssRUFBRSxNQUFNO0lBQUVDLE9BQU8sRUFBRTtFQUFHLENBQUM7RUFDcEQsTUFBTVosTUFBb0IsR0FBRyxFQUFFO0lBQUVZLE9BQWlCLEdBQUcsRUFBRTtFQUN2RCxJQUFJSCxRQUFRLENBQUNJLFVBQVUsS0FBS0osUUFBUSxDQUFDSSxVQUFVLENBQUNDLEtBQUssS0FBSyxJQUFJLElBQUlMLFFBQVEsQ0FBQ0ksVUFBVSxDQUFDRSxHQUFHLEtBQUssSUFBSSxDQUFDLEVBQUU7SUFDbkcsSUFBSSxDQUFDTCxLQUFLLENBQUNNLEVBQUUsSUFBSSxDQUFDekMsTUFBTSxDQUFDbUMsS0FBSyxDQUFDTSxFQUFFLENBQUMsRUFBRTtNQUFFaEIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDLFNBQVMsQ0FBQztNQUFFTCxPQUFPLENBQUNLLElBQUksQ0FBQyxhQUFhLENBQUM7SUFBRSxDQUFDLE1BQ3ZGO01BQUUsTUFBTUMsS0FBSyxHQUFHVCxRQUFRLENBQUNJLFVBQVU7TUFBRWIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDQyxLQUFLLENBQUNKLEtBQUssSUFBSXhDLFlBQVksQ0FBQ29DLEtBQUssQ0FBQ00sRUFBRSxFQUFFRSxLQUFLLENBQUNKLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSUksS0FBSyxDQUFDSCxHQUFHLElBQUl6QyxZQUFZLENBQUNvQyxLQUFLLENBQUNNLEVBQUUsRUFBRUUsS0FBSyxDQUFDSCxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxHQUFHLE1BQU0sQ0FBQztJQUFFO0VBQzNMO0VBQ0EsSUFBSU4sUUFBUSxDQUFDVSxjQUFjLEVBQUU7SUFDM0IsSUFBSSxDQUFDVCxLQUFLLENBQUNVLE9BQU8sSUFBSWxCLGVBQWUsQ0FBQ08sUUFBUSxDQUFDVSxjQUFjLENBQUMsRUFBRTtNQUFFbkIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDLFNBQVMsQ0FBQztNQUFFTCxPQUFPLENBQUNLLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUFFLENBQUMsTUFDdEgsSUFBSTtNQUFBLElBQUFJLGNBQUE7TUFBRSxNQUFNQyxNQUFNLEdBQUdqRCxpQkFBaUIsQ0FBQ29DLFFBQVEsQ0FBQ1UsY0FBYyxHQUFBRSxjQUFBLEdBQUVYLEtBQUssQ0FBQ1UsT0FBTyxjQUFBQyxjQUFBLGNBQUFBLGNBQUEsR0FBSTtRQUFFRSxLQUFLLEVBQUVyRCxpQkFBaUIsQ0FBQyxZQUFZO01BQUUsQ0FBQyxDQUFDO01BQUU4QixNQUFNLENBQUNpQixJQUFJLENBQUNLLE1BQU0sQ0FBQ1gsS0FBSyxDQUFDO01BQUVDLE9BQU8sQ0FBQ0ssSUFBSSxDQUFDLEdBQUdLLE1BQU0sQ0FBQ1YsT0FBTyxDQUFDO0lBQUUsQ0FBQyxDQUNoTSxPQUFPWSxLQUFLLEVBQUU7TUFBRXhCLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQyxTQUFTLENBQUM7TUFBRUwsT0FBTyxDQUFDSyxJQUFJLENBQUNPLEtBQUssWUFBWUMsS0FBSyxHQUFHRCxLQUFLLENBQUNFLE9BQU8sR0FBRyxlQUFlLENBQUM7SUFBRTtFQUNsSDtFQUNBLElBQUlqQixRQUFRLENBQUNrQixrQkFBa0IsRUFBRTtJQUMvQixJQUFJLENBQUNqQixLQUFLLENBQUNrQixlQUFlLEVBQUU7TUFBRTVCLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQyxTQUFTLENBQUM7TUFBRUwsT0FBTyxDQUFDSyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQUUsQ0FBQyxNQUMvRWpCLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQ1AsS0FBSyxDQUFDa0IsZUFBZSxDQUFDM0IsUUFBUSxDQUFDUSxRQUFRLENBQUNrQixrQkFBa0IsQ0FBQ0UsUUFBUSxDQUFDLEdBQUcsTUFBTSxHQUFHLE9BQU8sQ0FBQztFQUMzRztFQUNBLE9BQU87SUFBRWxCLEtBQUssRUFBRVosT0FBTyxDQUFDQyxNQUFNLENBQUM7SUFBRVksT0FBTyxFQUFFLENBQUMsR0FBRyxJQUFJa0IsR0FBRyxDQUFDbEIsT0FBTyxDQUFDO0VBQUUsQ0FBQztBQUNuRTtBQUVBLE9BQU8sU0FBU21CLGtCQUFrQkEsQ0FBQ3BCLEtBQXNCLEVBQWtCO0VBQUUsT0FBTyxPQUFPQSxLQUFLLEtBQUssUUFBUSxHQUFHQSxLQUFLLEdBQUdBLEtBQUssQ0FBQ3FCLElBQUksS0FBSyxLQUFLLEdBQUdyQixLQUFLLENBQUNBLEtBQUssR0FBR3NCLFNBQVM7QUFBRTtBQUN4SyxPQUFPLFNBQVNDLG1CQUFtQkEsQ0FBQ3ZCLEtBQXNCLEVBQUV3QixLQUFzQixFQUFVO0VBQUEsSUFBQUMsVUFBQTtFQUMxRixNQUFNQyxTQUFTLEdBQUdOLGtCQUFrQixDQUFDcEIsS0FBSyxDQUFDO0VBQzNDLElBQUkwQixTQUFTLEVBQUUsT0FBTyxFQUFBRCxVQUFBLEdBQUFELEtBQUssQ0FBQ0csR0FBRyxDQUFDRCxTQUFTLENBQUMsY0FBQUQsVUFBQSx1QkFBcEJBLFVBQUEsQ0FBc0JHLElBQUksS0FBSSxRQUFRO0VBQzVELE9BQU8sT0FBTzVCLEtBQUssS0FBSyxRQUFRLElBQUlBLEtBQUssQ0FBQ3FCLElBQUksS0FBSyxTQUFTLEdBQUcsUUFBUXJCLEtBQUssQ0FBQzZCLE1BQU0sRUFBRSxHQUFHLE9BQU83QixLQUFLLEtBQUssUUFBUSxHQUFHOEIsTUFBTSxDQUFDOUIsS0FBSyxDQUFDQSxLQUFLLENBQUMsR0FBR0EsS0FBSztBQUNqSjtBQUdBLFNBQVMrQixxQkFBcUJBLENBQUNDLFVBQWlDLEVBQUVqQyxLQUFpQixFQUFFa0MsUUFBYSxFQUFvQjtFQUNwSCxNQUFNQyxVQUFVLEdBQUdGLFVBQVUsQ0FBQ0csTUFBTSxDQUFDQyxNQUFNLElBQUlsRSxhQUFhLENBQUNrRSxNQUFNLENBQUMsS0FBS0gsUUFBUSxHQUFHRyxNQUFNLENBQUNDLElBQUksQ0FBQ0MsU0FBUyxLQUFLLGNBQWMsSUFBSUYsTUFBTSxDQUFDQyxJQUFJLENBQUNKLFFBQVEsS0FBS0EsUUFBUSxHQUFHRyxNQUFNLENBQUNDLElBQUksQ0FBQ0MsU0FBUyxLQUFLLGNBQWMsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsU0FBUyxLQUFLO0lBQUVBLFNBQVM7SUFBRUMsVUFBVSxFQUFFdEUsa0JBQWtCLENBQUNxRSxTQUFTLEVBQUUzQyxtQkFBbUIsQ0FBQzJDLFNBQVMsQ0FBQ0gsSUFBSSxDQUFDdkMsUUFBUSxFQUFFQyxLQUFLLENBQUMsQ0FBQztJQUFFMkMsUUFBUSxFQUFFdEIsa0JBQWtCLENBQUNvQixTQUFTLENBQUNILElBQUksQ0FBQ3JDLEtBQUs7RUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDbUMsTUFBTSxDQUFDUSxTQUFTLElBQUlBLFNBQVMsQ0FBQ0YsVUFBVSxDQUFDekMsS0FBSyxLQUFLLE9BQU8sQ0FBQztFQUNoYyxNQUFNNEMsUUFBUSxHQUFHVixVQUFVLENBQUNDLE1BQU0sQ0FBQ1EsU0FBUyxJQUFJQSxTQUFTLENBQUNGLFVBQVUsQ0FBQ3pDLEtBQUssS0FBSyxNQUFNLENBQUM7RUFDdEYsTUFBTTZDLE1BQU0sR0FBRyxJQUFJMUIsR0FBRyxDQUFDeUIsUUFBUSxDQUFDTCxHQUFHLENBQUNJLFNBQVMsSUFBSUEsU0FBUyxDQUFDRCxRQUFRLEdBQUcsT0FBT0MsU0FBUyxDQUFDRCxRQUFRLEVBQUUsR0FBR0ksSUFBSSxDQUFDQyxTQUFTLENBQUNKLFNBQVMsQ0FBQ0gsU0FBUyxDQUFDSCxJQUFJLENBQUNyQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQ3BKLE9BQU87SUFBRWtDLFVBQVU7SUFBRVUsUUFBUTtJQUFFSSxNQUFNLEVBQUUsQ0FBQ2QsVUFBVSxDQUFDZSxNQUFNLEdBQUcsU0FBUyxHQUFHSixNQUFNLENBQUNLLElBQUksR0FBRyxDQUFDLEdBQUcsVUFBVSxHQUFHaEIsVUFBVSxDQUFDdEMsSUFBSSxDQUFDK0MsU0FBUyxJQUFJQSxTQUFTLENBQUNGLFVBQVUsQ0FBQ3pDLEtBQUssS0FBSyxTQUFTLENBQUMsR0FBRyxVQUFVLEdBQUcsT0FBTztJQUFFLElBQUksQ0FBQ2tDLFVBQVUsQ0FBQ2UsTUFBTSxHQUFHO01BQUVwQixNQUFNLEVBQUU7SUFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUFFLENBQUM7QUFDNVE7QUFDQTtBQUNBLE9BQU8sU0FBU3NCLG9CQUFvQkEsQ0FBQ0MsT0FBeUMsRUFBRUMsU0FBYSxFQUFFQyxTQUFpQixFQUFFdkQsS0FBaUIsR0FBRyxDQUFDLENBQUMsRUFBRWtDLFFBQWEsRUFBb0I7RUFDekssT0FBT0YscUJBQXFCLENBQUNxQixPQUFPLENBQUNHLFFBQVEsQ0FBQ3BCLE1BQU0sQ0FBRUMsTUFBTSxJQUFvQ0EsTUFBTSxDQUFDb0IsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDcEIsTUFBTSxDQUFDcUIsU0FBUyxJQUFJckIsTUFBTSxDQUFDQyxJQUFJLENBQUNnQixTQUFTLEtBQUtBLFNBQVMsSUFBSWpCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDaUIsU0FBUyxLQUFLQSxTQUFTLENBQUMsRUFBRXZELEtBQUssRUFBRWtDLFFBQVEsQ0FBQztBQUNuUDtBQUNBO0FBQ0EsT0FBTyxTQUFTeUIscUJBQXFCQSxDQUFDTixPQUF5QyxFQUFFckQsS0FBaUIsR0FBRyxDQUFDLENBQUMsRUFBRTtFQUN2RyxNQUFNeUIsS0FBSyxHQUFHLElBQUltQyxHQUFHLENBQWdDLENBQUM7SUFBRUMsS0FBSyxHQUFHLElBQUlELEdBQUcsQ0FBMkIsQ0FBQztFQUNuRyxLQUFLLE1BQU12QixNQUFNLElBQUlnQixPQUFPLENBQUNHLFFBQVEsRUFBRSxJQUFJbkIsTUFBTSxDQUFDb0IsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDcEIsTUFBTSxDQUFDcUIsU0FBUyxFQUFFO0lBQUEsSUFBQUksV0FBQTtJQUFFLE1BQU1DLEdBQUcsR0FBRyxHQUFHMUIsTUFBTSxDQUFDQyxJQUFJLENBQUNnQixTQUFTLElBQUlqQixNQUFNLENBQUNDLElBQUksQ0FBQ2lCLFNBQVMsRUFBRTtNQUFFUyxPQUFPLElBQUFGLFdBQUEsR0FBR3JDLEtBQUssQ0FBQ0csR0FBRyxDQUFDbUMsR0FBRyxDQUFDLGNBQUFELFdBQUEsY0FBQUEsV0FBQSxHQUFJLEVBQUU7SUFBRUUsT0FBTyxDQUFDekQsSUFBSSxDQUFDOEIsTUFBTSxDQUFDO0lBQUVaLEtBQUssQ0FBQ3dDLEdBQUcsQ0FBQ0YsR0FBRyxFQUFFQyxPQUFPLENBQUM7RUFBRTtFQUMvTyxPQUFPO0lBQUVFLGVBQWVBLENBQUNaLFNBQWEsRUFBRUMsU0FBaUIsRUFBRXJCLFFBQWEsRUFBRWlDLGFBQXlCLEdBQUduRSxLQUFLLEVBQW9CO01BQUEsSUFBQW9FLFdBQUE7TUFBRSxNQUFNTCxHQUFHLEdBQUcsR0FBR1QsU0FBUyxJQUFJQyxTQUFTLElBQUlyQixRQUFRLGFBQVJBLFFBQVEsY0FBUkEsUUFBUSxHQUFJLEVBQUUsRUFBRTtRQUFFbUMsUUFBUSxHQUFHRixhQUFhLEtBQUtuRSxLQUFLLEdBQUc2RCxLQUFLLENBQUNqQyxHQUFHLENBQUNtQyxHQUFHLENBQUMsR0FBR3hDLFNBQVM7TUFBRSxJQUFJOEMsUUFBUSxFQUFFLE9BQU9BLFFBQVE7TUFBRSxNQUFNekQsTUFBTSxHQUFHb0IscUJBQXFCLEVBQUFvQyxXQUFBLEdBQUMzQyxLQUFLLENBQUNHLEdBQUcsQ0FBQyxHQUFHMEIsU0FBUyxJQUFJQyxTQUFTLEVBQUUsQ0FBQyxjQUFBYSxXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFLEVBQUVELGFBQWEsRUFBRWpDLFFBQVEsQ0FBQztNQUFFLElBQUlpQyxhQUFhLEtBQUtuRSxLQUFLLEVBQUU2RCxLQUFLLENBQUNJLEdBQUcsQ0FBQ0YsR0FBRyxFQUFFbkQsTUFBTSxDQUFDO01BQUUsT0FBT0EsTUFBTTtJQUFFO0VBQUUsQ0FBQztBQUNsZDtBQUdBO0FBQ0EsT0FBTyxTQUFTMEQsZ0JBQWdCQSxDQUFDakMsTUFBYyxFQUFFckMsS0FBMkQsR0FBRyxDQUFDLENBQUMsRUFBeUI7RUFBQSxJQUFBdUUsb0JBQUE7RUFDeEksSUFBSSxDQUFDdkUsS0FBSyxDQUFDa0MsUUFBUSxJQUFJLENBQUNsQyxLQUFLLENBQUN3RSxVQUFVLEVBQUUsT0FBTztJQUFFM0MsSUFBSSxFQUFFUSxNQUFNLENBQUNSLElBQUk7SUFBRU0sVUFBVSxFQUFFLEVBQUU7SUFBRWMsTUFBTSxFQUFFLE9BQU87SUFBRS9DLE9BQU8sRUFBRTtFQUFHLENBQUM7RUFDcEgsTUFBTXVFLE9BQU8sR0FBRyxTQUFTLElBQUlwQyxNQUFNLENBQUNDLElBQUksSUFBQWlDLG9CQUFBLEdBQUdsQyxNQUFNLENBQUNDLElBQUksQ0FBQ21DLE9BQU8sY0FBQUYsb0JBQUEsY0FBQUEsb0JBQUEsR0FBSSxFQUFFLEdBQUcsRUFBRTtFQUN6RSxNQUFNRyxPQUFPLEdBQUdELE9BQU8sQ0FBQ3JDLE1BQU0sQ0FBQ3VDLEtBQUssSUFBSTNFLEtBQUssQ0FBQ3dFLFVBQVUsR0FBR0csS0FBSyxDQUFDQyxlQUFlLElBQUlELEtBQUssQ0FBQ0UsaUJBQWlCLENBQUMzQixNQUFNLEtBQUssQ0FBQyxHQUFHeUIsS0FBSyxDQUFDQyxlQUFlLElBQUlELEtBQUssQ0FBQ0UsaUJBQWlCLENBQUMzQixNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQ2xELEtBQUssQ0FBQ2tDLFFBQVEsSUFBSXlDLEtBQUssQ0FBQ0UsaUJBQWlCLENBQUN0RixRQUFRLENBQUNTLEtBQUssQ0FBQ2tDLFFBQVEsQ0FBQyxDQUFDO0VBQ2pRLE1BQU00QyxNQUFNLEdBQUdKLE9BQU8sQ0FBQ3RDLE1BQU0sQ0FBQ3VDLEtBQUssSUFBSTdFLG1CQUFtQixDQUFDNkUsS0FBSyxDQUFDNUUsUUFBUSxFQUFFQyxLQUFLLENBQUMsQ0FBQ0MsS0FBSyxLQUFLLE1BQU0sQ0FBQztFQUNuRyxNQUFNOEUsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJM0QsR0FBRyxDQUFDMEQsTUFBTSxDQUFDdEMsR0FBRyxDQUFDbUMsS0FBSyxJQUFJQSxLQUFLLENBQUNLLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDM0QsT0FBT0QsS0FBSyxDQUFDN0IsTUFBTSxLQUFLLENBQUMsR0FBRztJQUFFckIsSUFBSSxFQUFFa0QsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUFFNUMsVUFBVSxFQUFFMkMsTUFBTTtJQUFFN0IsTUFBTSxFQUFFLE9BQU87SUFBRS9DLE9BQU8sRUFBRTtFQUFHLENBQUMsR0FBRzZFLEtBQUssQ0FBQzdCLE1BQU0sR0FBRyxDQUFDLEdBQUc7SUFBRXJCLElBQUksRUFBRSxjQUFjO0lBQUVNLFVBQVUsRUFBRTJDLE1BQU07SUFBRTdCLE1BQU0sRUFBRSxVQUFVO0lBQUUvQyxPQUFPLEVBQUUsQ0FBQyx1QkFBdUI7RUFBRSxDQUFDLEdBQUc7SUFBRTJCLElBQUksRUFBRSxRQUFRO0lBQUVNLFVBQVUsRUFBRSxFQUFFO0lBQUVjLE1BQU0sRUFBRSxTQUFTO0lBQUUvQyxPQUFPLEVBQUUsQ0FBQyxxQkFBcUI7RUFBRSxDQUFDO0FBQ3RUO0FBQ0E7QUFDQSxPQUFPLFNBQVMrRSxvQkFBb0JBLENBQUNDLE9BQXFDLEVBQUV2QyxRQUFZLEVBQUV3QyxPQUFXLEVBQWdDO0VBQ25JLE1BQU1DLE9BQU8sR0FBR0YsT0FBTyxDQUFDNUMsSUFBSSxDQUFDK0MsVUFBVTtFQUN2QyxNQUFNQyxNQUFxQixHQUFHLE1BQU0sSUFBSUYsT0FBTyxHQUFHO0lBQUVHLGFBQWEsRUFBRUgsT0FBTztJQUFFSSxVQUFVLEVBQUUsQ0FBQztFQUFFLENBQUMsR0FBRztJQUFFLEdBQUdKLE9BQU87SUFBRUksVUFBVSxFQUFFO01BQUUsR0FBR0osT0FBTyxDQUFDSTtJQUFXO0VBQUUsQ0FBQztFQUNwSixPQUFPO0lBQUUsR0FBR04sT0FBTztJQUFFNUMsSUFBSSxFQUFFO01BQUUsR0FBRzRDLE9BQU8sQ0FBQzVDLElBQUk7TUFBRStDLFVBQVUsRUFBRTtRQUFFLEdBQUdDLE1BQU07UUFBRUUsVUFBVSxFQUFFO1VBQUUsR0FBR0YsTUFBTSxDQUFDRSxVQUFVO1VBQUUsQ0FBQzdDLFFBQVEsR0FBRztZQUFFOEMsSUFBSSxFQUFFLE9BQU87WUFBRU47VUFBUTtRQUFFO01BQUU7SUFBRTtFQUFFLENBQUM7QUFDM0o7QUFFQSxTQUFTTyxTQUFTQSxDQUFDL0QsU0FBeUIsRUFBVTtFQUFFLE9BQU9vQixJQUFJLENBQUNDLFNBQVMsQ0FBQyxDQUFDckIsU0FBUyxDQUFDZ0UsU0FBUyxFQUFFaEUsU0FBUyxDQUFDaUUsbUJBQW1CLEVBQUVqRSxTQUFTLENBQUNrRSxXQUFXLENBQUMsQ0FBQztBQUFFO0FBQzVKLFNBQVNDLG1CQUFtQkEsQ0FBQ0MsTUFBcUIsRUFBZ0M7RUFDaEYsTUFBTXRFLEtBQUssR0FBRyxJQUFJbUMsR0FBRyxDQUEwQixDQUFDO0VBQ2hELEtBQUssTUFBTW9DLEtBQUssSUFBSUQsTUFBTSxFQUFFLEtBQUssTUFBTUUsUUFBUSxJQUFJRCxLQUFLLENBQUNFLFNBQVMsRUFBRSxJQUFJRCxRQUFRLENBQUNFLE9BQU8sQ0FBQ1IsU0FBUyxLQUFLSyxLQUFLLENBQUNMLFNBQVMsRUFBRTtJQUN0SCxNQUFNNUIsR0FBRyxHQUFHMkIsU0FBUyxDQUFDO01BQUVDLFNBQVMsRUFBRUssS0FBSyxDQUFDTCxTQUFTO01BQUVDLG1CQUFtQixFQUFFSyxRQUFRLENBQUNHLEVBQUU7TUFBRVAsV0FBVyxFQUFFSSxRQUFRLENBQUNKO0lBQVksQ0FBQyxDQUFDO0lBQzFILElBQUksQ0FBQ3BFLEtBQUssQ0FBQzRFLEdBQUcsQ0FBQ3RDLEdBQUcsQ0FBQyxFQUFFdEMsS0FBSyxDQUFDd0MsR0FBRyxDQUFDRixHQUFHLEVBQUVrQyxRQUFRLENBQUM7RUFDL0M7RUFDQSxPQUFPeEUsS0FBSztBQUNkO0FBQ0E7QUFDQSxPQUFPLFNBQVM2RSx1QkFBdUJBLENBQUNQLE1BQXFCLEVBQUVwRSxTQUF5QixFQUErQjtFQUNySCxPQUFPbUUsbUJBQW1CLENBQUNDLE1BQU0sQ0FBQyxDQUFDbkUsR0FBRyxDQUFDOEQsU0FBUyxDQUFDL0QsU0FBUyxDQUFDLENBQUM7QUFDOUQ7QUFDQSxTQUFTNEUsYUFBYUEsQ0FBQ0MsVUFBNEIsRUFBRS9FLEtBQW1DLEVBQStEO0VBQ3JKLE1BQU15RSxTQUE0QixHQUFHLEVBQUU7SUFBRU8sT0FBeUIsR0FBRyxFQUFFO0lBQUVDLElBQUksR0FBRyxJQUFJdEYsR0FBRyxDQUFTLENBQUM7SUFBRXVGLEtBQUssR0FBRyxDQUFDLEdBQUdILFVBQVUsQ0FBQztFQUMxSCxLQUFLLElBQUlJLE1BQU0sR0FBRyxDQUFDLEVBQUVBLE1BQU0sR0FBR0QsS0FBSyxDQUFDekQsTUFBTSxFQUFFMEQsTUFBTSxFQUFFLEVBQUU7SUFDcEQsTUFBTWpGLFNBQVMsR0FBR2dGLEtBQUssQ0FBQ0MsTUFBTSxDQUFDO01BQUU3QyxHQUFHLEdBQUcyQixTQUFTLENBQUMvRCxTQUFTLENBQUM7SUFBRSxJQUFJK0UsSUFBSSxDQUFDTCxHQUFHLENBQUN0QyxHQUFHLENBQUMsRUFBRTtJQUFVMkMsSUFBSSxDQUFDRyxHQUFHLENBQUM5QyxHQUFHLENBQUM7SUFDdkcsTUFBTWtDLFFBQVEsR0FBR3hFLEtBQUssQ0FBQ0csR0FBRyxDQUFDbUMsR0FBRyxDQUFDO0lBQUUsSUFBSSxDQUFDa0MsUUFBUSxFQUFFO01BQUVRLE9BQU8sQ0FBQ2xHLElBQUksQ0FBQ29CLFNBQVMsQ0FBQztNQUFFO0lBQVU7SUFDckZ1RSxTQUFTLENBQUMzRixJQUFJLENBQUMwRixRQUFRLENBQUM7SUFBRVUsS0FBSyxDQUFDcEcsSUFBSSxDQUFDLEdBQUcwRixRQUFRLENBQUNFLE9BQU8sQ0FBQ1csZUFBZSxDQUFDO0VBQzNFO0VBQ0EsT0FBTztJQUFFWixTQUFTO0lBQUVPO0VBQVEsQ0FBQztBQUMvQjtBQUNBLFNBQVNNLGtCQUFrQkEsQ0FBQzFELE9BQXVCLEVBQUU2QyxTQUE0QixFQUFrQjtFQUNqRyxNQUFNMUMsUUFBUSxHQUFHLENBQUMsR0FBR0gsT0FBTyxDQUFDRyxRQUFRLENBQUM7SUFBRXdELFNBQVMsR0FBRyxDQUFDLEdBQUczRCxPQUFPLENBQUMyRCxTQUFTLENBQUM7SUFBRUMsU0FBUyxHQUFHLENBQUMsR0FBRzVELE9BQU8sQ0FBQzRELFNBQVMsQ0FBQztFQUM5RyxNQUFNQyxZQUFZLEdBQUcsSUFBSTlGLEdBQUcsQ0FBQ29DLFFBQVEsQ0FBQ2hCLEdBQUcsQ0FBQ0gsTUFBTSxJQUFJQSxNQUFNLENBQUMrRCxFQUFFLENBQUMsQ0FBQztJQUFFZSxhQUFhLEdBQUcsSUFBSS9GLEdBQUcsQ0FBQzRGLFNBQVMsQ0FBQ3hFLEdBQUcsQ0FBQzRFLFFBQVEsSUFBSUEsUUFBUSxDQUFDaEIsRUFBRSxDQUFDLENBQUM7SUFBRWlCLGFBQWEsR0FBRyxJQUFJakcsR0FBRyxDQUFDNkYsU0FBUyxDQUFDekUsR0FBRyxDQUFDOEUsUUFBUSxJQUFJQSxRQUFRLENBQUNsQixFQUFFLENBQUMsQ0FBQztFQUNqTSxLQUFLLE1BQU1ILFFBQVEsSUFBSUMsU0FBUyxFQUFFO0lBQ2hDLEtBQUssTUFBTTdELE1BQU0sSUFBSTRELFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0MsUUFBUSxFQUFFLElBQUksQ0FBQzBELFlBQVksQ0FBQ2IsR0FBRyxDQUFDaEUsTUFBTSxDQUFDK0QsRUFBRSxDQUFDLEVBQUU7TUFBRTVDLFFBQVEsQ0FBQ2pELElBQUksQ0FBQzhCLE1BQU0sQ0FBQztNQUFFNkUsWUFBWSxDQUFDTCxHQUFHLENBQUN4RSxNQUFNLENBQUMrRCxFQUFFLENBQUM7SUFBRTtJQUN4SSxLQUFLLE1BQU1nQixRQUFRLElBQUluQixRQUFRLENBQUNFLE9BQU8sQ0FBQ2EsU0FBUyxFQUFFLElBQUksQ0FBQ0csYUFBYSxDQUFDZCxHQUFHLENBQUNlLFFBQVEsQ0FBQ2hCLEVBQUUsQ0FBQyxFQUFFO01BQUVZLFNBQVMsQ0FBQ3pHLElBQUksQ0FBQzZHLFFBQVEsQ0FBQztNQUFFRCxhQUFhLENBQUNOLEdBQUcsQ0FBQ08sUUFBUSxDQUFDaEIsRUFBRSxDQUFDO0lBQUU7SUFDcEosS0FBSyxNQUFNa0IsUUFBUSxJQUFJckIsUUFBUSxDQUFDRSxPQUFPLENBQUNjLFNBQVMsRUFBRSxJQUFJLENBQUNJLGFBQWEsQ0FBQ2hCLEdBQUcsQ0FBQ2lCLFFBQVEsQ0FBQ2xCLEVBQUUsQ0FBQyxFQUFFO01BQUVhLFNBQVMsQ0FBQzFHLElBQUksQ0FBQytHLFFBQVEsQ0FBQztNQUFFRCxhQUFhLENBQUNSLEdBQUcsQ0FBQ1MsUUFBUSxDQUFDbEIsRUFBRSxDQUFDO0lBQUU7RUFDdEo7RUFDQSxPQUFPO0lBQUUsR0FBRy9DLE9BQU87SUFBRUcsUUFBUTtJQUFFd0QsU0FBUztJQUFFQztFQUFVLENBQUM7QUFDdkQ7QUFDQTtBQUNBLE9BQU8sU0FBU00scUJBQXFCQSxDQUFDbEUsT0FBb0IsRUFBRTBDLE1BQXFCLEVBQWtCO0VBQ2pHLE1BQU07SUFBRXlCLE9BQU8sRUFBRUMsUUFBUTtJQUFFdkIsU0FBUyxFQUFFd0IsVUFBVTtJQUFFQyxrQkFBa0IsRUFBRUMsbUJBQW1CO0lBQUUsR0FBR3pCO0VBQVEsQ0FBQyxHQUFHOUMsT0FBTztFQUNqSCxPQUFPMEQsa0JBQWtCLENBQUNaLE9BQU8sRUFBRUksYUFBYSxDQUFDbEQsT0FBTyxDQUFDeUQsZUFBZSxFQUFFaEIsbUJBQW1CLENBQUNDLE1BQU0sQ0FBQyxDQUFDLENBQUNHLFNBQVMsQ0FBQztBQUNuSDtBQUlBLE9BQU8sZUFBZTJCLG1CQUFtQkEsQ0FBQ3hFLE9BQW9CLEVBQUUyQyxLQUFrQixFQUFFOEIsVUFBYyxFQUFFQyxVQUFnQixHQUFHLEVBQUUsRUFBRWhDLE1BQXFCLEdBQUcsRUFBRSxFQUFnQztFQUFBLElBQUFpQyxxQkFBQSxFQUFBQyxnQkFBQTtFQUNuTCxJQUFJakMsS0FBSyxDQUFDTCxTQUFTLEtBQUt0QyxPQUFPLENBQUNzQyxTQUFTLEVBQUUsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLHNCQUFzQixDQUFDO0VBQ2xGLE1BQU1tSCxPQUFPLEdBQUcsQ0FBQ2xDLEtBQUssRUFBRSxHQUFHRCxNQUFNLENBQUM7SUFBRXRFLEtBQUssR0FBR3FFLG1CQUFtQixDQUFDb0MsT0FBTyxDQUFDO0lBQUVDLElBQUksR0FBR0QsT0FBTyxDQUFDOUYsTUFBTSxDQUFDZ0csTUFBTSxJQUFJQSxNQUFNLENBQUN6QyxTQUFTLEtBQUtLLEtBQUssQ0FBQ0wsU0FBUyxDQUFDLENBQUMwQyxPQUFPLENBQUNELE1BQU0sSUFBSUEsTUFBTSxDQUFDbEMsU0FBUyxDQUFDLENBQUNvQyxJQUFJLENBQUNyQyxRQUFRLElBQUlBLFFBQVEsQ0FBQ0csRUFBRSxLQUFLMEIsVUFBVSxDQUFDO0VBQ2hPLElBQUksQ0FBQ0ssSUFBSSxJQUFJQSxJQUFJLENBQUNoQyxPQUFPLENBQUNSLFNBQVMsS0FBS0ssS0FBSyxDQUFDTCxTQUFTLElBQUksT0FBTXpILE1BQU0sQ0FBQ0QsU0FBUyxDQUFDa0ssSUFBSSxDQUFDaEMsT0FBTyxDQUFDLENBQUMsTUFBS2dDLElBQUksQ0FBQ3RDLFdBQVcsRUFBRSxNQUFNLElBQUk5RSxLQUFLLENBQUMsa0NBQWtDLENBQUM7RUFDMUssTUFBTXFFLE9BQU8sR0FBRy9CLE9BQU8sQ0FBQ3lELGVBQWUsQ0FBQ3dCLElBQUksQ0FBQzNHLFNBQVMsSUFBSUEsU0FBUyxDQUFDZ0UsU0FBUyxLQUFLSyxLQUFLLENBQUNMLFNBQVMsQ0FBQztJQUFFdEIsUUFBUSxHQUFHZSxPQUFPLEdBQUczRCxLQUFLLENBQUNHLEdBQUcsQ0FBQzhELFNBQVMsQ0FBQ04sT0FBTyxDQUFDLENBQUMsR0FBRzdELFNBQVM7RUFDbEssSUFBSTZELE9BQU8sSUFBSSxDQUFDZixRQUFRLEVBQUUsTUFBTSxJQUFJdEQsS0FBSyxDQUFDLDhDQUE4QyxDQUFDO0VBQ3pGLElBQUlzRCxRQUFRLElBQUksT0FBTW5HLE1BQU0sQ0FBQ0QsU0FBUyxDQUFDb0csUUFBUSxDQUFDOEIsT0FBTyxDQUFDLENBQUMsTUFBSzlCLFFBQVEsQ0FBQ3dCLFdBQVcsRUFBRSxNQUFNLElBQUk5RSxLQUFLLENBQUMsaUNBQWlDLENBQUM7RUFDdEksTUFBTXdILGVBQWUsR0FBR2hDLGFBQWEsRUFBQXlCLHFCQUFBLEdBQUMzRCxRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRThCLE9BQU8sQ0FBQ1csZUFBZSxjQUFBa0IscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLEVBQUV2RyxLQUFLLENBQUM7SUFBRStHLFdBQVcsR0FBR2pDLGFBQWEsQ0FBQzRCLElBQUksQ0FBQ2hDLE9BQU8sQ0FBQ1csZUFBZSxFQUFFckYsS0FBSyxDQUFDO0VBQ3ZKLElBQUk4RyxlQUFlLENBQUM5QixPQUFPLENBQUN2RCxNQUFNLElBQUlzRixXQUFXLENBQUMvQixPQUFPLENBQUN2RCxNQUFNLEVBQUUsTUFBTSxJQUFJbkMsS0FBSyxDQUFDLHdEQUF3RCxDQUFDO0VBQzNJLEtBQUssTUFBTWtGLFFBQVEsSUFBSSxDQUFDLEdBQUdzQyxlQUFlLENBQUNyQyxTQUFTLEVBQUUsR0FBR3NDLFdBQVcsQ0FBQ3RDLFNBQVMsQ0FBQyxFQUFFLElBQUksT0FBTWhJLE1BQU0sQ0FBQ0QsU0FBUyxDQUFDZ0ksUUFBUSxDQUFDRSxPQUFPLENBQUMsQ0FBQyxNQUFLRixRQUFRLENBQUNKLFdBQVcsRUFBRSxNQUFNLElBQUk5RSxLQUFLLENBQUMsMkJBQTJCLENBQUM7RUFDck0sTUFBTTBILG1CQUFtQixHQUFHLElBQUk3RSxHQUFHLENBQUNQLE9BQU8sQ0FBQzRELFNBQVMsQ0FBQ3pFLEdBQUcsQ0FBQzhFLFFBQVEsSUFBSSxDQUFDQSxRQUFRLENBQUNsQixFQUFFLEVBQUVrQixRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQy9GLEtBQUssTUFBTXJCLFFBQVEsSUFBSSxDQUFDa0MsSUFBSSxFQUFFLEdBQUdLLFdBQVcsQ0FBQ3RDLFNBQVMsQ0FBQyxFQUFFLEtBQUssTUFBTW9CLFFBQVEsSUFBSXJCLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDYyxTQUFTLEVBQUU7SUFBRSxNQUFNeUIsUUFBUSxHQUFHRCxtQkFBbUIsQ0FBQzdHLEdBQUcsQ0FBQzBGLFFBQVEsQ0FBQ2xCLEVBQUUsQ0FBQztJQUFFLElBQUlzQyxRQUFRLElBQUksQ0FBQzNLLHNCQUFzQixDQUFDMkssUUFBUSxFQUFFcEIsUUFBUSxDQUFDLEVBQUUsTUFBTSxJQUFJdkcsS0FBSyxDQUFDLFNBQVN1RyxRQUFRLENBQUNsQixFQUFFLHVDQUF1QyxDQUFDO0lBQUVxQyxtQkFBbUIsQ0FBQ3hFLEdBQUcsQ0FBQ3FELFFBQVEsQ0FBQ2xCLEVBQUUsRUFBRWtCLFFBQVEsQ0FBQztFQUFFO0VBQ2hXLE1BQU1xQixhQUFhLEdBQUd0RSxRQUFRLEdBQUcwQyxrQkFBa0IsQ0FBQzFDLFFBQVEsQ0FBQzhCLE9BQU8sRUFBRW9DLGVBQWUsQ0FBQ3JDLFNBQVMsQ0FBQyxHQUFHM0UsU0FBUztJQUFFcUgsWUFBWSxHQUFHN0Isa0JBQWtCLENBQUNvQixJQUFJLENBQUNoQyxPQUFPLEVBQUVxQyxXQUFXLENBQUN0QyxTQUFTLENBQUM7RUFDcEwsTUFBTTJDLFVBQVUsR0FBSTNDLFNBQTRCLElBQUs7SUFBRSxNQUFNNEMsUUFBUSxHQUFHLElBQUlsRixHQUFHLENBQWEsQ0FBQztJQUFFLEtBQUssTUFBTXFDLFFBQVEsSUFBSUMsU0FBUyxFQUFFLEtBQUssTUFBTSxDQUFDekMsSUFBSSxFQUFFc0YsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRTlDLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0MsUUFBUSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUV5QyxRQUFRLENBQUNFLE9BQU8sQ0FBQ2EsU0FBUyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUVmLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDYyxTQUFTLENBQUMsQ0FBQyxFQUFXLEtBQUssTUFBTStCLE1BQU0sSUFBSUQsT0FBTyxFQUFFLElBQUksQ0FBQ0QsUUFBUSxDQUFDekMsR0FBRyxDQUFDLEdBQUc1QyxJQUFJLElBQUl1RixNQUFNLENBQUM1QyxFQUFFLEVBQUUsQ0FBQyxFQUFFMEMsUUFBUSxDQUFDN0UsR0FBRyxDQUFDLEdBQUdSLElBQUksSUFBSXVGLE1BQU0sQ0FBQzVDLEVBQUUsRUFBRSxFQUFFSCxRQUFRLENBQUNHLEVBQUUsQ0FBQztJQUFFLE9BQU8wQyxRQUFRO0VBQUUsQ0FBQztFQUNuYixNQUFNRyxjQUFjLEdBQUdKLFVBQVUsQ0FBQ3hFLFFBQVEsR0FBRyxDQUFDQSxRQUFRLEVBQUUsR0FBR2tFLGVBQWUsQ0FBQ3JDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUFFZ0QsYUFBYSxHQUFHTCxVQUFVLENBQUMsQ0FBQ1YsSUFBSSxFQUFFLEdBQUdLLFdBQVcsQ0FBQ3RDLFNBQVMsQ0FBQyxDQUFDO0VBQ3pKLE1BQU1pRCxXQUFxQyxHQUFHLEVBQUU7RUFDaEQsS0FBSyxNQUFNLENBQUMxRixJQUFJLEVBQUUyRixNQUFNLEVBQUVDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEdBQUFDLHFCQUFBLEdBQUVYLGFBQWEsYUFBYkEsYUFBYSx1QkFBYkEsYUFBYSxDQUFFbkYsUUFBUSxjQUFBOEYscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLEVBQUVWLFlBQVksQ0FBQ3BGLFFBQVEsQ0FBQyxFQUFFLENBQUMsVUFBVSxHQUFBK0YscUJBQUEsR0FBRVosYUFBYSxhQUFiQSxhQUFhLHVCQUFiQSxhQUFhLENBQUUzQixTQUFTLGNBQUF1QyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUUsRUFBRVgsWUFBWSxDQUFDNUIsU0FBUyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEdBQUF3QyxxQkFBQSxHQUFFYixhQUFhLGFBQWJBLGFBQWEsdUJBQWJBLGFBQWEsQ0FBRTFCLFNBQVMsY0FBQXVDLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFWixZQUFZLENBQUMzQixTQUFTLENBQUMsQ0FBQyxFQUFXO0lBQUEsSUFBQXFDLHFCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLHFCQUFBO0lBQzNQLE1BQU1DLENBQUMsR0FBRyxJQUFJN0YsR0FBRyxDQUFrQndGLE1BQU0sQ0FBQ2hILE1BQU0sQ0FBQ25DLEtBQUssSUFBSSxFQUFFLFdBQVcsSUFBSUEsS0FBSyxDQUFDLElBQUksQ0FBQ0EsS0FBSyxDQUFDeUQsU0FBUyxDQUFDLENBQUNsQixHQUFHLENBQUN2QyxLQUFLLElBQUksQ0FBQ0EsS0FBSyxDQUFDbUcsRUFBRSxFQUFFbkcsS0FBSyxDQUFDLENBQUMsQ0FBQztNQUFFeUosQ0FBQyxHQUFHLElBQUk5RixHQUFHLENBQWtCeUYsS0FBSyxDQUFDakgsTUFBTSxDQUFDbkMsS0FBSyxJQUFJLEVBQUUsV0FBVyxJQUFJQSxLQUFLLENBQUMsSUFBSSxDQUFDQSxLQUFLLENBQUN5RCxTQUFTLENBQUMsQ0FBQ2xCLEdBQUcsQ0FBQ3ZDLEtBQUssSUFBSSxDQUFDQSxLQUFLLENBQUNtRyxFQUFFLEVBQUVuRyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3pRLEtBQUssTUFBTSxDQUFDbUcsRUFBRSxFQUFFbkcsS0FBSyxDQUFDLElBQUl5SixDQUFDLEVBQUUsSUFBSSxDQUFDRCxDQUFDLENBQUNwRCxHQUFHLENBQUNELEVBQUUsQ0FBQyxJQUFJLENBQUNwSSxTQUFTLENBQUN5TCxDQUFDLENBQUM3SCxHQUFHLENBQUN3RSxFQUFFLENBQUMsRUFBRW5HLEtBQUssQ0FBQyxFQUFFa0osV0FBVyxDQUFDNUksSUFBSSxDQUFDO01BQUU2RixFQUFFO01BQUUzQyxJQUFJO01BQUVrRyxNQUFNLEVBQUVGLENBQUMsQ0FBQ3BELEdBQUcsQ0FBQ0QsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFHLE9BQU87TUFBRWdELE1BQU0sRUFBRUssQ0FBQyxDQUFDN0gsR0FBRyxDQUFDd0UsRUFBRSxDQUFDO01BQUVpRCxLQUFLLEVBQUVwSixLQUFLO01BQUUySixnQkFBZ0IsRUFBRVgsY0FBYyxDQUFDckgsR0FBRyxDQUFDLEdBQUc2QixJQUFJLElBQUkyQyxFQUFFLEVBQUUsQ0FBQztNQUFFeUQsZUFBZSxFQUFFWCxhQUFhLENBQUN0SCxHQUFHLENBQUMsR0FBRzZCLElBQUksSUFBSTJDLEVBQUUsRUFBRTtJQUFFLENBQUMsQ0FBQztJQUNqUyxLQUFLLE1BQU0sQ0FBQ0EsRUFBRSxFQUFFbkcsS0FBSyxDQUFDLElBQUl3SixDQUFDLEVBQUUsSUFBSSxDQUFDQyxDQUFDLENBQUNyRCxHQUFHLENBQUNELEVBQUUsQ0FBQyxFQUFFK0MsV0FBVyxDQUFDNUksSUFBSSxDQUFDO01BQUU2RixFQUFFO01BQUUzQyxJQUFJO01BQUVrRyxNQUFNLEVBQUUsU0FBUztNQUFFUCxNQUFNLEVBQUVuSixLQUFLO01BQUUySixnQkFBZ0IsRUFBRVgsY0FBYyxDQUFDckgsR0FBRyxDQUFDLEdBQUc2QixJQUFJLElBQUkyQyxFQUFFLEVBQUU7SUFBRSxDQUFDLENBQUM7RUFDdEs7RUFDQSxNQUFNMEQsT0FBTyxHQUFHLElBQUkxSSxHQUFHLENBQUMrSCxXQUFXLENBQUMzRyxHQUFHLENBQUN1SCxVQUFVLElBQUlBLFVBQVUsQ0FBQzNELEVBQUUsQ0FBQyxDQUFDO0lBQUU0RCxPQUFPLEdBQUcsSUFBSTVJLEdBQUcsQ0FBQytILFdBQVcsQ0FBQy9HLE1BQU0sQ0FBQzJILFVBQVUsSUFBSUEsVUFBVSxDQUFDSixNQUFNLEtBQUssU0FBUyxDQUFDLENBQUNuSCxHQUFHLENBQUN1SCxVQUFVLElBQUlBLFVBQVUsQ0FBQzNELEVBQUUsQ0FBQyxDQUFDO0lBQUU2RCxXQUFXLEdBQUcsSUFBSTdJLEdBQUcsQ0FBSyxDQUFDO0lBQUU4SSxNQUFNLEdBQUcsSUFBSTlJLEdBQUcsQ0FBSyxDQUFDO0VBQ2pQLEtBQUssTUFBTWlCLE1BQU0sSUFBSWdCLE9BQU8sQ0FBQ0csUUFBUSxFQUFFLElBQUksQ0FBQ25CLE1BQU0sQ0FBQ3FCLFNBQVMsRUFBRSxLQUFLLE1BQU0vQixTQUFTLElBQUl0RSxpQkFBaUIsQ0FBQ2dGLE1BQU0sQ0FBQyxFQUFFO0lBQy9HLElBQUkzRSx5QkFBeUIsQ0FBQzJFLE1BQU0sRUFBRVYsU0FBUyxDQUFDLEVBQUU7SUFDbEQsSUFBSW1JLE9BQU8sQ0FBQ3pELEdBQUcsQ0FBQzFFLFNBQVMsQ0FBQ3lFLEVBQUUsQ0FBQyxFQUFFNkQsV0FBVyxDQUFDcEQsR0FBRyxDQUFDeEUsTUFBTSxDQUFDK0QsRUFBRSxDQUFDO0lBQ3pELElBQUk0RCxPQUFPLENBQUMzRCxHQUFHLENBQUMxRSxTQUFTLENBQUN5RSxFQUFFLENBQUMsRUFBRThELE1BQU0sQ0FBQ3JELEdBQUcsQ0FBQ3hFLE1BQU0sQ0FBQytELEVBQUUsQ0FBQztFQUN0RDtFQUNBLEtBQUssTUFBTWdCLFFBQVEsSUFBSS9ELE9BQU8sQ0FBQzJELFNBQVMsRUFBRSxJQUFJLENBQUNJLFFBQVEsQ0FBQzFELFNBQVMsRUFBRSxLQUFLLE1BQU0vQixTQUFTLElBQUlyRSx5QkFBeUIsQ0FBQzhKLFFBQVEsQ0FBQyxFQUFFO0lBQUUsSUFBSTFKLHlCQUF5QixDQUFDMEosUUFBUSxFQUFFekYsU0FBUyxDQUFDLEVBQUU7SUFBVSxJQUFJbUksT0FBTyxDQUFDekQsR0FBRyxDQUFDMUUsU0FBUyxDQUFDeUUsRUFBRSxDQUFDLEVBQUU2RCxXQUFXLENBQUNwRCxHQUFHLENBQUNPLFFBQVEsQ0FBQ2hCLEVBQUUsQ0FBQztJQUFFLElBQUk0RCxPQUFPLENBQUMzRCxHQUFHLENBQUMxRSxTQUFTLENBQUN5RSxFQUFFLENBQUMsRUFBRThELE1BQU0sQ0FBQ3JELEdBQUcsQ0FBQ08sUUFBUSxDQUFDaEIsRUFBRSxDQUFDO0VBQUU7RUFDclQsTUFBTStELEdBQUcsR0FBRyxJQUFJL0ksR0FBRyxDQUFDK0csSUFBSSxDQUFDaEMsT0FBTyxDQUFDM0MsUUFBUSxDQUFDcEIsTUFBTSxDQUFDQyxNQUFNLElBQUksQ0FBQ0EsTUFBTSxDQUFDcUIsU0FBUyxDQUFDLENBQUNsQixHQUFHLENBQUNILE1BQU0sSUFBSUEsTUFBTSxDQUFDK0QsRUFBRSxDQUFDLENBQUM7RUFDdkcsSUFBSTJCLFVBQVUsQ0FBQ2xJLElBQUksQ0FBQ3VHLEVBQUUsSUFBSSxDQUFDK0QsR0FBRyxDQUFDOUQsR0FBRyxDQUFDRCxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sSUFBSXJGLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQztFQUN2RixNQUFNWSxTQUF5QixHQUFHO0lBQUVnRSxTQUFTLEVBQUVLLEtBQUssQ0FBQ0wsU0FBUztJQUFFQyxtQkFBbUIsRUFBRXVDLElBQUksQ0FBQy9CLEVBQUU7SUFBRVAsV0FBVyxFQUFFc0MsSUFBSSxDQUFDdEM7RUFBWSxDQUFDO0VBQzdILE1BQU11RSxPQUFPLEdBQUcsa0JBQWtCcEUsS0FBSyxDQUFDTCxTQUFTLEVBQUU7SUFBRTBFLFlBQVksR0FBR2hILE9BQU8sQ0FBQ2lILEtBQUssQ0FBQ2hDLElBQUksQ0FBQ2lDLElBQUksSUFBSUEsSUFBSSxDQUFDQSxJQUFJLEtBQUtILE9BQU8sQ0FBQztFQUNySCxNQUFNSSxRQUFRLEdBQUc7SUFBRXBFLEVBQUUsR0FBQTZCLGdCQUFBLEdBQUVvQyxZQUFZLGFBQVpBLFlBQVksdUJBQVpBLFlBQVksQ0FBRWpFLEVBQUUsY0FBQTZCLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUl4SyxLQUFLLENBQUMsQ0FBQztJQUFFb0UsSUFBSSxFQUFFLEdBQUdtRSxLQUFLLENBQUNuRSxJQUFJLE9BQU87SUFBRTBJLElBQUksRUFBRUgsT0FBTztJQUFFSyxTQUFTLEVBQUUsQ0FBQyxHQUFHLElBQUlySixHQUFHLENBQUMyRyxVQUFVLENBQUMsQ0FBQztJQUFFMkMsUUFBUSxFQUFFO01BQUVDLGNBQWMsRUFBRTNFLEtBQUssQ0FBQ0wsU0FBUztNQUFFbUMsVUFBVSxFQUFFSyxJQUFJLENBQUMvQjtJQUFHO0VBQUUsQ0FBQztFQUN4TSxNQUFNeEQsU0FBUyxHQUFHO0lBQUUsR0FBR1MsT0FBTztJQUFFeUQsZUFBZSxFQUFFLENBQUMsR0FBR3pELE9BQU8sQ0FBQ3lELGVBQWUsQ0FBQzFFLE1BQU0sQ0FBQ3dJLElBQUksSUFBSUEsSUFBSSxDQUFDakYsU0FBUyxLQUFLSyxLQUFLLENBQUNMLFNBQVMsQ0FBQyxFQUFFaEUsU0FBUyxDQUFDO0lBQUUySSxLQUFLLEVBQUVELFlBQVksR0FBR2hILE9BQU8sQ0FBQ2lILEtBQUssQ0FBQzlILEdBQUcsQ0FBQytILElBQUksSUFBSUEsSUFBSSxDQUFDbkUsRUFBRSxLQUFLaUUsWUFBWSxDQUFDakUsRUFBRSxHQUFHb0UsUUFBUSxHQUFHRCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUdsSCxPQUFPLENBQUNpSCxLQUFLLEVBQUVFLFFBQVE7RUFBRSxDQUFDO0VBQzVRLEtBQUssTUFBTUQsSUFBSSxJQUFJM0gsU0FBUyxDQUFDMEgsS0FBSyxFQUFFLEtBQUssTUFBTWxFLEVBQUUsSUFBSW1FLElBQUksQ0FBQ0UsU0FBUyxFQUFFO0lBQUUsSUFBSVgsT0FBTyxDQUFDekQsR0FBRyxDQUFDRCxFQUFFLENBQUMsRUFBRTZELFdBQVcsQ0FBQ3BELEdBQUcsQ0FBQzBELElBQUksQ0FBQ25FLEVBQUUsQ0FBQztJQUFFLElBQUk0RCxPQUFPLENBQUMzRCxHQUFHLENBQUNELEVBQUUsQ0FBQyxFQUFFOEQsTUFBTSxDQUFDckQsR0FBRyxDQUFDMEQsSUFBSSxDQUFDbkUsRUFBRSxDQUFDO0VBQUU7RUFDaEssT0FBTztJQUFFeEQsU0FBUztJQUFFakIsU0FBUztJQUFFd0gsV0FBVztJQUFFYyxXQUFXLEVBQUUsQ0FBQyxHQUFHQSxXQUFXLENBQUM7SUFBRVksa0JBQWtCLEVBQUUsQ0FBQyxHQUFHWCxNQUFNLENBQUM7SUFBRVksUUFBUSxFQUFFWixNQUFNLENBQUMvRyxJQUFJLEtBQUs7RUFBRSxDQUFDO0FBQzNJO0FBQ0EsT0FBTyxlQUFlNEgsbUJBQW1CQSxDQUFDMUgsT0FBb0IsRUFBRTJILEtBQWEsRUFBd0I7RUFDbkcsTUFBTTtJQUFFeEQsT0FBTyxFQUFFQyxRQUFRO0lBQUV2QixTQUFTLEVBQUV3QixVQUFVO0lBQUVDLGtCQUFrQixFQUFFQyxtQkFBbUI7SUFBRSxHQUFHekI7RUFBUSxDQUFDLEdBQUc4RSxlQUFlLENBQUM1SCxPQUFPLENBQUM7RUFDbEksTUFBTStDLEVBQUUsR0FBRzNJLEtBQUssQ0FBQyxDQUFDO0lBQUVvSSxXQUFXLEdBQUcsTUFBTTNILE1BQU0sQ0FBQ0QsU0FBUyxDQUFDa0ksT0FBTyxDQUFDLENBQUM7SUFBRStFLFlBQVksR0FBR0YsS0FBSyxDQUFDRyxJQUFJLENBQUMsQ0FBQyxJQUFJLE9BQU85SCxPQUFPLENBQUMrSCxRQUFRLEVBQUU7RUFDNUgsTUFBTW5GLFFBQXlCLEdBQUc7SUFBRUcsRUFBRTtJQUFFUCxXQUFXO0lBQUVxRixZQUFZO0lBQUVHLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztJQUFFcEY7RUFBUSxDQUFDO0VBQ2pILE1BQU1xRixRQUFRLEdBQUc7SUFBRSxHQUFHak8sWUFBWSxDQUFDOEYsT0FBTyxDQUFDc0MsU0FBUyxFQUFFLFVBQVUsRUFBRXVGLFlBQVksRUFBRTtNQUFFQSxZQUFZO01BQUVyRixXQUFXO01BQUU0RixTQUFTLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFBRXJGO0VBQUcsQ0FBQztFQUNySSxPQUFPO0lBQUUsR0FBRy9DLE9BQU87SUFBRTZDLFNBQVMsRUFBRSxDQUFDLEdBQUc3QyxPQUFPLENBQUM2QyxTQUFTLEVBQUVELFFBQVEsQ0FBQztJQUFFekMsUUFBUSxFQUFFLENBQUMsR0FBR0gsT0FBTyxDQUFDRyxRQUFRLEVBQUVnSSxRQUFRO0VBQUUsQ0FBQztBQUMvRzs7QUFFQTtBQUNBLE9BQU8sU0FBU0UsbUJBQW1CQSxDQUFDakMsQ0FBSyxFQUFFQyxDQUFLLEVBQUVqSSxLQUFzQixFQUFXO0VBQ2pGLE1BQU1rSyxRQUFRLEdBQUdBLENBQUNoTSxLQUFTLEVBQUVpTSxNQUFVLEtBQUs7SUFBRSxNQUFNQyxPQUFPLEdBQUcsSUFBSXpLLEdBQUcsQ0FBSyxDQUFDO0lBQUUsSUFBSWdFLE9BQXVCLEdBQUd6RixLQUFLO0lBQUUsT0FBT3lGLE9BQU8sSUFBSSxDQUFDeUcsT0FBTyxDQUFDeEYsR0FBRyxDQUFDakIsT0FBTyxDQUFDLEVBQUU7TUFBQSxJQUFBMEcscUJBQUE7TUFBRSxJQUFJMUcsT0FBTyxLQUFLd0csTUFBTSxFQUFFLE9BQU8sSUFBSTtNQUFFQyxPQUFPLENBQUNoRixHQUFHLENBQUN6QixPQUFPLENBQUM7TUFBRSxNQUFNL0MsTUFBTSxHQUFHWixLQUFLLENBQUNHLEdBQUcsQ0FBQ3dELE9BQU8sQ0FBQztNQUFFQSxPQUFPLEdBQUcsQ0FBQS9DLE1BQU0sYUFBTkEsTUFBTSx1QkFBTkEsTUFBTSxDQUFFb0IsSUFBSSxNQUFLLE9BQU8sSUFBQXFJLHFCQUFBLEdBQUd6SixNQUFNLENBQUNDLElBQUksQ0FBQ3lKLFFBQVEsY0FBQUQscUJBQUEsY0FBQUEscUJBQUEsR0FBSXZLLFNBQVMsR0FBR0EsU0FBUztJQUFFO0lBQUUsT0FBTyxLQUFLO0VBQUUsQ0FBQztFQUNoVyxPQUFPb0ssUUFBUSxDQUFDbEMsQ0FBQyxFQUFFQyxDQUFDLENBQUMsSUFBSWlDLFFBQVEsQ0FBQ2pDLENBQUMsRUFBRUQsQ0FBQyxDQUFDO0FBQ3pDO0FBQ0EsT0FBTyxTQUFTdUMsbUJBQW1CQSxDQUFDdkMsQ0FBOEIsRUFBRUMsQ0FBOEIsRUFBVztFQUMzRyxNQUFNdUMsQ0FBQyxHQUFHeEMsQ0FBQyxhQUFEQSxDQUFDLHVCQUFEQSxDQUFDLENBQUV0SixVQUFVO0lBQUUrTCxDQUFDLEdBQUd4QyxDQUFDLGFBQURBLENBQUMsdUJBQURBLENBQUMsQ0FBRXZKLFVBQVU7RUFDMUMsT0FBTyxFQUFFOEwsQ0FBQyxhQUFEQSxDQUFDLGVBQURBLENBQUMsQ0FBRTVMLEdBQUcsSUFBSTZMLENBQUMsYUFBREEsQ0FBQyxlQUFEQSxDQUFDLENBQUU5TCxLQUFLLElBQUl0QyxTQUFTLENBQUNtTyxDQUFDLENBQUM1TCxHQUFHLENBQUMsSUFBSXZDLFNBQVMsQ0FBQ29PLENBQUMsQ0FBQzlMLEtBQUssQ0FBQyxJQUFJOEwsQ0FBQyxhQUFEQSxDQUFDLGVBQURBLENBQUMsQ0FBRTdMLEdBQUcsSUFBSTRMLENBQUMsYUFBREEsQ0FBQyxlQUFEQSxDQUFDLENBQUU3TCxLQUFLLElBQUl0QyxTQUFTLENBQUNvTyxDQUFDLENBQUM3TCxHQUFHLENBQUMsSUFBSXZDLFNBQVMsQ0FBQ21PLENBQUMsQ0FBQzdMLEtBQUssQ0FBQyxDQUFDO0FBQ3hJIiwiaWdub3JlTGlzdCI6W119