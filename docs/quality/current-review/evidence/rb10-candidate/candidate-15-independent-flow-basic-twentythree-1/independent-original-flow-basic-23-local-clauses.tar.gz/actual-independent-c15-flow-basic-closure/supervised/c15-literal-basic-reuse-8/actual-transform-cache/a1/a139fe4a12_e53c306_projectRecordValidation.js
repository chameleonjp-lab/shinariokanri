// 6931276d7ab9584426ca7f13d4dd47b43c41deb6
import { validateProject, validateCurrentProject } from './model';
import { validateAuthorAlternatives } from './authorAlternativeIntegrity';
import { validateReadingTraceRecord } from './runtimeRecordValidation';
import { captureRuntimeContent } from './runtimeVersions';
import { resolveReuseContent } from './reuse';
import { receiptPatchValue } from './authorAlternativeIntegrity';
import { canonicalJson } from '../storage/json';
import { createPinnedWorldDigestCache, freezePinnedWorldRegistry, verifyPinnedWorlds, resolvePinnedWorlds } from './pinnedWorlds';
function projectFromState(state) {
  return {
    ...state,
    history: []
  };
}
function samePrefix(previous, next) {
  return next.length >= previous.length && previous.every((item, index) => canonicalJson(item) === canonicalJson(next[index]));
}

/** Immutable branch evidence must remain byte-for-byte stable in every retained history image. */
function checkAlternativeHistory(project) {
  var _local$at;
  const issues = [];
  const versionById = new Map(),
    receiptById = new Map();
  const branchIdentityById = new Map();
  const timelines = new Map();
  const timelineFor = key => {
    let timeline = timelines.get(key);
    if (!timeline) {
      timeline = [];
      timelines.set(key, timeline);
    }
    return timeline;
  };
  const local = timelineFor('local');
  const firstLocal = project.history.findIndex(command => !command.importOrigin);
  if (firstLocal >= 0) local.push({
    label: `project.history[${firstLocal}].before`,
    state: project.history[firstLocal].before
  });
  for (const [index, command] of project.history.entries()) {
    const importOrigin = command.importOrigin;
    const key = importOrigin ? `import:${importOrigin.importOperationId}` : 'local';
    const timeline = timelineFor(key);
    if (importOrigin && !timeline.length) timeline.push({
      label: `project.history[${index}].before`,
      state: command.before
    });
    timeline.push({
      label: `project.history[${index}].after`,
      state: command.after
    });
  }
  const current = project;
  if (!local.length || ((_local$at = local.at(-1)) === null || _local$at === void 0 ? void 0 : _local$at.state.revision) !== project.revision) local.push({
    label: 'project',
    state: current
  });
  for (const timeline of timelines.values()) {
    let previousById = new Map();
    for (const {
      label,
      state
    } of timeline) {
      var _state$authorAlternat;
      const currentById = new Map(((_state$authorAlternat = state.authorAlternatives) !== null && _state$authorAlternat !== void 0 ? _state$authorAlternat : []).map(alternative => [alternative.id, alternative]));
      for (const [id, previous] of previousById) {
        const next = currentById.get(id);
        if (!next) {
          issues.push({
            code: 'INTEGRITY_FAILED',
            path: `${label}.authorAlternatives`,
            message: `過去に保存した別案「${id}」が履歴から失われています。`
          });
          continue;
        }
        if (!samePrefix(previous.versions, next.versions)) issues.push({
          code: 'INTEGRITY_FAILED',
          path: `${label}.authorAlternatives.${id}.versions`,
          message: '別案版の履歴は削除・書換えできません。'
        });
        if (!samePrefix(previous.applyReceipts, next.applyReceipts)) issues.push({
          code: 'INTEGRITY_FAILED',
          path: `${label}.authorAlternatives.${id}.applyReceipts`,
          message: '正本採用記録は削除・書換えできません。'
        });
      }
      for (const alternative of currentById.values()) {
        var _alternative$sourceSn;
        const identity = canonicalJson({
          projectId: alternative.projectId,
          baseRevision: alternative.baseRevision,
          sourceSnapshotId: (_alternative$sourceSn = alternative.sourceSnapshotId) !== null && _alternative$sourceSn !== void 0 ? _alternative$sourceSn : null,
          baseContent: alternative.baseContent,
          baseContentHash: alternative.baseContentHash,
          createdAt: alternative.createdAt
        });
        const priorIdentity = branchIdentityById.get(alternative.id);
        if (priorIdentity !== undefined && priorIdentity !== identity) issues.push({
          code: 'INTEGRITY_FAILED',
          path: `${label}.authorAlternatives.${alternative.id}`,
          message: '別案IDが異なる分岐元の内容に再利用されています。'
        });else branchIdentityById.set(alternative.id, identity);
        for (const version of alternative.versions) {
          const old = versionById.get(version.id);
          if (old && canonicalJson(old) !== canonicalJson(version)) issues.push({
            code: 'INTEGRITY_FAILED',
            path: `${label}.authorAlternatives.${alternative.id}.versions.${version.id}`,
            message: '不変の別案版IDが異なる内容へ再利用されています。'
          });else versionById.set(version.id, version);
        }
        for (const receipt of alternative.applyReceipts) {
          const old = receiptById.get(receipt.id);
          if (old && canonicalJson(old) !== canonicalJson(receipt)) issues.push({
            code: 'INTEGRITY_FAILED',
            path: `${label}.authorAlternatives.${alternative.id}.applyReceipts.${receipt.id}`,
            message: '不変の正本採用記録IDが異なる内容へ再利用されています。'
          });else receiptById.set(receipt.id, receipt);
        }
      }
      previousById = currentById;
    }
  }
  return issues;
}
function reservedIds(project) {
  const ids = new Set([project.projectId]);
  for (const item of [...project.entities, ...project.relations]) ids.add(item.id);
  for (const snapshot of project.snapshots) {
    ids.add(snapshot.id);
    for (const entity of project.entities) if (entity.kind === 'snapshot' && entity.id === snapshot.id) ids.add(entity.id);
  }
  for (const command of project.history) ids.add(command.operationId);
  return ids;
}
async function checkAlternatives(project, validationOptions, path, digestCache) {
  var _project$authorAltern;
  const issues = [];
  const snapshots = project.snapshots;
  const branchIssues = await validateAuthorAlternatives(project.projectId, (_project$authorAltern = project.authorAlternatives) !== null && _project$authorAltern !== void 0 ? _project$authorAltern : [], {
    snapshotIds: new Set(snapshots.map(snapshot => snapshot.id)),
    snapshots,
    reservedIds: reservedIds(project),
    validateContent: async content => {
      var _validationOptions$wo;
      const pinIssues = await verifyPinnedWorlds(content, (_validationOptions$wo = validationOptions.worldSnapshots) !== null && _validationOptions$wo !== void 0 ? _validationOptions$wo : {}, `${path}.authorAlternatives.worldReferences`, digestCache);
      const result = validateProject({
        ...content,
        snapshots,
        history: []
      }, validationOptions);
      return result.ok && !pinIssues.length ? {
        ok: true
      } : {
        ok: false,
        issues: [...pinIssues, ...(!result.ok ? result.issues : [])]
      };
    }
  });
  for (const issue of branchIssues) issues.push({
    code: 'INTEGRITY_FAILED',
    path: `${path}.${issue.path}`,
    message: issue.message
  });
  return issues;
}
async function checkChapterTraces(project, validationOptions, digestCache) {
  const issues = [];
  for (const [index, entity] of project.entities.entries()) {
    if (entity.kind !== 'trace') continue;
    const location = `project.entities[${index}].data`;
    const checkpoint = project.entities.find(candidate => candidate.id === entity.data.startCheckpointId && candidate.kind === 'checkpoint');
    if (!checkpoint || checkpoint.kind !== 'checkpoint') {
      issues.push({
        code: 'REFERENCE_INVALID',
        path: `${location}.startCheckpointId`,
        message: '経路の開始状態が見つかりません。'
      });
      continue;
    }
    try {
      const content = await captureRuntimeContent(project, entity.data.contentVersionId, validationOptions, digestCache);
      if (entity.data.mode === 'chapters') issues.push(...validateReadingTraceRecord(content, entity.data, checkpoint.data, location, validationOptions));else {
        var _validationOptions$wo2;
        const {
          replaySavedTrace
        } = await import('./runtime');
        const closure = resolvePinnedWorlds(resolveReuseContent(content, content.snapshots), (_validationOptions$wo2 = validationOptions.worldSnapshots) !== null && _validationOptions$wo2 !== void 0 ? _validationOptions$wo2 : {});
        const replay = replaySavedTrace(project, entity.id, closure.worlds.flatMap(world => world.entities));
        if (replay.status === 'error') issues.push(...replay.issues.map(issue => ({
          ...issue,
          path: `${location}.${issue.path}`
        })));
      }
    } catch (error) {
      const inner = error.issues;
      if (inner !== null && inner !== void 0 && inner.length) issues.push(...inner.map(issue => ({
        ...issue,
        path: `${location}.${issue.path}`
      })));else issues.push({
        code: 'INTEGRITY_FAILED',
        path: `${location}.contentVersionId`,
        message: error instanceof Error ? error.message : '章読み通しの固定版本文を確認できません。'
      });
    }
  }
  return issues;
}

/** Async durable-boundary checks for hashes, isolated branch contents, and replayable chapter evidence. */
export async function validateProjectIntegrity(input, options = {}, requireReceiptHistory = input.history.length > 0, verifiedStorage) {
  var _options$worldSnapsho2;
  try {
    var _options$worldSnapsho;
    const {
      verifyStoredGameEvidence
    } = await import('./gameProtocol');
    await verifyStoredGameEvidence(input, (_options$worldSnapsho = options.worldSnapshots) !== null && _options$worldSnapsho !== void 0 ? _options$worldSnapsho : {});
  } catch (error) {
    return [{
      code: 'INTEGRITY_FAILED',
      path: 'project.entities.handoffReceipt',
      message: error.message
    }];
  }
  // Freeze the exact dependency images at the durable boundary. Async hash checks
  // must never validate a different world map from the one structural validation read.
  const digestCache = createPinnedWorldDigestCache();
  const validationOptions = {
    ...options,
    worldSnapshots: freezePinnedWorldRegistry((_options$worldSnapsho2 = options.worldSnapshots) !== null && _options$worldSnapsho2 !== void 0 ? _options$worldSnapsho2 : {}, digestCache),
    worlds: options.worlds ? structuredClone(options.worlds) : undefined
  };
  // Storage has already verified immutable snapshots and the previous content.
  // Recheck every changed current record and every affected reference using the
  // same structural contract; imports/history still take the full validator.
  const structural = verifiedStorage && !requireReceiptHistory && !input.history.length ? validateCurrentProject(input, validationOptions, verifiedStorage) : validateProject(input, validationOptions);
  if (!structural.ok) return structural.issues;
  const issues = [];
  const reviewChanges = (before, after, path) => {
    const old = new Map(before.filter(e => e.kind === 'review' && e.data.sharedSource).map(e => [e.id, e]));
    for (const entity of after) {
      var _entity$data$sharedSo, _prior$data$quotedTex, _entity$data$quotedTe;
      const prior = old.get(entity.id);
      if (entity.kind !== 'review' || (prior === null || prior === void 0 ? void 0 : prior.kind) !== 'review') continue;
      if (canonicalJson(prior.data.sharedSource) !== canonicalJson((_entity$data$sharedSo = entity.data.sharedSource) !== null && _entity$data$sharedSo !== void 0 ? _entity$data$sharedSo : null)) issues.push({
        code: 'INTEGRITY_FAILED',
        path: `${path}.${entity.id}.data.sharedSource`,
        message: '元の共有指摘・公開版・位置・引用の記録は変更できません。解決文を別に保存してください。'
      });
      if (canonicalJson([prior.data.target, prior.data.targetVersionId, (_prior$data$quotedTex = prior.data.quotedText) !== null && _prior$data$quotedTex !== void 0 ? _prior$data$quotedTex : null]) !== canonicalJson([entity.data.target, entity.data.targetVersionId, (_entity$data$quotedTe = entity.data.quotedText) !== null && _entity$data$quotedTe !== void 0 ? _entity$data$quotedTe : null])) issues.push({
        code: 'INTEGRITY_FAILED',
        path: `${path}.${entity.id}.data.target`,
        message: '元の共有指摘の私的固定版と引用は変更できません。現在稿の修正は別に保存してください。'
      });
      if (prior.data.stage === 'open' && entity.data.stage === 'verified') issues.push({
        code: 'INTEGRITY_FAILED',
        path: `${path}.${entity.id}.data.stage`,
        message: '共有指摘は修正済みを保存してから再確認してください。'
      });
    }
  };
  if (verifiedStorage) reviewChanges(verifiedStorage.previous.entities, input.entities, 'project.entities');
  for (const [index, command] of input.history.entries()) reviewChanges(command.before.entities, command.after.entities, `project.history[${index}].after.entities`);
  issues.push(...(await verifyPinnedWorlds(input, validationOptions.worldSnapshots, 'project.worldReferences', digestCache)));
  for (const [index, snapshot] of input.snapshots.entries()) issues.push(...(await verifyPinnedWorlds(snapshot.content, validationOptions.worldSnapshots, `project.snapshots[${index}].content.worldReferences`, digestCache)));
  issues.push(...(await checkAlternatives(input, validationOptions, 'project', digestCache)));
  issues.push(...(await checkChapterTraces(input, validationOptions, digestCache)));
  issues.push(...checkAlternativeHistory(input));
  if (requireReceiptHistory) for (const [branchIndex, alternative] of ((_input$authorAlternat = input.authorAlternatives) !== null && _input$authorAlternat !== void 0 ? _input$authorAlternat : []).entries()) {
    var _input$authorAlternat;
    for (const [receiptIndex, receipt] of alternative.applyReceipts.entries()) {
      const receiptPath = `project.authorAlternatives[${branchIndex}].applyReceipts[${receiptIndex}]`;
      const command = input.history.find(item => item.revision === receipt.appliedRevision && item.before.revision === receipt.fromCanonicalRevision && receipt.patches.every(patch => {
        const before = receiptPatchValue(item.before, patch),
          after = receiptPatchValue(item.after, patch);
        const beforeExpected = patch.before.present ? patch.before.value : undefined,
          afterExpected = patch.after.present ? patch.after.value : undefined;
        return canonicalJson(before !== null && before !== void 0 ? before : null) === canonicalJson(beforeExpected !== null && beforeExpected !== void 0 ? beforeExpected : null) && before === undefined === !patch.before.present && canonicalJson(after !== null && after !== void 0 ? after : null) === canonicalJson(afterExpected !== null && afterExpected !== void 0 ? afterExpected : null) && after === undefined === !patch.after.present;
      }));
      if (!command) {
        issues.push({
          code: 'INTEGRITY_FAILED',
          path: receiptPath,
          message: '正本採用記録に対応する不変の変更履歴がありません。'
        });
        continue;
      }
      for (const [patchIndex, patch] of receipt.patches.entries()) {
        const before = receiptPatchValue(command.before, patch),
          after = receiptPatchValue(command.after, patch);
        const beforeExpected = patch.before.present ? patch.before.value : undefined,
          afterExpected = patch.after.present ? patch.after.value : undefined;
        if (canonicalJson(before !== null && before !== void 0 ? before : null) !== canonicalJson(beforeExpected !== null && beforeExpected !== void 0 ? beforeExpected : null) || before === undefined !== !patch.before.present) issues.push({
          code: 'INTEGRITY_FAILED',
          path: `${receiptPath}.patches[${patchIndex}].before`,
          message: '採用前の正本値が対応する変更履歴と一致しません。'
        });
        if (canonicalJson(after !== null && after !== void 0 ? after : null) !== canonicalJson(afterExpected !== null && afterExpected !== void 0 ? afterExpected : null) || after === undefined !== !patch.after.present) issues.push({
          code: 'INTEGRITY_FAILED',
          path: `${receiptPath}.patches[${patchIndex}].after`,
          message: '採用後の正本値が対応する変更履歴と一致しません。'
        });
      }
    }
  }
  for (const [index, command] of input.history.entries()) {
    for (const side of ['before', 'after']) {
      var _state$authorAlternat2;
      const state = command[side];
      const historical = projectFromState(state);
      issues.push(...(await verifyPinnedWorlds(historical, validationOptions.worldSnapshots, `project.history[${index}].${side}.worldReferences`, digestCache)));
      for (const [snapshotIndex, snapshot] of historical.snapshots.entries()) issues.push(...(await verifyPinnedWorlds(snapshot.content, validationOptions.worldSnapshots, `project.history[${index}].${side}.snapshots[${snapshotIndex}].content.worldReferences`, digestCache)));
      if ((_state$authorAlternat2 = state.authorAlternatives) !== null && _state$authorAlternat2 !== void 0 && _state$authorAlternat2.length) issues.push(...(await checkAlternatives(historical, validationOptions, `project.history[${index}].${side}`, digestCache)));
      issues.push(...(await checkChapterTraces(historical, validationOptions, digestCache)));
    }
  }
  return issues.slice(0, 256);
}

/** Hash verifier for callers that already performed structural validation. */
export async function assertProjectIntegrity(project, options = {}) {
  const issues = await validateProjectIntegrity(project, options);
  if (issues.length) throw Object.assign(new Error(issues.map(issue => `${issue.path}: ${issue.message}`).join('\n')), {
    issues
  });
}
export function snapshotContents(project) {
  return project.snapshots;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ2YWxpZGF0ZVByb2plY3QiLCJ2YWxpZGF0ZUN1cnJlbnRQcm9qZWN0IiwidmFsaWRhdGVBdXRob3JBbHRlcm5hdGl2ZXMiLCJ2YWxpZGF0ZVJlYWRpbmdUcmFjZVJlY29yZCIsImNhcHR1cmVSdW50aW1lQ29udGVudCIsInJlc29sdmVSZXVzZUNvbnRlbnQiLCJyZWNlaXB0UGF0Y2hWYWx1ZSIsImNhbm9uaWNhbEpzb24iLCJjcmVhdGVQaW5uZWRXb3JsZERpZ2VzdENhY2hlIiwiZnJlZXplUGlubmVkV29ybGRSZWdpc3RyeSIsInZlcmlmeVBpbm5lZFdvcmxkcyIsInJlc29sdmVQaW5uZWRXb3JsZHMiLCJwcm9qZWN0RnJvbVN0YXRlIiwic3RhdGUiLCJoaXN0b3J5Iiwic2FtZVByZWZpeCIsInByZXZpb3VzIiwibmV4dCIsImxlbmd0aCIsImV2ZXJ5IiwiaXRlbSIsImluZGV4IiwiY2hlY2tBbHRlcm5hdGl2ZUhpc3RvcnkiLCJwcm9qZWN0IiwiX2xvY2FsJGF0IiwiaXNzdWVzIiwidmVyc2lvbkJ5SWQiLCJNYXAiLCJyZWNlaXB0QnlJZCIsImJyYW5jaElkZW50aXR5QnlJZCIsInRpbWVsaW5lcyIsInRpbWVsaW5lRm9yIiwia2V5IiwidGltZWxpbmUiLCJnZXQiLCJzZXQiLCJsb2NhbCIsImZpcnN0TG9jYWwiLCJmaW5kSW5kZXgiLCJjb21tYW5kIiwiaW1wb3J0T3JpZ2luIiwicHVzaCIsImxhYmVsIiwiYmVmb3JlIiwiZW50cmllcyIsImltcG9ydE9wZXJhdGlvbklkIiwiYWZ0ZXIiLCJjdXJyZW50IiwiYXQiLCJyZXZpc2lvbiIsInZhbHVlcyIsInByZXZpb3VzQnlJZCIsIl9zdGF0ZSRhdXRob3JBbHRlcm5hdCIsImN1cnJlbnRCeUlkIiwiYXV0aG9yQWx0ZXJuYXRpdmVzIiwibWFwIiwiYWx0ZXJuYXRpdmUiLCJpZCIsImNvZGUiLCJwYXRoIiwibWVzc2FnZSIsInZlcnNpb25zIiwiYXBwbHlSZWNlaXB0cyIsIl9hbHRlcm5hdGl2ZSRzb3VyY2VTbiIsImlkZW50aXR5IiwicHJvamVjdElkIiwiYmFzZVJldmlzaW9uIiwic291cmNlU25hcHNob3RJZCIsImJhc2VDb250ZW50IiwiYmFzZUNvbnRlbnRIYXNoIiwiY3JlYXRlZEF0IiwicHJpb3JJZGVudGl0eSIsInVuZGVmaW5lZCIsInZlcnNpb24iLCJvbGQiLCJyZWNlaXB0IiwicmVzZXJ2ZWRJZHMiLCJpZHMiLCJTZXQiLCJlbnRpdGllcyIsInJlbGF0aW9ucyIsImFkZCIsInNuYXBzaG90Iiwic25hcHNob3RzIiwiZW50aXR5Iiwia2luZCIsIm9wZXJhdGlvbklkIiwiY2hlY2tBbHRlcm5hdGl2ZXMiLCJ2YWxpZGF0aW9uT3B0aW9ucyIsImRpZ2VzdENhY2hlIiwiX3Byb2plY3QkYXV0aG9yQWx0ZXJuIiwiYnJhbmNoSXNzdWVzIiwic25hcHNob3RJZHMiLCJ2YWxpZGF0ZUNvbnRlbnQiLCJjb250ZW50IiwiX3ZhbGlkYXRpb25PcHRpb25zJHdvIiwicGluSXNzdWVzIiwid29ybGRTbmFwc2hvdHMiLCJyZXN1bHQiLCJvayIsImlzc3VlIiwiY2hlY2tDaGFwdGVyVHJhY2VzIiwibG9jYXRpb24iLCJjaGVja3BvaW50IiwiZmluZCIsImNhbmRpZGF0ZSIsImRhdGEiLCJzdGFydENoZWNrcG9pbnRJZCIsImNvbnRlbnRWZXJzaW9uSWQiLCJtb2RlIiwiX3ZhbGlkYXRpb25PcHRpb25zJHdvMiIsInJlcGxheVNhdmVkVHJhY2UiLCJjbG9zdXJlIiwicmVwbGF5Iiwid29ybGRzIiwiZmxhdE1hcCIsIndvcmxkIiwic3RhdHVzIiwiZXJyb3IiLCJpbm5lciIsIkVycm9yIiwidmFsaWRhdGVQcm9qZWN0SW50ZWdyaXR5IiwiaW5wdXQiLCJvcHRpb25zIiwicmVxdWlyZVJlY2VpcHRIaXN0b3J5IiwidmVyaWZpZWRTdG9yYWdlIiwiX29wdGlvbnMkd29ybGRTbmFwc2hvMiIsIl9vcHRpb25zJHdvcmxkU25hcHNobyIsInZlcmlmeVN0b3JlZEdhbWVFdmlkZW5jZSIsInN0cnVjdHVyZWRDbG9uZSIsInN0cnVjdHVyYWwiLCJyZXZpZXdDaGFuZ2VzIiwiZmlsdGVyIiwiZSIsInNoYXJlZFNvdXJjZSIsIl9lbnRpdHkkZGF0YSRzaGFyZWRTbyIsIl9wcmlvciRkYXRhJHF1b3RlZFRleCIsIl9lbnRpdHkkZGF0YSRxdW90ZWRUZSIsInByaW9yIiwidGFyZ2V0IiwidGFyZ2V0VmVyc2lvbklkIiwicXVvdGVkVGV4dCIsInN0YWdlIiwiYnJhbmNoSW5kZXgiLCJfaW5wdXQkYXV0aG9yQWx0ZXJuYXQiLCJyZWNlaXB0SW5kZXgiLCJyZWNlaXB0UGF0aCIsImFwcGxpZWRSZXZpc2lvbiIsImZyb21DYW5vbmljYWxSZXZpc2lvbiIsInBhdGNoZXMiLCJwYXRjaCIsImJlZm9yZUV4cGVjdGVkIiwicHJlc2VudCIsInZhbHVlIiwiYWZ0ZXJFeHBlY3RlZCIsInBhdGNoSW5kZXgiLCJzaWRlIiwiX3N0YXRlJGF1dGhvckFsdGVybmF0MiIsImhpc3RvcmljYWwiLCJzbmFwc2hvdEluZGV4Iiwic2xpY2UiLCJhc3NlcnRQcm9qZWN0SW50ZWdyaXR5IiwiT2JqZWN0IiwiYXNzaWduIiwiam9pbiIsInNuYXBzaG90Q29udGVudHMiXSwic291cmNlcyI6WyJwcm9qZWN0UmVjb3JkVmFsaWRhdGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEVudGl0eSwgUHJvamVjdERhdGEsIFByb2plY3RTbmFwc2hvdCwgUHJvamVjdENvbnRlbnQsIFZhbGlkYXRpb25Jc3N1ZSwgQ29udGVudFN0YXRlLCBBdXRob3JBbHRlcm5hdGl2ZSwgQWx0ZXJuYXRpdmVWZXJzaW9uLCBBbHRlcm5hdGl2ZUFwcGx5UmVjZWlwdCB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHR5cGUgeyBQcm9qZWN0VmFsaWRhdGlvbk9wdGlvbnMgfSBmcm9tICcuL21vZGVsJztcbmltcG9ydCB7IHZhbGlkYXRlUHJvamVjdCx2YWxpZGF0ZUN1cnJlbnRQcm9qZWN0LCB0eXBlIERvbWFpblJlZmVyZW5jZSB9IGZyb20gJy4vbW9kZWwnO1xuaW1wb3J0IHsgdmFsaWRhdGVBdXRob3JBbHRlcm5hdGl2ZXMgfSBmcm9tICcuL2F1dGhvckFsdGVybmF0aXZlSW50ZWdyaXR5JztcbmltcG9ydCB7IHZhbGlkYXRlUmVhZGluZ1RyYWNlUmVjb3JkIH0gZnJvbSAnLi9ydW50aW1lUmVjb3JkVmFsaWRhdGlvbic7XG5pbXBvcnQgeyBjYXB0dXJlUnVudGltZUNvbnRlbnQgfSBmcm9tICcuL3J1bnRpbWVWZXJzaW9ucyc7XG5pbXBvcnQgeyByZXNvbHZlUmV1c2VDb250ZW50IH0gZnJvbSAnLi9yZXVzZSc7XG5pbXBvcnQgeyByZWNlaXB0UGF0Y2hWYWx1ZSB9IGZyb20gJy4vYXV0aG9yQWx0ZXJuYXRpdmVJbnRlZ3JpdHknO1xuaW1wb3J0IHsgY2Fub25pY2FsSnNvbiB9IGZyb20gJy4uL3N0b3JhZ2UvanNvbic7XG5pbXBvcnQgeyBjcmVhdGVQaW5uZWRXb3JsZERpZ2VzdENhY2hlLCBmcmVlemVQaW5uZWRXb3JsZFJlZ2lzdHJ5LCB2ZXJpZnlQaW5uZWRXb3JsZHMsIHJlc29sdmVQaW5uZWRXb3JsZHMgfSBmcm9tICcuL3Bpbm5lZFdvcmxkcyc7XG5pbXBvcnQgdHlwZSB7IFBpbm5lZFdvcmxkRGlnZXN0Q2FjaGUgfSBmcm9tICcuL3Bpbm5lZFdvcmxkcyc7XG5cbmZ1bmN0aW9uIHByb2plY3RGcm9tU3RhdGUoc3RhdGU6IENvbnRlbnRTdGF0ZSk6IFByb2plY3REYXRhIHtcbiAgcmV0dXJuIHsgLi4uc3RhdGUsIGhpc3Rvcnk6IFtdIH07XG59XG5cbmZ1bmN0aW9uIHNhbWVQcmVmaXg8VD4ocHJldmlvdXM6IHJlYWRvbmx5IFRbXSwgbmV4dDogcmVhZG9ubHkgVFtdKTogYm9vbGVhbiB7XG4gIHJldHVybiBuZXh0Lmxlbmd0aCA+PSBwcmV2aW91cy5sZW5ndGggJiYgcHJldmlvdXMuZXZlcnkoKGl0ZW0sIGluZGV4KSA9PiBjYW5vbmljYWxKc29uKGl0ZW0pID09PSBjYW5vbmljYWxKc29uKG5leHRbaW5kZXhdKSk7XG59XG5cbi8qKiBJbW11dGFibGUgYnJhbmNoIGV2aWRlbmNlIG11c3QgcmVtYWluIGJ5dGUtZm9yLWJ5dGUgc3RhYmxlIGluIGV2ZXJ5IHJldGFpbmVkIGhpc3RvcnkgaW1hZ2UuICovXG5mdW5jdGlvbiBjaGVja0FsdGVybmF0aXZlSGlzdG9yeShwcm9qZWN0OiBQcm9qZWN0RGF0YSk6IFZhbGlkYXRpb25Jc3N1ZVtdIHtcbiAgY29uc3QgaXNzdWVzOiBWYWxpZGF0aW9uSXNzdWVbXSA9IFtdO1xuICBjb25zdCB2ZXJzaW9uQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBBbHRlcm5hdGl2ZVZlcnNpb24+KCksIHJlY2VpcHRCeUlkID0gbmV3IE1hcDxzdHJpbmcsIEFsdGVybmF0aXZlQXBwbHlSZWNlaXB0PigpO1xuICBjb25zdCBicmFuY2hJZGVudGl0eUJ5SWQgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xuICBjb25zdCB0aW1lbGluZXMgPSBuZXcgTWFwPHN0cmluZywgQXJyYXk8eyBsYWJlbDogc3RyaW5nOyBzdGF0ZTogQ29udGVudFN0YXRlIH0+PigpO1xuICBjb25zdCB0aW1lbGluZUZvciA9IChrZXk6IHN0cmluZykgPT4geyBsZXQgdGltZWxpbmUgPSB0aW1lbGluZXMuZ2V0KGtleSk7IGlmICghdGltZWxpbmUpIHsgdGltZWxpbmUgPSBbXTsgdGltZWxpbmVzLnNldChrZXksIHRpbWVsaW5lKTsgfSByZXR1cm4gdGltZWxpbmU7IH07XG4gIGNvbnN0IGxvY2FsID0gdGltZWxpbmVGb3IoJ2xvY2FsJyk7XG4gIGNvbnN0IGZpcnN0TG9jYWwgPSBwcm9qZWN0Lmhpc3RvcnkuZmluZEluZGV4KGNvbW1hbmQgPT4gIShjb21tYW5kIGFzIHR5cGVvZiBjb21tYW5kICYgeyBpbXBvcnRPcmlnaW4/OiB1bmtub3duIH0pLmltcG9ydE9yaWdpbik7XG4gIGlmIChmaXJzdExvY2FsID49IDApIGxvY2FsLnB1c2goeyBsYWJlbDogYHByb2plY3QuaGlzdG9yeVske2ZpcnN0TG9jYWx9XS5iZWZvcmVgLCBzdGF0ZTogcHJvamVjdC5oaXN0b3J5W2ZpcnN0TG9jYWxdIS5iZWZvcmUgfSk7XG4gIGZvciAoY29uc3QgW2luZGV4LCBjb21tYW5kXSBvZiBwcm9qZWN0Lmhpc3RvcnkuZW50cmllcygpKSB7XG4gICAgY29uc3QgaW1wb3J0T3JpZ2luID0gKGNvbW1hbmQgYXMgdHlwZW9mIGNvbW1hbmQgJiB7IGltcG9ydE9yaWdpbj86IHsgaW1wb3J0T3BlcmF0aW9uSWQ6IHN0cmluZyB9IH0pLmltcG9ydE9yaWdpbjtcbiAgICBjb25zdCBrZXkgPSBpbXBvcnRPcmlnaW4gPyBgaW1wb3J0OiR7aW1wb3J0T3JpZ2luLmltcG9ydE9wZXJhdGlvbklkfWAgOiAnbG9jYWwnO1xuICAgIGNvbnN0IHRpbWVsaW5lID0gdGltZWxpbmVGb3Ioa2V5KTtcbiAgICBpZiAoaW1wb3J0T3JpZ2luICYmICF0aW1lbGluZS5sZW5ndGgpIHRpbWVsaW5lLnB1c2goeyBsYWJlbDogYHByb2plY3QuaGlzdG9yeVske2luZGV4fV0uYmVmb3JlYCwgc3RhdGU6IGNvbW1hbmQuYmVmb3JlIH0pO1xuICAgIHRpbWVsaW5lLnB1c2goeyBsYWJlbDogYHByb2plY3QuaGlzdG9yeVske2luZGV4fV0uYWZ0ZXJgLCBzdGF0ZTogY29tbWFuZC5hZnRlciB9KTtcbiAgfVxuICBjb25zdCBjdXJyZW50ID0gcHJvamVjdCBhcyB1bmtub3duIGFzIENvbnRlbnRTdGF0ZTtcbiAgaWYgKCFsb2NhbC5sZW5ndGggfHwgbG9jYWwuYXQoLTEpPy5zdGF0ZS5yZXZpc2lvbiAhPT0gcHJvamVjdC5yZXZpc2lvbikgbG9jYWwucHVzaCh7IGxhYmVsOiAncHJvamVjdCcsIHN0YXRlOiBjdXJyZW50IH0pO1xuXG4gIGZvciAoY29uc3QgdGltZWxpbmUgb2YgdGltZWxpbmVzLnZhbHVlcygpKSB7XG4gICAgbGV0IHByZXZpb3VzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBBdXRob3JBbHRlcm5hdGl2ZT4oKTtcbiAgICBmb3IgKGNvbnN0IHsgbGFiZWwsIHN0YXRlIH0gb2YgdGltZWxpbmUpIHtcbiAgICBjb25zdCBjdXJyZW50QnlJZCA9IG5ldyBNYXAoKHN0YXRlLmF1dGhvckFsdGVybmF0aXZlcyA/PyBbXSkubWFwKGFsdGVybmF0aXZlID0+IFthbHRlcm5hdGl2ZS5pZCwgYWx0ZXJuYXRpdmVdKSk7XG4gICAgZm9yIChjb25zdCBbaWQsIHByZXZpb3VzXSBvZiBwcmV2aW91c0J5SWQpIHtcbiAgICAgIGNvbnN0IG5leHQgPSBjdXJyZW50QnlJZC5nZXQoaWQpO1xuICAgICAgaWYgKCFuZXh0KSB7IGlzc3Vlcy5wdXNoKHsgY29kZTogJ0lOVEVHUklUWV9GQUlMRUQnLCBwYXRoOiBgJHtsYWJlbH0uYXV0aG9yQWx0ZXJuYXRpdmVzYCwgbWVzc2FnZTogYOmBjuWOu+OBq+S/neWtmOOBl+OBn+WIpeahiOOAjCR7aWR944CN44GM5bGl5q2044GL44KJ5aSx44KP44KM44Gm44GE44G+44GZ44CCYCB9KTsgY29udGludWU7IH1cbiAgICAgIGlmICghc2FtZVByZWZpeChwcmV2aW91cy52ZXJzaW9ucywgbmV4dC52ZXJzaW9ucykpIGlzc3Vlcy5wdXNoKHsgY29kZTogJ0lOVEVHUklUWV9GQUlMRUQnLCBwYXRoOiBgJHtsYWJlbH0uYXV0aG9yQWx0ZXJuYXRpdmVzLiR7aWR9LnZlcnNpb25zYCwgbWVzc2FnZTogJ+WIpeahiOeJiOOBruWxpeattOOBr+WJiumZpOODu+abuOaPm+OBiOOBp+OBjeOBvuOBm+OCk+OAgicgfSk7XG4gICAgICBpZiAoIXNhbWVQcmVmaXgocHJldmlvdXMuYXBwbHlSZWNlaXB0cywgbmV4dC5hcHBseVJlY2VpcHRzKSkgaXNzdWVzLnB1c2goeyBjb2RlOiAnSU5URUdSSVRZX0ZBSUxFRCcsIHBhdGg6IGAke2xhYmVsfS5hdXRob3JBbHRlcm5hdGl2ZXMuJHtpZH0uYXBwbHlSZWNlaXB0c2AsIG1lc3NhZ2U6ICfmraPmnKzmjqHnlKjoqJjpjLLjga/liYrpmaTjg7vmm7jmj5vjgYjjgafjgY3jgb7jgZvjgpPjgIInIH0pO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGFsdGVybmF0aXZlIG9mIGN1cnJlbnRCeUlkLnZhbHVlcygpKSB7XG4gICAgICBjb25zdCBpZGVudGl0eSA9IGNhbm9uaWNhbEpzb24oeyBwcm9qZWN0SWQ6IGFsdGVybmF0aXZlLnByb2plY3RJZCwgYmFzZVJldmlzaW9uOiBhbHRlcm5hdGl2ZS5iYXNlUmV2aXNpb24sIHNvdXJjZVNuYXBzaG90SWQ6IGFsdGVybmF0aXZlLnNvdXJjZVNuYXBzaG90SWQgPz8gbnVsbCxcbiAgICAgICAgYmFzZUNvbnRlbnQ6IGFsdGVybmF0aXZlLmJhc2VDb250ZW50LCBiYXNlQ29udGVudEhhc2g6IGFsdGVybmF0aXZlLmJhc2VDb250ZW50SGFzaCwgY3JlYXRlZEF0OiBhbHRlcm5hdGl2ZS5jcmVhdGVkQXQgfSk7XG4gICAgICBjb25zdCBwcmlvcklkZW50aXR5ID0gYnJhbmNoSWRlbnRpdHlCeUlkLmdldChhbHRlcm5hdGl2ZS5pZCk7XG4gICAgICBpZiAocHJpb3JJZGVudGl0eSAhPT0gdW5kZWZpbmVkICYmIHByaW9ySWRlbnRpdHkgIT09IGlkZW50aXR5KSBpc3N1ZXMucHVzaCh7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYCR7bGFiZWx9LmF1dGhvckFsdGVybmF0aXZlcy4ke2FsdGVybmF0aXZlLmlkfWAsIG1lc3NhZ2U6ICfliKXmoYhJROOBjOeVsOOBquOCi+WIhuWykOWFg+OBruWGheWuueOBq+WGjeWIqeeUqOOBleOCjOOBpuOBhOOBvuOBmeOAgicgfSk7XG4gICAgICBlbHNlIGJyYW5jaElkZW50aXR5QnlJZC5zZXQoYWx0ZXJuYXRpdmUuaWQsIGlkZW50aXR5KTtcbiAgICAgIGZvciAoY29uc3QgdmVyc2lvbiBvZiBhbHRlcm5hdGl2ZS52ZXJzaW9ucykge1xuICAgICAgICBjb25zdCBvbGQgPSB2ZXJzaW9uQnlJZC5nZXQodmVyc2lvbi5pZCk7XG4gICAgICAgIGlmIChvbGQgJiYgY2Fub25pY2FsSnNvbihvbGQpICE9PSBjYW5vbmljYWxKc29uKHZlcnNpb24pKSBpc3N1ZXMucHVzaCh7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYCR7bGFiZWx9LmF1dGhvckFsdGVybmF0aXZlcy4ke2FsdGVybmF0aXZlLmlkfS52ZXJzaW9ucy4ke3ZlcnNpb24uaWR9YCwgbWVzc2FnZTogJ+S4jeWkieOBruWIpeahiOeJiElE44GM55Ww44Gq44KL5YaF5a6544G45YaN5Yip55So44GV44KM44Gm44GE44G+44GZ44CCJyB9KTtcbiAgICAgICAgZWxzZSB2ZXJzaW9uQnlJZC5zZXQodmVyc2lvbi5pZCwgdmVyc2lvbik7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHJlY2VpcHQgb2YgYWx0ZXJuYXRpdmUuYXBwbHlSZWNlaXB0cykge1xuICAgICAgICBjb25zdCBvbGQgPSByZWNlaXB0QnlJZC5nZXQocmVjZWlwdC5pZCk7XG4gICAgICAgIGlmIChvbGQgJiYgY2Fub25pY2FsSnNvbihvbGQpICE9PSBjYW5vbmljYWxKc29uKHJlY2VpcHQpKSBpc3N1ZXMucHVzaCh7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYCR7bGFiZWx9LmF1dGhvckFsdGVybmF0aXZlcy4ke2FsdGVybmF0aXZlLmlkfS5hcHBseVJlY2VpcHRzLiR7cmVjZWlwdC5pZH1gLCBtZXNzYWdlOiAn5LiN5aSJ44Gu5q2j5pys5o6h55So6KiY6YyySUTjgYznlbDjgarjgovlhoXlrrnjgbjlho3liKnnlKjjgZXjgozjgabjgYTjgb7jgZnjgIInIH0pO1xuICAgICAgICBlbHNlIHJlY2VpcHRCeUlkLnNldChyZWNlaXB0LmlkLCByZWNlaXB0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgICBwcmV2aW91c0J5SWQgPSBjdXJyZW50QnlJZDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGlzc3Vlcztcbn1cblxuZnVuY3Rpb24gcmVzZXJ2ZWRJZHMocHJvamVjdDogUHJvamVjdERhdGEpOiBTZXQ8c3RyaW5nPiB7XG4gIGNvbnN0IGlkcyA9IG5ldyBTZXQ8c3RyaW5nPihbcHJvamVjdC5wcm9qZWN0SWRdKTtcbiAgZm9yIChjb25zdCBpdGVtIG9mIFsuLi5wcm9qZWN0LmVudGl0aWVzLCAuLi5wcm9qZWN0LnJlbGF0aW9uc10pIGlkcy5hZGQoaXRlbS5pZCk7XG4gIGZvciAoY29uc3Qgc25hcHNob3Qgb2YgcHJvamVjdC5zbmFwc2hvdHMpIHtcbiAgICBpZHMuYWRkKHNuYXBzaG90LmlkKTtcbiAgICBmb3IgKGNvbnN0IGVudGl0eSBvZiBwcm9qZWN0LmVudGl0aWVzKSBpZiAoZW50aXR5LmtpbmQgPT09ICdzbmFwc2hvdCcgJiYgZW50aXR5LmlkID09PSBzbmFwc2hvdC5pZCkgaWRzLmFkZChlbnRpdHkuaWQpO1xuICB9XG4gIGZvciAoY29uc3QgY29tbWFuZCBvZiBwcm9qZWN0Lmhpc3RvcnkpIGlkcy5hZGQoY29tbWFuZC5vcGVyYXRpb25JZCk7XG4gIHJldHVybiBpZHM7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrQWx0ZXJuYXRpdmVzKHByb2plY3Q6IFByb2plY3REYXRhLCB2YWxpZGF0aW9uT3B0aW9uczogUHJvamVjdFZhbGlkYXRpb25PcHRpb25zLCBwYXRoOiBzdHJpbmcsIGRpZ2VzdENhY2hlOiBQaW5uZWRXb3JsZERpZ2VzdENhY2hlKTogUHJvbWlzZTxWYWxpZGF0aW9uSXNzdWVbXT4ge1xuICBjb25zdCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdID0gW107XG4gIGNvbnN0IHNuYXBzaG90cyA9IHByb2plY3Quc25hcHNob3RzO1xuICBjb25zdCBicmFuY2hJc3N1ZXMgPSBhd2FpdCB2YWxpZGF0ZUF1dGhvckFsdGVybmF0aXZlcyhwcm9qZWN0LnByb2plY3RJZCwgcHJvamVjdC5hdXRob3JBbHRlcm5hdGl2ZXMgPz8gW10sIHtcbiAgICBzbmFwc2hvdElkczogbmV3IFNldChzbmFwc2hvdHMubWFwKHNuYXBzaG90ID0+IHNuYXBzaG90LmlkKSksIHNuYXBzaG90cywgcmVzZXJ2ZWRJZHM6IHJlc2VydmVkSWRzKHByb2plY3QpLFxuICAgIHZhbGlkYXRlQ29udGVudDogYXN5bmMgKGNvbnRlbnQ6IFByb2plY3RDb250ZW50KSA9PiB7XG4gICAgICBjb25zdCBwaW5Jc3N1ZXMgPSBhd2FpdCB2ZXJpZnlQaW5uZWRXb3JsZHMoY29udGVudCwgdmFsaWRhdGlvbk9wdGlvbnMud29ybGRTbmFwc2hvdHMgPz8ge30sIGAke3BhdGh9LmF1dGhvckFsdGVybmF0aXZlcy53b3JsZFJlZmVyZW5jZXNgLCBkaWdlc3RDYWNoZSk7XG4gICAgICBjb25zdCByZXN1bHQgPSB2YWxpZGF0ZVByb2plY3QoeyAuLi5jb250ZW50LCBzbmFwc2hvdHMsIGhpc3Rvcnk6IFtdIH0sIHZhbGlkYXRpb25PcHRpb25zKTtcbiAgICAgIHJldHVybiByZXN1bHQub2sgJiYgIXBpbklzc3Vlcy5sZW5ndGggPyB7IG9rOiB0cnVlIH0gOiB7IG9rOiBmYWxzZSwgaXNzdWVzOiBbLi4ucGluSXNzdWVzLCAuLi4oIXJlc3VsdC5vayA/IHJlc3VsdC5pc3N1ZXMgOiBbXSldIH07XG4gICAgfSxcbiAgfSk7XG4gIGZvciAoY29uc3QgaXNzdWUgb2YgYnJhbmNoSXNzdWVzKSBpc3N1ZXMucHVzaCh7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYCR7cGF0aH0uJHtpc3N1ZS5wYXRofWAsIG1lc3NhZ2U6IGlzc3VlLm1lc3NhZ2UgfSk7XG4gIHJldHVybiBpc3N1ZXM7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrQ2hhcHRlclRyYWNlcyhwcm9qZWN0OiBQcm9qZWN0RGF0YSwgdmFsaWRhdGlvbk9wdGlvbnM6IFByb2plY3RWYWxpZGF0aW9uT3B0aW9ucywgZGlnZXN0Q2FjaGU6IFBpbm5lZFdvcmxkRGlnZXN0Q2FjaGUpOiBQcm9taXNlPFZhbGlkYXRpb25Jc3N1ZVtdPiB7XG4gIGNvbnN0IGlzc3VlczogVmFsaWRhdGlvbklzc3VlW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaW5kZXgsIGVudGl0eV0gb2YgcHJvamVjdC5lbnRpdGllcy5lbnRyaWVzKCkpIHtcbiAgICBpZiAoZW50aXR5LmtpbmQgIT09ICd0cmFjZScpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGxvY2F0aW9uID0gYHByb2plY3QuZW50aXRpZXNbJHtpbmRleH1dLmRhdGFgO1xuICAgIGNvbnN0IGNoZWNrcG9pbnQgPSBwcm9qZWN0LmVudGl0aWVzLmZpbmQoY2FuZGlkYXRlID0+IGNhbmRpZGF0ZS5pZCA9PT0gZW50aXR5LmRhdGEuc3RhcnRDaGVja3BvaW50SWQgJiYgY2FuZGlkYXRlLmtpbmQgPT09ICdjaGVja3BvaW50Jyk7XG4gICAgaWYgKCFjaGVja3BvaW50IHx8IGNoZWNrcG9pbnQua2luZCAhPT0gJ2NoZWNrcG9pbnQnKSB7XG4gICAgICBpc3N1ZXMucHVzaCh7IGNvZGU6ICdSRUZFUkVOQ0VfSU5WQUxJRCcsIHBhdGg6IGAke2xvY2F0aW9ufS5zdGFydENoZWNrcG9pbnRJZGAsIG1lc3NhZ2U6ICfntYzot6/jga7plovlp4vnirbmhYvjgYzopovjgaTjgYvjgorjgb7jgZvjgpPjgIInIH0pO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgY2FwdHVyZVJ1bnRpbWVDb250ZW50KHByb2plY3QsIGVudGl0eS5kYXRhLmNvbnRlbnRWZXJzaW9uSWQsIHZhbGlkYXRpb25PcHRpb25zLCBkaWdlc3RDYWNoZSk7XG4gICAgICBpZiAoZW50aXR5LmRhdGEubW9kZSA9PT0gJ2NoYXB0ZXJzJykgaXNzdWVzLnB1c2goLi4udmFsaWRhdGVSZWFkaW5nVHJhY2VSZWNvcmQoY29udGVudCwgZW50aXR5LmRhdGEsIGNoZWNrcG9pbnQuZGF0YSwgbG9jYXRpb24sIHZhbGlkYXRpb25PcHRpb25zKSk7XG4gICAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgeyByZXBsYXlTYXZlZFRyYWNlIH0gPSBhd2FpdCBpbXBvcnQoJy4vcnVudGltZScpO1xuICAgICAgICBjb25zdCBjbG9zdXJlID0gcmVzb2x2ZVBpbm5lZFdvcmxkcyhyZXNvbHZlUmV1c2VDb250ZW50KGNvbnRlbnQsIGNvbnRlbnQuc25hcHNob3RzKSwgdmFsaWRhdGlvbk9wdGlvbnMud29ybGRTbmFwc2hvdHMgPz8ge30pO1xuICAgICAgICBjb25zdCByZXBsYXkgPSByZXBsYXlTYXZlZFRyYWNlKHByb2plY3QsIGVudGl0eS5pZCwgY2xvc3VyZS53b3JsZHMuZmxhdE1hcCh3b3JsZCA9PiB3b3JsZC5lbnRpdGllcykpO1xuICAgICAgICBpZiAocmVwbGF5LnN0YXR1cyA9PT0gJ2Vycm9yJykgaXNzdWVzLnB1c2goLi4ucmVwbGF5Lmlzc3Vlcy5tYXAoaXNzdWUgPT4gKHsgLi4uaXNzdWUsIHBhdGg6IGAke2xvY2F0aW9ufS4ke2lzc3VlLnBhdGh9YCB9KSkpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zdCBpbm5lciA9IChlcnJvciBhcyB7IGlzc3Vlcz86IFZhbGlkYXRpb25Jc3N1ZVtdIH0pLmlzc3VlcztcbiAgICAgIGlmIChpbm5lcj8ubGVuZ3RoKSBpc3N1ZXMucHVzaCguLi5pbm5lci5tYXAoaXNzdWUgPT4gKHsgLi4uaXNzdWUsIHBhdGg6IGAke2xvY2F0aW9ufS4ke2lzc3VlLnBhdGh9YCB9KSkpO1xuICAgICAgZWxzZSBpc3N1ZXMucHVzaCh7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYCR7bG9jYXRpb259LmNvbnRlbnRWZXJzaW9uSWRgLCBtZXNzYWdlOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICfnq6Doqq3jgb/pgJrjgZfjga7lm7rlrprniYjmnKzmlofjgpLnorroqo3jgafjgY3jgb7jgZvjgpPjgIInIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gaXNzdWVzO1xufVxuXG4vKiogQXN5bmMgZHVyYWJsZS1ib3VuZGFyeSBjaGVja3MgZm9yIGhhc2hlcywgaXNvbGF0ZWQgYnJhbmNoIGNvbnRlbnRzLCBhbmQgcmVwbGF5YWJsZSBjaGFwdGVyIGV2aWRlbmNlLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHZhbGlkYXRlUHJvamVjdEludGVncml0eShpbnB1dDogUHJvamVjdERhdGEsIG9wdGlvbnM6IFByb2plY3RWYWxpZGF0aW9uT3B0aW9ucyA9IHt9LCByZXF1aXJlUmVjZWlwdEhpc3RvcnkgPSBpbnB1dC5oaXN0b3J5Lmxlbmd0aCA+IDAsIHZlcmlmaWVkU3RvcmFnZT86e3ByZXZpb3VzOlByb2plY3REYXRhO3JlZmVyZW5jZXM6V2Vha01hcDxFbnRpdHksRG9tYWluUmVmZXJlbmNlW10+fSk6IFByb21pc2U8VmFsaWRhdGlvbklzc3VlW10+IHtcbiAgdHJ5IHtjb25zdCB7dmVyaWZ5U3RvcmVkR2FtZUV2aWRlbmNlfT1hd2FpdCBpbXBvcnQoJy4vZ2FtZVByb3RvY29sJyk7YXdhaXQgdmVyaWZ5U3RvcmVkR2FtZUV2aWRlbmNlKGlucHV0LG9wdGlvbnMud29ybGRTbmFwc2hvdHM/P3t9KTt9Y2F0Y2goZXJyb3Ipe3JldHVybiBbe2NvZGU6J0lOVEVHUklUWV9GQUlMRUQnLHBhdGg6J3Byb2plY3QuZW50aXRpZXMuaGFuZG9mZlJlY2VpcHQnLG1lc3NhZ2U6KGVycm9yIGFzIEVycm9yKS5tZXNzYWdlfV07fVxuICAvLyBGcmVlemUgdGhlIGV4YWN0IGRlcGVuZGVuY3kgaW1hZ2VzIGF0IHRoZSBkdXJhYmxlIGJvdW5kYXJ5LiBBc3luYyBoYXNoIGNoZWNrc1xuICAvLyBtdXN0IG5ldmVyIHZhbGlkYXRlIGEgZGlmZmVyZW50IHdvcmxkIG1hcCBmcm9tIHRoZSBvbmUgc3RydWN0dXJhbCB2YWxpZGF0aW9uIHJlYWQuXG4gIGNvbnN0IGRpZ2VzdENhY2hlID0gY3JlYXRlUGlubmVkV29ybGREaWdlc3RDYWNoZSgpO1xuICBjb25zdCB2YWxpZGF0aW9uT3B0aW9ucyA9IHsgLi4ub3B0aW9ucywgd29ybGRTbmFwc2hvdHM6IGZyZWV6ZVBpbm5lZFdvcmxkUmVnaXN0cnkob3B0aW9ucy53b3JsZFNuYXBzaG90cyA/PyB7fSwgZGlnZXN0Q2FjaGUpLCB3b3JsZHM6IG9wdGlvbnMud29ybGRzID8gc3RydWN0dXJlZENsb25lKG9wdGlvbnMud29ybGRzKSA6IHVuZGVmaW5lZCB9O1xuICAvLyBTdG9yYWdlIGhhcyBhbHJlYWR5IHZlcmlmaWVkIGltbXV0YWJsZSBzbmFwc2hvdHMgYW5kIHRoZSBwcmV2aW91cyBjb250ZW50LlxuICAvLyBSZWNoZWNrIGV2ZXJ5IGNoYW5nZWQgY3VycmVudCByZWNvcmQgYW5kIGV2ZXJ5IGFmZmVjdGVkIHJlZmVyZW5jZSB1c2luZyB0aGVcbiAgLy8gc2FtZSBzdHJ1Y3R1cmFsIGNvbnRyYWN0OyBpbXBvcnRzL2hpc3Rvcnkgc3RpbGwgdGFrZSB0aGUgZnVsbCB2YWxpZGF0b3IuXG4gIGNvbnN0IHN0cnVjdHVyYWwgPSB2ZXJpZmllZFN0b3JhZ2UmJiFyZXF1aXJlUmVjZWlwdEhpc3RvcnkmJiFpbnB1dC5oaXN0b3J5Lmxlbmd0aFxuICAgID92YWxpZGF0ZUN1cnJlbnRQcm9qZWN0KGlucHV0LHZhbGlkYXRpb25PcHRpb25zLHZlcmlmaWVkU3RvcmFnZSk6dmFsaWRhdGVQcm9qZWN0KGlucHV0LCB2YWxpZGF0aW9uT3B0aW9ucyk7XG4gIGlmICghc3RydWN0dXJhbC5vaykgcmV0dXJuIHN0cnVjdHVyYWwuaXNzdWVzO1xuICBjb25zdCBpc3N1ZXM6IFZhbGlkYXRpb25Jc3N1ZVtdID0gW107XG4gIGNvbnN0IHJldmlld0NoYW5nZXM9KGJlZm9yZTpQcm9qZWN0RGF0YVsnZW50aXRpZXMnXSxhZnRlcjpQcm9qZWN0RGF0YVsnZW50aXRpZXMnXSxwYXRoOnN0cmluZyk9PntcbiAgICBjb25zdCBvbGQ9bmV3IE1hcChiZWZvcmUuZmlsdGVyKGU9PmUua2luZD09PSdyZXZpZXcnJiZlLmRhdGEuc2hhcmVkU291cmNlKS5tYXAoZT0+W2UuaWQsZV0pKTtcbiAgICBmb3IoY29uc3QgZW50aXR5IG9mIGFmdGVyKXtjb25zdCBwcmlvcj1vbGQuZ2V0KGVudGl0eS5pZCk7aWYoZW50aXR5LmtpbmQhPT0ncmV2aWV3J3x8cHJpb3I/LmtpbmQhPT0ncmV2aWV3Jyljb250aW51ZTtcbiAgICAgIGlmKGNhbm9uaWNhbEpzb24ocHJpb3IuZGF0YS5zaGFyZWRTb3VyY2UpIT09Y2Fub25pY2FsSnNvbihlbnRpdHkuZGF0YS5zaGFyZWRTb3VyY2U/P251bGwpKWlzc3Vlcy5wdXNoKHtjb2RlOidJTlRFR1JJVFlfRkFJTEVEJyxwYXRoOmAke3BhdGh9LiR7ZW50aXR5LmlkfS5kYXRhLnNoYXJlZFNvdXJjZWAsbWVzc2FnZTon5YWD44Gu5YWx5pyJ5oyH5pGY44O75YWs6ZaL54mI44O75L2N572u44O75byV55So44Gu6KiY6Yyy44Gv5aSJ5pu044Gn44GN44G+44Gb44KT44CC6Kej5rG65paH44KS5Yil44Gr5L+d5a2Y44GX44Gm44GP44Gg44GV44GE44CCJ30pO1xuICAgICAgaWYoY2Fub25pY2FsSnNvbihbcHJpb3IuZGF0YS50YXJnZXQscHJpb3IuZGF0YS50YXJnZXRWZXJzaW9uSWQscHJpb3IuZGF0YS5xdW90ZWRUZXh0Pz9udWxsXSkhPT1jYW5vbmljYWxKc29uKFtlbnRpdHkuZGF0YS50YXJnZXQsZW50aXR5LmRhdGEudGFyZ2V0VmVyc2lvbklkLGVudGl0eS5kYXRhLnF1b3RlZFRleHQ/P251bGxdKSlpc3N1ZXMucHVzaCh7Y29kZTonSU5URUdSSVRZX0ZBSUxFRCcscGF0aDpgJHtwYXRofS4ke2VudGl0eS5pZH0uZGF0YS50YXJnZXRgLG1lc3NhZ2U6J+WFg+OBruWFseacieaMh+aRmOOBruengeeahOWbuuWumueJiOOBqOW8leeUqOOBr+WkieabtOOBp+OBjeOBvuOBm+OCk+OAguePvuWcqOeov+OBruS/ruato+OBr+WIpeOBq+S/neWtmOOBl+OBpuOBj+OBoOOBleOBhOOAgid9KTtcbiAgICAgIGlmKHByaW9yLmRhdGEuc3RhZ2U9PT0nb3BlbicmJmVudGl0eS5kYXRhLnN0YWdlPT09J3ZlcmlmaWVkJylpc3N1ZXMucHVzaCh7Y29kZTonSU5URUdSSVRZX0ZBSUxFRCcscGF0aDpgJHtwYXRofS4ke2VudGl0eS5pZH0uZGF0YS5zdGFnZWAsbWVzc2FnZTon5YWx5pyJ5oyH5pGY44Gv5L+u5q2j5riI44G/44KS5L+d5a2Y44GX44Gm44GL44KJ5YaN56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJ30pO1xuICAgIH1cbiAgfTtcbiAgaWYodmVyaWZpZWRTdG9yYWdlKXJldmlld0NoYW5nZXModmVyaWZpZWRTdG9yYWdlLnByZXZpb3VzLmVudGl0aWVzLGlucHV0LmVudGl0aWVzLCdwcm9qZWN0LmVudGl0aWVzJyk7XG4gIGZvcihjb25zdCBbaW5kZXgsY29tbWFuZF1vZiBpbnB1dC5oaXN0b3J5LmVudHJpZXMoKSlyZXZpZXdDaGFuZ2VzKGNvbW1hbmQuYmVmb3JlLmVudGl0aWVzLGNvbW1hbmQuYWZ0ZXIuZW50aXRpZXMsYHByb2plY3QuaGlzdG9yeVske2luZGV4fV0uYWZ0ZXIuZW50aXRpZXNgKTtcbiAgaXNzdWVzLnB1c2goLi4uYXdhaXQgdmVyaWZ5UGlubmVkV29ybGRzKGlucHV0LCB2YWxpZGF0aW9uT3B0aW9ucy53b3JsZFNuYXBzaG90cywgJ3Byb2plY3Qud29ybGRSZWZlcmVuY2VzJywgZGlnZXN0Q2FjaGUpKTtcbiAgZm9yIChjb25zdCBbaW5kZXgsIHNuYXBzaG90XSBvZiBpbnB1dC5zbmFwc2hvdHMuZW50cmllcygpKSBpc3N1ZXMucHVzaCguLi5hd2FpdCB2ZXJpZnlQaW5uZWRXb3JsZHMoc25hcHNob3QuY29udGVudCwgdmFsaWRhdGlvbk9wdGlvbnMud29ybGRTbmFwc2hvdHMsIGBwcm9qZWN0LnNuYXBzaG90c1ske2luZGV4fV0uY29udGVudC53b3JsZFJlZmVyZW5jZXNgLCBkaWdlc3RDYWNoZSkpO1xuICBpc3N1ZXMucHVzaCguLi5hd2FpdCBjaGVja0FsdGVybmF0aXZlcyhpbnB1dCwgdmFsaWRhdGlvbk9wdGlvbnMsICdwcm9qZWN0JywgZGlnZXN0Q2FjaGUpKTtcbiAgaXNzdWVzLnB1c2goLi4uYXdhaXQgY2hlY2tDaGFwdGVyVHJhY2VzKGlucHV0LCB2YWxpZGF0aW9uT3B0aW9ucywgZGlnZXN0Q2FjaGUpKTtcbiAgaXNzdWVzLnB1c2goLi4uY2hlY2tBbHRlcm5hdGl2ZUhpc3RvcnkoaW5wdXQpKTtcbiAgaWYgKHJlcXVpcmVSZWNlaXB0SGlzdG9yeSkgZm9yIChjb25zdCBbYnJhbmNoSW5kZXgsIGFsdGVybmF0aXZlXSBvZiAoaW5wdXQuYXV0aG9yQWx0ZXJuYXRpdmVzID8/IFtdKS5lbnRyaWVzKCkpIGZvciAoY29uc3QgW3JlY2VpcHRJbmRleCwgcmVjZWlwdF0gb2YgYWx0ZXJuYXRpdmUuYXBwbHlSZWNlaXB0cy5lbnRyaWVzKCkpIHtcbiAgICBjb25zdCByZWNlaXB0UGF0aCA9IGBwcm9qZWN0LmF1dGhvckFsdGVybmF0aXZlc1ske2JyYW5jaEluZGV4fV0uYXBwbHlSZWNlaXB0c1ske3JlY2VpcHRJbmRleH1dYDtcbiAgICBjb25zdCBjb21tYW5kID0gaW5wdXQuaGlzdG9yeS5maW5kKGl0ZW0gPT4gaXRlbS5yZXZpc2lvbiA9PT0gcmVjZWlwdC5hcHBsaWVkUmV2aXNpb24gJiYgaXRlbS5iZWZvcmUucmV2aXNpb24gPT09IHJlY2VpcHQuZnJvbUNhbm9uaWNhbFJldmlzaW9uICYmIHJlY2VpcHQucGF0Y2hlcy5ldmVyeShwYXRjaCA9PiB7XG4gICAgICBjb25zdCBiZWZvcmUgPSByZWNlaXB0UGF0Y2hWYWx1ZShpdGVtLmJlZm9yZSwgcGF0Y2gpLCBhZnRlciA9IHJlY2VpcHRQYXRjaFZhbHVlKGl0ZW0uYWZ0ZXIsIHBhdGNoKTtcbiAgICAgIGNvbnN0IGJlZm9yZUV4cGVjdGVkID0gcGF0Y2guYmVmb3JlLnByZXNlbnQgPyBwYXRjaC5iZWZvcmUudmFsdWUgOiB1bmRlZmluZWQsIGFmdGVyRXhwZWN0ZWQgPSBwYXRjaC5hZnRlci5wcmVzZW50ID8gcGF0Y2guYWZ0ZXIudmFsdWUgOiB1bmRlZmluZWQ7XG4gICAgICByZXR1cm4gY2Fub25pY2FsSnNvbihiZWZvcmUgPz8gbnVsbCkgPT09IGNhbm9uaWNhbEpzb24oYmVmb3JlRXhwZWN0ZWQgPz8gbnVsbCkgJiYgKGJlZm9yZSA9PT0gdW5kZWZpbmVkKSA9PT0gIXBhdGNoLmJlZm9yZS5wcmVzZW50XG4gICAgICAgICYmIGNhbm9uaWNhbEpzb24oYWZ0ZXIgPz8gbnVsbCkgPT09IGNhbm9uaWNhbEpzb24oYWZ0ZXJFeHBlY3RlZCA/PyBudWxsKSAmJiAoYWZ0ZXIgPT09IHVuZGVmaW5lZCkgPT09ICFwYXRjaC5hZnRlci5wcmVzZW50O1xuICAgIH0pKTtcbiAgICBpZiAoIWNvbW1hbmQpIHsgaXNzdWVzLnB1c2goeyBjb2RlOiAnSU5URUdSSVRZX0ZBSUxFRCcsIHBhdGg6IHJlY2VpcHRQYXRoLCBtZXNzYWdlOiAn5q2j5pys5o6h55So6KiY6Yyy44Gr5a++5b+c44GZ44KL5LiN5aSJ44Gu5aSJ5pu05bGl5q2044GM44GC44KK44G+44Gb44KT44CCJyB9KTsgY29udGludWU7IH1cbiAgICBmb3IgKGNvbnN0IFtwYXRjaEluZGV4LCBwYXRjaF0gb2YgcmVjZWlwdC5wYXRjaGVzLmVudHJpZXMoKSkge1xuICAgICAgY29uc3QgYmVmb3JlID0gcmVjZWlwdFBhdGNoVmFsdWUoY29tbWFuZC5iZWZvcmUsIHBhdGNoKSwgYWZ0ZXIgPSByZWNlaXB0UGF0Y2hWYWx1ZShjb21tYW5kLmFmdGVyLCBwYXRjaCk7XG4gICAgICBjb25zdCBiZWZvcmVFeHBlY3RlZCA9IHBhdGNoLmJlZm9yZS5wcmVzZW50ID8gcGF0Y2guYmVmb3JlLnZhbHVlIDogdW5kZWZpbmVkLCBhZnRlckV4cGVjdGVkID0gcGF0Y2guYWZ0ZXIucHJlc2VudCA/IHBhdGNoLmFmdGVyLnZhbHVlIDogdW5kZWZpbmVkO1xuICAgICAgaWYgKGNhbm9uaWNhbEpzb24oYmVmb3JlID8/IG51bGwpICE9PSBjYW5vbmljYWxKc29uKGJlZm9yZUV4cGVjdGVkID8/IG51bGwpIHx8IChiZWZvcmUgPT09IHVuZGVmaW5lZCkgIT09ICFwYXRjaC5iZWZvcmUucHJlc2VudCkgaXNzdWVzLnB1c2goeyBjb2RlOiAnSU5URUdSSVRZX0ZBSUxFRCcsIHBhdGg6IGAke3JlY2VpcHRQYXRofS5wYXRjaGVzWyR7cGF0Y2hJbmRleH1dLmJlZm9yZWAsIG1lc3NhZ2U6ICfmjqHnlKjliY3jga7mraPmnKzlgKTjgYzlr77lv5zjgZnjgovlpInmm7TlsaXmrbTjgajkuIDoh7TjgZfjgb7jgZvjgpPjgIInIH0pO1xuICAgICAgaWYgKGNhbm9uaWNhbEpzb24oYWZ0ZXIgPz8gbnVsbCkgIT09IGNhbm9uaWNhbEpzb24oYWZ0ZXJFeHBlY3RlZCA/PyBudWxsKSB8fCAoYWZ0ZXIgPT09IHVuZGVmaW5lZCkgIT09ICFwYXRjaC5hZnRlci5wcmVzZW50KSBpc3N1ZXMucHVzaCh7IGNvZGU6ICdJTlRFR1JJVFlfRkFJTEVEJywgcGF0aDogYCR7cmVjZWlwdFBhdGh9LnBhdGNoZXNbJHtwYXRjaEluZGV4fV0uYWZ0ZXJgLCBtZXNzYWdlOiAn5o6h55So5b6M44Gu5q2j5pys5YCk44GM5a++5b+c44GZ44KL5aSJ5pu05bGl5q2044Go5LiA6Ie044GX44G+44Gb44KT44CCJyB9KTtcbiAgICB9XG4gIH1cbiAgZm9yIChjb25zdCBbaW5kZXgsIGNvbW1hbmRdIG9mIGlucHV0Lmhpc3RvcnkuZW50cmllcygpKSB7XG4gICAgZm9yIChjb25zdCBzaWRlIG9mIFsnYmVmb3JlJywgJ2FmdGVyJ10gYXMgY29uc3QpIHtcbiAgICAgIGNvbnN0IHN0YXRlID0gY29tbWFuZFtzaWRlXTtcbiAgICAgIGNvbnN0IGhpc3RvcmljYWwgPSBwcm9qZWN0RnJvbVN0YXRlKHN0YXRlKTtcbiAgICAgIGlzc3Vlcy5wdXNoKC4uLmF3YWl0IHZlcmlmeVBpbm5lZFdvcmxkcyhoaXN0b3JpY2FsLCB2YWxpZGF0aW9uT3B0aW9ucy53b3JsZFNuYXBzaG90cywgYHByb2plY3QuaGlzdG9yeVske2luZGV4fV0uJHtzaWRlfS53b3JsZFJlZmVyZW5jZXNgLCBkaWdlc3RDYWNoZSkpO1xuICAgICAgZm9yIChjb25zdCBbc25hcHNob3RJbmRleCwgc25hcHNob3RdIG9mIGhpc3RvcmljYWwuc25hcHNob3RzLmVudHJpZXMoKSkgaXNzdWVzLnB1c2goLi4uYXdhaXQgdmVyaWZ5UGlubmVkV29ybGRzKHNuYXBzaG90LmNvbnRlbnQsIHZhbGlkYXRpb25PcHRpb25zLndvcmxkU25hcHNob3RzLCBgcHJvamVjdC5oaXN0b3J5WyR7aW5kZXh9XS4ke3NpZGV9LnNuYXBzaG90c1ske3NuYXBzaG90SW5kZXh9XS5jb250ZW50LndvcmxkUmVmZXJlbmNlc2AsIGRpZ2VzdENhY2hlKSk7XG4gICAgICBpZiAoc3RhdGUuYXV0aG9yQWx0ZXJuYXRpdmVzPy5sZW5ndGgpIGlzc3Vlcy5wdXNoKC4uLmF3YWl0IGNoZWNrQWx0ZXJuYXRpdmVzKGhpc3RvcmljYWwsIHZhbGlkYXRpb25PcHRpb25zLCBgcHJvamVjdC5oaXN0b3J5WyR7aW5kZXh9XS4ke3NpZGV9YCwgZGlnZXN0Q2FjaGUpKTtcbiAgICAgIGlzc3Vlcy5wdXNoKC4uLmF3YWl0IGNoZWNrQ2hhcHRlclRyYWNlcyhoaXN0b3JpY2FsLCB2YWxpZGF0aW9uT3B0aW9ucywgZGlnZXN0Q2FjaGUpKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGlzc3Vlcy5zbGljZSgwLCAyNTYpO1xufVxuXG4vKiogSGFzaCB2ZXJpZmllciBmb3IgY2FsbGVycyB0aGF0IGFscmVhZHkgcGVyZm9ybWVkIHN0cnVjdHVyYWwgdmFsaWRhdGlvbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhc3NlcnRQcm9qZWN0SW50ZWdyaXR5KHByb2plY3Q6IFByb2plY3REYXRhLCBvcHRpb25zOiBQcm9qZWN0VmFsaWRhdGlvbk9wdGlvbnMgPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBpc3N1ZXMgPSBhd2FpdCB2YWxpZGF0ZVByb2plY3RJbnRlZ3JpdHkocHJvamVjdCwgb3B0aW9ucyk7XG4gIGlmIChpc3N1ZXMubGVuZ3RoKSB0aHJvdyBPYmplY3QuYXNzaWduKG5ldyBFcnJvcihpc3N1ZXMubWFwKGlzc3VlID0+IGAke2lzc3VlLnBhdGh9OiAke2lzc3VlLm1lc3NhZ2V9YCkuam9pbignXFxuJykpLCB7IGlzc3VlcyB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNuYXBzaG90Q29udGVudHMocHJvamVjdDogUHJvamVjdERhdGEpOiByZWFkb25seSBQcm9qZWN0U25hcHNob3RbXSB7IHJldHVybiBwcm9qZWN0LnNuYXBzaG90czsgfVxuIl0sIm1hcHBpbmdzIjoiQUFFQSxTQUFTQSxlQUFlLEVBQUNDLHNCQUFzQixRQUE4QixTQUFTO0FBQ3RGLFNBQVNDLDBCQUEwQixRQUFRLDhCQUE4QjtBQUN6RSxTQUFTQywwQkFBMEIsUUFBUSwyQkFBMkI7QUFDdEUsU0FBU0MscUJBQXFCLFFBQVEsbUJBQW1CO0FBQ3pELFNBQVNDLG1CQUFtQixRQUFRLFNBQVM7QUFDN0MsU0FBU0MsaUJBQWlCLFFBQVEsOEJBQThCO0FBQ2hFLFNBQVNDLGFBQWEsUUFBUSxpQkFBaUI7QUFDL0MsU0FBU0MsNEJBQTRCLEVBQUVDLHlCQUF5QixFQUFFQyxrQkFBa0IsRUFBRUMsbUJBQW1CLFFBQVEsZ0JBQWdCO0FBR2pJLFNBQVNDLGdCQUFnQkEsQ0FBQ0MsS0FBbUIsRUFBZTtFQUMxRCxPQUFPO0lBQUUsR0FBR0EsS0FBSztJQUFFQyxPQUFPLEVBQUU7RUFBRyxDQUFDO0FBQ2xDO0FBRUEsU0FBU0MsVUFBVUEsQ0FBSUMsUUFBc0IsRUFBRUMsSUFBa0IsRUFBVztFQUMxRSxPQUFPQSxJQUFJLENBQUNDLE1BQU0sSUFBSUYsUUFBUSxDQUFDRSxNQUFNLElBQUlGLFFBQVEsQ0FBQ0csS0FBSyxDQUFDLENBQUNDLElBQUksRUFBRUMsS0FBSyxLQUFLZCxhQUFhLENBQUNhLElBQUksQ0FBQyxLQUFLYixhQUFhLENBQUNVLElBQUksQ0FBQ0ksS0FBSyxDQUFDLENBQUMsQ0FBQztBQUM5SDs7QUFFQTtBQUNBLFNBQVNDLHVCQUF1QkEsQ0FBQ0MsT0FBb0IsRUFBcUI7RUFBQSxJQUFBQyxTQUFBO0VBQ3hFLE1BQU1DLE1BQXlCLEdBQUcsRUFBRTtFQUNwQyxNQUFNQyxXQUFXLEdBQUcsSUFBSUMsR0FBRyxDQUE2QixDQUFDO0lBQUVDLFdBQVcsR0FBRyxJQUFJRCxHQUFHLENBQWtDLENBQUM7RUFDbkgsTUFBTUUsa0JBQWtCLEdBQUcsSUFBSUYsR0FBRyxDQUFpQixDQUFDO0VBQ3BELE1BQU1HLFNBQVMsR0FBRyxJQUFJSCxHQUFHLENBQXdELENBQUM7RUFDbEYsTUFBTUksV0FBVyxHQUFJQyxHQUFXLElBQUs7SUFBRSxJQUFJQyxRQUFRLEdBQUdILFNBQVMsQ0FBQ0ksR0FBRyxDQUFDRixHQUFHLENBQUM7SUFBRSxJQUFJLENBQUNDLFFBQVEsRUFBRTtNQUFFQSxRQUFRLEdBQUcsRUFBRTtNQUFFSCxTQUFTLENBQUNLLEdBQUcsQ0FBQ0gsR0FBRyxFQUFFQyxRQUFRLENBQUM7SUFBRTtJQUFFLE9BQU9BLFFBQVE7RUFBRSxDQUFDO0VBQzVKLE1BQU1HLEtBQUssR0FBR0wsV0FBVyxDQUFDLE9BQU8sQ0FBQztFQUNsQyxNQUFNTSxVQUFVLEdBQUdkLE9BQU8sQ0FBQ1QsT0FBTyxDQUFDd0IsU0FBUyxDQUFDQyxPQUFPLElBQUksQ0FBRUEsT0FBTyxDQUFpREMsWUFBWSxDQUFDO0VBQy9ILElBQUlILFVBQVUsSUFBSSxDQUFDLEVBQUVELEtBQUssQ0FBQ0ssSUFBSSxDQUFDO0lBQUVDLEtBQUssRUFBRSxtQkFBbUJMLFVBQVUsVUFBVTtJQUFFeEIsS0FBSyxFQUFFVSxPQUFPLENBQUNULE9BQU8sQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFFTTtFQUFPLENBQUMsQ0FBQztFQUMvSCxLQUFLLE1BQU0sQ0FBQ3RCLEtBQUssRUFBRWtCLE9BQU8sQ0FBQyxJQUFJaEIsT0FBTyxDQUFDVCxPQUFPLENBQUM4QixPQUFPLENBQUMsQ0FBQyxFQUFFO0lBQ3hELE1BQU1KLFlBQVksR0FBSUQsT0FBTyxDQUF1RUMsWUFBWTtJQUNoSCxNQUFNUixHQUFHLEdBQUdRLFlBQVksR0FBRyxVQUFVQSxZQUFZLENBQUNLLGlCQUFpQixFQUFFLEdBQUcsT0FBTztJQUMvRSxNQUFNWixRQUFRLEdBQUdGLFdBQVcsQ0FBQ0MsR0FBRyxDQUFDO0lBQ2pDLElBQUlRLFlBQVksSUFBSSxDQUFDUCxRQUFRLENBQUNmLE1BQU0sRUFBRWUsUUFBUSxDQUFDUSxJQUFJLENBQUM7TUFBRUMsS0FBSyxFQUFFLG1CQUFtQnJCLEtBQUssVUFBVTtNQUFFUixLQUFLLEVBQUUwQixPQUFPLENBQUNJO0lBQU8sQ0FBQyxDQUFDO0lBQ3pIVixRQUFRLENBQUNRLElBQUksQ0FBQztNQUFFQyxLQUFLLEVBQUUsbUJBQW1CckIsS0FBSyxTQUFTO01BQUVSLEtBQUssRUFBRTBCLE9BQU8sQ0FBQ087SUFBTSxDQUFDLENBQUM7RUFDbkY7RUFDQSxNQUFNQyxPQUFPLEdBQUd4QixPQUFrQztFQUNsRCxJQUFJLENBQUNhLEtBQUssQ0FBQ2xCLE1BQU0sSUFBSSxFQUFBTSxTQUFBLEdBQUFZLEtBQUssQ0FBQ1ksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQUF4QixTQUFBLHVCQUFaQSxTQUFBLENBQWNYLEtBQUssQ0FBQ29DLFFBQVEsTUFBSzFCLE9BQU8sQ0FBQzBCLFFBQVEsRUFBRWIsS0FBSyxDQUFDSyxJQUFJLENBQUM7SUFBRUMsS0FBSyxFQUFFLFNBQVM7SUFBRTdCLEtBQUssRUFBRWtDO0VBQVEsQ0FBQyxDQUFDO0VBRXhILEtBQUssTUFBTWQsUUFBUSxJQUFJSCxTQUFTLENBQUNvQixNQUFNLENBQUMsQ0FBQyxFQUFFO0lBQ3pDLElBQUlDLFlBQVksR0FBRyxJQUFJeEIsR0FBRyxDQUE0QixDQUFDO0lBQ3ZELEtBQUssTUFBTTtNQUFFZSxLQUFLO01BQUU3QjtJQUFNLENBQUMsSUFBSW9CLFFBQVEsRUFBRTtNQUFBLElBQUFtQixxQkFBQTtNQUN6QyxNQUFNQyxXQUFXLEdBQUcsSUFBSTFCLEdBQUcsQ0FBQyxFQUFBeUIscUJBQUEsR0FBQ3ZDLEtBQUssQ0FBQ3lDLGtCQUFrQixjQUFBRixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUUsRUFBRUcsR0FBRyxDQUFDQyxXQUFXLElBQUksQ0FBQ0EsV0FBVyxDQUFDQyxFQUFFLEVBQUVELFdBQVcsQ0FBQyxDQUFDLENBQUM7TUFDL0csS0FBSyxNQUFNLENBQUNDLEVBQUUsRUFBRXpDLFFBQVEsQ0FBQyxJQUFJbUMsWUFBWSxFQUFFO1FBQ3pDLE1BQU1sQyxJQUFJLEdBQUdvQyxXQUFXLENBQUNuQixHQUFHLENBQUN1QixFQUFFLENBQUM7UUFDaEMsSUFBSSxDQUFDeEMsSUFBSSxFQUFFO1VBQUVRLE1BQU0sQ0FBQ2dCLElBQUksQ0FBQztZQUFFaUIsSUFBSSxFQUFFLGtCQUFrQjtZQUFFQyxJQUFJLEVBQUUsR0FBR2pCLEtBQUsscUJBQXFCO1lBQUVrQixPQUFPLEVBQUUsYUFBYUgsRUFBRTtVQUFpQixDQUFDLENBQUM7VUFBRTtRQUFVO1FBQ2pKLElBQUksQ0FBQzFDLFVBQVUsQ0FBQ0MsUUFBUSxDQUFDNkMsUUFBUSxFQUFFNUMsSUFBSSxDQUFDNEMsUUFBUSxDQUFDLEVBQUVwQyxNQUFNLENBQUNnQixJQUFJLENBQUM7VUFBRWlCLElBQUksRUFBRSxrQkFBa0I7VUFBRUMsSUFBSSxFQUFFLEdBQUdqQixLQUFLLHVCQUF1QmUsRUFBRSxXQUFXO1VBQUVHLE9BQU8sRUFBRTtRQUFzQixDQUFDLENBQUM7UUFDaEwsSUFBSSxDQUFDN0MsVUFBVSxDQUFDQyxRQUFRLENBQUM4QyxhQUFhLEVBQUU3QyxJQUFJLENBQUM2QyxhQUFhLENBQUMsRUFBRXJDLE1BQU0sQ0FBQ2dCLElBQUksQ0FBQztVQUFFaUIsSUFBSSxFQUFFLGtCQUFrQjtVQUFFQyxJQUFJLEVBQUUsR0FBR2pCLEtBQUssdUJBQXVCZSxFQUFFLGdCQUFnQjtVQUFFRyxPQUFPLEVBQUU7UUFBc0IsQ0FBQyxDQUFDO01BQ2pNO01BQ0EsS0FBSyxNQUFNSixXQUFXLElBQUlILFdBQVcsQ0FBQ0gsTUFBTSxDQUFDLENBQUMsRUFBRTtRQUFBLElBQUFhLHFCQUFBO1FBQzlDLE1BQU1DLFFBQVEsR0FBR3pELGFBQWEsQ0FBQztVQUFFMEQsU0FBUyxFQUFFVCxXQUFXLENBQUNTLFNBQVM7VUFBRUMsWUFBWSxFQUFFVixXQUFXLENBQUNVLFlBQVk7VUFBRUMsZ0JBQWdCLEdBQUFKLHFCQUFBLEdBQUVQLFdBQVcsQ0FBQ1csZ0JBQWdCLGNBQUFKLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksSUFBSTtVQUMvSkssV0FBVyxFQUFFWixXQUFXLENBQUNZLFdBQVc7VUFBRUMsZUFBZSxFQUFFYixXQUFXLENBQUNhLGVBQWU7VUFBRUMsU0FBUyxFQUFFZCxXQUFXLENBQUNjO1FBQVUsQ0FBQyxDQUFDO1FBQ3pILE1BQU1DLGFBQWEsR0FBRzFDLGtCQUFrQixDQUFDSyxHQUFHLENBQUNzQixXQUFXLENBQUNDLEVBQUUsQ0FBQztRQUM1RCxJQUFJYyxhQUFhLEtBQUtDLFNBQVMsSUFBSUQsYUFBYSxLQUFLUCxRQUFRLEVBQUV2QyxNQUFNLENBQUNnQixJQUFJLENBQUM7VUFBRWlCLElBQUksRUFBRSxrQkFBa0I7VUFBRUMsSUFBSSxFQUFFLEdBQUdqQixLQUFLLHVCQUF1QmMsV0FBVyxDQUFDQyxFQUFFLEVBQUU7VUFBRUcsT0FBTyxFQUFFO1FBQTRCLENBQUMsQ0FBQyxDQUFDLEtBQ2pNL0Isa0JBQWtCLENBQUNNLEdBQUcsQ0FBQ3FCLFdBQVcsQ0FBQ0MsRUFBRSxFQUFFTyxRQUFRLENBQUM7UUFDckQsS0FBSyxNQUFNUyxPQUFPLElBQUlqQixXQUFXLENBQUNLLFFBQVEsRUFBRTtVQUMxQyxNQUFNYSxHQUFHLEdBQUdoRCxXQUFXLENBQUNRLEdBQUcsQ0FBQ3VDLE9BQU8sQ0FBQ2hCLEVBQUUsQ0FBQztVQUN2QyxJQUFJaUIsR0FBRyxJQUFJbkUsYUFBYSxDQUFDbUUsR0FBRyxDQUFDLEtBQUtuRSxhQUFhLENBQUNrRSxPQUFPLENBQUMsRUFBRWhELE1BQU0sQ0FBQ2dCLElBQUksQ0FBQztZQUFFaUIsSUFBSSxFQUFFLGtCQUFrQjtZQUFFQyxJQUFJLEVBQUUsR0FBR2pCLEtBQUssdUJBQXVCYyxXQUFXLENBQUNDLEVBQUUsYUFBYWdCLE9BQU8sQ0FBQ2hCLEVBQUUsRUFBRTtZQUFFRyxPQUFPLEVBQUU7VUFBNEIsQ0FBQyxDQUFDLENBQUMsS0FDbk5sQyxXQUFXLENBQUNTLEdBQUcsQ0FBQ3NDLE9BQU8sQ0FBQ2hCLEVBQUUsRUFBRWdCLE9BQU8sQ0FBQztRQUMzQztRQUNBLEtBQUssTUFBTUUsT0FBTyxJQUFJbkIsV0FBVyxDQUFDTSxhQUFhLEVBQUU7VUFDL0MsTUFBTVksR0FBRyxHQUFHOUMsV0FBVyxDQUFDTSxHQUFHLENBQUN5QyxPQUFPLENBQUNsQixFQUFFLENBQUM7VUFDdkMsSUFBSWlCLEdBQUcsSUFBSW5FLGFBQWEsQ0FBQ21FLEdBQUcsQ0FBQyxLQUFLbkUsYUFBYSxDQUFDb0UsT0FBTyxDQUFDLEVBQUVsRCxNQUFNLENBQUNnQixJQUFJLENBQUM7WUFBRWlCLElBQUksRUFBRSxrQkFBa0I7WUFBRUMsSUFBSSxFQUFFLEdBQUdqQixLQUFLLHVCQUF1QmMsV0FBVyxDQUFDQyxFQUFFLGtCQUFrQmtCLE9BQU8sQ0FBQ2xCLEVBQUUsRUFBRTtZQUFFRyxPQUFPLEVBQUU7VUFBK0IsQ0FBQyxDQUFDLENBQUMsS0FDM05oQyxXQUFXLENBQUNPLEdBQUcsQ0FBQ3dDLE9BQU8sQ0FBQ2xCLEVBQUUsRUFBRWtCLE9BQU8sQ0FBQztRQUMzQztNQUNGO01BQ0V4QixZQUFZLEdBQUdFLFdBQVc7SUFDNUI7RUFDRjtFQUNBLE9BQU81QixNQUFNO0FBQ2Y7QUFFQSxTQUFTbUQsV0FBV0EsQ0FBQ3JELE9BQW9CLEVBQWU7RUFDdEQsTUFBTXNELEdBQUcsR0FBRyxJQUFJQyxHQUFHLENBQVMsQ0FBQ3ZELE9BQU8sQ0FBQzBDLFNBQVMsQ0FBQyxDQUFDO0VBQ2hELEtBQUssTUFBTTdDLElBQUksSUFBSSxDQUFDLEdBQUdHLE9BQU8sQ0FBQ3dELFFBQVEsRUFBRSxHQUFHeEQsT0FBTyxDQUFDeUQsU0FBUyxDQUFDLEVBQUVILEdBQUcsQ0FBQ0ksR0FBRyxDQUFDN0QsSUFBSSxDQUFDcUMsRUFBRSxDQUFDO0VBQ2hGLEtBQUssTUFBTXlCLFFBQVEsSUFBSTNELE9BQU8sQ0FBQzRELFNBQVMsRUFBRTtJQUN4Q04sR0FBRyxDQUFDSSxHQUFHLENBQUNDLFFBQVEsQ0FBQ3pCLEVBQUUsQ0FBQztJQUNwQixLQUFLLE1BQU0yQixNQUFNLElBQUk3RCxPQUFPLENBQUN3RCxRQUFRLEVBQUUsSUFBSUssTUFBTSxDQUFDQyxJQUFJLEtBQUssVUFBVSxJQUFJRCxNQUFNLENBQUMzQixFQUFFLEtBQUt5QixRQUFRLENBQUN6QixFQUFFLEVBQUVvQixHQUFHLENBQUNJLEdBQUcsQ0FBQ0csTUFBTSxDQUFDM0IsRUFBRSxDQUFDO0VBQ3hIO0VBQ0EsS0FBSyxNQUFNbEIsT0FBTyxJQUFJaEIsT0FBTyxDQUFDVCxPQUFPLEVBQUUrRCxHQUFHLENBQUNJLEdBQUcsQ0FBQzFDLE9BQU8sQ0FBQytDLFdBQVcsQ0FBQztFQUNuRSxPQUFPVCxHQUFHO0FBQ1o7QUFFQSxlQUFlVSxpQkFBaUJBLENBQUNoRSxPQUFvQixFQUFFaUUsaUJBQTJDLEVBQUU3QixJQUFZLEVBQUU4QixXQUFtQyxFQUE4QjtFQUFBLElBQUFDLHFCQUFBO0VBQ2pMLE1BQU1qRSxNQUF5QixHQUFHLEVBQUU7RUFDcEMsTUFBTTBELFNBQVMsR0FBRzVELE9BQU8sQ0FBQzRELFNBQVM7RUFDbkMsTUFBTVEsWUFBWSxHQUFHLE1BQU16RiwwQkFBMEIsQ0FBQ3FCLE9BQU8sQ0FBQzBDLFNBQVMsR0FBQXlCLHFCQUFBLEdBQUVuRSxPQUFPLENBQUMrQixrQkFBa0IsY0FBQW9DLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFO0lBQ3pHRSxXQUFXLEVBQUUsSUFBSWQsR0FBRyxDQUFDSyxTQUFTLENBQUM1QixHQUFHLENBQUMyQixRQUFRLElBQUlBLFFBQVEsQ0FBQ3pCLEVBQUUsQ0FBQyxDQUFDO0lBQUUwQixTQUFTO0lBQUVQLFdBQVcsRUFBRUEsV0FBVyxDQUFDckQsT0FBTyxDQUFDO0lBQzFHc0UsZUFBZSxFQUFFLE1BQU9DLE9BQXVCLElBQUs7TUFBQSxJQUFBQyxxQkFBQTtNQUNsRCxNQUFNQyxTQUFTLEdBQUcsTUFBTXRGLGtCQUFrQixDQUFDb0YsT0FBTyxHQUFBQyxxQkFBQSxHQUFFUCxpQkFBaUIsQ0FBQ1MsY0FBYyxjQUFBRixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsQ0FBQyxFQUFFLEdBQUdwQyxJQUFJLHFDQUFxQyxFQUFFOEIsV0FBVyxDQUFDO01BQ3RKLE1BQU1TLE1BQU0sR0FBR2xHLGVBQWUsQ0FBQztRQUFFLEdBQUc4RixPQUFPO1FBQUVYLFNBQVM7UUFBRXJFLE9BQU8sRUFBRTtNQUFHLENBQUMsRUFBRTBFLGlCQUFpQixDQUFDO01BQ3pGLE9BQU9VLE1BQU0sQ0FBQ0MsRUFBRSxJQUFJLENBQUNILFNBQVMsQ0FBQzlFLE1BQU0sR0FBRztRQUFFaUYsRUFBRSxFQUFFO01BQUssQ0FBQyxHQUFHO1FBQUVBLEVBQUUsRUFBRSxLQUFLO1FBQUUxRSxNQUFNLEVBQUUsQ0FBQyxHQUFHdUUsU0FBUyxFQUFFLElBQUksQ0FBQ0UsTUFBTSxDQUFDQyxFQUFFLEdBQUdELE1BQU0sQ0FBQ3pFLE1BQU0sR0FBRyxFQUFFLENBQUM7TUFBRSxDQUFDO0lBQ3BJO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsS0FBSyxNQUFNMkUsS0FBSyxJQUFJVCxZQUFZLEVBQUVsRSxNQUFNLENBQUNnQixJQUFJLENBQUM7SUFBRWlCLElBQUksRUFBRSxrQkFBa0I7SUFBRUMsSUFBSSxFQUFFLEdBQUdBLElBQUksSUFBSXlDLEtBQUssQ0FBQ3pDLElBQUksRUFBRTtJQUFFQyxPQUFPLEVBQUV3QyxLQUFLLENBQUN4QztFQUFRLENBQUMsQ0FBQztFQUNsSSxPQUFPbkMsTUFBTTtBQUNmO0FBRUEsZUFBZTRFLGtCQUFrQkEsQ0FBQzlFLE9BQW9CLEVBQUVpRSxpQkFBMkMsRUFBRUMsV0FBbUMsRUFBOEI7RUFDcEssTUFBTWhFLE1BQXlCLEdBQUcsRUFBRTtFQUNwQyxLQUFLLE1BQU0sQ0FBQ0osS0FBSyxFQUFFK0QsTUFBTSxDQUFDLElBQUk3RCxPQUFPLENBQUN3RCxRQUFRLENBQUNuQyxPQUFPLENBQUMsQ0FBQyxFQUFFO0lBQ3hELElBQUl3QyxNQUFNLENBQUNDLElBQUksS0FBSyxPQUFPLEVBQUU7SUFDN0IsTUFBTWlCLFFBQVEsR0FBRyxvQkFBb0JqRixLQUFLLFFBQVE7SUFDbEQsTUFBTWtGLFVBQVUsR0FBR2hGLE9BQU8sQ0FBQ3dELFFBQVEsQ0FBQ3lCLElBQUksQ0FBQ0MsU0FBUyxJQUFJQSxTQUFTLENBQUNoRCxFQUFFLEtBQUsyQixNQUFNLENBQUNzQixJQUFJLENBQUNDLGlCQUFpQixJQUFJRixTQUFTLENBQUNwQixJQUFJLEtBQUssWUFBWSxDQUFDO0lBQ3hJLElBQUksQ0FBQ2tCLFVBQVUsSUFBSUEsVUFBVSxDQUFDbEIsSUFBSSxLQUFLLFlBQVksRUFBRTtNQUNuRDVELE1BQU0sQ0FBQ2dCLElBQUksQ0FBQztRQUFFaUIsSUFBSSxFQUFFLG1CQUFtQjtRQUFFQyxJQUFJLEVBQUUsR0FBRzJDLFFBQVEsb0JBQW9CO1FBQUUxQyxPQUFPLEVBQUU7TUFBbUIsQ0FBQyxDQUFDO01BQzlHO0lBQ0Y7SUFDQSxJQUFJO01BQ0YsTUFBTWtDLE9BQU8sR0FBRyxNQUFNMUYscUJBQXFCLENBQUNtQixPQUFPLEVBQUU2RCxNQUFNLENBQUNzQixJQUFJLENBQUNFLGdCQUFnQixFQUFFcEIsaUJBQWlCLEVBQUVDLFdBQVcsQ0FBQztNQUNsSCxJQUFJTCxNQUFNLENBQUNzQixJQUFJLENBQUNHLElBQUksS0FBSyxVQUFVLEVBQUVwRixNQUFNLENBQUNnQixJQUFJLENBQUMsR0FBR3RDLDBCQUEwQixDQUFDMkYsT0FBTyxFQUFFVixNQUFNLENBQUNzQixJQUFJLEVBQUVILFVBQVUsQ0FBQ0csSUFBSSxFQUFFSixRQUFRLEVBQUVkLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUMvSTtRQUFBLElBQUFzQixzQkFBQTtRQUNILE1BQU07VUFBRUM7UUFBaUIsQ0FBQyxHQUFHLE1BQU0sTUFBTSxDQUFDLFdBQVcsQ0FBQztRQUN0RCxNQUFNQyxPQUFPLEdBQUdyRyxtQkFBbUIsQ0FBQ04sbUJBQW1CLENBQUN5RixPQUFPLEVBQUVBLE9BQU8sQ0FBQ1gsU0FBUyxDQUFDLEdBQUEyQixzQkFBQSxHQUFFdEIsaUJBQWlCLENBQUNTLGNBQWMsY0FBQWEsc0JBQUEsY0FBQUEsc0JBQUEsR0FBSSxDQUFDLENBQUMsQ0FBQztRQUM1SCxNQUFNRyxNQUFNLEdBQUdGLGdCQUFnQixDQUFDeEYsT0FBTyxFQUFFNkQsTUFBTSxDQUFDM0IsRUFBRSxFQUFFdUQsT0FBTyxDQUFDRSxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsS0FBSyxJQUFJQSxLQUFLLENBQUNyQyxRQUFRLENBQUMsQ0FBQztRQUNwRyxJQUFJa0MsTUFBTSxDQUFDSSxNQUFNLEtBQUssT0FBTyxFQUFFNUYsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLEdBQUd3RSxNQUFNLENBQUN4RixNQUFNLENBQUM4QixHQUFHLENBQUM2QyxLQUFLLEtBQUs7VUFBRSxHQUFHQSxLQUFLO1VBQUV6QyxJQUFJLEVBQUUsR0FBRzJDLFFBQVEsSUFBSUYsS0FBSyxDQUFDekMsSUFBSTtRQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDOUg7SUFDRixDQUFDLENBQUMsT0FBTzJELEtBQUssRUFBRTtNQUNkLE1BQU1DLEtBQUssR0FBSUQsS0FBSyxDQUFvQzdGLE1BQU07TUFDOUQsSUFBSThGLEtBQUssYUFBTEEsS0FBSyxlQUFMQSxLQUFLLENBQUVyRyxNQUFNLEVBQUVPLE1BQU0sQ0FBQ2dCLElBQUksQ0FBQyxHQUFHOEUsS0FBSyxDQUFDaEUsR0FBRyxDQUFDNkMsS0FBSyxLQUFLO1FBQUUsR0FBR0EsS0FBSztRQUFFekMsSUFBSSxFQUFFLEdBQUcyQyxRQUFRLElBQUlGLEtBQUssQ0FBQ3pDLElBQUk7TUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FDcEdsQyxNQUFNLENBQUNnQixJQUFJLENBQUM7UUFBRWlCLElBQUksRUFBRSxrQkFBa0I7UUFBRUMsSUFBSSxFQUFFLEdBQUcyQyxRQUFRLG1CQUFtQjtRQUFFMUMsT0FBTyxFQUFFMEQsS0FBSyxZQUFZRSxLQUFLLEdBQUdGLEtBQUssQ0FBQzFELE9BQU8sR0FBRztNQUF1QixDQUFDLENBQUM7SUFDaEs7RUFDRjtFQUNBLE9BQU9uQyxNQUFNO0FBQ2Y7O0FBRUE7QUFDQSxPQUFPLGVBQWVnRyx3QkFBd0JBLENBQUNDLEtBQWtCLEVBQUVDLE9BQWlDLEdBQUcsQ0FBQyxDQUFDLEVBQUVDLHFCQUFxQixHQUFHRixLQUFLLENBQUM1RyxPQUFPLENBQUNJLE1BQU0sR0FBRyxDQUFDLEVBQUUyRyxlQUFvRixFQUE4QjtFQUFBLElBQUFDLHNCQUFBO0VBQzdRLElBQUk7SUFBQSxJQUFBQyxxQkFBQTtJQUFDLE1BQU07TUFBQ0M7SUFBd0IsQ0FBQyxHQUFDLE1BQU0sTUFBTSxDQUFDLGdCQUFnQixDQUFDO0lBQUMsTUFBTUEsd0JBQXdCLENBQUNOLEtBQUssR0FBQUsscUJBQUEsR0FBQ0osT0FBTyxDQUFDMUIsY0FBYyxjQUFBOEIscUJBQUEsY0FBQUEscUJBQUEsR0FBRSxDQUFDLENBQUMsQ0FBQztFQUFDLENBQUMsUUFBTVQsS0FBSyxFQUFDO0lBQUMsT0FBTyxDQUFDO01BQUM1RCxJQUFJLEVBQUMsa0JBQWtCO01BQUNDLElBQUksRUFBQyxpQ0FBaUM7TUFBQ0MsT0FBTyxFQUFFMEQsS0FBSyxDQUFXMUQ7SUFBTyxDQUFDLENBQUM7RUFBQztFQUMvUDtFQUNBO0VBQ0EsTUFBTTZCLFdBQVcsR0FBR2pGLDRCQUE0QixDQUFDLENBQUM7RUFDbEQsTUFBTWdGLGlCQUFpQixHQUFHO0lBQUUsR0FBR21DLE9BQU87SUFBRTFCLGNBQWMsRUFBRXhGLHlCQUF5QixFQUFBcUgsc0JBQUEsR0FBQ0gsT0FBTyxDQUFDMUIsY0FBYyxjQUFBNkIsc0JBQUEsY0FBQUEsc0JBQUEsR0FBSSxDQUFDLENBQUMsRUFBRXJDLFdBQVcsQ0FBQztJQUFFeUIsTUFBTSxFQUFFUyxPQUFPLENBQUNULE1BQU0sR0FBR2UsZUFBZSxDQUFDTixPQUFPLENBQUNULE1BQU0sQ0FBQyxHQUFHMUM7RUFBVSxDQUFDO0VBQ3BNO0VBQ0E7RUFDQTtFQUNBLE1BQU0wRCxVQUFVLEdBQUdMLGVBQWUsSUFBRSxDQUFDRCxxQkFBcUIsSUFBRSxDQUFDRixLQUFLLENBQUM1RyxPQUFPLENBQUNJLE1BQU0sR0FDOUVqQixzQkFBc0IsQ0FBQ3lILEtBQUssRUFBQ2xDLGlCQUFpQixFQUFDcUMsZUFBZSxDQUFDLEdBQUM3SCxlQUFlLENBQUMwSCxLQUFLLEVBQUVsQyxpQkFBaUIsQ0FBQztFQUM1RyxJQUFJLENBQUMwQyxVQUFVLENBQUMvQixFQUFFLEVBQUUsT0FBTytCLFVBQVUsQ0FBQ3pHLE1BQU07RUFDNUMsTUFBTUEsTUFBeUIsR0FBRyxFQUFFO0VBQ3BDLE1BQU0wRyxhQUFhLEdBQUNBLENBQUN4RixNQUE4QixFQUFDRyxLQUE2QixFQUFDYSxJQUFXLEtBQUc7SUFDOUYsTUFBTWUsR0FBRyxHQUFDLElBQUkvQyxHQUFHLENBQUNnQixNQUFNLENBQUN5RixNQUFNLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDaEQsSUFBSSxLQUFHLFFBQVEsSUFBRWdELENBQUMsQ0FBQzNCLElBQUksQ0FBQzRCLFlBQVksQ0FBQyxDQUFDL0UsR0FBRyxDQUFDOEUsQ0FBQyxJQUFFLENBQUNBLENBQUMsQ0FBQzVFLEVBQUUsRUFBQzRFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDNUYsS0FBSSxNQUFNakQsTUFBTSxJQUFJdEMsS0FBSyxFQUFDO01BQUEsSUFBQXlGLHFCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLHFCQUFBO01BQUMsTUFBTUMsS0FBSyxHQUFDaEUsR0FBRyxDQUFDeEMsR0FBRyxDQUFDa0QsTUFBTSxDQUFDM0IsRUFBRSxDQUFDO01BQUMsSUFBRzJCLE1BQU0sQ0FBQ0MsSUFBSSxLQUFHLFFBQVEsSUFBRSxDQUFBcUQsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUVyRCxJQUFJLE1BQUcsUUFBUSxFQUFDO01BQzFHLElBQUc5RSxhQUFhLENBQUNtSSxLQUFLLENBQUNoQyxJQUFJLENBQUM0QixZQUFZLENBQUMsS0FBRy9ILGFBQWEsRUFBQWdJLHFCQUFBLEdBQUNuRCxNQUFNLENBQUNzQixJQUFJLENBQUM0QixZQUFZLGNBQUFDLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUUsSUFBSSxDQUFDLEVBQUM5RyxNQUFNLENBQUNnQixJQUFJLENBQUM7UUFBQ2lCLElBQUksRUFBQyxrQkFBa0I7UUFBQ0MsSUFBSSxFQUFDLEdBQUdBLElBQUksSUFBSXlCLE1BQU0sQ0FBQzNCLEVBQUUsb0JBQW9CO1FBQUNHLE9BQU8sRUFBQztNQUE2QyxDQUFDLENBQUM7TUFDcE8sSUFBR3JELGFBQWEsQ0FBQyxDQUFDbUksS0FBSyxDQUFDaEMsSUFBSSxDQUFDaUMsTUFBTSxFQUFDRCxLQUFLLENBQUNoQyxJQUFJLENBQUNrQyxlQUFlLEdBQUFKLHFCQUFBLEdBQUNFLEtBQUssQ0FBQ2hDLElBQUksQ0FBQ21DLFVBQVUsY0FBQUwscUJBQUEsY0FBQUEscUJBQUEsR0FBRSxJQUFJLENBQUMsQ0FBQyxLQUFHakksYUFBYSxDQUFDLENBQUM2RSxNQUFNLENBQUNzQixJQUFJLENBQUNpQyxNQUFNLEVBQUN2RCxNQUFNLENBQUNzQixJQUFJLENBQUNrQyxlQUFlLEdBQUFILHFCQUFBLEdBQUNyRCxNQUFNLENBQUNzQixJQUFJLENBQUNtQyxVQUFVLGNBQUFKLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUUsSUFBSSxDQUFDLENBQUMsRUFBQ2hILE1BQU0sQ0FBQ2dCLElBQUksQ0FBQztRQUFDaUIsSUFBSSxFQUFDLGtCQUFrQjtRQUFDQyxJQUFJLEVBQUMsR0FBR0EsSUFBSSxJQUFJeUIsTUFBTSxDQUFDM0IsRUFBRSxjQUFjO1FBQUNHLE9BQU8sRUFBQztNQUE0QyxDQUFDLENBQUM7TUFDL1QsSUFBRzhFLEtBQUssQ0FBQ2hDLElBQUksQ0FBQ29DLEtBQUssS0FBRyxNQUFNLElBQUUxRCxNQUFNLENBQUNzQixJQUFJLENBQUNvQyxLQUFLLEtBQUcsVUFBVSxFQUFDckgsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDO1FBQUNpQixJQUFJLEVBQUMsa0JBQWtCO1FBQUNDLElBQUksRUFBQyxHQUFHQSxJQUFJLElBQUl5QixNQUFNLENBQUMzQixFQUFFLGFBQWE7UUFBQ0csT0FBTyxFQUFDO01BQTRCLENBQUMsQ0FBQztJQUNqTDtFQUNGLENBQUM7RUFDRCxJQUFHaUUsZUFBZSxFQUFDTSxhQUFhLENBQUNOLGVBQWUsQ0FBQzdHLFFBQVEsQ0FBQytELFFBQVEsRUFBQzJDLEtBQUssQ0FBQzNDLFFBQVEsRUFBQyxrQkFBa0IsQ0FBQztFQUNyRyxLQUFJLE1BQU0sQ0FBQzFELEtBQUssRUFBQ2tCLE9BQU8sQ0FBQyxJQUFHbUYsS0FBSyxDQUFDNUcsT0FBTyxDQUFDOEIsT0FBTyxDQUFDLENBQUMsRUFBQ3VGLGFBQWEsQ0FBQzVGLE9BQU8sQ0FBQ0ksTUFBTSxDQUFDb0MsUUFBUSxFQUFDeEMsT0FBTyxDQUFDTyxLQUFLLENBQUNpQyxRQUFRLEVBQUMsbUJBQW1CMUQsS0FBSyxrQkFBa0IsQ0FBQztFQUM1SkksTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLElBQUcsTUFBTS9CLGtCQUFrQixDQUFDZ0gsS0FBSyxFQUFFbEMsaUJBQWlCLENBQUNTLGNBQWMsRUFBRSx5QkFBeUIsRUFBRVIsV0FBVyxDQUFDLEVBQUM7RUFDekgsS0FBSyxNQUFNLENBQUNwRSxLQUFLLEVBQUU2RCxRQUFRLENBQUMsSUFBSXdDLEtBQUssQ0FBQ3ZDLFNBQVMsQ0FBQ3ZDLE9BQU8sQ0FBQyxDQUFDLEVBQUVuQixNQUFNLENBQUNnQixJQUFJLENBQUMsSUFBRyxNQUFNL0Isa0JBQWtCLENBQUN3RSxRQUFRLENBQUNZLE9BQU8sRUFBRU4saUJBQWlCLENBQUNTLGNBQWMsRUFBRSxxQkFBcUI1RSxLQUFLLDJCQUEyQixFQUFFb0UsV0FBVyxDQUFDLEVBQUM7RUFDM05oRSxNQUFNLENBQUNnQixJQUFJLENBQUMsSUFBRyxNQUFNOEMsaUJBQWlCLENBQUNtQyxLQUFLLEVBQUVsQyxpQkFBaUIsRUFBRSxTQUFTLEVBQUVDLFdBQVcsQ0FBQyxFQUFDO0VBQ3pGaEUsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLElBQUcsTUFBTTRELGtCQUFrQixDQUFDcUIsS0FBSyxFQUFFbEMsaUJBQWlCLEVBQUVDLFdBQVcsQ0FBQyxFQUFDO0VBQy9FaEUsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLEdBQUduQix1QkFBdUIsQ0FBQ29HLEtBQUssQ0FBQyxDQUFDO0VBQzlDLElBQUlFLHFCQUFxQixFQUFFLEtBQUssTUFBTSxDQUFDbUIsV0FBVyxFQUFFdkYsV0FBVyxDQUFDLElBQUksRUFBQXdGLHFCQUFBLEdBQUN0QixLQUFLLENBQUNwRSxrQkFBa0IsY0FBQTBGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxFQUFFcEcsT0FBTyxDQUFDLENBQUM7SUFBQSxJQUFBb0cscUJBQUE7SUFBRSxLQUFLLE1BQU0sQ0FBQ0MsWUFBWSxFQUFFdEUsT0FBTyxDQUFDLElBQUluQixXQUFXLENBQUNNLGFBQWEsQ0FBQ2xCLE9BQU8sQ0FBQyxDQUFDLEVBQUU7TUFDekwsTUFBTXNHLFdBQVcsR0FBRyw4QkFBOEJILFdBQVcsbUJBQW1CRSxZQUFZLEdBQUc7TUFDL0YsTUFBTTFHLE9BQU8sR0FBR21GLEtBQUssQ0FBQzVHLE9BQU8sQ0FBQzBGLElBQUksQ0FBQ3BGLElBQUksSUFBSUEsSUFBSSxDQUFDNkIsUUFBUSxLQUFLMEIsT0FBTyxDQUFDd0UsZUFBZSxJQUFJL0gsSUFBSSxDQUFDdUIsTUFBTSxDQUFDTSxRQUFRLEtBQUswQixPQUFPLENBQUN5RSxxQkFBcUIsSUFBSXpFLE9BQU8sQ0FBQzBFLE9BQU8sQ0FBQ2xJLEtBQUssQ0FBQ21JLEtBQUssSUFBSTtRQUMvSyxNQUFNM0csTUFBTSxHQUFHckMsaUJBQWlCLENBQUNjLElBQUksQ0FBQ3VCLE1BQU0sRUFBRTJHLEtBQUssQ0FBQztVQUFFeEcsS0FBSyxHQUFHeEMsaUJBQWlCLENBQUNjLElBQUksQ0FBQzBCLEtBQUssRUFBRXdHLEtBQUssQ0FBQztRQUNsRyxNQUFNQyxjQUFjLEdBQUdELEtBQUssQ0FBQzNHLE1BQU0sQ0FBQzZHLE9BQU8sR0FBR0YsS0FBSyxDQUFDM0csTUFBTSxDQUFDOEcsS0FBSyxHQUFHakYsU0FBUztVQUFFa0YsYUFBYSxHQUFHSixLQUFLLENBQUN4RyxLQUFLLENBQUMwRyxPQUFPLEdBQUdGLEtBQUssQ0FBQ3hHLEtBQUssQ0FBQzJHLEtBQUssR0FBR2pGLFNBQVM7UUFDakosT0FBT2pFLGFBQWEsQ0FBQ29DLE1BQU0sYUFBTkEsTUFBTSxjQUFOQSxNQUFNLEdBQUksSUFBSSxDQUFDLEtBQUtwQyxhQUFhLENBQUNnSixjQUFjLGFBQWRBLGNBQWMsY0FBZEEsY0FBYyxHQUFJLElBQUksQ0FBQyxJQUFLNUcsTUFBTSxLQUFLNkIsU0FBUyxLQUFNLENBQUM4RSxLQUFLLENBQUMzRyxNQUFNLENBQUM2RyxPQUFPLElBQzdIakosYUFBYSxDQUFDdUMsS0FBSyxhQUFMQSxLQUFLLGNBQUxBLEtBQUssR0FBSSxJQUFJLENBQUMsS0FBS3ZDLGFBQWEsQ0FBQ21KLGFBQWEsYUFBYkEsYUFBYSxjQUFiQSxhQUFhLEdBQUksSUFBSSxDQUFDLElBQUs1RyxLQUFLLEtBQUswQixTQUFTLEtBQU0sQ0FBQzhFLEtBQUssQ0FBQ3hHLEtBQUssQ0FBQzBHLE9BQU87TUFDOUgsQ0FBQyxDQUFDLENBQUM7TUFDSCxJQUFJLENBQUNqSCxPQUFPLEVBQUU7UUFBRWQsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDO1VBQUVpQixJQUFJLEVBQUUsa0JBQWtCO1VBQUVDLElBQUksRUFBRXVGLFdBQVc7VUFBRXRGLE9BQU8sRUFBRTtRQUE0QixDQUFDLENBQUM7UUFBRTtNQUFVO01BQzlILEtBQUssTUFBTSxDQUFDK0YsVUFBVSxFQUFFTCxLQUFLLENBQUMsSUFBSTNFLE9BQU8sQ0FBQzBFLE9BQU8sQ0FBQ3pHLE9BQU8sQ0FBQyxDQUFDLEVBQUU7UUFDM0QsTUFBTUQsTUFBTSxHQUFHckMsaUJBQWlCLENBQUNpQyxPQUFPLENBQUNJLE1BQU0sRUFBRTJHLEtBQUssQ0FBQztVQUFFeEcsS0FBSyxHQUFHeEMsaUJBQWlCLENBQUNpQyxPQUFPLENBQUNPLEtBQUssRUFBRXdHLEtBQUssQ0FBQztRQUN4RyxNQUFNQyxjQUFjLEdBQUdELEtBQUssQ0FBQzNHLE1BQU0sQ0FBQzZHLE9BQU8sR0FBR0YsS0FBSyxDQUFDM0csTUFBTSxDQUFDOEcsS0FBSyxHQUFHakYsU0FBUztVQUFFa0YsYUFBYSxHQUFHSixLQUFLLENBQUN4RyxLQUFLLENBQUMwRyxPQUFPLEdBQUdGLEtBQUssQ0FBQ3hHLEtBQUssQ0FBQzJHLEtBQUssR0FBR2pGLFNBQVM7UUFDakosSUFBSWpFLGFBQWEsQ0FBQ29DLE1BQU0sYUFBTkEsTUFBTSxjQUFOQSxNQUFNLEdBQUksSUFBSSxDQUFDLEtBQUtwQyxhQUFhLENBQUNnSixjQUFjLGFBQWRBLGNBQWMsY0FBZEEsY0FBYyxHQUFJLElBQUksQ0FBQyxJQUFLNUcsTUFBTSxLQUFLNkIsU0FBUyxLQUFNLENBQUM4RSxLQUFLLENBQUMzRyxNQUFNLENBQUM2RyxPQUFPLEVBQUUvSCxNQUFNLENBQUNnQixJQUFJLENBQUM7VUFBRWlCLElBQUksRUFBRSxrQkFBa0I7VUFBRUMsSUFBSSxFQUFFLEdBQUd1RixXQUFXLFlBQVlTLFVBQVUsVUFBVTtVQUFFL0YsT0FBTyxFQUFFO1FBQTJCLENBQUMsQ0FBQztRQUNyUSxJQUFJckQsYUFBYSxDQUFDdUMsS0FBSyxhQUFMQSxLQUFLLGNBQUxBLEtBQUssR0FBSSxJQUFJLENBQUMsS0FBS3ZDLGFBQWEsQ0FBQ21KLGFBQWEsYUFBYkEsYUFBYSxjQUFiQSxhQUFhLEdBQUksSUFBSSxDQUFDLElBQUs1RyxLQUFLLEtBQUswQixTQUFTLEtBQU0sQ0FBQzhFLEtBQUssQ0FBQ3hHLEtBQUssQ0FBQzBHLE9BQU8sRUFBRS9ILE1BQU0sQ0FBQ2dCLElBQUksQ0FBQztVQUFFaUIsSUFBSSxFQUFFLGtCQUFrQjtVQUFFQyxJQUFJLEVBQUUsR0FBR3VGLFdBQVcsWUFBWVMsVUFBVSxTQUFTO1VBQUUvRixPQUFPLEVBQUU7UUFBMkIsQ0FBQyxDQUFDO01BQ2xRO0lBQ0Y7RUFBQztFQUNELEtBQUssTUFBTSxDQUFDdkMsS0FBSyxFQUFFa0IsT0FBTyxDQUFDLElBQUltRixLQUFLLENBQUM1RyxPQUFPLENBQUM4QixPQUFPLENBQUMsQ0FBQyxFQUFFO0lBQ3RELEtBQUssTUFBTWdILElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBVztNQUFBLElBQUFDLHNCQUFBO01BQy9DLE1BQU1oSixLQUFLLEdBQUcwQixPQUFPLENBQUNxSCxJQUFJLENBQUM7TUFDM0IsTUFBTUUsVUFBVSxHQUFHbEosZ0JBQWdCLENBQUNDLEtBQUssQ0FBQztNQUMxQ1ksTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLElBQUcsTUFBTS9CLGtCQUFrQixDQUFDb0osVUFBVSxFQUFFdEUsaUJBQWlCLENBQUNTLGNBQWMsRUFBRSxtQkFBbUI1RSxLQUFLLEtBQUt1SSxJQUFJLGtCQUFrQixFQUFFbkUsV0FBVyxDQUFDLEVBQUM7TUFDeEosS0FBSyxNQUFNLENBQUNzRSxhQUFhLEVBQUU3RSxRQUFRLENBQUMsSUFBSTRFLFVBQVUsQ0FBQzNFLFNBQVMsQ0FBQ3ZDLE9BQU8sQ0FBQyxDQUFDLEVBQUVuQixNQUFNLENBQUNnQixJQUFJLENBQUMsSUFBRyxNQUFNL0Isa0JBQWtCLENBQUN3RSxRQUFRLENBQUNZLE9BQU8sRUFBRU4saUJBQWlCLENBQUNTLGNBQWMsRUFBRSxtQkFBbUI1RSxLQUFLLEtBQUt1SSxJQUFJLGNBQWNHLGFBQWEsMkJBQTJCLEVBQUV0RSxXQUFXLENBQUMsRUFBQztNQUMxUSxLQUFBb0Usc0JBQUEsR0FBSWhKLEtBQUssQ0FBQ3lDLGtCQUFrQixjQUFBdUcsc0JBQUEsZUFBeEJBLHNCQUFBLENBQTBCM0ksTUFBTSxFQUFFTyxNQUFNLENBQUNnQixJQUFJLENBQUMsSUFBRyxNQUFNOEMsaUJBQWlCLENBQUN1RSxVQUFVLEVBQUV0RSxpQkFBaUIsRUFBRSxtQkFBbUJuRSxLQUFLLEtBQUt1SSxJQUFJLEVBQUUsRUFBRW5FLFdBQVcsQ0FBQyxFQUFDO01BQzlKaEUsTUFBTSxDQUFDZ0IsSUFBSSxDQUFDLElBQUcsTUFBTTRELGtCQUFrQixDQUFDeUQsVUFBVSxFQUFFdEUsaUJBQWlCLEVBQUVDLFdBQVcsQ0FBQyxFQUFDO0lBQ3RGO0VBQ0Y7RUFDQSxPQUFPaEUsTUFBTSxDQUFDdUksS0FBSyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUM7QUFDN0I7O0FBRUE7QUFDQSxPQUFPLGVBQWVDLHNCQUFzQkEsQ0FBQzFJLE9BQW9CLEVBQUVvRyxPQUFpQyxHQUFHLENBQUMsQ0FBQyxFQUFpQjtFQUN4SCxNQUFNbEcsTUFBTSxHQUFHLE1BQU1nRyx3QkFBd0IsQ0FBQ2xHLE9BQU8sRUFBRW9HLE9BQU8sQ0FBQztFQUMvRCxJQUFJbEcsTUFBTSxDQUFDUCxNQUFNLEVBQUUsTUFBTWdKLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUkzQyxLQUFLLENBQUMvRixNQUFNLENBQUM4QixHQUFHLENBQUM2QyxLQUFLLElBQUksR0FBR0EsS0FBSyxDQUFDekMsSUFBSSxLQUFLeUMsS0FBSyxDQUFDeEMsT0FBTyxFQUFFLENBQUMsQ0FBQ3dHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFO0lBQUUzSTtFQUFPLENBQUMsQ0FBQztBQUNsSTtBQUVBLE9BQU8sU0FBUzRJLGdCQUFnQkEsQ0FBQzlJLE9BQW9CLEVBQThCO0VBQUUsT0FBT0EsT0FBTyxDQUFDNEQsU0FBUztBQUFFIiwiaWdub3JlTGlzdCI6W119