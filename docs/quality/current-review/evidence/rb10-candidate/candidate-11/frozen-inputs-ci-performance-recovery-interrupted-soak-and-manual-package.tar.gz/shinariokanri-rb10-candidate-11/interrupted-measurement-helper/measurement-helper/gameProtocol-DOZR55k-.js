import { $ as e, D as t, J as n, K as r, L as i, M as a, W as o, X as s, Z as c, a as l, b as u, x as d } from "./presentation-CmIsivsl.js";
import { startTrial as f, stepTrial as p } from "./runtime-D28rhPhB.js";
import { t as m } from "./exportPreparation-Bk8mriTB.js";
//#region src/domain/runtimeVerified.ts
async function h(e, t, n) {
	let r = structuredClone(e), a = structuredClone(n), s = await l(r, t, { worldSnapshots: a });
	return {
		source: r,
		content: s,
		registry: a,
		referenceEntities: o(i(s, s.snapshots), a).worlds.flatMap((e) => e.entities)
	};
}
async function g(e, t = {}, n = {}) {
	let r = structuredClone(t), i = await h(e, r.contentVersionId ?? e.projectId, n);
	return f(i.source, {
		...r,
		referenceEntities: i.referenceEntities
	});
}
//#endregion
//#region src/domain/portableRuntimeProject.ts
async function _(n) {
	let r = await e(s(n)), i = (e) => `${e.slice(0, 8)}-${e.slice(8, 12)}-4${e.slice(13, 16)}-a${e.slice(17, 20)}-${e.slice(20, 32)}`, o = i(r), c = n.versions ?? [];
	if (c.length > 128 || new Set(c.map((e) => e.id)).size !== c.length || c.some((e) => e.projection.versions?.length)) throw Error("EXPORT_UNSUPPORTED: 公開引用版の上限・重複・依存形式が不正です。");
	let l = [n, ...c.map((e) => e.projection)], f = new Set(l.flatMap((e) => [...e.entities.map((e) => e.id), ...e.relations.map((e) => e.id)]));
	c.forEach((e) => f.add(e.id));
	function p(e) {
		if (Array.isArray(e)) {
			e.forEach(p);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		typeof t.id == "string" && typeof t.text == "string" && typeof t.kind == "string" && f.add(t.id), typeof t.id == "string" && typeof t.eventKey == "string" && f.add(t.id), Object.values(t).forEach(p);
	}
	l.forEach((e) => e.entities.forEach((e) => p(e.data)));
	let m = { "public-project": o };
	for (let t of f) m[t] = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(t) ? t : i(await e(new TextEncoder().encode(`scenario-runtime-1:${t}`)));
	function h(e, t) {
		if (Array.isArray(e)) return e.map((e) => h(e, t));
		if (!e || typeof e != "object") return e;
		let n = e, r = Object.fromEntries(Object.entries(n).map(([e, n]) => [e, ["sourceVersionId", "targetSnapshotId"].includes(e) && n === "public-project" ? t : h(n, t)]));
		return typeof n.id == "string" && f.has(n.id) && (r.id = m[n.id]), Array.isArray(n.links) && (r.links = n.links.map((e) => {
			let n = e;
			return {
				start: n.start,
				end: n.end,
				target: {
					entityId: n.targetId,
					...n.blockId ? { blockId: n.blockId } : {},
					...n.lineId ? { lineId: n.lineId } : {},
					...n.sourceVersionId ? { sourceVersionId: n.sourceVersionId === "public-project" ? t : n.sourceVersionId } : {},
					...n.targetStart === void 0 ? {} : {
						start: n.targetStart,
						end: n.targetEnd
					}
				}
			};
		})), r;
	}
	function g(e, n) {
		let r = d(e.title);
		if (r.projectId = o, r.mainStart = e.mainStart ?? "0", r.calendars[0].id = r.calendarId = "public-calendar-default", r.entities = e.entities.map((e) => {
			let r = h(e.data, n);
			delete r.bytesIncluded;
			let i = u(o, e.kind, e.name, r);
			return i.id = m[e.id], i.createdAt = i.updatedAt = "1970-01-01T00:00:00.000Z", i.status = "confirmed", t(i, m);
		}), r.views = [], r.relations = e.relations.map((e) => ({
			...e,
			id: m[e.id],
			projectId: o,
			fromId: m[e.fromId],
			toId: m[e.toId],
			evidenceIds: e.evidenceIds.map((e) => m[e]),
			revision: "0",
			status: "confirmed",
			visibility: "projection",
			validity: t(u(o, "assertion", "公開関係の期間", {
				subjectId: m[e.fromId],
				predicate: "relation",
				validity: h(e.validity, n) ?? {
					worldRange: null,
					routeCondition: null,
					presentationAnchor: null
				}
			}), m).data.validity
		})), r.worldReferences = [], r.snapshots = [], r.history = [], e.calendars.length) {
			let t = r.calendars[0];
			r.calendars = e.calendars.map((e) => e.kind === "repeating" ? {
				id: e.id,
				name: e.name,
				kind: "repeating",
				originLabel: e.originLabel,
				ticksPerDay: e.ticksPerDay,
				years: e.years ?? []
			} : {
				...t,
				id: e.id,
				name: e.name,
				kind: "gregorian",
				ticksPerDay: e.ticksPerDay
			}), r.calendarId = r.calendars[0].id;
		}
		return r;
	}
	let _ = g(n, o);
	for (let t of c) {
		let { history: n, snapshots: r, authorAlternatives: i, ...a } = g(t.projection, m[t.id]);
		_.snapshots.push({
			id: m[t.id],
			versionLabel: t.projection.title,
			createdAt: "1970-01-01T00:00:00.000Z",
			content: a,
			contentHash: await e(s(a))
		});
	}
	let v = a(_);
	if (!v.ok) throw Object.assign(/* @__PURE__ */ Error("EXPORT_UNSUPPORTED: 公開実行内容を同じstrict契約へ対応できません。"), { issues: v.issues });
	return {
		project: _,
		publicToRuntime: m
	};
}
//#endregion
//#region src/domain/gameEvidence.ts
var v = (e) => {
	throw Error(`INTEGRITY_FAILED: ${e}`);
};
async function y(t, n, r) {
	n = structuredClone(n);
	let i = structuredClone(t), a = structuredClone(r), o = i.snapshots.find((e) => e.id === n.verificationVersionId);
	(!o || await e(s(o.content)) !== o.contentHash) && v("保存したゲーム受領の公開確認版を検証できません。");
	let c = o.content.entities.find((e) => e.id === n.approval.entityId);
	(n.approval.sourceVersionId !== o.id || c?.kind !== "note" || c.visibility !== "private" || c.status !== "confirmed" || c.customValues.gamePackageHash !== n.packageHash || c.customValues.gameReceiptHash !== n.receiptHash) && v("保存したゲーム受領hashが固定承認と一致しません。");
	let l = i.snapshots.find((e) => e.id === n.sourceVersionId)?.content;
	(!l || l.revision !== n.sourceRevision) && v("保存したゲーム受領の対象revisionが一致しません。");
	let u = {
		...structuredClone(o.content),
		snapshots: i.snapshots,
		history: []
	}, d = /* @__PURE__ */ new Map();
	for (let e of n.projectionBindings) {
		let t = d.get(e.editionVersionId);
		t || (t = {}, d.set(e.editionVersionId, t)), t[e.entityId] && t[e.entityId] !== e.publicId && v("保存した公開ID対応が重複しています。"), t[e.entityId] = e.publicId;
	}
	let f = new Map(n.citationBindings.map((e) => [e.sourceVersionId, e.publicVersionId]));
	f.size !== n.citationBindings.length && v("保存した引用版対応が重複しています。");
	let p = (e, t) => {
		if (e.kind !== "projection_profile") return e;
		let r = e.id === n.profileId ? n.sourceVersionId : e.data.sourceVersionId ?? t, i = d.get(r) ?? {}, a = structuredClone(e.data.namePolicy);
		for (let [e, t] of Object.entries(a.byEntityId ?? {})) t.mode === "anonymize" && i[e] && (t.publicId = i[e]);
		return {
			...e,
			data: {
				...e.data,
				publicIds: {
					...e.data.publicIds,
					...i
				},
				namePolicy: a,
				citedVersions: e.data.citedVersions?.map((e) => ({
					...e,
					publicVersionId: f.get(e.sourceVersionId) ?? e.publicVersionId
				}))
			}
		};
	};
	u.entities = u.entities.map((e) => p(e, n.sourceVersionId)), u.snapshots = await Promise.all(u.snapshots.map(async (t) => {
		await e(s(t.content)) !== t.contentHash && v("保存したゲーム受領の元版hashが一致しません。");
		let n = {
			...t.content,
			entities: t.content.entities.map((e) => p(e, t.id))
		};
		return {
			...t,
			content: n,
			contentHash: await e(s(n))
		};
	}));
	let h = [];
	for (let t of n.worldVersions) {
		let n = a[t.sourceVersionId];
		(!n || await e(s(n)) !== t.contentHash) && v("保存したゲーム受領の固定世界hashが一致しません。"), h.push({
			id: t.sourceVersionId,
			content: n,
			contentHash: t.contentHash
		});
	}
	let g = n.sourceVersionId === n.verificationVersionId, y = await m(u, {
		profile: "runtime_json",
		projectionProfileId: n.profileId,
		...g ? { targetRevision: u.revision } : { targetVersionId: n.sourceVersionId },
		worldSnapshots: a,
		worldPins: h
	}), b = Object.entries(y.idMap).filter(([, e]) => y.projection.entities.some((t) => t.id === e));
	(b.length !== n.idMappings.length || b.some(([e, t]) => !n.idMappings.some((r) => r.entityId === e && r.publicId === t && r.sourceVersionId === n.sourceVersionId))) && v("保存したゲーム受領の元ID・公開ID対応が一致しません。");
	for (let e of [y.projection, ...y.projection.versions?.map((e) => e.projection) ?? []]) for (let t of e.entities) t.kind === "attachment" && (t.data.bytesIncluded = !0);
	let x = await _(y.projection);
	return {
		publicProjection: y.projection,
		runtimeProject: x.project,
		publicToRuntime: x.publicToRuntime,
		runtimeProjectHash: await e(s(x.project)),
		entities: y.projection.entities
	};
}
var b = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/, x = (e) => {
	throw Error(`INTEGRITY_FAILED: ${e}`);
};
function S(e) {
	let t = e, n = [
		"format",
		"formatVersion",
		"specification",
		"receiverId",
		"sessionId",
		"receivedAt",
		"packageHash",
		"runtimeProjectHash",
		"entryId",
		"worldTick",
		"actions",
		"requests",
		"finalState",
		"status",
		"mode",
		"dialogueIds",
		"assets",
		"receiptHash"
	], r = /^[a-f0-9]{64}$/;
	(!t || typeof t != "object" || Array.isArray(t) || Object.keys(t).some((e) => !n.includes(e)) || t.format !== "scenario-game-receipt" || t.formatVersion !== "1.0.0" || t.specification !== "scenario-browser-game/1.0.0" || t.receiverId !== "independent-browser-game" || typeof t.sessionId != "string" || !b.test(t.sessionId) || typeof t.entryId != "string" || !b.test(t.entryId) || typeof t.receivedAt != "string" || !Number.isFinite(Date.parse(t.receivedAt)) || ![
		t.packageHash,
		t.runtimeProjectHash,
		t.receiptHash
	].every((e) => typeof e == "string" && r.test(e)) || ![
		"stub",
		"actual",
		"mixed"
	].includes(t.mode) || ![
		"ready",
		"terminal",
		"blocked",
		"unknown",
		"error"
	].includes(t.status) || !t.finalState || typeof t.finalState != "object" || Array.isArray(t.finalState) || t.worldTick != null && (typeof t.worldTick != "string" || !/^(?:0|-[1-9][0-9]*|[1-9][0-9]*)$/.test(t.worldTick)) || !Array.isArray(t.actions) || t.actions.length > 1e4 || !Array.isArray(t.requests) || t.requests.length > 1e4 || !Array.isArray(t.dialogueIds) || t.dialogueIds.some((e) => typeof e != "string") || new Set(t.dialogueIds).size !== t.dialogueIds.length || !Array.isArray(t.assets) || t.assets.some((e) => !e || Object.keys(e).some((e) => !["id", "contentHash"].includes(e)) || typeof e.id != "string" || !r.test(e.contentHash)) || new Set(t.assets.map((e) => e.id)).size !== t.assets.length || s(t).byteLength > 1048576) && x("受領証跡の仕様・構造・上限が不正です。");
	for (let e of t.actions) (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((e) => ![
		"sequence",
		"id",
		"contractId",
		"action",
		"stubIndex",
		"score",
		"value",
		"executedAt",
		"previousHash",
		"hash"
	].includes(e)) || typeof e.id != "string" || !b.test(e.id) || typeof e.contractId != "string" || typeof e.executedAt != "string" || !Number.isFinite(Date.parse(e.executedAt)) || ![
		"win",
		"lose",
		"collect",
		"stub"
	].includes(e.action) || !Number.isSafeInteger(e.score) || !Number.isSafeInteger(e.sequence) || !r.test(e.previousHash) || !r.test(e.hash)) && x("ゲーム実行記録のID・日時・構造が不正です。");
	for (let e of t.requests) (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((e) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(e))) && x("受領証跡の進行要求が未対応です。");
	return t;
}
function C(e) {
	return [...e.publicProjection.entities.filter((e) => e.kind === "attachment").map((e) => ({
		id: e.id,
		data: e.data
	})), ...(e.publicProjection.versions ?? []).flatMap((e) => e.projection.entities.filter((e) => e.kind === "attachment").map((t) => ({
		id: `${e.id}:${t.id}`,
		data: t.data
	})))];
}
function w(e, t) {
	let n = e.runtimeProject.entities.find((n) => n.kind === "external_contract" && n.id === e.publicToRuntime[t]);
	return n || x("受取パッケージに外部契約がありません。"), n;
}
function T(e, t, n, r, i) {
	let a = w(e, t);
	if (n === "stub") {
		let e = a.data.stubValues?.[i ?? -1];
		return e || x("宣言済み仮値がありません。"), {
			score: r,
			value: structuredClone(e)
		};
	}
	a.data.owner !== "game" && x("ゲーム管理以外の外部契約を実測にできません。");
	let o = n === "win" ? r + 3 : n === "collect" ? r + 1 : Math.max(0, r - 1), s;
	if (a.data.outputType === "boolean") s = {
		type: "boolean",
		value: n !== "lose"
	};
	else if (a.data.outputType === "integer") s = {
		type: "integer",
		value: o
	};
	else if (a.data.outputType === "enum") {
		let e = (a.data.stubValues ?? []).filter((e) => e.type === "enum");
		e.length || x("列挙結果の宣言がありません。"), s = structuredClone(e[n === "lose" ? e.length - 1 : n === "win" ? 0 : Math.min(1, e.length - 1)]);
	} else return x("受取例が未対応の結果型です。");
	return {
		score: o,
		value: s
	};
}
function E(e) {
	let t = e.some((e) => e.action === "stub");
	return e.some((e) => e.action !== "stub") ? t ? "mixed" : "actual" : "stub";
}
function D(e, t) {
	return Object.fromEntries(t.map((t) => [e.publicToRuntime[t.contractId], t.value]));
}
async function O(t, r) {
	let i = r.packageHash, a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set();
	for (let [c, l] of r.actions.entries()) {
		(!l || typeof l.id != "string" || !b.test(l.id) || o.has(l.id) || l.sequence !== c + 1 || l.previousHash !== i || typeof l.executedAt != "string" || !Number.isFinite(Date.parse(l.executedAt)) || ![
			"win",
			"lose",
			"collect",
			"stub"
		].includes(l.action)) && x("ゲーム実行記録の順序・ID・日時が不正です。"), o.add(l.id), Object.keys(l).some((e) => ![
			"sequence",
			"id",
			"contractId",
			"action",
			"stubIndex",
			"score",
			"value",
			"executedAt",
			"previousHash",
			"hash"
		].includes(e)) && x("未対応のゲーム実行項目があります。");
		let r = T(t, l.contractId, l.action, a.get(l.contractId) ?? 0, l.stubIndex), { hash: u, ...d } = l;
		(n(r.value) !== n(l.value) || r.score !== l.score || await e(s(d)) !== u) && x("ゲーム処理の実結果・hashが一致しません。"), a.set(l.contractId, l.score), i = u;
	}
	r.mode !== E(r.actions) && x("stub/actual/mixedの表示が実行証跡と一致しません。"), (n(r.dialogueIds) !== n(t.entities.filter((e) => e.kind === "dialogue_line").map((e) => e.id)) || n(r.assets) !== n(C(t).map((e) => ({
		id: e.id,
		contentHash: String(e.data.contentHash)
	})))) && x("台詞・素材ID対応または素材hashが一致しません。");
	let c = await g(t.runtimeProject, {
		entryId: r.entryId,
		worldTick: r.worldTick,
		externalValues: D(t, r.actions)
	});
	for (let e of r.requests) (!e || Object.keys(e).some((e) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(e))) && x("受領証跡の進行要求が未対応です。"), c = p(t.runtimeProject, c, e);
	(n(c.state) !== n(r.finalState) || c.status !== r.status) && x("受取ゲームの経路・最終結果を再生できません。");
}
function k(e) {
	return c(e, "game-receipt.json", {
		...r,
		jsonBytes: 1048576
	});
}
async function A(t, r = {}) {
	let i = (e) => [
		e,
		...e.snapshots.map((e) => e.content),
		...e.history.flatMap((e) => [e.before, e.after]),
		...e.authorAlternatives?.flatMap((e) => [e.baseContent, ...e.versions.map((e) => e.content)]) ?? []
	];
	if (!i(t).some((e) => e.entities.some((e) => e.kind === "note" && e.data.handoffReceipt))) return;
	let a = structuredClone(t), o = structuredClone(r), c = i(a), l = /* @__PURE__ */ new Set();
	for (let t of c) for (let r of t.entities) {
		if (r.kind !== "note" || !r.data.handoffReceipt) continue;
		let t = n(r.data.handoffReceipt);
		if (l.has(t)) continue;
		l.add(t);
		let i = r.data.handoffReceipt, c = S(k(new TextEncoder().encode(i.rawJson))), { receiptHash: u, ...d } = c;
		(await e(s(d)) !== u || u !== i.receiptHash || c.packageHash !== i.packageHash || c.mode !== i.mode || E(c.actions) !== i.mode) && x("保存したゲーム受領のhash・実行分類が元証跡と一致しません。");
		let f = await y(a, i, o), p = f;
		c.runtimeProjectHash !== f.runtimeProjectHash && x("保存したゲーム受領の実行内容が元の固定公開版と一致しません。"), await O(p, c);
	}
}
//#endregion
export { A as verifyStoredGameEvidence };
