import { B as e, F as t, I as n, L as r, N as i, P as a, R as o, S as s, T as c, V as l, d as u, f as d, j as f, l as p, n as m, p as h, r as g, u as _, w as v } from "./presentation-CmIsivsl.js";
//#region src/domain/runtime.ts
var y = (e) => structuredClone(e);
function b(e) {
	if (e === void 0) return "undefined";
	if (typeof e != "object" || !e) return JSON.stringify(e);
	if (Array.isArray(e)) return `[${e.map(b).join(",")}]`;
	let t = e;
	return `{${Object.keys(t).filter((e) => t[e] !== void 0).sort().map((e) => `${JSON.stringify(e)}:${b(t[e])}`).join(",")}}`;
}
var x = (e, t) => b(e) === b(t), S = (e, t, n = "runtime") => ({
	code: e,
	message: t,
	path: n
}), C = (e) => e.filter(l), w = /* @__PURE__ */ new WeakMap(), T = /* @__PURE__ */ new WeakMap(), E = (e) => [...e.entities, ...T.get(e) ?? []], D = (e, t) => {
	let n = w.get(e);
	return n ? n.activeByKind.get(t) ?? [] : C(v(e, t));
}, O = (e, t) => {
	let n = w.get(e);
	return n ? n.byId.get(t) : c(e, t);
}, k = (e) => D(e, "flow_node"), A = (e) => D(e, "flow_edge"), j = (e) => D(e, "variable"), M = (e) => D(e, "flow_graph");
function N(e, t) {
	if (t === e.projectId) return e;
	let n = e.snapshots.find((e) => e.id === t);
	return n ? {
		...n.content,
		snapshots: e.snapshots,
		history: []
	} : void 0;
}
function P(e, t = []) {
	let { authorAlternatives: n, ...i } = e, a = {
		...y({
			...i,
			history: [],
			snapshots: []
		}),
		snapshots: e.snapshots
	}, o = r(a, e.snapshots), s = {
		byId: /* @__PURE__ */ new Map(),
		activeByKind: /* @__PURE__ */ new Map(),
		edgesFrom: /* @__PURE__ */ new Map()
	};
	T.set(o, y(t));
	for (let e of [...o.entities, ...T.get(o) ?? []]) {
		if (e.deletedAt || (s.byId.set(e.id, e), !l(e))) continue;
		let t = s.activeByKind.get(e.kind) ?? [];
		if (t.push(e), s.activeByKind.set(e.kind, t), e.kind === "flow_edge") {
			let t = s.edgesFrom.get(e.data.fromId) ?? [];
			t.push(e), s.edgesFrom.set(e.data.fromId, t);
		}
	}
	return w.set(o, s), o;
}
function F(e, t) {
	return t.content ?? N(e, t.state.contentVersionId) ?? e;
}
var I = (e, t) => {
	let n = t === null ? void 0 : O(e, t);
	return n?.kind === "flow_node" && n.status !== "rejected" ? n : void 0;
}, L = (e, t) => {
	let n = w.get(e);
	return n ? n.edgesFrom.get(t) ?? [] : A(e).filter((e) => e.data.fromId === t);
}, R = (e, t, n, r) => _(n ?? {
	op: "constant",
	value: !0
}, {
	state: t,
	variables: j(e),
	entities: E(e),
	externalValues: r
}), z = (e, t, n) => ({
	...e,
	nodeId: e.state.presentationPosition,
	status: t,
	issues: n
});
function B(e) {
	return e?.data.reuse && e.data.reuse.mode !== "clone" ? S("VALIDATION_FAILED", "共通元を固定版から解決する参照・上書き試読は未対応です。実行を停止しています。", `${e.id}.reuse`) : void 0;
}
function V(e) {
	return e && typeof e == "object" && "issues" in e && Array.isArray(e.issues) ? e.issues : [S("VALIDATION_FAILED", e instanceof Error ? e.message : "試読の入力を検証できません。")];
}
function H(e) {
	e = o(e);
	let t = M(e).filter((t) => t.projectId === e.projectId && !t.data.parentGraphId);
	return t.length > 0 ? [...new Set(t.flatMap((e) => e.data.entryIds))] : k(e).filter((t) => t.projectId === e.projectId && t.data.nodeType === "entry").map((e) => e.id);
}
function U(e) {
	let t = H(e);
	return t.length === 1 ? t[0] : void 0;
}
function W(e, t, n, r, i) {
	return m(e, t, {
		nodeId: n,
		externalValues: r,
		referenceEntities: T.get(e),
		worldTick: i
	});
}
function G(e, t) {
	try {
		return K(e, t);
	} catch {
		return [];
	}
}
function K(e, t) {
	let n = t.content ?? N(e, t.state.contentVersionId);
	if (!n) return [];
	e = n;
	let r = I(e, t.nodeId);
	if (!r || r.data.nodeType === "terminal") return [];
	let i = R(e, t.state, r.data.gate, t.externalValues);
	return L(e, r.id).map((n) => {
		let r = R(e, t.state, n.data.condition, t.externalValues), a = i.value === "false" || r.value === "false" ? "false" : i.value === "unknown" || r.value === "unknown" ? "unknown" : "true";
		return {
			edgeId: n.id,
			label: n.data.label || n.name || "次へ",
			toId: typeof n.data.toId == "string" ? n.data.toId : null,
			result: a,
			reasons: [...i.reasons, ...r.reasons],
			priority: n.data.priority ?? 0
		};
	}).sort((e, t) => e.priority - t.priority);
}
function q(e, t) {
	let n = I(e, t.nodeId);
	if (!n) return z(t, "error", [S("REFERENCE_INVALID", "現在の分岐が存在しません。")]);
	let r = B(n);
	if (r) return z(t, "error", [r]);
	if (n.data.nodeType === "terminal") return n.data.terminalReason?.trim() ? z(t, "terminal", []) : z(t, "error", [S("VALIDATION_FAILED", "終端には終了理由が必要です。", `${n.id}.terminalReason`)]);
	let i = R(e, t.state, n.data.gate, t.externalValues);
	if (i.value === "unknown") return z(t, "unknown", [S("CONDITION_UNKNOWN", i.reasons.join("、") || "発火条件の値が不足しています。", `${n.id}.gate`)]);
	if (i.value === "false") return n.data.fallbackId ? z(t, "ready", []) : z(t, "blocked", [S("TRANSITION_BLOCKED", "発火条件を満たさず、代替の進行先もありません。", `${n.id}.gate`)]);
	if (n.data.nodeType === "call" || n.data.nodeType === "exit" && t.state.callStack.length > 0) return z(t, "ready", []);
	let a = n.data.executionPolicy ?? (n.data.nodeType === "automatic" ? "first_match" : "manual_choice"), o = K(e, t);
	if (o.some((e) => !Number.isSafeInteger(e.priority))) return z(t, "error", [S("VALIDATION_FAILED", "優先値には安全な整数が必要です。", `${n.id}.priority`)]);
	if (a !== "manual_choice" && new Set(o.map((e) => e.priority)).size !== o.length) return z(t, "error", [S("VALIDATION_FAILED", "自動分岐の優先値が重複しています。", `${n.id}.priority`)]);
	let s = o.filter((e) => e.result === "unknown"), c = o.filter((e) => e.result === "true");
	return s.length > 0 && (a !== "manual_choice" || c.length === 0) ? z(t, "unknown", [S("CONDITION_UNKNOWN", "未確認の条件があり、進行先を確定できません。", n.id)]) : c.length === 0 && !n.data.fallbackId ? z(t, "blocked", [S("TRANSITION_BLOCKED", "有効な選択肢がありません。意図した終端とは別の行き止まりです。", n.id)]) : z(t, "ready", []);
}
function J(e, t = {}) {
	try {
		return Y(e, t);
	} catch (n) {
		let r = t.state ? y(t.state) : s(t.contentVersionId ?? e.projectId);
		return {
			content: e,
			state: r,
			nodeId: r.presentationPosition,
			contentRevision: e.revision,
			startState: y(r),
			startConditionResults: [],
			status: "error",
			history: [],
			trace: [],
			issues: V(n),
			lastDiff: [],
			externalValues: {},
			startExternalValues: {}
		};
	}
}
function Y(n, r = {}, o = !1) {
	let s = n, c = r.checkpointId ? s.entities.find((e) => e.id === r.checkpointId && e.kind === "checkpoint") : void 0;
	r.worldTick === void 0 && c?.data.worldTick != null && (r = {
		...r,
		worldTick: c.data.worldTick
	});
	let p = r.contentVersionId ?? n.projectId, m = o ? n : N(n, p);
	m && (n = m), o || (n = P(n, r.referenceEntities));
	let _ = u(n, p, r.referenceEntities, r.externalValues), v = y(r.presentationResults ?? []), b = r.presentationState ? y(r.presentationState) : void 0, C, w, D, k = m && (!n.worldReferences.length || r.referenceEntities) ? void 0 : S("REFERENCE_INVALID", "指定した不変作品版が見つかりません。", "contentVersionId");
	for (let [e, t] of Object.entries(r.externalValues ?? {})) {
		let r = n.entities.find((t) => t.id === e && t.kind === "external_contract" && l(t));
		(!r || r.kind !== "external_contract" || t.type !== r.data.outputType || t.type === "integer" && !Number.isSafeInteger(t.value) || t.type === "enum" && typeof t.value != "string" || t.type === "boolean" && typeof t.value != "boolean") && (k = S("VALIDATION_FAILED", "外部管理値の契約・型・範囲が不正です。", e));
	}
	if (r.worldTick !== void 0 && !t(r.worldTick) && (k = S("VALIDATION_FAILED", "提示時点には整数の世界内tickを入力してください。", "worldTick")), r.checkpointId) {
		let e = O(s, r.checkpointId);
		!e || e.kind !== "checkpoint" || e.deletedAt ? k = S("REFERENCE_INVALID", "指定した途中開始の記録が存在しません。", "checkpointId") : e.data.contentVersionId !== p || e.data.runtimeState.contentVersionId !== p || e.data.contentRevision != null && e.data.contentRevision !== n.revision ? k = S("VALIDATION_FAILED", "開始状態と作品版が違います。移行または再作成が必要です。", `${e.id}.contentVersionId`) : (_ = y(e.data.runtimeState), v = y(e.data.presentationResults ?? []), b = e.data.presentationState ? y(e.data.presentationState) : void 0, _.provenance = _.provenance === "stub" ? "stub" : _.provenance === "imported" || e.data.origin === "imported" ? "imported" : _.provenance === "partial" || e.data.origin !== "full_play" ? "partial" : "full_play", C = e.id, e.data.presentationResults != null && (k = f(_, e.data.presentationResults, n.entities, `${e.id}.presentationResults`)[0]));
	} else r.state && (r.state.contentVersionId === p ? (_ = y(r.state), r.presentationResults != null && (k = f(_, r.presentationResults, n.entities)[0]), _.provenance === "full_play" && (_.provenance = "partial")) : k = S("VALIDATION_FAILED", "指定した開始状態と作品版が違います。", "state.contentVersionId"));
	r.seed !== void 0 && (_.rngSeed = r.seed);
	let A = r.entryId ?? _.presentationPosition ?? U(n);
	if (!k) {
		let t = i(_);
		t.ok || (k = t.issues[0]);
		for (let [e, t] of Object.entries(_.variableValues)) {
			let r = j(n).find((t) => t.id === e), i = r ? a(r, t, `${e}.value`) : [S("REFERENCE_INVALID", "開始状態に対象版の宣言がない状態値があります。", e)];
			if (i.length) {
				k = i[0];
				break;
			}
		}
		let o = g(n, {
			nodeId: A ?? void 0,
			worldTick: r.worldTick
		});
		k ||= h({
			state: _,
			variables: j(n),
			entities: E(n),
			externalValues: r.externalValues,
			ruleContext: o,
			ruleContexts: e(n, o)
		})[0];
	}
	if (C && _.provenance === "full_play") {
		let e = A && H(n).includes(A) ? Y(s, {
			contentVersionId: p,
			entryId: A,
			seed: _.rngSeed,
			externalValues: r.externalValues,
			worldTick: r.worldTick,
			referenceEntities: T.get(n)
		}) : void 0;
		(!e || e.status === "error" || !x(e.startState, _)) && (_.provenance = "partial");
	}
	if (r.entryId && !H(n).includes(r.entryId) && !C && (_.provenance = "partial"), !k && !A && (k = S("VALIDATION_FAILED", "開始点が一つに決まりません。入口を指定してください。", "entryId")), !k && !I(n, A ?? null) && (k = S("REFERENCE_INVALID", "指定した開始点が存在しません。", "entryId")), k ||= B(I(n, A ?? null)), !k && A) {
		if ((C || r.state) && _.presentationPosition && A !== _.presentationPosition && _.provenance !== "stub" && (_.provenance = "partial"), !(C || r.state) || A !== _.presentationPosition || (_.visitCounts[A] ?? 0) === 0 && !_.seenIds.includes(A)) {
			let t = W(n, _, A, r.externalValues, r.worldTick);
			if (t.ok) {
				_ = t.state, v = t.conditions, b = t.observationState;
				let i = I(n, A);
				if (i?.data.nodeType === "terminal") {
					let t = d(_, [
						...i.data.sceneId ? ["scene_end"] : [],
						...g(n, { nodeId: A }).chapterId ? ["chapter_end"] : [],
						"run_end"
					], {
						state: _,
						variables: j(n),
						entities: E(n),
						ruleContext: g(n, {
							nodeId: A,
							worldTick: r.worldTick
						}),
						ruleContexts: e(n, g(n, {
							nodeId: A,
							worldTick: r.worldTick
						}))
					});
					t.ok ? _ = t.state : w = t.issues;
				}
			} else w = t.issues, D = A, _ = {
				..._,
				presentationPosition: A
			};
		} else _.presentationPosition = A;
		r.entryId && !H(n).includes(r.entryId) && !C && (_.provenance = "partial");
	}
	b && (b.provenance = _.provenance);
	let M = {
		content: n,
		referenceEntities: y(T.get(n) ?? []),
		initialWorldTick: r.worldTick,
		declarationProject: y({
			...s,
			history: [],
			snapshots: [],
			authorAlternatives: void 0,
			entities: s.entities.filter((e) => [
				"collection",
				"trace",
				"checkpoint"
			].includes(e.kind))
		}),
		state: _,
		nodeId: _.presentationPosition,
		contentRevision: n.revision,
		startState: y(_),
		startConditionResults: v,
		startPresentationState: b,
		startCheckpointId: C,
		status: "ready",
		history: [],
		trace: [],
		issues: [],
		lastDiff: [],
		externalValues: y(r.externalValues ?? {}),
		startExternalValues: y(r.externalValues ?? {}),
		pendingPresentation: D
	};
	if (k) return z(M, k.code === "CONDITION_UNKNOWN" ? "unknown" : "error", [k]);
	if (r.stub) {
		let e = $(n, M, r.stub), t = e.trace.at(-1)?.presentationState ?? b;
		return {
			...e,
			history: [],
			trace: [],
			startState: y(e.state),
			startStubValues: y(r.stub),
			...r.state || r.checkpointId ? { startStubBaseState: y(M.state) } : {},
			startPresentationState: t ? {
				...y(t),
				provenance: e.state.provenance
			} : void 0,
			startConditionResults: e.trace.at(-1)?.conditionResults.length ? y(e.trace.at(-1).conditionResults) : v,
			startExternalValues: y(e.externalValues)
		};
	}
	return w ? z(M, w.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", w) : q(n, M);
}
function X(e, t) {
	let n = [];
	for (let r of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) {
		let i = e[r], a = t[r];
		if (!x(i, a)) {
			if ((r === "variableValues" || r === "visitCounts") && i && a) {
				let e = i, t = a;
				for (let i of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) x(e[i], t[i]) || n.push({
					path: `${r}.${i}`,
					before: y(e[i]),
					after: y(t[i])
				});
			} else n.push({
				path: r,
				before: y(i),
				after: y(a)
			});
		}
	}
	return n;
}
function ee(e, t) {
	if (!Number.isSafeInteger(t) || t <= 0) throw RangeError("抽選候補は1件以上必要です。");
	if (!Number.isSafeInteger(e.rngPosition) || e.rngPosition < 0 || !Number.isSafeInteger(e.rngPosition + 1)) throw RangeError("抽選位置が許容範囲を超えます。");
	let n = 2166136261, r = `${e.rngSeed}\u0000${e.rngPosition}`;
	for (let e = 0; e < r.length; e++) n = Math.imul(n ^ r.charCodeAt(e), 16777619) >>> 0;
	return n ^= n >>> 16, n = Math.imul(n, 2246822507) >>> 0, n ^= n >>> 13, {
		index: (n >>> 0) % t,
		state: {
			...y(e),
			rngPosition: e.rngPosition + 1
		}
	};
}
function Z(e, t, n) {
	let r = e.data.trigger;
	if (!r) return {
		once: void 0,
		occurrence: void 0
	};
	let i = r.id ?? e.id, a = r.scope ?? "run", o = a === "across_runs" ? a : `${a}:${t.loopNumber}`;
	return {
		once: r.repeat === "once" ? `trigger:${o}:${i}` : void 0,
		occurrence: n.event ? `occurrence:${o}:${i}:${n.event.occurrenceId}` : void 0
	};
}
function te(e, r, i, a) {
	let o = r.data.trigger;
	if (!o) return;
	let s = Z(r, i, a);
	if (s.once && i.onceTriggers.includes(s.once)) return S("TRANSITION_BLOCKED", "この一回限りの発火は実行済みです。", `${r.id}.trigger`);
	if (!a.event || a.event.event !== o.event || a.event.eventKey !== o.eventKey || a.event.triggerId && a.event.triggerId !== (o.id ?? r.id)) return S("TRANSITION_BLOCKED", "宣言したきっかけの入力が必要です。条件の成立だけでは実行しません。", `${r.id}.trigger`);
	if (o.deadline) {
		let i = n(o.deadline, D(e, "event"));
		if (i.status === "conflict") return S("TIME_CONSTRAINT_CONFLICT", i.reason, `${r.id}.trigger.deadline`);
		if (i.status !== "resolved" || !t(a.worldTick) || i.calendarId !== e.calendarId) return S("CONDITION_UNKNOWN", "期限または現在の世界時点を確定できません。", `${r.id}.trigger.deadline`);
		let s = BigInt(a.worldTick), c = BigInt(i.endEarliest), l = BigInt(i.endLatest);
		if (s > l || o.deadline.mode === "interval" && s === l) return S("TRANSITION_BLOCKED", "発火期限を過ぎています。", `${r.id}.trigger.deadline`);
		if (s > c) return S("CONDITION_UNKNOWN", "期限の範囲内に現在時点があり、期限切れか確定できません。", `${r.id}.trigger.deadline`);
	}
}
function ne(e, t, n) {
	let r = [];
	n.data.gate && r.push({
		targetId: n.id,
		...R(e, t.state, n.data.gate, t.externalValues)
	});
	for (let i of L(e, n.id)) i.data.condition && r.push({
		targetId: i.id,
		...R(e, t.state, i.data.condition, t.externalValues)
	});
	return r;
}
function re(t, n, r, i, a, o, s) {
	let c = I(t, n.nodeId), l = I(t, i), u = g(t, { nodeId: c?.id }), f = g(t, { nodeId: i }), p = [];
	c?.data.sceneId && c.data.sceneId !== l?.data.sceneId && p.push("scene_end"), u.chapterId && u.chapterId !== f.chapterId && p.push("chapter_end");
	let m = d({
		...r,
		...r.resetCauses ? { resetCauses: [] } : {}
	}, p, {
		state: r,
		variables: j(t),
		entities: E(t),
		externalValues: n.externalValues,
		ruleContext: g(t, {
			nodeId: c?.id,
			worldTick: o.worldTick
		}),
		ruleContexts: e(t, g(t, {
			nodeId: c?.id,
			worldTick: o.worldTick
		}))
	});
	if (!m.ok) return z(n, "error", m.issues);
	let h = W(t, m.state, i, n.externalValues, o.worldTick);
	if (!h.ok) return z(n, h.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", h.issues);
	let _ = [];
	l?.data.nodeType === "terminal" && (l.data.sceneId && _.push("scene_end"), f.chapterId && _.push("chapter_end"), _.push("run_end"));
	let v = d(h.state, _, {
		state: h.state,
		variables: j(t),
		entities: E(t),
		externalValues: n.externalValues,
		ruleContext: g(t, {
			nodeId: i,
			worldTick: o.worldTick
		}),
		ruleContexts: e(t, g(t, {
			nodeId: i,
			worldTick: o.worldTick
		}))
	});
	if (!v.ok) return z(n, "error", v.issues);
	let b = v.state;
	l?.data.nodeType === "terminal" && (m.state.resetCauses || v.state.resetCauses) && (b.resetCauses = [...m.state.resetCauses ?? [], ...v.state.resetCauses ?? []]), s = [...s, ...h.conditions];
	let x = X(n.state, b).map((e) => ({
		...e,
		edgeIds: a
	})), S = {
		fromId: n.nodeId,
		toId: i,
		edgeIds: a,
		before: y(n.state),
		after: y(b),
		changes: x,
		request: y(o),
		conditionResults: s,
		presentationState: h.observationState,
		triggerId: I(t, n.nodeId)?.data.trigger?.id ?? (I(t, n.nodeId)?.data.trigger ? n.nodeId : void 0),
		externalValuesBefore: y(n.externalValues),
		externalValuesAfter: y(n.externalValues)
	};
	return q(t, {
		...n,
		state: b,
		nodeId: i,
		status: "ready",
		issues: [],
		lastDiff: x,
		history: [...n.history, {
			state: y(n.state),
			status: n.status,
			issues: y(n.issues),
			lastDiff: y(n.lastDiff),
			traceLength: n.trace.length,
			externalValues: y(n.externalValues),
			pendingPresentation: n.pendingPresentation
		}],
		trace: [...n.trace, S]
	});
}
function Q(e, t, n = {}) {
	if (t.status === "error" && t.nodeId === null) return t;
	try {
		return ie(e, t, n);
	} catch (e) {
		return z(t, "error", V(e));
	}
}
function ie(t, n, r = {}) {
	if (r.stub) return $(t, n, r.stub);
	let i = N(t, n.state.contentVersionId);
	if (!i) return z(n, "error", [S("REFERENCE_INVALID", "固定した作品版が存在しません。", "contentVersionId")]);
	if (t = i, n.contentRevision !== t.revision) return z(n, "error", [S("VALIDATION_FAILED", "作品が変更されました。この記録は再確認待ちです。試読を開始し直してください。", "contentRevision")]);
	if (t = n.content, n.pendingPresentation) return z(n, "unknown", n.issues.length ? n.issues : [S("CONDITION_UNKNOWN", "場面の提示条件を先に確認してください。", n.pendingPresentation)]);
	if (n.state.contentVersionId !== n.startState.contentVersionId) return z(n, "error", [S("VALIDATION_FAILED", "試読中に作品版が変わりました。", "contentVersionId")]);
	let a = r.event?.triggerId ?? I(t, n.nodeId)?.data.trigger?.id ?? (I(t, n.nodeId)?.data.trigger ? n.nodeId : void 0);
	if (r.event && a && n.trace.some((e) => e.triggerId === a && e.request.event?.occurrenceId === r.event?.occurrenceId)) return n;
	let o = I(t, n.nodeId);
	if (o && r.event) {
		let e = Z(o, n.state, r).occurrence;
		if (e && n.state.onceTriggers.includes(e)) return n;
	}
	let s = q(t, n);
	if (s.status !== "ready") return s;
	let c = I(t, n.nodeId), l = te(t, c, n.state, r);
	if (l) return z(n, l.code === "CONDITION_UNKNOWN" ? "unknown" : l.code === "TIME_CONSTRAINT_CONFLICT" ? "error" : "blocked", [l]);
	let u = R(t, n.state, c.data.gate, n.externalValues), d = ne(t, n, c), f = y(n.state), m = [], h;
	if (u.value === "false") h = c.data.fallbackId ?? void 0;
	else if (c.data.nodeType === "exit" && f.callStack.length > 0) {
		let e = O(t, f.callStack.at(-1).graphId);
		if (!e || e.kind !== "flow_graph" || !e.data.exitIds.includes(c.id)) return z(n, "error", [S("REFERENCE_INVALID", "現在の出口が呼出中グラフの宣言した出口に含まれていません。", c.id)]);
		h = f.callStack.pop().returnNodeId;
	} else if (c.data.nodeType === "call") {
		let e = c.data.childGraphId ? O(t, c.data.childGraphId) : void 0;
		if (!e || e.kind !== "flow_graph" || e.data.entryIds.length !== 1) return z(n, "error", [S("REFERENCE_INVALID", "呼出先に一つの入口を持つ子グラフが必要です。", `${c.id}.childGraphId`)]);
		let r = L(t, c.id).filter((e) => e.data.edgeType === "call_return");
		if (r.length !== 1 || typeof r[0].data.toId != "string") return z(n, "error", [S("REFERENCE_INVALID", "呼出には一つの確定した戻り先が必要です。", c.id)]);
		let i = R(t, n.state, r[0].data.condition, n.externalValues);
		if (i.value === "unknown") return z(n, "unknown", [S("CONDITION_UNKNOWN", i.reasons.join("、") || "呼出の戻り先条件が未確認です。", r[0].id)]);
		if (i.value === "false") {
			if (!c.data.fallbackId) return z(n, "blocked", [S("TRANSITION_BLOCKED", "呼出の戻り先条件を満たしていません。", r[0].id)]);
			h = c.data.fallbackId;
		} else {
			m = r, h = e.data.entryIds[0];
			let t = {};
			for (let n of e.data.parameters ?? []) t[n.key] = y(n.default ?? {
				type: "unknown",
				value: null,
				reason: "呼出引数が未設定です。"
			});
			f.callStack.push({
				graphId: e.id,
				returnNodeId: r[0].data.toId,
				parameters: t
			});
		}
	} else {
		let e = c.data.executionPolicy ?? (c.data.nodeType === "automatic" ? "first_match" : "manual_choice"), i = G(t, n), a = i.filter((e) => e.result === "true");
		if (a.length === 0) h = c.data.fallbackId ?? void 0;
		else if (e === "manual_choice") {
			let e;
			if (r.random) {
				if (i.some((e) => e.result === "unknown")) return z(n, "unknown", [S("CONDITION_UNKNOWN", "未確認の抽選候補が残っています。", c.id)]);
				let t;
				try {
					t = ee(f, a.length);
				} catch {
					return z(n, "error", [S("TRANSITION_BLOCKED", "抽選位置が許容範囲を超えます。", "rngPosition")]);
				}
				f = t.state, e = a[t.index];
			} else e = i.find((e) => e.edgeId === r.edgeId);
			if (!e) return z(n, "blocked", [S("TRANSITION_BLOCKED", "進む選択肢を指定してください。", c.id)]);
			if (e.result !== "true") return z(n, e.result === "unknown" ? "unknown" : "blocked", [S(e.result === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED", e.reasons.join("、") || "この選択肢の条件は成立していません。", e.edgeId)]);
			m = L(t, c.id).filter((t) => t.id === e.edgeId);
		} else m = (e === "first_match" ? a.slice(0, 1) : a).map((e) => e.edgeId).map((e) => L(t, c.id).find((t) => t.id === e));
		if (m.length > 0) {
			if (new Set(m.map((e) => typeof e.data.toId == "string" ? e.data.toId : null)).size !== 1) return z(n, "error", [S("VALIDATION_FAILED", "all_matchの進行先が異なります。同じ進行先を指定してください。", c.id)]);
			let e = m[0].data.toId;
			typeof e == "string" && (h = e);
		}
	}
	if (!h || !I(t, h)) return z(n, "error", [S("REFERENCE_INVALID", "進行先が未完成、または存在しません。", c.id)]);
	let _ = B(I(t, h));
	if (_) return z(n, "error", [_]);
	let v = [];
	for (let e of m) for (let r of e.data.effectIds ?? []) {
		let i = O(t, r);
		if (!i || i.kind !== "effect" || i.deletedAt || i.status === "rejected") return z(n, "error", [S("REFERENCE_INVALID", i?.status === "rejected" ? "分岐に不採用の効果が指定されています。" : "分岐に指定した効果が存在しないか、削除済みです。", `${e.id}.effectIds`)]);
		v.push(i);
	}
	let b = p(f, v, {
		state: f,
		variables: j(t),
		entities: E(t),
		externalValues: n.externalValues,
		ruleContext: g(t, {
			nodeId: c.id,
			worldTick: r.worldTick
		}),
		ruleContexts: e(t, g(t, {
			nodeId: c.id,
			worldTick: r.worldTick
		}))
	});
	if (!b.ok) return z(n, b.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", b.issues);
	f = b.state;
	let x = Z(c, n.state, r);
	return f.onceTriggers = [.../* @__PURE__ */ new Set([...f.onceTriggers, ...[x.once, x.occurrence].filter((e) => e !== void 0)])], re(t, s, f, h, m.map((e) => e.id), r, d);
}
function $(e, t, n) {
	try {
		return ae(e, t, n);
	} catch (e) {
		return z(t, "error", V(e));
	}
}
function ae(e, t, n) {
	let r = N(e, t.state.contentVersionId);
	if (!r || r.revision !== t.contentRevision) return z(t, "error", [S("VALIDATION_FAILED", "作品版が変わりました。仮値を適用する前に開始し直してください。", "contentRevision")]);
	e = t.content;
	let i = y(t.externalValues);
	for (let [r, a] of Object.entries(n.external ?? {})) {
		let n = O(e, r);
		if (!n || n.kind !== "external_contract") return z(t, "error", [S("REFERENCE_INVALID", "仮の外部値には宣言した外部契約が必要です。", r)]);
		if (n.data.outputType !== a.type && a.type !== "unknown") return z(t, "error", [S("VALIDATION_FAILED", "仮の外部値と宣言した出力型が違います。", r)]);
		i[r] = y(a);
	}
	let a = Object.entries(n.variables ?? {}).map(([e, t]) => ({
		operation: "set",
		targetId: e,
		value: t
	})), o = p(t.state, a, {
		state: t.state,
		variables: j(e),
		entities: E(e),
		externalValues: i
	});
	if (!o.ok) return z(t, o.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", o.issues);
	let s = {
		...o.state,
		provenance: "stub"
	}, c = t.pendingPresentation, l = [], u;
	if (c) {
		let n = W(e, s, c, i, t.initialWorldTick);
		if (!n.ok) return z(t, n.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", n.issues);
		s = {
			...n.state,
			provenance: "stub"
		}, l = n.conditions, u = n.observationState, c = void 0;
	}
	let d = X(t.state, s);
	for (let e of /* @__PURE__ */ new Set([...Object.keys(t.externalValues), ...Object.keys(i)])) x(t.externalValues[e], i[e]) || d.push({
		path: `externalValues.${e}`,
		before: y(t.externalValues[e]),
		after: y(i[e])
	});
	let f = {
		...t,
		state: s,
		externalValues: i,
		issues: [],
		lastDiff: d,
		pendingPresentation: c,
		history: [...t.history, {
			state: y(t.state),
			externalValues: y(t.externalValues),
			status: t.status,
			issues: y(t.issues),
			lastDiff: y(t.lastDiff),
			traceLength: t.trace.length,
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, {
			fromId: t.nodeId,
			toId: t.nodeId,
			edgeIds: [],
			before: y(t.state),
			after: y(s),
			conditionResults: l,
			...u ? { presentationState: u } : {},
			changes: d,
			request: { stub: y(n) },
			externalValuesBefore: y(t.externalValues),
			externalValuesAfter: y(i)
		}]
	};
	return q(e, f);
}
function oe(e, t, n) {
	let r = O(e, t);
	if (!r || r.kind !== "trace") return z(J(e), "error", [S("REFERENCE_INVALID", "保存した経路記録が存在しません。", t)]);
	let i = J(e, {
		checkpointId: r.data.startCheckpointId,
		contentVersionId: r.data.contentVersionId,
		referenceEntities: n,
		worldTick: r.data.initialWorldTick ?? void 0
	}), a = F(e, i);
	if (r.data.contentRevision != null && r.data.contentRevision !== a.revision) return z(i, "error", [S("VALIDATION_FAILED", "経路記録の作品版が変更されました。再確認が必要です。", `${t}.contentRevision`)]);
	if (i.status === "error") return i;
	let o = e.entities.find((e) => e.id === r.data.startCheckpointId && e.kind === "checkpoint");
	if (r.data.initialWorldTick != null && o?.data.worldTick != null && r.data.initialWorldTick !== o.data.worldTick) return z(i, "error", [S("INTEGRITY_FAILED", "保存した開始時点と経路の初期提示時点が一致しません。", `${t}.initialWorldTick`)]);
	if (r.data.initialStubValues) {
		let a = J(e, {
			...r.data.initialStubBaseState ? { state: y(r.data.initialStubBaseState) } : {},
			entryId: i.startState.presentationPosition ?? void 0,
			contentVersionId: r.data.contentVersionId,
			referenceEntities: n,
			seed: i.startState.rngSeed,
			worldTick: r.data.initialWorldTick ?? o?.data.worldTick ?? void 0,
			stub: y(r.data.initialStubValues)
		});
		if (a.status === "error" || !x(a.startState, i.startState) || !x(a.startExternalValues, r.data.initialExternalValues ?? {})) return z(i, "error", [S("INTEGRITY_FAILED", "保存した初期stub入力と固定版の開始状態が一致しません。", `${t}.initialStubValues`)]);
	}
	i.externalValues = y(r.data.initialExternalValues ?? {}), i.startExternalValues = y(i.externalValues), i.startStubValues = r.data.initialStubValues ? y(r.data.initialStubValues) : void 0, i.startStubBaseState = r.data.initialStubBaseState ? y(r.data.initialStubBaseState) : void 0;
	for (let [n, o] of r.data.steps.entries()) {
		if (!x(i.state, o.before)) return z(i, "error", [S("VALIDATION_FAILED", "保存した開始状態と経路の直前状態が一致しません。", `${t}.steps[${n}].before`)]);
		let r = {};
		if (o.operation === "stub" || o.operation === void 0 && o.edgeIds.length === 0 && o.before.presentationPosition === o.after.presentationPosition && x(o.before.visitCounts, o.after.visitCounts) && o.after.provenance === "stub") {
			let e = {};
			for (let t of j(a)) !t.data.derived && !x(o.before.variableValues[t.id], o.after.variableValues[t.id]) && (e[t.id] = y(o.after.variableValues[t.id]));
			r = { stub: {
				variables: e,
				external: o.externalValues ?? i.externalValues
			} };
		} else {
			i.externalValues = y(o.externalValues ?? i.externalValues);
			let e = I(a, i.nodeId);
			r.edgeId = o.edgeIds[0], o.after.rngPosition === o.before.rngPosition + 1 && (r.random = !0), e?.data.trigger && (r.event = {
				triggerId: e.data.trigger.id ?? e.id,
				event: e.data.trigger.event,
				eventKey: e.data.trigger.eventKey,
				occurrenceId: o.occurrenceId ?? `replay:${n}`
			}), r.worldTick = o.worldTick;
		}
		if (i = Q(e, i, r), i.status === "error") return i;
		if (o.conditionResults && !x(i.trace.at(-1)?.conditionResults, o.conditionResults)) return z(i, "error", [S("VALIDATION_FAILED", "保存した提示時の条件結果と再実行が一致しません。", `${t}.steps[${n}].conditionResults`)]);
		if (o.presentationState && !x(o.presentationState, i.trace.at(-1)?.presentationState)) return z(i, "error", [S("INTEGRITY_FAILED", "保存した提示前の観測状態と再実行が一致しません。", `${t}.steps[${n}].presentationState`)]);
		if (!x(i.state, o.after)) return z(i, "error", [S("VALIDATION_FAILED", "保存した経路と再実行の状態が一致しません。", `${t}.steps[${n}].after`)]);
	}
	return i;
}
//#endregion
export { oe as replaySavedTrace, J as startTrial, Q as stepTrial };
