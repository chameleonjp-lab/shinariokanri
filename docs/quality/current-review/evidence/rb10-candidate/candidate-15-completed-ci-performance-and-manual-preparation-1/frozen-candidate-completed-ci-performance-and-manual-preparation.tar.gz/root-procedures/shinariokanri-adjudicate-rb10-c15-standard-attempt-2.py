import hashlib,json,math,pathlib,datetime
root=pathlib.Path('/workspace/shinariokanri-rb10-collection-views')
dest=pathlib.Path('/tmp/shinariokanri-rb10-candidate-15')
binding=json.loads((dest/'source-and-build-binding.json').read_text())
assert binding['commit']=='6ed5654ca6226061a48651dd317ce1a922c5d07b' and binding['tree']=='2e1650180b7769e8a2e59a6a01510c8d64bdac8b' and binding['build_info']['version']=='d0fc32b97242aa86b09f'
helper=pathlib.Path('/tmp/shinariokanri-rb10-candidate-15/measure-editable-performance.mjs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=='ae0845d9856e3932013af73901e0f77d58e84d82370fd1e16bdeb186533640ae'
for size in ['standard']:
    path=pathlib.Path('/workspace/shinariokanri-rb10-measurements')/f'c15-{size}-editable-performance-30-2.json'
    data=json.loads(path.read_text())
    assert data['sourceCommit']==binding['commit'] and data['sourceTree']==binding['tree']
    assert data['dirty'] is False and data['buildInfo']==binding['build_info']
    assert data['errors']==[] and data.get('finishedAt') and data['samples']==30
    assert data['measurementContract']['supplementalHelperSha256']==sha(helper)
    assert data['measurementContract']['originalHelperSha256']==sha(root/'scripts/measure-app.mjs')
    source={r['path']:r['sha256'] for r in binding['source_files']}
    observed={r['path']:r['sha256'] for r in data['sourceFiles']}
    assert observed=={p:h for p,h in source.items() if p!='index.html'}
    assert {r['path']:r['sha256'] for r in data['artifactFiles'] if r['path'].startswith('dist/')}=={r['path']:r['sha256'] for r in binding['artifact_files']}
    checks=[];metrics=data['measurements']
    limits={'cached_startup':3000,'selection':200,'list_switch':200,'compound_search':500,'command_save':1000,'next_period':200,'timeline_frames':33.4,'graph_frames':33.4} if size=='standard' else {'cached_startup':10000,'compound_search':2000}
    for name,value in metrics.items():
        samples=value['milliseconds'];assert value['count']==len(samples)
        assert value['p95']==sorted(samples)[math.ceil(.95*len(samples))-1]
        assert value['maximum']==max(samples)
        if name in limits:
            assert len(samples)==(330 if name in ['timeline_frames','graph_frames'] else 30)
            checks.append({'metric':name,'count':len(samples),'p95Milliseconds':value['p95'],'thresholdMilliseconds':limits[name],'passed':value['p95']<=limits[name],'rounding':'no rounding'})
    assert {c['metric'] for c in checks}==set(limits), 'Every required measured metric must be present'
    probes=metrics['cached_startup']['editableProbes'];assert len(probes)==30
    assert len({p['timeOrigin'] for p in probes})==30
    for p in probes:
        assert p['firstCardLabel']==p['editorName']
        assert all(p[k] is True for k in ['enabled','visible','focused','renderConfirmed']) and not p['readOnly'] and not p['inert']
        v=p['visibilityEvidence'];assert v['intersection']['width']>0 and v['intersection']['height']>0 and v['effectiveOpacity']>0
        assert all(s['display']!='none' and s['visibility'] not in ['hidden','collapse'] for s in v['styles'])
    before=data['initialAssetsVerified'];after=data['finalPersisted'];expected=8800 if size=='standard' else 88003
    assert before['records']==after['records']==expected
    assert before['revision']=='1' and before['historyCount']==before['outboxCount']==1
    assert after['revision']=='31' and after['historyCount']==after['outboxCount']==31
    assert before['recoveredPendingCount']==after['recoveredPendingCount']==0
    assert before['assets']==after['assets'] and all(a['verified'] for a in after['assets'])
    if size=='large':
        assert len(after['assets'])==3 and sum(a['bytes'] for a in after['assets'])==72*1024*1024
        assert data['fixture']['sha256']=='814daf96a6511cf47409f3497b03c7ba0309af250bfd87306c44a1dec5d5a917'
    result={'candidate':'RB10 C15','commit':binding['commit'],'tree':binding['tree'],'buildVersion':binding['build_info']['version'],'adjudicatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rawResult':str(path),'rawSha256':sha(path),'helperSha256':sha(helper),'checks':checks,'result':'local_numeric_targets_met_full_gate_unverified' if all(c['passed'] for c in checks) else 'failed_performance_candidate_preserved','startupProbe':'Actual matching editor enabled/non-readonly/non-inert/CSS ancestor-visible/viewport-intersecting/focused/next-frame, originalnavigationStart; no content input or startup saves','saveOrigin':'commandvalidation-to-atomiccommit; excludes500msdebounce','frameScope':'active330intervals across30gestures with12native application moves; idle360 diagnostic separate','recordAssetVerification':{'before':before,'after':after},'scope':'ManagedLinux actualproductionApp/nativeIndexedDB; source/helper/dist/env/fixture bound. Does not replace physicalOS/browser, VoiceOver/NVDA, actualAuth/RLS/privateStorage, or original116 clauses.'}
    (dest/f'{size}-editable-adjudication-attempt-2.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(size,result['result'],[(c['metric'],c['p95Milliseconds'],c['passed']) for c in checks])
