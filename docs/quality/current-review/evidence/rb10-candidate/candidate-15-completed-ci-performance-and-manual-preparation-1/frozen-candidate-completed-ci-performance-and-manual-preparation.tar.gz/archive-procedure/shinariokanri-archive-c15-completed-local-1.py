"""Seal C12 evidence separately from its immutable tested source commit.

Run after the independent final seal and actual >=7200 second Large drill.
No case/gate success is inferred from process exits, counts or old candidates.
Temporary signed-download URL raw remains local; its hash/redaction adjudication
is distributed. Every archive member and any <=64 MiB Git split is byte checked.
"""
import argparse, datetime, gzip, hashlib, io, json, pathlib, shutil, subprocess, tarfile
ROOT=pathlib.Path('/workspace/shinariokanri-rb10-basic-registration')
PROOF=pathlib.Path('/tmp/shinariokanri-rb10-candidate-12')
MEASURE=pathlib.Path('/workspace/shinariokanri-rb10-measurements')
COMMIT='1a604f0bcdb44a879b29b052008216e61aea3777'; TREE='3d9d914aeddae2192ee77fb7f5b467158d73959f'; BUILD='57f913e16b0a69e4494f'
EXCLUDED={'ci-native-artifact-download.log'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def descriptor(p,name):return {'path':str(name),'bytes':p.stat().st_size,'sha256':sha(p)}
def enumerate_folder(folder,prefix):
 return [(p,pathlib.PurePosixPath(prefix)/p.relative_to(folder).as_posix()) for p in sorted(folder.rglob('*')) if p.is_file() and not p.is_symlink() and 'node_modules' not in p.relative_to(folder).parts]
def bundle(dest,name,pairs,scope):
 assert len({str(n) for _,n in pairs})==len(pairs),'duplicate archive names'
 rows=[descriptor(p,n) for p,n in pairs]
 for r in rows:assert not pathlib.PurePosixPath(r['path']).is_absolute() and '..' not in pathlib.PurePosixPath(r['path']).parts
 archive=dest/(name+'.tar.gz')
 with archive.open('wb') as out:
  with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for (p,n),r in zip(pairs,rows):
     item=tarfile.TarInfo(str(n));item.mode=0o644;item.mtime=0;item.size=r['bytes']
     with p.open('rb') as f:tar.addfile(item,f)
    payload=(json.dumps({'candidate':'C15','commit':COMMIT,'tree':TREE,'scope':scope,'files':rows},ensure_ascii=False,indent=2)+'\n').encode()
    item=tarfile.TarInfo('BUNDLE_MANIFEST.json');item.mode=0o644;item.mtime=0;item.size=len(payload);tar.addfile(item,io.BytesIO(payload))
 with tarfile.open(archive,'r:gz') as tar:
  actual={}
  for item in tar:
   assert item.isfile();f=tar.extractfile(item);h=hashlib.sha256();count=0
   for c in iter(lambda:f.read(1048576),b''):h.update(c);count+=len(c)
   actual[item.name]=(count,h.hexdigest())
  for r in rows:assert actual.pop(r['path'])==(r['bytes'],r['sha256']),r['path']
  assert set(actual)=={'BUNDLE_MANIFEST.json'}
 result={'name':name,'scope':scope,'members':len(rows),'uncompressedBytes':sum(r['bytes'] for r in rows),'archive':descriptor(archive,archive.name),'allMembersByteVerified':True}
 if archive.stat().st_size>64*1024*1024:
  parts=[]
  with archive.open('rb') as f:
   index=0
   while True:
    chunk=f.read(64*1024*1024)
    if not chunk:break
    part=dest/(archive.name+f'.part-{index:03d}');part.write_bytes(chunk);parts.append(descriptor(part,part.name));index+=1
  h=hashlib.sha256();count=0
  for r in parts:
   p=dest/r['path'];assert sha(p)==r['sha256']
   with p.open('rb') as f:
    for c in iter(lambda:f.read(1048576),b''):h.update(c);count+=len(c)
  assert count==result['archive']['bytes'] and h.hexdigest()==result['archive']['sha256']
  result['parts']=parts;result['splitRecombinedHashVerified']=True
  (dest/(name+'-split-manifest.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');archive.unlink()
 return result


COMMIT='6ed5654ca6226061a48651dd317ce1a922c5d07b';TREE='2e1650180b7769e8a2e59a6a01510c8d64bdac8b';BUILD='d0fc32b97242aa86b09f'
PROOF=pathlib.Path('/tmp/shinariokanri-rb10-candidate-15');ROOT=pathlib.Path('/workspace/shinariokanri-rb10-collection-views')
out=pathlib.Path('/workspace/shinariokanri-rb10-final-candidate-evidence/docs/quality/current-review/evidence/rb10-candidate/candidate-15-completed-ci-performance-and-manual-preparation-1');assert not out.exists()
b=read(PROOF/'source-and-build-binding.json');assert b['commit']==COMMIT and b['tree']==TREE and b['build_info']['version']==BUILD
assert read(PROOF/'standard-editable-adjudication-attempt-2.json')['result']=='local_numeric_targets_met_full_gate_unverified'
assert read(PROOF/'large-editable-adjudication.json')['result']=='local_numeric_targets_met_full_gate_unverified'
ci=read(PROOF/'github-ci-adjudication.json');assert ci['conclusion']=='success' and ci['steps']==21 and ci['actualCheckoutTree']==TREE
pairs=[]
for r in b['source_files']+b['original_documents']+b['artifact_files']+[b['generated_runtime']]:
 src=pathlib.Path('/workspace/shinariokanri-rb10-c15-frozen-inputs')/r['path'];assert src.stat().st_size==r['bytes'] and sha(src)==r['sha256'];pairs.append((src,pathlib.PurePosixPath('actual-frozen-candidate')/r['path']))
for name in ['source-and-build-binding.json','environment-binding.json','helper-lineage-binding.json','measure-editable-performance.mjs','launch-procedure-before-91history-proof.py','standard-editable-performance-30-2-supervisor.json','large-editable-performance-30-supervisor.json','standard-editable-adjudication-attempt-2.json','large-editable-adjudication.json','ci-run-observed-2054.json','ci-jobs-observed-2054.json','main-observed-2058.json','pr29-observed-2058.json','ci-run-observed-2105.json','ci-jobs-final.json','ci-raw-log-final.txt','ci-checkout-sha.txt','ci-checkout-commit-final.json','github-ci-adjudication.json']:
 src=PROOF/name;assert src.is_file();pairs.append((src,pathlib.PurePosixPath('actual-binding-raw-and-adjudication')/name))
for key in ['standard-editable-performance-30-2','large-editable-performance-30']:
 s=read(PROOF/(key+'-supervisor.json'));assert s['exitCode']==0 and s['status']=='process_completed_unadjudicated' and s['helperCapture']=='all13actualbytes_captured' and not s.get('captureErrors');r=read(pathlib.Path(s['raw']));assert r['finishedAt'] and r['errors']==[] and r['sourceCommit']==COMMIT and r['sourceTree']==TREE
 pairs.append((pathlib.Path(s['raw']),pathlib.PurePosixPath('actual-completed-measurement')/pathlib.Path(s['raw']).name))
 pairs.extend(enumerate_folder(PROOF/(key+'-executed-helper'),'actual-executed-compiled-helper/'+key))
 for f in s['compiledHelperFiles']:
  src=PROOF/(key+'-executed-helper')/f['path'].removeprefix('measurement-helper/');assert src.stat().st_size==f['bytes'] and sha(src)==f['sha256']
 log=pathlib.Path('/tmp')/('shinariokanri-rb10-c15-'+key+'.txt');pairs.append((log,pathlib.PurePosixPath('actual-completed-execution-log')/log.name))
for key in ['standard-performance-launch-failure-1','three-form-launch-failure-1']:pairs.extend(enumerate_folder(PROOF/key,'own-pre-browser-preparation-failures/'+key))
for name in ['shinariokanri-adjudicate-rb10-c15-standard-attempt-2.py','shinariokanri-adjudicate-rb10-c15-large.py','shinariokanri-bind-rb10-c15.py']:
 src=pathlib.Path('/tmp')/name;pairs.append((src,pathlib.PurePosixPath('root-procedures')/name))
pairs.append((pathlib.Path(__file__),pathlib.PurePosixPath('archive-procedure')/pathlib.Path(__file__).name));pairs.extend(enumerate_folder(pathlib.Path('/workspace/shinariokanri-rb10-review-package/c15'),'prepared-unexecuted-real-environments'))
out.mkdir(parents=True)
r=bundle(out,'frozen-candidate-completed-ci-performance-and-manual-preparation',pairs,'C15 actual frozen425 source/original/dist/runtime bytes; all21CI/actualsame-tree merge; originalv4 Standard andLarge30 raw exact helper13each and allstage numeric evidence; own pre-browser dependency/output-parent failures; actual clean13-member candidate ZIP and unchanged originalLarge fixture. Manual realOS/AT/Auth/RLS/Storage11rows unexecuted. Does not certify original116/33/restore/actual7200.')
summary={'candidate':'C15','commit':COMMIT,'tree':TREE,'build':BUILD,'scope':'completed_local_metrics_and_CI_with_unexecuted_manual_package_only','standard':read(PROOF/'standard-editable-adjudication-attempt-2.json'),'large':read(PROOF/'large-editable-adjudication.json'),'ci':ci,'actual7200':'not_started_at_this_seal','original116':'independent4 directlyobserved, remaining112 unadjudicated at this seal','preparedRealEnvironments':'all11rows_not_run','archive':r,'historicalPreparationLineage':'Guide/helperlineage planned flags retained as originally prepared; actual measured modes separately bound by completed raw/13compiler/worker records above.'}
(out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(out/'MANIFEST.json').write_text(json.dumps({'candidate':'C15','commit':COMMIT,'tree':TREE,'allMembersByteVerified':True,'files':[descriptor(p,p.name) for p in sorted(out.iterdir()) if p.is_file()]},ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
