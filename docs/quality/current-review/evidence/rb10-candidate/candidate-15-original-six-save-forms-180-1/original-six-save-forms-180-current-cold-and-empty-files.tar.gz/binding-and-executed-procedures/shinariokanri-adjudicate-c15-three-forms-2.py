import datetime,hashlib,json,math,pathlib
base=pathlib.Path('/tmp/shinariokanri-rb10-candidate-15')
out=pathlib.Path('/workspace/shinariokanri-rb10-c15-rg06-proof/results/original-three-forms-2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((base/'source-and-build-binding.json').read_text());p=out/'raw.json';r=json.loads(p.read_text());s=json.loads((base/'original-three-forms-2-supervisor.json').read_text())
assert r['commit']==s['commit']==b['commit']=='6ed5654ca6226061a48651dd317ce1a922c5d07b'
assert r['tree']==b['tree']=='2e1650180b7769e8a2e59a6a01510c8d64bdac8b' and r['build']==b['build_info']['version']=='d0fc32b97242aa86b09f'
assert r['result']=='passed_local_original_three_save_forms_and_native_cold_empty_complete_restore' and r['finishedAt'] and r['errors']==[]
assert s['exitCode']==0 and s['rawSHA256']==sha(p)
assert sha(out/'executed-procedure.mjs')==r['procedureSHA256']==s['helperSHA256']=='f20c2c851862beb97fe8fdce12cc772cadd614a676ca677ee5e31d4f6ccaf0f1'
assert sha(base/'original-three-forms-2-executed-supervisor.py')=='c58772f8800c7814d7bfa656e05f28f6f493e4780c3cb37a94cd5c68cb477253'
assert r['sourceBindingSHA256']==sha(base/'source-and-build-binding.json')
assert r['samplesPerForm']==30 and len(r['cases'])==2
summaries=[]
for index,c in enumerate(r['cases']):
    assert c['fixture']['coreRecords']==8800 and c['fixture']['records']==8800+index*3
    assert [f['form'] for f in c['forms']]==['project_name_one_field','one_dialogue_text','atomic_two_dialogue_records']
    for f,expected_writes in zip(c['forms'],[0,1,2]):
        assert len(f['samples'])==f['summary']['count']==30
        for x in f['samples']:
            assert math.isfinite(x['commandMilliseconds']) and math.isfinite(x['uiMilliseconds'])
            assert sum(v for k,v in x['calls'].items() if k in ('entities.put','entities.add','entities.delete'))==expected_writes
            assert not any(k.startswith('commands.') and k.split('.')[-1] in ('getAll','getAllKeys','openCursor','openKeyCursor') for k in x['calls'])
            assert x['digestCalls']<5000
        actual=sorted(x['commandMilliseconds'] for x in f['samples'])[28]
        assert actual==f['summary']['commandP95']<=1000
        assert f['summary']['commandNumericResult']=='within_original_limit'
        summaries.append({'fixture':c['label'],'form':f['form'],'actualCount':30,'commandP95Milliseconds':actual,'inputOrClickToConfirmedUIp95Milliseconds':f['summary']['uiP95'],'maximumChangedEntityWrites':expected_writes})
    current=c['after'];cold=c['afterCold'];restored=c['empty390ColdRestoration']
    for v in (current,cold,restored):
        assert v['records']==8800+index*3 and v['revision']=='91' and v['historyCount']==91
        assert len(v['assets'])==index*3 and all(a['verified'] for a in v['assets'])
        assert sum(a['bytes'] for a in v['assets'])==index*3*1024*1024
    assert current['contentHash']==cold['contentHash']==restored['contentHash']
    assert current['assets']==cold['assets']==restored['assets']
    assert current['outboxCount']==cold['outboxCount']==91 and current['recoveredPendingCount']==cold['recoveredPendingCount']==0
    assert restored['outboxCount']==1 and restored['recoveredPendingCount']==91
    assert c['restorationProgress']['stage']=='native_hash_history_pending_assets_confirmed'
    file=pathlib.Path(c['completeFile']['path']);assert sha(file)==c['completeFile']['sha256'] and file.stat().st_size==c['completeFile']['bytes']
helper=json.loads((out/'HELPER_INPUTS.json').read_text())
for f in helper['helperFiles']:
    q=out/f['path'];assert sha(q)==f['sha256'] and q.stat().st_size==f['bytes']
result={'candidate':'C15','commit':b['commit'],'tree':b['tree'],'build':b['build_info']['version'],'adjudicatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'passed_local_6_original_save_form_groups_180_samples_and_both_actual_empty_cold_files','rawSHA256':sha(p),'procedureSHA256':r['procedureSHA256'],'actualExecutedSupervisorSHA256':sha(base/'original-three-forms-2-executed-supervisor.py'),'commandLimitMilliseconds':1000,'measurementOrigin':'command validation start→atomic durable commit,500ms editor debounce excluded. Separate input/click→Node-confirmed latest revision/UI ack includes debounce/poll/IPC and is not pure paint timing.','groups':summaries,'completeFiles':[c['completeFile'] for c in r['cases']],'sourceHashes':[c['afterCold']['contentHash'] for c in r['cases']],'actualAssets':'Bare originalStandard8800 plus explicitly additional3×1MiB actualmaterial records; no metadata-only substitution. Current/cold/file-empty-cold all hashes/IDs/Unicode/mainStart/calendars guarded in actual executed procedure.','claimLimit':'Local Linux production/native only; no full116/physical/liveAuth/wholeRG06 or arbitrary91clone/actual7200 promotion.'}
(base/'original-three-forms-adjudication-attempt-2.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'result':result['result'],'groups':summaries},ensure_ascii=False))
