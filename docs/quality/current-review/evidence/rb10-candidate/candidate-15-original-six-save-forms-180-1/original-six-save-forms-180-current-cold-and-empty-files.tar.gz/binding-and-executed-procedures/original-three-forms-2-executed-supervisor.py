import pathlib,json,hashlib,subprocess,os,sys,datetime,time,shutil
ROOT=pathlib.Path('/workspace/shinariokanri-rb10-collection-views');DEST=pathlib.Path('/tmp/shinariokanri-rb10-candidate-15');MEASURE=pathlib.Path('/workspace/shinariokanri-rb10-measurements');MEASURE.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
name=sys.argv[1];commands={
 'original-three-forms-2':['node','/workspace/shinariokanri-rb10-c15-rg06-proof/measure-three-save-forms.mjs','--attempt','original-three-forms-2'],
 'original-file-new-clone-1':['node','/workspace/shinariokanri-rb10-c15-91history-proof/verify-original-file-new-clone-1.mjs'],
 'standard-editable-performance-30-2':['node',str(DEST/'measure-editable-performance.mjs'),'--size','standard','--mode','performance','--samples','30','--output',str(MEASURE/'c15-standard-editable-performance-30-2.json')],
 'standard-editable-performance-30':['node',str(DEST/'measure-editable-performance.mjs'),'--size','standard','--mode','performance','--samples','30','--output',str(MEASURE/'c15-standard-editable-performance-30.json')],
 'large-editable-performance-30':['node',str(DEST/'measure-editable-performance.mjs'),'--size','large','--mode','performance','--samples','30','--output',str(MEASURE/'c15-large-editable-performance-30.json')],
 'large-recovery':['node','scripts/measure-app.mjs','--size','large','--mode','recovery','--samples','30','--output',str(MEASURE/'c15-large-recovery.json')],
 'large-soak-7200':['node','scripts/measure-app.mjs','--size','large','--mode','soak','--samples','30','--seconds','7200','--output',str(MEASURE/'c15-large-soak-7200.json')],
 'original-three-forms-1':['node','/workspace/shinariokanri-rb10-c15-rg06-proof/measure-three-save-forms.mjs','--attempt','original-three-forms-1'],
}
assert name in commands
status=DEST/(name+'-supervisor.json');log=pathlib.Path('/tmp')/('shinariokanri-rb10-c15-'+name+'.txt');binding=DEST/'source-and-build-binding.json';b=json.loads(binding.read_text())
if len(sys.argv)==2:
 assert not status.exists() and not log.exists(),'existing attempt must be retained'
 with log.open('wb') as stream:
  worker=subprocess.Popen([sys.executable,__file__,name,'--worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
 print(json.dumps({'name':name,'ownedSupervisorPid':worker.pid,'ownedProcessGroup':worker.pid,'status':str(status),'log':str(log),'scope':'actual unaccelerated local probe; no physical/live/full116 pass'}));sys.exit(0)
assert sys.argv[2]=='--worker' and os.getpgrp()==os.getpid()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert git('rev-parse','HEAD')==b['commit'] and git('rev-parse','HEAD^{tree}')==b['tree'] and not git('status','--porcelain')
for f in b['source_files']+b['original_documents']+b['artifact_files']+[b['generated_runtime']]:assert sha(ROOT/f['path'])==f['sha256'],f['path']
cmd=commands[name];helper=ROOT/cmd[1] if not pathlib.Path(cmd[1]).is_absolute() else pathlib.Path(cmd[1]);output=(pathlib.Path(cmd[cmd.index('--output')+1]) if '--output' in cmd else (pathlib.Path('/workspace/shinariokanri-rb10-c15-91history-proof/results/original-file-new-clone-1/raw.json') if name=='original-file-new-clone-1' else (pathlib.Path('/workspace/shinariokanri-rb10-c15-rg06-proof/results/original-three-forms-2/raw.json') if name=='original-three-forms-2' else pathlib.Path('/workspace/shinariokanri-rb10-c15-rg06-proof/results/original-three-forms-1/raw.json'))));assert not output.exists()
record={'candidate':'C15','commit':b['commit'],'tree':b['tree'],'build':b['build_info']['version'],'bindingSHA256':sha(binding),'name':name,'launchedAt':now(),'ownedSupervisorPid':os.getpid(),'ownedProcessGroup':os.getpgrp(),'helper':str(helper),'helperSHA256':sha(helper),'command':cmd,'raw':str(output),'clockAcceleration':False,'physical':False,'actualAuthRlsStorage':False,'environment':{k:os.environ.get(k) for k in ['CHROMIUM_PATH','PLAYWRIGHT_BROWSERS_PATH','PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS','LD_LIBRARY_PATH','TMPDIR']},'status':'running','helperCapture':'not_observed_yet','memoryEventsAtLaunch':pathlib.Path('/sys/fs/cgroup/memory.events').read_text()}
def save():status.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
save();print(json.dumps({'phase':'validated launch','name':name,'pid':os.getpid(),'commit':b['commit']}),flush=True);child=subprocess.Popen(cmd,cwd=ROOT);record['ownedNodePid']=child.pid;save()
def capture():
 if record['helperCapture']=='all13actualbytes_captured' or not output.exists() or '--output' not in cmd:return
 try:d=json.loads(output.read_text())
 except (json.JSONDecodeError,OSError):return
 rows=[f for f in d.get('artifactFiles',[]) if f['path'].startswith('measurement-helper/')]
 if not rows:return
 assert len(rows)==13
 for folder in pathlib.Path('/tmp').glob('scenario-app-measure-*'):
  h=folder/'helper'
  if h.is_dir() and all((h/f['path'].removeprefix('measurement-helper/')).is_file() and sha(h/f['path'].removeprefix('measurement-helper/'))==f['sha256'] for f in rows):
   dest=DEST/(name+'-executed-helper');assert not dest.exists();dest.mkdir()
   for f in rows:
    rel=f['path'].removeprefix('measurement-helper/');src=h/rel;q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,q);assert sha(q)==f['sha256'] and q.stat().st_size==f['bytes'];q.chmod(0o444)
   entry=folder/'entry.js';shutil.copyfile(entry,dest/'generated-source-entry.js');record['helperCapture']='all13actualbytes_captured';record['helperCapturedAt']=now();record['compiledHelperFiles']=rows;record['generatedEntrySHA256']=sha(entry);save();print('Captured actual13 helper files',flush=True);return
while child.poll() is None:
 record['lastSupervisorObservationAt']=now();record['memoryEventsCurrent']=pathlib.Path('/sys/fs/cgroup/memory.events').read_text();record['memoryCurrentBytes']=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());save()
 try:capture()
 except Exception as e:record.setdefault('captureErrors',[]).append({'at':now(),'type':type(e).__name__,'message':str(e)});save()
 time.sleep(1)
record['exitCode']=child.returncode;record['finishedAt']=now();record['status']='process_completed_unadjudicated';record['rawSHA256']=sha(output) if output.exists() else None;save();print(json.dumps({'phase':'process finished','name':name,'exitCode':child.returncode,'raw':str(output),'helperCapture':record['helperCapture']}),flush=True)
