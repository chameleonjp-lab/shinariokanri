import {expect,it} from 'vitest';
import {createDemoProject,createEntity,newId,validateProject} from './model';
import {getTrialChoices,startTrial,stepTrial,trialRecordData} from './runtime';
import {findCatalogMaintenance} from './catalog';
import {stateUsageIndex} from './stateUsage';
import {deletionImpact} from './maintenance';
import type {Entity,ProjectData} from './types';

function record(project:ProjectData){
  const start=startTrial(project),choice=getTrialChoices(project,start)[0];
  expect(start.status).toBe('ready');expect(choice).toBeDefined();
  const trial=stepTrial(project,start,{edgeId:choice.edgeId}),id=newId(),data=trialRecordData(project,trial,id);
  const checkpoint=createEntity(project.projectId,'checkpoint','保存した開始状態',data.checkpoint);checkpoint.id=id;
  const trace=createEntity(project.projectId,'trace','保存した試読経路',data.trace);project.entities.push(checkpoint,trace);
  const validation=validateProject(project);expect(validation.ok,JSON.stringify(validation.issues)).toBe(true);
  return {checkpoint,trace};
}

it('keeps external unused state discoverable after an actual trial record without losing protected references',()=>{
  const project=createDemoProject(),y=createEntity(project.projectId,'variable','未使用Y',{key:'unused-y',initial:{type:'boolean',value:false},externalUseDeclared:true});project.entities.push(y);
  expect(findCatalogMaintenance(project).some(f=>f.kind==='external_use'&&f.targetIds.includes(y.id))).toBe(true);
  const saved=record(project),before=structuredClone(project);
  expect(saved.checkpoint.data.runtimeState.variableValues[y.id]).toEqual(y.data.initial);
  expect(stateUsageIndex(project).get(y.id)??[]).toEqual([]);
  expect(findCatalogMaintenance(project).some(f=>f.kind==='external_use'&&f.targetIds.includes(y.id))).toBe(true);
  expect(findCatalogMaintenance(project).some(f=>f.kind==='unreferenced'&&f.targetIds.includes(y.id))).toBe(false);
  expect(deletionImpact(project,y.id).map(f=>f.sourceId)).toEqual(expect.arrayContaining([saved.checkpoint.id,saved.trace.id]));
  expect(project).toEqual(before);
});

it('distinguishes authored read/update/reset from saved values and retains actual usage across more trial records',()=>{
  const project=createDemoProject(),x=project.entities.find((e):e is Entity<'variable'>=>e.kind==='variable')!;
  x.data.resetRules=[{on:'new_loop',value:x.data.initial,reason:'次周回で初期化'}];
  const original=stateUsageIndex(project).get(x.id)!;
  expect(original.map(u=>u.operation)).toEqual(expect.arrayContaining(['read','update','reset']));
  record(project);record(project);
  expect(stateUsageIndex(project).get(x.id)).toEqual(original);
  expect(findCatalogMaintenance(project).some(f=>f.targetIds.includes(x.id)&&['unreferenced','external_use'].includes(f.kind))).toBe(false);
});

it('shows an unused state with saved values as a candidate, then removes it only when an authored declaration uses it',()=>{
  const project=createDemoProject(),y=createEntity(project.projectId,'variable','未使用Y',{key:'unused-y',initial:{type:'boolean',value:false}});project.entities.push(y);record(project);
  const candidate=findCatalogMaintenance(project).find(f=>f.kind==='unreferenced'&&f.targetIds.includes(y.id));
  expect(candidate?.disposition).toBe('candidate');expect(candidate?.reason).toContain('保存');
  const condition=createEntity(project.projectId,'condition','Yを読む条件',{expression:{op:'compare',variableId:y.id,comparator:'eq',value:{type:'boolean',value:false}}});project.entities.push(condition);
  expect(stateUsageIndex(project).get(y.id)).toEqual([expect.objectContaining({entityId:condition.id,operation:'read'})]);
  expect(findCatalogMaintenance(project).some(f=>f.kind==='unreferenced'&&f.targetIds.includes(y.id))).toBe(false);
});
