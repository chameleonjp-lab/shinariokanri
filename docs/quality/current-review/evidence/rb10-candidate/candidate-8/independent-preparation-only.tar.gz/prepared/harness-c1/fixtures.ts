import { createEntity, createProject, emptyValidity } from '../candidate/src/domain/model';
import { sha256, jsonBytes } from '../candidate/src/storage/json';
import { createWorldSnapshot } from '../candidate/src/domain/world';
import { preparePublicExecution } from '../candidate/src/domain/exportPreparation';
import { publicationReviewSources, type SharedComment } from '../candidate/src/domain/sharedReviews';
import type { Entity, EntityKind, ProjectData } from '../candidate/src/domain/types';

// Fixed UUIDs, timestamps and text positions are independent inputs, not product output assertions.
export const fixedTime='2026-10-08T12:00:00.000Z';
export const ids=(n:number)=>`c1000000-0000-4000-8000-${n.toString(16).padStart(12,'0')}`;
function project(n:number,name:string){return {...createProject(name),projectId:ids(n)};}
function record<K extends EntityKind>(p:ProjectData,n:number,kind:K,name:string,data:Partial<Entity<K>['data']>={}):Entity<K>{
  const r=createEntity(p.projectId,kind,name,data);return {...r,id:ids(n),status:'confirmed',createdAt:fixedTime,updatedAt:fixedTime} as Entity<K>;
}
function body(n:number,text:string){return [{id:ids(n),kind:'paragraph' as const,text}];}
export function combatFixture(){
  const p=project(1,'原AT-F42 enum戦闘結果'),contract=record(p,2,'external_contract','ゲーム管理の戦闘結果',{key:'combat_result',owner:'game',inputType:'enum',outputType:'enum',version:'1.0.0',missingPolicy:'block',stubValues:[{type:'enum',value:'勝利'},{type:'enum',value:'敗北'}]}),
    variable=record(p,3,'variable','戦闘結果enum',{key:'combat_result_value',valueType:'enum',initial:{type:'enum',value:'敗北'},scope:'run',allowed:{values:['勝利','敗北']},externalContractId:contract.id,externalUseDeclared:true}),
    line=record(p,4,'dialogue_line','勝利した後の台詞',{text:body(5,'😀勝利した。次へ進もう。')}),scene=record(p,6,'scene','勝利後の場面',{body:body(7,'😀戦闘結果を確認した門'),dialogueLineIds:[line.id]}),
    entry=record(p,8,'flow_node','勝利入口',{nodeType:'automatic',executionPolicy:'first_match',sceneId:scene.id,gate:{op:'compare',variableId:variable.id,comparator:'eq',value:{type:'enum',value:'勝利'}}}),
    terminal=record(p,9,'flow_node','勝利終端',{nodeType:'terminal',terminalReason:'勝利ルート完了'}),edge=record(p,10,'flow_edge','勝利した道',{fromId:entry.id,toId:terminal.id,edgeType:'automatic'}),
    graph=record(p,11,'flow_graph','戦闘後の経路',{nodeIds:[entry.id,terminal.id],edgeIds:[edge.id],entryIds:[entry.id],exitIds:[terminal.id]});
  p.entities.push(contract,variable,line,scene,entry,terminal,edge,graph);
  const publicTexts=Object.fromEntries(p.entities.map(e=>[e.id,Object.fromEntries(Object.entries(e.data).filter(([k,v])=>['body','text','key','label','terminalReason','description'].includes(k)&&v!=null))]));
  // The externalContractId makes an unreceived result unknown regardless of the
  // enum's declared default; confirmed public labels do not certify an actual result.
  const profile=record(p,12,'projection_profile','確認済みenum戦闘公開範囲',{audience:'reader',publicTitle:'enum戦闘ゲーム',publicVersionLabel:'原F42一版',includedIds:p.entities.map(e=>e.id),allowedKinds:[...new Set(p.entities.map(e=>e.kind))],idPolicy:'preserve',namePolicy:{defaultPolicy:{mode:'replace',replacement:'公開対象'}},publicTexts,publicValues:{[variable.id]:{'勝利':'勝利','敗北':'敗北'},[contract.id]:{'勝利':'勝利','敗北':'敗北'}}});
  p.entities.push(profile);return {p,contract,variable,line,scene,entry,terminal,edge,graph,profile};
}
export function travelFixture(){
  const p=project(101,'原AT-F11 100tick移動と破壊履歴'),person=record(p,102,'character','移動する人物'),a=record(p,103,'place','街A'),b=record(p,104,'place','街B'),
    evidence=record(p,105,'source','徒歩の所要時間資料',{sourceType:'observation',locator:'独立測定記録・街Aから街Bへの徒歩',accessedAt:fixedTime,interpretation:body(106,'街Aから街Bへの徒歩には最低200tick必要。')});
  const event=(n:number,name:string,at:string,locationId:string)=>record(p,n,'event',name,{time:{mode:'instant',calendarId:p.calendarId,at},laneRole:'participants',locationId,participants:[{characterId:person.id,role:'actor'}]});
  const depart=event(107,'街Aを出る','0',a.id),arrive=event(108,'街Bへ着く','100',b.id),
    route=record(p,109,'travel_route','街A→街Bの徒歩',{fromPlaceId:a.id,toPlaceId:b.id,direction:'one_way',method:'',minimumTicks:null,evidence:[],validity:emptyValidity()}),
    ownerBefore=record(p,110,'group','旧支配組織'),ownerAfter=record(p,111,'group','新支配組織');
  const history=(n:number,predicate:string,value:unknown,start:string|null,end:string|null)=>record(p,n,'assertion',`街Bの${predicate}履歴${n}`,{subjectId:b.id,predicate,value:value as any,truthKind:'author_truth',validity:{...emptyValidity(),worldRange:{start,end}},sourceIds:[evidence.id]});
  p.entities.push(person,a,b,evidence,depart,arrive,route,ownerBefore,ownerAfter,
    history(112,'place_state',{type:'enum',value:'破壊前'},null,'50'),history(113,'place_state',{type:'enum',value:'破壊済み'},'50',null),
    history(114,'display_name',{type:'text',value:'街B'},null,'50'),history(115,'display_name',{type:'text',value:'廃都B'},'50',null),
    history(116,'controlled_by',ownerBefore.id,null,'50'),history(117,'controlled_by',ownerAfter.id,'50',null));
  return {p,person,a,b,evidence,depart,arrive,route,ownerBefore,ownerAfter};
}
export const pngBytes=new Uint8Array(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j/a8AAAAASUVORK5CYII=','base64'));
export async function offlineFixture(){
  const p=project(201,'原AT-N11 閉じて再開する作品'),note=record(p,202,'note','オフラインで編集するメモ',{body:body(203,'取得済みの本文😀')}),contentHash=await sha256(pngBytes),
    attachment=record(p,204,'attachment','取得済み画像',{contentHash,byteSize:pngBytes.length,mediaType:'image/png',assetPath:`assets/${contentHash}.png`,displayName:'offline-known.png',stage:'final'});
  note.data.attachmentIds=[attachment.id];p.entities.push(note,attachment);return {p,note,attachment,assets:{[contentHash]:pngBytes}};
}
// Keep the earlier independent preparation's four fake-IndexedDB checks usable
// without changing those original test bytes or confusing them with native App proof.
export const id=ids;
export const combatEnum=combatFixture;
export const offlineWork=offlineFixture;
export function travel100(){const f=travelFixture();const before=f.p.entities.find(e=>e.id===ids(112));if(before?.kind==='assertion')before.data.value={type:'enum',value:'健在'};return f;}
export async function sharedCommentFixture(){
  let p=project(700,'独立F29 capture入力');
  const line=record(p,701,'dialogue_line','台詞L',{text:body(702,'前😀版本1の台詞L')});line.visibility='team';
  const publicBlocks=body(704,'前😀版本1の台詞L'),profile=record(p,703,'projection_profile','F29確認済み範囲',{audience:'reviewer',publicTitle:'公開F29',publicVersionLabel:'版1',includedIds:[line.id],allowedKinds:['dialogue_line'],idPolicy:'remap',namePolicy:{defaultPolicy:{mode:'replace',replacement:'公開台詞L'}},publicTexts:{[line.id]:{text:publicBlocks}},blockSources:{[publicBlocks[0].id]:line.data.text[0].id}});
  p.entities.push(line,profile);p=await createWorldSnapshot(p,'原版1');const pin=p.snapshots.at(-1)!;
  const prepared=await preparePublicExecution(p,{profile:'reader',projectionProfileId:profile.id,targetVersionId:pin.id}),sourceMap=await publicationReviewSources(p,prepared,pin.id,{}),entity=prepared.projection.entities.find(e=>e.kind==='dialogue_line')!,block=(entity.data.text as {id:string;text:string}[])[0];
  const comment:SharedComment={id:ids(705),snapshot_id:ids(706),public_version_id:'public-project',public_entity_id:entity.id,public_block_id:block.id,start_cp:1,end_cp:3,body:'版1の😀版という範囲への指摘',created_at:fixedTime,resolved:false,review_stage:'open'};
  const envelope={snapshotId:comment.snapshot_id,sourceVersionId:pin.id,sourceHash:pin.contentHash,projectionHash:await sha256(jsonBytes(prepared.projection)),projection:prepared.projection,sourceMap};return {p,line,profile,pin,comment,envelope};
}
