import copy
import datetime
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/tmp/shinariokanri-independent-rb10-c7-905aad8/prepared')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

now = datetime.datetime.now(datetime.timezone.utc).isoformat()
binding = read(ROOT / 'candidate-binding.json')
commit, tree = binding['commit'], binding['tree']
target = {'commit': commit, 'tree': tree, 'build': binding['buildInfo']['version'],
          'sourceBindingSHA256': sha(ROOT / 'candidate-binding.json')}
contracts = read(ROOT / 'candidate/docs/data/acceptance_cases.json')
assert isinstance(contracts, list) and len(contracts) == 116
original = {case['id']: case for case in contracts}

# Preserve preparation failures separately; neither involved a runtime/product test.
failure_path = ROOT / 'harness-ledger-preparation-failures.json'
if not failure_path.exists():
    write(failure_path, {
        'classification': 'own_metadata_preparation_error', 'candidate': target,
        'runtimeTestsStarted': 0, 'productFailureInferred': False,
        'failures': [
            {'error': "TypeError: string indices must be integers, not 'str'",
             'cause': 'additionalSixRequirementOrdinaryDefinitions is a single dictionary, not a list; iterating its keys yielded strings',
             'correction': 'handle the explicitly single dictionary separately; preserve the same original clauses/definitions'},
            {'error': "AttributeError: 'list' object has no attribute 'items'",
             'cause': 'metadata inspection assumed acceptance_cases.json was an object',
             'correction': 'read its original list format; no fixture/assertion changed'}
        ]})

proc = read(OLD / 'PROCEDURES_C7_EXTENDED.json')
proc['stage'] = 'C8 sealed original116 procedures; execution awaits explicit OPEN'
proc['candidateCommit'], proc['candidateTree'] = commit, tree
proc['candidateBindingSHA256'] = target['sourceBindingSHA256']
proc['reboundAt'] = now
proc['previousC7ProceduresSHA256'] = sha(OLD / 'PROCEDURES_C7_EXTENDED.json')
proc['previousC7PreparedLedgerSHA256'] = sha(OLD / 'ORIGINAL116_C7_CLAUSE_LEDGER_PREPARED.json')
proc['historicalC7ActualLedger'] = {
    'path': str(OLD / 'ORIGINAL116_C7_ACTUAL_CLAUSE_LEDGER_2.json'),
    'sha256': sha(OLD / 'ORIGINAL116_C7_ACTUAL_CLAUSE_LEDGER_2.json'),
    'promotedC8Results': 0}
proc['counts']['actuallyExecutedTestsOnC8'] = 0
proc['counts']['actuallyExecutedTests'] = 0
proc['counts']['originalCasePasses'] = 0
proc['rebinding'] = {'fromC7BindingSHA256': binding['previousC7BindingSHA256'],
                     'candidateSourceSHAUpdated': True, 'original104_116LiteralUnchanged': True,
                     'C7RuntimePassesPromoted': 0, 'sharedWrites': 0}
unique = {}
templated = []
for case in proc['cases']:
    assert case['originalContract'] == original[case['caseId']]
    case['candidateCommit'], case['candidateTree'] = commit, tree
    case['caseAdjudication'] = 'not_run_C8'
    case['resultRecordRequired']['commit'], case['resultRecordRequired']['tree'] = commit, tree
    for definition in case['existingDefinitions']:
        path = ROOT / 'candidate' / definition['path']
        assert path.is_file(), str(path)
        definition['actualResult'] = 'not_run_on_C8'
        definition['frozenCandidateSHA256'] = sha(path)
        lines = path.read_text().splitlines()
        present = [i + 1 for i, text in enumerate(lines) if definition['title'] in text]
        definition['frozenCandidateDefinitionLine'] = present[0] if present else None
        definition['definitionReinspection'] = (
            'literal present in C8' if present else
            'template/it.each title requires retained expansion recipe; no skip/pass inferred')
        unique[(definition['path'], definition['title'])] = definition
        if not present:
            templated.append({'caseId': case['caseId'], **definition})
    for definition in case.get('additionalConcreteHarnessDefinitions', []):
        assert isinstance(definition, dict)
        path = ROOT / definition['file']
        assert path.is_file(), str(path)
        definition['definitionFileSHA256'] = sha(path)
        definition['execution'] = 'not_run_C8'
    definition = case.get('additionalSixRequirementOrdinaryDefinitions')
    if definition is not None:
        assert isinstance(definition, dict)
        definition['fileSHA256'] = sha(ROOT / definition['file'])
        definition['actualResult'] = 'not_run_C8'
    if isinstance(case.get('preparedAdditionalHarness'), str):
        case['preparedAdditionalHarness'] = case['preparedAdditionalHarness'].replace('.c7', '.c8')

assert len(unique) == 347, len(unique)
layers = {}
for definition in unique.values():
    layers[definition['proofLayer']] = layers.get(definition['proofLayer'], 0) + 1
proc['counts']['staticExistingDefinitions'] = 347
proc['counts']['staticExistingDefinitionFiles'] = len({path for path, title in unique})
proc['counts']['staticUniqueDefinitionLayers'] = layers
proc['counts']['staticCountsAreNotActualExpandedTestCounts'] = True
proc['counts']['templateOrEachDefinitionsWithoutLiteral'] = len({(x['path'], x['title']) for x in templated})
proc['templatedDefinitionReinspection'] = templated
write(ROOT / 'PROCEDURES_C8_EXTENDED.json', proc)

ledger = read(OLD / 'ORIGINAL116_C7_CLAUSE_LEDGER_PREPARED.json')
ledger['target'], ledger['createdAt'] = target, now
ledger['originalCaseSHA256'] = sha(ROOT / 'candidate/docs/data/acceptance_cases.json')
ledger['historicalC7Results'] = proc['historicalC7ActualLedger']
ledger.pop('independentC7RuntimeTests', None)
ledger['independentC8RuntimeTests'] = 0
ledger['originalFullCasePasses'] = 0
ledger['proofBundleScope'] = 'C8 preparations only; old C7 actual results are historical, never copied to C8'
procedures = {case['caseId']: case for case in proc['cases']}
for case in ledger['cases']:
    assert case['originalContract'] == original[case['caseId']]
    case['targetCommit'], case['targetTree'], case['targetBuild'] = commit, tree, target['build']
    for key in ('given', 'when', 'then', 'negative_or_edge'):
        assert case['clauses'][key]['literalExpected'] == original[case['caseId']][key]
        case['clauses'][key].update(actualStatus='not_run_C8', observations=[],
                                    fixtureSHA256=None, artifactPaths=[])
    case['existingDefinitions'] = copy.deepcopy(procedures[case['caseId']]['existingDefinitions'])
    case['addedDefinitions'] = copy.deepcopy(procedures[case['caseId']].get('additionalConcreteHarnessDefinitions', []))
    case['addedLiteralNormalDefinition'] = copy.deepcopy(procedures[case['caseId']].get('additionalSixRequirementOrdinaryDefinitions'))
    case['finalCaseResult'] = 'not_run_C8'
    case['classification'] = 'sealed C8; feasible local original clauses await independent execution; specific physical/live dimensions remain separate'
    for field in ('inputArchives', 'metadataOnlyAssets', 'actualEmbeddedAssets', 'executions'):
        case[field] = []
assert len(ledger['cases']) == 116
write(ROOT / 'ORIGINAL116_C8_CLAUSE_LEDGER_PREPARED.json', ledger)

checks = []
for group in ('sourceFiles', 'originalDocuments', 'distFiles', 'generatedInputs'):
    for item in binding[group]:
        actual = sha(ROOT / 'candidate' / item['file'])
        assert actual == item['sha256'], item['file']
        checks.append({'group': group, 'file': item['file'], 'sha256': actual})

# The explicit module declaration is a control artifact, not product source.
module = ROOT / 'package.json'
assert not module.exists()
module.write_bytes((OLD / 'package.json').read_bytes())
write(ROOT / 'C8_MODULE_CONTROL_SUPPLEMENT.json', {
    'commit': commit, 'tree': tree, 'file': 'package.json', 'sha256': sha(module),
    'source': str(OLD / 'package.json'), 'sourceSHA256': sha(OLD / 'package.json'),
    'reason': 'same explicit ESM control as earlier prepared harness; no product/fixture/assertion change',
    'runtimeStarted': False})

manifest = {
    'target': target, 'preparedAt': now, 'heavyExecutionPaused': True,
    'originalCaseCount': 116, 'originalClausesPreserved': True,
    'actuallyExecutedTestsOnC8': 0, 'originalCasePasses': 0,
    'staticExistingDefinitions': 347, 'staticDefinitionFiles': len({path for path, title in unique}),
    'layerCounts': layers,
    'candidateGroupsVerified': {k: len(binding[k]) for k in ('sourceFiles', 'originalDocuments', 'distFiles', 'generatedInputs')},
    'parent359SourceExactlyMatch': binding['parentSource359ExactlyMatch'],
    'files': [{'file': str(path.relative_to(ROOT)), 'sha256': sha(path)} for path in [
        ROOT/'candidate-binding.json', ROOT/'PROCEDURES_C8_EXTENDED.json',
        ROOT/'ORIGINAL116_C8_CLAUSE_LEDGER_PREPARED.json', ROOT/'SELECTED_C8_TREE_BINDING.json',
        ROOT/'SELECTED_C8_EXECUTION_INPUTS.json', ROOT/'CONTROL_REBINDING_MANIFEST.json',
        ROOT/'LEGACY_THREE_C8_INPUT_BINDING.json', ROOT/'ARTIFACT_DESTINATIONS.json',
        ROOT/'harness-ledger-preparation-failures.json', ROOT/'package.json', ROOT/'C8_MODULE_CONTROL_SUPPLEMENT.json']],
    'sharedSourceGitWrites': 0, 'physical': 'not_run', 'actualAuth': 'not_run',
    'countsNotOriginalAcceptancePasses': True}
write(ROOT / 'C8_FINAL_PREPARATION_BINDING.json', manifest)
print(json.dumps({'preparedBindingSHA256': sha(ROOT / 'C8_FINAL_PREPARATION_BINDING.json'),
                  'procedureSHA256': sha(ROOT / 'PROCEDURES_C8_EXTENDED.json'),
                  'ledgerSHA256': sha(ROOT / 'ORIGINAL116_C8_CLAUSE_LEDGER_PREPARED.json'),
                  'groups': manifest['candidateGroupsVerified'], 'staticLayers': layers,
                  'C8Tests': 0, 'originalPasses': 0}, ensure_ascii=False))
