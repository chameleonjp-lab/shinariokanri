import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createReadStream,createWriteStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const root=dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex'),run=process.env.REVIEW_RUN,mode=process.argv[2];
if(process.env.REVIEW_EXECUTION_WINDOW!=='open'||!run||!/^[a-z0-9-]+$/.test(run)||!process.env.CHROMIUM_PATH?.includes('chromium-1243'))throw Error('Explicit OPEN/run/Chromium153 required.');
if(mode!=='rb04-selected2'&&mode!=='rb03-standalone5')throw Error('Bind one independent component collection.');
const binding=JSON.parse(await readFile(resolve(root,'candidate-binding.json'),'utf8'));
async function verify(){for(const entry of [...binding.sourceFiles,...binding.originalDocuments??[],...binding.distFiles,...binding.generatedInputs??[]])if(sha(await readFile(resolve(root,'candidate',entry.file)))!==entry.sha256)throw Error('Sealed source changed: '+entry.file);}
await verify();const output=resolve(root,'results',run);await mkdir(resolve(root,'results'),{recursive:true});await mkdir(output);await mkdir(resolve(output,'input-source'));
const inputs=[];for(const file of ['execute-independent-components.mjs','vite.independent-components.config.ts','playwright.selected-components.c8.config.ts','candidate/tests/browser/rb03-component-regressions.mjs','candidate/tests/browser/rb03-timeline-smoke.mjs','candidate/tests/browser/rb03-world-smoke.mjs','candidate/tests/rb04/workspace.spec.ts','candidate/tests/rb04/harness.tsx','candidate/tests/rb04/harness.html']){const bytes=await readFile(resolve(root,file)),name=file.replaceAll('/','_');await writeFile(resolve(output,'input-source',name),bytes);inputs.push({file,sha256:sha(bytes)});}
const startedAt=new Date().toISOString();await writeFile(resolve(output,'INPUTS.json'),JSON.stringify({commit:binding.commit,tree:binding.tree,candidateBindingSHA256:sha(await readFile(resolve(root,'candidate-binding.json'))),mode,startedAt,inputs,proofLayer:'developer component source: callback/state harness, NOT production App native transaction or physical browser/OS',productionBuildExecuted:false},null,2)+'\n');
let raw='';const immediate=createWriteStream(resolve(output,'raw.in-progress.log'));
const children=[];function start(command,args,env=process.env){const child=spawn(command,args,{cwd:root,env,stdio:'pipe'});children.push(child);for(const stream of[child.stdout,child.stderr])stream.on('data',bytes=>{raw+=bytes.toString();immediate.write(bytes);process.stdout.write(bytes);});return child;}
function finish(child){return new Promise((done,reject)=>{child.on('error',reject);child.on('close',code=>done(code));});}
let dev,exitCode=0;
try{
 if(mode==='rb04-selected2')exitCode=await finish(start(resolve(root,'node_modules/.bin/playwright'),['test','--config',resolve(root,'playwright.selected-components.c8.config.ts')]));
 else{
  dev=start(resolve(root,'node_modules/.bin/vite'),['--config',resolve(root,'vite.independent-components.config.ts')],{...process.env,REVIEW_DEV_BASE:'/shinariokanri/'});
  let ready=false;for(let i=0;i<1200;i++){if(dev.exitCode!==null)throw Error('Independent Vite exited before readiness');try{const r=await fetch('http://127.0.0.1:5311/shinariokanri/');if(r.ok){ready=true;break;}}catch{}await new Promise(done=>setTimeout(done,100));}if(!ready)throw Error('Independent Vite readiness timeout');
  const external=resolve('/workspace/shinariokanri-independent-artifacts/rb10-c8-fd67f0e',run,'artifacts');await mkdir(external,{recursive:true});
  for(const file of ['rb03-component-regressions.mjs','rb03-timeline-smoke.mjs','rb03-world-smoke.mjs']){
   raw+='\nCOMPONENT_SCRIPT '+file+'\n';immediate.write('\nCOMPONENT_SCRIPT '+file+'\n');
   const code=await finish(start(process.execPath,[resolve(root,'candidate/tests/browser',file)],{...process.env,RB03_ENGINE:'chromium',RB03_CHROMIUM_PATH:process.env.CHROMIUM_PATH,RB03_DEV_URL:'http://127.0.0.1:5311/shinariokanri/',RB03_OUTPUT_DIR:external}));if(code!==0){exitCode=code;break;}
  }
 }
}catch(error){raw+='\n'+String(error)+'\n';immediate.write('\n'+String(error)+'\n');exitCode=1;}
finally{if(dev&&dev.exitCode===null){dev.kill('SIGTERM');await finish(dev);}}
await new Promise(done=>immediate.end(done));await writeFile(resolve(output,'raw.log'),raw);await verify();
async function streamedSHA(file){const h=createHash('sha256');for await(const bytes of createReadStream(file))h.update(bytes);return h.digest('hex');}
const artifacts=[];async function walk(dir,prefix=''){for(const entry of await readdir(dir,{withFileTypes:true})){const q=resolve(dir,entry.name),name=prefix?prefix+'/'+entry.name:entry.name;if(entry.isDirectory())await walk(q,name);else artifacts.push({file:name,sha256:await streamedSHA(q)});}}await walk(output);
const external=resolve('/workspace/shinariokanri-independent-artifacts/rb10-c8-fd67f0e',run,'artifacts'),externalArtifacts=[];async function outside(dir,prefix=''){for(const entry of await readdir(dir,{withFileTypes:true})){const q=resolve(dir,entry.name),name=prefix?prefix+'/'+entry.name:entry.name;if(entry.isDirectory())await outside(q,name);else externalArtifacts.push({file:name,sha256:await streamedSHA(q)});}}await outside(external).catch(error=>{if(error.code!=='ENOENT')throw error;});
await writeFile(resolve(output,'EXECUTION_BINDING.json'),JSON.stringify({commit:binding.commit,tree:binding.tree,candidateBindingSHA256:sha(await readFile(resolve(root,'candidate-binding.json'))),mode,startedAt,finishedAt:new Date().toISOString(),exitCode,rawSHA256:sha(raw),artifacts,externalArtifactRoot:external,externalArtifacts,sourceAndFrozenProductionDistUnchanged:true,proofLayer:'component dev/React callbacks only; production App and durability NOT inferred',actualAuth:'not_run',physical:'not_run',originalAcceptancePassesInferred:0},null,2)+'\n');process.exitCode=exitCode??1;
