import { expect, test, type Page, type TestInfo } from '@playwright/test';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { exportScenario, inspectScenario } from '../candidate/src/storage/archive';
import type { ProjectData } from '../candidate/src/domain/types';
export const digest=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex');
export const appURL='http://127.0.0.1:5310/shinariokanri/';
const capturedFiles=new Map<string,number>();
export async function captureProofFile(bytes:Uint8Array,role:string,extension='scenario'){
 const info=test.info(),key=info.testId,number=(capturedFiles.get(key)??0)+1;capturedFiles.set(key,number);
 const captured=bytes.slice(),sha256=digest(captured),safeRole=role.replace(/[^a-zA-Z0-9_-]/g,'_'),filename=`${number}-${safeRole}-${sha256}.${extension}`,path=info.outputPath(filename);
 await mkdir(info.outputDir,{recursive:true});await writeFile(path,captured);
 await evidence(info,`${number}-${safeRole}-binding`,{role,sha256,bytes:captured.length,file:filename,testId:info.testId,testTitle:info.title,candidateProofScope:'independent fixture or actual downloaded bytes; does not certify physical Files or actual Auth'});
 return {path,sha256,bytes:captured.length};
}
export async function nav(page:Page,name:RegExp){
  const menu=page.getByRole('button',{name:'メニューを開く',exact:true});if(await menu.isVisible())await menu.click();
  await page.locator('.sidebar').getByRole('button',{name}).click();
}
export async function seed(page:Page,p:ProjectData,assets:Record<string,Uint8Array>={},url=appURL,mode:'new'|'clone'='new',metadataOnly=false){
  const bytes=await exportScenario(p,{exportedAt:'2026-10-08T12:00:00.000Z',assetMode:metadataOnly?'metadata_only':'embedded',loadAsset:hash=>assets[hash]});
  await importBytes(page,bytes,url,mode);return bytes;
}
export async function importBytes(page:Page,bytes:Uint8Array,url=appURL,mode:'new'|'clone'='new'){
  await captureProofFile(bytes,`input-${mode}`);
  await page.goto(url==='./'?appURL:url);
  const switcher=page.locator('.project-switch');if(await switcher.isVisible())await switcher.click();
  await page.getByRole('button',{name:'保存ファイルを読み込む',exact:true}).click();
  await page.locator('input[type=file]').setInputFiles({name:'independent.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});
  await expect(page.getByRole('heading',{name:/^検査済みの作品/})).toBeVisible();
  if(mode==='clone')await page.getByLabel('復元方法',{exact:true}).selectOption('clone');
  await page.getByLabel('復元方法と対象への影響を確認しました').check();
  await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect(page.locator('.app-shell')).toBeVisible();await expect(page.locator('.project-switch')).toBeAttached();
}
export async function backup(page:Page){
  await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
  const pending=page.waitForEvent('download');await page.getByRole('button',{name:'完全保存ファイルを作成',exact:true}).click();
  const download=await pending;expect(await download.failure()).toBeNull();const bytes=new Uint8Array(await readFile((await download.path())!));
  await captureProofFile(bytes,'complete-download');
  return {bytes,parsed:await inspectScenario(bytes,{worker:false}),download};
}
export async function durable(page:Page,includeInputs=false){return page.evaluate(async includeInputs=>{
  const db=await new Promise<IDBDatabase>((resolve,reject)=>{const q=indexedDB.open('scenario-manager-local-v1');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
  try{return await new Promise<Record<string,unknown[]>>((resolve,reject)=>{
    const wanted=['projects','entities','relations','blocks','snapshots','commands','outbox','assets','restorePoints','worlds','recoveredPending','recordParts',...(includeInputs?['workspaceInputs','authorToolDrafts']:[])],names=wanted.filter(n=>db.objectStoreNames.contains(n)),tx=db.transaction(names,'readonly'),out:Record<string,unknown[]>={};
    for(const n of names){const q=tx.objectStore(n).getAll();q.onsuccess=()=>{out[n]=q.result;};}tx.oncomplete=()=>resolve(out);tx.onabort=()=>reject(tx.error);tx.onerror=()=>reject(tx.error);
  });}finally{db.close();}
},includeInputs);}
export async function injectQuota(page:Page,message='independent quota'){await page.evaluate(message=>{
  const put=IDBObjectStore.prototype.put;let armed=true;IDBObjectStore.prototype.put=function(...args:Parameters<IDBObjectStore['put']>){if(armed&&this.name==='projects'){armed=false;throw new DOMException(message,'QuotaExceededError');}return put.apply(this,args);};
},message);}
export async function evidence(info:TestInfo,name:string,value:unknown){
  const path=info.outputPath(name+'.json');await mkdir(info.outputDir,{recursive:true});await writeFile(path,JSON.stringify(value,null,2)+'\n');await info.attach(name,{path,contentType:'application/json'});
}
