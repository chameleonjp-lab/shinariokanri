import {readFile} from 'node:fs/promises';
import {createEntity,createProject,emptyValidity,newId,textToRichText} from '../candidate/src/domain/model';
import {allKindsFixture} from '../candidate/src/testing/allKindsFixture';
import {createWorldSnapshot} from '../candidate/src/domain/world';
import {dialogueContentHash} from '../candidate/src/domain/production';
import {forkAuthorAlternative,appendAlternativeVersion,projectContent} from '../candidate/src/domain/writingWorkspace';
import {sealAuthorAlternative} from '../candidate/src/domain/authorAlternativeIntegrity';
import {startTrial,pinTrialRecord} from '../candidate/src/domain/runtime';
import {sha256,jsonBytes} from '../candidate/src/storage/json';
import {prepareReuse} from '../candidate/src/domain/reuse';
import {startTrialVerified} from '../candidate/src/domain/runtimeVerified';
import {stepTrial} from '../candidate/src/domain/runtime';
import type {Condition,Entity,EntityDataMap,EntityKind,ProjectData,PublicTextFields} from '../candidate/src/domain/types';
import {fixedTime,pngBytes,combatFixture} from './fixtures';

function add<K extends EntityKind>(p:ProjectData,kind:K,name:string,data:Partial<EntityDataMap[K]>={}):Entity<K>{
 const e=createEntity(p.projectId,kind,name,data);e.status='confirmed';e.createdAt=e.updatedAt=fixedTime;p.entities.push(e);return e;
}
function get<K extends EntityKind>(p:ProjectData,kind:K):Entity<K>{const e=p.entities.find(e=>e.kind===kind);if(!e)throw Error('missing fixture '+kind);return e as Entity<K>;}
export function keyRoutes(){
 const p=createProject('原E03鍵・二経路・禁止一括効果');
 const key=add(p,'variable','鍵を取った',{key:'has_key',valueType:'boolean',initial:{type:'boolean',value:false},scope:'across_runs'});
 const money=add(p,'variable','所持金',{key:'wallet',valueType:'integer',initial:{type:'integer',value:10},scope:'run',allowed:{min:0,max:100}});
 const state=add(p,'variable','許可状態',{key:'state',valueType:'integer',initial:{type:'integer',value:0},scope:'run',allowed:{min:0,max:3},transitionRules:[{from:{type:'integer',value:0},to:{type:'integer',value:1}}]});
 const itemType=add(p,'item','鍵の種類',{itemMode:'type'}),item=add(p,'item','名前のある鍵',{itemMode:'instance',typeId:itemType.id}),scene=add(p,'scene','同じ合流本文',{body:textToRichText('😀鍵の有無を保つ。')});
 const entry=add(p,'flow_node','鍵の宣言入口',{nodeType:'entry',executionPolicy:'manual_choice'}),merge=add(p,'flow_node','同じ合流先',{nodeType:'choice',sceneId:scene.id,executionPolicy:'manual_choice'}),end=add(p,'flow_node','意図した終端',{nodeType:'terminal',terminalReason:'固定の物語を完了'});
 const take=add(p,'effect','鍵を取得',{operation:'set',targetId:key.id,value:{type:'boolean',value:true}}),grant=add(p,'effect','物品も取得',{operation:'grant',targetId:item.id,instanceId:item.id,value:{type:'integer',value:1}}),addMoney=add(p,'effect','所持金を増やす',{operation:'add',targetId:money.id,value:{type:'integer',value:1}}),bad=add(p,'effect','理由だけの禁止遷移',{operation:'set',targetId:state.id,value:{type:'integer',value:3},reason:'備考だけ'});
 const have=add(p,'flow_edge','鍵を拾って合流',{fromId:entry.id,toId:merge.id,edgeType:'choice',label:'鍵を拾って合流',effectIds:[take.id,grant.id]}),skip=add(p,'flow_edge','鍵を拾わず合流',{fromId:entry.id,toId:merge.id,edgeType:'choice',label:'鍵を拾わず合流'}),invalid=add(p,'flow_edge','禁止batchを試す',{fromId:merge.id,toId:end.id,edgeType:'choice',label:'禁止batchを試す',effectIds:[addMoney.id,grant.id,bad.id]}),finish=add(p,'flow_edge','この状態で終わる',{fromId:merge.id,toId:end.id,edgeType:'choice',label:'この状態で終わる'});
 const graph=add(p,'flow_graph','鍵の二経路',{nodeIds:[entry.id,merge.id,end.id],edgeIds:[have.id,skip.id,invalid.id,finish.id],entryIds:[entry.id],exitIds:[end.id]});
 const unknownVariable=add(p,'variable','未知を偽にしない状態',{key:'unknown_boolean',valueType:'boolean',initial:{type:'unknown',value:null,reason:'作者がまだ決めていない'},scope:'run'});
 const unknownCondition:Condition={op:'compare',variableId:unknownVariable.id,comparator:'eq',value:{type:'boolean',value:true}};
 const unknownEntry=add(p,'flow_node','同じ作品の未知入口',{nodeType:'entry',gate:unknownCondition}),unknownEnd=add(p,'flow_node','未知の確認後だけの終端',{nodeType:'terminal',terminalReason:'未知を解消してから終端'}),unknownEdge=add(p,'flow_edge','未知の値を必要とする選択肢',{fromId:unknownEntry.id,toId:unknownEnd.id,label:'未知の値を必要とする選択肢',condition:structuredClone(unknownCondition)});
 const unknownGraph=add(p,'flow_graph','同じ作品の未知範囲',{nodeIds:[unknownEntry.id,unknownEnd.id],edgeIds:[unknownEdge.id],entryIds:[unknownEntry.id],exitIds:[unknownEnd.id]});
 const emptyEntry=add(p,'flow_node','同じ作品の有効選択肢ゼロ',{nodeType:'entry'}),emptyEnd=add(p,'flow_node','不成立条件の先だけの終端',{nodeType:'terminal',terminalReason:'偽の選択肢では到達しない'}),emptyEdge=add(p,'flow_edge','満たさない選択肢',{fromId:emptyEntry.id,toId:emptyEnd.id,label:'満たさない選択肢',condition:{op:'constant',value:false}});
 const emptyGraph=add(p,'flow_graph','同じ作品の不成立範囲',{nodeIds:[emptyEntry.id,emptyEnd.id],edgeIds:[emptyEdge.id],entryIds:[emptyEntry.id],exitIds:[emptyEnd.id]});
 return {p,key,money,state,itemType,item,scene,entry,merge,end,have,skip,invalid,finish,graph,unknownVariable,unknownEntry,unknownEnd,unknownEdge,unknownGraph,emptyEntry,emptyEnd,emptyEdge,emptyGraph};
}

export async function completeInformation(){
 let p=allKindsFixture();p.name='原E07全情報・回想・制作・旧版';
 p.entities.forEach(e=>{e.createdAt=e.updatedAt=fixedTime;e.status='confirmed';});
 const scene=get(p,'scene'),chapter=get(p,'chapter'),line=get(p,'dialogue_line'),event=get(p,'event'),source=get(p,'source'),asset=get(p,'attachment'),cue=get(p,'cue'),translation=get(p,'localization'),recording=get(p,'recording'),frame=get(p,'storyboard_frame'),task=get(p,'production_task'),node=get(p,'flow_node'),media=get(p,'media_variant');
 scene.name='固有制作を一回数える共通場面';scene.data.body=textToRichText('共通本文😀。<script>window.__originalUnsafe=1</script> javascript:alert(1)');scene.data.dialogueLineIds=[line.id];scene.data.chapterId=chapter.id;scene.data.eventIds=[event.id];chapter.name='前章';chapter.data.sceneIds=[scene.id];
 line.name='同じIDの原文台詞';line.data.text=textToRichText('😀門の前で同じ声を聞いた。');line.data.speakerId=get(p,'character').id;line.data.cueIds=[cue.id];
 event.name='世界tick -10の出来事';event.data.time={mode:'instant',calendarId:p.calendarId,at:'-10'};
 source.data={...source.data,sourceType:'observation',locator:'作者の独立資料',accessedAt:fixedTime,interpretation:textToRichText('取得日時と解釈を保持する。'),redistributionAllowed:true};
 const contentHash=await sha256(pngBytes);asset.name='完全保存する実画像';asset.data={...asset.data,contentHash,byteSize:pngBytes.length,mediaType:'image/png',assetPath:`assets/${contentHash}.png`,displayName:'original-proof.png',stage:'final'};
 const wav=new Uint8Array(await readFile(new URL('../candidate/tests/fixtures/media/fixture-tone.wav',import.meta.url))),wavHash=await sha256(wav),audio=add(p,'attachment','同じ原文の収録bytes',{contentHash:wavHash,byteSize:wav.length,mediaType:'audio/wav',assetPath:`assets/${wavHash}.wav`,stage:'final'});
 cue.data={...cue.data,anchor:{entityId:line.id,blockId:line.data.text[0].id,start:0,end:1},speakerId:line.data.speakerId,attachmentId:audio.id,waitMs:1000,mediaTime:1000,expression:'静か'};
 frame.data={...frame.data,anchor:{entityId:scene.id,blockId:scene.data.body[0].id,start:0,end:3},mediaStartMs:1000,mediaEndMs:2000,cueIds:[cue.id],referenceAssetId:asset.id,finalAssetId:asset.id,caption:textToRichText('現在コマの字幕😀')};
 const hash=await dialogueContentHash(p,line);translation.data={...translation.data,sourceLineId:line.id,sourceHash:hash,stage:'reviewed',text:textToRichText('The same voice.')};recording.data={...recording.data,sourceLineId:line.id,sourceHash:hash,stage:'reviewed',attachmentId:audio.id,translationId:translation.id};
 const unknown=add(p,'event','未定日時の出来事',{time:{mode:'unknown',reason:'作者未決定'}}),huge=add(p,'event','巨大tickの出来事',{time:{mode:'instant',calendarId:p.calendarId,at:'900719925474099312345'}}),secondScene=add(p,'scene','後章の回想',{body:textToRichText('世界tick -10を後章で回想する。'),eventIds:[event.id]}),secondChapter=add(p,'chapter','回想章',{sceneIds:[secondScene.id]});secondScene.data.chapterId=secondChapter.id;
 task.name='執筆済だが実装未完の作業';task.data={...task.data,targetIds:[scene.id],stage:'implementation',progress:'todo',deadline:{date:'2026-11-01',timeZone:'Asia/Tokyo'},estimate:null};
 // The all-kind trial declaration remains a real locally reconstructible record.
 // These fixture calls establish the given; the when uses the normal App only.
 p.entities=p.entities.filter(e=>!['checkpoint','trace'].includes(e.kind));
 const trial=startTrial(p,{entryId:node.id}),ids={checkpointId:newId(),snapshotId:newId()},fixed=pinTrialRecord(trial,ids,p),cp={...createEntity(p.projectId,'checkpoint','完全保存する開始状態',fixed.checkpoint),id:ids.checkpointId},trace=add(p,'trace','完全保存する旧経路',fixed.trace);cp.status='confirmed';p.entities.push(cp);p.snapshots.push({id:ids.snapshotId,content:fixed.content,contentHash:await sha256(jsonBytes(fixed.content)),createdAt:fixedTime,versionLabel:'旧経路の不変版'});
 const deep=createProject('完全保存の基層世界');add(deep,'place','旧世界の場所',{body:textToRichText('基層世界の旧本文😀')});const inner=await createWorldSnapshot(deep,'基層の旧版'),outer=createProject('完全保存の外側世界');outer.worldReferences=[{projectId:inner.projectId,immutableSnapshotId:inner.snapshots[0].id,contentHash:inner.snapshots[0].contentHash}];const world=await createWorldSnapshot(outer,'外側世界の旧版');p.worldReferences=[{projectId:world.projectId,immutableSnapshotId:world.snapshots[0].id,contentHash:world.snapshots[0].contentHash}];
 p=await createWorldSnapshot(p,'本編・小説の旧公開版');const published=p.snapshots.at(-1)!;const currentMedia=get(p,'media_variant');currentMedia.name='公開済み小説';currentMedia.data={...currentMedia.data,medium:'novel',baseSnapshotId:published.id,body:textToRichText('自動置換してはいけない小説の旧本文😀'),releaseAt:'2026-10-20T12:00:00Z',sourceIds:[scene.id],needsReview:false};
 const branch=forkAuthorAlternative(p,'公開済み本文を守る作者別案'),alternate=projectContent(branch.versions[0].content);alternate.entities.find(e=>e.id===scene.id)!.name='別案でだけ改名した場面';p.authorAlternatives=[await sealAuthorAlternative(appendAlternativeVersion(branch,alternate,'別案の比較用に改名'))];
 return {p,scene,chapter,line,event,unknown,huge,secondScene,secondChapter,asset,audio,cue,translation,recording,frame,task,media:currentMedia,trace,published,world,inner,worlds:{[world.snapshots[0].id]:world,[inner.snapshots[0].id]:inner},assets:{[contentHash]:pngBytes,[wavHash]:wav}};
}

export function approvedPublicScope(p:ProjectData,records:Entity[],name='作者確認済みの公開範囲'){
 const publicTexts:Record<string,PublicTextFields>={};
 for(const e of records){const fields:PublicTextFields={};for(const [key,value] of Object.entries(e.data)){if(['body','text','summary','description','key','label','terminalReason','reason','expression','cueType','predicate','question','intent','method','reading','canonical','language','locator','excerptLocation','interpretation'].includes(key)&&value!=null)(fields as Record<string,unknown>)[key]=structuredClone(value);}publicTexts[e.id]=fields;}
 return add(p,'projection_profile',name,{audience:'reader',publicTitle:'独立の公開物語',publicVersionLabel:'原受入用一版',includedIds:records.map(e=>e.id),allowedKinds:[...new Set(records.map(e=>e.kind))],idPolicy:'preserve',namePolicy:{defaultPolicy:{mode:'replace',replacement:'作者確認済み対象'}},publicTexts});
}

export async function approvedProduction(){
 const f=await completeInformation();let p=f.p;
 const source=get(p,'source'),speaker=get(p,'character');
 f.line.data.text[0].ruby=[{start:0,end:2,text:'えもじもん'}];
 f.line.data.text[0].links=[{start:3,end:5,target:{entityId:source.id}}];
 const other=add(p,'dialogue_line','並替える第二台詞',{speakerId:speaker.id,text:textToRichText('二番目も同じ話者😀')});
 f.scene.data.dialogueLineIds=[f.line.id,other.id];f.secondScene.data.dialogueLineIds=[f.line.id];
 const actor=newId();f.task.data={...f.task.data,targetIds:[f.scene.id,f.secondScene.id],assigneeId:actor};
 const hash=await dialogueContentHash(p,f.line);f.translation.data={...f.translation.data,language:'en',sourceHash:hash,stage:'reviewed'};f.recording.data={...f.recording.data,language:'ja',sourceHash:hash,stage:'reviewed'};
 const profile=approvedPublicScope(p,[f.scene,f.secondScene,f.line,other,speaker,source,f.cue,f.audio,f.translation,f.recording,f.task]);profile.data.approvedAttachmentIds=[f.audio.id];
 p=await createWorldSnapshot(p,'改名・並替前の承認済み制作版');const approved=p.snapshots.at(-1)!;
 return {...f,p,source,speaker,other,actor,profile,approved,approvedSourceHash:hash};
}

export async function reuseAndMedia(){
 let p=createProject('原E09共通制作と経路量・媒体旧版');
 const world=createProject('改訂する共通世界'),worldNote=add(world,'lore','共通世界の元設定',{body:textToRichText('旧世界の元設定😀')});const oldWorld=await createWorldSnapshot(world,'採用した旧世界');
 p.worldReferences=[{projectId:oldWorld.projectId,immutableSnapshotId:oldWorld.snapshots[0].id,contentHash:oldWorld.snapshots[0].contentHash}];
 const dateEvent=add(p,'event','共通場面の日付',{time:{mode:'instant',calendarId:p.calendarId,at:'-10'}});
 const line=add(p,'dialogue_line','共通台詞',{text:textToRichText('共通制作は一回である。')}),source=add(p,'scene','固有の共通元',{body:textToRichText('旧共通場面😀'),dialogueLineIds:[line.id],eventIds:[dateEvent.id]}),one=add(p,'scene','使用先A'),two=add(p,'scene','使用先B');
 p=(await prepareReuse(p,{ownerId:one.id,sourceId:source.id,mode:'reference'})).candidate;const reusePin=p.snapshots.at(-1)!;
 p=(await prepareReuse(p,{ownerId:two.id,sourceId:source.id,snapshotId:reusePin.id,mode:'reference'})).candidate;
 const entry=add(p,'flow_node','二経路の宣言入口',{nodeType:'entry',executionPolicy:'manual_choice'}),a=add(p,'flow_node','経路A',{nodeType:'scene',sceneId:one.id}),b=add(p,'flow_node','経路B',{nodeType:'scene',sceneId:two.id}),end=add(p,'flow_node','制作経路の終端',{nodeType:'terminal',terminalReason:'共通場面を読んだ'}),chooseA=add(p,'flow_edge','共通Aへ',{fromId:entry.id,toId:a.id,label:'共通Aへ'}),chooseB=add(p,'flow_edge','共通Bへ',{fromId:entry.id,toId:b.id,label:'共通Bへ'}),endA=add(p,'flow_edge','Aを終わる',{fromId:a.id,toId:end.id,label:'Aを終わる'}),endB=add(p,'flow_edge','Bを終わる',{fromId:b.id,toId:end.id,label:'Bを終わる'}),graph=add(p,'flow_graph','二経路の制作図',{nodeIds:[entry.id,a.id,b.id,end.id],entryIds:[entry.id],exitIds:[end.id],edgeIds:[chooseA.id,chooseB.id,endA.id,endB.id]});
 const task=add(p,'production_task','書けたが未実装',{targetIds:[one.id,two.id],stage:'implementation',progress:'todo',deadline:{date:'2026-11-01',timeZone:'Asia/Tokyo'}});
 const registry={[oldWorld.snapshots[0].id]:oldWorld.snapshots[0].content};
 for(const [choose,finish,name]of [[chooseA,endA,'経路Aの旧版'],[chooseB,endB,'経路Bの旧版']]as const){let trial=await startTrialVerified(p,{entryId:entry.id},registry);trial=stepTrial(p,trial,{edgeId:choose.id});trial=stepTrial(p,trial,{edgeId:finish.id});const ids={checkpointId:newId(),snapshotId:newId()},fixed=pinTrialRecord(trial,ids,p),checkpoint={...createEntity(p.projectId,'checkpoint',name+'開始',fixed.checkpoint),id:ids.checkpointId};checkpoint.status='confirmed';p.entities.push(checkpoint);add(p,'trace',name,fixed.trace);p.snapshots.push({id:ids.snapshotId,content:fixed.content,contentHash:await sha256(jsonBytes(fixed.content)),createdAt:fixedTime,versionLabel:name});}
 p=await createWorldSnapshot(p,'公開した小説の元版');const published=p.snapshots.at(-1)!,media=add(p,'media_variant','公開済み小説',{medium:'novel',baseSnapshotId:published.id,body:textToRichText('旧媒体本文。設定変更で書き換えない。'),sourceIds:[source.id,worldNote.id],releaseAt:'2026-10-20T12:00:00Z',needsReview:false});
 const updatedWorld=structuredClone(oldWorld);updatedWorld.entities.find(e=>e.id===worldNote.id)!.data={body:textToRichText('改訂済みの世界元設定')};updatedWorld.revision='1';const newWorld=await createWorldSnapshot(updatedWorld,'採用前の世界改訂版');
 return {p,source,line,one,two,entry,graph,chooseA,chooseB,endA,endB,task,media,published,oldWorld,newWorld,worldNote,reusePin,dateEvent,worlds:{[oldWorld.snapshots[0].id]:newWorld}};
}

export function presentationNarrative(){
 const p=createProject('原E04提示順・嘘・続編・未知経路'),speaker=add(p,'character','発言する人物C'),subject=add(p,'character','真実の対象'),source=add(p,'source','人物認識の取得元',{sourceType:'observation',locator:'作者が記録した目撃',accessedAt:fixedTime}),clueScene=add(p,'scene','必須情報を見る場面',{body:textToRichText('😀ここで人物が認識を取得する。')}),revealScene=add(p,'scene','真相と嘘の同じ提示',{body:textToRichText('最後に真相を提示する。')});
 const truth=add(p,'assertion','作者が定めた真実',{subjectId:subject.id,predicate:'door_open',value:{type:'boolean',value:true},truthKind:'author_truth'}),belief=add(p,'assertion','人物Cが取得する認識',{subjectId:subject.id,predicate:'door_open',value:{type:'boolean',value:false},truthKind:'belief',holderId:speaker.id,sourceIds:[source.id],evidenceLocation:{entityId:clueScene.id,blockId:clueScene.data.body[0].id,start:0,end:1}}),testimony=add(p,'assertion','嘘として記録する証言',{subjectId:subject.id,predicate:'door_open',value:{type:'boolean',value:false},truthKind:'testimony',holderId:speaker.id,sourceIds:[source.id]});
 const knowledge=add(p,'effect','人物Cが出所付き認識を取得',{operation:'assert',targetId:belief.id,value:{type:'boolean',value:true}}),line=add(p,'dialogue_line','真実と異なる意図した発言',{speakerId:speaker.id,text:textToRichText('😀xyz門は閉じていると話す。'),claimAssertionIds:[testimony.id],assertionIntent:'lie',assertionReason:'相手へ真実を隠すため。出所は目撃資料。'});revealScene.data.dialogueLineIds=[line.id];
 const entry=add(p,'flow_node','全宣言入口の一つ',{nodeType:'entry',executionPolicy:'manual_choice'}),clueNode=add(p,'flow_node','人物認識を取得する経路',{nodeType:'scene',sceneId:clueScene.id}),revealNode=add(p,'flow_node','同じ真相提示へ合流',{nodeType:'scene',sceneId:revealScene.id}),terminal=add(p,'flow_node','続編の問いを残す終端',{nodeType:'terminal',terminalReason:'続編の問いは作者の意図として残す'}),take=add(p,'flow_edge','必須情報を見て進む',{fromId:entry.id,toId:clueNode.id,label:'必須情報を見て進む'}),skip=add(p,'flow_edge','必須情報を飛ばして進む',{fromId:entry.id,toId:revealNode.id,label:'必須情報を飛ばして進む'}),toReveal=add(p,'flow_edge','真相へ進む',{fromId:clueNode.id,toId:revealNode.id,label:'真相へ進む'}),finish=add(p,'flow_edge','続編を残して終わる',{fromId:revealNode.id,toId:terminal.id,label:'続編を残して終わる'}),graph=add(p,'flow_graph','必須情報の二経路',{nodeIds:[entry.id,clueNode.id,revealNode.id,terminal.id],entryIds:[entry.id],exitIds:[terminal.id],edgeIds:[take.id,skip.id,toReveal.id,finish.id]});
 const question=add(p,'foreshadow','今作で必須情報を回収する問い',{question:textToRichText('なぜ門が閉じたと言ったか'),intent:textToRichText('回収前の情報を二経路で照合'),resolutionPolicy:'this_work',truthAssertionIds:[truth.id]}),clue=add(p,'disclosure','省略できない目撃の提示',{foreshadowId:question.id,anchor:{entityId:clueScene.id,blockId:clueScene.data.body[0].id,start:0,end:1},role:'clue',stage:'hint',knowledgeEffects:[knowledge.id]}),payoff=add(p,'disclosure','真相の提示',{foreshadowId:question.id,anchor:{entityId:revealScene.id,blockId:revealScene.data.body[0].id},role:'payoff',stage:'reveal'});question.data.clueIds=[clue.id];question.data.payoffIds=[payoff.id];question.data.requiredInfo=[clue.id];
 const sequel=add(p,'foreshadow','続編で残す謎',{question:textToRichText('門の向こうは誰か'),intent:textToRichText('続編で回収する'),resolutionPolicy:'sequel'}),sequelClue=add(p,'disclosure','続編の問いの提示',{foreshadowId:sequel.id,anchor:{entityId:revealScene.id,blockId:revealScene.data.body[0].id},role:'clue',stage:'hint'});sequel.data.clueIds=[sequelClue.id];
 const late=add(p,'foreshadow','Unicode位置を過ぎた回収',{question:textToRichText('😀の後の位置までに示す'),intent:textToRichText('コードポイント期限の検査'),resolutionPolicy:'this_work',presentationDeadline:{entityId:line.id,lineId:line.id,blockId:line.data.text[0].id,start:1,end:2}}),latePayoff=add(p,'disclosure','同じ台詞の期限より後の回収',{foreshadowId:late.id,anchor:{entityId:line.id,lineId:line.id,blockId:line.data.text[0].id,start:3,end:4},role:'payoff',stage:'reveal'});late.data.payoffIds=[latePayoff.id];
 const chapter=add(p,'chapter','提示順で読む章',{sceneIds:[clueScene.id,revealScene.id]});clueScene.data.chapterId=revealScene.data.chapterId=chapter.id;
 const external=add(p,'external_contract','結果未取得の別宣言入口',{key:'narrative_external',owner:'game',inputType:'boolean',outputType:'boolean',missingPolicy:'block',version:'1.0.0'}),unknownEntry=add(p,'flow_node','外部未確認の宣言入口',{nodeType:'entry',gate:{op:'external',contractId:external.id}}),unknownEnd=add(p,'flow_node','外部確認後だけの終端',{nodeType:'terminal',terminalReason:'実結果の取得が必要'}),unknownEdge=add(p,'flow_edge','実結果がある場合だけ進む',{fromId:unknownEntry.id,toId:unknownEnd.id,label:'実結果がある場合だけ進む'}),unknownGraph=add(p,'flow_graph','未確認を含む別宣言図',{nodeIds:[unknownEntry.id,unknownEnd.id],entryIds:[unknownEntry.id],exitIds:[unknownEnd.id],edgeIds:[unknownEdge.id]});
 return {p,speaker,subject,source,clueScene,revealScene,truth,belief,testimony,knowledge,line,entry,clueNode,revealNode,terminal,take,skip,toReveal,finish,graph,question,clue,payoff,sequel,sequelClue,late,latePayoff,chapter,external,unknownEntry,unknownEnd,unknownEdge,unknownGraph};
}

export function randomLoopAndBattle(){
 const f=combatFixture(),p=f.p;
 const counter=add(p,'variable','上限未宣言の反復回数',{key:'unbounded_count',valueType:'integer',initial:{type:'integer',value:0},scope:'across_runs',allowed:{},resetRules:[{on:'new_loop',value:{type:'integer',value:2}}]}),addCount=add(p,'effect','反復回数を一増やす',{operation:'add',targetId:counter.id,value:{type:'integer',value:1}});
 const randomEntry=add(p,'flow_node','同じseedの抽選入口',{nodeType:'entry',executionPolicy:'manual_choice'}),sceneA=add(p,'scene','抽選したA',{body:textToRichText('😀抽選A')}),sceneB=add(p,'scene','抽選したB',{body:textToRichText('😀抽選B')}),endA=add(p,'flow_node','抽選Aの終端',{nodeType:'terminal',sceneId:sceneA.id,terminalReason:'Aの反応を確認'}),endB=add(p,'flow_node','抽選Bの終端',{nodeType:'terminal',sceneId:sceneB.id,terminalReason:'Bの反応を確認'}),drawA=add(p,'flow_edge','抽選候補A',{fromId:randomEntry.id,toId:endA.id,label:'抽選候補A'}),drawB=add(p,'flow_edge','抽選候補B',{fromId:randomEntry.id,toId:endB.id,label:'抽選候補B'}),randomGraph=add(p,'flow_graph','抽選の宣言図',{nodeIds:[randomEntry.id,endA.id,endB.id],entryIds:[randomEntry.id],exitIds:[endA.id,endB.id],edgeIds:[drawA.id,drawB.id]});
 const loopEntry=add(p,'flow_node','上限未宣言のループ入口',{nodeType:'entry',executionPolicy:'first_match'}),loop=add(p,'flow_edge','終端としない反復',{fromId:loopEntry.id,toId:loopEntry.id,label:'終端としない反復',effectIds:[addCount.id]}),loopGraph=add(p,'flow_graph','停止条件を宣言していない図',{nodeIds:[loopEntry.id],entryIds:[loopEntry.id],exitIds:[],edgeIds:[loop.id]});
 const profile=approvedPublicScope(p,p.entities.filter(e=>e.kind!=='projection_profile'),'抽選・ループ・戦闘の作者確認範囲');profile.data.publicValues=structuredClone(f.profile.data.publicValues);
 return {...f,p,profile,counter,addCount,randomEntry,sceneA,sceneB,endA,endB,drawA,drawB,randomGraph,loopEntry,loop,loopGraph};
}

/** One AST is edited in three normal views; their evaluation state is identical. */
export function commonCondition(){
 const p=createProject('原N16同じ条件・異なる表示');
 const variable=add(p,'variable','共通の真偽状態',{key:'shared_boolean',valueType:'boolean',initial:{type:'boolean',value:true},scope:'run'});
 const trueCondition:Condition={op:'compare',variableId:variable.id,comparator:'eq',value:{type:'boolean',value:true}};
 const falseCondition:Condition={...trueCondition,value:{type:'boolean',value:false}};
 const invalidCondition:Condition={...trueCondition,comparator:'lt'};
 const scene=add(p,'scene','章と分岐で同じ提示',{body:textToRichText('同じ条件と段落IDを維持する😀')});
 const entry=add(p,'flow_node','条件を構造入力する入口',{nodeType:'entry',sceneId:scene.id,gate:structuredClone(trueCondition)}),end=add(p,'flow_node','同じ条件の終端',{nodeType:'terminal',terminalReason:'条件を満たした経路だけの終端'});
 const edge=add(p,'flow_edge','条件を線一覧で編集',{fromId:entry.id,toId:end.id,label:'同じ条件が真なら進む',condition:structuredClone(trueCondition)}),graph=add(p,'flow_graph','条件共有の図',{nodeIds:[entry.id,end.id],entryIds:[entry.id],exitIds:[end.id],edgeIds:[edge.id]});
 const question=add(p,'foreshadow','条件付き提示の問い',{question:textToRichText('同じ状態で同じ条件を観測する'),resolutionPolicy:'sequel'}),disclosure=add(p,'disclosure','条件を詳細入力する提示',{foreshadowId:question.id,anchor:{entityId:scene.id,blockId:scene.data.body[0].id,start:0,end:1},role:'clue',stage:'hint',condition:structuredClone(trueCondition)});question.data.clueIds=[disclosure.id];
 const chapter=add(p,'chapter','共通提示の一章',{sceneIds:[scene.id]});scene.data.chapterId=chapter.id;
 return {p,variable,trueCondition,falseCondition,invalidCondition,scene,entry,end,edge,graph,question,disclosure,chapter};
}
