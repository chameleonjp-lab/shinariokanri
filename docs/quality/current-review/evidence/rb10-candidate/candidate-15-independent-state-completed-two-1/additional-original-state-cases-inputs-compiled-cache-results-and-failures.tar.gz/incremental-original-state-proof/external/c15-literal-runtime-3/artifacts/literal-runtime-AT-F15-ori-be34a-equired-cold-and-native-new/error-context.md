# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: literal-runtime.spec.ts >> AT-F15 original key=true affinity=5 checkpoint, missing affinity and old version: partial is explicit, undo retains same start, migration required, cold and native new
- Location: harness/literal-runtime.spec.ts:87:1

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator: getByRole('button', { name: '鍵ありかつ好感度5', exact: true })
Expected: disabled
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeDisabled" getByRole('button', { name: '鍵ありかつ好感度5', exact: true }) with timeout 10000ms
  - waiting for getByRole('button', { name: '鍵ありかつ好感度5', exact: true })

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- link "本文へ移動":
  - /url: "#main-content"
- complementary "主要ナビゲーション":
  - text: S シナリオ管理
  - button "原F15 鍵あり・好感度5と値欠落 作品一覧へ ⌄":
    - strong: 原F15 鍵あり・好感度5と値欠落
    - text: 作品一覧へ ⌄
  - text: WORKSPACE
  - navigation:
    - button "年表"
    - button "構成"
    - button "資料 0"
    - button "検索"
  - text: QUICK NOTE
  - button "アイデアを残す"
  - button "作品・保存"
  - strong: この端末に保存
  - text: 同期接続先は未設定
  - button "暗い配色にする"
- banner:
  - text: 原F15 鍵あり・好感度5と値欠落 / 構成
  - status: 端末内保存済み LOCAL
- main:
  - text: STORY STRUCTURE
  - heading "構成" [level=1]
  - paragraph: 章から場面へ。物語の道筋を育てる。
  - button "追加"
  - tablist "構成の表示":
    - tab "章・本文"
    - tab "作者別案"
    - tab "章の試読"
    - tab "分岐"
    - tab "状態"
    - tab "伏線"
    - tab "試読・検査" [selected]
    - tab "制作"
  - group: 最近開いた情報・お気に入り
  - heading "試読の開始状態" [level=3]
  - text: 作者メモを含めずに確認 試読の開始点
  - searchbox "試読の開始点を検索"
  - combobox "試読の開始点":
    - option "宣言した入口を使う" [selected]
    - option "型付き途中開始"
    - option "途中開始の終端"
  - text: 試読する作品版
  - searchbox "試読する作品版を検索"
  - combobox "試読する作品版":
    - option "現在の編集稿 · 版 1"
    - option "原F15旧作品版" [selected]
    - option "試読記録の固定版 0"
  - text: 保存した開始状態
  - searchbox "保存した開始状態を検索"
  - combobox "保存した開始状態":
    - option "初期値から開始"
    - option "鍵あり・好感度5の途中状態"
    - option "好感度が欠落した途中状態" [selected]
  - text: 初期提示の世界内tick
  - textbox "試読開始時点の世界内tick"
  - text: 抽選種
  - textbox "抽選種": 物語の試読
  - button "この状態から開始し直す"
  - button "途中開始の状態を作成"
  - text: 未確認の条件 途中開始の経路 · 周回 0
  - checkbox "縦書き"
  - text: 縦書き
  - article:
    - text: SCENE
    - heading "型付き途中開始" [level=2]
    - paragraph: このノードには本文の場面が設定されていません。
    - paragraph: 未確認の条件があり、進行先を確定できません。
    - textbox "試読時点の世界内tick":
      - /placeholder: 期限の判定に使う世界内tick（未入力は不明）
    - button "鍵ありかつ好感度5 未確認 · 状態変数の値がありません。" [disabled]:
      - strong: 鍵ありかつ好感度5
      - text: 未確認 · 状態変数の値がありません。
    - button "一手戻る" [disabled]
    - button "次の周回"
    - button "すべて初期化"
  - complementary:
    - heading "試読の状態" [level=3]
    - paragraph: 作品の設定値とは別に保持しています。
    - strong: 鍵あり
    - text: has_key true
    - button "仮値"
    - strong: 好感度
    - text: affinity 未設定
    - button "仮値"
    - term: 所持品
    - definition: 0個
    - term: 知識・事実
    - definition: 0件
    - term: 既読の対象
    - definition: 1件
    - term: 抽選位置
    - definition: "0"
    - term: 呼出し階層
    - definition: "0"
  - heading "通った経路" [level=3]
  - button "経路を記録" [disabled]
  - list:
    - listitem:
      - text: "1"
      - button "型付き途中開始"
  - text: 場面の到達
  - strong: 0 / 0
  - text: 不明 0 · 除外 0 台詞の到達
  - strong: 0 / 0
  - text: 不明 0 · 除外 0 選択肢の実行
  - strong: 0 / 1
  - text: 不明 0 · 除外 0 条件の真偽確認
  - strong: 1 / 6
  - text: 不明 1 · 除外 0
  - heading "この経路の伏線・回収" [level=3]
  - paragraph: 作者が必須とした情報の提示順を確認します。読者の理解は判定しません。
  - paragraph: この経路で検出された必須提示の不足候補はありません。まだ通っていない回収の評価は含みません。
  - region "開始版の移行と経路の再確認":
    - heading "開始版の移行・変更後の経路確認" [level=3]
    - paragraph: 旧版を保持し、確認した基底revisionで新しい状態と証跡を保存します。移行した開始状態は途中開始として扱います。
    - group: 別版の開始状態を移行する
    - group: 保存した経路を改訂稿で再確認する
  - heading "保存した経路の再実行" [level=3]
  - button "試読経路 · 1遷移 再実行して状態を比較"
  - heading "回帰経路と合流比較" [level=3]
  - paragraph: 宣言経路 0件。保存版・開始由来・仮値を保持し、改訂後の確認とは区別します。
  - checkbox "試読経路 · 1遷移 · 0 · 内部状態"
  - text: 試読経路 · 1遷移 · 0 · 内部状態
  - button "選んだ二経路を再生して比較" [disabled]
  - button "選んだ経路を回帰集合へ保存" [disabled]
  - heading "状態の読取・更新・初期化" [level=3]
  - group: 鍵あり · run · 1箇所
  - group: 好感度 · run · 1箇所
  - heading "分岐の検査" [level=3]
  - button "到達性と行き止まりを検査"
  - paragraph: 最大100,000状態・10,000遷移・30秒の範囲を探索します。未確定値と探索打切りを確認済みとして扱いません。
- contentinfo: 端末内の作品 · 版 1 11件の情報 · 0件の関係
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import type {Entity} from '../candidate/src/domain/types';
  3   | import {originalStateWork,originalCoverageWork,originalCheckpointWork} from './literal-runtime-fixtures';
  4   | import {nav,seed,backup,durable,evidence,digest} from './common';
  5   | import {reader,begin,recordTrial,openRecord,editData,saveEditor,freshRoundtrip} from './extended-support';
  6   | 
  7   | test('AT-F37/F38/F39/F41 original enum life, integer affinity, unknown boolean, run10/across memory/derived: ordinary edits, atomic prohibited quest batch, reasons, cold and fullfile',async({page,browser},info)=>{
  8   |   test.setTimeout(240000);
  9   |   const f=originalStateWork();const input=await seed(page,f.p);
  10  |   await openRecord(page,'variable',f.alive.name);
  11  |   await expect(page.getByRole('region',{name:'同義語・反対語の状態候補',exact:true})).toContainText('存命／死亡');
  12  |   const savedBeforeWrongType=await durable(page);
  13  |   await editData(page,data=>{data.initial={type:'integer',value:1};});
  14  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  15  |   await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();
  16  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  17  |   expect(await durable(page)).toEqual(savedBeforeWrongType);
  18  |   await editData(page,data=>{data.initial={type:'enum',value:'未定義の値'};});
  19  |   await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();
  20  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/許容|候補|値/);
  21  |   expect(await durable(page)).toEqual(savedBeforeWrongType);
  22  |   await editData(page,data=>{data.initial={type:'enum',value:'存命'};});await saveEditor(page);
  23  |   await openRecord(page,'effect',f.derivedWrite.name);const derivedBefore=await durable(page);
  24  |   await editData(page,data=>{data.targetId=f.derived.id;data.value={type:'boolean',value:true};});
  25  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('算出状態へ直接代入できません');
  26  |   expect(await durable(page)).toEqual(derivedBefore);
  27  |   await editData(page,data=>{data.targetId=f.memory.id;data.value={type:'boolean',value:false};});await saveEditor(page);
  28  |   await openRecord(page,'variable',f.derived.name);const cycleBefore=await durable(page);
  29  |   await editData(page,data=>{data.derived={op:'variable',variableId:f.derived.id};});
  30  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/循環/);
  31  |   expect(await durable(page)).toEqual(cycleBefore);
  32  |   await editData(page,data=>{data.derived={op:'compare',variableId:f.affinity.id,comparator:'ge',value:{type:'integer',value:5}};});await saveEditor(page);
  33  |   await reader(page);await begin(page,f.entry.id);
  34  |   await expect(page.locator('.runtime-variable').filter({hasText:f.unsettled.name})).toContainText(/未定|未設定|不明/);
  35  |   const uses=page.locator('details').filter({has:page.locator('summary').filter({hasText:new RegExp('^'+f.affinity.name+' · run ·')})});
  36  |   await uses.locator('summary').first().click();await expect(uses).toContainText('read');await expect(uses).toContainText('update');await expect(uses).toContainText('reset');
  37  |   await uses.getByRole('button',{name:f.setAffinity.name,exact:true}).click();await expect(page.locator('.detail-heading')).toContainText(f.setAffinity.name);await reader(page);
  38  |   await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  39  |   for(const [name,value] of [[f.affinity.name,'5'],[f.money.name,'11'],[f.memory.name,'true'],[f.derived.name,'true']] as const)await expect(page.locator('.runtime-variable').filter({hasText:name})).toContainText(value);
  40  |   const beforeBatch=await durable(page);
  41  |   await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();
  42  |   await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移/);
  43  |   await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('11');
  44  |   await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('完了');
  45  |   expect(await durable(page)).toEqual(beforeBatch);
  46  |   // The whole-batch rejection cannot be repaired by an ordinary reason field.
  47  |   await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  48  |   await page.getByRole('button',{name:f.finish.data.label!,exact:true}).click();await recordTrial(page);
  49  |   const one=await backup(page),trace1=one.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
  50  |   expect(trace1.data.steps.at(-1)!.after.variableValues[f.affinity.id]).toEqual({type:'integer',value:5});
  51  |   expect(trace1.data.steps.at(-1)!.after.variableValues[f.money.id]).toEqual({type:'integer',value:11});
  52  |   await reader(page);await page.getByRole('button',{name:'次の周回',exact:true}).click();
  53  |   await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('10');
  54  |   await expect(page.locator('.runtime-variable').filter({hasText:f.memory.name})).toContainText('true');
  55  |   await page.getByRole('button',{name:'すべて初期化',exact:true}).click();
  56  |   await expect(page.locator('.runtime-variable').filter({hasText:f.memory.name})).toContainText('false');
  57  |   await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  58  |   await page.getByRole('button',{name:f.resetPath.data.label!,exact:true}).click();
  59  |   await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('未受注');
  60  |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText('0');
  61  |   await recordTrial(page);const resetArchive=await backup(page),resetTrace=resetArchive.parsed.project.entities.filter((e):e is Entity<'trace'>=>e.kind==='trace').at(-1)!;
  62  |   expect(resetTrace.data.steps.at(-1)!.before.variableValues[f.questState.id]).toEqual({type:'enum',value:'完了'});
  63  |   expect(resetTrace.data.steps.at(-1)!.after.variableValues[f.questState.id]).toEqual({type:'enum',value:'未受注'});
  64  |   expect(resetTrace.data.steps.at(-1)!.edgeIds).toEqual([f.resetPath.id]);
  65  |   await openRecord(page,'effect',f.prohibited.name);
  66  |   await editData(page,data=>{data.exceptionDetails={reason:'この経路のtick0–10に限り確認済み根拠に従って再受注する',targetScope:{projectId:f.p.projectId,graphId:f.graph.id,routeCondition:{op:'constant',value:true}},validity:{worldRange:{start:'0',end:'10'},routeCondition:{op:'constant',value:true},presentationAnchor:null},evidenceIds:[f.exceptionEvidence.id]};});await saveEditor(page);
  67  |   await reader(page);await page.getByLabel('試読開始時点の世界内tick',{exact:true}).fill('5');await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();
  68  |   await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('未受注');await recordTrial(page);
  69  |   const acceptedException=await backup(page),exceptionTrace=acceptedException.parsed.project.entities.filter((e):e is Entity<'trace'>=>e.kind==='trace').at(-1)!;
  70  |   expect(exceptionTrace.data.steps.at(-1)!.after.itemInstances.some(i=>i.instanceId===f.key.id&&i.quantity===1)).toBe(true);
  71  |   await reader(page);for(const tick of ['11','']){
  72  |     await page.getByLabel('試読開始時点の世界内tick',{exact:true}).fill(tick);await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();const rejectedNative=await durable(page);
  73  |     await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移|期限|時点|例外/);await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('11');await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('完了');expect(await durable(page)).toEqual(rejectedNative);
  74  |   }
  75  |   await nav(page,/^検索/);await page.getByRole('tab',{name:'見直しと統合',exact:true}).click();
  76  |   await expect(page.locator('.search-page')).toContainText(/外部.*利用/);
  77  |   const externalFinding=page.locator('.search-page article').filter({hasText:f.unused.name});
  78  |   await expect(externalFinding.getByRole('button',{name:'外部利用宣言を確認',exact:true})).toBeVisible();
  79  |   await page.reload();await expect(page.locator('.app-shell')).toBeVisible();const cold=await backup(page);
  80  |   expect(cold.parsed.project.entities.find(e=>e.id===f.unused.id)?.deletedAt).toBeFalsy();
  81  |   expect(cold.parsed.project.entities.find(e=>e.id===f.unsettled.id)?.data).toMatchObject({initial:{type:'unknown',value:null}});
  82  |   const restored=await freshRoundtrip(browser,cold.bytes),clone=await freshRoundtrip(browser,cold.bytes,'clone');
  83  |   expect(restored.parsed.project).toEqual(cold.parsed.project);expect(clone.parsed.project.entities.filter(e=>e.kind==='trace')).toHaveLength(3);
  84  |   await evidence(info,'F37-F38-F39-F41-literal-state',{fixtureSHA256:digest(input),sourceValues:{enum:['存命','死亡'],affinityInitial:0,runMoney:10,unknownBoolean:true,acrossRunMemory:true,derivedFrom:f.affinity.id},rejectedWrongTypeAndOutsideAllowed:true,derivedDirectWriteRejected:true,derivedCycleRejected:true,prohibitedQuestTransition:{from:'完了',to:'未受注',reason:'備考だけ',wholeMoneyAndItemBatchRejected:true},explicitResetTrace:resetTrace.data,exceptionTrace:exceptionTrace.data,exceptionInsideTick5Accepted:true,expiredTick11AndUnknownTickWholeBatchRefused:true,ordinaryUnchangedYExternalRetention:true,coldAndNewAndClone:true,archiveSHA256:digest(cold.bytes),fullCasesClaimed:[]});
  85  | });
  86  | 
  87  | test('AT-F15 original key=true affinity=5 checkpoint, missing affinity and old version: partial is explicit, undo retains same start, migration required, cold and native new',async({page,browser},info)=>{
  88  |   test.setTimeout(180000);const f=await originalCheckpointWork(),input=await seed(page,f.p);
  89  |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption(f.pin.id);await page.getByLabel('試読の開始点',{exact:true}).selectOption(f.entry.id);
  90  |   await page.getByLabel('保存した開始状態',{exact:true}).selectOption(f.cp.id);await page.getByRole('button',{name:'試読を始める',exact:true}).click();
  91  |   await expect(page.locator('.reader-trial-heading')).toContainText('途中開始の経路');
  92  |   await page.getByRole('button',{name:f.edge.data.label!,exact:true}).click();await page.getByRole('button',{name:'一手戻る',exact:true}).click();
  93  |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText('5');
  94  |   await page.getByRole('button',{name:f.edge.data.label!,exact:true}).click();await recordTrial(page);
  95  |   const saved=await backup(page),trace=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
  96  |   expect(trace.data.steps[0].before.provenance).toBe('partial');expect(trace.data.coverage?.declaredTests.checked).toBe(0);
  97  |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption(f.pin.id);await page.getByLabel('保存した開始状態',{exact:true}).selectOption(f.missing.id);await page.getByRole('button',{name:'この状態から開始し直す',exact:true}).click();
  98  |   await expect(page.locator('.reader-trial-heading')).toContainText(/未確認|不足/);
> 99  |   await expect(page.getByRole('button',{name:f.edge.data.label!,exact:true})).toBeDisabled();
      |                                                                               ^ Error: expect(locator).toBeDisabled() failed
  100 |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText(/不明|未設定/);
  101 |   await openRecord(page,'flow_edge',f.edge.name);await page.getByLabel('名前',{exact:true}).fill('改訂後でも固定して残る経路');await saveEditor(page);
  102 |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption('');
  103 |   const currentCheckpointOptions=await page.getByLabel('保存した開始状態',{exact:true}).locator('option').evaluateAll(options=>options.map(option=>(option as HTMLOptionElement).value));expect(currentCheckpointOptions).not.toContain(f.cp.id);
  104 |   const migration=page.getByRole('region',{name:'開始版の移行と経路の再確認',exact:true});await migration.locator('summary').filter({hasText:'保存した開始状態を別版へ移す'}).click();
  105 |   await expect(migration).toContainText(/別版|移行/);
  106 |   await page.reload();const cold=await backup(page);expect(cold.parsed.project.entities.find(e=>e.id===f.cp.id)).toEqual(saved.parsed.project.entities.find(e=>e.id===f.cp.id));expect(cold.parsed.project.snapshots.find(p=>p.id===f.pin.id)).toEqual(f.pin);
  107 |   const empty=await freshRoundtrip(browser,cold.bytes);expect(empty.parsed.project.entities.find(e=>e.id===trace.id)).toEqual(trace);
  108 |   await evidence(info,'F15-literal-checkpoint',{fixtureSHA256:digest(input),checkpointIDs:[f.cp.id,f.missing.id],specifiedKeyTrueAndAffinity5:true,fullStateBefore:trace.data.steps[0].before,missingAffinityStayedUnknown:true,partialDidNotCreditFullPlay:true,currentVersionDidNotOfferOldCheckpoint:true,explicitMigrationUI:true,oldPinHash:f.pin.contentHash,coldAndEmpty:true,archiveSHA256:digest(cold.bytes)});
  109 | });
  110 | 
  111 | test('AT-F17 original four scenes / three choices / four condition sites: two-choice fixed trace, separated denominators and changed-content reconfirmation',async({page},info)=>{
  112 |   const f=originalCoverageWork(),input=await seed(page,f.p);await reader(page);await begin(page,f.entry.id);
  113 |   await page.getByRole('button',{name:f.edge1.data.label!,exact:true}).click();await page.getByRole('button',{name:f.edge3.data.label!,exact:true}).click();await recordTrial(page);
  114 |   const saved=await backup(page),trace=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;const coverage=trace.data.coverage!;
  115 |   expect(coverage.scenes.total).toBe(4);expect(coverage.choices.total).toBe(3);expect(coverage.conditionTrue.total).toBe(4);expect(coverage.conditionFalse.total).toBe(4);
  116 |   expect(coverage.scenes.checked).toBe(3);expect(coverage.choices.checked).toBe(2);expect(coverage.dialogue.total).toBe(4);expect(coverage.dialogue.checked).toBe(3);expect(coverage.conditionFalse.checked).toBeLessThan(4);
  117 |   await page.reload();await reader(page);await page.locator('.saved-traces').getByRole('button',{name:new RegExp('^'+trace.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).click();
  118 |   await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  119 |   await openRecord(page,'scene',f.scenes[0].name);await page.getByRole('tab',{name:'本文',exact:true}).click();await page.getByRole('textbox',{name:'本文',exact:true}).fill('原母数を保った改訂内容😀');await saveEditor(page);
  120 |   await reader(page);const reconfirm=page.getByRole('region',{name:'開始版の移行と経路の再確認',exact:true});await reconfirm.locator('summary').filter({hasText:'保存した経路を改訂稿で再確認する'}).click();await reconfirm.getByRole('radio',{name:new RegExp('^'+trace.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).check();
  121 |   await expect(reconfirm).toContainText('再確認待ち');const changed=await backup(page);expect(changed.parsed.project.entities.find(e=>e.id===trace.id)).toEqual(trace);expect(changed.parsed.project.snapshots.find(p=>p.id===trace.data.contentVersionId)).toEqual(saved.parsed.project.snapshots.find(p=>p.id===trace.data.contentVersionId));
  122 |   await evidence(info,'F17-literal-denominators',{fixtureSHA256:digest(input),givenScenes:4,givenChoices:3,givenConditionSites:4,traceID:trace.id,coverage,observedEdges:[f.edge1.id,f.edge3.id],oldEvidenceNotPromotedAfterChange:true,reconfirmationPending:true,archiveSHA256:digest(changed.bytes)});
  123 | });
  124 | 
```