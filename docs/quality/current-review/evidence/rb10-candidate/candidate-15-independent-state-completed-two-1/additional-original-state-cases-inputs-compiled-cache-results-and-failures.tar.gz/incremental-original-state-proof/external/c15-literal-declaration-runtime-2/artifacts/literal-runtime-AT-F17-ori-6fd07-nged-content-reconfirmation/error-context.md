# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: literal-runtime.spec.ts >> AT-F17 original four scenes / three choices / four condition sites: two-choice fixed trace, separated denominators and changed-content reconfirmation
- Location: harness/literal-runtime.spec.ts:111:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 4
Received: 7
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - button "アカウント・専用同期" [ref=e6] [cursor=pointer]
      - generic [ref=e7]: この端末の作品
    - group "任意持出し診断" [ref=e8]:
      - generic "この作業の診断を確認・持出し" [ref=e9]
  - generic [ref=e11]:
    - link "本文へ移動" [ref=e12] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "主要ナビゲーション" [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]: S
        - generic [ref=e16]: シナリオ管理
      - button "原F17 場面4・選択肢3・条件4 作品一覧へ ⌄" [ref=e17] [cursor=pointer]:
        - generic [ref=e19]:
          - strong [ref=e20]: 原F17 場面4・選択肢3・条件4
          - generic [ref=e21]: 作品一覧へ
        - generic [ref=e22]: ⌄
      - generic [ref=e23]: WORKSPACE
      - navigation [ref=e24]:
        - button "年表" [ref=e25] [cursor=pointer]
        - button "構成" [ref=e26] [cursor=pointer]
        - button "資料 0" [ref=e27] [cursor=pointer]:
          - text: 資料
          - generic [ref=e28]: "0"
        - button "検索" [ref=e29] [cursor=pointer]
      - generic [ref=e30]:
        - generic [ref=e31]: QUICK NOTE
        - button "アイデアを残す" [ref=e32] [cursor=pointer]
      - generic [ref=e34]:
        - button "作品・保存" [ref=e35] [cursor=pointer]
        - generic [ref=e38]:
          - strong [ref=e39]: この端末に保存
          - generic [ref=e40]: 同期接続先は未設定
        - button "暗い配色にする" [ref=e41] [cursor=pointer]
    - generic [ref=e42]:
      - banner [ref=e43]:
        - generic [ref=e44]:
          - generic "原F17 場面4・選択肢3・条件4" [ref=e45]
          - generic [ref=e46]: /
          - generic [ref=e47]: 作品
        - status [ref=e48]:
          - generic [ref=e50]: 端末内保存済み
          - generic [ref=e51]: LOCAL
      - main [ref=e52]:
        - generic [ref=e54]:
          - generic [ref=e55]: YOUR PROJECT
          - heading "作品" [level=1] [ref=e56]
          - paragraph [ref=e57]: 作品を保存し、いつでも続きを書けるように。
        - tablist "作品の管理" [ref=e58]:
          - tab "完全保存・復元" [selected] [ref=e59] [cursor=pointer]
          - tab "目的別出力" [ref=e60] [cursor=pointer]
          - tab "変更履歴" [ref=e61] [cursor=pointer]
          - tab "作品の設定" [ref=e62] [cursor=pointer]
          - tab "同期・限定共有" [ref=e63] [cursor=pointer]
        - group [ref=e64]:
          - generic "最近開いた情報・お気に入り" [ref=e65] [cursor=pointer]
        - generic [ref=e68]:
          - generic [ref=e72]:
            - heading "作品を完全保存" [level=3] [ref=e73]
            - paragraph [ref=e74]: 本文・状態・固定世界・履歴・送信待ち・添付を .scenario ファイルに保存します。
            - button "完全保存ファイルを作成" [ref=e75] [cursor=pointer]
            - button "素材bytesを除いて保存" [ref=e76] [cursor=pointer]
          - generic [ref=e80]:
            - heading "ファイルから復元" [level=3] [ref=e81]
            - paragraph [ref=e82]: 元ファイルと対応の入力を端末内に保持し、影響を確認してから復元します。
            - generic [ref=e83] [cursor=pointer]:
              - text: 保存ファイルを選ぶ
              - button "保存ファイルを選ぶ" [ref=e84]
          - status [ref=e85]: 完全保存ファイルを作成しました。端末のダウンロードを確認してください。
      - contentinfo [ref=e86]:
        - generic [ref=e87]: 端末内の作品 · 版 1
        - generic [ref=e88]: 19件の情報 · 0件の関係
```

# Test source

```ts
  15  |   await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();
  16  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  17  |   expect(await durable(page)).toEqual(savedBeforeWrongType);
  18  |   await editData(page,data=>{data.initial={type:'enum',value:'未定義の値'};});
  19  |   await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();
  20  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/許容|候補|値/);
  21  |   expect(await durable(page)).toEqual(savedBeforeWrongType);
  22  |   await editData(page,data=>{data.initial={type:'enum',value:'存命'};});await saveEditor(page);
  23  |   await openRecord(page,'effect',f.derivedWrite.name);const derivedBefore=await durable(page);
  24  |   await editData(page,data=>{data.targetId=f.derived.id;data.value={type:'boolean',value:true};});
  25  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('算出状態へ直接代入できません');
  26  |   expect(await durable(page)).toEqual(derivedBefore);
  27  |   await editData(page,data=>{data.targetId=f.memory.id;data.value={type:'boolean',value:false};});await saveEditor(page);
  28  |   await openRecord(page,'variable',f.derived.name);const cycleBefore=await durable(page);
  29  |   await editData(page,data=>{data.derived={op:'variable',variableId:f.derived.id};});
  30  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/循環/);
  31  |   expect(await durable(page)).toEqual(cycleBefore);
  32  |   await editData(page,data=>{data.derived={op:'compare',variableId:f.affinity.id,comparator:'ge',value:{type:'integer',value:5}};});await saveEditor(page);
  33  |   await reader(page);await begin(page,f.entry.id);
  34  |   await expect(page.locator('.runtime-variable').filter({hasText:f.unsettled.name})).toContainText(/未定|未設定|不明/);
  35  |   const uses=page.locator('details').filter({has:page.locator('summary').filter({hasText:new RegExp('^'+f.affinity.name+' · run ·')})});
  36  |   await uses.locator('summary').first().click();await expect(uses).toContainText('read');await expect(uses).toContainText('write');await expect(uses).toContainText('reset');
  37  |   await uses.getByRole('button',{name:f.setAffinity.name,exact:true}).click();await expect(page.locator('.detail-heading')).toContainText(f.setAffinity.name);await reader(page);
  38  |   await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  39  |   for(const [name,value] of [[f.affinity.name,'5'],[f.money.name,'11'],[f.memory.name,'true'],[f.derived.name,'true']] as const)await expect(page.locator('.runtime-variable').filter({hasText:name})).toContainText(value);
  40  |   const beforeBatch=await durable(page);
  41  |   await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();
  42  |   await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移/);
  43  |   await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('11');
  44  |   await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('完了');
  45  |   expect(await durable(page)).toEqual(beforeBatch);
  46  |   // The whole-batch rejection cannot be repaired by an ordinary reason field.
  47  |   await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  48  |   await page.getByRole('button',{name:f.finish.data.label!,exact:true}).click();await recordTrial(page);
  49  |   const one=await backup(page),trace1=one.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
  50  |   expect(trace1.data.steps.at(-1)!.after.variableValues[f.affinity.id]).toEqual({type:'integer',value:5});
  51  |   expect(trace1.data.steps.at(-1)!.after.variableValues[f.money.id]).toEqual({type:'integer',value:11});
  52  |   await reader(page);await page.getByRole('button',{name:'次の周回',exact:true}).click();
  53  |   await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('10');
  54  |   await expect(page.locator('.runtime-variable').filter({hasText:f.memory.name})).toContainText('true');
  55  |   await page.getByRole('button',{name:'すべて初期化',exact:true}).click();
  56  |   await expect(page.locator('.runtime-variable').filter({hasText:f.memory.name})).toContainText('false');
  57  |   await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  58  |   await page.getByRole('button',{name:f.resetPath.data.label!,exact:true}).click();
  59  |   await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('未受注');
  60  |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText('0');
  61  |   await recordTrial(page);const resetArchive=await backup(page),resetTrace=resetArchive.parsed.project.entities.filter((e):e is Entity<'trace'>=>e.kind==='trace').at(-1)!;
  62  |   expect(resetTrace.data.steps.at(-1)!.before.variableValues[f.questState.id]).toEqual({type:'enum',value:'完了'});
  63  |   expect(resetTrace.data.steps.at(-1)!.after.variableValues[f.questState.id]).toEqual({type:'enum',value:'未受注'});
  64  |   expect(resetTrace.data.steps.at(-1)!.edgeIds).toEqual([f.resetPath.id]);
  65  |   await openRecord(page,'effect',f.prohibited.name);
  66  |   await editData(page,data=>{data.exceptionDetails={reason:'この経路のtick0–10に限り確認済み根拠に従って再受注する',targetScope:{projectId:f.p.projectId,graphId:f.graph.id,routeCondition:{op:'constant',value:true}},validity:{worldRange:{start:'0',end:'10'},routeCondition:{op:'constant',value:true},presentationAnchor:null},evidenceIds:[f.exceptionEvidence.id]};});await saveEditor(page);
  67  |   await reader(page);await page.getByLabel('試読開始時点の世界内tick',{exact:true}).fill('5');await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();
  68  |   await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('未受注');await recordTrial(page);
  69  |   const acceptedException=await backup(page),exceptionTrace=acceptedException.parsed.project.entities.filter((e):e is Entity<'trace'>=>e.kind==='trace').at(-1)!;
  70  |   expect(exceptionTrace.data.steps.at(-1)!.after.itemInstances.some(i=>i.instanceId===f.key.id&&i.quantity===1)).toBe(true);
  71  |   await reader(page);for(const tick of ['11','']){
  72  |     await page.getByLabel('試読開始時点の世界内tick',{exact:true}).fill(tick);await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();const rejectedNative=await durable(page);
  73  |     await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移|期限|時点|例外/);await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('11');await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('完了');expect(await durable(page)).toEqual(rejectedNative);
  74  |   }
  75  |   await nav(page,/^検索/);await page.getByRole('tab',{name:'見直しと統合',exact:true}).click();
  76  |   await expect(page.locator('.search-page')).toContainText(/外部.*利用/);
  77  |   const externalFinding=page.locator('.search-page article').filter({hasText:f.unused.name});
  78  |   await expect(externalFinding.getByRole('button',{name:'外部利用宣言を確認',exact:true})).toBeVisible();
  79  |   await page.reload();await expect(page.locator('.app-shell')).toBeVisible();const cold=await backup(page);
  80  |   expect(cold.parsed.project.entities.find(e=>e.id===f.unused.id)?.deletedAt).toBeFalsy();
  81  |   expect(cold.parsed.project.entities.find(e=>e.id===f.unsettled.id)?.data).toMatchObject({initial:{type:'unknown',value:null}});
  82  |   const restored=await freshRoundtrip(browser,cold.bytes),clone=await freshRoundtrip(browser,cold.bytes,'clone');
  83  |   expect(restored.parsed.project).toEqual(cold.parsed.project);expect(clone.parsed.project.entities.filter(e=>e.kind==='trace')).toHaveLength(3);
  84  |   await evidence(info,'F37-F38-F39-F41-literal-state',{fixtureSHA256:digest(input),sourceValues:{enum:['存命','死亡'],affinityInitial:0,runMoney:10,unknownBoolean:true,acrossRunMemory:true,derivedFrom:f.affinity.id},rejectedWrongTypeAndOutsideAllowed:true,derivedDirectWriteRejected:true,derivedCycleRejected:true,prohibitedQuestTransition:{from:'完了',to:'未受注',reason:'備考だけ',wholeMoneyAndItemBatchRejected:true},explicitResetTrace:resetTrace.data,exceptionTrace:exceptionTrace.data,exceptionInsideTick5Accepted:true,expiredTick11AndUnknownTickWholeBatchRefused:true,ordinaryUnchangedYExternalRetention:true,coldAndNewAndClone:true,archiveSHA256:digest(cold.bytes),fullCasesClaimed:[]});
  85  | });
  86  | 
  87  | test('AT-F15 original key=true affinity=5 checkpoint, missing affinity and old version: partial is explicit, undo retains same start, migration required, cold and native new',async({page,browser},info)=>{
  88  |   test.setTimeout(180000);const f=await originalCheckpointWork(),input=await seed(page,f.p);
  89  |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption(f.pin.id);await page.getByLabel('試読の開始点',{exact:true}).selectOption(f.entry.id);
  90  |   await page.getByLabel('保存した開始状態',{exact:true}).selectOption(f.cp.id);await page.getByRole('button',{name:'試読を始める',exact:true}).click();
  91  |   await expect(page.locator('.reader-trial-heading')).toContainText('途中開始の経路');
  92  |   await page.getByRole('button',{name:f.edge.data.label!,exact:true}).click();await page.getByRole('button',{name:'一手戻る',exact:true}).click();
  93  |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText('5');
  94  |   await page.getByRole('button',{name:f.edge.data.label!,exact:true}).click();await recordTrial(page);
  95  |   const saved=await backup(page),trace=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
  96  |   expect(trace.data.steps[0].before.provenance).toBe('partial');expect(trace.data.coverage?.declaredTests.checked).toBe(0);
  97  |   await reader(page);await page.getByLabel('保存した開始状態',{exact:true}).selectOption(f.missing.id);await page.getByRole('button',{name:'この状態から開始し直す',exact:true}).click();
  98  |   await expect(page.locator('.reader-trial-heading')).toContainText(/未確認|不足/);
  99  |   await expect(page.getByRole('button',{name:f.edge.data.label!,exact:true})).toBeDisabled();
  100 |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText(/不明|未設定/);
  101 |   await openRecord(page,'flow_edge',f.edge.name);await page.getByLabel('名前',{exact:true}).fill('改訂後でも固定して残る経路');await saveEditor(page);
  102 |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption('');
  103 |   const currentCheckpointOptions=await page.getByLabel('保存した開始状態',{exact:true}).locator('option').evaluateAll(options=>options.map(option=>(option as HTMLOptionElement).value));expect(currentCheckpointOptions).not.toContain(f.cp.id);
  104 |   const migration=page.getByRole('region',{name:'開始版の移行と経路の再確認',exact:true});await migration.locator('summary').filter({hasText:'保存した開始状態を別版へ移す'}).click();
  105 |   await expect(migration).toContainText(/別版|移行/);
  106 |   await page.reload();const cold=await backup(page);expect(cold.parsed.project.entities.find(e=>e.id===f.cp.id)).toEqual(saved.parsed.project.entities.find(e=>e.id===f.cp.id));expect(cold.parsed.project.snapshots.find(p=>p.id===f.pin.id)).toEqual(f.pin);
  107 |   const empty=await freshRoundtrip(browser,cold.bytes);expect(empty.parsed.project.entities.find(e=>e.id===trace.id)).toEqual(trace);
  108 |   await evidence(info,'F15-literal-checkpoint',{fixtureSHA256:digest(input),checkpointIDs:[f.cp.id,f.missing.id],specifiedKeyTrueAndAffinity5:true,fullStateBefore:trace.data.steps[0].before,missingAffinityStayedUnknown:true,partialDidNotCreditFullPlay:true,currentVersionDidNotOfferOldCheckpoint:true,explicitMigrationUI:true,oldPinHash:f.pin.contentHash,coldAndEmpty:true,archiveSHA256:digest(cold.bytes)});
  109 | });
  110 | 
  111 | test('AT-F17 original four scenes / three choices / four condition sites: two-choice fixed trace, separated denominators and changed-content reconfirmation',async({page},info)=>{
  112 |   const f=originalCoverageWork(),input=await seed(page,f.p);await reader(page);await begin(page,f.entry.id);
  113 |   await page.getByRole('button',{name:f.edge1.data.label!,exact:true}).click();await page.getByRole('button',{name:f.edge3.data.label!,exact:true}).click();await recordTrial(page);
  114 |   const saved=await backup(page),trace=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;const coverage=trace.data.coverage!;
> 115 |   expect(coverage.scenes.total).toBe(4);expect(coverage.choices.total).toBe(3);expect(coverage.conditionTrue.total).toBe(4);expect(coverage.conditionFalse.total).toBe(4);
      |                                                                                                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  116 |   expect(coverage.scenes.checked).toBe(3);expect(coverage.choices.checked).toBe(2);expect(coverage.dialogue.total).toBe(4);expect(coverage.dialogue.checked).toBe(3);expect(coverage.conditionFalse.checked).toBeLessThan(4);
  117 |   await page.reload();await reader(page);await page.locator('.saved-traces').getByRole('button',{name:new RegExp('^'+trace.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).click();
  118 |   await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  119 |   await openRecord(page,'scene',f.scenes[0].name);await page.getByRole('tab',{name:'本文',exact:true}).click();await page.getByRole('textbox',{name:'本文',exact:true}).fill('原母数を保った改訂内容😀');await saveEditor(page);
  120 |   await reader(page);const reconfirm=page.getByRole('region',{name:'開始版の移行と経路の再確認',exact:true});await reconfirm.locator('summary').filter({hasText:'保存した経路を改訂稿で再確認する'}).click();await reconfirm.getByRole('radio',{name:new RegExp('^'+trace.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).check();
  121 |   await expect(reconfirm).toContainText('再確認待ち');const changed=await backup(page);expect(changed.parsed.project.entities.find(e=>e.id===trace.id)).toEqual(trace);expect(changed.parsed.project.snapshots.find(p=>p.id===trace.data.contentVersionId)).toEqual(saved.parsed.project.snapshots.find(p=>p.id===trace.data.contentVersionId));
  122 |   await evidence(info,'F17-literal-denominators',{fixtureSHA256:digest(input),givenScenes:4,givenChoices:3,givenConditionSites:4,traceID:trace.id,coverage,observedEdges:[f.edge1.id,f.edge3.id],oldEvidenceNotPromotedAfterChange:true,reconfirmationPending:true,archiveSHA256:digest(changed.bytes)});
  123 | });
  124 | 
```