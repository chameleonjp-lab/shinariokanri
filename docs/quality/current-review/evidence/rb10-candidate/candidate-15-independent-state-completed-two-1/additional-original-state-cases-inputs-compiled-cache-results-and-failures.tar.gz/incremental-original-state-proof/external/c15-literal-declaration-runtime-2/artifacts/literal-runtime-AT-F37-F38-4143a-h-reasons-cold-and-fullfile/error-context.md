# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: literal-runtime.spec.ts >> AT-F37/F38/F39/F41 original enum life, integer affinity, unknown boolean, run10/across memory/derived: ordinary edits, atomic prohibited quest batch, reasons, cold and fullfile
- Location: harness/literal-runtime.spec.ts:7:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('details').filter({ has: locator('summary').filter({ hasText: /^好感度 · run ·/ }) })
Expected substring: "write"
Received string:    "好感度 · run · 4箇所好意は好感度から算出 · read · 算出または排他の参照Xを好感度5へ更新 · update · Xを明示初期化する原因 · reset · 作者がXの差を明示して解消するこの差を保って終える · read · 条件・宣言の参照"
Timeout: 10000ms

Call log:
  - Expect "toContainText" locator('details').filter({ has: locator('summary').filter({ hasText: /^好感度 · run ·/ }) }) with timeout 10000ms
  - waiting for locator('details').filter({ has: locator('summary').filter({ hasText: /^好感度 · run ·/ }) })
    24 × locator resolved to <details open="">…</details>
       - unexpected value "好感度 · run · 4箇所好意は好感度から算出 · read · 算出または排他の参照Xを好感度5へ更新 · update · Xを明示初期化する原因 · reset · 作者がXの差を明示して解消するこの差を保って終える · read · 条件・宣言の参照"

```

```yaml
- group:
  - text: 好感度 · run · 4箇所
  - paragraph:
    - button "好意は好感度から算出"
    - text: · read · 算出または排他の参照
  - paragraph:
    - button "Xを好感度5へ更新"
    - text: · update ·
  - paragraph:
    - button "Xを明示初期化する原因"
    - text: · reset · 作者がXの差を明示して解消する
  - paragraph:
    - button "この差を保って終える"
    - text: · read · 条件・宣言の参照
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import type {Entity} from '../candidate/src/domain/types';
  3   | import {originalStateWork,originalCoverageWork,originalCheckpointWork} from './literal-runtime-fixtures';
  4   | import {nav,seed,backup,durable,evidence,digest} from './common';
  5   | import {reader,begin,recordTrial,openRecord,editData,saveEditor,freshRoundtrip} from './extended-support';
  6   | 
  7   | test('AT-F37/F38/F39/F41 original enum life, integer affinity, unknown boolean, run10/across memory/derived: ordinary edits, atomic prohibited quest batch, reasons, cold and fullfile',async({page,browser},info)=>{
  8   |   test.setTimeout(240000);
  9   |   const f=originalStateWork();const input=await seed(page,f.p);
  10  |   await openRecord(page,'variable',f.alive.name);
  11  |   await expect(page.getByRole('region',{name:'同義語・反対語の状態候補',exact:true})).toContainText('存命／死亡');
  12  |   const savedBeforeWrongType=await durable(page);
  13  |   await editData(page,data=>{data.initial={type:'integer',value:1};});
  14  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  15  |   await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();
  16  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  17  |   expect(await durable(page)).toEqual(savedBeforeWrongType);
  18  |   await editData(page,data=>{data.initial={type:'enum',value:'未定義の値'};});
  19  |   await page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/}).click();
  20  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/許容|候補|値/);
  21  |   expect(await durable(page)).toEqual(savedBeforeWrongType);
  22  |   await editData(page,data=>{data.initial={type:'enum',value:'存命'};});await saveEditor(page);
  23  |   await openRecord(page,'effect',f.derivedWrite.name);const derivedBefore=await durable(page);
  24  |   await editData(page,data=>{data.targetId=f.derived.id;data.value={type:'boolean',value:true};});
  25  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('算出状態へ直接代入できません');
  26  |   expect(await durable(page)).toEqual(derivedBefore);
  27  |   await editData(page,data=>{data.targetId=f.memory.id;data.value={type:'boolean',value:false};});await saveEditor(page);
  28  |   await openRecord(page,'variable',f.derived.name);const cycleBefore=await durable(page);
  29  |   await editData(page,data=>{data.derived={op:'variable',variableId:f.derived.id};});
  30  |   await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/循環/);
  31  |   expect(await durable(page)).toEqual(cycleBefore);
  32  |   await editData(page,data=>{data.derived={op:'compare',variableId:f.affinity.id,comparator:'ge',value:{type:'integer',value:5}};});await saveEditor(page);
  33  |   await reader(page);await begin(page,f.entry.id);
  34  |   await expect(page.locator('.runtime-variable').filter({hasText:f.unsettled.name})).toContainText(/未定|未設定|不明/);
  35  |   const uses=page.locator('details').filter({has:page.locator('summary').filter({hasText:new RegExp('^'+f.affinity.name+' · run ·')})});
> 36  |   await uses.locator('summary').first().click();await expect(uses).toContainText('read');await expect(uses).toContainText('write');await expect(uses).toContainText('reset');
      |                                                                                                             ^ Error: expect(locator).toContainText(expected) failed
  37  |   await uses.getByRole('button',{name:f.setAffinity.name,exact:true}).click();await expect(page.locator('.detail-heading')).toContainText(f.setAffinity.name);await reader(page);
  38  |   await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  39  |   for(const [name,value] of [[f.affinity.name,'5'],[f.money.name,'11'],[f.memory.name,'true'],[f.derived.name,'true']] as const)await expect(page.locator('.runtime-variable').filter({hasText:name})).toContainText(value);
  40  |   const beforeBatch=await durable(page);
  41  |   await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();
  42  |   await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移/);
  43  |   await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('11');
  44  |   await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('完了');
  45  |   expect(await durable(page)).toEqual(beforeBatch);
  46  |   // The whole-batch rejection cannot be repaired by an ordinary reason field.
  47  |   await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  48  |   await page.getByRole('button',{name:f.finish.data.label!,exact:true}).click();await recordTrial(page);
  49  |   const one=await backup(page),trace1=one.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
  50  |   expect(trace1.data.steps.at(-1)!.after.variableValues[f.affinity.id]).toEqual({type:'integer',value:5});
  51  |   expect(trace1.data.steps.at(-1)!.after.variableValues[f.money.id]).toEqual({type:'integer',value:11});
  52  |   await reader(page);await page.getByRole('button',{name:'次の周回',exact:true}).click();
  53  |   await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('10');
  54  |   await expect(page.locator('.runtime-variable').filter({hasText:f.memory.name})).toContainText('true');
  55  |   await page.getByRole('button',{name:'すべて初期化',exact:true}).click();
  56  |   await expect(page.locator('.runtime-variable').filter({hasText:f.memory.name})).toContainText('false');
  57  |   await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();
  58  |   await page.getByRole('button',{name:f.resetPath.data.label!,exact:true}).click();
  59  |   await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('未受注');
  60  |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText('0');
  61  |   await recordTrial(page);const resetArchive=await backup(page),resetTrace=resetArchive.parsed.project.entities.filter((e):e is Entity<'trace'>=>e.kind==='trace').at(-1)!;
  62  |   expect(resetTrace.data.steps.at(-1)!.before.variableValues[f.questState.id]).toEqual({type:'enum',value:'完了'});
  63  |   expect(resetTrace.data.steps.at(-1)!.after.variableValues[f.questState.id]).toEqual({type:'enum',value:'未受注'});
  64  |   expect(resetTrace.data.steps.at(-1)!.edgeIds).toEqual([f.resetPath.id]);
  65  |   await openRecord(page,'effect',f.prohibited.name);
  66  |   await editData(page,data=>{data.exceptionDetails={reason:'この経路のtick0–10に限り確認済み根拠に従って再受注する',targetScope:{projectId:f.p.projectId,graphId:f.graph.id,routeCondition:{op:'constant',value:true}},validity:{worldRange:{start:'0',end:'10'},routeCondition:{op:'constant',value:true},presentationAnchor:null},evidenceIds:[f.exceptionEvidence.id]};});await saveEditor(page);
  67  |   await reader(page);await page.getByLabel('試読開始時点の世界内tick',{exact:true}).fill('5');await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();
  68  |   await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('未受注');await recordTrial(page);
  69  |   const acceptedException=await backup(page),exceptionTrace=acceptedException.parsed.project.entities.filter((e):e is Entity<'trace'>=>e.kind==='trace').at(-1)!;
  70  |   expect(exceptionTrace.data.steps.at(-1)!.after.itemInstances.some(i=>i.instanceId===f.key.id&&i.quantity===1)).toBe(true);
  71  |   await reader(page);for(const tick of ['11','']){
  72  |     await page.getByLabel('試読開始時点の世界内tick',{exact:true}).fill(tick);await begin(page,f.entry.id);await page.getByRole('button',{name:f.get.data.label!,exact:true}).click();const rejectedNative=await durable(page);
  73  |     await page.getByRole('button',{name:f.invalid.data.label!,exact:true}).click();await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移|期限|時点|例外/);await expect(page.locator('.runtime-variable').filter({hasText:f.money.name})).toContainText('11');await expect(page.locator('.runtime-variable').filter({hasText:f.questState.name})).toContainText('完了');expect(await durable(page)).toEqual(rejectedNative);
  74  |   }
  75  |   await nav(page,/^検索/);await page.getByRole('tab',{name:'見直しと統合',exact:true}).click();
  76  |   await expect(page.locator('.search-page')).toContainText(/外部.*利用/);
  77  |   const externalFinding=page.locator('.search-page article').filter({hasText:f.unused.name});
  78  |   await expect(externalFinding.getByRole('button',{name:'外部利用宣言を確認',exact:true})).toBeVisible();
  79  |   await page.reload();await expect(page.locator('.app-shell')).toBeVisible();const cold=await backup(page);
  80  |   expect(cold.parsed.project.entities.find(e=>e.id===f.unused.id)?.deletedAt).toBeFalsy();
  81  |   expect(cold.parsed.project.entities.find(e=>e.id===f.unsettled.id)?.data).toMatchObject({initial:{type:'unknown',value:null}});
  82  |   const restored=await freshRoundtrip(browser,cold.bytes),clone=await freshRoundtrip(browser,cold.bytes,'clone');
  83  |   expect(restored.parsed.project).toEqual(cold.parsed.project);expect(clone.parsed.project.entities.filter(e=>e.kind==='trace')).toHaveLength(3);
  84  |   await evidence(info,'F37-F38-F39-F41-literal-state',{fixtureSHA256:digest(input),sourceValues:{enum:['存命','死亡'],affinityInitial:0,runMoney:10,unknownBoolean:true,acrossRunMemory:true,derivedFrom:f.affinity.id},rejectedWrongTypeAndOutsideAllowed:true,derivedDirectWriteRejected:true,derivedCycleRejected:true,prohibitedQuestTransition:{from:'完了',to:'未受注',reason:'備考だけ',wholeMoneyAndItemBatchRejected:true},explicitResetTrace:resetTrace.data,exceptionTrace:exceptionTrace.data,exceptionInsideTick5Accepted:true,expiredTick11AndUnknownTickWholeBatchRefused:true,ordinaryUnchangedYExternalRetention:true,coldAndNewAndClone:true,archiveSHA256:digest(cold.bytes),fullCasesClaimed:[]});
  85  | });
  86  | 
  87  | test('AT-F15 original key=true affinity=5 checkpoint, missing affinity and old version: partial is explicit, undo retains same start, migration required, cold and native new',async({page,browser},info)=>{
  88  |   test.setTimeout(180000);const f=await originalCheckpointWork(),input=await seed(page,f.p);
  89  |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption(f.pin.id);await page.getByLabel('試読の開始点',{exact:true}).selectOption(f.entry.id);
  90  |   await page.getByLabel('保存した開始状態',{exact:true}).selectOption(f.cp.id);await page.getByRole('button',{name:'試読を始める',exact:true}).click();
  91  |   await expect(page.locator('.reader-trial-heading')).toContainText('途中開始の経路');
  92  |   await page.getByRole('button',{name:f.edge.data.label!,exact:true}).click();await page.getByRole('button',{name:'一手戻る',exact:true}).click();
  93  |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText('5');
  94  |   await page.getByRole('button',{name:f.edge.data.label!,exact:true}).click();await recordTrial(page);
  95  |   const saved=await backup(page),trace=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
  96  |   expect(trace.data.steps[0].before.provenance).toBe('partial');expect(trace.data.coverage?.declaredTests.checked).toBe(0);
  97  |   await reader(page);await page.getByLabel('保存した開始状態',{exact:true}).selectOption(f.missing.id);await page.getByRole('button',{name:'この状態から開始し直す',exact:true}).click();
  98  |   await expect(page.locator('.reader-trial-heading')).toContainText(/未確認|不足/);
  99  |   await expect(page.getByRole('button',{name:f.edge.data.label!,exact:true})).toBeDisabled();
  100 |   await expect(page.locator('.runtime-variable').filter({hasText:f.affinity.name})).toContainText(/不明|未設定/);
  101 |   await openRecord(page,'flow_edge',f.edge.name);await page.getByLabel('名前',{exact:true}).fill('改訂後でも固定して残る経路');await saveEditor(page);
  102 |   await reader(page);await page.getByLabel('試読する作品版',{exact:true}).selectOption('');
  103 |   const currentCheckpointOptions=await page.getByLabel('保存した開始状態',{exact:true}).locator('option').evaluateAll(options=>options.map(option=>(option as HTMLOptionElement).value));expect(currentCheckpointOptions).not.toContain(f.cp.id);
  104 |   const migration=page.getByRole('region',{name:'開始版の移行と経路の再確認',exact:true});await migration.locator('summary').filter({hasText:'保存した開始状態を別版へ移す'}).click();
  105 |   await expect(migration).toContainText(/別版|移行/);
  106 |   await page.reload();const cold=await backup(page);expect(cold.parsed.project.entities.find(e=>e.id===f.cp.id)).toEqual(saved.parsed.project.entities.find(e=>e.id===f.cp.id));expect(cold.parsed.project.snapshots.find(p=>p.id===f.pin.id)).toEqual(f.pin);
  107 |   const empty=await freshRoundtrip(browser,cold.bytes);expect(empty.parsed.project.entities.find(e=>e.id===trace.id)).toEqual(trace);
  108 |   await evidence(info,'F15-literal-checkpoint',{fixtureSHA256:digest(input),checkpointIDs:[f.cp.id,f.missing.id],specifiedKeyTrueAndAffinity5:true,fullStateBefore:trace.data.steps[0].before,missingAffinityStayedUnknown:true,partialDidNotCreditFullPlay:true,currentVersionDidNotOfferOldCheckpoint:true,explicitMigrationUI:true,oldPinHash:f.pin.contentHash,coldAndEmpty:true,archiveSHA256:digest(cold.bytes)});
  109 | });
  110 | 
  111 | test('AT-F17 original four scenes / three choices / four condition sites: two-choice fixed trace, separated denominators and changed-content reconfirmation',async({page},info)=>{
  112 |   const f=originalCoverageWork(),input=await seed(page,f.p);await reader(page);await begin(page,f.entry.id);
  113 |   await page.getByRole('button',{name:f.edge1.data.label!,exact:true}).click();await page.getByRole('button',{name:f.edge3.data.label!,exact:true}).click();await recordTrial(page);
  114 |   const saved=await backup(page),trace=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;const coverage=trace.data.coverage!;
  115 |   expect(coverage.scenes.total).toBe(4);expect(coverage.choices.total).toBe(3);expect(coverage.conditionTrue.total).toBe(4);expect(coverage.conditionFalse.total).toBe(4);
  116 |   expect(coverage.scenes.checked).toBe(3);expect(coverage.choices.checked).toBe(2);expect(coverage.dialogue.total).toBe(4);expect(coverage.dialogue.checked).toBe(3);expect(coverage.conditionFalse.checked).toBeLessThan(4);
  117 |   await page.reload();await reader(page);await page.locator('.saved-traces').getByRole('button',{name:new RegExp('^'+trace.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).click();
  118 |   await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  119 |   await openRecord(page,'scene',f.scenes[0].name);await page.getByRole('tab',{name:'本文',exact:true}).click();await page.getByRole('textbox',{name:'本文',exact:true}).fill('原母数を保った改訂内容😀');await saveEditor(page);
  120 |   await reader(page);const reconfirm=page.getByRole('region',{name:'開始版の移行と経路の再確認',exact:true});await reconfirm.locator('summary').filter({hasText:'保存した経路を改訂稿で再確認する'}).click();await reconfirm.getByRole('radio',{name:new RegExp('^'+trace.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).check();
  121 |   await expect(reconfirm).toContainText('再確認待ち');const changed=await backup(page);expect(changed.parsed.project.entities.find(e=>e.id===trace.id)).toEqual(trace);expect(changed.parsed.project.snapshots.find(p=>p.id===trace.data.contentVersionId)).toEqual(saved.parsed.project.snapshots.find(p=>p.id===trace.data.contentVersionId));
  122 |   await evidence(info,'F17-literal-denominators',{fixtureSHA256:digest(input),givenScenes:4,givenChoices:3,givenConditionSites:4,traceID:trace.id,coverage,observedEdges:[f.edge1.id,f.edge3.id],oldEvidenceNotPromotedAfterChange:true,reconfirmationPending:true,archiveSHA256:digest(changed.bytes)});
  123 | });
  124 | 
```