// 8e19d9d6b241c649dec98ca49b5e7005e47f67e6
import { createEntity, createProject, textToRichText } from '../candidate/src/domain/model';
import { createWorldSnapshot } from '../candidate/src/domain/world';
import { startTrial } from '../candidate/src/domain/runtime';
function add(p, kind, name, data = {}) {
  const e = createEntity(p.projectId, kind, name, data);
  e.status = 'confirmed';
  p.entities.push(e);
  return e;
}
const boolean = value => ({
  type: 'boolean',
  value
});
const integer = value => ({
  type: 'integer',
  value
});
const enumeration = value => ({
  type: 'enum',
  value
});

/** The original F37/F38/F39/F41 values, not a renamed integer-only example. */
export function originalStateWork() {
  const p = createProject('原F37–F41 型・初期化・原因・禁止遷移');
  const affinity = add(p, 'variable', '好感度', {
    key: 'affinity',
    valueType: 'integer',
    scope: 'run',
    initial: integer(0),
    allowed: {
      min: 0,
      max: 10
    }
  });
  const alive = add(p, 'variable', '生存', {
    key: 'life',
    valueType: 'enum',
    scope: 'across_runs',
    initial: enumeration('存命'),
    allowed: {
      values: ['存命', '死亡']
    },
    description: textToRichText('存命と死亡は一つの状態の反対の値')
  });
  const unsettled = add(p, 'variable', 'まだ宣言していない真偽', {
    key: 'undecided',
    valueType: 'boolean',
    scope: 'run',
    initial: {
      type: 'unknown',
      value: null,
      reason: '作者がまだ決めていない'
    }
  });
  const money = add(p, 'variable', 'run所持金10', {
    key: 'money',
    valueType: 'integer',
    scope: 'run',
    initial: integer(10),
    allowed: {
      min: 0,
      max: 100
    }
  });
  const memory = add(p, 'variable', 'across_runs記憶', {
    key: 'memory',
    valueType: 'boolean',
    scope: 'across_runs',
    initial: boolean(false)
  });
  const derived = add(p, 'variable', '好意は好感度から算出', {
    key: 'liking',
    valueType: 'boolean',
    scope: 'run',
    initial: {
      type: 'unknown',
      value: null,
      reason: '好感度から算出'
    },
    derived: {
      op: 'compare',
      variableId: affinity.id,
      comparator: 'ge',
      value: integer(5)
    }
  });
  const unused = add(p, 'variable', '未使用Y・外部利用宣言あり', {
    key: 'external_y',
    valueType: 'integer',
    scope: 'across_runs',
    initial: integer(7),
    allowed: {},
    externalUseDeclared: true
  });
  const questState = add(p, 'variable', 'クエスト状態', {
    key: 'quest_state',
    valueType: 'enum',
    scope: 'run',
    initial: enumeration('完了'),
    allowed: {
      values: ['未受注', '進行中', '完了', '失敗']
    },
    transitionRules: [{
      from: enumeration('未受注'),
      to: enumeration('進行中')
    }, {
      from: enumeration('進行中'),
      to: enumeration('完了')
    }, {
      from: enumeration('進行中'),
      to: enumeration('失敗')
    }]
  });
  const quest = add(p, 'quest', '完了と制作進捗を分けるクエスト', {
    key: 'q',
    stateVariableId: questState.id
  });
  const exceptionEvidence = add(p, 'source', '再受注の確認済み根拠', {
    sourceType: 'observation',
    locator: '作者が期限と対象経路を指定した再受注',
    accessedAt: '2026-10-08T12:00:00.000Z'
  });
  const keyType = add(p, 'item', '鍵の種類', {
      itemMode: 'type'
    }),
    key = add(p, 'item', '一つだけの名前付き鍵', {
      itemMode: 'instance',
      typeId: keyType.id
    });
  const first = add(p, 'scene', '状態Xを読んで更新する場面', {
    body: textToRichText('好感度が変わった理由を確認する😀')
  });
  const second = add(p, 'scene', '明示resetの後の場面', {
    body: textToRichText('合流しただけでは初期化しない。')
  });
  const entry = add(p, 'flow_node', '状態と禁止遷移の宣言入口', {
    nodeType: 'entry',
    sceneId: first.id
  });
  const merge = add(p, 'flow_node', '状態Xを読む合流先', {
    nodeType: 'choice',
    sceneId: second.id
  });
  const end = add(p, 'flow_node', '記憶と金額を確認する終端', {
    nodeType: 'terminal',
    terminalReason: '型と規則の確認を終えた'
  });
  const setAffinity = add(p, 'effect', 'Xを好感度5へ更新', {
    operation: 'set',
    targetId: affinity.id,
    value: integer(5)
  });
  const setMemory = add(p, 'effect', '記憶を持ち越す', {
    operation: 'set',
    targetId: memory.id,
    value: boolean(true)
  });
  const addMoney = add(p, 'effect', '所持金を加算する', {
    operation: 'add',
    targetId: money.id,
    value: integer(1)
  });
  const grant = add(p, 'effect', '鍵を一個取得する', {
    operation: 'grant',
    targetId: key.id,
    instanceId: key.id,
    value: integer(1)
  });
  const prohibited = add(p, 'effect', '完了を未受注へ戻す禁止効果', {
    operation: 'set',
    targetId: questState.id,
    value: enumeration('未受注'),
    reason: '備考だけ'
  });
  const reset = add(p, 'effect', '理由付き明示reset', {
    operation: 'reset',
    targetId: questState.id,
    value: enumeration('未受注'),
    reason: '作者が明示して最初からやり直す'
  });
  // Keep the initial file structurally valid. The normal editor later submits
  // the derived target and must refuse it without altering this saved effect.
  const derivedWrite = add(p, 'effect', '算出状態への禁止代入を試す入力元', {
    operation: 'set',
    targetId: memory.id,
    value: boolean(false)
  });
  const get = add(p, 'flow_edge', '好感度5・記憶・所持金11へ進む', {
    fromId: entry.id,
    toId: merge.id,
    label: '好感度5・記憶・所持金11へ進む',
    effectIds: [setAffinity.id, setMemory.id, addMoney.id]
  });
  const skip = add(p, 'flow_edge', '好感度0のまま同じ合流先へ', {
    fromId: entry.id,
    toId: merge.id,
    label: '好感度0のまま同じ合流先へ'
  });
  const invalid = add(p, 'flow_edge', '禁止遷移と金額と鍵を一括適用する', {
    fromId: merge.id,
    toId: end.id,
    label: '禁止遷移と金額と鍵を一括適用する',
    effectIds: [addMoney.id, grant.id, prohibited.id]
  });
  const resetAffinity = add(p, 'effect', 'Xを明示初期化する原因', {
    operation: 'reset',
    targetId: affinity.id,
    value: integer(0),
    reason: '作者がXの差を明示して解消する'
  });
  const resetPath = add(p, 'flow_edge', '理由付きresetだけを明示する', {
    fromId: merge.id,
    toId: end.id,
    label: '理由付きresetだけを明示する',
    effectIds: [reset.id, resetAffinity.id]
  });
  const derivedPath = add(p, 'flow_edge', '算出状態へ直接代入する', {
    fromId: merge.id,
    toId: end.id,
    label: '算出状態へ直接代入する',
    effectIds: [derivedWrite.id]
  });
  const finish = add(p, 'flow_edge', 'この差を保って終える', {
    fromId: merge.id,
    toId: end.id,
    label: 'この差を保って終える',
    condition: {
      op: 'compare',
      variableId: affinity.id,
      comparator: 'ge',
      value: integer(0)
    }
  });
  const graph = add(p, 'flow_graph', '原型と初期化の図', {
    nodeIds: [entry.id, merge.id, end.id],
    edgeIds: [get.id, skip.id, invalid.id, resetPath.id, derivedPath.id, finish.id],
    entryIds: [entry.id],
    exitIds: [end.id]
  });
  return {
    p,
    affinity,
    alive,
    unsettled,
    money,
    memory,
    derived,
    unused,
    questState,
    quest,
    exceptionEvidence,
    keyType,
    key,
    first,
    second,
    entry,
    merge,
    end,
    setAffinity,
    setMemory,
    addMoney,
    grant,
    prohibited,
    reset,
    resetAffinity,
    derivedWrite,
    get,
    skip,
    invalid,
    resetPath,
    derivedPath,
    finish,
    graph
  };
}

/** Four scenes, three choices, four distinct condition observation sites. */
export function originalCoverageWork() {
  const p = createProject('原F17 場面4・選択肢3・条件4');
  const state = add(p, 'variable', '条件結果を分ける状態', {
    key: 'condition_bool',
    valueType: 'boolean',
    scope: 'run',
    initial: boolean(true)
  });
  const scenes = Array.from({
    length: 4
  }, (_, i) => add(p, 'scene', `原母数の場面${i + 1}`, {
    body: textToRichText(`原母数の本文${i + 1}😀`)
  }));
  const entry = add(p, 'flow_node', '母数4/3/4の入口', {
    nodeType: 'entry',
    sceneId: scenes[0].id,
    gate: {
      op: 'compare',
      variableId: state.id,
      comparator: 'eq',
      value: boolean(true)
    }
  });
  const a = add(p, 'flow_node', '二つ目まで確認する場面', {
    nodeType: 'choice',
    sceneId: scenes[1].id
  });
  const b = add(p, 'flow_node', '未選択の第三場面', {
    nodeType: 'terminal',
    sceneId: scenes[2].id,
    terminalReason: '未選択の別経路'
  });
  const end = add(p, 'flow_node', '四番目の意図終端', {
    nodeType: 'terminal',
    sceneId: scenes[3].id,
    terminalReason: '二選択を確認した'
  });
  const edge1 = add(p, 'flow_edge', '母数の選択肢1', {
    fromId: entry.id,
    toId: a.id,
    label: '母数の選択肢1',
    condition: {
      op: 'compare',
      variableId: state.id,
      comparator: 'eq',
      value: boolean(true)
    }
  });
  const edge2 = add(p, 'flow_edge', '母数の選択肢2', {
    fromId: entry.id,
    toId: b.id,
    label: '母数の選択肢2',
    condition: {
      op: 'constant',
      value: true
    }
  });
  const edge3 = add(p, 'flow_edge', '母数の選択肢3', {
    fromId: a.id,
    toId: end.id,
    label: '母数の選択肢3',
    condition: {
      op: 'not',
      child: {
        op: 'compare',
        variableId: state.id,
        comparator: 'eq',
        value: boolean(false)
      }
    }
  });
  const graph = add(p, 'flow_graph', '母数を宣言した図', {
    nodeIds: [entry.id, a.id, b.id, end.id],
    edgeIds: [edge1.id, edge2.id, edge3.id],
    entryIds: [entry.id],
    exitIds: [b.id, end.id]
  });
  const lines = scenes.map((s, i) => {
    const l = add(p, 'dialogue_line', `母数の台詞${i + 1}`, {
      text: textToRichText(`母数の台詞本文${i + 1}`)
    });
    s.data.dialogueLineIds = [l.id];
    return l;
  });
  return {
    p,
    state,
    scenes,
    entry,
    a,
    b,
    end,
    edge1,
    edge2,
    edge3,
    graph,
    lines
  };
}

/** Exact key/affinity checkpoint, plus missing affinity in the same old edition. */
export async function originalCheckpointWork() {
  let p = createProject('原F15 鍵あり・好感度5と値欠落');
  const key = add(p, 'variable', '鍵あり', {
    key: 'has_key',
    valueType: 'boolean',
    scope: 'run',
    initial: boolean(false)
  });
  const affinity = add(p, 'variable', '好感度', {
    key: 'affinity',
    valueType: 'integer',
    scope: 'run',
    initial: integer(0),
    allowed: {
      min: 0,
      max: 10
    }
  });
  const entry = add(p, 'flow_node', '型付き途中開始', {
      nodeType: 'entry'
    }),
    end = add(p, 'flow_node', '途中開始の終端', {
      nodeType: 'terminal',
      terminalReason: '途中からの状態だけを確認した'
    });
  const condition = {
    op: 'all',
    children: [{
      op: 'compare',
      variableId: key.id,
      comparator: 'eq',
      value: boolean(true)
    }, {
      op: 'compare',
      variableId: affinity.id,
      comparator: 'eq',
      value: integer(5)
    }]
  };
  const edge = add(p, 'flow_edge', '鍵ありかつ好感度5', {
    fromId: entry.id,
    toId: end.id,
    label: '鍵ありかつ好感度5',
    condition
  });
  const graph = add(p, 'flow_graph', '途中開始の図', {
    nodeIds: [entry.id, end.id],
    edgeIds: [edge.id],
    entryIds: [entry.id],
    exitIds: [end.id]
  });
  p = await createWorldSnapshot(p, '原F15旧作品版');
  const pin = p.snapshots.at(-1);
  const initial = startTrial(p, {
    entryId: entry.id,
    contentVersionId: pin.id,
    seed: 'original-checkpoint-seed'
  }).startState;
  const state = {
    ...structuredClone(initial),
    provenance: 'partial',
    variableValues: {
      [key.id]: boolean(true),
      [affinity.id]: integer(5)
    }
  };
  const cp = add(p, 'checkpoint', '鍵あり・好感度5の途中状態', {
    contentVersionId: pin.id,
    contentRevision: pin.content.revision,
    runtimeState: state,
    origin: 'partial'
  });
  const missing = add(p, 'checkpoint', '好感度が欠落した途中状態', {
    contentVersionId: pin.id,
    contentRevision: pin.content.revision,
    runtimeState: {
      ...structuredClone(state),
      variableValues: {
        [key.id]: boolean(true)
      }
    },
    origin: 'partial'
  });
  return {
    p,
    key,
    affinity,
    entry,
    end,
    condition,
    edge,
    graph,
    pin,
    cp,
    missing
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjcmVhdGVFbnRpdHkiLCJjcmVhdGVQcm9qZWN0IiwidGV4dFRvUmljaFRleHQiLCJjcmVhdGVXb3JsZFNuYXBzaG90Iiwic3RhcnRUcmlhbCIsImFkZCIsInAiLCJraW5kIiwibmFtZSIsImRhdGEiLCJlIiwicHJvamVjdElkIiwic3RhdHVzIiwiZW50aXRpZXMiLCJwdXNoIiwiYm9vbGVhbiIsInZhbHVlIiwidHlwZSIsImludGVnZXIiLCJlbnVtZXJhdGlvbiIsIm9yaWdpbmFsU3RhdGVXb3JrIiwiYWZmaW5pdHkiLCJrZXkiLCJ2YWx1ZVR5cGUiLCJzY29wZSIsImluaXRpYWwiLCJhbGxvd2VkIiwibWluIiwibWF4IiwiYWxpdmUiLCJ2YWx1ZXMiLCJkZXNjcmlwdGlvbiIsInVuc2V0dGxlZCIsInJlYXNvbiIsIm1vbmV5IiwibWVtb3J5IiwiZGVyaXZlZCIsIm9wIiwidmFyaWFibGVJZCIsImlkIiwiY29tcGFyYXRvciIsInVudXNlZCIsImV4dGVybmFsVXNlRGVjbGFyZWQiLCJxdWVzdFN0YXRlIiwidHJhbnNpdGlvblJ1bGVzIiwiZnJvbSIsInRvIiwicXVlc3QiLCJzdGF0ZVZhcmlhYmxlSWQiLCJleGNlcHRpb25FdmlkZW5jZSIsInNvdXJjZVR5cGUiLCJsb2NhdG9yIiwiYWNjZXNzZWRBdCIsImtleVR5cGUiLCJpdGVtTW9kZSIsInR5cGVJZCIsImZpcnN0IiwiYm9keSIsInNlY29uZCIsImVudHJ5Iiwibm9kZVR5cGUiLCJzY2VuZUlkIiwibWVyZ2UiLCJlbmQiLCJ0ZXJtaW5hbFJlYXNvbiIsInNldEFmZmluaXR5Iiwib3BlcmF0aW9uIiwidGFyZ2V0SWQiLCJzZXRNZW1vcnkiLCJhZGRNb25leSIsImdyYW50IiwiaW5zdGFuY2VJZCIsInByb2hpYml0ZWQiLCJyZXNldCIsImRlcml2ZWRXcml0ZSIsImdldCIsImZyb21JZCIsInRvSWQiLCJsYWJlbCIsImVmZmVjdElkcyIsInNraXAiLCJpbnZhbGlkIiwicmVzZXRBZmZpbml0eSIsInJlc2V0UGF0aCIsImRlcml2ZWRQYXRoIiwiZmluaXNoIiwiY29uZGl0aW9uIiwiZ3JhcGgiLCJub2RlSWRzIiwiZWRnZUlkcyIsImVudHJ5SWRzIiwiZXhpdElkcyIsIm9yaWdpbmFsQ292ZXJhZ2VXb3JrIiwic3RhdGUiLCJzY2VuZXMiLCJBcnJheSIsImxlbmd0aCIsIl8iLCJpIiwiZ2F0ZSIsImEiLCJiIiwiZWRnZTEiLCJlZGdlMiIsImVkZ2UzIiwiY2hpbGQiLCJsaW5lcyIsIm1hcCIsInMiLCJsIiwidGV4dCIsImRpYWxvZ3VlTGluZUlkcyIsIm9yaWdpbmFsQ2hlY2twb2ludFdvcmsiLCJjaGlsZHJlbiIsImVkZ2UiLCJwaW4iLCJzbmFwc2hvdHMiLCJhdCIsImVudHJ5SWQiLCJjb250ZW50VmVyc2lvbklkIiwic2VlZCIsInN0YXJ0U3RhdGUiLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJwcm92ZW5hbmNlIiwidmFyaWFibGVWYWx1ZXMiLCJjcCIsImNvbnRlbnRSZXZpc2lvbiIsImNvbnRlbnQiLCJyZXZpc2lvbiIsInJ1bnRpbWVTdGF0ZSIsIm9yaWdpbiIsIm1pc3NpbmciXSwic291cmNlcyI6WyJsaXRlcmFsLXJ1bnRpbWUtZml4dHVyZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtjcmVhdGVFbnRpdHksY3JlYXRlUHJvamVjdCx0ZXh0VG9SaWNoVGV4dH0gZnJvbSAnLi4vY2FuZGlkYXRlL3NyYy9kb21haW4vbW9kZWwnO1xuaW1wb3J0IHtjcmVhdGVXb3JsZFNuYXBzaG90fSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL2RvbWFpbi93b3JsZCc7XG5pbXBvcnQgdHlwZSB7RW50aXR5LEVudGl0eURhdGFNYXAsRW50aXR5S2luZCxQcm9qZWN0RGF0YSxUeXBlZFZhbHVlLENvbmRpdGlvbn0gZnJvbSAnLi4vY2FuZGlkYXRlL3NyYy9kb21haW4vdHlwZXMnO1xuaW1wb3J0IHtzdGFydFRyaWFsfSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL2RvbWFpbi9ydW50aW1lJztcblxuZnVuY3Rpb24gYWRkPEsgZXh0ZW5kcyBFbnRpdHlLaW5kPihwOlByb2plY3REYXRhLGtpbmQ6SyxuYW1lOnN0cmluZyxkYXRhOlBhcnRpYWw8RW50aXR5RGF0YU1hcFtLXT49e30pOkVudGl0eTxLPntcbiAgY29uc3QgZT1jcmVhdGVFbnRpdHkocC5wcm9qZWN0SWQsa2luZCxuYW1lLGRhdGEpO2Uuc3RhdHVzPSdjb25maXJtZWQnO3AuZW50aXRpZXMucHVzaChlKTtyZXR1cm4gZTtcbn1cbmNvbnN0IGJvb2xlYW49KHZhbHVlOmJvb2xlYW4pOlR5cGVkVmFsdWU9Pih7dHlwZTonYm9vbGVhbicsdmFsdWV9KTtcbmNvbnN0IGludGVnZXI9KHZhbHVlOm51bWJlcik6VHlwZWRWYWx1ZT0+KHt0eXBlOidpbnRlZ2VyJyx2YWx1ZX0pO1xuY29uc3QgZW51bWVyYXRpb249KHZhbHVlOnN0cmluZyk6VHlwZWRWYWx1ZT0+KHt0eXBlOidlbnVtJyx2YWx1ZX0pO1xuXG4vKiogVGhlIG9yaWdpbmFsIEYzNy9GMzgvRjM5L0Y0MSB2YWx1ZXMsIG5vdCBhIHJlbmFtZWQgaW50ZWdlci1vbmx5IGV4YW1wbGUuICovXG5leHBvcnQgZnVuY3Rpb24gb3JpZ2luYWxTdGF0ZVdvcmsoKXtcbiAgY29uc3QgcD1jcmVhdGVQcm9qZWN0KCfljp9GMzfigJNGNDEg5Z6L44O75Yid5pyf5YyW44O75Y6f5Zug44O756aB5q2i6YG356e7Jyk7XG4gIGNvbnN0IGFmZmluaXR5PWFkZChwLCd2YXJpYWJsZScsJ+WlveaEn+W6picse2tleTonYWZmaW5pdHknLHZhbHVlVHlwZTonaW50ZWdlcicsc2NvcGU6J3J1bicsaW5pdGlhbDppbnRlZ2VyKDApLGFsbG93ZWQ6e21pbjowLG1heDoxMH19KTtcbiAgY29uc3QgYWxpdmU9YWRkKHAsJ3ZhcmlhYmxlJywn55Sf5a2YJyx7a2V5OidsaWZlJyx2YWx1ZVR5cGU6J2VudW0nLHNjb3BlOidhY3Jvc3NfcnVucycsaW5pdGlhbDplbnVtZXJhdGlvbign5a2Y5ZG9JyksYWxsb3dlZDp7dmFsdWVzOlsn5a2Y5ZG9Jywn5q275LqhJ119LGRlc2NyaXB0aW9uOnRleHRUb1JpY2hUZXh0KCflrZjlkb3jgajmrbvkuqHjga/kuIDjgaTjga7nirbmhYvjga7lj43lr77jga7lgKQnKX0pO1xuICBjb25zdCB1bnNldHRsZWQ9YWRkKHAsJ3ZhcmlhYmxlJywn44G+44Gg5a6j6KiA44GX44Gm44GE44Gq44GE55yf5YG9Jyx7a2V5Oid1bmRlY2lkZWQnLHZhbHVlVHlwZTonYm9vbGVhbicsc2NvcGU6J3J1bicsaW5pdGlhbDp7dHlwZTondW5rbm93bicsdmFsdWU6bnVsbCxyZWFzb246J+S9nOiAheOBjOOBvuOBoOaxuuOCgeOBpuOBhOOBquOBhCd9fSk7XG4gIGNvbnN0IG1vbmV5PWFkZChwLCd2YXJpYWJsZScsJ3J1buaJgOaMgemHkTEwJyx7a2V5Oidtb25leScsdmFsdWVUeXBlOidpbnRlZ2VyJyxzY29wZToncnVuJyxpbml0aWFsOmludGVnZXIoMTApLGFsbG93ZWQ6e21pbjowLG1heDoxMDB9fSk7XG4gIGNvbnN0IG1lbW9yeT1hZGQocCwndmFyaWFibGUnLCdhY3Jvc3NfcnVuc+iomOaGticse2tleTonbWVtb3J5Jyx2YWx1ZVR5cGU6J2Jvb2xlYW4nLHNjb3BlOidhY3Jvc3NfcnVucycsaW5pdGlhbDpib29sZWFuKGZhbHNlKX0pO1xuICBjb25zdCBkZXJpdmVkPWFkZChwLCd2YXJpYWJsZScsJ+WlveaEj+OBr+WlveaEn+W6puOBi+OCieeul+WHuicse2tleTonbGlraW5nJyx2YWx1ZVR5cGU6J2Jvb2xlYW4nLHNjb3BlOidydW4nLGluaXRpYWw6e3R5cGU6J3Vua25vd24nLHZhbHVlOm51bGwscmVhc29uOiflpb3mhJ/luqbjgYvjgonnrpflh7onfSxkZXJpdmVkOntvcDonY29tcGFyZScsdmFyaWFibGVJZDphZmZpbml0eS5pZCxjb21wYXJhdG9yOidnZScsdmFsdWU6aW50ZWdlcig1KX19KTtcbiAgY29uc3QgdW51c2VkPWFkZChwLCd2YXJpYWJsZScsJ+acquS9v+eUqFnjg7vlpJbpg6jliKnnlKjlrqPoqIDjgYLjgoonLHtrZXk6J2V4dGVybmFsX3knLHZhbHVlVHlwZTonaW50ZWdlcicsc2NvcGU6J2Fjcm9zc19ydW5zJyxpbml0aWFsOmludGVnZXIoNyksYWxsb3dlZDp7fSxleHRlcm5hbFVzZURlY2xhcmVkOnRydWV9KTtcbiAgY29uc3QgcXVlc3RTdGF0ZT1hZGQocCwndmFyaWFibGUnLCfjgq/jgqjjgrnjg4jnirbmhYsnLHtrZXk6J3F1ZXN0X3N0YXRlJyx2YWx1ZVR5cGU6J2VudW0nLHNjb3BlOidydW4nLGluaXRpYWw6ZW51bWVyYXRpb24oJ+WujOS6hicpLGFsbG93ZWQ6e3ZhbHVlczpbJ+acquWPl+azqCcsJ+mAsuihjOS4rScsJ+WujOS6hicsJ+WkseaVlyddfSx0cmFuc2l0aW9uUnVsZXM6W1xuICAgIHtmcm9tOmVudW1lcmF0aW9uKCfmnKrlj5fms6gnKSx0bzplbnVtZXJhdGlvbign6YCy6KGM5LitJyl9LFxuICAgIHtmcm9tOmVudW1lcmF0aW9uKCfpgLLooYzkuK0nKSx0bzplbnVtZXJhdGlvbign5a6M5LqGJyl9LFxuICAgIHtmcm9tOmVudW1lcmF0aW9uKCfpgLLooYzkuK0nKSx0bzplbnVtZXJhdGlvbign5aSx5pWXJyl9LFxuICBdfSk7XG4gIGNvbnN0IHF1ZXN0PWFkZChwLCdxdWVzdCcsJ+WujOS6huOBqOWItuS9nOmAsuaNl+OCkuWIhuOBkeOCi+OCr+OCqOOCueODiCcse2tleToncScsc3RhdGVWYXJpYWJsZUlkOnF1ZXN0U3RhdGUuaWR9KTtcbiAgY29uc3QgZXhjZXB0aW9uRXZpZGVuY2U9YWRkKHAsJ3NvdXJjZScsJ+WGjeWPl+azqOOBrueiuuiqjea4iOOBv+agueaLoCcse3NvdXJjZVR5cGU6J29ic2VydmF0aW9uJyxsb2NhdG9yOifkvZzogIXjgYzmnJ/pmZDjgajlr77osaHntYzot6/jgpLmjIflrprjgZfjgZ/lho3lj5fms6gnLGFjY2Vzc2VkQXQ6JzIwMjYtMTAtMDhUMTI6MDA6MDAuMDAwWid9KTtcbiAgY29uc3Qga2V5VHlwZT1hZGQocCwnaXRlbScsJ+mNteOBrueorumhnicse2l0ZW1Nb2RlOid0eXBlJ30pLGtleT1hZGQocCwnaXRlbScsJ+S4gOOBpOOBoOOBkeOBruWQjeWJjeS7mOOBjemNtScse2l0ZW1Nb2RlOidpbnN0YW5jZScsdHlwZUlkOmtleVR5cGUuaWR9KTtcbiAgY29uc3QgZmlyc3Q9YWRkKHAsJ3NjZW5lJywn54q25oWLWOOCkuiqreOCk+OBp+abtOaWsOOBmeOCi+WgtOmdoicse2JvZHk6dGV4dFRvUmljaFRleHQoJ+WlveaEn+W6puOBjOWkieOCj+OBo+OBn+eQhueUseOCkueiuuiqjeOBmeOCi/CfmIAnKX0pO1xuICBjb25zdCBzZWNvbmQ9YWRkKHAsJ3NjZW5lJywn5piO56S6cmVzZXTjga7lvozjga7loLTpnaInLHtib2R5OnRleHRUb1JpY2hUZXh0KCflkIjmtYHjgZfjgZ/jgaDjgZHjgafjga/liJ3mnJ/ljJbjgZfjgarjgYTjgIInKX0pO1xuICBjb25zdCBlbnRyeT1hZGQocCwnZmxvd19ub2RlJywn54q25oWL44Go56aB5q2i6YG356e744Gu5a6j6KiA5YWl5Y+jJyx7bm9kZVR5cGU6J2VudHJ5JyxzY2VuZUlkOmZpcnN0LmlkfSk7XG4gIGNvbnN0IG1lcmdlPWFkZChwLCdmbG93X25vZGUnLCfnirbmhYtY44KS6Kqt44KA5ZCI5rWB5YWIJyx7bm9kZVR5cGU6J2Nob2ljZScsc2NlbmVJZDpzZWNvbmQuaWR9KTtcbiAgY29uc3QgZW5kPWFkZChwLCdmbG93X25vZGUnLCfoqJjmhrbjgajph5HpoY3jgpLnorroqo3jgZnjgovntYLnq68nLHtub2RlVHlwZTondGVybWluYWwnLHRlcm1pbmFsUmVhc29uOiflnovjgajopo/liYfjga7norroqo3jgpLntYLjgYjjgZ8nfSk7XG4gIGNvbnN0IHNldEFmZmluaXR5PWFkZChwLCdlZmZlY3QnLCdY44KS5aW95oSf5bqmNeOBuOabtOaWsCcse29wZXJhdGlvbjonc2V0Jyx0YXJnZXRJZDphZmZpbml0eS5pZCx2YWx1ZTppbnRlZ2VyKDUpfSk7XG4gIGNvbnN0IHNldE1lbW9yeT1hZGQocCwnZWZmZWN0Jywn6KiY5oa244KS5oyB44Gh6LaK44GZJyx7b3BlcmF0aW9uOidzZXQnLHRhcmdldElkOm1lbW9yeS5pZCx2YWx1ZTpib29sZWFuKHRydWUpfSk7XG4gIGNvbnN0IGFkZE1vbmV5PWFkZChwLCdlZmZlY3QnLCfmiYDmjIHph5HjgpLliqDnrpfjgZnjgosnLHtvcGVyYXRpb246J2FkZCcsdGFyZ2V0SWQ6bW9uZXkuaWQsdmFsdWU6aW50ZWdlcigxKX0pO1xuICBjb25zdCBncmFudD1hZGQocCwnZWZmZWN0Jywn6Y2144KS5LiA5YCL5Y+W5b6X44GZ44KLJyx7b3BlcmF0aW9uOidncmFudCcsdGFyZ2V0SWQ6a2V5LmlkLGluc3RhbmNlSWQ6a2V5LmlkLHZhbHVlOmludGVnZXIoMSl9KTtcbiAgY29uc3QgcHJvaGliaXRlZD1hZGQocCwnZWZmZWN0Jywn5a6M5LqG44KS5pyq5Y+X5rOo44G45oi744GZ56aB5q2i5Yq55p6cJyx7b3BlcmF0aW9uOidzZXQnLHRhcmdldElkOnF1ZXN0U3RhdGUuaWQsdmFsdWU6ZW51bWVyYXRpb24oJ+acquWPl+azqCcpLHJlYXNvbjon5YKZ6ICD44Gg44GRJ30pO1xuICBjb25zdCByZXNldD1hZGQocCwnZWZmZWN0Jywn55CG55Sx5LuY44GN5piO56S6cmVzZXQnLHtvcGVyYXRpb246J3Jlc2V0Jyx0YXJnZXRJZDpxdWVzdFN0YXRlLmlkLHZhbHVlOmVudW1lcmF0aW9uKCfmnKrlj5fms6gnKSxyZWFzb246J+S9nOiAheOBjOaYjuekuuOBl+OBpuacgOWIneOBi+OCieOChOOCiuebtOOBmSd9KTtcbiAgLy8gS2VlcCB0aGUgaW5pdGlhbCBmaWxlIHN0cnVjdHVyYWxseSB2YWxpZC4gVGhlIG5vcm1hbCBlZGl0b3IgbGF0ZXIgc3VibWl0c1xuICAvLyB0aGUgZGVyaXZlZCB0YXJnZXQgYW5kIG11c3QgcmVmdXNlIGl0IHdpdGhvdXQgYWx0ZXJpbmcgdGhpcyBzYXZlZCBlZmZlY3QuXG4gIGNvbnN0IGRlcml2ZWRXcml0ZT1hZGQocCwnZWZmZWN0Jywn566X5Ye654q25oWL44G444Gu56aB5q2i5Luj5YWl44KS6Kmm44GZ5YWl5Yqb5YWDJyx7b3BlcmF0aW9uOidzZXQnLHRhcmdldElkOm1lbW9yeS5pZCx2YWx1ZTpib29sZWFuKGZhbHNlKX0pO1xuICBjb25zdCBnZXQ9YWRkKHAsJ2Zsb3dfZWRnZScsJ+WlveaEn+W6pjXjg7voqJjmhrbjg7vmiYDmjIHph5ExMeOBuOmAsuOCgCcse2Zyb21JZDplbnRyeS5pZCx0b0lkOm1lcmdlLmlkLGxhYmVsOiflpb3mhJ/luqY144O76KiY5oa244O75omA5oyB6YeRMTHjgbjpgLLjgoAnLGVmZmVjdElkczpbc2V0QWZmaW5pdHkuaWQsc2V0TWVtb3J5LmlkLGFkZE1vbmV5LmlkXX0pO1xuICBjb25zdCBza2lwPWFkZChwLCdmbG93X2VkZ2UnLCflpb3mhJ/luqYw44Gu44G+44G+5ZCM44GY5ZCI5rWB5YWI44G4Jyx7ZnJvbUlkOmVudHJ5LmlkLHRvSWQ6bWVyZ2UuaWQsbGFiZWw6J+WlveaEn+W6pjDjga7jgb7jgb7lkIzjgZjlkIjmtYHlhYjjgbgnfSk7XG4gIGNvbnN0IGludmFsaWQ9YWRkKHAsJ2Zsb3dfZWRnZScsJ+emgeatoumBt+enu+OBqOmHkemhjeOBqOmNteOCkuS4gOaLrOmBqeeUqOOBmeOCiycse2Zyb21JZDptZXJnZS5pZCx0b0lkOmVuZC5pZCxsYWJlbDon56aB5q2i6YG356e744Go6YeR6aGN44Go6Y2144KS5LiA5ous6YGp55So44GZ44KLJyxlZmZlY3RJZHM6W2FkZE1vbmV5LmlkLGdyYW50LmlkLHByb2hpYml0ZWQuaWRdfSk7XG4gIGNvbnN0IHJlc2V0QWZmaW5pdHk9YWRkKHAsJ2VmZmVjdCcsJ1jjgpLmmI7npLrliJ3mnJ/ljJbjgZnjgovljp/lm6AnLHtvcGVyYXRpb246J3Jlc2V0Jyx0YXJnZXRJZDphZmZpbml0eS5pZCx2YWx1ZTppbnRlZ2VyKDApLHJlYXNvbjon5L2c6ICF44GMWOOBruW3ruOCkuaYjuekuuOBl+OBpuino+a2iOOBmeOCiyd9KTtcbiAgY29uc3QgcmVzZXRQYXRoPWFkZChwLCdmbG93X2VkZ2UnLCfnkIbnlLHku5jjgY1yZXNldOOBoOOBkeOCkuaYjuekuuOBmeOCiycse2Zyb21JZDptZXJnZS5pZCx0b0lkOmVuZC5pZCxsYWJlbDon55CG55Sx5LuY44GNcmVzZXTjgaDjgZHjgpLmmI7npLrjgZnjgosnLGVmZmVjdElkczpbcmVzZXQuaWQscmVzZXRBZmZpbml0eS5pZF19KTtcbiAgY29uc3QgZGVyaXZlZFBhdGg9YWRkKHAsJ2Zsb3dfZWRnZScsJ+eul+WHuueKtuaFi+OBuOebtOaOpeS7o+WFpeOBmeOCiycse2Zyb21JZDptZXJnZS5pZCx0b0lkOmVuZC5pZCxsYWJlbDon566X5Ye654q25oWL44G455u05o6l5Luj5YWl44GZ44KLJyxlZmZlY3RJZHM6W2Rlcml2ZWRXcml0ZS5pZF19KTtcbiAgY29uc3QgZmluaXNoPWFkZChwLCdmbG93X2VkZ2UnLCfjgZPjga7lt67jgpLkv53jgaPjgabntYLjgYjjgosnLHtmcm9tSWQ6bWVyZ2UuaWQsdG9JZDplbmQuaWQsbGFiZWw6J+OBk+OBruW3ruOCkuS/neOBo+OBpue1guOBiOOCiycsY29uZGl0aW9uOntvcDonY29tcGFyZScsdmFyaWFibGVJZDphZmZpbml0eS5pZCxjb21wYXJhdG9yOidnZScsdmFsdWU6aW50ZWdlcigwKX19KTtcbiAgY29uc3QgZ3JhcGg9YWRkKHAsJ2Zsb3dfZ3JhcGgnLCfljp/lnovjgajliJ3mnJ/ljJbjga7lm7MnLHtub2RlSWRzOltlbnRyeS5pZCxtZXJnZS5pZCxlbmQuaWRdLGVkZ2VJZHM6W2dldC5pZCxza2lwLmlkLGludmFsaWQuaWQscmVzZXRQYXRoLmlkLGRlcml2ZWRQYXRoLmlkLGZpbmlzaC5pZF0sZW50cnlJZHM6W2VudHJ5LmlkXSxleGl0SWRzOltlbmQuaWRdfSk7XG4gIHJldHVybiB7cCxhZmZpbml0eSxhbGl2ZSx1bnNldHRsZWQsbW9uZXksbWVtb3J5LGRlcml2ZWQsdW51c2VkLHF1ZXN0U3RhdGUscXVlc3QsZXhjZXB0aW9uRXZpZGVuY2Usa2V5VHlwZSxrZXksZmlyc3Qsc2Vjb25kLGVudHJ5LG1lcmdlLGVuZCxzZXRBZmZpbml0eSxzZXRNZW1vcnksYWRkTW9uZXksZ3JhbnQscHJvaGliaXRlZCxyZXNldCxyZXNldEFmZmluaXR5LGRlcml2ZWRXcml0ZSxnZXQsc2tpcCxpbnZhbGlkLHJlc2V0UGF0aCxkZXJpdmVkUGF0aCxmaW5pc2gsZ3JhcGh9O1xufVxuXG4vKiogRm91ciBzY2VuZXMsIHRocmVlIGNob2ljZXMsIGZvdXIgZGlzdGluY3QgY29uZGl0aW9uIG9ic2VydmF0aW9uIHNpdGVzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9yaWdpbmFsQ292ZXJhZ2VXb3JrKCl7XG4gIGNvbnN0IHA9Y3JlYXRlUHJvamVjdCgn5Y6fRjE3IOWgtOmdojTjg7vpgbjmip7ogqIz44O75p2h5Lu2NCcpO1xuICBjb25zdCBzdGF0ZT1hZGQocCwndmFyaWFibGUnLCfmnaHku7bntZDmnpzjgpLliIbjgZHjgovnirbmhYsnLHtrZXk6J2NvbmRpdGlvbl9ib29sJyx2YWx1ZVR5cGU6J2Jvb2xlYW4nLHNjb3BlOidydW4nLGluaXRpYWw6Ym9vbGVhbih0cnVlKX0pO1xuICBjb25zdCBzY2VuZXM9QXJyYXkuZnJvbSh7bGVuZ3RoOjR9LChfLGkpPT5hZGQocCwnc2NlbmUnLGDljp/mr43mlbDjga7loLTpnaIke2krMX1gLHtib2R5OnRleHRUb1JpY2hUZXh0KGDljp/mr43mlbDjga7mnKzmlocke2krMX3wn5iAYCl9KSk7XG4gIGNvbnN0IGVudHJ5PWFkZChwLCdmbG93X25vZGUnLCfmr43mlbA0LzMvNOOBruWFpeWPoycse25vZGVUeXBlOidlbnRyeScsc2NlbmVJZDpzY2VuZXNbMF0uaWQsZ2F0ZTp7b3A6J2NvbXBhcmUnLHZhcmlhYmxlSWQ6c3RhdGUuaWQsY29tcGFyYXRvcjonZXEnLHZhbHVlOmJvb2xlYW4odHJ1ZSl9fSk7XG4gIGNvbnN0IGE9YWRkKHAsJ2Zsb3dfbm9kZScsJ+S6jOOBpOebruOBvuOBp+eiuuiqjeOBmeOCi+WgtOmdoicse25vZGVUeXBlOidjaG9pY2UnLHNjZW5lSWQ6c2NlbmVzWzFdLmlkfSk7XG4gIGNvbnN0IGI9YWRkKHAsJ2Zsb3dfbm9kZScsJ+acqumBuOaKnuOBruesrOS4ieWgtOmdoicse25vZGVUeXBlOid0ZXJtaW5hbCcsc2NlbmVJZDpzY2VuZXNbMl0uaWQsdGVybWluYWxSZWFzb246J+acqumBuOaKnuOBruWIpee1jOi3ryd9KTtcbiAgY29uc3QgZW5kPWFkZChwLCdmbG93X25vZGUnLCflm5vnlarnm67jga7mhI/lm7PntYLnq68nLHtub2RlVHlwZTondGVybWluYWwnLHNjZW5lSWQ6c2NlbmVzWzNdLmlkLHRlcm1pbmFsUmVhc29uOifkuozpgbjmip7jgpLnorroqo3jgZfjgZ8nfSk7XG4gIGNvbnN0IGVkZ2UxPWFkZChwLCdmbG93X2VkZ2UnLCfmr43mlbDjga7pgbjmip7ogqIxJyx7ZnJvbUlkOmVudHJ5LmlkLHRvSWQ6YS5pZCxsYWJlbDon5q+N5pWw44Gu6YG45oqe6IKiMScsY29uZGl0aW9uOntvcDonY29tcGFyZScsdmFyaWFibGVJZDpzdGF0ZS5pZCxjb21wYXJhdG9yOidlcScsdmFsdWU6Ym9vbGVhbih0cnVlKX19KTtcbiAgY29uc3QgZWRnZTI9YWRkKHAsJ2Zsb3dfZWRnZScsJ+avjeaVsOOBrumBuOaKnuiCojInLHtmcm9tSWQ6ZW50cnkuaWQsdG9JZDpiLmlkLGxhYmVsOifmr43mlbDjga7pgbjmip7ogqIyJyxjb25kaXRpb246e29wOidjb25zdGFudCcsdmFsdWU6dHJ1ZX19KTtcbiAgY29uc3QgZWRnZTM9YWRkKHAsJ2Zsb3dfZWRnZScsJ+avjeaVsOOBrumBuOaKnuiCojMnLHtmcm9tSWQ6YS5pZCx0b0lkOmVuZC5pZCxsYWJlbDon5q+N5pWw44Gu6YG45oqe6IKiMycsY29uZGl0aW9uOntvcDonbm90JyxjaGlsZDp7b3A6J2NvbXBhcmUnLHZhcmlhYmxlSWQ6c3RhdGUuaWQsY29tcGFyYXRvcjonZXEnLHZhbHVlOmJvb2xlYW4oZmFsc2UpfX19KTtcbiAgY29uc3QgZ3JhcGg9YWRkKHAsJ2Zsb3dfZ3JhcGgnLCfmr43mlbDjgpLlrqPoqIDjgZfjgZ/lm7MnLHtub2RlSWRzOltlbnRyeS5pZCxhLmlkLGIuaWQsZW5kLmlkXSxlZGdlSWRzOltlZGdlMS5pZCxlZGdlMi5pZCxlZGdlMy5pZF0sZW50cnlJZHM6W2VudHJ5LmlkXSxleGl0SWRzOltiLmlkLGVuZC5pZF19KTtcbiAgY29uc3QgbGluZXM9c2NlbmVzLm1hcCgocyxpKT0+e2NvbnN0IGw9YWRkKHAsJ2RpYWxvZ3VlX2xpbmUnLGDmr43mlbDjga7lj7DoqZ4ke2krMX1gLHt0ZXh0OnRleHRUb1JpY2hUZXh0KGDmr43mlbDjga7lj7DoqZ7mnKzmlocke2krMX1gKX0pO3MuZGF0YS5kaWFsb2d1ZUxpbmVJZHM9W2wuaWRdO3JldHVybiBsO30pO1xuICByZXR1cm4ge3Asc3RhdGUsc2NlbmVzLGVudHJ5LGEsYixlbmQsZWRnZTEsZWRnZTIsZWRnZTMsZ3JhcGgsbGluZXN9O1xufVxuXG4vKiogRXhhY3Qga2V5L2FmZmluaXR5IGNoZWNrcG9pbnQsIHBsdXMgbWlzc2luZyBhZmZpbml0eSBpbiB0aGUgc2FtZSBvbGQgZWRpdGlvbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcmlnaW5hbENoZWNrcG9pbnRXb3JrKCl7XG4gIGxldCBwPWNyZWF0ZVByb2plY3QoJ+WOn0YxNSDpjbXjgYLjgorjg7vlpb3mhJ/luqY144Go5YCk5qyg6JC9Jyk7XG4gIGNvbnN0IGtleT1hZGQocCwndmFyaWFibGUnLCfpjbXjgYLjgoonLHtrZXk6J2hhc19rZXknLHZhbHVlVHlwZTonYm9vbGVhbicsc2NvcGU6J3J1bicsaW5pdGlhbDpib29sZWFuKGZhbHNlKX0pO1xuICBjb25zdCBhZmZpbml0eT1hZGQocCwndmFyaWFibGUnLCflpb3mhJ/luqYnLHtrZXk6J2FmZmluaXR5Jyx2YWx1ZVR5cGU6J2ludGVnZXInLHNjb3BlOidydW4nLGluaXRpYWw6aW50ZWdlcigwKSxhbGxvd2VkOnttaW46MCxtYXg6MTB9fSk7XG4gIGNvbnN0IGVudHJ5PWFkZChwLCdmbG93X25vZGUnLCflnovku5jjgY3pgJTkuK3plovlp4snLHtub2RlVHlwZTonZW50cnknfSksZW5kPWFkZChwLCdmbG93X25vZGUnLCfpgJTkuK3plovlp4vjga7ntYLnq68nLHtub2RlVHlwZTondGVybWluYWwnLHRlcm1pbmFsUmVhc29uOifpgJTkuK3jgYvjgonjga7nirbmhYvjgaDjgZHjgpLnorroqo3jgZfjgZ8nfSk7XG4gIGNvbnN0IGNvbmRpdGlvbjpDb25kaXRpb249e29wOidhbGwnLGNoaWxkcmVuOlt7b3A6J2NvbXBhcmUnLHZhcmlhYmxlSWQ6a2V5LmlkLGNvbXBhcmF0b3I6J2VxJyx2YWx1ZTpib29sZWFuKHRydWUpfSx7b3A6J2NvbXBhcmUnLHZhcmlhYmxlSWQ6YWZmaW5pdHkuaWQsY29tcGFyYXRvcjonZXEnLHZhbHVlOmludGVnZXIoNSl9XX07XG4gIGNvbnN0IGVkZ2U9YWRkKHAsJ2Zsb3dfZWRnZScsJ+mNteOBguOCiuOBi+OBpOWlveaEn+W6pjUnLHtmcm9tSWQ6ZW50cnkuaWQsdG9JZDplbmQuaWQsbGFiZWw6J+mNteOBguOCiuOBi+OBpOWlveaEn+W6pjUnLGNvbmRpdGlvbn0pO1xuICBjb25zdCBncmFwaD1hZGQocCwnZmxvd19ncmFwaCcsJ+mAlOS4remWi+Wni+OBruWbsycse25vZGVJZHM6W2VudHJ5LmlkLGVuZC5pZF0sZWRnZUlkczpbZWRnZS5pZF0sZW50cnlJZHM6W2VudHJ5LmlkXSxleGl0SWRzOltlbmQuaWRdfSk7XG4gIHA9YXdhaXQgY3JlYXRlV29ybGRTbmFwc2hvdChwLCfljp9GMTXml6fkvZzlk4HniYgnKTtjb25zdCBwaW49cC5zbmFwc2hvdHMuYXQoLTEpITtcbiAgY29uc3QgaW5pdGlhbD1zdGFydFRyaWFsKHAse2VudHJ5SWQ6ZW50cnkuaWQsY29udGVudFZlcnNpb25JZDpwaW4uaWQsc2VlZDonb3JpZ2luYWwtY2hlY2twb2ludC1zZWVkJ30pLnN0YXJ0U3RhdGU7XG4gIGNvbnN0IHN0YXRlPXsuLi5zdHJ1Y3R1cmVkQ2xvbmUoaW5pdGlhbCkscHJvdmVuYW5jZToncGFydGlhbCcgYXMgY29uc3QsdmFyaWFibGVWYWx1ZXM6e1trZXkuaWRdOmJvb2xlYW4odHJ1ZSksW2FmZmluaXR5LmlkXTppbnRlZ2VyKDUpfX07XG4gIGNvbnN0IGNwPWFkZChwLCdjaGVja3BvaW50Jywn6Y2144GC44KK44O75aW95oSf5bqmNeOBrumAlOS4reeKtuaFiycse2NvbnRlbnRWZXJzaW9uSWQ6cGluLmlkLGNvbnRlbnRSZXZpc2lvbjpwaW4uY29udGVudC5yZXZpc2lvbixydW50aW1lU3RhdGU6c3RhdGUsb3JpZ2luOidwYXJ0aWFsJ30pO1xuICBjb25zdCBtaXNzaW5nPWFkZChwLCdjaGVja3BvaW50Jywn5aW95oSf5bqm44GM5qyg6JC944GX44Gf6YCU5Lit54q25oWLJyx7Y29udGVudFZlcnNpb25JZDpwaW4uaWQsY29udGVudFJldmlzaW9uOnBpbi5jb250ZW50LnJldmlzaW9uLHJ1bnRpbWVTdGF0ZTp7Li4uc3RydWN0dXJlZENsb25lKHN0YXRlKSx2YXJpYWJsZVZhbHVlczp7W2tleS5pZF06Ym9vbGVhbih0cnVlKX19LG9yaWdpbjoncGFydGlhbCd9KTtcbiAgcmV0dXJuIHtwLGtleSxhZmZpbml0eSxlbnRyeSxlbmQsY29uZGl0aW9uLGVkZ2UsZ3JhcGgscGluLGNwLG1pc3Npbmd9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFRQSxZQUFZLEVBQUNDLGFBQWEsRUFBQ0MsY0FBYyxRQUFPLCtCQUErQjtBQUN2RixTQUFRQyxtQkFBbUIsUUFBTywrQkFBK0I7QUFFakUsU0FBUUMsVUFBVSxRQUFPLGlDQUFpQztBQUUxRCxTQUFTQyxHQUFHQSxDQUF1QkMsQ0FBYSxFQUFDQyxJQUFNLEVBQUNDLElBQVcsRUFBQ0MsSUFBOEIsR0FBQyxDQUFDLENBQUMsRUFBVztFQUM5RyxNQUFNQyxDQUFDLEdBQUNWLFlBQVksQ0FBQ00sQ0FBQyxDQUFDSyxTQUFTLEVBQUNKLElBQUksRUFBQ0MsSUFBSSxFQUFDQyxJQUFJLENBQUM7RUFBQ0MsQ0FBQyxDQUFDRSxNQUFNLEdBQUMsV0FBVztFQUFDTixDQUFDLENBQUNPLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDSixDQUFDLENBQUM7RUFBQyxPQUFPQSxDQUFDO0FBQ25HO0FBQ0EsTUFBTUssT0FBTyxHQUFFQyxLQUFhLEtBQWU7RUFBQ0MsSUFBSSxFQUFDLFNBQVM7RUFBQ0Q7QUFBSyxDQUFDLENBQUM7QUFDbEUsTUFBTUUsT0FBTyxHQUFFRixLQUFZLEtBQWU7RUFBQ0MsSUFBSSxFQUFDLFNBQVM7RUFBQ0Q7QUFBSyxDQUFDLENBQUM7QUFDakUsTUFBTUcsV0FBVyxHQUFFSCxLQUFZLEtBQWU7RUFBQ0MsSUFBSSxFQUFDLE1BQU07RUFBQ0Q7QUFBSyxDQUFDLENBQUM7O0FBRWxFO0FBQ0EsT0FBTyxTQUFTSSxpQkFBaUJBLENBQUEsRUFBRTtFQUNqQyxNQUFNZCxDQUFDLEdBQUNMLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQztFQUMvQyxNQUFNb0IsUUFBUSxHQUFDaEIsR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLEtBQUssRUFBQztJQUFDZ0IsR0FBRyxFQUFDLFVBQVU7SUFBQ0MsU0FBUyxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDLEtBQUs7SUFBQ0MsT0FBTyxFQUFDUCxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQUNRLE9BQU8sRUFBQztNQUFDQyxHQUFHLEVBQUMsQ0FBQztNQUFDQyxHQUFHLEVBQUM7SUFBRTtFQUFDLENBQUMsQ0FBQztFQUNqSSxNQUFNQyxLQUFLLEdBQUN4QixHQUFHLENBQUNDLENBQUMsRUFBQyxVQUFVLEVBQUMsSUFBSSxFQUFDO0lBQUNnQixHQUFHLEVBQUMsTUFBTTtJQUFDQyxTQUFTLEVBQUMsTUFBTTtJQUFDQyxLQUFLLEVBQUMsYUFBYTtJQUFDQyxPQUFPLEVBQUNOLFdBQVcsQ0FBQyxJQUFJLENBQUM7SUFBQ08sT0FBTyxFQUFDO01BQUNJLE1BQU0sRUFBQyxDQUFDLElBQUksRUFBQyxJQUFJO0lBQUMsQ0FBQztJQUFDQyxXQUFXLEVBQUM3QixjQUFjLENBQUMsa0JBQWtCO0VBQUMsQ0FBQyxDQUFDO0VBQzFMLE1BQU04QixTQUFTLEdBQUMzQixHQUFHLENBQUNDLENBQUMsRUFBQyxVQUFVLEVBQUMsYUFBYSxFQUFDO0lBQUNnQixHQUFHLEVBQUMsV0FBVztJQUFDQyxTQUFTLEVBQUMsU0FBUztJQUFDQyxLQUFLLEVBQUMsS0FBSztJQUFDQyxPQUFPLEVBQUM7TUFBQ1IsSUFBSSxFQUFDLFNBQVM7TUFBQ0QsS0FBSyxFQUFDLElBQUk7TUFBQ2lCLE1BQU0sRUFBQztJQUFhO0VBQUMsQ0FBQyxDQUFDO0VBQzFKLE1BQU1DLEtBQUssR0FBQzdCLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFVBQVUsRUFBQyxVQUFVLEVBQUM7SUFBQ2dCLEdBQUcsRUFBQyxPQUFPO0lBQUNDLFNBQVMsRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQyxLQUFLO0lBQUNDLE9BQU8sRUFBQ1AsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUFDUSxPQUFPLEVBQUM7TUFBQ0MsR0FBRyxFQUFDLENBQUM7TUFBQ0MsR0FBRyxFQUFDO0lBQUc7RUFBQyxDQUFDLENBQUM7RUFDbEksTUFBTU8sTUFBTSxHQUFDOUIsR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLGVBQWUsRUFBQztJQUFDZ0IsR0FBRyxFQUFDLFFBQVE7SUFBQ0MsU0FBUyxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDLGFBQWE7SUFBQ0MsT0FBTyxFQUFDVixPQUFPLENBQUMsS0FBSztFQUFDLENBQUMsQ0FBQztFQUM1SCxNQUFNcUIsT0FBTyxHQUFDL0IsR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLFlBQVksRUFBQztJQUFDZ0IsR0FBRyxFQUFDLFFBQVE7SUFBQ0MsU0FBUyxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDLEtBQUs7SUFBQ0MsT0FBTyxFQUFDO01BQUNSLElBQUksRUFBQyxTQUFTO01BQUNELEtBQUssRUFBQyxJQUFJO01BQUNpQixNQUFNLEVBQUM7SUFBUyxDQUFDO0lBQUNHLE9BQU8sRUFBQztNQUFDQyxFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUNqQixRQUFRLENBQUNrQixFQUFFO01BQUNDLFVBQVUsRUFBQyxJQUFJO01BQUN4QixLQUFLLEVBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQUM7RUFBQyxDQUFDLENBQUM7RUFDL04sTUFBTXVCLE1BQU0sR0FBQ3BDLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFVBQVUsRUFBQyxlQUFlLEVBQUM7SUFBQ2dCLEdBQUcsRUFBQyxZQUFZO0lBQUNDLFNBQVMsRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQyxhQUFhO0lBQUNDLE9BQU8sRUFBQ1AsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUFDUSxPQUFPLEVBQUMsQ0FBQyxDQUFDO0lBQUNnQixtQkFBbUIsRUFBQztFQUFJLENBQUMsQ0FBQztFQUNoSyxNQUFNQyxVQUFVLEdBQUN0QyxHQUFHLENBQUNDLENBQUMsRUFBQyxVQUFVLEVBQUMsUUFBUSxFQUFDO0lBQUNnQixHQUFHLEVBQUMsYUFBYTtJQUFDQyxTQUFTLEVBQUMsTUFBTTtJQUFDQyxLQUFLLEVBQUMsS0FBSztJQUFDQyxPQUFPLEVBQUNOLFdBQVcsQ0FBQyxJQUFJLENBQUM7SUFBQ08sT0FBTyxFQUFDO01BQUNJLE1BQU0sRUFBQyxDQUFDLEtBQUssRUFBQyxLQUFLLEVBQUMsSUFBSSxFQUFDLElBQUk7SUFBQyxDQUFDO0lBQUNjLGVBQWUsRUFBQyxDQUM1SztNQUFDQyxJQUFJLEVBQUMxQixXQUFXLENBQUMsS0FBSyxDQUFDO01BQUMyQixFQUFFLEVBQUMzQixXQUFXLENBQUMsS0FBSztJQUFDLENBQUMsRUFDL0M7TUFBQzBCLElBQUksRUFBQzFCLFdBQVcsQ0FBQyxLQUFLLENBQUM7TUFBQzJCLEVBQUUsRUFBQzNCLFdBQVcsQ0FBQyxJQUFJO0lBQUMsQ0FBQyxFQUM5QztNQUFDMEIsSUFBSSxFQUFDMUIsV0FBVyxDQUFDLEtBQUssQ0FBQztNQUFDMkIsRUFBRSxFQUFDM0IsV0FBVyxDQUFDLElBQUk7SUFBQyxDQUFDO0VBQy9DLENBQUMsQ0FBQztFQUNILE1BQU00QixLQUFLLEdBQUMxQyxHQUFHLENBQUNDLENBQUMsRUFBQyxPQUFPLEVBQUMsaUJBQWlCLEVBQUM7SUFBQ2dCLEdBQUcsRUFBQyxHQUFHO0lBQUMwQixlQUFlLEVBQUNMLFVBQVUsQ0FBQ0o7RUFBRSxDQUFDLENBQUM7RUFDcEYsTUFBTVUsaUJBQWlCLEdBQUM1QyxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsWUFBWSxFQUFDO0lBQUM0QyxVQUFVLEVBQUMsYUFBYTtJQUFDQyxPQUFPLEVBQUMsb0JBQW9CO0lBQUNDLFVBQVUsRUFBQztFQUEwQixDQUFDLENBQUM7RUFDbEosTUFBTUMsT0FBTyxHQUFDaEQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsTUFBTSxFQUFDLE1BQU0sRUFBQztNQUFDZ0QsUUFBUSxFQUFDO0lBQU0sQ0FBQyxDQUFDO0lBQUNoQyxHQUFHLEdBQUNqQixHQUFHLENBQUNDLENBQUMsRUFBQyxNQUFNLEVBQUMsWUFBWSxFQUFDO01BQUNnRCxRQUFRLEVBQUMsVUFBVTtNQUFDQyxNQUFNLEVBQUNGLE9BQU8sQ0FBQ2Q7SUFBRSxDQUFDLENBQUM7RUFDM0gsTUFBTWlCLEtBQUssR0FBQ25ELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLE9BQU8sRUFBQyxlQUFlLEVBQUM7SUFBQ21ELElBQUksRUFBQ3ZELGNBQWMsQ0FBQyxtQkFBbUI7RUFBQyxDQUFDLENBQUM7RUFDckYsTUFBTXdELE1BQU0sR0FBQ3JELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLE9BQU8sRUFBQyxjQUFjLEVBQUM7SUFBQ21ELElBQUksRUFBQ3ZELGNBQWMsQ0FBQyxpQkFBaUI7RUFBQyxDQUFDLENBQUM7RUFDbkYsTUFBTXlELEtBQUssR0FBQ3RELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxjQUFjLEVBQUM7SUFBQ3NELFFBQVEsRUFBQyxPQUFPO0lBQUNDLE9BQU8sRUFBQ0wsS0FBSyxDQUFDakI7RUFBRSxDQUFDLENBQUM7RUFDakYsTUFBTXVCLEtBQUssR0FBQ3pELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxXQUFXLEVBQUM7SUFBQ3NELFFBQVEsRUFBQyxRQUFRO0lBQUNDLE9BQU8sRUFBQ0gsTUFBTSxDQUFDbkI7RUFBRSxDQUFDLENBQUM7RUFDaEYsTUFBTXdCLEdBQUcsR0FBQzFELEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxjQUFjLEVBQUM7SUFBQ3NELFFBQVEsRUFBQyxVQUFVO0lBQUNJLGNBQWMsRUFBQztFQUFhLENBQUMsQ0FBQztFQUM5RixNQUFNQyxXQUFXLEdBQUM1RCxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsV0FBVyxFQUFDO0lBQUM0RCxTQUFTLEVBQUMsS0FBSztJQUFDQyxRQUFRLEVBQUM5QyxRQUFRLENBQUNrQixFQUFFO0lBQUN2QixLQUFLLEVBQUNFLE9BQU8sQ0FBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQ3JHLE1BQU1rRCxTQUFTLEdBQUMvRCxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsU0FBUyxFQUFDO0lBQUM0RCxTQUFTLEVBQUMsS0FBSztJQUFDQyxRQUFRLEVBQUNoQyxNQUFNLENBQUNJLEVBQUU7SUFBQ3ZCLEtBQUssRUFBQ0QsT0FBTyxDQUFDLElBQUk7RUFBQyxDQUFDLENBQUM7RUFDbEcsTUFBTXNELFFBQVEsR0FBQ2hFLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFFBQVEsRUFBQyxVQUFVLEVBQUM7SUFBQzRELFNBQVMsRUFBQyxLQUFLO0lBQUNDLFFBQVEsRUFBQ2pDLEtBQUssQ0FBQ0ssRUFBRTtJQUFDdkIsS0FBSyxFQUFDRSxPQUFPLENBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUM5RixNQUFNb0QsS0FBSyxHQUFDakUsR0FBRyxDQUFDQyxDQUFDLEVBQUMsUUFBUSxFQUFDLFVBQVUsRUFBQztJQUFDNEQsU0FBUyxFQUFDLE9BQU87SUFBQ0MsUUFBUSxFQUFDN0MsR0FBRyxDQUFDaUIsRUFBRTtJQUFDZ0MsVUFBVSxFQUFDakQsR0FBRyxDQUFDaUIsRUFBRTtJQUFDdkIsS0FBSyxFQUFDRSxPQUFPLENBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUM3RyxNQUFNc0QsVUFBVSxHQUFDbkUsR0FBRyxDQUFDQyxDQUFDLEVBQUMsUUFBUSxFQUFDLGVBQWUsRUFBQztJQUFDNEQsU0FBUyxFQUFDLEtBQUs7SUFBQ0MsUUFBUSxFQUFDeEIsVUFBVSxDQUFDSixFQUFFO0lBQUN2QixLQUFLLEVBQUNHLFdBQVcsQ0FBQyxLQUFLLENBQUM7SUFBQ2MsTUFBTSxFQUFDO0VBQU0sQ0FBQyxDQUFDO0VBQ2hJLE1BQU13QyxLQUFLLEdBQUNwRSxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsYUFBYSxFQUFDO0lBQUM0RCxTQUFTLEVBQUMsT0FBTztJQUFDQyxRQUFRLEVBQUN4QixVQUFVLENBQUNKLEVBQUU7SUFBQ3ZCLEtBQUssRUFBQ0csV0FBVyxDQUFDLEtBQUssQ0FBQztJQUFDYyxNQUFNLEVBQUM7RUFBaUIsQ0FBQyxDQUFDO0VBQ3RJO0VBQ0E7RUFDQSxNQUFNeUMsWUFBWSxHQUFDckUsR0FBRyxDQUFDQyxDQUFDLEVBQUMsUUFBUSxFQUFDLGtCQUFrQixFQUFDO0lBQUM0RCxTQUFTLEVBQUMsS0FBSztJQUFDQyxRQUFRLEVBQUNoQyxNQUFNLENBQUNJLEVBQUU7SUFBQ3ZCLEtBQUssRUFBQ0QsT0FBTyxDQUFDLEtBQUs7RUFBQyxDQUFDLENBQUM7RUFDL0csTUFBTTRELEdBQUcsR0FBQ3RFLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxrQkFBa0IsRUFBQztJQUFDc0UsTUFBTSxFQUFDakIsS0FBSyxDQUFDcEIsRUFBRTtJQUFDc0MsSUFBSSxFQUFDZixLQUFLLENBQUN2QixFQUFFO0lBQUN1QyxLQUFLLEVBQUMsa0JBQWtCO0lBQUNDLFNBQVMsRUFBQyxDQUFDZCxXQUFXLENBQUMxQixFQUFFLEVBQUM2QixTQUFTLENBQUM3QixFQUFFLEVBQUM4QixRQUFRLENBQUM5QixFQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQzVKLE1BQU15QyxJQUFJLEdBQUMzRSxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsZUFBZSxFQUFDO0lBQUNzRSxNQUFNLEVBQUNqQixLQUFLLENBQUNwQixFQUFFO0lBQUNzQyxJQUFJLEVBQUNmLEtBQUssQ0FBQ3ZCLEVBQUU7SUFBQ3VDLEtBQUssRUFBQztFQUFlLENBQUMsQ0FBQztFQUNuRyxNQUFNRyxPQUFPLEdBQUM1RSxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsa0JBQWtCLEVBQUM7SUFBQ3NFLE1BQU0sRUFBQ2QsS0FBSyxDQUFDdkIsRUFBRTtJQUFDc0MsSUFBSSxFQUFDZCxHQUFHLENBQUN4QixFQUFFO0lBQUN1QyxLQUFLLEVBQUMsa0JBQWtCO0lBQUNDLFNBQVMsRUFBQyxDQUFDVixRQUFRLENBQUM5QixFQUFFLEVBQUMrQixLQUFLLENBQUMvQixFQUFFLEVBQUNpQyxVQUFVLENBQUNqQyxFQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQ3pKLE1BQU0yQyxhQUFhLEdBQUM3RSxHQUFHLENBQUNDLENBQUMsRUFBQyxRQUFRLEVBQUMsYUFBYSxFQUFDO0lBQUM0RCxTQUFTLEVBQUMsT0FBTztJQUFDQyxRQUFRLEVBQUM5QyxRQUFRLENBQUNrQixFQUFFO0lBQUN2QixLQUFLLEVBQUNFLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFBQ2UsTUFBTSxFQUFDO0VBQWlCLENBQUMsQ0FBQztFQUNwSSxNQUFNa0QsU0FBUyxHQUFDOUUsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLGtCQUFrQixFQUFDO0lBQUNzRSxNQUFNLEVBQUNkLEtBQUssQ0FBQ3ZCLEVBQUU7SUFBQ3NDLElBQUksRUFBQ2QsR0FBRyxDQUFDeEIsRUFBRTtJQUFDdUMsS0FBSyxFQUFDLGtCQUFrQjtJQUFDQyxTQUFTLEVBQUMsQ0FBQ04sS0FBSyxDQUFDbEMsRUFBRSxFQUFDMkMsYUFBYSxDQUFDM0MsRUFBRTtFQUFDLENBQUMsQ0FBQztFQUNsSixNQUFNNkMsV0FBVyxHQUFDL0UsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLGFBQWEsRUFBQztJQUFDc0UsTUFBTSxFQUFDZCxLQUFLLENBQUN2QixFQUFFO0lBQUNzQyxJQUFJLEVBQUNkLEdBQUcsQ0FBQ3hCLEVBQUU7SUFBQ3VDLEtBQUssRUFBQyxhQUFhO0lBQUNDLFNBQVMsRUFBQyxDQUFDTCxZQUFZLENBQUNuQyxFQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQ2hJLE1BQU04QyxNQUFNLEdBQUNoRixHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsWUFBWSxFQUFDO0lBQUNzRSxNQUFNLEVBQUNkLEtBQUssQ0FBQ3ZCLEVBQUU7SUFBQ3NDLElBQUksRUFBQ2QsR0FBRyxDQUFDeEIsRUFBRTtJQUFDdUMsS0FBSyxFQUFDLFlBQVk7SUFBQ1EsU0FBUyxFQUFDO01BQUNqRCxFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUNqQixRQUFRLENBQUNrQixFQUFFO01BQUNDLFVBQVUsRUFBQyxJQUFJO01BQUN4QixLQUFLLEVBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQUM7RUFBQyxDQUFDLENBQUM7RUFDOUssTUFBTXFFLEtBQUssR0FBQ2xGLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFlBQVksRUFBQyxVQUFVLEVBQUM7SUFBQ2tGLE9BQU8sRUFBQyxDQUFDN0IsS0FBSyxDQUFDcEIsRUFBRSxFQUFDdUIsS0FBSyxDQUFDdkIsRUFBRSxFQUFDd0IsR0FBRyxDQUFDeEIsRUFBRSxDQUFDO0lBQUNrRCxPQUFPLEVBQUMsQ0FBQ2QsR0FBRyxDQUFDcEMsRUFBRSxFQUFDeUMsSUFBSSxDQUFDekMsRUFBRSxFQUFDMEMsT0FBTyxDQUFDMUMsRUFBRSxFQUFDNEMsU0FBUyxDQUFDNUMsRUFBRSxFQUFDNkMsV0FBVyxDQUFDN0MsRUFBRSxFQUFDOEMsTUFBTSxDQUFDOUMsRUFBRSxDQUFDO0lBQUNtRCxRQUFRLEVBQUMsQ0FBQy9CLEtBQUssQ0FBQ3BCLEVBQUUsQ0FBQztJQUFDb0QsT0FBTyxFQUFDLENBQUM1QixHQUFHLENBQUN4QixFQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQzlMLE9BQU87SUFBQ2pDLENBQUM7SUFBQ2UsUUFBUTtJQUFDUSxLQUFLO0lBQUNHLFNBQVM7SUFBQ0UsS0FBSztJQUFDQyxNQUFNO0lBQUNDLE9BQU87SUFBQ0ssTUFBTTtJQUFDRSxVQUFVO0lBQUNJLEtBQUs7SUFBQ0UsaUJBQWlCO0lBQUNJLE9BQU87SUFBQy9CLEdBQUc7SUFBQ2tDLEtBQUs7SUFBQ0UsTUFBTTtJQUFDQyxLQUFLO0lBQUNHLEtBQUs7SUFBQ0MsR0FBRztJQUFDRSxXQUFXO0lBQUNHLFNBQVM7SUFBQ0MsUUFBUTtJQUFDQyxLQUFLO0lBQUNFLFVBQVU7SUFBQ0MsS0FBSztJQUFDUyxhQUFhO0lBQUNSLFlBQVk7SUFBQ0MsR0FBRztJQUFDSyxJQUFJO0lBQUNDLE9BQU87SUFBQ0UsU0FBUztJQUFDQyxXQUFXO0lBQUNDLE1BQU07SUFBQ0U7RUFBSyxDQUFDO0FBQ2xSOztBQUVBO0FBQ0EsT0FBTyxTQUFTSyxvQkFBb0JBLENBQUEsRUFBRTtFQUNwQyxNQUFNdEYsQ0FBQyxHQUFDTCxhQUFhLENBQUMsbUJBQW1CLENBQUM7RUFDMUMsTUFBTTRGLEtBQUssR0FBQ3hGLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFVBQVUsRUFBQyxZQUFZLEVBQUM7SUFBQ2dCLEdBQUcsRUFBQyxnQkFBZ0I7SUFBQ0MsU0FBUyxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDLEtBQUs7SUFBQ0MsT0FBTyxFQUFDVixPQUFPLENBQUMsSUFBSTtFQUFDLENBQUMsQ0FBQztFQUN2SCxNQUFNK0UsTUFBTSxHQUFDQyxLQUFLLENBQUNsRCxJQUFJLENBQUM7SUFBQ21ELE1BQU0sRUFBQztFQUFDLENBQUMsRUFBQyxDQUFDQyxDQUFDLEVBQUNDLENBQUMsS0FBRzdGLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLE9BQU8sRUFBQyxTQUFTNEYsQ0FBQyxHQUFDLENBQUMsRUFBRSxFQUFDO0lBQUN6QyxJQUFJLEVBQUN2RCxjQUFjLENBQUMsU0FBU2dHLENBQUMsR0FBQyxDQUFDLElBQUk7RUFBQyxDQUFDLENBQUMsQ0FBQztFQUNoSCxNQUFNdkMsS0FBSyxHQUFDdEQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFlBQVksRUFBQztJQUFDc0QsUUFBUSxFQUFDLE9BQU87SUFBQ0MsT0FBTyxFQUFDaUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDdkQsRUFBRTtJQUFDNEQsSUFBSSxFQUFDO01BQUM5RCxFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUN1RCxLQUFLLENBQUN0RCxFQUFFO01BQUNDLFVBQVUsRUFBQyxJQUFJO01BQUN4QixLQUFLLEVBQUNELE9BQU8sQ0FBQyxJQUFJO0lBQUM7RUFBQyxDQUFDLENBQUM7RUFDL0osTUFBTXFGLENBQUMsR0FBQy9GLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxhQUFhLEVBQUM7SUFBQ3NELFFBQVEsRUFBQyxRQUFRO0lBQUNDLE9BQU8sRUFBQ2lDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZEO0VBQUUsQ0FBQyxDQUFDO0VBQ2pGLE1BQU04RCxDQUFDLEdBQUNoRyxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsVUFBVSxFQUFDO0lBQUNzRCxRQUFRLEVBQUMsVUFBVTtJQUFDQyxPQUFPLEVBQUNpQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUN2RCxFQUFFO0lBQUN5QixjQUFjLEVBQUM7RUFBUyxDQUFDLENBQUM7RUFDekcsTUFBTUQsR0FBRyxHQUFDMUQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFVBQVUsRUFBQztJQUFDc0QsUUFBUSxFQUFDLFVBQVU7SUFBQ0MsT0FBTyxFQUFDaUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDdkQsRUFBRTtJQUFDeUIsY0FBYyxFQUFDO0VBQVUsQ0FBQyxDQUFDO0VBQzVHLE1BQU1zQyxLQUFLLEdBQUNqRyxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsU0FBUyxFQUFDO0lBQUNzRSxNQUFNLEVBQUNqQixLQUFLLENBQUNwQixFQUFFO0lBQUNzQyxJQUFJLEVBQUN1QixDQUFDLENBQUM3RCxFQUFFO0lBQUN1QyxLQUFLLEVBQUMsU0FBUztJQUFDUSxTQUFTLEVBQUM7TUFBQ2pELEVBQUUsRUFBQyxTQUFTO01BQUNDLFVBQVUsRUFBQ3VELEtBQUssQ0FBQ3RELEVBQUU7TUFBQ0MsVUFBVSxFQUFDLElBQUk7TUFBQ3hCLEtBQUssRUFBQ0QsT0FBTyxDQUFDLElBQUk7SUFBQztFQUFDLENBQUMsQ0FBQztFQUNySyxNQUFNd0YsS0FBSyxHQUFDbEcsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFNBQVMsRUFBQztJQUFDc0UsTUFBTSxFQUFDakIsS0FBSyxDQUFDcEIsRUFBRTtJQUFDc0MsSUFBSSxFQUFDd0IsQ0FBQyxDQUFDOUQsRUFBRTtJQUFDdUMsS0FBSyxFQUFDLFNBQVM7SUFBQ1EsU0FBUyxFQUFDO01BQUNqRCxFQUFFLEVBQUMsVUFBVTtNQUFDckIsS0FBSyxFQUFDO0lBQUk7RUFBQyxDQUFDLENBQUM7RUFDekgsTUFBTXdGLEtBQUssR0FBQ25HLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxTQUFTLEVBQUM7SUFBQ3NFLE1BQU0sRUFBQ3dCLENBQUMsQ0FBQzdELEVBQUU7SUFBQ3NDLElBQUksRUFBQ2QsR0FBRyxDQUFDeEIsRUFBRTtJQUFDdUMsS0FBSyxFQUFDLFNBQVM7SUFBQ1EsU0FBUyxFQUFDO01BQUNqRCxFQUFFLEVBQUMsS0FBSztNQUFDb0UsS0FBSyxFQUFDO1FBQUNwRSxFQUFFLEVBQUMsU0FBUztRQUFDQyxVQUFVLEVBQUN1RCxLQUFLLENBQUN0RCxFQUFFO1FBQUNDLFVBQVUsRUFBQyxJQUFJO1FBQUN4QixLQUFLLEVBQUNELE9BQU8sQ0FBQyxLQUFLO01BQUM7SUFBQztFQUFDLENBQUMsQ0FBQztFQUNyTCxNQUFNd0UsS0FBSyxHQUFDbEYsR0FBRyxDQUFDQyxDQUFDLEVBQUMsWUFBWSxFQUFDLFVBQVUsRUFBQztJQUFDa0YsT0FBTyxFQUFDLENBQUM3QixLQUFLLENBQUNwQixFQUFFLEVBQUM2RCxDQUFDLENBQUM3RCxFQUFFLEVBQUM4RCxDQUFDLENBQUM5RCxFQUFFLEVBQUN3QixHQUFHLENBQUN4QixFQUFFLENBQUM7SUFBQ2tELE9BQU8sRUFBQyxDQUFDYSxLQUFLLENBQUMvRCxFQUFFLEVBQUNnRSxLQUFLLENBQUNoRSxFQUFFLEVBQUNpRSxLQUFLLENBQUNqRSxFQUFFLENBQUM7SUFBQ21ELFFBQVEsRUFBQyxDQUFDL0IsS0FBSyxDQUFDcEIsRUFBRSxDQUFDO0lBQUNvRCxPQUFPLEVBQUMsQ0FBQ1UsQ0FBQyxDQUFDOUQsRUFBRSxFQUFDd0IsR0FBRyxDQUFDeEIsRUFBRTtFQUFDLENBQUMsQ0FBQztFQUMvSixNQUFNbUUsS0FBSyxHQUFDWixNQUFNLENBQUNhLEdBQUcsQ0FBQyxDQUFDQyxDQUFDLEVBQUNWLENBQUMsS0FBRztJQUFDLE1BQU1XLENBQUMsR0FBQ3hHLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLGVBQWUsRUFBQyxRQUFRNEYsQ0FBQyxHQUFDLENBQUMsRUFBRSxFQUFDO01BQUNZLElBQUksRUFBQzVHLGNBQWMsQ0FBQyxVQUFVZ0csQ0FBQyxHQUFDLENBQUMsRUFBRTtJQUFDLENBQUMsQ0FBQztJQUFDVSxDQUFDLENBQUNuRyxJQUFJLENBQUNzRyxlQUFlLEdBQUMsQ0FBQ0YsQ0FBQyxDQUFDdEUsRUFBRSxDQUFDO0lBQUMsT0FBT3NFLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDNUosT0FBTztJQUFDdkcsQ0FBQztJQUFDdUYsS0FBSztJQUFDQyxNQUFNO0lBQUNuQyxLQUFLO0lBQUN5QyxDQUFDO0lBQUNDLENBQUM7SUFBQ3RDLEdBQUc7SUFBQ3VDLEtBQUs7SUFBQ0MsS0FBSztJQUFDQyxLQUFLO0lBQUNqQixLQUFLO0lBQUNtQjtFQUFLLENBQUM7QUFDckU7O0FBRUE7QUFDQSxPQUFPLGVBQWVNLHNCQUFzQkEsQ0FBQSxFQUFFO0VBQzVDLElBQUkxRyxDQUFDLEdBQUNMLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztFQUN4QyxNQUFNcUIsR0FBRyxHQUFDakIsR0FBRyxDQUFDQyxDQUFDLEVBQUMsVUFBVSxFQUFDLEtBQUssRUFBQztJQUFDZ0IsR0FBRyxFQUFDLFNBQVM7SUFBQ0MsU0FBUyxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDLEtBQUs7SUFBQ0MsT0FBTyxFQUFDVixPQUFPLENBQUMsS0FBSztFQUFDLENBQUMsQ0FBQztFQUN4RyxNQUFNTSxRQUFRLEdBQUNoQixHQUFHLENBQUNDLENBQUMsRUFBQyxVQUFVLEVBQUMsS0FBSyxFQUFDO0lBQUNnQixHQUFHLEVBQUMsVUFBVTtJQUFDQyxTQUFTLEVBQUMsU0FBUztJQUFDQyxLQUFLLEVBQUMsS0FBSztJQUFDQyxPQUFPLEVBQUNQLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFBQ1EsT0FBTyxFQUFDO01BQUNDLEdBQUcsRUFBQyxDQUFDO01BQUNDLEdBQUcsRUFBQztJQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQ2pJLE1BQU0rQixLQUFLLEdBQUN0RCxHQUFHLENBQUNDLENBQUMsRUFBQyxXQUFXLEVBQUMsU0FBUyxFQUFDO01BQUNzRCxRQUFRLEVBQUM7SUFBTyxDQUFDLENBQUM7SUFBQ0csR0FBRyxHQUFDMUQsR0FBRyxDQUFDQyxDQUFDLEVBQUMsV0FBVyxFQUFDLFNBQVMsRUFBQztNQUFDc0QsUUFBUSxFQUFDLFVBQVU7TUFBQ0ksY0FBYyxFQUFDO0lBQWdCLENBQUMsQ0FBQztFQUNsSixNQUFNc0IsU0FBbUIsR0FBQztJQUFDakQsRUFBRSxFQUFDLEtBQUs7SUFBQzRFLFFBQVEsRUFBQyxDQUFDO01BQUM1RSxFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUNoQixHQUFHLENBQUNpQixFQUFFO01BQUNDLFVBQVUsRUFBQyxJQUFJO01BQUN4QixLQUFLLEVBQUNELE9BQU8sQ0FBQyxJQUFJO0lBQUMsQ0FBQyxFQUFDO01BQUNzQixFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUNqQixRQUFRLENBQUNrQixFQUFFO01BQUNDLFVBQVUsRUFBQyxJQUFJO01BQUN4QixLQUFLLEVBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQUMsQ0FBQztFQUFDLENBQUM7RUFDM0wsTUFBTWdHLElBQUksR0FBQzdHLEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFdBQVcsRUFBQyxXQUFXLEVBQUM7SUFBQ3NFLE1BQU0sRUFBQ2pCLEtBQUssQ0FBQ3BCLEVBQUU7SUFBQ3NDLElBQUksRUFBQ2QsR0FBRyxDQUFDeEIsRUFBRTtJQUFDdUMsS0FBSyxFQUFDLFdBQVc7SUFBQ1E7RUFBUyxDQUFDLENBQUM7RUFDbkcsTUFBTUMsS0FBSyxHQUFDbEYsR0FBRyxDQUFDQyxDQUFDLEVBQUMsWUFBWSxFQUFDLFFBQVEsRUFBQztJQUFDa0YsT0FBTyxFQUFDLENBQUM3QixLQUFLLENBQUNwQixFQUFFLEVBQUN3QixHQUFHLENBQUN4QixFQUFFLENBQUM7SUFBQ2tELE9BQU8sRUFBQyxDQUFDeUIsSUFBSSxDQUFDM0UsRUFBRSxDQUFDO0lBQUNtRCxRQUFRLEVBQUMsQ0FBQy9CLEtBQUssQ0FBQ3BCLEVBQUUsQ0FBQztJQUFDb0QsT0FBTyxFQUFDLENBQUM1QixHQUFHLENBQUN4QixFQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQzNIakMsQ0FBQyxHQUFDLE1BQU1ILG1CQUFtQixDQUFDRyxDQUFDLEVBQUMsVUFBVSxDQUFDO0VBQUMsTUFBTTZHLEdBQUcsR0FBQzdHLENBQUMsQ0FBQzhHLFNBQVMsQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFFO0VBQ3ZFLE1BQU01RixPQUFPLEdBQUNyQixVQUFVLENBQUNFLENBQUMsRUFBQztJQUFDZ0gsT0FBTyxFQUFDM0QsS0FBSyxDQUFDcEIsRUFBRTtJQUFDZ0YsZ0JBQWdCLEVBQUNKLEdBQUcsQ0FBQzVFLEVBQUU7SUFBQ2lGLElBQUksRUFBQztFQUEwQixDQUFDLENBQUMsQ0FBQ0MsVUFBVTtFQUNqSCxNQUFNNUIsS0FBSyxHQUFDO0lBQUMsR0FBRzZCLGVBQWUsQ0FBQ2pHLE9BQU8sQ0FBQztJQUFDa0csVUFBVSxFQUFDLFNBQWtCO0lBQUNDLGNBQWMsRUFBQztNQUFDLENBQUN0RyxHQUFHLENBQUNpQixFQUFFLEdBQUV4QixPQUFPLENBQUMsSUFBSSxDQUFDO01BQUMsQ0FBQ00sUUFBUSxDQUFDa0IsRUFBRSxHQUFFckIsT0FBTyxDQUFDLENBQUM7SUFBQztFQUFDLENBQUM7RUFDeEksTUFBTTJHLEVBQUUsR0FBQ3hILEdBQUcsQ0FBQ0MsQ0FBQyxFQUFDLFlBQVksRUFBQyxlQUFlLEVBQUM7SUFBQ2lILGdCQUFnQixFQUFDSixHQUFHLENBQUM1RSxFQUFFO0lBQUN1RixlQUFlLEVBQUNYLEdBQUcsQ0FBQ1ksT0FBTyxDQUFDQyxRQUFRO0lBQUNDLFlBQVksRUFBQ3BDLEtBQUs7SUFBQ3FDLE1BQU0sRUFBQztFQUFTLENBQUMsQ0FBQztFQUMvSSxNQUFNQyxPQUFPLEdBQUM5SCxHQUFHLENBQUNDLENBQUMsRUFBQyxZQUFZLEVBQUMsY0FBYyxFQUFDO0lBQUNpSCxnQkFBZ0IsRUFBQ0osR0FBRyxDQUFDNUUsRUFBRTtJQUFDdUYsZUFBZSxFQUFDWCxHQUFHLENBQUNZLE9BQU8sQ0FBQ0MsUUFBUTtJQUFDQyxZQUFZLEVBQUM7TUFBQyxHQUFHUCxlQUFlLENBQUM3QixLQUFLLENBQUM7TUFBQytCLGNBQWMsRUFBQztRQUFDLENBQUN0RyxHQUFHLENBQUNpQixFQUFFLEdBQUV4QixPQUFPLENBQUMsSUFBSTtNQUFDO0lBQUMsQ0FBQztJQUFDbUgsTUFBTSxFQUFDO0VBQVMsQ0FBQyxDQUFDO0VBQ2pOLE9BQU87SUFBQzVILENBQUM7SUFBQ2dCLEdBQUc7SUFBQ0QsUUFBUTtJQUFDc0MsS0FBSztJQUFDSSxHQUFHO0lBQUN1QixTQUFTO0lBQUM0QixJQUFJO0lBQUMzQixLQUFLO0lBQUM0QixHQUFHO0lBQUNVLEVBQUU7SUFBQ007RUFBTyxDQUFDO0FBQ3ZFIiwiaWdub3JlTGlzdCI6W119