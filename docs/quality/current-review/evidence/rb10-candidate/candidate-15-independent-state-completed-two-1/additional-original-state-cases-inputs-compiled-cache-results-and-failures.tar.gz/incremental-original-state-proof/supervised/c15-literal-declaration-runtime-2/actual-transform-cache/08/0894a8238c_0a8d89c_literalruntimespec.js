// 44e1dba0e7221790d530cc585570a3cae9731f92
import { test, expect } from '@playwright/test';
import { originalStateWork, originalCoverageWork, originalCheckpointWork } from './literal-runtime-fixtures';
import { nav, seed, backup, durable, evidence, digest } from './common';
import { reader, begin, recordTrial, openRecord, editData, saveEditor, freshRoundtrip } from './extended-support';
test('AT-F37/F38/F39/F41 original enum life, integer affinity, unknown boolean, run10/across memory/derived: ordinary edits, atomic prohibited quest batch, reasons, cold and fullfile', async ({
  page,
  browser
}, info) => {
  var _cold$parsed$project$, _cold$parsed$project$2;
  test.setTimeout(240000);
  const f = originalStateWork();
  const input = await seed(page, f.p);
  await openRecord(page, 'variable', f.alive.name);
  await expect(page.getByRole('region', {
    name: '同義語・反対語の状態候補',
    exact: true
  })).toContainText('存命／死亡');
  const savedBeforeWrongType = await durable(page);
  await editData(page, data => {
    data.initial = {
      type: 'integer',
      value: 1
    };
  });
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  await page.locator('.editor-footer').getByRole('button', {
    name: /^(保存する|保存を再試行)$/
  }).click();
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/型|初期/);
  expect(await durable(page)).toEqual(savedBeforeWrongType);
  await editData(page, data => {
    data.initial = {
      type: 'enum',
      value: '未定義の値'
    };
  });
  await page.locator('.editor-footer').getByRole('button', {
    name: /^(保存する|保存を再試行)$/
  }).click();
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/許容|候補|値/);
  expect(await durable(page)).toEqual(savedBeforeWrongType);
  await editData(page, data => {
    data.initial = {
      type: 'enum',
      value: '存命'
    };
  });
  await saveEditor(page);
  await openRecord(page, 'effect', f.derivedWrite.name);
  const derivedBefore = await durable(page);
  await editData(page, data => {
    data.targetId = f.derived.id;
    data.value = {
      type: 'boolean',
      value: true
    };
  });
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('算出状態へ直接代入できません');
  expect(await durable(page)).toEqual(derivedBefore);
  await editData(page, data => {
    data.targetId = f.memory.id;
    data.value = {
      type: 'boolean',
      value: false
    };
  });
  await saveEditor(page);
  await openRecord(page, 'variable', f.derived.name);
  const cycleBefore = await durable(page);
  await editData(page, data => {
    data.derived = {
      op: 'variable',
      variableId: f.derived.id
    };
  });
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/循環/);
  expect(await durable(page)).toEqual(cycleBefore);
  await editData(page, data => {
    data.derived = {
      op: 'compare',
      variableId: f.affinity.id,
      comparator: 'ge',
      value: {
        type: 'integer',
        value: 5
      }
    };
  });
  await saveEditor(page);
  await reader(page);
  await begin(page, f.entry.id);
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.unsettled.name
  })).toContainText(/未定|未設定|不明/);
  const uses = page.locator('details').filter({
    has: page.locator('summary').filter({
      hasText: new RegExp('^' + f.affinity.name + ' · run ·')
    })
  });
  await uses.locator('summary').first().click();
  await expect(uses).toContainText('read');
  await expect(uses).toContainText('write');
  await expect(uses).toContainText('reset');
  await uses.getByRole('button', {
    name: f.setAffinity.name,
    exact: true
  }).click();
  await expect(page.locator('.detail-heading')).toContainText(f.setAffinity.name);
  await reader(page);
  await page.getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  for (const [name, value] of [[f.affinity.name, '5'], [f.money.name, '11'], [f.memory.name, 'true'], [f.derived.name, 'true']]) await expect(page.locator('.runtime-variable').filter({
    hasText: name
  })).toContainText(value);
  const beforeBatch = await durable(page);
  await page.getByRole('button', {
    name: f.invalid.data.label,
    exact: true
  }).click();
  await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移/);
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.money.name
  })).toContainText('11');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.questState.name
  })).toContainText('完了');
  expect(await durable(page)).toEqual(beforeBatch);
  // The whole-batch rejection cannot be repaired by an ordinary reason field.
  await begin(page, f.entry.id);
  await page.getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  await page.getByRole('button', {
    name: f.finish.data.label,
    exact: true
  }).click();
  await recordTrial(page);
  const one = await backup(page),
    trace1 = one.parsed.project.entities.find(e => e.kind === 'trace');
  expect(trace1.data.steps.at(-1).after.variableValues[f.affinity.id]).toEqual({
    type: 'integer',
    value: 5
  });
  expect(trace1.data.steps.at(-1).after.variableValues[f.money.id]).toEqual({
    type: 'integer',
    value: 11
  });
  await reader(page);
  await page.getByRole('button', {
    name: '次の周回',
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.money.name
  })).toContainText('10');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.memory.name
  })).toContainText('true');
  await page.getByRole('button', {
    name: 'すべて初期化',
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.memory.name
  })).toContainText('false');
  await begin(page, f.entry.id);
  await page.getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  await page.getByRole('button', {
    name: f.resetPath.data.label,
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.questState.name
  })).toContainText('未受注');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.affinity.name
  })).toContainText('0');
  await recordTrial(page);
  const resetArchive = await backup(page),
    resetTrace = resetArchive.parsed.project.entities.filter(e => e.kind === 'trace').at(-1);
  expect(resetTrace.data.steps.at(-1).before.variableValues[f.questState.id]).toEqual({
    type: 'enum',
    value: '完了'
  });
  expect(resetTrace.data.steps.at(-1).after.variableValues[f.questState.id]).toEqual({
    type: 'enum',
    value: '未受注'
  });
  expect(resetTrace.data.steps.at(-1).edgeIds).toEqual([f.resetPath.id]);
  await openRecord(page, 'effect', f.prohibited.name);
  await editData(page, data => {
    data.exceptionDetails = {
      reason: 'この経路のtick0–10に限り確認済み根拠に従って再受注する',
      targetScope: {
        projectId: f.p.projectId,
        graphId: f.graph.id,
        routeCondition: {
          op: 'constant',
          value: true
        }
      },
      validity: {
        worldRange: {
          start: '0',
          end: '10'
        },
        routeCondition: {
          op: 'constant',
          value: true
        },
        presentationAnchor: null
      },
      evidenceIds: [f.exceptionEvidence.id]
    };
  });
  await saveEditor(page);
  await reader(page);
  await page.getByLabel('試読開始時点の世界内tick', {
    exact: true
  }).fill('5');
  await begin(page, f.entry.id);
  await page.getByRole('button', {
    name: f.get.data.label,
    exact: true
  }).click();
  await page.getByRole('button', {
    name: f.invalid.data.label,
    exact: true
  }).click();
  await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.questState.name
  })).toContainText('未受注');
  await recordTrial(page);
  const acceptedException = await backup(page),
    exceptionTrace = acceptedException.parsed.project.entities.filter(e => e.kind === 'trace').at(-1);
  expect(exceptionTrace.data.steps.at(-1).after.itemInstances.some(i => i.instanceId === f.key.id && i.quantity === 1)).toBe(true);
  await reader(page);
  for (const tick of ['11', '']) {
    await page.getByLabel('試読開始時点の世界内tick', {
      exact: true
    }).fill(tick);
    await begin(page, f.entry.id);
    await page.getByRole('button', {
      name: f.get.data.label,
      exact: true
    }).click();
    const rejectedNative = await durable(page);
    await page.getByRole('button', {
      name: f.invalid.data.label,
      exact: true
    }).click();
    await expect(page.locator('.reader-issue')).toContainText(/禁止|遷移|期限|時点|例外/);
    await expect(page.locator('.runtime-variable').filter({
      hasText: f.money.name
    })).toContainText('11');
    await expect(page.locator('.runtime-variable').filter({
      hasText: f.questState.name
    })).toContainText('完了');
    expect(await durable(page)).toEqual(rejectedNative);
  }
  await nav(page, /^検索/);
  await page.getByRole('tab', {
    name: '見直しと統合',
    exact: true
  }).click();
  await expect(page.locator('.search-page')).toContainText(/外部.*利用/);
  const externalFinding = page.locator('.search-page article').filter({
    hasText: f.unused.name
  });
  await expect(externalFinding.getByRole('button', {
    name: '外部利用宣言を確認',
    exact: true
  })).toBeVisible();
  await page.reload();
  await expect(page.locator('.app-shell')).toBeVisible();
  const cold = await backup(page);
  expect((_cold$parsed$project$ = cold.parsed.project.entities.find(e => e.id === f.unused.id)) === null || _cold$parsed$project$ === void 0 ? void 0 : _cold$parsed$project$.deletedAt).toBeFalsy();
  expect((_cold$parsed$project$2 = cold.parsed.project.entities.find(e => e.id === f.unsettled.id)) === null || _cold$parsed$project$2 === void 0 ? void 0 : _cold$parsed$project$2.data).toMatchObject({
    initial: {
      type: 'unknown',
      value: null
    }
  });
  const restored = await freshRoundtrip(browser, cold.bytes),
    clone = await freshRoundtrip(browser, cold.bytes, 'clone');
  expect(restored.parsed.project).toEqual(cold.parsed.project);
  expect(clone.parsed.project.entities.filter(e => e.kind === 'trace')).toHaveLength(3);
  await evidence(info, 'F37-F38-F39-F41-literal-state', {
    fixtureSHA256: digest(input),
    sourceValues: {
      enum: ['存命', '死亡'],
      affinityInitial: 0,
      runMoney: 10,
      unknownBoolean: true,
      acrossRunMemory: true,
      derivedFrom: f.affinity.id
    },
    rejectedWrongTypeAndOutsideAllowed: true,
    derivedDirectWriteRejected: true,
    derivedCycleRejected: true,
    prohibitedQuestTransition: {
      from: '完了',
      to: '未受注',
      reason: '備考だけ',
      wholeMoneyAndItemBatchRejected: true
    },
    explicitResetTrace: resetTrace.data,
    exceptionTrace: exceptionTrace.data,
    exceptionInsideTick5Accepted: true,
    expiredTick11AndUnknownTickWholeBatchRefused: true,
    ordinaryUnchangedYExternalRetention: true,
    coldAndNewAndClone: true,
    archiveSHA256: digest(cold.bytes),
    fullCasesClaimed: []
  });
});
test('AT-F15 original key=true affinity=5 checkpoint, missing affinity and old version: partial is explicit, undo retains same start, migration required, cold and native new', async ({
  page,
  browser
}, info) => {
  var _trace$data$coverage;
  test.setTimeout(180000);
  const f = await originalCheckpointWork(),
    input = await seed(page, f.p);
  await reader(page);
  await page.getByLabel('試読する作品版', {
    exact: true
  }).selectOption(f.pin.id);
  await page.getByLabel('試読の開始点', {
    exact: true
  }).selectOption(f.entry.id);
  await page.getByLabel('保存した開始状態', {
    exact: true
  }).selectOption(f.cp.id);
  await page.getByRole('button', {
    name: '試読を始める',
    exact: true
  }).click();
  await expect(page.locator('.reader-trial-heading')).toContainText('途中開始の経路');
  await page.getByRole('button', {
    name: f.edge.data.label,
    exact: true
  }).click();
  await page.getByRole('button', {
    name: '一手戻る',
    exact: true
  }).click();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.affinity.name
  })).toContainText('5');
  await page.getByRole('button', {
    name: f.edge.data.label,
    exact: true
  }).click();
  await recordTrial(page);
  const saved = await backup(page),
    trace = saved.parsed.project.entities.find(e => e.kind === 'trace');
  expect(trace.data.steps[0].before.provenance).toBe('partial');
  expect((_trace$data$coverage = trace.data.coverage) === null || _trace$data$coverage === void 0 ? void 0 : _trace$data$coverage.declaredTests.checked).toBe(0);
  await reader(page);
  await page.getByLabel('保存した開始状態', {
    exact: true
  }).selectOption(f.missing.id);
  await page.getByRole('button', {
    name: 'この状態から開始し直す',
    exact: true
  }).click();
  await expect(page.locator('.reader-trial-heading')).toContainText(/未確認|不足/);
  await expect(page.getByRole('button', {
    name: f.edge.data.label,
    exact: true
  })).toBeDisabled();
  await expect(page.locator('.runtime-variable').filter({
    hasText: f.affinity.name
  })).toContainText(/不明|未設定/);
  await openRecord(page, 'flow_edge', f.edge.name);
  await page.getByLabel('名前', {
    exact: true
  }).fill('改訂後でも固定して残る経路');
  await saveEditor(page);
  await reader(page);
  await page.getByLabel('試読する作品版', {
    exact: true
  }).selectOption('');
  const currentCheckpointOptions = await page.getByLabel('保存した開始状態', {
    exact: true
  }).locator('option').evaluateAll(options => options.map(option => option.value));
  expect(currentCheckpointOptions).not.toContain(f.cp.id);
  const migration = page.getByRole('region', {
    name: '開始版の移行と経路の再確認',
    exact: true
  });
  await migration.locator('summary').filter({
    hasText: '保存した開始状態を別版へ移す'
  }).click();
  await expect(migration).toContainText(/別版|移行/);
  await page.reload();
  const cold = await backup(page);
  expect(cold.parsed.project.entities.find(e => e.id === f.cp.id)).toEqual(saved.parsed.project.entities.find(e => e.id === f.cp.id));
  expect(cold.parsed.project.snapshots.find(p => p.id === f.pin.id)).toEqual(f.pin);
  const empty = await freshRoundtrip(browser, cold.bytes);
  expect(empty.parsed.project.entities.find(e => e.id === trace.id)).toEqual(trace);
  await evidence(info, 'F15-literal-checkpoint', {
    fixtureSHA256: digest(input),
    checkpointIDs: [f.cp.id, f.missing.id],
    specifiedKeyTrueAndAffinity5: true,
    fullStateBefore: trace.data.steps[0].before,
    missingAffinityStayedUnknown: true,
    partialDidNotCreditFullPlay: true,
    currentVersionDidNotOfferOldCheckpoint: true,
    explicitMigrationUI: true,
    oldPinHash: f.pin.contentHash,
    coldAndEmpty: true,
    archiveSHA256: digest(cold.bytes)
  });
});
test('AT-F17 original four scenes / three choices / four condition sites: two-choice fixed trace, separated denominators and changed-content reconfirmation', async ({
  page
}, info) => {
  const f = originalCoverageWork(),
    input = await seed(page, f.p);
  await reader(page);
  await begin(page, f.entry.id);
  await page.getByRole('button', {
    name: f.edge1.data.label,
    exact: true
  }).click();
  await page.getByRole('button', {
    name: f.edge3.data.label,
    exact: true
  }).click();
  await recordTrial(page);
  const saved = await backup(page),
    trace = saved.parsed.project.entities.find(e => e.kind === 'trace');
  const coverage = trace.data.coverage;
  expect(coverage.scenes.total).toBe(4);
  expect(coverage.choices.total).toBe(3);
  expect(coverage.conditionTrue.total).toBe(4);
  expect(coverage.conditionFalse.total).toBe(4);
  expect(coverage.scenes.checked).toBe(3);
  expect(coverage.choices.checked).toBe(2);
  expect(coverage.dialogue.total).toBe(4);
  expect(coverage.dialogue.checked).toBe(3);
  expect(coverage.conditionFalse.checked).toBeLessThan(4);
  await page.reload();
  await reader(page);
  await page.locator('.saved-traces').getByRole('button', {
    name: new RegExp('^' + trace.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  }).click();
  await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');
  await openRecord(page, 'scene', f.scenes[0].name);
  await page.getByRole('tab', {
    name: '本文',
    exact: true
  }).click();
  await page.getByRole('textbox', {
    name: '本文',
    exact: true
  }).fill('原母数を保った改訂内容😀');
  await saveEditor(page);
  await reader(page);
  const reconfirm = page.getByRole('region', {
    name: '開始版の移行と経路の再確認',
    exact: true
  });
  await reconfirm.locator('summary').filter({
    hasText: '保存した経路を改訂稿で再確認する'
  }).click();
  await reconfirm.getByRole('radio', {
    name: new RegExp('^' + trace.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  }).check();
  await expect(reconfirm).toContainText('再確認待ち');
  const changed = await backup(page);
  expect(changed.parsed.project.entities.find(e => e.id === trace.id)).toEqual(trace);
  expect(changed.parsed.project.snapshots.find(p => p.id === trace.data.contentVersionId)).toEqual(saved.parsed.project.snapshots.find(p => p.id === trace.data.contentVersionId));
  await evidence(info, 'F17-literal-denominators', {
    fixtureSHA256: digest(input),
    givenScenes: 4,
    givenChoices: 3,
    givenConditionSites: 4,
    traceID: trace.id,
    coverage,
    observedEdges: [f.edge1.id, f.edge3.id],
    oldEvidenceNotPromotedAfterChange: true,
    reconfirmationPending: true,
    archiveSHA256: digest(changed.bytes)
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0Iiwib3JpZ2luYWxTdGF0ZVdvcmsiLCJvcmlnaW5hbENvdmVyYWdlV29yayIsIm9yaWdpbmFsQ2hlY2twb2ludFdvcmsiLCJuYXYiLCJzZWVkIiwiYmFja3VwIiwiZHVyYWJsZSIsImV2aWRlbmNlIiwiZGlnZXN0IiwicmVhZGVyIiwiYmVnaW4iLCJyZWNvcmRUcmlhbCIsIm9wZW5SZWNvcmQiLCJlZGl0RGF0YSIsInNhdmVFZGl0b3IiLCJmcmVzaFJvdW5kdHJpcCIsInBhZ2UiLCJicm93c2VyIiwiaW5mbyIsIl9jb2xkJHBhcnNlZCRwcm9qZWN0JCIsIl9jb2xkJHBhcnNlZCRwcm9qZWN0JDIiLCJzZXRUaW1lb3V0IiwiZiIsImlucHV0IiwicCIsImFsaXZlIiwibmFtZSIsImdldEJ5Um9sZSIsImV4YWN0IiwidG9Db250YWluVGV4dCIsInNhdmVkQmVmb3JlV3JvbmdUeXBlIiwiZGF0YSIsImluaXRpYWwiLCJ0eXBlIiwidmFsdWUiLCJsb2NhdG9yIiwiY2xpY2siLCJ0b0VxdWFsIiwiZGVyaXZlZFdyaXRlIiwiZGVyaXZlZEJlZm9yZSIsInRhcmdldElkIiwiZGVyaXZlZCIsImlkIiwibWVtb3J5IiwiY3ljbGVCZWZvcmUiLCJvcCIsInZhcmlhYmxlSWQiLCJhZmZpbml0eSIsImNvbXBhcmF0b3IiLCJlbnRyeSIsImZpbHRlciIsImhhc1RleHQiLCJ1bnNldHRsZWQiLCJ1c2VzIiwiaGFzIiwiUmVnRXhwIiwiZmlyc3QiLCJzZXRBZmZpbml0eSIsImdldCIsImxhYmVsIiwibW9uZXkiLCJiZWZvcmVCYXRjaCIsImludmFsaWQiLCJxdWVzdFN0YXRlIiwiZmluaXNoIiwib25lIiwidHJhY2UxIiwicGFyc2VkIiwicHJvamVjdCIsImVudGl0aWVzIiwiZmluZCIsImUiLCJraW5kIiwic3RlcHMiLCJhdCIsImFmdGVyIiwidmFyaWFibGVWYWx1ZXMiLCJyZXNldFBhdGgiLCJyZXNldEFyY2hpdmUiLCJyZXNldFRyYWNlIiwiYmVmb3JlIiwiZWRnZUlkcyIsInByb2hpYml0ZWQiLCJleGNlcHRpb25EZXRhaWxzIiwicmVhc29uIiwidGFyZ2V0U2NvcGUiLCJwcm9qZWN0SWQiLCJncmFwaElkIiwiZ3JhcGgiLCJyb3V0ZUNvbmRpdGlvbiIsInZhbGlkaXR5Iiwid29ybGRSYW5nZSIsInN0YXJ0IiwiZW5kIiwicHJlc2VudGF0aW9uQW5jaG9yIiwiZXZpZGVuY2VJZHMiLCJleGNlcHRpb25FdmlkZW5jZSIsImdldEJ5TGFiZWwiLCJmaWxsIiwiYWNjZXB0ZWRFeGNlcHRpb24iLCJleGNlcHRpb25UcmFjZSIsIml0ZW1JbnN0YW5jZXMiLCJzb21lIiwiaSIsImluc3RhbmNlSWQiLCJrZXkiLCJxdWFudGl0eSIsInRvQmUiLCJ0aWNrIiwicmVqZWN0ZWROYXRpdmUiLCJleHRlcm5hbEZpbmRpbmciLCJ1bnVzZWQiLCJ0b0JlVmlzaWJsZSIsInJlbG9hZCIsImNvbGQiLCJkZWxldGVkQXQiLCJ0b0JlRmFsc3kiLCJ0b01hdGNoT2JqZWN0IiwicmVzdG9yZWQiLCJieXRlcyIsImNsb25lIiwidG9IYXZlTGVuZ3RoIiwiZml4dHVyZVNIQTI1NiIsInNvdXJjZVZhbHVlcyIsImVudW0iLCJhZmZpbml0eUluaXRpYWwiLCJydW5Nb25leSIsInVua25vd25Cb29sZWFuIiwiYWNyb3NzUnVuTWVtb3J5IiwiZGVyaXZlZEZyb20iLCJyZWplY3RlZFdyb25nVHlwZUFuZE91dHNpZGVBbGxvd2VkIiwiZGVyaXZlZERpcmVjdFdyaXRlUmVqZWN0ZWQiLCJkZXJpdmVkQ3ljbGVSZWplY3RlZCIsInByb2hpYml0ZWRRdWVzdFRyYW5zaXRpb24iLCJmcm9tIiwidG8iLCJ3aG9sZU1vbmV5QW5kSXRlbUJhdGNoUmVqZWN0ZWQiLCJleHBsaWNpdFJlc2V0VHJhY2UiLCJleGNlcHRpb25JbnNpZGVUaWNrNUFjY2VwdGVkIiwiZXhwaXJlZFRpY2sxMUFuZFVua25vd25UaWNrV2hvbGVCYXRjaFJlZnVzZWQiLCJvcmRpbmFyeVVuY2hhbmdlZFlFeHRlcm5hbFJldGVudGlvbiIsImNvbGRBbmROZXdBbmRDbG9uZSIsImFyY2hpdmVTSEEyNTYiLCJmdWxsQ2FzZXNDbGFpbWVkIiwiX3RyYWNlJGRhdGEkY292ZXJhZ2UiLCJzZWxlY3RPcHRpb24iLCJwaW4iLCJjcCIsImVkZ2UiLCJzYXZlZCIsInRyYWNlIiwicHJvdmVuYW5jZSIsImNvdmVyYWdlIiwiZGVjbGFyZWRUZXN0cyIsImNoZWNrZWQiLCJtaXNzaW5nIiwidG9CZURpc2FibGVkIiwiY3VycmVudENoZWNrcG9pbnRPcHRpb25zIiwiZXZhbHVhdGVBbGwiLCJvcHRpb25zIiwibWFwIiwib3B0aW9uIiwibm90IiwidG9Db250YWluIiwibWlncmF0aW9uIiwic25hcHNob3RzIiwiZW1wdHkiLCJjaGVja3BvaW50SURzIiwic3BlY2lmaWVkS2V5VHJ1ZUFuZEFmZmluaXR5NSIsImZ1bGxTdGF0ZUJlZm9yZSIsIm1pc3NpbmdBZmZpbml0eVN0YXllZFVua25vd24iLCJwYXJ0aWFsRGlkTm90Q3JlZGl0RnVsbFBsYXkiLCJjdXJyZW50VmVyc2lvbkRpZE5vdE9mZmVyT2xkQ2hlY2twb2ludCIsImV4cGxpY2l0TWlncmF0aW9uVUkiLCJvbGRQaW5IYXNoIiwiY29udGVudEhhc2giLCJjb2xkQW5kRW1wdHkiLCJlZGdlMSIsImVkZ2UzIiwic2NlbmVzIiwidG90YWwiLCJjaG9pY2VzIiwiY29uZGl0aW9uVHJ1ZSIsImNvbmRpdGlvbkZhbHNlIiwiZGlhbG9ndWUiLCJ0b0JlTGVzc1RoYW4iLCJyZXBsYWNlIiwicmVjb25maXJtIiwiY2hlY2siLCJjaGFuZ2VkIiwiY29udGVudFZlcnNpb25JZCIsImdpdmVuU2NlbmVzIiwiZ2l2ZW5DaG9pY2VzIiwiZ2l2ZW5Db25kaXRpb25TaXRlcyIsInRyYWNlSUQiLCJvYnNlcnZlZEVkZ2VzIiwib2xkRXZpZGVuY2VOb3RQcm9tb3RlZEFmdGVyQ2hhbmdlIiwicmVjb25maXJtYXRpb25QZW5kaW5nIl0sInNvdXJjZXMiOlsibGl0ZXJhbC1ydW50aW1lLnNwZWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt0ZXN0LGV4cGVjdH0gZnJvbSAnQHBsYXl3cmlnaHQvdGVzdCc7XG5pbXBvcnQgdHlwZSB7RW50aXR5fSBmcm9tICcuLi9jYW5kaWRhdGUvc3JjL2RvbWFpbi90eXBlcyc7XG5pbXBvcnQge29yaWdpbmFsU3RhdGVXb3JrLG9yaWdpbmFsQ292ZXJhZ2VXb3JrLG9yaWdpbmFsQ2hlY2twb2ludFdvcmt9IGZyb20gJy4vbGl0ZXJhbC1ydW50aW1lLWZpeHR1cmVzJztcbmltcG9ydCB7bmF2LHNlZWQsYmFja3VwLGR1cmFibGUsZXZpZGVuY2UsZGlnZXN0fSBmcm9tICcuL2NvbW1vbic7XG5pbXBvcnQge3JlYWRlcixiZWdpbixyZWNvcmRUcmlhbCxvcGVuUmVjb3JkLGVkaXREYXRhLHNhdmVFZGl0b3IsZnJlc2hSb3VuZHRyaXB9IGZyb20gJy4vZXh0ZW5kZWQtc3VwcG9ydCc7XG5cbnRlc3QoJ0FULUYzNy9GMzgvRjM5L0Y0MSBvcmlnaW5hbCBlbnVtIGxpZmUsIGludGVnZXIgYWZmaW5pdHksIHVua25vd24gYm9vbGVhbiwgcnVuMTAvYWNyb3NzIG1lbW9yeS9kZXJpdmVkOiBvcmRpbmFyeSBlZGl0cywgYXRvbWljIHByb2hpYml0ZWQgcXVlc3QgYmF0Y2gsIHJlYXNvbnMsIGNvbGQgYW5kIGZ1bGxmaWxlJyxhc3luYyh7cGFnZSxicm93c2VyfSxpbmZvKT0+e1xuICB0ZXN0LnNldFRpbWVvdXQoMjQwMDAwKTtcbiAgY29uc3QgZj1vcmlnaW5hbFN0YXRlV29yaygpO2NvbnN0IGlucHV0PWF3YWl0IHNlZWQocGFnZSxmLnApO1xuICBhd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ3ZhcmlhYmxlJyxmLmFsaXZlLm5hbWUpO1xuICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ3JlZ2lvbicse25hbWU6J+WQjOe+qeiqnuODu+WPjeWvvuiqnuOBrueKtuaFi+WAmeijnCcsZXhhY3Q6dHJ1ZX0pKS50b0NvbnRhaW5UZXh0KCflrZjlkb3vvI/mrbvkuqEnKTtcbiAgY29uc3Qgc2F2ZWRCZWZvcmVXcm9uZ1R5cGU9YXdhaXQgZHVyYWJsZShwYWdlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5pbml0aWFsPXt0eXBlOidpbnRlZ2VyJyx2YWx1ZToxfTt9KTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmRldGFpbC1wYW5lbCcpLmdldEJ5Um9sZSgnYWxlcnQnKSkudG9Db250YWluVGV4dCgv5Z6LfOWIneacny8pO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJy5lZGl0b3ItZm9vdGVyJykuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOi9eKOS/neWtmOOBmeOCi3zkv53lrZjjgpLlho3oqabooYwpJC99KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuZGV0YWlsLXBhbmVsJykuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0NvbnRhaW5UZXh0KC/lnot85Yid5pyfLyk7XG4gIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKHNhdmVkQmVmb3JlV3JvbmdUeXBlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5pbml0aWFsPXt0eXBlOidlbnVtJyx2YWx1ZTon5pyq5a6a576p44Gu5YCkJ307fSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignLmVkaXRvci1mb290ZXInKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6L14o5L+d5a2Y44GZ44KLfOS/neWtmOOCkuWGjeippuihjCkkL30pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtcGFuZWwnKS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoL+ioseWuuXzlgJnoo5x85YCkLyk7XG4gIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKHNhdmVkQmVmb3JlV3JvbmdUeXBlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS5pbml0aWFsPXt0eXBlOidlbnVtJyx2YWx1ZTon5a2Y5ZG9J307fSk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiAgYXdhaXQgb3BlblJlY29yZChwYWdlLCdlZmZlY3QnLGYuZGVyaXZlZFdyaXRlLm5hbWUpO2NvbnN0IGRlcml2ZWRCZWZvcmU9YXdhaXQgZHVyYWJsZShwYWdlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS50YXJnZXRJZD1mLmRlcml2ZWQuaWQ7ZGF0YS52YWx1ZT17dHlwZTonYm9vbGVhbicsdmFsdWU6dHJ1ZX07fSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtcGFuZWwnKS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ+eul+WHuueKtuaFi+OBuOebtOaOpeS7o+WFpeOBp+OBjeOBvuOBm+OCkycpO1xuICBleHBlY3QoYXdhaXQgZHVyYWJsZShwYWdlKSkudG9FcXVhbChkZXJpdmVkQmVmb3JlKTtcbiAgYXdhaXQgZWRpdERhdGEocGFnZSxkYXRhPT57ZGF0YS50YXJnZXRJZD1mLm1lbW9yeS5pZDtkYXRhLnZhbHVlPXt0eXBlOidib29sZWFuJyx2YWx1ZTpmYWxzZX07fSk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiAgYXdhaXQgb3BlblJlY29yZChwYWdlLCd2YXJpYWJsZScsZi5kZXJpdmVkLm5hbWUpO2NvbnN0IGN5Y2xlQmVmb3JlPWF3YWl0IGR1cmFibGUocGFnZSk7XG4gIGF3YWl0IGVkaXREYXRhKHBhZ2UsZGF0YT0+e2RhdGEuZGVyaXZlZD17b3A6J3ZhcmlhYmxlJyx2YXJpYWJsZUlkOmYuZGVyaXZlZC5pZH07fSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5kZXRhaWwtcGFuZWwnKS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoL+W+queSsC8pO1xuICBleHBlY3QoYXdhaXQgZHVyYWJsZShwYWdlKSkudG9FcXVhbChjeWNsZUJlZm9yZSk7XG4gIGF3YWl0IGVkaXREYXRhKHBhZ2UsZGF0YT0+e2RhdGEuZGVyaXZlZD17b3A6J2NvbXBhcmUnLHZhcmlhYmxlSWQ6Zi5hZmZpbml0eS5pZCxjb21wYXJhdG9yOidnZScsdmFsdWU6e3R5cGU6J2ludGVnZXInLHZhbHVlOjV9fTt9KTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO1xuICBhd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgYmVnaW4ocGFnZSxmLmVudHJ5LmlkKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi51bnNldHRsZWQubmFtZX0pKS50b0NvbnRhaW5UZXh0KC/mnKrlrpp85pyq6Kit5a6afOS4jeaYji8pO1xuICBjb25zdCB1c2VzPXBhZ2UubG9jYXRvcignZGV0YWlscycpLmZpbHRlcih7aGFzOnBhZ2UubG9jYXRvcignc3VtbWFyeScpLmZpbHRlcih7aGFzVGV4dDpuZXcgUmVnRXhwKCdeJytmLmFmZmluaXR5Lm5hbWUrJyDCtyBydW4gwrcnKX0pfSk7XG4gIGF3YWl0IHVzZXMubG9jYXRvcignc3VtbWFyeScpLmZpcnN0KCkuY2xpY2soKTthd2FpdCBleHBlY3QodXNlcykudG9Db250YWluVGV4dCgncmVhZCcpO2F3YWl0IGV4cGVjdCh1c2VzKS50b0NvbnRhaW5UZXh0KCd3cml0ZScpO2F3YWl0IGV4cGVjdCh1c2VzKS50b0NvbnRhaW5UZXh0KCdyZXNldCcpO1xuICBhd2FpdCB1c2VzLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLnNldEFmZmluaXR5Lm5hbWUsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmRldGFpbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQoZi5zZXRBZmZpbml0eS5uYW1lKTthd2FpdCByZWFkZXIocGFnZSk7XG4gIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuZ2V0LmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO1xuICBmb3IoY29uc3QgW25hbWUsdmFsdWVdIG9mIFtbZi5hZmZpbml0eS5uYW1lLCc1J10sW2YubW9uZXkubmFtZSwnMTEnXSxbZi5tZW1vcnkubmFtZSwndHJ1ZSddLFtmLmRlcml2ZWQubmFtZSwndHJ1ZSddXSBhcyBjb25zdClhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpuYW1lfSkpLnRvQ29udGFpblRleHQodmFsdWUpO1xuICBjb25zdCBiZWZvcmVCYXRjaD1hd2FpdCBkdXJhYmxlKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmludmFsaWQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItaXNzdWUnKSkudG9Db250YWluVGV4dCgv56aB5q2ifOmBt+enuy8pO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpmLm1vbmV5Lm5hbWV9KSkudG9Db250YWluVGV4dCgnMTEnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi5xdWVzdFN0YXRlLm5hbWV9KSkudG9Db250YWluVGV4dCgn5a6M5LqGJyk7XG4gIGV4cGVjdChhd2FpdCBkdXJhYmxlKHBhZ2UpKS50b0VxdWFsKGJlZm9yZUJhdGNoKTtcbiAgLy8gVGhlIHdob2xlLWJhdGNoIHJlamVjdGlvbiBjYW5ub3QgYmUgcmVwYWlyZWQgYnkgYW4gb3JkaW5hcnkgcmVhc29uIGZpZWxkLlxuICBhd2FpdCBiZWdpbihwYWdlLGYuZW50cnkuaWQpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuZ2V0LmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO1xuICBhd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmZpbmlzaC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCByZWNvcmRUcmlhbChwYWdlKTtcbiAgY29uc3Qgb25lPWF3YWl0IGJhY2t1cChwYWdlKSx0cmFjZTE9b25lLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoKGUpOmUgaXMgRW50aXR5PCd0cmFjZSc+PT5lLmtpbmQ9PT0ndHJhY2UnKSE7XG4gIGV4cGVjdCh0cmFjZTEuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnZhcmlhYmxlVmFsdWVzW2YuYWZmaW5pdHkuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZTo1fSk7XG4gIGV4cGVjdCh0cmFjZTEuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnZhcmlhYmxlVmFsdWVzW2YubW9uZXkuaWRdKS50b0VxdWFsKHt0eXBlOidpbnRlZ2VyJyx2YWx1ZToxMX0pO1xuICBhd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+asoeOBruWRqOWbnicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYubW9uZXkubmFtZX0pKS50b0NvbnRhaW5UZXh0KCcxMCcpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpmLm1lbW9yeS5uYW1lfSkpLnRvQ29udGFpblRleHQoJ3RydWUnKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+OBmeOBueOBpuWIneacn+WMlicsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYubWVtb3J5Lm5hbWV9KSkudG9Db250YWluVGV4dCgnZmFsc2UnKTtcbiAgYXdhaXQgYmVnaW4ocGFnZSxmLmVudHJ5LmlkKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmdldC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5yZXNldFBhdGguZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYucXVlc3RTdGF0ZS5uYW1lfSkpLnRvQ29udGFpblRleHQoJ+acquWPl+azqCcpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpmLmFmZmluaXR5Lm5hbWV9KSkudG9Db250YWluVGV4dCgnMCcpO1xuICBhd2FpdCByZWNvcmRUcmlhbChwYWdlKTtjb25zdCByZXNldEFyY2hpdmU9YXdhaXQgYmFja3VwKHBhZ2UpLHJlc2V0VHJhY2U9cmVzZXRBcmNoaXZlLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbHRlcigoZSk6ZSBpcyBFbnRpdHk8J3RyYWNlJz49PmUua2luZD09PSd0cmFjZScpLmF0KC0xKSE7XG4gIGV4cGVjdChyZXNldFRyYWNlLmRhdGEuc3RlcHMuYXQoLTEpIS5iZWZvcmUudmFyaWFibGVWYWx1ZXNbZi5xdWVzdFN0YXRlLmlkXSkudG9FcXVhbCh7dHlwZTonZW51bScsdmFsdWU6J+WujOS6hid9KTtcbiAgZXhwZWN0KHJlc2V0VHJhY2UuZGF0YS5zdGVwcy5hdCgtMSkhLmFmdGVyLnZhcmlhYmxlVmFsdWVzW2YucXVlc3RTdGF0ZS5pZF0pLnRvRXF1YWwoe3R5cGU6J2VudW0nLHZhbHVlOifmnKrlj5fms6gnfSk7XG4gIGV4cGVjdChyZXNldFRyYWNlLmRhdGEuc3RlcHMuYXQoLTEpIS5lZGdlSWRzKS50b0VxdWFsKFtmLnJlc2V0UGF0aC5pZF0pO1xuICBhd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ2VmZmVjdCcsZi5wcm9oaWJpdGVkLm5hbWUpO1xuICBhd2FpdCBlZGl0RGF0YShwYWdlLGRhdGE9PntkYXRhLmV4Y2VwdGlvbkRldGFpbHM9e3JlYXNvbjon44GT44Gu57WM6Lev44GudGljazDigJMxMOOBq+mZkOOCiueiuuiqjea4iOOBv+agueaLoOOBq+W+k+OBo+OBpuWGjeWPl+azqOOBmeOCiycsdGFyZ2V0U2NvcGU6e3Byb2plY3RJZDpmLnAucHJvamVjdElkLGdyYXBoSWQ6Zi5ncmFwaC5pZCxyb3V0ZUNvbmRpdGlvbjp7b3A6J2NvbnN0YW50Jyx2YWx1ZTp0cnVlfX0sdmFsaWRpdHk6e3dvcmxkUmFuZ2U6e3N0YXJ0OicwJyxlbmQ6JzEwJ30scm91dGVDb25kaXRpb246e29wOidjb25zdGFudCcsdmFsdWU6dHJ1ZX0scHJlc2VudGF0aW9uQW5jaG9yOm51bGx9LGV2aWRlbmNlSWRzOltmLmV4Y2VwdGlvbkV2aWRlbmNlLmlkXX07fSk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiAgYXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn6Kmm6Kqt6ZaL5aeL5pmC54K544Gu5LiW55WM5YaFdGljaycse2V4YWN0OnRydWV9KS5maWxsKCc1Jyk7YXdhaXQgYmVnaW4ocGFnZSxmLmVudHJ5LmlkKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmdldC5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmludmFsaWQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5yZWFkZXItdHJpYWwtaGVhZGluZycpKS50b0NvbnRhaW5UZXh0KCfmhI/lm7PjgZfjgZ/ntYLnq68nKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucnVudGltZS12YXJpYWJsZScpLmZpbHRlcih7aGFzVGV4dDpmLnF1ZXN0U3RhdGUubmFtZX0pKS50b0NvbnRhaW5UZXh0KCfmnKrlj5fms6gnKTthd2FpdCByZWNvcmRUcmlhbChwYWdlKTtcbiAgY29uc3QgYWNjZXB0ZWRFeGNlcHRpb249YXdhaXQgYmFja3VwKHBhZ2UpLGV4Y2VwdGlvblRyYWNlPWFjY2VwdGVkRXhjZXB0aW9uLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbHRlcigoZSk6ZSBpcyBFbnRpdHk8J3RyYWNlJz49PmUua2luZD09PSd0cmFjZScpLmF0KC0xKSE7XG4gIGV4cGVjdChleGNlcHRpb25UcmFjZS5kYXRhLnN0ZXBzLmF0KC0xKSEuYWZ0ZXIuaXRlbUluc3RhbmNlcy5zb21lKGk9PmkuaW5zdGFuY2VJZD09PWYua2V5LmlkJiZpLnF1YW50aXR5PT09MSkpLnRvQmUodHJ1ZSk7XG4gIGF3YWl0IHJlYWRlcihwYWdlKTtmb3IoY29uc3QgdGljayBvZiBbJzExJywnJ10pe1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn6Kmm6Kqt6ZaL5aeL5pmC54K544Gu5LiW55WM5YaFdGljaycse2V4YWN0OnRydWV9KS5maWxsKHRpY2spO2F3YWl0IGJlZ2luKHBhZ2UsZi5lbnRyeS5pZCk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5nZXQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7Y29uc3QgcmVqZWN0ZWROYXRpdmU9YXdhaXQgZHVyYWJsZShwYWdlKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmludmFsaWQuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci1pc3N1ZScpKS50b0NvbnRhaW5UZXh0KC/npoHmraJ86YG356e7fOacn+mZkHzmmYLngrl85L6L5aSWLyk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi5tb25leS5uYW1lfSkpLnRvQ29udGFpblRleHQoJzExJyk7YXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJ1bnRpbWUtdmFyaWFibGUnKS5maWx0ZXIoe2hhc1RleHQ6Zi5xdWVzdFN0YXRlLm5hbWV9KSkudG9Db250YWluVGV4dCgn5a6M5LqGJyk7ZXhwZWN0KGF3YWl0IGR1cmFibGUocGFnZSkpLnRvRXF1YWwocmVqZWN0ZWROYXRpdmUpO1xuICB9XG4gIGF3YWl0IG5hdihwYWdlLC9e5qSc57SiLyk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ3RhYicse25hbWU6J+imi+ebtOOBl+OBqOe1seWQiCcsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5zZWFyY2gtcGFnZScpKS50b0NvbnRhaW5UZXh0KC/lpJbpg6guKuWIqeeUqC8pO1xuICBjb25zdCBleHRlcm5hbEZpbmRpbmc9cGFnZS5sb2NhdG9yKCcuc2VhcmNoLXBhZ2UgYXJ0aWNsZScpLmZpbHRlcih7aGFzVGV4dDpmLnVudXNlZC5uYW1lfSk7XG4gIGF3YWl0IGV4cGVjdChleHRlcm5hbEZpbmRpbmcuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOiflpJbpg6jliKnnlKjlrqPoqIDjgpLnorroqo0nLGV4YWN0OnRydWV9KSkudG9CZVZpc2libGUoKTtcbiAgYXdhaXQgcGFnZS5yZWxvYWQoKTthd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuYXBwLXNoZWxsJykpLnRvQmVWaXNpYmxlKCk7Y29uc3QgY29sZD1hd2FpdCBiYWNrdXAocGFnZSk7XG4gIGV4cGVjdChjb2xkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PWYudW51c2VkLmlkKT8uZGVsZXRlZEF0KS50b0JlRmFsc3koKTtcbiAgZXhwZWN0KGNvbGQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmluZChlPT5lLmlkPT09Zi51bnNldHRsZWQuaWQpPy5kYXRhKS50b01hdGNoT2JqZWN0KHtpbml0aWFsOnt0eXBlOid1bmtub3duJyx2YWx1ZTpudWxsfX0pO1xuICBjb25zdCByZXN0b3JlZD1hd2FpdCBmcmVzaFJvdW5kdHJpcChicm93c2VyLGNvbGQuYnl0ZXMpLGNsb25lPWF3YWl0IGZyZXNoUm91bmR0cmlwKGJyb3dzZXIsY29sZC5ieXRlcywnY2xvbmUnKTtcbiAgZXhwZWN0KHJlc3RvcmVkLnBhcnNlZC5wcm9qZWN0KS50b0VxdWFsKGNvbGQucGFyc2VkLnByb2plY3QpO2V4cGVjdChjbG9uZS5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maWx0ZXIoZT0+ZS5raW5kPT09J3RyYWNlJykpLnRvSGF2ZUxlbmd0aCgzKTtcbiAgYXdhaXQgZXZpZGVuY2UoaW5mbywnRjM3LUYzOC1GMzktRjQxLWxpdGVyYWwtc3RhdGUnLHtmaXh0dXJlU0hBMjU2OmRpZ2VzdChpbnB1dCksc291cmNlVmFsdWVzOntlbnVtOlsn5a2Y5ZG9Jywn5q275LqhJ10sYWZmaW5pdHlJbml0aWFsOjAscnVuTW9uZXk6MTAsdW5rbm93bkJvb2xlYW46dHJ1ZSxhY3Jvc3NSdW5NZW1vcnk6dHJ1ZSxkZXJpdmVkRnJvbTpmLmFmZmluaXR5LmlkfSxyZWplY3RlZFdyb25nVHlwZUFuZE91dHNpZGVBbGxvd2VkOnRydWUsZGVyaXZlZERpcmVjdFdyaXRlUmVqZWN0ZWQ6dHJ1ZSxkZXJpdmVkQ3ljbGVSZWplY3RlZDp0cnVlLHByb2hpYml0ZWRRdWVzdFRyYW5zaXRpb246e2Zyb206J+WujOS6hicsdG86J+acquWPl+azqCcscmVhc29uOiflgpnogIPjgaDjgZEnLHdob2xlTW9uZXlBbmRJdGVtQmF0Y2hSZWplY3RlZDp0cnVlfSxleHBsaWNpdFJlc2V0VHJhY2U6cmVzZXRUcmFjZS5kYXRhLGV4Y2VwdGlvblRyYWNlOmV4Y2VwdGlvblRyYWNlLmRhdGEsZXhjZXB0aW9uSW5zaWRlVGljazVBY2NlcHRlZDp0cnVlLGV4cGlyZWRUaWNrMTFBbmRVbmtub3duVGlja1dob2xlQmF0Y2hSZWZ1c2VkOnRydWUsb3JkaW5hcnlVbmNoYW5nZWRZRXh0ZXJuYWxSZXRlbnRpb246dHJ1ZSxjb2xkQW5kTmV3QW5kQ2xvbmU6dHJ1ZSxhcmNoaXZlU0hBMjU2OmRpZ2VzdChjb2xkLmJ5dGVzKSxmdWxsQ2FzZXNDbGFpbWVkOltdfSk7XG59KTtcblxudGVzdCgnQVQtRjE1IG9yaWdpbmFsIGtleT10cnVlIGFmZmluaXR5PTUgY2hlY2twb2ludCwgbWlzc2luZyBhZmZpbml0eSBhbmQgb2xkIHZlcnNpb246IHBhcnRpYWwgaXMgZXhwbGljaXQsIHVuZG8gcmV0YWlucyBzYW1lIHN0YXJ0LCBtaWdyYXRpb24gcmVxdWlyZWQsIGNvbGQgYW5kIG5hdGl2ZSBuZXcnLGFzeW5jKHtwYWdlLGJyb3dzZXJ9LGluZm8pPT57XG4gIHRlc3Quc2V0VGltZW91dCgxODAwMDApO2NvbnN0IGY9YXdhaXQgb3JpZ2luYWxDaGVja3BvaW50V29yaygpLGlucHV0PWF3YWl0IHNlZWQocGFnZSxmLnApO1xuICBhd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgcGFnZS5nZXRCeUxhYmVsKCfoqaboqq3jgZnjgovkvZzlk4HniYgnLHtleGFjdDp0cnVlfSkuc2VsZWN0T3B0aW9uKGYucGluLmlkKTthd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+ippuiqreOBrumWi+Wni+eCuScse2V4YWN0OnRydWV9KS5zZWxlY3RPcHRpb24oZi5lbnRyeS5pZCk7XG4gIGF3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn5L+d5a2Y44GX44Gf6ZaL5aeL54q25oWLJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbihmLmNwLmlkKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTon6Kmm6Kqt44KS5aeL44KB44KLJyxleGFjdDp0cnVlfSkuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci10cmlhbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQoJ+mAlOS4remWi+Wni+OBrue1jOi3rycpO1xuICBhd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmVkZ2UuZGF0YS5sYWJlbCEsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J+S4gOaJi+aIu+OCiycsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYuYWZmaW5pdHkubmFtZX0pKS50b0NvbnRhaW5UZXh0KCc1Jyk7XG4gIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOmYuZWRnZS5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCByZWNvcmRUcmlhbChwYWdlKTtcbiAgY29uc3Qgc2F2ZWQ9YXdhaXQgYmFja3VwKHBhZ2UpLHRyYWNlPXNhdmVkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoKGUpOmUgaXMgRW50aXR5PCd0cmFjZSc+PT5lLmtpbmQ9PT0ndHJhY2UnKSE7XG4gIGV4cGVjdCh0cmFjZS5kYXRhLnN0ZXBzWzBdLmJlZm9yZS5wcm92ZW5hbmNlKS50b0JlKCdwYXJ0aWFsJyk7ZXhwZWN0KHRyYWNlLmRhdGEuY292ZXJhZ2U/LmRlY2xhcmVkVGVzdHMuY2hlY2tlZCkudG9CZSgwKTtcbiAgYXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn5L+d5a2Y44GX44Gf6ZaL5aeL54q25oWLJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbihmLm1pc3NpbmcuaWQpO2F3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOifjgZPjga7nirbmhYvjgYvjgonplovlp4vjgZfnm7TjgZknLGV4YWN0OnRydWV9KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcucmVhZGVyLXRyaWFsLWhlYWRpbmcnKSkudG9Db250YWluVGV4dCgv5pyq56K66KqNfOS4jei2sy8pO1xuICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5lZGdlLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KSkudG9CZURpc2FibGVkKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ydW50aW1lLXZhcmlhYmxlJykuZmlsdGVyKHtoYXNUZXh0OmYuYWZmaW5pdHkubmFtZX0pKS50b0NvbnRhaW5UZXh0KC/kuI3mmI585pyq6Kit5a6aLyk7XG4gIGF3YWl0IG9wZW5SZWNvcmQocGFnZSwnZmxvd19lZGdlJyxmLmVkZ2UubmFtZSk7YXdhaXQgcGFnZS5nZXRCeUxhYmVsKCflkI3liY0nLHtleGFjdDp0cnVlfSkuZmlsbCgn5pS56KiC5b6M44Gn44KC5Zu65a6a44GX44Gm5q6L44KL57WM6LevJyk7YXdhaXQgc2F2ZUVkaXRvcihwYWdlKTtcbiAgYXdhaXQgcmVhZGVyKHBhZ2UpO2F3YWl0IHBhZ2UuZ2V0QnlMYWJlbCgn6Kmm6Kqt44GZ44KL5L2c5ZOB54mIJyx7ZXhhY3Q6dHJ1ZX0pLnNlbGVjdE9wdGlvbignJyk7XG4gIGNvbnN0IGN1cnJlbnRDaGVja3BvaW50T3B0aW9ucz1hd2FpdCBwYWdlLmdldEJ5TGFiZWwoJ+S/neWtmOOBl+OBn+mWi+Wni+eKtuaFiycse2V4YWN0OnRydWV9KS5sb2NhdG9yKCdvcHRpb24nKS5ldmFsdWF0ZUFsbChvcHRpb25zPT5vcHRpb25zLm1hcChvcHRpb249PihvcHRpb24gYXMgSFRNTE9wdGlvbkVsZW1lbnQpLnZhbHVlKSk7ZXhwZWN0KGN1cnJlbnRDaGVja3BvaW50T3B0aW9ucykubm90LnRvQ29udGFpbihmLmNwLmlkKTtcbiAgY29uc3QgbWlncmF0aW9uPXBhZ2UuZ2V0QnlSb2xlKCdyZWdpb24nLHtuYW1lOifplovlp4vniYjjga7np7vooYzjgajntYzot6/jga7lho3norroqo0nLGV4YWN0OnRydWV9KTthd2FpdCBtaWdyYXRpb24ubG9jYXRvcignc3VtbWFyeScpLmZpbHRlcih7aGFzVGV4dDon5L+d5a2Y44GX44Gf6ZaL5aeL54q25oWL44KS5Yil54mI44G456e744GZJ30pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChtaWdyYXRpb24pLnRvQ29udGFpblRleHQoL+WIpeeJiHznp7vooYwvKTtcbiAgYXdhaXQgcGFnZS5yZWxvYWQoKTtjb25zdCBjb2xkPWF3YWl0IGJhY2t1cChwYWdlKTtleHBlY3QoY29sZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLmNwLmlkKSkudG9FcXVhbChzYXZlZC5wYXJzZWQucHJvamVjdC5lbnRpdGllcy5maW5kKGU9PmUuaWQ9PT1mLmNwLmlkKSk7ZXhwZWN0KGNvbGQucGFyc2VkLnByb2plY3Quc25hcHNob3RzLmZpbmQocD0+cC5pZD09PWYucGluLmlkKSkudG9FcXVhbChmLnBpbik7XG4gIGNvbnN0IGVtcHR5PWF3YWl0IGZyZXNoUm91bmR0cmlwKGJyb3dzZXIsY29sZC5ieXRlcyk7ZXhwZWN0KGVtcHR5LnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PXRyYWNlLmlkKSkudG9FcXVhbCh0cmFjZSk7XG4gIGF3YWl0IGV2aWRlbmNlKGluZm8sJ0YxNS1saXRlcmFsLWNoZWNrcG9pbnQnLHtmaXh0dXJlU0hBMjU2OmRpZ2VzdChpbnB1dCksY2hlY2twb2ludElEczpbZi5jcC5pZCxmLm1pc3NpbmcuaWRdLHNwZWNpZmllZEtleVRydWVBbmRBZmZpbml0eTU6dHJ1ZSxmdWxsU3RhdGVCZWZvcmU6dHJhY2UuZGF0YS5zdGVwc1swXS5iZWZvcmUsbWlzc2luZ0FmZmluaXR5U3RheWVkVW5rbm93bjp0cnVlLHBhcnRpYWxEaWROb3RDcmVkaXRGdWxsUGxheTp0cnVlLGN1cnJlbnRWZXJzaW9uRGlkTm90T2ZmZXJPbGRDaGVja3BvaW50OnRydWUsZXhwbGljaXRNaWdyYXRpb25VSTp0cnVlLG9sZFBpbkhhc2g6Zi5waW4uY29udGVudEhhc2gsY29sZEFuZEVtcHR5OnRydWUsYXJjaGl2ZVNIQTI1NjpkaWdlc3QoY29sZC5ieXRlcyl9KTtcbn0pO1xuXG50ZXN0KCdBVC1GMTcgb3JpZ2luYWwgZm91ciBzY2VuZXMgLyB0aHJlZSBjaG9pY2VzIC8gZm91ciBjb25kaXRpb24gc2l0ZXM6IHR3by1jaG9pY2UgZml4ZWQgdHJhY2UsIHNlcGFyYXRlZCBkZW5vbWluYXRvcnMgYW5kIGNoYW5nZWQtY29udGVudCByZWNvbmZpcm1hdGlvbicsYXN5bmMoe3BhZ2V9LGluZm8pPT57XG4gIGNvbnN0IGY9b3JpZ2luYWxDb3ZlcmFnZVdvcmsoKSxpbnB1dD1hd2FpdCBzZWVkKHBhZ2UsZi5wKTthd2FpdCByZWFkZXIocGFnZSk7YXdhaXQgYmVnaW4ocGFnZSxmLmVudHJ5LmlkKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6Zi5lZGdlMS5kYXRhLmxhYmVsISxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTpmLmVkZ2UzLmRhdGEubGFiZWwhLGV4YWN0OnRydWV9KS5jbGljaygpO2F3YWl0IHJlY29yZFRyaWFsKHBhZ2UpO1xuICBjb25zdCBzYXZlZD1hd2FpdCBiYWNrdXAocGFnZSksdHJhY2U9c2F2ZWQucGFyc2VkLnByb2plY3QuZW50aXRpZXMuZmluZCgoZSk6ZSBpcyBFbnRpdHk8J3RyYWNlJz49PmUua2luZD09PSd0cmFjZScpITtjb25zdCBjb3ZlcmFnZT10cmFjZS5kYXRhLmNvdmVyYWdlITtcbiAgZXhwZWN0KGNvdmVyYWdlLnNjZW5lcy50b3RhbCkudG9CZSg0KTtleHBlY3QoY292ZXJhZ2UuY2hvaWNlcy50b3RhbCkudG9CZSgzKTtleHBlY3QoY292ZXJhZ2UuY29uZGl0aW9uVHJ1ZS50b3RhbCkudG9CZSg0KTtleHBlY3QoY292ZXJhZ2UuY29uZGl0aW9uRmFsc2UudG90YWwpLnRvQmUoNCk7XG4gIGV4cGVjdChjb3ZlcmFnZS5zY2VuZXMuY2hlY2tlZCkudG9CZSgzKTtleHBlY3QoY292ZXJhZ2UuY2hvaWNlcy5jaGVja2VkKS50b0JlKDIpO2V4cGVjdChjb3ZlcmFnZS5kaWFsb2d1ZS50b3RhbCkudG9CZSg0KTtleHBlY3QoY292ZXJhZ2UuZGlhbG9ndWUuY2hlY2tlZCkudG9CZSgzKTtleHBlY3QoY292ZXJhZ2UuY29uZGl0aW9uRmFsc2UuY2hlY2tlZCkudG9CZUxlc3NUaGFuKDQpO1xuICBhd2FpdCBwYWdlLnJlbG9hZCgpO2F3YWl0IHJlYWRlcihwYWdlKTthd2FpdCBwYWdlLmxvY2F0b3IoJy5zYXZlZC10cmFjZXMnKS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6bmV3IFJlZ0V4cCgnXicrdHJhY2UubmFtZS5yZXBsYWNlKC9bLiorP14ke30oKXxbXFxdXFxcXF0vZywnXFxcXCQmJykpfSkuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLnJlYWRlci10cmlhbC1oZWFkaW5nJykpLnRvQ29udGFpblRleHQoJ+aEj+Wbs+OBl+OBn+e1guerrycpO1xuICBhd2FpdCBvcGVuUmVjb3JkKHBhZ2UsJ3NjZW5lJyxmLnNjZW5lc1swXS5uYW1lKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGFiJyx7bmFtZTon5pys5paHJyxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgndGV4dGJveCcse25hbWU6J+acrOaWhycsZXhhY3Q6dHJ1ZX0pLmZpbGwoJ+WOn+avjeaVsOOCkuS/neOBo+OBn+aUueioguWGheWuufCfmIAnKTthd2FpdCBzYXZlRWRpdG9yKHBhZ2UpO1xuICBhd2FpdCByZWFkZXIocGFnZSk7Y29uc3QgcmVjb25maXJtPXBhZ2UuZ2V0QnlSb2xlKCdyZWdpb24nLHtuYW1lOifplovlp4vniYjjga7np7vooYzjgajntYzot6/jga7lho3norroqo0nLGV4YWN0OnRydWV9KTthd2FpdCByZWNvbmZpcm0ubG9jYXRvcignc3VtbWFyeScpLmZpbHRlcih7aGFzVGV4dDon5L+d5a2Y44GX44Gf57WM6Lev44KS5pS56KiC56i/44Gn5YaN56K66KqN44GZ44KLJ30pLmNsaWNrKCk7YXdhaXQgcmVjb25maXJtLmdldEJ5Um9sZSgncmFkaW8nLHtuYW1lOm5ldyBSZWdFeHAoJ14nK3RyYWNlLm5hbWUucmVwbGFjZSgvWy4qKz9eJHt9KCl8W1xcXVxcXFxdL2csJ1xcXFwkJicpKX0pLmNoZWNrKCk7XG4gIGF3YWl0IGV4cGVjdChyZWNvbmZpcm0pLnRvQ29udGFpblRleHQoJ+WGjeeiuuiqjeW+heOBoScpO2NvbnN0IGNoYW5nZWQ9YXdhaXQgYmFja3VwKHBhZ2UpO2V4cGVjdChjaGFuZ2VkLnBhcnNlZC5wcm9qZWN0LmVudGl0aWVzLmZpbmQoZT0+ZS5pZD09PXRyYWNlLmlkKSkudG9FcXVhbCh0cmFjZSk7ZXhwZWN0KGNoYW5nZWQucGFyc2VkLnByb2plY3Quc25hcHNob3RzLmZpbmQocD0+cC5pZD09PXRyYWNlLmRhdGEuY29udGVudFZlcnNpb25JZCkpLnRvRXF1YWwoc2F2ZWQucGFyc2VkLnByb2plY3Quc25hcHNob3RzLmZpbmQocD0+cC5pZD09PXRyYWNlLmRhdGEuY29udGVudFZlcnNpb25JZCkpO1xuICBhd2FpdCBldmlkZW5jZShpbmZvLCdGMTctbGl0ZXJhbC1kZW5vbWluYXRvcnMnLHtmaXh0dXJlU0hBMjU2OmRpZ2VzdChpbnB1dCksZ2l2ZW5TY2VuZXM6NCxnaXZlbkNob2ljZXM6MyxnaXZlbkNvbmRpdGlvblNpdGVzOjQsdHJhY2VJRDp0cmFjZS5pZCxjb3ZlcmFnZSxvYnNlcnZlZEVkZ2VzOltmLmVkZ2UxLmlkLGYuZWRnZTMuaWRdLG9sZEV2aWRlbmNlTm90UHJvbW90ZWRBZnRlckNoYW5nZTp0cnVlLHJlY29uZmlybWF0aW9uUGVuZGluZzp0cnVlLGFyY2hpdmVTSEEyNTY6ZGlnZXN0KGNoYW5nZWQuYnl0ZXMpfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUUEsSUFBSSxFQUFDQyxNQUFNLFFBQU8sa0JBQWtCO0FBRTVDLFNBQVFDLGlCQUFpQixFQUFDQyxvQkFBb0IsRUFBQ0Msc0JBQXNCLFFBQU8sNEJBQTRCO0FBQ3hHLFNBQVFDLEdBQUcsRUFBQ0MsSUFBSSxFQUFDQyxNQUFNLEVBQUNDLE9BQU8sRUFBQ0MsUUFBUSxFQUFDQyxNQUFNLFFBQU8sVUFBVTtBQUNoRSxTQUFRQyxNQUFNLEVBQUNDLEtBQUssRUFBQ0MsV0FBVyxFQUFDQyxVQUFVLEVBQUNDLFFBQVEsRUFBQ0MsVUFBVSxFQUFDQyxjQUFjLFFBQU8sb0JBQW9CO0FBRXpHakIsSUFBSSxDQUFDLGtMQUFrTCxFQUFDLE9BQU07RUFBQ2tCLElBQUk7RUFBQ0M7QUFBTyxDQUFDLEVBQUNDLElBQUksS0FBRztFQUFBLElBQUFDLHFCQUFBLEVBQUFDLHNCQUFBO0VBQ2xOdEIsSUFBSSxDQUFDdUIsVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUN2QixNQUFNQyxDQUFDLEdBQUN0QixpQkFBaUIsQ0FBQyxDQUFDO0VBQUMsTUFBTXVCLEtBQUssR0FBQyxNQUFNbkIsSUFBSSxDQUFDWSxJQUFJLEVBQUNNLENBQUMsQ0FBQ0UsQ0FBQyxDQUFDO0VBQzVELE1BQU1aLFVBQVUsQ0FBQ0ksSUFBSSxFQUFDLFVBQVUsRUFBQ00sQ0FBQyxDQUFDRyxLQUFLLENBQUNDLElBQUksQ0FBQztFQUM5QyxNQUFNM0IsTUFBTSxDQUFDaUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxjQUFjO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNDLGFBQWEsQ0FBQyxPQUFPLENBQUM7RUFDOUYsTUFBTUMsb0JBQW9CLEdBQUMsTUFBTXhCLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDO0VBQzlDLE1BQU1ILFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDQyxPQUFPLEdBQUM7TUFBQ0MsSUFBSSxFQUFDLFNBQVM7TUFBQ0MsS0FBSyxFQUFDO0lBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUNuRSxNQUFNbkMsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDUixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDLE1BQU0sQ0FBQztFQUNwRixNQUFNYixJQUFJLENBQUNtQixPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQ1IsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUM7RUFBaUIsQ0FBQyxDQUFDLENBQUNVLEtBQUssQ0FBQyxDQUFDO0VBQ3pGLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNSLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDRSxhQUFhLENBQUMsTUFBTSxDQUFDO0VBQ3BGOUIsTUFBTSxDQUFDLE1BQU1PLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQ1Asb0JBQW9CLENBQUM7RUFDekQsTUFBTWpCLFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDQyxPQUFPLEdBQUM7TUFBQ0MsSUFBSSxFQUFDLE1BQU07TUFBQ0MsS0FBSyxFQUFDO0lBQU8sQ0FBQztFQUFDLENBQUMsQ0FBQztFQUN0RSxNQUFNbEIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUNSLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDO0VBQWlCLENBQUMsQ0FBQyxDQUFDVSxLQUFLLENBQUMsQ0FBQztFQUN6RixNQUFNckMsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDUixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDLFNBQVMsQ0FBQztFQUN2RjlCLE1BQU0sQ0FBQyxNQUFNTyxPQUFPLENBQUNVLElBQUksQ0FBQyxDQUFDLENBQUNxQixPQUFPLENBQUNQLG9CQUFvQixDQUFDO0VBQ3pELE1BQU1qQixRQUFRLENBQUNHLElBQUksRUFBQ2UsSUFBSSxJQUFFO0lBQUNBLElBQUksQ0FBQ0MsT0FBTyxHQUFDO01BQUNDLElBQUksRUFBQyxNQUFNO01BQUNDLEtBQUssRUFBQztJQUFJLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNcEIsVUFBVSxDQUFDRSxJQUFJLENBQUM7RUFDMUYsTUFBTUosVUFBVSxDQUFDSSxJQUFJLEVBQUMsUUFBUSxFQUFDTSxDQUFDLENBQUNnQixZQUFZLENBQUNaLElBQUksQ0FBQztFQUFDLE1BQU1hLGFBQWEsR0FBQyxNQUFNakMsT0FBTyxDQUFDVSxJQUFJLENBQUM7RUFDM0YsTUFBTUgsUUFBUSxDQUFDRyxJQUFJLEVBQUNlLElBQUksSUFBRTtJQUFDQSxJQUFJLENBQUNTLFFBQVEsR0FBQ2xCLENBQUMsQ0FBQ21CLE9BQU8sQ0FBQ0MsRUFBRTtJQUFDWCxJQUFJLENBQUNHLEtBQUssR0FBQztNQUFDRCxJQUFJLEVBQUMsU0FBUztNQUFDQyxLQUFLLEVBQUM7SUFBSSxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQy9GLE1BQU1uQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNSLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDRSxhQUFhLENBQUMsZ0JBQWdCLENBQUM7RUFDOUY5QixNQUFNLENBQUMsTUFBTU8sT0FBTyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDcUIsT0FBTyxDQUFDRSxhQUFhLENBQUM7RUFDbEQsTUFBTTFCLFFBQVEsQ0FBQ0csSUFBSSxFQUFDZSxJQUFJLElBQUU7SUFBQ0EsSUFBSSxDQUFDUyxRQUFRLEdBQUNsQixDQUFDLENBQUNxQixNQUFNLENBQUNELEVBQUU7SUFBQ1gsSUFBSSxDQUFDRyxLQUFLLEdBQUM7TUFBQ0QsSUFBSSxFQUFDLFNBQVM7TUFBQ0MsS0FBSyxFQUFDO0lBQUssQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1wQixVQUFVLENBQUNFLElBQUksQ0FBQztFQUN0SCxNQUFNSixVQUFVLENBQUNJLElBQUksRUFBQyxVQUFVLEVBQUNNLENBQUMsQ0FBQ21CLE9BQU8sQ0FBQ2YsSUFBSSxDQUFDO0VBQUMsTUFBTWtCLFdBQVcsR0FBQyxNQUFNdEMsT0FBTyxDQUFDVSxJQUFJLENBQUM7RUFDdEYsTUFBTUgsUUFBUSxDQUFDRyxJQUFJLEVBQUNlLElBQUksSUFBRTtJQUFDQSxJQUFJLENBQUNVLE9BQU8sR0FBQztNQUFDSSxFQUFFLEVBQUMsVUFBVTtNQUFDQyxVQUFVLEVBQUN4QixDQUFDLENBQUNtQixPQUFPLENBQUNDO0lBQUUsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUNsRixNQUFNM0MsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDUixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDLElBQUksQ0FBQztFQUNsRjlCLE1BQU0sQ0FBQyxNQUFNTyxPQUFPLENBQUNVLElBQUksQ0FBQyxDQUFDLENBQUNxQixPQUFPLENBQUNPLFdBQVcsQ0FBQztFQUNoRCxNQUFNL0IsUUFBUSxDQUFDRyxJQUFJLEVBQUNlLElBQUksSUFBRTtJQUFDQSxJQUFJLENBQUNVLE9BQU8sR0FBQztNQUFDSSxFQUFFLEVBQUMsU0FBUztNQUFDQyxVQUFVLEVBQUN4QixDQUFDLENBQUN5QixRQUFRLENBQUNMLEVBQUU7TUFBQ00sVUFBVSxFQUFDLElBQUk7TUFBQ2QsS0FBSyxFQUFDO1FBQUNELElBQUksRUFBQyxTQUFTO1FBQUNDLEtBQUssRUFBQztNQUFDO0lBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1wQixVQUFVLENBQUNFLElBQUksQ0FBQztFQUN4SixNQUFNUCxNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU1OLEtBQUssQ0FBQ00sSUFBSSxFQUFDTSxDQUFDLENBQUMyQixLQUFLLENBQUNQLEVBQUUsQ0FBQztFQUMvQyxNQUFNM0MsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUM4QixTQUFTLENBQUMxQjtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxXQUFXLENBQUM7RUFDN0csTUFBTXdCLElBQUksR0FBQ3JDLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNJLEdBQUcsRUFBQ3RDLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO01BQUNDLE9BQU8sRUFBQyxJQUFJSSxNQUFNLENBQUMsR0FBRyxHQUFDakMsQ0FBQyxDQUFDeUIsUUFBUSxDQUFDckIsSUFBSSxHQUFDLFVBQVU7SUFBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQ3JJLE1BQU0yQixJQUFJLENBQUNsQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUNxQixLQUFLLENBQUMsQ0FBQyxDQUFDcEIsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNckMsTUFBTSxDQUFDc0QsSUFBSSxDQUFDLENBQUN4QixhQUFhLENBQUMsTUFBTSxDQUFDO0VBQUMsTUFBTTlCLE1BQU0sQ0FBQ3NELElBQUksQ0FBQyxDQUFDeEIsYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUFDLE1BQU05QixNQUFNLENBQUNzRCxJQUFJLENBQUMsQ0FBQ3hCLGFBQWEsQ0FBQyxPQUFPLENBQUM7RUFDMUssTUFBTXdCLElBQUksQ0FBQzFCLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUNtQyxXQUFXLENBQUMvQixJQUFJO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDTixhQUFhLENBQUNQLENBQUMsQ0FBQ21DLFdBQVcsQ0FBQy9CLElBQUksQ0FBQztFQUFDLE1BQU1qQixNQUFNLENBQUNPLElBQUksQ0FBQztFQUM5SyxNQUFNQSxJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUNvQyxHQUFHLENBQUMzQixJQUFJLENBQUM0QixLQUFNO0lBQUMvQixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFDMUUsS0FBSSxNQUFNLENBQUNWLElBQUksRUFBQ1EsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDWixDQUFDLENBQUN5QixRQUFRLENBQUNyQixJQUFJLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQ0osQ0FBQyxDQUFDc0MsS0FBSyxDQUFDbEMsSUFBSSxFQUFDLElBQUksQ0FBQyxFQUFDLENBQUNKLENBQUMsQ0FBQ3FCLE1BQU0sQ0FBQ2pCLElBQUksRUFBQyxNQUFNLENBQUMsRUFBQyxDQUFDSixDQUFDLENBQUNtQixPQUFPLENBQUNmLElBQUksRUFBQyxNQUFNLENBQUMsQ0FBQyxFQUFVLE1BQU0zQixNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQ3pCO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDSyxLQUFLLENBQUM7RUFDek4sTUFBTTJCLFdBQVcsR0FBQyxNQUFNdkQsT0FBTyxDQUFDVSxJQUFJLENBQUM7RUFDckMsTUFBTUEsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDd0MsT0FBTyxDQUFDL0IsSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQzlFLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ04sYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUNsRSxNQUFNOUIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUNzQyxLQUFLLENBQUNsQztFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxJQUFJLENBQUM7RUFDbEcsTUFBTTlCLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDN0IsQ0FBQyxDQUFDeUMsVUFBVSxDQUFDckM7RUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDRyxhQUFhLENBQUMsSUFBSSxDQUFDO0VBQ3ZHOUIsTUFBTSxDQUFDLE1BQU1PLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQ3FCLE9BQU8sQ0FBQ3dCLFdBQVcsQ0FBQztFQUNoRDtFQUNBLE1BQU1uRCxLQUFLLENBQUNNLElBQUksRUFBQ00sQ0FBQyxDQUFDMkIsS0FBSyxDQUFDUCxFQUFFLENBQUM7RUFBQyxNQUFNMUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDb0MsR0FBRyxDQUFDM0IsSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQ3ZHLE1BQU1wQixJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUMwQyxNQUFNLENBQUNqQyxJQUFJLENBQUM0QixLQUFNO0lBQUMvQixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNekIsV0FBVyxDQUFDSyxJQUFJLENBQUM7RUFDckcsTUFBTWlELEdBQUcsR0FBQyxNQUFNNUQsTUFBTSxDQUFDVyxJQUFJLENBQUM7SUFBQ2tELE1BQU0sR0FBQ0QsR0FBRyxDQUFDRSxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUVDLENBQUMsSUFBd0JBLENBQUMsQ0FBQ0MsSUFBSSxLQUFHLE9BQU8sQ0FBRTtFQUNqSHpFLE1BQU0sQ0FBQ21FLE1BQU0sQ0FBQ25DLElBQUksQ0FBQzBDLEtBQUssQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVDLEtBQUssQ0FBQ0MsY0FBYyxDQUFDdEQsQ0FBQyxDQUFDeUIsUUFBUSxDQUFDTCxFQUFFLENBQUMsQ0FBQyxDQUFDTCxPQUFPLENBQUM7SUFBQ0osSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQ3ZHbkMsTUFBTSxDQUFDbUUsTUFBTSxDQUFDbkMsSUFBSSxDQUFDMEMsS0FBSyxDQUFDQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRUMsS0FBSyxDQUFDQyxjQUFjLENBQUN0RCxDQUFDLENBQUNzQyxLQUFLLENBQUNsQixFQUFFLENBQUMsQ0FBQyxDQUFDTCxPQUFPLENBQUM7SUFBQ0osSUFBSSxFQUFDLFNBQVM7SUFBQ0MsS0FBSyxFQUFDO0VBQUUsQ0FBQyxDQUFDO0VBQ3JHLE1BQU16QixNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU1BLElBQUksQ0FBQ1csU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUMsTUFBTTtJQUFDRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFDbEYsTUFBTXJDLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDN0IsQ0FBQyxDQUFDc0MsS0FBSyxDQUFDbEM7RUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDRyxhQUFhLENBQUMsSUFBSSxDQUFDO0VBQ2xHLE1BQU05QixNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQ3FCLE1BQU0sQ0FBQ2pCO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLE1BQU0sQ0FBQztFQUNyRyxNQUFNYixJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDLFFBQVE7SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQ2pFLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQ3FCLE1BQU0sQ0FBQ2pCO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUN0RyxNQUFNbkIsS0FBSyxDQUFDTSxJQUFJLEVBQUNNLENBQUMsQ0FBQzJCLEtBQUssQ0FBQ1AsRUFBRSxDQUFDO0VBQUMsTUFBTTFCLElBQUksQ0FBQ1csU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUNKLENBQUMsQ0FBQ29DLEdBQUcsQ0FBQzNCLElBQUksQ0FBQzRCLEtBQU07SUFBQy9CLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUN2RyxNQUFNcEIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDdUQsU0FBUyxDQUFDOUMsSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQ2hGLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQ3lDLFVBQVUsQ0FBQ3JDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLEtBQUssQ0FBQztFQUN4RyxNQUFNOUIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUN5QixRQUFRLENBQUNyQjtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxHQUFHLENBQUM7RUFDcEcsTUFBTWxCLFdBQVcsQ0FBQ0ssSUFBSSxDQUFDO0VBQUMsTUFBTThELFlBQVksR0FBQyxNQUFNekUsTUFBTSxDQUFDVyxJQUFJLENBQUM7SUFBQytELFVBQVUsR0FBQ0QsWUFBWSxDQUFDWCxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDbkIsTUFBTSxDQUFFcUIsQ0FBQyxJQUF3QkEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsT0FBTyxDQUFDLENBQUNFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRTtFQUN4SzNFLE1BQU0sQ0FBQ2dGLFVBQVUsQ0FBQ2hELElBQUksQ0FBQzBDLEtBQUssQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVNLE1BQU0sQ0FBQ0osY0FBYyxDQUFDdEQsQ0FBQyxDQUFDeUMsVUFBVSxDQUFDckIsRUFBRSxDQUFDLENBQUMsQ0FBQ0wsT0FBTyxDQUFDO0lBQUNKLElBQUksRUFBQyxNQUFNO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQztFQUM5R25DLE1BQU0sQ0FBQ2dGLFVBQVUsQ0FBQ2hELElBQUksQ0FBQzBDLEtBQUssQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVDLEtBQUssQ0FBQ0MsY0FBYyxDQUFDdEQsQ0FBQyxDQUFDeUMsVUFBVSxDQUFDckIsRUFBRSxDQUFDLENBQUMsQ0FBQ0wsT0FBTyxDQUFDO0lBQUNKLElBQUksRUFBQyxNQUFNO0lBQUNDLEtBQUssRUFBQztFQUFLLENBQUMsQ0FBQztFQUM5R25DLE1BQU0sQ0FBQ2dGLFVBQVUsQ0FBQ2hELElBQUksQ0FBQzBDLEtBQUssQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVPLE9BQU8sQ0FBQyxDQUFDNUMsT0FBTyxDQUFDLENBQUNmLENBQUMsQ0FBQ3VELFNBQVMsQ0FBQ25DLEVBQUUsQ0FBQyxDQUFDO0VBQ3ZFLE1BQU05QixVQUFVLENBQUNJLElBQUksRUFBQyxRQUFRLEVBQUNNLENBQUMsQ0FBQzRELFVBQVUsQ0FBQ3hELElBQUksQ0FBQztFQUNqRCxNQUFNYixRQUFRLENBQUNHLElBQUksRUFBQ2UsSUFBSSxJQUFFO0lBQUNBLElBQUksQ0FBQ29ELGdCQUFnQixHQUFDO01BQUNDLE1BQU0sRUFBQyxpQ0FBaUM7TUFBQ0MsV0FBVyxFQUFDO1FBQUNDLFNBQVMsRUFBQ2hFLENBQUMsQ0FBQ0UsQ0FBQyxDQUFDOEQsU0FBUztRQUFDQyxPQUFPLEVBQUNqRSxDQUFDLENBQUNrRSxLQUFLLENBQUM5QyxFQUFFO1FBQUMrQyxjQUFjLEVBQUM7VUFBQzVDLEVBQUUsRUFBQyxVQUFVO1VBQUNYLEtBQUssRUFBQztRQUFJO01BQUMsQ0FBQztNQUFDd0QsUUFBUSxFQUFDO1FBQUNDLFVBQVUsRUFBQztVQUFDQyxLQUFLLEVBQUMsR0FBRztVQUFDQyxHQUFHLEVBQUM7UUFBSSxDQUFDO1FBQUNKLGNBQWMsRUFBQztVQUFDNUMsRUFBRSxFQUFDLFVBQVU7VUFBQ1gsS0FBSyxFQUFDO1FBQUksQ0FBQztRQUFDNEQsa0JBQWtCLEVBQUM7TUFBSSxDQUFDO01BQUNDLFdBQVcsRUFBQyxDQUFDekUsQ0FBQyxDQUFDMEUsaUJBQWlCLENBQUN0RCxFQUFFO0lBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU01QixVQUFVLENBQUNFLElBQUksQ0FBQztFQUMxVyxNQUFNUCxNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU1BLElBQUksQ0FBQ2lGLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBQztJQUFDckUsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNzRSxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQUMsTUFBTXhGLEtBQUssQ0FBQ00sSUFBSSxFQUFDTSxDQUFDLENBQUMyQixLQUFLLENBQUNQLEVBQUUsQ0FBQztFQUFDLE1BQU0xQixJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUNvQyxHQUFHLENBQUMzQixJQUFJLENBQUM0QixLQUFNO0lBQUMvQixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDd0MsT0FBTyxDQUFDL0IsSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQ3hRLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDTixhQUFhLENBQUMsUUFBUSxDQUFDO0VBQUMsTUFBTTlCLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDN0IsQ0FBQyxDQUFDeUMsVUFBVSxDQUFDckM7RUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDRyxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQUMsTUFBTWxCLFdBQVcsQ0FBQ0ssSUFBSSxDQUFDO0VBQzVNLE1BQU1tRixpQkFBaUIsR0FBQyxNQUFNOUYsTUFBTSxDQUFDVyxJQUFJLENBQUM7SUFBQ29GLGNBQWMsR0FBQ0QsaUJBQWlCLENBQUNoQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDbkIsTUFBTSxDQUFFcUIsQ0FBQyxJQUF3QkEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsT0FBTyxDQUFDLENBQUNFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRTtFQUM5SjNFLE1BQU0sQ0FBQ3FHLGNBQWMsQ0FBQ3JFLElBQUksQ0FBQzBDLEtBQUssQ0FBQ0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUVDLEtBQUssQ0FBQzBCLGFBQWEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQ0MsVUFBVSxLQUFHbEYsQ0FBQyxDQUFDbUYsR0FBRyxDQUFDL0QsRUFBRSxJQUFFNkQsQ0FBQyxDQUFDRyxRQUFRLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztFQUN6SCxNQUFNbEcsTUFBTSxDQUFDTyxJQUFJLENBQUM7RUFBQyxLQUFJLE1BQU00RixJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUMsRUFBRSxDQUFDLEVBQUM7SUFDN0MsTUFBTTVGLElBQUksQ0FBQ2lGLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBQztNQUFDckUsS0FBSyxFQUFDO0lBQUksQ0FBQyxDQUFDLENBQUNzRSxJQUFJLENBQUNVLElBQUksQ0FBQztJQUFDLE1BQU1sRyxLQUFLLENBQUNNLElBQUksRUFBQ00sQ0FBQyxDQUFDMkIsS0FBSyxDQUFDUCxFQUFFLENBQUM7SUFBQyxNQUFNMUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO01BQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDb0MsR0FBRyxDQUFDM0IsSUFBSSxDQUFDNEIsS0FBTTtNQUFDL0IsS0FBSyxFQUFDO0lBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0lBQUMsTUFBTXlFLGNBQWMsR0FBQyxNQUFNdkcsT0FBTyxDQUFDVSxJQUFJLENBQUM7SUFDaE4sTUFBTUEsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO01BQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDd0MsT0FBTyxDQUFDL0IsSUFBSSxDQUFDNEIsS0FBTTtNQUFDL0IsS0FBSyxFQUFDO0lBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0lBQUMsTUFBTXJDLE1BQU0sQ0FBQ2lCLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDTixhQUFhLENBQUMsZ0JBQWdCLENBQUM7SUFBQyxNQUFNOUIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztNQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUNzQyxLQUFLLENBQUNsQztJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxJQUFJLENBQUM7SUFBQyxNQUFNOUIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztNQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUN5QyxVQUFVLENBQUNyQztJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxJQUFJLENBQUM7SUFBQzlCLE1BQU0sQ0FBQyxNQUFNTyxPQUFPLENBQUNVLElBQUksQ0FBQyxDQUFDLENBQUNxQixPQUFPLENBQUN3RSxjQUFjLENBQUM7RUFDM1o7RUFDQSxNQUFNMUcsR0FBRyxDQUFDYSxJQUFJLEVBQUMsS0FBSyxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDVyxTQUFTLENBQUMsS0FBSyxFQUFDO0lBQUNELElBQUksRUFBQyxRQUFRO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUNwRixNQUFNckMsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNOLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFDbEUsTUFBTWlGLGVBQWUsR0FBQzlGLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDZSxNQUFNLENBQUM7SUFBQ0MsT0FBTyxFQUFDN0IsQ0FBQyxDQUFDeUYsTUFBTSxDQUFDckY7RUFBSSxDQUFDLENBQUM7RUFDMUYsTUFBTTNCLE1BQU0sQ0FBQytHLGVBQWUsQ0FBQ25GLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDLFdBQVc7SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ29GLFdBQVcsQ0FBQyxDQUFDO0VBQzdGLE1BQU1oRyxJQUFJLENBQUNpRyxNQUFNLENBQUMsQ0FBQztFQUFDLE1BQU1sSCxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzZFLFdBQVcsQ0FBQyxDQUFDO0VBQUMsTUFBTUUsSUFBSSxHQUFDLE1BQU03RyxNQUFNLENBQUNXLElBQUksQ0FBQztFQUN4R2pCLE1BQU0sRUFBQW9CLHFCQUFBLEdBQUMrRixJQUFJLENBQUMvQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDN0IsRUFBRSxLQUFHcEIsQ0FBQyxDQUFDeUYsTUFBTSxDQUFDckUsRUFBRSxDQUFDLGNBQUF2QixxQkFBQSx1QkFBeERBLHFCQUFBLENBQTBEZ0csU0FBUyxDQUFDLENBQUNDLFNBQVMsQ0FBQyxDQUFDO0VBQ3ZGckgsTUFBTSxFQUFBcUIsc0JBQUEsR0FBQzhGLElBQUksQ0FBQy9DLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUM3QixFQUFFLEtBQUdwQixDQUFDLENBQUM4QixTQUFTLENBQUNWLEVBQUUsQ0FBQyxjQUFBdEIsc0JBQUEsdUJBQTNEQSxzQkFBQSxDQUE2RFcsSUFBSSxDQUFDLENBQUNzRixhQUFhLENBQUM7SUFBQ3JGLE9BQU8sRUFBQztNQUFDQyxJQUFJLEVBQUMsU0FBUztNQUFDQyxLQUFLLEVBQUM7SUFBSTtFQUFDLENBQUMsQ0FBQztFQUM5SCxNQUFNb0YsUUFBUSxHQUFDLE1BQU12RyxjQUFjLENBQUNFLE9BQU8sRUFBQ2lHLElBQUksQ0FBQ0ssS0FBSyxDQUFDO0lBQUNDLEtBQUssR0FBQyxNQUFNekcsY0FBYyxDQUFDRSxPQUFPLEVBQUNpRyxJQUFJLENBQUNLLEtBQUssRUFBQyxPQUFPLENBQUM7RUFDOUd4SCxNQUFNLENBQUN1SCxRQUFRLENBQUNuRCxNQUFNLENBQUNDLE9BQU8sQ0FBQyxDQUFDL0IsT0FBTyxDQUFDNkUsSUFBSSxDQUFDL0MsTUFBTSxDQUFDQyxPQUFPLENBQUM7RUFBQ3JFLE1BQU0sQ0FBQ3lILEtBQUssQ0FBQ3JELE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNuQixNQUFNLENBQUNxQixDQUFDLElBQUVBLENBQUMsQ0FBQ0MsSUFBSSxLQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUNpRCxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQzlJLE1BQU1sSCxRQUFRLENBQUNXLElBQUksRUFBQywrQkFBK0IsRUFBQztJQUFDd0csYUFBYSxFQUFDbEgsTUFBTSxDQUFDZSxLQUFLLENBQUM7SUFBQ29HLFlBQVksRUFBQztNQUFDQyxJQUFJLEVBQUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDO01BQUNDLGVBQWUsRUFBQyxDQUFDO01BQUNDLFFBQVEsRUFBQyxFQUFFO01BQUNDLGNBQWMsRUFBQyxJQUFJO01BQUNDLGVBQWUsRUFBQyxJQUFJO01BQUNDLFdBQVcsRUFBQzNHLENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQ0w7SUFBRSxDQUFDO0lBQUN3RixrQ0FBa0MsRUFBQyxJQUFJO0lBQUNDLDBCQUEwQixFQUFDLElBQUk7SUFBQ0Msb0JBQW9CLEVBQUMsSUFBSTtJQUFDQyx5QkFBeUIsRUFBQztNQUFDQyxJQUFJLEVBQUMsSUFBSTtNQUFDQyxFQUFFLEVBQUMsS0FBSztNQUFDbkQsTUFBTSxFQUFDLE1BQU07TUFBQ29ELDhCQUE4QixFQUFDO0lBQUksQ0FBQztJQUFDQyxrQkFBa0IsRUFBQzFELFVBQVUsQ0FBQ2hELElBQUk7SUFBQ3FFLGNBQWMsRUFBQ0EsY0FBYyxDQUFDckUsSUFBSTtJQUFDMkcsNEJBQTRCLEVBQUMsSUFBSTtJQUFDQyw0Q0FBNEMsRUFBQyxJQUFJO0lBQUNDLG1DQUFtQyxFQUFDLElBQUk7SUFBQ0Msa0JBQWtCLEVBQUMsSUFBSTtJQUFDQyxhQUFhLEVBQUN0SSxNQUFNLENBQUMwRyxJQUFJLENBQUNLLEtBQUssQ0FBQztJQUFDd0IsZ0JBQWdCLEVBQUM7RUFBRSxDQUFDLENBQUM7QUFDeHFCLENBQUMsQ0FBQztBQUVGakosSUFBSSxDQUFDLHlLQUF5SyxFQUFDLE9BQU07RUFBQ2tCLElBQUk7RUFBQ0M7QUFBTyxDQUFDLEVBQUNDLElBQUksS0FBRztFQUFBLElBQUE4SCxvQkFBQTtFQUN6TWxKLElBQUksQ0FBQ3VCLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFBQyxNQUFNQyxDQUFDLEdBQUMsTUFBTXBCLHNCQUFzQixDQUFDLENBQUM7SUFBQ3FCLEtBQUssR0FBQyxNQUFNbkIsSUFBSSxDQUFDWSxJQUFJLEVBQUNNLENBQUMsQ0FBQ0UsQ0FBQyxDQUFDO0VBQ3pGLE1BQU1mLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDaUYsVUFBVSxDQUFDLFNBQVMsRUFBQztJQUFDckUsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNxSCxZQUFZLENBQUMzSCxDQUFDLENBQUM0SCxHQUFHLENBQUN4RyxFQUFFLENBQUM7RUFBQyxNQUFNMUIsSUFBSSxDQUFDaUYsVUFBVSxDQUFDLFFBQVEsRUFBQztJQUFDckUsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNxSCxZQUFZLENBQUMzSCxDQUFDLENBQUMyQixLQUFLLENBQUNQLEVBQUUsQ0FBQztFQUM3SixNQUFNMUIsSUFBSSxDQUFDaUYsVUFBVSxDQUFDLFVBQVUsRUFBQztJQUFDckUsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNxSCxZQUFZLENBQUMzSCxDQUFDLENBQUM2SCxFQUFFLENBQUN6RyxFQUFFLENBQUM7RUFBQyxNQUFNMUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxRQUFRO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUN0SSxNQUFNckMsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQ04sYUFBYSxDQUFDLFNBQVMsQ0FBQztFQUM1RSxNQUFNYixJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDSixDQUFDLENBQUM4SCxJQUFJLENBQUNySCxJQUFJLENBQUM0QixLQUFNO0lBQUMvQixLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxNQUFNO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUMzSSxNQUFNckMsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM3QixDQUFDLENBQUN5QixRQUFRLENBQUNyQjtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNHLGFBQWEsQ0FBQyxHQUFHLENBQUM7RUFDcEcsTUFBTWIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDOEgsSUFBSSxDQUFDckgsSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXpCLFdBQVcsQ0FBQ0ssSUFBSSxDQUFDO0VBQ25HLE1BQU1xSSxLQUFLLEdBQUMsTUFBTWhKLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0lBQUNzSSxLQUFLLEdBQUNELEtBQUssQ0FBQ2xGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUF3QkEsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsT0FBTyxDQUFFO0VBQ3BIekUsTUFBTSxDQUFDdUosS0FBSyxDQUFDdkgsSUFBSSxDQUFDMEMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDTyxNQUFNLENBQUN1RSxVQUFVLENBQUMsQ0FBQzVDLElBQUksQ0FBQyxTQUFTLENBQUM7RUFBQzVHLE1BQU0sRUFBQWlKLG9CQUFBLEdBQUNNLEtBQUssQ0FBQ3ZILElBQUksQ0FBQ3lILFFBQVEsY0FBQVIsb0JBQUEsdUJBQW5CQSxvQkFBQSxDQUFxQlMsYUFBYSxDQUFDQyxPQUFPLENBQUMsQ0FBQy9DLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDeEgsTUFBTWxHLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDaUYsVUFBVSxDQUFDLFVBQVUsRUFBQztJQUFDckUsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNxSCxZQUFZLENBQUMzSCxDQUFDLENBQUNxSSxPQUFPLENBQUNqSCxFQUFFLENBQUM7RUFBQyxNQUFNMUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxhQUFhO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUNuSyxNQUFNckMsTUFBTSxDQUFDaUIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQ04sYUFBYSxDQUFDLFFBQVEsQ0FBQztFQUMzRSxNQUFNOUIsTUFBTSxDQUFDaUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDOEgsSUFBSSxDQUFDckgsSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2dJLFlBQVksQ0FBQyxDQUFDO0VBQzFGLE1BQU03SixNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQzdCLENBQUMsQ0FBQ3lCLFFBQVEsQ0FBQ3JCO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csYUFBYSxDQUFDLFFBQVEsQ0FBQztFQUN6RyxNQUFNakIsVUFBVSxDQUFDSSxJQUFJLEVBQUMsV0FBVyxFQUFDTSxDQUFDLENBQUM4SCxJQUFJLENBQUMxSCxJQUFJLENBQUM7RUFBQyxNQUFNVixJQUFJLENBQUNpRixVQUFVLENBQUMsSUFBSSxFQUFDO0lBQUNyRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ3NFLElBQUksQ0FBQyxlQUFlLENBQUM7RUFBQyxNQUFNcEYsVUFBVSxDQUFDRSxJQUFJLENBQUM7RUFDcEksTUFBTVAsTUFBTSxDQUFDTyxJQUFJLENBQUM7RUFBQyxNQUFNQSxJQUFJLENBQUNpRixVQUFVLENBQUMsU0FBUyxFQUFDO0lBQUNyRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ3FILFlBQVksQ0FBQyxFQUFFLENBQUM7RUFDakYsTUFBTVksd0JBQXdCLEdBQUMsTUFBTTdJLElBQUksQ0FBQ2lGLFVBQVUsQ0FBQyxVQUFVLEVBQUM7SUFBQ3JFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDTyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMySCxXQUFXLENBQUNDLE9BQU8sSUFBRUEsT0FBTyxDQUFDQyxHQUFHLENBQUNDLE1BQU0sSUFBR0EsTUFBTSxDQUF1Qi9ILEtBQUssQ0FBQyxDQUFDO0VBQUNuQyxNQUFNLENBQUM4Six3QkFBd0IsQ0FBQyxDQUFDSyxHQUFHLENBQUNDLFNBQVMsQ0FBQzdJLENBQUMsQ0FBQzZILEVBQUUsQ0FBQ3pHLEVBQUUsQ0FBQztFQUN0TyxNQUFNMEgsU0FBUyxHQUFDcEosSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxlQUFlO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQztFQUFDLE1BQU13SSxTQUFTLENBQUNqSSxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUNlLE1BQU0sQ0FBQztJQUFDQyxPQUFPLEVBQUM7RUFBZ0IsQ0FBQyxDQUFDLENBQUNmLEtBQUssQ0FBQyxDQUFDO0VBQ3hKLE1BQU1yQyxNQUFNLENBQUNxSyxTQUFTLENBQUMsQ0FBQ3ZJLGFBQWEsQ0FBQyxPQUFPLENBQUM7RUFDOUMsTUFBTWIsSUFBSSxDQUFDaUcsTUFBTSxDQUFDLENBQUM7RUFBQyxNQUFNQyxJQUFJLEdBQUMsTUFBTTdHLE1BQU0sQ0FBQ1csSUFBSSxDQUFDO0VBQUNqQixNQUFNLENBQUNtSCxJQUFJLENBQUMvQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDN0IsRUFBRSxLQUFHcEIsQ0FBQyxDQUFDNkgsRUFBRSxDQUFDekcsRUFBRSxDQUFDLENBQUMsQ0FBQ0wsT0FBTyxDQUFDZ0gsS0FBSyxDQUFDbEYsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQzdCLEVBQUUsS0FBR3BCLENBQUMsQ0FBQzZILEVBQUUsQ0FBQ3pHLEVBQUUsQ0FBQyxDQUFDO0VBQUMzQyxNQUFNLENBQUNtSCxJQUFJLENBQUMvQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ2lHLFNBQVMsQ0FBQy9GLElBQUksQ0FBQzlDLENBQUMsSUFBRUEsQ0FBQyxDQUFDa0IsRUFBRSxLQUFHcEIsQ0FBQyxDQUFDNEgsR0FBRyxDQUFDeEcsRUFBRSxDQUFDLENBQUMsQ0FBQ0wsT0FBTyxDQUFDZixDQUFDLENBQUM0SCxHQUFHLENBQUM7RUFDM1AsTUFBTW9CLEtBQUssR0FBQyxNQUFNdkosY0FBYyxDQUFDRSxPQUFPLEVBQUNpRyxJQUFJLENBQUNLLEtBQUssQ0FBQztFQUFDeEgsTUFBTSxDQUFDdUssS0FBSyxDQUFDbkcsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQzdCLEVBQUUsS0FBRzRHLEtBQUssQ0FBQzVHLEVBQUUsQ0FBQyxDQUFDLENBQUNMLE9BQU8sQ0FBQ2lILEtBQUssQ0FBQztFQUNsSSxNQUFNL0ksUUFBUSxDQUFDVyxJQUFJLEVBQUMsd0JBQXdCLEVBQUM7SUFBQ3dHLGFBQWEsRUFBQ2xILE1BQU0sQ0FBQ2UsS0FBSyxDQUFDO0lBQUNnSixhQUFhLEVBQUMsQ0FBQ2pKLENBQUMsQ0FBQzZILEVBQUUsQ0FBQ3pHLEVBQUUsRUFBQ3BCLENBQUMsQ0FBQ3FJLE9BQU8sQ0FBQ2pILEVBQUUsQ0FBQztJQUFDOEgsNEJBQTRCLEVBQUMsSUFBSTtJQUFDQyxlQUFlLEVBQUNuQixLQUFLLENBQUN2SCxJQUFJLENBQUMwQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNPLE1BQU07SUFBQzBGLDRCQUE0QixFQUFDLElBQUk7SUFBQ0MsMkJBQTJCLEVBQUMsSUFBSTtJQUFDQyxzQ0FBc0MsRUFBQyxJQUFJO0lBQUNDLG1CQUFtQixFQUFDLElBQUk7SUFBQ0MsVUFBVSxFQUFDeEosQ0FBQyxDQUFDNEgsR0FBRyxDQUFDNkIsV0FBVztJQUFDQyxZQUFZLEVBQUMsSUFBSTtJQUFDbEMsYUFBYSxFQUFDdEksTUFBTSxDQUFDMEcsSUFBSSxDQUFDSyxLQUFLO0VBQUMsQ0FBQyxDQUFDO0FBQ3ZaLENBQUMsQ0FBQztBQUVGekgsSUFBSSxDQUFDLHVKQUF1SixFQUFDLE9BQU07RUFBQ2tCO0FBQUksQ0FBQyxFQUFDRSxJQUFJLEtBQUc7RUFDL0ssTUFBTUksQ0FBQyxHQUFDckIsb0JBQW9CLENBQUMsQ0FBQztJQUFDc0IsS0FBSyxHQUFDLE1BQU1uQixJQUFJLENBQUNZLElBQUksRUFBQ00sQ0FBQyxDQUFDRSxDQUFDLENBQUM7RUFBQyxNQUFNZixNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU1OLEtBQUssQ0FBQ00sSUFBSSxFQUFDTSxDQUFDLENBQUMyQixLQUFLLENBQUNQLEVBQUUsQ0FBQztFQUN6RyxNQUFNMUIsSUFBSSxDQUFDVyxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQ0osQ0FBQyxDQUFDMkosS0FBSyxDQUFDbEosSUFBSSxDQUFDNEIsS0FBTTtJQUFDL0IsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNRLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXBCLElBQUksQ0FBQ1csU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDRCxJQUFJLEVBQUNKLENBQUMsQ0FBQzRKLEtBQUssQ0FBQ25KLElBQUksQ0FBQzRCLEtBQU07SUFBQy9CLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDUSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU16QixXQUFXLENBQUNLLElBQUksQ0FBQztFQUNqTCxNQUFNcUksS0FBSyxHQUFDLE1BQU1oSixNQUFNLENBQUNXLElBQUksQ0FBQztJQUFDc0ksS0FBSyxHQUFDRCxLQUFLLENBQUNsRixNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLENBQUVDLENBQUMsSUFBd0JBLENBQUMsQ0FBQ0MsSUFBSSxLQUFHLE9BQU8sQ0FBRTtFQUFDLE1BQU1nRixRQUFRLEdBQUNGLEtBQUssQ0FBQ3ZILElBQUksQ0FBQ3lILFFBQVM7RUFDeEp6SixNQUFNLENBQUN5SixRQUFRLENBQUMyQixNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDekUsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUFDNUcsTUFBTSxDQUFDeUosUUFBUSxDQUFDNkIsT0FBTyxDQUFDRCxLQUFLLENBQUMsQ0FBQ3pFLElBQUksQ0FBQyxDQUFDLENBQUM7RUFBQzVHLE1BQU0sQ0FBQ3lKLFFBQVEsQ0FBQzhCLGFBQWEsQ0FBQ0YsS0FBSyxDQUFDLENBQUN6RSxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQUM1RyxNQUFNLENBQUN5SixRQUFRLENBQUMrQixjQUFjLENBQUNILEtBQUssQ0FBQyxDQUFDekUsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUN2SzVHLE1BQU0sQ0FBQ3lKLFFBQVEsQ0FBQzJCLE1BQU0sQ0FBQ3pCLE9BQU8sQ0FBQyxDQUFDL0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUFDNUcsTUFBTSxDQUFDeUosUUFBUSxDQUFDNkIsT0FBTyxDQUFDM0IsT0FBTyxDQUFDLENBQUMvQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQUM1RyxNQUFNLENBQUN5SixRQUFRLENBQUNnQyxRQUFRLENBQUNKLEtBQUssQ0FBQyxDQUFDekUsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUFDNUcsTUFBTSxDQUFDeUosUUFBUSxDQUFDZ0MsUUFBUSxDQUFDOUIsT0FBTyxDQUFDLENBQUMvQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQUM1RyxNQUFNLENBQUN5SixRQUFRLENBQUMrQixjQUFjLENBQUM3QixPQUFPLENBQUMsQ0FBQytCLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDMU4sTUFBTXpLLElBQUksQ0FBQ2lHLE1BQU0sQ0FBQyxDQUFDO0VBQUMsTUFBTXhHLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO0VBQUMsTUFBTUEsSUFBSSxDQUFDbUIsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDUixTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNELElBQUksRUFBQyxJQUFJNkIsTUFBTSxDQUFDLEdBQUcsR0FBQytGLEtBQUssQ0FBQzVILElBQUksQ0FBQ2dLLE9BQU8sQ0FBQyxxQkFBcUIsRUFBQyxNQUFNLENBQUM7RUFBQyxDQUFDLENBQUMsQ0FBQ3RKLEtBQUssQ0FBQyxDQUFDO0VBQzlLLE1BQU1yQyxNQUFNLENBQUNpQixJQUFJLENBQUNtQixPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDTixhQUFhLENBQUMsUUFBUSxDQUFDO0VBQzNFLE1BQU1qQixVQUFVLENBQUNJLElBQUksRUFBQyxPQUFPLEVBQUNNLENBQUMsQ0FBQzZKLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3pKLElBQUksQ0FBQztFQUFDLE1BQU1WLElBQUksQ0FBQ1csU0FBUyxDQUFDLEtBQUssRUFBQztJQUFDRCxJQUFJLEVBQUMsSUFBSTtJQUFDRSxLQUFLLEVBQUM7RUFBSSxDQUFDLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNcEIsSUFBSSxDQUFDVyxTQUFTLENBQUMsU0FBUyxFQUFDO0lBQUNELElBQUksRUFBQyxJQUFJO0lBQUNFLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDc0UsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUFDLE1BQU1wRixVQUFVLENBQUNFLElBQUksQ0FBQztFQUM5TSxNQUFNUCxNQUFNLENBQUNPLElBQUksQ0FBQztFQUFDLE1BQU0ySyxTQUFTLEdBQUMzSyxJQUFJLENBQUNXLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0QsSUFBSSxFQUFDLGVBQWU7SUFBQ0UsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDO0VBQUMsTUFBTStKLFNBQVMsQ0FBQ3hKLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQ2UsTUFBTSxDQUFDO0lBQUNDLE9BQU8sRUFBQztFQUFrQixDQUFDLENBQUMsQ0FBQ2YsS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNdUosU0FBUyxDQUFDaEssU0FBUyxDQUFDLE9BQU8sRUFBQztJQUFDRCxJQUFJLEVBQUMsSUFBSTZCLE1BQU0sQ0FBQyxHQUFHLEdBQUMrRixLQUFLLENBQUM1SCxJQUFJLENBQUNnSyxPQUFPLENBQUMscUJBQXFCLEVBQUMsTUFBTSxDQUFDO0VBQUMsQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQ2hTLE1BQU03TCxNQUFNLENBQUM0TCxTQUFTLENBQUMsQ0FBQzlKLGFBQWEsQ0FBQyxPQUFPLENBQUM7RUFBQyxNQUFNZ0ssT0FBTyxHQUFDLE1BQU14TCxNQUFNLENBQUNXLElBQUksQ0FBQztFQUFDakIsTUFBTSxDQUFDOEwsT0FBTyxDQUFDMUgsTUFBTSxDQUFDQyxPQUFPLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFDLElBQUVBLENBQUMsQ0FBQzdCLEVBQUUsS0FBRzRHLEtBQUssQ0FBQzVHLEVBQUUsQ0FBQyxDQUFDLENBQUNMLE9BQU8sQ0FBQ2lILEtBQUssQ0FBQztFQUFDdkosTUFBTSxDQUFDOEwsT0FBTyxDQUFDMUgsTUFBTSxDQUFDQyxPQUFPLENBQUNpRyxTQUFTLENBQUMvRixJQUFJLENBQUM5QyxDQUFDLElBQUVBLENBQUMsQ0FBQ2tCLEVBQUUsS0FBRzRHLEtBQUssQ0FBQ3ZILElBQUksQ0FBQytKLGdCQUFnQixDQUFDLENBQUMsQ0FBQ3pKLE9BQU8sQ0FBQ2dILEtBQUssQ0FBQ2xGLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDaUcsU0FBUyxDQUFDL0YsSUFBSSxDQUFDOUMsQ0FBQyxJQUFFQSxDQUFDLENBQUNrQixFQUFFLEtBQUc0RyxLQUFLLENBQUN2SCxJQUFJLENBQUMrSixnQkFBZ0IsQ0FBQyxDQUFDO0VBQ3hVLE1BQU12TCxRQUFRLENBQUNXLElBQUksRUFBQywwQkFBMEIsRUFBQztJQUFDd0csYUFBYSxFQUFDbEgsTUFBTSxDQUFDZSxLQUFLLENBQUM7SUFBQ3dLLFdBQVcsRUFBQyxDQUFDO0lBQUNDLFlBQVksRUFBQyxDQUFDO0lBQUNDLG1CQUFtQixFQUFDLENBQUM7SUFBQ0MsT0FBTyxFQUFDNUMsS0FBSyxDQUFDNUcsRUFBRTtJQUFDOEcsUUFBUTtJQUFDMkMsYUFBYSxFQUFDLENBQUM3SyxDQUFDLENBQUMySixLQUFLLENBQUN2SSxFQUFFLEVBQUNwQixDQUFDLENBQUM0SixLQUFLLENBQUN4SSxFQUFFLENBQUM7SUFBQzBKLGlDQUFpQyxFQUFDLElBQUk7SUFBQ0MscUJBQXFCLEVBQUMsSUFBSTtJQUFDdkQsYUFBYSxFQUFDdEksTUFBTSxDQUFDcUwsT0FBTyxDQUFDdEUsS0FBSztFQUFDLENBQUMsQ0FBQztBQUN4UyxDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=