import {test,expect,type Page} from '@playwright/test';
import {strFromU8} from 'fflate';
import {createEntity,createProject,textToRichText} from '../candidate/src/domain/model';
import {completeInformation,approvedPublicScope} from './composite-fixtures';
import {nav,importBytes,seed,backup,durable,evidence,digest} from './common';
import {openRecord,saveEditor,output,fullFixtureBytes,equalArchiveAssets,freshRoundtrip,downloadArtifact} from './extended-support';

// Only unobserved original clauses are supplemented here. These are prepared
// procedures, not results. They must run on the new frozen C10 after OPEN.
test('AT-N14 empty recovery resumes a normal edit, atomic save, cold and complete re-export with actual material bytes',async({page,browser},info)=>{
 const f=await completeInformation(),bytes=await fullFixtureBytes(f);
 await importBytes(page,bytes);await page.reload();
 const restored=await backup(page);
 await openRecord(page,'scene',f.scene.name);await page.getByRole('tab',{name:'本文',exact:true}).click();
 await page.locator('.detail-panel').getByRole('textbox',{name:'本文',exact:true}).fill('空環境へ完全復元した後に編集を再開した😀');
 await saveEditor(page);await page.reload();await openRecord(page,'scene',f.scene.name);await page.getByRole('tab',{name:'本文',exact:true}).click();
 await expect(page.locator('.detail-panel').getByRole('textbox',{name:'本文',exact:true})).toHaveValue('空環境へ完全復元した後に編集を再開した😀');
 const edited=await backup(page);equalArchiveAssets(restored.parsed,edited.parsed);
 expect(edited.parsed.project.entities.map(e=>e.id)).toEqual(restored.parsed.project.entities.map(e=>e.id));
 expect(edited.parsed.project.snapshots).toEqual(restored.parsed.project.snapshots);
 for(const prior of restored.parsed.project.entities.filter(e=>['condition','variable','flow_edge'].includes(e.kind)))expect(edited.parsed.project.entities.find(e=>e.id===prior.id)?.data).toEqual(prior.data);
 expect(BigInt(edited.parsed.project.revision)).toBeGreaterThan(BigInt(restored.parsed.project.revision));
 const again=await freshRoundtrip(browser,edited.bytes);expect(again.parsed.project).toEqual(edited.parsed.project);equalArchiveAssets(edited.parsed,again.parsed);
 await evidence(info,'N14-post-restore-edit',{inputSHA:digest(bytes),restoredSHA:digest(restored.bytes),editedSHA:digest(edited.bytes),againSHA:digest(again.bytes),sameIDs:true,actualAssetBytes:edited.parsed.assets.map(a=>({path:a.path,bytes:a.bytes.length,sha256:digest(a.bytes)})),externalFullFileUsed:true,localHistoryNotPromisedAsBackup:true});
});

async function readTwo(page:Page,expected:string[],version=''){
 await nav(page,/^構成/);await page.getByRole('tab',{name:'章の試読',exact:true}).click();
 const region=page.getByRole('region',{name:'章順・選択経路の通読',exact:true});
 await region.getByLabel('読む作品の版',{exact:true}).selectOption(version);
 await region.getByRole('button',{name:/^(記録付き読書を始める|読み直す)$/}).click();
 for(const id of expected){await region.getByRole('button',{name:'次の場面を提示',exact:true}).click();await expect(region.locator('.chapter-reading-presented')).toHaveAttribute('data-presented-scene-id',id);}
 await expect(region.getByRole('button',{name:'全場面を提示しました',exact:true})).toBeDisabled();
 await region.getByRole('button',{name:'開始状態と経路を保存',exact:true}).click();
 await expect(region.getByText('開始状態と実際に提示した場面を保存しました。',{exact:true})).toBeVisible();
}
test('AT-E02 actual chapter presentation and disclosure order change while tick−10 and the fixed old edition remain',async({page},info)=>{
 const f=await completeInformation();await importBytes(page,await fullFixtureBytes(f));
 await nav(page,/^構成/);await page.getByRole('tab',{name:'章・本文',exact:true}).click();await page.getByLabel('物語の並べ方',{exact:true}).selectOption('chapter');
 await page.getByLabel(`${f.chapter.name}を下へ`,{exact:true}).click();await expect(page.locator('.story-lane').first()).toContainText(f.secondChapter.name);
 await readTwo(page,[f.secondScene.id,f.scene.id]);const current=await backup(page);
 const latest=current.parsed.project.entities.filter(e=>e.kind==='trace'&&e.data.mode==='chapters').at(-1)!;if(latest.kind!=='trace')throw Error('chapter trace required');
 expect(latest.data.readingPath?.occurrences.map(o=>o.entityId)).toEqual([f.secondScene.id,f.scene.id]);
 const disclosure=f.p.entities.find(e=>e.kind==='disclosure')!;
 expect(latest.data.readingPath?.occurrences[0].conditionResults.some(c=>c.targetId===disclosure.id)).toBe(false);
 expect(latest.data.readingPath?.occurrences[1].conditionResults).toEqual(expect.arrayContaining([expect.objectContaining({targetId:disclosure.id,value:'true'})]));
 await page.reload();await readTwo(page,[f.scene.id,f.secondScene.id],f.published.id);const old=await backup(page);
 const oldTrace=old.parsed.project.entities.filter(e=>e.kind==='trace'&&e.data.mode==='chapters').at(-1)!;if(oldTrace.kind!=='trace')throw Error('old chapter trace required');
 expect(oldTrace.data.readingPath?.occurrences.map(o=>o.entityId)).toEqual([f.scene.id,f.secondScene.id]);
 expect(oldTrace.data.readingPath?.occurrences[0].conditionResults).toEqual(expect.arrayContaining([expect.objectContaining({targetId:disclosure.id,value:'true'})]));
 expect(old.parsed.project.entities.find(e=>e.id===f.event.id)?.data).toMatchObject({time:{at:'-10'}});
 expect(old.parsed.project.snapshots.find(s=>s.id===f.published.id)).toEqual(f.published);equalArchiveAssets(current.parsed,old.parsed);
 await evidence(info,'E02-executed-presentation-order',{currentArchiveSHA:digest(current.bytes),oldTraceArchiveSHA:digest(old.bytes),currentTrace:latest.data,oldTrace:oldTrace.data,worldTickNotMoved:true,oldEditionHash:f.published.contentHash});
});

test('AT-N20 mismatch location opens the exact unsupported contract before safe reader generation',async({page},info)=>{
 const p=createProject('未対応型の対象を通常画面へ戻す'),scene=createEntity(p.projectId,'scene','安全な本文',{body:textToRichText('安全な読者本文😀')}),entry=createEntity(p.projectId,'flow_node','入口',{nodeType:'entry',sceneId:scene.id}),end=createEntity(p.projectId,'flow_node','終端',{nodeType:'terminal',terminalReason:'終了'}),edge=createEntity(p.projectId,'flow_edge','終端へ',{fromId:entry.id,toId:end.id,label:'終端へ'}),graph=createEntity(p.projectId,'flow_graph','通常範囲',{nodeIds:[entry.id,end.id],edgeIds:[edge.id],entryIds:[entry.id],exitIds:[end.id]}),contract=createEntity(p.projectId,'external_contract','ここへ戻る未対応の文字列契約',{key:'unsupported_command',owner:'game',inputType:'text',outputType:'text',stubValues:[{type:'text',value:'command'}]});
 p.entities.push(scene,entry,end,edge,graph,contract);p.entities.forEach(e=>e.status='confirmed');const profile=approvedPublicScope(p,[scene,entry,end,edge,graph,contract]),safe=approvedPublicScope(p,[scene,entry,end,edge,graph],'作者が確認した安全な本文のみ');await seed(page,p);const initial=await durable(page);
 const downloads:string[]=[];page.on('download',d=>downloads.push(d.suggestedFilename()));
 for(const purpose of ['runtime_json','playable_preview']){
  await output(page);await page.getByLabel('出力する公開範囲',{exact:true}).selectOption(profile.id);await page.getByLabel('出力目的',{exact:true}).selectOption(purpose);await page.getByRole('button',{name:'内容を検査・プレビュー',exact:true}).click();
  const issue=page.locator('.export-result li').filter({hasText:'この外部値の型を対応先で表せません。'});await expect(issue).toBeVisible();await issue.getByRole('button',{name:'対象を開く',exact:true}).click();
  await expect(page.locator('.detail-heading')).toContainText(contract.name);await expect(page.locator('.detail-panel').getByLabel('名前',{exact:true})).toHaveValue(contract.name);
  await expect(page.locator('.detail-panel')).toHaveAttribute('aria-label','外部契約の詳細');expect(downloads).toEqual([]);
 }
 expect(await durable(page)).toEqual(initial);await output(page);await page.getByLabel('出力する公開範囲',{exact:true}).selectOption(safe.id);await page.getByLabel('出力目的',{exact:true}).selectOption('reader');await page.getByRole('button',{name:'内容を検査・プレビュー',exact:true}).click();const delivered=await downloadArtifact(page,'reader.md');expect(strFromU8(delivered)).toContain('安全な読者本文😀');expect(await durable(page)).toEqual(initial);
 await evidence(info,'N20-actual-location-return',{contractID:contract.id,contractKey:contract.data.key,safeSHA:digest(delivered),canonicalUnchanged:true,unsupportedProfiles:['runtime_json','playable_preview'],allEnginesSupportedClaim:false});
});
