import {createServer,type Server} from 'node:http';
import {readFile,realpath} from 'node:fs/promises';
import {extname,resolve,sep} from 'node:path';
export async function buildServer(firstRoot:string,port:number) {
 if(port<5300||port>5399)throw Error('Independent preview port must be 53xx');
 let root=await realpath(firstRoot);const mime:Record<string,string>={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
 const server=createServer(async(req,res)=>{try{const url=new URL(req.url||'/','http://127.0.0.1');if(url.pathname==='/__independent.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><html lang="ja"><title>Independent fixture seed</title><p>Native IndexedDB fixture origin only</p></html>');return;}if(!url.pathname.startsWith('/shinariokanri/')){res.writeHead(404).end();return;}const current=root,part=decodeURIComponent(url.pathname.slice('/shinariokanri/'.length))||'index.html',file=resolve(current,part);if(!file.startsWith(current+sep)){res.writeHead(400).end();return;}res.setHeader('Content-Type',mime[extname(file)]||'application/octet-stream');res.setHeader('Cache-Control','no-store');res.end(await readFile(file));}catch{res.writeHead(404).end();}});
 await new Promise<void>((done,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',done);});
 return {url:`http://127.0.0.1:${port}/shinariokanri/`,server,switchRoot:async(next:string)=>{root=await realpath(next);},stop:()=>stopServer(server)};
}
export async function stopServer(server:Server){if(!server.listening)return;server.closeAllConnections();await new Promise<void>((done,reject)=>server.close(cause=>cause?reject(cause):done()));}
