import {test,expect} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {randomLoopAndBattle} from './composite-fixtures';
import {nav,seed,durable,evidence,digest} from './common';
import {reader,begin,openRecord,editData} from './extended-support';

// Small supplementary reproduction for the original N05 then. This does not
// stand in for the full original Large + long-branch given. No result yet.
test('AT-N05 supplementary: cancelled unknown analysis remains openable after a different screen and unsaved input resumes',async({page},info)=>{
 const f=randomLoopAndBattle();await seed(page,f.p);
 await openRecord(page,'scene',f.sceneA.name);
 const draft=await editData(page,()=>{}),draftText=(await draft.inputValue()).slice(0,-1);await draft.fill(draftText);
 await expect(page.locator('.editor-save-state')).toContainText('未保存');
 await reader(page);await begin(page,f.loopEntry.id);
 const before=await durable(page);await page.getByRole('button',{name:'到達性と行き止まりを検査',exact:true}).click();
 await expect(page.getByRole('button',{name:'探索を中止',exact:true})).toBeVisible();await page.getByRole('button',{name:'探索を中止',exact:true}).click();
 await expect(page.locator('.analysis-result-heading')).toContainText('探索打切り');
 const saveBefore=page.waitForEvent('download');await page.getByRole('button',{name:'検査結果を保存',exact:true}).click();
 const originalBytes=await readFile((await(await saveBefore).path())!),original=JSON.parse(originalBytes.toString('utf8'));
 expect(original.truncated).toBe(true);expect(original.status).not.toBe('passed_for_checked_scope');expect(await durable(page)).toEqual(before);
 await nav(page,/^資料/);await reader(page);
 await expect(page.locator('.analysis-result-heading')).toContainText('探索打切り');
 const saveAfter=page.waitForEvent('download');await page.getByRole('button',{name:'検査結果を保存',exact:true}).click();const retainedBytes=await readFile((await(await saveAfter).path())!);expect(JSON.parse(retainedBytes.toString('utf8'))).toEqual(original);
 await openRecord(page,'scene',f.sceneA.name);const advanced=page.locator('details.advanced-details').filter({has:page.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true})});if(await advanced.getAttribute('open')===null)await advanced.locator('summary').click();await expect(advanced.getByRole('textbox',{name:'詳細データ',exact:true})).toHaveValue(draftText);expect(await durable(page)).toEqual(before);
 await evidence(info,'N05-unknown-result-navigation',{fixtureScope:'Small same unbounded branch; full original Large given requires separate actual archive/analysis run',originalResultSHA256:digest(originalBytes),retainedResultSHA256:digest(retainedBytes),allNativeRowsUnchanged:true,unsavedJSONRestored:true,unknownNeverFullSafety:true});
});
