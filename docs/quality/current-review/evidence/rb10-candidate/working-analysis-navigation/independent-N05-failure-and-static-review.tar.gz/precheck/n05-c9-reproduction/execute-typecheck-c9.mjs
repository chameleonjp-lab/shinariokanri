import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {release as osRelease} from 'node:os';
const root=dirname(fileURLToPath(import.meta.url)),sha=bytes=>createHash('sha256').update(bytes).digest('hex'),run=process.env.REVIEW_RUN;
if(process.env.REVIEW_EXECUTION_WINDOW!=='open'||!run||!/^[a-z0-9-]+$/.test(run))throw Error('Explicit OPEN and unique review run required for compiler execution.');
const binding=JSON.parse(await readFile(resolve(root,'candidate-binding.json'),'utf8'));
async function verifyCandidate(){for(const item of [...binding.sourceFiles,...binding.originalDocuments??[],...binding.distFiles,...binding.generatedInputs??[]])if(sha(await readFile(resolve(root,'candidate',item.file)))!==item.sha256)throw Error('Frozen C9 candidate changed: '+item.file);}
await verifyCandidate();await mkdir(resolve(root,'results'),{recursive:true});const output=resolve(root,'results',run);await mkdir(output);await mkdir(resolve(output,'input-source'));
const files=['tsconfig.harness-c9.json','execute-typecheck-c9.mjs'];for(const name of(await readdir(root)).sort())if(name.endsWith('.config.ts'))files.push(name);for(const name of(await readdir(resolve(root,'harness-c1'))).sort())if(name.endsWith('.ts'))files.push('harness-c1/'+name);
const harnessFiles=[];for(const file of files){const bytes=await readFile(resolve(root,file));const target=resolve(output,'input-source',file);await mkdir(dirname(target),{recursive:true});await writeFile(target,bytes);harnessFiles.push({file,sha256:sha(bytes)});}
const command=[resolve(root,'node_modules/.bin/tsc'),'--project',resolve(root,'tsconfig.harness-c9.json'),'--noEmit'];const startedAt=new Date().toISOString();
await writeFile(resolve(output,'INPUTS.json'),JSON.stringify({commit:binding.commit,tree:binding.tree,startedAt,command,harnessFiles,environment:{node:process.version,platform:process.platform,arch:process.arch,osVersion:osRelease()},proofLayer:'TypeScript/import verification only; no functional acceptance result'},null,2)+'\n');
const child=spawn(command[0],command.slice(1),{cwd:root,env:process.env,stdio:'pipe'});let raw='';const stream=createWriteStream(resolve(output,'raw.in-progress.log'));for(const channel of[child.stdout,child.stderr])channel.on('data',bytes=>{raw+=bytes.toString();stream.write(bytes);process.stdout.write(bytes);});
const exitCode=await new Promise((done,reject)=>{child.on('error',reject);child.on('close',done);});await new Promise(done=>stream.end(done));await writeFile(resolve(output,'raw.log'),raw);await verifyCandidate();for(const item of harnessFiles)if(sha(await readFile(resolve(root,item.file)))!==item.sha256)throw Error('Harness changed during compile: '+item.file);
const result={commit:binding.commit,tree:binding.tree,candidateBindingSHA256:sha(await readFile(resolve(root,'candidate-binding.json'))),startedAt,finishedAt:new Date().toISOString(),exitCode:Number(exitCode??1),command,harnessFiles,rawFile:'results/'+run+'/raw.log',rawSHA256:sha(raw),sealedCandidateUnchanged:true,proofLayer:'TypeScript/import verification only',functionalTestsStarted:0,acceptancePassesInferred:0,physical:'not_run',actualAuth:'not_run'};
await writeFile(resolve(output,'EXECUTION_BINDING.json'),JSON.stringify(result,null,2)+'\n');if(exitCode===0){await writeFile(resolve(output,'HARNESS_SUCCESS.json'),JSON.stringify(result,null,2)+'\n');try{await writeFile(resolve(root,'harness-typecheck-c9-success.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});}catch(error){if(error.code!=='EEXIST')throw error;}}
process.exitCode=Number(exitCode??1);
