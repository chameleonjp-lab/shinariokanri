import {test,expect} from '@playwright/test';
import {sharedCommentFixture,ids} from './fixtures';
import {createSharedCommentReview} from '../candidate/src/domain/sharedReviews';
import {nav,seed,durable,evidence} from './common';

test('AT-F29/N18 author UI: invalid detail JSON remains unsaved and blocks stage/task commands until explicitly corrected',async({page},info)=>{
 const f=await sharedCommentFixture(),review=await createSharedCommentReview(f.p,f.envelope,f.comment,'https://independent-reviews.invalid');review.id=ids(707);review.name='独立共有指摘';f.p.entities.push(review);await seed(page,f.p);await nav(page,/^検索/);await page.locator('.search-page .kind-select').selectOption('review');await page.locator('.entity-card').filter({hasText:review.name}).click();
 const editor=page.locator('.detail-panel'),actions=page.getByRole('region',{name:'指摘の修正と確認'});await expect(actions).toContainText('未処理');const before=await durable(page);
 await editor.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true}).click();await editor.getByLabel('詳細データ',{exact:true}).fill('{INDEPENDENT_UNSAVED_INVALID_REVIEW');await expect(editor.getByRole('button',{name:'保存する',exact:true})).toBeDisabled();await expect(actions.getByRole('button',{name:'修正済みとして保存',exact:true})).toBeDisabled();await expect(actions.getByRole('button',{name:'この指摘の制作タスクを作る',exact:true})).toBeDisabled();
 await nav(page,/^構成/);await nav(page,/^検索/);await page.locator('.entity-card').filter({hasText:review.name}).click();await editor.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true}).click();await expect(editor.getByLabel('詳細データ',{exact:true})).toHaveValue('{INDEPENDENT_UNSAVED_INVALID_REVIEW');expect(await durable(page)).toEqual(before);
 await evidence(info,'F29-invalid-json-command-guard',{reviewId:review.id,sourceVersionId:f.pin.id,quote:'😀版',commandsBlocked:true,allCanonicalRowsUnchanged:true,proofLayer:'normal author App/native IndexedDB only; seeded public/private correspondence is a synthetic fixture'});
});
