import {test,expect} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
import {defaultCaps,defaultBoundaryFixture,type BoundaryDimension} from './archive-default-fixtures';
import {offlineFixture} from './fixtures';
import {seed,nav,durable,digest,evidence} from './common';

// Run one dimension per independent invocation. The other definitions stay
// explicitly unexecuted; the isolation hold must never allocate these fixtures.
const selected=process.env.REVIEW_DEFAULT_BOUNDARY;
for(const dimension of Object.keys(defaultCaps) as BoundaryDimension[]){
 for(const offset of [-1,0,1] as const){
  test(`AT-E07/N09 original default ${dimension} ${offset}: normal inspection/restoration or whole saved-image refusal`,async({page},info)=>{
   test.skip(selected!==dimension,'Deferred default-cap fixture; choose one dimension after performance isolation ends.');
   test.setTimeout(600000); // Harness watchdog, not a changed product performance target.
   const sentinel=await offlineFixture();await seed(page,sentinel.p,sentinel.assets);
   await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
   const before=await durable(page),beforeSHA=digest(JSON.stringify(before));
   const f=defaultBoundaryFixture(dimension,offset),input=info.outputPath(`${dimension}-${offset}.scenario`);
   await writeFile(input,f.bytes);await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles(input);
   if(!f.expectedAccepted){
    const alert=page.locator('.backup-page').getByRole('alert').first();await expect(alert).toContainText(/上限|LIMIT|件数|深さ|文字|MiB|構造|node|条件|サイズ/i,{timeout:180000});
    const after=await durable(page);expect(after).toEqual(before);
    await evidence(info,'default-boundary-result',{inputSHA256:f.sha256,dimension,offset,expected:'reject; every existing saved image/asset/history/outbox/part unchanged',actual:await alert.innerText(),metrics:f.metrics,beforeSHA,afterSHA:digest(JSON.stringify(after)),wholeDurableStateUnchanged:true});
   }else{
    await expect(page.getByRole('heading',{name:/^検査済みの作品/})).toBeVisible({timeout:180000});
    await page.getByLabel('復元方法',{exact:true}).selectOption('new');await page.getByLabel('復元方法と対象への影響を確認しました').check();
    await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect(page.locator('.project-switch')).toContainText(f.project.name,{timeout:180000});
    await page.reload();await expect(page.locator('.project-switch')).toContainText(f.project.name,{timeout:180000});
    const counts=await page.evaluate(async projectId=>{
     const db=await new Promise<IDBDatabase>((resolve,reject)=>{const q=indexedDB.open('scenario-manager-local-v1');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
     try{return await new Promise<{entities:number;relations:number;projects:number}>((resolve,reject)=>{const tx=db.transaction(['projects','entities','relations'],'readonly');let entities=0,relations=0,projects=0;const e=tx.objectStore('entities').index('projectId').count(projectId),r=tx.objectStore('relations').index('projectId').count(projectId),p=tx.objectStore('projects').count();e.onsuccess=()=>entities=e.result;r.onsuccess=()=>relations=r.result;p.onsuccess=()=>projects=p.result;tx.oncomplete=()=>resolve({entities,relations,projects});tx.onabort=()=>reject(tx.error);});}finally{db.close();}
    },f.project.projectId);
    expect(counts.entities).toBe(f.project.entities.length);expect(counts.relations).toBe(f.project.relations.length);expect(counts.projects).toBe(2);
    await evidence(info,'default-boundary-result',{inputSHA256:f.sha256,dimension,offset,expected:'accepted at original default; atomic import and cold restart',metrics:f.metrics,counts,scope:'Normal production/native IndexedDB boundary only. Full all-kind/material/re-export chain is recorded by the separate E07 fixture; physical Files not inferred.'});
   }
  });
 }
}
