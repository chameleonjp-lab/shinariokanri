import {defineConfig,devices} from '@playwright/test';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),run=process.env.REVIEW_RUN??'additional-c8';
if(!/^[a-z0-9-]+$/.test(run))throw Error('Bound review run name required.');
if(!process.env.CHROMIUM_PATH)throw Error('Explicitly bound Chromium153 required.');
export default defineConfig({
 testDir:resolve(root,'harness-c1'),testMatch:'n05-analysis-navigation.spec.ts',workers:1,fullyParallel:false,retries:0,
 timeout:90000,expect:{timeout:10000},outputDir:resolve('/workspace/shinariokanri-independent-artifacts/rb10-c9-n05-precheck',run,'artifacts'),
 reporter:[['list'],['json',{outputFile:resolve(root,'results',run,'playwright.json')}]],
 use:{baseURL:'http://127.0.0.1:5310/shinariokanri/',trace:'on',screenshot:'only-on-failure',...devices['Desktop Chrome'],launchOptions:{executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']}},
 webServer:{command:'node server.mjs --port 5310',cwd:root,url:'http://127.0.0.1:5310/shinariokanri/build-info.json',reuseExistingServer:false},
});
