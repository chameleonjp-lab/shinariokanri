import {expect,type Page,type Browser,type TestInfo} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {unzipSync,zipSync,strFromU8,strToU8} from 'fflate';
import {exportScenario,type ScenarioManifest,type PreparedScenario} from '../candidate/src/storage/archive';
import {sha256,jsonBytes} from '../candidate/src/storage/json';
import type {EntityKind,ProjectData} from '../candidate/src/domain/types';
import {appURL,nav,importBytes,backup,durable,evidence,digest,captureProofFile} from './common';

export async function openRecord(page:Page,kind:EntityKind,name:string){
 await nav(page,/^資料/);await page.getByLabel('情報の種類',{exact:true}).selectOption(kind);
 await page.locator('.entity-card').filter({has:page.getByRole('heading',{name,exact:true})}).click();
 await expect(page.locator('.detail-heading')).toContainText(name);
}
export async function saveEditor(page:Page){
 const button=page.locator('.editor-footer').getByRole('button',{name:/^(保存する|保存を再試行)$/});
 await button.click();await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
}
export async function editData(page:Page,change:(data:Record<string,unknown>)=>void){
 const advanced=page.locator('details.advanced-details').filter({has:page.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true})});
 if(await advanced.getAttribute('open')===null)await advanced.locator('summary').click();
 const input=advanced.getByRole('textbox',{name:'詳細データ',exact:true}),data=JSON.parse(await input.inputValue());
 change(data);await input.fill(JSON.stringify(data));return input;
}
export async function reader(page:Page){await nav(page,/^構成/);await page.getByRole('tab',{name:'試読・検査',exact:true}).click();}
export async function production(page:Page){await nav(page,/^構成/);await page.getByRole('tab',{name:'制作',exact:true}).click();}
export async function output(page:Page){await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'目的別出力',exact:true}).click();}
export async function settings(page:Page){await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'作品の設定',exact:true}).click();}
export async function begin(page:Page,entryId:string,version='',seed='original-acceptance-seed'){
 await page.getByLabel('試読する作品版',{exact:true}).selectOption(version);
 await page.getByLabel('試読の開始点',{exact:true}).selectOption(entryId);await page.getByLabel('抽選種',{exact:true}).fill(seed);
 await page.getByRole('button',{name:/^(試読を始める|この状態から開始し直す)$/}).click();
}
export async function recordTrial(page:Page){
 await page.getByRole('button',{name:'経路を記録',exact:true}).click();
 await expect(page.getByText('開始状態と経路を端末内に保存しました。',{exact:true})).toBeVisible();
}
export async function downloadArtifact(page:Page,filename:string){
 const item=page.locator('.export-artifact').filter({hasText:filename});await expect(item).toBeVisible();
 const pending=page.waitForEvent('download');await item.getByRole('button',{name:'この内容を保存',exact:true}).click();
 const file=await pending;expect(await file.failure()).toBeNull();const bytes=new Uint8Array(await readFile((await file.path())!));await captureProofFile(bytes,`purpose-${filename}`,filename.split('.').at(-1)??'bin');return bytes;
}
export async function freshRoundtrip(browser:Browser,bytes:Uint8Array,mode:'new'|'clone'='new'){
 const fresh=await browser.newContext();try{const p=await fresh.newPage();await importBytes(p,bytes,appURL,mode);await p.reload();await expect(p.locator('.project-switch')).toBeVisible();return await backup(p);}finally{await fresh.close();}
}
export function equalArchiveAssets(before:PreparedScenario,after:PreparedScenario){
 const canonical=(v:PreparedScenario)=>v.assets.map(a=>({path:a.path,hash:a.contentHash,mediaType:a.mediaType,byteSHA256:digest(a.bytes),bytes:a.bytes.length})).sort((a,b)=>a.path.localeCompare(b.path));
 expect(canonical(after)).toEqual(canonical(before));expect(after.worlds).toEqual(before.worlds);
}
export async function fullFixtureBytes(f:{p:ProjectData;worlds?:Record<string,ProjectData>;assets?:Record<string,Uint8Array>}){
 return exportScenario(f.p,{worker:false,worlds:f.worlds,exportedAt:'2026-10-08T12:00:00.000Z',loadAsset:h=>f.assets?.[h]});
}

export interface BadArchive {name:string;bytes:Uint8Array;expected:RegExp;expectedPath?:string;explanation:string}
async function reseal(files:Record<string,Uint8Array>,path:string){
 const m=JSON.parse(strFromU8(files['manifest.json'])) as ScenarioManifest,file=m.files.find(f=>f.path===path);if(!file)throw Error('missing manifest fixture path '+path);
 file.byteSize=files[path].length;file.sha256=await sha256(files[path]);files['manifest.json']=jsonBytes(m);
}
export async function badArchives(good:Uint8Array):Promise<BadArchive[]>{
 const original=unzipSync(good),out:BadArchive[]=[];
 const fresh=():Record<string,Uint8Array>=>Object.fromEntries(Object.entries(original).map(([k,v])=>[k,v.slice()]));
 {const f=fresh();f['data/project.json'][4]^=1;out.push({name:'project hash mismatch',bytes:zipSync(f),expected:/hash|ハッシュ|一致|破損/,expectedPath:'data/project.json',explanation:'One private project byte changes; manifest SHA remains original.'});}
 {const f=fresh(),m=JSON.parse(strFromU8(f['manifest.json']));m.formatVersion='99.0.0';f['manifest.json']=jsonBytes(m);out.push({name:'unknown major format',bytes:zipSync(f),expected:/版|未対応|形式/,expectedPath:'manifest.json',explanation:'Unsupported major version is not migrated or partially imported.'});}
 {const f=fresh();f['../project.json']=strToU8('{}');out.push({name:'dangerous path',bytes:zipSync(f),expected:/パス|path|危険|禁止/,expectedPath:'../project.json',explanation:'Explicit traversal path in the ZIP container.'});}
 {const f=fresh(),p=JSON.parse(strFromU8(f['data/project.json']));const event=p.entities.find((e:{kind:string})=>e.kind==='event');if(!event)throw Error('reference fixture requires event');event.data.locationId='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';f['data/project.json']=jsonBytes(p);await reseal(f,'data/project.json');out.push({name:'broken typed reference',bytes:zipSync(f),expected:/参照|REFERENCE|見つか|存在/,explanation:'Correct file SHA but a nonexistent typed event.locationId.'});}
 {const f=fresh(),p=JSON.parse(strFromU8(f['data/project.json']));p.entities.push(structuredClone(p.entities[0]));f['data/project.json']=jsonBytes(p);await reseal(f,'data/project.json');out.push({name:'owned ID collision',bytes:zipSync(f),expected:/ID|重複|衝突/,explanation:'Correct SHA but duplicate owned entity ID.'});}
 {const f=fresh(),p=JSON.parse(strFromU8(f['data/project.json']));p.entities.find((e:{kind:string})=>e.kind==='note').data.body=[{id:'dd000000-0000-4000-8000-000000000001',kind:'paragraph',text:'X'.repeat(100000)}];f['data/project.json']=jsonBytes(p);await reseal(f,'data/project.json');const zipped=zipSync(f,{level:9}),v=new DataView(zipped.buffer,zipped.byteOffset,zipped.byteLength);for(let i=0;i<zipped.length-46;i++){if(v.getUint32(i,true)!==0x02014b50)continue;const n=v.getUint16(i+28,true),name=strFromU8(zipped.subarray(i+46,i+46+n));if(name!=='data/project.json')continue;const local=v.getUint32(i+42,true);v.setUint32(i+24,100,true);v.setUint32(local+22,100,true);}out.push({name:'understated compressed payload',bytes:zipped,expected:/上限|LIMIT|展開|宣言/,expectedPath:'data/project.json',explanation:'Compressed text is bounded at100KB but central/local expanded sizes understate100B; reject before partial import.'});}
 {const f=fresh(),zipped=zipSync(f),paths=Object.keys(f).filter(k=>k.startsWith('assets/'));if(paths.length>=2&&paths[0].length===paths[1].length){const from=strToU8(paths[1]),to=strToU8(paths[0]);for(let i=0;i<=zipped.length-from.length;i++)if(from.every((b,j)=>zipped[i+j]===b))zipped.set(to,i);out.push({name:'duplicate attachment ZIP path',bytes:zipped,expected:/重複|ファイル名/,expectedPath:paths[0],explanation:'Both central and local names of the second attachment become the first attachment name.'});}}
 return out;
}
export async function rejectFileAtomic(page:Page,bad:BadArchive,info:TestInfo){
 await captureProofFile(bad.bytes,`rejected-${bad.name}`);
 await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();const before=await durable(page),beforeSHA=digest(JSON.stringify(before));
 await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles({name:'negative.scenario',mimeType:'application/zip',buffer:Buffer.from(bad.bytes)});
 const alert=page.locator('.backup-page').getByRole('alert').first();await expect(alert).toContainText(bad.expected);
 if(bad.expectedPath)await expect.soft(alert).toContainText(bad.expectedPath,{timeout:100});
 const after=await durable(page);expect(after).toEqual(before);
 await evidence(info,bad.name.replace(/\W/g,'-'),{inputSHA256:digest(bad.bytes),expectedPath:bad.expectedPath,expected:bad.expected.source,actualAlert:await alert.innerText(),beforeSHA,afterSHA:digest(JSON.stringify(after)),allDurableRowsUnchanged:true,explanation:bad.explanation});
}
export async function noPageOverflow(page:Page){const difference=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);if(difference>1){console.log('INDEPENDENT_OVERFLOW_DIAGNOSTIC '+JSON.stringify(await page.evaluate(()=>({innerWidth,scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,scrollX,offenders:Array.from(document.querySelectorAll('*')).flatMap(element=>{if(!(element instanceof HTMLElement))return [];const rect=element.getBoundingClientRect(),style=getComputedStyle(element);if(rect.right<=innerWidth+1||rect.width<=0||style.display==='none'||style.visibility==='hidden')return [];return [{tag:element.tagName,className:element.getAttribute('class'),id:element.id,text:(element.textContent??'').slice(0,100),left:rect.left,right:rect.right,width:rect.width,minWidth:style.minWidth,whiteSpace:style.whiteSpace,scrollWidth:element.scrollWidth,clientWidth:element.clientWidth,overflowX:style.overflowX,position:style.position,ancestors:Array.from((function*(current:Element|null){for(let i=0;current&&i<4;i++,current=current.parentElement)yield current;})(element.parentElement)).map(parent=>({tag:parent.tagName,className:parent.getAttribute('class'),overflowX:getComputedStyle(parent).overflowX,right:parent.getBoundingClientRect().right}))}];}).slice(0,60)}))));}expect(difference).toBeLessThanOrEqual(1);}
