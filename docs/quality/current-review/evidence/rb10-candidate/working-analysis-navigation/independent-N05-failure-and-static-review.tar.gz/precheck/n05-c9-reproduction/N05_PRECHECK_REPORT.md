N05 small supplementary reproduction: FAIL on fixed C9 572c6df / tree1822ac / buildd20d.

The normal cancel action exports an unknown, truncated result. Navigation to 資料 and back removes both the result and its download button. Native12 rows match exactly before/after navigation and the unfinished scene JSON resumes. This confirms the result-retention defect; it does not satisfy the original Large-data given.

Run2 and run3 product failures, run1 harness setup failure, all four compiler passes and fixed original archive bytes remain preserved. C10 repair is presently static-only and needs independent final-target execution.
