import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import {afterEach,expect,it,vi} from 'vitest';
import {installRecordPartsDatabase} from '../candidate/src/storage/recordPartsDatabase';
import {packRecordData} from '../candidate/src/storage/recordPartsCore';

// Independent small fixtures exercise storage semantics without measuring the
// Large fixture or claiming a native browser quota result.
const databases:Dexie[]=[];let sequence=0;
const schema={commands:'operationId,projectId,[projectId+revision]',recordParts:'key,scope'};
function database(){const db=new Dexie(`independent-parts-${++sequence}`);db.version(1).stores(schema);installRecordPartsDatabase(db,512);databases.push(db);return db;}
async function raw(db:Dexie){await db.open();return new Promise<Record<string,unknown[]>>((resolve,reject)=>{
 const tx=db.backendDB().transaction(['commands','recordParts'],'readonly'),out:Record<string,unknown[]>={};
 for(const name of ['commands','recordParts']){const q=tx.objectStore(name).getAll();q.onsuccess=()=>{out[name]=q.result;};}
 tx.oncomplete=()=>resolve(out);tx.onabort=()=>reject(tx.error);tx.onerror=()=>reject(tx.error);
});}
const row=(operationId:string,projectId='A',revision='1')=>({operationId,projectId,revision,before:{text:'旧本文😀'.repeat(80)},after:{text:'改稿かな漢字😀'.repeat(80),present:undefined}});
afterEach(async()=>{vi.restoreAllMocks();for(const db of databases.splice(0))await db.delete();});

it('parts: arbitrary older history remains searchable by compound index and cursor page without borrowing another work',async()=>{
 const db=database(),rows=[row('A1','A','1'),row('A2','A','2'),row('B1','B','1')];await db.table('commands').bulkAdd(rows);
 expect(await db.table('commands').where('[projectId+revision]').equals(['A','1']).toArray()).toEqual([rows[0]]);
 expect(await db.table('commands').where('projectId').equals('A').reverse().offset(1).limit(1).toArray()).toEqual([rows[0]]);
 expect(await db.table('commands').where('projectId').equals('A').filter(r=>r.before.text.includes('😀')).toArray()).toEqual(rows.slice(0,2));
 expect(await db.table('commands').bulkGet(['missing','B1','A1'])).toEqual([undefined,rows[2],rows[0]]);
});

it('parts: an existing v6 database upgrades without rewriting or losing an unsegmented history row',async()=>{
 const name=`independent-legacy-parts-${++sequence}`,legacy=new Dexie(name);legacy.version(6).stores({commands:schema.commands});await legacy.open();const original=row('v6');await legacy.table('commands').add(original);legacy.close();
 const current=new Dexie(name);current.version(6).stores({commands:schema.commands});current.version(7).stores({recordParts:schema.recordParts});installRecordPartsDatabase(current,512);databases.push(current);await current.open();
 expect(await current.table('commands').get('v6')).toEqual(original);expect(await current.table('recordParts').count()).toBe(0);
 await current.table('commands').add(row('v7'));current.close();await current.open();expect(await current.table('commands').get('v6')).toEqual(original);expect(await current.table('commands').get('v7')).toEqual(row('v7'));
});

it('parts: a native write quota failure after part creation leaves old rows and all old parts unchanged',async()=>{
 const db=database(),original=row('old');await db.table('commands').add(original);const before=await raw(db),nativeAdd=IDBObjectStore.prototype.add;let fired=false;
 vi.spyOn(IDBObjectStore.prototype,'add').mockImplementation(function(this:IDBObjectStore,...args:Parameters<IDBObjectStore['add']>){if(this.name==='commands'&&!fired){fired=true;throw new DOMException('independent native quota','QuotaExceededError');}return nativeAdd.apply(this,args);});
 await expect(db.transaction('rw','commands',async()=>{await db.table('commands').put({...original,after:{text:'後発編集😀'.repeat(90)}});await db.table('commands').add(row('later'));})).rejects.toThrow();
 expect(fired).toBe(true);expect(await raw(db)).toEqual(before);expect(await db.table('commands').get('old')).toEqual(original);
});

it('parts: a scoped range deletion removes only the chosen work and its parts while preserving another work',async()=>{
 const db=database(),a=[row('A1'),row('A2')],b=row('B1','B');await db.table('commands').bulkAdd([...a,b]);const before=await raw(db),bHeader=(before.commands as Record<string,unknown>[]).find(r=>r.operationId==='B1')!,bKeys=((bHeader.__scenarioRecordParts as {parts:{key:string}[]}).parts).map(p=>p.key);
 await db.table('commands').where('projectId').equals('A').delete();expect(await db.table('commands').toArray()).toEqual([b]);
 const after=await raw(db);expect((after.recordParts as {key:string}[]).map(p=>p.key).sort()).toEqual(bKeys.sort());expect(after.recordParts).toEqual(before.recordParts.filter(p=>bKeys.includes((p as {key:string}).key)));
});

it('parts: repeated keys in one put batch retain the final complete row without committing unreachable intermediate parts',async()=>{
 const db=database(),first=row('same'),last={...first,after:{text:'最終本文😀'.repeat(100)}};await db.table('commands').bulkPut([first,last]);expect(await db.table('commands').get('same')).toEqual(last);
 const state=await raw(db),header=state.commands[0] as {__scenarioRecordParts:{parts:{key:string}[]}},reachable=header.__scenarioRecordParts.parts.map(p=>p.key);
 expect((state.recordParts as {key:string}[]).map(p=>p.key).sort()).toEqual(reachable.sort());
});

it('parts: cancellation while the final SHA is awaiting does not return a successful packed record',async()=>{
 const controller=new AbortController(),digest=crypto.subtle.digest.bind(crypto.subtle);let released!:()=>void,arrived!:()=>void;
 const gate=new Promise<void>(resolve=>{released=resolve;}),entered=new Promise<void>(resolve=>{arrived=resolve;});
 vi.spyOn(crypto.subtle,'digest').mockImplementation(async(...args:Parameters<SubtleCrypto['digest']>)=>{arrived();await gate;return digest(...args);});
 const result=packRecordData(row('cancel'),'independent-cancel',controller.signal);await entered;controller.abort();released();await expect(result).rejects.toMatchObject({code:'CANCELLED'});
});
