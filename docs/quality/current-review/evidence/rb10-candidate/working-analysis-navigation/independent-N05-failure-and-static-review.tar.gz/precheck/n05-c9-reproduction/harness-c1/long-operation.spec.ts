import {test,expect} from '@playwright/test';
import {createProject,createEntity,textToRichText} from '../candidate/src/domain/model';
import {seed,nav,durable,evidence,digest,backup} from './common';
import {openRecord,saveEditor} from './extended-support';

test('AT-N05/N18 functional save held beyond two seconds: progress + cancel retain every saved row and input, navigation + explicit retry + cold + full file',async({page},info)=>{
 const project=createProject('長処理の取消と入力再開');
 const note=createEntity(project.projectId,'note','取消前のメモ',{body:textToRichText('😀入力と本文IDを保持する。')});
 project.entities.push(note);
 const bodyBefore=structuredClone(note.data.body),newName='中止後に明示保存する名前';
 await seed(page,project);
 await openRecord(page,'note',note.name);
 const before=await durable(page),beforeSHA=digest(JSON.stringify(before));
 await page.evaluate(()=>{
   const original=crypto.subtle.digest.bind(crypto.subtle);let armed=true;
   const state={waiting:false,started:0,released:false,release:undefined as undefined|(()=>void)};
   (window as typeof window & {__irLongSave?:typeof state}).__irLongSave=state;
   crypto.subtle.digest=async(...args:Parameters<SubtleCrypto['digest']>)=>{
     if(armed){armed=false;state.waiting=true;state.started=performance.now();await new Promise<void>(resolve=>state.release=()=>{state.released=true;resolve();});}
     return original(...args);
   };
 });
 const name=page.getByLabel('名前',{exact:true});await name.fill(newName);
 await page.waitForFunction(()=>(window as typeof window & {__irLongSave?:{waiting:boolean}}).__irLongSave?.waiting);
 // This artificial gate tests functional cancellation/atomicity after 2 seconds.
 // It is not a real data-size performance measurement or a two-hour soak.
 await page.waitForTimeout(2200);
 const cancel=page.getByRole('button',{name:'現在の保存を中止して入力を保持',exact:true});
 await expect(cancel).toBeVisible();await expect(cancel).toBeEnabled();
 await expect(page.getByRole('status').filter({hasText:'作品の保存を検査しています…'})).toBeVisible();
 await expect(name).toHaveValue(newName);
 const held=await page.evaluate(()=>performance.now()-(window as typeof window & {__irLongSave:{started:number}}).__irLongSave.started);
 expect(held).toBeGreaterThanOrEqual(2000);
 await cancel.click();
 await page.evaluate(()=>(window as typeof window & {__irLongSave:{release:()=>void}}).__irLongSave.release());
 const alert=page.locator('.detail-panel').getByRole('alert');await expect(alert).toContainText('取り消し');
 await expect(name).toHaveValue(newName);await page.waitForTimeout(650);
 const afterCancel=await durable(page);expect(afterCancel).toEqual(before);
 await evidence(info,'save-held-cancelled',{proofLayer:'normal frozen production App + native IndexedDB, artificial delayed SHA only',heldMilliseconds:held,performanceResult:'not_measured',soakResult:'not_run',scope:'available cancellation/input/atomicity clauses; does not satisfy the complete Large/long-branch AT-N05 given',alert:await alert.innerText(),beforeSHA,afterCancelSHA:digest(JSON.stringify(afterCancel)),tables:Object.keys(before),allSavedRowsUnchanged:true,inputRetained:newName,stableEntityId:note.id,bodyBefore});
 await nav(page,/^構成/);await nav(page,/^資料/);await page.getByLabel('情報の種類',{exact:true}).selectOption('note');await page.locator('.entity-card').filter({has:page.getByRole('heading',{name:note.name,exact:true})}).click();await expect(name).toHaveValue(newName);await expect(page.locator('.detail-heading')).toContainText(newName);
 await saveEditor(page);await expect(page.locator('.detail-heading')).toContainText(newName);
 const afterRetry=await durable(page);expect(afterRetry).not.toEqual(before);
 expect(afterRetry.commands.length).toBe(before.commands.length+1);expect(afterRetry.outbox.length).toBe(before.outbox.length+1);
 await page.reload();await expect(page.locator('.app-shell')).toBeVisible();
 await openRecord(page,'note',newName);await expect(page.getByLabel('名前',{exact:true})).toHaveValue(newName);
 const file=await backup(page),saved=file.parsed.project.entities.find(e=>e.id===note.id);
 expect(saved?.name).toBe(newName);expect(saved?.data).toMatchObject({body:bodyBefore});
 await evidence(info,'retry-cold-complete',{projectId:project.projectId,entityId:note.id,revision:file.parsed.project.revision,historyCount:file.parsed.project.history.length,archiveBytes:file.bytes.length,archiveSHA256:digest(file.bytes),newName,bodyIDsPreserved:true,originalAcceptancePassesInferred:0,physical:'not_run',actualAuth:'not_run'});
});
