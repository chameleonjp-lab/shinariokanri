import {test,expect} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {inspectScenario} from '../candidate/src/storage/archive';
import {nav,importBytes,durable,evidence,digest,captureProofFile} from './common';
import {reader,begin,openRecord,editData} from './extended-support';

// Small supplementary reproduction for the original N05 then. This does not
// stand in for the full original Large + long-branch given. No result yet.
test('AT-N05 supplementary: cancelled unknown analysis remains openable after a different screen and unsaved input resumes',async({page},info)=>{
 const fixtureBytes=new Uint8Array(await readFile(new URL('../fixtures/n05-original.scenario',import.meta.url))),parsed=await inspectScenario(fixtureBytes,{worker:false}),sceneA=parsed.project.entities.find(e=>e.kind==='scene'&&e.name==='抽選したA'),loopEntry=parsed.project.entities.find(e=>e.kind==='flow_node'&&e.name==='上限未宣言のループ入口');if(!sceneA||!loopEntry)throw Error('Original fixed N05 entities missing');const f={sceneA,loopEntry};await importBytes(page,fixtureBytes);
 await openRecord(page,'scene',f.sceneA.name);
 const draft=await editData(page,()=>{}),draftText=(await draft.inputValue()).slice(0,-1);await draft.fill(draftText);
 await expect(page.locator('.editor-save-state')).toContainText('未保存');
 await reader(page);await begin(page,f.loopEntry.id);
 const before=await durable(page);await page.getByRole('button',{name:'到達性と行き止まりを検査',exact:true}).click();
 await expect(page.getByRole('button',{name:'探索を中止',exact:true})).toBeVisible();await page.getByRole('button',{name:'探索を中止',exact:true}).click();
 await expect(page.locator('.analysis-result-heading')).toContainText('探索打切り');
 const saveBefore=page.waitForEvent('download');await page.getByRole('button',{name:'検査結果を保存',exact:true}).click();
 const originalBytes=await readFile((await(await saveBefore).path())!),original=JSON.parse(originalBytes.toString('utf8'));
 expect(original.truncated).toBe(true);expect(original.status).not.toBe('passed_for_checked_scope');expect(await durable(page)).toEqual(before);await captureProofFile(new Uint8Array(originalBytes),'N05-cancelled-original-result','json');await evidence(info,'N05-before-navigation',{original,nativeBefore:before,cancelledNativeUnchanged:true,fixtureSHA256:digest(fixtureBytes)});
 await nav(page,/^資料/);await reader(page);
 await expect.soft(page.locator('.analysis-result-heading')).toContainText('探索打切り',{timeout:1000});
 let retainedBytes:Buffer|null=null;const saveResult=page.getByRole('button',{name:'検査結果を保存',exact:true});await expect.soft(saveResult).toHaveCount(1);if(await saveResult.count()){const saveAfter=page.waitForEvent('download');await saveResult.click();retainedBytes=await readFile((await(await saveAfter).path())!);}expect.soft(retainedBytes?JSON.parse(retainedBytes.toString('utf8')):null).toEqual(original);const afterNavigation=await durable(page);expect(afterNavigation).toEqual(before);await evidence(info,'N05-after-navigation',{resultRetained:!!retainedBytes,original,beforeNativeSHA:digest(JSON.stringify(before)),afterNativeSHA:digest(JSON.stringify(afterNavigation)),nativeUnchanged:true});
 await openRecord(page,'scene',f.sceneA.name);const advanced=page.locator('details.advanced-details').filter({has:page.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true})});if(await advanced.getAttribute('open')===null)await advanced.locator('summary').click();await expect(advanced.getByRole('textbox',{name:'詳細データ',exact:true})).toHaveValue(draftText);expect(await durable(page)).toEqual(before);
 await evidence(info,'N05-unknown-result-navigation',{fixtureScope:'Small same unbounded branch; full original Large given requires separate actual archive/analysis run',originalResultSHA256:digest(originalBytes),retainedResultSHA256:retainedBytes?digest(retainedBytes):null,allNativeRowsUnchanged:true,unsavedJSONRestored:true,unknownNeverFullSafety:true});
});
