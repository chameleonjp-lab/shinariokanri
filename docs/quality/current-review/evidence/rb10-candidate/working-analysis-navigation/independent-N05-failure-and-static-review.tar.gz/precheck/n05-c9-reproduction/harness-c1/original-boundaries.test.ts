import 'fake-indexeddb/auto';
import {it,expect,afterEach} from 'vitest';
import {combatEnum,travel100,offlineWork,id} from './fixtures';
import {validateProject} from '../candidate/src/domain/model';
import {validateExternalInput} from '../candidate/src/domain/externalInputs';
import {startTrialVerified,replaySavedTraceVerified} from '../candidate/src/domain/runtimeVerified';
import {setTrialStubValues,stepTrial,pinTrialRecord} from '../candidate/src/domain/runtime';
import {inspectWorldCandidates} from '../candidate/src/domain/worldCheck';
import {worldStateCandidates} from '../candidate/src/domain/world';
import {exportScenario,inspectScenario} from '../candidate/src/storage/archive';
import {ScenarioStore} from '../candidate/src/storage/store';

const stores:ScenarioStore[]=[];
const db=()=>{const store=new ScenarioStore({databaseName:'independent-original-'+crypto.randomUUID()});stores.push(store);return store;};
afterEach(async()=>{for(const s of stores.splice(0))await s.deleteDatabase();});

it('AT-F42 enum declared values, unknown/block, wrong type and outside enum are never made actual; stub/native/clone keep true provenance',async()=>{
 const f=combatEnum();expect(validateProject(f.p)).toMatchObject({ok:true});expect(validateExternalInput(f.p,{[f.contract.id]:{type:'boolean',value:true}}).some(i=>i.code==='VALIDATION_FAILED')).toBe(true);expect(validateExternalInput(f.p,{[f.contract.id]:{type:'enum',value:'引き分け'}}).length).toBeGreaterThan(0);expect(validateExternalInput(f.p,{[f.contract.id]:{type:'unknown',value:null,reason:'未取得'}}).some(i=>i.code==='CONDITION_UNKNOWN')).toBe(true);
 const untouched=structuredClone(f.p);let session=await startTrialVerified(f.p,{entryId:f.entry.id});expect(session.status).toBe('unknown');session=setTrialStubValues(f.p,session,{external:{[f.contract.id]:{type:'enum',value:'勝利'}}});expect(session.state.provenance).toBe('stub');session=stepTrial(f.p,session,{});expect(session.status).toBe('terminal');expect(f.p).toEqual(untouched);
 const fixed=pinTrialRecord(session,{checkpointId:id(4291),snapshotId:id(4292)},f.p);const source=db();const {createEntity}=await import('../candidate/src/domain/model');const checkpoint=createEntity(f.p.projectId,'checkpoint','原enumの開始状態',fixed.checkpoint),trace=createEntity(f.p.projectId,'trace','原enumのstub経路',fixed.trace);checkpoint.id=id(4291);trace.id=id(4293);const saved=(await source.saveProject({...f.p,entities:[...f.p.entities,checkpoint,trace],snapshots:[{id:id(4292),versionLabel:'原enum固定版',contentHash:await(await import('../candidate/src/storage/json')).sha256((await import('../candidate/src/storage/json')).jsonBytes(fixed.content)),createdAt:'2026-10-08T00:00:00.000Z',content:fixed.content}]},{reason:'原enumのstub記録'})).project;
 expect((await replaySavedTraceVerified(saved,trace.id)).status).toBe('terminal');const prepared=await inspectScenario(await source.exportProject(saved.projectId),{worker:false}),target=db(),cloned=await target.importScenario(prepared,{mode:'clone'});expect((await replaySavedTraceVerified(cloned.project,cloned.idMap![trace.id])).status).toBe('terminal');const mapped=cloned.project.entities.find(e=>e.id===cloned.idMap![trace.id]);expect(mapped?.kind==='trace'&&mapped.data.externalMode).toBe('stub');
});

it('AT-F11 exact100/min200 plus method/evidence omissions, destruction boundary50 and no permanent name/control overwrite',()=>{
 const f=travel100(),baseline=structuredClone(f.p);expect(validateProject(f.p)).toMatchObject({ok:true});const initial=inspectWorldCandidates(f.p).candidates.filter(c=>c.kind==='travel');expect(initial).toHaveLength(1);expect(initial[0].certainty).toBe('uncertain');expect(initial[0].reason).toContain('移動不可能とは断定しません');
 for(const omission of ['none','method','evidence','minimum'] as const){const p=structuredClone(f.p),r=p.entities.find(e=>e.id===f.route.id);if(r?.kind!=='travel_route')throw Error('fixture');r.data={...r.data,method:omission==='method'?'':'徒歩',evidence:omission==='evidence'?[]:[f.evidence.id],minimumTicks:omission==='minimum'?null:'200'};const candidate=inspectWorldCandidates(p).candidates.find(c=>c.kind==='travel');expect(candidate?.certainty).toBe(omission==='none'?'supported':'uncertain');}
 expect(worldStateCandidates(f.p,f.b.id,'place_state',{at:'49'}).candidates[0].assertion.data.value).toEqual({type:'enum',value:'健在'});expect(worldStateCandidates(f.p,f.b.id,'place_state',{at:'50'}).candidates[0].assertion.data.value).toEqual({type:'enum',value:'破壊済み'});expect(f.p).toEqual(baseline);
});

it('AT-N11/E12 missing material: full export refuses bytes absence, metadata file is not complete restoration and keeps references',async()=>{
 const f=await offlineWork();expect(validateProject(f.p)).toMatchObject({ok:true});await expect(exportScenario(f.p)).rejects.toMatchObject({code:'ASSET_MISSING'});const prepared=await inspectScenario(await exportScenario(f.p,{assetMode:'metadata_only'}),{worker:false});expect(prepared.manifest.assetMode).toBe('metadata_only');expect(prepared.summary.missingAssets).toBe(1);expect(prepared.warnings.length).toBeGreaterThan(0);expect(prepared.project.entities.find(e=>e.id===f.note.id)).toMatchObject({data:{attachmentIds:[f.attachment.id]}});
});

it('AT-E12 migration conversion/validation failures keep same content/history/outbox/assets and an explicit pre-migration restore point',async()=>{
 const f=await offlineWork(),store=db(),saved=(await store.saveProject(f.p,{reason:'キャッシュ済み作品',assets:Object.entries(f.assets).map(([contentHash,bytes])=>({contentHash,bytes,mediaType:'image/png'}))})).project,before=await store.getProject(saved.projectId),pending=await store.listOutbox(saved.projectId),asset=await store.getAsset(f.attachment.data.contentHash);
 await expect(store.migrateProject(saved.projectId,p=>{p.name='採用してはいけない途中稿';throw Error('independent conversion failure');})).rejects.toThrow('independent conversion failure');expect(await store.getProject(saved.projectId)).toEqual(before);expect(await store.listOutbox(saved.projectId)).toEqual(pending);expect(await store.getAsset(f.attachment.data.contentHash)).toEqual(asset);const points=await store.listRestorePoints(saved.projectId);expect(points).toHaveLength(1);expect(points[0].project).toEqual(before);
 await expect(store.migrateProject(saved.projectId,p=>({...p,mainStart:'-0'}))).rejects.toMatchObject({code:'VALIDATION_FAILED'});expect(await store.getProject(saved.projectId)).toEqual(before);expect(await store.listOutbox(saved.projectId)).toEqual(pending);const prepared=await inspectScenario(await store.exportProject(saved.projectId),{worker:false}),restored=await db().importScenario(prepared,{mode:'new'});expect(restored.project.entities.find(e=>e.id===f.note.id)?.data).toEqual(f.note.data);expect(prepared.recovery?.pending.map(o=>o.operationId)).toEqual(pending.map(o=>o.operationId));expect(prepared.assets[0].bytes).toEqual(asset);
});
