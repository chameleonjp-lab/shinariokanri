import {test,expect} from '@playwright/test';
import {createProject,createEntity,textToRichText} from '../candidate/src/domain/model';
import {createWorldSnapshot} from '../candidate/src/domain/world';
import {preparePublicExecution} from '../candidate/src/domain/exportPreparation';
import {createSharedCommentReview,publicationReviewSources,reviewLatestPosition,type SharedComment} from '../candidate/src/domain/sharedReviews';
import {sha256,jsonBytes} from '../candidate/src/storage/json';
import {ids,fixedTime} from './fixtures';
import {evidence} from './common';

test('AT-F29 component: capture a fixed public/private Unicode comment before delayed hash, retain quote after current block deletion',async({},info)=>{
  let p={...createProject('独立F29 capture入力'),projectId:ids(700)};
  const line={...createEntity(p.projectId,'dialogue_line','台詞L',{text:[{id:ids(702),kind:'paragraph' as const,text:'前😀版本1の台詞L'}]}),id:ids(701),status:'confirmed' as const,visibility:'team' as const,createdAt:fixedTime,updatedAt:fixedTime};
  const publicBlocks=[{id:ids(704),kind:'paragraph' as const,text:'前😀版本1の台詞L'}],profile={...createEntity(p.projectId,'projection_profile','F29確認済み範囲',{audience:'reviewer',publicTitle:'公開F29',publicVersionLabel:'版1',includedIds:[line.id],allowedKinds:['dialogue_line'],idPolicy:'remap',namePolicy:{defaultPolicy:{mode:'replace',replacement:'公開台詞L'}},publicTexts:{[line.id]:{text:publicBlocks}},blockSources:{[publicBlocks[0].id]:line.data.text[0].id}}),id:ids(703),status:'confirmed' as const};
  p.entities.push(line,profile);p=await createWorldSnapshot(p,'原版1');const pin=p.snapshots.at(-1)!;
  const prepared=await preparePublicExecution(p,{profile:'reader',projectionProfileId:profile.id,targetVersionId:pin.id}),sourceMap=await publicationReviewSources(p,prepared,pin.id,{}),entity=prepared.projection.entities.find(e=>e.kind==='dialogue_line')!,block=(entity.data.text as {id:string;text:string}[])[0];
  const comment:SharedComment={id:ids(705),snapshot_id:ids(706),public_version_id:'public-project',public_entity_id:entity.id,public_block_id:block.id,start_cp:1,end_cp:3,body:'版1の😀版という範囲への指摘',created_at:fixedTime,resolved:false,review_stage:'open'};
  const envelope={snapshotId:comment.snapshot_id,sourceVersionId:pin.id,sourceHash:pin.contentHash,projectionHash:await sha256(jsonBytes(prepared.projection)),projection:prepared.projection,sourceMap};
  const body=comment.body,bodyHash=await sha256(jsonBytes(body)),digest=crypto.subtle.digest.bind(crypto.subtle);let armed=true,release!:()=>void,entered!:()=>void;
  const waiting=new Promise<void>(resolve=>entered=resolve),gate=new Promise<void>(resolve=>release=resolve);crypto.subtle.digest=async(...args:Parameters<SubtleCrypto['digest']>)=>{if(armed){armed=false;entered();await gate;}return digest(...args);};
  let review:Awaited<ReturnType<typeof createSharedCommentReview>>;
  try{const pending=createSharedCommentReview(p,envelope,comment,'https://independent-reviews.invalid');await waiting;comment.body='呼出後の別の指摘';comment.start_cp=3;comment.end_cp=4;p.snapshots[0].content.entities.find(e=>e.id===line.id)!.name='後発改名';release();review=await pending;}finally{release?.();crypto.subtle.digest=digest;}
  expect(review!.data).toMatchObject({quotedText:'😀版',target:{entityId:line.id,blockId:line.data.text[0].id,start:1,end:3,sourceVersionId:pin.id},sharedSource:{comment:ids(705),startCp:1,endCp:3,commentBodyHash:bodyHash}});expect(review!.data.body.map(b=>b.text).join('')).toBe(body);
  const changed=structuredClone(p);changed.entities=changed.entities.map(e=>e.id===line.id&&e.kind==='dialogue_line'?{...e,data:{...e.data,text:[]}}:e);expect(reviewLatestPosition(changed,review!)).toBe('unknown');expect(review!.data.quotedText).toBe('😀版');
  await evidence(info,'F29-independent-capture-component',{sourcePinId:pin.id,commentAtInvocation:{id:ids(705),body,startCp:1,endCp:3},observedReview:review!,currentDeletedPosition:'unknown',proofLayer:'domain component, no API/Auth/UI execution'});
});
