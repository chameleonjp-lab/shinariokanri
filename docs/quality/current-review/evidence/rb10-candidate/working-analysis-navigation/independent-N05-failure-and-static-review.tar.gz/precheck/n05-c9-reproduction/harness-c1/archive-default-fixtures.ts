import {createHash} from 'node:crypto';
import {zipSync} from 'fflate';
import {createProject} from '../candidate/src/domain/model';
import type {Condition,Entity,ProjectData} from '../candidate/src/domain/types';
import type {ScenarioManifest} from '../candidate/src/storage/archive';

// The original v1 contract values are independent literals, never lowered to
// make a small fixture pass, and never obtained from the product under test.
export const defaultCaps={compressedBytes:64*1024*1024,expandedBytes:256*1024*1024,jsonBytes:64*1024*1024,assetBytes:32*1024*1024,files:5000,records:100000,depth:32,objects:500000,conditionDepth:16,conditionNodes:256,fieldBytes:1024*1024} as const;
export type BoundaryDimension=keyof typeof defaultCaps;
const at='2026-10-08T12:00:00.000Z',uuid=(n:number)=>`d4000000-0000-4000-8000-${n.toString(16).padStart(12,'0')}`;
const encode=(v:unknown)=>new TextEncoder().encode(JSON.stringify(v)),hash=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const objectStats=(v:unknown,depth=1):{objects:number;depth:number}=>{
 if(v===null||typeof v!=='object')return {objects:0,depth:0};
 let objects=1,maximum=depth;
 for(const child of Object.values(v)){const next=objectStats(child,depth+1);objects+=next.objects;maximum=Math.max(maximum,next.depth);}
 return {objects,depth:maximum};
};
function note(p:ProjectData,n:number,text=''):Entity<'note'>{return {id:uuid(n),projectId:p.projectId,kind:'note',revision:'0',name:'境界'+n,status:'confirmed',visibility:'private',createdAt:at,updatedAt:at,customValues:{},data:{body:text?[{id:uuid(n+200000),kind:'paragraph',text}]:[]}};}
function project(dimension:BoundaryDimension,offset:number):ProjectData{return {...createProject(`原v1上限 ${dimension} ${offset}`),projectId:uuid(1)};}
function wav(size:number,number:number){
 if(size<52)throw Error('WAV boundary fixture must contain PCM bytes');
 const b=new Uint8Array(size),v=new DataView(b.buffer),ascii=(o:number,s:string)=>[...s].forEach((c,i)=>b[o+i]=c.charCodeAt(0));
 ascii(0,'RIFF');v.setUint32(4,size-8,true);ascii(8,'WAVE');ascii(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,8000,true);v.setUint32(28,8000,true);v.setUint16(32,1,true);v.setUint16(34,8,true);ascii(36,'data');v.setUint32(40,size-44,true);v.setUint32(44,number,true);v.setUint32(48,number^0xa55a5aa5,true);return b;
}
function attach(p:ProjectData,n:number,bytes:Uint8Array,assets:Record<string,Uint8Array>){
 const sha=hash(bytes),path=`assets/${sha}.wav`;assets[path]=bytes;
 p.entities.push({id:uuid(n),projectId:p.projectId,kind:'attachment',revision:'0',name:'実WAV'+n,status:'confirmed',visibility:'private',createdAt:at,updatedAt:at,customValues:{},data:{contentHash:sha,byteSize:bytes.length,mediaType:'audio/wav',assetPath:path,displayName:`pcm-${n}.wav`,stage:'final'}});
}
function packageFiles(p:ProjectData,assets:Record<string,Uint8Array>={}){
 const data=encode(p),files:Record<string,Uint8Array>={'data/project.json':data,...assets};
 const manifest:ScenarioManifest={format:'scenario-package',formatVersion:'1.0.0',projectId:p.projectId,snapshotId:uuid(2),exportedAt:at,assetMode:'embedded',minimumReaderVersion:'1.0.0',files:Object.entries(files).map(([path,bytes])=>({path,byteSize:bytes.length,sha256:hash(bytes),role:path==='data/project.json'?'project':'asset'}))};
 files['manifest.json']=encode(manifest);return {files,manifest};
}
function astStats(c:Condition,depth=1):{nodes:number;depth:number}{
 const children=c.op==='all'||c.op==='any'?c.children:c.op==='not'?[c.child]:[];
 let nodes=1,maximum=depth;for(const child of children){const next=astStats(child,depth+1);nodes+=next.nodes;maximum=Math.max(maximum,next.depth);}return {nodes,depth:maximum};
}
function flow(p:ProjectData,gate:Condition){p.entities.push({id:uuid(100),projectId:p.projectId,kind:'flow_node',revision:'0',name:'条件境界',status:'confirmed',visibility:'private',createdAt:at,updatedAt:at,customValues:{},data:{nodeType:'choice',sceneId:null,gate,executionPolicy:'manual_choice'}});}
export interface DefaultBoundaryFixture{dimension:BoundaryDimension;offset:number;limit:number;target:number;expectedAccepted:boolean;project:ProjectData;bytes:Uint8Array;sha256:string;metrics:Record<string,unknown>}

// Deliberately deferred. Defining this module never allocates large records or
// bytes; generate one fixture only after the isolated measurement window ends.
export function defaultBoundaryFixture(dimension:BoundaryDimension,offset:-1|0|1):DefaultBoundaryFixture{
 const p=project(dimension,offset),target=defaultCaps[dimension]+offset;let assets:Record<string,Uint8Array>={},level:0|6=6;
 if(dimension==='records')for(let i=0;i<target;i++)p.entities.push(note(p,1000+i));
 else if(dimension==='fieldBytes')p.entities.push(note(p,1000,'X'.repeat(target-4)+'😀'));
 else if(dimension==='conditionDepth'){let c:Condition={op:'constant',value:true};for(let i=1;i<target;i++)c={op:'not',child:c};flow(p,c);}
 else if(dimension==='conditionNodes')flow(p,{op:'all',children:Array.from({length:target-1},()=>({op:'constant' as const,value:true}))});
 else if(dimension==='depth'){
  // Each all+children contributes two JSON-container levels; not contributes
  // one. Keep the AST at16 levels while positioning gate at JSON level5.
  const all=target-20,not=15-all;let c:Condition={op:'constant',value:true};
  for(let i=0;i<not;i++)c={op:'not',child:c};for(let i=0;i<all;i++)c={op:'all',children:[c]};flow(p,c);
 }else if(dimension==='objects'){
  for(let i=0;i<6;i++)p.entities.push(note(p,1000+i));
  const {manifest}=packageFiles(p),base=objectStats(p).objects+objectStats(manifest).objects;let remaining=target-base,block=0;
  for(const record of p.entities){if(record.kind!=='note')throw Error('object fixture');const amount=Math.min(100000,remaining);record.data.body=Array.from({length:amount},()=>({id:uuid(300000+block++),kind:'paragraph' as const,text:''}));remaining-=amount;}
  if(remaining!==0)throw Error('default object budget recipe exceeded array bound');
 }else if(dimension==='jsonBytes'){
  for(let i=0;i<64;i++)p.entities.push(note(p,1000+i,'X'.repeat(i<63?defaultCaps.fieldBytes:1)));
  const last=p.entities.at(-1)!;if(last.kind!=='note')throw Error('JSON fixture');
  for(let pass=0;pass<4;pass++){const difference=target-encode(p).length;if(!difference)break;last.data.body[0].text+='X'.repeat(Math.max(0,difference));if(difference<0)last.data.body[0].text=last.data.body[0].text.slice(0,difference);}
 }else if(dimension==='files'){
  for(let i=0;i<target-2;i++)attach(p,1000+i,wav(52,i),assets);
 }else if(dimension==='assetBytes')attach(p,1000,wav(target,0),assets);
 else if(dimension==='compressedBytes'||dimension==='expandedBytes'){
  const count=dimension==='compressedBytes'?3:8,initial=dimension==='compressedBytes'?21*1024*1024:defaultCaps.assetBytes;
  level=dimension==='compressedBytes'?0:6;let lastSize=initial;
  for(let pass=0;pass<6;pass++){
   p.entities=[];assets={};for(let i=0;i<count;i++)attach(p,1000+i,wav(i===count-1?lastSize:initial,i),assets);
   const {files}=packageFiles(p,assets),actual=dimension==='compressedBytes'?zipSync(files,{level,mtime:new Date(at)}).length:Object.values(files).reduce((s,b)=>s+b.length,0);
   const difference=target-actual;if(!difference)break;lastSize+=difference;
   if(lastSize<52||lastSize>defaultCaps.assetBytes)throw Error('container boundary fixture would violate separate asset limit');
  }
 }
 const {files,manifest}=packageFiles(p,assets),bytes=zipSync(files,{level,mtime:new Date(at)}),stats=objectStats(p),ms=objectStats(manifest),gate=p.entities.find((e):e is Entity<'flow_node'>=>e.kind==='flow_node')?.data.gate;
 let maximumFieldBytes=0;
 const utf8=new TextEncoder();for(const record of p.entities)if(record.kind==='note')for(const block of record.data.body)maximumFieldBytes=Math.max(maximumFieldBytes,utf8.encode(block.text).length);
 const metrics={compressedBytes:bytes.length,expandedBytes:Object.values(files).reduce((s,b)=>s+b.length,0),jsonBytes:files['data/project.json'].length,assetBytes:Object.values(assets).reduce((maximum,b)=>Math.max(maximum,b.length),0),files:Object.keys(files).length,records:p.entities.length+p.relations.length,objects:stats.objects+ms.objects,depth:Math.max(stats.depth,ms.depth),conditionDepth:gate?astStats(gate).depth:0,conditionNodes:gate?astStats(gate).nodes:0,fieldBytes:maximumFieldBytes,assets:Object.entries(assets).map(([path,b])=>({path,sha256:hash(b),bytes:b.length})),projectSHA256:hash(files['data/project.json']),manifestSHA256:hash(files['manifest.json'])};
 if(metrics[dimension]!==target)throw Error(`Independent fixture recipe ${dimension} expected exact${target}, actual${metrics[dimension]}`);
 return {dimension,offset,limit:defaultCaps[dimension],target,expectedAccepted:offset<=0,project:p,bytes,sha256:hash(bytes),metrics};
}
