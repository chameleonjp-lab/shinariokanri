import {test,expect} from '@playwright/test';
import {combatFixture,travelFixture} from './fixtures';
import {startTrialVerified} from '../candidate/src/domain/runtimeVerified';
import {inspectWorldCandidates} from '../candidate/src/domain/worldCheck';
import {createWorldAssessment,WORLD_PREDICATES} from '../candidate/src/domain/world';
import {evidence} from './common';

// These are domain component checks. They are never labeled App/native/device proof.
test('AT-F42 component: unreceived enum, wrong type and out-of-set value stop without certification',async({},info)=>{
  const f=combatFixture(),source=structuredClone(f.p),missing=await startTrialVerified(f.p),wrong=await startTrialVerified(f.p,{externalValues:{[f.contract.id]:{type:'boolean',value:true}}}),outside=await startTrialVerified(f.p,{externalValues:{[f.contract.id]:{type:'enum',value:'引き分け'}}});
  expect(missing.status).toBe('unknown');expect(wrong.status).toBe('error');expect(outside.status).toBe('error');expect([missing,wrong,outside].every(s=>s.state.provenance!=='full_play'||s.status!=='terminal')).toBe(true);expect(f.p).toEqual(source);await evidence(info,'F42-type-missing-components',{missing,wrong,outside,sourceUnchanged:true,proofLayer:'domain component'});
});
test('AT-F11 component: each missing method/evidence/time remains uncertain; period boundary never mutates place identity',async({},info)=>{
  const f=travelFixture(),checks=[];
  for(const patch of [{minimumTicks:null,method:'徒歩',evidence:[f.evidence.id]},{minimumTicks:'200',method:'',evidence:[f.evidence.id]},{minimumTicks:'200',method:'徒歩',evidence:[]}]){const p=structuredClone(f.p);p.entities=p.entities.map(e=>e.id===f.route.id&&e.kind==='travel_route'?{...e,data:{...e.data,...patch}}:e);const report=inspectWorldCandidates(p);expect(report.candidates.find(c=>c.kind==='travel')?.certainty).toBe('uncertain');expect(report.candidates.find(c=>c.kind==='travel')?.reason).toContain('未確認');checks.push(report);}
  const source=structuredClone(f.p),before=createWorldAssessment(f.p,{at:'49'}),after=createWorldAssessment(f.p,{at:'50'});expect(before.stateCandidates(f.b.id,WORLD_PREDICATES.placeState).candidates.map(c=>c.assertion.data.value)).toEqual([{type:'enum',value:'破壊前'}]);expect(after.stateCandidates(f.b.id,WORLD_PREDICATES.placeState).candidates.map(c=>c.assertion.data.value)).toEqual([{type:'enum',value:'破壊済み'}]);expect(f.p).toEqual(source);await evidence(info,'F11-missing-components',{checks,sourceUnchanged:true,proofLayer:'domain component'});
});
