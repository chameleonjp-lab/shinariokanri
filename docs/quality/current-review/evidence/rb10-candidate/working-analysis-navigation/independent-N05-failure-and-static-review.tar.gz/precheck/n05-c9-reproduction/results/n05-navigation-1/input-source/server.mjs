import { createServer } from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import { dirname, resolve, sep, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
const home=dirname(fileURLToPath(import.meta.url)), port=Number(process.argv[process.argv.indexOf('--port')+1]);
if (!Number.isInteger(port)||port<5300||port>5399) throw Error('Independent port must be in 5300–5399.');
const root=await realpath(resolve(home,'candidate/dist'));
const binding=JSON.parse(await readFile(resolve(home,'candidate-binding.json'),'utf8'));
const info=JSON.parse(await readFile(resolve(root,'build-info.json'),'utf8'));
if(info.commit!==binding.commit||info.tree&&info.tree!==binding.tree||info.dirty!==false||info.base!=='/shinariokanri/') throw Error('Unbound or dirty candidate build.');
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.mp4':'video/mp4','.woff2':'font/woff2'};
const server=createServer(async(req,res)=>{
  try{
    const u=new URL(req.url??'/','http://localhost');
    if(u.pathname==='/__review_native__.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Independent native IndexedDB fixture origin</title>');return;}
    if(!u.pathname.startsWith('/shinariokanri/')){res.writeHead(404).end();return;}
    const relative=decodeURIComponent(u.pathname.slice('/shinariokanri/'.length))||'index.html';
    const file=await realpath(resolve(root,relative));if(!file.startsWith(root+sep))throw Error('Path outside isolated build.');
    res.setHeader('Content-Type',mime[extname(file)]??'application/octet-stream');res.setHeader('Cache-Control','no-cache');res.end(await readFile(file));
  }catch{res.writeHead(404).end();}
});
server.listen(port,'127.0.0.1',()=>process.stdout.write(JSON.stringify({port,commit:binding.commit,tree:binding.tree,build:info.version})+'\n'));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{server.closeAllConnections();server.close(()=>process.exit(0));});
