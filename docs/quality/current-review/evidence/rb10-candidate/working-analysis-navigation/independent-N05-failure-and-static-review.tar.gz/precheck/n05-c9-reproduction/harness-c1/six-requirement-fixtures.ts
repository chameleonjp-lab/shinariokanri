import {createEntity,createProject,emptyValidity,textToRichText} from '../candidate/src/domain/model';
import type {Entity,EntityDataMap,EntityKind,ProjectData} from '../candidate/src/domain/types';
import {fixedTime,ids} from './fixtures';

function add<K extends EntityKind>(p:ProjectData,n:number,kind:K,name:string,data:Partial<EntityDataMap[K]>={}):Entity<K>{
 const value=createEntity(p.projectId,kind,name,data);value.id=ids(n);value.status='confirmed';value.createdAt=value.updatedAt=fixedTime;p.entities.push(value);return value;
}

/** Original AT-F05 values are independently specified, including null rather than zero. */
export function tensionThree(){
 const p={...createProject('原F05 緊張度2・8・未入力の三場面'),projectId:ids(4300)};
 const two=add(p,4301,'scene','緊張度2の場面',{body:textToRichText('二の場面'),tension:2}),eight=add(p,4302,'scene','緊張度8の場面',{body:textToRichText('八の場面'),tension:8}),missing=add(p,4303,'scene','緊張度未入力の場面',{body:textToRichText('未入力の場面'),tension:null});
 const chapter=add(p,4304,'chapter','三場面の章',{sceneIds:[two.id,eight.id,missing.id]});
 for(const scene of [two,eight,missing])scene.data.chapterId=chapter.id;
 return {p,two,eight,missing,chapter};
}

/** Original AT-F40 boolean/enum and two simultaneous automatic candidates. */
export function keyDayNight(){
 const p={...createProject('原F40 鍵booleanと時刻enum昼・夜'),projectId:ids(4400)};
 const key=add(p,4401,'variable','鍵あり',{key:'literal_key',valueType:'boolean',scope:'run',initial:{type:'boolean',value:false},allowed:{values:[false,true]}}),clock=add(p,4402,'variable','時刻enum昼・夜',{key:'literal_day_night',valueType:'enum',scope:'run',initial:{type:'enum',value:'昼'},allowed:{values:['昼','夜']}});
 const entry=add(p,4403,'flow_node','括弧付き条件の入口',{nodeType:'automatic',executionPolicy:'first_match',gate:{op:'constant',value:true}}),a=add(p,4404,'flow_node','自動候補Aの終端',{nodeType:'terminal',terminalReason:'候補Aを意図して完了'}),b=add(p,4405,'flow_node','自動候補Bの終端',{nodeType:'terminal',terminalReason:'候補Bを意図して完了'});
 const edgeA=add(p,4406,'flow_edge','同時成立する自動候補A',{fromId:entry.id,toId:a.id,edgeType:'automatic',label:'同時成立する自動候補A',condition:{op:'constant',value:true},priority:0}),edgeB=add(p,4407,'flow_edge','同時成立する自動候補B',{fromId:entry.id,toId:b.id,edgeType:'automatic',label:'同時成立する自動候補B',condition:{op:'constant',value:true},priority:1});
 const graph=add(p,4408,'flow_graph','二つの自動候補',{nodeIds:[entry.id,a.id,b.id],edgeIds:[edgeA.id,edgeB.id],entryIds:[entry.id],exitIds:[a.id,b.id]});
 const personA=add(p,4409,'character','幅操作の人物A',{body:textToRichText('😀人物Aの保存本文')}),personB=add(p,4410,'character','幅操作の人物B',{body:textToRichText('人物Bの保存本文')});
 p.relations.push({id:ids(4411),projectId:p.projectId,revision:'0',fromId:personA.id,toId:personB.id,relationType:'trust',direction:'forward',validity:emptyValidity(),evidenceIds:[],status:'confirmed',visibility:'private'});
 return {p,key,clock,entry,a,b,edgeA,edgeB,graph,personA,personB,relation:p.relations[0]};
}
