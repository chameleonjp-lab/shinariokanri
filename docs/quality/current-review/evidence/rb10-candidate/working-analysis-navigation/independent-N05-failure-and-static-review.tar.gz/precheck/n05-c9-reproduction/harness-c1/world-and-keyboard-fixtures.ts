import {createEntity,createProject,newId,textToRichText} from '../candidate/src/domain/model';
import {createWorldSnapshot} from '../candidate/src/domain/world';
import type {EntityDataMap,EntityKind,ProjectData} from '../candidate/src/domain/types';
import {fixedTime} from './fixtures';

function add<K extends EntityKind>(p:ProjectData,kind:K,name:string,data:Partial<EntityDataMap[K]>={}){
 const e=createEntity(p.projectId,kind,name,data);e.status='confirmed';e.createdAt=e.updatedAt=fixedTime;p.entities.push(e);return e;
}

/** This constructs the original given only. W2 and Q's change must use the App. */
export async function twoWorksFixedWorld(){
 let w=createProject('原F09共通世界W');
 const lore=add(w,'lore','版を固定する共通設定',{body:textToRichText('世界公開版1の設定😀。後の改稿で変えない。')});
 const variable=add(w,'variable','公開版1だけ真の条件',{key:'fixed_world_gate',valueType:'boolean',initial:{type:'boolean',value:true},scope:'run'});
 w=await createWorldSnapshot(w,'世界公開版1');const oldPin=w.snapshots.at(-1)!;
 const work=async(name:string)=>{
  let p=createProject(name);p.mainStart='-10';p.worldReferences=[{projectId:w.projectId,immutableSnapshotId:oldPin.id,contentHash:oldPin.contentHash}];
  p.views=[{id:newId(),name:'共通設定の明示採用',view:`world-adoption:${w.projectId}`,entityIds:[lore.id],settings:{worldProjectId:w.projectId,snapshotId:oldPin.id}}];
  const body=textToRichText('😀旧世界の設定を読む。');body[0].links=[{start:1,end:4,target:{entityId:lore.id,sourceVersionId:oldPin.id,blockId:lore.data.body[0].id,start:0,end:8}}];
  const scene=add(p,'scene',name+'の固定引用本文',{body});
  const gate={op:'compare' as const,variableId:variable.id,comparator:'eq' as const,value:{type:'boolean' as const,value:true}};
  const entry=add(p,'flow_node',name+'の旧世界条件入口',{nodeType:'entry',sceneId:scene.id,gate,executionPolicy:'manual_choice'}),end=add(p,'flow_node',name+'の終端',{nodeType:'terminal',terminalReason:'公開版1の条件と引用を確認'});
  const edge=add(p,'flow_edge','旧世界の真条件で進む',{fromId:entry.id,toId:end.id,label:'旧世界の真条件で進む',condition:structuredClone(gate)});
  const graph=add(p,'flow_graph',name+'の宣言図',{nodeIds:[entry.id,end.id],edgeIds:[edge.id],entryIds:[entry.id],exitIds:[end.id]});
  p=await createWorldSnapshot(p,name+'公開版1');return {p,scene,entry,end,edge,graph,publication:p.snapshots.at(-1)!};
 };
 return {w,oldPin,lore,variable,P:await work('原F09旧作P'),Q:await work('原F09続編Q')};
}
