import {test,expect,type Page} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {createEntity,createProject,textToRichText} from '../candidate/src/domain/model';
import {DomainValidationError,evaluateCondition} from '../candidate/src/domain/conditions';
import {conditionInputError} from '../candidate/src/domain/conditionDraft';
import {startTrial} from '../candidate/src/domain/runtime';
import type {Entity,ProjectData,Condition} from '../candidate/src/domain/types';
import {createHttpContract,type HttpContract} from '../candidate/tests/e2e/httpContract';
import {commonCondition} from './composite-fixtures';
import {seed,nav,backup,durable,injectQuota,evidence,digest} from './common';
import {openRecord,saveEditor,editData,reader,begin,recordTrial} from './extended-support';

async function downloadDiagnostics(page:Page){
 const details=page.getByLabel('任意持出し診断',{exact:true});
 if(await details.getAttribute('open')===null)await details.locator('summary').click();
 const button=details.getByRole('button',{name:'確認した診断をファイルに持出す',exact:true});
 await expect(button).toBeEnabled();const pending=page.waitForEvent('download');await button.click();
 const file=await pending;expect(await file.failure()).toBeNull();const bytes=new Uint8Array(await readFile((await file.path())!));
 return {bytes,raw:Buffer.from(bytes).toString(),value:JSON.parse(Buffer.from(bytes).toString())};
}

test('AT-N15/N18 same manuscript work: failed atomic save + synthetic Auth failure keep inputs; diagnostics disclose only selected metadata and never send prose',async({page,context},info)=>{
 const p=createProject('__N15_SECRET_WORK__'),note=createEntity(p.projectId,'note','__N15_SECRET_NAME__',{body:textToRichText('__N15_SECRET_MANUSCRIPT__😀')});p.entities.push(note);
 const observed:{url:string;method:string;body:string|null}[]=[],downloads:string[]=[],consoleText:string[]=[];
 const requests=(request:{url():string;method():string;postData():string|null})=>observed.push({url:request.url(),method:request.method(),body:request.postData()});
 context.on('request',requests);page.on('download',download=>downloads.push(download.suggestedFilename()));page.on('console',message=>consoleText.push(message.text()));
 let contract:HttpContract|undefined;
 try{
  const input=await seed(page,p);await openRecord(page,'note',note.name);const before=await durable(page),name=page.getByLabel('名前',{exact:true});
  await injectQuota(page,'__N15_SECRET_MANUSCRIPT__😀 private stack access_token');await name.fill('__N15_SECRET_DRAFT__');
  await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('容量');await expect(name).toHaveValue('__N15_SECRET_DRAFT__');await expect(page.locator('.editor-save-state')).toContainText('未保存');expect(await durable(page)).toEqual(before);expect(downloads).toEqual([]);
  contract=await createHttpContract(async route=>{
   if(route.request().method()==='OPTIONS')return route.fulfill({status:204});
   return route.fulfill({status:401,json:{message:'__N15_SECRET_MANUSCRIPT__ private auth stack',access_token:'__N15_PRIVATE_TOKEN__'}});
  });
  await page.getByRole('button',{name:'アカウント・専用同期',exact:true}).click();const account=page.getByRole('region',{name:'アカウントと専用接続先',exact:true});
  await account.getByLabel('専用Supabase URL',{exact:true}).fill(contract.url);await account.getByLabel('公開用APIキー',{exact:true}).fill('sb_publishable_N15_private_fixture');await account.getByRole('button',{name:'接続設定を保持',exact:true}).click();
  await account.getByLabel('メール',{exact:true}).fill('__N15_PRIVATE_AUTHOR__@example.invalid');await account.getByLabel('パスワード',{exact:true}).fill('__N15_PRIVATE_PASSWORD__');await account.getByRole('button',{name:'認証してアカウント領域を開く',exact:true}).click();
  await expect(account.getByRole('alert')).toContainText('AUTH_REQUIRED');await expect(page.locator('.editor-save-state')).toContainText('未保存');expect(await durable(page)).toEqual(before);expect(downloads).toEqual([]);
  const diagnostics=await downloadDiagnostics(page),rows=diagnostics.value.records as {code:string;operationId:string|null;revision:string|null;metadata:Record<string,unknown>}[];
  const failedSave=rows.find(row=>row.code==='QUOTA_EXCEEDED'),failedAuth=rows.find(row=>row.code==='AUTH_REQUIRED');expect(failedSave).toBeTruthy();expect(failedAuth).toBeTruthy();
  expect(failedSave!.operationId).toMatch(/^[0-9a-f-]{36}$/);expect(failedSave!.revision).toMatch(/^\d+$/);expect(failedAuth!.operationId).toMatch(/^[0-9a-f-]{36}$/);
  for(const row of rows){expect(row.metadata.base).toBe('/shinariokanri/');expect(row.metadata.commit).toMatch(/^[0-9a-f]{40}$/);expect(row.metadata.tree).toMatch(/^[0-9a-f]{40}$/);expect(row.metadata.browser).toBe('Chromium');expect(row.metadata.width).toBeGreaterThan(0);}
  for(const forbidden of ['__N15_','private','stack','access_token','publishable','@','password'])expect(diagnostics.raw).not.toContain(forbidden);
  expect(downloads).toHaveLength(1);expect(observed.some(row=>row.url.startsWith(contract!.url+'/auth/v1/token')&&row.method==='POST')).toBe(true);
  for(const row of observed){expect(row.body??'').not.toContain('__N15_SECRET_');const address=new URL(row.url);expect(address.hostname).toBe('127.0.0.1');}
  expect(consoleText.join('\n')).not.toContain('__N15_SECRET_MANUSCRIPT__');
  await page.getByRole('button',{name:'アカウント・専用同期',exact:true}).click();await nav(page,/^構成/);await openRecord(page,'note',note.name);await expect(name).toHaveValue('__N15_SECRET_DRAFT__');
  const beforeReference=await durable(page);await editData(page,data=>{data.originNoteId='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';});await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/参照|見つか|存在/);expect(await durable(page)).toEqual(beforeReference);await expect(name).toHaveValue('__N15_SECRET_DRAFT__');
  await editData(page,data=>{delete data.originNoteId;});await saveEditor(page);await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');await page.reload();const complete=await backup(page);expect(complete.parsed.project.entities.find(row=>row.id===note.id)).toMatchObject({name:'__N15_SECRET_DRAFT__',data:{body:note.data.body}});
  await evidence(info,'N15-same-work-diagnostic',{fixtureSHA256:digest(input),diagnosticSHA256:digest(diagnostics.bytes),codes:rows.map(row=>row.code),operationIds:rows.map(row=>row.operationId),beforeSHA256:digest(JSON.stringify(before)),saveAndReferenceFailuresAtomic:true,requestCount:observed.length,requestBodySHAs:observed.filter(row=>row.body).map(row=>digest(row.body!)),userSelectedDownloadCountBeforeBackup:1,manuscriptSent:false,completeFileSHA256:digest(complete.bytes),authorityScope:'Synthetic401 over localhost HTTP only. Real Auth/RLS/private Storage not_run.'});
 }finally{context.off('request',requests);await contract?.close();}
});

function row<K extends Entity['kind']>(p:ProjectData,id:string,kind:K){const entity=p.entities.find(e=>e.id===id);expect(entity?.kind).toBe(kind);return entity as Entity<K>;}
function pureError(f:ReturnType<typeof commonCondition>,condition:Condition){
 try{evaluateCondition(condition,{state:startTrial(f.p,{entryId:f.entry.id}).startState,entities:f.p.entities});throw Error('Invalid comparison was accepted');}
 catch(error){expect(error).toBeInstanceOf(DomainValidationError);return (error as DomainValidationError).issues;}
}

test('AT-N16 one condition edited at entry, edge list, and detailed disclosure: shared true/false/invalid rules + stable IDs survive atomic save/cold/chapter/branch',async({page},info)=>{
 const f=commonCondition(),fixture=await seed(page,f.p),initialIds=f.p.entities.map(e=>e.id);
 await openRecord(page,'flow_node',f.entry.name);const gate=page.locator('[data-field="gate"]');await gate.getByLabel('真偽値',{exact:true}).selectOption('false');await saveEditor(page);
 await nav(page,/^構成/);await page.getByRole('tab',{name:'分岐',exact:true}).click();await openRecord(page,'flow_edge',f.edge.name);const condition=page.locator('[data-field="condition"]');await condition.getByLabel('真偽値',{exact:true}).selectOption('false');await saveEditor(page);
 await openRecord(page,'disclosure',f.disclosure.name);await editData(page,data=>{data.condition=structuredClone(f.falseCondition);});await saveEditor(page);const falseFile=await backup(page),p=falseFile.parsed.project;
 const states=startTrial(p,{entryId:f.entry.id}).startState;for(const value of [row(p,f.entry.id,'flow_node').data.gate!,row(p,f.edge.id,'flow_edge').data.condition!,row(p,f.disclosure.id,'disclosure').data.condition!]){expect(value).toEqual(f.falseCondition);expect(evaluateCondition(value,{state:states,entities:p.entities}).value).toBe('false');}expect(p.entities.map(e=>e.id)).toEqual(initialIds);
 await reader(page);await begin(page,f.entry.id);await expect(page.locator('.reader-trial-heading')).toContainText('進行不可');await expect(page.locator('.reader-choices').getByRole('button',{name:new RegExp(f.edge.data.label!)})).toBeDisabled();
 await openRecord(page,'flow_node',f.entry.name);const beforeInvalid=await durable(page),invalidMessage=conditionInputError(f.invalidCondition,f.p)!;expect(pureError(f,f.invalidCondition).every(issue=>issue.code==='VALIDATION_FAILED')).toBe(true);
 await editData(page,data=>{data.gate=structuredClone(f.invalidCondition);});await expect(page.locator('[data-field="gate"]').getByRole('alert')).toContainText(invalidMessage);await expect(page.locator('.editor-footer').getByRole('button',{name:'保存する',exact:true})).toBeDisabled();expect(await durable(page)).toEqual(beforeInvalid);
 await nav(page,/^構成/);await openRecord(page,'flow_node',f.entry.name);await expect(page.locator('[data-field="gate"]').getByRole('alert')).toContainText(invalidMessage);expect(await durable(page)).toEqual(beforeInvalid);
 await page.locator('[data-field="gate"]').getByLabel('比較演算',{exact:true}).selectOption('eq');await page.locator('[data-field="gate"]').getByLabel('真偽値',{exact:true}).selectOption('true');await saveEditor(page);
 await openRecord(page,'flow_edge',f.edge.name);await editData(page,data=>{data.condition=structuredClone(f.trueCondition);});await saveEditor(page);
 await openRecord(page,'disclosure',f.disclosure.name);await page.locator('[data-field="condition"]').getByLabel('真偽値',{exact:true}).selectOption('true');await saveEditor(page);await page.reload();const trueFile=await backup(page);expect(trueFile.parsed.project.entities.map(e=>e.id)).toEqual(initialIds);
 for(const value of [row(trueFile.parsed.project,f.entry.id,'flow_node').data.gate!,row(trueFile.parsed.project,f.edge.id,'flow_edge').data.condition!,row(trueFile.parsed.project,f.disclosure.id,'disclosure').data.condition!])expect(value).toEqual(f.trueCondition);
 await reader(page);await begin(page,f.entry.id);await expect(page.locator('.reader-trial-heading')).toContainText('試読中');await page.locator('.reader-choices').getByRole('button',{name:f.edge.data.label!,exact:true}).click();await expect(page.locator('.reader-trial-heading')).toContainText('意図した終端');await recordTrial(page);const branch=await backup(page),flow=branch.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace')!;
 await nav(page,/^構成/);await page.getByRole('tab',{name:'章の試読',exact:true}).click();await page.getByRole('button',{name:/^(記録付き読書を始める|読み直す)$/}).click();await page.getByRole('button',{name:'次の場面を提示',exact:true}).click();await expect(page.getByRole('button',{name:'全場面を提示しました',exact:true})).toBeDisabled();await page.getByRole('button',{name:'開始状態と経路を保存',exact:true}).click();await expect(page.getByText('開始状態と実際に提示した場面を保存しました。',{exact:true})).toBeVisible();const saved=await backup(page),chapter=saved.parsed.project.entities.find((e):e is Entity<'trace'>=>e.kind==='trace'&&e.data.mode==='chapters')!;
 expect(chapter.data.readingPath!.occurrences[0].conditionResults.find(result=>result.targetId===f.disclosure.id)?.value).toBe('true');const checkpoint=row(saved.parsed.project,flow.data.startCheckpointId,'checkpoint');expect(checkpoint.data.presentationResults?.find(result=>result.targetId===f.disclosure.id)?.value).toBe('true');
 await evidence(info,'N16-shared-rule-and-IDs',{fixtureSHA256:digest(fixture),falseArchiveSHA256:digest(falseFile.bytes),trueArchiveSHA256:digest(trueFile.bytes),finalArchiveSHA256:digest(saved.bytes),originalIds:initialIds,trueCondition:f.trueCondition,falseCondition:f.falseCondition,invalidCondition:f.invalidCondition,pureErrorCodes:pureError(f,f.invalidCondition).map(issue=>issue.code),normalGuardMessage:invalidMessage,invalidAllCanonicalRowsUnchanged:true,chapterTrace:chapter.id,branchTrace:flow.id,proofLimit:'The normal UI exposes a shared guard message; error-code equivalence is separately observed at the pure common contract. No UI-only error-code display is inferred.'});
});
