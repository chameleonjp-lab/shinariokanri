import json,pathlib
template=pathlib.Path('/tmp/shinariokanri-archive-c15-completed-local-1.py').read_text()
namespace={}
exec(template[:template.index("\n\nCOMMIT='6ed5654")],namespace)
namespace['COMMIT']='6ed5654ca6226061a48651dd317ce1a922c5d07b'
namespace['TREE']='2e1650180b7769e8a2e59a6a01510c8d64bdac8b'
base=pathlib.Path('/tmp/shinariokanri-rb10-candidate-15')
out=pathlib.Path('/workspace/shinariokanri-rb10-final-candidate-evidence/docs/quality/current-review/evidence/rb10-candidate/candidate-15-large-preparation-failures-1')
assert not out.exists();out.mkdir(parents=True)
pairs=namespace['enumerate_folder'](base/'large-concurrent-preparation-failures-1','actual-failed-preparation')
for name in ['source-and-build-binding.json','ci-artifacts-final.json','ci-artifact-download-adjudication.json']:
    pairs.append((base/name,pathlib.PurePosixPath('binding-and-artifact-adjudication')/name))
pairs.append((pathlib.Path(__file__),pathlib.PurePosixPath('archive-procedure')/pathlib.Path(__file__).name))
# Signed temporary URLs/FileService transport reference are deliberately absent.
assert not any('reference-private' in str(p) for p,_ in pairs)
r=namespace['bundle'](out,'actual-failed-large-preparation-helper-inputs-raw-and-oom',pairs,'C15 originalLarge initial soak/recovery preparation each Target crashed while root concurrently launched twoLarge seeds with two other restoration browsers. cgroup OOM0→11/kills0→2; fixture not completed, actual7200 interval not started. Preserve actual source binding/procedure/generated entry/compiled13/raw/log/status; isolate retries using unchanged originalfixture and limits. Product unadjudicated. CI artifact metadata/reference only, actualZIP403/zero localbytes. Signed temporaryURLs excluded.')
summary={'candidate':'C15','commit':namespace['COMMIT'],'tree':namespace['TREE'],'build':'d0fc32b97242aa86b09f','result':'not_run_soak_or_recovery_actual_operations_initial_concurrent_preparation_OOM','productResult':'unadjudicated_pending_isolated_reexecution','actualSoakStarted':False,'originalLimitsUnchanged':True,'ciArtifactZIP':'not_downloaded_HTTP403','archive':r}
(out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(out/'MANIFEST.json').write_text(json.dumps({'candidate':'C15','commit':namespace['COMMIT'],'tree':namespace['TREE'],'allArchiveMembersByteVerified':True,'files':[namespace['descriptor'](p,p.name) for p in sorted(out.iterdir()) if p.is_file()]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r,ensure_ascii=False))
