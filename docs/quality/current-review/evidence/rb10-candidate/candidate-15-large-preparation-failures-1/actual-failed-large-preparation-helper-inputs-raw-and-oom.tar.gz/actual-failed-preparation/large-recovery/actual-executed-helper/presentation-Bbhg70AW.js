//#region src/storage/errors.ts
var e = class extends Error {
	code;
	path;
	constructor(e, t, n, r) {
		super(t, r), this.name = "StorageError", this.code = e, this.path = n;
	}
};
function t(t) {
	if (t?.aborted) throw new e("CANCELLED", "処理を取り消しました。既存の作品は変更していません。");
}
function n(t) {
	if (t instanceof e) return t;
	let n = t instanceof Error && /quota/i.test(t.name + t.message);
	return new e(n ? "QUOTA_EXCEEDED" : "SAVE_FAILED", n ? "保存容量が不足しています。入力を保持して完全ファイルへ書き出すか、容量を確保して再試行してください。" : "端末内への保存に失敗しました。入力を保持して再試行してください。", void 0, { cause: t });
}
//#endregion
//#region src/storage/json.ts
var r = "1.0.0", i = Object.freeze({
	compressedBytes: 67108864,
	expandedBytes: 268435456,
	jsonBytes: 67108864,
	assetBytes: 33554432,
	files: 5e3,
	records: 1e5,
	depth: 32,
	objects: 5e5,
	conditionDepth: 16,
	conditionNodes: 256,
	fieldBytes: 1048576
});
function a(e) {
	for (let t = 0; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(++t);
			if (!(n >= 56320 && n <= 57343)) return !1;
		} else if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function o(t, n, r = i, o = { objects: 0 }) {
	if (t.byteLength > r.jsonBytes) throw new e("LIMIT_EXCEEDED", "JSONファイルが上限を超えています。", n);
	if (t[0] === 239 && t[1] === 187 && t[2] === 191) throw new e("ARCHIVE_INVALID", "JSONのBOMは使用できません。", n);
	let s;
	try {
		s = new TextDecoder("utf-8", { fatal: !0 }).decode(t);
	} catch (t) {
		throw new e("ARCHIVE_INVALID", "JSONは有効なUTF-8である必要があります。", n, { cause: t });
	}
	let c = 0, l = (t) => {
		throw new e("ARCHIVE_INVALID", `${t}（位置 ${c}）`, n);
	}, u = () => {
		for (; /[ \t\n\r]/.test(s[c] ?? "") && c < s.length;) c++;
	};
	function d() {
		let e = c++;
		for (; c < s.length;) {
			let t = s[c++];
			if (t === "\"") {
				let t;
				try {
					t = JSON.parse(s.slice(e, c));
				} catch {
					return l("文字列が不正です。");
				}
				return a(t) ? t : l("Unicodeのサロゲートが不正です。");
			}
			t === "\\" && c++;
		}
		return l("文字列が閉じられていません。");
	}
	function f(t) {
		u();
		let i = s[c];
		if (i === "\"") return d();
		if (i === "{" || i === "[") {
			if (t > r.depth || ++o.objects > r.objects) throw new e("LIMIT_EXCEEDED", "JSONの構造が安全上限を超えています。", n);
			let a = i === "{";
			c++, u();
			let p = a ? "}" : "]", m = a ? Object.create(null) : [], h = /* @__PURE__ */ new Set();
			if (s[c] === p) return c++, m;
			for (; c < s.length;) {
				if (u(), a) {
					if (s[c] !== "\"") return l("オブジェクトのkeyが不正です。");
					let e = d();
					if (h.has(e)) return l(`key「${e}」が重複しています。`);
					if (h.add(e), u(), s[c++] !== ":") return l("keyの後にコロンが必要です。");
					m[e] = f(t + 1);
				} else m.push(f(t + 1));
				u();
				let e = s[c++];
				if (e === p) return m;
				if (e !== ",") return l("区切り文字が不正です。");
			}
			return l("JSONが閉じられていません。");
		}
		for (let [e, t] of [
			["true", !0],
			["false", !1],
			["null", null]
		]) if (s.startsWith(e, c)) return c += e.length, t;
		let a = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(s.slice(c));
		if (!a) return l("値が不正です。");
		c += a[0].length;
		let p = Number(a[0]);
		return Number.isFinite(p) ? p : l("有限でない数値は保存できません。");
	}
	let p = f(1);
	return u(), c !== s.length && l("JSONの末尾に余分なデータがあります。"), p;
}
function s(t) {
	let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new WeakSet();
	function i(t) {
		if (t !== null && typeof t != "boolean") {
			if (typeof t == "string") {
				if (!a(t)) throw new e("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
				return;
			}
			if (typeof t == "number") {
				if (!Number.isFinite(t)) throw new e("VALIDATION_FAILED", "有限でない数値は保存できません。");
				return;
			}
			if (typeof t != "object") throw new e("VALIDATION_FAILED", "JSONに保存できない値があります。");
			if (n.has(t)) throw new e("VALIDATION_FAILED", "循環したJSONは保存できません。");
			if (!r.has(t)) {
				if (n.add(t), Array.isArray(t)) t.forEach(i);
				else for (let e of Object.keys(t)) {
					let n = t[e];
					n !== void 0 && i(n);
				}
				n.delete(t), r.add(t);
			}
		}
	}
	i(t);
}
function c(t) {
	let n = /* @__PURE__ */ new Set();
	function r(t) {
		if (t === null) return "null";
		if (typeof t == "string") {
			if (!a(t)) throw new e("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return JSON.stringify(t);
		}
		if (typeof t == "boolean") return String(t);
		if (typeof t == "number") {
			if (!Number.isFinite(t)) throw new e("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return JSON.stringify(t);
		}
		if (typeof t != "object") throw new e("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (n.has(t)) throw new e("VALIDATION_FAILED", "循環したJSONは保存できません。");
		n.add(t);
		let i = Array.isArray(t) ? `[${t.map(r).join(",")}]` : `{${Object.keys(t).filter((e) => t[e] !== void 0).sort().map((e) => `${JSON.stringify(e)}:${r(t[e])}`).join(",")}}`;
		return n.delete(t), i;
	}
	return r(t);
}
var l = (e) => new TextEncoder().encode(c(e)), u = (e, t) => c(e) === c(t);
function d(t, n) {
	let r = /* @__PURE__ */ new WeakMap(), i = /* @__PURE__ */ new Set(), a = (e) => new TextEncoder().encode(c(e)).byteLength, o = (t) => {
		if (!t || typeof t != "object") return Math.min(n + 1, a(t));
		if (i.has(t)) throw new e("VALIDATION_FAILED", "循環したJSONは保存できません。");
		let s = r.get(t);
		if (s !== void 0) return s;
		i.add(t);
		let c = 2;
		if (Array.isArray(t)) {
			c += Math.max(0, t.length - 1);
			for (let e = 0; e < t.length && c <= n; e++) Object.hasOwn(t, e) && (c += o(t[e]));
		} else {
			let e = !0;
			for (let r of Object.keys(t)) {
				let i = t[r];
				if (i !== void 0 && (c += +!e + new TextEncoder().encode(JSON.stringify(r)).byteLength + 1 + o(i), e = !1, c > n)) break;
			}
		}
		return i.delete(t), c = Math.min(c, n + 1), r.set(t, c), c;
	};
	return o(t) > n;
}
async function f(e) {
	let t = await crypto.subtle.digest("SHA-256", e.slice().buffer);
	return [...new Uint8Array(t)].map((e) => e.toString(16).padStart(2, "0")).join("");
}
function p(t) {
	if (!t || t.includes("\0") || t.includes("\\") || t.startsWith("/") || /^[a-z]:/i.test(t) || t.split("/").some((e) => !e || e === "." || e === "..") || !a(t)) throw new e("UNSAFE_PATH", "危険なファイルパスです。", t);
}
//#endregion
//#region src/domain/pinnedWorlds.ts
function m() {
	return {
		hashes: /* @__PURE__ */ new WeakMap(),
		registryClones: /* @__PURE__ */ new WeakMap(),
		stableRegistries: /* @__PURE__ */ new WeakSet()
	};
}
function h(e, t) {
	let n = t.registryClones.get(e);
	if (n) return n;
	let r = structuredClone(e);
	return t.registryClones.set(e, r), t.stableRegistries.add(r), r;
}
function g(e, t) {
	let n = [], r = [], i = [], a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = [...e.worldReferences].reverse().map((e) => ({ reference: e })), u = 0;
	for (; l.length;) {
		if (++u > 2e5) {
			i.push("共通世界の依存数が安全上限を超えています。");
			break;
		}
		let e = l.pop();
		if ("exit" in e) {
			o.delete(e.exit);
			continue;
		}
		let d = e.reference, f = d.immutableSnapshotId;
		if (o.has(f)) {
			i.push("共通世界の固定版参照が循環しています。");
			continue;
		}
		let p = c.get(f);
		if (p && p !== d.contentHash) {
			i.push("同じ共通世界の固定版に異なる内容ハッシュが指定されています。");
			continue;
		}
		c.set(f, d.contentHash);
		let m = s.get(d.projectId);
		if (m && m !== f) {
			i.push("同じ共通世界の異なる版が同時に参照されています。");
			continue;
		}
		if (s.set(d.projectId, f), a.has(f)) continue;
		let h = t[f];
		if (!h || h.projectId !== d.projectId) {
			i.push("参照した共通世界の固定版がありません。");
			continue;
		}
		if (a.add(f), o.add(f), r.push(d), n.push(h), l.push({ exit: f }), !Array.isArray(h.worldReferences)) {
			i.push("共通世界の依存参照が不正です。");
			continue;
		}
		for (let e of [...h.worldReferences].reverse()) l.push({ reference: e });
	}
	return {
		worlds: n,
		references: r,
		errors: i
	};
}
async function ee(e, t, n = "worldReferences", r) {
	let i = g(e, t), a = i.errors.map((e) => ({
		code: "REFERENCE_INVALID",
		path: n,
		message: e
	}));
	for (let e of i.references) {
		let i = t[e.immutableSnapshotId];
		if (!i) continue;
		let o = `${e.immutableSnapshotId}\0${e.contentHash}`, s = r?.hashes.get(i);
		r && !s && (s = /* @__PURE__ */ new Map(), r.hashes.set(i, s));
		let c = s?.get(o);
		c || (c = f(l(i)), s?.set(o, c)), await c !== e.contentHash && a.push({
			code: "INTEGRITY_FAILED",
			path: `${n}.${e.projectId}.${e.immutableSnapshotId}.contentHash`,
			message: "共通世界の固定版内容ハッシュが一致しません。"
		});
	}
	return a;
}
//#endregion
//#region src/domain/adoption.ts
function _(e) {
	return !e.deletedAt && e.status !== "rejected" && e.status !== "alternate";
}
//#endregion
//#region src/domain/reuse.ts
var te = /* @__PURE__ */ new WeakMap(), v = /* @__PURE__ */ new WeakMap(), y = (e, t) => te.get(e)?.get(t), ne = (e) => v.get(e) ?? e, b = (e) => e.kind === "scene" || e.kind === "flow_node";
function re(e, t) {
	let n = e;
	for (let e of t.replace(/\[(\d+)\]/g, ".$1").split(".")) {
		if (!n || typeof n != "object") return;
		if ("sourceVersionId" in n && typeof n.sourceVersionId == "string") return n.sourceVersionId;
		n = n[e];
	}
}
function x(e) {
	throw Object.assign(/* @__PURE__ */ Error(`REFERENCE_INVALID: ${e}`), { issues: [{
		code: "REFERENCE_INVALID",
		path: "reuse",
		message: e
	}] });
}
function ie(e) {
	if (Array.isArray(e)) return e.flatMap(ie);
	if (!e || typeof e != "object") return [];
	let t = e;
	return [...typeof t.id == "string" && ("text" in t && "kind" in t || "audienceHolderIds" in t || "eventKey" in t || "x" in t && "y" in t) ? [t.id] : [], ...Object.values(t).flatMap(ie)];
}
function ae(e, t, n) {
	let r = new Map(e.entities.filter(_).map((e) => [e.id, e])), i = new Map(e.entities.flatMap((e) => ie(e.data).map((t) => [t, e.id]))), a = /* @__PURE__ */ new Map();
	for (let e of r.values()) e.kind === "disclosure" && a.set(e.data.anchor.entityId, [...a.get(e.data.anchor.entityId) ?? [], e]);
	let o = [t], s = /* @__PURE__ */ new Set(), c = [];
	for (let e = 0; e < o.length; e++) {
		let t = o[e];
		if (s.has(t)) continue;
		s.add(t);
		let n = r.get(t);
		n || x("共通元の依存情報が存在しないか、不採用です。"), c.push(n);
		for (let e of a.get(t) ?? []) o.push(e.id);
		for (let e of nn(n)) {
			if (n.kind === "scene" && e.path === "data.chapterId" || re(n, e.path) || ![
				"entity",
				"record",
				"presentation",
				"block"
			].includes(e.scope)) continue;
			let t = r.has(e.id) ? e.id : i.get(e.id);
			t && o.push(t);
		}
		c.length > 1e5 && x("共通元の依存情報が100,000件を超えています。");
	}
	return c;
}
var oe = (e) => [...new Set(e.flatMap((e) => [e.id, ...ie(e.data)]))], se = (e, t) => c(e) === c(t);
function ce(e, t, n) {
	return !!t && [
		"variable",
		"item",
		"character",
		"place",
		"group",
		"assertion",
		"external_contract"
	].includes(e.kind) && t.kind === e.kind && _(t) && e.status === t.status && e.name === t.name && se(sn(e, n).data, t.data);
}
function le(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => le(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	typeof n.id == "string" && ("text" in n && "kind" in n || "audienceHolderIds" in n || "eventKey" in n || "x" in n && "y" in n) && (n.id = t[n.id] ?? n.id), Object.values(n).forEach((e) => le(e, t));
}
function ue(e, t, n, r) {
	let i = sn(e, t);
	i.id = t[e.id] ?? e.id, i.projectId = n, le(i.data, t);
	for (let t of nn(e)) if (re(e, t.path)) {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split("."), n = i;
		for (let t of e.slice(0, -1)) n = n[t];
		n[e.at(-1)] = t.id;
	}
	return i;
}
function de(e, t, n = []) {
	if (te.has(e) || !e.entities.some((e) => _(e) && b(e) && e.data.reuse && e.data.reuse.mode !== "clone")) return e;
	let r = new Map(e.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Set([
		...e.entities.flatMap((e) => [e.id, ...ie(e.data)]),
		...e.relations.map((e) => e.id),
		...e.views.map((e) => e.id),
		e.projectId
	]), o = new Map(e.worldReferences.map((e) => [e.projectId, e]));
	for (let s of e.entities) {
		if (!_(s) || !b(s) || !s.data.reuse || s.data.reuse.mode === "clone") continue;
		let c = s.data.reuse, l = t.find((e) => e.id === c.pinnedSnapshotId);
		(!l || l.content.projectId !== e.projectId) && x("共通元の固定版がありません。"), (n.includes(l.id) || n.length >= 32) && x("共通元の固定参照が循環しているか、32段を超えています。");
		let u = de(l.content, t, [...n, l.id]), d = u.entities.find((e) => e.id === c.sourceId && _(e));
		(!d || d.kind !== s.kind || !b(d)) && x("共通元の種類が一致しないか、固定版で不採用です。");
		let f = ae(u, d.id, l.id), p = oe(f), m = c.bindings;
		(!m || m[d.id] !== s.id || p.length !== Object.keys(m).length || p.some((e) => !m[e]) || new Set(Object.values(m)).size !== p.length) && x("共通元のID対応が欠落・重複しています。対象版を確認して再設定してください。");
		for (let [e, t] of Object.entries(m)) if (t !== s.id && a.has(t)) {
			let n = f.find((t) => t.id === e);
			(e !== t || !n || !ce(n, r.get(t), m)) && x("共通元の実行用IDが現在稿のレコード・段落・関係と衝突しています。ID対応を確認し直してください。");
		}
		let h = new Set(Object.keys(d.data).filter((e) => !["reuse", "chapterId"].includes(e)));
		(c.mode === "reference" && c.overrideFields.length || c.overrideFields.some((e) => !h.has(e))) && x("上書き対象が不正です。宣言したフィールドだけを上書きしてください。");
		for (let e of u.worldReferences) {
			let t = o.get(e.projectId);
			t && !se(t, e) && x("共通元と使用先が同じ世界の異なる固定版を要求しています。適用する版を明示して揃えてください。"), o.set(e.projectId, e);
		}
		let g = u.entities.find((e) => e.kind === "flow_graph" && d.kind === "flow_node" && e.data.nodeIds.includes(d.id)), ee = d.kind === "scene" ? d : u.entities.find((e) => d.kind === "flow_node" && e.id === d.data.sceneId && e.kind === "scene");
		for (let t of f) {
			let n = ue(t, m, e.projectId, l.id), a = n.id, o = r.get(a);
			if (a !== s.id && o) {
				(t.id !== a || !ce(t, o, m)) && x("共通元の実行用IDが現在稿と衝突しています。対応を再確認してください。");
				continue;
			}
			let d = y(u, t.id), f = d ? Object.fromEntries(Object.entries(d.bindings).flatMap(([e, t]) => m[t] ? [[e, m[t]]] : [])) : m;
			if (i.set(a, {
				entityId: d?.entityId ?? t.id,
				sourceVersionId: d?.sourceVersionId ?? l.id,
				ownerId: s.id,
				bindings: f,
				graphId: g ? m[g.id] ?? g.id : void 0,
				chapterId: ee?.kind === "scene" && ee.data.chapterId ? m[ee.data.chapterId] ?? ee.data.chapterId : void 0
			}), a === s.id) {
				let e = { ...n.data };
				delete e.reuse;
				for (let t of c.overrideFields) Object.hasOwn(s.data, t) ? e[t] = structuredClone(s.data[t]) : delete e[t];
				s.kind === "scene" && (e.chapterId = s.data.chapterId ?? null), r.set(a, {
					...s,
					data: e
				});
			} else r.set(a, n);
		}
		r.size > 1e5 && x("再利用を解決した実行情報が100,000件を超えています。");
	}
	let s = /* @__PURE__ */ new Set();
	for (let t of [...r.values()].flatMap((e) => [e.id, ...ie(e.data)]).concat(e.relations.map((e) => e.id), e.views.map((e) => e.id))) s.has(t) && x("再利用先どうしでレコード・段落等のIDが衝突しています。ID対応を確認し直してください。"), s.add(t);
	let c = {
		...e,
		entities: [...r.values()],
		worldReferences: [...o.values()]
	};
	return te.set(c, i), v.set(c, e), c;
}
function fe(e, t) {
	return Object.fromEntries([...te.get(e) ?? []].map(([e, n]) => [e, {
		...t,
		graphId: t.graphId ? n.bindings[t.graphId] ?? t.graphId : void 0,
		chapterId: t.chapterId ? n.bindings[t.chapterId] ?? t.chapterId : void 0,
		sourceVersionId: n.sourceVersionId,
		anchorBindings: n.bindings
	}]));
}
function pe(e, t, n) {
	let r = y(e, n);
	return !r || t.sourceVersionId !== r.sourceVersionId ? t : {
		...t,
		entityId: r.bindings[t.entityId] ?? t.entityId,
		...t.blockId ? { blockId: r.bindings[t.blockId] ?? t.blockId } : {},
		...t.lineId ? { lineId: r.bindings[t.lineId] ?? t.lineId } : {}
	};
}
function me(e, t, n) {
	if (!e.entities.some((e) => b(e) && e.data.reuse?.bindings)) return [];
	try {
		return de(e, t), [];
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: `${n}.reuse`,
			message: e.message
		}];
	}
}
//#endregion
//#region src/domain/types.ts
var he = "1.0.0", ge = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/, _e = 10n ** 38n - 1n, ve = {
	id: "proleptic-gregorian-second",
	name: "先発グレゴリオ暦",
	kind: "gregorian",
	originLabel: "0000-01-01 00:00:00",
	ticksPerDay: "86400"
};
function S(e) {
	return typeof e == "string" && ge.test(e);
}
function C(e) {
	if (!S(e)) throw RangeError("tickは38桁以内の正規整数文字列で指定してください。");
	return BigInt(e);
}
function ye(e) {
	if (e < -_e || e > _e) throw RangeError("tickが38桁の範囲を超えています。");
	return e.toString();
}
function be(e, t) {
	return ye(C(e) + C(t));
}
function w(e, t) {
	let n = C(e), r = C(t);
	return n < r ? -1 : +(n > r);
}
function xe(e, t = "calendar") {
	let n = (e, n = t) => ({
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: n,
			message: e
		}]
	});
	if (!e || typeof e != "object" || Array.isArray(e)) return n("暦はオブジェクトです。");
	let r = e, i = r.kind === "repeating" ? [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay",
		"years"
	] : [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay"
	];
	if (Object.keys(r).some((e) => !i.includes(e))) return n("暦に未知の項目があります。");
	if (typeof r.id != "string" || !r.id || typeof r.name != "string" || !r.name || typeof r.originLabel != "string") return n("暦のID・名称・原点ラベルが必要です。");
	if (!S(r.ticksPerDay) || C(r.ticksPerDay) <= 0n) return n("1日のtick数は正の整数です。", `${t}.ticksPerDay`);
	if (r.kind === "gregorian") return r.ticksPerDay === "86400" ? {
		ok: !0,
		value: e
	} : n("標準暦は1日86400tickです。", `${t}.ticksPerDay`);
	if (r.kind !== "repeating" || !Array.isArray(r.years) || r.years.length < 1 || r.years.length > 400) return n("繰返し暦は1〜400年の周期が必要です。");
	for (let e = 0; e < r.years.length; e++) {
		let i = r.years[e];
		if (!i || typeof i != "object" || Object.keys(i).some((e) => e !== "months") || !Array.isArray(i.months) || i.months.length < 1 || i.months.length > 24) return n("1年の月数は1〜24です。", `${t}.years[${e}]`);
		for (let r = 0; r < i.months.length; r++) {
			let a = i.months[r];
			if (!a || typeof a != "object" || Object.keys(a).some((e) => !["name", "days"].includes(e)) || typeof a.name != "string" || !a.name || !Number.isInteger(a.days) || a.days < 1 || a.days > 400) return n("月名と1〜400の日数が必要です。", `${t}.years[${e}].months[${r}]`);
		}
	}
	return {
		ok: !0,
		value: e
	};
}
function Se(e, t) {
	try {
		return e.mode === "unknown" ? {
			status: "unknown",
			reason: e.reason || "日時が未定です。",
			path: t
		} : e.mode === "instant" ? (C(e.at), {
			status: "resolved",
			earliest: e.at,
			latest: e.at,
			endEarliest: e.at,
			endLatest: e.at,
			calendarId: e.calendarId,
			mode: e.mode
		}) : e.mode === "interval" ? w(e.start, e.end) >= 0 ? {
			status: "conflict",
			reason: "期間は開始より後に終了してください。",
			path: t
		} : {
			status: "resolved",
			earliest: e.start,
			latest: e.start,
			endEarliest: e.end,
			endLatest: e.end,
			calendarId: e.calendarId,
			mode: e.mode
		} : w(e.earliest, e.latest) > 0 ? {
			status: "conflict",
			reason: "概算範囲が逆転しています。",
			path: t
		} : {
			status: "resolved",
			earliest: e.earliest,
			latest: e.latest,
			endEarliest: e.earliest,
			endLatest: e.latest,
			calendarId: e.calendarId,
			mode: e.mode
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: t
		};
	}
}
function Ce(e, t, n, r) {
	try {
		if (w(e.minOffset, e.maxOffset) > 0) return {
			status: "conflict",
			reason: "相対日時の範囲が逆転しています。",
			path: n()
		};
		if (t.status !== "resolved") return r ? {
			...t,
			path: [...n(), ...t.path].slice(0, 64)
		} : t;
		let i = be(e.anchorPoint === "start" ? t.earliest : t.endEarliest, e.minOffset), a = be(e.anchorPoint === "start" ? t.latest : t.endLatest, e.maxOffset);
		return {
			status: "resolved",
			earliest: i,
			latest: a,
			endEarliest: i,
			endLatest: a,
			calendarId: t.calendarId,
			mode: "relative"
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: n()
		};
	}
}
function we(e, t, n = []) {
	return Ce(e, t, () => n, !0);
}
function Te(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) !n.deletedAt && !t.has(n.id) && t.set(n.id, n);
	return t;
}
function Ee(e, t = [], n = []) {
	if (e.mode !== "relative") return Se(e, n);
	let r = Te(t), i = [...n], a = new Set(n), o = [], s = e;
	for (; s.mode === "relative";) {
		if (a.has(s.anchorEventId)) return {
			status: "conflict",
			reason: "相対日時の参照が循環しています。",
			path: [...i, s.anchorEventId]
		};
		try {
			if (w(s.minOffset, s.maxOffset) > 0) return {
				status: "conflict",
				reason: "相対日時の範囲が逆転しています。",
				path: [...i]
			};
		} catch (e) {
			return {
				status: "conflict",
				reason: e instanceof Error ? e.message : "日時を解決できません。",
				path: [...i]
			};
		}
		let e = r.get(s.anchorEventId);
		if (!e) return {
			status: "unknown",
			reason: "基準となる出来事がありません。",
			path: [...i, s.anchorEventId]
		};
		o.push({
			time: s,
			pathLength: i.length
		}), a.add(e.id), i.push(e.id), s = e.data.time;
	}
	let c = Se(s, i);
	for (let e = o.length - 1; e >= 0 && c.status === "resolved"; e--) {
		let t = o[e];
		c = Ce(t.time, c, () => i.slice(0, t.pathLength), !1);
	}
	return c;
}
function De(e) {
	let t = Te(e), n = /* @__PURE__ */ new Map();
	for (let e of t.values()) {
		if (n.has(e.id)) continue;
		let r = [], i = /* @__PURE__ */ new Map(), a = e.id;
		for (; !n.has(a);) {
			let e = t.get(a);
			if (!e) {
				n.set(a, {
					status: "unknown",
					reason: "基準となる出来事がありません。",
					path: [a]
				});
				break;
			}
			let o = i.get(a);
			if (o !== void 0) {
				let e = r.slice(o);
				for (let t = 0; t < e.length; t++) n.set(e[t], {
					status: "conflict",
					reason: "相対日時の参照が循環しています。",
					path: Array.from({ length: Math.min(e.length + 1, 64) }, (n, r) => e[(t + r) % e.length])
				});
				break;
			}
			if (e.data.time.mode !== "relative") {
				n.set(a, Se(e.data.time, [a]));
				break;
			}
			let s = e.data.time;
			if (!i.has(s.anchorEventId) && s.anchorEventId !== a) try {
				if (w(s.minOffset, s.maxOffset) > 0) {
					n.set(a, {
						status: "conflict",
						reason: "相対日時の範囲が逆転しています。",
						path: [a]
					});
					break;
				}
			} catch (e) {
				n.set(a, {
					status: "conflict",
					reason: e instanceof Error ? e.message : "日時を解決できません。",
					path: [a]
				});
				break;
			}
			i.set(a, r.length), r.push(a), a = s.anchorEventId;
		}
		for (let e = r.length - 1; e >= 0; e--) {
			let i = r[e], a = t.get(i);
			!n.has(i) && a.data.time.mode === "relative" && n.set(i, we(a.data.time, n.get(a.data.time.anchorEventId), [i]));
		}
	}
	return n;
}
function Oe(e) {
	let t = [], n = Te(e), r = De(e);
	for (let e of n.values()) {
		let i = r.get(e.id);
		i.status === "conflict" && t.push({
			code: "TIME_CONSTRAINT_CONFLICT",
			path: `entities.${e.id}.data.time`,
			message: i.reason
		});
		for (let a of e.data.constraints ?? []) {
			let o = n.get(a.targetEventId);
			if (!o || i.status !== "resolved") continue;
			let s = r.get(o.id);
			if (s.status !== "resolved") continue;
			let c = i.calendarId !== s.calendarId;
			if (a.type === "before") c ||= i.mode === "interval" ? w(i.endEarliest, s.latest) > 0 : w(i.endEarliest, s.latest) >= 0;
			else if (a.type === "same_start") c ||= w(i.earliest, s.latest) > 0 || w(s.earliest, i.latest) > 0;
			else {
				let e = C(s.earliest) - C(i.endLatest), t = C(s.latest) - C(i.endEarliest);
				c ||= t < C(a.minimumTicks) || e > C(a.maximumTicks);
			}
			c && t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "指定した出来事の日時制約と矛盾しています。"
			});
		}
	}
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
	for (let e of n.values()) a.set(e.id, (e.data.constraints ?? []).map((e) => e.targetEventId));
	for (let e of n.values()) e.data.time.mode === "relative" && n.has(e.data.time.anchorEventId) && a.get(e.data.time.anchorEventId).push(e.id);
	for (let e of n.values()) {
		if (i.get(e.id)) continue;
		let r = [{
			id: e.id,
			targets: a.get(e.id),
			cursor: 0
		}];
		for (i.set(e.id, 1); r.length;) {
			let e = r[r.length - 1];
			if (e.cursor === e.targets.length) {
				i.set(e.id, 2), r.pop();
				continue;
			}
			let o = e.targets[e.cursor++], s = n.get(o);
			s && (i.get(o) === 1 ? t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "日時制約の依存が循環しています。"
			}) : i.has(o) || (i.set(o, 1), r.push({
				id: o,
				targets: a.get(s.id),
				cursor: 0
			})));
		}
	}
	return t;
}
function ke(e, t) {
	return e.id !== t.id || e.kind !== t.kind || e.name !== t.name || e.originLabel !== t.originLabel || e.ticksPerDay !== t.ticksPerDay ? !1 : e.kind === "gregorian" || t.kind === "gregorian" ? e.kind === t.kind : e.years.length === t.years.length && e.years.every((e, n) => e.months.length === t.years[n].months.length && e.months.every((e, r) => e.name === t.years[n].months[r].name && e.days === t.years[n].months[r].days));
}
//#endregion
//#region src/domain/templates.ts
var T = (e, t, n = "VALIDATION_FAILED") => ({
	path: e,
	message: t,
	code: n
}), Ae = [
	"id",
	"projectId",
	"kind",
	"revision",
	"name",
	"status",
	"visibility",
	"retainIfUnreferenced",
	"projectionProfileId",
	"templateId",
	"createdAt",
	"updatedAt",
	"deletedAt",
	"deletionOperationId",
	"customValues",
	"data"
], je = [
	"__proto__",
	"prototype",
	"constructor"
], Me = [
	"text",
	"number",
	"boolean",
	"enum",
	"date",
	"ref"
];
function Ne(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = e;
	return typeof t.key == "string" && typeof t.label == "string" && Me.includes(t.type) && typeof t.required == "boolean" && typeof t.nullable == "boolean" && (t.help == null || typeof t.help == "string") && (t.allowedValues == null || Array.isArray(t.allowedValues) && t.allowedValues.every((e) => typeof e == "string")) && (t.targetKinds == null || Array.isArray(t.targetKinds) && t.targetKinds.every((e) => Object.hasOwn(At, e)));
}
function Pe(e) {
	let t = At[e];
	return [...Ae, ...t?.type === "object" ? Object.keys(t.fields) : []];
}
function Fe(e, t, n, r) {
	if (t === void 0) return e.required ? [T(n, `「${e.label}」は必須項目です。`)] : [];
	if (t === null) return e.nullable ? [] : [T(n, `「${e.label}」は空欄を許可していません。`)];
	let i = !1;
	if (e.type === "text" && (i = typeof t == "string" && (!e.required || t.trim().length > 0)), e.type === "number" && (i = typeof t == "number" && Number.isFinite(t)), e.type === "boolean" && (i = typeof t == "boolean"), e.type === "enum" && (i = typeof t == "string" && !!e.allowedValues?.includes(t)), e.type === "date" || e.type === "ref") {
		let a = t && typeof t == "object" && !Array.isArray(t) ? t : void 0;
		if (i = a?.type === e.type && typeof a.value == "string", i && e.type === "date") {
			let e = a.value, t = /^\d{4}-\d{2}-\d{2}$/.test(e) ? /* @__PURE__ */ new Date(`${e}T00:00:00.000Z`) : /* @__PURE__ */ new Date(NaN);
			i = Number.isFinite(t.getTime()) && t.toISOString().slice(0, 10) === e;
		}
		if (i && e.type === "ref") {
			let t = a.value;
			if (!Ue.test(t)) i = !1;
			else if (r) {
				let i = "get" in r ? r.get(t) : r.find((e) => e.id === t);
				if (!i || i.deletedAt || e.targetKinds?.length && !e.targetKinds.includes(i.kind)) return [T(n, `「${e.label}」の参照先が存在しないか、許可された種類ではありません。`, "REFERENCE_INVALID")];
			}
		}
	}
	return i ? [] : [T(n, `「${e.label}」の値が宣言した${e.type}型または選択候補と一致しません。`)];
}
function Ie(e, t = "data", n) {
	let r = [];
	if (!e || !Array.isArray(e.fields)) return [T(`${t}.fields`, "項目定義は配列で入力してください。")];
	Object.hasOwn(At, e.targetKind) || r.push(T(`${t}.targetKind`, "対象の情報の種類を選んでください。")), e.defaults != null && (typeof e.defaults != "object" || Array.isArray(e.defaults)) && r.push(T(`${t}.defaults`, "初期値は項目キーごとの辞書で指定してください。"));
	let i = /* @__PURE__ */ new Set(), a = new Set(Pe(e.targetKind));
	for (let [o, s] of e.fields.entries()) {
		let e = `${t}.fields[${o}]`;
		if (!Ne(s)) {
			r.push(T(e, "項目定義のキー・表示名・型・必須・空欄・説明・候補・参照先の形式を確認してください。"));
			continue;
		}
		(!s.key.trim() || i.has(s.key) || a.has(s.key) || je.includes(s.key)) && r.push(T(`${e}.key`, "キーが空欄・重複・予約済み、または標準項目と衝突しています。")), i.add(s.key), s.type === "enum" && (!Array.isArray(s.allowedValues) || !s.allowedValues.length || s.allowedValues.some((e) => typeof e != "string" || !e.trim()) || new Set(s.allowedValues).size !== s.allowedValues.length) && r.push(T(`${e}.allowedValues`, "選択型には空欄と重複のない候補を指定してください。")), s.type !== "enum" && s.allowedValues?.length && r.push(T(`${e}.allowedValues`, "選択候補はenum型だけに設定できます。")), s.type !== "ref" && s.targetKinds?.length && r.push(T(`${e}.targetKinds`, "参照先の種類はref型だけに設定できます。")), Object.hasOwn(s, "default") ? r.push(...Fe(s, s.default, `${e}.default`, n)) : r.push(T(`${e}.default`, "項目の初期値を指定してください。"));
	}
	let o = e.fields.filter(Ne), s = e.defaults && typeof e.defaults == "object" && !Array.isArray(e.defaults) ? e.defaults : {};
	for (let [e, i] of Object.entries(s)) {
		let a = o.find((t) => t.key === e);
		a ? r.push(...Fe(a, i, `${t}.defaults.${e}`, n)) : r.push(T(`${t}.defaults.${e}`, "初期値のキーを項目定義へ追加してください。"));
	}
	return r;
}
function Le(e, t = "project", n = e.entities) {
	let r = new Map(n.filter((e) => e.kind === "template").map((e) => [e.id, e])), i = [], a = new Map(n.map((e) => [e.id, e]));
	return e.entities.forEach((e, n) => {
		let o = e;
		if (e.deletedAt || !o.templateId) return;
		let s = `${t}.entities[${n}]`, c = r.get(o.templateId);
		if (!c || c.deletedAt || c.status === "rejected" || c.data.targetKind !== e.kind) {
			i.push(T(`${s}.templateId`, "適用した雛形が存在しない・不採用・削除済み、または対象の種類が異なります。", "REFERENCE_INVALID"));
			return;
		}
		for (let t of c.data.fields) i.push(...Fe(t, e.customValues[t.key], `${s}.customValues.${t.key}`, a));
	}), i;
}
//#endregion
//#region src/domain/model.ts
var Re = {
	character: "人物",
	group: "グループ",
	event: "出来事",
	place: "場所",
	item: "物品",
	note: "メモ",
	chapter: "章",
	scene: "場面",
	goal: "目標",
	flow_node: "進行ノード",
	flow_edge: "進行線",
	flow_graph: "分岐図",
	dialogue_line: "台詞",
	quest: "クエスト",
	lore: "設定",
	variable: "状態変数",
	effect: "効果",
	assertion: "事実・認識",
	foreshadow: "伏線",
	disclosure: "手掛かり・回収",
	checkpoint: "途中開始点",
	trace: "試読記録",
	attachment: "添付素材",
	source: "資料・出所",
	cue: "演出",
	storyboard_frame: "絵コンテ",
	localization: "翻訳",
	recording: "収録",
	terminology: "用語",
	map: "地図",
	travel_route: "移動経路",
	template: "雛形",
	collection: "一覧",
	review: "レビュー",
	creative_brief: "企画",
	decision: "制作判断",
	gameplay_spec: "ゲーム仕様",
	production_task: "制作タスク",
	media_variant: "媒体版",
	voice_rule: "口調",
	external_contract: "外部契約",
	snapshot: "公開版",
	projection_profile: "公開投影"
}, E = Object.keys(Re), ze = [
	"confirmed",
	"provisional",
	"needs_review",
	"rejected",
	"alternate"
], Be = [
	"scene",
	"chapter",
	"character",
	"run",
	"across_runs"
], Ve = [
	{
		key: "trust",
		label: "信頼",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "causes",
		label: "因果",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "requires",
		label: "前提",
		fromKinds: E,
		toKinds: E,
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "foreshadow_payoff",
		label: "手掛かり→回収",
		fromKinds: ["disclosure"],
		toKinds: ["disclosure"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "parent_of",
		label: "親子",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_foreshadow",
		label: "出来事の予告",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_payoff",
		label: "出来事の回収",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "mentor_of",
		label: "師弟",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "bloodline",
		label: "血統",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "related",
		label: "関連",
		fromKinds: E,
		toKinds: E,
		allowSelf: !1,
		allowSymmetric: !0
	},
	{
		key: "reference",
		label: "参照",
		fromKinds: E,
		toKinds: E,
		allowSelf: !0,
		allowSymmetric: !1
	}
], He = Object.fromEntries(Ve.map((e) => [e.key, e.label])), Ue = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, We = /^(?:0|[1-9][0-9]*)$/, Ge = () => ({
	worldRange: null,
	routeCondition: null,
	presentationAnchor: null
}), Ke = () => crypto.randomUUID();
function qe(e) {
	return e === "" ? [] : e.split("\n").map((e) => ({
		id: Ke(),
		kind: "paragraph",
		text: e
	}));
}
function Je(e) {
	return (e ?? []).map((e) => e.text).join("\n");
}
function Ye(e, t) {
	return e.entities.find((e) => e.id === t && !e.deletedAt);
}
function Xe(e, t) {
	return e.entities.filter((e) => e.kind === t && !e.deletedAt);
}
function Ze(e) {
	let t = {
		type: "unknown",
		value: null,
		reason: "未入力"
	}, n = {
		character: {
			reading: "",
			aliases: [],
			summary: [],
			body: [],
			authorNotes: [],
			goals: [],
			voiceRules: []
		},
		group: {
			groupType: "display",
			members: [],
			parentId: null,
			summary: []
		},
		event: {
			summary: [],
			time: {
				mode: "unknown",
				reason: ""
			},
			laneRole: "common",
			participants: [],
			locationId: null,
			itemIds: [],
			authorNotes: [],
			constraints: []
		},
		place: {
			parentId: null,
			reading: "",
			aliases: [],
			body: [],
			mapIds: [],
			changes: []
		},
		item: {
			itemMode: "type",
			typeId: null,
			body: [],
			properties: null,
			changes: []
		},
		note: {
			body: [],
			attachmentIds: [],
			convertedToIds: [],
			originNoteId: null
		},
		chapter: {
			sceneIds: [],
			summary: [],
			authorNotes: [],
			structureRole: ""
		},
		scene: {
			summary: [],
			body: [],
			authorNotes: [],
			eventIds: [],
			chapterId: null,
			threadIds: [],
			povId: null,
			goals: [],
			conflicts: [],
			results: [],
			newInformation: [],
			tension: null,
			importance: null,
			blockIds: []
		},
		goal: {
			ownerId: null,
			description: [],
			changes: [],
			evidenceSceneIds: [],
			validity: Ge()
		},
		flow_node: {
			nodeType: "choice",
			sceneId: null,
			childGraphId: null,
			terminalReason: "",
			gate: {
				op: "constant",
				value: !0
			},
			executionPolicy: "manual_choice",
			fallbackId: null
		},
		flow_edge: {
			fromId: null,
			toId: { unresolved: {
				label: "",
				reason: "未完成"
			} },
			edgeType: "choice",
			label: "",
			condition: {
				op: "constant",
				value: !0
			},
			effectIds: [],
			priority: 0,
			choiceLineId: null
		},
		flow_graph: {
			nodeIds: [],
			edgeIds: [],
			entryIds: [],
			exitIds: [],
			parentGraphId: null,
			parameters: []
		},
		dialogue_line: {
			text: [],
			speakerId: null,
			choiceEdgeId: null,
			cueIds: [],
			originLineIds: []
		},
		quest: {
			key: "",
			stateVariableId: null,
			description: [],
			flowIds: [],
			transitionRules: [],
			gameplaySpecIds: []
		},
		lore: {
			body: [],
			assertionIds: [],
			sourceIds: [],
			reading: "",
			aliases: []
		},
		variable: {
			key: "",
			valueType: "boolean",
			scope: "run",
			initial: t,
			allowed: { values: [!1, !0] },
			description: [],
			ownerId: null,
			externalContractId: null,
			resetRules: [],
			transitionRules: [],
			externalUseDeclared: !1
		},
		effect: {
			operation: "set",
			targetId: null,
			value: t,
			condition: {
				op: "constant",
				value: !0
			},
			instanceId: null,
			reason: ""
		},
		assertion: {
			subjectId: null,
			predicate: "",
			value: t,
			truthKind: "author_truth",
			holderId: null,
			sourceIds: [],
			evidenceLocation: null,
			validity: Ge(),
			reason: ""
		},
		foreshadow: {
			question: [],
			intent: [],
			resolutionPolicy: "undecided",
			truthAssertionIds: [],
			clueIds: [],
			payoffIds: [],
			requiredInfo: [],
			deadline: null,
			exceptions: []
		},
		disclosure: {
			foreshadowId: null,
			anchor: { entityId: null },
			stage: "hint",
			role: "clue",
			condition: {
				op: "constant",
				value: !0
			},
			knowledgeEffects: [],
			targetScope: null
		},
		checkpoint: {
			contentVersionId: null,
			runtimeState: et(""),
			origin: "partial",
			traceId: null
		},
		trace: {
			contentVersionId: null,
			startCheckpointId: null,
			steps: [],
			seed: "",
			engineVersion: "1.0.0",
			externalMode: "stub"
		},
		attachment: {
			mediaType: "",
			contentHash: "",
			byteSize: 0,
			assetPath: "",
			displayName: "",
			stage: "reference",
			revisionHistory: []
		},
		source: {
			sourceType: "web",
			locator: "",
			accessedAt: null,
			excerptLocation: "",
			interpretation: [],
			attachmentId: null,
			redistributionAllowed: !1
		},
		cue: {
			anchor: { entityId: null },
			cueType: "",
			attachmentId: null,
			speakerId: null,
			expression: "",
			waitMs: null,
			camera: null,
			mediaTime: null,
			stage: ""
		},
		storyboard_frame: {
			anchor: { entityId: null },
			mediaStartMs: 0,
			mediaEndMs: null,
			referenceAssetId: null,
			finalAssetId: null,
			cueIds: [],
			caption: []
		},
		localization: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			text: [],
			stage: "draft",
			reviewedBy: null,
			recordingIds: []
		},
		recording: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			translationId: null,
			attachmentId: null,
			notes: [],
			stage: "planned",
			reviewedBy: null
		},
		terminology: {
			canonical: "",
			reading: "",
			variants: [],
			language: null,
			usageNotes: [],
			validity: Ge(),
			exceptions: [],
			voiceOwnerId: null
		},
		map: {
			placeId: null,
			coordinateSystem: "normalized",
			attachmentId: null,
			parentMapId: null,
			pins: []
		},
		travel_route: {
			fromPlaceId: null,
			toPlaceId: null,
			direction: "one_way",
			method: "",
			minimumTicks: null,
			maximumTicks: null,
			evidence: [],
			validity: Ge()
		},
		template: {
			targetKind: "character",
			fields: [],
			description: "",
			version: "0",
			defaults: {}
		},
		collection: {
			mode: "fixed",
			memberIds: [],
			query: null,
			sort: {
				field: "name",
				direction: "asc"
			}
		},
		review: {
			target: null,
			targetVersionId: null,
			body: [],
			stage: "open",
			assigneeId: null,
			quotedText: "",
			resolution: []
		},
		creative_brief: {
			targetAudience: [],
			experience: [],
			theme: [],
			tone: [],
			scope: [],
			deliverableIds: [],
			decisionIds: []
		},
		decision: {
			subject: "",
			reason: [],
			targetVersionId: null,
			outcome: "deferred",
			priority: "",
			requirementIds: [],
			reviewIds: []
		},
		gameplay_spec: {
			sceneId: null,
			action: [],
			mechanic: "",
			tutorial: [],
			reward: null,
			questId: null,
			taskIds: [],
			intentionalDifference: ""
		},
		production_task: {
			targetIds: [],
			stage: "writing",
			progress: "todo",
			assigneeId: null,
			deadline: null,
			dependsOn: [],
			estimate: null,
			blockingReason: ""
		},
		media_variant: {
			medium: "novel",
			baseSnapshotId: null,
			body: [],
			releaseAt: null,
			projectionProfileId: null,
			sourceIds: [],
			needsReview: !1
		},
		voice_rule: {
			characterId: null,
			validity: Ge(),
			firstPerson: "",
			addressing: "",
			phrasing: "",
			examples: [],
			exceptions: []
		},
		external_contract: {
			key: "",
			owner: "tool",
			inputType: "boolean",
			outputType: "boolean",
			missingPolicy: "unknown",
			description: [],
			stubValues: [],
			adapterProfileIds: [],
			version: "1.0.0"
		},
		snapshot: {
			versionLabel: "",
			contentHash: "",
			immutable: !0,
			parentVersionIds: [],
			releasedAt: null,
			referencedWorldVersionIds: []
		},
		projection_profile: {
			audience: "",
			includedIds: [],
			namePolicy: { mode: "exclude" },
			allowedKinds: [],
			excludedFields: ["authorNotes"],
			routeScope: null,
			includeAuthorNotes: !1,
			publicTitle: "",
			publicTexts: {},
			allowedRelationIds: [],
			idPolicy: "remap"
		}
	};
	if (!(e in n)) throw RangeError("未対応の情報種別です。");
	return n[e];
}
function Qe(e, t, n = "", r) {
	let i = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: Ke(),
		projectId: e,
		kind: t,
		revision: "0",
		name: n,
		status: "provisional",
		visibility: "private",
		createdAt: i,
		updatedAt: i,
		customValues: {},
		data: {
			...Ze(t),
			...r
		}
	};
}
function $e(e = "新しい作品") {
	return {
		projectId: Ke(),
		name: e,
		formatVersion: he,
		revision: "0",
		calendarId: ve.id,
		mainStart: "0",
		calendars: [structuredClone(ve)],
		worldReferences: [],
		entities: [],
		relations: [],
		snapshots: [],
		history: [],
		views: []
	};
}
function et(e) {
	return {
		contentVersionId: e,
		variableValues: {},
		itemInstances: [],
		assertions: [],
		seenIds: [],
		visitCounts: {},
		onceTriggers: [],
		rngSeed: "scenario-1",
		rngPosition: 0,
		callStack: [],
		presentationPosition: null,
		loopNumber: 0,
		provenance: "full_play"
	};
}
var D = (e = 0, t) => ({
	type: "text",
	min: e,
	max: t,
	maxBytes: 1048576
}), O = D(0, 128), tt = D(1, 128), k = (e, t, n = !1) => ({
	type: "number",
	min: e,
	max: t,
	integer: n
}), A = { type: "boolean" }, j = { type: "id" }, M = { type: "tick" }, N = { type: "typed" }, P = (...e) => ({
	type: "enum",
	values: e
}), F = (...e) => ({
	type: "ref",
	kinds: e.length ? e : void 0,
	scope: "entity"
}), I = (e) => ({
	type: "ref",
	scope: e
}), L = (e, t = !1, n, r) => ({
	type: "array",
	item: e,
	unique: t,
	min: n,
	max: r
}), R = (...e) => L(F(...e), !0), z = (e) => ({
	type: "object",
	fields: e
}), B = (e) => ({
	schema: e,
	required: !0
}), V = (e) => ({
	schema: e,
	nullable: !0
}), nt = (e) => ({
	schema: e,
	nullable: !1
}), H = { type: "richtext" }, rt = {
	type: "richtext",
	max: 2048
}, U = { type: "condition" }, it = { type: "time" }, W = (e, t) => ({
	type: "record",
	value: e,
	key: t
}), at = (...e) => ({
	type: "union",
	choices: e
}), G = z({
	entityId: B(F()),
	blockId: V(I("block")),
	lineId: V(F("dialogue_line")),
	start: V(k(0, void 0, !0)),
	end: V(k(0, void 0, !0)),
	sourceVersionId: V(I("snapshot")),
	positionStatus: V(P("unresolved")),
	positionReason: V(D(1)),
	quotedText: V(D())
}), ot = at(z({
	kind: B(P("ruby")),
	originalText: B(D()),
	reason: B(D(1)),
	reading: B(D())
}), z({
	kind: B(P("link")),
	originalText: B(D()),
	reason: B(D(1)),
	target: B(G)
})), st = z({
	worldRange: {
		schema: z({
			start: {
				schema: M,
				required: !0,
				nullable: !0
			},
			end: {
				schema: M,
				required: !0,
				nullable: !0
			}
		}),
		required: !0,
		nullable: !0
	},
	routeCondition: {
		schema: U,
		required: !0,
		nullable: !0
	},
	presentationAnchor: {
		schema: G,
		required: !0,
		nullable: !0
	}
}), ct = z({
	projectId: B(I("project")),
	graphId: V(F("flow_graph")),
	chapterId: V(F("chapter")),
	routeCondition: V(U),
	targetSnapshotId: V(I("snapshot"))
}), lt = z({
	id: B(j),
	text: B(D(1, 128)),
	reading: B(O),
	validity: B(st),
	audienceHolderIds: B(R("character")),
	isPublicDefault: B(A)
}), ut = z({
	reason: B(D(1)),
	targetScope: B(ct),
	validity: B(st),
	evidenceIds: B(R())
}), dt = z({
	from: B(N),
	to: B(N),
	reason: V(D()),
	exception: V(A),
	exceptionDetails: V(ut)
}), ft = z({
	on: B(P("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
	value: B(N),
	reason: V(D())
}), pt = z({
	min: V(k(void 0, void 0, !0)),
	max: V(k(void 0, void 0, !0)),
	values: V(L(at(D(), A), !0))
}), mt = z({
	id: V(j),
	event: B(P("enter", "talk", "battle_result", "manual", "custom")),
	eventKey: B(D()),
	repeat: B(P("once", "repeatable")),
	scope: V(P(...Be)),
	deadline: V(it)
}), ht = z({
	mode: B(P("reference", "clone", "override")),
	sourceId: B(F()),
	pinnedSnapshotId: B(I("snapshot")),
	overrideFields: B(L(D(1), !0)),
	bindings: V(W(j, j))
}), gt = z({ unresolved: B(z({
	label: B(D()),
	reason: B(D(1))
})) }), _t = z({
	instanceId: B(j),
	typeId: B(F("item")),
	quantity: B(k(0, void 0, !0)),
	ownerId: V(F("character", "group")),
	locationId: V(F("place")),
	consumed: B(A),
	reason: V(D())
}), vt = z({
	assertionId: B(F("assertion")),
	holderId: V(F("character")),
	truth: B(P("true", "false", "unknown")),
	sourceEffectId: V(F("effect"))
}), yt = z({
	targetId: B(F("flow_node", "flow_edge", "disclosure")),
	value: B(P("true", "false", "unknown")),
	reasons: B(L(D()))
}), bt = z({
	graphId: B(F("flow_graph")),
	returnNodeId: B(F("flow_node")),
	parameters: B(W(N, tt))
}), xt = z({
	contentVersionId: B(I("snapshot")),
	variableValues: B(W(N, F("variable"))),
	itemInstances: B(L(_t)),
	assertions: B(L(vt)),
	seenIds: B(L(I("presentation"), !0)),
	visitCounts: B(W(k(0, void 0, !0), F())),
	onceTriggers: B(L(D(1), !0)),
	rngSeed: B(D(1)),
	rngPosition: B(k(0, void 0, !0)),
	callStack: B(L(bt)),
	presentationPosition: V(F("flow_node")),
	loopNumber: B(k(0, void 0, !0)),
	provenance: B(P("full_play", "partial", "imported", "stub")),
	resetCauses: V(L(z({
		variableId: B(F("variable")),
		on: B(P("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
		before: B(N),
		after: B(N),
		reason: B(D())
	})))
}), St = z({
	entityId: B(F("scene")),
	occurrenceId: B(D(1, 256)),
	before: B(xt),
	after: B(xt),
	presentationState: V(xt),
	conditionResults: B(L(yt)),
	externalValues: V(W(N, F("external_contract"))),
	worldTick: V(M)
}), Ct = z({
	chapterIds: B(R("chapter")),
	sceneIds: B(L(F("scene"))),
	selection: V(P("chapters", "scenes")),
	occurrences: B(L(St))
}), wt = z({
	checked: B(k(0, void 0, !0)),
	total: B(k(0, void 0, !0))
}), Tt = z({
	byProvenance: V(W(wt, P("full_play", "partial", "imported", "stub"))),
	byExternalMode: V(W(wt, P("internal", "stub", "actual", "mixed"))),
	checked: B(k(0, void 0, !0)),
	total: B(k(0, void 0, !0)),
	excluded: V(k(0, void 0, !0)),
	unknown: V(k(0, void 0, !0))
}), Et = z(Object.fromEntries([
	"scenes",
	"dialogue",
	"choices",
	"conditionTrue",
	"conditionFalse",
	"declaredTests"
].map((e) => [e, B(Tt)]))), Dt = z({
	key: B(tt),
	label: B(D(1, 128)),
	type: B(P("text", "number", "boolean", "enum", "date", "ref")),
	required: B(A),
	nullable: B(A),
	default: {
		schema: { type: "custom" },
		required: !0,
		nullable: !0
	},
	allowedValues: V(L(D(), !0)),
	targetKinds: V(L(P(...E), !0)),
	help: V(D())
}), Ot = z({
	value: V(k(0)),
	range: V(z({
		min: B(k(0)),
		max: B(k(0))
	})),
	unit: B(D(1)),
	assumptions: B(L(D())),
	scope: B(ct),
	unknownCount: B(k(0, void 0, !0)),
	source: B(D()),
	speed: V(k(Number.MIN_VALUE))
}), kt = z({
	...Object.fromEntries([
		"summary",
		"body",
		"text",
		"description",
		"question",
		"intent",
		"caption",
		"usageNotes",
		"interpretation",
		"examples",
		"action",
		"tutorial"
	].map((e) => [e, V(H)])),
	...Object.fromEntries((/* @__PURE__ */ "label.reading.terminalReason.reason.key.canonical.language.locale.sourceHash.expression.method.locator.predicate.cueType.precision.displayName.relationType.eventKey.resetReason.exclusionReason.exceptionReason.camera.parameters.variants.estimateAssumptions.estimateSource.blockingReason.mechanic.intentionalDifference.excerptLocation.estimateUnit.firstPerson.addressing.phrasing".split(".")).map((e) => [e, V(D())]))
}), At = {
	character: z({
		reading: V(O),
		aliases: V(L(lt)),
		summary: V(rt),
		body: V(H),
		authorNotes: V(H),
		birth: V(it),
		death: V(it),
		goals: V(R("goal")),
		voiceRules: V(R("voice_rule"))
	}),
	group: z({
		groupType: B(P("display", "faction", "plot_thread", "category")),
		members: V(R()),
		parentId: V(F("group")),
		summary: V(rt)
	}),
	event: z({
		summary: B(rt),
		time: B(it),
		laneRole: B(P("common", "participants", "both")),
		participants: V(L(z({
			characterId: B(F("character")),
			role: B(P("actor", "witness", "mentioned", "informed", "custom")),
			evidenceIds: V(R()),
			knowledgeEffectIds: V(R("effect"))
		}))),
		locationId: V(F("place")),
		itemIds: V(R("item")),
		authorNotes: V(H),
		constraints: V(L(at(z({
			type: B(P("before", "same_start")),
			targetEventId: B(F("event"))
		}), z({
			type: B(P("end_gap")),
			targetEventId: B(F("event")),
			minimumTicks: B(M),
			maximumTicks: B(M)
		}))))
	}),
	place: z({
		parentId: V(F("place")),
		reading: V(O),
		aliases: V(L(lt)),
		body: V(H),
		mapIds: V(R("map")),
		changes: V(R("assertion"))
	}),
	item: z({
		itemMode: B(P("type", "instance")),
		typeId: V(F("item")),
		body: V(H),
		properties: V({ type: "custom" }),
		changes: V(R("assertion"))
	}),
	note: z({
		handoffReceipt: V(z({
			approval: B(z({
				entityId: B(I("entity")),
				sourceVersionId: B(I("snapshot"))
			})),
			sourceVersionId: B(I("snapshot")),
			verificationVersionId: B(I("snapshot")),
			profileVersionId: B(I("snapshot")),
			sourceRevision: B({ type: "revision" }),
			profileId: B(F("projection_profile")),
			packageHash: B({ type: "hash" }),
			receiptHash: B({ type: "hash" }),
			mode: B(P("stub", "actual", "mixed")),
			rawJson: B(D(1, 1048576)),
			idMappings: B(L(z({
				entityId: B(I("record")),
				sourceVersionId: B(I("snapshot")),
				publicId: B(D(1, 256))
			}))),
			projectionBindings: B(L(z({
				entityId: B(I("projection_record")),
				sourceVersionId: B(I("snapshot")),
				editionVersionId: B(I("snapshot")),
				publicId: B(D(1, 256))
			}))),
			citationBindings: B(L(z({
				sourceVersionId: B(I("snapshot")),
				publicVersionId: B(D(1, 256))
			}))),
			worldVersions: B(L(z({
				sourceVersionId: B(I("snapshot")),
				contentHash: B({ type: "hash" })
			})))
		})),
		body: B(H),
		attachmentIds: V(R("attachment")),
		convertedToIds: V(R()),
		originNoteId: V(F("note"))
	}),
	chapter: z({
		sceneIds: B(R("scene")),
		summary: V(rt),
		authorNotes: V(H),
		structureRole: V(O)
	}),
	scene: z({
		summary: B(rt),
		body: B(H),
		authorNotes: B(H),
		eventIds: B(R("event")),
		dialogueLineIds: V(R("dialogue_line")),
		chapterId: V(F("chapter")),
		threadIds: V(R("group")),
		povId: V(F("character")),
		goals: V(H),
		conflicts: V(H),
		results: V(H),
		newInformation: V(H),
		tension: V(k(0, 10)),
		importance: V(k(0, 10)),
		blockIds: V(L(I("block"), !0)),
		reuse: V(ht)
	}),
	goal: z({
		ownerId: B(F("character", "group")),
		description: B(H),
		changes: V(R("assertion")),
		evidenceSceneIds: V(R("scene")),
		validity: V(st)
	}),
	flow_node: z({
		nodeType: B(P("scene", "choice", "automatic", "call", "entry", "exit", "terminal")),
		sceneId: V(F("scene")),
		childGraphId: V(F("flow_graph")),
		terminalReason: V(D()),
		trigger: V(mt),
		gate: V(U),
		executionPolicy: V(P("manual_choice", "first_match", "all_match")),
		fallbackId: V(F("flow_node")),
		reuse: V(ht)
	}),
	flow_edge: z({
		fromId: B(F("flow_node")),
		toId: B(at(F("flow_node"), gt)),
		edgeType: B(P("choice", "automatic", "call_return")),
		label: V(D()),
		condition: V(U),
		effectIds: V(R("effect")),
		priority: V(k(void 0, void 0, !0)),
		choiceLineId: V(F("dialogue_line"))
	}),
	flow_graph: z({
		nodeIds: B(R("flow_node")),
		edgeIds: B(R("flow_edge")),
		entryIds: B(R("flow_node")),
		exitIds: B(R("flow_node")),
		parentGraphId: V(F("flow_graph")),
		parameters: V(L(z({
			key: B(tt),
			type: B(P("boolean", "integer", "enum")),
			default: V(N)
		})))
	}),
	dialogue_line: z({
		text: B(H),
		speakerId: V(F("character")),
		choiceEdgeId: V(F("flow_edge")),
		cueIds: V(R("cue")),
		originLineIds: V(R("dialogue_line")),
		replacedByLineIds: V(R("dialogue_line")),
		lineage: V(z({
			mode: B(P("split", "merge", "copy")),
			baseRevision: B({ type: "revision" }),
			reason: B(D(1)),
			segments: B(L(z({
				source: B(G),
				target: B(G)
			}), !1, 1))
		})),
		claimAssertionIds: V(R("assertion")),
		assertionIntent: V(P("statement", "lie", "misunderstanding", "quotation")),
		assertionReason: V(D())
	}),
	quest: z({
		key: B(tt),
		stateVariableId: B(F("variable")),
		description: V(H),
		flowIds: V(R("flow_graph")),
		transitionRules: V(L(dt)),
		gameplaySpecIds: V(R("gameplay_spec"))
	}),
	lore: z({
		body: B(H),
		assertionIds: V(R("assertion")),
		sourceIds: V(R("source")),
		reading: V(O),
		aliases: V(L(lt))
	}),
	variable: z({
		key: B(tt),
		valueType: B(P("boolean", "integer", "enum")),
		scope: B(P(...Be)),
		initial: B(N),
		allowed: B(pt),
		description: V(H),
		ownerId: V(F("character")),
		derived: V({ type: "expression" }),
		externalContractId: V(F("external_contract")),
		resetRules: V(L(ft)),
		transitionRules: V(L(dt)),
		exclusions: V(L(z({
			variableId: B(F("variable")),
			value: B(N),
			otherValue: B(N),
			reason: B(D(1)),
			exceptions: V(L(ut))
		}))),
		externalUseDeclared: V(A)
	}),
	effect: z({
		operation: B(P("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset")),
		targetId: B(F()),
		value: V(N),
		condition: V(U),
		instanceId: V(F("item")),
		reason: V(D()),
		exceptionDetails: V(ut)
	}),
	assertion: z({
		subjectId: B(F()),
		predicate: B(D(1, 128)),
		value: B(at(N, F())),
		truthKind: B(P("author_truth", "testimony", "belief", "hypothesis")),
		holderId: V(F("character")),
		sourceIds: V(R("source", "assertion", "event", "scene", "dialogue_line")),
		evidenceLocation: V(G),
		validity: V(st),
		reason: V(D())
	}),
	foreshadow: z({
		question: B(H),
		intent: B(H),
		resolutionPolicy: B(P("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
		truthAssertionIds: V(R("assertion")),
		clueIds: V(R("disclosure")),
		payoffIds: V(R("disclosure")),
		requiredInfo: V(R("disclosure", "assertion")),
		alternativeInfo: V(W(R("disclosure", "assertion"), F("disclosure", "assertion"))),
		deadline: V(ct),
		presentationDeadline: V(G),
		exceptions: V(L(ut))
	}),
	disclosure: z({
		foreshadowId: B(F("foreshadow")),
		anchor: B(G),
		stage: B(P("hint", "suspicion", "reinforce", "reveal", "alternative")),
		role: B(P("clue", "payoff")),
		condition: V(U),
		knowledgeEffects: V(R("effect")),
		targetScope: V(ct)
	}),
	checkpoint: z({
		worldTick: V(M),
		contentVersionId: B(I("snapshot")),
		runtimeState: B(xt),
		presentationState: V(xt),
		presentationResults: V(L(yt)),
		contentRevision: V({ type: "revision" }),
		origin: V(P("full_play", "partial", "imported")),
		traceId: V(F("trace")),
		migration: V(z({
			sourceCheckpointId: B(F("checkpoint")),
			sourceVersionId: B(I("snapshot")),
			baseRevision: B({ type: "revision" }),
			method: B(P("migrate", "recreate"))
		}))
	}),
	trace: z({
		contentVersionId: B(I("snapshot")),
		startCheckpointId: B(F("checkpoint")),
		steps: B(L(z({
			nodeId: B(F("flow_node")),
			edgeIds: B(R("flow_edge")),
			before: B(xt),
			after: B(xt),
			presentationState: V(xt),
			conditionResults: V(L(yt)),
			operation: V(P("advance", "stub")),
			occurrenceId: V(D()),
			worldTick: V(M),
			externalMode: V(P("stub", "actual", "mixed")),
			externalValues: V(W(N, F("external_contract")))
		}))),
		contentRevision: V({ type: "revision" }),
		initialExternalValues: V(W(N, F("external_contract"))),
		initialStubBaseState: V(xt),
		initialStubValues: V(z({
			variables: V(W(N, F("variable"))),
			external: V(W(N, F("external_contract")))
		})),
		initialWorldTick: V(M),
		seed: V(D()),
		engineVersion: V(D()),
		externalMode: V(P("stub", "actual", "mixed")),
		coverage: V(Et),
		regressionDeclarations: V(z({
			projectRevision: B({ type: "revision" }),
			traceIds: B(R("trace"))
		})),
		reconfirmation: V(z({
			sourceTraceId: B(F("trace")),
			sourceVersionId: B(I("snapshot")),
			baseRevision: B({ type: "revision" }),
			startCheckpointId: V(F("checkpoint"))
		})),
		mode: V(P("flow", "chapters", null)),
		readingPath: V(at(Ct, P(null)))
	}),
	attachment: z({
		mediaType: B(D(1, 128)),
		contentHash: B({ type: "hash" }),
		byteSize: B(k(0, 33554432, !0)),
		assetPath: B({ type: "safe_path" }),
		displayName: V(D()),
		provenanceId: V(F("source")),
		licenseNote: V(D()),
		stage: V(P("reference", "temporary", "final")),
		revisionHistory: V(R("attachment"))
	}),
	source: z({
		sourceType: B(P("web", "file", "book", "observation")),
		locator: B(D(1)),
		accessedAt: V({ type: "datetime" }),
		excerptLocation: V(D()),
		interpretation: V(H),
		attachmentId: V(F("attachment")),
		redistributionAllowed: V(A)
	}),
	cue: z({
		anchor: B(G),
		cueType: B(D(1, 128)),
		attachmentId: V(F("attachment")),
		speakerId: V(F("character")),
		expression: V(D()),
		waitMs: V(k(0, void 0, !0)),
		camera: V({ type: "custom" }),
		mediaTime: V(k(0, void 0, !0)),
		stage: V(O)
	}),
	storyboard_frame: z({
		anchor: B(G),
		mediaStartMs: B(k(0, void 0, !0)),
		mediaEndMs: V(k(0, void 0, !0)),
		referenceAssetId: V(F("attachment")),
		finalAssetId: V(F("attachment")),
		cueIds: V(R("cue")),
		caption: V(H)
	}),
	localization: z({
		sourceLineId: B(F("dialogue_line")),
		language: B(D(1, 128)),
		sourceHash: B({ type: "hash" }),
		text: B(H),
		stage: V(P("draft", "reviewed", "needs_review")),
		reviewedBy: V(I("identity")),
		recordingIds: V(R("recording"))
	}),
	recording: z({
		sourceLineId: B(F("dialogue_line")),
		language: B(D(1, 128)),
		sourceHash: B({ type: "hash" }),
		translationId: V(F("localization")),
		attachmentId: V(F("attachment")),
		notes: V(H),
		stage: V(P("planned", "recorded", "reviewed", "needs_review")),
		reviewedBy: V(I("identity"))
	}),
	terminology: z({
		canonical: B(D(1, 128)),
		reading: B(O),
		variants: V(L(O, !0)),
		language: V(O),
		usageNotes: V(H),
		validity: V(st),
		exceptions: V(L(ut)),
		voiceOwnerId: V(F("character"))
	}),
	map: z({
		placeId: B(F("place")),
		coordinateSystem: B(P("normalized")),
		attachmentId: V(F("attachment")),
		parentMapId: V(F("map")),
		pins: V(L(z({
			id: B(j),
			placeId: B(F("place")),
			x: B(k(0, 1)),
			y: B(k(0, 1)),
			label: V(D())
		})))
	}),
	travel_route: z({
		fromPlaceId: B(F("place")),
		toPlaceId: B(F("place")),
		direction: B(P("one_way", "two_way")),
		method: V(D()),
		minimumTicks: V(M),
		maximumTicks: V(M),
		evidence: V(R()),
		validity: V(st)
	}),
	template: z({
		targetKind: B(P(...E)),
		fields: B(L(Dt)),
		description: V(D()),
		version: V({ type: "revision" }),
		defaults: V(W({ type: "custom" }, tt))
	}),
	collection: z({
		purpose: V(P("regression")),
		mode: B(P("dynamic", "fixed")),
		query: V({ type: "query" }),
		memberIds: V(R()),
		sort: V(z({
			field: B(P("name", "createdAt", "updatedAt", "kind")),
			direction: B(P("asc", "desc"))
		}))
	}),
	review: z({
		target: B(at(G, F())),
		targetVersionId: B(I("snapshot")),
		body: B(H),
		stage: B(P("open", "fixed", "verified")),
		assigneeId: V(I("identity")),
		quotedText: V(D()),
		resolution: V(H),
		sharedSource: V(z({
			connection: B(D(1)),
			sharedSnapshot: B(D(1)),
			comment: B(D(1)),
			publicVersion: B(D(1)),
			publicEntity: V(D(1)),
			publicRelation: V(D(1)),
			publicBlock: V(D(1)),
			startCp: V(k(0, void 0, !0)),
			endCp: V(k(0, void 0, !0)),
			projectionHash: B(D(64, 64)),
			commentBodyHash: B(D(64, 64)),
			quotedText: B(D()),
			observedStage: B(P("open", "fixed", "verified"))
		}))
	}),
	creative_brief: z({
		targetAudience: B(H),
		experience: B(H),
		theme: B(H),
		tone: B(H),
		scope: B(H),
		deliverableIds: V(R()),
		decisionIds: V(R("decision"))
	}),
	decision: z({
		subject: B(D(1)),
		reason: B(H),
		targetVersionId: B(I("snapshot")),
		outcome: B(P("accepted", "rejected", "deferred")),
		priority: V(O),
		requirementIds: V(L(O, !0)),
		reviewIds: V(R("review"))
	}),
	gameplay_spec: z({
		sceneId: B(F("scene")),
		action: B(H),
		mechanic: V(D()),
		tutorial: V(H),
		reward: V(N),
		questId: V(F("quest")),
		taskIds: V(R("production_task")),
		intentionalDifference: V(D())
	}),
	production_task: z({
		targetIds: B(R()),
		stage: B(P("writing", "review", "implementation", "translation", "recording", "verification", "publication")),
		progress: B(P("todo", "doing", "done", "needs_review")),
		assigneeId: V(I("identity")),
		deadline: V(z({
			date: B({ type: "date" }),
			timeZone: B(D(1, 128))
		})),
		dependsOn: V(R("production_task")),
		estimate: V(Ot),
		blockingReason: V(D())
	}),
	media_variant: z({
		previousVariantId: V(F("media_variant")),
		confirmationRecipientIds: V(L(I("identity"), !0)),
		medium: B(P("game", "novel", "video", "audio", "promotion", "custom")),
		baseSnapshotId: B(I("snapshot")),
		body: V(H),
		releaseAt: V({ type: "datetime" }),
		projectionProfileId: V(F("projection_profile")),
		sourceIds: V(R()),
		needsReview: V(A)
	}),
	voice_rule: z({
		characterId: B(F("character")),
		validity: B(st),
		firstPerson: V(O),
		addressing: V(D()),
		phrasing: V(D()),
		examples: V(H),
		exceptions: V(L(ut))
	}),
	external_contract: z({
		key: B(tt),
		owner: B(P("tool", "game")),
		inputType: B(D(1, 128)),
		outputType: B(D(1, 128)),
		missingPolicy: B(P("unknown", "block")),
		description: V(H),
		stubValues: V(L(N)),
		adapterProfileIds: V(R("projection_profile")),
		version: V(O)
	}),
	snapshot: z({
		versionLabel: B(D(1, 128)),
		contentHash: B({ type: "hash" }),
		immutable: B(P(!0)),
		parentVersionIds: V(L(I("snapshot"), !0)),
		releasedAt: V({ type: "datetime" }),
		referencedWorldVersionIds: V(L(I("snapshot"), !0))
	}),
	projection_profile: z({
		blockSources: V(W(I("block"), I("projection_record"))),
		citedVersions: V(L(z({
			sourceVersionId: B(I("snapshot")),
			profileId: B(F("projection_profile")),
			publicVersionId: B(j)
		}))),
		audience: B(D(1, 128)),
		includedIds: B(R()),
		namePolicy: B({ type: "name_policy" }),
		allowedKinds: V(L(P(...E), !0)),
		excludedFields: V(L(D(1), !0)),
		routeScope: V(ct),
		includeAuthorNotes: V(A),
		publicTitle: V(D()),
		publicTexts: V(W(kt, I("record"))),
		allowedFields: V(W(L(D(1), !0), P(...E))),
		allowedRelationIds: V(L(I("relation"), !0)),
		idPolicy: V(P("remap", "preserve")),
		publicIds: V(W(j, I("projection_record"))),
		sourceVersionId: V(I("snapshot")),
		publicValues: V(W(W(D(), D()), F("variable", "external_contract", "assertion"))),
		includedStatuses: V(L(P(...ze), !0)),
		publicVersionLabel: V(D()),
		approvedAttachmentIds: V(R("attachment"))
	})
}, K = (e) => !!e && typeof e == "object" && !Array.isArray(e) && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null), jt = new TextEncoder(), Mt = (e) => jt.encode(e).byteLength;
function Nt(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++, t++) {
		let t = e.charCodeAt(n), r = e.charCodeAt(n + 1);
		t >= 55296 && t <= 56319 && r >= 56320 && r <= 57343 && n++;
	}
	return t;
}
function Pt(e) {
	for (let t = 0; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(++t);
			if (!(n >= 56320 && n <= 57343)) return !1;
		} else if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function q(e, t, n, r = "VALIDATION_FAILED") {
	e.length < 256 && e.push({
		code: r,
		path: t,
		message: n
	});
}
function Ft(e) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(e)) return !1;
	let t = /* @__PURE__ */ new Date(`${e}T00:00:00Z`);
	return Number.isFinite(t.getTime()) && t.toISOString().slice(0, 10) === e;
}
function It(e) {
	switch (e.op) {
		case "constant": return z({
			op: B(P("constant")),
			value: B(A)
		});
		case "all":
		case "any": return z({
			op: B(P("all", "any")),
			children: B(L(U, !1, 1, 256))
		});
		case "not": return z({
			op: B(P("not")),
			child: B(U)
		});
		case "compare": return z({
			op: B(P("compare")),
			variableId: B(F("variable")),
			comparator: B(P("eq", "ne", "lt", "le", "gt", "ge", "in")),
			value: B(e.comparator === "in" ? L(N, !1, 1, 256) : N)
		});
		case "item": return z({
			op: B(P("item")),
			itemId: B(F("item")),
			quantity: B(k(1, void 0, !0))
		});
		case "known": return z({
			op: B(P("known")),
			assertionId: B(F("assertion")),
			holderId: B(F("character"))
		});
		case "visited": return z({
			op: B(P("visited")),
			entityId: B(F()),
			count: B(k(1, void 0, !0))
		});
		case "external": return z({
			op: B(P("external")),
			contractId: B(F("external_contract"))
		});
		default: return;
	}
}
function Lt(e) {
	let t = { type: "expression" };
	switch (e.op) {
		case "value": return z({
			op: B(P("value")),
			value: B(N)
		});
		case "variable": return z({
			op: B(P("variable")),
			variableId: B(F("variable"))
		});
		case "add":
		case "subtract":
		case "multiply": return z({
			op: B(P("add", "subtract", "multiply")),
			left: B(t),
			right: B(t)
		});
		case "if": return z({
			op: B(P("if")),
			condition: B(U),
			then: B(t),
			else: B(t)
		});
		default: return It(e);
	}
}
function Rt(e) {
	let t = B(I("calendar"));
	switch (e.mode) {
		case "instant": return z({
			mode: B(P("instant")),
			at: B(M),
			calendarId: t
		});
		case "interval": return z({
			mode: B(P("interval")),
			start: B(M),
			end: B(M),
			calendarId: t
		});
		case "uncertain": return z({
			mode: B(P("uncertain")),
			earliest: B(M),
			latest: B(M),
			calendarId: t,
			precision: B(D())
		});
		case "relative": return z({
			mode: B(P("relative")),
			anchorEventId: B(F("event")),
			anchorPoint: B(P("start", "end")),
			minOffset: B(M),
			maxOffset: B(M)
		});
		case "unknown": return z({
			mode: B(P("unknown")),
			reason: B(D())
		});
		default: return;
	}
}
function zt(e) {
	switch (e.op) {
		case "all":
		case "any": return z({
			op: B(P("all", "any")),
			children: B(L({ type: "query" }, !1, 1, 256))
		});
		case "kind": return z({
			op: B(P("kind")),
			value: B(P(...E))
		});
		case "text": return z({
			op: B(P("text")),
			value: B(D())
		});
		case "status": return z({
			op: B(P("status")),
			value: B(P(...ze))
		});
		case "participant": return z({
			op: B(P("participant")),
			characterId: B(F("character"))
		});
		case "production": return z({
			op: B(P("production")),
			value: B(P("todo", "doing", "done", "needs_review"))
		});
		case "chapter": return z({
			op: B(P("chapter")),
			chapterId: B(F("chapter"))
		});
		case "foreshadow": return z({
			op: B(P("foreshadow")),
			foreshadowId: nt(F("foreshadow")),
			resolutionPolicy: nt(P("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
			role: nt(P("clue", "payoff")),
			stage: nt(P("hint", "suspicion", "reinforce", "reveal", "alternative"))
		});
		default: return;
	}
}
function Bt(e) {
	if (!("mode" in e)) {
		let e = at(...[
			"alias",
			"replace",
			"exclude",
			"anonymize"
		].map((e) => Bt({ mode: e })));
		return z({
			defaultPolicy: V(e),
			byEntityId: V(W(e, F()))
		});
	}
	switch (e.mode) {
		case "alias": return z({
			mode: B(P("alias")),
			aliasId: B(I("alias"))
		});
		case "replace": return z({
			mode: B(P("replace")),
			replacement: B(D(1, 128))
		});
		case "exclude": return z({ mode: B(P("exclude")) });
		case "anonymize": return z({
			mode: B(P("anonymize")),
			publicId: B(j),
			publicName: B(D(1, 128))
		});
		default: return;
	}
}
var Vt = {
	start: B(k(0, void 0, !0)),
	end: B(k(0, void 0, !0))
}, Ht = L(z({
	id: B(j),
	kind: B(P("paragraph", "heading", "list_item", "quote")),
	text: B(D()),
	ruby: V(L(z({
		...Vt,
		text: B(D())
	}))),
	links: V(L(z({
		...Vt,
		target: B(G)
	}))),
	unresolvedAnnotations: V(L(ot))
}));
function J(e, t, n, r, i, a = 0, o) {
	if (r.length >= 256) return;
	if (a > 32) {
		q(r, n, "構造の深さが上限32を超えています。", "IMPORT_LIMIT");
		return;
	}
	let s = (e) => q(r, n, e);
	switch (e.type) {
		case "json": {
			let e = (t, n, i, a) => {
				if (i > 100) {
					q(r, n, "JSON階層の上限を超えています。", "IMPORT_LIMIT");
					return;
				}
				if (t !== null && typeof t != "string" && typeof t != "boolean" && !(typeof t == "number" && Number.isFinite(t))) {
					if (!t || typeof t != "object" || a.has(t)) {
						q(r, n, "通常のJSON値を指定してください。");
						return;
					}
					if (a.add(t), Array.isArray(t)) t.forEach((t, r) => e(t, `${n}[${r}]`, i + 1, a));
					else if (Object.getPrototypeOf(t) === Object.prototype || Object.getPrototypeOf(t) === null) for (let [o, s] of Object.entries(t)) [
						"__proto__",
						"prototype",
						"constructor"
					].includes(o) ? q(r, `${n}.${o}`, "予約済みのキーは使えません。") : e(s, `${n}.${o}`, i + 1, a);
					else q(r, n, "通常のJSONオブジェクトを指定してください。");
					a.delete(t);
				}
			};
			e(t, n, 0, /* @__PURE__ */ new Set());
			return;
		}
		case "text": {
			if (typeof t != "string") {
				s("文字列を入力してください。");
				return;
			}
			Pt(t) || s("文字列に不正なUnicodeがあります。");
			let n = Nt(t);
			e.min !== void 0 && n < e.min && s(`${e.min}文字以上で入力してください。`), e.max !== void 0 && n > e.max && s(`${e.max}文字以内で入力してください。`), e.maxBytes !== void 0 && Mt(t) > e.maxBytes && s("本文が1 MiBの上限を超えています。");
			return;
		}
		case "number":
			typeof t != "number" || !Number.isFinite(t) || e.integer && !Number.isSafeInteger(t) ? s(e.integer ? "安全な範囲の整数を入力してください。" : "有限の数値を入力してください。") : (e.min !== void 0 && t < e.min || e.max !== void 0 && t > e.max) && s("数値が許容範囲外です。");
			return;
		case "boolean":
			typeof t != "boolean" && s("真偽値を指定してください。");
			return;
		case "enum":
			e.values.includes(t) || s("宣言された値を選んでください。");
			return;
		case "id":
			(typeof t != "string" || !Ue.test(t)) && s("小文字のUUIDを指定してください。");
			return;
		case "ref":
			typeof t == "string" && (e.scope === "calendar" ? t.length > 0 : Ue.test(t)) || s(e.scope === "calendar" ? "暦IDが必要です。" : "参照先は小文字UUIDです。"), typeof t == "string" && i.push({
				id: t,
				path: n,
				kinds: e.kinds,
				scope: e.scope ?? "entity"
			});
			return;
		case "tick":
			S(t) || s("tickは38桁以内の正規整数文字列です。");
			return;
		case "revision":
			(typeof t != "string" || !We.test(t)) && s("revisionは0以上の整数文字列です。");
			return;
		case "datetime":
			(typeof t != "string" || !/^\d{4}-\d{2}-\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.\d+)?(?:Z|\+00:00)$/.test(t) || !Number.isFinite(Date.parse(t)) || !Ft(t.slice(0, 10))) && s("UTCのRFC 3339日時を指定してください。");
			return;
		case "date":
			(typeof t != "string" || !Ft(t)) && s("実在するYYYY-MM-DD形式の日付を指定してください。");
			return;
		case "hash":
			(typeof t != "string" || !/^[0-9a-f]{64}$/.test(t)) && s("SHA-256は小文字16進数64文字です。");
			return;
		case "safe_path":
			(typeof t != "string" || !t || t.startsWith("/") || t.includes("\\") || t.includes("\0") || /^[a-zA-Z]:/.test(t) || t.split("/").some((e) => !e || e === "." || e === "..") || /[\u0000-\u001f\u007f]/.test(t)) && s("安全な相対パスを指定してください。");
			return;
		case "array":
			if (!Array.isArray(t)) {
				s("配列を指定してください。");
				return;
			}
			if (t.length > (e.max ?? 1e5) || e.min !== void 0 && t.length < e.min) {
				s("配列の件数が許容範囲外です。");
				return;
			}
			e.unique && new Set(t.map((e) => typeof e == "object" ? JSON.stringify(e) : e)).size !== t.length && s("同じ値を集合内で重複保存できません。"), t.forEach((t, s) => J(e.item, t, `${n}[${s}]`, r, i, a + 1, o));
			return;
		case "object":
			if (!K(t)) {
				s("オブジェクトを指定してください。");
				return;
			}
			for (let i of Object.keys(t)) Object.hasOwn(e.fields, i) || q(r, `${n}.${i}`, "未知の項目は保存できません。");
			for (let s of Object.keys(e.fields)) {
				let c = e.fields[s], l = t[s], u = `${n}.${s}`;
				if (l === void 0) {
					c.required && q(r, u, "必須項目です。");
					continue;
				}
				l === null && c.nullable || J(c.schema, l, u, r, i, a + 1, o);
			}
			return;
		case "record":
			if (!K(t)) {
				s("項目の辞書を指定してください。");
				return;
			}
			for (let [s, c] of Object.entries(t)) {
				if ([
					"__proto__",
					"prototype",
					"constructor"
				].includes(s)) {
					q(r, `${n}.${s}`, "予約済みのキーは使えません。");
					continue;
				}
				e.key && J(e.key, s, `${n}.${s}.$key`, r, i, a + 1, o), J(e.value, c, `${n}.${s}`, r, i, a + 1, o);
			}
			return;
		case "union": {
			let s;
			for (let r of e.choices) {
				let e = [], c = [];
				if (J(r, t, n, e, c, a + 1, o), !e.length) {
					i.push(...c);
					return;
				}
				(!s || e.length < s.length) && (s = e);
			}
			r.push(...s ?? [{
				code: "VALIDATION_FAILED",
				path: n,
				message: "対応する型ではありません。"
			}]);
			return;
		}
		case "typed": {
			if (!K(t)) {
				s("型と値を指定してください。");
				return;
			}
			let e;
			switch (t.type) {
				case "boolean":
					e = A;
					break;
				case "integer":
					e = k(void 0, void 0, !0);
					break;
				case "enum":
				case "text":
					e = D();
					break;
				case "ref":
					e = F();
					break;
				case "unknown":
					J(z({
						type: B(P("unknown")),
						value: {
							schema: D(),
							required: !0,
							nullable: !0
						},
						reason: B(D())
					}), t, n, r, i, a + 1, o), t.value !== null && s("未定値のvalueはnullです。");
					return;
				default:
					s("未知の値型です。");
					return;
			}
			J(z({
				type: B(P(t.type)),
				value: B(e)
			}), t, n, r, i, a + 1, o);
			return;
		}
		case "custom":
			if (t === null) return;
			if (typeof t == "string") J(D(), t, n, r, i, a, o);
			else if (typeof t == "number") J(k(), t, n, r, i, a, o);
			else if (typeof t == "boolean") return;
			else K(t) && t.type === "ref" ? J(z({
				type: B(P("ref")),
				value: B(F())
			}), t, n, r, i, a + 1, o) : K(t) && t.type === "date" ? J(z({
				type: B(P("date")),
				value: B({ type: "date" })
			}), t, n, r, i, a + 1, o) : s("カスタム値は文字列・数値・真偽・日付・参照またはnullです。");
			return;
		case "richtext": {
			if (J(Ht, t, n, r, i, a + 1, o), !Array.isArray(t)) return;
			let c = 0, l = 0, u = /* @__PURE__ */ new Set();
			t.forEach((e, t) => {
				if (!K(e) || typeof e.text != "string") return;
				let i = Nt(e.text);
				if (c += Mt(e.text), l += i, typeof e.id == "string" && (u.has(e.id) && q(r, `${n}[${t}].id`, "段落IDが重複しています。"), u.add(e.id)), Array.isArray(e.unresolvedAnnotations)) {
					for (let t of e.unresolvedAnnotations) if (K(t)) for (let e of [
						"originalText",
						"reason",
						"reading"
					]) typeof t[e] == "string" && (c += Mt(t[e]));
				}
				for (let a of ["ruby", "links"]) Array.isArray(e[a]) && e[a].forEach((e, o) => {
					K(e) && (typeof e.start == "number" && typeof e.end == "number" && (e.start >= e.end || e.end > i) && q(r, `${n}[${t}].${a}[${o}]`, "文字範囲はコードポイントで数え、本文内の半開区間を指定してください。"), typeof e.text == "string" && (c += Mt(e.text)));
				});
			}), c > 1048576 && s("本文フィールドが1 MiBを超えています。"), e.max !== void 0 && l > e.max && s(`要約は${e.max}文字以内です。`);
			return;
		}
		case "condition":
		case "expression": {
			let a = o ?? {
				counter: { count: 0 },
				depth: 0
			};
			if (a.counter.count++, a.counter.count > 256 || a.depth >= 16) {
				s("条件・式は深さ16、ノード256までです。");
				return;
			}
			if (!K(t)) {
				s("条件・式は型付きASTで指定してください。");
				return;
			}
			let c = e.type === "condition" ? It(t) : Lt(t);
			if (!c) {
				s("未知の条件・式opです。");
				return;
			}
			J(c, t, n, r, i, 0, {
				counter: a.counter,
				depth: a.depth + 1
			});
			return;
		}
		case "time": {
			if (!K(t)) {
				s("日時はTimeSpecで指定してください。");
				return;
			}
			let e = Rt(t);
			if (!e) {
				s("未知の日時modeです。");
				return;
			}
			let c = r.length;
			J(e, t, n, r, i, a + 1, o), r.length === c && (t.mode === "interval" && w(t.start, t.end) >= 0 && s("期間はstart < endの半開区間です。"), t.mode === "uncertain" && w(t.earliest, t.latest) > 0 && s("earliestはlatest以下です。"), t.mode === "relative" && w(t.minOffset, t.maxOffset) > 0 && s("minOffsetはmaxOffset以下です。"));
			return;
		}
		case "query":
		case "name_policy": {
			if (!K(t)) {
				s("型付きのオブジェクトを指定してください。");
				return;
			}
			let c = e.type === "query" ? zt(t) : Bt(t);
			if (!c) {
				s("未知の規則です。");
				return;
			}
			let l = r.length;
			J(c, t, n, r, i, a + 1, o), e.type === "query" && t.op === "foreshadow" && r.length === l && ![
				"foreshadowId",
				"resolutionPolicy",
				"role",
				"stage"
			].some((e) => t[e] !== void 0 && t[e] !== null) && q(r, n, "伏線検索には対象・回収方針・開示役割・段階のいずれかを指定してください。");
			return;
		}
	}
}
var Ut = {
	id: B(j),
	projectId: B(I("project")),
	kind: B(P(...E)),
	revision: B({ type: "revision" }),
	name: B(O),
	status: B(P(...ze)),
	visibility: B(P("private", "team", "projection")),
	retainIfUnreferenced: V(A),
	projectionProfileId: V(F("projection_profile")),
	templateId: V(F("template")),
	createdAt: B({ type: "datetime" }),
	updatedAt: B({ type: "datetime" }),
	deletedAt: V({ type: "datetime" }),
	deletionOperationId: V(j),
	customValues: B(W({ type: "custom" }, tt))
}, Wt = z({
	id: B(j),
	projectId: B(I("project")),
	revision: B({ type: "revision" }),
	fromId: B(F()),
	toId: B(F()),
	relationType: B(D(1, 128)),
	direction: B(P("forward", "symmetric")),
	validity: B(st),
	evidenceIds: B(R()),
	status: B(P(...ze)),
	visibility: B(P("private", "team", "projection")),
	projectionProfileId: V(F("projection_profile")),
	deletedAt: V({ type: "datetime" }),
	deletionOperationId: V(j)
}), Gt = /* @__PURE__ */ new Map();
function Kt(e) {
	let t = At[e], n = Gt.get(e);
	if (n?.data === t) return n.record;
	let r = z({
		...Ut,
		kind: B(P(e)),
		data: B(t)
	});
	return Gt.set(e, {
		data: t,
		record: r
	}), r;
}
function qt(e, t, n, r = []) {
	let i = [];
	return J(e, t, n, i, r), i.length ? {
		ok: !1,
		issues: i
	} : {
		ok: !0,
		value: t
	};
}
function Jt(e, t = "condition") {
	return qt(U, e, t);
}
function Yt(e, t = "value") {
	return qt(N, e, t);
}
function Xt(e, t = "runtimeState") {
	let n = qt(xt, e, t);
	if (!n.ok) return n;
	let r = [], i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	return n.value.itemInstances.forEach((e, n) => {
		i.has(e.instanceId) && q(r, `${t}.itemInstances[${n}].instanceId`, "物品個体のIDが重複しています。"), i.add(e.instanceId), (e.ownerId && e.locationId || e.consumed && e.quantity !== 0 || !e.consumed && e.quantity < 1) && q(r, `${t}.itemInstances[${n}]`, "物品の所在・所有・消費状態・数量が不整合です。");
	}), n.value.assertions.forEach((e, n) => {
		let i = `${e.assertionId}/${e.holderId}`;
		a.has(i) && q(r, `${t}.assertions[${n}]`, "同じ人物・事実の認識が重複しています。"), a.add(i);
	}), r.length ? {
		ok: !1,
		issues: r
	} : n;
}
function Zt(e, t, n, r = "presentationResults") {
	let i = qt(L(yt), t, r);
	if (!i.ok) return i.issues;
	let a = [], o = new Set(e.seenIds), s = /* @__PURE__ */ new Set(), c = n.find((t) => t.kind === "flow_node" && t.id === e.presentationPosition && !t.deletedAt && t.status !== "rejected"), l = n.filter((e) => {
		if (e.kind !== "disclosure" || e.deletedAt || e.status === "rejected" || !c || !o.has(c.id)) return !1;
		let t = e.data.anchor;
		return t.positionStatus !== "unresolved" && (t.entityId === c.id || t.entityId === c.data.sceneId) && (!t.blockId || o.has(t.blockId)) && (!t.lineId || o.has(t.lineId));
	}), u = new Set(l.map((e) => e.id));
	i.value.forEach((t, n) => {
		let i = `${r}[${n}]`;
		s.has(t.targetId) && q(a, `${i}.targetId`, "初期提示の条件結果が重複しています。"), s.add(t.targetId), u.has(t.targetId) || q(a, `${i}.targetId`, "初期提示の対象ではない開示の条件結果です。", "REFERENCE_INVALID"), t.value === "unknown" && q(a, `${i}.value`, "未確認の開示条件では初期提示を完了できません。"), t.value === "true" && !o.has(t.targetId) && q(a, `${i}.value`, "提示した条件結果と既読の証跡が一致しません。"), t.value === "false" && o.has(t.targetId) && e.provenance === "full_play" && q(a, `${i}.value`, "提示済みの開示を初期条件のfalseで取り消すことはできません。");
	});
	for (let e of l) s.has(e.id) || q(a, r, "初期提示の開示条件結果が不足しています。");
	return a;
}
function Qt(e, t = "effect") {
	return qt(At.effect, e, t);
}
function $t(e, t, n) {
	if (!K(e) || !E.includes(e.kind)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: `${t}.kind`,
			message: "未対応の情報種別です。"
		}]
	};
	let r = qt(Kt(e.kind), e, t, n);
	if (!r.ok) return r;
	let i = [];
	return en(r.value, t, i), i.length ? {
		ok: !1,
		issues: i
	} : r;
}
function Y(e, t, n = "value", r = !0) {
	let i = [], a = e.data;
	if (t.type === "unknown") return r || q(i, n, "未定の値はこの操作で使えません。", "CONDITION_UNKNOWN"), i;
	if (t.type !== a.valueType) return q(i, n, "状態変数の宣言型と値の型が一致しません。"), i;
	if (t.type === "integer") {
		let e = a.allowed.min ?? -2147483647, r = a.allowed.max ?? 2147483647;
		(!Number.isSafeInteger(t.value) || t.value < e || t.value > r) && q(i, n, "状態変数の値が宣言した整数範囲外です。");
	}
	return (t.type === "enum" || t.type === "boolean") && a.allowed.values && !a.allowed.values.includes(t.value) && q(i, n, "状態変数の値が許容集合にありません。"), i;
}
function en(e, t, n) {
	let r = (e, r) => q(n, `${t}.${e}`, r);
	![
		"dialogue_line",
		"effect",
		"assertion",
		"disclosure",
		"cue",
		"storyboard_frame",
		"localization",
		"recording",
		"checkpoint",
		"trace"
	].includes(e.kind) && !e.name.trim() && (e.kind === "event" ? Je(e.data.summary).trim() || r("data.summary", "名称または要約を入力してください。") : r("name", "名称を入力してください。")), e.visibility === "projection" && !e.projectionProfileId && r("projectionProfileId", "公開投影の対象プロファイルを指定してください。"), e.deletedAt && !e.deletionOperationId && r("deletionOperationId", "削除には削除操作IDが必要です。"), !e.deletedAt && e.deletionOperationId && r("deletionOperationId", "削除されていない情報に削除操作IDは保存できません。");
	for (let t of Object.keys(e.customValues)) {
		let n = At[e.kind];
		(Object.hasOwn(Ut, t) || n.type === "object" && Object.hasOwn(n.fields, t)) && r(`customValues.${t}`, "標準項目とカスタム項目のキーが衝突しています。");
	}
	switch (e.kind) {
		case "event":
			for (let [t, n] of (e.data.constraints ?? []).entries()) n.type === "end_gap" && w(n.minimumTicks, n.maximumTicks) > 0 && r(`data.constraints[${t}]`, "日時差の最小値は最大値以下です。");
			break;
		case "item":
			e.data.itemMode === "instance" && !e.data.typeId && r("data.typeId", "物品の個体には種類への参照が必要です。");
			break;
		case "flow_node":
			e.data.nodeType === "terminal" && !e.data.terminalReason?.trim() && r("data.terminalReason", "意図した終端には終了理由が必要です。"), e.data.nodeType === "call" && !e.data.childGraphId && r("data.childGraphId", "呼出ノードには子分岐図が必要です。");
			break;
		case "variable": {
			let i = e.data;
			i.scope === "character" && !i.ownerId && r("data.ownerId", "人物scopeには所有人物が必要です。"), i.valueType === "integer" ? (i.allowed.values && r("data.allowed.values", "整数には集合ではなくmin/maxを指定してください。"), (i.allowed.min ?? -2147483647) > (i.allowed.max ?? 2147483647) && r("data.allowed", "整数の最小値は最大値以下です。")) : ((i.allowed.min != null || i.allowed.max != null) && r("data.allowed", "この型に数値範囲は設定できません。"), i.valueType === "enum" && (!i.allowed.values?.length || i.allowed.values.some((e) => typeof e != "string" || !e)) && r("data.allowed.values", "enumには空でない文字列の候補集合が必要です。"), i.valueType === "boolean" && i.allowed.values?.some((e) => typeof e != "boolean") && r("data.allowed.values", "booleanの候補は真偽値です。")), n.push(...Y(e, i.initial, `${t}.data.initial`));
			for (let [r, a] of (i.resetRules ?? []).entries()) n.push(...Y(e, a.value, `${t}.data.resetRules[${r}].value`));
			new Set((i.resetRules ?? []).map((e) => e.on)).size !== (i.resetRules ?? []).length && r("data.resetRules", "同じ終了時点の初期化規則は一つにしてください。");
			for (let [a, o] of (i.transitionRules ?? []).entries()) n.push(...Y(e, o.from, `${t}.data.transitionRules[${a}].from`, !1), ...Y(e, o.to, `${t}.data.transitionRules[${a}].to`, !1)), o.exception && !o.reason?.trim() && r(`data.transitionRules[${a}].reason`, "例外遷移には理由が必要です。");
			for (let [a, o] of (i.exclusions ?? []).entries()) n.push(...Y(e, o.value, `${t}.data.exclusions[${a}].value`, !1)), o.reason.trim() || r(`data.exclusions[${a}].reason`, "相互排他には理由が必要です。");
			break;
		}
		case "effect":
			[
				"set",
				"add",
				"move"
			].includes(e.data.operation) && (!e.data.value || e.data.value.type === "unknown") && r("data.value", "この効果には既知の入力値が必要です。"), e.data.operation === "add" && e.data.value?.type !== "integer" && r("data.value", "addはinteger値だけを使えます。"), e.data.operation === "move" && e.data.value?.type !== "ref" && r("data.value", "moveには所在・所有先のref値が必要です。"), e.data.operation === "consume" && !e.data.reason?.trim() && r("data.reason", "消費・破壊には理由が必要です。"), ["grant", "consume"].includes(e.data.operation) && e.data.value != null && (e.data.value.type !== "integer" || e.data.value.value < 1) && r("data.value", "物品数量は正のintegerです。"), e.data.operation === "assert" && e.data.value != null && e.data.value.type !== "boolean" && r("data.value", "assertの真偽入力はbooleanです。");
			break;
		case "assertion":
			e.data.truthKind === "belief" && !e.data.holderId && r("data.holderId", "beliefには認識を持つ人物が必要です。"), e.data.truthKind === "testimony" && !e.data.sourceIds?.length && r("data.sourceIds", "testimonyには出所が必要です。");
			break;
		case "storyboard_frame":
			e.data.mediaEndMs != null && e.data.mediaEndMs < e.data.mediaStartMs && r("data.mediaEndMs", "演出の終了は開始以上です。");
			break;
		case "travel_route":
			(e.data.minimumTicks != null && C(e.data.minimumTicks) < 0n || e.data.maximumTicks != null && C(e.data.maximumTicks) < 0n) && r("data", "移動所要時間は0以上です。"), e.data.minimumTicks != null && e.data.maximumTicks != null && w(e.data.minimumTicks, e.data.maximumTicks) > 0 && r("data.maximumTicks", "最大所要時間は最小以上です。");
			break;
		case "collection":
			e.data.purpose === "regression" && e.data.mode !== "fixed" && r("data.mode", "回帰経路集合は宣言した固定経路の集合です。"), e.data.mode === "dynamic" && !e.data.query && r("data.query", "動的一覧には型付き検索条件が必要です。"), e.data.mode === "fixed" && !Array.isArray(e.data.memberIds) && r("data.memberIds", "固定一覧にはID配列が必要です。");
			break;
		case "template":
			n.push(...Ie(e.data, `${t}.data`));
			break;
		case "production_task":
			if (e.data.deadline) try {
				new Intl.DateTimeFormat("ja", { timeZone: e.data.deadline.timeZone });
			} catch {
				r("data.deadline.timeZone", "有効なタイムゾーンを指定してください。");
			}
			if (e.data.estimate) {
				let t = e.data.estimate;
				t.value == null == (t.range == null) && r("data.estimate", "見積もりはvalueまたはrangeの一つです。"), t.range && t.range.min > t.range.max && r("data.estimate.range", "見積範囲が逆転しています。"), ["reading_minutes", "playing_minutes"].includes(t.unit) && !t.speed && r("data.estimate.speed", "本文量からの時間見積もりには速度が必要です。");
			}
			break;
		case "review": {
			let t = e.data.sharedSource;
			if (!t) break;
			try {
				let e = new URL(t.connection);
				(e.origin !== t.connection || e.username || e.password || !["https:", "http:"].includes(e.protocol) || e.protocol === "http:" && ![
					"localhost",
					"127.0.0.1",
					"[::1]"
				].includes(e.hostname)) && r("data.sharedSource.connection", "指摘の専用接続先のoriginを確認してください。");
			} catch {
				r("data.sharedSource.connection", "指摘の接続先が不正です。");
			}
			(!Ue.test(t.sharedSnapshot) || !Ue.test(t.comment) || !t.publicVersion || !/^([a-f0-9]{64})$/.test(t.projectionHash) || !/^([a-f0-9]{64})$/.test(t.commentBodyHash)) && r("data.sharedSource", "元の公開版・指摘・hashが不正です。"), (!!t.publicEntity == !!t.publicRelation || t.publicRelation && (t.publicBlock !== void 0 || t.startCp !== void 0 || t.endCp !== void 0) || t.publicBlock !== void 0 && (t.startCp === void 0 || t.endCp === void 0 || t.endCp <= t.startCp) || t.publicBlock === void 0 && (t.startCp !== void 0 || t.endCp !== void 0)) && r("data.sharedSource", "元指摘の対象とUnicode位置の組合せを確認してください。");
			break;
		}
		case "localization":
		case "recording": /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(e.data.language) || r("data.language", "言語コードを指定してください（例: ja、en-US）。");
	}
	tn(e.data, `${t}.data`, n);
}
function tn(e, t, n, r = 0) {
	if (r > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, i) => tn(e, `${t}[${i}]`, n, r + 1));
		return;
	}
	let i = e;
	if ("worldRange" in i && K(i.worldRange)) {
		let e = i.worldRange;
		S(e.start) && S(e.end) && w(e.start, e.end) >= 0 && q(n, `${t}.worldRange`, "有効期間はstart < endの半開区間です。");
	}
	"entityId" in i && typeof i.start == "number" && typeof i.end == "number" && i.start >= i.end && q(n, t, "位置の文字範囲はstart < endです。");
	for (let [e, a] of Object.entries(i)) tn(a, `${t}.${e}`, n, r + 1);
}
function nn(e) {
	let t = [];
	return J(Kt(e.kind), e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function rn(e) {
	let t = [];
	return J(Wt, e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function an(e) {
	return e.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
}
function on(e, t, n) {
	let r = structuredClone(e), i = (e) => n instanceof Map ? n.get(e) : Object.hasOwn(n, e) ? n[e] : void 0, a = [...t].sort((e, t) => {
		let n = e.path.endsWith(".$key"), r = t.path.endsWith(".$key");
		return Number(n) - Number(r) || (n ? an(t.path).length - an(e.path).length : 0);
	});
	for (let e of a) {
		let t = i(e.id);
		if (!t) continue;
		let n = an(e.path), a = n.at(-1) === "$key";
		a && n.pop();
		let o = n.pop();
		if (!o) continue;
		let s = r;
		for (let e of n) s = s[e];
		if (a) {
			if (t === o) continue;
			if (Object.hasOwn(s, t)) throw Error("REFERENCE_INVALID: 参照の統合で辞書キーが衝突します。保持する内容を選んでください。");
			s[t] = s[o], delete s[o];
		} else s[o] = t;
	}
	return r;
}
function sn(e, t) {
	let n = on(e, nn(e), t), r = (e) => (t instanceof Map ? t.get(e) : t[e]) ?? e;
	return (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings && (n.kind === "scene" || n.kind === "flow_node") && n.data.reuse && (n.data.reuse.bindings = Object.fromEntries(Object.entries(e.data.reuse.bindings).map(([e, t]) => [r(e), r(t)]))), n;
}
function cn(e, t) {
	return on(e, rn(e), t);
}
var ln = z({
	projectId: B(j),
	immutableSnapshotId: B(j),
	contentHash: B({ type: "hash" })
}), un = z({
	id: B(j),
	name: B(D(1, 128)),
	view: B(D(1)),
	entityIds: B(R()),
	settings: B(W(at(D(), k(), A, P(null)), tt))
}), dn = {
	projectId: B(j),
	name: B(D(1, 128)),
	formatVersion: B(P(he)),
	revision: B({ type: "revision" }),
	calendarId: B(D(1)),
	mainStart: B(M),
	worldReferences: B(L(ln))
}, fn = [
	...Object.keys(dn),
	"calendars",
	"entities",
	"relations",
	"views"
], pn = [...fn, "authorAlternatives"], mn = L({ type: "json" }, !1, 0, 100);
function hn(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set([e.projectId]), o = /* @__PURE__ */ new Set();
	e.worldReferences.forEach((e, t) => {
		i.has(e.projectId) && q(r, `${n}.worldReferences[${t}]`, "同じ世界の複数の版を同時に参照すると、IDの参照先が曖昧になります。一つの固定版を選んでください。", "REFERENCE_INVALID"), i.add(e.projectId);
	});
	let s = [{
		content: e,
		location: n
	}, ...t.map((t) => ({
		content: t,
		location: `${n}.worldReferences[${e.worldReferences.findIndex((e) => e.projectId === t.projectId)}]`
	}))], c = /* @__PURE__ */ new Map();
	for (let [e, { content: t, location: n }] of s.entries()) {
		e > 0 && (a.has(t.projectId) && q(r, n, "同じ作品・世界の複数の内容が現在の参照範囲に含まれています。固定版を一つにしてください。", "REFERENCE_INVALID"), a.add(t.projectId));
		for (let [e, i] of t.calendars.entries()) {
			let t = c.get(i.id);
			t && !ke(t, i) && q(r, `${n}.calendars[${e}].id`, "同じ暦IDに異なる定義があります。固定版の日時を読み替えず、暦IDを明示して対応付けてください。", "REFERENCE_INVALID"), c.set(i.id, i);
		}
		for (let [e, i] of [["entities", t.entities], ["relations", t.relations]]) i.forEach((i, a) => {
			let s = `${n}.${e}[${a}]`;
			o.has(i.id) && q(r, `${s}.id`, "現在の作品と参照中の共通世界でentity・relationのIDが衝突しています。曖昧な参照は保存できません。", "REFERENCE_INVALID"), o.add(i.id), i.projectId !== t.projectId && q(r, `${s}.projectId`, "参照範囲のレコードが所属する作品・世界と一致しません。", "REFERENCE_INVALID");
		});
	}
}
function gn(e, t, n, r, i = /* @__PURE__ */ new Map(), a) {
	let o = [];
	if (!K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: t,
			message: "作品はオブジェクトです。"
		}]
	};
	for (let n of Object.keys(e)) fn.includes(n) || q(o, `${t}.${n}`, "作品に未知の項目があります。");
	let s = Object.fromEntries(Object.keys(dn).filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]]));
	J(z(dn), s, t, o, []), e.formatVersion !== "1.0.0" && q(o, `${t}.formatVersion`, "対応していない形式版です。", "FORMAT_UNSUPPORTED");
	for (let n of [
		"entities",
		"relations",
		"calendars",
		"views"
	]) Array.isArray(e[n]) || q(o, `${t}.${n}`, "必須の配列です。");
	if (o.length) return {
		ok: !1,
		issues: o
	};
	let c = e.entities, l = e.relations, u = e.calendars;
	if (c.length + l.length > 1e5) return {
		ok: !1,
		issues: [{
			code: "IMPORT_LIMIT",
			path: t,
			message: "entityとrelationの合計は100,000件までです。"
		}]
	};
	let d = new Map(a?.previous.entities.map((e) => [e.id, e])), f = new Map(a?.previous.relations.map((e) => [e.id, e])), p = /* @__PURE__ */ new WeakMap(), m = /* @__PURE__ */ new WeakMap(), h = (e, t) => e.map((e) => ({
		...e,
		path: e.path.slice(t.length + 1)
	}));
	c.forEach((e, n) => {
		if (a && K(e) && d.get(e.id) === e) return;
		let r = `${t}.entities[${n}]`, i = [], s = $t(e, r, i);
		s.ok ? p.set(s.value, h(i, r)) : o.push(...s.issues);
	}), l.forEach((e, n) => {
		if (a && K(e) && Object.is(f.get(e.id), e)) return;
		let r = `${t}.relations[${n}]`, i = [], s = qt(Wt, e, r, i);
		s.ok ? m.set(s.value, h(i, r)) : o.push(...s.issues);
	}), u.forEach((e, n) => {
		let r = xe(e, `${t}.calendars[${n}]`);
		r.ok || o.push(...r.issues);
	});
	let ee = [];
	if (J(L(un), e.views, `${t}.views`, o, ee), o.length) return {
		ok: !1,
		issues: o.slice(0, 256)
	};
	let _ = e, te = [...i].map(([e, t]) => ({
		id: e,
		content: t,
		contentHash: "",
		createdAt: "",
		versionLabel: ""
	}));
	if (o.push(...me(_, te, t)), o.length) return {
		ok: !1,
		issues: o.slice(0, 256)
	};
	let v = _.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) ? de(_, te) : _, y = new Set(v.worldReferences.map((e) => e.projectId)), ne = n.worldSnapshots ? g(v, n.worldSnapshots) : void 0;
	if (ne) for (let e of ne.errors) q(o, `${t}.worldReferences`, e, "REFERENCE_INVALID");
	let b = ne?.worlds ?? (n.worlds ?? []).filter((e) => y.has(e.projectId));
	if (c.length + l.length + b.reduce((e, t) => e + t.entities.length + t.relations.length, 0) > 1e5 && q(o, t, "参照世界を含むレコード数が100,000件を超えています。", "IMPORT_LIMIT"), hn(_, b, t, o), v !== _ && hn(v, b, `${t}.reuse`, o), o.length) return {
		ok: !1,
		issues: o.slice(0, 256)
	};
	let re = [...v.entities, ...b.flatMap((e) => e.entities)], x = new Map(re.map((e) => [e.id, e])), ie = new Map([..._.relations, ...b.flatMap((e) => e.relations)].map((e) => [e.id, e])), ae = new Set([..._.calendars, ...b.flatMap((e) => e.calendars)].map((e) => e.id)), oe = /* @__PURE__ */ new Set();
	for (let [e, n] of [["entities", _.entities], ["relations", _.relations]]) n.forEach((n, r) => {
		oe.has(n.id) && q(o, `${t}.${e}[${r}].id`, "entityとrelationのIDは作品内で一意です。"), oe.add(n.id), n.projectId !== _.projectId && q(o, `${t}.${e}[${r}].projectId`, "レコードが別の作品に属しています。", "REFERENCE_INVALID");
	});
	let se = _.calendars.map((e) => e.id);
	new Set(se).size !== se.length && q(o, `${t}.calendars`, "暦IDが重複しています。"), se.includes(_.calendarId) || q(o, `${t}.calendarId`, "作品の暦が定義されていません。", "REFERENCE_INVALID");
	let ce = _.worldReferences.map((e) => `${e.projectId}/${e.immutableSnapshotId}`);
	(new Set(ce).size !== ce.length || _.worldReferences.some((e) => e.projectId === _.projectId)) && q(o, `${t}.worldReferences`, "共通世界参照の重複または自己参照があります。");
	let le = /* @__PURE__ */ new Map(), ue = /* @__PURE__ */ new Map();
	for (let e of re) _n(e.data, e.id, le, ue, o, `${t}.entities.${e.id}.data`);
	let fe = /* @__PURE__ */ new Set([
		...x.keys(),
		...ie.keys(),
		...le.keys()
	]);
	for (let e of re) if (e.kind === "flow_node" && e.data.trigger?.id && fe.add(e.data.trigger.id), e.kind === "projection_profile") {
		for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) K(t) && typeof t.id == "string" && fe.add(t.id);
	}
	let pe = b.flatMap((e) => [...e.entities.flatMap(nn), ...e.relations.flatMap(rn)]).filter((e) => e.scope === "snapshot" && n.worldSnapshots?.[e.id] && b.some((t) => t.projectId === n.worldSnapshots?.[e.id].projectId)).map((e) => e.id), he = /* @__PURE__ */ new Set([
		...r,
		...pe,
		_.projectId,
		...re.filter((e) => e.kind === "snapshot").map((e) => e.id),
		...(ne?.references ?? v.worldReferences).map((e) => e.immutableSnapshotId)
	]), ge = {
		entities: x,
		relations: ie,
		blocks: le,
		calendars: ae,
		projects: /* @__PURE__ */ new Set([_.projectId, ...(ne?.references ?? v.worldReferences).map((e) => e.projectId)]),
		projectionIds: fe
	}, _e = /* @__PURE__ */ new Map();
	function ve(e) {
		if (e === _.projectId && !_.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings)) return ge;
		let r = _e.get(e);
		if (r) return r;
		let a = e === _.projectId ? _ : i.get(e) ?? n.worldSnapshots?.[e];
		if (!a) return;
		let s = a;
		try {
			s.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) && (s = de(s, te));
		} catch {
			return;
		}
		let c = n.worldSnapshots ? g(s, n.worldSnapshots) : void 0;
		if (c) for (let n of c.errors) q(o, `${t}.versions.${e}.worldReferences`, n, "REFERENCE_INVALID");
		let l = c?.worlds ?? (n.worlds ?? []).filter((e) => s.worldReferences.some((t) => t.projectId === e.projectId)), u = o.length;
		if (hn(s, l, `${t}.versions.${e}`, o), o.length !== u) return;
		let d = [...s.entities, ...l.flatMap((e) => e.entities)], f = /* @__PURE__ */ new Map();
		for (let e of d) K(e) && _n(e.data, e.id, f, /* @__PURE__ */ new Map(), [], "version");
		let p = /* @__PURE__ */ new Set([
			...d.map((e) => e.id),
			...s.relations.map((e) => e.id),
			...l.flatMap((e) => e.relations.map((e) => e.id)),
			...f.keys()
		]);
		for (let e of d) if (e.kind === "flow_node" && e.data.trigger?.id && p.add(e.data.trigger.id), e.kind === "projection_profile") {
			for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) K(t) && typeof t.id == "string" && p.add(t.id);
		}
		let m = {
			entities: new Map(d.filter((e) => K(e)).map((e) => [e.id, e])),
			relations: new Map([...s.relations, ...l.flatMap((e) => e.relations)].filter((e) => K(e)).map((e) => [e.id, e])),
			blocks: f,
			calendars: new Set([...s.calendars, ...l.flatMap((e) => e.calendars)].map((e) => e.id)),
			projects: /* @__PURE__ */ new Set([s.projectId, ...l.map((e) => e.projectId)]),
			projectionIds: p
		};
		return _e.set(e, m), m;
	}
	function S(e, t = "", r = ge) {
		let i = t ? `${t}.${e.path}` : e.path, a = !0;
		if (e.scope === "entity") {
			let t = r.entities.get(e.id);
			a = !!t, t && e.kinds && !e.kinds.includes(t.kind) && q(o, i, `参照先の種類は${e.kinds.map((e) => Re[e]).join(" / ")}です。`, "REFERENCE_INVALID"), t && n.runtime && t.deletedAt && q(o, i, "削除済み情報は実行用出力で参照できません。", "REFERENCE_INVALID");
		} else e.scope === "relation" ? a = r.relations.has(e.id) : e.scope === "record" ? a = r.entities.has(e.id) || r.relations.has(e.id) : e.scope === "projection_record" ? a = r.projectionIds.has(e.id) : e.scope === "presentation" ? a = r.entities.has(e.id) || r.blocks.has(e.id) : e.scope === "calendar" ? a = r.calendars.has(e.id) : e.scope === "project" ? a = r.projects.has(e.id) : e.scope === "snapshot" ? a = he.has(e.id) : e.scope === "block" ? a = r.blocks.has(e.id) : e.scope === "alias" && (a = ue.has(e.id));
		a || q(o, i, "参照先が存在しないか、指定した作品・共通世界の範囲外です。", "REFERENCE_INVALID");
	}
	let C = (e) => {
		let t = p.get(e);
		if (t) return t;
		if (!a || d.get(e.id) !== e) return nn(e);
		let n = a.references.get(e);
		if (n) return n;
		let r = nn(e);
		return a.references.set(e, r), r;
	};
	_.entities.forEach((e, n) => {
		let r = `${t}.entities[${n}]`;
		for (let t of C(e)) {
			let n = an(t.path), i = n.slice(0, -1).reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), a = (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse && t.path === "data.reuse.sourceId" ? e.data.reuse.pinnedSnapshotId : void 0, s = e.kind === "projection_profile" && e.data.sourceVersionId && /^data\.(?:includedIds|publicTexts|blockSources|publicIds|publicValues|namePolicy|allowedRelationIds|approvedAttachmentIds)(?:\.|\[)/.test(t.path) ? e.data.sourceVersionId : void 0, c = (e.kind === "note" && t.path === "data.handoffReceipt.profileId" ? e.data.handoffReceipt?.profileVersionId : void 0) ?? a ?? (K(i) && typeof i.entityId == "string" && typeof i.sourceVersionId == "string" ? i.sourceVersionId : e.kind === "review" && t.path.startsWith("data.target.") ? e.data.targetVersionId : s);
			if (e.kind === "projection_profile" && t.scope === "projection_record" && t.path.endsWith(".$key") && Object.values(e.data.publicTexts ?? {}).some((e) => Object.values(e).some((e) => Array.isArray(e) && e.some((e) => e.id === t.id)))) {
				S(t, r);
				continue;
			}
			let l = e.kind === "checkpoint" && (t.path.startsWith("data.runtimeState.") || t.path.startsWith("data.presentationState.") || t.path.startsWith("data.presentationResults[")) || e.kind === "trace" && (t.path.startsWith("data.steps[") || t.path.startsWith("data.initialExternalValues.") || t.path.startsWith("data.initialStubValues.") || t.path.startsWith("data.initialStubBaseState.") || t.path.startsWith("data.readingPath."));
			if (c || l && (e.kind === "checkpoint" || e.kind === "trace")) {
				let i = ve(c ?? (e.kind === "checkpoint" || e.kind === "trace" ? e.data.contentVersionId : _.projectId));
				if (!i) {
					q(o, c ? e.kind === "review" ? `${r}.data.targetVersionId` : `${r}.${n.slice(0, -1).join(".")}.sourceVersionId` : `${r}.data.contentVersionId`, "参照する固定版の本文がありません。", "REFERENCE_INVALID");
					continue;
				}
				S(t, r, i);
			} else S(t, r);
		}
	}), _.relations.forEach((e, n) => (m.get(e) ?? rn(e)).forEach((e) => S(e, `${t}.relations[${n}]`))), ee.forEach((e) => S(e));
	let ye = n.relationTypes ?? Ve;
	_.relations.forEach((e, n) => {
		let r = `${t}.relations[${n}]`, i = ye.find((t) => t.key === e.relationType), a = x.get(e.fromId), s = x.get(e.toId);
		i ? (a && !i.fromKinds.includes(a.kind) && q(o, `${r}.fromId`, "この関係で許されない始点種類です。", "REFERENCE_INVALID"), s && !i.toKinds.includes(s.kind) && q(o, `${r}.toId`, "この関係で許されない終点種類です。", "REFERENCE_INVALID"), e.fromId === e.toId && !i.allowSelf && q(o, r, "この関係は自己関係を許しません。"), e.direction === "symmetric" && !i.allowSymmetric && q(o, `${r}.direction`, "この関係は対称ではありません。")) : q(o, `${r}.relationType`, "関係の種類が辞書に定義されていません。"), e.deletedAt && !e.deletionOperationId && q(o, `${r}.deletionOperationId`, "削除には操作IDが必要です。"), tn(e.validity, `${r}.validity`, o);
	});
	let be;
	if (a && JSON.stringify(_.worldReferences) === JSON.stringify(a.previous.worldReferences) && JSON.stringify(_.calendars) === JSON.stringify(a.previous.calendars)) {
		be = /* @__PURE__ */ new Set([..._.entities.filter((e) => d.get(e.id) !== e).map((e) => e.id), ..._.relations.filter((e) => f.get(e.id) !== e).map((e) => e.id)]);
		for (let e of d.keys()) x.has(e) || be.add(e);
		for (let e of f.keys()) ie.has(e) || be.add(e);
	}
	return yn(_, x, ue, he, le, o, t, n, ve, be ? (e) => d.get(e.id) !== e || C(e).some((e) => be.has(e.id)) : void 0), o.length ? {
		ok: !1,
		issues: o.slice(0, 256)
	} : {
		ok: !0,
		value: _
	};
}
function _n(e, t, n, r, i, a, o = 0) {
	if (o > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, s) => _n(e, t, n, r, i, `${a}[${s}]`, o + 1));
		return;
	}
	let s = e;
	typeof s.id == "string" && typeof s.text == "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(s.kind) && (n.has(s.id) && q(i, `${a}.id`, "本文ブロックIDが重複しています。"), n.set(s.id, {
		entityId: t,
		text: s.text
	})), typeof s.id == "string" && "isPublicDefault" in s && (r.has(s.id) && q(i, `${a}.id`, "別名IDが重複しています。"), r.set(s.id, {
		entityId: t,
		alias: s
	}));
	for (let [e, c] of Object.entries(s)) [
		"runtimeState",
		"before",
		"after",
		"publicTexts"
	].includes(e) || _n(c, t, n, r, i, `${a}.${e}`, o + 1);
}
function vn(e, t, n, r, i) {
	let a = new Map(e.map((e) => [e.id, e])), o = /* @__PURE__ */ new Map();
	for (let s of e) {
		if (o.get(s.id)) continue;
		let e = [{
			id: s.id,
			ids: t(s),
			cursor: 0
		}];
		for (o.set(s.id, 1); e.length;) {
			let s = e[e.length - 1];
			if (s.cursor >= s.ids.length) {
				o.set(s.id, 2), e.pop();
				continue;
			}
			let c = s.ids[s.cursor++], l = a.get(c);
			if (l) {
				if (o.get(c) === 1) {
					q(n, `${r}.entities.${s.id}.data`, `${i}に循環があります。`);
					continue;
				}
				o.get(c) || (o.set(c, 1), e.push({
					id: c,
					ids: t(l),
					cursor: 0
				}));
			}
		}
	}
}
function yn(e, t, n, r, i, a, o, s, c, l) {
	let u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set();
	e.entities.some((e) => !!e.templateId && !e.deletedAt) && a.push(...Le(e, o, [...t.values()])), e.entities.forEach((e, f) => {
		let p = `${o}.entities[${f}]`;
		if (!e.deletedAt) {
			if (e.kind === "variable" || e.kind === "quest" || e.kind === "external_contract") {
				let t = `${e.kind}/${e.kind === "variable" ? `${e.data.scope}/${e.data.ownerId ?? ""}/` : ""}${e.data.key}`;
				u.has(t) && q(a, `${p}.data.key`, "同じスコープでキーが重複しています。"), u.set(t, e.id);
			}
			if (e.kind === "localization") {
				let t = `${e.data.sourceLineId}/${e.data.language}/${e.data.sourceHash}`;
				d.has(t) && q(a, p, "同じ台詞・言語・原文版の翻訳が重複しています。"), d.add(t);
			}
			if (!l || l(e) || e.kind === "checkpoint" || e.kind === "trace") {
				if (e.kind === "template" && a.push(...Ie(e.data, `${p}.data`, t)), e.kind === "item" && e.data.itemMode === "instance") {
					let n = e.data.typeId ? t.get(e.data.typeId) : void 0;
					n?.kind === "item" && n.data.itemMode !== "type" && q(a, `${p}.data.typeId`, "個体のtypeIdは物品種類を参照してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "quest") {
					let n = t.get(e.data.stateVariableId);
					if (n?.kind === "variable") for (let [t, r] of (e.data.transitionRules ?? []).entries()) a.push(...Y(n, r.from, `${p}.data.transitionRules[${t}].from`, !1), ...Y(n, r.to, `${p}.data.transitionRules[${t}].to`, !1));
				}
				if (e.kind === "variable") for (let [n, r] of (e.data.exclusions ?? []).entries()) {
					let e = t.get(r.variableId);
					e?.kind === "variable" && a.push(...Y(e, r.otherValue, `${p}.data.exclusions[${n}].otherValue`, !1));
				}
				if (e.kind === "collection" && e.data.purpose === "regression") for (let [n, r] of (e.data.memberIds ?? []).entries()) {
					let e = t.get(r);
					e && e.kind !== "trace" && q(a, `${p}.data.memberIds[${n}]`, "回帰経路集合には保存した試読記録を指定してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "effect") {
					let n = t.get(e.data.targetId), r = e.data.operation;
					if (n && [
						"set",
						"add",
						"reset"
					].includes(r) && (n.kind === "variable" ? (n.data.derived && q(a, `${p}.data.targetId`, "算出状態へ直接代入できません。"), r === "add" && n.data.valueType !== "integer" && q(a, `${p}.data.targetId`, "addはinteger状態だけです。"), e.data.value && r !== "add" && a.push(...Y(n, e.data.value, `${p}.data.value`))) : q(a, `${p}.data.targetId`, "状態更新効果は状態変数を参照してください。", "REFERENCE_INVALID")), n && [
						"grant",
						"consume",
						"move"
					].includes(r) && n.kind !== "item" && q(a, `${p}.data.targetId`, "物品効果は物品を参照してください。", "REFERENCE_INVALID"), n?.kind === "item" && [
						"grant",
						"consume",
						"move"
					].includes(r) && e.data.instanceId) {
						let r = t.get(e.data.instanceId);
						r?.kind === "item" && (r.data.itemMode !== "instance" || (n.data.itemMode === "type" ? r.data.typeId !== n.id : r.id !== n.id)) && q(a, `${p}.data.instanceId`, "指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
					}
					if (n && r === "assert" && n.kind !== "assertion" && q(a, `${p}.data.targetId`, "認識効果は事実・認識を参照してください。", "REFERENCE_INVALID"), r === "move" && e.data.value?.type === "ref") {
						let n = t.get(e.data.value.value);
						n && ![
							"character",
							"group",
							"place"
						].includes(n.kind) && q(a, `${p}.data.value`, "物品の移動先は人物・グループ・場所です。", "REFERENCE_INVALID");
					}
				}
				if (e.kind === "flow_graph") {
					for (let t of [...e.data.entryIds, ...e.data.exitIds]) e.data.nodeIds.includes(t) || q(a, `${p}.data`, "入口・出口はその分岐図のノード集合に含めてください。");
					for (let n of e.data.edgeIds) {
						let r = t.get(n);
						r?.kind === "flow_edge" && (!e.data.nodeIds.includes(r.data.fromId) || typeof r.data.toId == "string" && !e.data.nodeIds.includes(r.data.toId)) && q(a, `${p}.data.edgeIds`, "進行線の始点・終点は同じ分岐図内に置いてください。");
					}
					let n = (e.data.parameters ?? []).map((e) => e.key);
					new Set(n).size !== n.length && q(a, `${p}.data.parameters`, "引数のキーが重複しています。");
				}
				if (e.kind === "flow_edge" && s.runtime && typeof e.data.toId != "string" && q(a, `${p}.data.toId`, "未完成の分岐先は実行用出力できません。", "EXPORT_UNSUPPORTED"), e.kind === "variable" && s.runtime && e.data.initial.type === "unknown" && !e.data.derived && q(a, `${p}.data.initial`, "初期値が未定です。", "CONDITION_UNKNOWN"), xn(e.data, p, t, a), e.kind === "review" && typeof e.data.target == "object" ? (Sn(e.data.target, `${p}.data.target`, t, i, a, 0, c, e.data.targetVersionId), Sn({
					...e.data,
					target: null
				}, `${p}.data`, t, i, a, 0, c)) : Sn(e.data, `${p}.data`, t, i, a, 0, c), e.kind === "projection_profile") {
					let t = e.data.namePolicy;
					if ("mode" in t && t.mode === "alias") {
						let r = n.get(t.aliasId);
						r && !e.data.includedIds.includes(r.entityId) && q(a, `${p}.data.namePolicy`, "別名は投影対象の本体に属している必要があります。");
					} else if (!("mode" in t)) for (let [e, r] of Object.entries(t.byEntityId ?? {})) r.mode === "alias" && n.get(r.aliasId)?.entityId !== e && q(a, `${p}.data.namePolicy.byEntityId.${e}`, "別名が指定した本体に属していません。");
				}
				if (e.kind === "checkpoint" && (!r.has(e.data.runtimeState.contentVersionId) || e.data.runtimeState.contentVersionId !== e.data.contentVersionId) && q(a, `${p}.data.runtimeState.contentVersionId`, "途中開始の状態と対象版が一致しません。"), e.kind === "checkpoint") {
					let t = Xt(e.data.runtimeState, `${p}.data.runtimeState`);
					if (t.ok || a.push(...t.issues), e.data.presentationState && (e.data.presentationState.contentVersionId !== e.data.contentVersionId || e.data.presentationState.presentationPosition !== e.data.runtimeState.presentationPosition || e.data.presentationState.provenance !== e.data.runtimeState.provenance) && q(a, `${p}.data.presentationState`, "提示前の観測状態と開始点・対象版・由来が一致しません。"), e.data.presentationResults != null) {
						let t = c(e.data.contentVersionId);
						t && a.push(...Zt({
							...e.data.runtimeState,
							provenance: e.data.origin ?? "partial"
						}, e.data.presentationResults, [...t.entities.values()], `${p}.data.presentationResults`));
					}
				}
				if (e.kind === "trace") {
					let t = e.data;
					t.initialStubBaseState && !t.initialStubValues && q(a, `${p}.data.initialStubBaseState`, "stub前の個別状態には初期stub入力の記録が必要です。"), t.mode === "chapters" ? ((t.initialStubValues || t.initialStubBaseState) && q(a, `${p}.data.initialStubValues`, "章経路の個別開始はcheckpointへ、外部仮値はinitialExternalValuesへ記録してください。"), t.readingPath || q(a, `${p}.data.readingPath`, "章読み通しには提示経路が必要です。"), t.steps.length && q(a, `${p}.data.steps`, "章読み通しとフロー遷移を混在させられません。")) : t.readingPath != null && q(a, `${p}.data.readingPath`, "提示経路はmode:chaptersの記録に指定してください。"), t.steps.forEach((e, n) => {
						for (let [t, r] of [["before", e.before], ["after", e.after]]) {
							let e = Xt(r, `${p}.data.steps[${n}].${t}`);
							e.ok || a.push(...e.issues);
						}
						e.presentationState && (e.presentationState.contentVersionId !== t.contentVersionId || e.presentationState.presentationPosition !== e.after.presentationPosition || e.presentationState.provenance !== e.after.provenance) && q(a, `${p}.data.steps[${n}].presentationState`, "提示前の観測状態と提示先・対象版・由来が一致しません。");
					}), t.readingPath?.occurrences.forEach((e, t) => {
						for (let [n, r] of [["before", e.before], ["after", e.after]]) {
							let e = Xt(r, `${p}.data.readingPath.occurrences[${t}].${n}`);
							e.ok || a.push(...e.issues);
						}
					});
				}
			}
		}
	});
	for (let t of [
		"place",
		"group",
		"flow_graph",
		"map"
	]) vn(e.entities.filter((e) => e.kind === t && !e.deletedAt), (e) => e.kind === "place" || e.kind === "group" ? e.data.parentId ? [e.data.parentId] : [] : e.kind === "flow_graph" ? e.data.parentGraphId ? [e.data.parentGraphId] : [] : e.kind === "map" && e.data.parentMapId ? [e.data.parentMapId] : [], a, o, `${Re[t]}の階層`);
	vn(e.entities.filter((e) => e.kind === "production_task" && !e.deletedAt), (e) => e.kind === "production_task" ? e.data.dependsOn ?? [] : [], a, o, "制作依存"), vn(e.entities.filter((e) => e.kind === "variable" && !e.deletedAt), (e) => e.kind === "variable" && e.data.derived ? bn(e.data.derived) : [], a, o, "算出状態"), vn(e.entities.filter((e) => e.kind === "flow_graph" && !e.deletedAt), (e) => e.kind === "flow_graph" ? e.data.nodeIds.flatMap((e) => {
		let n = t.get(e);
		return n?.kind === "flow_node" && n.data.childGraphId ? [n.data.childGraphId] : [];
	}) : [], a, o, "分岐図の呼出階層"), a.push(...Oe([...t.values()].filter((e) => e.kind === "event" && !e.deletedAt)));
	let f = /* @__PURE__ */ new Map();
	for (let t of e.entities) if (t.kind === "flow_edge" && t.data.edgeType === "automatic" && !t.deletedAt) {
		let e = `${t.data.fromId}/${t.data.priority ?? 0}`;
		f.has(e) && q(a, `${o}.entities.${t.id}.data.priority`, "同じ始点の自動候補で優先順位が重複しています。"), f.set(e, t.id);
	}
}
function bn(e) {
	let t = [];
	return J({ type: "expression" }, e, "", [], t), t.filter((e) => e.kinds?.includes("variable")).map((e) => e.id);
}
function xn(e, t, n, r, i = 0) {
	if (i > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, a) => xn(e, `${t}[${a}]`, n, r, i + 1));
		return;
	}
	let a = e;
	if (a.op === "compare") {
		let e = n.get(a.variableId);
		if (e?.kind === "variable") {
			let n = a.comparator, i = Array.isArray(a.value) ? a.value : [a.value];
			[
				"lt",
				"le",
				"gt",
				"ge"
			].includes(n) && e.data.valueType !== "integer" && q(r, `${t}.comparator`, "順序比較はintegerにだけ使えます。"), i.forEach((n, a) => {
				n.type !== "unknown" && n.type !== e.data.valueType && q(r, `${t}.value${i.length > 1 ? `[${a}]` : ""}`, "比較値の型が状態変数と一致しません。");
			});
		}
	}
	for (let [e, o] of Object.entries(a)) xn(o, `${t}.${e}`, n, r, i + 1);
}
function Sn(e, t, n, r, i, a = 0, o, s) {
	if (a > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, c) => Sn(e, `${t}[${c}]`, n, r, i, a + 1, o, s));
		return;
	}
	let c = e;
	if (typeof c.entityId == "string") {
		c.positionStatus === "unresolved" && (!c.positionReason || c.start != null || c.end != null) && q(i, t, "位置不明には理由を付け、確定した文字範囲を外してください。"), c.positionStatus !== "unresolved" && (c.positionReason != null || c.quotedText != null) && q(i, t, "位置不明の理由・引用は位置不明状態と一緒に保存してください。");
		let e = typeof c.sourceVersionId == "string" ? c.sourceVersionId : s, a = e && o ? o(e) : void 0, l = a?.entities ?? n, u = a?.blocks ?? r, d;
		if (typeof c.blockId == "string") {
			let e = u.get(c.blockId);
			e && e.entityId !== c.entityId && q(i, `${t}.blockId`, "段落は指定した情報に属していません。", "REFERENCE_INVALID"), d = e?.text;
		}
		if (typeof c.lineId == "string") {
			let e = l.get(c.lineId);
			e?.kind === "dialogue_line" && (d = Je(e.data.text));
		}
		(typeof c.start == "number" || typeof c.end == "number") && ((typeof c.start != "number" || typeof c.end != "number") && q(i, t, "文字範囲はstart/endを対で指定してください。"), d === void 0 ? q(i, t, "文字範囲には本文ブロックまたは台詞への参照が必要です。") : typeof c.end == "number" && c.end > Nt(d) && q(i, `${t}.end`, "文字範囲が参照元の本文を超えています。"));
	}
	for (let [e, s] of Object.entries(c)) [
		"publicTexts",
		"before",
		"after",
		"runtimeState"
	].includes(e) || Sn(s, `${t}.${e}`, n, r, i, a + 1, o);
}
function Cn(e, t = {}) {
	if (!K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	let n = [];
	for (let t of Object.keys(e)) [
		...pn,
		"snapshots",
		"history"
	].includes(t) || q(n, `project.${t}`, "作品に未知の項目があります。");
	Array.isArray(e.snapshots) || q(n, "project.snapshots", "必須の配列です。"), Array.isArray(e.history) || q(n, "project.history", "必須の配列です。");
	let r = new Set((Array.isArray(e.snapshots) ? e.snapshots : []).flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : []));
	Object.hasOwn(e, "authorAlternatives") && J(mn, e.authorAlternatives, "project.authorAlternatives", n, []);
	let i = gn(Object.fromEntries(fn.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, r, En(e.snapshots));
	if (i.ok || n.push(...i.issues), n.length) return {
		ok: !1,
		issues: n.slice(0, 256)
	};
	let a = e;
	Tn(a.snapshots, "project.snapshots", a.projectId, t, n);
	let o = /* @__PURE__ */ new Set();
	return a.history.forEach((e, r) => {
		let i = `project.history[${r}]`, s = e;
		if (!K(s)) {
			q(n, i, "履歴はコマンドです。");
			return;
		}
		let c = z({
			operationId: B(j),
			projectId: B(j),
			baseRevision: B({ type: "revision" }),
			revision: B({ type: "revision" }),
			targetIds: B(L(j, !0)),
			reason: B(D()),
			createdAt: B({ type: "datetime" }),
			compensatesOperationId: V(j),
			idMap: V(W(j, j)),
			importOrigin: V(z({
				sourceProjectId: B(j),
				sourceOperationId: B(j),
				importOperationId: B(j)
			}))
		});
		for (let e of Object.keys(s)) e !== "before" && e !== "after" && c.type === "object" && !Object.hasOwn(c.fields, e) && q(n, `${i}.${e}`, "コマンドに未知の項目があります。");
		J(c, Object.fromEntries(Object.entries(s).filter(([e]) => e !== "before" && e !== "after")), i, n, []), o.has(e.operationId) && q(n, `${i}.operationId`, "履歴の操作IDが重複しています。"), o.add(e.operationId), e.projectId !== a.projectId && q(n, `${i}.projectId`, "履歴が別の作品に属しています。");
		for (let e of ["before", "after"]) {
			if (!K(s[e])) {
				q(n, `${i}.${e}`, "変更前後の内容を保持してください。");
				continue;
			}
			let r = s[e];
			Array.isArray(r.snapshots) || q(n, `${i}.${e}.snapshots`, "復元に必要な公開版配列が必要です。"), Object.hasOwn(r, "authorAlternatives") && J(mn, r.authorAlternatives, `${i}.${e}.authorAlternatives`, n, []);
			let o = Object.fromEntries(Object.entries(r).filter(([e]) => e !== "snapshots" && e !== "authorAlternatives")), c = new Set((Array.isArray(r.snapshots) ? r.snapshots : []).flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : [])), l = gn(o, `${i}.${e}`, t, c, En(r.snapshots));
			l.ok ? l.value.projectId !== a.projectId && q(n, `${i}.${e}.projectId`, "履歴の内容が別の作品に属しています。") : n.push(...l.issues), Array.isArray(r.snapshots) && Tn(r.snapshots, `${i}.${e}.snapshots`, a.projectId, t, n);
		}
	}), n.length ? {
		ok: !1,
		issues: n.slice(0, 256)
	} : {
		ok: !0,
		value: a
	};
}
function wn(e, t = {}, n) {
	let r = [];
	for (let t of Object.keys(e)) [
		...pn,
		"snapshots",
		"history"
	].includes(t) || q(r, `project.${t}`, "作品に未知の項目があります。");
	if ((!Array.isArray(e.snapshots) || !Array.isArray(e.history)) && q(r, "project", "公開版と履歴の配列が必要です。"), Object.hasOwn(e, "authorAlternatives") && J(mn, e.authorAlternatives, "project.authorAlternatives", r, []), r.length) return {
		ok: !1,
		issues: r
	};
	let i = new Set(e.snapshots.map((e) => e.id)), a = gn(Object.fromEntries(fn.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, i, En(e.snapshots), n);
	return a.ok ? {
		ok: !0,
		value: e
	} : a;
}
function Tn(e, t, n, r, i) {
	let a = new Set(e.flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : [])), o = /* @__PURE__ */ new Set(), s = En(e);
	e.forEach((e, c) => {
		let l = `${t}[${c}]`;
		if (!K(e)) {
			q(i, l, "公開版はオブジェクトです。");
			return;
		}
		let u = z({
			id: B(j),
			versionLabel: B(D(1, 128)),
			contentHash: B({ type: "hash" }),
			createdAt: B({ type: "datetime" })
		});
		for (let t of Object.keys(e)) [
			"id",
			"versionLabel",
			"contentHash",
			"createdAt",
			"content"
		].includes(t) || q(i, `${l}.${t}`, "公開版に未知の項目があります。");
		J(u, Object.fromEntries(Object.entries(e).filter(([e]) => e !== "content")), l, i, []), typeof e.id == "string" && (o.has(e.id) && q(i, `${l}.id`, "公開版のIDが重複しています。"), o.add(e.id), e.id === n && q(i, `${l}.id`, "公開版IDは作品IDと別にしてください。"));
		let d = gn(e.content, `${l}.content`, r, a, s);
		d.ok ? d.value.projectId !== n && q(i, `${l}.content.projectId`, "公開版が別の作品に属しています。") : i.push(...d.issues);
	});
}
function En(e) {
	return Array.isArray(e) ? new Map(e.flatMap((e) => K(e) && typeof e.id == "string" && K(e.content) && [
		"entities",
		"relations",
		"calendars",
		"worldReferences"
	].every((t) => Array.isArray(e.content[t]) && e.content[t].every(K)) ? [[e.id, e.content]] : [])) : /* @__PURE__ */ new Map();
}
//#endregion
//#region src/domain/stateRules.ts
function Dn(e, t) {
	let n = t.ruleContext;
	if (!n) return {
		value: "unknown",
		reasons: ["対象作品・章・経路の実行情報がありません。"]
	};
	if (e.projectId !== n.projectId || e.targetSnapshotId && ![
		n.projectId,
		t.state.contentVersionId,
		n.sourceVersionId
	].includes(e.targetSnapshotId)) return {
		value: "false",
		reasons: ["対象作品版の範囲外です。"]
	};
	if (e.graphId && n.graphId && e.graphId !== n.graphId || e.chapterId && n.chapterId && e.chapterId !== n.chapterId) return {
		value: "false",
		reasons: ["対象グラフまたは章の範囲外です。"]
	};
	let r = In(e.routeCondition, t);
	return r.value === "false" ? r : e.graphId && !n.graphId || e.chapterId && !n.chapterId ? {
		value: "unknown",
		reasons: ["対象グラフまたは章を確認できません。", ...r.reasons]
	} : r;
}
function On(e, t) {
	let n = (e, t) => ({
		value: e,
		reasons: [t]
	});
	if (!e.reason.trim() || !e.evidenceIds.length) return n("false", "例外には理由と根拠が必要です。");
	let r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (e.evidenceIds.some((e) => !r.some((t) => t.id === e && !t.deletedAt && t.status === "confirmed"))) return n("unknown", "例外の根拠が存在しないか、採用確定していません。");
	let i = Dn(e.targetScope, t);
	if (i.value !== "true") return i;
	let a = e.validity.worldRange, o = t.ruleContext?.worldTick;
	if (!a || a.end === null) return n("unknown", "例外の有効期限を指定してください。");
	if (!S(o)) return n("unknown", "例外の期限を評価する現在の世界時点がありません。");
	if (a.start !== null && w(o, a.start) < 0 || w(o, a.end) >= 0) return n("false", "例外の有効期間外です。");
	let s = In(e.validity.routeCondition, t);
	if (s.value !== "true") return s;
	let c = e.validity.presentationAnchor, l = t.ruleContext?.anchorBindings, u = c && l && c.sourceVersionId === t.ruleContext?.sourceVersionId ? {
		...c,
		entityId: l[c.entityId] ?? c.entityId,
		...c.blockId ? { blockId: l[c.blockId] ?? c.blockId } : {},
		...c.lineId ? { lineId: l[c.lineId] ?? c.lineId } : {}
	} : c;
	return u && (u.positionStatus === "unresolved" || u.sourceVersionId && ![
		t.ruleContext.projectId,
		t.state.contentVersionId,
		t.ruleContext.sourceVersionId
	].includes(u.sourceVersionId)) ? n("unknown", "例外の提示位置または版を確認できません。") : u && ![
		u.entityId,
		u.blockId,
		u.lineId
	].filter(Boolean).every((e) => t.state.seenIds.includes(e)) ? n("false", "例外の提示位置に到達していません。") : {
		value: "true",
		reasons: []
	};
}
function kn(e, t) {
	if (!e.data.holderId) return;
	if (typeof e.data.value != "string" && e.data.value.type === "unknown") return {
		code: "CONDITION_UNKNOWN",
		message: "人物が取得する認識の内容が未確定です。"
	};
	let n = e.data.sourceIds ?? [], r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (!n.length || n.some((e) => !r.some((t) => t.id === e && _(t)))) return {
		code: "REFERENCE_INVALID",
		message: "人物の認識取得には採用中の出所が必要です。"
	};
	let i = e.data.validity, a = e.data.evidenceLocation ?? i?.presentationAnchor, o = t.ruleContexts?.[e.id] ?? t.ruleContext, s = o?.anchorBindings, c = a && s && a.sourceVersionId === o?.sourceVersionId ? {
		...a,
		entityId: s[a.entityId] ?? a.entityId,
		...a.blockId ? { blockId: s[a.blockId] ?? a.blockId } : {},
		...a.lineId ? { lineId: s[a.lineId] ?? a.lineId } : {}
	} : a, l = i?.worldRange;
	if (!c && (!l || l.start === null)) return {
		code: "CONDITION_UNKNOWN",
		message: "人物の認識取得には本文位置または世界内の取得時点が必要です。"
	};
	if (c) {
		if (c.positionStatus === "unresolved" || c.sourceVersionId && ![
			o?.projectId,
			o?.sourceVersionId,
			t.state.contentVersionId
		].includes(c.sourceVersionId)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置または固定版が未確認です。"
		};
		if (![
			c.entityId,
			c.blockId,
			c.lineId
		].filter(Boolean).every((e) => t.state.seenIds.includes(e))) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置へ到達していません。"
		};
		let e = t.currentPresentation;
		if (e) {
			let t = c.entityId === e.anchor.entityId && c.blockId === e.anchor.blockId && c.lineId === e.anchor.lineId && c.start === e.anchor.start, n = fr(e.project, c, e.anchor, e.target);
			if (!t && n !== !0) return {
				code: n === !1 ? "TRANSITION_BLOCKED" : "CONDITION_UNKNOWN",
				message: "認識取得の位置が、この効果の提示位置より後か、順序を確認できません。"
			};
		}
	}
	if (l) {
		if (!S(o?.worldTick)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識の取得時点を照合する世界内tickが未入力です。"
		};
		if (l.start !== null && w(o.worldTick, l.start) < 0 || l.end !== null && w(o.worldTick, l.end) >= 0) return {
			code: "TRANSITION_BLOCKED",
			message: "認識の取得時点が宣言した有効期間外です。"
		};
	}
	let u = In(i?.routeCondition, {
		...t,
		ruleContext: o
	});
	if (u.value !== "true") return {
		code: u.value === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED",
		message: "認識を取得する経路条件が成立していません。"
	};
}
//#endregion
//#region src/domain/conditions.ts
var X = class extends Error {
	issues;
	constructor(e) {
		super(e.map((e) => e.message).join("、")), this.name = "DomainValidationError", this.issues = e;
	}
}, Z = (e, t = "condition", n = "VALIDATION_FAILED") => ({
	code: n,
	path: t,
	message: e
}), An = (e) => ({
	type: "unknown",
	value: null,
	reason: e
}), Q = (e, t = []) => ({
	value: e,
	reasons: [...new Set(t)]
}), jn = (e) => [...e.entities ?? [], ...e.referenceEntities ?? []].filter(_), Mn = (e) => (e.variables ?? [...e.entities ?? [], ...e.referenceEntities ?? []].filter((e) => e.kind === "variable")).filter(_);
function Nn(e, t, n) {
	let r = Mn(t).find((t) => t.id === e);
	if (!r) {
		if (t.variables || t.entities) return An("状態変数が定義されていません。");
		let n = t.state.variableValues[e];
		if (!n) return An("状態変数の値がありません。");
		let r = Yt(n);
		if (!r.ok) throw new X(r.issues);
		return n;
	}
	if (r.data.derived) {
		if (n.includes(e)) throw new X([Z("算出状態の参照が循環しています。", `variables.${e}.derived`)]);
		let i = Ln(r.data.derived, t, [...n, e]), a = Y(r, i, `variables.${e}.derived`);
		if (a.length) throw new X(a);
		return i;
	}
	if (r.data.externalContractId) {
		let e = t.externalValues?.[r.data.externalContractId];
		if (!e) return An("宣言した外部値をまだ取得していません。");
		let n = Yt(e);
		if (!n.ok) throw new X(n.issues);
		let i = Y(r, e);
		if (i.length) throw new X(i);
		return e;
	}
	let i = t.state.variableValues[e];
	if (!i) return An("状態変数の値がありません。");
	let a = Yt(i);
	if (!a.ok) throw new X(a.issues);
	let o = Y(r, i);
	if (o.length) throw new X(o);
	return i;
}
function Pn(e, t, n) {
	if (e.type === "unknown" || t.type === "unknown") return Q("unknown", [e.type === "unknown" ? e.reason : "", t.type === "unknown" ? t.reason : ""].filter(Boolean));
	if (e.type !== t.type) throw new X([Z("比較する値の型が一致しません。")]);
	if (![
		"eq",
		"ne",
		"lt",
		"le",
		"gt",
		"ge"
	].includes(n)) throw new X([Z("未知の比較演算です。")]);
	if (n === "eq" || n === "ne") return Q((n === "eq" ? e.value === t.value : e.value !== t.value) ? "true" : "false");
	if (e.type !== "integer" || t.type !== "integer") throw new X([Z("順序比較はintegerにだけ使えます。")]);
	return Q((n === "lt" ? e.value < t.value : n === "le" ? e.value <= t.value : n === "gt" ? e.value > t.value : e.value >= t.value) ? "true" : "false");
}
function Fn(e, t, n) {
	switch (e.op) {
		case "constant": return Q(e.value ? "true" : "false");
		case "all":
		case "any": {
			let r = e.children.map((e) => Fn(e, t, n)), i = r.flatMap((e) => e.reasons);
			return e.op === "all" ? Q(r.some((e) => e.value === "false") ? "false" : r.every((e) => e.value === "true") ? "true" : "unknown", i) : Q(r.some((e) => e.value === "true") ? "true" : r.every((e) => e.value === "false") ? "false" : "unknown", i);
		}
		case "not": {
			let r = Fn(e.child, t, n);
			return Q(r.value === "unknown" ? "unknown" : r.value === "true" ? "false" : "true", r.reasons);
		}
		case "compare": {
			let r = Nn(e.variableId, t, n);
			if (e.comparator !== "in") return Pn(r, e.value, e.comparator);
			let i = e.value.map((e) => Pn(r, e, "eq"));
			return Q(i.some((e) => e.value === "true") ? "true" : i.some((e) => e.value === "unknown") ? "unknown" : "false", i.flatMap((e) => e.reasons));
		}
		case "item": return t.entities && !jn(t).some((t) => t.id === e.itemId && t.kind === "item") ? Q("unknown", ["指定した物品が定義されていません。"]) : Q(t.state.itemInstances.filter((t) => !t.consumed && (t.instanceId === e.itemId || t.typeId === e.itemId)).reduce((e, t) => e + t.quantity, 0) >= e.quantity ? "true" : "false");
		case "known": {
			if (t.entities && (!jn(t).some((t) => t.id === e.assertionId && t.kind === "assertion") || !jn(t).some((t) => t.id === e.holderId && t.kind === "character"))) return Q("unknown", ["認識の対象または人物が定義されていません。"]);
			let n = t.state.assertions.find((t) => t.assertionId === e.assertionId && t.holderId === e.holderId);
			return n ? Q(n.truth, n.truth === "unknown" ? ["人物の認識が未確定です。"] : []) : Q("false");
		}
		case "visited": return t.entities && !jn(t).some((t) => t.id === e.entityId) ? Q("unknown", ["訪問先が定義されていません。"]) : Q((t.state.visitCounts[e.entityId] ?? 0) >= e.count ? "true" : "false");
		case "external": {
			if (t.entities && !jn(t).some((t) => t.id === e.contractId && t.kind === "external_contract")) return Q("unknown", ["外部契約が定義されていません。"]);
			let n = t.externalValues?.[e.contractId];
			if (!n) return Q("unknown", ["外部値をまだ取得していません。"]);
			let r = Yt(n);
			if (!r.ok) throw new X(r.issues);
			if (n.type === "unknown") return Q("unknown", [n.reason]);
			if (n.type !== "boolean") throw new X([Z("外部条件はbooleanの結果が必要です。")]);
			return Q(n.value ? "true" : "false");
		}
	}
}
function In(e, t) {
	let n = Jt(e ?? {
		op: "constant",
		value: !0
	});
	if (!n.ok) throw new X(n.issues);
	return Fn(n.value, t, []);
}
function Ln(e, t, n) {
	switch (e.op) {
		case "value": return e.value;
		case "variable": return Nn(e.variableId, t, n);
		case "if": {
			let r = Fn(e.condition, t, n);
			return r.value === "unknown" ? An(r.reasons.join("、") || "分岐条件が未定です。") : Ln(r.value === "true" ? e.then : e.else, t, n);
		}
		case "add":
		case "subtract":
		case "multiply": {
			let r = Ln(e.left, t, n), i = Ln(e.right, t, n);
			if (r.type === "unknown" || i.type === "unknown") return An([r.type === "unknown" ? r.reason : "", i.type === "unknown" ? i.reason : ""].filter(Boolean).join("、"));
			if (r.type !== "integer" || i.type !== "integer") throw new X([Z("算術の入力はintegerです。", "expression")]);
			let a = e.op === "add" ? r.value + i.value : e.op === "subtract" ? r.value - i.value : r.value * i.value;
			if (!Number.isSafeInteger(a)) throw new X([Z("算術結果が安全な整数の範囲を超えています。", "expression")]);
			return {
				type: "integer",
				value: a
			};
		}
		default: {
			let r = Fn(e, t, n);
			return r.value === "unknown" ? An(r.reasons.join("、")) : {
				type: "boolean",
				value: r.value === "true"
			};
		}
	}
}
function Rn(e, t = e.projectId, n = [], r = {}) {
	let i = et(t), a = [...e.entities, ...n].filter((e) => e.kind === "variable" && _(e));
	for (let e of a) i.variableValues[e.id] = structuredClone(e.data.initial);
	for (let t of a) (t.data.derived || t.data.externalContractId && r[t.data.externalContractId]) && (i.variableValues[t.id] = Nn(t.id, {
		state: i,
		variables: a,
		entities: e.entities,
		referenceEntities: n,
		externalValues: r
	}, []));
	return i;
}
function zn(e) {
	let t = [];
	for (let n of Mn(e)) for (let [r, i] of (n.data.exclusions ?? []).entries()) {
		let a = In({
			op: "all",
			children: [{
				op: "compare",
				variableId: n.id,
				comparator: "eq",
				value: i.value
			}, {
				op: "compare",
				variableId: i.variableId,
				comparator: "eq",
				value: i.otherValue
			}]
		}, e);
		if (a.value === "false") continue;
		let o = (i.exceptions ?? []).map((t) => On(t, {
			...e,
			ruleContext: e.ruleContexts?.[n.id] ?? e.ruleContext
		}));
		if (a.value === "true" && o.some((e) => e.value === "true")) continue;
		let s = a.value === "unknown" || o.some((e) => e.value === "unknown");
		t.push(Z(s ? `相互排他を評価できません。${i.reason}` : `相互排他に反する状態です。${i.reason}`, `${n.id}.exclusions[${r}]`, s ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED"));
	}
	return t;
}
function Bn(e, t) {
	return e.type === t.type && e.value === t.value;
}
function Vn(e, t, n, r, i) {
	if (r.operation === "reset" || Bn(t, n)) return;
	let a = jn(i).filter((t) => t.kind === "quest" && t.data.stateVariableId === e.id), o = [...(e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})), ...a.flatMap((e) => (e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})))];
	if (!o.length && !a.length) return;
	if (t.type === "unknown") throw new X([Z("遷移前の状態が未定です。", `variables.${e.id}`, "CONDITION_UNKNOWN")]);
	let s = o.filter(({ rule: e }) => Bn(e.from, t) && Bn(e.to, n));
	if (s.some(({ rule: e }) => !e.exception && !e.exceptionDetails)) return;
	let c = [...s.flatMap(({ rule: e, ownerId: t }) => e.exceptionDetails ? [On(e.exceptionDetails, {
		...i,
		ruleContext: i.ruleContexts?.[t] ?? i.ruleContext
	})] : []), ...r.exceptionDetails ? [On(r.exceptionDetails, i)] : []];
	if (!c.some((e) => e.value === "true")) throw new X([Z(c.flatMap((e) => e.reasons).join("、") || "許容遷移表にない状態更新です。明示resetまたは対象・期限・根拠付きの例外が必要です。", `variables.${e.id}`, c.some((e) => e.value === "unknown") ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED")]);
}
function Hn(e, t, n) {
	return e.itemInstances.filter((e) => n ? e.instanceId === n : e.instanceId === t || e.typeId === t);
}
function Un(e, t, n, r) {
	let i = Mn(n), a = [...n.entities ?? [], ...n.referenceEntities ?? []].find((e) => e.id === t.targetId && _(e)), o = (e, n = "TRANSITION_BLOCKED") => {
		throw new X([Z(e, `effects.${r ?? t.targetId}`, n)]);
	};
	if ([
		"set",
		"add",
		"reset"
	].includes(t.operation)) {
		let a = i.find((e) => e.id === t.targetId);
		a || o("更新先の状態変数がありません。", "REFERENCE_INVALID"), a.data.derived && o("算出状態へ直接代入できません。", "VALIDATION_FAILED");
		let s = Nn(a.id, {
			...n,
			state: e
		}, []), c = t.operation === "reset" ? structuredClone(t.value ?? a.data.initial) : t.value;
		c || o("状態更新の入力値がありません。", "VALIDATION_FAILED"), t.operation === "add" && (s.type === "unknown" && o(s.reason || "加算元の状態が未定です。", "CONDITION_UNKNOWN"), (s.type !== "integer" || c.type !== "integer" || a.data.valueType !== "integer") && o("addはinteger状態とinteger入力だけを使えます。", "VALIDATION_FAILED"), c = {
			type: "integer",
			value: s.value + c.value
		});
		let l = Y(a, c, `effects.${r ?? t.targetId}.value`, t.operation === "reset");
		if (l.length) throw new X(l.map((e) => ({
			...e,
			code: e.code === "CONDITION_UNKNOWN" ? e.code : "TRANSITION_BLOCKED"
		})));
		Vn(a, s, c, t, n), e.variableValues[a.id] = structuredClone(c);
		return;
	}
	if (t.operation === "mark_seen") {
		n.entities && !a && o("既読対象が定義されていません。", "REFERENCE_INVALID"), e.seenIds.includes(t.targetId) || e.seenIds.push(t.targetId);
		return;
	}
	if (t.operation === "assert") {
		(!a || a.kind !== "assertion") && o("認識効果の対象には事実・認識が必要です。", "REFERENCE_INVALID"), t.value && t.value.type !== "boolean" && o("認識効果の入力はbooleanです。", "VALIDATION_FAILED");
		let i = t.value?.type === "boolean" && !t.value.value ? "false" : "true", s = a.data.holderId ?? null;
		if (i === "true") {
			let e = kn(a, n);
			e && o(e.message, e.code);
		}
		let c = e.assertions.find((e) => e.assertionId === a.id && e.holderId === s);
		c ? (c.truth = i, r && (c.sourceEffectId = r)) : e.assertions.push({
			assertionId: a.id,
			holderId: s,
			truth: i,
			...r ? { sourceEffectId: r } : {}
		});
		return;
	}
	if ((!a || a.kind !== "item") && o("物品効果の対象には宣言済みの物品が必要です。", "REFERENCE_INVALID"), t.instanceId) {
		let e = jn(n).find((e) => e.id === t.instanceId);
		(!e || e.kind !== "item" || e.data.itemMode !== "instance") && o("指定した物品個体が定義されていません。", "REFERENCE_INVALID"), (a.data.itemMode === "type" && e.data.typeId !== a.id || a.data.itemMode === "instance" && e.id !== a.id) && o("指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
	}
	let s = t.value?.type === "integer" ? t.value.value : 1;
	if (t.operation === "grant") {
		t.value && t.value.type !== "integer" && o("取得数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(s) || s < 1) && o("取得数量は正の安全な整数です。", "VALIDATION_FAILED");
		let r = a.data.itemMode === "instance" ? a : t.instanceId ? jn(n).find((e) => e.id === t.instanceId && e.kind === "item" && e.data.itemMode === "instance") : void 0;
		if (t.instanceId && !r && o("指定した物品個体がありません。", "REFERENCE_INVALID"), r) {
			s !== 1 && o("物品個体の数量は1です。"), a.data.itemMode === "type" && r.data.typeId !== a.id && o("個体が指定した物品種類に属していません。", "REFERENCE_INVALID"), e.itemInstances.some((e) => e.instanceId === r.id) && o("同じ物品個体を二重取得・復活させられません。");
			let t = r.data.typeId;
			t || o("物品個体の種類が未定義です。", "REFERENCE_INVALID"), e.itemInstances.push({
				instanceId: r.id,
				typeId: t,
				quantity: 1,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		} else {
			let t = e.itemInstances.find((e) => e.instanceId === a.id && e.typeId === a.id);
			t ? (Number.isSafeInteger(t.quantity + s) || o("物品数量が安全な整数範囲を超えています。"), t.quantity += s, t.consumed = !1) : e.itemInstances.push({
				instanceId: a.id,
				typeId: a.id,
				quantity: s,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		}
		return;
	}
	let c = Hn(e, t.targetId, t.instanceId).filter((e) => !e.consumed && e.quantity > 0);
	if (c.some((e) => a.data.itemMode === "type" ? e.typeId !== a.id : e.instanceId !== a.id || e.typeId !== a.data.typeId) && o("実行状態の個体と効果の対象物品が一致しません。", "REFERENCE_INVALID"), t.operation === "consume") {
		t.reason?.trim() || o("消費・破壊の理由を記録してください。", "VALIDATION_FAILED"), t.value && t.value.type !== "integer" && o("消費数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(s) || s < 1 || c.reduce((e, t) => e + t.quantity, 0) < s) && o("物品が不足しています。");
		let e = s;
		for (let n of c) {
			let r = Math.min(n.quantity, e);
			if (n.quantity -= r, e -= r, n.reason = t.reason, n.consumed = n.quantity === 0, e === 0) break;
		}
		return;
	}
	if (t.operation === "move") {
		t.value?.type !== "ref" && o("移動先には人物・グループ・場所のrefが必要です。", "VALIDATION_FAILED");
		let e = jn(n).find((e) => e.id === t.value?.value);
		(!e || ![
			"character",
			"group",
			"place"
		].includes(e.kind)) && o("物品の移動先がありません。", "REFERENCE_INVALID"), c.length !== 1 && o("移動する現存物品を一個体に特定してください。");
		let r = c[0];
		r.ownerId = e.kind === "place" ? null : e.id, r.locationId = e.kind === "place" ? e.id : null;
		return;
	}
	o("未対応の物品操作です。", "VALIDATION_FAILED");
}
function Wn(e, t, n = { state: e }) {
	let r = Xt(e);
	if (!r.ok) return {
		ok: !1,
		state: e,
		issues: r.issues
	};
	let i = structuredClone(e);
	try {
		for (let [e, n] of t.entries()) {
			if ("data" in n && !_(n)) throw new X([Z("削除・不採用・別案の効果は実行できません。", `effects[${e}]`, "REFERENCE_INVALID")]);
			let t = Qt("data" in n ? n.data : n, `effects[${e}]`);
			if (!t.ok) throw new X(t.issues);
		}
		for (let [e, r] of t.entries()) {
			let t = "data" in r ? r.data : r, a = "id" in r ? r.id : void 0, o = {
				...n,
				currentPresentation: n.effectPresentations?.[e] ?? n.currentPresentation,
				state: i,
				ruleContext: a && n.ruleContexts?.[a] || n.ruleContext
			}, s = In(t.condition, o);
			if (s.value === "unknown") throw new X([Z(s.reasons.join("、") || "効果の条件が未定です。", `effects[${e}].condition`, "CONDITION_UNKNOWN")]);
			s.value !== "false" && Un(i, t, o, a);
		}
		let e = /* @__PURE__ */ new Set();
		for (let t of i.itemInstances) {
			if (e.has(t.instanceId) || t.ownerId && t.locationId || t.consumed && t.quantity !== 0 || !t.consumed && t.quantity < 1) throw new X([Z("物品の個体ID・所在・数量が不整合です。", "itemInstances", "TRANSITION_BLOCKED")]);
			e.add(t.instanceId);
		}
		for (let e of Mn(n)) e.data.derived && (i.variableValues[e.id] = Nn(e.id, {
			...n,
			state: i
		}, []));
		let r = zn({
			...n,
			state: i
		});
		if (r.length) throw new X(r);
		return {
			ok: !0,
			state: i
		};
	} catch (t) {
		return {
			ok: !1,
			state: e,
			issues: t instanceof X ? t.issues : [Z(t instanceof Error ? t.message : "効果を適用できません。", "effects")]
		};
	}
}
function Gn(e, t, n) {
	if (!t.length) return {
		ok: !0,
		state: structuredClone(e)
	};
	let r = structuredClone(e), i = [], a = [];
	for (let e of t) for (let t of Mn(n)) {
		if (t.data.derived || t.data.externalContractId) continue;
		let n = t.data.resetRules?.find((t) => t.on === e), o = e === "full_reset" || e === "new_loop" && [
			"scene",
			"chapter",
			"run"
		].includes(t.data.scope);
		if (!n && !o) continue;
		let s = n?.value ?? t.data.initial;
		i.push({
			operation: "reset",
			targetId: t.id,
			value: s
		}), a.push({
			variableId: t.id,
			on: e,
			before: structuredClone(r.variableValues[t.id] ?? {
				type: "unknown",
				value: null,
				reason: "途中開始時の値が未指定です。"
			}),
			after: structuredClone(s),
			reason: n?.reason || (n ? "宣言した初期化規則" : `有効範囲 ${t.data.scope} の初期化`)
		}), r.variableValues[t.id] = structuredClone(s);
	}
	let o = Wn(e, i, n);
	return o.ok && t.length && (a.length || e.resetCauses) && (o.state.resetCauses = a), o;
}
//#endregion
//#region src/domain/writingWorkspace.ts
function Kn(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function qn(e) {
	let { history: t, snapshots: n, ...r } = e, i = structuredClone(r);
	return delete i.authorAlternatives, i;
}
function Jn(e) {
	let t = e.versions.find((t) => t.id === e.headVersionId);
	if (!t) throw Error("別案の現在版が見つかりません。");
	return structuredClone(t.content);
}
function Yn(e, t, n = "別案の編集", r = (/* @__PURE__ */ new Date()).toISOString(), i = globalThis.crypto.randomUUID(), a) {
	let o = qn(t);
	if (o.projectId !== e.projectId) throw Error("別の作品の内容をこの別案へ保存できません。");
	if (!e.versions.some((t) => t.id === e.headVersionId)) throw Error("別案の現在版が見つかりません。");
	let s = {
		id: i,
		parentVersionId: e.headVersionId,
		label: n.trim() || "別案の編集",
		createdAt: r,
		content: o,
		...a ? { structurePlan: structuredClone(a) } : {}
	};
	return {
		...structuredClone(e),
		versions: [...e.versions, s],
		headVersionId: s.id,
		updatedAt: r
	};
}
function Xn(e, t) {
	return JSON.stringify(e) === JSON.stringify(t);
}
function Zn(e, t, n) {
	return [
		e,
		t ?? "",
		...n
	].map((e) => encodeURIComponent(e)).join(":");
}
function Qn(e, t, n, r) {
	if (e === "presentation") return Kn(t);
	if (e === "project") return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, t);
	let i = (e === "entity" ? t.entities : t.relations).find((e) => e.id === n);
	if (i) return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, i);
}
function $n(e, t, n, r, i, a, o, s) {
	if (Xn(a, s) || Xn(o, s)) return;
	let c = a === void 0 ? "add" : s === void 0 ? "remove" : "replace";
	e.push({
		key: Zn(t, n, r),
		scope: t,
		...n ? { itemId: n } : {},
		path: r,
		label: i,
		kind: c,
		baseValue: structuredClone(a),
		canonicalValue: structuredClone(o),
		alternativeValue: structuredClone(s),
		conflict: !Xn(o, a) && !Xn(o, s)
	});
}
function er(e) {
	return new Map(e.entities.map((e) => [e.id, e]));
}
function tr(e, t) {
	if (t.projectId !== e.projectId) throw Error("別の作品とは比較できません。");
	let n = e.baseContent, r = Jn(e), i = qn(t), a = [];
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) $n(a, "project", void 0, [e], {
		name: "作品名",
		calendarId: "標準暦",
		mainStart: "本編開始時点",
		calendars: "暦の定義",
		worldReferences: "参照する世界版"
	}[e], n[e], i[e], r[e]);
	let o = er(n), s = er(r), c = er(i), l = /* @__PURE__ */ new Set([
		"id",
		"projectId",
		"kind",
		"revision",
		"createdAt",
		"updatedAt"
	]);
	for (let e of /* @__PURE__ */ new Set([...o.keys(), ...s.keys()])) {
		let t = o.get(e), n = s.get(e), r = c.get(e);
		if (!t || !n) {
			$n(a, "entity", e, [], `${t?.name ?? n?.name ?? "情報"} · 情報全体`, t, r, n);
			continue;
		}
		let i = /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)]);
		for (let o of i) {
			if (l.has(o) || o === "data" || o === "customValues") continue;
			let i = t[o], s = n[o], c = r && r[o];
			$n(a, "entity", e, [o], `${n.name} · ${o}`, i, c, s);
		}
		let u = t.data, d = n.data, f = r?.data;
		for (let r of /* @__PURE__ */ new Set([...Object.keys(u), ...Object.keys(d)])) t.kind === "chapter" && r === "sceneIds" || t.kind === "scene" && r === "chapterId" || $n(a, "entity", e, ["data", r], `${n.name} · ${r}`, u[r], f?.[r], d[r]);
		let p = t.customValues, m = n.customValues, h = r?.customValues;
		for (let t of /* @__PURE__ */ new Set([...Object.keys(p), ...Object.keys(m)])) $n(a, "entity", e, ["customValues", t], `${n.name} · 独自項目 ${t}`, p[t], h?.[t], m[t]);
	}
	let u = new Map(n.relations.map((e) => [e.id, e])), d = new Map(r.relations.map((e) => [e.id, e])), f = new Map(i.relations.map((e) => [e.id, e]));
	for (let e of /* @__PURE__ */ new Set([...u.keys(), ...d.keys()])) {
		let t = u.get(e), n = d.get(e), r = f.get(e);
		if (!t || !n) {
			$n(a, "relation", e, [], "関係 · 全体", t, r, n);
			continue;
		}
		for (let i of /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)])) {
			if ([
				"id",
				"projectId",
				"revision"
			].includes(i)) continue;
			let o = t[i], s = n[i], c = r && r[i];
			$n(a, "relation", e, [i], `関係 ${t.fromId.slice(-6)} → ${t.toId.slice(-6)} · ${i}`, o, c, s);
		}
	}
	let p = Kn(n), m = Kn(r), h = Kn(i);
	return !Xn(p, m) && !Xn(h, m) && a.push({
		key: Zn("presentation", void 0, ["all"]),
		scope: "presentation",
		path: ["all"],
		label: "章と場面の提示順",
		kind: "replace",
		baseValue: p,
		canonicalValue: h,
		alternativeValue: m,
		conflict: !Xn(h, p)
	}), a.sort((e, t) => e.label.localeCompare(t.label) || e.key.localeCompare(t.key));
}
function nr(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	return t.length && (n === void 0 ? delete i[t[t.length - 1]] : i[t[t.length - 1]] = structuredClone(n)), r;
}
function rr(e, t) {
	let n = structuredClone(e), r = new Map(n.entities.filter((e) => e.kind === "chapter").map((e) => [e.id, e]));
	for (let e of r.values()) e.data.sceneIds = t.chapters.find((t) => t.id === e.id)?.sceneIds.filter((e) => n.entities.some((t) => t.kind === "scene" && t.id === e)) ?? [];
	for (let e of n.entities) e.kind === "scene" && (e.data.chapterId = t.scenes.find((t) => t.id === e.id)?.chapterId ?? null);
	let i = t.chapterOrder.flatMap((e) => {
		let t = r.get(e);
		return t ? [t] : [];
	});
	return n.entities.flatMap((e, t) => e.kind === "chapter" && !e.deletedAt ? [t] : []).forEach((e, t) => {
		i[t] && (n.entities[e] = i[t]);
	}), n;
}
function ir(e, t, n) {
	if (t.scope === "presentation") return rr(e, n);
	if (t.scope === "project") return nr(e, t.path, n);
	let r = t.scope === "entity" ? "entities" : "relations", i = [...e[r]], a = i.findIndex((e) => e.id === t.itemId);
	if (!t.path.length) n === void 0 ? a >= 0 && i.splice(a, 1) : a < 0 ? i.push(structuredClone(n)) : i[a] = structuredClone(n);
	else if (a >= 0) i[a] = nr(i[a], t.path, n);
	else if (n !== void 0) throw Error(`差分の対象が見つかりません: ${t.itemId}`);
	return {
		...e,
		[r]: i
	};
}
function ar(e, t, n, r, i = (/* @__PURE__ */ new Date()).toISOString(), a = globalThis.crypto.randomUUID()) {
	let o = tr(t, e);
	if ([...r].some((e) => !o.some((t) => t.key === e))) throw Error("選択した差分は現在の別案・正本から確認できません。内容を比較し直してください。");
	let s = o.filter((e) => r.has(e.key));
	if (!s.length) throw Error("採用する変更を選んでください。");
	if (s.some((e) => e.conflict)) throw Error("分岐元の後に正本が更新された項目があります。競合を確認し、別案の最新内容へ取り込んでください。");
	let c = qn(e), l = [];
	for (let e of [...s].sort((e, t) => +(e.scope === "presentation") - (t.scope === "presentation"))) {
		let t = Qn(e.scope, c, e.itemId, e.path), n = e.alternativeValue;
		l.push({
			key: e.key,
			scope: e.scope,
			...e.itemId ? { itemId: e.itemId } : {},
			path: [...e.path],
			label: e.label,
			before: t === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(t)
			},
			after: n === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(n)
			}
		}), c = ir(c, e, e.alternativeValue);
	}
	if (c.projectId !== e.projectId) throw Error("別案のprojectIdは変更できません。");
	let { history: u, ...d } = e;
	return {
		project: {
			...structuredClone(d),
			...c,
			snapshots: e.snapshots,
			history: e.history
		},
		receipt: {
			id: a,
			createdAt: i,
			alternativeVersionId: t.headVersionId,
			sourceSnapshotId: t.sourceSnapshotId ?? null,
			selectedChangeKeys: [...r].sort(),
			fromCanonicalRevision: e.revision,
			patches: l
		}
	};
}
//#endregion
//#region src/domain/runtimeVersions.ts
async function or(e, t = e.projectId, n = {}, r) {
	let i = t === e.projectId ? e : e.snapshots.find((e) => e.id === t);
	if (!i) throw new X([{
		code: "REFERENCE_INVALID",
		path: "contentVersionId",
		message: "実行する固定版がありません。"
	}]);
	let a = n.worldSnapshots ? r?.stableRegistries.has(n.worldSnapshots) ? n.worldSnapshots : r ? h(n.worldSnapshots, r) : structuredClone(n.worldSnapshots) : {}, o = n.worlds ? structuredClone(n.worlds) : void 0, s = {
		...n,
		worldSnapshots: a,
		worlds: o
	}, c = "content" in i, u = structuredClone(c ? i.content : i), d = c ? i.contentHash : void 0, p = "content" in i ? i.id : e.projectId, m = structuredClone(e.snapshots), { authorAlternatives: g, snapshots: _, history: te, ...v } = u, y = {
		...v,
		snapshots: m,
		history: []
	};
	if (d && await f(l(v)) !== d) throw new X([{
		code: "INTEGRITY_FAILED",
		path: `snapshots.${p}.contentHash`,
		message: "固定版の内容ハッシュが一致しません。実行を停止しました。"
	}]);
	let ne = /* @__PURE__ */ new Set(), b = [y];
	for (let e = 0; e < b.length; e++) for (let t of b[e].entities) if ((t.kind === "scene" || t.kind === "flow_node") && t.data.reuse && t.data.reuse.mode !== "clone") {
		let e = t.data.reuse.pinnedSnapshotId;
		if (ne.has(e)) continue;
		ne.add(e);
		let n = m.find((t) => t.id === e);
		if (!n || await f(l(n.content)) !== n.contentHash) throw new X([{
			code: "INTEGRITY_FAILED",
			path: `snapshots.${e}`,
			message: "共通元の固定版がないか、内容hashが一致しません。"
		}]);
		b.push({
			...n.content,
			snapshots: m,
			history: []
		});
	}
	let re = await ee(de(y, m), a, "worldReferences", r);
	if (re.length) throw new X(re);
	let x = Cn(y, s);
	if (!x.ok) throw new X(x.issues);
	return y;
}
//#endregion
//#region src/domain/externalInputs.ts
function sr(e, t, n, r = []) {
	let i = [], a = [...e.entities, ...r].filter(_);
	n && (n.mode !== "actual" || !/^[0-9a-f]{64}$/.test(n.receiptHash)) && i.push({
		code: "INTEGRITY_FAILED",
		path: "receiptHash",
		message: "実際の外部入力には検証済み受信記録のSHA-256が必要です。"
	});
	for (let [e, n] of Object.entries(t)) {
		let t = `externalValues.${e}`, r = a.find((t) => t.id === e && t.kind === "external_contract");
		if (!r) {
			i.push({
				code: "REFERENCE_INVALID",
				path: t,
				message: "入力先の外部契約が存在しないか、削除・不採用です。"
			});
			continue;
		}
		let o = Yt(n);
		if (!o.ok) {
			i.push(...o.issues.map((e) => ({
				...e,
				path: t
			})));
			continue;
		}
		if (n.type !== "unknown" && n.type !== r.data.outputType) {
			i.push({
				code: "VALIDATION_FAILED",
				path: t,
				message: "実際の外部値と契約の出力型が違います。"
			});
			continue;
		}
		n.type === "unknown" && r.data.missingPolicy === "block" && i.push({
			code: "CONDITION_UNKNOWN",
			path: t,
			message: n.reason || "この外部契約は未確認値で進められません。"
		});
		for (let r of a) r.kind === "variable" && r.data.externalContractId === e && i.push(...Y(r, n, t, !0));
	}
	return i;
}
structuredClone;
//#endregion
//#region src/domain/presentation.ts
var $ = (e, t) => e.entities.filter((e) => e.kind === t && _(e)), cr = (e, t, n = "REFERENCE_INVALID") => ({
	ok: !1,
	issues: [{
		code: n,
		path: e,
		message: t
	}]
});
function lr(e, t) {
	let n = $(e, "flow_node").find((e) => e.id === t.nodeId), r = $(e, "scene").find((e) => e.id === (t.sceneId ?? n?.data.sceneId));
	return {
		projectId: e.projectId,
		worldTick: t.worldTick,
		graphId: n ? $(e, "flow_graph").find((e) => e.data.nodeIds.includes(n.id))?.id : void 0,
		chapterId: r?.data.chapterId ?? (r ? $(e, "chapter").find((e) => e.data.sceneIds.includes(r.id))?.id : void 0)
	};
}
function ur(e, t) {
	let n = $(e, "flow_node").find((e) => e.id === t.nodeId), r = $(e, "scene").find((e) => e.id === (t.sceneId ?? n?.data.sceneId)), i = n?.data.executionPolicy ?? (n?.data.nodeType === "automatic" ? "first_match" : "manual_choice");
	return [.../* @__PURE__ */ new Set([...r?.data.dialogueLineIds ?? [], ...n && i === "manual_choice" ? $(e, "flow_edge").filter((e) => e.data.fromId === n.id).flatMap((e) => e.data.choiceLineId ? [e.data.choiceLineId] : []) : []])];
}
function dr(e, t, n, r, i) {
	if (n.positionStatus === "unresolved") return !1;
	let a = i ? y(e, i) : void 0;
	if (n.sourceVersionId && ![
		e.projectId,
		t.contentVersionId,
		y(e, n.entityId)?.sourceVersionId,
		a?.sourceVersionId
	].includes(n.sourceVersionId)) return !1;
	let o = $(e, "flow_node").find((e) => e.id === r.nodeId), s = r.sceneId ?? o?.data.sceneId;
	$(e, "scene").find((e) => e.id === s);
	let c = ur(e, r);
	return [
		r.nodeId,
		s,
		...c
	].includes(n.entityId) ? [
		n.entityId,
		n.blockId,
		n.lineId
	].filter((e) => !!e).every((e) => t.seenIds.includes(e)) : !1;
}
function fr(e, t, n, r) {
	if (t.positionStatus === "unresolved" || n.positionStatus === "unresolved") return;
	let i = $(e, "flow_node").find((e) => e.id === r.nodeId), a = $(e, "scene").find((e) => e.id === (r.sceneId ?? i?.data.sceneId)), o = ur(e, r), s = [...(a?.data.body ?? []).map((e) => e.id)];
	for (let t of o) s.push(t, ...($(e, "dialogue_line").find((e) => e.id === t)?.data.text ?? []).map((e) => e.id));
	let c = t.blockId ?? t.lineId ?? (o.includes(t.entityId) ? t.entityId : void 0), l = n.blockId ?? n.lineId ?? (o.includes(n.entityId) ? n.entityId : void 0), u = s.indexOf(c ?? ""), d = s.indexOf(l ?? "");
	if (u >= 0 && d >= 0 && u !== d) return u < d;
	if (c === l && t.entityId === n.entityId && t.start != null && n.start != null && t.start !== n.start && !(t.start < n.start && t.end != null && t.end > n.start || n.start < t.start && n.end != null && n.end > t.start)) return t.start < n.start;
}
function pr(e, t, n) {
	let r = Xt(t);
	if (!r.ok) return {
		ok: !1,
		issues: r.issues
	};
	let i = sr(e, n.externalValues ?? {}, void 0, n.referenceEntities);
	if (i.length) return {
		ok: !1,
		issues: i
	};
	try {
		let r = n.nodeId ? $(e, "flow_node").find((e) => e.id === n.nodeId) : void 0;
		if (n.nodeId && !r) return cr("presentation.nodeId", "提示する分岐が存在しないか、削除・不採用です。");
		let i = n.sceneId ?? r?.data.sceneId ?? void 0;
		if (!r && !i) return cr("presentation", "提示する場面または分岐を指定してください。");
		let a = i ? $(e, "scene").find((e) => e.id === i) : void 0;
		if (i && !a) return cr("presentation.sceneId", "提示する場面が存在しないか、削除・不採用です。");
		let o = lr(e, {
			...n,
			sceneId: i
		}), s = zn({
			state: t,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: o,
			ruleContexts: fe(e, o)
		});
		if (s.length) return {
			ok: !1,
			issues: s
		};
		let c = {
			...n,
			sceneId: i
		}, l = structuredClone(t), u = new Set(l.seenIds);
		if (r && (l.presentationPosition = r.id, l.visitCounts[r.id] = (l.visitCounts[r.id] ?? 0) + 1, u.add(r.id)), a) {
			u.add(a.id), l.visitCounts[a.id] = (l.visitCounts[a.id] ?? 0) + 1;
			for (let e of a.data.blockIds ?? []) u.add(e);
			for (let e of a.data.body) u.add(e.id);
		}
		for (let t of ur(e, c)) {
			let n = $(e, "dialogue_line").find((e) => e.id === t);
			if (!n) return cr(`${r?.id ?? a?.id}.dialogueLineIds`, "提示する台詞が存在しないか、削除・不採用です。");
			u.add(n.id), l.visitCounts[n.id] = (l.visitCounts[n.id] ?? 0) + 1;
			for (let e of n.data.text) u.add(e.id);
		}
		l.seenIds = [...u];
		let d = [...$(e, "variable"), ...(n.referenceEntities ?? []).filter((e) => e.kind === "variable" && _(e))], f = lr(e, c), p = {
			state: l,
			variables: d,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: f,
			ruleContexts: fe(e, f)
		}, m = [], h = [];
		for (let n of $(e, "disclosure")) {
			let i = pe(e, n.data.anchor, n.id), o = n.data.targetScope, s = {
				...p,
				ruleContext: p.ruleContexts[n.id] ?? p.ruleContext
			}, u = o ? Dn(o, s) : { value: "true" };
			if (u.value === "false" || i.sourceVersionId && ![
				e.projectId,
				t.contentVersionId,
				y(e, i.entityId)?.sourceVersionId,
				y(e, n.id)?.sourceVersionId
			].includes(i.sourceVersionId)) continue;
			let d = ur(e, c);
			if (![
				r?.id,
				a?.id,
				...d
			].includes(i.entityId)) continue;
			if (u.value === "unknown") return cr(`${n.id}.targetScope`, "開示の対象範囲・経路を確認できません。", "CONDITION_UNKNOWN");
			if (i.positionStatus === "unresolved" && [
				r?.id,
				a?.id,
				...d
			].includes(i.entityId)) return cr(`${n.id}.anchor`, i.positionReason || "提示位置が不明です。本文へ再リンクしてください。", "CONDITION_UNKNOWN");
			if (!dr(e, l, i, c, n.id)) continue;
			let f = In({
				op: "all",
				children: [n.data.condition ?? {
					op: "constant",
					value: !0
				}, o?.routeCondition ?? {
					op: "constant",
					value: !0
				}]
			}, s);
			if (m.push({
				targetId: n.id,
				...f
			}), f.value === "unknown") return cr(`${n.id}.condition`, f.reasons.join("、") || "この場面の開示条件が未確認です。", "CONDITION_UNKNOWN");
			f.value === "true" && h.push(n);
		}
		let g = h.filter((e) => (e.data.knowledgeEffects?.length ?? 0) > 0);
		for (let t = 0; t < g.length; t++) for (let n = t + 1; n < g.length; n++) if (fr(e, pe(e, g[t].data.anchor, g[t].id), pe(e, g[n].data.anchor, g[n].id), c) === void 0) return cr(`${r?.id ?? a?.id}.disclosures`, "複数の開示効果の提示順が確定していません。段落と文字位置を指定してください。", "CONDITION_UNKNOWN");
		g.sort((t, n) => fr(e, pe(e, t.data.anchor, t.id), pe(e, n.data.anchor, n.id), c) ? -1 : 1);
		let ee = [], te = [];
		for (let t of g) for (let r of t.data.knowledgeEffects ?? []) {
			let i = [...e.entities, ...n.referenceEntities ?? []].find((e) => e.kind === "effect" && e.id === r && _(e));
			if (!i) return cr(`${t.id}.knowledgeEffects`, "開示に指定した効果が存在しないか、削除・不採用です。");
			ee.push(i), te.push({
				project: e,
				target: c,
				anchor: pe(e, t.data.anchor, t.id)
			});
		}
		let v = Wn(l, ee, {
			...p,
			effectPresentations: te
		});
		return v.ok ? (v.state.seenIds = [.../* @__PURE__ */ new Set([...v.state.seenIds, ...h.map((e) => e.id)])], {
			ok: !0,
			state: v.state,
			observationState: structuredClone(l),
			conditions: m
		}) : v;
	} catch (e) {
		return {
			ok: !1,
			issues: e instanceof X ? e.issues : [{
				code: "VALIDATION_FAILED",
				path: "presentation",
				message: e instanceof Error ? e.message : "提示を検証できません。"
			}]
		};
	}
}
function mr(e, t, n) {
	let { sceneId: r, previousSceneId: i } = n, a = lr(e, { sceneId: i }), o = lr(e, { sceneId: r }), s = i && i !== r ? ["scene_end"] : [];
	a.chapterId && a.chapterId !== o.chapterId && s.push("chapter_end");
	let c = Gn({
		...t,
		...t.resetCauses ? { resetCauses: [] } : {}
	}, s, {
		state: t,
		entities: e.entities,
		referenceEntities: n.referenceEntities,
		externalValues: n.externalValues,
		ruleContext: lr(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick
		}),
		ruleContexts: fe(e, lr(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick
		}))
	});
	if (!c.ok) return c;
	let l = pr(e, c.state, n);
	if (!l.ok) return l;
	if (n.last) {
		let t = Gn(l.state, [
			"scene_end",
			"chapter_end",
			"run_end"
		], {
			state: l.state,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: lr(e, n),
			ruleContexts: fe(e, lr(e, n))
		});
		if (!t.ok) return t;
		l.state = t.state, (c.state.resetCauses || t.state.resetCauses) && (l.state.resetCauses = [...c.state.resetCauses ?? [], ...t.state.resetCauses ?? []]);
	}
	return l;
}
//#endregion
export { p as $, wn as A, fe as B, Ge as C, sn as D, Ke as E, S as F, ee as G, m as H, Ee as I, c as J, i as K, de as L, Cn as M, Xt as N, cn as O, Y as P, o as Q, ne as R, et as S, Ye as T, h as U, _ as V, g as W, d as X, u as Y, l as Z, He as _, or as a, Qe as b, qn as c, Rn as d, f as et, Gn as f, Re as g, Ue as h, sr as i, n as it, Zt as j, qe as k, Wn as l, E as m, pr as n, e as nt, Yn as o, zn as p, r as q, lr as r, t as rt, ar as s, mr as t, s as tt, In as u, nn as v, Xe as w, $e as x, rn as y, y as z };
