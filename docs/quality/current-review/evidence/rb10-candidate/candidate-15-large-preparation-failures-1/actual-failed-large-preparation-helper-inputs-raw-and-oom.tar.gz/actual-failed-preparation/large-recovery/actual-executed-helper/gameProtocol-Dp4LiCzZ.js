import { D as e, J as t, K as n, L as r, M as i, Q as a, W as o, Z as s, a as c, b as l, et as u, x as d } from "./presentation-Bbhg70AW.js";
import { startTrial as f, stepTrial as p } from "./runtime-TkB-9JI1.js";
import { t as m } from "./exportPreparation-CCZngPw_.js";
//#region src/domain/runtimeVerified.ts
async function h(e, t, n) {
	let i = structuredClone(e), a = structuredClone(n), s = await c(i, t, { worldSnapshots: a });
	return {
		source: i,
		content: s,
		registry: a,
		referenceEntities: o(r(s, s.snapshots), a).worlds.flatMap((e) => e.entities)
	};
}
async function g(e, t = {}, n = {}) {
	let r = structuredClone(t), i = await h(e, r.contentVersionId ?? e.projectId, n);
	return f(i.source, {
		...r,
		referenceEntities: i.referenceEntities
	});
}
//#endregion
//#region src/domain/portableRuntimeProject.ts
async function _(t) {
	let n = await u(s(t)), r = (e) => `${e.slice(0, 8)}-${e.slice(8, 12)}-4${e.slice(13, 16)}-a${e.slice(17, 20)}-${e.slice(20, 32)}`, a = r(n), o = t.versions ?? [];
	if (o.length > 128 || new Set(o.map((e) => e.id)).size !== o.length || o.some((e) => e.projection.versions?.length)) throw Error("EXPORT_UNSUPPORTED: 公開引用版の上限・重複・依存形式が不正です。");
	let c = [t, ...o.map((e) => e.projection)], f = new Set(c.flatMap((e) => [...e.entities.map((e) => e.id), ...e.relations.map((e) => e.id)]));
	o.forEach((e) => f.add(e.id));
	function p(e) {
		if (Array.isArray(e)) {
			e.forEach(p);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		typeof t.id == "string" && typeof t.text == "string" && typeof t.kind == "string" && f.add(t.id), typeof t.id == "string" && typeof t.eventKey == "string" && f.add(t.id), Object.values(t).forEach(p);
	}
	c.forEach((e) => e.entities.forEach((e) => p(e.data)));
	let m = { "public-project": a };
	for (let e of f) m[e] = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(e) ? e : r(await u(new TextEncoder().encode(`scenario-runtime-1:${e}`)));
	function h(e, t) {
		if (Array.isArray(e)) return e.map((e) => h(e, t));
		if (!e || typeof e != "object") return e;
		let n = e, r = Object.fromEntries(Object.entries(n).map(([e, n]) => [e, ["sourceVersionId", "targetSnapshotId"].includes(e) && n === "public-project" ? t : h(n, t)]));
		return typeof n.id == "string" && f.has(n.id) && (r.id = m[n.id]), Array.isArray(n.links) && (r.links = n.links.map((e) => {
			let n = e;
			return {
				start: n.start,
				end: n.end,
				target: {
					entityId: n.targetId,
					...n.blockId ? { blockId: n.blockId } : {},
					...n.lineId ? { lineId: n.lineId } : {},
					...n.sourceVersionId ? { sourceVersionId: n.sourceVersionId === "public-project" ? t : n.sourceVersionId } : {},
					...n.targetStart === void 0 ? {} : {
						start: n.targetStart,
						end: n.targetEnd
					}
				}
			};
		})), r;
	}
	function g(t, n) {
		let r = d(t.title);
		if (r.projectId = a, r.mainStart = t.mainStart ?? "0", r.calendars[0].id = r.calendarId = "public-calendar-default", r.entities = t.entities.map((t) => {
			let r = h(t.data, n);
			delete r.bytesIncluded;
			let i = l(a, t.kind, t.name, r);
			return i.id = m[t.id], i.createdAt = i.updatedAt = "1970-01-01T00:00:00.000Z", i.status = "confirmed", e(i, m);
		}), r.views = [], r.relations = t.relations.map((t) => ({
			...t,
			id: m[t.id],
			projectId: a,
			fromId: m[t.fromId],
			toId: m[t.toId],
			evidenceIds: t.evidenceIds.map((e) => m[e]),
			revision: "0",
			status: "confirmed",
			visibility: "projection",
			validity: e(l(a, "assertion", "公開関係の期間", {
				subjectId: m[t.fromId],
				predicate: "relation",
				validity: h(t.validity, n) ?? {
					worldRange: null,
					routeCondition: null,
					presentationAnchor: null
				}
			}), m).data.validity
		})), r.worldReferences = [], r.snapshots = [], r.history = [], t.calendars.length) {
			let e = r.calendars[0];
			r.calendars = t.calendars.map((t) => t.kind === "repeating" ? {
				id: t.id,
				name: t.name,
				kind: "repeating",
				originLabel: t.originLabel,
				ticksPerDay: t.ticksPerDay,
				years: t.years ?? []
			} : {
				...e,
				id: t.id,
				name: t.name,
				kind: "gregorian",
				ticksPerDay: t.ticksPerDay
			}), r.calendarId = r.calendars[0].id;
		}
		return r;
	}
	let _ = g(t, a);
	for (let e of o) {
		let { history: t, snapshots: n, authorAlternatives: r, ...i } = g(e.projection, m[e.id]);
		_.snapshots.push({
			id: m[e.id],
			versionLabel: e.projection.title,
			createdAt: "1970-01-01T00:00:00.000Z",
			content: i,
			contentHash: await u(s(i))
		});
	}
	let v = i(_);
	if (!v.ok) throw Object.assign(/* @__PURE__ */ Error("EXPORT_UNSUPPORTED: 公開実行内容を同じstrict契約へ対応できません。"), { issues: v.issues });
	return {
		project: _,
		publicToRuntime: m
	};
}
//#endregion
//#region src/domain/gameEvidence.ts
var v = (e) => {
	throw Error(`INTEGRITY_FAILED: ${e}`);
};
async function y(e, t, n) {
	t = structuredClone(t);
	let r = structuredClone(e), i = structuredClone(n), a = r.snapshots.find((e) => e.id === t.verificationVersionId);
	(!a || await u(s(a.content)) !== a.contentHash) && v("保存したゲーム受領の公開確認版を検証できません。");
	let o = a.content.entities.find((e) => e.id === t.approval.entityId);
	(t.approval.sourceVersionId !== a.id || o?.kind !== "note" || o.visibility !== "private" || o.status !== "confirmed" || o.customValues.gamePackageHash !== t.packageHash || o.customValues.gameReceiptHash !== t.receiptHash) && v("保存したゲーム受領hashが固定承認と一致しません。");
	let c = r.snapshots.find((e) => e.id === t.sourceVersionId)?.content;
	(!c || c.revision !== t.sourceRevision) && v("保存したゲーム受領の対象revisionが一致しません。");
	let l = {
		...structuredClone(a.content),
		snapshots: r.snapshots,
		history: []
	}, d = /* @__PURE__ */ new Map();
	for (let e of t.projectionBindings) {
		let t = d.get(e.editionVersionId);
		t || (t = {}, d.set(e.editionVersionId, t)), t[e.entityId] && t[e.entityId] !== e.publicId && v("保存した公開ID対応が重複しています。"), t[e.entityId] = e.publicId;
	}
	let f = new Map(t.citationBindings.map((e) => [e.sourceVersionId, e.publicVersionId]));
	f.size !== t.citationBindings.length && v("保存した引用版対応が重複しています。");
	let p = (e, n) => {
		if (e.kind !== "projection_profile") return e;
		let r = e.id === t.profileId ? t.sourceVersionId : e.data.sourceVersionId ?? n, i = d.get(r) ?? {}, a = structuredClone(e.data.namePolicy);
		for (let [e, t] of Object.entries(a.byEntityId ?? {})) t.mode === "anonymize" && i[e] && (t.publicId = i[e]);
		return {
			...e,
			data: {
				...e.data,
				publicIds: {
					...e.data.publicIds,
					...i
				},
				namePolicy: a,
				citedVersions: e.data.citedVersions?.map((e) => ({
					...e,
					publicVersionId: f.get(e.sourceVersionId) ?? e.publicVersionId
				}))
			}
		};
	};
	l.entities = l.entities.map((e) => p(e, t.sourceVersionId)), l.snapshots = await Promise.all(l.snapshots.map(async (e) => {
		await u(s(e.content)) !== e.contentHash && v("保存したゲーム受領の元版hashが一致しません。");
		let t = {
			...e.content,
			entities: e.content.entities.map((t) => p(t, e.id))
		};
		return {
			...e,
			content: t,
			contentHash: await u(s(t))
		};
	}));
	let h = [];
	for (let e of t.worldVersions) {
		let t = i[e.sourceVersionId];
		(!t || await u(s(t)) !== e.contentHash) && v("保存したゲーム受領の固定世界hashが一致しません。"), h.push({
			id: e.sourceVersionId,
			content: t,
			contentHash: e.contentHash
		});
	}
	let g = t.sourceVersionId === t.verificationVersionId, y = await m(l, {
		profile: "runtime_json",
		projectionProfileId: t.profileId,
		...g ? { targetRevision: l.revision } : { targetVersionId: t.sourceVersionId },
		worldSnapshots: i,
		worldPins: h
	}), b = Object.entries(y.idMap).filter(([, e]) => y.projection.entities.some((t) => t.id === e));
	(b.length !== t.idMappings.length || b.some(([e, n]) => !t.idMappings.some((r) => r.entityId === e && r.publicId === n && r.sourceVersionId === t.sourceVersionId))) && v("保存したゲーム受領の元ID・公開ID対応が一致しません。");
	for (let e of [y.projection, ...y.projection.versions?.map((e) => e.projection) ?? []]) for (let t of e.entities) t.kind === "attachment" && (t.data.bytesIncluded = !0);
	let x = await _(y.projection);
	return {
		publicProjection: y.projection,
		runtimeProject: x.project,
		publicToRuntime: x.publicToRuntime,
		runtimeProjectHash: await u(s(x.project)),
		entities: y.projection.entities
	};
}
var b = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/, x = (e) => {
	throw Error(`INTEGRITY_FAILED: ${e}`);
};
function S(e) {
	let t = e, n = [
		"format",
		"formatVersion",
		"specification",
		"receiverId",
		"sessionId",
		"receivedAt",
		"packageHash",
		"runtimeProjectHash",
		"entryId",
		"worldTick",
		"actions",
		"requests",
		"finalState",
		"status",
		"mode",
		"dialogueIds",
		"assets",
		"receiptHash"
	], r = /^[a-f0-9]{64}$/;
	(!t || typeof t != "object" || Array.isArray(t) || Object.keys(t).some((e) => !n.includes(e)) || t.format !== "scenario-game-receipt" || t.formatVersion !== "1.0.0" || t.specification !== "scenario-browser-game/1.0.0" || t.receiverId !== "independent-browser-game" || typeof t.sessionId != "string" || !b.test(t.sessionId) || typeof t.entryId != "string" || !b.test(t.entryId) || typeof t.receivedAt != "string" || !Number.isFinite(Date.parse(t.receivedAt)) || ![
		t.packageHash,
		t.runtimeProjectHash,
		t.receiptHash
	].every((e) => typeof e == "string" && r.test(e)) || ![
		"stub",
		"actual",
		"mixed"
	].includes(t.mode) || ![
		"ready",
		"terminal",
		"blocked",
		"unknown",
		"error"
	].includes(t.status) || !t.finalState || typeof t.finalState != "object" || Array.isArray(t.finalState) || t.worldTick != null && (typeof t.worldTick != "string" || !/^(?:0|-[1-9][0-9]*|[1-9][0-9]*)$/.test(t.worldTick)) || !Array.isArray(t.actions) || t.actions.length > 1e4 || !Array.isArray(t.requests) || t.requests.length > 1e4 || !Array.isArray(t.dialogueIds) || t.dialogueIds.some((e) => typeof e != "string") || new Set(t.dialogueIds).size !== t.dialogueIds.length || !Array.isArray(t.assets) || t.assets.some((e) => !e || Object.keys(e).some((e) => !["id", "contentHash"].includes(e)) || typeof e.id != "string" || !r.test(e.contentHash)) || new Set(t.assets.map((e) => e.id)).size !== t.assets.length || s(t).byteLength > 1048576) && x("受領証跡の仕様・構造・上限が不正です。");
	for (let e of t.actions) (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((e) => ![
		"sequence",
		"id",
		"contractId",
		"action",
		"stubIndex",
		"score",
		"value",
		"executedAt",
		"previousHash",
		"hash"
	].includes(e)) || typeof e.id != "string" || !b.test(e.id) || typeof e.contractId != "string" || typeof e.executedAt != "string" || !Number.isFinite(Date.parse(e.executedAt)) || ![
		"win",
		"lose",
		"collect",
		"stub"
	].includes(e.action) || !Number.isSafeInteger(e.score) || !Number.isSafeInteger(e.sequence) || !r.test(e.previousHash) || !r.test(e.hash)) && x("ゲーム実行記録のID・日時・構造が不正です。");
	for (let e of t.requests) (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((e) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(e))) && x("受領証跡の進行要求が未対応です。");
	return t;
}
function C(e) {
	return [...e.publicProjection.entities.filter((e) => e.kind === "attachment").map((e) => ({
		id: e.id,
		data: e.data
	})), ...(e.publicProjection.versions ?? []).flatMap((e) => e.projection.entities.filter((e) => e.kind === "attachment").map((t) => ({
		id: `${e.id}:${t.id}`,
		data: t.data
	})))];
}
function w(e, t) {
	let n = e.runtimeProject.entities.find((n) => n.kind === "external_contract" && n.id === e.publicToRuntime[t]);
	return n || x("受取パッケージに外部契約がありません。"), n;
}
function T(e, t, n, r, i) {
	let a = w(e, t);
	if (n === "stub") {
		let e = a.data.stubValues?.[i ?? -1];
		return e || x("宣言済み仮値がありません。"), {
			score: r,
			value: structuredClone(e)
		};
	}
	a.data.owner !== "game" && x("ゲーム管理以外の外部契約を実測にできません。");
	let o = n === "win" ? r + 3 : n === "collect" ? r + 1 : Math.max(0, r - 1), s;
	if (a.data.outputType === "boolean") s = {
		type: "boolean",
		value: n !== "lose"
	};
	else if (a.data.outputType === "integer") s = {
		type: "integer",
		value: o
	};
	else if (a.data.outputType === "enum") {
		let e = (a.data.stubValues ?? []).filter((e) => e.type === "enum");
		e.length || x("列挙結果の宣言がありません。"), s = structuredClone(e[n === "lose" ? e.length - 1 : n === "win" ? 0 : Math.min(1, e.length - 1)]);
	} else return x("受取例が未対応の結果型です。");
	return {
		score: o,
		value: s
	};
}
function E(e) {
	let t = e.some((e) => e.action === "stub");
	return e.some((e) => e.action !== "stub") ? t ? "mixed" : "actual" : "stub";
}
function D(e, t) {
	return Object.fromEntries(t.map((t) => [e.publicToRuntime[t.contractId], t.value]));
}
async function O(e, n) {
	let r = n.packageHash, i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Set();
	for (let [o, c] of n.actions.entries()) {
		(!c || typeof c.id != "string" || !b.test(c.id) || a.has(c.id) || c.sequence !== o + 1 || c.previousHash !== r || typeof c.executedAt != "string" || !Number.isFinite(Date.parse(c.executedAt)) || ![
			"win",
			"lose",
			"collect",
			"stub"
		].includes(c.action)) && x("ゲーム実行記録の順序・ID・日時が不正です。"), a.add(c.id), Object.keys(c).some((e) => ![
			"sequence",
			"id",
			"contractId",
			"action",
			"stubIndex",
			"score",
			"value",
			"executedAt",
			"previousHash",
			"hash"
		].includes(e)) && x("未対応のゲーム実行項目があります。");
		let n = T(e, c.contractId, c.action, i.get(c.contractId) ?? 0, c.stubIndex), { hash: l, ...d } = c;
		(t(n.value) !== t(c.value) || n.score !== c.score || await u(s(d)) !== l) && x("ゲーム処理の実結果・hashが一致しません。"), i.set(c.contractId, c.score), r = l;
	}
	n.mode !== E(n.actions) && x("stub/actual/mixedの表示が実行証跡と一致しません。"), (t(n.dialogueIds) !== t(e.entities.filter((e) => e.kind === "dialogue_line").map((e) => e.id)) || t(n.assets) !== t(C(e).map((e) => ({
		id: e.id,
		contentHash: String(e.data.contentHash)
	})))) && x("台詞・素材ID対応または素材hashが一致しません。");
	let o = await g(e.runtimeProject, {
		entryId: n.entryId,
		worldTick: n.worldTick,
		externalValues: D(e, n.actions)
	});
	for (let t of n.requests) (!t || Object.keys(t).some((e) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(e))) && x("受領証跡の進行要求が未対応です。"), o = p(e.runtimeProject, o, t);
	(t(o.state) !== t(n.finalState) || o.status !== n.status) && x("受取ゲームの経路・最終結果を再生できません。");
}
function k(e) {
	return a(e, "game-receipt.json", {
		...n,
		jsonBytes: 1048576
	});
}
async function A(e, n = {}) {
	let r = (e) => [
		e,
		...e.snapshots.map((e) => e.content),
		...e.history.flatMap((e) => [e.before, e.after]),
		...e.authorAlternatives?.flatMap((e) => [e.baseContent, ...e.versions.map((e) => e.content)]) ?? []
	];
	if (!r(e).some((e) => e.entities.some((e) => e.kind === "note" && e.data.handoffReceipt))) return;
	let i = structuredClone(e), a = structuredClone(n), o = r(i), c = /* @__PURE__ */ new Set();
	for (let e of o) for (let n of e.entities) {
		if (n.kind !== "note" || !n.data.handoffReceipt) continue;
		let e = t(n.data.handoffReceipt);
		if (c.has(e)) continue;
		c.add(e);
		let r = n.data.handoffReceipt, o = S(k(new TextEncoder().encode(r.rawJson))), { receiptHash: l, ...d } = o;
		(await u(s(d)) !== l || l !== r.receiptHash || o.packageHash !== r.packageHash || o.mode !== r.mode || E(o.actions) !== r.mode) && x("保存したゲーム受領のhash・実行分類が元証跡と一致しません。");
		let f = await y(i, r, a), p = f;
		o.runtimeProjectHash !== f.runtimeProjectHash && x("保存したゲーム受領の実行内容が元の固定公開版と一致しません。"), await O(p, o);
	}
}
//#endregion
export { A as verifyStoredGameEvidence };
