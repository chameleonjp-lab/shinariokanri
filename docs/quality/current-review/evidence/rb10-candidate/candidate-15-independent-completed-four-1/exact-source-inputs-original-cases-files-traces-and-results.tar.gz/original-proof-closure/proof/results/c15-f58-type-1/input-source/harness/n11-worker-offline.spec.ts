import {test, expect, type Page} from '@playwright/test';
import {createServer} from 'node:http';
import {readFile, realpath} from 'node:fs/promises';
import {resolve, sep, extname} from 'node:path';
import {createEntity, newId, textToRichText} from '../candidate/src/domain/model';
import {jsonBytes, sha256} from '../candidate/src/storage';
import {offlineFixture} from './fixtures';
import {seed, nav, backup, evidence, digest, captureProofFile} from './common';
import {reader, openRecord} from './extended-support';

// Additional original N11/N05 integration, not physical airplane-mode evidence:
// exact cached production+real Worker, actual server shutdown, a new document,
// fixed source version, real cancellation and retained input/native bytes.
test('AT-N11/N05 cached real analysis Worker: stopped server→cold offline→fixed edition cancel→navigation preserves unknown result and unfinished input', async ({page, context}, info) => {
  test.setTimeout(180_000);
  const candidate = JSON.parse(await readFile('candidate-binding.json', 'utf8'));
  const dist = await realpath(resolve('candidate/dist'));
  const build = JSON.parse(await readFile(resolve(dist, 'build-info.json'), 'utf8'));
  expect(build).toMatchObject({commit: candidate.commit, tree: candidate.tree, dirty: false, base: '/shinariokanri/', version: candidate.buildInfo.version});
  const workerDescriptor = candidate.distFiles.find((item: {file: string}) => /^dist\/assets\/analysis\.worker-.*\.js$/.test(item.file));
  expect(workerDescriptor).toBeDefined();
  const server = createServer(async (request, response) => {
    try {
      const url = new URL(request.url ?? '/', 'http://localhost');
      if (!url.pathname.startsWith('/shinariokanri/')) throw Error('outside own static base');
      const file = await realpath(resolve(dist, decodeURIComponent(url.pathname.slice('/shinariokanri/'.length)) || 'index.html'));
      if (!file.startsWith(dist + sep)) throw Error('outside own frozen build');
      response.setHeader('Cache-Control', 'no-cache');
      response.setHeader('Content-Type', ({'.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.css': 'text/css', '.svg': 'image/svg+xml'} as Record<string, string>)[extname(file)] ?? 'application/octet-stream');
      response.end(await readFile(file));
    } catch { response.writeHead(404).end(); }
  });
  await new Promise<void>((done, reject) => { server.once('error', reject); server.listen(5313, '127.0.0.1', done); });
  const url = 'http://127.0.0.1:5313/shinariokanri/';
  const stopServer = async () => { if (server.listening) { server.closeAllConnections(); await new Promise<void>(done => server.close(() => done())); } };
  try {
    await context.addInitScript(() => { (window as any).__independentN11DocumentNonce = crypto.randomUUID(); });
    const f = await offlineFixture(), project = f.p;
    const scene = createEntity(project.projectId, 'scene', '固定版と入力の場面', {body: textToRichText('旧固定本文😀と取得済み画像の根拠。')});
    const variable = createEntity(project.projectId, 'variable', '反復回数', {key: 'offline_loop_count', valueType: 'integer', initial: {type: 'integer', value: 0}, scope: 'across_runs', allowed: {}});
    const effect = createEntity(project.projectId, 'effect', '反復回数を増やす', {operation: 'add', targetId: variable.id, value: {type: 'integer', value: 1}});
    const entry = createEntity(project.projectId, 'flow_node', '固定探索入口', {nodeType: 'entry', executionPolicy: 'first_match', sceneId: scene.id});
    const edge = createEntity(project.projectId, 'flow_edge', '上限未宣言の反復', {fromId: entry.id, toId: entry.id, label: '上限未宣言の反復', effectIds: [effect.id]});
    const graph = createEntity(project.projectId, 'flow_graph', '固定された探索図', {nodeIds: [entry.id], entryIds: [entry.id], exitIds: [], edgeIds: [edge.id]});
    project.entities.push(scene, variable, effect, entry, edge, graph);
    const {history: _history, snapshots: _snapshots, authorAlternatives: _alternatives, ...content} = structuredClone(project);
    const snapshotId = newId(), snapshotHash = await sha256(jsonBytes(content));
    project.snapshots.push({id: snapshotId, content, contentHash: snapshotHash, createdAt: '2026-10-09T13:00:00.000Z', versionLabel: 'オフライン前の固定版'});
    scene.data.body = textToRichText('現在稿の別本文😀。固定版の代用にはしない。');
    scene.revision = (BigInt(scene.revision) + 1n).toString(); project.revision = (BigInt(project.revision) + 1n).toString();
    const inputBytes = await seed(page, project, f.assets, url);
    await page.evaluate(async () => { await navigator.serviceWorker.ready; });
    await page.reload();
    await expect.poll(() => page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
    const servedFiles = await page.evaluate(async descriptors => {
      const records = [];
      for (const descriptor of descriptors) {
        const path = '/shinariokanri/' + descriptor.file.slice('dist/'.length);
        const response = await fetch(path), bytes = await response.arrayBuffer();
        if (!response.ok) throw Error('missing production file ' + path);
        const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), value => value.toString(16).padStart(2, '0')).join('');
        records.push({path, bytes: bytes.byteLength, sha256: hash});
      }
      return records;
    }, candidate.distFiles as Array<{file: string; bytes: number; sha256: string}>);
    expect(servedFiles).toHaveLength(13);
    for (const item of candidate.distFiles) expect(servedFiles.find(row => row.path === '/shinariokanri/' + item.file.slice('dist/'.length))).toMatchObject({bytes: item.bytes, sha256: item.sha256});
    const cacheBefore = await cacheWorker(page, workerDescriptor.file);
    expect(cacheBefore.cacheNames).toContain(`shinariokanri:/shinariokanri/:${build.version}`);
    expect(cacheBefore.sha256).toBe(workerDescriptor.sha256);
    expect(cacheBefore.bytes).toBe(workerDescriptor.bytes);
    const oldDocumentNonce = await page.evaluate(() => (window as any).__independentN11DocumentNonce as string);
    await stopServer(); expect(server.listening).toBe(false);
    let connectionFailure = '';
    try { await fetch(url, {signal: AbortSignal.timeout(3000)}); } catch (error) { connectionFailure = String(error); }
    expect(connectionFailure).not.toBe('');
    await context.setOffline(true);
    await page.close();
    const cold = await context.newPage();
    await cold.goto(url);
    await expect(cold.locator('.app-shell')).toBeVisible();
    await expect(cold.locator('.topbar-status')).toContainText('OFFLINE');
    const nonce = await cold.evaluate(() => (window as any).__independentN11DocumentNonce as string);
    expect(typeof nonce).toBe('string'); expect(nonce).not.toBe(oldDocumentNonce);
    await expect.poll(() => cold.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
    await openRecord(cold, 'scene', scene.name);
    const advanced = cold.locator('details.advanced-details').filter({has: cold.getByText('詳細データ・ルビ・本文リンクを編集', {exact: true})});
    if (await advanced.getAttribute('open') === null) await advanced.locator('summary').click();
    const input = advanced.getByRole('textbox', {name: '詳細データ', exact: true}), unfinished = (await input.inputValue()).slice(0, -1);
    await input.fill(unfinished); await expect(cold.locator('.editor-save-state')).toContainText('未保存');
    await reader(cold);
    await cold.getByLabel('試読する作品版', {exact: true}).selectOption(snapshotId);
    await cold.getByLabel('試読の開始点', {exact: true}).selectOption(entry.id);
    await cold.getByLabel('試読開始時点の世界内tick', {exact: true}).fill('5');
    await expect.poll(() => cold.evaluate(async expected => {
      const db = await new Promise<IDBDatabase>((done, reject) => { const request = indexedDB.open('scenario-manager-local-v1'); request.onsuccess = () => done(request.result); request.onerror = () => reject(request.error); });
      try { return await new Promise<boolean>((done, reject) => { const request = db.transaction('workspaceInputs', 'readonly').objectStore('workspaceInputs').get('workspace'); request.onsuccess = () => done(Object.values(request.result?.value?.jsonBuffers ?? {}).some(group => Object.values(group as Record<string, string>).includes(expected))); request.onerror = () => reject(request.error); }); }
      finally { db.close(); }
    }, unfinished)).toBe(true);
    await cold.evaluate(() => window.scrollTo(0, 0)); await cold.waitForTimeout(300);
    const before = await nativeFingerprint(cold);
    await cold.getByRole('button', {name: '到達性と行き止まりを検査', exact: true}).click();
    const cancel = cold.getByRole('button', {name: '探索を中止', exact: true});
    await expect(cancel).toBeVisible({timeout: 2000}); await cold.waitForTimeout(2200); await expect(cancel).toBeEnabled();
    await cancel.click();
    await expect(cold.locator('.analysis-result-heading')).toContainText('探索打切り');
    const result = await analysisDownload(cold);
    expect(result).toMatchObject({status: 'unknown', truncated: true, contentVersionId: snapshotId, limits: {maxStates: 100000, maxTransitions: 10000, maxMs: 30000}});
    await nav(cold, /^資料/); await reader(cold);
    await expect(cold.getByLabel('試読する作品版', {exact: true})).toHaveValue(snapshotId);
    expect(await analysisDownload(cold)).toEqual(result);
    await openRecord(cold, 'scene', scene.name);
    const reopened = cold.locator('details.advanced-details').filter({has: cold.getByText('詳細データ・ルビ・本文リンクを編集', {exact: true})});
    if (await reopened.getAttribute('open') === null) await reopened.locator('summary').click();
    await expect(reopened.getByRole('textbox', {name: '詳細データ', exact: true})).toHaveValue(unfinished);
    await reader(cold); await cold.evaluate(() => window.scrollTo(0, 0)); await cold.waitForTimeout(300);
    const after = await nativeFingerprint(cold), cacheAfter = await cacheWorker(cold, workerDescriptor.file);
    await evidence(info, 'N11-real-worker-stopped-server', {build, servedFiles, oldDocumentNonce, coldDocumentNonce: nonce, actualServerStopped: true, NodeConnectionFailure: connectionFailure, cacheBefore, cacheAfter, inputArchiveSHA256: digest(inputBytes), fixedSnapshotId: snapshotId, fixedSnapshotHash: snapshotHash, result, nativeBefore: before, nativeAfter: after, originalInputResumed: true, scope: 'Linux production browser + actual stopped local server + emulated offline + real cached module Worker. Small fixture only; physical airplane mode, Large, duration and actual Auth remain separate.'});
    expect(after).toEqual(before); expect(cacheAfter).toEqual(cacheBefore);
    const complete = await backup(cold);
    expect(complete.parsed.project.snapshots.find(snapshot => snapshot.id === snapshotId)?.contentHash).toBe(snapshotHash);
    expect(complete.parsed.assets.find(asset => asset.contentHash === f.attachment.data.contentHash)?.bytes).toEqual(f.assets[f.attachment.data.contentHash]);
    expect(complete.parsed.recovery?.pending.length).toBeGreaterThan(0);
    await evidence(info, 'N11-worker-complete-offline', {archiveSHA256: digest(complete.bytes), archiveBytes: complete.bytes.byteLength, actualKnownAssetBytes: f.assets[f.attachment.data.contentHash].byteLength, pendingCount: complete.parsed.recovery?.pending.length, wholeOriginalCasePassInferred: false});
  } finally { await context.setOffline(false); await stopServer(); }
});

async function analysisDownload(page: Page) {
  const pending = page.waitForEvent('download');
  await page.getByRole('button', {name: '検査結果を保存', exact: true}).click();
  const file = await pending; expect(await file.failure()).toBeNull();
  const bytes = new Uint8Array(await readFile((await file.path())!));
  await captureProofFile(bytes, 'N11-worker-analysis-result', 'json');
  return JSON.parse(Buffer.from(bytes).toString('utf8'));
}
async function cacheWorker(page: Page, file: string) {
  return page.evaluate(async file => {
    const path = '/shinariokanri/' + file.slice('dist/'.length), cacheNames = (await caches.keys()).sort();
    for (const name of cacheNames) {
      const response = await (await caches.open(name)).match(path);
      if (!response) continue;
      const bytes = await response.arrayBuffer(), sha256 = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), value => value.toString(16).padStart(2, '0')).join('');
      return {cacheNames, path, bytes: bytes.byteLength, sha256};
    }
    throw Error('actual analysis Worker not cached');
  }, file);
}

async function nativeFingerprint(page: Page) {
  return page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((done, reject) => { const request = indexedDB.open('scenario-manager-local-v1'); request.onsuccess = () => done(request.result); request.onerror = () => reject(request.error); });
    try {
      const names = Array.from(db.objectStoreNames).sort();
      const rows = await new Promise<Record<string, unknown[]>>((done, reject) => { const transaction = db.transaction(names, 'readonly'), all: Record<string, unknown[]> = {}; for (const name of names) { const request = transaction.objectStore(name).getAll(); request.onsuccess = () => { all[name] = request.result; }; } transaction.oncomplete = () => done(all); transaction.onabort = () => reject(transaction.error); transaction.onerror = () => reject(transaction.error); });
      const hash = async (bytes: Uint8Array) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes as BufferSource)), value => value.toString(16).padStart(2, '0')).join('');
      const encoder = new TextEncoder();
      async function normalize(value: unknown): Promise<unknown> {
        if (value instanceof ArrayBuffer) return {binaryType: 'ArrayBuffer', bytes: value.byteLength, sha256: await hash(new Uint8Array(value))};
        if (ArrayBuffer.isView(value)) return {binaryType: value.constructor.name, bytes: value.byteLength, sha256: await hash(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))};
        if (Array.isArray(value)) { const result: unknown[] = []; for (const item of value) result.push(await normalize(item)); return result; }
        if (value && typeof value === 'object') { const result: Record<string, unknown> = {}; for (const key of Object.keys(value).sort()) result[key] = await normalize((value as Record<string, unknown>)[key]); return result; }
        return value;
      }
      const result: Record<string, {count: number; sha256: string}> = {};
      for (const name of names) { const hashes: string[] = []; for (const row of rows[name]) hashes.push(await hash(encoder.encode(JSON.stringify(await normalize(row))))); result[name] = {count: rows[name].length, sha256: await hash(encoder.encode(JSON.stringify(hashes)))}; }
      return result;
    } finally { db.close(); }
  });
}
