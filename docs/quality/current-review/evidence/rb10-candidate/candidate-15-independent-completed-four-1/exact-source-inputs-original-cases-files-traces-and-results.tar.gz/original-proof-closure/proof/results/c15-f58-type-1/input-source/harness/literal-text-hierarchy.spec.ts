import {test,expect} from '@playwright/test';
import {createEntity,createProject,newId,textToRichText} from '../candidate/src/domain/model';
import type {Entity,EntityKind,EntityDataMap,ProjectData} from '../candidate/src/domain/types';
import {createWorldSnapshot} from '../candidate/src/domain/world';
import {nav,seed,backup,durable,digest,evidence} from './common';
import {openRecord,editData,saveEditor,freshRoundtrip} from './extended-support';

function add<K extends EntityKind>(p:ProjectData,kind:K,name:string,data:Partial<EntityDataMap[K]>={}):Entity<K>{const e=createEntity(p.projectId,kind,name,data);e.status='confirmed';p.entities.push(e);return e;}

test('AT-B10/F27 literal two Aoi persons, common noun and alias: choose exact ID/Unicode range, exclude suggestions without automatic replacement, reverse links, cold and fullfile',async({page,browser},info)=>{
  test.setTimeout(240000);let p=createProject('原B10/F27 二人の葵と一般語');
  const first=add(p,'character','葵',{reading:'あおい',summary:textToRichText('門番の葵'),aliases:[{id:newId(),text:'青い子',reading:'あおいこ',validity:{worldRange:null,routeCondition:null,presentationAnchor:null},audienceHolderIds:[],isPublicDefault:false}]});
  const second=add(p,'character','葵',{reading:'あおい',summary:textToRichText('旅人の葵')});
  const body=textToRichText('😀葵が葵の花を持ち、青い子と会う。'),scene=add(p,'scene','葵と普通の葵を選び分ける本文',{body});
  p=await createWorldSnapshot(p,'リンク前の固定版');const oldPin=p.snapshots.at(-1)!;const input=await seed(page,p);
  await openRecord(page,'scene',scene.name);await page.getByRole('tab',{name:'本文',exact:true}).click();
  const annotations=page.getByRole('region',{name:'本文のルビとリンク',exact:true}),candidates=annotations.getByLabel('本文に見つかった候補',{exact:true});
  const options=await candidates.locator('option').evaluateAll(nodes=>nodes.map(node=>({value:(node as HTMLOptionElement).value,label:node.textContent??''})));
  const aoi=options.filter(o=>o.label.includes('「葵」'));expect(aoi.length).toBeGreaterThanOrEqual(4);expect(aoi.some(o=>o.label.includes(first.id.slice(-6)))).toBe(true);expect(aoi.some(o=>o.label.includes(second.id.slice(-6)))).toBe(true);
  const unlinked=await backup(page);const unlinkedScene=unlinked.parsed.project.entities.find((e):e is Entity<'scene'>=>e.id===scene.id&&e.kind==='scene')!;expect(unlinkedScene.data.body[0].links??[]).toEqual([]);await openRecord(page,'scene',scene.name);await page.getByRole('tab',{name:'本文',exact:true}).click();
  const firstName=aoi.find(o=>o.label.includes(first.id.slice(-6))&&o.label.includes('2〜2文字目'))!;expect(firstName).toBeTruthy();await candidates.selectOption(firstName.value);await annotations.getByRole('button',{name:'リンクを付ける',exact:true}).click();await saveEditor(page);
  const aliasOptions=await candidates.locator('option').evaluateAll(nodes=>nodes.map(node=>({value:(node as HTMLOptionElement).value,label:node.textContent??''})));const alias=aliasOptions.find(o=>o.label.includes('「青い子」'))!;expect(alias).toBeTruthy();await candidates.selectOption(alias.value);await annotations.getByRole('button',{name:'リンクを付ける',exact:true}).click();await saveEditor(page);
  // An exclusion is an authored target/term preference. It does not add or
  // retarget links; the already selected first-name link remains explicit.
  for(const person of [first,second]){
    const opts=await candidates.locator('option').evaluateAll(nodes=>nodes.map(node=>({value:(node as HTMLOptionElement).value,label:node.textContent??''})));const common=opts.find(o=>o.label.includes(person.id.slice(-6))&&o.label.includes('「葵」')&&o.label.includes('4〜4文字目'))!;expect(common).toBeTruthy();await candidates.selectOption(common.value);await annotations.getByRole('button',{name:'この語句とリンク先の候補を表示しない',exact:true}).click();
  }
  const linked=await backup(page),savedScene=linked.parsed.project.entities.find((e):e is Entity<'scene'>=>e.id===scene.id&&e.kind==='scene')!;
  expect(savedScene.data.body[0].id).toBe(body[0].id);expect(savedScene.data.body[0].text).toBe(body[0].text);expect(savedScene.data.body[0].links?.map(l=>({start:l.start,end:l.end,entityId:l.target.entityId}))).toEqual([{start:1,end:2,entityId:first.id},{start:10,end:13,entityId:first.id}]);
  expect(linked.parsed.project.snapshots.find(s=>s.id===oldPin.id)).toEqual(oldPin);await openRecord(page,'scene',scene.name);await page.getByRole('tab',{name:'本文',exact:true}).click();
  await annotations.getByRole('button',{name:/参照元/}).first().click();await expect(page.getByRole('dialog')).toContainText(scene.name);await page.getByRole('dialog').getByRole('button',{name:/閉じる/}).first().click();
  await page.reload();await openRecord(page,'scene',scene.name);await page.getByRole('tab',{name:'本文',exact:true}).click();const after=page.getByRole('region',{name:'本文のルビとリンク',exact:true});
  const coldCandidates=await after.getByLabel('本文に見つかった候補',{exact:true}).locator('option').allTextContents();expect(coldCandidates.some(t=>t.includes('「葵」'))).toBe(false);expect(coldCandidates.some(t=>t.includes('「青い子」'))).toBe(true);
  const cold=await backup(page),fresh=await freshRoundtrip(browser,cold.bytes),clone=await freshRoundtrip(browser,cold.bytes,'clone');expect(fresh.parsed.project).toEqual(cold.parsed.project);expect(clone.parsed.project.entities.filter(e=>e.kind==='character')).toHaveLength(2);
  await evidence(info,'B10-F27-literal-name-candidates',{given:{sameName:'葵',personIDs:[first.id,second.id],commonNoun:'葵の花',alias:'青い子'},when:{candidateLabels:options,selectedTarget:first.id,explicitUnicodeLinks:savedScene.data.body[0].links,sourceBlockID:body[0].id,ignoredBothTargetTerms:true,reverseReferenceDialog:true,reCandidateAfterCold:coldCandidates},then:{noLinkBeforeChoice:true,noCommonNounLink:true,noAutomaticTextReplacement:true,oldPinUnchanged:true},negative:{sameNamesDisambiguatedByID:true,coldExclusionsPreservedOnSameAccountDevice:true,generalWordUnlinked:true},fileSHA256:digest(cold.bytes),fixtureSHA256:digest(input),newAndClonePreserveAuthoredLinks:true,preferencePortability:'Ignore preferences are local account/device preferences; no complete-file restoration of them is claimed',fullCasesClaimed:[]});
});

test('AT-F13 literal chapter→scene→dialogue hierarchy: one unresolved child exit and unknown condition remain in collapsed upper counts, ordinary reconnect, cold/new',async({page,browser},info)=>{
  test.setTimeout(240000);const p=createProject('原F13 下位会話の出口と条件');
  const unknown=add(p,'variable','会話入口の未入力条件',{key:'dialogue_gate',valueType:'boolean',scope:'run',initial:{type:'unknown',value:null,reason:'作者が未定'},allowed:{values:[false,true]}});
  const scene=add(p,'scene','原F13上位場面',{body:textToRichText('共通の会話を呼び出す。')}),conversation=add(p,'scene','原F13会話の場面',{body:textToRichText('下位の会話。')});
  const line=add(p,'dialogue_line','原F13会話の一台詞',{text:textToRichText('出口を後からつなぐ。')});conversation.data.dialogueLineIds=[line.id];
  const chapter=add(p,'chapter','原F13上位章',{sceneIds:[scene.id,conversation.id]});scene.data.chapterId=chapter.id;conversation.data.chapterId=chapter.id;
  const entry=add(p,'flow_node','原F13上位入口',{nodeType:'entry',sceneId:scene.id}),call=add(p,'flow_node','原F13会話呼出し',{nodeType:'call',sceneId:scene.id}),end=add(p,'flow_node','原F13上位終端',{nodeType:'terminal',terminalReason:'上位の意図終端',sceneId:scene.id});
  const childEntry=add(p,'flow_node','原F13会話入口',{nodeType:'entry',sceneId:conversation.id,gate:{op:'compare',variableId:unknown.id,comparator:'eq',value:{type:'boolean',value:true}}}),childExit=add(p,'flow_node','原F13会話出口',{nodeType:'exit',sceneId:conversation.id});
  const link=add(p,'flow_edge','原F13上位から会話へ',{fromId:entry.id,toId:call.id,label:'会話へ'}),unfinished=add(p,'flow_edge','原F13未接続出口',{fromId:childEntry.id,toId:{unresolved:{label:'下位出口',reason:'作者がまだ接続していない'}},label:'未接続の出口'});
  const root=add(p,'flow_graph','原F13章の図',{nodeIds:[entry.id,call.id,end.id],edgeIds:[link.id],entryIds:[entry.id],exitIds:[end.id]});const child=add(p,'flow_graph','原F13会話の下位図',{nodeIds:[childEntry.id,childExit.id],edgeIds:[unfinished.id],entryIds:[childEntry.id],exitIds:[childExit.id],parentGraphId:root.id});call.data.childGraphId=child.id;call.data.fallbackId=end.id;
  const input=await seed(page,p);await nav(page,/^構成/);await page.getByRole('tab',{name:'分岐',exact:true}).click();const hierarchy=page.getByRole('region',{name:'章・場面・会話と分岐の階層図',exact:true});
  const upper=hierarchy.locator('ol.flow-hierarchy-level').first().locator(':scope > li').filter({has:page.getByRole('button',{name:'章 · '+chapter.name,exact:true})});
  await expect(upper.locator(':scope > div > span')).toContainText('未完成 1');await expect(upper.locator(':scope > div > span')).toContainText('未確認条件 1');await expect(upper.getByRole('button',{name:chapter.name+'を掘り下げる',exact:true})).toHaveAttribute('aria-expanded','false');
  await upper.getByRole('button',{name:chapter.name+'を掘り下げる',exact:true}).click();await upper.getByRole('button',{name:conversation.name+'を掘り下げる',exact:true}).click();await expect(upper).toContainText(line.name);await expect(upper).toContainText('接続の出口が未完成です');
  await openRecord(page,'flow_edge',unfinished.name);await editData(page,d=>{d.toId=childExit.id;});await saveEditor(page);await openRecord(page,'flow_node',childEntry.name);const beforeInvalid=await durable(page);const raw=await editData(page,d=>{d.gate={op:'unknown-unsafe-operator'};});const invalidRaw=await raw.inputValue();await expect(page.locator('.detail-panel').getByRole('alert')).toContainText(/条件|op|演算/);expect(await durable(page)).toEqual(beforeInvalid);await expect(raw).toHaveValue(invalidRaw);
  await editData(page,d=>{d.gate={op:'constant',value:true};});await saveEditor(page);await nav(page,/^構成/);await page.getByRole('tab',{name:'分岐',exact:true}).click();
  const fixedUpper=page.getByRole('region',{name:'章・場面・会話と分岐の階層図',exact:true}).locator('ol.flow-hierarchy-level').first().locator(':scope > li').filter({has:page.getByRole('button',{name:'章 · '+chapter.name,exact:true})});await expect(fixedUpper.locator(':scope > div > span')).toContainText('未完成 0');await expect(fixedUpper.locator(':scope > div > span')).toContainText('未確認条件 0');
  await page.reload();const cold=await backup(page),fresh=await freshRoundtrip(browser,cold.bytes);expect(fresh.parsed.project).toEqual(cold.parsed.project);expect(cold.parsed.project.entities.find(e=>e.id===unfinished.id)?.data).toMatchObject({toId:childExit.id});
  await evidence(info,'F13-literal-upper-child-counts',{given:{chapter:chapter.id,scenes:[scene.id,conversation.id],line:line.id,rootGraph:root.id,childGraph:child.id,oneUnresolvedChildExit:unfinished.id},when:{upperCollapsedUnfinished:1,upperUnknownCondition:1,descendedToDialogue:true,normalReconnectedChildExit:childExit.id},then:{afterUnfinished:0,afterUnknown:0,coldAndEmpty:true},negative:{invalidConditionInputHeld:true,invalidConditionNativeUnchanged:true,errorsNotCommitted:true,unknownNotSilentlyPassed:true},fixtureSHA256:digest(input),fileSHA256:digest(cold.bytes),fullCasesClaimed:[]});
});
