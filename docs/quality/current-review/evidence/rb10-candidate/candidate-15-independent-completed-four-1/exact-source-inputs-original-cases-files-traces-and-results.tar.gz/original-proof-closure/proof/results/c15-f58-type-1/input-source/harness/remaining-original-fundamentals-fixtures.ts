import {createEntity,createProject,emptyValidity,validateProject} from '../candidate/src/domain/model';
import {createWorldSnapshot} from '../candidate/src/domain/world';
import type {Entity,EntityKind,ProjectData} from '../candidate/src/domain/types';
import {ids,fixedTime} from './fixtures';

// Given-only fixture. Every when below is an ordinary App operation. These IDs
// and texts are independent inputs, not values inferred from product results.
function record<K extends EntityKind>(p:ProjectData,n:number,kind:K,name:string,data:Partial<Entity<K>['data']>={}):Entity<K>{
 const e=createEntity(p.projectId,kind,name,data);return {...e,id:ids(n),status:'confirmed',createdAt:fixedTime,updatedAt:fixedTime} as Entity<K>;
}
const body=(n:number,text:string)=>[{id:ids(n),kind:'paragraph' as const,text}];
export async function originalFundamentalsFixture(){
 let p={...createProject('原基礎 年表・筋・人物変化'),projectId:ids(4000)};
 p.mainStart='-10';
 const a=record(p,4001,'character','原基礎 人物A'),b=record(p,4002,'character','原基礎 人物B');
 const g1=record(p,4003,'group','原B03 グループ一',{groupType:'display',members:[a.id,b.id]}),g2=record(p,4004,'group','原B03 グループ二',{groupType:'display',members:[a.id]});
 const common=record(p,4005,'event','原B02 共通出来事',{summary:body(4006,'全員の参加や知識を作らない共通表示😀'),laneRole:'common',time:{mode:'instant',calendarId:p.calendarId,at:'0'}});
 const both=record(p,4007,'event','原B02 二人の出来事',{summary:body(4008,'二人の同一出来事ID'),laneRole:'both',time:{mode:'instant',calendarId:p.calendarId,at:'10'},participants:[{characterId:a.id,role:'actor'},{characterId:b.id,role:'witness'}]});
 const unset=record(p,4009,'event','原B08 参加者未設定',{summary:body(4010,'役割を混同しない'),laneRole:'both',time:{mode:'instant',calendarId:p.calendarId,at:'20'}});
 const place=record(p,4011,'place','原B11 場所'),type=record(p,4012,'item','原B11 鍵の種類',{itemMode:'type'}),instance=record(p,4013,'item','原B11 鍵の個体',{itemMode:'instance',typeId:type.id});
 const romance=record(p,4014,'group','原F03 恋愛',{groupType:'plot_thread'}),war=record(p,4015,'group','原F03 戦争',{groupType:'plot_thread'});
 const scene=record(p,4016,'scene','原F03 場面S',{body:body(4017,'同じ場面の本文😀'),threadIds:[romance.id,war.id],povId:a.id,eventIds:[both.id]});
 const t=record(p,4018,'scene','原F04 役割未入力T',{body:body(4019,'役割が空でも保存する場面')});
 const chapter=record(p,4020,'chapter','原基礎 第一章',{sceneIds:[scene.id,t.id]});scene.data.chapterId=chapter.id;t.data.chapterId=chapter.id;
 const goal=record(p,4021,'goal','原B20 人物Aの変化する目的',{ownerId:a.id,description:body(4022,'鍵を得る目的から仲間を守る目的へ変わる'),evidenceSceneIds:[]});a.data.goals=[goal.id];
 const variable=record(p,4023,'variable','原B22 クエストだけの状態',{key:'original_quest_state',valueType:'enum',scope:'run',initial:{type:'enum',value:'未完了'},allowed:{values:['未完了','完了']}});
 const quest=record(p,4024,'quest','原B22 クエスト',{key:'original_quest',stateVariableId:variable.id,description:body(4025,'鍵を得るクエスト')});
 const lore=record(p,4026,'lore','原B22 設定',{body:body(4027,'鍵は門を開く設定')});
 const line=record(p,4028,'dialogue_line','原B22 会話',{speakerId:a.id,text:body(4029,'😀鍵と門について話す')});scene.data.dialogueLineIds=[line.id];
 p.entities.push(a,b,g1,g2,common,both,unset,place,type,instance,romance,war,scene,t,chapter,goal,variable,quest,lore,line);
 const valid=validateProject(p);if(!valid.ok)throw new Error(JSON.stringify(valid.issues));
 p=await createWorldSnapshot(p,'基礎操作前の固定版');
 return {p,a,b,g1,g2,common,both,unset,place,type,instance,romance,war,scene,t,chapter,goal,variable,quest,lore,line,pin:p.snapshots.at(-1)!};
}

export function wrongRelationFixture(p:ProjectData,fromId:string,toId:string){
 const copy=structuredClone(p);copy.relations.push({id:ids(4090),projectId:copy.projectId,revision:'0',fromId,toId,relationType:'trust',direction:'forward',validity:emptyValidity(),evidenceIds:[],status:'confirmed',visibility:'private'});
 return copy;
}
