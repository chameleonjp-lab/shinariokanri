import {test,expect} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {appURL,digest,evidence} from './common';
import {openRecord,reader} from './extended-support';

// Supplemental responsiveness observation only. Input is the exact byte-sealed
// original Large/long-branch archive from failed run1, with no cap changes.
test('AT-N05 exact Large input: native pointer cancellation and RAF/timer responsiveness',async({page},info)=>{
 test.setTimeout(900_000);
 const descriptor=JSON.parse(await readFile('prepared/N05_LARGE_HEARTBEAT_INPUT.json','utf8'));
 const bytes=await readFile(descriptor.archive);expect(digest(bytes)).toBe(descriptor.sha256);
 const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
 await page.goto(appURL);await page.getByRole('button',{name:'保存ファイルを読み込む',exact:true}).click();await page.locator('input[type=file]').setInputFiles({name:'original-N05-large.scenario',mimeType:'application/zip',buffer:bytes});
 await expect(page.getByRole('heading',{name:/^検査済みの作品/})).toBeVisible({timeout:600_000});await page.getByLabel('復元方法と対象への影響を確認しました').check();await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect(page.locator('.app-shell')).toBeVisible({timeout:600_000});
 await openRecord(page,'scene',descriptor.sceneName);const advanced=page.locator('details.advanced-details').filter({has:page.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true})});if(await advanced.getAttribute('open')===null)await advanced.locator('summary').click();const input=advanced.getByRole('textbox',{name:'詳細データ',exact:true}),unfinished=(await input.inputValue()).slice(0,-1);await input.fill(unfinished);await expect(page.locator('.editor-save-state')).toContainText('未保存');
 await reader(page);await page.getByLabel('試読の開始点',{exact:true}).selectOption('');
 const analyze=page.getByRole('button',{name:'到達性と行き止まりを検査',exact:true});await analyze.scrollIntoViewIfNeeded();const box=await analyze.boundingBox();expect(box).not.toBeNull();
 await page.evaluate(()=>new Promise<void>(done=>requestAnimationFrame(()=>done())));
 await page.evaluate(()=>{
  const state={started:performance.now(),stopped:false,frames:[] as Array<{at:number;gap:number;cancel:boolean;progress:string|null}>,timers:[] as Array<{at:number;gap:number;cancel:boolean}>,events:[] as Array<{type:string;at:number;target:string}>,longTasks:[] as Array<{at:number;duration:number}>};
  (window as unknown as {__independentN05:typeof state}).__independentN05=state;
  const cancel=()=>Array.from(document.querySelectorAll('button')).some(button=>button.textContent==='探索を中止');let frameBefore=performance.now(),timerBefore=frameBefore;
  const raf=()=>{const at=performance.now();state.frames.push({at,gap:at-frameBefore,cancel:cancel(),progress:Array.from(document.querySelectorAll('[role="status"]')).find(el=>el.textContent?.includes('状態を確認中'))?.textContent??null});frameBefore=at;if(!state.stopped)requestAnimationFrame(raf);};requestAnimationFrame(raf);
  const timer=setInterval(()=>{const at=performance.now();state.timers.push({at,gap:at-timerBefore,cancel:cancel()});timerBefore=at;if(state.stopped)clearInterval(timer);},50);
  for(const type of ['pointerdown','pointerup','click'])document.addEventListener(type,event=>{const target=(event.target as Element|null)?.closest('button')?.textContent??'';state.events.push({type,at:performance.now(),target});},true);
  const observer=new PerformanceObserver(list=>{for(const entry of list.getEntries())state.longTasks.push({at:entry.startTime,duration:entry.duration});});observer.observe({entryTypes:['longtask']});
 });
 const nodeStarted=Date.now();await page.mouse.move(box!.x+box!.width/2,box!.y+box!.height/2);await page.mouse.down();
 const release=page.mouse.up();const nodeReleased=Date.now();await new Promise(done=>setTimeout(done,2200));const nodeCancelQueued=Date.now();const cancelPointer=page.mouse.click(box!.x+box!.width/2,box!.y+box!.height/2);
 const pointerResults=await Promise.allSettled([release,cancelPointer]);const nodePointerFinished=Date.now();
 await expect(page.locator('.analysis-result-heading')).toContainText('探索打切り',{timeout:80_000});
 const observation=await page.evaluate(()=>{const state=(window as unknown as {__independentN05:{stopped:boolean}}).__independentN05;state.stopped=true;return state;});
 await page.screenshot({path:info.outputPath('after-native-pointer.png'),fullPage:true});
 const text=await page.locator('.analysis-result-heading').innerText();
 await evidence(info,'N05-Large-native-pointer-heartbeat',{descriptor,errors,nodeStarted,nodeReleased,nodeCancelQueued,nodePointerFinished,pointerResults:pointerResults.map(result=>({status:result.status,reason:result.status==='rejected'?String(result.reason):null})),observation,text,scope:'supplemental normal production App native pointer + RAF/timer; no original full-case pass; native all-tables equality remains unobserved in this diagnostic',performance:'single responsiveness diagnostic only; not formal30',physical:'not_run',actualAuth:'not_run'});
 const actual=observation as unknown as {started:number;events:Array<{type:string;at:number;target:string}>;frames:Array<{at:number;gap:number;cancel:boolean}>};
 const firstClick=actual.events.find(event=>event.type==='click'&&event.target==='到達性と行き止まりを検査');const firstCancel=actual.frames.find(frame=>frame.cancel&&frame.at>(firstClick?.at??Infinity));
 expect(firstClick).toBeDefined();expect(firstCancel,'Progress and cancellation must be rendered within the original 2-second long-operation boundary').toBeDefined();expect(firstCancel!.at-firstClick!.at).toBeLessThanOrEqual(2000);
});
