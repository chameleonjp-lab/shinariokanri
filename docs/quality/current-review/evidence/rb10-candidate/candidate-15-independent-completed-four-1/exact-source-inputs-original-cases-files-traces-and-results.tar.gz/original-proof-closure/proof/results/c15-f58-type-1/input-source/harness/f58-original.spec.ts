import {test,expect,type Page} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {inspectScenario} from '../candidate/src/storage/archive';
import {createEntity,createProject,textToRichText,validateProject} from '../candidate/src/domain/model';
import {evaluateCollection} from '../candidate/src/domain/catalog';
import type {ProjectData,Entity,EntityKind} from '../candidate/src/domain/types';
import {importBytes,nav,backup,durable,evidence,digest,injectQuota} from './common';
import {editData,saveEditor,freshRoundtrip} from './extended-support';

async function catalog(page:Page){await nav(page,/^検索/);await expect(page.locator('.search-page')).toBeVisible();}
async function closeDetail(page:Page){const close=page.locator('.detail-panel').getByRole('button',{name:'詳細を閉じる',exact:true});if(await close.isVisible())await close.click();}
async function add(page:Page,kind:EntityKind,name:string){
 await nav(page,/^資料/);await page.getByLabel('情報の種類',{exact:true}).selectOption(kind);
 await page.locator('.workspace-heading').getByRole('button',{name:/を追加$/}).click();
 const modal=page.getByRole('dialog',{name:'情報を追加',exact:true});await modal.getByLabel('名前',{exact:true}).fill(name);await modal.getByRole('button',{name:'編集を始める',exact:true}).click();
 await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
}
async function list(page:Page,name:string,count:number){
 await catalog(page);await page.getByLabel('保存した一覧を再表示',{exact:true}).selectOption({label:name});
 await expect(page.locator('.search-page .list-heading')).toContainText(count+'件');
}
async function fixture(){
 const input=new Uint8Array(await readFile(new URL('../regression-inputs/F58-original-fixed-input.scenario',import.meta.url)));expect(digest(input)).toBe('717eb244aa5173d61d277dfe3a1b1b09bfbf2ba85c3ceddc5a14e76e99429ad5');
 const p=(await inspectScenario(input,{worker:false})).project;
 const a=p.entities.find(e=>e.kind==='character'&&e.name==='人物A')!,ea=p.entities.find(e=>e.kind==='event'&&e.name==='人物Aが出る出来事')!,first=p.entities.find(e=>e.kind==='scene'&&e.name==='Aの未実装場面')!,done=p.entities.find(e=>e.kind==='scene'&&e.name==='Aの実装済み場面')!,other=p.entities.find(e=>e.kind==='scene'&&e.name==='Bの未実装場面')!;
 expect(validateProject(p).ok).toBe(true);return {p,a,ea,first,done,other,input};
}
function collections(p:ProjectData){return p.entities.filter((e):e is Entity<'collection'>=>e.kind==='collection'&&!e.deletedAt);}
function assertCollections(p:ProjectData,firstName:string,newName:string){
 const dynamic=collections(p).find(e=>e.name==='人物Aかつ未実装・動的')!,fixed=collections(p).find(e=>e.name==='人物Aかつ未実装・固定')!;
 expect(dynamic.data.mode).toBe('dynamic');expect(dynamic.data.memberIds??[]).toEqual([]);expect(dynamic.data.query).toMatchObject({op:'all',children:expect.arrayContaining([{op:'kind',value:'scene'},{op:'participant',characterId:p.entities.find(e=>e.kind==='character'&&e.name==='人物A')!.id},{op:'production',value:'todo'}])});
 expect(fixed.data.mode).toBe('fixed');expect(fixed.data.query).toBeNull();
 expect(evaluateCollection(p,dynamic).entities.map(e=>e.name).sort()).toEqual([firstName,newName].sort());
 expect(evaluateCollection(p,fixed).entities.map(e=>e.name)).toEqual([firstName]);return {dynamic,fixed};
}

test('原 AT-F58 same fixed input: cards/table/diagram/timeline→ordinary source editing and return→atomic bulk cancel/failure/undo→cold/new/clone',async({page,browser},info)=>{
 const f=await fixture();const input=f.input;await importBytes(page,input);await closeDetail(page);await catalog(page);
 await page.locator('.search-page .kind-select').selectOption('scene');await page.getByLabel('参加人物で絞り込む',{exact:true}).selectOption(f.a.id);await page.getByLabel('制作進捗で絞り込む',{exact:true}).selectOption('todo');
 await expect(page.locator('.search-page .list-heading')).toContainText('1件');await expect(page.locator('.search-page .entity-card')).toContainText(f.first.name);
 await page.getByLabel('一覧の名前',{exact:true}).fill('人物Aかつ未実装・動的');await page.getByLabel('保存する内容',{exact:true}).selectOption('dynamic');await page.getByRole('button',{name:'一覧を保存',exact:true}).click();await expect(page.locator('.search-page [role=status]').first()).toContainText('一覧を保存しました');
 await page.getByLabel('一覧の名前',{exact:true}).fill('人物Aかつ未実装・固定');await page.getByLabel('保存する内容',{exact:true}).selectOption('fixed');await page.getByRole('button',{name:'一覧を保存',exact:true}).click();await expect(page.locator('.search-page [role=status]').first()).toContainText('一覧を保存しました');
 const initial=await backup(page);expect(collections(initial.parsed.project)).toHaveLength(2);
 await add(page,'scene','新しいAの未実装場面');await editData(page,data=>{data.eventIds=[f.ea.id];data.body=textToRichText('追加しても動的一覧だけが追従する😀。');});await saveEditor(page);await closeDetail(page);
 const afterScene=await backup(page),added=afterScene.parsed.project.entities.find(e=>e.kind==='scene'&&e.name==='新しいAの未実装場面')!;expect(added).toBeTruthy();
 await add(page,'production_task','新しいAの実装タスク');await editData(page,data=>{data.targetIds=[added.id];data.stage='implementation';data.progress='todo';});await saveEditor(page);await closeDetail(page);
 const afterAdd=await backup(page);const c=assertCollections(afterAdd.parsed.project,f.first.name,added.name);
 await list(page,c.fixed.name,1);await expect(page.locator('.search-page .entity-card')).toHaveCount(1);
 await list(page,c.dynamic.name,2);await expect(page.locator('.search-page .entity-card')).toHaveCount(2);
 const beforeViews=await durable(page),view=page.locator('.filter-pills[aria-label="検索結果の表示"]');
 await view.getByRole('button',{name:'表',exact:true}).click();await expect(page.getByRole('table',{name:'同じ検索結果の一覧'}).locator('tbody tr')).toHaveCount(2);
 await view.getByRole('button',{name:'カード',exact:true}).click();await expect(page.locator('.search-page .entity-card')).toHaveCount(2);expect(await durable(page)).toEqual(beforeViews);
 await view.getByRole('button',{name:'図',exact:true}).click();const diagram=page.getByRole('region',{name:'同じ検索結果の図',exact:true});await expect(diagram.locator('g[data-entity-id]')).toHaveCount(2);expect((await diagram.locator('g[data-entity-id]').evaluateAll(nodes=>nodes.map(node=>node.getAttribute('data-entity-id')))).sort()).toEqual([f.first.id,added.id].sort());
 await view.getByRole('button',{name:'年表',exact:true}).click();const timeline=page.getByRole('region',{name:'同じ検索結果の年表',exact:true});await expect(timeline.locator('li[data-entity-id]')).toHaveCount(2);expect((await timeline.locator('li[data-entity-id]').evaluateAll(nodes=>nodes.map(node=>node.getAttribute('data-entity-id')))).sort()).toEqual([f.first.id,added.id].sort());await expect(timeline).toContainText('日時未確認');expect(await durable(page)).toEqual(beforeViews);
 await view.getByRole('button',{name:'図',exact:true}).click();await diagram.locator(`g[data-entity-id="${f.first.id}"]`).focus();await page.keyboard.press('Enter');await expect(page.locator('#entity-name')).toHaveValue(f.first.name);await page.getByRole('tab',{name:'本文',exact:true}).click();const body=page.getByRole('textbox',{name:'本文',exact:true});await body.focus();await body.press('End');await page.keyboard.insertText('図から同じ本文へ追記😀');await saveEditor(page);await closeDetail(page);await expect(view.getByRole('button',{name:'図',exact:true})).toHaveAttribute('aria-pressed','true');
 await view.getByRole('button',{name:'年表',exact:true}).click();await timeline.locator(`li[data-entity-id="${f.first.id}"]`).getByRole('button',{name:'日時の元情報を開く',exact:true}).click();await expect(page.locator('#entity-name')).toHaveValue(f.ea.name);await editData(page,data=>{data.time={mode:'instant',at:'10',calendarId:f.p.calendarId};});await saveEditor(page);await closeDetail(page);await expect(view.getByRole('button',{name:'年表',exact:true})).toHaveAttribute('aria-pressed','true');await expect(timeline).not.toContainText('日時未確認');
 const afterViewEdit=await backup(page),editedFirst=afterViewEdit.parsed.project.entities.find(e=>e.id===f.first.id)!;expect(editedFirst.kind).toBe('scene');if(editedFirst.kind==='scene'){expect(editedFirst.data.body[0].id).toBe((f.first.data as Entity<'scene'>['data']).body[0].id);expect(editedFirst.data.body[0].text).toContain('図から同じ本文へ追記😀');}assertCollections(afterViewEdit.parsed.project,f.first.name,added.name);await list(page,c.dynamic.name,2);

 const beforeCancel=await durable(page);await page.getByText('結果をまとめて編集',{exact:true}).click();await page.getByRole('button',{name:'結果をすべて選択',exact:true}).click();await page.getByLabel('まとめて設定する状態',{exact:true}).selectOption('needs_review');await page.getByRole('button',{name:'変更差分を確認',exact:true}).click();
 let modal=page.getByRole('dialog',{name:'変更差分の確認',exact:true});await expect(modal).toContainText(f.first.name);await expect(modal).toContainText(added.name);await expect(modal).toContainText('下書き → 確認待ち');await modal.getByRole('button',{name:'中止',exact:true}).click();expect(await durable(page)).toEqual(beforeCancel);
 await page.getByRole('button',{name:'変更差分を確認',exact:true}).click();modal=page.getByRole('dialog',{name:'変更差分の確認',exact:true});const beforeFailure=await durable(page);await injectQuota(page,'原F58 一部書込失敗の原子拒否');await modal.getByRole('button',{name:'差分を確定して保存',exact:true}).click();await expect(page.locator('.search-page').getByRole('alert')).toBeVisible();expect(await durable(page)).toEqual(beforeFailure);await expect(modal).toBeVisible();
 const failureText=await page.locator('.search-page').getByRole('alert').innerText();await modal.getByRole('button',{name:'差分を確定して保存',exact:true}).click();await expect(modal).toHaveCount(0);await expect(page.locator('.search-page [role=status]').first()).toContainText('一括変更を保存しました');
 const bulk=await backup(page);for(const id of [f.first.id,added.id])expect(bulk.parsed.project.entities.find(e=>e.id===id)!.status).toBe('needs_review');expect(bulk.parsed.project.entities.find(e=>e.id===f.done.id)!.status).toBe('provisional');
 await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'変更履歴',exact:true}).click();await page.getByRole('button',{name:'この変更を取り消す',exact:true}).click();await expect(page.locator('.history-page [role=status]').last()).toContainText('復元し、保存した版を確認');
 const undone=await backup(page);for(const id of [f.first.id,added.id]){const restored=undone.parsed.project.entities.find(e=>e.id===id)!;expect(restored.status).toBe('provisional');expect(restored.data).toEqual(afterViewEdit.parsed.project.entities.find(e=>e.id===id)!.data);}expect(undone.parsed.project.history.length).toBeGreaterThan(bulk.parsed.project.history.length);
 await page.reload();await list(page,c.dynamic.name,2);await list(page,c.fixed.name,1);const cold=await backup(page);assertCollections(cold.parsed.project,f.first.name,added.name);
 const fresh=await freshRoundtrip(browser,cold.bytes,'new'),clone=await freshRoundtrip(browser,cold.bytes,'clone');assertCollections(fresh.parsed.project,f.first.name,added.name);assertCollections(clone.parsed.project,f.first.name,added.name);expect(clone.parsed.project.projectId).not.toBe(cold.parsed.project.projectId);
 await list(page,c.dynamic.name,2);await view.getByRole('button',{name:'カード',exact:true}).click();const observedButtons=await view.getByRole('button').allTextContents();
 await view.getByRole('button',{name:'図',exact:true}).click();await expect(page.getByRole('region',{name:'同じ検索結果の図',exact:true}).locator('g[data-entity-id]')).toHaveCount(2);await view.getByRole('button',{name:'年表',exact:true}).click();await expect(page.getByRole('region',{name:'同じ検索結果の年表',exact:true}).locator('li[data-entity-id]')).toHaveCount(2);
 await evidence(info,'F58-original-four-views',{phase:'clean_fixed_C15_independent_production',originalInputSHA256:digest(input),displayButtons:observedButtons,normalObserved:{dynamic1to2Fixed1to1:true,allFourViewsSameResultIDs:true,viewSwitchesNativeUnchanged:true,keyboardGraphToSameBodyAndReturn:true,paragraphIDKept:true,timelineToSameEventTimeAndReturn:true,bothBulkBeforeAfter:true,cancelAllNativeUnchanged:true,quotaAllNativeUnchanged:true,retryBothApplied:true,undoBothAndEditedBodyKept:true,coldNewClone:true},failureText,archives:{initial:digest(initial.bytes),added:digest(afterAdd.bytes),viewEdited:digest(afterViewEdit.bytes),bulk:digest(bulk.bytes),undo:digest(undone.bytes),cold:digest(cold.bytes),freshNew:digest(fresh.bytes),freshClone:digest(clone.bytes)},physical:'not_run',actualAuth:'not_run',whole116OrFinalF58PassInferred:false});
});
