import { $ as e, D as t, E as n, G as r, H as i, I as a, J as o, K as s, O as c, Q as l, T as u, U as d, V as f, W as p, X as m, Y as h, Z as g, _, a as v, b as y, c as b, et as x, g as S, h as C, i as w, j as T, k as E, m as D, nt as O, o as ee, q as k, rt as A, s as te, t as j, tt as M, v as N, y as ne } from "./presentation-DKAwcIkS.js";
import { a as P, c as re, d as F, f as ie, i as I, l as ae, o as oe, r as se, s as L, t as R, u as z } from "./protocol-DZd519mb.js";
//#region \0rolldown/runtime.js
var ce = Object.create, le = Object.defineProperty, ue = Object.getOwnPropertyDescriptor, de = Object.getOwnPropertyNames, fe = Object.getPrototypeOf, pe = Object.prototype.hasOwnProperty, me = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), he = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = de(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !pe.call(e, s) && s !== n && le(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = ue(t, s)) || r.enumerable
	});
	return e;
}, ge = (e, t, n) => (n = e == null ? {} : ce(fe(e)), he(t || !e || !e.__esModule || !pe.call(e, "default") ? le(n, "default", {
	value: e,
	enumerable: !0
}) : n, e)), _e = [
	"VALIDATION_FAILED",
	"REFERENCE_INVALID",
	"LOCAL_SAVE_FAILED",
	"QUOTA_EXCEEDED",
	"SYNC_CONFLICT",
	"AUTH_REQUIRED",
	"FORBIDDEN",
	"FORMAT_UNSUPPORTED",
	"INTEGRITY_FAILED",
	"IMPORT_LIMIT",
	"ANALYSIS_LIMIT",
	"EXPORT_UNSUPPORTED",
	"UI_RENDER_FAILED"
], ve = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
function ye(e, t, n, r) {
	if (!_e.includes(e)) throw Error("Unknown diagnostic code");
	if (t !== void 0 && !ve.test(t)) throw Error("Invalid operation ID");
	if (n !== void 0 && !/^(0|[1-9]\d*)$/.test(n)) throw Error("Invalid revision");
	let i = {};
	if (r) {
		for (let e of ["commit", "tree"]) typeof r[e] == "string" && /^[0-9a-f]{40}$/.test(r[e]) && (i[e] = r[e]);
		typeof r.dirty == "boolean" && (i.dirty = r.dirty), typeof r.base == "string" && /^\/[A-Za-z0-9_/-]{0,100}\/$/.test(r.base) && (i.base = r.base), [
			"Chromium",
			"Edge",
			"Firefox",
			"Safari",
			"unknown"
		].includes(r.browser ?? "") && (i.browser = r.browser), [
			"Windows",
			"macOS",
			"iOS",
			"Android",
			"Linux",
			"unknown"
		].includes(r.os ?? "") && (i.os = r.os);
		for (let e of ["browserVersion", "osVersion"]) typeof r[e] == "string" && /^\d+(?:\.\d+){0,4}$/.test(r[e]) && r[e].length <= 32 && (i[e] = r[e]);
		for (let e of ["width", "height"]) Number.isSafeInteger(r[e]) && r[e] >= 0 && r[e] <= 1e4 && (i[e] = r[e]);
		typeof r.online == "boolean" && (i.online = r.online);
	}
	return {
		schemaVersion: "1.0.0",
		code: e,
		operationId: t ?? null,
		revision: n ?? null,
		environment: "browser",
		recordedAt: (/* @__PURE__ */ new Date()).toISOString(),
		...r ? { metadata: i } : {}
	};
}
var be = /* @__PURE__ */ new Map(), xe = /* @__PURE__ */ new Set(), Se = "guest";
function Ce() {
	let e = typeof navigator > "u" ? "" : navigator.userAgent, t = e.match(/Edg\/([\d.]+)/) ? "Edge" : e.match(/Firefox\/([\d.]+)/) ? "Firefox" : e.match(/(?:Chrome|Chromium)\/([\d.]+)/) ? "Chromium" : e.match(/Version\/([\d.]+).*Safari/) ? "Safari" : "unknown", n = e.match(t === "Edge" ? /Edg\/([\d.]+)/ : t === "Firefox" ? /Firefox\/([\d.]+)/ : t === "Chromium" ? /(?:Chrome|Chromium)\/([\d.]+)/ : /Version\/([\d.]+)/)?.[1], r = /iPhone|iPad|iPod/.test(e) ? "iOS" : /Android/.test(e) ? "Android" : /Windows/.test(e) ? "Windows" : /Macintosh/.test(e) ? "macOS" : /Linux/.test(e) ? "Linux" : "unknown";
	return {
		commit: void 0,
		tree: void 0,
		dirty: void 0,
		base: "/__restore/",
		browser: t,
		browserVersion: n,
		os: r,
		osVersion: e.match(r === "iOS" ? /OS ([\d_]+)/ : r === "Android" ? /Android ([\d.]+)/ : r === "Windows" ? /Windows NT ([\d.]+)/ : /Mac OS X ([\d_]+)/)?.[1]?.replaceAll("_", "."),
		...typeof window > "u" ? {} : {
			width: window.innerWidth,
			height: window.innerHeight,
			online: navigator.onLine
		}
	};
}
function we(e, t = {}) {
	try {
		let n = e && typeof e == "object" && "code" in e ? String(e.code) : "";
		if (n === "CANCELLED" || e instanceof DOMException && e.name === "AbortError") return;
		let r = t.code ?? (_e.includes(n) ? n : {
			SAVE_FAILED: "LOCAL_SAVE_FAILED",
			REVISION_CONFLICT: "SYNC_CONFLICT",
			OPERATION_CONFLICT: "SYNC_CONFLICT",
			REVISION_CHANGED: "SYNC_CONFLICT",
			ARCHIVE_INVALID: "INTEGRITY_FAILED",
			HASH_MISMATCH: "INTEGRITY_FAILED",
			UNSAFE_PATH: "INTEGRITY_FAILED",
			ASSET_MISSING: "INTEGRITY_FAILED",
			ASSET_INVALID: "INTEGRITY_FAILED",
			LIMIT_EXCEEDED: "IMPORT_LIMIT",
			PROTOCOL_INVALID: "INTEGRITY_FAILED"
		}[n] ?? "LOCAL_SAVE_FAILED"), i = t.accountId === void 0 ? Se : t.accountId ?? "guest", a = ye(r, ve.test(t.operationId ?? "") ? t.operationId : void 0, /^(0|[1-9]\d*)$/.test(t.revision ?? "") ? t.revision : void 0, Ce());
		return be.set(i, [...(be.get(i) ?? []).slice(-19), a]), xe.forEach((e) => e()), a;
	} catch {}
}
//#endregion
//#region ../shinariokanri/node_modules/dexie/import-wrapper-prod.mjs
var Te = /* @__PURE__ */ ge((/* @__PURE__ */ me(((e, t) => {
	((n, r) => {
		typeof e == "object" && t !== void 0 ? t.exports = r() : typeof define == "function" && define.amd ? define(r) : (n = typeof globalThis < "u" ? globalThis : n || self).Dexie = r();
	})(e, function() {
		var e = function(t, n) {
			return (e = Object.setPrototypeOf || ({ __proto__: [] } instanceof Array ? function(e, t) {
				e.__proto__ = t;
			} : function(e, t) {
				for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
			}))(t, n);
		}, t = function() {
			return (t = Object.assign || function(e) {
				for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
				return e;
			}).apply(this, arguments);
		};
		function n(e, t, n) {
			if (n || arguments.length === 2) for (var r, i = 0, a = t.length; i < a; i++) !r && i in t || ((r ||= Array.prototype.slice.call(t, 0, i))[i] = t[i]);
			return e.concat(r || Array.prototype.slice.call(t));
		}
		var r = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, i = Object.keys, a = Array.isArray;
		function o(e, t) {
			return typeof t == "object" && i(t).forEach(function(n) {
				e[n] = t[n];
			}), e;
		}
		typeof Promise > "u" || r.Promise || (r.Promise = Promise);
		var s = Object.getPrototypeOf, c = {}.hasOwnProperty;
		function l(e, t) {
			return c.call(e, t);
		}
		function u(e, t) {
			typeof t == "function" && (t = t(s(e))), (typeof Reflect > "u" ? i : Reflect.ownKeys)(t).forEach(function(n) {
				f(e, n, t[n]);
			});
		}
		var d = Object.defineProperty;
		function f(e, t, n, r) {
			d(e, t, o(n && l(n, "get") && typeof n.get == "function" ? {
				get: n.get,
				set: n.set,
				configurable: !0
			} : {
				value: n,
				configurable: !0,
				writable: !0
			}, r));
		}
		function p(e) {
			return { from: function(t) {
				return e.prototype = Object.create(t.prototype), f(e.prototype, "constructor", e), { extend: u.bind(null, e.prototype) };
			} };
		}
		var m = Object.getOwnPropertyDescriptor, h = [].slice;
		function g(e, t, n) {
			return h.call(e, t, n);
		}
		function _(e, t) {
			return t(e);
		}
		function v(e) {
			if (!e) throw Error("Assertion Failed");
		}
		function y(e) {
			r.setImmediate ? setImmediate(e) : setTimeout(e, 0);
		}
		function b(e, t) {
			if (typeof t == "string" && l(e, t)) return e[t];
			if (!t) return e;
			if (typeof t != "string") {
				for (var n = [], r = 0, i = t.length; r < i; ++r) {
					var a = b(e, t[r]);
					n.push(a);
				}
				return n;
			}
			var o, s = t.indexOf(".");
			return s === -1 || (o = e[t.substr(0, s)]) == null ? void 0 : b(o, t.substr(s + 1));
		}
		function x(e, t, n) {
			if (e && t !== void 0 && !("isFrozen" in Object && Object.isFrozen(e))) {
				if (typeof t != "string" && "length" in t) {
					v(typeof n != "string" && "length" in n);
					for (var r = 0, i = t.length; r < i; ++r) x(e, t[r], n[r]);
				} else {
					var o = t.indexOf(".");
					if (o !== -1) {
						var s = t.substr(0, o), o = t.substr(o + 1);
						if (o === "") n === void 0 ? a(e) && !isNaN(parseInt(s)) ? e.splice(s, 1) : delete e[s] : e[s] = n;
						else {
							var c = e[s];
							if (!c || !l(e, s)) {
								if (n === void 0) return;
								c = e[s] = {};
							}
							x(c, o, n);
						}
					} else n === void 0 ? a(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n;
				}
			}
		}
		function S(e) {
			var t, n = {};
			for (t in e) l(e, t) && (n[t] = e[t]);
			return n;
		}
		var C = [].concat;
		function w(e) {
			return C.apply([], e);
		}
		var T = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(w([
			8,
			16,
			32,
			64
		].map(function(e) {
			return [
				"Int",
				"Uint",
				"Float"
			].map(function(t) {
				return t + e + "Array";
			});
		}))).filter(function(e) {
			return r[e];
		}), E = new Set(T.map(function(e) {
			return r[e];
		})), D = null;
		function O(e) {
			return D = /* @__PURE__ */ new WeakMap(), e = function e(t) {
				if (!t || typeof t != "object") return t;
				var n = D.get(t);
				if (n) return n;
				if (a(t)) {
					n = [], D.set(t, n);
					for (var r = 0, i = t.length; r < i; ++r) n.push(e(t[r]));
				} else if (E.has(t.constructor)) n = t;
				else {
					var o, c = s(t);
					for (o in n = c === Object.prototype ? {} : Object.create(c), D.set(t, n), t) l(t, o) && (n[o] = e(t[o]));
				}
				return n;
			}(e), D = null, e;
		}
		var ee = {}.toString;
		function k(e) {
			return ee.call(e).slice(8, -1);
		}
		var A = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", te = typeof A == "symbol" ? function(e) {
			var t;
			return e != null && (t = e[A]) && t.apply(e);
		} : function() {
			return null;
		};
		function j(e, t) {
			t = e.indexOf(t), 0 <= t && e.splice(t, 1);
		}
		var M = {};
		function N(e) {
			var t, n, r, i;
			if (arguments.length === 1) {
				if (a(e)) return e.slice();
				if (this === M && typeof e == "string") return [e];
				if (i = te(e)) for (n = []; !(r = i.next()).done;) n.push(r.value);
				else {
					if (e == null || typeof (t = e.length) != "number") return [e];
					for (n = Array(t); t--;) n[t] = e[t];
				}
			} else for (t = arguments.length, n = Array(t); t--;) n[t] = arguments[t];
			return n;
		}
		var ne = typeof Symbol < "u" ? function(e) {
			return e[Symbol.toStringTag] === "AsyncFunction";
		} : function() {
			return !1;
		}, T = [
			"Unknown",
			"Constraint",
			"Data",
			"TransactionInactive",
			"ReadOnly",
			"Version",
			"NotFound",
			"InvalidState",
			"InvalidAccess",
			"Abort",
			"Timeout",
			"QuotaExceeded",
			"Syntax",
			"DataClone"
		], P = [
			"Modify",
			"Bulk",
			"OpenFailed",
			"VersionChange",
			"Schema",
			"Upgrade",
			"InvalidTable",
			"MissingAPI",
			"NoSuchDatabase",
			"InvalidArgument",
			"SubTransaction",
			"Unsupported",
			"Internal",
			"DatabaseClosed",
			"PrematureCommit",
			"ForeignAwait"
		].concat(T), re = {
			VersionChanged: "Database version changed by other database connection",
			DatabaseClosed: "Database has been closed",
			Abort: "Transaction aborted",
			TransactionInactive: "Transaction has already completed or failed",
			MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
		};
		function F(e, t) {
			this.name = e, this.message = t;
		}
		function ie(e, t) {
			return e + ". Errors: " + Object.keys(t).map(function(e) {
				return t[e].toString();
			}).filter(function(e, t, n) {
				return n.indexOf(e) === t;
			}).join("\n");
		}
		function I(e, t, n, r) {
			this.failures = t, this.failedKeys = r, this.successCount = n, this.message = ie(e, t);
		}
		function ae(e, t) {
			this.name = "BulkError", this.failures = Object.keys(t).map(function(e) {
				return t[e];
			}), this.failuresByPos = t, this.message = ie(e, this.failures);
		}
		p(F).from(Error).extend({ toString: function() {
			return this.name + ": " + this.message;
		} }), p(I).from(F), p(ae).from(F);
		var oe = P.reduce(function(e, t) {
			return e[t] = t + "Error", e;
		}, {}), se = F, L = P.reduce(function(e, t) {
			var n = t + "Error";
			function r(e, r) {
				this.name = n, e ? typeof e == "string" ? (this.message = `${e}${r ? "\n " + r : ""}`, this.inner = r || null) : typeof e == "object" && (this.message = `${e.name} ${e.message}`, this.inner = e) : (this.message = re[t] || n, this.inner = null);
			}
			return p(r).from(se), e[t] = r, e;
		}, {}), R = (L.Syntax = SyntaxError, L.Type = TypeError, L.Range = RangeError, T.reduce(function(e, t) {
			return e[t + "Error"] = L[t], e;
		}, {}));
		T = P.reduce(function(e, t) {
			return [
				"Syntax",
				"Type",
				"Range"
			].indexOf(t) === -1 && (e[t + "Error"] = L[t]), e;
		}, {});
		function z() {}
		function ce(e) {
			return e;
		}
		function le(e, t) {
			return e == null || e === ce ? t : function(n) {
				return t(e(n));
			};
		}
		function ue(e, t) {
			return function() {
				e.apply(this, arguments), t.apply(this, arguments);
			};
		}
		function de(e, t) {
			return e === z ? t : function() {
				var n = e.apply(this, arguments), r = (n !== void 0 && (arguments[0] = n), this.onsuccess), i = this.onerror, a = (this.onsuccess = null, this.onerror = null, t.apply(this, arguments));
				return r && (this.onsuccess = this.onsuccess ? ue(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? ue(i, this.onerror) : i), a === void 0 ? n : a;
			};
		}
		function fe(e, t) {
			return e === z ? t : function() {
				e.apply(this, arguments);
				var n = this.onsuccess, r = this.onerror;
				this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? ue(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? ue(r, this.onerror) : r);
			};
		}
		function pe(e, t) {
			return e === z ? t : function() {
				var n = e.apply(this, arguments), r = (o(arguments[0], n), this.onsuccess), i = this.onerror, a = (this.onsuccess = null, this.onerror = null, t.apply(this, arguments));
				return r && (this.onsuccess = this.onsuccess ? ue(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? ue(i, this.onerror) : i), n === void 0 ? a === void 0 ? void 0 : a : o(n, a);
			};
		}
		function me(e, t) {
			return e === z ? t : function() {
				return !1 !== t.apply(this, arguments) && e.apply(this, arguments);
			};
		}
		function he(e, t) {
			return e === z ? t : function() {
				var n = e.apply(this, arguments);
				if (n && typeof n.then == "function") {
					for (var r = this, i = arguments.length, a = Array(i); i--;) a[i] = arguments[i];
					return n.then(function() {
						return t.apply(r, a);
					});
				}
				return t.apply(this, arguments);
			};
		}
		T.ModifyError = I, T.DexieError = F, T.BulkError = ae;
		var ge = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
		function _e(e) {
			ge = e;
		}
		var ve = {}, ye = 100, be = typeof Promise > "u" ? [] : (P = Promise.resolve(), typeof crypto < "u" && crypto.subtle ? [
			be = crypto.subtle.digest("SHA-512", new Uint8Array([0])),
			s(be),
			P
		] : [
			P,
			s(P),
			P
		]), P = be[0], xe = be[1], xe = xe && xe.then, Se = P && P.constructor, Ce = !!be[2], we = function(e, t) {
			je.push([e, t]), Ee &&= (queueMicrotask(H), !1);
		}, Te = !0, Ee = !0, De = [], Oe = [], ke = ce, Ae = {
			id: "global",
			global: !0,
			ref: 0,
			unhandleds: [],
			onunhandled: z,
			pgp: !1,
			env: {},
			finalize: z
		}, B = Ae, je = [], Me = 0, Ne = [];
		function V(e) {
			if (typeof this != "object") throw TypeError("Promises must be constructed via new");
			this._listeners = [], this._lib = !1;
			var t = this._PSD = B;
			if (typeof e != "function") {
				if (e !== ve) throw TypeError("Not a function");
				this._state = arguments[1], this._value = arguments[2], !1 === this._state && Ie(this, this._value);
			} else this._state = null, this._value = null, ++t.ref, function e(t, n) {
				try {
					n(function(n) {
						if (t._state === null) {
							if (n === t) throw TypeError("A promise cannot be resolved with itself.");
							var r = t._lib && Be();
							n && typeof n.then == "function" ? e(t, function(e, t) {
								n instanceof V ? n._then(e, t) : n.then(e, t);
							}) : (t._state = !0, t._value = n, Le(t)), r && Ve();
						}
					}, Ie.bind(null, t));
				} catch (e) {
					Ie(t, e);
				}
			}(this, e);
		}
		var Pe = {
			get: function() {
				var e = B, t = Je;
				function n(n, r) {
					var i = this, a = !e.global && (e !== B || t !== Je), o = a && !Qe(), s = new V(function(t, s) {
						Re(i, new Fe(it(n, e, a, o), it(r, e, a, o), t, s, e));
					});
					return this._consoleTask && (s._consoleTask = this._consoleTask), s;
				}
				return n.prototype = ve, n;
			},
			set: function(e) {
				f(this, "then", e && e.prototype === ve ? Pe : {
					get: function() {
						return e;
					},
					set: Pe.set
				});
			}
		};
		function Fe(e, t, n, r, i) {
			this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = i;
		}
		function Ie(e, t) {
			var n, r;
			Oe.push(t), e._state === null && (n = e._lib && Be(), t = ke(t), e._state = !1, e._value = t, r = e, De.some(function(e) {
				return e._value === r._value;
			}) || De.push(r), Le(e), n) && Ve();
		}
		function Le(e) {
			var t = e._listeners;
			e._listeners = [];
			for (var n = 0, r = t.length; n < r; ++n) Re(e, t[n]);
			var i = e._PSD;
			--i.ref || i.finalize(), Me === 0 && (++Me, we(function() {
				--Me == 0 && He();
			}, []));
		}
		function Re(e, t) {
			if (e._state === null) e._listeners.push(t);
			else {
				var n = e._state ? t.onFulfilled : t.onRejected;
				if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
				++t.psd.ref, ++Me, we(ze, [
					n,
					e,
					t
				]);
			}
		}
		function ze(e, t, n) {
			try {
				var r, i = t._value;
				!t._state && Oe.length && (Oe = []), r = ge && t._consoleTask ? t._consoleTask.run(function() {
					return e(i);
				}) : e(i), t._state || Oe.indexOf(i) !== -1 || ((e) => {
					for (var t = De.length; t;) if (De[--t]._value === e._value) return De.splice(t, 1);
				})(t), n.resolve(r);
			} catch (e) {
				n.reject(e);
			} finally {
				--Me == 0 && He(), --n.psd.ref || n.psd.finalize();
			}
		}
		function H() {
			rt(Ae, function() {
				Be() && Ve();
			});
		}
		function Be() {
			var e = Te;
			return Ee = Te = !1, e;
		}
		function Ve() {
			var e, t, n;
			do
				for (; 0 < je.length;) for (e = je, je = [], n = e.length, t = 0; t < n; ++t) {
					var r = e[t];
					r[0].apply(null, r[1]);
				}
			while (0 < je.length);
			Ee = Te = !0;
		}
		function He() {
			for (var e = De, t = (De = [], e.forEach(function(e) {
				e._PSD.onunhandled.call(null, e._value, e);
			}), Ne.slice(0)), n = t.length; n;) t[--n]();
		}
		function Ue(e) {
			return new V(ve, !1, e);
		}
		function U(e, t) {
			var n = B;
			return function() {
				var r = Be(), i = B;
				try {
					return tt(n, !0), e.apply(this, arguments);
				} catch (e) {
					t && t(e);
				} finally {
					tt(i, !1), r && Ve();
				}
			};
		}
		u(V.prototype, {
			then: Pe,
			_then: function(e, t) {
				Re(this, new Fe(null, null, e, t, B));
			},
			catch: function(e) {
				var t, n;
				return arguments.length === 1 ? this.then(null, e) : (t = e, n = arguments[1], typeof t == "function" ? this.then(null, function(e) {
					return (e instanceof t ? n : Ue)(e);
				}) : this.then(null, function(e) {
					return (e && e.name === t ? n : Ue)(e);
				}));
			},
			finally: function(e) {
				return this.then(function(t) {
					return V.resolve(e()).then(function() {
						return t;
					});
				}, function(t) {
					return V.resolve(e()).then(function() {
						return Ue(t);
					});
				});
			},
			timeout: function(e, t) {
				var n = this;
				return e < 1 / 0 ? new V(function(r, i) {
					var a = setTimeout(function() {
						return i(new L.Timeout(t));
					}, e);
					n.then(r, i).finally(clearTimeout.bind(null, a));
				}) : this;
			}
		}), typeof Symbol < "u" && Symbol.toStringTag && f(V.prototype, Symbol.toStringTag, "Dexie.Promise"), Ae.env = nt(), u(V, {
			all: function() {
				var e = N.apply(null, arguments).map($e);
				return new V(function(t, n) {
					e.length === 0 && t([]);
					var r = e.length;
					e.forEach(function(i, a) {
						return V.resolve(i).then(function(n) {
							e[a] = n, --r || t(e);
						}, n);
					});
				});
			},
			resolve: function(e) {
				return e instanceof V ? e : e && typeof e.then == "function" ? new V(function(t, n) {
					e.then(t, n);
				}) : new V(ve, !0, e);
			},
			reject: Ue,
			race: function() {
				var e = N.apply(null, arguments).map($e);
				return new V(function(t, n) {
					e.map(function(e) {
						return V.resolve(e).then(t, n);
					});
				});
			},
			PSD: {
				get: function() {
					return B;
				},
				set: function(e) {
					return B = e;
				}
			},
			totalEchoes: { get: function() {
				return Je;
			} },
			newPSD: Xe,
			usePSD: rt,
			scheduler: {
				get: function() {
					return we;
				},
				set: function(e) {
					we = e;
				}
			},
			rejectionMapper: {
				get: function() {
					return ke;
				},
				set: function(e) {
					ke = e;
				}
			},
			follow: function(e, t) {
				return new V(function(n, r) {
					return Xe(function(t, n) {
						var r = B;
						r.unhandleds = [], r.onunhandled = n, r.finalize = ue(function() {
							var e, r = this;
							e = function() {
								r.unhandleds.length === 0 ? t() : n(r.unhandleds[0]);
							}, Ne.push(function t() {
								e(), Ne.splice(Ne.indexOf(t), 1);
							}), ++Me, we(function() {
								--Me == 0 && He();
							}, []);
						}, r.finalize), e();
					}, t, n, r);
				});
			}
		}), Se && (Se.allSettled && f(V, "allSettled", function() {
			var e = N.apply(null, arguments).map($e);
			return new V(function(t) {
				e.length === 0 && t([]);
				var n = e.length, r = Array(n);
				e.forEach(function(e, i) {
					return V.resolve(e).then(function(e) {
						return r[i] = {
							status: "fulfilled",
							value: e
						};
					}, function(e) {
						return r[i] = {
							status: "rejected",
							reason: e
						};
					}).then(function() {
						return --n || t(r);
					});
				});
			});
		}), Se.any && typeof AggregateError < "u" && f(V, "any", function() {
			var e = N.apply(null, arguments).map($e);
			return new V(function(t, n) {
				e.length === 0 && n(/* @__PURE__ */ AggregateError([]));
				var r = e.length, i = Array(r);
				e.forEach(function(e, a) {
					return V.resolve(e).then(function(e) {
						return t(e);
					}, function(e) {
						i[a] = e, --r || n(AggregateError(i));
					});
				});
			});
		}), Se.withResolvers) && (V.withResolvers = Se.withResolvers);
		var We = {
			awaits: 0,
			echoes: 0,
			id: 0
		}, Ge = 0, Ke = [], qe = 0, Je = 0, Ye = 0;
		function Xe(e, t, n, r) {
			var i = B, a = Object.create(i), t = (a.parent = i, a.ref = 0, a.global = !1, a.id = ++Ye, Ae.env, a.env = Ce ? {
				Promise: V,
				PromiseProp: {
					value: V,
					configurable: !0,
					writable: !0
				},
				all: V.all,
				race: V.race,
				allSettled: V.allSettled,
				any: V.any,
				resolve: V.resolve,
				reject: V.reject
			} : {}, t && o(a, t), ++i.ref, a.finalize = function() {
				--this.parent.ref || this.parent.finalize();
			}, rt(a, e, n, r));
			return a.ref === 0 && a.finalize(), t;
		}
		function Ze() {
			return We.id ||= ++Ge, ++We.awaits, We.echoes += ye, We.id;
		}
		function Qe() {
			return !!We.awaits && (--We.awaits == 0 && (We.id = 0), We.echoes = We.awaits * ye, !0);
		}
		function $e(e) {
			return We.echoes && e && e.constructor === Se ? (Ze(), e.then(function(e) {
				return Qe(), e;
			}, function(e) {
				return Qe(), ot(e);
			})) : e;
		}
		function et() {
			var e = Ke[Ke.length - 1];
			Ke.pop(), tt(e, !1);
		}
		function tt(e, t) {
			var n, i, a = B;
			(t ? !We.echoes || qe++ && e === B : !qe || --qe && e === B) || queueMicrotask(t ? function(e) {
				++Je, We.echoes && --We.echoes != 0 || (We.echoes = We.awaits = We.id = 0), Ke.push(B), tt(e, !0);
			}.bind(null, e) : et), e !== B && (B = e, a === Ae && (Ae.env = nt()), Ce) && (n = Ae.env.Promise, i = e.env, a.global || e.global) && (Object.defineProperty(r, "Promise", i.PromiseProp), n.all = i.all, n.race = i.race, n.resolve = i.resolve, n.reject = i.reject, i.allSettled && (n.allSettled = i.allSettled), i.any) && (n.any = i.any);
		}
		function nt() {
			var e = r.Promise;
			return Ce ? {
				Promise: e,
				PromiseProp: Object.getOwnPropertyDescriptor(r, "Promise"),
				all: e.all,
				race: e.race,
				allSettled: e.allSettled,
				any: e.any,
				resolve: e.resolve,
				reject: e.reject
			} : {};
		}
		function rt(e, t, n, r, i) {
			var a = B;
			try {
				return tt(e, !0), t(n, r, i);
			} finally {
				tt(a, !1);
			}
		}
		function it(e, t, n, r) {
			return typeof e == "function" ? function() {
				var i = B;
				n && Ze(), tt(t, !0);
				try {
					return e.apply(this, arguments);
				} finally {
					tt(i, !1), r && queueMicrotask(Qe);
				}
			} : e;
		}
		function at(e) {
			Promise === Se && We.echoes === 0 ? qe === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0);
		}
		("" + xe).indexOf("[native code]") === -1 && (Ze = Qe = z);
		var ot = V.reject, st = "￿", ct = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", lt = "String expected.", W = "__dbnames", ut = "readonly", dt = "readwrite";
		function ft(e, t) {
			return e ? t ? function() {
				return e.apply(this, arguments) && t.apply(this, arguments);
			} : e : t;
		}
		var pt = {
			type: 3,
			lower: -1 / 0,
			lowerOpen: !1,
			upper: [[]],
			upperOpen: !1
		};
		function mt(e) {
			return typeof e != "string" || /\./.test(e) ? function(e) {
				return e;
			} : function(t) {
				return t[e] === void 0 && e in t && delete (t = O(t))[e], t;
			};
		}
		function ht() {
			throw L.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
		}
		function G(e, t) {
			try {
				var n = gt(e), r = gt(t);
				if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r === "Date" ? -1 : NaN;
				switch (n) {
					case "number":
					case "Date":
					case "string": return t < e ? 1 : e < t ? -1 : 0;
					case "binary":
						for (var i = _t(e), a = _t(t), o = i.length, s = a.length, c = o < s ? o : s, l = 0; l < c; ++l) if (i[l] !== a[l]) return i[l] < a[l] ? -1 : 1;
						return o === s ? 0 : o < s ? -1 : 1;
					case "Array":
						for (var u = e, d = t, f = u.length, p = d.length, m = f < p ? f : p, h = 0; h < m; ++h) {
							var g = G(u[h], d[h]);
							if (g !== 0) return g;
						}
						return f === p ? 0 : f < p ? -1 : 1;
				}
			} catch {}
			return NaN;
		}
		function gt(e) {
			var t = typeof e;
			return t == "object" && (ArrayBuffer.isView(e) || (t = k(e)) === "ArrayBuffer") ? "binary" : t;
		}
		function _t(e) {
			return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
		}
		function vt(e, t, n) {
			var r = e.schema.yProps;
			return r ? (t && 0 < n.numFailures && (t = t.filter(function(e, t) {
				return !n.failures[t];
			})), Promise.all(r.map(function(n) {
				return n = n.updatesTable, t ? e.db.table(n).where("k").anyOf(t).delete() : e.db.table(n).clear();
			})).then(function() {
				return n;
			})) : n;
		}
		bt.prototype.execute = function(e) {
			var t = this["@@propmod"];
			if (t.add !== void 0) {
				var r = t.add;
				if (a(r)) return n(n([], a(e) ? e : [], !0), r, !0).sort();
				if (typeof r == "number") return (Number(e) || 0) + r;
				if (typeof r == "bigint") try {
					return BigInt(e) + r;
				} catch {
					return BigInt(0) + r;
				}
				throw TypeError(`Invalid term ${r}`);
			}
			if (t.remove !== void 0) {
				var i = t.remove;
				if (a(i)) return a(e) ? e.filter(function(e) {
					return !i.includes(e);
				}).sort() : [];
				if (typeof i == "number") return Number(e) - i;
				if (typeof i == "bigint") try {
					return BigInt(e) - i;
				} catch {
					return BigInt(0) - i;
				}
				throw TypeError(`Invalid subtrahend ${i}`);
			}
			return r = (r = t.replacePrefix)?.[0], r && typeof e == "string" && e.startsWith(r) ? t.replacePrefix[1] + e.substring(r.length) : e;
		};
		var yt = bt;
		function bt(e) {
			this["@@propmod"] = e;
		}
		function xt(e, t) {
			for (var n = i(t), r = n.length, a = !1, o = 0; o < r; ++o) {
				var s = n[o], c = t[s], l = b(e, s);
				c instanceof yt ? (x(e, s, c.execute(l)), a = !0) : l !== c && (x(e, s, c), a = !0);
			}
			return a;
		}
		K.prototype._trans = function(e, t, n) {
			var r = this._tx || B.trans, i = this.name, a = ge && typeof console < "u" && console.createTask && console.createTask(`Dexie: ${e === "readonly" ? "read" : "write"} ${this.name}`);
			function o(e, n, r) {
				if (r.schema[i]) return t(r.idbtrans, r);
				throw new L.NotFound("Table " + i + " not part of transaction");
			}
			var s = Be();
			try {
				var c = r && r.db._novip === this.db._novip ? r === B.trans ? r._promise(e, o, n) : Xe(function() {
					return r._promise(e, o, n);
				}, {
					trans: r,
					transless: B.transless || B
				}) : function e(t, n, r, i) {
					if (t.idbdb && (t._state.openComplete || B.letThrough || t._vip)) {
						var a = t._createTransaction(n, r, t._dbSchema);
						try {
							a.create(), t._state.PR1398_maxLoop = 3;
						} catch (a) {
							return a.name === oe.InvalidState && t.isOpen() && 0 < --t._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), t.close({ disableAutoOpen: !1 }), t.open().then(function() {
								return e(t, n, r, i);
							})) : ot(a);
						}
						return a._promise(n, function(e, t) {
							return Xe(function() {
								return B.trans = a, i(e, t, a);
							});
						}).then(function(e) {
							if (n === "readwrite") try {
								a.idbtrans.commit();
							} catch {}
							return n === "readonly" ? e : a._completion.then(function() {
								return e;
							});
						});
					}
					if (t._state.openComplete) return ot(new L.DatabaseClosed(t._state.dbOpenError));
					if (!t._state.isBeingOpened) {
						if (!t._state.autoOpen) return ot(new L.DatabaseClosed());
						t.open().catch(z);
					}
					return t._state.dbReadyPromise.then(function() {
						return e(t, n, r, i);
					});
				}(this.db, e, [this.name], o);
				return a && (c._consoleTask = a, c = c.catch(function(e) {
					return console.trace(e), ot(e);
				})), c;
			} finally {
				s && Ve();
			}
		}, K.prototype.get = function(e, t) {
			var n = this;
			return e && e.constructor === Object ? this.where(e).first(t) : e == null ? ot(new L.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(t) {
				return n.core.get({
					trans: t,
					key: e
				}).then(function(e) {
					return n.hook.reading.fire(e);
				});
			}).then(t);
		}, K.prototype.where = function(e) {
			if (typeof e == "string") return new this.db.WhereClause(this, e);
			if (a(e)) return new this.db.WhereClause(this, `[${e.join("+")}]`);
			var t = i(e);
			if (t.length === 1) return this.where(t[0]).equals(e[t[0]]);
			var n = this.schema.indexes.concat(this.schema.primKey).filter(function(e) {
				if (e.compound && t.every(function(t) {
					return 0 <= e.keyPath.indexOf(t);
				})) {
					for (var n = 0; n < t.length; ++n) if (t.indexOf(e.keyPath[n]) === -1) return !1;
					return !0;
				}
				return !1;
			}).sort(function(e, t) {
				return e.keyPath.length - t.keyPath.length;
			})[0];
			if (n && this.db._maxKey !== st) return s = n.keyPath.slice(0, t.length), this.where(s).equals(s.map(function(t) {
				return e[t];
			}));
			!n && ge && console.warn(`The query ${JSON.stringify(e)} on ${this.name} would benefit from a compound index [${t.join("+")}]`);
			var r = this.schema.idxByName;
			function o(e, t) {
				return G(e, t) === 0;
			}
			var s = t.reduce(function(t, n) {
				var i = t[0], t = t[1], s = r[n], c = e[n];
				return [i || s, i || !s ? ft(t, s && s.multi ? function(e) {
					return e = b(e, n), a(e) && e.some(function(e) {
						return o(c, e);
					});
				} : function(e) {
					return o(c, b(e, n));
				}) : t];
			}, [null, null]), c = s[0], s = s[1];
			return c ? this.where(c.name).equals(e[c.keyPath]).filter(s) : n ? this.filter(s) : this.where(t).equals("");
		}, K.prototype.filter = function(e) {
			return this.toCollection().and(e);
		}, K.prototype.count = function(e) {
			return this.toCollection().count(e);
		}, K.prototype.offset = function(e) {
			return this.toCollection().offset(e);
		}, K.prototype.limit = function(e) {
			return this.toCollection().limit(e);
		}, K.prototype.each = function(e) {
			return this.toCollection().each(e);
		}, K.prototype.toArray = function(e) {
			return this.toCollection().toArray(e);
		}, K.prototype.toCollection = function() {
			return new this.db.Collection(new this.db.WhereClause(this));
		}, K.prototype.orderBy = function(e) {
			return new this.db.Collection(new this.db.WhereClause(this, a(e) ? `[${e.join("+")}]` : e));
		}, K.prototype.reverse = function() {
			return this.toCollection().reverse();
		}, K.prototype.mapToClass = function(t) {
			for (var n = this.db, r = this.name, i = ((this.schema.mappedClass = t).prototype instanceof ht && (t = ((t) => {
				var i = s, a = t;
				if (typeof a != "function" && a !== null) throw TypeError("Class extends value " + String(a) + " is not a constructor or null");
				function o() {
					this.constructor = i;
				}
				function s() {
					return t !== null && t.apply(this, arguments) || this;
				}
				return e(i, a), i.prototype = a === null ? Object.create(a) : (o.prototype = a.prototype, new o()), Object.defineProperty(s.prototype, "db", {
					get: function() {
						return n;
					},
					enumerable: !1,
					configurable: !0
				}), s.prototype.table = function() {
					return r;
				}, s;
			})(t)), /* @__PURE__ */ new Set()), a = t.prototype; a; a = s(a)) Object.getOwnPropertyNames(a).forEach(function(e) {
				return i.add(e);
			});
			function o(e) {
				if (!e) return e;
				var n, r = Object.create(t.prototype);
				for (n in e) if (!i.has(n)) try {
					r[n] = e[n];
				} catch {}
				return r;
			}
			return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = o, this.hook("reading", o), t;
		}, K.prototype.defineClass = function() {
			return this.mapToClass(function(e) {
				o(this, e);
			});
		}, K.prototype.add = function(e, t) {
			var n = this, r = this.schema.primKey, i = r.auto, a = r.keyPath, o = e;
			return a && i && (o = mt(a)(e)), this._trans("readwrite", function(e) {
				return n.core.mutate({
					trans: e,
					type: "add",
					keys: t == null ? null : [t],
					values: [o]
				});
			}).then(function(e) {
				return e.numFailures ? V.reject(e.failures[0]) : e.lastResult;
			}).then(function(t) {
				if (a) try {
					x(e, a, t);
				} catch {}
				return t;
			});
		}, K.prototype.upsert = function(e, t) {
			var n = this, r = this.schema.primKey.keyPath;
			return this._trans("readwrite", function(i) {
				return n.core.get({
					trans: i,
					key: e
				}).then(function(a) {
					var o = a ?? {};
					return xt(o, t), r && x(o, r, e), n.core.mutate({
						trans: i,
						type: "put",
						values: [o],
						keys: [e],
						upsert: !0,
						updates: {
							keys: [e],
							changeSpecs: [t]
						}
					}).then(function(e) {
						return e.numFailures ? V.reject(e.failures[0]) : !!a;
					});
				});
			});
		}, K.prototype.update = function(e, t) {
			return typeof e != "object" || a(e) ? this.where(":id").equals(e).modify(t) : (e = b(e, this.schema.primKey.keyPath)) === void 0 ? ot(new L.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(t);
		}, K.prototype.put = function(e, t) {
			var n = this, r = this.schema.primKey, i = r.auto, a = r.keyPath, o = e;
			return a && i && (o = mt(a)(e)), this._trans("readwrite", function(e) {
				return n.core.mutate({
					trans: e,
					type: "put",
					values: [o],
					keys: t == null ? null : [t]
				});
			}).then(function(e) {
				return e.numFailures ? V.reject(e.failures[0]) : e.lastResult;
			}).then(function(t) {
				if (a) try {
					x(e, a, t);
				} catch {}
				return t;
			});
		}, K.prototype.delete = function(e) {
			var t = this;
			return this._trans("readwrite", function(n) {
				return t.core.mutate({
					trans: n,
					type: "delete",
					keys: [e]
				}).then(function(n) {
					return vt(t, [e], n);
				}).then(function(e) {
					return e.numFailures ? V.reject(e.failures[0]) : void 0;
				});
			});
		}, K.prototype.clear = function() {
			var e = this;
			return this._trans("readwrite", function(t) {
				return e.core.mutate({
					trans: t,
					type: "deleteRange",
					range: pt
				}).then(function(t) {
					return vt(e, null, t);
				});
			}).then(function(e) {
				return e.numFailures ? V.reject(e.failures[0]) : void 0;
			});
		}, K.prototype.bulkGet = function(e) {
			var t = this;
			return this._trans("readonly", function(n) {
				return t.core.getMany({
					keys: e,
					trans: n
				}).then(function(e) {
					return e.map(function(e) {
						return t.hook.reading.fire(e);
					});
				});
			});
		}, K.prototype.bulkAdd = function(e, t, n) {
			var r = this, i = Array.isArray(t) ? t : void 0, a = (n ||= i ? void 0 : t) ? n.allKeys : void 0;
			return this._trans("readwrite", function(t) {
				var n = r.schema.primKey, o = n.auto, n = n.keyPath;
				if (n && i) throw new L.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
				if (i && i.length !== e.length) throw new L.InvalidArgument("Arguments objects and keys must have the same length");
				var s = e.length, o = n && o ? e.map(mt(n)) : e;
				return r.core.mutate({
					trans: t,
					type: "add",
					keys: i,
					values: o,
					wantResults: a
				}).then(function(e) {
					var t = e.numFailures, n = e.failures;
					if (t === 0) return a ? e.results : e.lastResult;
					throw new ae(`${r.name}.bulkAdd(): ${t} of ${s} operations failed`, n);
				});
			});
		}, K.prototype.bulkPut = function(e, t, n) {
			var r = this, i = Array.isArray(t) ? t : void 0, a = (n ||= i ? void 0 : t) ? n.allKeys : void 0;
			return this._trans("readwrite", function(t) {
				var n = r.schema.primKey, o = n.auto, n = n.keyPath;
				if (n && i) throw new L.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
				if (i && i.length !== e.length) throw new L.InvalidArgument("Arguments objects and keys must have the same length");
				var s = e.length, o = n && o ? e.map(mt(n)) : e;
				return r.core.mutate({
					trans: t,
					type: "put",
					keys: i,
					values: o,
					wantResults: a
				}).then(function(e) {
					var t = e.numFailures, n = e.failures;
					if (t === 0) return a ? e.results : e.lastResult;
					throw new ae(`${r.name}.bulkPut(): ${t} of ${s} operations failed`, n);
				});
			});
		}, K.prototype.bulkUpdate = function(e) {
			var t = this, n = this.core, r = e.map(function(e) {
				return e.key;
			}), i = e.map(function(e) {
				return e.changes;
			}), a = [];
			return this._trans("readwrite", function(o) {
				return n.getMany({
					trans: o,
					keys: r,
					cache: "clone"
				}).then(function(s) {
					var c = [], l = [], u = (e.forEach(function(e, n) {
						var r = e.key, i = e.changes, o = s[n];
						if (o) {
							for (var u = 0, d = Object.keys(i); u < d.length; u++) {
								var f = d[u], p = i[f];
								if (f === t.schema.primKey.keyPath) {
									if (G(p, r) !== 0) throw new L.Constraint("Cannot update primary key in bulkUpdate()");
								} else x(o, f, p);
							}
							a.push(n), c.push(r), l.push(o);
						}
					}), c.length);
					return n.mutate({
						trans: o,
						type: "put",
						keys: c,
						values: l,
						updates: {
							keys: r,
							changeSpecs: i
						}
					}).then(function(e) {
						var n = e.numFailures, r = e.failures;
						if (n === 0) return u;
						for (var i = 0, o = Object.keys(r); i < o.length; i++) {
							var s, c = o[i], l = a[Number(c)];
							l != null && (s = r[c], delete r[c], r[l] = s);
						}
						throw new ae(`${t.name}.bulkUpdate(): ${n} of ${u} operations failed`, r);
					});
				});
			});
		}, K.prototype.bulkDelete = function(e) {
			var t = this, n = e.length;
			return this._trans("readwrite", function(n) {
				return t.core.mutate({
					trans: n,
					type: "delete",
					keys: e
				}).then(function(n) {
					return vt(t, e, n);
				});
			}).then(function(e) {
				var r = e.numFailures, i = e.failures;
				if (r === 0) return e.lastResult;
				throw new ae(`${t.name}.bulkDelete(): ${r} of ${n} operations failed`, i);
			});
		};
		var St = K;
		function K() {}
		function Ct(e) {
			function t(t, r) {
				if (r) {
					for (var i = arguments.length, a = Array(i - 1); --i;) a[i - 1] = arguments[i];
					return n[t].subscribe.apply(null, a), e;
				}
				if (typeof t == "string") return n[t];
			}
			var n = {};
			t.addEventType = s;
			for (var r = 1, o = arguments.length; r < o; ++r) s(arguments[r]);
			return t;
			function s(e, r, o) {
				var c, l;
				if (typeof e != "object") return r ||= me, l = {
					subscribers: [],
					fire: o ||= z,
					subscribe: function(e) {
						l.subscribers.indexOf(e) === -1 && (l.subscribers.push(e), l.fire = r(l.fire, e));
					},
					unsubscribe: function(e) {
						l.subscribers = l.subscribers.filter(function(t) {
							return t !== e;
						}), l.fire = l.subscribers.reduce(r, o);
					}
				}, n[e] = t[e] = l;
				i(c = e).forEach(function(e) {
					var t = c[e];
					if (a(t)) s(e, c[e][0], c[e][1]);
					else {
						if (t !== "asap") throw new L.InvalidArgument("Invalid event config");
						var n = s(e, ce, function() {
							for (var e = arguments.length, t = Array(e); e--;) t[e] = arguments[e];
							n.subscribers.forEach(function(e) {
								y(function() {
									e.apply(null, t);
								});
							});
						});
					}
				});
			}
		}
		function wt(e, t) {
			return p(t).from({ prototype: e }), t;
		}
		function Tt(e, t) {
			return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter);
		}
		function Et(e, t) {
			e.filter = ft(e.filter, t);
		}
		function Dt(e, t, n) {
			var r = e.replayFilter;
			e.replayFilter = r ? function() {
				return ft(r(), t());
			} : t, e.justLimit = n && !r;
		}
		function Ot(e, t) {
			if (e.isPrimKey) return t.primaryKey;
			var n = t.getIndexByKeyPath(e.index);
			if (n) return n;
			throw new L.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
		}
		function kt(e, t, n) {
			var r = Ot(e, t.schema);
			return t.openCursor({
				trans: n,
				values: !e.keysOnly,
				reverse: e.dir === "prev",
				unique: !!e.unique,
				query: {
					index: r,
					range: e.range
				}
			});
		}
		function At(e, t, n, r) {
			var i, a, o = e.replayFilter ? ft(e.filter, e.replayFilter()) : e.filter;
			return e.or ? (i = {}, a = function(e, n, r) {
				var a, s;
				o && !o(n, r, function(e) {
					return n.stop(e);
				}, function(e) {
					return n.fail(e);
				}) || ((s = "" + (a = n.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(a)), l(i, s)) || (i[s] = !0, t(e, n, r));
			}, Promise.all([e.or._iterate(a, n), jt(kt(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)])) : jt(kt(e, r, n), ft(e.algorithm, o), t, !e.keysOnly && e.valueMapper);
		}
		function jt(e, t, n, r) {
			var i = U(r ? function(e, t, i) {
				return n(r(e), t, i);
			} : n);
			return e.then(function(e) {
				if (e) return e.start(function() {
					var n = function() {
						return e.continue();
					};
					t && !t(e, function(e) {
						return n = e;
					}, function(t) {
						e.stop(t), n = z;
					}, function(t) {
						e.fail(t), n = z;
					}) || i(e.value, e, function(e) {
						return n = e;
					}), n();
				});
			});
		}
		q.prototype._read = function(e, t) {
			var n = this._ctx;
			return n.error ? n.table._trans(null, ot.bind(null, n.error)) : n.table._trans("readonly", e).then(t);
		}, q.prototype._write = function(e) {
			var t = this._ctx;
			return t.error ? t.table._trans(null, ot.bind(null, t.error)) : t.table._trans("readwrite", e, "locked");
		}, q.prototype._addAlgorithm = function(e) {
			var t = this._ctx;
			t.algorithm = ft(t.algorithm, e);
		}, q.prototype._iterate = function(e, t) {
			return At(this._ctx, e, t, this._ctx.table.core);
		}, q.prototype.clone = function(e) {
			var t = Object.create(this.constructor.prototype), n = Object.create(this._ctx);
			return e && o(n, e), t._ctx = n, t;
		}, q.prototype.raw = function() {
			return this._ctx.valueMapper = null, this;
		}, q.prototype.each = function(e) {
			var t = this._ctx;
			return this._read(function(n) {
				return At(t, e, n, t.table.core);
			});
		}, q.prototype.count = function(e) {
			var t = this;
			return this._read(function(e) {
				var n, r = t._ctx, i = r.table.core;
				return Tt(r, !0) ? i.count({
					trans: e,
					query: {
						index: Ot(r, i.schema),
						range: r.range
					}
				}).then(function(e) {
					return Math.min(e, r.limit);
				}) : (n = 0, At(r, function() {
					return ++n, !1;
				}, e, i).then(function() {
					return n;
				}));
			}).then(e);
		}, q.prototype.sortBy = function(e, t) {
			var n = e.split(".").reverse(), r = n[0], i = n.length - 1;
			function a(e, t) {
				return t ? a(e[n[t]], t - 1) : e[r];
			}
			var o = this._ctx.dir === "next" ? 1 : -1;
			function s(e, t) {
				return G(a(e, i), a(t, i)) * o;
			}
			return this.toArray(function(e) {
				return e.slice().sort(s);
			}).then(t);
		}, q.prototype.toArray = function(e) {
			var t = this;
			return this._read(function(e) {
				var n, r, i, a = t._ctx;
				return Tt(a, !0) && 0 < a.limit ? (n = a.valueMapper, r = Ot(a, a.table.core.schema), a.table.core.query({
					trans: e,
					limit: a.limit,
					values: !0,
					direction: a.dir === "prev" ? "prev" : void 0,
					query: {
						index: r,
						range: a.range
					}
				}).then(function(e) {
					return e = e.result, n ? e.map(n) : e;
				})) : (i = [], At(a, function(e) {
					return i.push(e);
				}, e, a.table.core).then(function() {
					return i;
				}));
			}, e);
		}, q.prototype.offset = function(e) {
			var t = this._ctx;
			return e <= 0 || (t.offset += e, Tt(t) ? Dt(t, function() {
				var t = e;
				return function(e, n) {
					return t === 0 || (t === 1 ? --t : n(function() {
						e.advance(t), t = 0;
					}), !1);
				};
			}) : Dt(t, function() {
				var t = e;
				return function() {
					return --t < 0;
				};
			})), this;
		}, q.prototype.limit = function(e) {
			return this._ctx.limit = Math.min(this._ctx.limit, e), Dt(this._ctx, function() {
				var t = e;
				return function(e, n, r) {
					return --t <= 0 && n(r), 0 <= t;
				};
			}, !0), this;
		}, q.prototype.until = function(e, t) {
			return Et(this._ctx, function(n, r, i) {
				return !e(n.value) || (r(i), t);
			}), this;
		}, q.prototype.first = function(e) {
			return this.limit(1).toArray(function(e) {
				return e[0];
			}).then(e);
		}, q.prototype.last = function(e) {
			return this.reverse().first(e);
		}, q.prototype.filter = function(e) {
			var t;
			return Et(this._ctx, function(t) {
				return e(t.value);
			}), (t = this._ctx).isMatch = ft(t.isMatch, e), this;
		}, q.prototype.and = function(e) {
			return this.filter(e);
		}, q.prototype.or = function(e) {
			return new this.db.WhereClause(this._ctx.table, e, this);
		}, q.prototype.reverse = function() {
			return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
		}, q.prototype.desc = function() {
			return this.reverse();
		}, q.prototype.eachKey = function(e) {
			var t = this._ctx;
			return t.keysOnly = !t.isMatch, this.each(function(t, n) {
				e(n.key, n);
			});
		}, q.prototype.eachUniqueKey = function(e) {
			return this._ctx.unique = "unique", this.eachKey(e);
		}, q.prototype.eachPrimaryKey = function(e) {
			var t = this._ctx;
			return t.keysOnly = !t.isMatch, this.each(function(t, n) {
				e(n.primaryKey, n);
			});
		}, q.prototype.keys = function(e) {
			var t = this._ctx, n = (t.keysOnly = !t.isMatch, []);
			return this.each(function(e, t) {
				n.push(t.key);
			}).then(function() {
				return n;
			}).then(e);
		}, q.prototype.primaryKeys = function(e) {
			var t = this._ctx;
			if (Tt(t, !0) && 0 < t.limit) return this._read(function(e) {
				var n = Ot(t, t.table.core.schema);
				return t.table.core.query({
					trans: e,
					values: !1,
					limit: t.limit,
					direction: t.dir === "prev" ? "prev" : void 0,
					query: {
						index: n,
						range: t.range
					}
				});
			}).then(function(e) {
				return e.result;
			}).then(e);
			t.keysOnly = !t.isMatch;
			var n = [];
			return this.each(function(e, t) {
				n.push(t.primaryKey);
			}).then(function() {
				return n;
			}).then(e);
		}, q.prototype.uniqueKeys = function(e) {
			return this._ctx.unique = "unique", this.keys(e);
		}, q.prototype.firstKey = function(e) {
			return this.limit(1).keys(function(e) {
				return e[0];
			}).then(e);
		}, q.prototype.lastKey = function(e) {
			return this.reverse().firstKey(e);
		}, q.prototype.distinct = function() {
			var e, t = this._ctx, t = t.index && t.table.schema.idxByName[t.index];
			return t && t.multi && (e = {}, Et(this._ctx, function(t) {
				var t = t.primaryKey.toString(), n = l(e, t);
				return e[t] = !0, !n;
			})), this;
		}, q.prototype.modify = function(e) {
			var t = this, n = this._ctx;
			return this._write(function(r) {
				function a(e, t) {
					var n = t.failures;
					p += e - t.numFailures;
					for (var r = 0, a = i(n); r < a.length; r++) {
						var o = a[r];
						f.push(n[o]);
					}
				}
				var o = typeof e == "function" ? e : function(t) {
					return xt(t, e);
				}, s = n.table.core, c = s.schema.primaryKey, l = c.outbound, u = c.extractKey, d = 200, c = t.db._options.modifyChunkSize, f = (c && (d = typeof c == "object" ? c[s.name] || c["*"] || 200 : c), []), p = 0, m = [], h = e === Nt;
				return t.clone().primaryKeys().then(function(t) {
					function i(f) {
						var p = Math.min(d, t.length - f), m = t.slice(f, f + p);
						return (h ? Promise.resolve([]) : s.getMany({
							trans: r,
							keys: m,
							cache: "immutable"
						})).then(function(g) {
							var _ = [], v = [], y = l ? [] : null, b = h ? m : [];
							if (!h) for (var x = 0; x < p; ++x) {
								var S = g[x], C = {
									value: O(S),
									primKey: t[f + x]
								};
								!1 !== o.call(C, C.value, C) && (C.value == null ? b.push(t[f + x]) : l || G(u(S), u(C.value)) === 0 ? (v.push(C.value), l && y.push(t[f + x])) : (b.push(t[f + x]), _.push(C.value)));
							}
							return Promise.resolve(0 < _.length && s.mutate({
								trans: r,
								type: "add",
								values: _
							}).then(function(e) {
								for (var t in e.failures) b.splice(parseInt(t), 1);
								a(_.length, e);
							})).then(function() {
								return (0 < v.length || c && typeof e == "object") && s.mutate({
									trans: r,
									type: "put",
									keys: y,
									values: v,
									criteria: c,
									changeSpec: typeof e != "function" && e,
									isAdditionalChunk: 0 < f
								}).then(function(e) {
									return a(v.length, e);
								});
							}).then(function() {
								return (0 < b.length || c && h) && s.mutate({
									trans: r,
									type: "delete",
									keys: b,
									criteria: c,
									isAdditionalChunk: 0 < f
								}).then(function(e) {
									return vt(n.table, b, e);
								}).then(function(e) {
									return a(b.length, e);
								});
							}).then(function() {
								return t.length > f + p && i(f + d);
							});
						});
					}
					var c = Tt(n) && n.limit === 1 / 0 && (typeof e != "function" || h) && {
						index: n.index,
						range: n.range
					};
					return i(0).then(function() {
						if (0 < f.length) throw new I("Error modifying one or more objects", f, p, m);
						return t.length;
					});
				});
			});
		}, q.prototype.delete = function() {
			var e = this._ctx, t = e.range;
			return !Tt(e) || e.table.schema.yProps || !e.isPrimKey && t.type !== 3 ? this.modify(Nt) : this._write(function(n) {
				var r = e.table.core.schema.primaryKey, i = t;
				return e.table.core.count({
					trans: n,
					query: {
						index: r,
						range: i
					}
				}).then(function(t) {
					return e.table.core.mutate({
						trans: n,
						type: "deleteRange",
						range: i
					}).then(function(e) {
						var n = e.failures, e = e.numFailures;
						if (e) throw new I("Could not delete some values", Object.keys(n).map(function(e) {
							return n[e];
						}), t - e);
						return t - e;
					});
				});
			});
		};
		var Mt = q;
		function q() {}
		var Nt = function(e, t) {
			return t.value = null;
		};
		function Pt(e, t) {
			return e < t ? -1 : e === t ? 0 : 1;
		}
		function Ft(e, t) {
			return t < e ? -1 : e === t ? 0 : 1;
		}
		function It(e, t, n) {
			return e = e instanceof Vt ? new e.Collection(e) : e, e._ctx.error = new (n || TypeError)(t), e;
		}
		function Lt(e) {
			return new e.Collection(e, function() {
				return Bt("");
			}).limit(0);
		}
		function Rt(e, t, n, r) {
			var i, a, o, s, c, l, u, d = n.length;
			if (!n.every(function(e) {
				return typeof e == "string";
			})) return It(e, lt);
			function f(e) {
				i = e === "next" ? function(e) {
					return e.toUpperCase();
				} : function(e) {
					return e.toLowerCase();
				}, a = e === "next" ? function(e) {
					return e.toLowerCase();
				} : function(e) {
					return e.toUpperCase();
				}, o = e === "next" ? Pt : Ft;
				var t = n.map(function(e) {
					return {
						lower: a(e),
						upper: i(e)
					};
				}).sort(function(e, t) {
					return o(e.lower, t.lower);
				});
				s = t.map(function(e) {
					return e.upper;
				}), c = t.map(function(e) {
					return e.lower;
				}), u = (l = e) === "next" ? "" : r;
			}
			f("next");
			var e = new e.Collection(e, function() {
				return zt(s[0], c[d - 1] + r);
			}), p = (e._ondirectionchange = function(e) {
				f(e);
			}, 0);
			return e._addAlgorithm(function(e, n, r) {
				var i = e.key;
				if (typeof i == "string") {
					var f = a(i);
					if (t(f, c, p)) return !0;
					for (var m = null, h = p; h < d; ++h) {
						var g = ((e, t, n, r, i, a) => {
							for (var o = Math.min(e.length, r.length), s = -1, c = 0; c < o; ++c) {
								var l = t[c];
								if (l !== r[c]) return i(e[c], n[c]) < 0 ? e.substr(0, c) + n[c] + n.substr(c + 1) : i(e[c], r[c]) < 0 ? e.substr(0, c) + r[c] + n.substr(c + 1) : 0 <= s ? e.substr(0, s) + t[s] + n.substr(s + 1) : null;
								i(e[c], l) < 0 && (s = c);
							}
							return o < r.length && a === "next" ? e + n.substr(e.length) : o < e.length && a === "prev" ? e.substr(0, n.length) : s < 0 ? null : e.substr(0, s) + r[s] + n.substr(s + 1);
						})(i, f, s[h], c[h], o, l);
						g === null && m === null ? p = h + 1 : (m === null || 0 < o(m, g)) && (m = g);
					}
					n(m === null ? r : function() {
						e.continue(m + u);
					});
				}
				return !1;
			}), e;
		}
		function zt(e, t, n, r) {
			return {
				type: 2,
				lower: e,
				upper: t,
				lowerOpen: n,
				upperOpen: r
			};
		}
		function Bt(e) {
			return {
				type: 1,
				lower: e,
				upper: e
			};
		}
		Object.defineProperty(J.prototype, "Collection", {
			get: function() {
				return this._ctx.table.db.Collection;
			},
			enumerable: !1,
			configurable: !0
		}), J.prototype.between = function(e, t, n, r) {
			n = !1 !== n, r = !0 === r;
			try {
				return 0 < this._cmp(e, t) || this._cmp(e, t) === 0 && (n || r) && (!n || !r) ? Lt(this) : new this.Collection(this, function() {
					return zt(e, t, !n, !r);
				});
			} catch {
				return It(this, ct);
			}
		}, J.prototype.equals = function(e) {
			return e == null ? It(this, ct) : new this.Collection(this, function() {
				return Bt(e);
			});
		}, J.prototype.above = function(e) {
			return e == null ? It(this, ct) : new this.Collection(this, function() {
				return zt(e, void 0, !0);
			});
		}, J.prototype.aboveOrEqual = function(e) {
			return e == null ? It(this, ct) : new this.Collection(this, function() {
				return zt(e, void 0, !1);
			});
		}, J.prototype.below = function(e) {
			return e == null ? It(this, ct) : new this.Collection(this, function() {
				return zt(void 0, e, !1, !0);
			});
		}, J.prototype.belowOrEqual = function(e) {
			return e == null ? It(this, ct) : new this.Collection(this, function() {
				return zt(void 0, e);
			});
		}, J.prototype.startsWith = function(e) {
			return typeof e == "string" ? this.between(e, e + st, !0, !0) : It(this, lt);
		}, J.prototype.startsWithIgnoreCase = function(e) {
			return e === "" ? this.startsWith(e) : Rt(this, function(e, t) {
				return e.indexOf(t[0]) === 0;
			}, [e], st);
		}, J.prototype.equalsIgnoreCase = function(e) {
			return Rt(this, function(e, t) {
				return e === t[0];
			}, [e], "");
		}, J.prototype.anyOfIgnoreCase = function() {
			var e = N.apply(M, arguments);
			return e.length === 0 ? Lt(this) : Rt(this, function(e, t) {
				return t.indexOf(e) !== -1;
			}, e, "");
		}, J.prototype.startsWithAnyOfIgnoreCase = function() {
			var e = N.apply(M, arguments);
			return e.length === 0 ? Lt(this) : Rt(this, function(e, t) {
				return t.some(function(t) {
					return e.indexOf(t) === 0;
				});
			}, e, st);
		}, J.prototype.anyOf = function() {
			var e, t, n = this, r = N.apply(M, arguments), i = this._cmp;
			try {
				r.sort(i);
			} catch {
				return It(this, ct);
			}
			return r.length === 0 ? Lt(this) : ((e = new this.Collection(this, function() {
				return zt(r[0], r[r.length - 1]);
			}))._ondirectionchange = function(e) {
				i = e === "next" ? n._ascending : n._descending, r.sort(i);
			}, t = 0, e._addAlgorithm(function(e, n, a) {
				for (var o = e.key; 0 < i(o, r[t]);) if (++t === r.length) return n(a), !1;
				return i(o, r[t]) === 0 || (n(function() {
					e.continue(r[t]);
				}), !1);
			}), e);
		}, J.prototype.notEqual = function(e) {
			return this.inAnyRange([[-1 / 0, e], [e, this.db._maxKey]], {
				includeLowers: !1,
				includeUppers: !1
			});
		}, J.prototype.noneOf = function() {
			var e = N.apply(M, arguments);
			if (e.length === 0) return new this.Collection(this);
			try {
				e.sort(this._ascending);
			} catch {
				return It(this, ct);
			}
			var t = e.reduce(function(e, t) {
				return e ? e.concat([[e[e.length - 1][1], t]]) : [[-1 / 0, t]];
			}, null);
			return t.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(t, {
				includeLowers: !1,
				includeUppers: !1
			});
		}, J.prototype.inAnyRange = function(e, t) {
			var n = this, r = this._cmp, i = this._ascending, a = this._descending, o = this._min, s = this._max;
			if (e.length === 0) return Lt(this);
			if (!e.every(function(e) {
				return e[0] !== void 0 && e[1] !== void 0 && i(e[0], e[1]) <= 0;
			})) return It(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", L.InvalidArgument);
			var c = !t || !1 !== t.includeLowers, l = t && !0 === t.includeUppers, u, d = i;
			function f(e, t) {
				return d(e[0], t[0]);
			}
			try {
				(u = e.reduce(function(e, t) {
					for (var n = 0, i = e.length; n < i; ++n) {
						var a = e[n];
						if (r(t[0], a[1]) < 0 && 0 < r(t[1], a[0])) {
							a[0] = o(a[0], t[0]), a[1] = s(a[1], t[1]);
							break;
						}
					}
					return n === i && e.push(t), e;
				}, [])).sort(f);
			} catch {
				return It(this, ct);
			}
			var p = 0, m = l ? function(e) {
				return 0 < i(e, u[p][1]);
			} : function(e) {
				return 0 <= i(e, u[p][1]);
			}, h = c ? function(e) {
				return 0 < a(e, u[p][0]);
			} : function(e) {
				return 0 <= a(e, u[p][0]);
			}, g = m, t = new this.Collection(this, function() {
				return zt(u[0][0], u[u.length - 1][1], !c, !l);
			});
			return t._ondirectionchange = function(e) {
				d = e === "next" ? (g = m, i) : (g = h, a), u.sort(f);
			}, t._addAlgorithm(function(e, t, r) {
				for (var a, o = e.key; g(o);) if (++p === u.length) return t(r), !1;
				return !m(a = o) && !h(a) || (n._cmp(o, u[p][1]) === 0 || n._cmp(o, u[p][0]) === 0 || t(function() {
					d === i ? e.continue(u[p][0]) : e.continue(u[p][1]);
				}), !1);
			}), t;
		}, J.prototype.startsWithAnyOf = function() {
			var e = N.apply(M, arguments);
			return e.every(function(e) {
				return typeof e == "string";
			}) ? e.length === 0 ? Lt(this) : this.inAnyRange(e.map(function(e) {
				return [e, e + st];
			})) : It(this, "startsWithAnyOf() only works with strings");
		};
		var Vt = J;
		function J() {}
		function Y(e) {
			return U(function(t) {
				return Ht(t), e(t.target.error), !1;
			});
		}
		function Ht(e) {
			e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault();
		}
		var Ut = "storagemutated", Wt = "x-storagemutated-1", Gt = Ct(null, Ut), Kt = (qt.prototype._lock = function() {
			return v(!B.global), ++this._reculock, this._reculock !== 1 || B.global || (B.lockOwnerFor = this), this;
		}, qt.prototype._unlock = function() {
			if (v(!B.global), --this._reculock == 0) for (B.global || (B.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked();) {
				var e = this._blockedFuncs.shift();
				try {
					rt(e[1], e[0]);
				} catch {}
			}
			return this;
		}, qt.prototype._locked = function() {
			return this._reculock && B.lockOwnerFor !== this;
		}, qt.prototype.create = function(e) {
			var t = this;
			if (this.mode) {
				var n = this.db.idbdb, r = this.db._state.dbOpenError;
				if (v(!this.idbtrans), !e && !n) switch (r && r.name) {
					case "DatabaseClosedError": throw new L.DatabaseClosed(r);
					case "MissingAPIError": throw new L.MissingAPI(r.message, r);
					default: throw new L.OpenFailed(r);
				}
				if (!this.active) throw new L.TransactionInactive();
				v(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || n).transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability })).onerror = U(function(n) {
					Ht(n), t._reject(e.error);
				}), e.onabort = U(function(n) {
					Ht(n), t.active && t._reject(new L.Abort(e.error)), t.active = !1, t.on("abort").fire(n);
				}), e.oncomplete = U(function() {
					t.active = !1, t._resolve(), "mutatedParts" in e && Gt.storagemutated.fire(e.mutatedParts);
				});
			}
			return this;
		}, qt.prototype._promise = function(e, t, n) {
			var r, i = this;
			return e === "readwrite" && this.mode !== "readwrite" ? ot(new L.ReadOnly("Transaction is readonly")) : this.active ? this._locked() ? new V(function(r, a) {
				i._blockedFuncs.push([function() {
					i._promise(e, t, n).then(r, a);
				}, B]);
			}) : n ? Xe(function() {
				var e = new V(function(e, n) {
					i._lock();
					var r = t(e, n, i);
					r && r.then && r.then(e, n);
				});
				return e.finally(function() {
					return i._unlock();
				}), e._lib = !0, e;
			}) : ((r = new V(function(e, n) {
				var r = t(e, n, i);
				r && r.then && r.then(e, n);
			}))._lib = !0, r) : ot(new L.TransactionInactive());
		}, qt.prototype._root = function() {
			return this.parent ? this.parent._root() : this;
		}, qt.prototype.waitFor = function(e) {
			var t, n = this._root(), r = V.resolve(e), i = (n._waitingFor ? n._waitingFor = n._waitingFor.then(function() {
				return r;
			}) : (n._waitingFor = r, n._waitingQueue = [], t = n.idbtrans.objectStore(n.storeNames[0]), function e() {
				for (++n._spinCount; n._waitingQueue.length;) n._waitingQueue.shift()();
				n._waitingFor && (t.get(-1 / 0).onsuccess = e);
			}()), n._waitingFor);
			return new V(function(e, t) {
				r.then(function(t) {
					return n._waitingQueue.push(U(e.bind(null, t)));
				}, function(e) {
					return n._waitingQueue.push(U(t.bind(null, e)));
				}).finally(function() {
					n._waitingFor === i && (n._waitingFor = null);
				});
			});
		}, qt.prototype.abort = function() {
			this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new L.Abort()));
		}, qt.prototype.table = function(e) {
			var t = this._memoizedTables ||= {};
			if (l(t, e)) return t[e];
			var n = this.schema[e];
			if (n) return (n = new this.db.Table(e, n, this)).core = this.db.core.table(e), t[e] = n;
			throw new L.NotFound("Table " + e + " not part of transaction");
		}, qt);
		function qt() {}
		function Jt(e, t, n, r, i, a, o, s) {
			return {
				name: e,
				keyPath: t,
				unique: n,
				multi: r,
				auto: i,
				compound: a,
				src: (n && !o ? "&" : "") + (r ? "*" : "") + (i ? "++" : "") + Yt(t),
				type: s
			};
		}
		function Yt(e) {
			return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : "";
		}
		function Xt(e, t, n) {
			return {
				name: e,
				primKey: t,
				indexes: n,
				mappedClass: null,
				idxByName: (r = function(e) {
					return [e.name, e];
				}, n.reduce(function(e, t, n) {
					return t = r(t, n), t && (e[t[0]] = t[1]), e;
				}, {}))
			};
			var r;
		}
		var Zt = function(e) {
			try {
				return e.only([[]]), Zt = function() {
					return [[]];
				}, [[]];
			} catch {
				return Zt = function() {
					return st;
				}, st;
			}
		};
		function Qt(e) {
			return e == null ? function() {} : typeof e == "string" ? (t = e).split(".").length === 1 ? function(e) {
				return e[t];
			} : function(e) {
				return b(e, t);
			} : function(t) {
				return b(t, e);
			};
			var t;
		}
		function $t(e) {
			return [].slice.call(e);
		}
		var en = 0;
		function tn(e) {
			return e == null ? ":id" : typeof e == "string" ? e : `[${e.join("+")}]`;
		}
		function nn(e, t, n) {
			function r(e) {
				if (e.type === 3) return null;
				if (e.type === 4) throw Error("Cannot convert never type to IDBKeyRange");
				var n = e.lower, r = e.upper, i = e.lowerOpen, e = e.upperOpen;
				return n === void 0 ? r === void 0 ? null : t.upperBound(r, !!e) : r === void 0 ? t.lowerBound(n, !!i) : t.bound(n, r, !!i, !!e);
			}
			function i(e) {
				var t, n, i = e.name;
				return {
					name: i,
					schema: e,
					mutate: function(e) {
						var t = e.trans, n = e.type, a = e.keys, o = e.values, s = e.range;
						return new Promise(function(e, c) {
							e = U(e);
							var l = t.objectStore(i), u = l.keyPath == null, d = n === "put" || n === "add";
							if (!d && n !== "delete" && n !== "deleteRange") throw Error("Invalid operation type: " + n);
							var f, p = (a || o || { length: 1 }).length;
							if (a && o && a.length !== o.length) throw Error("Given keys array must have same length as given values array.");
							if (p === 0) return e({
								numFailures: 0,
								failures: {},
								results: [],
								lastResult: void 0
							});
							function m(e) {
								++_, Ht(e);
							}
							var h = [], g = [], _ = 0;
							if (n === "deleteRange") {
								if (s.type === 4) return e({
									numFailures: _,
									failures: g,
									results: [],
									lastResult: void 0
								});
								s.type === 3 ? h.push(f = l.clear()) : h.push(f = l.delete(r(s)));
							} else {
								var u = d ? u ? [o, a] : [o, null] : [a, null], v = u[0], y = u[1];
								if (d) for (var b = 0; b < p; ++b) h.push(f = y && y[b] !== void 0 ? l[n](v[b], y[b]) : l[n](v[b])), f.onerror = m;
								else for (b = 0; b < p; ++b) h.push(f = l[n](v[b])), f.onerror = m;
							}
							function x(t) {
								t = t.target.result, h.forEach(function(e, t) {
									return e.error != null && (g[t] = e.error);
								}), e({
									numFailures: _,
									failures: g,
									results: n === "delete" ? a : h.map(function(e) {
										return e.result;
									}),
									lastResult: t
								});
							}
							f.onerror = function(e) {
								m(e), x(e);
							}, f.onsuccess = x;
						});
					},
					getMany: function(e) {
						var t = e.trans, n = e.keys;
						return new Promise(function(e, r) {
							e = U(e);
							for (var a, o = t.objectStore(i), s = n.length, c = Array(s), l = 0, u = 0, d = function(t) {
								t = t.target, c[t._pos] = t.result, ++u === l && e(c);
							}, f = Y(r), p = 0; p < s; ++p) n[p] != null && ((a = o.get(n[p]))._pos = p, a.onsuccess = d, a.onerror = f, ++l);
							l === 0 && e(c);
						});
					},
					get: function(e) {
						var t = e.trans, n = e.key;
						return new Promise(function(e, r) {
							e = U(e);
							var a = t.objectStore(i).get(n);
							a.onsuccess = function(t) {
								return e(t.target.result);
							}, a.onerror = Y(r);
						});
					},
					query: (t = c, n = l, function(e) {
						return new Promise(function(a, o) {
							a = U(a);
							var s, c, l, u, d = e.trans, f = e.values, p = e.limit, m = e.query, h = (h = e.direction) ?? "next", g = p === 1 / 0 ? void 0 : p, _ = m.index, m = m.range, d = d.objectStore(i), d = _.isPrimaryKey ? d : d.index(_.name), _ = r(m);
							if (p === 0) return a({ result: [] });
							n ? (m = {
								query: _,
								count: g,
								direction: h
							}, (s = f ? d.getAll(m) : d.getAllKeys(m)).onsuccess = function(e) {
								return a({ result: e.target.result });
							}, s.onerror = Y(o)) : t && h === "next" ? ((s = f ? d.getAll(_, g) : d.getAllKeys(_, g)).onsuccess = function(e) {
								return a({ result: e.target.result });
							}, s.onerror = Y(o)) : (c = 0, l = !f && "openKeyCursor" in d ? d.openKeyCursor(_, h) : d.openCursor(_, h), u = [], l.onsuccess = function() {
								var e = l.result;
								return !e || (u.push(f ? e.value : e.primaryKey), ++c === p) ? a({ result: u }) : void e.continue();
							}, l.onerror = Y(o));
						});
					}),
					openCursor: function(e) {
						var t = e.trans, n = e.values, a = e.query, o = e.reverse, s = e.unique;
						return new Promise(function(e, c) {
							e = U(e);
							var l = a.index, u = a.range, d = t.objectStore(i), d = l.isPrimaryKey ? d : d.index(l.name), l = o ? s ? "prevunique" : "prev" : s ? "nextunique" : "next", f = !n && "openKeyCursor" in d ? d.openKeyCursor(r(u), l) : d.openCursor(r(u), l);
							f.onerror = Y(c), f.onsuccess = U(function(n) {
								var r, i, a, o, s = f.result;
								s ? (s.___id = ++en, s.done = !1, r = s.continue.bind(s), i = (i = s.continuePrimaryKey) && i.bind(s), a = s.advance.bind(s), o = function() {
									throw Error("Cursor not stopped");
								}, s.trans = t, s.stop = s.continue = s.continuePrimaryKey = s.advance = function() {
									throw Error("Cursor not started");
								}, s.fail = U(c), s.next = function() {
									var e = this, t = 1;
									return this.start(function() {
										return t-- ? e.continue() : e.stop();
									}).then(function() {
										return e;
									});
								}, s.start = function(e) {
									function t() {
										if (f.result) try {
											e();
										} catch (e) {
											s.fail(e);
										}
										else s.done = !0, s.start = function() {
											throw Error("Cursor behind last entry");
										}, s.stop();
									}
									var n = new Promise(function(e, t) {
										e = U(e), f.onerror = Y(t), s.fail = t, s.stop = function(t) {
											s.stop = s.continue = s.continuePrimaryKey = s.advance = o, e(t);
										};
									});
									return f.onsuccess = U(function(e) {
										f.onsuccess = t, t();
									}), s.continue = r, s.continuePrimaryKey = i, s.advance = a, t(), n;
								}, e(s)) : e(null);
							}, c);
						});
					},
					count: function(e) {
						var t = e.query, n = e.trans, a = t.index, o = t.range;
						return new Promise(function(e, t) {
							var s = n.objectStore(i), s = a.isPrimaryKey ? s : s.index(a.name), c = r(o), c = c ? s.count(c) : s.count();
							c.onsuccess = U(function(t) {
								return e(t.target.result);
							}), c.onerror = Y(t);
						});
					}
				};
			}
			o = n, s = $t((n = e).objectStoreNames), u = 0 < s.length ? o.objectStore(s[0]) : {};
			var o, n = {
				schema: {
					name: n.name,
					tables: s.map(function(e) {
						return o.objectStore(e);
					}).map(function(e) {
						var t = e.keyPath, n = e.autoIncrement, r = a(t), i = {}, r = {
							name: e.name,
							primaryKey: {
								name: null,
								isPrimaryKey: !0,
								outbound: t == null,
								compound: r,
								keyPath: t,
								autoIncrement: n,
								unique: !0,
								extractKey: Qt(t)
							},
							indexes: $t(e.indexNames).map(function(t) {
								return e.index(t);
							}).map(function(e) {
								var t = e.name, n = e.unique, r = e.multiEntry, e = e.keyPath, t = {
									name: t,
									compound: a(e),
									keyPath: e,
									unique: n,
									multiEntry: r,
									extractKey: Qt(e)
								};
								return i[tn(e)] = t;
							}),
							getIndexByKeyPath: function(e) {
								return i[tn(e)];
							}
						};
						return i[":id"] = r.primaryKey, t != null && (i[tn(t)] = r.primaryKey), r;
					})
				},
				hasGetAll: 0 < s.length && "getAll" in u && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604),
				hasIdb3Features: "getAllRecords" in u
			}, s = n.schema, c = n.hasGetAll, l = n.hasIdb3Features, u = s.tables.map(i), d = {};
			return u.forEach(function(e) {
				return d[e.name] = e;
			}), {
				stack: "dbcore",
				transaction: e.transaction.bind(e),
				table: function(e) {
					if (d[e]) return d[e];
					throw Error(`Table '${e}' not found`);
				},
				MIN_KEY: -1 / 0,
				MAX_KEY: Zt(t),
				schema: s
			};
		}
		function rn(e, n, r, i) {
			return r = r.IDBKeyRange, n = nn(n, r, i), { dbcore: e.dbcore.reduce(function(e, n) {
				return n = n.create, t(t({}, e), n(e));
			}, n) };
		}
		function an(e, t) {
			var n = t.db, n = rn(e._middlewares, n, e._deps, t);
			e.core = n.dbcore, e.tables.forEach(function(t) {
				var n = t.name;
				e.core.schema.tables.some(function(e) {
					return e.name === n;
				}) && (t.core = e.core.table(n), e[n] instanceof e.Table) && (e[n].core = t.core);
			});
		}
		function on(e, t, n, r) {
			n.forEach(function(n) {
				var i = r[n];
				t.forEach(function(t) {
					var r = function e(t, n) {
						return m(t, n) || (t = s(t)) && e(t, n);
					}(t, n);
					(!r || "value" in r && r.value === void 0) && (t === e.Transaction.prototype || t instanceof e.Transaction ? f(t, n, {
						get: function() {
							return this.table(n);
						},
						set: function(e) {
							d(this, n, {
								value: e,
								writable: !0,
								configurable: !0,
								enumerable: !0
							});
						}
					}) : t[n] = new e.Table(n, i));
				});
			});
		}
		function sn(e, t) {
			t.forEach(function(t) {
				for (var n in t) t[n] instanceof e.Table && delete t[n];
			});
		}
		function cn(e, t) {
			return e._cfg.version - t._cfg.version;
		}
		function ln(e, t, n, r) {
			var a = e._dbSchema, o = (n.objectStoreNames.contains("$meta") && !a.$meta && (a.$meta = Xt("$meta", _n("")[0], []), e._storeNames.push("$meta")), e._createTransaction("readwrite", e._storeNames, a)), s = (o.create(n), o._completion.catch(r), o._reject.bind(o)), c = B.transless || B;
			Xe(function() {
				if (B.trans = o, B.transless = c, t !== 0) return an(e, n), l = t, ((r = o).storeNames.includes("$meta") ? r.table("$meta").get("version").then(function(e) {
					return e ?? l;
				}) : V.resolve(l)).then(function(t) {
					var r = e, a = t, s = o, c = n, l = [], t = r._versions, u = r._dbSchema = hn(0, r.idbdb, c);
					return (t = t.filter(function(e) {
						return e._cfg.version >= a;
					})).length === 0 ? V.resolve() : (t.forEach(function(e) {
						l.push(function() {
							var t, n, o, l = u, d = e._cfg.dbschema, f = (gn(r, l, c), gn(r, d, c), u = r._dbSchema = d, dn(l, d)), p = (f.add.forEach(function(e) {
								fn(c, e[0], e[1].primKey, e[1].indexes);
							}), f.change.forEach(function(e) {
								if (e.recreate) throw new L.Upgrade("Not yet support for changing primary key");
								var t = c.objectStore(e.name);
								e.add.forEach(function(e) {
									return mn(t, e);
								}), e.change.forEach(function(e) {
									t.deleteIndex(e.name), mn(t, e);
								}), e.del.forEach(function(e) {
									return t.deleteIndex(e);
								});
							}), e._cfg.contentUpgrade);
							if (p && e._cfg.version > a) return an(r, c), s._memoizedTables = {}, t = S(d), f.del.forEach(function(e) {
								t[e] = l[e];
							}), sn(r, [r.Transaction.prototype]), on(r, [r.Transaction.prototype], i(t), t), s.schema = t, (n = ne(p)) && Ze(), d = V.follow(function() {
								var e;
								(o = p(s)) && n && (e = Qe.bind(null, null), o.then(e, e));
							}), o && typeof o.then == "function" ? V.resolve(o) : d.then(function() {
								return o;
							});
						}), l.push(function(t) {
							var n = e._cfg.dbschema, i = t;
							[].slice.call(i.db.objectStoreNames).forEach(function(e) {
								return n[e] == null && i.db.deleteObjectStore(e);
							}), sn(r, [r.Transaction.prototype]), on(r, [r.Transaction.prototype], r._storeNames, r._dbSchema), s.schema = r._dbSchema;
						}), l.push(function(t) {
							r.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(r.idbdb.version / 10) === e._cfg.version ? (r.idbdb.deleteObjectStore("$meta"), delete r._dbSchema.$meta, r._storeNames = r._storeNames.filter(function(e) {
								return e !== "$meta";
							})) : t.objectStore("$meta").put(e._cfg.version, "version"));
						});
					}), function e() {
						return l.length ? V.resolve(l.shift()(s.idbtrans)).then(e) : V.resolve();
					}().then(function() {
						pn(u, c);
					}));
				}).catch(s);
				var r, l;
				i(a).forEach(function(e) {
					fn(n, e, a[e].primKey, a[e].indexes);
				}), an(e, n), V.follow(function() {
					return e.on.populate.fire(o);
				}).catch(s);
			});
		}
		function un(e, t) {
			pn(e._dbSchema, t), t.db.version % 10 != 0 || t.objectStoreNames.contains("$meta") || t.db.createObjectStore("$meta").add(Math.ceil(t.db.version / 10 - 1), "version");
			var n = hn(0, e.idbdb, t);
			gn(e, e._dbSchema, t);
			for (var r = 0, i = dn(n, e._dbSchema).change; r < i.length; r++) {
				var a = ((e) => {
					if (e.change.length || e.recreate) return console.warn(`Unable to patch indexes of table ${e.name} because it has changes on the type of index or primary key.`), { value: void 0 };
					var n = t.objectStore(e.name);
					e.add.forEach(function(t) {
						ge && console.debug(`Dexie upgrade patch: Creating missing index ${e.name}.${t.src}`), mn(n, t);
					});
				})(i[r]);
				if (typeof a == "object") return a.value;
			}
		}
		function dn(e, t) {
			var n, r = {
				del: [],
				add: [],
				change: []
			};
			for (n in e) t[n] || r.del.push(n);
			for (n in t) {
				var i = e[n], a = t[n];
				if (i) {
					var o = {
						name: n,
						def: a,
						recreate: !1,
						del: [],
						add: [],
						change: []
					};
					if ("" + (i.primKey.keyPath || "") != "" + (a.primKey.keyPath || "") || i.primKey.auto !== a.primKey.auto) o.recreate = !0, r.change.push(o);
					else {
						var s = i.idxByName, c = a.idxByName, l = void 0;
						for (l in s) c[l] || o.del.push(l);
						for (l in c) {
							var u = s[l], d = c[l];
							u ? u.src !== d.src && o.change.push(d) : o.add.push(d);
						}
						(0 < o.del.length || 0 < o.add.length || 0 < o.change.length) && r.change.push(o);
					}
				} else r.add.push([n, a]);
			}
			return r;
		}
		function fn(e, t, n, r) {
			var i = e.db.createObjectStore(t, n.keyPath ? {
				keyPath: n.keyPath,
				autoIncrement: n.auto
			} : { autoIncrement: n.auto });
			r.forEach(function(e) {
				return mn(i, e);
			});
		}
		function pn(e, t) {
			i(e).forEach(function(n) {
				t.db.objectStoreNames.contains(n) || (ge && console.debug("Dexie: Creating missing table", n), fn(t, n, e[n].primKey, e[n].indexes));
			});
		}
		function mn(e, t) {
			e.createIndex(t.name, t.keyPath, {
				unique: t.unique,
				multiEntry: t.multi
			});
		}
		function hn(e, t, n) {
			var r = {};
			return g(t.objectStoreNames, 0).forEach(function(e) {
				for (var t = n.objectStore(e), i = Jt(Yt(c = t.keyPath), c || "", !0, !1, !!t.autoIncrement, c && typeof c != "string", !0), a = [], o = 0; o < t.indexNames.length; ++o) {
					var s = t.index(t.indexNames[o]), c = s.keyPath, s = Jt(s.name, c, !!s.unique, !!s.multiEntry, !1, c && typeof c != "string", !1);
					a.push(s);
				}
				r[e] = Xt(e, i, a);
			}), r;
		}
		function gn(e, t, n) {
			for (var i = n.db.objectStoreNames, a = 0; a < i.length; ++a) {
				var o = i[a], s = n.objectStore(o);
				e._hasGetAll = "getAll" in s;
				for (var c = 0; c < s.indexNames.length; ++c) {
					var l, u = s.indexNames[c], d = s.index(u).keyPath, d = typeof d == "string" ? d : "[" + g(d).join("+") + "]";
					t[o] && (l = t[o].idxByName[d]) && (l.name = u, delete t[o].idxByName[d], t[o].idxByName[u] = l);
				}
			}
			typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && r.WorkerGlobalScope && r instanceof r.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1);
		}
		function _n(e) {
			return e.split(",").map(function(e, t) {
				var n = e.split(":"), r = (r = n[1])?.trim(), n = (e = n[0].trim()).replace(/([&*]|\+\+)/g, ""), i = /^\[/.test(n) ? n.match(/^\[(.*)\]$/)[1].split("+") : n;
				return Jt(n, i || null, /\&/.test(e), /\*/.test(e), /\+\+/.test(e), a(i), t === 0, r);
			});
		}
		yn.prototype._createTableSchema = Xt, yn.prototype._parseIndexSyntax = _n, yn.prototype._parseStoresSpec = function(e, t) {
			var n = this;
			i(e).forEach(function(r) {
				if (e[r] !== null) {
					var i = n._parseIndexSyntax(e[r]), a = i.shift();
					if (!a) throw new L.Schema("Invalid schema for table " + r + ": " + e[r]);
					if (a.unique = !0, a.multi) throw new L.Schema("Primary key cannot be multiEntry*");
					i.forEach(function(e) {
						if (e.auto) throw new L.Schema("Only primary key can be marked as autoIncrement (++)");
						if (!e.keyPath) throw new L.Schema("Index must have a name and cannot be an empty string");
					}), a = n._createTableSchema(r, a, i), t[r] = a;
				}
			});
		}, yn.prototype.stores = function(e) {
			var t = this.db, e = (this._cfg.storesSource = this._cfg.storesSource ? o(this._cfg.storesSource, e) : e, t._versions), n = {}, r = {};
			return e.forEach(function(e) {
				o(n, e._cfg.storesSource), r = e._cfg.dbschema = {}, e._parseStoresSpec(n, r);
			}), t._dbSchema = r, sn(t, [
				t._allTables,
				t,
				t.Transaction.prototype
			]), on(t, [
				t._allTables,
				t,
				t.Transaction.prototype,
				this._cfg.tables
			], i(r), r), t._storeNames = i(r), this;
		}, yn.prototype.upgrade = function(e) {
			return this._cfg.contentUpgrade = he(this._cfg.contentUpgrade || z, e), this;
		};
		var vn = yn;
		function yn() {}
		var bn = (() => {
			var e, t, n;
			return typeof FinalizationRegistry < "u" && typeof WeakRef < "u" ? (e = /* @__PURE__ */ new Set(), t = new FinalizationRegistry(function(t) {
				e.delete(t);
			}), {
				toArray: function() {
					return Array.from(e).map(function(e) {
						return e.deref();
					}).filter(function(e) {
						return e !== void 0;
					});
				},
				add: function(n) {
					var r = new WeakRef(n._novip);
					e.add(r), t.register(n._novip, r, r), e.size > n._options.maxConnections && (r = e.values().next().value, e.delete(r), t.unregister(r));
				},
				remove: function(n) {
					if (n) for (var r = e.values(), i = r.next(); !i.done;) {
						var a = i.value;
						if (a.deref() === n._novip) return e.delete(a), void t.unregister(a);
						i = r.next();
					}
				}
			}) : (n = [], {
				toArray: function() {
					return n;
				},
				add: function(e) {
					n.push(e._novip);
				},
				remove: function(e) {
					e && (e = n.indexOf(e._novip)) !== -1 && n.splice(e, 1);
				}
			});
		})();
		function xn(e, t) {
			var n = e._dbNamesDB;
			return n || (n = e._dbNamesDB = new or(W, {
				addons: [],
				indexedDB: e,
				IDBKeyRange: t
			})).version(1).stores({ dbnames: "name" }), n.table("dbnames");
		}
		function Sn(e) {
			return e && typeof e.databases == "function";
		}
		function Cn(e) {
			return Xe(function() {
				return B.letThrough = !0, e();
			});
		}
		function wn(e) {
			return !("from" in e);
		}
		var Tn = function(e, t) {
			var n;
			if (!this) return n = new Tn(), e && "d" in e && o(n, e), n;
			o(this, arguments.length ? {
				d: 1,
				from: e,
				to: 1 < arguments.length ? t : e
			} : { d: 0 });
		};
		function En(e, t, n) {
			var r = G(t, n);
			if (!isNaN(r)) {
				if (0 < r) throw RangeError();
				if (wn(e)) return o(e, {
					from: t,
					to: n,
					d: 1
				});
				var r = e.l, i = e.r;
				if (G(n, e.from) < 0) return r ? En(r, t, n) : e.l = {
					from: t,
					to: n,
					d: 1,
					l: null,
					r: null
				}, An(e);
				if (0 < G(t, e.to)) return i ? En(i, t, n) : e.r = {
					from: t,
					to: n,
					d: 1,
					l: null,
					r: null
				}, An(e);
				G(t, e.from) < 0 && (e.from = t, e.l = null, e.d = i ? i.d + 1 : 1), 0 < G(n, e.to) && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1), t = !e.r, r && !e.l && Dn(e, r), i && t && Dn(e, i);
			}
		}
		function Dn(e, t) {
			wn(t) || function e(t, n) {
				var r = n.from, i = n.l, a = n.r;
				En(t, r, n.to), i && e(t, i), a && e(t, a);
			}(e, t);
		}
		function On(e, t) {
			var n = kn(t), r = n.next();
			if (!r.done) for (var i = r.value, a = kn(e), o = a.next(i.from), s = o.value; !r.done && !o.done;) {
				if (G(s.from, i.to) <= 0 && 0 <= G(s.to, i.from)) return !0;
				G(i.from, s.from) < 0 ? i = (r = n.next(s.from)).value : s = (o = a.next(i.from)).value;
			}
			return !1;
		}
		function kn(e) {
			var t = wn(e) ? null : {
				s: 0,
				n: e
			};
			return { next: function(e) {
				for (var n = 0 < arguments.length; t;) switch (t.s) {
					case 0: if (t.s = 1, n) for (; t.n.l && G(e, t.n.from) < 0;) t = {
						up: t,
						n: t.n.l,
						s: 1
					};
					else for (; t.n.l;) t = {
						up: t,
						n: t.n.l,
						s: 1
					};
					case 1: if (t.s = 2, !n || G(e, t.n.to) <= 0) return {
						value: t.n,
						done: !1
					};
					case 2: if (t.n.r) {
						t.s = 3, t = {
							up: t,
							n: t.n.r,
							s: 0
						};
						continue;
					}
					case 3: t = t.up;
				}
				return { done: !0 };
			} };
		}
		function An(e) {
			var n, r, i, a = ((a = e.r)?.d || 0) - ((a = e.l)?.d || 0), a = 1 < a ? "r" : a < -1 ? "l" : "";
			a && (n = a == "r" ? "l" : "r", r = t({}, e), i = e[a], e.from = i.from, e.to = i.to, e[a] = i[a], r[a] = i[n], (e[n] = r).d = jn(r)), e.d = jn(e);
		}
		function jn(e) {
			var t = e.r, e = e.l;
			return (t ? e ? Math.max(t.d, e.d) : t.d : e ? e.d : 0) + 1;
		}
		function Mn(e, t) {
			return i(t).forEach(function(n) {
				e[n] ? Dn(e[n], t[n]) : e[n] = function e(t) {
					var n, r, i = {};
					for (n in t) l(t, n) && (r = t[n], i[n] = !r || typeof r != "object" || E.has(r.constructor) ? r : e(r));
					return i;
				}(t[n]);
			}), e;
		}
		function Nn(e, t) {
			return e.all || t.all || Object.keys(e).some(function(n) {
				return t[n] && On(t[n], e[n]);
			});
		}
		u(Tn.prototype, ((P = {
			add: function(e) {
				return Dn(this, e), this;
			},
			addKey: function(e) {
				return En(this, e, e), this;
			},
			addKeys: function(e) {
				var t = this;
				return e.forEach(function(e) {
					return En(t, e, e);
				}), this;
			},
			hasKey: function(e) {
				var t = kn(this).next(e).value;
				return t && G(t.from, e) <= 0 && 0 <= G(t.to, e);
			}
		})[A] = function() {
			return kn(this);
		}, P));
		var Pn = {}, Fn = {}, In = !1;
		function Ln(e) {
			Mn(Fn, e), In || (In = !0, setTimeout(function() {
				In = !1, Rn(Fn, !(Fn = {}));
			}, 0));
		}
		function Rn(e, t) {
			t === void 0 && (t = !1);
			var n = /* @__PURE__ */ new Set();
			if (e.all) for (var r = 0, i = Object.values(Pn); r < i.length; r++) zn(s = i[r], e, n, t);
			else for (var a in e) {
				var o, s, a = /^idb\:\/\/(.*)\/(.*)\//.exec(a);
				a && (o = a[1], a = a[2], s = Pn[`idb://${o}/${a}`]) && zn(s, e, n, t);
			}
			n.forEach(function(e) {
				return e();
			});
		}
		function zn(e, t, n, r) {
			for (var i = [], a = 0, o = Object.entries(e.queries.query); a < o.length; a++) {
				for (var s = o[a], c = s[0], l = [], u = 0, d = s[1]; u < d.length; u++) {
					var f = d[u];
					Nn(t, f.obsSet) ? f.subscribers.forEach(function(e) {
						return n.add(e);
					}) : r && l.push(f);
				}
				r && i.push([c, l]);
			}
			if (r) for (var p = 0, m = i; p < m.length; p++) {
				var h = m[p], c = h[0], l = h[1];
				e.queries.query[c] = l;
			}
		}
		function Bn(e) {
			var t = e._state, n = e._deps.indexedDB;
			if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
				return t.dbOpenError ? ot(t.dbOpenError) : e;
			});
			t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
			var r = t.openCanceller, a = Math.round(10 * e.verno), o = !1;
			function s() {
				if (t.openCanceller !== r) throw new L.DatabaseClosed("db.open() was cancelled");
			}
			function c() {
				return new V(function(r, l) {
					if (s(), !n) throw new L.MissingAPI();
					var u = e.name, p = t.autoSchema || !a ? n.open(u) : n.open(u, a);
					if (!p) throw new L.MissingAPI();
					p.onerror = Y(l), p.onblocked = U(e._fireOnBlocked), p.onupgradeneeded = U(function(r) {
						var i;
						d = p.transaction, t.autoSchema && !e._options.allowEmptyDB ? (p.onerror = Ht, d.abort(), p.result.close(), (i = n.deleteDatabase(u)).onsuccess = i.onerror = U(function() {
							l(new L.NoSuchDatabase(`Database ${u} doesnt exist`));
						})) : (d.onerror = Y(l), i = r.oldVersion > 2 ** 62 ? 0 : r.oldVersion, f = i < 1, e.idbdb = p.result, o && un(e, d), ln(e, i / 10, d, l));
					}, l), p.onsuccess = U(function() {
						d = null;
						var n, s, l, m, h, _, v = e.idbdb = p.result, y = g(v.objectStoreNames);
						if (0 < y.length) try {
							var b = v.transaction((h = y).length === 1 ? h[0] : h, "readonly");
							if (t.autoSchema) _ = v, m = b, (l = e).verno = _.version / 10, m = l._dbSchema = hn(0, _, m), l._storeNames = g(_.objectStoreNames, 0), on(l, [l._allTables], i(m), m);
							else if (gn(e, e._dbSchema, b), s = b, ((s = dn(hn(0, (n = e).idbdb, s), n._dbSchema)).add.length || s.change.some(function(e) {
								return e.add.length || e.change.length;
							})) && !o) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), v.close(), a = v.version + 1, o = !0, r(c());
							an(e, b);
						} catch {}
						bn.add(e), v.onversionchange = U(function(n) {
							t.vcFired = !0, e.on("versionchange").fire(n);
						}), v.onclose = U(function() {
							e.close({ disableAutoOpen: !1 });
						}), f && (y = e._deps, h = u, Sn(_ = y.indexedDB) || h === W || xn(_, y.IDBKeyRange).put({ name: h }).catch(z)), r();
					}, l);
				}).catch(function(e) {
					switch (e?.name) {
						case "UnknownError":
							if (0 < t.PR1398_maxLoop) return t.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), c();
							break;
						case "VersionError": if (0 < a) return a = 0, c();
					}
					return V.reject(e);
				});
			}
			var l, u = t.dbReadyResolve, d = null, f = !1;
			return V.race([r, (typeof navigator > "u" ? V.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(e) {
				function t() {
					return indexedDB.databases().finally(e);
				}
				l = setInterval(t, 100), t();
			}).finally(function() {
				return clearInterval(l);
			}) : Promise.resolve()).then(c)]).then(function() {
				return s(), t.onReadyBeingFired = [], V.resolve(Cn(function() {
					return e.on.ready.fire(e.vip);
				})).then(function n() {
					var r;
					if (0 < t.onReadyBeingFired.length) return r = t.onReadyBeingFired.reduce(he, z), t.onReadyBeingFired = [], V.resolve(Cn(function() {
						return r(e.vip);
					})).then(n);
				});
			}).finally(function() {
				t.openCanceller === r && (t.onReadyBeingFired = null, t.isBeingOpened = !1);
			}).catch(function(n) {
				t.dbOpenError = n;
				try {
					d && d.abort();
				} catch {}
				return r === t.openCanceller && e._close(), ot(n);
			}).finally(function() {
				t.openComplete = !0, u();
			}).then(function() {
				var t;
				return f && (t = {}, e.tables.forEach(function(n) {
					n.schema.indexes.forEach(function(r) {
						r.name && (t[`idb://${e.name}/${n.name}/${r.name}`] = new Tn(-1 / 0, [[[]]]));
					}), t[`idb://${e.name}/${n.name}/`] = t[`idb://${e.name}/${n.name}/:dels`] = new Tn(-1 / 0, [[[]]]);
				}), Gt(Ut).fire(t), Rn(t, !0)), e;
			});
		}
		function Vn(e) {
			function t(t) {
				return e.next(t);
			}
			var n = i(t), r = i(function(t) {
				return e.throw(t);
			});
			function i(e) {
				return function(t) {
					var t = e(t), i = t.value;
					return t.done ? i : i && typeof i.then == "function" ? i.then(n, r) : a(i) ? Promise.all(i).then(n, r) : n(i);
				};
			}
			return i(t)();
		}
		function Hn(e, t, n) {
			for (var r = a(e) ? e.slice() : [e], i = 0; i < n; ++i) r.push(t);
			return r;
		}
		var Un = {
			stack: "dbcore",
			name: "VirtualIndexMiddleware",
			level: 1,
			create: function(e) {
				return t(t({}, e), { table: function(n) {
					var r = e.table(n), n = r.schema, i = Object.create(null), a = [];
					function o(e, n, r) {
						var s = tn(e), c = i[s] = i[s] || [], l = e == null ? 0 : typeof e == "string" ? 1 : e.length, u = 0 < n, s = t(t({}, r), {
							name: u ? `${s}(virtual-from:${r.name})` : r.name,
							lowLevelIndex: r,
							isVirtual: u,
							keyTail: n,
							keyLength: l,
							extractKey: Qt(e),
							unique: !u && r.unique
						});
						return c.push(s), s.isPrimaryKey || a.push(s), 1 < l && o(l === 2 ? e[0] : e.slice(0, l - 1), n + 1, r), c.sort(function(e, t) {
							return e.keyTail - t.keyTail;
						}), s;
					}
					var s = o(n.primaryKey.keyPath, 0, n.primaryKey);
					i[":id"] = [s];
					for (var c = 0, l = n.indexes; c < l.length; c++) {
						var u = l[c];
						o(u.keyPath, 0, u);
					}
					function d(n) {
						var r, i = n.query.index;
						return i.isVirtual ? t(t({}, n), { query: {
							index: i.lowLevelIndex,
							range: (r = n.query.range, i = i.keyTail, {
								type: r.type === 1 ? 2 : r.type,
								lower: Hn(r.lower, r.lowerOpen ? e.MAX_KEY : e.MIN_KEY, i),
								lowerOpen: !0,
								upper: Hn(r.upper, r.upperOpen ? e.MIN_KEY : e.MAX_KEY, i),
								upperOpen: !0
							})
						} }) : n;
					}
					return t(t({}, r), {
						schema: t(t({}, n), {
							primaryKey: s,
							indexes: a,
							getIndexByKeyPath: function(e) {
								return (e = i[tn(e)]) && e[0];
							}
						}),
						count: function(e) {
							return r.count(d(e));
						},
						query: function(e) {
							return r.query(d(e));
						},
						openCursor: function(t) {
							var n = t.query.index, i = n.keyTail, a = n.keyLength;
							return n.isVirtual ? r.openCursor(d(t)).then(function(e) {
								return e && o(e);
							}) : r.openCursor(t);
							function o(n) {
								return Object.create(n, {
									continue: { value: function(r) {
										r == null ? t.unique ? n.continue(n.key.slice(0, a).concat(t.reverse ? e.MIN_KEY : e.MAX_KEY, i)) : n.continue() : n.continue(Hn(r, t.reverse ? e.MAX_KEY : e.MIN_KEY, i));
									} },
									continuePrimaryKey: { value: function(t, r) {
										n.continuePrimaryKey(Hn(t, e.MAX_KEY, i), r);
									} },
									primaryKey: { get: function() {
										return n.primaryKey;
									} },
									key: { get: function() {
										var e = n.key;
										return a === 1 ? e[0] : e.slice(0, a);
									} },
									value: { get: function() {
										return n.value;
									} }
								});
							}
						}
					});
				} });
			}
		};
		function Wn(e, t, n, r) {
			return n ||= {}, r ||= "", i(e).forEach(function(i) {
				var a, o, s;
				l(t, i) ? (a = e[i], o = t[i], typeof a == "object" && typeof o == "object" && a && o ? (s = k(a)) === k(o) ? s === "Object" ? Wn(a, o, n, r + i + ".") : a !== o && (n[r + i] = t[i]) : n[r + i] = t[i] : a !== o && (n[r + i] = t[i])) : n[r + i] = void 0;
			}), i(t).forEach(function(i) {
				l(e, i) || (n[r + i] = t[i]);
			}), n;
		}
		function Gn(e, t) {
			return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey);
		}
		var Kn = {
			stack: "dbcore",
			name: "HooksMiddleware",
			level: 2,
			create: function(e) {
				return t(t({}, e), { table: function(r) {
					var i = e.table(r), a = i.schema.primaryKey;
					return t(t({}, i), { mutate: function(e) {
						var o = B.trans, s = o.table(r).hook, c = s.deleting, u = s.creating, d = s.updating;
						switch (e.type) {
							case "add":
								if (u.fire === z) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "put":
								if (u.fire === z && d.fire === z) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "delete":
								if (c.fire === z) break;
								return o._promise("readwrite", function() {
									return f(e);
								}, !0);
							case "deleteRange":
								if (c.fire === z) break;
								return o._promise("readwrite", function() {
									return function e(n, r, o) {
										return i.query({
											trans: n,
											values: !1,
											query: {
												index: a,
												range: r
											},
											limit: o
										}).then(function(i) {
											var a = i.result;
											return f({
												type: "delete",
												keys: a,
												trans: n
											}).then(function(i) {
												return 0 < i.numFailures ? Promise.reject(i.failures[0]) : a.length < o ? {
													failures: [],
													numFailures: 0,
													lastResult: void 0
												} : e(n, t(t({}, r), {
													lower: a[a.length - 1],
													lowerOpen: !0
												}), o);
											});
										});
									}(e.trans, e.range, 1e4);
								}, !0);
						}
						return i.mutate(e);
						function f(e) {
							var r, o, s, f = B.trans, p = e.keys || Gn(a, e);
							if (p) return (e = e.type === "add" || e.type === "put" ? t(t({}, e), { keys: p }) : t({}, e)).type !== "delete" && (e.values = n([], e.values, !0)), e.keys && (e.keys = n([], e.keys, !0)), r = i, s = p, ((o = e).type === "add" ? Promise.resolve([]) : r.getMany({
								trans: o.trans,
								keys: s,
								cache: "immutable"
							})).then(function(t) {
								var n = p.map(function(n, r) {
									var i, o, s, p = t[r], m = {
										onerror: null,
										onsuccess: null
									};
									return e.type === "delete" ? c.fire.call(m, n, p, f) : e.type === "add" || p === void 0 ? (i = u.fire.call(m, n, e.values[r], f), n == null && i != null && (e.keys[r] = n = i, a.outbound || x(e.values[r], a.keyPath, n))) : (i = Wn(p, e.values[r]), (o = d.fire.call(m, i, n, p, f)) && (s = e.values[r], Object.keys(o).forEach(function(e) {
										l(s, e) ? s[e] = o[e] : x(s, e, o[e]);
									}))), m;
								});
								return i.mutate(e).then(function(r) {
									for (var i = r.failures, a = r.results, o = r.numFailures, r = r.lastResult, s = 0; s < p.length; ++s) {
										var c = (a || p)[s], l = n[s];
										c == null ? l.onerror && l.onerror(i[s]) : l.onsuccess && l.onsuccess(e.type === "put" && t[s] ? e.values[s] : c);
									}
									return {
										failures: i,
										results: a,
										numFailures: o,
										lastResult: r
									};
								}).catch(function(e) {
									return n.forEach(function(t) {
										return t.onerror && t.onerror(e);
									}), Promise.reject(e);
								});
							});
							throw Error("Keys missing");
						}
					} });
				} });
			}
		};
		function qn(e, t, n) {
			try {
				if (!t || t.keys.length < e.length) return null;
				for (var r = [], i = 0, a = 0; i < t.keys.length && a < e.length; ++i) G(t.keys[i], e[a]) === 0 && (r.push(n ? O(t.values[i]) : t.values[i]), ++a);
				return r.length === e.length ? r : null;
			} catch {
				return null;
			}
		}
		var Jn = {
			stack: "dbcore",
			level: -1,
			create: function(e) {
				return { table: function(n) {
					var r = e.table(n);
					return t(t({}, r), {
						getMany: function(e) {
							var t;
							return e.cache ? (t = qn(e.keys, e.trans._cache, e.cache === "clone")) ? V.resolve(t) : r.getMany(e).then(function(t) {
								return e.trans._cache = {
									keys: e.keys,
									values: e.cache === "clone" ? O(t) : t
								}, t;
							}) : r.getMany(e);
						},
						mutate: function(e) {
							return e.type !== "add" && (e.trans._cache = null), r.mutate(e);
						}
					});
				} };
			}
		};
		function Yn(e, t) {
			return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !t.schema.primaryKey.outbound;
		}
		function Xn(e, t) {
			switch (e) {
				case "query": return t.values && !t.unique;
				case "get":
				case "getMany":
				case "count":
				case "openCursor": return !1;
			}
		}
		var Zn = {
			stack: "dbcore",
			level: 0,
			name: "Observability",
			create: function(e) {
				var n = e.schema.name, r = new Tn(e.MIN_KEY, e.MAX_KEY);
				return t(t({}, e), {
					transaction: function(t, n, r) {
						if (B.subscr && n !== "readonly") throw new L.ReadOnly(`Readwrite transaction in liveQuery context. Querier source: ${B.querier}`);
						return e.transaction(t, n, r);
					},
					table: function(o) {
						function s(t) {
							var t = t.query;
							return [t.index, new Tn((t = t.range).lower ?? e.MIN_KEY, t.upper ?? e.MAX_KEY)];
						}
						var c = e.table(o), l = c.schema, u = l.primaryKey, d = l.indexes, f = u.extractKey, p = u.outbound, m = u.autoIncrement && d.filter(function(e) {
							return e.compound && e.keyPath.includes(u.keyPath);
						}), h = t(t({}, c), { mutate: function(t) {
							function i(e) {
								return e = `idb://${n}/${o}/${e}`, h[e] || (h[e] = new Tn());
							}
							var s, d, f, p = t.trans, h = t.mutatedParts ||= {}, g = i(""), _ = i(":dels"), v = t.type, y = t.type === "deleteRange" ? [t.range] : t.type === "delete" ? [t.keys] : t.values.length < 50 ? [Gn(u, t).filter(function(e) {
								return e;
							}), t.values] : [], b = y[0], y = y[1], x = t.trans._cache;
							return a(b) ? (g.addKeys(b), (v = v === "delete" || b.length === y.length ? qn(b, x) : null) || _.addKeys(b), (v || y) && (s = i, d = v, f = y, l.indexes.forEach(function(e) {
								var t = s(e.name || "");
								function n(t) {
									return t == null ? null : e.extractKey(t);
								}
								function r(n) {
									e.multiEntry && a(n) ? n.forEach(function(e) {
										return t.addKey(e);
									}) : t.addKey(n);
								}
								(d || f).forEach(function(e, t) {
									var i = d && n(d[t]), t = f && n(f[t]);
									G(i, t) !== 0 && (i != null && r(i), t != null) && r(t);
								});
							}))) : b ? (y = {
								from: (x = b.lower) ?? e.MIN_KEY,
								to: (v = b.upper) ?? e.MAX_KEY
							}, _.add(y), g.add(y)) : (g.add(r), _.add(r), l.indexes.forEach(function(e) {
								return i(e.name).add(r);
							})), c.mutate(t).then(function(e) {
								return !b || t.type !== "add" && t.type !== "put" || (g.addKeys(e.results), m && m.forEach(function(n) {
									for (var r = t.values.map(function(e) {
										return n.extractKey(e);
									}), a = n.keyPath.findIndex(function(e) {
										return e === u.keyPath;
									}), o = 0, s = e.results.length; o < s; ++o) r[o][a] = e.results[o];
									i(n.name).addKeys(r);
								})), p.mutatedParts = Mn(p.mutatedParts || {}, h), e;
							});
						} }), g = {
							get: function(e) {
								return [u, new Tn(e.key)];
							},
							getMany: function(e) {
								return [u, new Tn().addKeys(e.keys)];
							},
							count: s,
							query: s,
							openCursor: s
						};
						return i(g).forEach(function(e) {
							h[e] = function(i) {
								var a = B.subscr, s = !!a, l = Yn(B, c) && Xn(e, i) ? i.obsSet = {} : a;
								if (s) {
									var u, a = function(e) {
										return e = `idb://${n}/${o}/${e}`, l[e] || (l[e] = new Tn());
									}, d = a(""), m = a(":dels"), s = g[e](i), h = s[0], s = s[1];
									if ((e === "query" && h.isPrimaryKey && !i.values ? m : a(h.name || "")).add(s), !h.isPrimaryKey) {
										if (e !== "count") return u = e === "query" && p && i.values && c.query(t(t({}, i), { values: !1 })), c[e].apply(this, arguments).then(function(t) {
											if (e === "query") {
												if (p && i.values) return u.then(function(e) {
													return e = e.result, d.addKeys(e), t;
												});
												var n = i.values ? t.result.map(f) : t.result;
												(i.values ? d : m).addKeys(n);
											} else {
												var r, a;
												if (e === "openCursor") return a = i.values, (r = t) && Object.create(r, {
													key: { get: function() {
														return m.addKey(r.primaryKey), r.key;
													} },
													primaryKey: { get: function() {
														var e = r.primaryKey;
														return m.addKey(e), e;
													} },
													value: { get: function() {
														return a && d.addKey(r.primaryKey), r.value;
													} }
												});
											}
											return t;
										});
										m.add(r);
									}
								}
								return c[e].apply(this, arguments);
							};
						}), h;
					}
				});
			}
		};
		function Qn(e, n, r) {
			var i;
			return r.numFailures === 0 ? n : n.type === "deleteRange" || (i = n.keys ? n.keys.length : "values" in n && n.values ? n.values.length : 1, r.numFailures === i) ? null : (i = t({}, n), a(i.keys) && (i.keys = i.keys.filter(function(e, t) {
				return !(t in r.failures);
			})), "values" in i && a(i.values) && (i.values = i.values.filter(function(e, t) {
				return !(t in r.failures);
			})), i);
		}
		function $n(e, t) {
			return n = e, ((r = t).lower === void 0 || (r.lowerOpen ? 0 < G(n, r.lower) : 0 <= G(n, r.lower))) && (n = e, (r = t).upper === void 0 || (r.upperOpen ? G(n, r.upper) < 0 : G(n, r.upper) <= 0));
			var n, r;
		}
		function er(e, t, n, r, i, o) {
			var s, c, l, u, d, f, p;
			return !n || n.length === 0 || (s = t.query.index, c = s.multiEntry, l = t.query.range, u = r.schema.primaryKey.extractKey, d = s.extractKey, f = (s.lowLevelIndex || s).extractKey, (r = n.reduce(function(e, n) {
				var r = e, i = [];
				if (n.type === "add" || n.type === "put") for (var o = new Tn(), s = n.values.length - 1; 0 <= s; --s) {
					var f, p = n.values[s], m = u(p);
					!o.hasKey(m) && (f = d(p), c && a(f) ? f.some(function(e) {
						return $n(e, l);
					}) : $n(f, l)) && (o.addKey(m), i.push(p));
				}
				switch (n.type) {
					case "add":
						var h = new Tn().addKeys(t.values ? e.map(function(e) {
							return u(e);
						}) : e), r = e.concat(t.values ? i.filter(function(e) {
							return e = u(e), !h.hasKey(e) && (h.addKey(e), !0);
						}) : i.map(function(e) {
							return u(e);
						}).filter(function(e) {
							return !h.hasKey(e) && (h.addKey(e), !0);
						}));
						break;
					case "put":
						var g = new Tn().addKeys(n.values.map(function(e) {
							return u(e);
						}));
						r = e.filter(function(e) {
							return !g.hasKey(t.values ? u(e) : e);
						}).concat(t.values ? i : i.map(function(e) {
							return u(e);
						}));
						break;
					case "delete":
						var _ = new Tn().addKeys(n.keys);
						r = e.filter(function(e) {
							return !_.hasKey(t.values ? u(e) : e);
						});
						break;
					case "deleteRange":
						var v = n.range;
						r = e.filter(function(e) {
							return !$n(u(e), v);
						});
				}
				return r;
			}, e)) === e) ? e : (p = function(e, t) {
				return G(f(e), f(t)) || G(u(e), u(t));
			}, r.sort(t.direction === "prev" || t.direction === "prevunique" ? function(e, t) {
				return p(t, e);
			} : p), t.limit && t.limit < 1 / 0 && (r.length > t.limit ? r.length = t.limit : e.length === t.limit && r.length < t.limit && (i.dirty = !0)), o ? Object.freeze(r) : r);
		}
		function tr(e, t) {
			return G(e.lower, t.lower) === 0 && G(e.upper, t.upper) === 0 && !!e.lowerOpen == !!t.lowerOpen && !!e.upperOpen == !!t.upperOpen;
		}
		function nr(e, t) {
			return ((e, t, n, r) => {
				if (e === void 0) return t === void 0 ? 0 : -1;
				if (t === void 0) return 1;
				if ((e = G(e, t)) === 0) {
					if (n && r) return 0;
					if (n) return 1;
					if (r) return -1;
				}
				return e;
			})(e.lower, t.lower, e.lowerOpen, t.lowerOpen) <= 0 && 0 <= ((e, t, n, r) => {
				if (e === void 0) return t === void 0 ? 0 : 1;
				if (t === void 0) return -1;
				if ((e = G(e, t)) === 0) {
					if (n && r) return 0;
					if (n) return -1;
					if (r) return 1;
				}
				return e;
			})(e.upper, t.upper, e.upperOpen, t.upperOpen);
		}
		function rr(e, t, n, r) {
			e.subscribers.add(n), r.addEventListener("abort", function() {
				var r, i;
				e.subscribers.delete(n), e.subscribers.size === 0 && (r = e, i = t, setTimeout(function() {
					r.subscribers.size === 0 && j(i, r);
				}, 3e3));
			});
		}
		var ir = {
			stack: "dbcore",
			level: 0,
			name: "Cache",
			create: function(e) {
				var n = e.schema.name;
				return t(t({}, e), {
					transaction: function(t, r, i) {
						var a, o, s = e.transaction(t, r, i);
						return r === "readwrite" && (i = (a = new AbortController()).signal, s.addEventListener("abort", (o = function(i) {
							return function() {
								if (a.abort(), r === "readwrite") {
									for (var o = /* @__PURE__ */ new Set(), c = 0, l = t; c < l.length; c++) {
										var u = l[c], d = Pn[`idb://${n}/${u}`];
										if (d) {
											var f = e.table(u), p = d.optimisticOps.filter(function(e) {
												return e.trans === s;
											});
											if (s._explicit && i && s.mutatedParts) for (var m = 0, h = Object.values(d.queries.query); m < h.length; m++) for (var g = 0, _ = (b = h[m]).slice(); g < _.length; g++) Nn((x = _[g]).obsSet, s.mutatedParts) && (j(b, x), x.subscribers.forEach(function(e) {
												return o.add(e);
											}));
											else if (0 < p.length) {
												d.optimisticOps = d.optimisticOps.filter(function(e) {
													return e.trans !== s;
												});
												for (var v = 0, y = Object.values(d.queries.query); v < y.length; v++) for (var b, x, S, C = 0, w = (b = y[v]).slice(); C < w.length; C++) (x = w[C]).res != null && s.mutatedParts && (i && !x.dirty ? (S = Object.isFrozen(x.res), S = er(x.res, x.req, p, f, x, S), x.dirty ? (j(b, x), x.subscribers.forEach(function(e) {
													return o.add(e);
												})) : S !== x.res && (x.res = S, x.promise = V.resolve({ result: S }))) : (x.dirty && j(b, x), x.subscribers.forEach(function(e) {
													return o.add(e);
												})));
											}
										}
									}
									o.forEach(function(e) {
										return e();
									});
								}
							};
						})(!1), { signal: i }), s.addEventListener("error", o(!1), { signal: i }), s.addEventListener("complete", o(!0), { signal: i })), s;
					},
					table: function(r) {
						var i = e.table(r), a = i.schema.primaryKey;
						return t(t({}, i), {
							mutate: function(e) {
								var o, s = B.trans;
								return !a.outbound && s.db._options.cache !== "disabled" && !s.explicit && s.idbtrans.mode === "readwrite" && (o = Pn[`idb://${n}/${r}`]) ? (s = i.mutate(e), e.type !== "add" && e.type !== "put" || !(50 <= e.values.length || Gn(a, e).some(function(e) {
									return e == null;
								})) ? (o.optimisticOps.push(e), e.mutatedParts && Ln(e.mutatedParts), s.then(function(t) {
									0 < t.numFailures && (j(o.optimisticOps, e), (t = Qn(0, e, t)) && o.optimisticOps.push(t), e.mutatedParts) && Ln(e.mutatedParts);
								}), s.catch(function() {
									j(o.optimisticOps, e), e.mutatedParts && Ln(e.mutatedParts);
								})) : s.then(function(n) {
									var r = Qn(0, t(t({}, e), { values: e.values.map(function(e, r) {
										var i;
										return n.failures[r] ? e : (x(i = (i = a.keyPath) != null && i.includes(".") ? O(e) : t({}, e), a.keyPath, n.results[r]), i);
									}) }), n);
									o.optimisticOps.push(r), queueMicrotask(function() {
										return e.mutatedParts && Ln(e.mutatedParts);
									});
								}), s) : i.mutate(e);
							},
							query: function(e) {
								var t, a, o, s, c, l, u;
								return Yn(B, i) && Xn("query", e) ? (t = (o = B.trans)?.db._options.cache === "immutable", a = (o = B).requery, o = o.signal, l = ((e, t, n, r) => {
									var i = Pn[`idb://${e}/${t}`];
									if (!i) return [];
									if (!(e = i.queries[n])) return [
										null,
										!1,
										i,
										null
									];
									var a = e[(r.query ? r.query.index.name : null) || ""];
									if (!a) return [
										null,
										!1,
										i,
										null
									];
									switch (n) {
										case "query":
											var o = (s = r.direction) ?? "next", s = a.find(function(e) {
												return e.req.limit === r.limit && e.req.values === r.values && (e.req.direction ?? "next") === o && tr(e.req.query.range, r.query.range);
											});
											return s ? [
												s,
												!0,
												i,
												a
											] : [
												a.find(function(e) {
													return ("limit" in e.req ? e.req.limit : 1 / 0) >= r.limit && (e.req.direction ?? "next") === o && (!r.values || e.req.values) && nr(e.req.query.range, r.query.range);
												}),
												!1,
												i,
												a
											];
										case "count": return s = a.find(function(e) {
											return tr(e.req.query.range, r.query.range);
										}), [
											s,
											!!s,
											i,
											a
										];
									}
								})(n, r, "query", e), u = l[0], s = l[2], c = l[3], u && l[1] ? u.obsSet = e.obsSet : (l = i.query(e).then(function(e) {
									var n = e.result;
									if (u && (u.res = n), t) {
										for (var r = 0, i = n.length; r < i; ++r) Object.freeze(n[r]);
										Object.freeze(n);
									}
									return e;
								}).catch(function(e) {
									return c && u && j(c, u), Promise.reject(e);
								}), u = {
									obsSet: e.obsSet,
									promise: l,
									subscribers: /* @__PURE__ */ new Set(),
									type: "query",
									req: e,
									dirty: !1
								}, c ? c.push(u) : (c = [u], (s ||= Pn[`idb://${n}/${r}`] = {
									queries: {
										query: {},
										count: {}
									},
									objs: /* @__PURE__ */ new Map(),
									optimisticOps: [],
									unsignaledParts: {}
								}).queries.query[e.query.index.name || ""] = c)), rr(u, c, a, o), u.promise.then(function(n) {
									return n = er(n.result, e, s?.optimisticOps, i, u, t), { result: t ? n : O(n) };
								})) : i.query(e);
							}
						});
					}
				});
			}
		};
		function ar(e, t) {
			return new Proxy(e, { get: function(e, n, r) {
				return n === "db" ? t : Reflect.get(e, n, r);
			} });
		}
		X.prototype.version = function(e) {
			if (isNaN(e) || e < .1) throw new L.Type("Given version is not a positive number");
			if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new L.Schema("Cannot add version when database is open");
			this.verno = Math.max(this.verno, e);
			var t = this._versions, n = t.filter(function(t) {
				return t._cfg.version === e;
			})[0];
			return n || (n = new this.Version(e), t.push(n), t.sort(cn), n.stores({}), this._state.autoSchema = !1), n;
		}, X.prototype._whenReady = function(e) {
			var t = this;
			return this.idbdb && (this._state.openComplete || B.letThrough || this._vip) ? e() : new V(function(e, n) {
				if (t._state.openComplete) return n(new L.DatabaseClosed(t._state.dbOpenError));
				if (!t._state.isBeingOpened) {
					if (!t._state.autoOpen) return void n(new L.DatabaseClosed());
					t.open().catch(z);
				}
				t._state.dbReadyPromise.then(e, n);
			}).then(e);
		}, X.prototype.use = function(e) {
			var t = e.stack, n = e.create, r = e.level, e = e.name, i = (e && this.unuse({
				stack: t,
				name: e
			}), this._middlewares[t] || (this._middlewares[t] = []));
			return i.push({
				stack: t,
				create: n,
				level: r ?? 10,
				name: e
			}), i.sort(function(e, t) {
				return e.level - t.level;
			}), this;
		}, X.prototype.unuse = function(e) {
			var t = e.stack, n = e.name, r = e.create;
			return t && this._middlewares[t] && (this._middlewares[t] = this._middlewares[t].filter(function(e) {
				return r ? e.create !== r : !!n && e.name !== n;
			})), this;
		}, X.prototype.open = function() {
			var e = this;
			return rt(Ae, function() {
				return Bn(e);
			});
		}, X.prototype._close = function() {
			this.on.close.fire(new CustomEvent("close"));
			var e = this._state;
			if (bn.remove(this), this.idbdb) {
				try {
					this.idbdb.close();
				} catch {}
				this.idbdb = null;
			}
			e.isBeingOpened || (e.dbReadyPromise = new V(function(t) {
				e.dbReadyResolve = t;
			}), e.openCanceller = new V(function(t, n) {
				e.cancelOpen = n;
			}));
		}, X.prototype.close = function(e) {
			var e = (e === void 0 ? { disableAutoOpen: !0 } : e).disableAutoOpen, t = this._state;
			e ? (t.isBeingOpened && t.cancelOpen(new L.DatabaseClosed()), this._close(), t.autoOpen = !1, t.dbOpenError = new L.DatabaseClosed()) : (this._close(), t.autoOpen = this._options.autoOpen || t.isBeingOpened, t.openComplete = !1, t.dbOpenError = null);
		}, X.prototype.delete = function(e) {
			var t = this, n = (e === void 0 && (e = { disableAutoOpen: !0 }), 0 < arguments.length && typeof arguments[0] != "object"), r = this._state;
			return new V(function(i, a) {
				function o() {
					t.close(e);
					var n = t._deps.indexedDB.deleteDatabase(t.name);
					n.onsuccess = U(function() {
						var e = t._deps, n = t.name, r;
						Sn(r = e.indexedDB) || n === W || xn(r, e.IDBKeyRange).delete(n).catch(z), i();
					}), n.onerror = Y(a), n.onblocked = t._fireOnBlocked;
				}
				if (n) throw new L.InvalidArgument("Invalid closeOptions argument to db.delete()");
				r.isBeingOpened ? r.dbReadyPromise.then(o) : o();
			});
		}, X.prototype.backendDB = function() {
			return this.idbdb;
		}, X.prototype.isOpen = function() {
			return this.idbdb !== null;
		}, X.prototype.hasBeenClosed = function() {
			var e = this._state.dbOpenError;
			return e && e.name === "DatabaseClosed";
		}, X.prototype.hasFailed = function() {
			return this._state.dbOpenError !== null;
		}, X.prototype.dynamicallyOpened = function() {
			return this._state.autoSchema;
		}, Object.defineProperty(X.prototype, "tables", {
			get: function() {
				var e = this;
				return i(this._allTables).map(function(t) {
					return e._allTables[t];
				});
			},
			enumerable: !1,
			configurable: !0
		}), X.prototype.transaction = function() {
			var e = function(e, t, n) {
				var r = arguments.length;
				if (r < 2) throw new L.InvalidArgument("Too few arguments");
				for (var i = Array(r - 1); --r;) i[r - 1] = arguments[r];
				return n = i.pop(), [
					e,
					w(i),
					n
				];
			}.apply(this, arguments);
			return this._transaction.apply(this, e);
		}, X.prototype._transaction = function(e, t, n) {
			var r, i, a = this, o = B.trans, s = (o && o.db === this && e.indexOf("!") === -1 || (o = null), e.indexOf("?") !== -1);
			e = e.replace("!", "").replace("?", "");
			try {
				if (i = t.map(function(e) {
					if (e = e instanceof a.Table ? e.name : e, typeof e != "string") throw TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
					return e;
				}), e == "r" || e === ut) r = ut;
				else {
					if (e != "rw" && e != dt) throw new L.InvalidArgument("Invalid transaction mode: " + e);
					r = dt;
				}
				if (o) {
					if (o.mode === ut && r === dt) {
						if (!s) throw new L.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
						o = null;
					}
					o && i.forEach(function(e) {
						if (o && o.storeNames.indexOf(e) === -1) {
							if (!s) throw new L.SubTransaction("Table " + e + " not included in parent transaction.");
							o = null;
						}
					}), s && o && !o.active && (o = null);
				}
			} catch (e) {
				return o ? o._promise(null, function(t, n) {
					n(e);
				}) : ot(e);
			}
			var c = function e(t, n, r, i, a) {
				return V.resolve().then(function() {
					var o = B.transless || B, s = t._createTransaction(n, r, t._dbSchema, i), o = (s.explicit = !0, {
						trans: s,
						transless: o
					});
					if (i) s.idbtrans = i.idbtrans;
					else try {
						s.create(), s.idbtrans._explicit = !0, t._state.PR1398_maxLoop = 3;
					} catch (i) {
						return i.name === oe.InvalidState && t.isOpen() && 0 < --t._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), t.close({ disableAutoOpen: !1 }), t.open().then(function() {
							return e(t, n, r, null, a);
						})) : ot(i);
					}
					var c, l = ne(a), o = (l && Ze(), V.follow(function() {
						var e;
						(c = a.call(s, s)) && (l ? (e = Qe.bind(null, null), c.then(e, e)) : typeof c.next == "function" && typeof c.throw == "function" && (c = Vn(c)));
					}, o));
					return (c && typeof c.then == "function" ? V.resolve(c).then(function(e) {
						return s.active ? e : ot(new L.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
					}) : o.then(function() {
						return c;
					})).then(function(e) {
						return i && s._resolve(), s._completion.then(function() {
							return e;
						});
					}).catch(function(e) {
						return s._reject(e), ot(e);
					});
				});
			}.bind(null, this, r, i, o, n);
			return o ? o._promise(r, c, "lock") : B.trans ? rt(B.transless, function() {
				return a._whenReady(c);
			}) : this._whenReady(c);
		}, X.prototype.table = function(e) {
			if (l(this._allTables, e)) return this._allTables[e];
			throw new L.InvalidTable(`Table ${e} does not exist`);
		};
		var or = X;
		function X(e, n) {
			var r, i, a, o, s, c = this, l = (this._middlewares = {}, this.verno = 0, X.dependencies), l = (this._options = n = t({
				addons: X.addons,
				autoOpen: !0,
				indexedDB: l.indexedDB,
				IDBKeyRange: l.IDBKeyRange,
				cache: "cloned",
				maxConnections: 1e3
			}, n), this._deps = {
				indexedDB: n.indexedDB,
				IDBKeyRange: n.IDBKeyRange
			}, n.addons), u = (this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this, {
				dbOpenError: null,
				isBeingOpened: !1,
				onReadyBeingFired: null,
				openComplete: !1,
				dbReadyResolve: z,
				dbReadyPromise: null,
				cancelOpen: z,
				openCanceller: null,
				autoSchema: !0,
				PR1398_maxLoop: 3,
				autoOpen: n.autoOpen
			}), d = (u.dbReadyPromise = new V(function(e) {
				u.dbReadyResolve = e;
			}), u.openCanceller = new V(function(e, t) {
				u.cancelOpen = t;
			}), this._state = u, this.name = e, this.on = Ct(this, "populate", "blocked", "versionchange", "close", { ready: [he, z] }), this.once = function(e, t) {
				var n = function() {
					var r = [...arguments];
					c.on(e).unsubscribe(n), t.apply(c, r);
				};
				return c.on(e, n);
			}, this.on.ready.subscribe = _(this.on.ready.subscribe, function(e) {
				return function(t, n) {
					X.vip(function() {
						var r, i = c._state;
						i.openComplete ? (i.dbOpenError || V.resolve().then(t), n && e(t)) : i.onReadyBeingFired ? (i.onReadyBeingFired.push(t), n && e(t)) : (e(t), r = c, n || e(function e() {
							r.on.ready.unsubscribe(t), r.on.ready.unsubscribe(e);
						}));
					});
				};
			}), this.Collection = (r = this, wt(Mt.prototype, function(e, t) {
				this.db = r;
				var n = pt, i = null;
				if (t) try {
					n = t();
				} catch (e) {
					i = e;
				}
				var t = e._ctx, e = t.table, a = e.hook.reading.fire;
				this._ctx = {
					table: e,
					index: t.index,
					isPrimKey: !t.index || e.schema.primKey.keyPath && t.index === e.schema.primKey.name,
					range: n,
					keysOnly: !1,
					dir: "next",
					unique: "",
					algorithm: null,
					filter: null,
					replayFilter: null,
					justLimit: !0,
					isMatch: null,
					offset: 0,
					limit: 1 / 0,
					error: i,
					or: t.or,
					valueMapper: a === ce ? null : a
				};
			})), this.Table = (i = this, wt(St.prototype, function(e, t, n) {
				this.db = i, this._tx = n, this.name = e, this.schema = t, this.hook = i._allTables[e] ? i._allTables[e].hook : Ct(null, {
					creating: [de, z],
					reading: [le, ce],
					updating: [pe, z],
					deleting: [fe, z]
				});
			})), this.Transaction = (a = this, wt(Kt.prototype, function(e, t, n, r, i) {
				var o = this;
				e !== "readonly" && t.forEach(function(e) {
					e = (e = n[e])?.yProps, e && (t = t.concat(e.map(function(e) {
						return e.updatesTable;
					})));
				}), this.db = a, this.mode = e, this.storeNames = t, this.schema = n, this.chromeTransactionDurability = r, this.idbtrans = null, this.on = Ct(this, "complete", "error", "abort"), this.parent = i || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new V(function(e, t) {
					o._resolve = e, o._reject = t;
				}), this._completion.then(function() {
					o.active = !1, o.on.complete.fire();
				}, function(e) {
					var t = o.active;
					return o.active = !1, o.on.error.fire(e), o.parent ? o.parent._reject(e) : t && o.idbtrans && o.idbtrans.abort(), ot(e);
				});
			})), this.Version = (o = this, wt(vn.prototype, function(e) {
				this.db = o, this._cfg = {
					version: e,
					storesSource: null,
					dbschema: {},
					tables: {},
					contentUpgrade: null
				};
			})), this.WhereClause = (s = this, wt(Vt.prototype, function(e, t, n) {
				if (this.db = s, this._ctx = {
					table: e,
					index: t === ":id" ? null : t,
					or: n
				}, this._cmp = this._ascending = G, this._descending = function(e, t) {
					return G(t, e);
				}, this._max = function(e, t) {
					return 0 < G(e, t) ? e : t;
				}, this._min = function(e, t) {
					return G(e, t) < 0 ? e : t;
				}, this._IDBKeyRange = s._deps.IDBKeyRange, !this._IDBKeyRange) throw new L.MissingAPI();
			})), this.on("versionchange", function(e) {
				0 < e.newVersion ? console.warn(`Another connection wants to upgrade database '${c.name}'. Closing db now to resume the upgrade.`) : console.warn(`Another connection wants to delete database '${c.name}'. Closing db now to resume the delete request.`), c.close({ disableAutoOpen: !1 });
			}), this.on("blocked", function(e) {
				!e.newVersion || e.newVersion < e.oldVersion ? console.warn(`Dexie.delete('${c.name}') was blocked`) : console.warn(`Upgrade '${c.name}' blocked by other connection holding version ${e.oldVersion / 10}`);
			}), this._maxKey = Zt(n.IDBKeyRange), this._createTransaction = function(e, t, n, r) {
				return new c.Transaction(e, t, n, c._options.chromeTransactionDurability, r);
			}, this._fireOnBlocked = function(e) {
				c.on("blocked").fire(e), bn.toArray().filter(function(e) {
					return e.name === c.name && e !== c && !e._state.vcFired;
				}).map(function(t) {
					return t.on("versionchange").fire(e);
				});
			}, this.use(Jn), this.use(ir), this.use(Zn), this.use(Un), this.use(Kn), new Proxy(this, { get: function(e, t, n) {
				var r;
				return t === "_vip" || (t === "table" ? function(e) {
					return ar(c.table(e), d);
				} : (r = Reflect.get(e, t, n)) instanceof St ? ar(r, d) : t === "tables" ? r.map(function(e) {
					return ar(e, d);
				}) : t === "_createTransaction" ? function() {
					return ar(r.apply(this, arguments), d);
				} : r);
			} }));
			this.vip = d, l.forEach(function(e) {
				return e(c);
			});
		}
		var sr, xe = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", cr = (lr.prototype.subscribe = function(e, t, n) {
			return this._subscribe(e && typeof e != "function" ? e : {
				next: e,
				error: t,
				complete: n
			});
		}, lr.prototype[xe] = function() {
			return this;
		}, lr);
		function lr(e) {
			this._subscribe = e;
		}
		try {
			sr = {
				indexedDB: r.indexedDB || r.mozIndexedDB || r.webkitIndexedDB || r.msIndexedDB,
				IDBKeyRange: r.IDBKeyRange || r.webkitIDBKeyRange
			};
		} catch {
			sr = {
				indexedDB: null,
				IDBKeyRange: null
			};
		}
		function ur(e) {
			var t, n = !1, r = new cr(function(r) {
				var i = ne(e), a, o = !1, s = {}, c = {}, l = {
					get closed() {
						return o;
					},
					unsubscribe: function() {
						o || (o = !0, a && a.abort(), u && Gt.storagemutated.unsubscribe(p));
					}
				}, u = (r.start && r.start(l), !1), d = function() {
					return at(m);
				};
				function f() {
					return Nn(c, s);
				}
				var p = function(e) {
					Mn(s, e), f() && d();
				}, m = function() {
					var l, m, h;
					!o && sr.indexedDB && (s = {}, l = {}, a && a.abort(), a = new AbortController(), h = ((t) => {
						var n = Be();
						try {
							i && Ze();
							var r = Xe(e, t);
							return r = i ? r.finally(Qe) : r;
						} finally {
							n && Ve();
						}
					})(m = {
						subscr: l,
						signal: a.signal,
						requery: d,
						querier: e,
						trans: null
					}), u ||= (Gt.storagemutated.subscribe(p), !0), Promise.resolve(h).then(function(e) {
						n = !0, t = e, o || m.signal.aborted || (f() || (c = l, f()) ? d() : (s = {}, at(function() {
							return !o && r.next && r.next(e);
						})));
					}, function(e) {
						n = !1, ["DatabaseClosedError", "AbortError"].includes(e?.name) || o || at(function() {
							o || r.error && r.error(e);
						});
					}));
				};
				return setTimeout(d, 0), l;
			});
			return r.hasValue = function() {
				return n;
			}, r.getValue = function() {
				return t;
			}, r;
		}
		var dr = or;
		function fr(e) {
			var t = mr;
			try {
				mr = !0, Gt.storagemutated.fire(e), Rn(e, !0);
			} finally {
				mr = t;
			}
		}
		u(dr, t(t({}, T), {
			delete: function(e) {
				return new dr(e, { addons: [] }).delete();
			},
			exists: function(e) {
				return new dr(e, { addons: [] }).open().then(function(e) {
					return e.close(), !0;
				}).catch("NoSuchDatabaseError", function() {
					return !1;
				});
			},
			getDatabaseNames: function(e) {
				try {
					return t = dr.dependencies, n = t.indexedDB, t = t.IDBKeyRange, (Sn(n) ? Promise.resolve(n.databases()).then(function(e) {
						return e.map(function(e) {
							return e.name;
						}).filter(function(e) {
							return e !== W;
						});
					}) : xn(n, t).toCollection().primaryKeys()).then(e);
				} catch {
					return ot(new L.MissingAPI());
				}
				var t, n;
			},
			defineClass: function() {
				return function(e) {
					o(this, e);
				};
			},
			ignoreTransaction: function(e) {
				return B.trans ? rt(B.transless || Ae, e) : e();
			},
			vip: Cn,
			async: function(e) {
				return function() {
					try {
						var t = Vn(e.apply(this, arguments));
						return t && typeof t.then == "function" ? t : V.resolve(t);
					} catch (e) {
						return ot(e);
					}
				};
			},
			spawn: function(e, t, n) {
				try {
					var r = Vn(e.apply(n, t || []));
					return r && typeof r.then == "function" ? r : V.resolve(r);
				} catch (e) {
					return ot(e);
				}
			},
			currentTransaction: { get: function() {
				return B.trans || null;
			} },
			waitFor: function(e, t) {
				return e = V.resolve(typeof e == "function" ? dr.ignoreTransaction(e) : e).timeout(t || 6e4), B.trans ? B.trans.waitFor(e) : e;
			},
			Promise: V,
			debug: {
				get: function() {
					return ge;
				},
				set: function(e) {
					_e(e);
				}
			},
			derive: p,
			extend: o,
			props: u,
			override: _,
			Events: Ct,
			on: Gt,
			liveQuery: ur,
			extendObservabilitySet: Mn,
			getByKeyPath: b,
			setByKeyPath: x,
			delByKeyPath: function(e, t) {
				typeof t == "string" ? x(e, t, void 0) : "length" in t && [].map.call(t, function(t) {
					x(e, t, void 0);
				});
			},
			shallowClone: S,
			deepClone: O,
			getObjectDiff: Wn,
			cmp: G,
			asap: y,
			minKey: -1 / 0,
			addons: [],
			connections: { get: bn.toArray },
			errnames: oe,
			dependencies: sr,
			cache: Pn,
			semVer: "4.4.6",
			version: "4.4.6".split(".").map(function(e) {
				return parseInt(e);
			}).reduce(function(e, t, n) {
				return e + t / 10 ** (2 * n);
			})
		})), dr.maxKey = Zt(dr.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (Gt(Ut, function(e) {
			mr ||= (e = new CustomEvent(Wt, { detail: e }), mr = !0, dispatchEvent(e), !1);
		}), addEventListener(Wt, function(e) {
			e = e.detail, mr || fr(e);
		}));
		var pr, mr = !1, hr = function() {};
		return typeof BroadcastChannel < "u" && ((hr = function() {
			(pr = new BroadcastChannel(Wt)).onmessage = function(e) {
				return e.data && fr(e.data);
			};
		})(), typeof pr.unref == "function" && pr.unref(), Gt(Ut, function(e) {
			mr || pr.postMessage(e);
		})), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
			if (!or.disableBfCache && e.persisted) {
				ge && console.debug("Dexie: handling persisted pagehide"), pr?.close();
				for (var t = 0, n = bn.toArray(); t < n.length; t++) n[t].close({ disableAutoOpen: !1 });
			}
		}), addEventListener("pageshow", function(e) {
			!or.disableBfCache && e.persisted && (ge && console.debug("Dexie: handling persisted pageshow"), hr(), fr({ all: new Tn(-1 / 0, [[]]) }));
		})), V.rejectionMapper = function(e, t) {
			return !e || e instanceof F || e instanceof TypeError || e instanceof SyntaxError || !e.name || !R[e.name] ? e : (t = new R[e.name](t || e.message, e), "stack" in e && f(t, "stack", { get: function() {
				return this.inner.stack;
			} }), t);
		}, _e(ge), t(or, Object.freeze({
			__proto__: null,
			DEFAULT_MAX_CONNECTIONS: 1e3,
			Dexie: or,
			Entity: ht,
			PropModification: yt,
			RangeSet: Tn,
			add: function(e) {
				return new yt({ add: e });
			},
			cmp: G,
			default: or,
			liveQuery: ur,
			mergeRanges: Dn,
			rangesOverlap: On,
			remove: function(e) {
				return new yt({ remove: e });
			},
			replacePrefix: function(e, t) {
				return new yt({ replacePrefix: [e, t] });
			}
		}), { default: or }), or;
	});
})))(), 1), Ee = Symbol.for("Dexie"), De = globalThis[Ee] || (globalThis[Ee] = Te.default);
if (Te.default.semVer !== De.semVer) throw Error(`Two different versions of Dexie loaded in the same app: ${Te.default.semVer} and ${De.semVer}`);
var { liveQuery: Oe, mergeRanges: ke, rangesOverlap: Ae, RangeSet: B, cmp: je, Entity: Me, PropModification: Ne, replacePrefix: V, add: Pe, remove: Fe, DexieYProvider: Ie } = De, Le = 8388608, Re = 268435456, ze = 4e6, H = () => {
	throw new M("SAVE_FAILED", "大きな履歴の分割記録が破損しています。既存データを保持しています。");
};
async function Be(t, n, r) {
	O(r);
	let i = [], a = /* @__PURE__ */ new WeakMap(), o = /* @__PURE__ */ new WeakSet(), s = [], c = /* @__PURE__ */ new Map(), l = (e) => {
		let t = c.get(e);
		return t === void 0 && (t = s.length, s.push(e), c.set(e, t)), t;
	}, u = (e) => {
		if (e === void 0) return { undefined: !0 };
		if (typeof e == "string") return -l(e) - 1;
		if (typeof e == "number") return Number.isFinite(e) ? { number: e } : H();
		if (e === null || typeof e == "boolean") return e;
		if (!e || typeof e != "object" || !Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return H();
		let t = a.get(e);
		if (t !== void 0) return o.has(e) ? H() : t;
		let n = i.length;
		if (n >= ze) return H();
		a.set(e, n), o.add(e);
		let r = [+!Array.isArray(e)];
		if (i.push(r), Array.isArray(e)) {
			if (Object.keys(e).length !== e.length) return H();
			for (let t of e) r.push(u(t));
		} else for (let [t, n] of Object.entries(e)) r.push(l(t), u(n));
		return o.delete(e), n;
	}, d = u(t), f = [], p = 0;
	for (let [t, a] of [["strings", s], ["nodes", i]]) {
		let i = [], o = 0, s = async () => {
			if (!i.length) return;
			O(r);
			let a = m(i);
			if (p += a.byteLength, a.byteLength > Le || p > Re) throw new M("LIMIT_EXCEEDED", "履歴の分割記録が端末の安全上限を超えています。");
			let s = f.length;
			f.push({
				key: `${n}:${s}`,
				scope: n,
				sequence: s,
				kind: t,
				bytes: a,
				sha256: await e(a)
			}), O(r), i = [], o = 0;
		};
		for (let e of a) {
			let t = m(e).byteLength;
			if (t > Le) return H();
			i.length && o + t + i.length + 2 > Le / 4 && await s(), i.push(e), o += t;
		}
		await s();
	}
	return O(r), {
		packed: {
			version: 1,
			scope: n,
			root: d,
			nodes: i.length,
			strings: s.length,
			parts: f.map((e) => ({
				key: e.key,
				kind: e.kind,
				bytes: e.bytes.byteLength,
				sha256: e.sha256
			}))
		},
		parts: f
	};
}
async function Ve(t, n, i) {
	if (O(i), t.version !== 1 || typeof t.scope != "string" || !Number.isSafeInteger(t.nodes) || t.nodes < 0 || t.nodes > ze || !Number.isSafeInteger(t.strings) || t.strings < 0 || t.strings > ze || !Array.isArray(t.parts) || t.parts.length !== n.length || new Set(n.map((e) => e.key)).size !== n.length) return H();
	let a = 0;
	for (let e of n) if (!(e.bytes instanceof Uint8Array) || e.bytes.byteLength > Le || (a += e.bytes.byteLength, a > Re)) return H();
	t = structuredClone(t), n = n.map((e) => ({
		...e,
		bytes: new Uint8Array(e.bytes)
	}));
	let o = [], s = [], c = new Map(n.map((e) => [e.key, e])), l = 0;
	for (let [n, a] of t.parts.entries()) {
		O(i);
		let u = c.get(a.key);
		if (!u || u.scope !== t.scope || u.sequence !== n || a.key !== `${t.scope}:${n}` || !["strings", "nodes"].includes(a.kind) || u.kind !== a.kind || !(u.bytes instanceof Uint8Array) || u.bytes.byteLength !== a.bytes || a.bytes > Le || u.sha256 !== a.sha256 || !/^([a-f0-9]{64})$/.test(a.sha256) || await e(u.bytes) !== a.sha256 || (l += a.bytes, l > Re)) return H();
		let d = g(u.bytes, u.key, {
			...r,
			jsonBytes: Le,
			expandedBytes: Re
		});
		if (!Array.isArray(d)) return H();
		if (u.kind === "strings") {
			if (s.length + d.length > t.strings || d.some((e) => typeof e != "string")) return H();
			for (let e of d) s.push(e);
		} else {
			if (o.length + d.length > t.nodes) return H();
			for (let e of d) o.push(e);
		}
	}
	if (o.length !== t.nodes || s.length !== t.strings || new Set(s).size !== s.length) return H();
	let u = /* @__PURE__ */ new Set(), d = (e) => !Number.isSafeInteger(e) || e < 0 || e >= s.length ? H() : (u.add(e), s[e]), f = (e) => {
		if (e !== null && typeof e != "boolean") {
			if (typeof e == "number") {
				if (!Number.isSafeInteger(e)) return H();
				if (e < 0) {
					d(-e - 1);
					return;
				}
				return e >= o.length ? H() : e;
			}
			if (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).length !== 1 || !("undefined" in e && e.undefined === !0) && !("number" in e && typeof e.number == "number" && Number.isFinite(e.number))) return H();
		}
	}, p = (e) => {
		if (!Array.isArray(e) || e[0] !== 0 && e[0] !== 1) return H();
		if (e[0] === 0) return e.slice(1);
		if (e.length % 2 != 1) return H();
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 1; r < e.length; r += 2) {
			let i = d(e[r]);
			if (t.has(i)) return H();
			t.add(i), n.push(e[r + 1]);
		}
		return n;
	};
	f(t.root);
	for (let e of o) for (let t of p(e)) f(t);
	let m = new Uint8Array(o.length), h = f(t.root), _ = 0;
	if (h !== void 0) {
		let e = [{
			id: h,
			next: 1
		}];
		for (; e.length;) {
			let t = e.at(-1), n = o[t.id];
			if (m[t.id] || (m[t.id] = 1, _++), t.next >= n.length) {
				m[t.id] = 2, e.pop();
				continue;
			}
			let r = t.next + +(n[0] === 1);
			t.next += n[0] === 1 ? 2 : 1;
			let i = f(n[r]);
			if (i !== void 0) {
				if (m[i] === 1 || e.length > 64) return H();
				m[i] || e.push({
					id: i,
					next: 1
				});
			}
		}
	}
	if (_ !== o.length || u.size !== s.length) return H();
	let v = o.map((e) => e[0] === 0 ? [] : {}), y = (e) => typeof e == "number" ? e < 0 ? d(-e - 1) : v[e] : e && typeof e == "object" ? "number" in e ? e.number : void 0 : e;
	for (let [e, t] of o.entries()) if (t[0] === 0) for (let n = 1; n < t.length; n++) v[e].push(y(t[n]));
	else for (let n = 1; n < t.length; n += 2) Object.defineProperty(v[e], d(t[n]), {
		value: y(t[n + 1]),
		enumerable: !0,
		configurable: !0,
		writable: !0
	});
	return O(i), y(t.root);
}
function He(e, t = 8388608) {
	let n = 0, r = /* @__PURE__ */ new WeakSet(), i = [e];
	for (; i.length && n <= t;) {
		let e = i.pop();
		if (typeof e == "string") n += e.length * 2 + 16;
		else if (e && typeof e == "object") {
			if (r.has(e)) continue;
			r.add(e), n += 32;
			for (let [t, r] of Object.entries(e)) n += t.length * 2 + 16, i.push(r);
		} else n += 16;
	}
	return n > t;
}
//#endregion
//#region src/storage/recordParts.ts
function Ue(e, t) {
	return O(t), new Promise((n, r) => {
		let i = new Worker(new URL(
			/* @vite-ignore */
			"/__restore/assets/recordParts.worker-T_qEKL4N.js",
			"" + import.meta.url
		), { type: "module" }), a = !0, o = (e, o) => {
			a && (a = !1, t?.removeEventListener("abort", s), i.terminate(), e ? r(e) : n(o));
		}, s = () => o(new M("CANCELLED", "履歴の分割処理を取り消しました。既存データを保持しています。"));
		t?.addEventListener("abort", s, { once: !0 }), i.onmessage = (e) => e.data.ok ? o(void 0, e.data.value) : o(new M(e.data.code, "大きな履歴を処理できません。既存データを保持しています。")), i.onerror = () => o(new M("SAVE_FAILED", "履歴の処理作業領域を開けません。"));
		try {
			O(t), i.postMessage(e);
		} catch (e) {
			o(e);
		}
	});
}
var U = () => typeof window < "u" && typeof Worker < "u";
function We(e, t, n) {
	return U() ? Ue({
		action: "pack",
		value: e,
		scope: t
	}, n) : Be(e, t, n);
}
function Ge(e, t, n) {
	return U() ? Ue({
		action: "unpack",
		packed: e,
		parts: t
	}, n) : Ve(e, t, n);
}
//#endregion
//#region src/storage/recordPartsDatabase.ts
var Ke = "__scenarioRecordParts", qe = /* @__PURE__ */ new Set([
	"commands",
	"outbox",
	"recoveredPending",
	"restorePoints",
	"worlds",
	"snapshots",
	"syncBases",
	"preparedSync",
	"syncConflicts",
	"syncAckEvidence",
	"retainedSyncRecovery",
	"projects",
	"entities"
]), Je = (e) => !!e && typeof e == "object" && Object.hasOwn(e, Ke), Ye = /* @__PURE__ */ new WeakMap();
function Xe(e) {
	let t = De.currentTransaction?.idbtrans;
	t && e && Ye.set(t, e);
}
function Ze(e, t) {
	e.use({
		stack: "dbcore",
		name: "scenario-record-parts-v1",
		level: -2,
		create(e) {
			if (!e.schema.tables.some((e) => e.name === "recordParts")) return e;
			let n = e.table("recordParts"), r = (e, t) => new Promise((n, r) => {
				let i = e, a = !1, o, s, c = !1, l = () => {
					try {
						let e = i.objectStore("recordParts").get("__scenario_keep_alive__");
						e.onsuccess = () => {
							if (a) {
								c ? r(s) : n(o);
								return;
							}
							l();
						}, e.onerror = () => r(e.error ?? new M("SAVE_FAILED", "履歴のトランザクションを維持できません。"));
					} catch (e) {
						r(e);
					}
				};
				l();
				try {
					t().then((e) => {
						o = e, a = !0;
					}, (e) => {
						s = e, c = !0, a = !0;
					});
				} catch (e) {
					s = e, c = !0, a = !0;
				}
			});
			return {
				...e,
				transaction(t, n, r) {
					return e.transaction([.../* @__PURE__ */ new Set([...t, "recordParts"])], n, r);
				},
				table(i) {
					let a = e.table(i);
					if (!qe.has(i)) return a;
					let s = [a.schema.primaryKey, ...a.schema.indexes], c = (e, t) => {
						let n = { [Ke]: t };
						for (let t of s) {
							let r = typeof t.keyPath == "string" ? [t.keyPath] : t.keyPath ?? [];
							for (let t of r) {
								if (t.includes(".")) throw new M("SAVE_FAILED", "分割保存の索引形式に対応していません。");
								Object.hasOwn(e, t) && (n[t] = e[t]);
							}
						}
						return n;
					}, l = async (e, t) => {
						if (!Je(e)) return e;
						let i = await n.getMany({
							trans: t,
							keys: e[Ke].parts.map((e) => e.key)
						});
						if (i.some((e) => !e)) throw new M("SAVE_FAILED", "履歴の分割記録が不足しています。");
						let a = await r(t, () => Ge(e[Ke], i, Ye.get(t)));
						if (!a || typeof a != "object" || Je(a) || !o(c(a, e[Ke]), e)) throw new M("SAVE_FAILED", "履歴の分割記録と索引が一致しません。");
						return a;
					}, d = async (e, t) => {
						let r = e.flatMap((e) => Je(e) ? e[Ke].parts.map((e) => e.key) : []);
						if (r.length) {
							let e = await n.mutate({
								type: "delete",
								trans: t,
								keys: r
							});
							if (e.numFailures) throw Object.values(e.failures)[0];
						}
					};
					return {
						...a,
						async get(e) {
							return l(await a.get(e), e.trans);
						},
						async getMany(e) {
							let t = await a.getMany(e), n;
							for (let r = 0; r < t.length; r++) Je(t[r]) && (n ??= t.slice(), n[r] = await l(t[r], e.trans));
							return n ?? t;
						},
						async query(e) {
							let t = await a.query(e);
							if (e.values) {
								let n;
								for (let r = 0; r < t.result.length; r++) Je(t.result[r]) && (n ??= t.result.slice(), n[r] = await l(t.result[r], e.trans));
								if (n) return {
									...t,
									result: n
								};
							}
							return t;
						},
						async openCursor(e) {
							let t = await a.openCursor(e);
							if (!t || !e.values) return t;
							let n = await l(t.value, e.trans), r = {
								get trans() {
									return t.trans;
								},
								get key() {
									return t.key;
								},
								get primaryKey() {
									return t.primaryKey;
								},
								get done() {
									return t.done;
								},
								get value() {
									return n;
								},
								continue(e) {
									t.continue(e);
								},
								continuePrimaryKey(e, n) {
									t.continuePrimaryKey(e, n);
								},
								advance(e) {
									t.advance(e);
								},
								stop(e) {
									t.stop(e);
								},
								fail(e) {
									t.fail(e);
								},
								async next() {
									return await t.next(), n = await l(t.value, e.trans), r;
								},
								start(r) {
									return t.start(() => {
										l(t.value, e.trans).then((e) => {
											n = e, r();
										}, (e) => t.fail(e));
									});
								}
							};
							return r;
						},
						async mutate(e) {
							let o = [];
							if (e.type === "put" || e.type === "delete") {
								let t = e.keys ?? (e.type === "put" ? e.values.map((e) => a.schema.primaryKey.extractKey?.(e)) : []);
								o = await a.getMany({
									trans: e.trans,
									keys: t
								});
							}
							if (e.type === "deleteRange" && (o = (await a.query({
								trans: e.trans,
								values: !0,
								query: {
									index: a.schema.primaryKey,
									range: e.range
								}
							})).result), e.type === "add" || e.type === "put") {
								let s = [], l = [];
								for (let n of e.values) {
									if (Je(n)) throw new M("SAVE_FAILED", "内部の分割記録を入力値として保存できません。");
									if (He(n, t)) {
										let t = await r(e.trans, () => We(n, `${i}:${u()}`, Ye.get(e.trans)));
										s.push(c(n, t.packed)), l.push(...t.parts);
									} else s.push(n);
								}
								let f = /* @__PURE__ */ new Map();
								s.forEach((t, n) => {
									let r = e.keys?.[n] ?? a.schema.primaryKey.extractKey?.(t);
									f.set(JSON.stringify(r), t);
								});
								let p = new Set([...f.values()].flatMap((e) => Je(e) ? [e[Ke].scope] : [])), m = l.filter((e) => p.has(e.scope));
								if (m.length) {
									let t = await n.mutate({
										type: "add",
										trans: e.trans,
										values: m
									});
									if (t.numFailures) throw Object.values(t.failures)[0];
								}
								let h = await a.mutate({
									...e,
									values: s
								});
								return h.numFailures ? (e.trans.abort(), h) : (await d(o, e.trans), h);
							}
							let s = await a.mutate(e);
							return s.numFailures ? (e.trans.abort(), s) : (await d(o, e.trans), s);
						}
					};
				}
			};
		}
	});
}
//#endregion
//#region src/domain/authorAlternativeIntegrity.ts
var Qe = /^[0-9a-f]{64}$/, $e = /^(0|[1-9][0-9]*)$/, et = /* @__PURE__ */ new Set([
	"active",
	"provisional",
	"needs_review",
	"rejected",
	"accepted"
]), tt = /* @__PURE__ */ new Set([
	"project",
	"entity",
	"relation",
	"presentation"
]), nt = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), rt = {
	alternatives: 100,
	versions: 500,
	branchBytes: 8e6,
	totalBytes: 16e6
};
function it(e, t = /* @__PURE__ */ new Set(), n = 0) {
	if (n > 100) throw Error("内容の階層が上限を超えています。");
	if (e === null || typeof e == "boolean" || typeof e == "string" || typeof e == "number" && Number.isFinite(e)) return JSON.stringify(e);
	if (!e || typeof e != "object" || t.has(e)) throw Error("SHA-256対象が通常のJSON値ではありません。");
	let r = Object.getPrototypeOf(e);
	if (!Array.isArray(e) && r !== Object.prototype && r !== null) throw Error("SHA-256対象に未対応の値があります。");
	t.add(e);
	let i = Array.isArray(e) ? `[${e.map((e) => it(e, t, n + 1)).join(",")}]` : `{${Object.keys(e).sort().map((r) => {
		if (nt.has(r)) throw Error("JSONに未対応の項目名があります。");
		return `${JSON.stringify(r)}:${it(e[r], t, n + 1)}`;
	}).join(",")}}`;
	return t.delete(e), i;
}
async function at(e) {
	let t = new TextEncoder().encode(it(e)), n = await globalThis.crypto.subtle.digest("SHA-256", t);
	return Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("");
}
function ot(e) {
	let { integrityHash: t, ...n } = e;
	return n;
}
async function st(e) {
	let t = structuredClone(e);
	t.baseContentHash = await at(t.baseContent);
	for (let e of t.versions) e.contentHash = await at({
		content: e.content,
		structurePlan: e.structurePlan ?? null
	});
	return delete t.integrityHash, t.integrityHash = await at(ot(t)), t;
}
function ct(e) {
	return !!e && typeof e == "object" && !Array.isArray(e);
}
function lt(e) {
	return typeof e == "string" && Number.isFinite(Date.parse(e));
}
function W(e, t, n) {
	e.push({
		path: t,
		message: n
	});
}
function ut(e, t, n, r) {
	(typeof e.templateId != "string" || !e.templateId.trim()) && W(r, `${n}.templateId`, "構成雛形IDが必要です。"), !Array.isArray(e.beatLabels) || e.beatLabels.length > 100 || e.beatLabels.some((e) => typeof e != "string" || !e.trim()) ? W(r, `${n}.beatLabels`, "構成の役割は空でない文章を100件以内で指定してください。") : new Set(e.beatLabels).size !== e.beatLabels.length && W(r, `${n}.beatLabels`, "構成の役割名は重複できません。");
	let i = t.entities.find((t) => t.kind === "chapter" && t.id === e.chapterId && !t.deletedAt);
	if (i || W(r, `${n}.chapterId`, "構成計画の章が別案に存在しません。"), !ct(e.assignments)) {
		W(r, `${n}.assignments`, "場面の割り当てが不正です。");
		return;
	}
	let a = new Set(Array.isArray(e.beatLabels) ? e.beatLabels : []), o = /* @__PURE__ */ new Set();
	for (let [s, c] of Object.entries(e.assignments)) a.has(s) || W(r, `${n}.assignments.${s}`, "定義されていない構成の役割です。"), (typeof c != "string" || o.has(c)) && W(r, `${n}.assignments.${s}`, "同じ場面を複数の役割へ割り当てられません。"), o.add(c), t.entities.some((e) => e.kind === "scene" && e.id === c && !e.deletedAt) || W(r, `${n}.assignments.${s}`, "割り当てる場面が別案に存在しません。"), i && typeof c == "string" && !i.data.sceneIds.includes(c) && W(r, `${n}.assignments.${s}`, "場面は対象の章に所属していません。");
}
function dt(e, t) {
	return t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
}
function ft(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function pt(e, t) {
	if (t.scope === "presentation") return ft(e);
	if (t.scope === "project") return dt(e, t.path);
	let n = (t.scope === "entity" ? e.entities : e.relations).find((e) => e.id === t.itemId);
	if (n && !n.deletedAt) return t.path.length ? dt(n, t.path) : n;
}
function mt(e, t, n, r, i) {
	if (!e || typeof e != "object") {
		W(i, r, "正本採用記録が不正です。");
		return;
	}
	lt(e.createdAt) || W(i, `${r}.createdAt`, "採用日時が不正です。");
	let a = t.get(e.alternativeVersionId ?? "");
	if (a || W(i, `${r}.alternativeVersionId`, "採用元の別案版が見つかりません。"), (e.sourceSnapshotId ?? null) !== (n ?? null) && W(i, `${r}.sourceSnapshotId`, "採用記録の分岐元固定版が別案と一致しません。"), !$e.test(e.fromCanonicalRevision) || !e.appliedRevision || !$e.test(e.appliedRevision) ? W(i, r, "採用元と採用先の正本版番号が必要です。") : BigInt(e.appliedRevision) <= BigInt(e.fromCanonicalRevision) && W(i, `${r}.appliedRevision`, "採用先の正本版は採用元より新しくなければなりません。"), (!Array.isArray(e.selectedChangeKeys) || !e.selectedChangeKeys.length || new Set(e.selectedChangeKeys).size !== e.selectedChangeKeys.length) && W(i, `${r}.selectedChangeKeys`, "採用対象の差分キーが必要です。"), !Array.isArray(e.patches) || !e.patches.length) {
		W(i, `${r}.patches`, "採用した差分がありません。");
		return;
	}
	let o = /* @__PURE__ */ new Set();
	e.patches.forEach((e, t) => {
		let n = `${r}.patches[${t}]`;
		(!e || typeof e.key != "string" || o.has(e.key)) && W(i, `${n}.key`, "差分キーが不正または重複しています。"), o.add(e.key), (!tt.has(e.scope) || !Array.isArray(e.path) || e.path.some((e) => typeof e != "string") || typeof e.label != "string") && W(i, n, "差分の対象が不正です。"), (typeof e.before?.present != "boolean" || typeof e.after?.present != "boolean") && W(i, n, "差分の前後値の有無が不正です。");
		let s = [
			e.scope,
			e.itemId ?? "",
			...e.path ?? []
		].map((e) => encodeURIComponent(e)).join(":");
		if (e.key !== s && W(i, `${n}.key`, "差分キーが保存した範囲と一致しません。"), e.scope === "presentation" && (e.itemId || e.path?.length !== 1 || e.path[0] !== "all") && W(i, n, "提示順差分の範囲が不正です。"), (e.before?.present === !1 && Object.hasOwn(e.before, "value") || e.after?.present === !1 && Object.hasOwn(e.after, "value")) && W(i, n, "値がない差分に値を含められません。"), (e.before?.present === !0 && !Object.hasOwn(e.before, "value") || e.after?.present === !0 && !Object.hasOwn(e.after, "value")) && W(i, n, "値がある差分には値を含めてください。"), a && e.after && typeof e.after.present == "boolean") {
			let t = pt(a.content, e), r = t !== void 0;
			if (e.after.present !== r) W(i, `${n}.after`, "採用後の有無が参照した別案版と一致しません。");
			else if (r) try {
				it(e.after.value) !== it(t) && W(i, `${n}.after.value`, "採用後の値が参照した別案版と一致しません。");
			} catch (e) {
				W(i, `${n}.after.value`, e instanceof Error ? e.message : "採用後の値を別案版と比較できません。");
			}
		}
	}), Array.isArray(e.selectedChangeKeys) && !ht(e.selectedChangeKeys, [...o]) && W(i, `${r}.selectedChangeKeys`, "採用対象キーと保存した差分内容が一致しません。");
}
function ht(e, t) {
	return e.length === t.length && [...e].sort().every((e, n) => e === [...t].sort()[n]);
}
async function G(e, t, n) {
	let r = [], i = {
		alternatives: n.maxAlternatives ?? rt.alternatives,
		versions: n.maxVersionsPerAlternative ?? rt.versions,
		branchBytes: n.maxBytesPerAlternative ?? rt.branchBytes,
		totalBytes: n.maxBytesTotal ?? rt.totalBytes
	};
	if (!Array.isArray(t)) return [{
		path: "authorAlternatives",
		message: "作者別案は配列で指定してください。"
	}];
	t.length > i.alternatives && W(r, "authorAlternatives", `作者別案は${i.alternatives}件までです。`);
	let a = new Set(n.reservedIds ?? []), o = /* @__PURE__ */ new Set(), s = 0;
	for (let [c, l] of t.entries()) {
		let t = `authorAlternatives[${c}]`;
		if (!ct(l)) {
			W(r, t, "作者別案の記録が不正です。");
			continue;
		}
		let u = l;
		if ((typeof u.id != "string" || o.has(u.id) || a.has(u.id)) && W(r, `${t}.id`, "別案IDが不正または重複しています。"), typeof u.id == "string" && (o.add(u.id), a.add(u.id)), u.projectId !== e && W(r, `${t}.projectId`, "別案が別の作品を参照しています。"), (typeof u.name != "string" || !u.name.trim()) && W(r, `${t}.name`, "別案名が必要です。"), et.has(u.status) || W(r, `${t}.status`, "別案の状態が不正です。"), (!lt(u.createdAt) || !lt(u.updatedAt)) && W(r, t, "別案の作成日時または更新日時が不正です。"), $e.test(u.baseRevision) || W(r, `${t}.baseRevision`, "分岐元の版番号が不正です。"), u.sourceSnapshotId != null && n.snapshotIds && !n.snapshotIds.has(u.sourceSnapshotId) && W(r, `${t}.sourceSnapshotId`, "分岐元の固定版が見つかりません。"), (!ct(u.baseContent) || u.baseContent.projectId !== e || u.baseContent.revision !== u.baseRevision) && W(r, `${t}.baseContent`, "分岐元の内容・作品ID・版番号が一致しません。"), ct(u.baseContent) && Object.hasOwn(u.baseContent, "authorAlternatives") && W(r, `${t}.baseContent.authorAlternatives`, "別案の内容へ別案一覧を再帰保存できません。"), ct(u.baseContent)) {
			if (u.sourceSnapshotId) {
				let e = n.snapshots?.find((e) => e.id === u.sourceSnapshotId);
				if (!e) W(r, `${t}.sourceSnapshotId`, "分岐元の固定版本文がありません。");
				else try {
					it(e.content) !== it(u.baseContent) && W(r, `${t}.baseContent`, "固定版から分岐した別案は、固定版本文をそのまま保持してください。");
				} catch (e) {
					W(r, `${t}.baseContent`, e instanceof Error ? e.message : "固定版本文と分岐元を比較できません。");
				}
			}
			let e = await n.validateContent(u.baseContent);
			if (e.ok || (e.issues ?? []).forEach((e) => W(r, `${t}.baseContent${e.path ? `.${e.path}` : ""}`, e.message)), Qe.test(u.baseContentHash ?? "")) try {
				await at(u.baseContent) !== u.baseContentHash && W(r, `${t}.baseContentHash`, "分岐元の内容SHA-256が一致しません。");
			} catch (e) {
				W(r, `${t}.baseContentHash`, e instanceof Error ? e.message : "分岐元の内容hashを確認できません。");
			}
			else W(r, `${t}.baseContentHash`, "分岐元の内容SHA-256がありません。");
		}
		if (!Array.isArray(u.versions) || !u.versions.length || u.versions.length > i.versions) {
			W(r, `${t}.versions`, `別案の版は1〜${i.versions}件で指定してください。`);
			continue;
		}
		let d = u.versions, f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map();
		for (let [i, o] of d.entries()) {
			let s = `${t}.versions[${i}]`;
			if ((!o || typeof o.id != "string" || f.has(o.id) || a.has(o.id)) && W(r, `${s}.id`, "別案版IDが不正または重複しています。"), typeof o?.id == "string" && (f.set(o.id, o), p.set(o.id, i), a.add(o.id)), (typeof o?.label != "string" || !o.label.trim() || !lt(o.createdAt)) && W(r, s, "別案版の名前または作成日時が不正です。"), !ct(o?.content) || o.content.projectId !== e) {
				W(r, `${s}.content`, "別案版の作品IDが一致しません。");
				continue;
			}
			Object.hasOwn(o.content, "authorAlternatives") && W(r, `${s}.content.authorAlternatives`, "別案版へ別案一覧を再帰保存できません。");
			let c = await n.validateContent(o.content);
			c.ok || (c.issues ?? []).forEach((e) => W(r, `${s}.content${e.path ? `.${e.path}` : ""}`, e.message)), o.structurePlan && ut(o.structurePlan, o.content, `${s}.structurePlan`, r);
			try {
				let e = await at({
					content: o.content,
					structurePlan: o.structurePlan ?? null
				});
				(!Qe.test(o.contentHash ?? "") || o.contentHash !== e) && W(r, `${s}.contentHash`, "別案版の内容SHA-256がありません、または一致しません。");
			} catch (e) {
				W(r, `${s}.contentHash`, e instanceof Error ? e.message : "別案版の内容hashを確認できません。");
			}
		}
		let m = d.filter((e) => e.parentVersionId === null);
		if (m.length !== 1 && W(r, `${t}.versions`, "別案履歴には親のない開始版が一つ必要です。"), m[0]) try {
			it(m[0].content) !== it(u.baseContent) && W(r, `${t}.versions`, "開始版は分岐元の内容を保持してください。");
		} catch (e) {
			W(r, `${t}.versions`, e instanceof Error ? e.message : "開始版と分岐元の内容を比較できません。");
		}
		let h = -Infinity;
		for (let [e, n] of d.entries()) {
			let i = `${t}.versions[${e}]`, a = Date.parse(n.createdAt);
			if (Number.isFinite(a) && a < h && W(r, `${i}.createdAt`, "別案の版は作成順に並べてください。"), Number.isFinite(a) && (h = a), n.parentVersionId !== null) {
				let t = p.get(n.parentVersionId ?? "");
				(t === void 0 || t >= e) && W(r, `${i}.parentVersionId`, "別案版の親が存在しないか、作成順の後にあります。");
			}
		}
		let g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set(), v = (e) => {
			if (_.has(e)) {
				W(r, `${t}.versions`, "別案版の親子関係に循環があります。");
				return;
			}
			if (g.has(e)) return;
			_.add(e);
			let n = f.get(e)?.parentVersionId;
			n && v(n), _.delete(e), g.add(e);
		};
		if (f.forEach((e, t) => v(t)), u.headVersionId !== d.at(-1)?.id && W(r, `${t}.headVersionId`, "別案の現在版は履歴の最後の版でなければなりません。"), !Array.isArray(u.applyReceipts)) W(r, `${t}.applyReceipts`, "正本採用履歴が不正です.");
		else {
			let e = /* @__PURE__ */ new Set(), n = -1n;
			u.applyReceipts.forEach((i, o) => {
				let s = `${t}.applyReceipts[${o}]`;
				if ((e.has(i.id) || a.has(i.id)) && W(r, `${s}.id`, "採用記録IDが重複しています。"), e.add(i.id), a.add(i.id), mt(i, f, u.sourceSnapshotId, s, r), $e.test(i.appliedRevision ?? "")) {
					let e = BigInt(i.appliedRevision);
					e <= n && W(r, `${s}.appliedRevision`, "正本採用履歴は版の昇順で並べてください。"), n = e;
				}
			});
		}
		try {
			let e = ot(u);
			(!Qe.test(u.integrityHash ?? "") || await at(e) !== u.integrityHash) && W(r, `${t}.integrityHash`, "作者別案全体のSHA-256がありません、または一致しません。");
		} catch (e) {
			W(r, `${t}.integrityHash`, e instanceof Error ? e.message : "作者別案のhashを確認できません。");
		}
		try {
			let e = new TextEncoder().encode(it(u)).byteLength;
			s += e, e > i.branchBytes && W(r, t, `別案は${i.branchBytes} bytesまでです。`);
		} catch (e) {
			W(r, t, e instanceof Error ? e.message : "別案をJSON化できません。");
		}
	}
	return s > i.totalBytes && W(r, "authorAlternatives", `作者別案全体は${i.totalBytes} bytesまでです。`), r;
}
//#endregion
//#region src/domain/runtimeRecordValidation.ts
function gt(e, t, n, r = "trace", i = {}) {
	try {
		e = a(e, e.snapshots);
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: r,
			message: e.message
		}];
	}
	let o = [], s = (e, t, n = "VALIDATION_FAILED") => o.push({
		code: n,
		path: `${r}.${e}`,
		message: t
	});
	if (t.mode !== "chapters") return t.readingPath && s("readingPath", "章の提示経路はmode:chaptersの記録に指定してください。"), o;
	let c = t.readingPath;
	if (!c) return s("readingPath", "章読み通し記録に提示経路がありません。"), o;
	let l = d(e, i.worldSnapshots ?? {});
	l.errors.length && s("worldReferences", l.errors[0], "REFERENCE_INVALID");
	let u = l.worlds.flatMap((e) => e.entities);
	o.push(...w(e, t.initialExternalValues ?? {}, void 0, u).map((e) => ({
		...e,
		path: `${r}.initialExternalValues.${e.path}`
	}))), t.initialWorldTick != null && n.worldTick != null && t.initialWorldTick !== n.worldTick && s("initialWorldTick", "保存した開始時点と章経路の提示時点が一致しません。", "INTEGRITY_FAILED"), t.steps.length && s("steps", "章読み通しにフロー遷移を混在させられません。"), (t.contentVersionId !== n.contentVersionId || n.runtimeState.contentVersionId !== t.contentVersionId) && s("contentVersionId", "開始状態と読み通しの固定版が一致しません。"), (t.contentRevision !== e.revision || n.contentRevision !== e.revision) && s("contentRevision", "章読み通しには開始状態と内容版に一致する更新番号が必要です。"), (n.origin !== "partial" || n.runtimeState.presentationPosition !== null) && s("startCheckpointId", "章読み通しの開始状態はフロー位置を持たない途中開始です。"), c.occurrences.length > c.sceneIds.length && s("readingPath.occurrences", "実際の提示数が計画した場面数を超えています。");
	let f = /* @__PURE__ */ new Set(), p = n.runtimeState;
	for (let [i, a] of c.occurrences.entries()) {
		let l = `readingPath.occurrences[${i}]`;
		(!a.occurrenceId.trim() || f.has(a.occurrenceId)) && s(`${l}.occurrenceId`, "提示の識別子が空か重複しています。"), f.add(a.occurrenceId), a.entityId !== c.sceneIds[i] && s(`${l}.entityId`, "提示した場面が計画した場面の順序と一致しません。"), (a.before.contentVersionId !== t.contentVersionId || a.after.contentVersionId !== t.contentVersionId || a.before.presentationPosition !== null || a.after.presentationPosition !== null) && s(l, "提示状態の内容版またはフロー位置が不正です。"), k(a.before) !== k(p) && s(`${l}.before`, "提示状態が開始状態または直前の提示とつながりません。", "INTEGRITY_FAILED"), k(a.externalValues ?? {}) !== k(t.initialExternalValues ?? {}) && s(`${l}.externalValues`, "章読み通し中に、記録した外部入力を未記録の操作で変更できません。", "INTEGRITY_FAILED");
		let d = j(e, a.before, {
			sceneId: a.entityId,
			worldTick: t.initialWorldTick ?? n.worldTick ?? void 0,
			previousSceneId: c.occurrences[i - 1]?.entityId,
			last: i + 1 === c.sceneIds.length,
			externalValues: a.externalValues ?? t.initialExternalValues ?? {},
			referenceEntities: u
		});
		if (d.ok) k(d.state) !== k(a.after) && s(`${l}.after`, "記録した提示後の状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED"), a.presentationState && k(d.observationState) !== k(a.presentationState) && s(`${l}.presentationState`, "提示前の観測状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED"), k(d.conditions) !== k(a.conditionResults) && s(`${l}.conditionResults`, "提示時の条件根拠が不足・重複・矛盾しています。", "INTEGRITY_FAILED");
		else for (let e of d.issues) o.push({
			...e,
			path: `${r}.${l}.${e.path}`
		});
		p = a.after;
	}
	return o;
}
//#endregion
//#region src/domain/projectRecordValidation.ts
function _t(e) {
	return {
		...e,
		history: []
	};
}
function vt(e, t) {
	return t.length >= e.length && e.every((e, n) => k(e) === k(t[n]));
}
function yt(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = (e) => {
		let t = a.get(e);
		return t || (t = [], a.set(e, t)), t;
	}, s = o("local"), c = e.history.findIndex((e) => !e.importOrigin);
	c >= 0 && s.push({
		label: `project.history[${c}].before`,
		state: e.history[c].before
	});
	for (let [t, n] of e.history.entries()) {
		let e = n.importOrigin, r = o(e ? `import:${e.importOperationId}` : "local");
		e && !r.length && r.push({
			label: `project.history[${t}].before`,
			state: n.before
		}), r.push({
			label: `project.history[${t}].after`,
			state: n.after
		});
	}
	let l = e;
	(!s.length || s.at(-1)?.state.revision !== e.revision) && s.push({
		label: "project",
		state: l
	});
	for (let e of a.values()) {
		let a = /* @__PURE__ */ new Map();
		for (let { label: o, state: s } of e) {
			let e = new Map((s.authorAlternatives ?? []).map((e) => [e.id, e]));
			for (let [n, r] of a) {
				let i = e.get(n);
				if (!i) {
					t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives`,
						message: `過去に保存した別案「${n}」が履歴から失われています。`
					});
					continue;
				}
				vt(r.versions, i.versions) || t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${n}.versions`,
					message: "別案版の履歴は削除・書換えできません。"
				}), vt(r.applyReceipts, i.applyReceipts) || t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${n}.applyReceipts`,
					message: "正本採用記録は削除・書換えできません。"
				});
			}
			for (let a of e.values()) {
				let e = k({
					projectId: a.projectId,
					baseRevision: a.baseRevision,
					sourceSnapshotId: a.sourceSnapshotId ?? null,
					baseContent: a.baseContent,
					baseContentHash: a.baseContentHash,
					createdAt: a.createdAt
				}), s = i.get(a.id);
				s !== void 0 && s !== e ? t.push({
					code: "INTEGRITY_FAILED",
					path: `${o}.authorAlternatives.${a.id}`,
					message: "別案IDが異なる分岐元の内容に再利用されています。"
				}) : i.set(a.id, e);
				for (let e of a.versions) {
					let r = n.get(e.id);
					r && k(r) !== k(e) ? t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives.${a.id}.versions.${e.id}`,
						message: "不変の別案版IDが異なる内容へ再利用されています。"
					}) : n.set(e.id, e);
				}
				for (let e of a.applyReceipts) {
					let n = r.get(e.id);
					n && k(n) !== k(e) ? t.push({
						code: "INTEGRITY_FAILED",
						path: `${o}.authorAlternatives.${a.id}.applyReceipts.${e.id}`,
						message: "不変の正本採用記録IDが異なる内容へ再利用されています。"
					}) : r.set(e.id, e);
				}
			}
			a = e;
		}
	}
	return t;
}
function bt(e) {
	let t = /* @__PURE__ */ new Set([e.projectId]);
	for (let n of [...e.entities, ...e.relations]) t.add(n.id);
	for (let n of e.snapshots) {
		t.add(n.id);
		for (let r of e.entities) r.kind === "snapshot" && r.id === n.id && t.add(r.id);
	}
	for (let n of e.history) t.add(n.operationId);
	return t;
}
async function xt(e, t, n, r) {
	let i = [], a = e.snapshots, o = await G(e.projectId, e.authorAlternatives ?? [], {
		snapshotIds: new Set(a.map((e) => e.id)),
		snapshots: a,
		reservedIds: bt(e),
		validateContent: async (e) => {
			let i = await p(e, t.worldSnapshots ?? {}, `${n}.authorAlternatives.worldReferences`, r), o = T({
				...e,
				snapshots: a,
				history: []
			}, t);
			return o.ok && !i.length ? { ok: !0 } : {
				ok: !1,
				issues: [...i, ...o.ok ? [] : o.issues]
			};
		}
	});
	for (let e of o) i.push({
		code: "INTEGRITY_FAILED",
		path: `${n}.${e.path}`,
		message: e.message
	});
	return i;
}
async function St(e, t, n) {
	let r = [];
	for (let [i, o] of e.entities.entries()) {
		if (o.kind !== "trace") continue;
		let s = `project.entities[${i}].data`, c = e.entities.find((e) => e.id === o.data.startCheckpointId && e.kind === "checkpoint");
		if (!c || c.kind !== "checkpoint") {
			r.push({
				code: "REFERENCE_INVALID",
				path: `${s}.startCheckpointId`,
				message: "経路の開始状態が見つかりません。"
			});
			continue;
		}
		try {
			let i = await v(e, o.data.contentVersionId, t, n);
			if (o.data.mode === "chapters") r.push(...gt(i, o.data, c.data, s, t));
			else {
				let { replaySavedTrace: n } = await import("./runtime-fwDPINsl.js"), c = d(a(i, i.snapshots), t.worldSnapshots ?? {}), l = n(e, o.id, c.worlds.flatMap((e) => e.entities));
				l.status === "error" && r.push(...l.issues.map((e) => ({
					...e,
					path: `${s}.${e.path}`
				})));
			}
		} catch (e) {
			let t = e.issues;
			t?.length ? r.push(...t.map((e) => ({
				...e,
				path: `${s}.${e.path}`
			}))) : r.push({
				code: "INTEGRITY_FAILED",
				path: `${s}.contentVersionId`,
				message: e instanceof Error ? e.message : "章読み通しの固定版本文を確認できません。"
			});
		}
	}
	return r;
}
async function K(e, t = {}, n = e.history.length > 0, r) {
	try {
		let { verifyStoredGameEvidence: n } = await import("./gameProtocol-BzD1jUJl.js");
		await n(e, t.worldSnapshots ?? {});
	} catch (e) {
		return [{
			code: "INTEGRITY_FAILED",
			path: "project.entities.handoffReceipt",
			message: e.message
		}];
	}
	let a = f(), o = {
		...t,
		worldSnapshots: i(t.worldSnapshots ?? {}, a),
		worlds: t.worlds ? structuredClone(t.worlds) : void 0
	}, s = r && !n && !e.history.length ? E(e, o, r) : T(e, o);
	if (!s.ok) return s.issues;
	let c = [], l = (e, t, n) => {
		let r = new Map(e.filter((e) => e.kind === "review" && e.data.sharedSource).map((e) => [e.id, e]));
		for (let e of t) {
			let t = r.get(e.id);
			e.kind === "review" && t?.kind === "review" && (k(t.data.sharedSource) !== k(e.data.sharedSource ?? null) && c.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.sharedSource`,
				message: "元の共有指摘・公開版・位置・引用の記録は変更できません。解決文を別に保存してください。"
			}), k([
				t.data.target,
				t.data.targetVersionId,
				t.data.quotedText ?? null
			]) !== k([
				e.data.target,
				e.data.targetVersionId,
				e.data.quotedText ?? null
			]) && c.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.target`,
				message: "元の共有指摘の私的固定版と引用は変更できません。現在稿の修正は別に保存してください。"
			}), t.data.stage === "open" && e.data.stage === "verified" && c.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.${e.id}.data.stage`,
				message: "共有指摘は修正済みを保存してから再確認してください。"
			}));
		}
	};
	r && l(r.previous.entities, e.entities, "project.entities");
	for (let [t, n] of e.history.entries()) l(n.before.entities, n.after.entities, `project.history[${t}].after.entities`);
	c.push(...await p(e, o.worldSnapshots, "project.worldReferences", a));
	for (let [t, n] of e.snapshots.entries()) c.push(...await p(n.content, o.worldSnapshots, `project.snapshots[${t}].content.worldReferences`, a));
	if (c.push(...await xt(e, o, "project", a)), c.push(...await St(e, o, a)), c.push(...yt(e)), n) for (let [t, n] of (e.authorAlternatives ?? []).entries()) for (let [r, i] of n.applyReceipts.entries()) {
		let n = `project.authorAlternatives[${t}].applyReceipts[${r}]`, a = e.history.find((e) => e.revision === i.appliedRevision && e.before.revision === i.fromCanonicalRevision && i.patches.every((t) => {
			let n = pt(e.before, t), r = pt(e.after, t), i = t.before.present ? t.before.value : void 0, a = t.after.present ? t.after.value : void 0;
			return k(n ?? null) === k(i ?? null) && n === void 0 == !t.before.present && k(r ?? null) === k(a ?? null) && r === void 0 == !t.after.present;
		}));
		if (!a) {
			c.push({
				code: "INTEGRITY_FAILED",
				path: n,
				message: "正本採用記録に対応する不変の変更履歴がありません。"
			});
			continue;
		}
		for (let [e, t] of i.patches.entries()) {
			let r = pt(a.before, t), i = pt(a.after, t), o = t.before.present ? t.before.value : void 0, s = t.after.present ? t.after.value : void 0;
			(k(r ?? null) !== k(o ?? null) || r === void 0 != !t.before.present) && c.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.patches[${e}].before`,
				message: "採用前の正本値が対応する変更履歴と一致しません。"
			}), (k(i ?? null) !== k(s ?? null) || i === void 0 != !t.after.present) && c.push({
				code: "INTEGRITY_FAILED",
				path: `${n}.patches[${e}].after`,
				message: "採用後の正本値が対応する変更履歴と一致しません。"
			});
		}
	}
	for (let [t, n] of e.history.entries()) for (let e of ["before", "after"]) {
		let r = n[e], i = _t(r);
		c.push(...await p(i, o.worldSnapshots, `project.history[${t}].${e}.worldReferences`, a));
		for (let [n, r] of i.snapshots.entries()) c.push(...await p(r.content, o.worldSnapshots, `project.history[${t}].${e}.snapshots[${n}].content.worldReferences`, a));
		r.authorAlternatives?.length && c.push(...await xt(i, o, `project.history[${t}].${e}`, a)), c.push(...await St(i, o, a));
	}
	return c.slice(0, 256);
}
//#endregion
//#region src/sync/merge.ts
function Ct(e) {
	return e ? {
		fields: e.fields,
		tombstone: e.tombstone
	} : null;
}
function wt(e, t, n) {
	n.present && (e[t] = L(n.value));
}
function Tt(e, t, n, r) {
	return {
		targetId: t.id,
		base: L(e),
		local: L(t),
		server: L(n),
		reasons: r,
		fields: [],
		automaticFields: {}
	};
}
function Et(e, t, n) {
	I(t);
	for (let r of [e, n]) if (r && (I(r), r.id !== t.id || r.projectId !== t.projectId)) throw new R("PROTOCOL_INVALID");
	if (!e) return !n || F(Ct(t), Ct(n)) ? {
		status: "merged",
		document: L(n ?? t)
	} : {
		status: "conflict",
		conflict: Tt(e, t, n, ["concurrent-create"])
	};
	if (!n) return {
		status: "conflict",
		conflict: Tt(e, t, n, ["missing-server-record"])
	};
	let r = !F(Ct(e), Ct(t)), i = !F(Ct(e), Ct(n));
	if (!r) return {
		status: "merged",
		document: L(n)
	};
	if (!i) return {
		status: "merged",
		document: L(t)
	};
	if (F(Ct(t), Ct(n))) return {
		status: "merged",
		document: L(n)
	};
	let a = t.tombstone !== null, o = n.tombstone !== null, s = !F(e.tombstone, t.tombstone), c = !F(e.tombstone, n.tombstone);
	if (a !== o && (s || c)) return {
		status: "conflict",
		conflict: Tt(e, t, n, ["delete-versus-edit"])
	};
	if (a || o) return a && o && F(t.fields, n.fields) ? {
		status: "merged",
		document: L(n)
	} : {
		status: "conflict",
		conflict: Tt(e, t, n, ["delete-versus-edit"])
	};
	let l = L(n);
	l.fields = {};
	let u = Tt(e, t, n, ["same-field"]), d = [.../* @__PURE__ */ new Set([
		...Object.keys(e.fields),
		...Object.keys(t.fields),
		...Object.keys(n.fields)
	])].sort();
	for (let r of d) {
		let i = ae(e, r), a = ae(t, r), o = ae(n, r), s;
		if (F(a, o)) s = a;
		else if (F(a, i)) s = o;
		else if (F(o, i)) s = a;
		else {
			u.fields.push({
				field: r,
				base: i,
				local: a,
				server: o
			});
			continue;
		}
		u.automaticFields[r] = L(s), wt(l.fields, r, s);
	}
	return u.fields.length ? {
		status: "conflict",
		conflict: u
	} : {
		status: "merged",
		document: l
	};
}
function Dt(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) if (![
		"id",
		"projectId",
		"revision",
		"createdAt",
		"updatedAt",
		"deletedAt",
		"deleteOperationId",
		"deletionOperationId"
	].includes(n)) {
		if (n === "$tombstone" || n.startsWith("data.")) throw new R("PROTOCOL_INVALID");
		if (n === "data" && r && typeof r == "object" && !Array.isArray(r)) for (let [e, n] of Object.entries(r)) {
			if (e.includes(".")) throw new R("PROTOCOL_INVALID");
			n !== void 0 && (t["data." + e] = L(n));
		}
		else r !== void 0 && (t[n] = L(r));
	}
	return t;
}
//#endregion
//#region src/sync/validation.ts
async function Ot(e, t) {
	await se(e, t);
	let n = [];
	for (let [r, i] of e.targets.entries()) {
		let e = t.documents[r], a = Et(i.base, i.local, e);
		if (t.status === "applied") {
			if (a.status !== "merged" || !e || !F({
				fields: a.document.fields,
				tombstone: a.document.tombstone
			}, {
				fields: e.fields,
				tombstone: e.tombstone
			})) throw new R("PROTOCOL_INVALID");
		} else a.status === "conflict" && n.push(a.conflict);
	}
	if (t.status === "conflict" && !F(t.conflicts, n)) throw new R("PROTOCOL_INVALID");
}
//#endregion
//#region src/sync/adapter.ts
function kt(e) {
	if (e.deletedAt && !e.deletionOperationId) throw new R("PROTOCOL_INVALID");
	let t = {
		id: e.id,
		projectId: e.projectId,
		revision: e.revision,
		fields: Dt(e),
		tombstone: e.deletedAt ? {
			deletedAt: e.deletedAt,
			operationId: e.deletionOperationId
		} : null
	};
	return I(t), t;
}
//#endregion
//#region src/sync/nativeBridge.ts
function At(e, t) {
	let { entities: n, relations: r, history: i, ...a } = e;
	return [
		kt({
			...a,
			id: e.projectId,
			kind: "project",
			visibility: "private",
			revision: t,
			entityIds: n.map((e) => e.id),
			relationIds: r.map((e) => e.id)
		}),
		...n.map((e) => {
			let n = kt({
				...e,
				revision: t
			});
			return n.fields.createdAt = e.createdAt, n;
		}),
		...r.map((e) => kt({
			...e,
			revision: t
		}))
	];
}
function jt(e, t) {
	return F(e ? {
		fields: e.fields,
		tombstone: e.tombstone
	} : null, t ? {
		fields: t.fields,
		tombstone: t.tombstone
	} : null);
}
function Mt(e) {
	let t = {
		id: e.id,
		projectId: e.projectId,
		revision: e.revision
	};
	for (let [n, r] of Object.entries(e.fields)) if (n.startsWith("data.")) {
		let e = n.slice(5);
		if (!e || e.includes(".") || [
			"__proto__",
			"prototype",
			"constructor"
		].includes(e)) throw new R("PROTOCOL_INVALID");
		t.data ??= {}, t.data[e] = L(r);
	} else {
		if ([
			"id",
			"projectId",
			"revision",
			"updatedAt",
			"deletedAt",
			"deletionOperationId",
			"__proto__",
			"prototype",
			"constructor"
		].includes(n)) throw new R("PROTOCOL_INVALID");
		t[n] = L(r);
	}
	return e.tombstone && (t.deletedAt = e.tombstone.deletedAt, t.deletionOperationId = e.tombstone.operationId), t;
}
function q(e, t, n) {
	let r = new Map(t.map((e) => [e.id, e]));
	if (r.size !== t.length) throw new R("PROTOCOL_INVALID");
	let i = r.get(e.projectId);
	if (!i || i.fields.kind !== "project" || i.tombstone) throw new R("PROTOCOL_INVALID");
	let { id: a, kind: o, visibility: s, entityIds: c, relationIds: l, ...u } = Mt(i);
	if (!Array.isArray(c) || !Array.isArray(l) || [...c, ...l].some((e) => typeof e != "string") || (/* @__PURE__ */ new Set([
		...c,
		...l,
		i.id
	])).size !== t.length) throw new R("PROTOCOL_INVALID");
	let d = new Map([...e.entities, ...e.relations].map((e) => [e.id, e])), f = (t, i) => {
		let a = r.get(t);
		if (!a || a.projectId !== e.projectId) throw new R("PROTOCOL_INVALID");
		let o = Mt(a), s = d.get(a.id);
		if (i) {
			if (o.createdAt = o.createdAt ?? (s && "createdAt" in s ? s.createdAt : n), s && "createdAt" in s && s.createdAt !== o.createdAt) throw new R("PROTOCOL_INVALID");
			o.updatedAt = s && "updatedAt" in s ? s.updatedAt : n;
		}
		return o.revision = s?.revision ?? "0", a.tombstone || (delete o.deletedAt, delete o.deletionOperationId), o;
	};
	return {
		...u,
		projectId: e.projectId,
		revision: e.revision,
		entities: c.map((e) => f(e, !0)),
		relations: l.map((e) => f(e, !1)),
		history: e.history
	};
}
async function Nt(e, t, n, r, i) {
	e = L(e);
	let a = L(n), o = L(t), s = L(r), c = At(a, o.serverRevision), l = new Map(o.documents.map((e) => [e.id, e])), d = c.filter((e) => !jt(l.get(e.id), e)).map((e) => ({
		base: l.get(e.id) ?? null,
		local: e
	}));
	if (o.documents.some((e) => !c.some((t) => t.id === e.id))) throw new R("PROTOCOL_INVALID");
	if (!d.length) return null;
	let f = await re({
		scope: L(e),
		baseRevision: o.serverRevision,
		operationId: u(),
		targets: d,
		reason: i
	});
	return {
		operationId: f.operationId,
		projectId: e.projectId,
		operation: f,
		localRevision: a.revision,
		localDocuments: c,
		outboxIds: s,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function Pt(e, t, n, r) {
	if (BigInt(n.serverRevision) < BigInt(t.serverRevision) || !n.confirmedDocuments) throw new R("PROTOCOL_INVALID");
	let i = new Map(n.confirmedDocuments.map((e) => [e.id, L(e)])), a = Array.isArray(r) ? r : At(r, n.serverRevision), o = new Map(e.localDocuments.map((e) => [e.id, e])), s = [], c = [];
	for (let e of a) {
		let t = i.get(e.id) ?? null, n = o.get(e.id) ?? null;
		if (!n && !t) {
			c.push(L(e));
			continue;
		}
		let r = Et(n, e, t);
		r.status === "conflict" ? (s.push(r.conflict), c.push(L(e))) : c.push(r.document);
	}
	for (let e of i.values()) c.some((t) => t.id === e.id) || c.push(L(e));
	return {
		confirmed: [...i.values()],
		documents: c,
		conflicts: s
	};
}
function Ft(e, t, n, r) {
	let i = new Map(n.map((e) => [e.id, e])), a = new Map((Array.isArray(r) ? r : At(r, e.ack.serverRevision)).map((e) => [e.id, e]));
	if (!F(Object.keys(t).sort(), e.conflicts.map((e) => e.targetId).sort())) throw new R("PROTOCOL_INVALID");
	let o = /* @__PURE__ */ new Set([
		...e.prepared.operation.targets.map((e) => e.targetId),
		...e.conflicts.map((e) => e.targetId),
		...a.keys()
	]), s = [];
	for (let n of o) {
		let r = i.get(n) ?? null, o = a.get(n), c = e.prepared.operation.targets.find((e) => e.targetId === n), l = e.conflicts.find((e) => e.targetId === n);
		if (!o) throw new R("PROTOCOL_INVALID");
		let u = L(o);
		if (l) {
			if (!F(l.server, r)) throw new R("REVISION_CHANGED");
			let e = Et(l.base, o, r), i = t[n];
			if (e.status === "merged") u = e.document;
			else if (i.strategy === "fields") {
				if (e.conflict.reasons.some((e) => e !== "same-field") || !F(Object.keys(i.choices).sort(), e.conflict.fields.map((e) => e.field).sort()) || !r) throw new R("REVISION_CHANGED");
				u = L(r), u.fields = {};
				for (let [t, n] of Object.entries(e.conflict.automaticFields)) n.present && (u.fields[t] = L(n.value));
				for (let t of e.conflict.fields) {
					let e = i.choices[t.field], n = e === "local" ? t.local : e === "server" ? t.server : e.value;
					n.present && (u.fields[t.field] = L(n.value));
				}
			} else if (e.conflict.reasons.every((e) => e === "same-field") && r) {
				u = L(r), u.fields = {};
				for (let [t, n] of Object.entries(e.conflict.automaticFields)) n.present && (u.fields[t] = L(n.value));
				for (let t of e.conflict.fields) {
					let e = i.strategy === "local" ? t.local : t.server;
					e.present && (u.fields[t.field] = L(e.value));
				}
			} else u = L(i.strategy === "local" ? o : r ?? (() => {
				throw new R("BASE_UNAVAILABLE");
			})());
		} else if (e.ack.status === "conflict" && c) {
			let e = Et(c.base, o, r);
			if (e.status === "conflict") throw new R("REVISION_CHANGED");
			u = e.document;
		}
		(c || l || !jt(r, u)) && s.push({
			base: L(r),
			local: u
		});
	}
	return s;
}
//#endregion
//#region src/storage/syncRecovery.ts
function It(e = []) {
	return e.flatMap((e) => {
		let t = [];
		e.base && t.push(e.base.documents);
		for (let n of e.prepared) t.push(n.localDocuments);
		for (let n of e.conflicts) t.push(n.prepared.localDocuments), n.ack.confirmedDocuments && t.push(n.ack.confirmedDocuments);
		for (let n of e.acknowledgements) n.ack.confirmedDocuments && t.push(n.ack.confirmedDocuments);
		return [L(e.origin), ...t.map((t) => q(e.origin, t, "1970-01-01T00:00:00.000Z"))].map((e) => ({
			...e,
			history: []
		}));
	});
}
async function Lt(e, t, n) {
	if (!Array.isArray(e) || e.length > 1e5) throw new M("VALIDATION_FAILED", "同期復元証跡の形式・件数が不正です。");
	let r = L(e), i = /* @__PURE__ */ new Set();
	try {
		for (let e of r) {
			if (O(n), !e || e.format !== "scenario-sync-recovery" || e.version !== 1 || e.state !== "needs_reconnect" || !e.origin || !C.test(e.origin.projectId) || !Array.isArray(e.prepared) || !Array.isArray(e.conflicts) || !Array.isArray(e.acknowledgements) || Object.keys(e).some((e) => ![
				"format",
				"version",
				"state",
				"origin",
				"base",
				"prepared",
				"conflicts",
				"acknowledgements",
				"assetAcknowledgements",
				"contentHash"
			].includes(e))) throw new R("PROTOCOL_INVALID");
			let { contentHash: r, ...a } = e;
			if (await ie(a) !== r || i.has(r) || (i.add(r), e.base && (!z(e.base.serverRevision) || !Array.isArray(e.base.documents) || e.base.documents.length > 100001 || e.base.projectId !== e.origin.projectId || await ie(e.base.documents) !== e.base.contentHash))) throw new R("PROTOCOL_INVALID");
			if (e.base) for (let t of e.base.documents) P(t, {
				accountId: "00000000-0000-4000-8000-000000000001",
				projectId: e.origin.projectId
			}, t.id);
			if (e.assetAcknowledgements) {
				if (!Array.isArray(e.assetAcknowledgements)) throw new R("PROTOCOL_INVALID");
				for (let t of e.assetAcknowledgements) if (t.projectId !== e.origin.projectId || t.key !== `${t.projectId}:${t.contentHash}` || !/^[0-9a-f]{64}$/.test(t.contentHash) || !Number.isSafeInteger(t.byteSize) || t.byteSize < 0 || t.byteSize > 33554432 || typeof t.mediaType != "string") throw new R("PROTOCOL_INVALID");
			}
			for (let t of [...e.prepared, ...e.conflicts.map((e) => e.prepared)]) {
				if (await oe(t.operation), t.operationId !== t.operation.operationId || t.projectId !== e.origin.projectId || t.operation.scope.projectId !== t.projectId || !z(t.localRevision) || !Array.isArray(t.localDocuments) || t.localDocuments.length > 100001 || !Array.isArray(t.outboxIds) || t.outboxIds.length > 1e5 || new Set(t.outboxIds).size !== t.outboxIds.length || t.outboxIds.some((e) => !C.test(e)) || !Number.isFinite(Date.parse(t.createdAt)) || t.origin !== void 0 && !["prepared_operation", "received_image"].includes(t.origin)) throw new R("PROTOCOL_INVALID");
				for (let e of t.localDocuments) P(e, t.operation.scope, e.id);
				for (let e of t.operation.targets) if (!F(e.local, t.localDocuments.find((t) => t.id === e.targetId))) throw new R("PROTOCOL_INVALID");
			}
			for (let t of e.conflicts) if (t.operationId !== t.prepared.operationId || t.projectId !== e.origin.projectId || (await Ot(t.prepared.operation, t.ack), !Array.isArray(t.conflicts) || t.conflicts.some((e) => {
				let t = Et(e.base, e.local, e.server);
				return t.status !== "conflict" || !F(t.conflict, e);
			})) || t.ack.status === "conflict" && JSON.stringify(t.conflicts) !== JSON.stringify(t.ack.conflicts)) throw new R("PROTOCOL_INVALID");
			for (let t of e.acknowledgements) {
				if (t.origin !== void 0 && !["prepared_operation", "received_image"].includes(t.origin) || t.projectId !== e.origin.projectId || t.operationId !== t.operation.operationId) throw new R("PROTOCOL_INVALID");
				await oe(t.operation), await Ot(t.operation, t.ack);
			}
			for (let r of It([e])) if (O(n), !T(r, { worldSnapshots: t }).ok || (await K(r, { worldSnapshots: t }, !1)).length) throw new R("PROTOCOL_INVALID");
		}
	} catch {
		throw n?.aborted && O(n), new M("VALIDATION_FAILED", "同期の共通元・二案・ACK・hashの整合性を確認できません。");
	}
	return r;
}
//#endregion
//#region src/storage/recordDictionary.ts
var Rt = "shared-records-v1", zt = (e) => !!e && typeof e == "object" && !Array.isArray(e), Bt = (e) => zt(e) && typeof e.id == "string" && typeof e.projectId == "string" && (typeof e.kind == "string" && zt(e.data) || typeof e.relationType == "string" && typeof e.fromId == "string" && typeof e.toId == "string" || typeof e.revision == "string" && zt(e.fields) && Object.hasOwn(e, "tombstone")), Vt = class {
	records = [];
	arrays = [];
	ids = /* @__PURE__ */ new Map();
	identities = /* @__PURE__ */ new WeakMap();
	arrayIds = /* @__PURE__ */ new Map();
	previous = /* @__PURE__ */ new Map();
	add(e) {
		let t = this.identities.get(e);
		if (t !== void 0) return t;
		let n = k(e), r = this.ids.get(n);
		return r === void 0 && (r = this.records.length, this.records.push(e), this.ids.set(n, r)), this.identities.set(e, r), r;
	}
	encode(e) {
		let t = [], n = [], r = (e, i) => {
			if (Array.isArray(e)) {
				if (e.length && e.every(Bt)) {
					t.push(i);
					let n = e.map((e) => this.add(e)), r = n.join(","), a = this.arrayIds.get(r);
					if (a === void 0) {
						a = this.arrays.length;
						let e = this.previous.get(n.length), t = e ? n.flatMap((t, n) => t === e.values[n] ? [] : [[n, t]]) : void 0;
						this.arrays.push(e && t && t.length * 2 < n.length ? {
							base: e.id,
							length: n.length,
							changes: t
						} : { values: n }), this.arrayIds.set(r, a);
					}
					return this.previous.set(n.length, {
						id: a,
						values: n
					}), a;
				}
				return e.map((e, t) => r(e, [...i, t]));
			}
			return zt(e) ? Bt(e) ? (n.push(i), this.add(e)) : Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0).map(([e, t]) => [e, r(t, [...i, e])])) : e;
		};
		return {
			version: 1,
			value: r(e, []),
			arrays: t,
			records: n
		};
	}
}, J = Uint8Array, Y = Uint16Array, Ht = Int32Array, Ut = new J([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), Wt = new J([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), Gt = new J([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), Kt = function(e, t) {
	for (var n = new Y(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new Ht(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, qt = Kt(Ut, 2), Jt = qt.b, Yt = qt.r;
Jt[28] = 258, Yt[258] = 28;
var Xt = Kt(Wt, 0);
Xt.b;
for (var Zt = Xt.r, Qt = new Y(32768), $t = 0; $t < 32768; ++$t) {
	var en = ($t & 43690) >> 1 | ($t & 21845) << 1;
	en = (en & 52428) >> 2 | (en & 13107) << 2, en = (en & 61680) >> 4 | (en & 3855) << 4, Qt[$t] = ((en & 65280) >> 8 | (en & 255) << 8) >> 1;
}
for (var tn = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new Y(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new Y(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new Y(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[Qt[d] >> c] = l;
	} else for (s = new Y(r), i = 0; i < r; ++i) e[i] && (s[i] = Qt[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), nn = new J(288), $t = 0; $t < 144; ++$t) nn[$t] = 8;
for (var $t = 144; $t < 256; ++$t) nn[$t] = 9;
for (var $t = 256; $t < 280; ++$t) nn[$t] = 7;
for (var $t = 280; $t < 288; ++$t) nn[$t] = 8;
for (var rn = new J(32), $t = 0; $t < 32; ++$t) rn[$t] = 5;
var an = /*#__PURE__*/ tn(nn, 9, 0), on = /*#__PURE__*/ tn(rn, 5, 0), sn = function(e) {
	return (e + 7) / 8 | 0;
}, cn = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new J(e.subarray(t, n));
}, ln = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], un = function(e, t, n) {
	var r = Error(t || ln[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, un), !n) throw r;
	return r;
}, dn = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8;
}, fn = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8, e[r + 2] |= n >> 16;
}, pn = function(e, t) {
	for (var n = [], r = 0; r < e.length; ++r) e[r] && n.push({
		s: r,
		f: e[r]
	});
	var i = n.length, a = n.slice();
	if (!i) return {
		t: bn,
		l: 0
	};
	if (i == 1) {
		var o = new J(n[0].s + 1);
		return o[n[0].s] = 1, {
			t: o,
			l: 1
		};
	}
	n.sort(function(e, t) {
		return e.f - t.f;
	}), n.push({
		s: -1,
		f: 25001
	});
	var s = n[0], c = n[1], l = 0, u = 1, d = 2;
	for (n[0] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	}; u != i - 1;) s = n[n[l].f < n[d].f ? l++ : d++], c = n[l != u && n[l].f < n[d].f ? l++ : d++], n[u++] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	};
	for (var f = a[0].s, r = 1; r < i; ++r) a[r].s > f && (f = a[r].s);
	var p = new Y(f + 1), m = mn(n[u - 1], p, 0);
	if (m > t) {
		var r = 0, h = 0, g = m - t, _ = 1 << g;
		for (a.sort(function(e, t) {
			return p[t.s] - p[e.s] || e.f - t.f;
		}); r < i; ++r) {
			var v = a[r].s;
			if (p[v] > t) h += _ - (1 << m - p[v]), p[v] = t;
			else break;
		}
		for (h >>= g; h > 0;) {
			var y = a[r].s;
			p[y] < t ? h -= 1 << t - p[y]++ - 1 : ++r;
		}
		for (; r >= 0 && h; --r) {
			var b = a[r].s;
			p[b] == t && (--p[b], ++h);
		}
		m = t;
	}
	return {
		t: new J(p),
		l: m
	};
}, mn = function(e, t, n) {
	return e.s == -1 ? Math.max(mn(e.l, t, n + 1), mn(e.r, t, n + 1)) : t[e.s] = n;
}, hn = function(e) {
	for (var t = e.length; t && !e[--t];);
	for (var n = new Y(++t), r = 0, i = e[0], a = 1, o = function(e) {
		n[r++] = e;
	}, s = 1; s <= t; ++s) if (e[s] == i && s != t) ++a;
	else {
		if (!i && a > 2) {
			for (; a > 138; a -= 138) o(32754);
			a > 2 && (o(a > 10 ? a - 11 << 5 | 28690 : a - 3 << 5 | 12305), a = 0);
		} else if (a > 3) {
			for (o(i), --a; a > 6; a -= 6) o(8304);
			a > 2 && (o(a - 3 << 5 | 8208), a = 0);
		}
		for (; a--;) o(i);
		a = 1, i = e[s];
	}
	return {
		c: n.subarray(0, r),
		n: t
	};
}, gn = function(e, t) {
	for (var n = 0, r = 0; r < t.length; ++r) n += e[r] * t[r];
	return n;
}, _n = function(e, t, n) {
	var r = n.length, i = sn(t + 2);
	e[i] = r & 255, e[i + 1] = r >> 8, e[i + 2] = e[i] ^ 255, e[i + 3] = e[i + 1] ^ 255;
	for (var a = 0; a < r; ++a) e[i + a + 4] = n[a];
	return (i + 4 + r) * 8;
}, vn = function(e, t, n, r, i, a, o, s, c, l, u) {
	dn(t, u++, n), ++i[256];
	for (var d = pn(i, 15), f = d.t, p = d.l, m = pn(a, 15), h = m.t, g = m.l, _ = hn(f), v = _.c, y = _.n, b = hn(h), x = b.c, S = b.n, C = new Y(19), w = 0; w < v.length; ++w) ++C[v[w] & 31];
	for (var w = 0; w < x.length; ++w) ++C[x[w] & 31];
	for (var T = pn(C, 7), E = T.t, D = T.l, O = 19; O > 4 && !E[Gt[O - 1]]; --O);
	var ee = l + 5 << 3, k = gn(i, nn) + gn(a, rn) + o, A = gn(i, f) + gn(a, h) + o + 14 + 3 * O + gn(C, E) + 2 * C[16] + 3 * C[17] + 7 * C[18];
	if (c >= 0 && ee <= k && ee <= A) return _n(t, u, e.subarray(c, c + l));
	var te, j, M, N;
	if (dn(t, u, 1 + (A < k)), u += 2, A < k) {
		te = tn(f, p, 0), j = f, M = tn(h, g, 0), N = h;
		var ne = tn(E, D, 0);
		dn(t, u, y - 257), dn(t, u + 5, S - 1), dn(t, u + 10, O - 4), u += 14;
		for (var w = 0; w < O; ++w) dn(t, u + 3 * w, E[Gt[w]]);
		u += 3 * O;
		for (var P = [v, x], re = 0; re < 2; ++re) for (var F = P[re], w = 0; w < F.length; ++w) {
			var ie = F[w] & 31;
			dn(t, u, ne[ie]), u += E[ie], ie > 15 && (dn(t, u, F[w] >> 5 & 127), u += F[w] >> 12);
		}
	} else te = an, j = nn, M = on, N = rn;
	for (var w = 0; w < s; ++w) {
		var I = r[w];
		if (I > 255) {
			var ie = I >> 18 & 31;
			fn(t, u, te[ie + 257]), u += j[ie + 257], ie > 7 && (dn(t, u, I >> 23 & 31), u += Ut[ie]);
			var ae = I & 31;
			fn(t, u, M[ae]), u += N[ae], ae > 3 && (fn(t, u, I >> 5 & 8191), u += Wt[ae]);
		} else fn(t, u, te[I]), u += j[I];
	}
	return fn(t, u, te[256]), u + j[256];
}, yn = /*#__PURE__*/ new Ht([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]), bn = /*#__PURE__*/ new J(0), xn = function(e, t, n, r, i, a) {
	var o = a.z || e.length, s = new J(r + o + 5 * (1 + Math.ceil(o / 7e3)) + i), c = s.subarray(r, s.length - i), l = a.l, u = (a.r || 0) & 7;
	if (t) {
		u && (c[0] = a.r >> 3);
		for (var d = yn[t - 1], f = d >> 13, p = d & 8191, m = (1 << n) - 1, h = a.p || new Y(32768), g = a.h || new Y(m + 1), _ = Math.ceil(n / 3), v = 2 * _, y = function(t) {
			return (e[t] ^ e[t + 1] << _ ^ e[t + 2] << v) & m;
		}, b = new Ht(25e3), x = new Y(288), S = new Y(32), C = 0, w = 0, T = a.i || 0, E = 0, D = a.w || 0, O = 0; T + 2 < o; ++T) {
			var ee = y(T), k = T & 32767, A = g[ee];
			if (h[k] = A, g[ee] = k, D <= T) {
				var te = o - T;
				if ((C > 7e3 || E > 24576) && (te > 423 || !l)) {
					u = vn(e, c, 0, b, x, S, w, E, O, T - O, u), E = C = w = 0, O = T;
					for (var j = 0; j < 286; ++j) x[j] = 0;
					for (var j = 0; j < 30; ++j) S[j] = 0;
				}
				var M = 2, N = 0, ne = p, P = k - A & 32767;
				if (te > 2 && ee == y(T - P)) for (var re = Math.min(f, te) - 1, F = Math.min(32767, T), ie = Math.min(258, te); P <= F && --ne && k != A;) {
					if (e[T + M] == e[T + M - P]) {
						for (var I = 0; I < ie && e[T + I] == e[T + I - P]; ++I);
						if (I > M) {
							if (M = I, N = P, I > re) break;
							for (var ae = Math.min(P, I - 2), oe = 0, j = 0; j < ae; ++j) {
								var se = T - P + j & 32767, L = se - h[se] & 32767;
								L > oe && (oe = L, A = se);
							}
						}
					}
					k = A, A = h[k], P += k - A & 32767;
				}
				if (N) {
					b[E++] = 268435456 | Yt[M] << 18 | Zt[N];
					var R = Yt[M] & 31, z = Zt[N] & 31;
					w += Ut[R] + Wt[z], ++x[257 + R], ++S[z], D = T + M, ++C;
				} else b[E++] = e[T], ++x[e[T]];
			}
		}
		for (T = Math.max(T, D); T < o; ++T) b[E++] = e[T], ++x[e[T]];
		u = vn(e, c, l, b, x, S, w, E, O, T - O, u), l || (a.r = u & 7 | c[u / 8 | 0] << 3, u -= 7, a.h = g, a.p = h, a.i = T, a.w = D);
	} else {
		for (var T = a.w || 0; T < o + l; T += 65535) {
			var ce = T + 65535;
			ce >= o && (c[u / 8 | 0] = l, ce = o), u = _n(c, u + 1, e.subarray(T, ce));
		}
		a.i = o;
	}
	return cn(s, 0, r + sn(u) + i);
}, Sn = /*#__PURE__*/ (function() {
	for (var e = /* @__PURE__ */ new Int32Array(256), t = 0; t < 256; ++t) {
		for (var n = t, r = 9; --r;) n = (n & 1 && -306674912) ^ n >>> 1;
		e[t] = n;
	}
	return e;
})(), Cn = function() {
	var e = -1;
	return {
		p: function(t) {
			for (var n = e, r = 0; r < t.length; ++r) n = Sn[n & 255 ^ t[r]] ^ n >>> 8;
			e = n;
		},
		d: function() {
			return ~e;
		}
	};
}, wn = function(e, t, n, r, i) {
	if (!i && (i = { l: 1 }, t.dictionary)) {
		var a = t.dictionary.subarray(-32768), o = new J(a.length + e.length);
		o.set(a), o.set(e, a.length), e = o, i.w = a.length;
	}
	return xn(e, t.level == null ? 6 : t.level, t.mem == null ? i.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5) : 20 : 12 + t.mem, n, r, i);
}, Tn = function(e, t) {
	var n = {};
	for (var r in e) n[r] = e[r];
	for (var r in t) n[r] = t[r];
	return n;
}, En = function(e, t, n) {
	for (; n; ++t) e[t] = n, n >>>= 8;
};
function Dn(e, t) {
	return wn(e, t || {}, 0, 0);
}
var On = function(e, t, n, r) {
	for (var i in e) {
		var a = e[i], o = t + i, s = r;
		Array.isArray(a) && (s = Tn(r, a[1]), a = a[0]), ArrayBuffer.isView(a) ? n[o] = [a, s] : (n[o += "/"] = [new J(0), s], On(a, o, n, r));
	}
}, kn = typeof TextEncoder < "u" && /*#__PURE__*/ new TextEncoder(), An = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	An.decode(bn, { stream: !0 });
} catch {}
function jn(e, t) {
	if (t) {
		for (var n = new J(e.length), r = 0; r < e.length; ++r) n[r] = e.charCodeAt(r);
		return n;
	}
	if (kn) return kn.encode(e);
	for (var i = e.length, a = new J(e.length + (e.length >> 1)), o = 0, s = function(e) {
		a[o++] = e;
	}, r = 0; r < i; ++r) {
		if (o + 5 > a.length) {
			var c = new J(o + 8 + (i - r << 1));
			c.set(a), a = c;
		}
		var l = e.charCodeAt(r);
		l < 128 || t ? s(l) : l < 2048 ? (s(192 | l >> 6), s(128 | l & 63)) : l > 55295 && l < 57344 ? (l = 65536 + (l & 1047552) | e.charCodeAt(++r) & 1023, s(240 | l >> 18), s(128 | l >> 12 & 63), s(128 | l >> 6 & 63), s(128 | l & 63)) : (s(224 | l >> 12), s(128 | l >> 6 & 63), s(128 | l & 63));
	}
	return cn(a, 0, o);
}
var Mn = function(e) {
	var t = 0;
	if (e) for (var n in e) {
		var r = e[n].length;
		r > 65535 && un(9), t += r + 4;
	}
	return t;
}, Nn = function(e, t, n, r, i, a, o, s) {
	var c = r.length, l = n.extra, u = s && s.length, d = Mn(l);
	En(e, t, o == null ? 67324752 : 33639248), t += 4, o != null && (e[t++] = 20, e[t++] = n.os), e[t] = 20, t += 2, e[t++] = n.flag << 1 | (a < 0 && 8), e[t++] = i && 8, e[t++] = n.compression & 255, e[t++] = n.compression >> 8;
	var f = new Date(n.mtime == null ? Date.now() : n.mtime), p = f.getFullYear() - 1980;
	if ((p < 0 || p > 119) && un(10), En(e, t, p << 25 | f.getMonth() + 1 << 21 | f.getDate() << 16 | f.getHours() << 11 | f.getMinutes() << 5 | f.getSeconds() >> 1), t += 4, a != -1 && (En(e, t, n.crc), En(e, t + 4, a < 0 ? -a - 2 : a), En(e, t + 8, n.size)), En(e, t + 12, c), En(e, t + 14, d), t += 16, o != null && (En(e, t, u), En(e, t + 6, n.attrs), En(e, t + 10, o), t += 14), e.set(r, t), t += c, d) for (var m in l) {
		var h = l[m], g = h.length;
		En(e, t, +m), En(e, t + 2, g), e.set(h, t + 4), t += 4 + g;
	}
	return u && (e.set(s, t), t += u), t;
}, Pn = function(e, t, n, r, i) {
	En(e, t, 101010256), En(e, t + 8, n), En(e, t + 10, n), En(e, t + 12, r), En(e, t + 16, i);
};
function Fn(e, t) {
	t ||= {};
	var n = {}, r = [];
	On(e, "", n, t);
	var i = 0, a = 0;
	for (var o in n) {
		var s = n[o], c = s[0], l = s[1], u = l.level == 0 ? 0 : 8, d = jn(o), f = d.length, p = l.comment, m = p && jn(p), h = m && m.length, g = Mn(l.extra);
		f > 65535 && un(11);
		var _ = u ? Dn(c, l) : c, v = _.length, y = Cn();
		y.p(c), r.push(Tn(l, {
			size: c.length,
			crc: y.d(),
			c: _,
			f: d,
			m,
			u: f != o.length || m && p.length != h,
			o: i,
			compression: u
		})), i += 30 + f + g + v, a += 76 + 2 * (f + g) + (h || 0) + v;
	}
	for (var b = new J(a + 22), x = i, S = a - i, C = 0; C < r.length; ++C) {
		var d = r[C];
		Nn(b, d.o, d, d.f, d.u, d.c.length);
		var w = 30 + d.f.length + Mn(d.extra);
		b.set(d.c, d.o + w), Nn(b, i, d, d.f, d.u, d.c.length, d.o, d.m), i += 16 + w + (d.m ? d.m.length : 0);
	}
	return Pn(b, i, r.length, S, x), b;
}
//#endregion
//#region src/storage/recovery.ts
function In(e) {
	return e?.pending.flatMap((e) => [e.command.before, e.command.after].map((e) => ({
		...e,
		history: []
	}))) ?? [];
}
function Ln(e, t) {
	let n = new Map(e.history.map((e) => [e.operationId, e]));
	for (let e of t?.pending ?? []) {
		let t = n.get(e.operationId);
		if (t && !o(t, e.command)) throw new M("OPERATION_CONFLICT", "送信待ちの内容が保存履歴と一致しません。", e.operationId);
		n.set(e.operationId, e.command);
	}
	return {
		...e,
		history: [...n.values()]
	};
}
async function Rn(t, n, r, i) {
	let a = (e, t = "data/recovery.json") => {
		throw new M("VALIDATION_FAILED", e, t);
	};
	if (!t || typeof t != "object" || Array.isArray(t)) return a("送信待ち復元情報はオブジェクトです。");
	let o = t;
	if (Object.keys(o).some((e) => ![
		"version",
		"projectId",
		"sourceRevision",
		"serverRevision",
		"pending"
	].includes(e)) || o.version !== 1 || o.projectId !== n.projectId || o.sourceRevision !== n.revision || typeof o.serverRevision != "string" || !/^(0|[1-9]\d*)$/.test(o.serverRevision) || !Array.isArray(o.pending) || o.pending.length > 1e5) return a("送信待ち復元情報の版・作品・基底版・件数が不正です。");
	let s = structuredClone(t), c = /* @__PURE__ */ new Set();
	for (let t of s.pending) {
		if (O(i), !t || typeof t != "object" || Object.keys(t).some((e) => ![
			"operationId",
			"command",
			"commandHash",
			"origin"
		].includes(e)) || !C.test(t.operationId) || c.has(t.operationId) || typeof t.commandHash != "string" || !/^[0-9a-f]{64}$/.test(t.commandHash)) return a("送信待ちの操作IDまたはhashが不正・重複しています。");
		if ("origin" in t && (!t.origin || typeof t.origin != "object" || Array.isArray(t.origin) || Object.keys(t.origin).some((e) => ![
			"projectId",
			"operationId",
			"serverRevision"
		].includes(e)) || !C.test(t.origin.projectId) || !C.test(t.origin.operationId) || !/^(0|[1-9]\d*)$/.test(t.origin.serverRevision))) return a("送信待ちの元操作の記録が不正です。");
		if (c.add(t.operationId), !t.command || t.command.operationId !== t.operationId || t.command.projectId !== n.projectId || await e(m(t.command)) !== t.commandHash) return a("送信待ち操作の内容が固定したhashと一致しません。");
		let o = {
			...t.command.after,
			history: [t.command]
		}, l = T(o, { worldSnapshots: r });
		if (!l.ok) return a(l.issues.map((e) => `${e.path}: ${e.message}`).join("\n"));
		for (let e of In({
			...s,
			pending: [t]
		})) {
			let t = await K(e, { worldSnapshots: r }, !1);
			if (t.length) return a(t.map((e) => e.message).join("\n"));
		}
	}
	return Ln(n, s), s;
}
//#endregion
//#region src/storage/archiveData.ts
var zn = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/, Bn = /^[0-9a-f]{64}$/, Vn = /^(?:manifest\.json|data\/(?:project|recovery|sync-recovery|records)\.json|worlds\/[0-9a-f-]{36}\.json|assets\/[0-9a-f]{64}\.[a-z0-9]{1,8})$/, Hn = {
	"image/png": ["png"],
	"image/jpeg": ["jpg", "jpeg"],
	"image/gif": ["gif"],
	"image/webp": ["webp"],
	"audio/mpeg": ["mp3"],
	"audio/wav": ["wav"],
	"audio/x-wav": ["wav"],
	"audio/ogg": ["ogg"],
	"video/mp4": ["mp4"],
	"video/webm": ["webm"],
	"application/pdf": ["pdf"],
	"text/plain": ["txt"],
	"application/json": ["json"],
	"application/octet-stream": ["bin"]
};
function Un(e, t = "application/octet-stream") {
	let n = Hn[t];
	if (!Bn.test(e) || !n) throw new M("ASSET_INVALID", "素材のhashまたは種類が未対応です。");
	return `assets/${e}.${n[0]}`;
}
function Wn(e, t, n) {
	l(e);
	let r = /^assets\/([0-9a-f]{64})\.([a-z0-9]{1,8})$/.exec(e);
	if (!r || !Hn[t]?.includes(r[2])) throw new M("ASSET_INVALID", "素材パス・種類・拡張子が一致しません。", e);
	if (n) {
		let r = (e) => e.every((e, t) => n[t] === e), i = (e, t) => [...t].every((t, r) => n[e + r] === t.charCodeAt(0)), a = !0;
		switch (t) {
			case "image/png":
				a = r([
					137,
					80,
					78,
					71,
					13,
					10,
					26,
					10
				]);
				break;
			case "image/jpeg":
				a = r([
					255,
					216,
					255
				]);
				break;
			case "image/gif":
				a = i(0, "GIF87a") || i(0, "GIF89a");
				break;
			case "image/webp":
				a = i(0, "RIFF") && i(8, "WEBP");
				break;
			case "audio/mpeg":
				a = i(0, "ID3") || n[0] === 255 && (n[1] & 224) == 224;
				break;
			case "audio/wav":
			case "audio/x-wav":
				a = i(0, "RIFF") && i(8, "WAVE");
				break;
			case "audio/ogg":
				a = i(0, "OggS");
				break;
			case "video/mp4":
				a = i(4, "ftyp");
				break;
			case "video/webm":
				a = r([
					26,
					69,
					223,
					163
				]);
				break;
			case "application/pdf":
				a = i(0, "%PDF-");
				break;
			case "application/json":
				g(n, e);
				break;
			case "text/plain": try {
				new TextDecoder("utf-8", { fatal: !0 }).decode(n);
			} catch {
				a = !1;
			}
		}
		if (!a) throw new M("ASSET_INVALID", "素材bytesが宣言した種類と一致しません。", e);
	}
	return r[1];
}
Uint32Array.from({ length: 256 }, (e, t) => {
	let n = t;
	for (let e = 0; e < 8; e++) n = n & 1 ? n >>> 1 ^ 3988292384 : n >>> 1;
	return n >>> 0;
});
function Gn(e, t) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw new M("ARCHIVE_INVALID", "オブジェクトが必要です。", t);
	return e;
}
function Kn(e) {
	let t = Gn(e, "manifest.json");
	if (t.format !== "scenario-package" || t.formatVersion !== "1.0.0") throw new M("FORMAT_UNSUPPORTED", "この専用形式の版には対応していません。元のファイルを保持してください。", "manifest.json");
	let n = typeof t.minimumReaderVersion == "string" && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(t.minimumReaderVersion) ? t.minimumReaderVersion.split(".").map(Number) : void 0;
	if (!n || n[0] > 1 || n[0] === 1 && (n[1] > 0 || n[2] > 0)) throw new M("FORMAT_UNSUPPORTED", "読み込みに新しいアプリが必要です。", "manifest.json/minimumReaderVersion");
	if (t.requiredFeatures !== void 0 && (!Array.isArray(t.requiredFeatures) || t.requiredFeatures.some((e) => ![
		"portable-recovery-v1",
		"native-sync-recovery-v1",
		"shared-review-source-v1",
		"shared-records-v1"
	].includes(e)))) throw new M("FORMAT_UNSUPPORTED", "未知の必須機能が宣言されています。", "manifest.json/requiredFeatures");
	if (typeof t.projectId != "string" || !zn.test(t.projectId) || typeof t.snapshotId != "string" || !zn.test(t.snapshotId) || typeof t.exportedAt != "string" || !Number.isFinite(Date.parse(t.exportedAt)) || !t.exportedAt.endsWith("Z") || !["embedded", "metadata_only"].includes(t.assetMode) || !Array.isArray(t.files)) throw new M("ARCHIVE_INVALID", "manifestの必須項目が不正です。", "manifest.json");
	let r = /* @__PURE__ */ new Set();
	for (let [e, n] of t.files.entries()) {
		let t = Gn(n, `manifest.json/files/${e}`);
		if (typeof t.path != "string") throw new M("ARCHIVE_INVALID", "manifestのpathが不正です。", `manifest.json/files/${e}`);
		if (l(t.path), t.path === "manifest.json" || !Vn.test(t.path) || r.has(t.path) || !Number.isSafeInteger(t.byteSize) || t.byteSize < 0 || typeof t.sha256 != "string" || !Bn.test(t.sha256) || t.role !== (t.path === "data/project.json" ? "project" : t.path === "data/recovery.json" ? "recovery" : t.path === "data/sync-recovery.json" ? "sync_recovery" : t.path === "data/records.json" ? "record_dictionary" : t.path.startsWith("worlds/") ? "world" : "asset")) throw new M("ARCHIVE_INVALID", "manifestのファイル宣言が不正または重複しています。", t.path);
		r.add(t.path);
	}
	return t;
}
function qn(e, t, n, r = {}) {
	let i;
	try {
		i = T(e, { worldSnapshots: r });
	} catch (e) {
		throw new M("VALIDATION_FAILED", "共通世界または作品の構造が不正です。", t, { cause: e });
	}
	if (!i.ok) throw new M("VALIDATION_FAILED", i.issues.map((e) => `${e.path}: ${e.message}`).join("\n"), t);
	let a = i.value;
	if (a.entities.length + a.relations.length > n.records) throw new M("LIMIT_EXCEEDED", "entityとrelationの件数が上限を超えています。", t);
	return Yn(a, t, n), a;
}
async function Jn(e, t, n = {}) {
	let r = await K(e, { worldSnapshots: n }, !0);
	if (r.length) throw new M("VALIDATION_FAILED", r.map((e) => `${e.path}: ${e.message}`).join("\n"), t);
}
function Yn(e, t, n) {
	if (typeof e == "string") {
		if (new TextEncoder().encode(e).byteLength > n.fieldBytes) throw new M("LIMIT_EXCEEDED", "本文フィールドが1 MiBの上限を超えています。", t);
	} else if (Array.isArray(e)) e.forEach((e, r) => Yn(e, `${t}/${r}`, n));
	else if (e && typeof e == "object") for (let [r, i] of Object.entries(e)) Yn(i, `${t}/${r}`, n);
}
function Xn(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new WeakSet();
	function r(e) {
		if (e && typeof e == "object") {
			if (n.has(e)) return;
			n.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(r);
			return;
		}
		if (!e || typeof e != "object") return;
		let i = e;
		if (i.kind === "attachment") {
			let e = Gn(i.data, "attachment/data"), n = Wn(e.assetPath, e.mediaType);
			if (n !== e.contentHash || !Number.isSafeInteger(e.byteSize) || e.byteSize < 0) throw new M("ASSET_INVALID", "素材のhashまたはサイズが不正です。", e.assetPath);
			let r = t.get(n);
			if (r && (r.assetPath !== e.assetPath || r.byteSize !== e.byteSize || r.mediaType !== e.mediaType)) throw new M("ASSET_INVALID", "同じhashの素材に異なるメタデータがあります。", e.assetPath);
			t.set(n, e);
		}
		for (let e of Object.values(i)) r(e);
	}
	return r(e), [...t.values()];
}
function Zn(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let e of Xn(n)) {
		let n = t.get(e.contentHash);
		if (n && (n.assetPath !== e.assetPath || n.mediaType !== e.mediaType || n.byteSize !== e.byteSize)) throw new M("ASSET_INVALID", "作品間の素材メタデータが一致しません。", e.assetPath);
		t.set(e.contentHash, e);
	}
	return [...t.values()];
}
function Qn(e, t = {}) {
	let n = {}, i = [e];
	for (; i.length;) for (let e of $n(i.splice(0), t)) {
		let a = e.immutableSnapshotId;
		if (n[a]) continue;
		let o = t[a], s = o?.snapshots.find((e) => e.id === a);
		if (!o || o.projectId !== e.projectId || s?.contentHash !== e.contentHash) throw new M("ASSET_MISSING", "素材の固定世界依存が不足または不一致です。", a);
		if (n[a] = o, Object.keys(n).length > r.records) throw new M("LIMIT_EXCEEDED", "固定世界の依存上限を超えています。");
		i.push(o);
	}
	return Zn([e, ...Object.values(n)]);
}
function $n(e, t = {}) {
	let n = /* @__PURE__ */ new Map();
	for (let e of Object.values(t)) for (let t of e.snapshots) {
		let r = n.get(t.id);
		if (r && r.reference.contentHash !== t.contentHash) throw new M("IMMUTABLE_SNAPSHOT", "固定世界の期待hashが同じIDで異なります。", t.id);
		n.set(t.id, {
			world: e,
			reference: {
				projectId: e.projectId,
				immutableSnapshotId: t.id,
				contentHash: t.contentHash
			}
		});
	}
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new WeakSet();
	function a(e) {
		if (e && typeof e == "object") {
			if (i.has(e)) return;
			i.add(e);
		}
		if (Array.isArray(e)) {
			e.forEach(a);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		if (Array.isArray(t.worldReferences)) for (let e of t.worldReferences) {
			let t = r.get(e.immutableSnapshotId);
			if (t && (t.projectId !== e.projectId || t.contentHash !== e.contentHash)) throw new M("VALIDATION_FAILED", "同じ共通世界snapshot IDの参照内容が一致しません。", e.immutableSnapshotId);
			r.set(e.immutableSnapshotId, e);
		}
		let o = n.size ? typeof t.kind == "string" && D.includes(t.kind) && typeof t.projectId == "string" && t.data && typeof t.data == "object" ? N(t) : typeof t.relationType == "string" && typeof t.projectId == "string" && typeof t.fromId == "string" && typeof t.toId == "string" ? ne(t) : [] : [];
		for (let e of o) if (e.scope === "snapshot") {
			let i = n.get(e.id);
			if (i && i.world.projectId !== t.projectId) {
				let t = r.get(e.id);
				if (t && t.contentHash !== i.reference.contentHash) throw new M("IMMUTABLE_SNAPSHOT", "引用世界の期待hashが採用版と異なります。", e.id);
				r.set(e.id, i.reference);
			}
		}
		for (let e of Object.values(t)) a(e);
	}
	return e.forEach(a), [...r.values()];
}
function er(e) {
	let t = Object.create(null);
	for (let [n, r] of Object.entries(e)) {
		if (!r || typeof r != "object" || !Array.isArray(r.snapshots)) continue;
		let e = r.snapshots.find((e) => e && e.id === n);
		if (e?.content && typeof e.content == "object" && Array.isArray(e.content.entities) && Array.isArray(e.content.relations) && Array.isArray(e.content.calendars)) {
			if (t[n] && !o(t[n], e.content)) throw new M("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", n);
			t[n] = e.content;
			for (let e of r.snapshots) if (e?.content?.projectId === r.projectId) {
				if (t[e.id] && !o(t[e.id], e.content)) throw new M("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", e.id);
				t[e.id] = e.content;
			}
		}
	}
	return t;
}
function tr(e, t) {
	for (let [e, n] of Object.entries(t)) if (!n.snapshots.some((t) => t.id === e)) throw new M("VALIDATION_FAILED", "共通世界ファイルに指定した不変snapshotがありません。", `worlds/${e}.json`);
	for (let n of $n(e)) {
		let e = t[n.immutableSnapshotId], r = e?.snapshots.find((e) => e.id === n.immutableSnapshotId);
		if (!e || e.projectId !== n.projectId || !r || r.contentHash !== n.contentHash) throw new M("VALIDATION_FAILED", "参照した共通世界の不変snapshotが不足または不一致です。", `worlds/${n.immutableSnapshotId}.json`);
	}
}
async function nr(t) {
	let n = /* @__PURE__ */ new Map();
	function r(e) {
		if (Array.isArray(e)) {
			e.forEach(r);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		if (Array.isArray(t.snapshots)) for (let e of t.snapshots) {
			let t = n.get(e.id);
			if (t && !o(t, e)) throw new M("IMMUTABLE_SNAPSHOT", "同じ不変snapshot IDに異なる内容があります。", e.id);
			n.set(e.id, e);
		}
		for (let e of Object.values(t)) r(e);
	}
	t.forEach(r);
	for (let t of n.values()) if (await e(m(t.content)) !== t.contentHash) throw new M("HASH_MISMATCH", "不変snapshotの内容hashが一致しません。", `snapshots/${t.id}`);
}
async function rr(t, n = {}) {
	O(n.signal), n.onProgress?.({
		stage: "validating",
		completed: 0,
		total: 1
	});
	let i = n.worlds ?? {}, a = er(i), c = qn(t, "data/project.json", r, a), l = n.snapshotId ? c.snapshots.find((e) => e.id === n.snapshotId) : void 0;
	if (l) {
		let { history: e, snapshots: t, authorAlternatives: r, ...i } = c;
		if (!o(i, l.content)) throw new M("OPERATION_CONFLICT", "指定した版と書き出す内容が一致しません。対象snapshotの内容を選び直してください。", n.snapshotId);
	}
	tr([c, ...Object.values(i)], i), await nr([c, ...Object.values(i)]), await Jn(c, "data/project.json", a);
	for (let [e, t] of Object.entries(i)) await Jn(t, `worlds/${e}.json`, a);
	let d = [c, ...Object.values(i)].reduce((e, t) => e + t.entities.length + t.relations.length, 0);
	if (d > r.records) throw new M("LIMIT_EXCEEDED", "参照世界を含むentityとrelationの件数が上限を超えています。");
	let f = n.recovery ? await Rn(n.recovery, c, a, n.signal) : void 0, p = n.syncRecovery?.length ? await Lt(n.syncRecovery, a, n.signal) : void 0, _ = [...In(f), ...It(p)];
	tr(_, i), await nr(_);
	let v = n.assetMode ?? "embedded", y = Zn([
		c,
		..._,
		...Object.values(i)
	]);
	n.onProgress?.({
		stage: "serializing",
		completed: 0,
		total: 1
	});
	let b = c.history.length + c.snapshots.length + (c.authorAlternatives?.length ?? 0) + (f?.pending.length ?? 0) + (p?.length ?? 0), x = d >= 5e3 && b > 0 || [
		c,
		...Object.values(i),
		f,
		p
	].some((e) => e !== void 0 && h(e, r.jsonBytes)) ? new Vt() : void 0, S = (e) => m(x ? x.encode(e) : e), C = {
		"data/project.json": S(c),
		...f ? { "data/recovery.json": S(f) } : {},
		...p ? { "data/sync-recovery.json": S(p) } : {}
	};
	for (let [e, t] of Object.entries(i)) {
		if (!zn.test(e)) throw new M("VALIDATION_FAILED", "共通世界snapshot IDが不正です。", e);
		C[`worlds/${e}.json`] = S(qn(t, `worlds/${e}.json`, r, a));
	}
	if (x && (C["data/records.json"] = m({
		records: x.records,
		arrays: x.arrays
	})), v === "embedded") for (let t of y) {
		if (O(n.signal), C[t.assetPath]) continue;
		let r = await n.loadAsset?.(t.contentHash);
		if (!r) throw new M("ASSET_MISSING", "完全保存に必要な添付bytesが取得されていません。", t.assetPath);
		if (Wn(t.assetPath, t.mediaType, r), r.byteLength !== t.byteSize || await e(r) !== t.contentHash) throw new M("HASH_MISMATCH", "素材bytesと保存メタデータが一致しません。", t.assetPath);
		C[t.assetPath] = r, n.onProgress?.({
			stage: "serializing",
			completed: Object.keys(C).filter((e) => e.startsWith("assets/")).length,
			total: y.length
		});
	}
	else if (v !== "metadata_only") throw new M("FORMAT_UNSUPPORTED", "出力プロファイルが未対応です。");
	let w = 0, T = { objects: 0 }, E = [];
	for (let [t, n] of Object.entries(C)) {
		let i = t === "data/project.json" ? "project" : t === "data/recovery.json" ? "recovery" : t === "data/sync-recovery.json" ? "sync_recovery" : t === "data/records.json" ? "record_dictionary" : t.startsWith("worlds/") ? "world" : "asset";
		if (n.byteLength > (i === "asset" ? r.assetBytes : r.jsonBytes) || (w += n.byteLength) > r.expandedBytes) throw new M("LIMIT_EXCEEDED", "出力サイズが安全上限を超えています。分割や軽量出力を選んでください。", t);
		E.push({
			path: t,
			byteSize: n.byteLength,
			sha256: await e(n),
			role: i
		}), i !== "asset" && g(n, t, r, T);
	}
	let D = ir([
		c,
		..._,
		...Object.values(i)
	]), ee = {
		format: "scenario-package",
		formatVersion: s,
		projectId: c.projectId,
		snapshotId: n.snapshotId ?? u(),
		exportedAt: n.exportedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
		assetMode: v,
		files: E,
		minimumReaderVersion: s,
		...f || p || x || D ? { requiredFeatures: [
			...f ? ["portable-recovery-v1"] : [],
			...p ? ["native-sync-recovery-v1"] : [],
			...x ? [Rt] : [],
			...D ? ["shared-review-source-v1"] : []
		] } : {}
	};
	if (Kn(ee), C["manifest.json"] = m(ee), g(C["manifest.json"], "manifest.json", r, T), Object.keys(C).length > r.files || w + C["manifest.json"].length > r.expandedBytes) throw new M("LIMIT_EXCEEDED", "出力のファイル数または全bytesが上限を超えています。");
	O(n.signal), n.onProgress?.({
		stage: "compressing",
		completed: 0,
		total: 1
	});
	let k = Fn(C, { level: 6 });
	if (k.byteLength > r.compressedBytes) throw new M("LIMIT_EXCEEDED", "圧縮後の出力が64 MiBを超えています。分割や軽量出力を選んでください。");
	return k;
}
function ir(e) {
	let t = /* @__PURE__ */ new WeakSet(), n = (e) => {
		if (!e || typeof e != "object" || t.has(e)) return !1;
		t.add(e);
		let r = e;
		return r.kind === "review" && r.data && typeof r.data == "object" && r.data.sharedSource ? !0 : Object.values(e).some(n);
	};
	return e.some(n);
}
//#endregion
//#region src/storage/readValidationCore.ts
async function ar(e, t, n) {
	let r = {
		...e,
		history: []
	}, i = er(t);
	n?.("structure"), x(r), n?.("integrity");
	let a = await K(r, { worldSnapshots: i }, !1);
	if (a.length) throw Object.assign(new M("VALIDATION_FAILED", a.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: a });
	n?.("worlds"), tr([r], t), n?.("hashes"), await nr([r]);
}
//#endregion
//#region src/storage/readValidation.ts
async function or(e, t, n = {}) {
	if (O(n.signal), typeof window > "u" || typeof Worker > "u" || e.entities.length + e.relations.length < 5e3) {
		await ar(e, t, n.onStage), O(n.signal);
		return;
	}
	await new Promise((r, i) => {
		let a = new Worker(new URL(
			/* @vite-ignore */
			"/__restore/assets/readValidation.worker-62nbWJxt.js",
			"" + import.meta.url
		), { type: "module" }), o = (e) => {
			a.terminate(), n.signal?.removeEventListener("abort", s), e ? i(e) : r();
		}, s = () => o(new M("CANCELLED", "作品の確認を取り消しました。保存済み内容と入力は変更していません。"));
		a.onmessage = (e) => {
			let t = e.data;
			if (t.type === "stage") n.onStage?.(t.stage);
			else if (t.type === "done") try {
				O(n.signal), o();
			} catch (e) {
				o(e);
			}
			else t.type === "error" && o(Object.assign(new M(t.code, t.message), { issues: t.issues ?? [] }));
		}, a.onerror = () => o(new M("SAVE_FAILED", "作品の確認処理を開始できませんでした。保存済み内容を保持しています。")), n.signal?.addEventListener("abort", s, { once: !0 });
		try {
			O(n.signal), a.postMessage({
				project: e,
				worlds: t
			});
		} catch (e) {
			o(e);
		}
	});
}
//#endregion
//#region src/performance.ts
function X() {
	try {
		return sessionStorage.getItem("scenario-performance") === "measure";
	} catch {
		return !1;
	}
}
function sr() {
	return X() ? performance.now() : void 0;
}
function cr(e, t, n) {
	if (!(e === void 0 || !Number.isFinite(e) || e < 0 || !X())) try {
		performance.measure("scenario-local-save", {
			start: e,
			end: performance.now(),
			detail: {
				operationId: t,
				...n ? { milliseconds: n } : {}
			}
		});
	} catch {}
}
function lr(e, t, n) {
	if (!(e === void 0 || !Number.isFinite(e) || e < 0 || !X())) try {
		performance.measure("scenario-local-read", {
			start: e,
			end: performance.now(),
			detail: {
				projectId: t,
				milliseconds: n
			}
		});
	} catch {}
}
//#endregion
//#region src/storage/archive.ts
async function ur(e, t = {}) {
	return O(t.signal), t.worker === !1 || typeof window > "u" || typeof Worker > "u" ? rr(e, t) : new Promise((n, r) => {
		let i = new Worker(new URL(
			/* @vite-ignore */
			"/__restore/assets/archiveExport.worker-Bjpg4KH3.js",
			"" + import.meta.url
		), { type: "module" }), a = !0, o = (e, o) => {
			a && (a = !1, i.terminate(), t.signal?.removeEventListener("abort", s), e ? r(e) : n(o));
		}, s = () => o(new M("CANCELLED", "保存ファイルの作成を取り消しました。端末の作品と入力は変更していません。"));
		i.onmessage = (e) => {
			let n = e.data;
			n.type === "progress" ? t.onProgress?.(n.progress) : n.type === "done" ? o(void 0, n.bytes) : n.type === "error" ? o(new M(n.code, n.message, n.path)) : n.type === "asset" && Promise.resolve().then(() => t.loadAsset?.(n.hash)).then((e) => {
				if (!a) return;
				let t = e?.slice();
				i.postMessage({
					type: "asset",
					id: n.id,
					bytes: t
				}, t ? [t.buffer] : []);
			}).catch(() => {
				a && i.postMessage({
					type: "asset",
					id: n.id
				});
			});
		}, i.onerror = () => o(new M("SAVE_FAILED", "保存ファイルを作成できませんでした。端末の作品は保持しています。")), t.signal?.addEventListener("abort", s, { once: !0 });
		let { loadAsset: c, signal: l, onProgress: u, ...d } = t;
		try {
			O(t.signal), i.postMessage({
				input: e,
				options: d
			});
		} catch (e) {
			o(e);
		}
	});
}
//#endregion
//#region src/storage/worldPins.ts
async function dr(e, t, n) {
	let r = {
		...n,
		...t.dependencies,
		[t.snapshotId]: t.world
	}, i = {}, a = [t.snapshotId];
	for (; a.length;) {
		let e = a.pop();
		if (i[e]) continue;
		let t = r[e], s = t?.snapshots.find((t) => t.id === e);
		if (!t || !s || s.content.projectId !== t.projectId) throw new M("VALIDATION_FAILED", "固定する共通世界の版が見つかりません。", e);
		let c = n[e]?.snapshots.find((t) => t.id === e);
		if (c && !o(c, s)) throw new M("IMMUTABLE_SNAPSHOT", "保存済みの共通世界版を変更できません。", e);
		let l = /* @__PURE__ */ new Map([[s.id, s]]), u = [s];
		for (; u.length;) {
			let e = u.pop(), n = [...e.content.entities.flatMap(N), ...e.content.relations.flatMap(ne)];
			for (let e of n) if (e.scope === "snapshot" && e.id !== t.projectId && !l.has(e.id)) {
				let n = t.snapshots.find((t) => t.id === e.id);
				n && (l.set(n.id, n), u.push(n));
			}
		}
		let d = {
			...structuredClone(s.content),
			snapshots: structuredClone([...l.values()]),
			history: []
		};
		i[e] = d;
		for (let e of $n([d])) a.push(e.immutableSnapshotId);
	}
	let s = i[t.snapshotId].snapshots[0];
	if (!e.worldReferences.some((e) => e.immutableSnapshotId === t.snapshotId && e.projectId === s.content.projectId && e.contentHash === s.contentHash)) throw new M("VALIDATION_FAILED", "作品の固定版参照と保存対象が一致しません。", t.snapshotId);
	let c = {
		...n,
		...i
	}, l = er(c);
	for (let e of Object.values(i)) {
		let t = T(e, { worldSnapshots: l });
		if (!t.ok) throw new M("VALIDATION_FAILED", t.issues.map((e) => e.message).join("\n"));
	}
	return tr([e, ...Object.values(i)], c), await nr([...Object.values(n), ...Object.values(i)]), i;
}
//#endregion
//#region src/domain/text.ts
var fr = "本文の置換・削除・段落分割が注記に重なり、元の文字を特定できません。", pr = (e) => e.map((e) => e.text).join("\n"), mr = /* @__PURE__ */ new WeakMap();
function hr(e, t, n) {
	let r = Array(e.length), i = 0, a = 0;
	if (n && n.start >= 0 && n.end >= n.start && n.end <= e.length) {
		let i = t.length - (e.length - (n.end - n.start));
		if (i >= 0 && e.slice(0, n.start).join("") === t.slice(0, n.start).join("") && e.slice(n.end).join("") === t.slice(n.start + i).join("")) {
			for (let e = 0; e < n.start; e++) r[e] = e;
			for (let t = n.end; t < e.length; t++) r[t] = t + i - (n.end - n.start);
			return r;
		}
	}
	for (; i < e.length && i < t.length && e[i] === t[i];) r[i] = i, i++;
	for (; a < e.length - i && a < t.length - i && e[e.length - a - 1] === t[t.length - a - 1];) r[e.length - a - 1] = t.length - a - 1, a++;
	let o = e.length - i - a, s = t.length - i - a;
	if (!o || !s || o * s > 25e4) return r;
	let c = s + 1, l = new Uint32Array((o + 1) * c);
	for (let n = o - 1; n >= 0; n--) for (let r = s - 1; r >= 0; r--) l[n * c + r] = e[i + n] === t[i + r] ? l[(n + 1) * c + r + 1] + 1 : Math.max(l[(n + 1) * c + r], l[n * c + r + 1]);
	let u = 0, d = 0;
	for (; u < o && d < s;) e[i + u] === t[i + d] ? (r[i + u] = i + d, u++, d++) : l[(u + 1) * c + d] > l[u * c + d + 1] ? u++ : d++;
	return r;
}
function gr(e) {
	let t = 0;
	return e.map((e) => {
		let n = t;
		return t += Array.from(e.text).length + 1, n;
	});
}
function _r(e, t, n) {
	let r = pr(e), i = pr(t), a = Array.from(r), o = Array.from(i), s = gr(e), c = gr(t), l = hr(a, o, n), u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map();
	e.forEach((e, t) => u.set(e.text, [...u.get(e.text) ?? [], t])), t.forEach((e, t) => d.set(e.text, [...d.get(e.text) ?? [], t]));
	let f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Set();
	e.forEach((e, r) => {
		if (!n && u.get(e.text)?.length !== d.get(e.text)?.length) return;
		let i = t.findIndex((t) => t.id === e.id && t.text === e.text);
		if (!(i < 0)) {
			f.set(r, i);
			for (let t = 0; t < Array.from(e.text).length; t++) p.add(c[i] + t);
		}
	});
	for (let [e, t] of u) {
		let n = d.get(e);
		n && t.length === 1 && n.length === 1 && t.forEach((t, r) => {
			if (f.has(t)) return;
			let i = n[r];
			f.set(t, i);
			for (let t = 0; t < Array.from(e).length; t++) p.add(c[i] + t);
		});
	}
	e.forEach((e, t) => {
		let r = f.get(t);
		for (let i = 0; i < Array.from(e.text).length; i++) {
			let a = s[t] + i;
			r === void 0 ? l[a] !== void 0 && p.has(l[a]) && (l[a] = void 0) : l[a] = c[r] + i, !n && !f.has(t) && (u.get(e.text)?.length ?? 0) > 1 && u.get(e.text)?.length !== d.get(e.text)?.length && (l[a] = void 0);
		}
	});
	let m = /* @__PURE__ */ new Map();
	t.forEach((e, t) => {
		for (let n = 0; n < Array.from(e.text).length; n++) m.set(c[t] + n, {
			block: t,
			offset: n
		});
	});
	let h = new Map(e.map((e, t) => [e.id, t])), g = a.every((e, t) => l[t] !== void 0 && l[t] === l[0] + t), _ = (e, t) => {
		let n = 0, r = 0;
		for (; t && (r = e.indexOf(t, r)) >= 0;) n++, r++;
		return n;
	}, v = (e) => !n && e && _(i, e) > 1 && _(r, e) !== _(i, e), y = /* @__PURE__ */ new Map();
	e.forEach((e, n) => {
		if (f.has(n)) {
			y.set(n, f.get(n));
			return;
		}
		let r = /* @__PURE__ */ new Map();
		for (let t = 0; t < Array.from(e.text).length; t++) {
			let e = l[s[n] + t], i = e === void 0 ? void 0 : m.get(e);
			i && r.set(i.block, (r.get(i.block) ?? 0) + 1);
		}
		let i = [...r].sort((e, t) => e[0] - t[0])[0];
		i ? y.set(n, i[0]) : t.some((t) => t.id === e.id) && y.set(n, t.findIndex((t) => t.id === e.id));
	});
	let b = (e, t) => {
		if (e < 0 || t < e || t > a.length) return;
		if (e === t) return l[e] === void 0 ? e > 0 && l[e - 1] !== void 0 ? {
			start: l[e - 1] + 1,
			end: l[e - 1] + 1
		} : void 0 : {
			start: l[e],
			end: l[e]
		};
		let n = l[e];
		if (n !== void 0) {
			for (let r = e + 1; r < t; r++) if (l[r] !== n + r - e) return;
			return {
				start: n,
				end: n + t - e
			};
		}
	};
	return {
		blocks: t,
		block: (e) => {
			let n = h.get(e), r = n === void 0 ? void 0 : y.get(n);
			return r === void 0 ? void 0 : t[r]?.id;
		},
		lineRange: (e, t) => {
			let o = a.slice(e, t).join("");
			if (!v(o) && !(!n && o && r !== i && i.indexOf(o, i.indexOf(o) + 1) >= 0 && r.indexOf(o, r.indexOf(o) + 1) < 0) && !(!n && !g && o && r.indexOf(o, r.indexOf(o) + 1) >= 0)) return b(e, t);
		},
		range: (a, o, l) => {
			let u = h.get(a);
			if (u === void 0 || l > Array.from(e[u].text).length) return;
			let d = Array.from(e[u].text).slice(o, l).join("");
			if (!f.has(u) && v(d) || !n && !f.has(u) && d && r !== i && i.indexOf(d, i.indexOf(d) + 1) >= 0 && r.indexOf(d, r.indexOf(d) + 1) < 0 || !n && !g && !f.has(u) && d && r.indexOf(d, r.indexOf(d) + 1) >= 0) return;
			let p = b(s[u] + o, s[u] + l);
			if (!p) return;
			let _ = m.get(p.start) ?? (o === l ? m.get(p.start - 1) : void 0), y = m.get(p.end - 1) ?? _;
			if (!_ || !y || _.block !== y.block) return;
			let x = p.start - c[_.block];
			return {
				blockId: t[_.block].id,
				start: x,
				end: x + l - o
			};
		}
	};
}
function vr(e, t, n, r, i) {
	if (e.entityId !== t || e.sourceVersionId && e.sourceVersionId !== i || e.positionStatus === "unresolved") return e;
	let a = n.find((t) => t.id === e.blockId);
	if (!a && e.lineId !== t) return e;
	let o = typeof e.start == "number" && typeof e.end == "number";
	if (o) {
		let t = a ? r.range(a.id, e.start, e.end) : r.lineRange(e.start, e.end);
		if (t) return t.start === e.start && t.end === e.end && (!a || "blockId" in t && t.blockId === e.blockId) ? e : {
			...e,
			...a ? t : {
				start: t.start,
				end: t.end
			}
		};
	} else if (a) {
		let t = r.block(a.id);
		if (t) return t === e.blockId ? e : {
			...e,
			blockId: t
		};
	} else return e;
	let s = {
		...e,
		positionStatus: "unresolved",
		positionReason: fr,
		quotedText: o ? Array.from(a?.text ?? pr(n)).slice(e.start, e.end).join("") : a?.text ?? ""
	};
	if (delete s.start, delete s.end, a) {
		let e = r.block(a.id);
		e ? s.blockId = e : delete s.blockId;
	}
	return s;
}
function yr(e) {
	return Array.isArray(e) && e.length > 0 && e.every((e) => e && typeof e == "object" && typeof e.id == "string" && typeof e.text == "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(e.kind));
}
function br(e, t) {
	let n = e.data, r = t.data, i = Object.entries(n).flatMap(([e, t]) => {
		let n = r[e];
		if (!yr(t) || !Array.isArray(n) || JSON.stringify(t) === JSON.stringify(n)) return [];
		let i = [], a = n;
		for (let e = 0; e < 64; e++) {
			let e = mr.get(a);
			if (!e) break;
			if (i.unshift({
				before: e.before,
				transform: e.transform
			}), JSON.stringify(e.before) === JSON.stringify(t)) return i;
			a = e.before;
		}
		return [{
			before: t,
			transform: _r(t, n)
		}];
	});
	if (!i.length) return;
	let a = (t) => {
		if (Array.isArray(t)) {
			let e = t.map(a);
			return e.some((e, n) => e !== t[n]) ? e : t;
		}
		if (!t || typeof t != "object") return t;
		let n = t, r = t;
		if (typeof n.entityId == "string") for (let t of i) r = vr(r, e.id, t.before, t.transform, e.projectId);
		let o = r, s = Object.entries(o).map(([e, t]) => [e, a(t)]);
		return s.some(([e, t]) => t !== o[e]) ? Object.fromEntries(s) : r;
	};
	return a;
}
function xr(e, t, n) {
	let r = br(t, n);
	if (!r) return e;
	let i = Object.entries(t.data).flatMap(([e, t]) => {
		let r = n.data[e];
		return yr(t) && Array.isArray(r) && JSON.stringify(t) !== JSON.stringify(r) ? [{
			before: t,
			transform: _r(t, r)
		}] : [];
	});
	return e.map((e) => {
		let n = e.kind === "review" && e.data.targetVersionId !== t.projectId, a = e.data, o = n ? Object.entries(a).map(([e, t]) => [e, e === "target" ? t : r(t)]) : void 0, s = o ? o.some(([e, t]) => t !== a[e]) ? Object.fromEntries(o) : a : r(a);
		if (e.id === t.id && e.kind === "scene" && e.data.blockIds?.length) {
			let t = [...new Set(e.data.blockIds.map((t) => r({
				entityId: e.id,
				blockId: t
			}).blockId ?? t))];
			(t.some((t, n) => t !== e.data.blockIds[n]) || t.length !== e.data.blockIds.length) && (s = {
				...s,
				blockIds: t
			});
		}
		if (e.kind === "projection_profile" && (!e.data.sourceVersionId || e.data.sourceVersionId === t.projectId)) {
			let t = { ...e.data.blockSources }, n = !1;
			for (let [e, r] of Object.entries(t)) for (let a of i) if (a.before.some((e) => e.id === r)) {
				n = !0;
				let i = a.transform.block(r);
				i ? t[e] = i : delete t[e];
			}
			if (n) return {
				...e,
				status: "needs_review",
				data: {
					...s,
					blockSources: t
				}
			};
		}
		return s === a ? e : {
			...e,
			data: s
		};
	});
}
function Sr(e, t, n) {
	let r = br(t, n);
	return r ? e.map((e) => {
		let t = r(e.validity);
		return t === e.validity ? e : {
			...e,
			validity: t
		};
	}) : e;
}
//#endregion
//#region src/domain/production.ts
function Cr(e) {
	return typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? "[" + e.map(Cr).join(",") + "]" : "{" + Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e < t ? -1 : +(e > t)).map(([e, t]) => JSON.stringify(e) + ":" + Cr(t)).join(",") + "}";
}
async function wr(e, t) {
	let n = (t.data.cueIds ?? []).map((t) => e.entities.find((e) => e.id === t && e.kind === "cue" && !e.deletedAt));
	if (n.some((e) => !e)) throw Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
	let r = {
		text: t.data.text.map((e) => ({
			kind: e.kind,
			text: e.text,
			ruby: e.ruby ?? []
		})),
		speakerId: t.data.speakerId ?? null,
		cues: n.map((e) => e.data)
	}, i = new TextEncoder().encode(Cr(r));
	return [...new Uint8Array(await crypto.subtle.digest("SHA-256", i))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
async function Tr(e, t) {
	let n = new Map(e.entities.map((e) => [e.id, e])), r = new Map(t.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	for (let [e, t] of r) {
		let r = n.get(e);
		r !== t && (!r || !!r.deletedAt != !!t.deletedAt || Cr(r.data) !== Cr(t.data)) && a.add(e);
	}
	for (let e of n.keys()) r.has(e) || a.add(e);
	let o = (e, t) => Cr({
		text: e.data.text.map((e) => ({
			kind: e.kind,
			text: e.text,
			ruby: e.ruby ?? []
		})),
		speakerId: e.data.speakerId ?? null,
		cues: (e.data.cueIds ?? []).map((e) => {
			let n = t.get(e);
			if (!n || n.kind !== "cue" || n.deletedAt) throw Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
			return n.data;
		})
	});
	for (let e of t.entities) {
		if (e.kind !== "dialogue_line" || e.deletedAt) continue;
		let t = n.get(e.id);
		(!t || t.kind !== "dialogue_line" || t.deletedAt || ["rejected", "alternate"].includes(t.status) !== ["rejected", "alternate"].includes(e.status) || (a.has(e.id) || (e.data.cueIds ?? []).some((e) => a.has(e))) && o(t, n) !== o(e, r)) && i.add(e.id);
	}
	for (let t of e.entities) if (t.kind === "dialogue_line" && !t.deletedAt) {
		let e = r.get(t.id);
		(!e || e.deletedAt || e.kind !== "dialogue_line") && i.add(t.id);
	}
	let s = /* @__PURE__ */ new Set();
	for (let e of t.entities) if (!e.deletedAt && (e.kind === "localization" || e.kind === "recording") && ["reviewed", "recorded"].includes(e.data.stage ?? "") && !i.has(e.data.sourceLineId) && a.has(e.id)) {
		let n = r.get(e.data.sourceLineId);
		(!n || n.kind !== "dialogue_line" || n.deletedAt || ["rejected", "alternate"].includes(n.status) || e.data.sourceHash !== await wr(t, n)) && s.add(e.id);
	}
	if (!a.size && !i.size && !s.size) return t;
	let c = t.entities.map((e) => e.deletedAt ? e : (e.kind === "localization" || e.kind === "recording") && (i.has(e.data.sourceLineId) || s.has(e.id)) && e.data.stage !== "needs_review" ? {
		...e,
		data: {
			...e.data,
			stage: "needs_review"
		}
	} : e.kind === "media_variant" && (e.data.sourceIds ?? []).some((e) => a.has(e)) && !e.data.needsReview ? {
		...e,
		data: {
			...e.data,
			needsReview: !0
		}
	} : e), l = (e, n) => {
		let r = e;
		for (let i of n.split(/[.\[\]]+/).filter(Boolean)) if (r && typeof r == "object") {
			let n = r, a = n.sourceVersionId ?? n.targetSnapshotId ?? (e.kind === "trace" || e.kind === "checkpoint" ? n.contentVersionId : void 0);
			if (typeof a == "string" && a !== t.projectId) return !1;
			r = n[i];
		} else return !0;
		return !0;
	}, u = /* @__PURE__ */ new Map();
	for (let e of c) if (!e.deletedAt && !["rejected", "alternate"].includes(e.status)) {
		for (let t of N(e)) if (!t.path.startsWith("data.lineage") && !t.path.startsWith("data.originLineIds") && l(e, t.path)) {
			let n = u.get(t.id);
			n ? n.push(e.id) : u.set(t.id, [e.id]);
		}
	}
	let d = new Set(a), f = [...d];
	for (let e = 0; e < f.length; e++) for (let t of u.get(f[e]) ?? []) d.has(t) || (d.add(t), f.push(t));
	return {
		...t,
		entities: c.map((e) => !d.has(e.id) || e.deletedAt || ["rejected", "alternate"].includes(e.status) ? e : e.kind === "storyboard_frame" && n.has(e.id) ? {
			...e,
			status: "needs_review"
		} : e.kind === "media_variant" && n.has(e.id) ? {
			...e,
			data: {
				...e.data,
				needsReview: !0
			}
		} : e.kind === "production_task" && n.has(e.id) && e.data.progress === "done" ? {
			...e,
			data: {
				...e.data,
				progress: "needs_review"
			}
		} : e)
	};
}
//#endregion
//#region src/domain/changeReviews.ts
var Er = "changeReview.generatedBy", Dr = "changeReview.key", Or = "changeReview.sourceIds", kr = "changeReview.sourceRevisions", Ar = "changeReview.projectRevision", jr = "changeReview.paths", Mr = "semantic-change-review/v1", Nr = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]), Pr = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]), Fr = /* @__PURE__ */ new Set(["reference"]);
function Ir(e) {
	try {
		return (BigInt(e) + 1n).toString();
	} catch {
		return e;
	}
}
function Lr(e) {
	return typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? `[${e.map(Lr).join(",")}]` : `{${Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${JSON.stringify(e)}:${Lr(t)}`).join(",")}}`;
}
function Rr(e, t) {
	if (Nr.has(e.kind) || e.kind === "group" && e.data.groupType === "category") return;
	let n = { ...e.data };
	return (e.kind === "character" || e.kind === "place" || e.kind === "lore") && (delete n.reading, delete n.aliases), (e.kind === "localization" || e.kind === "recording") && (delete n.stage, delete n.reviewedBy), e.kind === "media_variant" && delete n.needsReview, e.kind === "attachment" && (delete n.displayName, delete n.licenseNote, delete n.byteSize), e.kind === "source" && delete n.accessedAt, Lr({
		deleted: t,
		data: n,
		customValues: e.customValues
	});
}
function zr(e, t) {
	let n = new Map(t.entities.map((e) => [e.id, e])), r = [];
	for (let t of e.entities) {
		let e = n.get(t.id);
		if (t.deletedAt && (!e || e.deletedAt) || e === t || e && e.kind !== t.kind) continue;
		let i = Rr(t, !!t.deletedAt), a = e ? Rr(e, !!e.deletedAt) : Rr(t, !0);
		i && a && i !== a && r.push({
			source: e ?? t,
			sourceRevision: Ir(t.revision)
		});
	}
	return r;
}
function Br(e) {
	return e.deletedAt || Pr.has(e.kind) ? !1 : e.kind !== "group" || e.data.groupType !== "category";
}
function Vr(e, t, n = "data") {
	if (!e || typeof e != "object") return [];
	if (Array.isArray(e)) return e.flatMap((e, r) => Vr(e, t, `${n}[${r}]`));
	let r = e;
	return typeof r.entityId == "string" && typeof r.sourceVersionId == "string" && r.sourceVersionId !== t ? [n] : Object.entries(r).flatMap(([e, r]) => Vr(r, t, `${n}.${e}`));
}
function Hr(e, t) {
	return Lr({
		targetId: e,
		sources: t.map((e) => ({
			id: e.source.id,
			revision: e.sourceRevision,
			directPaths: [...new Set(e.directPaths)].sort(),
			relationLabels: [...new Set(e.relationLabels)].sort()
		})).sort((e, t) => e.id.localeCompare(t.id))
	});
}
function Ur(e) {
	let { source: t, sourceRevision: n, directPaths: r, relationLabels: i } = e, a = [];
	return r.length && a.push(`IDで直接参照しています（${[...new Set(r)].sort().join("、")}）`), i.length && a.push(`作者が設定した関係「${[...new Set(i)].sort().join("・")}」でつながっています`), `変更元: ${S[t.kind]}「${t.name || "無題"}」 (${t.id})。改訂 ${t.revision} → ${n}。${a.join("。")}`;
}
function Wr(e) {
	return new Set(e.entities.flatMap((e) => e.kind === "review" && !e.deletedAt && e.customValues[Er] === Mr && typeof e.customValues[Dr] == "string" ? [e.customValues[Dr]] : []));
}
function Gr(e, t) {
	if (e.projectId !== t.projectId) return t;
	let n = zr(e, t);
	if (!n.length) return t;
	let r = t.entities.filter(Br), i = new Map(r.map((e) => [e.id, e])), a = /* @__PURE__ */ new Map(), o = new Map(n.map((e) => [e.source.id, e]));
	for (let e of r) {
		let n = /* @__PURE__ */ new Map(), r = Vr(e.data, t.projectId);
		for (let t of N(e)) {
			if (r.some((e) => t.path === e || t.path.startsWith(e + "."))) continue;
			let i = o.get(t.id);
			if (!i || e.id === i.source.id) continue;
			let a = n.get(t.id) ?? /* @__PURE__ */ new Set();
			a.add(t.path), n.set(t.id, a);
		}
		if (!n.size) continue;
		let i = a.get(e.id) ?? /* @__PURE__ */ new Map();
		for (let [e, t] of n) {
			let n = o.get(e);
			i.set(e, {
				...n,
				directPaths: [...t],
				relationLabels: []
			});
		}
		a.set(e.id, i);
	}
	for (let e of t.relations) if (!(e.deletedAt || e.status === "rejected" || Fr.has(e.relationType))) for (let t of new Set([e.fromId, e.toId].filter((e) => o.has(e)))) {
		let n = e.fromId === t ? e.toId : e.fromId, r = i.get(n), s = o.get(t);
		if (!r || !s || r.id === t) continue;
		let c = a.get(r.id) ?? /* @__PURE__ */ new Map(), l = c.get(t) ?? {
			...s,
			directPaths: [],
			relationLabels: []
		};
		l.relationLabels.push(_[e.relationType] ?? e.relationType), c.set(t, l), a.set(r.id, c);
	}
	let s = Wr(t), l = Ir(t.revision), u = [];
	for (let [e, n] of a) {
		let r = i.get(e);
		if (!r) continue;
		let a = [...n.values()].sort((e, t) => e.source.id.localeCompare(t.source.id)), o = Hr(r.id, a);
		if (s.has(o)) continue;
		s.add(o);
		let d = a.map(Ur), f = [
			`「${r.name || S[r.kind]}」に関係する情報が変更されました。内容への影響を確認してください。`,
			...d,
			`確認対象の作品改訂: ${t.revision} → ${l}。候補は人による確認用です。本文や設定は自動変更していません。`
		].join("\n"), p = y(t.projectId, "review", `変更確認: ${r.name || S[r.kind]}`, {
			target: r.id,
			targetVersionId: t.projectId,
			body: c(f),
			stage: "open",
			quotedText: null,
			resolution: []
		});
		p.status = "needs_review", p.visibility = "private", p.customValues = {
			...p.customValues,
			[Er]: Mr,
			[Dr]: o,
			[Or]: JSON.stringify(a.map((e) => e.source.id)),
			[kr]: JSON.stringify(Object.fromEntries(a.map((e) => [e.source.id, e.sourceRevision]))),
			[Ar]: l,
			[jr]: JSON.stringify(Object.fromEntries(a.map((e) => [e.source.id, {
				directPaths: [...new Set(e.directPaths)].sort(),
				relationLabels: [...new Set(e.relationLabels)].sort()
			}])))
		}, u.push(p);
	}
	return u.length ? {
		...t,
		entities: [...t.entities, ...u]
	} : t;
}
//#endregion
//#region src/storage/importMapping.ts
function Kr(e) {
	let t = /* @__PURE__ */ new Map(), n = [], r = /* @__PURE__ */ new Set(), i = (e, n, r) => {
		let i = t.get(e);
		if (i && (i.role !== n || i.ownerId !== r)) throw new M("IMPORT_CONFLICT", "同じIDが別の種別・所有者で使われています。", e);
		t.set(e, {
			id: e,
			role: n,
			...r ? { ownerId: r } : {}
		});
	}, a = (e, t) => {
		if (Array.isArray(e)) {
			e.forEach((e) => a(e, t));
			return;
		}
		if (!e || typeof e != "object") return;
		let o = e;
		if (typeof o.id == "string") {
			let e = "kind" in o && "text" in o ? "block" : "audienceHolderIds" in o ? "alias" : "eventKey" in o ? "trigger" : "x" in o && "y" in o ? "map_pin" : (() => {
				throw new M("IMPORT_CONFLICT", "未対応の埋込IDです。", o.id);
			})();
			i(o.id, e, t);
		}
		typeof o.instanceId == "string" && "quantity" in o && "consumed" in o && r.add(o.instanceId), typeof o.sourceVersionId == "string" && typeof o.profileId == "string" && typeof o.publicVersionId == "string" && i(o.publicVersionId, "public_id"), o.mode === "anonymize" && typeof o.publicId == "string" && i(o.publicId, "public_id");
		for (let [e, r] of Object.entries(o)) {
			if (e === "publicIds" && r && typeof r == "object") for (let e of Object.values(r)) typeof e == "string" && i(e, "public_id");
			if (e === "bindings" && r && typeof r == "object" && !Array.isArray(r)) for (let e of Object.values(r)) typeof e == "string" && n.push({
				id: e,
				ownerId: t
			});
			a(r, t);
		}
	}, o = (e) => {
		i(e.projectId, "project");
		for (let t of e.entities) i(t.id, t.kind === "snapshot" ? "snapshot" : `entity:${t.kind}`), t.deletionOperationId && i(t.deletionOperationId, "operation"), a(t.data, t.id);
		for (let t of e.relations) i(t.id, "relation"), t.deletionOperationId && i(t.deletionOperationId, "operation");
		for (let t of e.views) i(t.id, "view");
		if ("authorAlternatives" in e && Array.isArray(e.authorAlternatives)) for (let t of e.authorAlternatives) {
			i(t.id, "alternative", t.projectId);
			for (let e of t.versions) i(e.id, "alternative_version", t.id);
			for (let e of t.applyReceipts) i(e.id, "alternative_receipt", t.id);
			o(t.baseContent);
			for (let e of t.versions) o(e.content);
		}
		if ("snapshots" in e) for (let t of e.snapshots) i(t.id, "snapshot"), o(t.content);
	};
	o(e);
	for (let t of e.history) i(t.operationId, "operation"), o(t.before), o(t.after);
	for (let e of r) t.get(e)?.role !== "entity:item" && i(e, "runtime_item");
	for (let e of n) t.has(e.id) || i(e.id, "reuse_binding", e.ownerId);
	return [...t.values()];
}
function qr(e) {
	return Object.assign(new M("VALIDATION_FAILED", e.map((e) => `${e.path}: ${e.message}`).join("\n"), e[0]?.path), { issues: e });
}
function Jr(e, t, n) {
	if (e.projectId === t.projectId) throw new M("IMPORT_CONFLICT", "同じ作品はIDを維持して統合してください。");
	let r = new Map(Kr(e).map((e) => [e.id, e])), i = new Map(Kr(t).map((e) => [e.id, e])), a = {}, o = /* @__PURE__ */ new Set();
	for (let e of Object.keys(n)) if (!r.has(e)) throw new M("IMPORT_CONFLICT", "対応表に作品外・未知のIDがあります。固定世界のIDは変更できません。", e);
	for (let [e, t] of r) {
		let r = Object.hasOwn(n, e) ? n[e] : void 0;
		if (!r || !C.test(r)) throw new M("IMPORT_CONFLICT", "全ローカルIDの明示対応が必要です。", e);
		if (o.has(r)) throw new M("IMPORT_CONFLICT", "複数の元IDを同じIDへ統合できません。対応を一対一にしてください。", e);
		o.add(r), a[e] = r;
		let s = i.get(r);
		if (s && s.role !== t.role) throw new M("IMPORT_CONFLICT", "対応先の種別が異なります。", e);
		if (s && (t.role === "operation" || t.role === "snapshot")) throw new M(t.role === "snapshot" ? "IMMUTABLE_SNAPSHOT" : "OPERATION_CONFLICT", "復元履歴・不変版は既存IDを上書きできません。新しい対応IDを選んでください。", e);
	}
	if (a[e.projectId] !== t.projectId) throw new M("IMPORT_CONFLICT", "元projectIdの対応先を対象作品にしてください。", e.projectId);
	for (let [e, t] of r) {
		let n = i.get(a[e]);
		if (t.ownerId && n?.ownerId && a[t.ownerId] !== n.ownerId) throw new M("IMPORT_CONFLICT", "段落・別名などの対応先が対応した所有者に属していません。", e);
	}
	return a;
}
function Yr(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => Yr(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	if (typeof n.id == "string" && (n.id = t[n.id] ?? n.id), typeof n.instanceId == "string" && "quantity" in n && "consumed" in n && (n.instanceId = t[n.instanceId] ?? n.instanceId), n.mode === "anonymize" && typeof n.publicId == "string" && (n.publicId = t[n.publicId] ?? n.publicId), n.publicIds && typeof n.publicIds == "object") for (let [e, r] of Object.entries(n.publicIds)) typeof r == "string" && (n.publicIds[e] = t[r] ?? r);
	Array.isArray(n.onceTriggers) && (n.onceTriggers = n.onceTriggers.map((e) => typeof e == "string" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, (e) => t[e] ?? e) : e));
	for (let e of Object.values(n)) Yr(e, t);
}
function Xr(e, t) {
	let r = n(e, t);
	for (let t of N(e)) if (t.scope === "identity" || t.scope === "calendar") {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean), n = e.pop();
		if (n === "$key") throw new M("IMPORT_CONFLICT", "外部参照をkeyにした未知の辞書は対応表で変換できません。", t.path);
		let i = r;
		for (let t of e) i = i[t];
		i[n] = t.id;
	}
	return r;
}
function Zr(e, n, r = "", i) {
	let a = (e) => n[e] ?? e;
	if (typeof e == "string") return r === "onceTriggers" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, a) : r === "id" || r === "operationId" || /(?:Id|Ids)$/.test(r) || r === "value" && i?.type === "ref" ? a(e) : e;
	if (Array.isArray(e)) return e.map((e) => Zr(e, n, r, i));
	if (!e || typeof e != "object") return e;
	let o = e;
	if ("kind" in o && "data" in o && "projectId" in o) {
		let e = Xr(o, n);
		return Yr(e.data, n), e;
	}
	if ("relationType" in o && "fromId" in o && "toId" in o) return t(o, n);
	let s = [
		"variableValues",
		"visitCounts",
		"publicTexts",
		"publicIds",
		"byEntityId"
	].includes(r);
	return Object.fromEntries(Object.entries(o).map(([e, t]) => [s ? a(e) : e, Zr(t, n, e, o)]));
}
function Qr(e, t) {
	return t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
}
function $r(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	if (t.length) {
		let e = t[t.length - 1];
		n === void 0 ? delete i[e] : i[e] = structuredClone(n);
	}
	return r;
}
function ei(e, n, r, i, a) {
	if (n.scope === "presentation" && e && typeof e == "object" && !Array.isArray(e)) {
		let t = structuredClone(e), n = (e) => typeof e == "string" ? a[e] ?? e : e;
		return Array.isArray(t.chapterOrder) && (t.chapterOrder = t.chapterOrder.map(n)), Array.isArray(t.chapters) && (t.chapters = t.chapters.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = e;
			return {
				...t,
				id: n(t.id),
				sceneIds: Array.isArray(t.sceneIds) ? t.sceneIds.map(n) : t.sceneIds
			};
		})), Array.isArray(t.scenes) && (t.scenes = t.scenes.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = e;
			return {
				...t,
				id: n(t.id),
				chapterId: n(t.chapterId)
			};
		})), t;
	}
	if (n.scope === "entity" && n.itemId) {
		let t = i.entities.find((e) => e.id === n.itemId) ?? r.baseContent.entities.find((e) => e.id === n.itemId);
		if (n.path.length === 0 && e && typeof e == "object" && "kind" in e && "data" in e) {
			let t = Xr(e, a);
			return Yr(t.data, a), t;
		}
		if (t && n.path.length) {
			let r = Xr($r(t, n.path, e), a);
			return Yr(r.data, a), Qr(r, n.path);
		}
	}
	if (n.scope === "relation" && n.itemId) {
		let o = i.relations.find((e) => e.id === n.itemId) ?? r.baseContent.relations.find((e) => e.id === n.itemId);
		if (n.path.length === 0 && e && typeof e == "object" && "relationType" in e) return t(e, a);
		if (o && n.path.length) return Qr(t($r(o, n.path, e), a), n.path);
	}
	return n.scope === "project" && n.path[0] === "worldReferences" ? structuredClone(e) : n.scope === "project" && n.path.length === 1 && n.path[0] === "calendarId" && typeof e == "string" ? a[e] ?? e : n.scope === "project" && n.path.length === 1 && n.path[0] === "calendars" && Array.isArray(e) ? e.map((e) => e && typeof e == "object" ? {
		...e,
		id: typeof e.id == "string" ? a[e.id] ?? e.id : e.id
	} : e) : Zr(e, a, n.path.at(-1) ?? "");
}
function ti(e, t) {
	return {
		...structuredClone(e),
		chapterId: t(e.chapterId),
		templateId: t(e.templateId),
		assignments: Object.fromEntries(Object.entries(e.assignments).map(([e, n]) => [e, t(n)]))
	};
}
async function ni(n, r, i, a) {
	let o = (e) => i[e] ?? e, s = async (e) => {
		O(a);
		let r = structuredClone(e);
		r.projectId = o(e.projectId), r.entities = e.entities.map((e) => {
			let t = Xr(e, i);
			return t.id = o(e.id), t.projectId = o(e.projectId), Yr(t.data, i), t.deletionOperationId &&= o(t.deletionOperationId), t;
		}), r.relations = e.relations.map((e) => ({
			...t(e, i),
			id: o(e.id),
			projectId: o(e.projectId),
			...e.deletionOperationId ? { deletionOperationId: o(e.deletionOperationId) } : {}
		})), r.views = e.views.map((e) => ({
			...structuredClone(e),
			id: o(e.id),
			entityIds: e.entityIds.map(o)
		}));
		for (let t = 0; t < e.entities.length; t++) {
			let i = e.entities[t], a = r.entities[t];
			if ((i.kind === "localization" || i.kind === "recording") && (a.kind === "localization" || a.kind === "recording")) {
				let t = e.entities.find((e) => e.kind === "dialogue_line" && e.id === i.data.sourceLineId), o = r.entities.find((e) => e.kind === "dialogue_line" && e.id === a.data.sourceLineId);
				t && o && i.data.sourceHash === await wr({
					...n,
					...e
				}, t) && (a.data.sourceHash = await wr({
					...n,
					...r
				}, o));
			}
		}
		let c = "authorAlternatives" in e ? e.authorAlternatives : void 0;
		return Array.isArray(c) && (r.authorAlternatives = await Promise.all(c.map(async (e) => {
			let t = structuredClone(e);
			return t.id = o(e.id), t.projectId = o(e.projectId), t.sourceSnapshotId = e.sourceSnapshotId ? o(e.sourceSnapshotId) : null, t.baseContent = await s(e.baseContent), t.versions = await Promise.all(e.versions.map(async (e) => ({
				...structuredClone(e),
				id: o(e.id),
				parentVersionId: e.parentVersionId ? o(e.parentVersionId) : null,
				content: await s(e.content),
				...e.structurePlan ? { structurePlan: ti(e.structurePlan, o) } : {}
			}))), t.headVersionId = o(e.headVersionId), t.applyReceipts = e.applyReceipts.map((t) => {
				let n = e.versions.find((e) => e.id === t.alternativeVersionId)?.content ?? e.baseContent, r = t.patches.map((t) => {
					let r = t.itemId ? o(t.itemId) : void 0, a = [...t.path], s = [
						t.scope,
						r ?? "",
						...a
					].map((e) => encodeURIComponent(e)).join(":");
					return {
						...structuredClone(t),
						key: s,
						...r ? { itemId: r } : {},
						path: a,
						before: {
							...structuredClone(t.before),
							...t.before.present ? { value: ei(t.before.value, t, e, n, i) } : {}
						},
						after: {
							...structuredClone(t.after),
							...t.after.present ? { value: ei(t.after.value, t, e, n, i) } : {}
						}
					};
				});
				return {
					...structuredClone(t),
					id: o(t.id),
					alternativeVersionId: t.alternativeVersionId ? o(t.alternativeVersionId) : void 0,
					sourceSnapshotId: t.sourceSnapshotId ? o(t.sourceSnapshotId) : null,
					patches: r,
					selectedChangeKeys: r.map((e) => e.key).sort()
				};
			}), st(t);
		}))), "snapshots" in r && "snapshots" in e && (r.snapshots = await Promise.all(e.snapshots.map(async (e) => ({
			...structuredClone(e),
			id: o(e.id),
			content: await s(e.content)
		})))), r;
	}, c = {
		...await s(n),
		history: await Promise.all(n.history.map(async (e) => ({
			...structuredClone(e),
			operationId: o(e.operationId),
			projectId: o(e.projectId),
			targetIds: e.targetIds.map(o),
			before: await s(e.before),
			after: await s(e.after),
			...e.compensatesOperationId ? { compensatesOperationId: o(e.compensatesOperationId) } : {},
			...e.importOrigin ? { importOrigin: {
				...e.importOrigin,
				importOperationId: o(e.importOrigin.importOperationId)
			} } : {},
			...e.idMap ? { idMap: Object.fromEntries(Object.entries(e.idMap).map(([e, t]) => [e, o(t)])) } : {}
		})))
	}, l = /* @__PURE__ */ new Map(), u = (e) => {
		let t = (n) => {
			if (e(n), "snapshots" in n) for (let e of n.snapshots) t(e.content);
			if ("authorAlternatives" in n && Array.isArray(n.authorAlternatives)) for (let e of n.authorAlternatives) {
				t(e.baseContent);
				for (let n of e.versions) t(n.content);
			}
		};
		t(c);
		for (let e of c.history) t(e.before), t(e.after);
	};
	u((e) => {
		if ("snapshots" in e) for (let t of e.snapshots) l.set(t.id, t);
	});
	let d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Set(), p = async (t) => {
		if (d.has(t.id)) return d.get(t.id);
		if (f.has(t.id)) throw new M("HASH_MISMATCH", "版の内容hashに循環参照があります。", t.id);
		f.add(t.id);
		for (let e of t.content.entities) e.kind === "snapshot" && l.has(e.id) && (e.data.contentHash = await p(l.get(e.id)));
		let n = await e(m(t.content));
		return d.set(t.id, n), f.delete(t.id), n;
	};
	for (let e of l.values()) await p(e);
	u((e) => {
		for (let t of e.entities) t.kind === "snapshot" && d.has(t.id) && (t.data.contentHash = d.get(t.id));
		if ("snapshots" in e) for (let t of e.snapshots) {
			t.contentHash = d.get(t.id);
			for (let e of t.content.entities) e.kind === "snapshot" && d.has(e.id) && (e.data.contentHash = d.get(e.id));
		}
	});
	let h = async (e) => {
		"authorAlternatives" in e && Array.isArray(e.authorAlternatives) && (e.authorAlternatives = await Promise.all(e.authorAlternatives.map(st)));
	};
	for (let e of [c, ...c.history.flatMap((e) => [e.before, e.after])]) await h(e);
	let g = new Map(r.entities.map((e) => [e.id, e]));
	return c.entities = c.entities.map((e) => g.has(e.id) ? {
		...e,
		createdAt: g.get(e.id).createdAt
	} : e), c;
}
var ri = [
	"name",
	"calendarId",
	"mainStart",
	"calendars",
	"worldReferences"
];
function ii(e, t, n) {
	let r = [], i = [], a = {
		...structuredClone({
			...e,
			history: []
		}),
		history: e.history
	};
	for (let s of ri) if (!o(e[s], t[s])) {
		let o = `project.${s}`;
		r.push({
			id: o,
			kind: "project",
			existing: e[s],
			incoming: t[s]
		});
		let c = n?.[o] === "incoming";
		c && (a[s] = structuredClone(t[s])), i.push({
			id: o,
			kind: "project",
			action: c ? "update" : "keep",
			fields: [s]
		});
	}
	for (let [s, c] of [
		["entities", "entity"],
		["relations", "relation"],
		["snapshots", "snapshot"],
		["views", "view"]
	]) {
		let l = new Map(e[s].map((e) => [e.id, e]));
		for (let e of t[s]) {
			let t = l.get(e.id), a = t && !o(t, e);
			a && r.push({
				id: e.id,
				kind: c,
				existing: t,
				incoming: e
			}), (!t || n?.[e.id] === "incoming") && l.set(e.id, structuredClone(e));
			let s = Object.keys(e).filter((n) => !t || !o(t[n] ?? null, e[n] ?? null));
			i.push({
				id: e.id,
				kind: c,
				action: t ? a && n?.[e.id] === "incoming" ? "update" : "keep" : "add",
				fields: s
			});
		}
		a[s] = [...l.values()];
	}
	let s = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e]));
	for (let e of t.authorAlternatives ?? []) {
		let t = s.get(e.id);
		if (t && !o(t, e)) {
			if (r.push({
				id: e.id,
				kind: "alternative",
				existing: t,
				incoming: e
			}), n?.[e.id] === "incoming") throw new M("IMPORT_CONFLICT", "保存済み作者別案のIDへ別の履歴を上書きできません。新しいIDへ対応してください。", e.id);
			i.push({
				id: e.id,
				kind: "alternative",
				action: "keep",
				fields: []
			});
		} else t ? i.push({
			id: e.id,
			kind: "alternative",
			action: "keep",
			fields: []
		}) : (s.set(e.id, structuredClone(e)), i.push({
			id: e.id,
			kind: "alternative",
			action: "add",
			fields: [
				"name",
				"baseContent",
				"versions",
				"applyReceipts"
			]
		}));
	}
	(s.size || "authorAlternatives" in e || "authorAlternatives" in t) && (a.authorAlternatives = [...s.values()]);
	let c = r.filter((e) => !n?.[e.id]).map((e) => e.id);
	for (let e of r) if (e.kind === "snapshot" && n?.[e.id] === "incoming") throw new M("IMMUTABLE_SNAPSHOT", "既存版を別の内容に置き換えられません。", e.id);
	return {
		conflicts: r,
		unresolved: c,
		changes: i,
		...c.length ? {} : { candidate: a }
	};
}
async function ai(t, n, r) {
	O(r.signal);
	let i = { ...r.knownWorlds ?? {} };
	for (let [e, n] of Object.entries(t.worlds)) {
		if (i[e] && !o(i[e], n)) throw new M("IMMUTABLE_SNAPSHOT", "固定世界IDと内容が衝突します。", e);
		i[e] = n;
	}
	let a = er(i), s = T(t.project, { worldSnapshots: a });
	if (!s.ok) throw qr(s.issues);
	let c = T(n, { worldSnapshots: a });
	if (!c.ok) throw qr(c.issues);
	if (t.manifest.projectId !== t.project.projectId) throw new M("VALIDATION_FAILED", "manifestと作品のIDが一致しません。");
	tr([
		t.project,
		n,
		...Object.values(i)
	], i), await nr([
		t.project,
		n,
		...Object.values(i)
	]);
	for (let [e, t] of Object.entries(r.resolutions ?? {})) if (!["existing", "incoming"].includes(t)) throw new M("IMPORT_CONFLICT", "競合の採用方法が未対応です。", e);
	let l = Jr(t.project, n, r.idMap), u = await ni(t.project, n, l, r.signal), d = T(u, { worldSnapshots: a });
	if (!d.ok) throw qr(d.issues);
	await nr([u]);
	let f = /* @__PURE__ */ new Map();
	for (let e of [t.project, ...Object.values(t.worlds)]) for (let t of Xn(e)) {
		let e = f.get(t.contentHash);
		if (e && !o(e, t)) throw new M("ASSET_INVALID", "同じ素材hashのメタデータが一致しません。", t.assetPath);
		f.set(t.contentHash, t);
	}
	let p = /* @__PURE__ */ new Map();
	for (let n of t.assets) {
		O(r.signal);
		let t = f.get(n.contentHash);
		if (!t || t.assetPath !== n.path || t.mediaType !== n.mediaType) throw new M("ASSET_INVALID", "素材bytesの宣言と添付が一致しません。", n.path);
		if (Wn(n.path, n.mediaType, n.bytes), n.bytes.byteLength !== t.byteSize || await e(n.bytes) !== n.contentHash) throw new M("HASH_MISMATCH", "素材bytes・サイズ・hashが一致しません。", n.path);
		if (p.has(n.contentHash)) throw new M("ASSET_INVALID", "素材bytesが重複しています。", n.path);
		p.set(n.contentHash, n.bytes);
	}
	let h = [], g = [];
	for (let [t, n] of f) if (!p.has(t)) {
		let i = await r.loadAsset?.(t);
		if (O(r.signal), !i) {
			g.push(t);
			continue;
		}
		if (Wn(n.assetPath, n.mediaType, i), i.byteLength !== n.byteSize || await e(i) !== t) throw new M("HASH_MISMATCH", "端末内の素材bytesが宣言と一致しません。", n.assetPath);
		h.push(t);
	}
	if (t.manifest.assetMode === "embedded" && g.length) throw new M("ASSET_MISSING", "完全復元に必要な素材が不足しています。", g[0]);
	let _ = ii(n, u, r.resolutions), v = new Map(Object.entries(l).map(([e, t]) => [t, e]));
	for (let e of _.changes) v.has(e.id) && (e.sourceId = v.get(e.id));
	if (_.candidate) {
		let e = E(_.candidate, { worldSnapshots: a });
		if (!e.ok) throw qr(e.issues);
	}
	return O(r.signal), {
		sourceProjectId: t.project.projectId,
		targetProjectId: n.projectId,
		targetRevision: n.revision,
		sourceContentHash: await e(m(t.project)),
		idMap: l,
		mappedProject: u,
		..._,
		assets: {
			provided: [...p.keys()],
			reused: h,
			missing: g,
			byteSize: t.assets.reduce((e, t) => e + t.bytes.length, 0)
		},
		warnings: [...t.warnings]
	};
}
//#endregion
//#region src/storage/store.ts
var oi = Object.freeze({ present: !1 }), si = class extends De {
	sharedSnapshots;
	projects;
	entities;
	relations;
	blocks;
	snapshots;
	commands;
	outbox;
	assets;
	views;
	viewStates;
	syncMetadata;
	acks;
	restorePoints;
	worlds;
	importLogs;
	importDrafts;
	authorToolDrafts;
	workspaceInputs;
	recoveredPending;
	retainedSyncRecovery;
	syncAssetAcks;
	syncBases;
	preparedSync;
	syncConflicts;
	syncAckEvidence;
	constructor(e) {
		super(e), this.version(1).stores({
			projects: "projectId,name",
			entities: "[projectId+id],projectId,[projectId+kind]",
			relations: "[projectId+id],projectId,[projectId+fromId],[projectId+toId]",
			blocks: "[projectId+id],projectId,[projectId+entityId]",
			snapshots: "[projectId+id],projectId",
			commands: "operationId,projectId,[projectId+revision]",
			outbox: "operationId,projectId,accountId",
			assets: "contentHash",
			views: "[projectId+id],projectId",
			viewStates: "key,projectId",
			syncMetadata: "projectId",
			acks: "operationId,projectId",
			restorePoints: "id,projectId,createdAt",
			worlds: "id",
			importLogs: "operationId,projectId"
		}), this.version(2).stores({ importDrafts: "key" }), this.version(3).stores({ recoveredPending: "key,projectId" }), this.version(4).stores({ authorToolDrafts: "key,projectId" }), this.version(5).stores({
			syncBases: "projectId",
			preparedSync: "operationId,projectId",
			syncConflicts: "operationId,projectId",
			syncAckEvidence: "operationId,projectId",
			retainedSyncRecovery: "key,projectId",
			syncAssetAcks: "key,projectId",
			sharedSnapshots: "id,createdAt"
		}), this.version(6).stores({ workspaceInputs: "key" }), this.version(7).stores({ recordParts: "key,scope" }), Ze(this);
	}
}, Z = (e) => structuredClone(e), Q = (e, t) => e === t || o(e ?? null, t ?? null), ci = /* @__PURE__ */ new WeakSet();
function li(e) {
	if (e && typeof e == "object" && !ci.has(e)) {
		for (let t of Object.values(e)) li(t);
		Object.freeze(e), ci.add(e);
	}
	return e;
}
function ui(e) {
	return {
		...Z($(e)),
		history: e.history
	};
}
function di(e) {
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object") return typeof e == "function" ? Z(e) : e;
		if (ci.has(e)) return e;
		if (t.has(e)) return t.get(e);
		if (!Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return Z(e);
		let r = Array.isArray(e) ? Array(e.length) : {};
		t.set(e, r);
		for (let t of Object.keys(e)) Object.defineProperty(r, t, {
			value: n(e[t]),
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		return r;
	};
	return {
		...n($(e)),
		history: e.history
	};
}
function fi(e, t) {
	let n = (e, t) => {
		let n = new Map(e.map((e) => [e.id, e])), r = new Map(t.map((e) => [e.id, e]));
		return [.../* @__PURE__ */ new Set([...n.keys(), ...r.keys()])].flatMap((e) => Q(n.get(e) ?? null, r.get(e) ?? null) ? [] : [{
			id: e,
			record: r.get(e) ?? null
		}]);
	}, r = Di(e), i = Di(t), a = {};
	for (let e of Object.keys(i)) e !== "id" && e !== "kind" && !Q(r[e], i[e]) && (a[e] = i[e]);
	let o = (e, t) => e.length === t.length && e.every((e, n) => e.id === t[n].id) ? void 0 : t.map((e) => e.id);
	return {
		header: a,
		entities: n(e.entities, t.entities),
		relations: n(e.relations, t.relations),
		entityIds: o(e.entities, t.entities),
		relationIds: o(e.relations, t.relations)
	};
}
function pi(e, t) {
	let n = (e, t, n) => {
		if (!t.length && !n) return e;
		let r = new Map(e.map((e) => [e.id, e]));
		for (let e of t) e.record ? r.set(e.id, e.record) : r.delete(e.id);
		return (n ?? [...r.keys()]).map((e) => {
			let t = r.get(e);
			if (!t) throw new M("SAVE_FAILED", "履歴の差分に必要な情報が不足しています。", e);
			return t;
		});
	};
	return {
		...e,
		...t.header,
		entities: n(e.entities, t.entities, t.entityIds),
		relations: n(e.relations, t.relations, t.relationIds)
	};
}
var mi = (e) => (BigInt(e) + 1n).toString(), $ = ({ history: e, ...t }) => t, hi = (e) => {
	let t = {
		...$(e),
		entities: [],
		relations: [],
		snapshots: [],
		views: [],
		revision: "0"
	};
	return e.authorAlternatives?.length ? t.authorAlternatives = [] : delete t.authorAlternatives, t;
};
function gi(e, t = {}) {
	let n = T(e, { worldSnapshots: t });
	if (!n.ok) throw Object.assign(new M("VALIDATION_FAILED", n.issues.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: n.issues });
	return x(n.value), n.value;
}
function _i(e, t, n, r = /* @__PURE__ */ new WeakMap()) {
	let i = E(e, { worldSnapshots: t }, n ? {
		previous: n,
		references: r
	} : void 0);
	if (!i.ok) {
		let e = new M("VALIDATION_FAILED", i.issues.map((e) => `${e.path}: ${e.message}`).join("\n"));
		throw Object.assign(e, { issues: i.issues }), e;
	}
	return e;
}
async function vi(e, t = {}, n = e.history.length > 0, r) {
	let i = await K(e, { worldSnapshots: t }, n, r);
	if (i.length) throw Object.assign(new M("VALIDATION_FAILED", i.map((e) => `${e.path}: ${e.message}`).join("\n")), { issues: i });
}
function yi(e) {
	return Object.fromEntries(Object.entries(e).filter(([e]) => !["revision", "updatedAt"].includes(e)));
}
function bi(e, t, n, r) {
	let i = new Map(e.map((e) => [e.id, e])), a = t.map((e) => {
		let t = i.get(e.id);
		if (t && "kind" in t && "kind" in e && t.kind !== e.kind) throw new M("OPERATION_CONFLICT", "既存IDを別の種類へ再利用できません。", e.id);
		if (!t) return Z(e);
		if ("createdAt" in t && "createdAt" in e && t.createdAt !== e.createdAt) throw new M("OPERATION_CONFLICT", "既存IDの作成日時は変更できません。", e.id);
		return Q(t, e) || Q(yi(t), yi(e)) ? t : {
			...Z(e),
			revision: mi(t.revision),
			..."updatedAt" in e ? { updatedAt: r } : {}
		};
	}), o = new Set(t.map((e) => e.id));
	for (let t of e) o.has(t.id) || a.push(t.deletedAt ? t : {
		...Z(t),
		deletedAt: r,
		deletionOperationId: n,
		revision: mi(t.revision),
		..."updatedAt" in t ? { updatedAt: r } : {}
	});
	return a;
}
function xi(e, t) {
	for (let n of e.snapshots) {
		let e = t.snapshots.find((e) => e.id === n.id);
		if (!e || !o(n, e)) throw new M("IMMUTABLE_SNAPSHOT", "公開済み・保存済みの不変snapshotは変更や削除ができません。", n.id);
	}
	for (let n of e.entities.filter((e) => e.kind === "snapshot")) {
		let e = t.entities.find((e) => e.id === n.id);
		if (!e || !o(n, e)) throw new M("IMMUTABLE_SNAPSHOT", "不変snapshotは変更や削除ができません。", n.id);
	}
}
function Si(e, t, n) {
	let r = Math.min(e.length, t.length);
	for (let i = 0; i < r; i++) if (!Q(e[i], t[i])) throw new M("VALIDATION_FAILED", `${n}の既存記録は変更できません。`);
	return t.length < e.length;
}
async function Ci(e, t) {
	let n = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e])), r = new Map((t.authorAlternatives ?? []).map((e) => [e.id, e])), i = [];
	for (let e of n.values()) {
		let t = r.get(e.id);
		if (!t) {
			i.push(await st({
				...Z(e),
				status: "rejected",
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			}));
			continue;
		}
		if (t.projectId !== e.projectId || t.baseRevision !== e.baseRevision || (t.sourceSnapshotId ?? null) !== (e.sourceSnapshotId ?? null) || t.createdAt !== e.createdAt || !Q(t.baseContent, e.baseContent) || t.baseContentHash !== e.baseContentHash) throw new M("VALIDATION_FAILED", "別案の分岐元と識別情報は変更できません。", e.id);
		let n = Si(e.versions, t.versions, "別案の版"), a = Si(e.applyReceipts, t.applyReceipts, "正本採用履歴"), o = t.versions.find((e) => e.id === t.headVersionId);
		if (!o) throw new M("VALIDATION_FAILED", "別案の現在版が見つかりません。", e.id);
		if (!(n || a || t.headVersionId !== t.versions.at(-1)?.id)) {
			i.push(t);
			continue;
		}
		let s = {
			...Z(t),
			versions: Z(n ? e.versions : t.versions),
			applyReceipts: Z(a ? e.applyReceipts : t.applyReceipts)
		};
		if (n || s.headVersionId !== s.versions.at(-1)?.id) {
			let e = o.content, t = o.structurePlan, n = Date.parse(s.versions.at(-1)?.createdAt ?? ""), r = new Date(Math.max(Date.now(), Number.isFinite(n) ? n + 1 : 0)).toISOString();
			s = ee(s, e, `「${o.label}」から復元`, r, u(), t);
		}
		i.push(await st(s));
	}
	for (let e of r.values()) n.has(e.id) || i.push(e);
	t.authorAlternatives = i;
}
function wi(e, t) {
	let n = new Map((e.authorAlternatives ?? []).map((e) => [e.id, e])), r = [];
	for (let e of t.authorAlternatives ?? []) {
		let t = n.get(e.id), i = new Set(t?.applyReceipts.map((e) => e.id) ?? []);
		for (let t of e.applyReceipts) i.has(t.id) || r.push({
			alternativeId: e.id,
			receipt: t
		});
	}
	if (!r.length) return;
	if (r.length !== 1) throw new M("VALIDATION_FAILED", "一回の保存では一件の作者別案採用を記録してください。");
	let { alternativeId: i, receipt: a } = r[0], o = n.get(i);
	if (!o || a.alternativeVersionId !== o.headVersionId || a.fromCanonicalRevision !== e.revision || a.appliedRevision !== mi(e.revision)) throw new M("VALIDATION_FAILED", "採用記録の正本版または別案版が保存元と一致しません。", i);
	let s;
	try {
		s = te(e, o, [], new Set(a.selectedChangeKeys ?? []), a.createdAt, a.id);
	} catch (e) {
		throw new M("VALIDATION_FAILED", e instanceof Error ? e.message : "採用差分を再計算できません。", i);
	}
	let { appliedRevision: c, ...l } = a;
	if (!Q(l, s.receipt)) throw new M("VALIDATION_FAILED", "作者別案の採用差分が現在の正本・選択元版と一致しません。", i);
	let u = (e) => e.kind === "review" && e.customValues["changeReview.generatedBy"] === "semantic-change-review/v1" && typeof e.customValues["changeReview.key"] == "string" ? e.customValues["changeReview.key"] : void 0, d = new Set(e.entities.flatMap((e) => u(e) ?? [])), f = Gr(e, s.project), p = (e) => e.entities.filter((e) => {
		let t = u(e);
		return t !== void 0 && !d.has(t);
	}), m = (e) => {
		let t = Z(e);
		if (delete t.id, delete t.createdAt, delete t.updatedAt, t.kind === "review") {
			let e = t.data;
			Array.isArray(e.body) && (e.body = e.body.map((e) => {
				let t = { ...e };
				return delete t.id, t;
			}));
		}
		return t;
	}, h = p(f).sort((e, t) => (u(e) ?? "").localeCompare(u(t) ?? "")), g = p(t).sort((e, t) => (u(e) ?? "").localeCompare(u(t) ?? "")), _ = (e, t) => {
		let n = new Set(t.map((e) => e.id));
		return {
			...b(e),
			entities: e.entities.filter((e) => !n.has(e.id))
		};
	}, v = Q(_(f, h), _(t, g)), y = h.length === g.length && h.every((e, t) => Q(m(e), m(g[t])));
	if (!v || !y) throw new M("VALIDATION_FAILED", "作者別案の採用差分が現在の正本・選択元版と一致しません。", i);
}
function Ti(e) {
	let t = [], n = (r) => {
		if (Array.isArray(r)) {
			if (r.length && r.every((e) => e && typeof e == "object" && "id" in e && "text" in e && [
				"paragraph",
				"heading",
				"list_item",
				"quote"
			].includes(e.kind))) {
				for (let n of r) t.push({
					id: n.id,
					projectId: e.projectId,
					entityId: e.id,
					block: Z(n)
				});
				return { __scenarioRichText: r.map((e) => e.id) };
			}
			return r.map(n);
		}
		return r && typeof r == "object" ? Object.fromEntries(Object.entries(r).map(([e, t]) => [e, n(t)])) : r;
	};
	return {
		record: n(e),
		blocks: t
	};
}
function Ei(e, t) {
	let n = (e) => {
		if (Array.isArray(e)) {
			let t;
			for (let r = 0; r < e.length; r++) {
				let i = n(e[r]);
				i !== e[r] && (t ??= e.slice(), t[r] = i);
			}
			return t ?? e;
		}
		if (e && typeof e == "object") {
			let r = e;
			if (Array.isArray(r.__scenarioRichText)) return r.__scenarioRichText.map((e) => {
				let n = t.get(e);
				if (!n) throw new M("SAVE_FAILED", "本文blockが不足しています。完全保存ファイルから復元してください。", e);
				return Z(n);
			});
			let i;
			for (let e of Object.keys(r)) {
				let t = n(r[e]);
				t !== r[e] && (i ??= { ...r }, i[e] = t);
			}
			return i ?? e;
		}
		return e;
	};
	return n(e);
}
function Di(e) {
	let { entities: t, relations: n, ...r } = e;
	return {
		...r,
		id: e.projectId,
		kind: "project"
	};
}
async function Oi(t, n, r = !1) {
	let i = new Map([
		...t.entities,
		...t.relations,
		...r ? [] : [Di(t)]
	].map((e) => [e.id, e])), a = new Map([
		...n.entities,
		...n.relations,
		Di(n)
	].map((e) => [e.id, e])), o = [], s;
	for (let t of /* @__PURE__ */ new Set([...i.keys(), ...a.keys()])) {
		let r = i.get(t) ?? null, c = a.get(t) ?? null;
		if (t !== n.projectId && (r === c || Q(r ? yi(r) : null, c ? yi(c) : null))) continue;
		let l = [];
		for (let t of /* @__PURE__ */ new Set([...Object.keys(r ?? {}), ...Object.keys(c ?? {})])) {
			if (["revision", "updatedAt"].includes(t)) continue;
			let n = r && t in r ? {
				present: !0,
				value: r[t]
			} : oi, i = c && t in c ? {
				present: !0,
				value: c[t]
			} : oi;
			n.present && i.present && n.value === i.value || Q(n, i) || l.push({
				field: t,
				oldValueHash: n.present ? await e(m(n)) : s ??= await e(m(n)),
				before: n,
				after: i
			});
		}
		o.push({
			targetId: t,
			before: r,
			after: c,
			fields: l
		});
	}
	return o;
}
var ki = class {
	authorAccess = null;
	setAuthorAccess(e) {
		this.authorAccess = e ? new Map(Object.entries(e)) : null;
	}
	db;
	activeOperations = 0;
	get pendingOperations() {
		return this.activeOperations;
	}
	accountId;
	faultInjector;
	onSaveMetrics;
	cachedProjects = /* @__PURE__ */ new Map();
	contentHeads = /* @__PURE__ */ new Map();
	cachedHistoryIds = /* @__PURE__ */ new Map();
	completeHistories = /* @__PURE__ */ new Set();
	cacheEpochs = /* @__PURE__ */ new Map();
	cacheLifetime = 0;
	editingHistories = /* @__PURE__ */ new WeakMap();
	validationReferences = /* @__PURE__ */ new WeakMap();
	constructor(e = {}) {
		this.accountId = e.accountId ?? null, this.faultInjector = e.faultInjector, this.onSaveMetrics = e.onSaveMetrics, this.db = new si(e.databaseName ?? (this.accountId ? `scenario-manager-account-${encodeURIComponent(this.accountId)}` : "scenario-manager-local-v1"));
		for (let e of [
			"saveProject",
			"importScenario",
			"putAsset",
			"commitPreparedAck",
			"confirmSyncResolution",
			"bindBootstrapBase",
			"bindConfirmedProject",
			"saveAuthorToolDraft",
			"saveImportDraft",
			"applyReceivedImage",
			"saveWorkspaceInputs",
			"restoreAuthorInputs",
			"restoreAuthorToolDrafts"
		]) {
			let t = this[e].bind(this);
			Object.defineProperty(this, e, {
				configurable: !0,
				writable: !0,
				value: async (...e) => {
					this.activeOperations++;
					try {
						return await t(...e);
					} finally {
						this.activeOperations--;
					}
				}
			});
		}
	}
	get writeTables() {
		return [
			"projects",
			"entities",
			"relations",
			"blocks",
			"snapshots",
			"commands",
			"outbox",
			"assets",
			"views",
			"syncMetadata",
			"restorePoints",
			"worlds",
			"importLogs",
			"recoveredPending",
			"syncBases",
			"preparedSync",
			"syncConflicts",
			"syncAckEvidence",
			"retainedSyncRecovery",
			"syncAssetAcks"
		];
	}
	async guardWorldRegistry(e) {
		let t = /* @__PURE__ */ new Map();
		for (let n of [...(await this.db.worlds.toArray()).map((e) => e.project), ...e]) for (let e of n.snapshots) {
			let n = t.get(e.id);
			if (n && !Q(n, e)) throw new M("IMMUTABLE_SNAPSHOT", "固定版IDが別の保存済み内容と衝突しています。", e.id);
			t.set(e.id, e);
		}
	}
	close() {
		this.cacheLifetime++;
		for (let e of this.cacheEpochs.keys()) this.invalidateProjectCache(e);
		this.db.close();
	}
	async deleteDatabase() {
		this.close(), await this.db.delete();
	}
	invalidateProjectCache(e) {
		this.cacheEpochs.set(e, (this.cacheEpochs.get(e) ?? 0) + 1), this.cachedProjects.delete(e), this.contentHeads.delete(e), this.cachedHistoryIds.delete(e), this.completeHistories.delete(e);
	}
	rememberProject(e, t, n = e.history.map((e) => e.operationId), r) {
		let i = this.cachedProjects.get(e.projectId), a = this.cacheEpochs.get(e.projectId) ?? 0;
		if (r && (r.project !== a || r.lifetime !== this.cacheLifetime) || i && BigInt(i.revision) > BigInt(e.revision)) return e;
		let o = li({
			...$(e),
			history: li(e.history.map((e) => li(e)))
		});
		return this.cachedProjects.set(e.projectId, o), this.contentHeads.set(e.projectId, t), this.cachedHistoryIds.set(e.projectId, n), Q(n, e.history.map((e) => e.operationId)) ? this.completeHistories.add(e.projectId) : this.completeHistories.delete(e.projectId), this.cacheEpochs.set(e.projectId, a + 1), o;
	}
	editingCopy(e, t = e.history.map((e) => e.operationId), n = !1) {
		let r = li([]);
		return this.editingHistories.set(r, {
			projectId: e.projectId,
			revision: e.revision,
			historyIds: t
		}), {
			...n ? $(e) : Z($(e)),
			history: r
		};
	}
	getHistoryCount(e) {
		return this.editingHistories.get(e.history)?.historyIds.length ?? e.history.length;
	}
	async materializeCommand(e, t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = !0) {
		let a = n.get(e.operationId);
		if (a) return a;
		if (e.record) return n.set(e.operationId, e.record), e.record;
		let o = e.delta;
		if (!o || r.has(e.operationId)) throw new M("SAVE_FAILED", "履歴の差分または復元点が破損しています。", e.operationId);
		r.add(e.operationId);
		let s = o.checkpoint;
		if (!s && o.parentOperationId) {
			let a = t.get(o.parentOperationId) ?? (i ? await this.db.commands.get(o.parentOperationId) : void 0);
			if (!a || a.projectId !== e.projectId) throw new M("SAVE_FAILED", "履歴の元の版が不足しています。", o.parentOperationId);
			s = (await this.materializeCommand(a, t, n, r, i)).after;
		}
		if (!s || s.projectId !== e.projectId || s.revision !== o.metadata.baseRevision) throw new M("SAVE_FAILED", "履歴の復元点と元の版が一致しません。", e.operationId);
		let c = {
			...o.metadata,
			before: s,
			after: pi(s, o.patch)
		};
		if (c.operationId !== e.operationId || c.projectId !== e.projectId || c.after.revision !== e.revision) throw new M("SAVE_FAILED", "履歴の差分と操作情報が一致しません。", e.operationId);
		return r.delete(e.operationId), n.set(e.operationId, c), c;
	}
	async readProject(e, t = !0, n, r, i) {
		let a = (e, t) => {
			if (!n) return t();
			let r = performance.now();
			return t().then((t) => (n[`database.${e}`] = performance.now() - r, t));
		}, o = r ?? await this.db.projects.get(e);
		if (!o) return;
		if (o.projectId !== e) throw new M("SAVE_FAILED", "作品の保存情報が別の作品を指しています。", e);
		let { entityIds: s, relationIds: c, snapshotIds: l, historyIds: u, viewIds: d, contentHeadOperationId: f, ...p } = o, m = async (t) => {
			let n = [], r = 2048, a;
			for (;;) {
				O(i);
				let o = await t.where("[projectId+id]").between([e, a ?? De.minKey], [e, De.maxKey], a === void 0, !0).limit(r).toArray();
				O(i);
				for (let e of o) n.push(e);
				if (o.length < r) return n;
				let s = o[o.length - 1].id;
				if (typeof s != "string" || !s || a !== void 0 && s <= a) throw new M("SAVE_FAILED", "作品の保存索引を順に読み取れません。保存済みデータを保持しています。", e);
				a = s;
			}
		}, [h, g, _, v, y, b] = await Promise.all([
			a("entities", () => m(this.db.entities)),
			a("relations", () => m(this.db.relations)),
			a("snapshots", () => m(this.db.snapshots)),
			t ? this.db.commands.bulkGet(u) : Promise.resolve([]),
			m(this.db.views),
			a("blocks", () => m(this.db.blocks))
		]), x = (e, t) => {
			let n = /* @__PURE__ */ new Map();
			for (let e of t) n.set(e.id, e);
			return e.map((e) => n.get(e));
		}, S = x(s, h), C = x(c, g), w = x(l, _), T = x(d, y);
		if ([
			S,
			C,
			w,
			v,
			T
		].some((e) => e.some((e) => !e))) throw new M("SAVE_FAILED", "作品の保存情報が不足しています。完全保存ファイルから復元してください。", e);
		let E = /* @__PURE__ */ new Map();
		for (let e of b) E.set(e.id, e.block);
		let D = new Map(v.map((e) => [e.operationId, e])), ee = /* @__PURE__ */ new Map(), k = [];
		v.length && await De.waitFor((async () => {
			for (let e of v) k.push(await this.materializeCommand(e, D, ee));
		})());
		let A = n ? performance.now() : void 0, te = S.map((e) => Ei(e.record, E));
		return A !== void 0 && (n["database.hydrate"] = performance.now() - A), {
			historyIds: u,
			contentHeadOperationId: f,
			project: {
				...p,
				entities: te,
				relations: C,
				snapshots: w.map((e) => {
					let { projectId: t, ...n } = e;
					return n;
				}),
				history: k,
				views: T.map((e) => {
					let { projectId: t, ...n } = e;
					return n;
				})
			}
		};
	}
	async getProject(e) {
		try {
			let t = {
				project: this.cacheEpochs.get(e) ?? 0,
				lifetime: this.cacheLifetime
			}, n = await this.db.transaction("r", this.writeTables, async () => {
				let t = await this.db.projects.get(e), n = this.cachedProjects.get(e);
				if (t) return n?.revision === t.revision && this.completeHistories.has(e) && Q(this.cachedHistoryIds.get(e), t.historyIds) ? {
					project: n,
					historyIds: t.historyIds,
					contentHeadOperationId: t.contentHeadOperationId
				} : this.readProject(e, !0, void 0, t);
			});
			if (!n) return;
			let { project: r } = n;
			if (r !== this.cachedProjects.get(e)) {
				let e = await this.validationWorlds();
				gi(r, er(e)), tr([r], e), await nr([r]), await vi(r, er(e)), r = this.rememberProject(r, n.contentHeadOperationId, n.historyIds, t);
			}
			return ui(r);
		} catch (e) {
			throw A(e);
		}
	}
	async getProjectForEditing(e, t = {}) {
		O(t.signal);
		let n = sr(), r = {}, i = n, a = (e) => {
			if (i === void 0) return;
			let t = performance.now();
			r[e] = (r[e] ?? 0) + t - i, i = t;
		}, o = this.authorAccess && await this.db.syncBases.get(e) && this.authorAccess.get(e) !== "owner";
		if (O(t.signal), !o) try {
			let i = {
				project: this.cacheEpochs.get(e) ?? 0,
				lifetime: this.cacheLifetime
			}, o = await this.db.transaction("r", this.writeTables, async () => {
				Xe(t.signal), O(t.signal);
				let i = n === void 0 ? void 0 : performance.now(), a = await this.db.projects.get(e), o = this.cachedProjects.get(e);
				if (i !== void 0 && (r["database.header"] = performance.now() - i), a) return o?.revision === a.revision && Q(this.cachedHistoryIds.get(e), a.historyIds) ? {
					project: o,
					historyIds: a.historyIds,
					contentHeadOperationId: a.contentHeadOperationId
				} : this.readProject(e, !1, n === void 0 ? void 0 : r, a, t.signal);
			});
			if (O(t.signal), !o) return;
			a("database");
			let { project: s } = o;
			if (s !== this.cachedProjects.get(e)) {
				let e = await this.validationWorlds();
				a("dependencies");
				let n = "transfer";
				await or(s, e, {
					...t,
					onStage: (e) => {
						a(n), n = `validation.${e}`, t.onStage?.(e);
					}
				}), a(n), O(t.signal), s = this.rememberProject(s, o.contentHeadOperationId, o.historyIds, i), a("immutable");
			}
			O(t.signal);
			let c = this.editingCopy(s, o.historyIds, t.immutableView);
			return a("view"), lr(n, s.projectId, r), c;
		} catch (e) {
			throw A(e);
		}
	}
	async listProjectsForEditing(e = {}) {
		O(e.signal);
		let t = await this.db.projects.toCollection().primaryKeys(), n = [];
		e.onProgress?.(0, t.length);
		for (let [r, i] of t.entries()) {
			O(e.signal);
			let a = await this.getProjectForEditing(i, e);
			O(e.signal), a && n.push(a), e.onProgress?.(r + 1, t.length);
		}
		return n;
	}
	async listProjects() {
		try {
			let e = await this.db.projects.toArray();
			return (await Promise.all(e.map((e) => this.getProject(e.projectId)))).filter((e) => !!e);
		} catch (e) {
			throw A(e);
		}
	}
	async listHistory(e) {
		return (await this.getProject(e))?.history ?? [];
	}
	async historyPage(e, t = {}) {
		let n = (t.query ?? "").normalize("NFKC").toLocaleLowerCase(), r = t.page ?? 0, i = t.size ?? 30;
		if (!Number.isSafeInteger(r) || r < 0 || !Number.isSafeInteger(i) || i < 1 || i > 60) throw new M("VALIDATION_FAILED", "履歴のページは0以上、ページ件数は1〜60です。");
		let a = await this.db.projects.get(e);
		if (!a) throw new M("NOT_FOUND", "作品が見つかりません。");
		let o = (await this.db.commands.bulkGet(a.historyIds)).map((t, n) => {
			let r = t?.delta?.metadata ?? t?.record;
			if (!r || r.projectId !== e || r.operationId !== a.historyIds[n]) throw new M("SAVE_FAILED", "履歴の操作情報が不足しています。", a.historyIds[n]);
			let { before: i, after: o, ...s } = r;
			return s;
		}).reverse().filter((e) => !n || [
			e.reason,
			e.revision,
			e.baseRevision,
			e.operationId,
			e.createdAt,
			...e.targetIds
		].some((e) => e.normalize("NFKC").toLocaleLowerCase().includes(n))), s = Math.max(0, Math.ceil(o.length / i) - 1), c = Math.min(r, s);
		return {
			entries: o.slice(c * i, (c + 1) * i),
			page: c,
			maximum: s,
			total: o.length,
			size: i
		};
	}
	async historyCommand(e, t) {
		let n = await this.db.projects.get(e), r = await this.db.commands.get(t);
		if (!n?.historyIds.includes(t) || !r || r.projectId !== e) throw new M("NOT_FOUND", "この作品の履歴操作が見つかりません。", t);
		return Z(await this.materializeCommand(r));
	}
	async validationWorlds(e = {}) {
		let t = await this.db.worlds.toArray(), n = Object.fromEntries(t.map((e) => [e.id, e.project]));
		for (let [t, r] of Object.entries(e)) n[t] = r;
		return n;
	}
	async listWorldSnapshots() {
		return Z(await this.validationWorlds());
	}
	async getProjectAtRevision(e, t) {
		if (!/^(?:0|[1-9]\d*)$/.test(t)) throw new M("VALIDATION_FAILED", "revisionは正規の10進整数文字列で指定してください。");
		let n = await this.getProject(e);
		if (!n) return;
		let r = n.history.filter((e) => e.revision === t);
		if (r.length > 1 && r.some((e) => !o(e.after, r[0].after))) throw new M("RESTORE_CONFLICT", "同じrevisionに複数の履歴があります。操作IDまたは不変snapshotで対象版を選んでください。");
		if (n.revision === t) {
			if (r.some((e) => !o(e.after, $(n)))) throw new M("RESTORE_CONFLICT", "現在版と同じrevisionに別の履歴があります。操作IDまたは不変snapshotで対象版を選んでください。");
			return n;
		}
		let i = r[0];
		if (i) return {
			...Z(i.after),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(t))
		};
		let a = n.history.find((e) => e.baseRevision === t);
		return a ? {
			...Z(a.before),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(t))
		} : void 0;
	}
	async getProjectAtSnapshot(e, t) {
		let n = await this.getProject(e), r = n?.snapshots.find((e) => e.id === t);
		return r ? {
			...Z(r.content),
			snapshots: Z(n.snapshots),
			history: n.history.filter((e) => BigInt(e.revision) <= BigInt(r.content.revision))
		} : void 0;
	}
	async writeContent(e, t, n, r = e.history.map((e) => e.operationId)) {
		let { entities: i, relations: a, snapshots: o, history: s, views: c, ...l } = e, u = (t, n) => {
			let r = new Map(t.map((e) => [e.id, e])), i = new Set(n.map((e) => e.id));
			return {
				put: n.filter((e) => !Q(r.get(e.id), e)),
				remove: t.filter((e) => !i.has(e.id)).map((t) => [e.projectId, t.id])
			};
		}, d = u(t?.entities ?? [], i), f = u(t?.relations ?? [], a), p = u(t?.snapshots ?? [], o), m = u(t?.views ?? [], c), h = d.put.map((e) => ({
			entity: e,
			...Ti(e)
		})), g = /* @__PURE__ */ new Set([...d.put.map((e) => e.id), ...d.remove.map((e) => e[1])]), _ = u((t?.entities ?? []).filter((e) => g.has(e.id)).flatMap((e) => Ti(e).blocks), h.flatMap((e) => e.blocks));
		return await Promise.all([
			this.db.entities.bulkDelete(d.remove),
			this.db.relations.bulkDelete(f.remove),
			this.db.blocks.bulkDelete(_.remove),
			this.db.snapshots.bulkDelete(p.remove),
			this.db.views.bulkDelete(m.remove)
		]), await this.db.projects.put({
			...l,
			entityIds: i.map((e) => e.id),
			relationIds: a.map((e) => e.id),
			snapshotIds: o.map((e) => e.id),
			historyIds: r,
			viewIds: c.map((e) => e.id),
			...n ? { contentHeadOperationId: n } : {}
		}), await Promise.all([
			this.db.entities.bulkPut(h.map((t) => ({
				id: t.entity.id,
				projectId: e.projectId,
				kind: t.entity.kind,
				record: t.record
			}))),
			this.db.relations.bulkPut(f.put),
			this.db.blocks.bulkPut(_.put),
			this.db.snapshots.bulkPut(p.put.map((t) => ({
				...t,
				projectId: e.projectId
			}))),
			this.db.views.bulkPut(m.put.map((t) => ({
				...t,
				projectId: e.projectId
			})))
		]), {
			entities: d.put.length + d.remove.length,
			relations: f.put.length + f.remove.length,
			blocks: _.put.length + _.remove.length,
			snapshots: p.put.length + p.remove.length,
			views: m.put.length + m.remove.length,
			commands: 1,
			outbox: 1
		};
	}
	async checkedAssets(t = []) {
		let n = [];
		for (let r of t) {
			let t = r.bytes.slice(), i = r.assetPath ?? Un(r.contentHash, r.mediaType), a = Wn(i, r.mediaType, t);
			if (t.byteLength > 33554432) throw new M("LIMIT_EXCEEDED", "一つの添付は32 MiB以下にしてください。", i);
			if (a !== r.contentHash || await e(t) !== a) throw new M("HASH_MISMATCH", "添付bytesのhashが一致しません。", i);
			n.push({
				contentHash: a,
				mediaType: r.mediaType,
				path: i,
				bytes: t
			});
		}
		return n;
	}
	async writeAssets(e, t, n) {
		for (let t of e) {
			let e = await this.db.assets.get(t.contentHash);
			if (e && !Ai(e.bytes, t.bytes)) throw new M("HASH_MISMATCH", "既存hashの素材bytesが異なります。", t.path);
			await this.db.assets.put(t);
		}
		for (let e of Xn(t)) {
			let t = await this.db.assets.get(e.contentHash);
			if (t && t.bytes.byteLength !== e.byteSize) throw new M("ASSET_INVALID", "添付bytesとメタデータのサイズが一致しません。", e.assetPath);
			if (n && !t) throw new M("ASSET_MISSING", "完全復元に必要な添付bytesがありません。", e.assetPath);
		}
	}
	async saveProject(t, n) {
		let r = performance.now(), i = n.operationId ?? u(), a = r, o = {
			prepare: 0,
			hash: 0,
			read: 0,
			reconcile: 0,
			validate: 0,
			diff: 0,
			database: 0,
			total: 0
		}, s = (e) => {
			let t = performance.now();
			o[e] += t - a, a = t;
		};
		try {
			O(n.signal);
			let a = di(t), c = i, l = (/* @__PURE__ */ new Date()).toISOString();
			if (this.authorAccess && await this.db.syncBases.get(a.projectId) && this.authorAccess.get(a.projectId) !== "owner") throw new R("FORBIDDEN");
			let u = await this.checkedAssets(n.assets);
			s("prepare");
			let d = await this.db.commands.get(c), f = this.editingHistories.get(a.history);
			if (f && (f.projectId !== a.projectId || f.revision !== a.revision)) throw new M("OPERATION_CONFLICT", "履歴の読込元と編集中の作品・版が一致しません。");
			let p = this.cachedProjects.get(a.projectId), h = await this.db.projects.get(a.projectId);
			h && (p?.revision !== h.revision || !Q(this.cachedHistoryIds.get(a.projectId), h.historyIds) || !f && !this.completeHistories.has(a.projectId)) && (f ? await this.getProjectForEditing(a.projectId) : await this.getProject(a.projectId));
			let g = h ? this.cachedProjects.get(a.projectId) : void 0, _ = await this.validationWorlds(), v = n.worldPin ? await dr(a, n.worldPin, _) : {}, y = {
				..._,
				...v
			}, b = er(y);
			if (s("read"), !d && (g && g.revision !== a.revision || !g && a.revision !== "0")) throw new M("REVISION_CONFLICT", "別の編集が先に保存されています。現在版を読み直して変更を比較してください。", a.projectId);
			let x = h?.historyIds ?? [], S = d ? x.slice(0, x.indexOf(c)) : x, w = f?.historyIds ?? a.history.map((e) => e.operationId), T = d ? g?.history.slice(0, g.history.findIndex((e) => e.operationId === c)) ?? [] : g?.history ?? [];
			if (!Q(S, w) || !f && (T.length !== a.history.length || T.some((e, t) => !Q(e, a.history[t])))) throw new M("OPERATION_CONFLICT", "履歴は保存コマンドからのみ追加できます。");
			let E = await e(m({
				draft: d && !d.requestHashVersion ? a : $(a),
				...d && !d.requestHashVersion ? {} : { historyIds: w },
				reason: n.reason,
				assets: (n.assets ?? []).map((e) => ({
					contentHash: e.contentHash,
					mediaType: e.mediaType,
					path: e.assetPath ?? null
				})),
				compensatesOperationId: n.compensatesOperationId ?? null,
				...n.worldPin ? { worldPins: v } : {}
			}));
			if (s("hash"), d) return this.duplicateResult(d, E, a.projectId);
			if (!g && a.history.length) throw new M("OPERATION_CONFLICT", "既存履歴の復元には専用読み込みを使用してください。");
			if (!C.test(c) || n.compensatesOperationId && !C.test(n.compensatesOperationId)) throw new M("VALIDATION_FAILED", "操作IDは安定したUUIDで指定してください。");
			if (typeof n.reason != "string" || !n.reason.trim() || new TextEncoder().encode(n.reason).byteLength > 1048576) throw new M("VALIDATION_FAILED", "変更の理由を1 MiB以内で指定してください。");
			g && wi(g, a);
			let D = {
				...a,
				entities: bi(g?.entities ?? [], a.entities, c, l),
				relations: bi(g?.relations ?? [], a.relations, c, l),
				revision: mi(a.revision)
			};
			if (g) {
				xi(g, D), await Ci(g, D);
				let e = new Map(g.snapshots.map((e) => [e.id, e]));
				D.snapshots = D.snapshots.map((t) => e.get(t.id) ?? t), D = await Tr(g, D), D.entities = bi(g.entities, D.entities, c, l);
			}
			if (new Set(D.snapshots.map((e) => e.id)).size !== D.snapshots.length) throw new M("VALIDATION_FAILED", "公開版IDが重複しています。");
			s("reconcile"), D = _i(D, b, g, this.validationReferences);
			let ee = new Set(g?.snapshots.map((e) => e.id) ?? []), k = D.snapshots.filter((e) => !ee.has(e.id));
			k.length && (gi({
				...D,
				history: []
			}, b), await nr([{
				...D,
				history: [],
				snapshots: k
			}])), tr([{
				...D,
				history: []
			}], y), s("validate");
			let A = g ? $(g) : hi(a), te = $(D), j = await Oi(A, te, !g), N = {
				operationId: c,
				projectId: D.projectId,
				baseRevision: a.revision,
				revision: D.revision,
				targetIds: j.map((e) => e.targetId),
				reason: n.reason,
				createdAt: l,
				before: A,
				after: te,
				...n.compensatesOperationId ? { compensatesOperationId: n.compensatesOperationId } : {}
			};
			li(N), D.history = li(f ? [] : [...g?.history ?? [], N]), await vi(D, b, !f, g ? {
				previous: g,
				references: this.validationReferences
			} : void 0);
			let ne = [...x, c], P = this.contentHeads.get(D.projectId), re = !P || x.length % 64 == 0, { before: F, after: ie, ...I } = N, ae = {
				operationId: c,
				projectId: D.projectId,
				revision: D.revision,
				requestHash: E,
				requestHashVersion: 2,
				delta: {
					metadata: I,
					...re ? { checkpoint: A } : { parentOperationId: P },
					patch: fi(A, te)
				}
			}, oe = {
				entities: 0,
				relations: 0,
				blocks: 0,
				snapshots: 0,
				views: 0,
				commands: 1,
				outbox: 1
			};
			s("diff");
			let se = await this.db.transaction("rw", this.writeTables, async () => {
				if (Xe(n.signal), O(n.signal), this.authorAccess && await this.db.syncBases.get(D.projectId) && this.authorAccess.get(D.projectId) !== "owner") throw new R("FORBIDDEN");
				let e = await this.db.commands.get(c);
				if (e) return this.duplicateResult(e, E, D.projectId);
				let t = await this.db.projects.get(D.projectId);
				if (g ? !t || t.revision !== g.revision : t) throw new M("REVISION_CONFLICT", "保存中に現在版が変わりました。変更を比較して再試行してください。", D.projectId);
				(Object.keys(v).length || k.length) && await this.guardWorldRegistry([D, ...Object.values(v)]);
				for (let [e, t] of Object.entries(v)) {
					let n = await this.db.worlds.get(e), r = n?.project.snapshots.find((t) => t.id === e);
					if (n && !Q(r, t.snapshots[0])) throw new M("IMMUTABLE_SNAPSHOT", "保存中に共通世界の固定版が変わりました。", e);
					await this.writeAssets([], t, !1), n || await this.db.worlds.add({
						id: e,
						project: t
					});
				}
				await this.writeAssets(u, D, !1), oe = await this.writeContent(D, g, c, ne), this.faultInjector?.("after-content"), await this.db.commands.add(ae), this.faultInjector?.("after-history");
				let r = await this.db.syncMetadata.get(D.projectId);
				return await this.db.outbox.add({
					operationId: c,
					projectId: D.projectId,
					accountId: this.accountId,
					baseRevision: r?.serverRevision ?? "0",
					localRevision: D.revision,
					createdAt: l,
					targetIds: N.targetIds,
					changes: j.map(({ before: e, after: t, ...n }) => ({
						...n,
						...e === null ? { before: null } : {},
						...t === null ? { after: null } : {}
					})),
					commandOperationId: c
				}), await this.db.syncMetadata.put({
					projectId: D.projectId,
					serverRevision: r?.serverRevision ?? "0",
					state: "pending"
				}), this.faultInjector?.("after-outbox"), O(n.signal), this.faultInjector?.("before-commit"), {
					project: D,
					operationId: c,
					localSaved: !0,
					pendingSync: !0
				};
			});
			s("database"), o.total = performance.now() - r, cr(n.measurementStartedAt, c, o), se.project === D && this.rememberProject(D, c, ne);
			try {
				this.onSaveMetrics?.({
					operationId: c,
					projectId: D.projectId,
					milliseconds: o,
					written: oe,
					historyRead: g === p ? 0 : g?.history.length ?? 0
				});
			} catch {}
			if (f && n.includeHistory === !0) {
				let e = await this.db.commands.bulkGet(ne), t = new Map(e.filter((e) => !!e).map((e) => [e.operationId, e])), n = /* @__PURE__ */ new Map();
				if (e.some((e) => !e)) throw new M("SAVE_FAILED", "保存した対象版の履歴を読み込めません。");
				let r = [];
				for (let i of e) r.push(await this.materializeCommand(i, t, n));
				return {
					...se,
					project: {
						...ui(se.project),
						history: r
					}
				};
			}
			return {
				...se,
				project: f || n.includeHistory === !1 ? this.editingCopy(se.project, se.project === D ? ne : se.project.history.map((e) => e.operationId), n.immutableView) : ui(se.project)
			};
		} catch (e) {
			let n = A(e);
			throw we(n, {
				accountId: this.accountId,
				operationId: i,
				revision: t.revision
			}), n;
		}
	}
	async duplicateResult(e, t, n) {
		if (e.projectId !== n || e.requestHash !== t) throw new M("OPERATION_CONFLICT", "同じ操作IDが異なる変更に使われています。", e.operationId);
		let r = await this.getProject(n);
		if (!r) throw new M("NOT_FOUND", "作品が見つかりません。", n);
		return {
			project: {
				...Z((r.history.find((t) => t.operationId === e.operationId) ?? await this.materializeCommand(e)).after),
				history: r.history.filter((t) => BigInt(t.revision) <= BigInt(e.revision))
			},
			operationId: e.operationId,
			localSaved: !0,
			pendingSync: !!await this.db.outbox.get(e.operationId)
		};
	}
	async undo(e, t) {
		let n = await this.getProject(e);
		if (!n) throw new M("NOT_FOUND", "作品が見つかりません。", e);
		let r = t ? n.history.find((e) => e.operationId === t) : n.history.at(-1);
		if (!r) throw new M("NOT_FOUND", "取り消せる履歴がありません。");
		let i = Pi(n, r);
		return this.saveProject(i, {
			reason: `取り消し: ${r.reason}`,
			compensatesOperationId: r.operationId
		});
	}
	async previewRestoreEntity(e, t, n, r = "after") {
		let i = await this.getProjectForEditing(e), a = await this.historyCommand(e, t), o = a[r].entities.find((e) => e.id === n);
		if (!i || !a || !o) throw new M("NOT_FOUND", "指定した版の情報が見つかりません。", n);
		let s = i.entities.filter((e) => e.id !== n && N(e).some((e) => e.id === n)).map((e) => e.id);
		return {
			project: i,
			source: Z(o),
			referrers: s,
			warnings: s.length ? [`${s.length}件の参照があります。翻訳・音声・媒体版は内容の変更に応じて確認待ちになります。`] : []
		};
	}
	async restoreEntity(e, t, n, r = "after", i) {
		let a = await this.previewRestoreEntity(e, t, n, r), o = a.project;
		if (i !== void 0 && o.revision !== i) throw new M("REVISION_CONFLICT", "復元の影響確認後に作品が更新されました。選択を保持して再確認してください。");
		let s = o.entities.find((e) => e.id === n);
		return o.entities = o.entities.some((e) => e.id === n) ? o.entities.map((e) => e.id === n ? a.source : e) : [...o.entities, a.source], s && (o.entities = xr(o.entities, s, a.source), o.relations = Sr(o.relations, s, a.source)), this.saveProject(o, {
			reason: `履歴から単体復元: ${a.source.name}`,
			compensatesOperationId: t,
			includeHistory: !0
		});
	}
	async restoreRelation(e, t, n, r = "after", i) {
		let a = await this.getProjectForEditing(e), o = (await this.historyCommand(e, t))?.[r].relations.find((e) => e.id === n);
		if (!a || !o) throw new M("NOT_FOUND", "指定した版の関係が見つかりません。", n);
		if (i !== void 0 && a.revision !== i) throw new M("REVISION_CONFLICT", "復元の影響確認後に作品が更新されました。選択を保持して再確認してください。");
		return a.relations = a.relations.some((e) => e.id === n) ? a.relations.map((e) => e.id === n ? Z(o) : e) : [...a.relations, Z(o)], this.saveProject(a, {
			reason: "履歴から関係を単体復元",
			compensatesOperationId: t,
			includeHistory: !0
		});
	}
	async previewRestoreVersion(t, n, r = "after") {
		let i = await this.getProjectForEditing(t), a = await this.historyCommand(t, n);
		if (!i) throw new M("NOT_FOUND", "復元先の作品が見つかりません。");
		let o = a[r], s = Mi({
			...Z(o),
			revision: i.revision,
			history: i.history
		}, i), c = await Oi($(i), $(s)), l = {
			projectId: t,
			historyOperationId: n,
			side: r,
			baseRevision: i.revision,
			sourceRevision: o.revision,
			changes: c.map((e) => ({
				id: e.targetId,
				fields: e.fields.map((e) => e.field)
			}))
		};
		return {
			...l,
			confirmationHash: await e(m(l))
		};
	}
	async restoreHistoryVersion(t, n) {
		let r = Z(n), i = await this.previewRestoreVersion(t, r.historyOperationId, r.side), { confirmationHash: a, ...o } = r;
		if (await e(m(o)) !== a || t !== r.projectId || i.baseRevision !== r.baseRevision || i.confirmationHash !== r.confirmationHash) throw new M("REVISION_CONFLICT", "作品全体の復元差分が変わりました。対象操作と差分を再確認してください。");
		let s = await this.getProjectForEditing(t), c = await this.historyCommand(t, r.historyOperationId);
		if (!s || s.revision !== r.baseRevision) throw new M("REVISION_CONFLICT", "復元の確定前に作品が更新されました。");
		let l = Mi({
			...Z(c[r.side]),
			revision: s.revision,
			history: s.history
		}, s);
		return this.saveProject(l, {
			reason: `作品全体を操作 ${r.historyOperationId} の${r.side === "before" ? "変更前" : "変更後"}（版 ${r.sourceRevision}）へ復元`,
			compensatesOperationId: r.historyOperationId,
			includeHistory: !0
		});
	}
	async restoreRevision(e, t) {
		let [n, r] = await Promise.all([this.getProject(e), this.getProjectAtRevision(e, t)]);
		if (!n || !r) throw new M("NOT_FOUND", "復元する版が見つかりません。");
		let i = Mi({
			...r,
			revision: n.revision,
			history: n.history
		}, n);
		return this.saveProject(i, { reason: `作品全体をrevision ${t}から復元` });
	}
	async putAsset(e, t, n = "application/octet-stream") {
		let r = await this.checkedAssets([{
			contentHash: e,
			bytes: t,
			mediaType: n
		}]);
		try {
			await this.db.transaction("rw", this.db.assets, async () => {
				let t = await this.db.assets.get(e);
				if (t && !Ai(t.bytes, r[0].bytes)) throw new M("HASH_MISMATCH", "既存hashの素材bytesが異なります。");
				await this.db.assets.put(r[0]);
			});
		} catch (e) {
			throw A(e);
		}
	}
	async getAsset(e) {
		return (await this.db.assets.get(e))?.bytes.slice();
	}
	async availableAssetHashes() {
		return new Set(await this.db.assets.toCollection().primaryKeys());
	}
	async materializeOutbox(e, t) {
		e = [...e].sort((e, t) => BigInt(e.localRevision) < BigInt(t.localRevision) ? -1 : BigInt(e.localRevision) > BigInt(t.localRevision) ? 1 : e.createdAt.localeCompare(t.createdAt));
		let n = /* @__PURE__ */ new Map(), r = [];
		for (let i of e) {
			let e = i.commandOperationId ? t.get(i.commandOperationId) : void 0, a = i.command ?? (e ? await this.materializeCommand(e, t, n, /* @__PURE__ */ new Set(), !1) : void 0);
			if (!a || a.projectId !== i.projectId) throw new M("SAVE_FAILED", "送信待ちに必要な履歴が不足しています。", i.operationId);
			let o = new Map([
				...a.before.entities,
				...a.before.relations,
				Di(a.before)
			].map((e) => [e.id, e])), s = new Map([
				...a.after.entities,
				...a.after.relations,
				Di(a.after)
			].map((e) => [e.id, e])), { commandOperationId: c, ...l } = i;
			r.push({
				...l,
				command: a,
				changes: i.changes.map((e) => ({
					...e,
					before: Object.hasOwn(e, "before") ? e.before : o.get(e.targetId) ?? null,
					after: Object.hasOwn(e, "after") ? e.after : s.get(e.targetId) ?? null
				}))
			});
		}
		return r;
	}
	async listOutbox(e) {
		let t = await this.db.transaction("r", ["outbox", "commands"], async () => ({
			rows: await this.db.outbox.where("projectId").equals(e).toArray(),
			commands: await this.db.commands.where("projectId").equals(e).toArray()
		}));
		return this.materializeOutbox(t.rows, new Map(t.commands.map((e) => [e.operationId, e])));
	}
	async getSaveState(e) {
		return this.db.transaction("r", this.writeTables, async () => {
			let [t, n, r, i, a] = await Promise.all([
				this.readProject(e, !1),
				this.db.syncMetadata.get(e),
				this.db.outbox.where("projectId").equals(e).count(),
				this.db.recoveredPending.where("projectId").equals(e).count(),
				this.db.syncAssetAcks.where("projectId").equals(e).toArray()
			]), o = t ? Qn(t.project, await this.validationWorlds()).filter((e) => !a.some((t) => t.contentHash === e.contentHash && t.byteSize === e.byteSize && t.mediaType === e.mediaType)).length : 0;
			return {
				localSaved: !!t,
				pendingCount: r,
				recoveredPendingCount: i,
				pendingAssetCount: o,
				serverRevision: n?.serverRevision ?? "0",
				syncState: n?.state === "conflict" ? "conflict" : r || o ? "pending" : n?.state ?? "pending"
			};
		});
	}
	async getAssetSyncAck(e, t) {
		return Z(await this.db.syncAssetAcks.get(`${e}:${t}`));
	}
	async confirmAssetUpload(t, n) {
		this.syncScope(t);
		let r = Z(n), i = await this.getAsset(r.contentHash);
		if (!i || i.byteLength !== r.bytes || await e(i) !== r.contentHash) throw new R("PROTOCOL_INVALID");
		let a = {
			key: `${t}:${r.contentHash}`,
			projectId: t,
			contentHash: r.contentHash,
			byteSize: r.bytes,
			mediaType: r.mediaType
		};
		await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.syncAssetAcks.get(a.key);
			if (e && !F(e, a)) throw new R("PROTOCOL_INVALID");
			await this.db.syncAssetAcks.put(a), this.faultInjector?.("before-commit");
		});
	}
	async listRetainedSyncRecovery(e) {
		return Z(await this.db.retainedSyncRecovery.where("projectId").equals(e).toArray());
	}
	async listAuthorToolDrafts() {
		return Z(await this.db.authorToolDrafts.toArray());
	}
	async saveSharedSnapshot(e) {
		let { validateSharedSnapshot: t } = await import("./publicShare-UUrjY7Zg.js"), n = await t(Z(e)), r = await this.db.sharedSnapshots.get(n.id);
		if (r && r.contentHash !== n.contentHash) throw new R("PROTOCOL_INVALID");
		await this.db.sharedSnapshots.put(n);
	}
	async listSharedSnapshots() {
		return Z(await this.db.sharedSnapshots.toArray());
	}
	async discardSharedSnapshot(e) {
		await this.db.sharedSnapshots.delete(e);
	}
	async listRecoveredPending(e) {
		return Z((await this.db.recoveredPending.where("projectId").equals(e).toArray()).sort((e, t) => e.sequence - t.sequence));
	}
	async commitAck(e, t) {
		if (t.projectId !== e || !/^(?:0|[1-9]\d*)$/.test(t.serverRevision) || !["applied", "conflict"].includes(t.status)) throw new M("VALIDATION_FAILED", "同期ackの作品・revision・結果が不正です。");
		try {
			await this.db.transaction("rw", [
				"outbox",
				"acks",
				"syncMetadata"
			], async () => {
				let n = await this.db.acks.get(t.operationId);
				if (n) {
					if (!o(n, t)) throw new M("OPERATION_CONFLICT", "同じ操作に異なるackが届きました。");
					return;
				}
				let r = await this.db.outbox.get(t.operationId), i = await this.db.syncMetadata.get(e);
				if (!r || r.projectId !== e || r.accountId !== this.accountId) throw new M("NOT_FOUND", "この領域の送信待ち操作が見つかりません。");
				if (i && BigInt(t.serverRevision) < BigInt(i.serverRevision)) throw new M("REVISION_CONFLICT", "古いサーバーrevisionのackです。");
				await this.db.acks.add(Z(t)), t.status === "applied" && await this.db.outbox.delete(t.operationId);
				let a = await this.db.outbox.where("projectId").equals(e).count();
				await this.db.syncMetadata.put({
					projectId: e,
					serverRevision: t.serverRevision,
					state: t.status === "conflict" ? "conflict" : a ? "pending" : "synced"
				});
			});
		} catch (e) {
			throw A(e);
		}
	}
	syncScope(e) {
		if (!this.accountId || this.accountId === "guest") throw new R("AUTH_REQUIRED");
		return {
			accountId: this.accountId,
			projectId: e
		};
	}
	async bindConfirmedProject(e) {
		let t = Z(e), n = this.syncScope(t.projectId);
		if (!/^(0|[1-9]\d*)$/.test(t.serverRevision) || !t.documents.length || t.documents.length > 100001) throw new R("PROTOCOL_INVALID");
		let r = /* @__PURE__ */ new Set();
		for (let e of t.documents) {
			if (P(e, n, e.id), r.has(e.id) || BigInt(e.revision) > BigInt(t.serverRevision)) throw new R("PROTOCOL_INVALID");
			r.add(e.id);
		}
		if (await ie(t.documents) !== t.contentHash) throw new R("PROTOCOL_INVALID");
		let i = await this.getProject(t.projectId);
		if (!i || i.revision !== t.localRevision) throw new R("REVISION_CHANGED");
		let a = q(i, t.documents, (/* @__PURE__ */ new Date()).toISOString()), o = await this.validationWorlds();
		if (gi(a, er(o)), await nr([a]), await vi(a, er(o)), !F(At(i, t.serverRevision).map(({ revision: e, ...t }) => t), t.documents.map(({ revision: e, ...t }) => t))) throw new R("REVISION_CHANGED");
		await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.projects.get(t.projectId);
			if (!e || e.revision !== t.localRevision || await this.db.preparedSync.where("projectId").equals(t.projectId).count() || await this.db.syncConflicts.where("projectId").equals(t.projectId).count()) throw new R("REVISION_CHANGED");
			for (let e of t.outboxIds) {
				let n = await this.db.outbox.get(e);
				if (!n || n.projectId !== t.projectId || n.accountId !== this.accountId || BigInt(n.localRevision) > BigInt(t.localRevision)) throw new R("PROTOCOL_INVALID");
			}
			await this.db.syncBases.put({
				projectId: t.projectId,
				serverRevision: t.serverRevision,
				documents: t.documents,
				contentHash: t.contentHash
			}), await this.db.outbox.bulkDelete(t.outboxIds), await this.db.syncMetadata.put({
				projectId: t.projectId,
				serverRevision: t.serverRevision,
				state: await this.db.outbox.where("projectId").equals(t.projectId).count() ? "pending" : "synced"
			}), this.faultInjector?.("before-commit");
		});
	}
	async getConfirmedSyncBase(e) {
		return this.syncScope(e), Z(await this.db.syncBases.get(e));
	}
	async bindBootstrapBase(e, t) {
		let n = Z(e), r = Z(t), i = this.syncScope(n.projectId), a = At(n, r.serverRevision);
		if (!F(a, r.documents) || await ie(a) !== r.contentHash) throw new R("PROTOCOL_INVALID");
		let o = await this.validationWorlds();
		gi(n, er(o)), await nr([n]), await vi(n, er(o)), await this.db.transaction("rw", this.writeTables, async () => {
			let e = await this.db.projects.get(i.projectId);
			if (!e || BigInt(e.revision) < BigInt(n.revision) || await this.db.syncBases.get(i.projectId) || await this.db.preparedSync.where("projectId").equals(i.projectId).count()) throw new R("REVISION_CHANGED");
			for (let e of r.outboxIds) {
				let t = await this.db.outbox.get(e);
				if (!t || t.accountId !== this.accountId || t.projectId !== i.projectId || BigInt(t.localRevision) > BigInt(n.revision)) throw new R("PROTOCOL_INVALID");
			}
			await this.db.syncBases.put({
				projectId: i.projectId,
				serverRevision: r.serverRevision,
				documents: a,
				contentHash: r.contentHash
			}), await this.db.outbox.bulkDelete(r.outboxIds), await this.db.syncMetadata.put({
				projectId: i.projectId,
				serverRevision: r.serverRevision,
				state: await this.db.outbox.where("projectId").equals(i.projectId).count() ? "pending" : "synced"
			}), this.faultInjector?.("before-commit");
		});
	}
	async applyReceivedImage(e, t) {
		let n = Z(t), r = this.syncScope(e), [i, a, o, s] = await Promise.all([
			this.db.syncBases.get(e),
			this.getProject(e),
			this.listPreparedOperations(e),
			this.listPreparedConflicts(e)
		]);
		if (!i || !a) throw new R("BASE_UNAVAILABLE");
		if (o.length || s.length) throw new R("REVISION_CHANGED");
		if (BigInt(n.serverRevision) < BigInt(i.serverRevision) || await ie(n.documents) !== n.contentHash) throw new R("PROTOCOL_INVALID");
		let c = new Map(i.documents.map((e) => [e.id, e])), l = n.documents.filter((e) => !jt(c.get(e.id), e)).map((e) => ({
			base: c.get(e.id) ?? null,
			local: c.get(e.id) ?? e
		}));
		if (!l.length) {
			let t = i.documents.find((t) => t.id === e);
			if (!t) throw new R("PROTOCOL_INVALID");
			l.push({
				base: t,
				local: t
			});
		}
		let d = await re({
			scope: r,
			baseRevision: i.serverRevision,
			operationId: u(),
			targets: l,
			reason: "認証した接続先の確定版を取得して端末の後発編集を保持"
		}), f = {
			schemaVersion: 1,
			operationId: d.operationId,
			scope: r,
			operationHash: await ie(d),
			status: "applied",
			serverRevision: n.serverRevision,
			documents: l.map((e) => n.documents.find((t) => t.id === e.local.id)),
			confirmedDocuments: n.documents,
			conflicts: []
		};
		await Ot(d, f), await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.projects.get(e), n = await this.db.syncBases.get(e);
			if (t?.revision !== a.revision || !F(n, i) || await this.db.preparedSync.where("projectId").equals(e).count() || await this.db.syncConflicts.where("projectId").equals(e).count()) throw new R("REVISION_CHANGED");
			await this.db.preparedSync.add({
				operationId: d.operationId,
				projectId: e,
				operation: d,
				localRevision: a.revision,
				localDocuments: i.documents,
				outboxIds: [],
				origin: "received_image",
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			});
		}), await this.commitPreparedAck(e, f, n.worlds);
	}
	async prepareSavedOperations(e, t = "端末の保存待ちを確定共通元から準備") {
		let n = this.syncScope(e), r = await this.db.transaction("r", this.writeTables, async () => ({
			base: await this.db.syncBases.get(e),
			current: await this.readProject(e, !1),
			pending: await this.db.preparedSync.where("projectId").equals(e).toArray(),
			conflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray(),
			outbox: await this.db.outbox.where("projectId").equals(e).toArray()
		}));
		if (r.pending.length) return Z(r.pending[0].operation);
		if (r.conflicts.length) throw new R("REVISION_CHANGED");
		if (!r.base || !r.current) throw new R("BASE_UNAVAILABLE");
		let i = await Nt(n, r.base, r.current.project, r.outbox.map((e) => e.operationId), t);
		return await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.projects.get(e), n = await this.db.syncBases.get(e);
			if (t?.revision !== r.current.project.revision || n?.contentHash !== r.base.contentHash || n?.serverRevision !== r.base.serverRevision || await this.db.preparedSync.where("projectId").equals(e).count() || await this.db.syncConflicts.where("projectId").equals(e).count()) throw new R("REVISION_CHANGED");
			i ? await this.db.preparedSync.add(i) : (await this.db.outbox.bulkDelete(r.outbox.map((e) => e.operationId)), await this.db.syncMetadata.put({
				projectId: e,
				serverRevision: r.base.serverRevision,
				state: "synced"
			})), this.faultInjector?.("before-commit");
		}), i ? Z(i.operation) : null;
	}
	async listPreparedOperations(e) {
		return this.syncScope(e), Z((await this.db.preparedSync.where("projectId").equals(e).toArray()).map((e) => e.operation));
	}
	async listPreparedConflicts(e) {
		return this.syncScope(e), Z((await this.db.syncConflicts.where("projectId").equals(e).toArray()).map((e) => ({
			operationId: e.operationId,
			conflicts: e.conflicts
		})));
	}
	async listSyncConflictAlternatives(e) {
		return this.syncScope(e), Z(await this.db.syncConflicts.where("projectId").equals(e).toArray());
	}
	async listSyncAckEvidence(e) {
		return this.syncScope(e), Z(await this.db.syncAckEvidence.where("projectId").equals(e).toArray());
	}
	async commitPreparedAck(e, t, n = {}) {
		let r = Z(n);
		await this.guardWorldRegistry(Object.values(r)), await nr(Object.values(r));
		let i = this.syncScope(e), a = Z(t);
		if (!F(i, a.scope)) throw new R("PROTOCOL_INVALID");
		let s = await this.db.transaction("r", this.writeTables, async () => ({
			prepared: await this.db.preparedSync.get(a.operationId),
			previousAck: await this.db.syncAckEvidence.get(a.operationId),
			base: await this.db.syncBases.get(e),
			current: await this.readProject(e),
			conflicts: await this.db.syncConflicts.where("projectId").equals(e).toArray()
		}));
		if (s.previousAck) {
			if (!F(s.previousAck.ack, a)) throw new R("OPERATION_REUSED");
			return;
		}
		if (!s.prepared || s.prepared.projectId !== e || !s.base || !s.current || s.base.serverRevision !== s.prepared.operation.baseRevision) throw new R("BASE_UNAVAILABLE");
		await Ot(s.prepared.operation, a);
		let c = s.current.project, l = (/* @__PURE__ */ new Date()).toISOString(), d = c, f, p, m;
		if (a.status === "applied") {
			let t = Pt(s.prepared, s.base, a, c);
			p = {
				projectId: e,
				serverRevision: a.serverRevision,
				documents: t.confirmed,
				contentHash: await ie(t.confirmed)
			};
			let n = q(c, t.documents, l);
			if (xi(c, n), await Ci(c, n), n = await Tr(c, n), n = Gr(c, n), n.entities = bi(c.entities, n.entities, a.operationId, l), n.relations = bi(c.relations, n.relations, a.operationId, l), !Q($(n), $(c))) {
				n.revision = mi(c.revision);
				let t = $(c), r = $(n), i = await Oi(t, r), o = u(), s = {
					operationId: o,
					projectId: e,
					baseRevision: c.revision,
					revision: n.revision,
					targetIds: i.map((e) => e.targetId),
					reason: `同期ackを端末確定: ${a.operationId}`,
					createdAt: l,
					before: t,
					after: r
				};
				n.history = [...c.history, s], f = {
					operationId: o,
					projectId: e,
					revision: n.revision,
					record: s
				}, d = n;
			}
			let i = await this.validationWorlds(r);
			gi(d, er(i)), tr([d], i), await nr([d]), await vi(d, er(i)), t.conflicts.length && (m = {
				operationId: a.operationId,
				projectId: e,
				prepared: s.prepared,
				ack: a,
				conflicts: t.conflicts,
				createdAt: l
			});
		}
		await this.db.transaction("rw", this.writeTables, async () => {
			let t = await this.db.syncAckEvidence.get(a.operationId);
			if (t) {
				if (!F(t.ack, a)) throw new R("OPERATION_REUSED");
				return;
			}
			let n = await this.db.projects.get(e), i = await this.db.syncBases.get(e), u = await this.db.preparedSync.get(a.operationId);
			if (n?.revision !== c.revision || i?.contentHash !== s.base.contentHash || i?.serverRevision !== s.base.serverRevision || !F(u, s.prepared)) throw new R("REVISION_CHANGED");
			if (a.status === "conflict") await this.db.syncConflicts.put({
				operationId: a.operationId,
				projectId: e,
				prepared: s.prepared,
				ack: a,
				conflicts: a.conflicts,
				createdAt: l
			});
			else {
				for (let [e, t] of Object.entries(r)) {
					let n = await this.db.worlds.get(e);
					if (n && !o(n.project, t)) throw new M("IMMUTABLE_SNAPSHOT", "固定世界の取得内容が保存済み版と異なります。");
					await this.db.worlds.put({
						id: e,
						project: t
					});
				}
				if (f && (await this.writeContent(d, c, f.operationId), this.faultInjector?.("after-content"), await this.db.commands.add(f), this.faultInjector?.("after-history")), await this.db.syncBases.put(p), await this.db.outbox.bulkDelete(s.prepared.outboxIds), s.prepared.operation.resolvesOperationId) {
					let e = await this.db.syncConflicts.get(s.prepared.operation.resolvesOperationId);
					if (!e || [...e.prepared.operation.targets.map((e) => e.targetId), ...e.conflicts.map((e) => e.targetId)].some((e) => !s.prepared.operation.targets.some((t) => t.targetId === e))) throw new R("PROTOCOL_INVALID");
					await this.db.syncConflicts.delete(e.operationId);
				}
				m && await this.db.syncConflicts.put(m);
			}
			await this.db.syncAckEvidence.add({
				operationId: a.operationId,
				projectId: e,
				operation: s.prepared.operation,
				ack: a,
				origin: s.prepared.origin ?? "prepared_operation",
				createdAt: l
			}), await this.db.preparedSync.delete(a.operationId), await this.db.syncMetadata.put({
				projectId: e,
				serverRevision: p?.serverRevision ?? s.base.serverRevision,
				state: await this.db.syncConflicts.where("projectId").equals(e).count() ? "conflict" : await this.db.outbox.where("projectId").equals(e).count() ? "pending" : "synced"
			}), this.faultInjector?.("after-outbox"), this.faultInjector?.("before-commit");
		}), this.invalidateProjectCache(e);
	}
	async previewSyncResolution(e, t, n) {
		let r = Z(n), i = this.syncScope(e), [a, o, s] = await Promise.all([
			this.db.syncConflicts.get(t),
			this.db.syncBases.get(e),
			this.getProject(e)
		]);
		if (!a || a.projectId !== e || !o || !s) throw new R("BASE_UNAVAILABLE");
		let c = Z(a.ack.confirmedDocuments);
		if (!c) throw new R("PROTOCOL_INVALID");
		for (let e of a.ack.documents) if (e) {
			let t = c.findIndex((t) => t.id === e.id);
			t >= 0 ? c[t] = Z(e) : c.push(Z(e));
		}
		let l = Ft(a, r, c, s), d = await re({
			scope: i,
			baseRevision: a.ack.serverRevision,
			operationId: u(),
			targets: l,
			reason: "共通元・二案と参照への影響を確認して競合解決",
			resolvesOperationId: t
		}), f = new Map(c.map((e) => [e.id, e]));
		for (let e of l) f.set(e.local.id, e.local);
		let p = q(s, [...f.values()], (/* @__PURE__ */ new Date()).toISOString()), m = await this.validationWorlds();
		gi(p, er(m)), await nr([p]), await vi(p, er(m));
		let h = {
			projectId: e,
			operationId: t,
			localRevision: s.revision,
			serverRevision: a.ack.serverRevision,
			baseHash: o.contentHash,
			conflictHash: await ie(a),
			choices: r,
			operation: d,
			candidate: p
		};
		return {
			...h,
			confirmationHash: await ie(h)
		};
	}
	async confirmSyncResolution(e) {
		let t = Z(e), { confirmationHash: n, ...r } = t;
		if (this.syncScope(t.projectId), await ie(r) !== n) throw new R("PROTOCOL_INVALID");
		let i = await this.previewSyncResolution(t.projectId, t.operationId, t.choices);
		if (i.localRevision !== t.localRevision || i.baseHash !== t.baseHash || i.conflictHash !== t.conflictHash || i.serverRevision !== t.serverRevision) throw new R("REVISION_CHANGED");
		if (!F({
			...i.operation,
			operationId: t.operation.operationId
		}, t.operation) || !F(i.candidate, t.candidate)) throw new R("PROTOCOL_INVALID");
		let [a, o, s] = await Promise.all([
			this.getProject(t.projectId),
			this.db.syncBases.get(t.projectId),
			this.db.syncConflicts.get(t.operationId)
		]);
		if (!a || !o || !s) throw new R("BASE_UNAVAILABLE");
		let c = Z(s.ack.confirmedDocuments);
		if (!c) throw new R("PROTOCOL_INVALID");
		let l = {
			projectId: t.projectId,
			serverRevision: t.serverRevision,
			documents: c,
			contentHash: await ie(c)
		}, d = (/* @__PURE__ */ new Date()).toISOString(), f = u(), p = {
			...t.candidate,
			revision: mi(a.revision)
		};
		xi(a, p), await Ci(a, p), p = await Tr(a, p), p = Gr(a, p), p.entities = bi(a.entities, p.entities, f, d), p.relations = bi(a.relations, p.relations, f, d);
		let m = await this.validationWorlds();
		gi(p, er(m)), await nr([p]), await vi(p, er(m));
		let h = await Oi($(a), $(p)), g = {
			operationId: f,
			projectId: t.projectId,
			baseRevision: a.revision,
			revision: p.revision,
			targetIds: h.map((e) => e.targetId),
			reason: `競合の共通元・二案から明示選択: ${t.operationId}`,
			createdAt: d,
			before: $(a),
			after: $(p)
		};
		return p.history = [...a.history, g], await this.db.transaction("rw", this.writeTables, async () => {
			let [e, n, r] = await Promise.all([
				this.db.projects.get(t.projectId),
				this.db.syncBases.get(t.projectId),
				this.db.syncConflicts.get(t.operationId)
			]);
			if (e?.revision !== t.localRevision || !F(n, o) || !F(r, s) || await this.db.preparedSync.where("projectId").equals(t.projectId).count()) throw new R("REVISION_CHANGED");
			await this.writeContent(p, a, f), await this.db.commands.add({
				operationId: f,
				projectId: t.projectId,
				revision: p.revision,
				record: g
			}), await this.db.outbox.add({
				operationId: f,
				projectId: t.projectId,
				accountId: this.accountId,
				baseRevision: t.serverRevision,
				localRevision: p.revision,
				targetIds: g.targetIds,
				changes: h,
				command: g,
				createdAt: d
			}), await this.db.syncBases.put(l);
			let i = (await this.db.outbox.where("projectId").equals(t.projectId).toArray()).map((e) => e.operationId);
			await this.db.preparedSync.add({
				operationId: t.operation.operationId,
				projectId: t.projectId,
				operation: t.operation,
				localRevision: p.revision,
				localDocuments: At(p, t.serverRevision),
				outboxIds: i,
				createdAt: d
			}), this.faultInjector?.("before-commit");
		}), this.invalidateProjectCache(t.projectId), Z(t.operation);
	}
	async getViewState(e, t, n, r) {
		let i = await this.db.viewStates.get(k([
			e,
			t,
			n,
			r
		]));
		if (!i) return;
		let { key: a, projectId: o, ...s } = i;
		return s;
	}
	async saveViewState(e, t) {
		await this.db.viewStates.put({
			...Z(t),
			projectId: e,
			key: k([
				e,
				t.userId,
				t.deviceClass,
				t.viewId
			])
		});
	}
	async createRestorePoint(e, t) {
		return this.db.transaction("rw", this.writeTables, async () => {
			let n = (await this.readProject(e))?.project;
			if (!n) throw new M("NOT_FOUND", "復元点を作る作品が見つかりません。");
			await De.waitFor(this.writeAssets([], n, !0));
			let r = {
				id: u(),
				projectId: e,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				reason: t,
				project: n,
				assetHashes: Xn(n).map((e) => e.contentHash)
			};
			return await this.db.restorePoints.add(r), r;
		});
	}
	async listRestorePoints(e) {
		return this.db.restorePoints.where("projectId").equals(e).reverse().toArray();
	}
	async restorePointPage(e, t = 0, n = 30) {
		n = Math.max(1, Math.min(60, Number.isSafeInteger(n) ? n : 30));
		let r = await this.db.restorePoints.where("projectId").equals(e).count(), i = Math.max(0, Math.ceil(r / n) - 1);
		return t = Math.max(0, Math.min(i, Number.isSafeInteger(t) ? t : 0)), {
			entries: (await this.db.restorePoints.where("projectId").equals(e).offset(t * n).limit(n).toArray()).map(({ id: e, createdAt: t, reason: n, project: r, assetHashes: i }) => ({
				id: e,
				createdAt: t,
				reason: n,
				revision: r.revision,
				assetCount: i.length
			})),
			total: r,
			page: t,
			maximum: i,
			size: n
		};
	}
	async previewRestorePoint(t, n) {
		let [r, i] = await Promise.all([this.db.restorePoints.get(n), this.getProjectForEditing(t)]);
		if (!r || r.projectId !== t || !i) throw new M("NOT_FOUND", "この作品の復元点が見つかりません。");
		let a = Mi({
			...Z(r.project),
			revision: i.revision,
			history: i.history
		}, i), o = await Oi($(i), $(a)), s = {
			projectId: t,
			restorePointId: n,
			baseRevision: i.revision,
			sourceRevision: r.project.revision,
			pointHash: await e(m(r.project)),
			changes: o.map((e) => ({
				id: e.targetId,
				fields: e.fields.map((e) => e.field)
			}))
		};
		return {
			...s,
			confirmationHash: await e(m(s))
		};
	}
	async restorePoint(t, n, r) {
		if (r) {
			let { confirmationHash: i, ...a } = Z(r), o = await this.previewRestorePoint(t, n);
			if (a.projectId !== t || a.restorePointId !== n || await e(m(a)) !== i || o.confirmationHash !== i) throw new M("REVISION_CONFLICT", "復元点の影響確認後に作品または差分が更新されました。選択を保持して再確認してください。");
		}
		let [i, a] = await Promise.all([this.db.restorePoints.get(n), this.getProject(t)]);
		if (!i || i.projectId !== t || !a) throw new M("NOT_FOUND", "この作品の復元点が見つかりません。");
		if (r && a.revision !== r.baseRevision) throw new M("REVISION_CONFLICT", "復元点の確定前に作品が更新されました。");
		let o = Mi({
			...Z(i.project),
			revision: a.revision,
			history: a.history
		}, a);
		return this.saveProject(o, { reason: `復元点から作品全体を復元: ${i.reason}` });
	}
	async migrateProject(e, t) {
		let n = await this.createRestorePoint(e, "形式移行前の復元点"), r = await this.validationWorlds(), i = gi(await t(Z(n.project)), er(r));
		if (i.projectId !== e) throw new M("VALIDATION_FAILED", "移行で作品IDを変更できません。");
		return i.revision = n.project.revision, i.history = n.project.history, this.saveProject(i, { reason: "検証済みの形式移行" });
	}
	async exportProject(t, n = {}) {
		O(n.signal);
		let r = await this.db.transaction("r", this.writeTables, async () => ({
			current: await this.readProject(t, !1),
			commands: await this.db.commands.where("projectId").equals(t).toArray(),
			rows: await this.db.outbox.where("projectId").equals(t).toArray(),
			retained: await this.listRecoveredPending(t),
			metadata: await this.db.syncMetadata.get(t),
			syncBase: await this.db.syncBases.get(t),
			syncPrepared: await this.db.preparedSync.where("projectId").equals(t).toArray(),
			syncConflicts: await this.db.syncConflicts.where("projectId").equals(t).toArray(),
			syncAcks: await this.db.syncAckEvidence.where("projectId").equals(t).toArray(),
			syncAssetAcks: await this.db.syncAssetAcks.where("projectId").equals(t).toArray(),
			syncRetained: await this.db.retainedSyncRecovery.where("projectId").equals(t).toArray(),
			registry: await this.validationWorlds()
		}));
		if (O(n.signal), !r.current) throw new M("NOT_FOUND", "書き出す作品が見つかりません。");
		let i = new Map(r.commands.map((e) => [e.operationId, e])), a = /* @__PURE__ */ new Map(), o = [];
		for (let e of r.current.historyIds) {
			O(n.signal);
			let t = i.get(e);
			if (!t) throw new M("SAVE_FAILED", "完全保存に必要な履歴が不足しています。", e);
			o.push(await this.materializeCommand(t, i, a, /* @__PURE__ */ new Set(), !1));
		}
		let s = {
			...r.current.project,
			history: o
		}, c = await this.materializeOutbox(r.rows, i), l = n.snapshotId ? s.snapshots.find((e) => e.id === n.snapshotId) : void 0;
		if (n.snapshotId && !l) throw new M("NOT_FOUND", "書き出す固定版が見つかりません。");
		let u = l ? {
			...Z(l.content),
			snapshots: s.snapshots,
			history: s.history.filter((e) => BigInt(e.revision) <= BigInt(l.content.revision))
		} : s, d = n.snapshotId ? [] : c, f = n.snapshotId ? [] : r.retained, p = new Map(f.map((e) => [e.operation.operationId, e.operation]));
		for (let r of d) {
			O(n.signal);
			let i = await e(m(r.command)), a = p.get(r.operationId);
			if (a && a.commandHash !== i) throw new M("OPERATION_CONFLICT", "復元した送信待ちと現在の送信待ちが同じIDで異なります。");
			p.set(r.operationId, {
				operationId: r.operationId,
				command: r.command,
				commandHash: i,
				origin: {
					projectId: t,
					operationId: r.operationId,
					serverRevision: r.baseRevision
				}
			}), n.onProgress?.({
				stage: "hashes",
				completed: p.size,
				total: d.length
			});
		}
		let h = p.size ? {
			version: 1,
			projectId: t,
			sourceRevision: u.revision,
			serverRevision: r.metadata?.serverRevision ?? "0",
			pending: [...p.values()]
		} : void 0, g = n.snapshotId ? [] : r.syncRetained.map((e) => e.evidence);
		if (!n.snapshotId && (r.syncBase || r.syncPrepared.length || r.syncConflicts.length || r.syncAcks.length)) {
			let e = {
				format: "scenario-sync-recovery",
				version: 1,
				state: "needs_reconnect",
				origin: {
					...u,
					history: []
				},
				...r.syncBase ? { base: r.syncBase } : {},
				prepared: r.syncPrepared,
				conflicts: r.syncConflicts,
				acknowledgements: r.syncAcks,
				assetAcknowledgements: r.syncAssetAcks
			}, t = {
				...e,
				contentHash: await ie(e)
			};
			g.some((e) => e.contentHash === t.contentHash) || g.push(t);
		}
		let _ = {}, v = [
			u,
			...In(h),
			...It(g)
		];
		for (; v.length;) {
			let e = [];
			for (let t of $n(v, r.registry)) {
				if (_[t.immutableSnapshotId]) continue;
				let n = r.registry[t.immutableSnapshotId];
				n && (_[t.immutableSnapshotId] = n, e.push(n));
			}
			v = e;
		}
		return ur(u, {
			...n,
			...h ? { recovery: h } : {},
			worlds: _,
			syncRecovery: g,
			loadAsset: (e) => this.getAsset(e)
		});
	}
	async previewImport(t, n) {
		let r = Z(t), i = {
			...n,
			idMap: n.idMap ? Z(n.idMap) : void 0,
			resolutions: n.resolutions ? Z(n.resolutions) : void 0
		}, a = r.project, o = i.targetProjectId ?? a.projectId, s = await this.getProject(o), c = s ? (await this.listOutbox(o)).length : 0;
		if (i.mode === "new") return {
			conflicts: s ? [{
				id: o,
				kind: "project",
				existing: s,
				incoming: a
			}] : [],
			pendingChanges: c,
			target: s,
			additions: a.entities.length + a.relations.length
		};
		if (i.mode === "clone") return {
			conflicts: [],
			pendingChanges: 0,
			additions: a.entities.length + a.relations.length
		};
		if (!s) throw new M("NOT_FOUND", "置換・統合する既存作品が見つかりません。", o);
		if (i.mode === "mapped_merge") {
			if (!i.idMap) throw new M("IMPORT_CONFLICT", "別作品の統合には全IDの明示対応表が必要です。");
			let t = await ai({
				...r,
				project: Ln(r.project, r.recovery)
			}, s, {
				idMap: i.idMap,
				resolutions: i.resolutions,
				knownWorlds: await this.validationWorlds(r.worlds),
				loadAsset: (e) => this.getAsset(e),
				signal: i.signal
			}), n = r.recovery ? await ji(r.recovery, t.mappedProject, t.idMap, i.signal) : void 0, a = new Set(r.project.history.map((e) => t.idMap[e.operationId]));
			t.mappedProject.history = t.mappedProject.history.filter((e) => a.has(e.operationId));
			let l = await e(m({
				sourceContentHash: t.sourceContentHash,
				manifest: r.manifest,
				targetId: o,
				targetRevision: s.revision,
				idMap: t.idMap,
				resolutions: i.resolutions ?? {},
				changes: t.changes,
				assets: t.assets
			}));
			return {
				conflicts: t.conflicts,
				pendingChanges: c,
				target: s,
				additions: t.changes.filter((e) => e.action === "add").length,
				mappedPlan: t,
				mappedRecovery: n,
				confirmationHash: l
			};
		}
		if (o !== a.projectId) throw new M("IMPORT_CONFLICT", "置換・統合は同じprojectIdが必要です。別の作品には複製して追加してください。", o);
		let l = Ii(s, a), u = new Set([...s.entities, ...s.relations].map((e) => e.id));
		return {
			conflicts: l,
			pendingChanges: c,
			target: s,
			additions: [...a.entities, ...a.relations].filter((e) => !u.has(e.id)).length
		};
	}
	async saveImportDraft(t) {
		if (!t.key || t.bytes && t.bytes.byteLength > 67108864) throw new M("LIMIT_EXCEEDED", "復元入力の一時保存上限を超えています。");
		let n = Z(t);
		if (n.bytes && await e(n.bytes) !== n.sourceHash) throw new M("HASH_MISMATCH", "復元入力の元ファイルが変わっています。");
		try {
			await this.db.transaction("rw", this.db.importDrafts, async () => {
				let e = await this.db.importDrafts.get(n.key);
				!n.bytes && e && e.sourceHash === n.sourceHash && (n.bytes = e.bytes), await this.db.importDrafts.put(n);
			});
		} catch (e) {
			throw A(e);
		}
	}
	async getImportDraft(e) {
		let t = await this.db.importDrafts.get(e);
		return t ? Z(t) : void 0;
	}
	async clearImportDraft(e) {
		await this.db.importDrafts.delete(e);
	}
	async saveAuthorToolDraft(t) {
		let n = Z(t);
		if (!n.key || !C.test(n.projectId) || !/^\d+$/.test(n.baseRevision) || m(n.fields).byteLength > 1048576 || n.asset && n.asset.bytes.byteLength > 33554432) throw new M("LIMIT_EXCEEDED", "制作入力の一時保存上限または作品識別が不正です。");
		if (n.asset && await e(n.asset.bytes) !== n.asset.contentHash) throw new M("HASH_MISMATCH", "制作入力の素材bytesが変わっています。");
		try {
			await this.db.authorToolDrafts.put(n);
		} catch (e) {
			throw A(e);
		}
	}
	async restoreAuthorToolDrafts(t, n) {
		let r = Z(t), i = Z(n);
		if (new Set(r.map((e) => e.key)).size !== r.length) throw new M("VALIDATION_FAILED", "入力IDが重複しています。");
		for (let t of r) if (!this.accountId || !t.key.startsWith(this.accountId + ":") || !C.test(t.projectId) || !/^\d+$/.test(t.baseRevision) || m(t.fields).byteLength > 1048576 || t.asset && (t.asset.bytes.byteLength > 33554432 || await e(t.asset.bytes) !== t.asset.contentHash)) throw new M("VALIDATION_FAILED", "入力の領域・hash・上限が不正です。");
		await this.db.transaction("rw", this.db.authorToolDrafts, async () => {
			if (!Q((await this.db.authorToolDrafts.toArray()).map((e) => ({
				...e,
				asset: e.asset ? {
					contentHash: e.asset.contentHash,
					byteSize: e.asset.bytes.byteLength
				} : null
			})), i.map((e) => ({
				...e,
				asset: e.asset ? {
					contentHash: e.asset.contentHash,
					byteSize: e.asset.bytes.byteLength
				} : null
			})))) throw new M("REVISION_CONFLICT", "確認後に未保存入力が変わりました。");
			await this.db.authorToolDrafts.bulkPut(r), this.faultInjector?.("before-commit");
		});
	}
	async getWorkspaceInputs() {
		let e = await this.db.workspaceInputs.get("workspace");
		return e ? Z(e.value) : void 0;
	}
	checkedWorkspaceInputs(e) {
		let t = Z(e);
		if (!t || Object.keys(t).some((e) => ![
			"drafts",
			"jsonBuffers",
			"settingsDrafts",
			"alternativeDrafts"
		].includes(e)) || [
			"drafts",
			"jsonBuffers",
			"settingsDrafts",
			"alternativeDrafts"
		].some((e) => {
			let n = t[e];
			return !n || typeof n != "object" || Array.isArray(n);
		}) || m(t).byteLength > 67108864) throw new M("VALIDATION_FAILED", "作品入力の構造または保持上限が不正です。");
		return t;
	}
	async saveWorkspaceInputs(e, t) {
		let n = this.checkedWorkspaceInputs(e), r = Z(t);
		try {
			await this.db.transaction("rw", this.db.workspaceInputs, async () => {
				if (!Q((await this.db.workspaceInputs.get("workspace"))?.value, r)) throw new M("REVISION_CONFLICT", "別画面で作品入力が変わりました。入力を持ち出して再確認してください。");
				await this.db.workspaceInputs.put({
					key: "workspace",
					value: n
				});
			});
		} catch (e) {
			throw A(e);
		}
	}
	async restoreAuthorInputs(t, n) {
		let r = Z(t.tools), i = this.checkedWorkspaceInputs(t.workspace), a = Z(n);
		if (new Set(r.map((e) => e.key)).size !== r.length) throw new M("VALIDATION_FAILED", "入力IDが重複しています。");
		for (let t of r) if (!this.accountId || !t.key.startsWith(this.accountId + ":") || !C.test(t.projectId) || !/^(0|[1-9]\d*)$/.test(t.baseRevision) || !t.fields || typeof t.fields != "object" || Array.isArray(t.fields) || m(t.fields).byteLength > 1048576 || t.asset && (t.asset.bytes.byteLength > 33554432 || await e(t.asset.bytes) !== t.asset.contentHash)) throw new M("VALIDATION_FAILED", "入力の領域・hash・上限が不正です。");
		let o = (e) => e.map((e) => ({
			...e,
			asset: e.asset ? {
				contentHash: e.asset.contentHash,
				byteSize: e.asset.bytes.byteLength
			} : null
		})).sort((e, t) => e.key.localeCompare(t.key));
		try {
			await this.db.transaction("rw", this.db.authorToolDrafts, this.db.workspaceInputs, async () => {
				let e = await this.db.authorToolDrafts.toArray(), t = await this.db.workspaceInputs.get("workspace");
				if (!Q(o(e), o(a.tools)) || !Q(t?.value, a.workspace)) throw new M("REVISION_CONFLICT", "確認後に未保存入力が変わりました。");
				await this.db.authorToolDrafts.bulkPut(r), await this.db.workspaceInputs.put({
					key: "workspace",
					value: i
				}), this.faultInjector?.("before-commit");
			});
		} catch (e) {
			throw A(e);
		}
	}
	async getAuthorToolDraft(e) {
		let t = await this.db.authorToolDrafts.get(e);
		return t ? Z(t) : void 0;
	}
	async clearAuthorToolDraft(e) {
		await this.db.authorToolDrafts.delete(e);
	}
	async importScenario(t, n) {
		let r = {
			...n,
			idMap: n.idMap ? Z(n.idMap) : void 0,
			resolutions: n.resolutions ? Z(n.resolutions) : void 0
		};
		try {
			if (O(r.signal), ![
				"new",
				"clone",
				"replace",
				"merge",
				"mapped_merge"
			].includes(r.mode)) throw new M("FORMAT_UNSUPPORTED", "読み込みモードが未対応です。");
			let n = Z(t), i = r.operationId ?? u(), a = await this.validationWorlds(n.worlds), s = er(a);
			if (n.project = gi(n.project, s), n.recovery &&= await Rn(n.recovery, n.project, s, r.signal), tr([n.project, ...Object.values(n.worlds)], a), n.manifest.projectId !== n.project.projectId) throw new M("VALIDATION_FAILED", "読み込み候補とmanifestの作品IDが一致しません。");
			let c = await this.previewImport(n, r);
			if (r.mode === "new" && c.target) throw new M("IMPORT_CONFLICT", "同じ作品IDが既にあります。複製・置換・統合を選んでください。");
			if (r.mode === "replace" && c.pendingChanges) throw new M("PENDING_CHANGES", "未送信の変更があります。同期・競合解決を済ませるか、複製して復元してください。");
			if (c.target && r.baseRevision !== c.target.revision) throw new M("REVISION_CONFLICT", "確認した対象版と現在版が一致しません。読み込みの影響を確認し直してください。");
			let l = n.project, d = n.recovery, f;
			if (r.mode === "mapped_merge") {
				if (!c.mappedPlan?.candidate || c.mappedPlan.unresolved.length) throw new M("IMPORT_CONFLICT", "全IDの対応とすべての採用差分を確認してください。");
				if (!r.confirmationHash || r.confirmationHash !== c.confirmationHash) throw new M("REVISION_CONFLICT", "確認したID対応・採用差分・素材が変わりました。入力を保持して再確認してください。");
				l = c.mappedPlan.candidate, f = c.mappedPlan.idMap, d = c.mappedRecovery;
			}
			if (r.mode === "clone") {
				let e = await Fi(Ln(l, d));
				f = e.idMap, d = d ? await ji(d, e.project, f, r.signal) : void 0;
				let t = new Set(l.history.map((e) => f[e.operationId]));
				l = {
					...e.project,
					history: e.project.history.filter((e) => t.has(e.operationId))
				};
			}
			if (r.mode === "merge" && (l = Li(c.target, l, r.resolutions ?? {})), r.mode === "replace") {
				let e = new Map(l.snapshots.map((e) => [e.id, e]));
				for (let t of c.target.snapshots) {
					let n = e.get(t.id);
					if (n && !o(t, n)) throw new M("IMMUTABLE_SNAPSHOT", "同じsnapshot IDに異なる内容があります。", t.id);
					e.set(t.id, t);
				}
				l.snapshots = [...e.values()];
				let t = new Set(l.entities.map((e) => e.id));
				l.entities.push(...c.target.entities.filter((e) => e.kind === "snapshot" && !t.has(e.id)));
			}
			let p = n.assets.map((e) => ({
				contentHash: e.contentHash,
				bytes: e.bytes,
				mediaType: e.mediaType,
				assetPath: e.path
			})), h = await this.checkedAssets(p);
			await nr([l]), await vi(l, s);
			let g = Object.entries(n.worlds).map(([e, t]) => ({
				id: e,
				project: gi(t, s)
			})), _ = (/* @__PURE__ */ new Date()).toISOString(), v = c.target ? $(c.target) : hi(l), y;
			c.target ? (l = {
				...l,
				revision: mi(c.target.revision),
				history: Ni(c.target.history, (c.mappedPlan?.mappedProject.history ?? n.project.history).map((e, t) => r.mode === "mapped_merge" ? {
					...e,
					importOrigin: e.importOrigin ?? {
						sourceProjectId: n.project.projectId,
						sourceOperationId: n.project.history[t].operationId,
						importOperationId: i
					}
				} : e))
			}, l.entities = bi(c.target.entities, l.entities, i, _), l.relations = bi(c.target.relations, l.relations, i, _), xi(c.target, l), l = await Tr(c.target, l), l.entities = bi(c.target.entities, l.entities, i, _)) : r.mode === "clone" && (l = {
				...l,
				revision: mi(l.revision)
			}), l = gi(l, s);
			let b = await Oi(v, $(l), !c.target);
			if (y = {
				operationId: i,
				projectId: l.projectId,
				baseRevision: c.target?.revision ?? "0",
				revision: l.revision,
				targetIds: b.map((e) => e.targetId),
				createdAt: _,
				reason: `専用ファイルを${r.mode}で復元`,
				before: Z(v),
				after: Z($(l)),
				...f ? { idMap: f } : {}
			}, (c.target || r.mode === "clone") && (l.history = [...l.history, y]), d) {
				let t = new Map(l.history.map((e) => [e.operationId, e])), n = [];
				for (let i of d.pending) {
					O(r.signal);
					let a = t.get(i.operationId) ?? i.command;
					n.push({
						...i,
						command: a,
						commandHash: await e(m(a))
					});
				}
				d = {
					...d,
					projectId: l.projectId,
					sourceRevision: l.revision,
					pending: n
				};
			}
			l = gi(l, s), await vi(l, s), d &&= await Rn({
				...d,
				projectId: l.projectId,
				sourceRevision: l.revision
			}, l, s, r.signal);
			let x = n.syncRecovery ? await Lt(n.syncRecovery, s, r.signal) : [], S = c.target ? {
				id: u(),
				projectId: c.target.projectId,
				createdAt: _,
				reason: `専用ファイル${r.mode}の前の復元点`,
				project: c.target,
				assetHashes: Xn(c.target).map((e) => e.contentHash)
			} : void 0, C = await this.db.transaction("rw", this.writeTables, async () => {
				if (Xe(r.signal), O(r.signal), await this.db.importLogs.get(i) || await this.db.outbox.get(i) || await this.db.commands.get(i)) throw new M("OPERATION_CONFLICT", "この読み込み操作IDは既に使われています。");
				let e = await this.db.projects.get(l.projectId);
				if (c.target ? !e || e.revision !== c.target.revision : e) throw new M("REVISION_CONFLICT", "読み込みの確定前に対象作品が変わりました。");
				if (r.mode === "replace" && await this.db.outbox.where("projectId").equals(l.projectId).count()) throw new M("PENDING_CHANGES", "確定前に未送信の変更が増えました。");
				await this.guardWorldRegistry([l, ...g.map((e) => e.project)]), S && (await this.writeAssets([], S.project, !0), await this.db.restorePoints.add(S)), await this.writeAssets(h, l, n.manifest.assetMode === "embedded");
				for (let e of g) {
					let t = await this.db.worlds.get(e.id);
					if (t && !o(t.project, e.project)) throw new M("IMMUTABLE_SNAPSHOT", "既存の共通世界snapshotと内容が異なります。", e.id);
					await this.db.worlds.put(e);
				}
				await this.writeContent(l, c.target), this.faultInjector?.("after-content");
				for (let e of l.history) {
					let t = await this.db.commands.get(e.operationId);
					if (t && !Q(await this.materializeCommand(t), e)) throw new M("OPERATION_CONFLICT", "読み込む履歴の操作IDが既存履歴と衝突しています。", e.operationId);
					t || await this.db.commands.add({
						operationId: e.operationId,
						projectId: l.projectId,
						revision: e.revision,
						record: e
					});
				}
				this.faultInjector?.("after-history");
				let t = await this.db.syncMetadata.get(l.projectId);
				await this.db.outbox.add({
					operationId: i,
					projectId: l.projectId,
					accountId: this.accountId,
					baseRevision: t?.serverRevision ?? "0",
					localRevision: l.revision,
					createdAt: _,
					targetIds: y.targetIds,
					changes: b,
					command: y
				});
				let a = (await this.listRecoveredPending(l.projectId)).reduce((e, t) => Math.max(e, t.sequence), -1) + 1;
				for (let e of d?.pending ?? []) {
					let t = {
						key: `${l.projectId}:${e.operationId}`,
						projectId: l.projectId,
						importOperationId: i,
						sequence: a++,
						operation: e,
						status: "needs_reconnect"
					}, n = await this.db.recoveredPending.get(t.key);
					if (n && !o(n.operation, e)) throw new M("OPERATION_CONFLICT", "同じ送信待ち操作の復元内容が異なります。");
					n || await this.db.recoveredPending.add(t);
				}
				for (let e of x) await this.db.retainedSyncRecovery.put({
					key: `${l.projectId}:${e.contentHash}`,
					projectId: l.projectId,
					evidence: e,
					status: "needs_reconnect"
				});
				return await this.db.syncMetadata.put({
					projectId: l.projectId,
					serverRevision: t?.serverRevision ?? "0",
					state: "pending"
				}), await this.db.importLogs.add({
					operationId: i,
					projectId: l.projectId,
					mode: r.mode,
					createdAt: _,
					...f ? { idMap: f } : {}
				}), this.faultInjector?.("after-outbox"), O(r.signal), this.faultInjector?.("before-commit"), {
					project: l,
					operationId: i,
					localSaved: !0,
					pendingSync: !0,
					mode: r.mode,
					...f ? { idMap: f } : {},
					...S ? { restorePointId: S.id } : {},
					warnings: n.warnings
				};
			});
			return this.invalidateProjectCache(l.projectId), C;
		} catch (e) {
			throw A(e);
		}
	}
};
function Ai(e, t) {
	return e.byteLength === t.byteLength && e.every((e, n) => e === t[n]);
}
async function ji(t, n, r, i) {
	let a = new Map(n.history.map((e) => [e.operationId, e])), o = [];
	for (let n of t.pending) {
		O(i);
		let s = r[n.operationId], c = a.get(s);
		if (!s || !c) throw new M("IMPORT_CONFLICT", "復元する送信待ち操作の明示ID対応が不足しています。", n.operationId);
		o.push({
			operationId: s,
			command: c,
			commandHash: await e(m(c)),
			origin: n.origin ?? {
				projectId: t.projectId,
				operationId: n.operationId,
				serverRevision: t.serverRevision
			}
		});
	}
	return {
		...t,
		projectId: n.projectId,
		sourceRevision: n.revision,
		pending: o
	};
}
function Mi(e, t) {
	let n = new Map(e.snapshots.map((e) => [e.id, e]));
	for (let e of t.snapshots) n.set(e.id, Z(e));
	e.snapshots = [...n.values()], t.authorAlternatives && (e.authorAlternatives = Z(t.authorAlternatives));
	let r = new Map(t.entities.filter((e) => e.kind === "snapshot").map((e) => [e.id, e]));
	e.entities = e.entities.map((e) => Z(r.get(e.id) ?? e));
	let i = new Set(e.entities.map((e) => e.id));
	for (let [t, n] of r) i.has(t) || e.entities.push(Z(n));
	return e;
}
function Ni(e, t) {
	let n = new Map(e.map((e) => [e.operationId, e]));
	for (let e of t) {
		let t = n.get(e.operationId);
		if (t && !o(t, e)) throw new M("IMPORT_CONFLICT", "同じ操作IDに異なる履歴があります。", e.operationId);
		t || n.set(e.operationId, Z(e));
	}
	return [...n.values()];
}
function Pi(e, t) {
	let n = Z(e), r = (e, t, n) => {
		let r = new Map(e.map((e) => [e.id, e])), i = new Map(t.map((e) => [e.id, e])), a = new Map(n.map((e) => [e.id, e]));
		for (let e of /* @__PURE__ */ new Set([...r.keys(), ...i.keys()])) {
			let t = r.get(e), n = i.get(e);
			if (o(t ?? null, n ?? null)) continue;
			let s = a.get(e);
			if (!o(s ? yi(s) : null, n ? yi(n) : null)) throw new M("RESTORE_CONFLICT", "取り消し対象がその後に変更されています。履歴の単体復元で内容を比較してください。", e);
			t ? a.set(e, Z(t)) : a.delete(e);
		}
		return [...a.values()];
	};
	n.entities = r(t.before.entities, t.after.entities, e.entities), n.relations = r(t.before.relations, t.after.relations, e.relations);
	for (let r of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences",
		"snapshots",
		"views"
	]) if (!o(t.before[r], t.after[r])) {
		if (!o(e[r], t.after[r])) throw new M("RESTORE_CONFLICT", "取り消す項目がその後に変更されています。", r);
		n[r] = Z(t.before[r]);
	}
	return n;
}
async function Fi(r) {
	let i = { [r.projectId]: u() }, a = /* @__PURE__ */ new WeakSet(), o = (e) => {
		if (e && typeof e == "object" && !a.has(e)) {
			if (a.add(e), Array.isArray(e)) return e.forEach(o);
			for (let [t, n] of Object.entries(e)) {
				if ([
					"id",
					"operationId",
					"instanceId",
					"deletionOperationId"
				].includes(t) && typeof n == "string" && /^[0-9a-f-]{36}$/.test(n) && (i[n] ??= u()), t === "bindings" && n && typeof n == "object" && !Array.isArray(n)) for (let e of Object.values(n)) typeof e == "string" && /^[0-9a-f-]{36}$/.test(e) && (i[e] ??= u());
				o(n);
			}
		}
	};
	o(r);
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new WeakSet(), d = (e) => {
		if (!e || typeof e != "object" || l.has(e)) return;
		if (l.add(e), Array.isArray(e)) {
			for (let t = e.length - 1; t >= 0; t--) d(e[t]);
			return;
		}
		let t = e, n = Object.values(t);
		for (let e = n.length - 1; e >= 0; e--) d(n[e]);
		typeof t.id == "string" && "kind" in t && "data" in t && "projectId" in t && !s.has(t.id) && s.set(t.id, t), typeof t.id == "string" && "relationType" in t && "fromId" in t && "toId" in t && !c.has(t.id) && c.set(t.id, t);
	};
	d(r);
	let f = (e, t) => t.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), p = (e, t, n) => {
		let r = e;
		for (let e of t.slice(0, -1)) (!r[e] || typeof r[e] != "object") && (r[e] = {}), r = r[e];
		t.length && (r[t[t.length - 1]] = structuredClone(n));
	}, h = (e) => {
		if (Array.isArray(e)) {
			e.forEach(h);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		if (typeof t.id == "string" && (t.id = i[t.id] ?? t.id), typeof t.instanceId == "string" && "quantity" in t && "consumed" in t && (t.instanceId = i[t.instanceId] ?? t.instanceId), t.mode === "anonymize" && typeof t.publicId == "string" && (t.publicId = i[t.publicId] ?? t.publicId), t.publicIds && typeof t.publicIds == "object") for (let [e, n] of Object.entries(t.publicIds)) typeof n == "string" && (t.publicIds[e] = i[n] ?? n);
		for (let e of Object.values(t)) h(e);
	}, g = /* @__PURE__ */ new WeakMap(), _ = (e, t = "", n) => {
		if (!e || typeof e != "object") return v(e, t, n);
		let r = t;
		Array.isArray(e) && (t === "value" && (r += n?.type === "ref" ? ":ref" : ":literal"), t === "key" && n && typeof n.scope == "string" && Array.isArray(n.path) && (r += k([
			n.scope,
			n.itemId ?? null,
			n.path
		])), t === "publicId" && (r += n && typeof n.entityId == "string" && typeof n.sourceVersionId == "string" ? ":citation" : ":local"));
		let i = g.get(e) ?? /* @__PURE__ */ new Map();
		if (i.has(r)) return i.get(r);
		let a = v(e, t, n);
		return i.set(r, a), g.set(e, i), a;
	}, v = (e, r = "", a) => {
		if (typeof e == "string") return r === "onceTriggers" ? e.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/g, (e) => i[e] ?? e) : r === "key" && a && typeof a.scope == "string" && Array.isArray(a.path) ? [
			a.scope,
			typeof a.itemId == "string" ? i[a.itemId] ?? a.itemId : "",
			...a.path.map((e) => String(e))
		].map((e) => encodeURIComponent(e)).join(":") : r === "publicId" && a && typeof a.entityId == "string" && typeof a.sourceVersionId == "string" ? e : (/(?:Id|Ids)$/.test(r) || ["id", "operationId"].includes(r) || r === "value" && a?.type === "ref") && i[e] ? i[e] : e;
		if (r === "importOrigin" && e && typeof e == "object") {
			let t = e;
			return {
				...t,
				importOperationId: i[t.importOperationId] ?? t.importOperationId
			};
		}
		if (r === "path" && Array.isArray(e)) return [...e];
		if (r === "assignments" && e && typeof e == "object" && !Array.isArray(e)) return Object.fromEntries(Object.entries(e).map(([e, t]) => [e, typeof t == "string" ? i[t] ?? t : t]));
		if (Array.isArray(e)) return e.map((e) => _(e, r, a));
		if (e && typeof e == "object") {
			let a = e;
			if ([
				"entity",
				"relation",
				"project",
				"presentation"
			].includes(String(a.scope)) && Array.isArray(a.path) && a.before && a.after && "present" in a.before && "present" in a.after) {
				let e = String(a.scope), r = a.path, o = typeof a.itemId == "string" ? a.itemId : void 0, l = o ? i[o] ?? o : void 0, u = [...r], d = (a) => {
					if (e === "entity" && o && s.has(o) && r.length) {
						let e = structuredClone(s.get(o));
						p(e, r, a);
						let t = n(e, i);
						return t.id = i[e.id] ?? e.id, t.projectId = i[e.projectId] ?? e.projectId, t.deletionOperationId &&= i[t.deletionOperationId] ?? t.deletionOperationId, h(t.data), f(t, r);
					}
					if (e === "relation" && o && c.has(o) && r.length) {
						let e = structuredClone(c.get(o));
						p(e, r, a);
						let n = t(e, i);
						return n.id = i[e.id] ?? e.id, n.projectId = i[e.projectId] ?? e.projectId, f(n, r);
					}
					if (e === "project" && r[0] === "worldReferences") return structuredClone(a);
					if (e === "presentation" && a && typeof a == "object" && !Array.isArray(a)) {
						let e = structuredClone(a);
						return Array.isArray(e.chapterOrder) && (e.chapterOrder = e.chapterOrder.map((e) => typeof e == "string" ? i[e] ?? e : e)), _(e);
					}
					let l = r.at(-1) ?? "";
					return _(a, l);
				}, m = (e) => {
					let t = structuredClone(e);
					return t.present === !0 && (t.value = d(t.value)), t;
				}, g = {
					...a,
					...l ? { itemId: l } : {},
					path: u,
					before: m(a.before),
					after: m(a.after)
				};
				return g.key = [
					e,
					l ?? "",
					...u
				].map((e) => encodeURIComponent(e)).join(":"), g;
			}
			let o = [
				"variableValues",
				"visitCounts",
				"publicTexts",
				"publicIds",
				"byEntityId",
				"bindings"
			].includes(r), l = Object.fromEntries(Object.entries(e).map(([t, n]) => [o ? i[t] ?? t : t, ["idMap", "bindings"].includes(r) && typeof n == "string" ? i[n] ?? n : _(n, t, e)]));
			return "kind" in l && "data" in l && "projectId" in l ? n(l, i) : "relationType" in l && "fromId" in l && "toId" in l ? t(l, i) : (Array.isArray(l.patches) && Array.isArray(l.selectedChangeKeys) && (l.selectedChangeKeys = l.patches.map((e) => e.key).sort()), l);
		}
		return e;
	}, y = _(r), b = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new WeakSet(), S = (e) => {
		if (!e || typeof e != "object" || x.has(e)) return;
		if (x.add(e), Array.isArray(e)) {
			e.forEach(S);
			return;
		}
		let t = e;
		if (typeof t.id == "string" && t.content && typeof t.content == "object" && "versionLabel" in t && "contentHash" in t) {
			let e = b.get(t.id) ?? [];
			e.push(t), b.set(t.id, e);
		}
		Object.values(t).forEach(S);
	};
	S(y);
	let C = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Set(), T = async (t) => {
		let n = C.get(t);
		if (n) return n;
		let r = b.get(t);
		if (!r?.length) throw new M("HASH_MISMATCH", "参照したsnapshotがclone後に見つかりません。", t);
		if (w.has(t)) throw new M("HASH_MISMATCH", "snapshotの内容hashに循環があります。", t);
		w.add(t);
		for (let e of r) {
			let t = e.content;
			for (let e of t.entities) e.kind === "snapshot" && b.has(e.id) && (e.data.contentHash = await T(e.id));
		}
		let i = await e(m(r[0].content));
		for (let e of r) e.contentHash = i;
		return C.set(t, i), w.delete(t), i;
	};
	for (let e of b.keys()) await T(e);
	let E = /* @__PURE__ */ new WeakSet(), D = (e) => {
		if (!e || typeof e != "object" || E.has(e)) return;
		if (E.add(e), Array.isArray(e)) {
			e.forEach(D);
			return;
		}
		let t = e;
		if (t.kind === "snapshot" && typeof t.id == "string" && t.data && typeof t.data == "object") {
			let e = C.get(t.id);
			e && (t.data.contentHash = e);
		}
		Object.values(t).forEach(D);
	};
	D(y);
	let O = /* @__PURE__ */ new Set(), ee = async (e) => {
		if (!e || typeof e != "object" || O.has(e)) return;
		if (O.add(e), Array.isArray(e)) {
			for (let t of e) await ee(t);
			return;
		}
		let t = e;
		Array.isArray(t.authorAlternatives) && (t.authorAlternatives = await Promise.all((t.authorAlternatives ?? []).map(st)));
		for (let e of Object.values(t)) await ee(e);
	};
	await ee(y);
	let { history: A, snapshots: te, authorAlternatives: j, ...N } = y, ne = {
		...y,
		...Z(N)
	};
	li(ne.history);
	for (let e of ne.snapshots) li(e);
	return {
		project: ne,
		idMap: i
	};
}
function Ii(e, t) {
	let n = [];
	for (let r of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) o(e[r], t[r]) || n.push({
		id: `project.${r}`,
		kind: "project",
		existing: e[r],
		incoming: t[r]
	});
	for (let [r, i] of [
		["entities", "entity"],
		["relations", "relation"],
		["snapshots", "snapshot"],
		["views", "view"],
		["authorAlternatives", "alternative"]
	]) {
		let a = new Map((e[r] ?? []).map((e) => [e.id, e]));
		for (let e of t[r] ?? []) a.has(e.id) && !o(a.get(e.id), e) && n.push({
			id: e.id,
			kind: i,
			existing: a.get(e.id),
			incoming: e
		});
	}
	return n;
}
function Li(e, t, n) {
	let r = Ii(e, t);
	for (let e of r) {
		if (!n[e.id]) throw new M("IMPORT_CONFLICT", "同じID・異なる内容の競合があります。採用する内容を選択してください。", e.id);
		if (e.kind === "snapshot" && n[e.id] !== "existing") throw new M("IMMUTABLE_SNAPSHOT", "既存snapshotは別の内容へ置き換えられません。", e.id);
		if (e.kind === "alternative" && n[e.id] !== "existing") throw new M("IMPORT_CONFLICT", "保存済み作者別案のIDへ別の履歴を上書きできません。", e.id);
	}
	let i = Z(e);
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) n[`project.${e}`] === "incoming" && (i[e] = Z(t[e]));
	for (let r of [
		"entities",
		"relations",
		"snapshots",
		"views",
		"authorAlternatives"
	]) {
		let a = new Map((e[r] ?? []).map((e) => [e.id, e]));
		for (let e of t[r] ?? []) (!a.has(e.id) || n[e.id] === "incoming") && a.set(e.id, Z(e));
		i[r] = [...a.values()];
	}
	return i;
}
//#endregion
//#region ../shinariokanri-rb10-c16-91history-proof/results/original-file-new-clone-1/entry.mjs
new ki(), globalThis.inspectOriginalRestore = async () => {
	let t = new ki(), n = await t.listProjectsForEditing(), r = [];
	for (let i of n) {
		let n = await t.historyPage(i.projectId, { size: 60 }), a = [...n.entries];
		for (let e = 1; e <= n.maximum; e++) a.push(...(await t.historyPage(i.projectId, {
			page: e,
			size: 60
		})).entries);
		let o = await t.getSaveState(i.projectId), s = await t.db.importLogs.where("projectId").equals(i.projectId).toArray(), c = "4c36d59b-04fb-4289-a8c3-d5e5d4ca9c10", l = s.at(-1)?.idMap;
		l && (c = l[c]);
		let u = await t.historyCommand(i.projectId, c);
		r.push({
			project: i,
			contentHash: await e(m({
				...i,
				history: []
			})),
			records: i.entities.length + i.relations.length,
			historyCount: n.total,
			metadata: a,
			saveState: o,
			importLogs: s,
			oldEdition: {
				operationId: u.operationId,
				projectId: u.projectId,
				baseRevision: u.baseRevision,
				revision: u.revision,
				beforeName: u.before.name,
				afterName: u.after.name,
				records: u.after.entities.length + u.after.relations.length
			}
		});
	}
	return t.close(), r;
};
//#endregion
