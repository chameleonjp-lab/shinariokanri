import datetime,hashlib,json,pathlib
root=pathlib.Path('/workspace/shinariokanri-rb10-declared-state-usage');frozen=pathlib.Path('/workspace/shinariokanri-rb10-c16-frozen-inputs');dest=pathlib.Path('/tmp/shinariokanri-rb10-candidate-16');binding=dest/'source-and-build-binding.json';b=json.loads(binding.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=b['source_files']+b['original_documents']+b['artifact_files']+[b['generated_runtime']]
for row in rows:
 for parent in [root,frozen]:assert sha(parent/row['path'])==row['sha256'],row['path']
raw=pathlib.Path('/workspace/shinariokanri-rb10-c16-91history-proof/results/original-file-new-clone-1/raw.json');r=json.loads(raw.read_text());proof=raw.parent
assert r['bindingSHA256']==sha(binding)
assert (r['commit'],r['tree'],r['build'])==(b['commit'],b['tree'],b['build_info']['version'])
assert r['procedureSHA256']==sha(proof/'executed-procedure.mjs')=='14c47fd14b106e31a98f3a85afef6c4b3a71e95d9cc8b4c63b4ff0852553da15'
original=pathlib.Path(r['file']['path']);assert original.stat().st_size==r['file']['bytes']==255211;assert sha(original)==r['file']['sha256']=='5fc45f32b1ef2a428e7cd0facbd7388b32f8a05edfc22dd0f28bb7f5bc4efd9a'
assert r['result']=='passed_local_original_8800_91_complete_new_clone_cold_oldedition' and r['errors']==[]
assert [p['mode'] for p in r['phases']]==['new','clone'];summary=[]
for phase,count in zip(r['phases'],[91,92]):
 c,k=phase['current'],phase['cold'];assert c['records']==8800 and c['historyCount']==k['historyCount']==count and len(c['metadata'])==count
 assert c['contentHash']==k['contentHash'] and c['saveState']==k['saveState'] and c['oldEdition']==k['oldEdition']
 assert c['saveState']['localSaved'] is True and c['saveState']['pendingCount']==1 and c['saveState']['recoveredPendingCount']==91
 assert c['oldEdition']['revision']=='8' and c['oldEdition']['beforeName']=='元RG06作品名5' and c['oldEdition']['afterName']=='元RG06作品名6' and c['oldEdition']['records']==8800
 assert len(c['importLogs'])==1 and c['importLogs'][0]['mode']==phase['mode']
 summary.append({'mode':phase['mode'],'records':c['records'],'currentAndColdHash':c['contentHash'],'historyAndMetadata':count,'pending':c['saveState'],'arbitraryOldEdition':c['oldEdition']})
supervisor=json.loads((dest/'original-file-new-clone-1-supervisor.json').read_text());assert supervisor['exitCode']==0
closure=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(proof.rglob('*')) if p.is_file()]
helper=json.loads((proof/'HELPER_INPUTS.json').read_text())
d={'adjudicatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'C16','commit':b['commit'],'tree':b['tree'],'build':b['build_info'],'bindingSHA256':sha(binding),'allFrozenAndExecutedInputsStillMatch':len(rows),'rawSHA256':sha(raw),'originalFile':r['file'],'sourceProcedureSHA256':r['procedureSHA256'],'startedAt':r['startedAt'],'finishedAt':r['finishedAt'],'supervisorExitCode':0,'result':r['result'],'phases':summary,'readOnlyObserverExceptionsPreserved':r.get('readOnlyObserverErrors',[]),'claimLimit':'Actual managed-Linux Chromium production/IndexedDB same original 8800/91 file functional new and clone plus cold reload/arbitrary old revision8. Observer innerText timeout exceptions remain. No performance, 116 whole-acceptance, physical device, assistive technology, liveAuthRLSStorage, OS restart or unaccelerated7200 claim. C15 original clone crash remains historical failure; not overwritten.','retainedFiles':closure,'compiledHelperInputCapture':helper}
output=dest/'original-file-new-clone-1-adjudication.json';assert not output.exists();output.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passedFunctionalOnly':True,'frozenFiles':len(rows),'proofFiles':len(closure),'observerExceptions':len(d['readOnlyObserverExceptionsPreserved']),'adjudicationSHA256':sha(output)}))
