import {test,expect,type Page} from '@playwright/test';
import {readFile} from 'node:fs/promises';
import {createEntity} from '../candidate/src/domain/model';
import {createMaterialPerformanceFixture} from '../candidate/src/testing/performanceFixture';
import {exportScenario,inspectScenario} from '../candidate/src/storage/archive';
import {nav,evidence,digest,captureProofFile,appURL} from './common';
import {reader,openRecord} from './extended-support';

// Preparation only until a final C10 candidate and explicit huge-fixture window.
// Retain the entire original88,003-record/72MiB material fixture, then add a
// 256-transition declared branch plus an independently unbounded state loop.
// No existing record, body, material or safety limit is reduced.
async function nativeFingerprint(page:Page){return page.evaluate(async()=>{
 const db=await new Promise<IDBDatabase>((resolve,reject)=>{const q=indexedDB.open('scenario-manager-local-v1');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
 try{
 const names=Array.from(db.objectStoreNames).sort();
  const rows=await new Promise<Record<string,unknown[]>>((resolve,reject)=>{const tx=db.transaction(names,'readonly'),all:Record<string,unknown[]>={};for(const name of names){const q=tx.objectStore(name).getAll();q.onsuccess=()=>{all[name]=q.result;};}tx.oncomplete=()=>resolve(all);tx.onabort=()=>reject(tx.error);tx.onerror=()=>reject(tx.error);});
  const hash=async(bytes:Uint8Array)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes as BufferSource)),v=>v.toString(16).padStart(2,'0')).join('');
  const encoder=new TextEncoder();
  async function normalize(value:unknown):Promise<unknown>{
   if(value instanceof ArrayBuffer)return {binaryType:'ArrayBuffer',bytes:value.byteLength,sha256:await hash(new Uint8Array(value))};
   if(ArrayBuffer.isView(value))return {binaryType:value.constructor.name,bytes:value.byteLength,sha256:await hash(new Uint8Array(value.buffer,value.byteOffset,value.byteLength))};
   if(Array.isArray(value)){const result:unknown[]=[];for(const item of value)result.push(await normalize(item));return result;}
   if(value&&typeof value==='object'){const result:Record<string,unknown>={};for(const key of Object.keys(value).sort())result[key]=await normalize((value as Record<string,unknown>)[key]);return result;}
   return value;
  }
  const out:Record<string,{count:number;sha256:string}>={};
  for(const name of names){const perRow:string[]=[];for(const row of rows[name])perRow.push(await hash(encoder.encode(JSON.stringify(await normalize(row)))));out[name]={count:rows[name].length,sha256:await hash(encoder.encode(JSON.stringify(perRow)))};}
  return out;
 }finally{db.close();}
});}

test('AT-N05 original Large and long branch: cancel→different screen→same unknown result + unfinished input, all native record and material hashes unchanged',async({page},info)=>{
 test.setTimeout(1_200_000);
 const descriptor=JSON.parse(await readFile('prepared/FIXED_N05_LARGE_INPUT.json','utf8'));
 const bytes=new Uint8Array(await readFile(descriptor.archive));expect(digest(bytes)).toBe(descriptor.sha256);
 const inspected=await inspectScenario(bytes,{worker:false}),p=inspected.project;
 const additions=p.entities.filter(entity=>(descriptor.additionIds as string[]).includes(entity.id));
 expect(additions).toHaveLength(519);const additionIds=new Set(additions.map(entity=>entity.id));
 const originalRecordIds=[...p.entities.filter(entity=>!additionIds.has(entity.id)).map(entity=>entity.id),...p.relations.map(relation=>relation.id)];expect(originalRecordIds).toHaveLength(88003);
 const inputScene=p.entities.find(entity=>entity.id===descriptor.sceneId)!;expect(inputScene.name).toBe(descriptor.sceneName);
 const loop=p.entities.find(entity=>entity.id===descriptor.loopEntryId)!;
 const chain=p.entities.filter(entity=>entity.kind==='flow_node'&&entity.name.startsWith('原N05長い分岐')).sort((a,b)=>Number(a.name.slice('原N05長い分岐'.length))-Number(b.name.slice('原N05長い分岐'.length)));expect(chain).toHaveLength(257);expect(chain[0]!.id).toBe(descriptor.finiteEntryId);expect(chain.at(-1)!.id).toBe(descriptor.finiteTerminalId);
 const fixture={project:p,seed:descriptor.fixtureSeed,coreRecords:88000,counts:{totalRecords:originalRecordIds.length},assetBytes:inspected.assets.reduce((sum,asset)=>sum+asset.bytes.byteLength,0),assets:inspected.assets};
 expect(fixture.coreRecords).toBe(88000);expect(fixture.counts.totalRecords).toBe(88003);expect(fixture.assetBytes).toBe(72*1024*1024);expect(fixture.assets).toHaveLength(3);
 const retainedRecordIds=new Set([...p.entities.map(entity=>entity.id),...p.relations.map(relation=>relation.id)]);expect(originalRecordIds.every(id=>retainedRecordIds.has(id))).toBe(true);
 const assetHashes=fixture.assets.map(asset=>({sha256:digest(asset.bytes),bytes:asset.bytes.byteLength}));expect(assetHashes.map(asset=>asset.sha256).sort()).toEqual(fixture.assets.map(asset=>asset.contentHash).sort());
 await captureProofFile(bytes,'N05-original-Large-long-branch-fixed-bytes');
 await page.goto(appURL);await page.getByRole('button',{name:'保存ファイルを読み込む',exact:true}).click();await page.locator('input[type=file]').setInputFiles({name:'original-N05-large.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});
 await expect(page.getByRole('heading',{name:/^検査済みの作品/})).toBeVisible({timeout:600_000});await page.getByLabel('復元方法と対象への影響を確認しました').check();await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect(page.locator('.app-shell')).toBeVisible({timeout:600_000});
 await openRecord(page,'scene',inputScene.name);const advanced=page.locator('details.advanced-details').filter({has:page.getByText('詳細データ・ルビ・本文リンクを編集',{exact:true})});if(await advanced.getAttribute('open')===null)await advanced.locator('summary').click();const input=advanced.getByRole('textbox',{name:'詳細データ',exact:true}),unfinished=(await input.inputValue()).slice(0,-1);await input.fill(unfinished);await expect(page.locator('.editor-save-state')).toContainText('未保存');
 await reader(page);await page.getByLabel('試読の開始点',{exact:true}).selectOption('');
 await expect.poll(()=>page.evaluate(async expected=>{
  const db=await new Promise<IDBDatabase>((resolve,reject)=>{const q=indexedDB.open('scenario-manager-local-v1');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
  try{return await new Promise<boolean>((resolve,reject)=>{const q=db.transaction('workspaceInputs','readonly').objectStore('workspaceInputs').get('workspace');q.onsuccess=()=>{const buffers=q.result?.value?.jsonBuffers??{};resolve(Object.values(buffers).some(group=>Object.values(group as Record<string,string>).includes(expected)));};q.onerror=()=>reject(q.error);});}finally{db.close();}
 },unfinished)).toBe(true);
 const before=await nativeFingerprint(page);
 await page.getByRole('button',{name:'到達性と行き止まりを検査',exact:true}).click();const cancel=page.getByRole('button',{name:'探索を中止',exact:true});await expect(cancel).toBeVisible();await page.waitForTimeout(2200);await expect(cancel).toBeEnabled();const progressText=await page.getByRole('status').filter({hasText:'状態を確認中'}).innerText();await cancel.click();await expect(page.locator('.analysis-result-heading')).toContainText('探索打切り',{timeout:40_000});
 const firstDownload=page.waitForEvent('download');await page.getByRole('button',{name:'検査結果を保存',exact:true}).click();const file=await firstDownload;expect(await file.failure()).toBeNull();const firstResultBytes=new Uint8Array(await readFile((await file.path())!)),result=JSON.parse(Buffer.from(firstResultBytes).toString('utf8'));await captureProofFile(firstResultBytes,'N05-Large-interrupted-result','json');expect(result.status).toBe('unknown');expect(result.truncated).toBe(true);expect(result.limits).toEqual({maxStates:100000,maxTransitions:10000,maxMs:30000});expect(result.declaredEntryIds).toEqual(expect.arrayContaining([loop.id,chain[0]!.id]));
 await nav(page,/^資料/);await reader(page);await expect(page.locator('.analysis-result-heading')).toContainText('探索打切り');const secondDownload=page.waitForEvent('download');await page.getByRole('button',{name:'検査結果を保存',exact:true}).click();const second=await secondDownload;expect(await second.failure()).toBeNull();const retained=new Uint8Array(await readFile((await second.path())!));expect(JSON.parse(Buffer.from(retained).toString('utf8'))).toEqual(result);await captureProofFile(retained,'N05-Large-retained-result','json');
 await openRecord(page,'scene',inputScene.name);if(await advanced.getAttribute('open')===null)await advanced.locator('summary').click();await expect(advanced.getByRole('textbox',{name:'詳細データ',exact:true})).toHaveValue(unfinished);const after=await nativeFingerprint(page);expect(after).toEqual(before);
 await evidence(info,'N05-original-Large-cancel-navigation',{fixtureSeed:fixture.seed,originalCoreRecords:88000,originalMaterialRecords:3,originalRecordIdsRetained:88003,additionalLongBranchRecords:additions.length,longFiniteTransitions:256,unboundedStateLoop:true,archiveSHA256:digest(bytes),actualAssetHashes:assetHashes,actualAssetBytes:fixture.assetBytes,progressText,result,firstResultSHA256:digest(firstResultBytes),retainedResultSHA256:digest(retained),nativeBefore:before,nativeAfter:after,allSavedMetadataAndActualBinaryHashesUnchanged:true,unfinishedInputResumed:true,originalNegativeUnknownNeverFullSafety:true,proofLayer:'normal production App/native IndexedDB; actual generated fixture/material bytes',performance:'not_measured',physical:'not_run',actualAuth:'not_run'});
});
