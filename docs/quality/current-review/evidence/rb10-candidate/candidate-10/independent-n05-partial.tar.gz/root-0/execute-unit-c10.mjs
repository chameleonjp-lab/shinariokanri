import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createReadStream,createWriteStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {release as osRelease} from 'node:os';
import {spawn} from 'node:child_process';
const root=dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex');
const run=process.env.REVIEW_RUN,stage=process.argv[2];
if(process.env.REVIEW_EXECUTION_WINDOW!=='open'||!run||!/^[a-z0-9-]+$/.test(run))throw Error('Explicit OPEN and unique run name required.');
if(!process.env.CHROMIUM_PATH?.includes('chromium-1243'))throw Error('Bound Chromium153 required even for unit wrappers.');
const definitions={legacy17:'vitest.corrected-legacy17.c10.config.ts',additional10:'vitest.additional.c10.config.ts',optimization2:'vitest.c10-new-boundaries.config.ts',selected276:'vitest.selected.c10.config.ts',allocation2:'vitest.c10-allocation-boundaries.config.ts',reference3:'vitest.c10-reference-index.config.ts',bounded1:'vitest.c10-bounded-read.config.ts'};
if(!Object.hasOwn(definitions,stage))throw Error('Select a recorded unit definition set.');
const binding=JSON.parse(await readFile(resolve(root,'candidate-binding.json'),'utf8'));
async function verify(){for(const entry of [...binding.sourceFiles,...binding.originalDocuments??[],...binding.distFiles,...binding.generatedInputs??[]])if(sha(await readFile(resolve(root,'candidate',entry.file)))!==entry.sha256)throw Error('C10 sealed file changed: '+entry.file);}
async function verifySelected(){const tree=JSON.parse(await readFile(resolve(root,'SELECTED_C10_TREE_BINDING.json'),'utf8'));for(const row of tree.files)if(sha(await readFile(resolve(root,'selected-c10',row.file)))!==row.sha256)throw Error('C10 private selected tree changed: '+row.file);}
await verify();await verifySelected();const output=resolve(root,'results',run);await mkdir(resolve(root,'results'),{recursive:true});await mkdir(output);await mkdir(resolve(output,'input-source'));
let config=await readFile(resolve(root,definitions[stage]),'utf8');
const resultPath=resolve(output,'vitest.json');
// Change the reporter destination only; leave all values/assertions and product
// limits untouched. Each retry receives its own retained JSON and raw log.
if(config.includes('export default defineConfig({"')){
 const options=JSON.parse(config.split('export default defineConfig(')[1].split(');')[0]);options.test.outputFile=resultPath;
 config="import {defineConfig} from 'vitest/config';\nexport default defineConfig("+JSON.stringify(options)+');\n';
}else config=config.replace(/outputFile:'[^']*'/,"outputFile:"+JSON.stringify(resultPath));
const configPath=resolve(output,'input-source','vitest.config.ts');await writeFile(configPath,config);
const selected=stage==='additional10'?root:resolve(root,'selected-c10'),inputFiles=[];
if(stage==='additional10'){
 for(const name of(await readdir(resolve(root,'harness-c1'))).sort())if(name.endsWith('.ts')){
  const bytes=await readFile(resolve(root,'harness-c1',name));await writeFile(resolve(output,'input-source',name),bytes);inputFiles.push({file:'harness-c1/'+name,sha256:sha(bytes)});
 }
}else{
 const input=JSON.parse(await readFile(resolve(root,'SELECTED_C10_EXECUTION_INPUTS.json'),'utf8'));
 for(const entry of input.files){if(sha(await readFile(resolve(selected,entry.file)))!==entry.executionCopySHA256)throw Error('Private selected input changed: '+entry.file);inputFiles.push({file:entry.file,sha256:entry.executionCopySHA256});}
}
const command=[resolve(root,'node_modules/.bin/vitest'),'run','--config',configPath],startedAt=new Date().toISOString();
await writeFile(resolve(output,'INPUTS.json'),JSON.stringify({commit:binding.commit,tree:binding.tree,candidateBindingSHA256:sha(await readFile(resolve(root,'candidate-binding.json'))),stage,command,cwd:selected,startedAt,configSHA256:sha(config),inputFiles,environment:{node:process.version,platform:process.platform,arch:process.arch,osVersion:osRelease(),CHROMIUM_PATH:process.env.CHROMIUM_PATH},proofLayer:'pure/unit or fakeIndexedDB components; internal exported-browser checks where explicitly selected; not normal production/physical/Auth'},null,2)+'\n');
const child=spawn(command[0],command.slice(1),{cwd:selected,env:process.env,stdio:'pipe'});let raw='';const immediateRaw=createWriteStream(resolve(output,'raw.in-progress.log'));
for(const stream of[child.stdout,child.stderr])stream.on('data',bytes=>{raw+=bytes.toString();immediateRaw.write(bytes);process.stdout.write(bytes);});
const exitCode=await new Promise((done,reject)=>{child.on('error',reject);child.on('close',done);});await new Promise(done=>immediateRaw.end(done));await writeFile(resolve(output,'raw.log'),raw);await verify();await verifySelected();
const artifacts=[];async function walk(dir,relative=''){for(const entry of await readdir(dir,{withFileTypes:true})){const file=resolve(dir,entry.name),name=relative?relative+'/'+entry.name:entry.name;if(entry.isDirectory())await walk(file,name);else{const h=createHash('sha256');for await(const chunk of createReadStream(file))h.update(chunk);artifacts.push({file:name,sha256:h.digest('hex')});}}}await walk(output);
await writeFile(resolve(output,'EXECUTION_BINDING.json'),JSON.stringify({commit:binding.commit,tree:binding.tree,stage,candidateBindingSHA256:sha(await readFile(resolve(root,'candidate-binding.json'))),command,cwd:selected,startedAt,finishedAt:new Date().toISOString(),exitCode,rawSHA256:sha(raw),artifacts,sealedSourceAndDistUnchanged:true,originalAcceptancePassesInferred:0,physical:'not_run',actualAuth:'not_run'},null,2)+'\n');process.exitCode=Number(exitCode??1);
