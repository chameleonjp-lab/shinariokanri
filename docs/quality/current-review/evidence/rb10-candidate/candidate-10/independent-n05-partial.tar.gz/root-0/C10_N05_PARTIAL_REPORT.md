# C10 independent N05 preflight: partial, failed

Target f76d5e997efc45506bb21c88c5b8d275e093ead6 / tree e5fc7afa2c861af1249559c148df902905502559 / clean build187d47a7aa5851672542.

Two compiler runs passed. Small23-record cancellation/navigation/input/native12 equality passed as support. The original Large88,003-record plus256-transition fixture with actual72MiB materials failed progress/cancellation responsiveness. A native pointer diagnostic independently recorded first cancellation rendering after12,498.9ms and cancellation-event processing after19,653.4ms, with12,502ms and7,146ms LongTasks. The original2-second condition was preserved. Both failures, actual archive, trace, screenshots, raw logs, source and compiler bindings are retained.

Original Large unknown/truncated results were observed; full Large cancellation→screen navigation→input/result restoration and all-native equality were not completed. Actual7200-second soak was not started on C10. No original104/116/24/6 completion, real-device or liveAuth pass is inferred. Other available original clauses and33 real boundaries remain prepared for the next fixed target.

The historical C7 F05 full-case assessment remains withdrawn because multiple chapters were not observed in that original fixture. Historical C9 results are not transferred to C10.
