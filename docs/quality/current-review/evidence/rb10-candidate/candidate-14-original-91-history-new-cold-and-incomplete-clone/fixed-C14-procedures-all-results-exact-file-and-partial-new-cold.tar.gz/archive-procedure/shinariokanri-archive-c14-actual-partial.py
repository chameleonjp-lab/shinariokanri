"""Seal C12 evidence separately from its immutable tested source commit.

Run after the independent final seal and actual >=7200 second Large drill.
No case/gate success is inferred from process exits, counts or old candidates.
Temporary signed-download URL raw remains local; its hash/redaction adjudication
is distributed. Every archive member and any <=64 MiB Git split is byte checked.
"""
import argparse, datetime, gzip, hashlib, io, json, pathlib, shutil, subprocess, tarfile
ROOT=pathlib.Path('/workspace/shinariokanri-rb10-basic-registration')
PROOF=pathlib.Path('/tmp/shinariokanri-rb10-candidate-12')
MEASURE=pathlib.Path('/workspace/shinariokanri-rb10-measurements')
COMMIT='1a604f0bcdb44a879b29b052008216e61aea3777'; TREE='3d9d914aeddae2192ee77fb7f5b467158d73959f'; BUILD='57f913e16b0a69e4494f'
EXCLUDED={'ci-native-artifact-download.log'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def descriptor(p,name):return {'path':str(name),'bytes':p.stat().st_size,'sha256':sha(p)}
def enumerate_folder(folder,prefix):
 return [(p,pathlib.PurePosixPath(prefix)/p.relative_to(folder).as_posix()) for p in sorted(folder.rglob('*')) if p.is_file() and not p.is_symlink() and 'node_modules' not in p.relative_to(folder).parts]
def bundle(dest,name,pairs,scope):
 assert len({str(n) for _,n in pairs})==len(pairs),'duplicate archive names'
 rows=[descriptor(p,n) for p,n in pairs]
 for r in rows:assert not pathlib.PurePosixPath(r['path']).is_absolute() and '..' not in pathlib.PurePosixPath(r['path']).parts
 archive=dest/(name+'.tar.gz')
 with archive.open('wb') as out:
  with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for (p,n),r in zip(pairs,rows):
     item=tarfile.TarInfo(str(n));item.mode=0o644;item.mtime=0;item.size=r['bytes']
     with p.open('rb') as f:tar.addfile(item,f)
    payload=(json.dumps({'candidate':'C14','commit':COMMIT,'tree':TREE,'scope':scope,'files':rows},ensure_ascii=False,indent=2)+'\n').encode()
    item=tarfile.TarInfo('BUNDLE_MANIFEST.json');item.mode=0o644;item.mtime=0;item.size=len(payload);tar.addfile(item,io.BytesIO(payload))
 with tarfile.open(archive,'r:gz') as tar:
  actual={}
  for item in tar:
   assert item.isfile();f=tar.extractfile(item);h=hashlib.sha256();count=0
   for c in iter(lambda:f.read(1048576),b''):h.update(c);count+=len(c)
   actual[item.name]=(count,h.hexdigest())
  for r in rows:assert actual.pop(r['path'])==(r['bytes'],r['sha256']),r['path']
  assert set(actual)=={'BUNDLE_MANIFEST.json'}
 result={'name':name,'scope':scope,'members':len(rows),'uncompressedBytes':sum(r['bytes'] for r in rows),'archive':descriptor(archive,archive.name),'allMembersByteVerified':True}
 if archive.stat().st_size>64*1024*1024:
  parts=[]
  with archive.open('rb') as f:
   index=0
   while True:
    chunk=f.read(64*1024*1024)
    if not chunk:break
    part=dest/(archive.name+f'.part-{index:03d}');part.write_bytes(chunk);parts.append(descriptor(part,part.name));index+=1
  h=hashlib.sha256();count=0
  for r in parts:
   p=dest/r['path'];assert sha(p)==r['sha256']
   with p.open('rb') as f:
    for c in iter(lambda:f.read(1048576),b''):h.update(c);count+=len(c)
  assert count==result['archive']['bytes'] and h.hexdigest()==result['archive']['sha256']
  result['parts']=parts;result['splitRecombinedHashVerified']=True
  (dest/(name+'-split-manifest.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');archive.unlink()
 return result


COMMIT='9801e0ebcf3a8e8abb3f12b9d7a0f457000576bb';TREE='b86fc177e2476076033c9312bb126f42075a1af9';BUILD='3d25b03c26e1bbfa74cb'
PROOF=pathlib.Path('/tmp/shinariokanri-rb10-candidate-14');b=read(PROOF/'source-and-build-binding.json');assert b['commit']==COMMIT and b['tree']==TREE and b['build_info']['version']==BUILD
out=pathlib.Path('/workspace/shinariokanri-rb10-final-candidate-evidence/docs/quality/current-review/evidence/rb10-candidate/candidate-14-original-91-history-new-cold-and-incomplete-clone');assert not out.exists()
run=read(PROOF/'ci-run-final.json');jobs=read(PROOF/'ci-jobs-final.json');c=read(PROOF/'ci-checkout-commit-final.json');assert run['head_sha']==COMMIT and run['conclusion']=='success';assert c['commit']['tree']['sha']==TREE and c['sha']=='a1fccbe72170be56cdcd78a625830244f304edaf';assert len(jobs['jobs'][0]['steps'])==21 and all(s['conclusion']=='success' for s in jobs['jobs'][0]['steps'])
pairs=[]
for r in b['source_files']+b['original_documents']+b['artifact_files']+[b['generated_runtime']]:
 src=pathlib.Path('/workspace/shinariokanri-rb10-c14-frozen-inputs')/r['path'];assert src.stat().st_size==r['bytes'] and sha(src)==r['sha256'];pairs.append((src,pathlib.PurePosixPath('actual-frozen-c14')/r['path']))
for f in sorted(PROOF.iterdir()):
 if f.is_file():pairs.append((f,pathlib.PurePosixPath('source-binding-environment-and-CI')/f.name))
pairs.extend(enumerate_folder(pathlib.Path('/workspace/shinariokanri-rb10-c14-restore-proof'),'original-procedures-all-actual-attempts-and-files'))
input_file=pathlib.Path('/workspace/shinariokanri-rb10-c13-rg06-proof/results/original-three-forms-3/bare-actual-complete.scenario');assert sha(input_file)=='5fc45f32b1ef2a428e7cd0facbd7388b32f8a05edfc22dd0f28bb7f5bc4efd9a';pairs.append((input_file,pathlib.PurePosixPath('unchanged-original-failed-C13-file')/input_file.name))
for name in ['shinariokanri-rb10-c14-original-file-new-clone-1.txt','shinariokanri-rb10-c14-original-file-new-clone-2.txt','shinariokanri-rb10-c14-clean-build-1.txt','shinariokanri-bind-rb10-c14.py']:
 f=pathlib.Path('/tmp')/name
 if f.exists():pairs.append((f,pathlib.PurePosixPath('actual-root-logs-and-procedures')/name))
pairs.append((pathlib.Path(__file__),pathlib.PurePosixPath('archive-procedure')/pathlib.Path(__file__).name))
r2=read(pathlib.Path('/workspace/shinariokanri-rb10-c14-restore-proof/results/original-file-new-clone-2/raw.json'));assert len(r2['phases'])==1 and r2['phases'][0]['cold'] and not r2.get('result')
out.mkdir(parents=True);r=bundle(out,'fixed-C14-procedures-all-results-exact-file-and-partial-new-cold',pairs,'Historical C14 source420/all21CI/tempmerge same-tree. Exact formerC13 original8800+91history actualfile, attempt1 ownhistoryPage100 against unchangedmax60 stopped after normalnew; attempt2 originalpage60 all91metadata, originaloldrev8/new/current/cold passed, clone commit process vanished after20:41 withoutfinish. Whole procedure UNADJUDICATED, no clone/fullRG06/C15/native/performance/physical/live promotion.')
summary={'candidate':'C14','commit':COMMIT,'tree':TREE,'build':BUILD,'result':'partial_new_cold_verified_clone_unadjudicated_process_lost','actualOriginalFile':r2['file'],'newAndCold':{'records':r2['phases'][0]['current']['records'],'history':r2['phases'][0]['current']['historyCount'],'oldEdition':r2['phases'][0]['current']['oldEdition'],'saveState':r2['phases'][0]['current']['saveState'],'contentHash':r2['phases'][0]['cold']['contentHash']},'lastObservedCloneStage':r2['stage'],'lastObservationAt':r2['lastObservation']['at'],'cloneResult':'not_established','firstAttempt':'own_history_page_size100_rejected_before_native_proof_corrected_to_original_max60_fullpaging','readOnlyObserverTimeouts':len(r2['readOnlyObserverErrors']),'observerScope':'all retained diagnostic errors, notprogress/performance pass','CI':{'run':run['id'],'steps':21,'conclusion':'success','actualCheckoutCommit':c['sha'],'actualCheckoutTree':TREE},'archive':r,'oldTargetPromotion':0};(out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'MANIFEST.json').write_text(json.dumps({'candidate':'C14','commit':COMMIT,'tree':TREE,'files':[descriptor(p,p.name) for p in sorted(out.iterdir()) if p.is_file()]},ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
