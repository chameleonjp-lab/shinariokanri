import { A as e, B as t, C as n, F as r, I as i, L as a, M as o, N as s, P as c, S as l, d as u, f as d, l as f, n as p, p as m, r as h, u as g, w as _, z as v } from "./presentation-CcDrCHDQ.js";
//#region ../shinariokanri-rb10-shared-history-restore/src/domain/runtime.ts
var y = (e) => structuredClone(e);
function b(e) {
	if (e === void 0) return "undefined";
	if (typeof e != "object" || !e) return JSON.stringify(e);
	if (Array.isArray(e)) return `[${e.map(b).join(",")}]`;
	let t = e;
	return `{${Object.keys(t).filter((e) => t[e] !== void 0).sort().map((e) => `${JSON.stringify(e)}:${b(t[e])}`).join(",")}}`;
}
var x = (e, t) => b(e) === b(t), S = (e, t, n = "runtime") => ({
	code: e,
	message: t,
	path: n
}), C = (e) => e.filter(t), w = /* @__PURE__ */ new WeakMap(), T = /* @__PURE__ */ new WeakMap(), E = (e) => [...e.entities, ...T.get(e) ?? []], D = (e, t) => {
	let r = w.get(e);
	return r ? r.activeByKind.get(t) ?? [] : C(n(e, t));
}, O = (e, t) => {
	let n = w.get(e);
	return n ? n.byId.get(t) : _(e, t);
}, k = (e) => D(e, "flow_node"), A = (e) => D(e, "flow_edge"), j = (e) => D(e, "variable"), M = (e) => D(e, "flow_graph");
function N(e, t) {
	if (t === e.projectId) return e;
	let n = e.snapshots.find((e) => e.id === t);
	return n ? {
		...n.content,
		snapshots: e.snapshots,
		history: []
	} : void 0;
}
function P(e, n = []) {
	let { authorAlternatives: r, ...a } = e, o = {
		...y({
			...a,
			history: [],
			snapshots: []
		}),
		snapshots: e.snapshots
	}, s = i(o, e.snapshots), c = {
		byId: /* @__PURE__ */ new Map(),
		activeByKind: /* @__PURE__ */ new Map(),
		edgesFrom: /* @__PURE__ */ new Map()
	};
	T.set(s, y(n));
	for (let e of [...s.entities, ...T.get(s) ?? []]) {
		if (e.deletedAt || (c.byId.set(e.id, e), !t(e))) continue;
		let n = c.activeByKind.get(e.kind) ?? [];
		if (n.push(e), c.activeByKind.set(e.kind, n), e.kind === "flow_edge") {
			let t = c.edgesFrom.get(e.data.fromId) ?? [];
			t.push(e), c.edgesFrom.set(e.data.fromId, t);
		}
	}
	return w.set(s, c), s;
}
function F(e, t) {
	return t.content ?? N(e, t.state.contentVersionId) ?? e;
}
var I = (e, t) => {
	let n = t === null ? void 0 : O(e, t);
	return n?.kind === "flow_node" && n.status !== "rejected" ? n : void 0;
}, L = (e, t) => {
	let n = w.get(e);
	return n ? n.edgesFrom.get(t) ?? [] : A(e).filter((e) => e.data.fromId === t);
}, R = (e, t, n, r) => g(n ?? {
	op: "constant",
	value: !0
}, {
	state: t,
	variables: j(e),
	entities: E(e),
	externalValues: r
}), z = (e, t, n) => ({
	...e,
	nodeId: e.state.presentationPosition,
	status: t,
	issues: n
});
function B(e) {
	return e?.data.reuse && e.data.reuse.mode !== "clone" ? S("VALIDATION_FAILED", "共通元を固定版から解決する参照・上書き試読は未対応です。実行を停止しています。", `${e.id}.reuse`) : void 0;
}
function V(e) {
	return e && typeof e == "object" && "issues" in e && Array.isArray(e.issues) ? e.issues : [S("VALIDATION_FAILED", e instanceof Error ? e.message : "試読の入力を検証できません。")];
}
function H(e) {
	e = a(e);
	let t = M(e).filter((t) => t.projectId === e.projectId && !t.data.parentGraphId);
	return t.length > 0 ? [...new Set(t.flatMap((e) => e.data.entryIds))] : k(e).filter((t) => t.projectId === e.projectId && t.data.nodeType === "entry").map((e) => e.id);
}
function U(e) {
	let t = H(e);
	return t.length === 1 ? t[0] : void 0;
}
function W(e, t, n, r, i) {
	return p(e, t, {
		nodeId: n,
		externalValues: r,
		referenceEntities: T.get(e),
		worldTick: i
	});
}
function G(e, t) {
	try {
		return K(e, t);
	} catch {
		return [];
	}
}
function K(e, t) {
	let n = t.content ?? N(e, t.state.contentVersionId);
	if (!n) return [];
	e = n;
	let r = I(e, t.nodeId);
	if (!r || r.data.nodeType === "terminal") return [];
	let i = R(e, t.state, r.data.gate, t.externalValues);
	return L(e, r.id).map((n) => {
		let r = R(e, t.state, n.data.condition, t.externalValues), a = i.value === "false" || r.value === "false" ? "false" : i.value === "unknown" || r.value === "unknown" ? "unknown" : "true";
		return {
			edgeId: n.id,
			label: n.data.label || n.name || "次へ",
			toId: typeof n.data.toId == "string" ? n.data.toId : null,
			result: a,
			reasons: [...i.reasons, ...r.reasons],
			priority: n.data.priority ?? 0
		};
	}).sort((e, t) => e.priority - t.priority);
}
function q(e, t) {
	let n = I(e, t.nodeId);
	if (!n) return z(t, "error", [S("REFERENCE_INVALID", "現在の分岐が存在しません。")]);
	let r = B(n);
	if (r) return z(t, "error", [r]);
	if (n.data.nodeType === "terminal") return n.data.terminalReason?.trim() ? z(t, "terminal", []) : z(t, "error", [S("VALIDATION_FAILED", "終端には終了理由が必要です。", `${n.id}.terminalReason`)]);
	let i = R(e, t.state, n.data.gate, t.externalValues);
	if (i.value === "unknown") return z(t, "unknown", [S("CONDITION_UNKNOWN", i.reasons.join("、") || "発火条件の値が不足しています。", `${n.id}.gate`)]);
	if (i.value === "false") return n.data.fallbackId ? z(t, "ready", []) : z(t, "blocked", [S("TRANSITION_BLOCKED", "発火条件を満たさず、代替の進行先もありません。", `${n.id}.gate`)]);
	if (n.data.nodeType === "call" || n.data.nodeType === "exit" && t.state.callStack.length > 0) return z(t, "ready", []);
	let a = n.data.executionPolicy ?? (n.data.nodeType === "automatic" ? "first_match" : "manual_choice"), o = K(e, t);
	if (o.some((e) => !Number.isSafeInteger(e.priority))) return z(t, "error", [S("VALIDATION_FAILED", "優先値には安全な整数が必要です。", `${n.id}.priority`)]);
	if (a !== "manual_choice" && new Set(o.map((e) => e.priority)).size !== o.length) return z(t, "error", [S("VALIDATION_FAILED", "自動分岐の優先値が重複しています。", `${n.id}.priority`)]);
	let s = o.filter((e) => e.result === "unknown"), c = o.filter((e) => e.result === "true");
	return s.length > 0 && (a !== "manual_choice" || c.length === 0) ? z(t, "unknown", [S("CONDITION_UNKNOWN", "未確認の条件があり、進行先を確定できません。", n.id)]) : c.length === 0 && !n.data.fallbackId ? z(t, "blocked", [S("TRANSITION_BLOCKED", "有効な選択肢がありません。意図した終端とは別の行き止まりです。", n.id)]) : z(t, "ready", []);
}
function J(e, t = {}) {
	try {
		return Y(e, t);
	} catch (n) {
		let r = t.state ? y(t.state) : l(t.contentVersionId ?? e.projectId);
		return {
			content: e,
			state: r,
			nodeId: r.presentationPosition,
			contentRevision: e.revision,
			startState: y(r),
			startConditionResults: [],
			status: "error",
			history: [],
			trace: [],
			issues: V(n),
			lastDiff: [],
			externalValues: {},
			startExternalValues: {}
		};
	}
}
function Y(n, r = {}, i = !1) {
	let a = n, l = r.checkpointId ? a.entities.find((e) => e.id === r.checkpointId && e.kind === "checkpoint") : void 0;
	r.worldTick === void 0 && l?.data.worldTick != null && (r = {
		...r,
		worldTick: l.data.worldTick
	});
	let f = r.contentVersionId ?? n.projectId, p = i ? n : N(n, f);
	p && (n = p), i || (n = P(n, r.referenceEntities));
	let g = u(n, f, r.referenceEntities, r.externalValues), _ = y(r.presentationResults ?? []), b = r.presentationState ? y(r.presentationState) : void 0, C, w, D, k = p && (!n.worldReferences.length || r.referenceEntities) ? void 0 : S("REFERENCE_INVALID", "指定した不変作品版が見つかりません。", "contentVersionId");
	for (let [e, i] of Object.entries(r.externalValues ?? {})) {
		let r = n.entities.find((n) => n.id === e && n.kind === "external_contract" && t(n));
		(!r || r.kind !== "external_contract" || i.type !== r.data.outputType || i.type === "integer" && !Number.isSafeInteger(i.value) || i.type === "enum" && typeof i.value != "string" || i.type === "boolean" && typeof i.value != "boolean") && (k = S("VALIDATION_FAILED", "外部管理値の契約・型・範囲が不正です。", e));
	}
	if (r.worldTick !== void 0 && !c(r.worldTick) && (k = S("VALIDATION_FAILED", "提示時点には整数の世界内tickを入力してください。", "worldTick")), r.checkpointId) {
		let t = O(a, r.checkpointId);
		!t || t.kind !== "checkpoint" || t.deletedAt ? k = S("REFERENCE_INVALID", "指定した途中開始の記録が存在しません。", "checkpointId") : t.data.contentVersionId !== f || t.data.runtimeState.contentVersionId !== f || t.data.contentRevision != null && t.data.contentRevision !== n.revision ? k = S("VALIDATION_FAILED", "開始状態と作品版が違います。移行または再作成が必要です。", `${t.id}.contentVersionId`) : (g = y(t.data.runtimeState), _ = y(t.data.presentationResults ?? []), b = t.data.presentationState ? y(t.data.presentationState) : void 0, g.provenance = g.provenance === "stub" ? "stub" : g.provenance === "imported" || t.data.origin === "imported" ? "imported" : g.provenance === "partial" || t.data.origin !== "full_play" ? "partial" : "full_play", C = t.id, t.data.presentationResults != null && (k = e(g, t.data.presentationResults, n.entities, `${t.id}.presentationResults`)[0]));
	} else r.state && (r.state.contentVersionId === f ? (g = y(r.state), r.presentationResults != null && (k = e(g, r.presentationResults, n.entities)[0]), g.provenance === "full_play" && (g.provenance = "partial")) : k = S("VALIDATION_FAILED", "指定した開始状態と作品版が違います。", "state.contentVersionId"));
	r.seed !== void 0 && (g.rngSeed = r.seed);
	let A = r.entryId ?? g.presentationPosition ?? U(n);
	if (!k) {
		let e = o(g);
		e.ok || (k = e.issues[0]);
		for (let [e, t] of Object.entries(g.variableValues)) {
			let r = j(n).find((t) => t.id === e), i = r ? s(r, t, `${e}.value`) : [S("REFERENCE_INVALID", "開始状態に対象版の宣言がない状態値があります。", e)];
			if (i.length) {
				k = i[0];
				break;
			}
		}
		let t = h(n, {
			nodeId: A ?? void 0,
			worldTick: r.worldTick
		});
		k ||= m({
			state: g,
			variables: j(n),
			entities: E(n),
			externalValues: r.externalValues,
			ruleContext: t,
			ruleContexts: v(n, t)
		})[0];
	}
	if (C && g.provenance === "full_play") {
		let e = A && H(n).includes(A) ? Y(a, {
			contentVersionId: f,
			entryId: A,
			seed: g.rngSeed,
			externalValues: r.externalValues,
			worldTick: r.worldTick,
			referenceEntities: T.get(n)
		}) : void 0;
		(!e || e.status === "error" || !x(e.startState, g)) && (g.provenance = "partial");
	}
	if (r.entryId && !H(n).includes(r.entryId) && !C && (g.provenance = "partial"), !k && !A && (k = S("VALIDATION_FAILED", "開始点が一つに決まりません。入口を指定してください。", "entryId")), !k && !I(n, A ?? null) && (k = S("REFERENCE_INVALID", "指定した開始点が存在しません。", "entryId")), k ||= B(I(n, A ?? null)), !k && A) {
		if ((C || r.state) && g.presentationPosition && A !== g.presentationPosition && g.provenance !== "stub" && (g.provenance = "partial"), !(C || r.state) || A !== g.presentationPosition || (g.visitCounts[A] ?? 0) === 0 && !g.seenIds.includes(A)) {
			let e = W(n, g, A, r.externalValues, r.worldTick);
			if (e.ok) {
				g = e.state, _ = e.conditions, b = e.observationState;
				let t = I(n, A);
				if (t?.data.nodeType === "terminal") {
					let e = d(g, [
						...t.data.sceneId ? ["scene_end"] : [],
						...h(n, { nodeId: A }).chapterId ? ["chapter_end"] : [],
						"run_end"
					], {
						state: g,
						variables: j(n),
						entities: E(n),
						ruleContext: h(n, {
							nodeId: A,
							worldTick: r.worldTick
						}),
						ruleContexts: v(n, h(n, {
							nodeId: A,
							worldTick: r.worldTick
						}))
					});
					e.ok ? g = e.state : w = e.issues;
				}
			} else w = e.issues, D = A, g = {
				...g,
				presentationPosition: A
			};
		} else g.presentationPosition = A;
		r.entryId && !H(n).includes(r.entryId) && !C && (g.provenance = "partial");
	}
	b && (b.provenance = g.provenance);
	let M = {
		content: n,
		referenceEntities: y(T.get(n) ?? []),
		initialWorldTick: r.worldTick,
		declarationProject: y({
			...a,
			history: [],
			snapshots: [],
			authorAlternatives: void 0,
			entities: a.entities.filter((e) => [
				"collection",
				"trace",
				"checkpoint"
			].includes(e.kind))
		}),
		state: g,
		nodeId: g.presentationPosition,
		contentRevision: n.revision,
		startState: y(g),
		startConditionResults: _,
		startPresentationState: b,
		startCheckpointId: C,
		status: "ready",
		history: [],
		trace: [],
		issues: [],
		lastDiff: [],
		externalValues: y(r.externalValues ?? {}),
		startExternalValues: y(r.externalValues ?? {}),
		pendingPresentation: D
	};
	if (k) return z(M, k.code === "CONDITION_UNKNOWN" ? "unknown" : "error", [k]);
	if (r.stub) {
		let e = $(n, M, r.stub), t = e.trace.at(-1)?.presentationState ?? b;
		return {
			...e,
			history: [],
			trace: [],
			startState: y(e.state),
			startStubValues: y(r.stub),
			...r.state || r.checkpointId ? { startStubBaseState: y(M.state) } : {},
			startPresentationState: t ? {
				...y(t),
				provenance: e.state.provenance
			} : void 0,
			startConditionResults: e.trace.at(-1)?.conditionResults.length ? y(e.trace.at(-1).conditionResults) : _,
			startExternalValues: y(e.externalValues)
		};
	}
	return w ? z(M, w.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", w) : q(n, M);
}
function X(e, t) {
	let n = [];
	for (let r of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) {
		let i = e[r], a = t[r];
		if (!x(i, a)) {
			if ((r === "variableValues" || r === "visitCounts") && i && a) {
				let e = i, t = a;
				for (let i of /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(t)])) x(e[i], t[i]) || n.push({
					path: `${r}.${i}`,
					before: y(e[i]),
					after: y(t[i])
				});
			} else n.push({
				path: r,
				before: y(i),
				after: y(a)
			});
		}
	}
	return n;
}
function ee(e, t) {
	if (!Number.isSafeInteger(t) || t <= 0) throw RangeError("抽選候補は1件以上必要です。");
	if (!Number.isSafeInteger(e.rngPosition) || e.rngPosition < 0 || !Number.isSafeInteger(e.rngPosition + 1)) throw RangeError("抽選位置が許容範囲を超えます。");
	let n = 2166136261, r = `${e.rngSeed}\u0000${e.rngPosition}`;
	for (let e = 0; e < r.length; e++) n = Math.imul(n ^ r.charCodeAt(e), 16777619) >>> 0;
	return n ^= n >>> 16, n = Math.imul(n, 2246822507) >>> 0, n ^= n >>> 13, {
		index: (n >>> 0) % t,
		state: {
			...y(e),
			rngPosition: e.rngPosition + 1
		}
	};
}
function Z(e, t, n) {
	let r = e.data.trigger;
	if (!r) return {
		once: void 0,
		occurrence: void 0
	};
	let i = r.id ?? e.id, a = r.scope ?? "run", o = a === "across_runs" ? a : `${a}:${t.loopNumber}`;
	return {
		once: r.repeat === "once" ? `trigger:${o}:${i}` : void 0,
		occurrence: n.event ? `occurrence:${o}:${i}:${n.event.occurrenceId}` : void 0
	};
}
function te(e, t, n, i) {
	let a = t.data.trigger;
	if (!a) return;
	let o = Z(t, n, i);
	if (o.once && n.onceTriggers.includes(o.once)) return S("TRANSITION_BLOCKED", "この一回限りの発火は実行済みです。", `${t.id}.trigger`);
	if (!i.event || i.event.event !== a.event || i.event.eventKey !== a.eventKey || i.event.triggerId && i.event.triggerId !== (a.id ?? t.id)) return S("TRANSITION_BLOCKED", "宣言したきっかけの入力が必要です。条件の成立だけでは実行しません。", `${t.id}.trigger`);
	if (a.deadline) {
		let n = r(a.deadline, D(e, "event"));
		if (n.status === "conflict") return S("TIME_CONSTRAINT_CONFLICT", n.reason, `${t.id}.trigger.deadline`);
		if (n.status !== "resolved" || !c(i.worldTick) || n.calendarId !== e.calendarId) return S("CONDITION_UNKNOWN", "期限または現在の世界時点を確定できません。", `${t.id}.trigger.deadline`);
		let o = BigInt(i.worldTick), s = BigInt(n.endEarliest), l = BigInt(n.endLatest);
		if (o > l || a.deadline.mode === "interval" && o === l) return S("TRANSITION_BLOCKED", "発火期限を過ぎています。", `${t.id}.trigger.deadline`);
		if (o > s) return S("CONDITION_UNKNOWN", "期限の範囲内に現在時点があり、期限切れか確定できません。", `${t.id}.trigger.deadline`);
	}
}
function ne(e, t, n) {
	let r = [];
	n.data.gate && r.push({
		targetId: n.id,
		...R(e, t.state, n.data.gate, t.externalValues)
	});
	for (let i of L(e, n.id)) i.data.condition && r.push({
		targetId: i.id,
		...R(e, t.state, i.data.condition, t.externalValues)
	});
	return r;
}
function re(e, t, n, r, i, a, o) {
	let s = I(e, t.nodeId), c = I(e, r), l = h(e, { nodeId: s?.id }), u = h(e, { nodeId: r }), f = [];
	s?.data.sceneId && s.data.sceneId !== c?.data.sceneId && f.push("scene_end"), l.chapterId && l.chapterId !== u.chapterId && f.push("chapter_end");
	let p = d({
		...n,
		...n.resetCauses ? { resetCauses: [] } : {}
	}, f, {
		state: n,
		variables: j(e),
		entities: E(e),
		externalValues: t.externalValues,
		ruleContext: h(e, {
			nodeId: s?.id,
			worldTick: a.worldTick
		}),
		ruleContexts: v(e, h(e, {
			nodeId: s?.id,
			worldTick: a.worldTick
		}))
	});
	if (!p.ok) return z(t, "error", p.issues);
	let m = W(e, p.state, r, t.externalValues, a.worldTick);
	if (!m.ok) return z(t, m.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", m.issues);
	let g = [];
	c?.data.nodeType === "terminal" && (c.data.sceneId && g.push("scene_end"), u.chapterId && g.push("chapter_end"), g.push("run_end"));
	let _ = d(m.state, g, {
		state: m.state,
		variables: j(e),
		entities: E(e),
		externalValues: t.externalValues,
		ruleContext: h(e, {
			nodeId: r,
			worldTick: a.worldTick
		}),
		ruleContexts: v(e, h(e, {
			nodeId: r,
			worldTick: a.worldTick
		}))
	});
	if (!_.ok) return z(t, "error", _.issues);
	let b = _.state;
	c?.data.nodeType === "terminal" && (p.state.resetCauses || _.state.resetCauses) && (b.resetCauses = [...p.state.resetCauses ?? [], ..._.state.resetCauses ?? []]), o = [...o, ...m.conditions];
	let x = X(t.state, b).map((e) => ({
		...e,
		edgeIds: i
	})), S = {
		fromId: t.nodeId,
		toId: r,
		edgeIds: i,
		before: y(t.state),
		after: y(b),
		changes: x,
		request: y(a),
		conditionResults: o,
		presentationState: m.observationState,
		triggerId: I(e, t.nodeId)?.data.trigger?.id ?? (I(e, t.nodeId)?.data.trigger ? t.nodeId : void 0),
		externalValuesBefore: y(t.externalValues),
		externalValuesAfter: y(t.externalValues)
	};
	return q(e, {
		...t,
		state: b,
		nodeId: r,
		status: "ready",
		issues: [],
		lastDiff: x,
		history: [...t.history, {
			state: y(t.state),
			status: t.status,
			issues: y(t.issues),
			lastDiff: y(t.lastDiff),
			traceLength: t.trace.length,
			externalValues: y(t.externalValues),
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, S]
	});
}
function Q(e, t, n = {}) {
	if (t.status === "error" && t.nodeId === null) return t;
	try {
		return ie(e, t, n);
	} catch (e) {
		return z(t, "error", V(e));
	}
}
function ie(e, t, n = {}) {
	if (n.stub) return $(e, t, n.stub);
	let r = N(e, t.state.contentVersionId);
	if (!r) return z(t, "error", [S("REFERENCE_INVALID", "固定した作品版が存在しません。", "contentVersionId")]);
	if (e = r, t.contentRevision !== e.revision) return z(t, "error", [S("VALIDATION_FAILED", "作品が変更されました。この記録は再確認待ちです。試読を開始し直してください。", "contentRevision")]);
	if (e = t.content, t.pendingPresentation) return z(t, "unknown", t.issues.length ? t.issues : [S("CONDITION_UNKNOWN", "場面の提示条件を先に確認してください。", t.pendingPresentation)]);
	if (t.state.contentVersionId !== t.startState.contentVersionId) return z(t, "error", [S("VALIDATION_FAILED", "試読中に作品版が変わりました。", "contentVersionId")]);
	let i = n.event?.triggerId ?? I(e, t.nodeId)?.data.trigger?.id ?? (I(e, t.nodeId)?.data.trigger ? t.nodeId : void 0);
	if (n.event && i && t.trace.some((e) => e.triggerId === i && e.request.event?.occurrenceId === n.event?.occurrenceId)) return t;
	let a = I(e, t.nodeId);
	if (a && n.event) {
		let e = Z(a, t.state, n).occurrence;
		if (e && t.state.onceTriggers.includes(e)) return t;
	}
	let o = q(e, t);
	if (o.status !== "ready") return o;
	let s = I(e, t.nodeId), c = te(e, s, t.state, n);
	if (c) return z(t, c.code === "CONDITION_UNKNOWN" ? "unknown" : c.code === "TIME_CONSTRAINT_CONFLICT" ? "error" : "blocked", [c]);
	let l = R(e, t.state, s.data.gate, t.externalValues), u = ne(e, t, s), d = y(t.state), p = [], m;
	if (l.value === "false") m = s.data.fallbackId ?? void 0;
	else if (s.data.nodeType === "exit" && d.callStack.length > 0) {
		let n = O(e, d.callStack.at(-1).graphId);
		if (!n || n.kind !== "flow_graph" || !n.data.exitIds.includes(s.id)) return z(t, "error", [S("REFERENCE_INVALID", "現在の出口が呼出中グラフの宣言した出口に含まれていません。", s.id)]);
		m = d.callStack.pop().returnNodeId;
	} else if (s.data.nodeType === "call") {
		let n = s.data.childGraphId ? O(e, s.data.childGraphId) : void 0;
		if (!n || n.kind !== "flow_graph" || n.data.entryIds.length !== 1) return z(t, "error", [S("REFERENCE_INVALID", "呼出先に一つの入口を持つ子グラフが必要です。", `${s.id}.childGraphId`)]);
		let r = L(e, s.id).filter((e) => e.data.edgeType === "call_return");
		if (r.length !== 1 || typeof r[0].data.toId != "string") return z(t, "error", [S("REFERENCE_INVALID", "呼出には一つの確定した戻り先が必要です。", s.id)]);
		let i = R(e, t.state, r[0].data.condition, t.externalValues);
		if (i.value === "unknown") return z(t, "unknown", [S("CONDITION_UNKNOWN", i.reasons.join("、") || "呼出の戻り先条件が未確認です。", r[0].id)]);
		if (i.value === "false") {
			if (!s.data.fallbackId) return z(t, "blocked", [S("TRANSITION_BLOCKED", "呼出の戻り先条件を満たしていません。", r[0].id)]);
			m = s.data.fallbackId;
		} else {
			p = r, m = n.data.entryIds[0];
			let e = {};
			for (let t of n.data.parameters ?? []) e[t.key] = y(t.default ?? {
				type: "unknown",
				value: null,
				reason: "呼出引数が未設定です。"
			});
			d.callStack.push({
				graphId: n.id,
				returnNodeId: r[0].data.toId,
				parameters: e
			});
		}
	} else {
		let r = s.data.executionPolicy ?? (s.data.nodeType === "automatic" ? "first_match" : "manual_choice"), i = G(e, t), a = i.filter((e) => e.result === "true");
		if (a.length === 0) m = s.data.fallbackId ?? void 0;
		else if (r === "manual_choice") {
			let r;
			if (n.random) {
				if (i.some((e) => e.result === "unknown")) return z(t, "unknown", [S("CONDITION_UNKNOWN", "未確認の抽選候補が残っています。", s.id)]);
				let e;
				try {
					e = ee(d, a.length);
				} catch {
					return z(t, "error", [S("TRANSITION_BLOCKED", "抽選位置が許容範囲を超えます。", "rngPosition")]);
				}
				d = e.state, r = a[e.index];
			} else r = i.find((e) => e.edgeId === n.edgeId);
			if (!r) return z(t, "blocked", [S("TRANSITION_BLOCKED", "進む選択肢を指定してください。", s.id)]);
			if (r.result !== "true") return z(t, r.result === "unknown" ? "unknown" : "blocked", [S(r.result === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED", r.reasons.join("、") || "この選択肢の条件は成立していません。", r.edgeId)]);
			p = L(e, s.id).filter((e) => e.id === r.edgeId);
		} else p = (r === "first_match" ? a.slice(0, 1) : a).map((e) => e.edgeId).map((t) => L(e, s.id).find((e) => e.id === t));
		if (p.length > 0) {
			if (new Set(p.map((e) => typeof e.data.toId == "string" ? e.data.toId : null)).size !== 1) return z(t, "error", [S("VALIDATION_FAILED", "all_matchの進行先が異なります。同じ進行先を指定してください。", s.id)]);
			let e = p[0].data.toId;
			typeof e == "string" && (m = e);
		}
	}
	if (!m || !I(e, m)) return z(t, "error", [S("REFERENCE_INVALID", "進行先が未完成、または存在しません。", s.id)]);
	let g = B(I(e, m));
	if (g) return z(t, "error", [g]);
	let _ = [];
	for (let n of p) for (let r of n.data.effectIds ?? []) {
		let i = O(e, r);
		if (!i || i.kind !== "effect" || i.deletedAt || i.status === "rejected") return z(t, "error", [S("REFERENCE_INVALID", i?.status === "rejected" ? "分岐に不採用の効果が指定されています。" : "分岐に指定した効果が存在しないか、削除済みです。", `${n.id}.effectIds`)]);
		_.push(i);
	}
	let b = f(d, _, {
		state: d,
		variables: j(e),
		entities: E(e),
		externalValues: t.externalValues,
		ruleContext: h(e, {
			nodeId: s.id,
			worldTick: n.worldTick
		}),
		ruleContexts: v(e, h(e, {
			nodeId: s.id,
			worldTick: n.worldTick
		}))
	});
	if (!b.ok) return z(t, b.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", b.issues);
	d = b.state;
	let x = Z(s, t.state, n);
	return d.onceTriggers = [.../* @__PURE__ */ new Set([...d.onceTriggers, ...[x.once, x.occurrence].filter((e) => e !== void 0)])], re(e, o, d, m, p.map((e) => e.id), n, u);
}
function $(e, t, n) {
	try {
		return ae(e, t, n);
	} catch (e) {
		return z(t, "error", V(e));
	}
}
function ae(e, t, n) {
	let r = N(e, t.state.contentVersionId);
	if (!r || r.revision !== t.contentRevision) return z(t, "error", [S("VALIDATION_FAILED", "作品版が変わりました。仮値を適用する前に開始し直してください。", "contentRevision")]);
	e = t.content;
	let i = y(t.externalValues);
	for (let [r, a] of Object.entries(n.external ?? {})) {
		let n = O(e, r);
		if (!n || n.kind !== "external_contract") return z(t, "error", [S("REFERENCE_INVALID", "仮の外部値には宣言した外部契約が必要です。", r)]);
		if (n.data.outputType !== a.type && a.type !== "unknown") return z(t, "error", [S("VALIDATION_FAILED", "仮の外部値と宣言した出力型が違います。", r)]);
		i[r] = y(a);
	}
	let a = Object.entries(n.variables ?? {}).map(([e, t]) => ({
		operation: "set",
		targetId: e,
		value: t
	})), o = f(t.state, a, {
		state: t.state,
		variables: j(e),
		entities: E(e),
		externalValues: i
	});
	if (!o.ok) return z(t, o.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", o.issues);
	let s = {
		...o.state,
		provenance: "stub"
	}, c = t.pendingPresentation, l = [], u;
	if (c) {
		let n = W(e, s, c, i, t.initialWorldTick);
		if (!n.ok) return z(t, n.issues.some((e) => e.code === "CONDITION_UNKNOWN") ? "unknown" : "error", n.issues);
		s = {
			...n.state,
			provenance: "stub"
		}, l = n.conditions, u = n.observationState, c = void 0;
	}
	let d = X(t.state, s);
	for (let e of /* @__PURE__ */ new Set([...Object.keys(t.externalValues), ...Object.keys(i)])) x(t.externalValues[e], i[e]) || d.push({
		path: `externalValues.${e}`,
		before: y(t.externalValues[e]),
		after: y(i[e])
	});
	let p = {
		...t,
		state: s,
		externalValues: i,
		issues: [],
		lastDiff: d,
		pendingPresentation: c,
		history: [...t.history, {
			state: y(t.state),
			externalValues: y(t.externalValues),
			status: t.status,
			issues: y(t.issues),
			lastDiff: y(t.lastDiff),
			traceLength: t.trace.length,
			pendingPresentation: t.pendingPresentation
		}],
		trace: [...t.trace, {
			fromId: t.nodeId,
			toId: t.nodeId,
			edgeIds: [],
			before: y(t.state),
			after: y(s),
			conditionResults: l,
			...u ? { presentationState: u } : {},
			changes: d,
			request: { stub: y(n) },
			externalValuesBefore: y(t.externalValues),
			externalValuesAfter: y(i)
		}]
	};
	return q(e, p);
}
function oe(e, t, n) {
	let r = O(e, t);
	if (!r || r.kind !== "trace") return z(J(e), "error", [S("REFERENCE_INVALID", "保存した経路記録が存在しません。", t)]);
	let i = J(e, {
		checkpointId: r.data.startCheckpointId,
		contentVersionId: r.data.contentVersionId,
		referenceEntities: n,
		worldTick: r.data.initialWorldTick ?? void 0
	}), a = F(e, i);
	if (r.data.contentRevision != null && r.data.contentRevision !== a.revision) return z(i, "error", [S("VALIDATION_FAILED", "経路記録の作品版が変更されました。再確認が必要です。", `${t}.contentRevision`)]);
	if (i.status === "error") return i;
	let o = e.entities.find((e) => e.id === r.data.startCheckpointId && e.kind === "checkpoint");
	if (r.data.initialWorldTick != null && o?.data.worldTick != null && r.data.initialWorldTick !== o.data.worldTick) return z(i, "error", [S("INTEGRITY_FAILED", "保存した開始時点と経路の初期提示時点が一致しません。", `${t}.initialWorldTick`)]);
	if (r.data.initialStubValues) {
		let a = J(e, {
			...r.data.initialStubBaseState ? { state: y(r.data.initialStubBaseState) } : {},
			entryId: i.startState.presentationPosition ?? void 0,
			contentVersionId: r.data.contentVersionId,
			referenceEntities: n,
			seed: i.startState.rngSeed,
			worldTick: r.data.initialWorldTick ?? o?.data.worldTick ?? void 0,
			stub: y(r.data.initialStubValues)
		});
		if (a.status === "error" || !x(a.startState, i.startState) || !x(a.startExternalValues, r.data.initialExternalValues ?? {})) return z(i, "error", [S("INTEGRITY_FAILED", "保存した初期stub入力と固定版の開始状態が一致しません。", `${t}.initialStubValues`)]);
	}
	i.externalValues = y(r.data.initialExternalValues ?? {}), i.startExternalValues = y(i.externalValues), i.startStubValues = r.data.initialStubValues ? y(r.data.initialStubValues) : void 0, i.startStubBaseState = r.data.initialStubBaseState ? y(r.data.initialStubBaseState) : void 0;
	for (let [n, o] of r.data.steps.entries()) {
		if (!x(i.state, o.before)) return z(i, "error", [S("VALIDATION_FAILED", "保存した開始状態と経路の直前状態が一致しません。", `${t}.steps[${n}].before`)]);
		let r = {};
		if (o.operation === "stub" || o.operation === void 0 && o.edgeIds.length === 0 && o.before.presentationPosition === o.after.presentationPosition && x(o.before.visitCounts, o.after.visitCounts) && o.after.provenance === "stub") {
			let e = {};
			for (let t of j(a)) !t.data.derived && !x(o.before.variableValues[t.id], o.after.variableValues[t.id]) && (e[t.id] = y(o.after.variableValues[t.id]));
			r = { stub: {
				variables: e,
				external: o.externalValues ?? i.externalValues
			} };
		} else {
			i.externalValues = y(o.externalValues ?? i.externalValues);
			let e = I(a, i.nodeId);
			r.edgeId = o.edgeIds[0], o.after.rngPosition === o.before.rngPosition + 1 && (r.random = !0), e?.data.trigger && (r.event = {
				triggerId: e.data.trigger.id ?? e.id,
				event: e.data.trigger.event,
				eventKey: e.data.trigger.eventKey,
				occurrenceId: o.occurrenceId ?? `replay:${n}`
			}), r.worldTick = o.worldTick;
		}
		if (i = Q(e, i, r), i.status === "error") return i;
		if (o.conditionResults && !x(i.trace.at(-1)?.conditionResults, o.conditionResults)) return z(i, "error", [S("VALIDATION_FAILED", "保存した提示時の条件結果と再実行が一致しません。", `${t}.steps[${n}].conditionResults`)]);
		if (o.presentationState && !x(o.presentationState, i.trace.at(-1)?.presentationState)) return z(i, "error", [S("INTEGRITY_FAILED", "保存した提示前の観測状態と再実行が一致しません。", `${t}.steps[${n}].presentationState`)]);
		if (!x(i.state, o.after)) return z(i, "error", [S("VALIDATION_FAILED", "保存した経路と再実行の状態が一致しません。", `${t}.steps[${n}].after`)]);
	}
	return i;
}
//#endregion
export { oe as replaySavedTrace, J as startTrial, Q as stepTrial };
