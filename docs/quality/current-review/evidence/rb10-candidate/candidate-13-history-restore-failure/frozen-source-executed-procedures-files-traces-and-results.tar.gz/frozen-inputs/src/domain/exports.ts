import type { Entity, ID, ProjectContent, ProjectData, ProjectSnapshot, RichText, TypedValue } from './types';
import portableScript from '../portable/generated/runtime.js?raw';
import { portableRuntimeProject } from './portableRuntimeProject';
import { sha256, jsonBytes } from '../storage/json';
import { prepareAsset } from './attachments';
import { dialogueContentHash } from './production';
import { validateProject,ENTITY_SCHEMAS,type Schema } from './model';
import { strToU8, zipSync } from 'fflate';
import { createProjection, PROJECTION_FIELDS } from './projection';
import { selectExportSource as selectSource, executionExportView, prepareExportCitations, validatePublicPositions, type CitationSource } from './exportPreparation';
import type { ProjectedBlock, ProjectedEntity, ProjectionIssue, ProjectionOmission, PublicProjection, PublicValue } from './projection';

export type ExportProfile = 'reader' | 'runtime_json' | 'localization' | 'production' | 'consultation' | 'playable_preview';
export interface ExportArtifact { filename: string; mimeType: string; content: string; bytes?: Uint8Array<ArrayBuffer> }
/** Preview is private author information. Only artifact.content is the deliverable. */
export interface ExportPreview {
  profile: ExportProfile;
  sourceRevision: string;
  /** Author-only provenance and ID map never enter downloadable payloads. */
  sourceVersionId?:ID;sourceContentHash?:string;sourceIdMap?:Record<ID,ID>;
  includedCount: number;
  omissions: ProjectionOmission[];
  warnings: string[];
  assetCount: number;
  assetBytesIncluded: boolean;
}
export type ExportResult =
  | { ok: true; artifact: ExportArtifact; artifacts: ExportArtifact[]; preview: ExportPreview }
  | { ok: false; issues: ProjectionIssue[]; preview?: ExportPreview };
export interface RuntimeExportProfile {
  profileId: string;
  profileVersion: string;
  schemaVersion: '1.0.0';
  supportedNodeTypes: readonly string[];
  supportedConditions: readonly string[];
  supportedEffects: readonly string[];
  externalContracts: readonly string[];
  assetTypes: readonly string[];
  omissions: readonly string[];
}
export const GENERIC_RUNTIME_PROFILE: Readonly<RuntimeExportProfile> = Object.freeze({
  profileId: 'scenario-runtime', profileVersion: '1.1.0', schemaVersion: '1.0.0',
  supportedNodeTypes: Object.freeze(['scene', 'choice', 'automatic', 'call', 'entry', 'exit', 'terminal']),
  supportedConditions: Object.freeze(['constant', 'all', 'any', 'not', 'compare', 'item', 'known', 'visited', 'external']),
  supportedEffects: Object.freeze(['set', 'add', 'grant', 'consume', 'move', 'assert', 'mark_seen', 'reset']),
  externalContracts: Object.freeze(['boolean', 'integer', 'enum']),
  assetTypes: Object.freeze(['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'audio/wav', 'audio/mpeg', 'application/pdf', 'video/mp4', 'video/webm', 'video/ogg', 'audio/ogg', 'text/plain', 'application/json', 'application/octet-stream']),
  omissions: Object.freeze(['author_notes', 'rejected_and_alternate_records', 'private_names_and_aliases', 'original_source_ids_unless_explicitly_approved', 'asset_bytes', 'playtest_traces']),
});
export const PLAYABLE_PREVIEW_PROFILE: Readonly<RuntimeExportProfile> = GENERIC_RUNTIME_PROFILE;
export interface ExportOptions {
  profile: ExportProfile;
  projectionProfileId: ID;
  /** Exactly one version selector is required; never fall back from a snapshot to live text. */
  targetRevision?: string;
  targetVersionId?: ID;
  readerFormat?: 'markdown' | 'html';
  writingMode?: 'horizontal' | 'vertical';
  runtimeProfile?: RuntimeExportProfile;
  sourceLanguage?: string;
  /** Filters production deliverables by authored task assignment; identity IDs stay private. */
  assigneeId?: ID;
  worldSnapshots?: Record<ID, ProjectContent>;
  worldPins?:readonly Pick<ProjectSnapshot,'id'|'contentHash'|'content'>[];
  /** Captured verified bytes. Metadata-only output explicitly records their absence. */
  assetBytes?: Record<string, Uint8Array>;
  consultationContext?: { focusIds?: ID[]; beforeValues?: Record<ID, TypedValue>; afterValues?: Record<ID, TypedValue> };
}
const record = (value: unknown): Record<string, unknown> | undefined => value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
const has = (value: Record<string, unknown>, key: string) => Object.prototype.hasOwnProperty.call(value, key);
const revisionPattern = /^(?:0|[1-9][0-9]*)$/;

function canonical(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  return `{${Object.entries(value).filter(([, child]) => child !== undefined).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0).map(([key, child]) => `${JSON.stringify(key)}:${canonical(child)}`).join(',')}}`;
}
async function hash(value: unknown): Promise<string> {
  const bytes = new TextEncoder().encode(canonical(value));
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(value => value.toString(16).padStart(2, '0')).join('');
}

/** Captures the input before hashing, so editing during an export cannot mix versions. */
export async function exportProject(input: ProjectData, options: ExportOptions): Promise<ExportResult> {
  try { return await exportCapturedProject(input, structuredClone(options)); }
  catch(cause) {const message=cause instanceof Error&&/^(?:EXPORT_UNSUPPORTED|INTEGRITY_FAILED|REFERENCE_INVALID|IMPORT_LIMIT):/.test(cause.message)?cause.message:'出力に必要な情報または参照が不正です。作品を確認してください。';const details=cause&&typeof cause==='object'&&'issues' in cause&&Array.isArray(cause.issues)?cause.issues:[];return { ok: false, issues: details.length?details.map(issue=>({code:'VALIDATION_FAILED' as const,message:String(issue.message),field:String(issue.path??issue.field??'')})):[{ code:message.startsWith('EXPORT_UNSUPPORTED:')?'EXPORT_UNSUPPORTED':'VALIDATION_FAILED', message }] }; }
}
async function exportCapturedProject(input: ProjectData, options: ExportOptions): Promise<ExportResult> {
  let captured: ProjectData;
  try { captured = structuredClone(input); } catch { return { ok: false, issues: [{ code: 'VALIDATION_FAILED', message: '作品の出力内容を固定できませんでした。' }] }; }
  const selected = await selectSource(captured, options);
  if (!selected.ok) return selected;
  const authorProject = selected.project;
  const sourceValidation = validateProject(authorProject, {worldSnapshots: options.worldSnapshots ?? {}});
  if (!sourceValidation.ok) return { ok: false, issues: sourceValidation.issues.map(issue => ({ code: issue.code === 'REFERENCE_INVALID' ? 'REFERENCE_INVALID' as const : 'VALIDATION_FAILED' as const, message: issue.message, field: issue.path })) };
  const project = await executionExportView(captured, authorProject, options);
  const policyEntity = project.entities.find((entity): entity is Entity<'projection_profile'> => entity.id === options.projectionProfileId && entity.kind === 'projection_profile' && !entity.deletedAt);
  if (policyEntity?.data.sourceVersionId != null && policyEntity.data.sourceVersionId !== options.targetVersionId && policyEntity.data.sourceVersionId !== project.revision) return { ok: false, issues: [{ code: 'VALIDATION_FAILED', message: 'この公開範囲が対象とする版と、選択した版が一致しません。', entityId: policyEntity.id, field: 'sourceVersionId' }] };
  const executable = options.profile === 'runtime_json' || options.profile === 'playable_preview';
  const citations=await prepareExportCitations(captured,project,options,executable);
  const result = createProjection(project, options.projectionProfileId, { strictReferences: executable, confirmedOnly: options.profile !== 'consultation', targetVersionId: options.targetVersionId,versionTargets:citations.targets });
  if(result.ok&&citations.versions.length)result.projection.versions=citations.versions;
  const preview: ExportPreview = {
    profile: options.profile, sourceRevision: project.revision,sourceVersionId:options.targetVersionId??authorProject.projectId,sourceContentHash:await sha256(jsonBytes({...authorProject,history:[]})),sourceIdMap:result.ok?result.idMap:undefined, includedCount: result.ok ? result.projection.entities.length : 0,
    omissions: result.omissions, warnings: ['公開用の文面は作者が内容を確認してください。文章から秘密を自動で判定する機能ではありません。'],
    assetCount: result.ok ? [result.projection,...citations.versions.map(version=>version.projection)].reduce((count,edition)=>count+edition.entities.filter(entity=>entity.kind==='attachment').length,0) : 0, assetBytesIncluded: false,
  };
  if (!result.ok) return { ok: false, issues: result.issues, preview };
  const projection = result.projection;
  const positions=validatePublicPositions(projection);if(positions.length)return {ok:false,issues:positions,preview};
  const policy = policyEntity!.data;
  const publicVersionLabel = policy.publicVersionLabel ?? '公開版';
  const artifact = (filename: string, mimeType: string, content: string): ExportArtifact => ({ filename, mimeType, content });
  const succeed = (artifacts: ExportArtifact[]): ExportResult => ({ ok: true, artifact: artifacts[0], artifacts, preview });
  if (preview.assetCount) preview.warnings.push('この出力に素材bytesは含まれません。素材の対応と取得状況は別に確認してください。');
  if (projection.calendars.length) preview.warnings.push('公開用の暦・月・原点のラベルは匿名の表記に置き換えます。tickと暦の数値定義は保持します。');
  switch (options.profile) {
    case 'reader': {
      const format = options.readerFormat ?? 'markdown';
      return succeed([artifact(`reader.${format === 'html' ? 'html' : 'md'}`, format === 'html' ? 'text/html;charset=utf-8' : 'text/markdown;charset=utf-8', format === 'html' ? renderReaderHtml(projection, publicVersionLabel, options.writingMode ?? 'horizontal') : renderReaderMarkdown(projection, publicVersionLabel))]);
    }
    case 'runtime_json': {
      const runtimeProfile = options.runtimeProfile ?? GENERIC_RUNTIME_PROFILE;
      const issues = runtimeCapabilityIssues(project,projection,result.idMap,policy,runtimeProfile,citations.sources);
      if (issues.length) return { ok: false, issues, preview };
      const includedAssets = await exportAllAssetBytes(project,projection,result.idMap,citations.sources,options.assetBytes);
      const portable=await portableRuntimeProject(projection);
      preview.assetBytesIncluded = includedAssets.complete&&Object.keys(includedAssets.data).length>0;
      if(preview.assetBytesIncluded)preview.warnings=preview.warnings.filter(w=>!w.includes('素材bytesは含まれません'));
      const contentVersionId=`sha256:${await hash(projection)}`;
      const payload = {
        format: 'scenario-runtime', formatVersion: '1.0.0',requiredFeatures:['runtime-project-1','lifecycle-1','presentation-1','reuse-flattening-1','finite-exceptions-1'], profile: publicRuntimeProfile(runtimeProfile,preview.assetBytesIncluded), title: projection.title, versionLabel: publicVersionLabel, contentVersionId,
        hashScope: 'public_projection',
        entities: projection.entities, relations: projection.relations, calendars: projection.calendars,
        flow: { graphs: byKind(projection, 'flow_graph'), nodes: byKind(projection, 'flow_node'), edges: byKind(projection, 'flow_edge') },
        dialogue: byKind(projection, 'dialogue_line'), scenes: byKind(projection, 'scene'), characters: byKind(projection, 'character'),
        variables: byKind(projection, 'variable'), effects: byKind(projection, 'effect'), items: byKind(projection, 'item'), assertions: byKind(projection, 'assertion'),
        quests: byKind(projection, 'quest'), disclosures: byKind(projection, 'disclosure'), cues: byKind(projection, 'cue'),
        externalContracts: byKind(projection, 'external_contract'), assets: byKind(projection, 'attachment'),
        externalEvidence: 'not_included', publicProjection:projection, assetBytesIncluded: includedAssets.complete&&Object.keys(includedAssets.data).length>0, runtimeProject:portable.project, runtimeProjectHash:await sha256(jsonBytes(portable.project)), publicToRuntime:portable.publicToRuntime, assetData:includedAssets.data,
      };
      return succeed([artifact('runtime.json', 'application/json;charset=utf-8', JSON.stringify(payload, null, 2))]);
    }
    case 'localization': case 'production': {
      const issues = stableIdIssues(result.idMap, policy);
      for (const entity of projection.entities) if (entity.kind === 'localization' || entity.kind === 'recording') {
        if (typeof entity.data.sourceLineId !== 'string' || !projection.entities.some(line => line.kind === 'dialogue_line' && line.id === entity.data.sourceLineId)) issues.push({ code: 'REFERENCE_INVALID', message: '翻訳・収録の元台詞を公開範囲に含めてください。', field: 'sourceLineId' });
        if (typeof entity.data.language !== 'string' || !validLanguage(entity.data.language)) issues.push({ code: 'VALIDATION_FAILED', message: '翻訳・収録の公開用言語コードを指定してください。', field: 'language' });
      }
      if (issues.length) return { ok: false, issues, preview };
      const language = options.sourceLanguage ?? 'ja';
      if (!validLanguage(language)) return { ok: false, issues: [{ code: 'VALIDATION_FAILED', message: '有効な言語コードを指定してください。', field: 'sourceLanguage' }], preview };
      let assigned: Set<ID> | undefined;
      if (options.assigneeId) {
        assigned = new Set(project.entities.filter(entity => entity.kind === 'production_task' && !entity.deletedAt && !['rejected', 'alternate'].includes(entity.status) && entity.data.assigneeId === options.assigneeId).flatMap(entity => entity.kind === 'production_task' ? entity.data.targetIds : []));
        const pending=[...assigned];for(let at=0;at<pending.length;at++){const target=project.entities.find(entity=>entity.id===pending[at]),children=target?.kind==='chapter'?target.data.sceneIds:target?.kind==='scene'?target.data.dialogueLineIds??[]:[];for(const id of children)if(!assigned.has(id)){assigned.add(id);pending.push(id);}}
        if (!assigned.size) return { ok: false, issues: [{ code: 'REFERENCE_INVALID', message: 'この担当者に対応する制作タスクの対象がありません。対象版・担当・公開範囲を確認してください。' }], preview };
      }
      const exportedLines = await localizedLines(project, projection, result.idMap, language, assigned);
      if (assigned && !exportedLines.length) return { ok: false, issues: [{ code: 'REFERENCE_INVALID', message: '担当の台詞・翻訳・収録が公開範囲にありません。公開範囲を確認してください。' }], preview };
      if (assigned) preview.warnings.push('作者が指定した制作タスクの担当範囲へ絞っています。担当者の識別情報は公開ファイルへ含めません。');
      const selectedLineIds = new Set(exportedLines.map(line => line.lineId));
      const assetIds = new Set(exportedLines.flatMap(line => line.recordings.flatMap(recording => recording.attachmentId ? [recording.attachmentId] : [])));
      for (const line of byKind(projection, 'dialogue_line').filter(line => selectedLineIds.has(line.id))) for (const cue of byKind(projection, 'cue').filter(cue => Array.isArray(line.data.cueIds) && line.data.cueIds.includes(cue.id))) if (typeof cue.data.attachmentId === 'string') assetIds.add(cue.data.attachmentId);
      const deliveredAssets=await exportAllAssetBytes(project,{...projection,entities:projection.entities.filter(entity=>entity.kind!=='attachment'||!assigned||assetIds.has(entity.id))},result.idMap,citations.sources,options.assetBytes);preview.assetBytesIncluded=deliveredAssets.complete&&Object.keys(deliveredAssets.data).length>0;
      const payload = { format: options.profile==='production'?'scenario-production':'scenario-localization', formatVersion: '1.0.0', title: projection.title, versionLabel: publicVersionLabel, hashScope: 'projected_line', lines: exportedLines, terminology: byKind(projection, 'terminology'),voiceRules:byKind(projection,'voice_rule'),citedVersions:projection.versions??[],...(options.profile==='production'?{tasks:byKind(projection,'production_task').filter(task=>!assigned||project.entities.some(entity=>entity.kind==='production_task'&&entity.data.assigneeId===options.assigneeId&&result.idMap[entity.id]===task.id)),scenes:byKind(projection,'scene').filter(scene=>!assigned||assigned.has(Object.keys(result.idMap).find(id=>result.idMap[id]===scene.id)??'')),cues:byKind(projection,'cue').filter(cue=>!assigned||exportedLines.some(line=>byKind(projection,'dialogue_line').find(source=>source.id===line.lineId)?.data.cueIds instanceof Array&&(byKind(projection,'dialogue_line').find(source=>source.id===line.lineId)!.data.cueIds as string[]).includes(cue.id))),storyboards:byKind(projection,'storyboard_frame').filter(frame=>!assigned||assigned.has(Object.keys(result.idMap).find(id=>result.idMap[id]===frame.id)??'')||project.entities.some(entity=>entity.kind==='storyboard_frame'&&result.idMap[entity.id]===frame.id&&assigned.has(entity.data.anchor.lineId??entity.data.anchor.entityId))),media:byKind(projection,'media_variant').filter(media=>!assigned||assigned.has(Object.keys(result.idMap).find(id=>result.idMap[id]===media.id)??''))}:{ }),assets: byKind(projection, 'attachment').filter(asset => !assigned || assetIds.has(asset.id)),assetData:deliveredAssets.data,assetBytesIncluded:preview.assetBytesIncluded };
      if(preview.assetBytesIncluded)preview.warnings=preview.warnings.filter(w=>!w.includes('素材bytesは含まれません'));
      preview.warnings.push('台詞hashは公開用本文・ルビ・話者・演出から計算します。作者原稿のhashは公開ファイルに含めません。');
      return succeed([
        artifact(options.profile==='production'?'production.json':'localization.json', 'application/json;charset=utf-8', JSON.stringify(payload, null, 2)),
        artifact(options.profile==='production'?'production.md':'localization.md', 'text/markdown;charset=utf-8', renderLocalizationMarkdown(projection.title, publicVersionLabel, exportedLines)),
      ]);
    }
    case 'consultation': {
      const context = consultationContext(projection, project, result.idMap, policy, options.consultationContext);
      if (!context.ok) return { ok: false, issues: context.issues, preview };
      const content = `${renderReaderMarkdown(projection, publicVersionLabel)}\n## 相談の対象\n\n${context.markdown}\n## 参照ID\n\n${projection.entities.map(entity => `- ${escapeMarkdown(entity.id)}: ${escapeMarkdown(entity.name)} (${escapeMarkdown(entity.kind)})`).join('\n')}\n\nこのファイルは手動で持ち出す相談資料です。取り込んだ提案は作者別案として扱います。\n`;
      return succeed([artifact('consultation.md', 'text/markdown;charset=utf-8', content)]);
    }
    case 'playable_preview': {
      const issues = runtimeCapabilityIssues(project,projection,result.idMap,policy,PLAYABLE_PREVIEW_PROFILE,citations.sources);
      if (issues.length) return { ok: false, issues, preview };
      const assets=await exportAllAssetBytes(project,projection,result.idMap,citations.sources,options.assetBytes);
      if(!assets.complete)return {ok:false,issues:[{code:'REFERENCE_INVALID',message:'試遊に含める素材bytesが不足しています。完全保存から復元して再検査してください。'}],preview};
      preview.assetBytesIncluded=assets.complete&&Object.keys(assets.data).length>0;
      const output = await buildPlayableArchive(projection, publicVersionLabel,assets);
      preview.warnings=preview.warnings.filter(w=>!w.includes('素材bytesは含まれません'));
      preview.warnings.push('本体と同じ状態・物品・知識・提示・再利用の実行器を含みます。外部値の仮入力はstubとして記録し、実ゲームの確認結果へ換算しません。');
      return succeed([output]);
    }
    default: return { ok: false, issues: [{ code: 'EXPORT_UNSUPPORTED', message: 'この出力目的には対応していません。' }], preview };
  }
}

function byKind(projection: PublicProjection, kind: ProjectedEntity['kind']): ProjectedEntity[] { return projection.entities.filter(entity => entity.kind === kind); }
function publicRuntimeProfile(profile: RuntimeExportProfile,bytesIncluded=false): RuntimeExportProfile {
  return { profileId: profile.profileId, profileVersion: profile.profileVersion, schemaVersion: profile.schemaVersion,
    supportedNodeTypes: [...profile.supportedNodeTypes], supportedConditions: [...profile.supportedConditions], supportedEffects: [...profile.supportedEffects],
    externalContracts: [...profile.externalContracts], assetTypes: [...profile.assetTypes], omissions: GENERIC_RUNTIME_PROFILE.omissions.filter(omission=>omission!=='asset_bytes'||!bytesIncluded) };
}
function stableIdIssues(idMap: Record<string, string>, policy: Entity<'projection_profile'>['data']): ProjectionIssue[] {
  return policy.idPolicy !== 'preserve' && Object.keys(idMap).some(id => !policy.publicIds?.[id]&&!Object.entries(policy.blockSources??{}).some(([publicBlock,sourceBlock])=>sourceBlock===id&&policy.publicIds?.[publicBlock]))
    ? [{ code: 'EXPORT_UNSUPPORTED', message: '制作出力には安定した公開IDを全対象へ指定するか、選択した正本IDの公開を明示してください。', field: 'publicIds' }]
    : [];
}
function presentationDisclosures(project: ProjectData, idMap: Record<string, string>): Entity<'disclosure'>[] {
  const anchors = new Set<ID>();
  for (const entity of project.entities) if (entity.kind === 'flow_node' && has(idMap, entity.id)) {
    anchors.add(entity.id);
    if (entity.data.sceneId) anchors.add(entity.data.sceneId);
  }
  // Arrival anchors target the active node or its scene. Retain every such
  // dependency conservatively, including anchors with a blockId or lineId.
  return project.entities.filter((entity): entity is Entity<'disclosure'> => entity.kind === 'disclosure' && !entity.deletedAt && entity.status !== 'rejected' && anchors.has(entity.data.anchor.entityId));
}
const SAFE_RUNTIME_OMISSIONS: Readonly<Record<string, readonly string[]>> = {
  note:['handoffReceipt','originNoteId','convertedToIds'],
  character: ['aliases', 'authorNotes', 'goals', 'voiceRules'], group: [], event: ['authorNotes', 'constraints'], place: ['aliases', 'changes'], item: ['changes'],
  scene: ['authorNotes', 'goals', 'conflicts', 'results', 'newInformation'], chapter: ['authorNotes', 'structureRole'], dialogue_line: ['originLineIds', 'replacedByLineIds', 'lineage'],
  variable: [], flow_node: [], flow_edge: [], flow_graph: [], effect: [], assertion: [], foreshadow: [], disclosure: [],
  attachment: ['assetPath', 'licenseNote', 'provenanceId', 'stage', 'revisionHistory', 'mediaType', 'contentHash', 'byteSize'], source: ['accessedAt', 'excerptLocation', 'attachmentId'],
  external_contract:['adapterProfileIds'],
  cue: ['stage'], quest: ['gameplaySpecIds'], lore: ['aliases', 'sourceIds'], recording: ['sourceHash', 'notes', 'reviewedBy'], localization: ['sourceHash', 'reviewedBy'],
};
function runtimeCapabilityIssues(project:ProjectData,projection:PublicProjection,idMap:Record<string,string>,policy:Entity<'projection_profile'>['data'],profile:RuntimeExportProfile,citations:readonly CitationSource[]){
 const issues=validateRuntimeExport(project,projection,idMap,policy,profile);
 for(const citation of citations){const policy=citation.project.entities.find((entity):entity is Entity<'projection_profile'>=>entity.id===citation.profileId&&entity.kind==='projection_profile');if(!policy)issues.push({code:'REFERENCE_INVALID',message:'引用版の公開範囲がありません。'});else issues.push(...validateRuntimeExport(citation.project,citation.projection,citation.idMap,policy.data,profile,false));}
 return issues;
}
function validateRuntimeExport(project: ProjectData, projection: PublicProjection, idMap: Record<string, string>, policy: Entity<'projection_profile'>['data'], profile: RuntimeExportProfile,requireGraph=true): ProjectionIssue[] {
  const issues: ProjectionIssue[] = [];
  const fail = (message: string, entityId?: string, field?: string) => { issues.push({ code: 'EXPORT_UNSUPPORTED', message, ...(entityId ? { entityId } : {}), ...(field ? { field } : {}) }); };
  if (profile.profileId !== 'scenario-runtime' || profile.schemaVersion !== '1.0.0' || profile.profileVersion !== '1.1.0') fail('この制作出力は汎用scenario-runtime 1.1.0専用です。未実装のゲームエンジンへ直接変換できません。');
  for (const field of ['supportedNodeTypes', 'supportedConditions', 'supportedEffects', 'externalContracts', 'assetTypes'] as const) if (!Array.isArray(profile[field]) || profile[field].some(value => !GENERIC_RUNTIME_PROFILE[field].includes(value))) fail('対応先の機能一覧に未対応の種類が含まれています。', undefined, field);
  const included = new Set(Object.keys(idMap)),projectedById=new Map(projection.entities.map(entity=>[entity.id,entity]));
  issues.push(...stableIdIssues(idMap, policy));
  for (const disclosure of presentationDisclosures(project, idMap)) {
    if (disclosure.data.anchor.positionStatus === 'unresolved') fail('提示位置が不明な開示があります。本文へ再リンクしてから実行用出力を作成してください。', disclosure.id, 'anchor');
    if (!disclosure.data.knowledgeEffects?.length) continue;
    const emitted = projection.entities.find(entity => entity.id === idMap[disclosure.id]);
    const effects = emitted?.data.knowledgeEffects;
    if (!emitted || !Array.isArray(effects) || effects.length !== disclosure.data.knowledgeEffects.length || disclosure.data.knowledgeEffects.some((id, index) => !idMap[id] || effects[index] !== idMap[id])) fail('提示時に状態を変える開示と効果が公開範囲から除かれています。制作の動作を保持できないため出力を停止しました。', disclosure.id, 'knowledgeEffects');
  }
  for (const entity of project.entities) {
    if (!included.has(entity.id)) continue;
    const projected = projectedById.get(idMap[entity.id])!;
    const schema = PROJECTION_FIELDS[entity.kind] ?? {};
    const data = entity.data as unknown as Record<string, unknown>;
    if (Object.keys(entity.customValues).length && ['flow_node', 'flow_edge', 'flow_graph', 'variable', 'effect', 'quest'].includes(entity.kind)) fail('制作処理に追加したカスタム項目の意味を対応先で表せません。', entity.id, 'customValues');
    for (const [field, value] of Object.entries(data)) {
      if (value == null || value === '' || (Array.isArray(value) && !value.length)) continue;
      if (!(field in schema) && !SAFE_RUNTIME_OMISSIONS[entity.kind]?.includes(field)) fail('この制作処理の項目は未対応です。黙って省略せず出力を停止しました。', entity.id, field);
    }
    const required: Record<string, string[]> = {
      flow_node: ['nodeType'], flow_edge: ['fromId', 'toId', 'edgeType'], flow_graph: ['nodeIds', 'edgeIds', 'entryIds', 'exitIds'],
      variable: ['key', 'valueType', 'scope', 'initial', 'allowed'], effect: ['operation', 'targetId'], external_contract: ['key', 'owner', 'inputType', 'outputType', 'missingPolicy'],
      dialogue_line: ['text'], quest: ['key', 'stateVariableId'], item: ['itemMode'], assertion: ['subjectId', 'predicate', 'value', 'truthKind'], disclosure: ['foreshadowId', 'anchor', 'stage', 'role'],
    };
    for (const field of required[entity.kind] ?? []) if (!has(projected.data, field)) fail('制作に必要な項目が公開範囲から除かれています。', entity.id, field);
    // Omitting an optional author field is safe; omitting a present behavior field is not.
    const behaviorFields = new Set(['condition', 'gate', 'trigger', 'executionPolicy', 'fallbackId', 'effectIds', 'knowledgeEffects', 'sceneId', 'childGraphId', 'parentGraphId', 'choiceLineId', 'dialogueLineIds', 'blockIds', 'priority', 'initial', 'allowed', 'ownerId', 'externalContractId', 'transitionRules', 'value', 'instanceId', 'cueIds', 'stateVariableId','derived','resetRules','exclusions','exceptionDetails','targetScope','validity','presentationDeadline','deadline','alternativeInfo','parameters','mediaTime','camera']);
    for (const [field, value] of Object.entries(data)) if (behaviorFields.has(field) && value != null && !(Array.isArray(value) && !value.length) && !has(projected.data, field)) fail('分岐や状態の動作を変える項目を除外できません。', entity.id, field);
    if (entity.kind === 'flow_node') {
      if (!profile.supportedNodeTypes.includes(entity.data.nodeType)) fail('このノード種類を対応先で表せません。', entity.id, 'nodeType');
      if (entity.data.nodeType === 'terminal' && !projected.data.terminalReason) fail('公開用の終端理由を指定してください。', entity.id, 'terminalReason');
      if (entity.data.nodeType === 'call' && !projected.data.childGraphId) fail('呼び出すグラフの公開参照が必要です。', entity.id, 'childGraphId');
    }
    if (entity.kind === 'flow_edge' && typeof entity.data.toId !== 'string') fail('未完成の分岐先を制作出力には含められません。', entity.id, 'toId');
    if (entity.kind === 'effect' && !profile.supportedEffects.includes(entity.data.operation)) fail('この効果を対応先で表せません。', entity.id, 'operation');
    if (entity.kind === 'variable') {
      if (entity.data.initial.type === 'unknown' ? !entity.data.externalContractId : entity.data.initial.type !== entity.data.valueType) fail('変数の初期値を正しい型で確定してください。', entity.id, 'initial');
      if (entity.data.initial.type === 'enum' && !(entity.data.allowed.values ?? []).includes(entity.data.initial.value)) fail('初期値が許可列挙に含まれていません。', entity.id, 'initial');
      if (entity.data.initial.type === 'integer' && (entity.data.initial.value < (entity.data.allowed.min ?? -2147483648) || entity.data.initial.value > (entity.data.allowed.max ?? 2147483647))) fail('変数の初期値が許可範囲から外れています。', entity.id, 'initial');
      if (entity.data.valueType === 'enum' && !entity.data.allowed.values?.length) fail('列挙変数の許可値を指定してください。', entity.id, 'allowed');
      if (entity.data.externalContractId && !projection.entities.some(candidate => candidate.id === idMap[entity.data.externalContractId!] && candidate.kind === 'external_contract')) fail('外部値の契約が公開範囲にありません。', entity.id, 'externalContractId');
    }
    if (entity.kind === 'external_contract' && (!profile.externalContracts.includes(entity.data.inputType) || !profile.externalContracts.includes(entity.data.outputType))) fail('この外部値の型を対応先で表せません。', entity.id);
    if (entity.kind === 'attachment' && !profile.assetTypes.includes(entity.data.mediaType)) fail('この素材形式を対応先で表せません。', entity.id, 'mediaType');
    checkTypedConditionCapabilities(projected.data,ENTITY_SCHEMAS[entity.kind],profile,(message,field)=>fail(message,entity.id,field));
  }
  for(const relation of projection.relations){const validity=record(relation.validity);if(validity?.routeCondition)checkConditionCapability(validity.routeCondition,profile,message=>fail(message,relation.id,'validity.routeCondition'));}
  if (requireGraph&&!byKind(projection, 'flow_graph').length) fail('制作出力には公開されたフローグラフが必要です。');
  const keys = byKind(projection, 'variable').map(variable => variable.data.key);
  if (new Set(keys).size !== keys.length) fail('公開用の変数キーが重複しています。', undefined, 'key');
  return issues;
}
/** Walk only typed executable conditions/expressions, preserving opaque camera and author text semantics. */
function checkTypedConditionCapabilities(value:unknown,schema:Schema,profile:RuntimeExportProfile,fail:(message:string,path:string)=>void,path='',depth=0):void{
 if(value==null)return;if(depth>32){fail('条件構造の上限を超えています。',path);return;}
 if(schema.type==='condition'){checkConditionCapability(value,profile,message=>fail(message,path));return;}
 if(schema.type==='expression'){const ast=record(value);if(!ast)return;if(['value','variable'].includes(String(ast.op)))return;if(['add','subtract','multiply'].includes(String(ast.op))){for(const field of ['left','right'])checkTypedConditionCapabilities(ast[field],schema,profile,fail,`${path}.${field}`,depth+1);return;}if(ast.op==='if'){checkTypedConditionCapabilities(ast.condition,{type:'condition'},profile,fail,`${path}.condition`,depth+1);for(const field of ['then','else'])checkTypedConditionCapabilities(ast[field],schema,profile,fail,`${path}.${field}`,depth+1);return;}checkConditionCapability(value,profile,message=>fail(message,path));return;}
 if(schema.type==='array'&&Array.isArray(value))value.forEach((item,index)=>checkTypedConditionCapabilities(item,schema.item,profile,fail,`${path}[${index}]`,depth+1));
 else if(schema.type==='object'){const object=record(value);if(object)for(const [field,definition]of Object.entries(schema.fields))checkTypedConditionCapabilities(object[field],definition.schema,profile,fail,path?`${path}.${field}`:field,depth+1);}
 else if(schema.type==='record'){const object=record(value);if(object)for(const [field,item]of Object.entries(object))checkTypedConditionCapabilities(item,schema.value,profile,fail,`${path}.${field}`,depth+1);}
 else if(schema.type==='union')for(const choice of schema.choices)checkTypedConditionCapabilities(value,choice,profile,fail,path,depth+1);
}
function checkConditionCapability(input: unknown, profile: RuntimeExportProfile, fail: (message: string) => void, depth = 1): void {
  const ast = record(input);
  if (!ast || depth > 16 || typeof ast.op !== 'string' || !profile.supportedConditions.includes(ast.op)) { fail('この条件を対応先で表せません。'); return; }
  if (Array.isArray(ast.children)) ast.children.forEach(child => checkConditionCapability(child, profile, fail, depth + 1));
  if (ast.child != null) checkConditionCapability(ast.child, profile, fail, depth + 1);
}

const escapeHtml = (value: string): string => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const escapeMarkdown = (value: string): string => escapeHtml(value).replace(/([\\`*_[\]{}()#+.!|~>-])/g, '\\$1');
function blocks(value: PublicValue | undefined): ProjectedBlock[] { return Array.isArray(value) ? value as unknown as ProjectedBlock[] : []; }
const readerId=(id:string,version='public-project')=>version==='public-project'?id:`${version}--${id}`;
type ReaderRange={version:string;blockId:string;start:number;end:number};
function readerRanges(projection:PublicProjection):ReaderRange[]{const ranges=([{id:'public-project',projection},...projection.versions??[]]).flatMap(({id:version,projection:edition})=>edition.entities.flatMap(entity=>entityDocuments(entity).flatMap(([,document])=>document.flatMap(block=>(block.links??[]).flatMap(link=>link.blockId&&link.targetStart!=null&&link.targetEnd!=null?[{version:link.sourceVersionId??version,blockId:link.blockId,start:link.targetStart,end:link.targetEnd}]:[])))));return [...new Map(ranges.map(range=>[JSON.stringify(range),range])).values()];}
function blockHtml(block: ProjectedBlock, markdown = false,version='public-project',ranges:readonly ReaderRange[]=[]): string {
  const escape = markdown ? escapeMarkdown : escapeHtml;
  const letters = [...block.text];
  let position = 0, output = '';
  for (const ruby of [...block.ruby ?? []].sort((left, right) => left.start - right.start)) {
    if (ruby.start < position || ruby.end > letters.length) continue;
    output += escape(letters.slice(position, ruby.start).join(''));
    output += `<ruby>${escape(letters.slice(ruby.start, ruby.end).join(''))}<rt>${escape(ruby.text)}</rt></ruby>`;
    position = ruby.end;
  }
  output += escape(letters.slice(position).join(''));
  for(const range of ranges.filter(range=>range.version===version&&range.blockId===block.id))output+=` <mark id="${escapeHtml(readerId(block.id,version))}--${range.start}--${range.end}" data-target-start="${range.start}" data-target-end="${range.end}">${escape(letters.slice(range.start,range.end).join(''))}</mark>`;
  for (const link of block.links ?? []) {const target=readerId(link.blockId??link.lineId??link.targetId,link.sourceVersionId??version),position=link.blockId&&link.targetStart!=null&&link.targetEnd!=null?`--${link.targetStart}--${link.targetEnd}`:'';output+=` <a href="#${escapeHtml(target+position)}"${link.sourceVersionId?` data-source-version="${escapeHtml(link.sourceVersionId)}"`:''}>関連${position?`（文字${link.targetStart}〜${link.targetEnd}）`:''}</a>`;}
  return output;
}
function readingEntities(projection: PublicProjection): ProjectedEntity[] {
  const scenes = new Map(byKind(projection, 'scene').map(scene => [scene.id, scene]));
  const order: ProjectedEntity[] = [], seen = new Set<string>();
  const add = (entity: ProjectedEntity) => { if (!seen.has(entity.id)) { seen.add(entity.id); order.push(entity); } };
  for (const chapter of byKind(projection, 'chapter')) { add(chapter); for (const id of Array.isArray(chapter.data.sceneIds) ? chapter.data.sceneIds : []) if (typeof id === 'string' && scenes.has(id)) add(scenes.get(id)!); }
  for (const entity of projection.entities) if (entityDocuments(entity).length || ['scene', 'dialogue_line', 'character', 'event', 'place', 'item', 'note', 'lore', 'goal', 'terminology', 'media_variant'].includes(entity.kind)) add(entity);
  return order;
}
function entityDocuments(entity: ProjectedEntity): [string, ProjectedBlock[]][] {
  return ['body', 'text', 'summary', 'description', 'usageNotes','caption','action','tutorial','interpretation','targetAudience','experience','theme','tone','scope'].filter(field => blocks(entity.data[field]).length).map(field => [field, blocks(entity.data[field])]);
}
export function renderReaderMarkdown(projection: PublicProjection, versionLabel = '公開版'): string {
 const output=[`# ${escapeMarkdown(projection.title)}`,'',`対象版: ${escapeMarkdown(versionLabel)}`,''],ranges=readerRanges(projection);
 for(const [version,edition] of [['public-project',projection],...(projection.versions??[]).map(pin=>[pin.id,pin.projection])] as [string,PublicProjection][]){
  if(version!=='public-project')output.push(`## 引用固定版 ${escapeMarkdown(edition.title)} (${escapeMarkdown(version)})`,'');
  for(const entity of readingEntities(edition)){
   output.push(`<a id="${escapeHtml(readerId(entity.id,version))}"></a>`,`## ${escapeMarkdown(entity.name||entity.kind)}`,'');
   if(entity.status!=='confirmed')output.push(`採用状態: ${escapeMarkdown(entity.status)}`,'');
   for(const [field,document]of entityDocuments(entity)){if(field==='summary'&&entityDocuments(entity).length>1)output.push('### 要約','');for(const block of document){output.push(`<a id="${escapeHtml(readerId(block.id,version))}"></a>`);const prefix=block.kind==='heading'?'### ':block.kind==='quote'?'> ':block.kind==='list_item'?'- ':'';output.push(`${prefix}${blockHtml(block,true,version,ranges)}`,'');}}
  }
 }
 return `${output.join('\n')}\n`;
}
export function renderReaderHtml(projection: PublicProjection, versionLabel = '公開版', writingMode: 'horizontal' | 'vertical' = 'horizontal'): string {
 const ranges=readerRanges(projection),sections=([['public-project',projection],...(projection.versions??[]).map(pin=>[pin.id,pin.projection])] as [string,PublicProjection][]).map(([version,edition])=>`${version!=='public-project'?`<h2>引用固定版 ${escapeHtml(edition.title)} (${escapeHtml(version)})</h2>`:''}${readingEntities(edition).map(entity=>`<section id="${escapeHtml(readerId(entity.id,version))}"><h2>${escapeHtml(entity.name||entity.kind)}</h2>${entityDocuments(entity).map(([,document])=>document.map(block=>{const tag=block.kind==='heading'?'h3':block.kind==='quote'?'blockquote':'p';return `<${tag} id="${escapeHtml(readerId(block.id,version))}">${blockHtml(block,false,version,ranges)}</${tag}>`;}).join('')).join('')}</section>`).join('\n')}`).join('\n');
 return `<!doctype html>\n<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>${escapeHtml(projection.title)}</title><style>body{font-family:serif;line-height:1.9;margin:2rem;overflow-wrap:anywhere;${writingMode==='vertical'?'writing-mode:vertical-rl;':''}}section{margin-block:2rem}rt{font-size:.55em}</style></head><body><h1>${escapeHtml(projection.title)}</h1><p>対象版: ${escapeHtml(versionLabel)}</p>${sections}</body></html>\n`;
}

function validLanguage(value: string): boolean { try { return value.length < 64 && Intl.getCanonicalLocales(value).length === 1; } catch { return false; } }
interface ExportedLine {
  lineId: string; language: string; speakerId: string | null; sourceHash: string; text: PublicValue;
  translations: { id: string; language: string; text: PublicValue; stage: string }[];
  recordings: { id: string; language: string; attachmentId: string | null; stage: string }[];
}
async function localizedLines(project: ProjectData, projection: PublicProjection, idMap: Record<string, string>, language: string, assigned?: ReadonlySet<ID>): Promise<ExportedLine[]> {
  const lines: ExportedLine[] = [];
  for (const line of byKind(projection, 'dialogue_line')) {
    const original = project.entities.find((entity): entity is Entity<'dialogue_line'> => entity.kind === 'dialogue_line' && idMap[entity.id] === line.id)!;
    const assignedLine = assigned?.has(original.id);
    if (assigned && !assignedLine && !project.entities.some(entity => (entity.kind === 'localization' || entity.kind === 'recording') && entity.data.sourceLineId === original.id && assigned.has(entity.id))) continue;
    const allowed = (publicId: string) => !assigned || assignedLine || project.entities.some(entity => idMap[entity.id] === publicId && assigned.has(entity.id));
    const originalHash = await dialogueContentHash(project, original);
    const sourceHash = await hash({ text: blocks(line.data.text).map(block => ({ kind: block.kind, text: block.text, ruby: block.ruby ?? [] })), speakerId: line.data.speakerId ?? null, cues: byKind(projection, 'cue').filter(cue => Array.isArray(line.data.cueIds) && line.data.cueIds.includes(cue.id)).map(cue => cue.data) });
    const translations = byKind(projection, 'localization').filter(translation => translation.data.sourceLineId === line.id && allowed(translation.id)).map(translation => {
      const source = project.entities.find((entity): entity is Entity<'localization'> => entity.kind === 'localization' && idMap[entity.id] === translation.id)!;
      return { id: translation.id, language: String(translation.data.language ?? ''), text: translation.data.text ?? [], stage: source.data.sourceHash !== originalHash ? 'needs_review' : String(translation.data.stage ?? 'draft') };
    });
    const recordings = byKind(projection, 'recording').filter(recording => recording.data.sourceLineId === line.id && allowed(recording.id)).map(recording => {
      const source = project.entities.find((entity): entity is Entity<'recording'> => entity.kind === 'recording' && idMap[entity.id] === recording.id)!;
      return { id: recording.id, language: String(recording.data.language ?? ''), attachmentId: typeof recording.data.attachmentId === 'string' ? recording.data.attachmentId : null, stage: source.data.sourceHash !== originalHash ? 'needs_review' : String(recording.data.stage ?? 'planned') };
    });
    lines.push({ lineId: line.id, language, speakerId: typeof line.data.speakerId === 'string' ? line.data.speakerId : null, sourceHash, text: line.data.text ?? [], translations, recordings });
  }
  return lines;
}
function renderLocalizationMarkdown(title: string, versionLabel: string, lines: ExportedLine[]): string {
  const plain = (value: PublicValue) => blocks(value).map(block => block.text).join('\n');
  const cell = (value: string) => escapeMarkdown(value).replace(/\r?\n/g, '<br>');
  const output = [`# ${escapeMarkdown(title)} 翻訳・収録用`, '', `対象版: ${escapeMarkdown(versionLabel)}`, '', '| 台詞ID | 言語 | 公開原文hash | 原稿 | 状態 |', '| --- | --- | --- | --- | --- |'];
  for (const line of lines) {
    output.push(`| ${cell(line.lineId)} | ${cell(line.language)} | ${line.sourceHash} | ${cell(plain(line.text))} | 原文 |`);
    for (const translation of line.translations) output.push(`| ${cell(line.lineId)} | ${cell(translation.language)} | ${line.sourceHash} | ${cell(plain(translation.text))} | ${cell(translation.stage)} |`);
  }
  return `${output.join('\n')}\n`;
}

function consultationContext(projection: PublicProjection, project: ProjectData, idMap: Record<string, string>, policy: Entity<'projection_profile'>['data'], context?: ExportOptions['consultationContext']): { ok: true; markdown: string } | { ok: false; issues: ProjectionIssue[] } {
  const issues: ProjectionIssue[] = [], output: string[] = [];
  for (const id of context?.focusIds ?? []) {
    const visible = projection.entities.find(entity => entity.id === idMap[id]);
    if (!visible) issues.push({ code: 'REFERENCE_INVALID', message: '相談の対象が公開範囲にありません。', entityId: id });
    else output.push(`- ${escapeMarkdown(visible.id)}: ${escapeMarkdown(visible.name)}`);
  }
  for (const [label, values] of [['前の状態', context?.beforeValues], ['後の状態', context?.afterValues]] as const) if (values) {
    output.push('', `### ${label}`, '');
    for (const [id, value] of Object.entries(values)) {
      const source = project.entities.find((entity): entity is Entity<'variable'> => entity.id === id && entity.kind === 'variable');
      const visible = projection.entities.find(entity => entity.id === idMap[id] && entity.kind === 'variable');
      if (!source || !visible) { issues.push({ code: 'REFERENCE_INVALID', message: '公開範囲にない状態を相談へ含められません。', entityId: id }); continue; }
      let displayed: string | undefined;
      if (value.type !== 'unknown' && value.type !== source.data.valueType) { issues.push({ code: 'VALIDATION_FAILED', message: '相談用の状態値と変数の型が一致しません。', entityId: id }); continue; }
      if (value.type === 'boolean' && typeof value.value === 'boolean') displayed = String(value.value);
      else if (value.type === 'integer' && Number.isSafeInteger(value.value) && value.value >= (source.data.allowed.min ?? -2147483648) && value.value <= (source.data.allowed.max ?? 2147483647)) displayed = String(value.value);
      else if (value.type === 'enum' && source.data.allowed.values?.includes(value.value)) displayed = policy.publicValues?.[id]?.[value.value];
      else if (value.type === 'unknown') displayed = '未確定';
      if (displayed === undefined) { issues.push({ code: 'PUBLIC_TEXT_REQUIRED', message: '状態値の公開用表記がありません。', entityId: id }); continue; }
      output.push(`- ${escapeMarkdown(visible.name || String(visible.data.key ?? visible.id))}: ${escapeMarkdown(displayed)}`);
    }
  }
  if (!output.length) output.push('選択した公開範囲の設定と本文。前後の状態は未指定。');
  const unresolved = projection.entities.filter(entity => entity.status !== 'confirmed');
  if (unresolved.length) output.push('', '### 未確定事項', '', ...unresolved.map(entity => `- ${escapeMarkdown(entity.id)}: ${escapeMarkdown(entity.name)} (${escapeMarkdown(entity.status)})`));
  return issues.length ? { ok: false, issues } : { ok: true, markdown: output.join('\n') };
}

export interface ConsultationProposal { source: string; targetRevision: string; candidate: Entity<'note'> }
/** Manual import creates an alternate candidate; applying it is a separate author command. */
export function createConsultationProposal(project: ProjectData, input: { id: ID; blockId: ID; text: string; source: string; targetRevision: string; createdAt: string }): ConsultationProposal {
  const idPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
  const occupied = new Set<string>(), visited = new Set<object>();
  const findIds = (value: unknown): void => {
    if (!value || typeof value !== 'object' || visited.has(value)) return;
    visited.add(value);
    if (Array.isArray(value)) value.forEach(findIds);
    else { const object = value as Record<string, unknown>; if (typeof object.id === 'string') occupied.add(object.id); Object.values(object).forEach(findIds); }
  };
  findIds(project);
  const knownRevision = input.targetRevision === project.revision || project.snapshots.some(snapshot => snapshot.content.revision === input.targetRevision) || project.history.some(command => command.baseRevision === input.targetRevision || command.revision === input.targetRevision);
  if (!idPattern.test(input.id) || !idPattern.test(input.blockId) || input.id === input.blockId || occupied.has(input.id) || occupied.has(input.blockId) || !input.text.trim() || new TextEncoder().encode(input.text).byteLength > 1024 * 1024 || !input.source.trim() || input.source.length > 2048 || !revisionPattern.test(input.targetRevision) || !knownRevision || !Number.isFinite(Date.parse(input.createdAt))) throw new Error('VALIDATION_FAILED: 提案の出所・対象版・ID・本文を確認してください。');
  const body: RichText = [{ id: input.blockId, kind: 'paragraph', text: input.text }];
  return {
    source: input.source, targetRevision: input.targetRevision,
    candidate: { id: input.id, projectId: project.projectId, kind: 'note', revision: '0', name: '相談からの提案', status: 'alternate', visibility: 'private', createdAt: input.createdAt, updatedAt: input.createdAt,
      customValues: { consultationSource: input.source, consultationTargetRevision: input.targetRevision }, data: { body, attachmentIds: [], convertedToIds: [] } },
  };
}

type ExportAssets={data:Record<string,{mediaType:string;base64:string}>;files:Record<string,Uint8Array>;complete:boolean};
async function exportAssetBytes(project:ProjectData,projection:PublicProjection,idMap:Record<string,string>,supplied?:Record<string,Uint8Array>):Promise<ExportAssets>{
 const data:ExportAssets['data']={},files:ExportAssets['files']={};let complete=true;
 for(const projected of byKind(projection,'attachment')){const original=project.entities.find((entity):entity is Entity<'attachment'>=>entity.kind==='attachment'&&idMap[entity.id]===projected.id)!;const bytes=supplied?.[original.data.contentHash];if(!bytes){complete=false;continue;}if(bytes.byteLength!==original.data.byteSize||await sha256(bytes)!==original.data.contentHash)throw Error('INTEGRITY_FAILED: 出力素材のbytes/hash/sizeが一致しません。');const verified=await prepareAsset(new Uint8Array(bytes),String(projected.data.displayName??'素材'),original.data.mediaType);if(verified.contentHash!==original.data.contentHash)throw Error('INTEGRITY_FAILED: 素材形式を検証できません。');let binary='';for(let offset=0;offset<bytes.length;offset+=16384)binary+=String.fromCharCode(...bytes.subarray(offset,offset+16384));data[projected.id]={mediaType:original.data.mediaType,base64:btoa(binary)};files[String(projected.data.assetPath)]=new Uint8Array(bytes);}
 return {data,files,complete};
}
async function exportAllAssetBytes(project:ProjectData,projection:PublicProjection,idMap:Record<string,string>,citations:readonly CitationSource[],supplied?:Record<string,Uint8Array>):Promise<ExportAssets>{
 const result=await exportAssetBytes(project,projection,idMap,supplied);
 for(const asset of byKind(projection,'attachment'))asset.data.bytesIncluded=!!result.data[asset.id];
 for(const source of citations){
  const assets=await exportAssetBytes(source.project,source.projection,source.idMap,supplied);result.complete&&=assets.complete;
  for(const [id,data]of Object.entries(assets.data))result.data[`${source.publicVersionId}:${id}`]=data;
  for(const [path,bytes]of Object.entries(assets.files))result.files[`citations/${source.publicVersionId}/${path}`]=bytes;
  for(const asset of byKind(source.projection,'attachment'))asset.data.bytesIncluded=!!assets.data[asset.id];
 }
 return result;
}
async function buildPlayableArchive(projection:PublicProjection,versionLabel:string,assets:ExportAssets):Promise<ExportArtifact>{
 const portable=await portableRuntimeProject(projection),payload={format:'scenario-playable-preview',formatVersion:'1.0.0',profile:publicRuntimeProfile(PLAYABLE_PREVIEW_PROFILE,assets.complete&&Object.keys(assets.data).length>0),title:projection.title,versionLabel,contentVersionId:`sha256:${await hash(projection)}`,entities:projection.entities,calendars:projection.calendars,project:portable.project,projectHash:await sha256(jsonBytes(portable.project)),publicToRuntime:portable.publicToRuntime,externalEvidence:'not_included',assetBytesIncluded:assets.complete&&Object.keys(assets.data).length>0,transitionLimit:10000,assetData:assets.data};
 const json=JSON.stringify(payload,null,2),embedded=json.replace(/</g,'\\u003c').replace(/>/g,'\\u003e').replace(/&/g,'\\u0026'),scriptDigest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(portableScript))),scriptHash=btoa(String.fromCharCode(...scriptDigest));
 if(/<\/script/i.test(portableScript))throw Error('INTEGRITY_FAILED: Portable script contains an unsafe HTML boundary');
 const html=`<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'sha256-${scriptHash}'; style-src 'unsafe-inline'; img-src blob:; media-src blob:; base-uri 'none'; form-action 'none'"><title>${escapeHtml(projection.title)} 試遊</title><style>body{font-family:system-ui,sans-serif;max-width:48rem;margin:2rem auto;padding:0 1rem;line-height:1.8;color:#202624}button,input,select{font:inherit;margin:.3rem;padding:.55rem}button:focus-visible{outline:3px solid #17765a}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.85rem}img,video{max-width:100%}</style></head><body><h1 id="title"></h1><p>対象版: <span id="version"></span></p><p>外部値の仮入力はstubです。実ゲームの副作用は実行しません。</p><main><button id="start" type="button">選択した入口から開始</button><h2 id="node-name"></h2><div id="scene"></div><p id="message" role="status" aria-live="polite"></p><div id="choices"></div><p><button id="undo" type="button">戻る</button><button id="restart" type="button">初期値から再開</button><button id="loop" type="button">次周回へ</button></p><details><summary>試遊の値・訪問記録</summary><pre id="state"></pre></details></main><script type="application/json" id="scenario-data">${embedded}</script><script>${portableScript}</script></body></html>
`;
 const readme='試遊 1.0.0\nZIPを展開しindex.htmlをブラウザーで開いてください。通信は不要です。\n本アプリと同じ実行器で三値条件・効果群の原子拒否・scope初期化・相互排他・算出・呼出/復帰・all_match・物品・認識・提示時効果を評価します。\n全宣言入口の選択、戻る、全初期化、次周回、演出msと素材を提供します。固定共通元と世界版はhash検証後に公開範囲で投影した出力用内容です。\n未確認の条件は停止します。一経路10,000遷移が上限です。外部値はstubで、実ゲーム副作用・実受領証跡は含まれません。\n出力は作者の正本を変更しません。素材不足・非公開の必要な効果・未対応項目は出力時に拒否します。\n';
 const files:Record<string,Uint8Array>={'index.html':strToU8(html),'runtime.json':strToU8(json),'README.txt':strToU8(readme),...assets.files},manifestFiles=await Promise.all(Object.entries(files).map(async([path,bytes])=>({path,byteSize:bytes.byteLength,sha256:await sha256(bytes)})));
 files['manifest.json']=strToU8(JSON.stringify({format:'scenario-playable-package',formatVersion:'1.0.0',files:manifestFiles,contentVersionId:payload.contentVersionId,externalEvidence:'not_included',assetBytesIncluded:assets.complete},null,2));
 return {filename:'playable-preview.zip',mimeType:'application/zip',content:'',bytes:new Uint8Array(zipSync(files,{level:6}))};
}
