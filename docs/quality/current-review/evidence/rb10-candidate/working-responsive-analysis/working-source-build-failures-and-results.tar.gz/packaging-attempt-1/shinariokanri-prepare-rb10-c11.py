import base64, copy, datetime, gzip, hashlib, io, json, pathlib, shutil, subprocess, tarfile

root = pathlib.Path('/workspace/shinariokanri-rb10-responsive-analysis')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prior = json.loads(pathlib.Path('/tmp/shinariokanri-rb10-candidate-10/source-and-build-binding.json').read_text())
for row in prior['original_documents']: assert sha(root / row['path']) == row['sha256'], row['path']
unit = pathlib.Path('/tmp/shinariokanri-rb10-c11-working-unit-full-2.json')
u = json.loads(unit.read_text()); assert u['success'] and u['numTotalTests'] == u['numPassedTests'] == 770
nav = json.loads(pathlib.Path('/tmp/shinariokanri-rb10-c11-working-navigation-browser-1.json').read_text())
large = json.loads(pathlib.Path('/tmp/shinariokanri-rb10-c11-working-large-browser-2.json').read_text())
assert nav['stats']['expected'] == 6 and nav['stats']['unexpected'] == 0
assert large['stats']['expected'] == 1 and large['stats']['unexpected'] == 0
observation = json.loads(pathlib.Path('/tmp/shinariokanri-rb10-c11-working-large-browser-2-observation.json').read_text())
assert observation['nativeBefore'] == observation['nativeAfter'] and len(observation['nativeBefore']) == 27
assert observation['result']['status'] == 'unknown' and observation['result']['truncated']
assert observation['result']['limits'] == {'maxStates': 100000, 'maxTransitions': 10000, 'maxMs': 30000}
assert observation['timing']['firstPaintAt'] - observation['timing']['startedAt'] <= 2000
assert observation['timing']['largestTimerGap'] <= 2000
for name, marker in [('docs', 'Documentation check passed'), ('plan', 'Completion plan check passed')]:
    p = pathlib.Path('/tmp') / f'shinariokanri-rb10-c11-{name}.txt'
    assert p.exists() and 'passed' in p.read_text().lower(), name
assert 'Ran 15 tests' in pathlib.Path('/tmp/shinariokanri-rb10-c11-python.txt').read_text()

dest = root / 'docs/quality/current-review/evidence/rb10-candidate/working-responsive-analysis'
assert not dest.exists(); dest.mkdir()
folders = [pathlib.Path(f'/tmp/shinariokanri-rb10-c11-working-inputs-{i}') for i in range(1, 6)]
folders += [pathlib.Path('/workspace/shinariokanri-rb10-artifacts') / name for name in ['c11-working-navigation-browser-1', 'c11-working-large-browser-1', 'c11-working-large-browser-2']]
pairs = [(p, folder.name + '/' + str(p.relative_to(folder))) for folder in folders for p in sorted(folder.rglob('*')) if p.is_file()]
for p in sorted(pathlib.Path('/tmp').glob('shinariokanri-rb10-c11-*.txt')): pairs.append((p, p.name))
for name in ['working-unit-targeted-1', 'working-unit-targeted-2', 'working-unit-targeted-3', 'working-unit-full', 'working-unit-full-2', 'working-navigation-browser-1', 'working-large-browser-1', 'working-large-browser-2', 'working-large-browser-2-observation']:
    p = pathlib.Path('/tmp') / f'shinariokanri-rb10-c11-{name}.json'
    assert p.exists(), p; pairs.append((p, p.name))
static = pathlib.Path('/tmp/shinariokanri-independent-responsive-input3-static-seal.json')
st = json.loads(static.read_text())
for row in st['files']:
    p = pathlib.Path(row['path']); assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes']
    pairs.append((p, 'independent-input3-static/' + p.name))
pairs.append((static, static.name))
assert len({name for _, name in pairs}) == len(pairs)
manifest = [{'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)} for p, name in pairs]
archive_path = dest / 'working-source-build-failures-and-results.tar.gz'
with archive_path.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for (p, name), row in zip(pairs, manifest):
                item = tarfile.TarInfo(name); item.size = row['bytes']; item.mode = 0o644; item.mtime = 0
                with p.open('rb') as contents: archive.addfile(item, contents)
            data = (json.dumps({'scope': 'C11 dirty preparation; full original clauses and clean final verification remain separate', 'files': manifest}, ensure_ascii=False, indent=2) + '\n').encode()
            item = tarfile.TarInfo('BUNDLE_MANIFEST.json'); item.size = len(data); item.mode = 0o644; archive.addfile(item, io.BytesIO(data))
with tarfile.open(archive_path, 'r:gz') as archive:
    for row in manifest:
        h = hashlib.sha256(); stream = archive.extractfile(row['path']); size = 0
        for part in iter(lambda: stream.read(1024 * 1024), b''): h.update(part); size += len(part)
        assert size == row['bytes'] and h.hexdigest() == row['sha256']
summary = {
    'candidate': 'C11 dirty preparation', 'parent': prior['commit'], 'working_build': json.loads((root / 'dist/build-info.json').read_text()),
    'original_case': next(c for c in json.loads((root / 'docs/data/acceptance_cases.json').read_text()) if c['id'] == 'AT-N05'),
    'historical_failure': 'C10 same1ca2... originalLarge+519 long/unbounded records: first visible progress12498.9ms and queued pointer19653.4ms; real7200 never started. Historical failed result sealed separately.',
    'source_change': 'Browser Worker runs the unchanged verified domain capture/validation/hash/exploration. Captured edition/world bytes, signal and callback; original preparation-included30sec/100k/10k limits; elapsed8ms and128state yields including fanout/continue; late results after cancel stay unknown/truncated and author epoch protects draft.',
    'unit': {'final_preparation': '770/82 passed with configured Chromium and4workers', 'first_full': '768 passed/2 browser-dependent launch failures from omitted Chromium path, preserved; not product failure', 'first_targeted': '39 passed/1 invalid fixture lacking graph; expectation retained and fixture repaired, original source reconstruction explicitly identified'},
    'navigation': {'passed': 6, 'engines': ['Chromium', 'Firefox', 'WebKit'], 'scope': 'Linux production normal App, current/fixed request-capture waiting; native12/input/revision/edition checks; queued Worker request waiting is not mid-digest evidence'},
    'large': {'passed': 1, 'fixtureSha256': '1ca2b19dcf4c8464c68a24a1bbe02cd1b1c4be20187ed2cee99d4e541822d0d0', 'originalRecords': 88003, 'declaredExtraRecords': 519, 'actualAssetBytes': 72*1024*1024, 'finiteLongBranchTransitionsDeclared': 256, 'checkedStatesBeforeCancel': observation['result']['checkedStates'], 'firstProgressMilliseconds': observation['timing']['firstPaintAt']-observation['timing']['startedAt'], 'largest50msTimerGap': observation['timing']['largestTimerGap'], 'nativeTables': 27, 'allNativeMetadataAndBinaryUnchanged': True, 'scope': 'Actual cancellation/unknown/input/result retention, not whole finite/unbounded exploration or p95 certification'},
    'first_large': 'Correct product behavior and all other27-store hashes matched, but comparison used Reader baseline and Editor final; viewStates differed by intentional navigation. Same Reader/scroll0 and300ms existing preference debounce settle now compared; all stores still included. Failed raw/source/trace retained.',
    'static': 'Independent input3 sealed12 files/execution0; no new static blocker; functional verification deferred to clean candidate',
    'schema_format_limits': 'unchanged', 'originalCounts': [104,24,116,6], 'originalDocuments': 26,
    'unverified': ['clean candidate CI/formal30/recovery/actual7200/all original116/33 boundaries', 'real OS/browser/assistive/manual', 'dedicated realAuth/RLS/privateStorage/5 real accounts/currentquota/costs/published direct links']}
(dest / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
(dest / 'README.md').write_text('# 元Largeの探索応答と取消結果の準備補修\n\nC10の同じ元88,003件＋519宣言分岐・実72MiBで、画面停止を実ポインター/LongTaskにより独立再現した。C11は同じ版検証と実行器をWorkerへ接続し、元上限を保持する。結果受取前の取消を全体確認済みにしない。\n\n準備版の通常3browser×2、小fixture以外の元Large取消1、770単体が成功。Largeは進捗/取消/unknown結果/入力再開/全27nativeとbinary不変を確認したが、全探索・clean最終・実時間2時間・116全体・実機/実権限へ換算しない。最初のviewStates観測位置差、Chromium設定漏れ、fixture修正と元source/rawを保持する。Worker要求待ちとdigest途中待ちを混同しない。\n\n全memberを梱包後にSHA/bytes再検算した。C10の失敗と部分成功はcandidate-10に別保存する。\n')
(dest / 'MANIFEST.json').write_text(json.dumps({'files': [{'path': str(p.relative_to(dest)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(dest.rglob('*')) if p.is_file()], 'allArchiveMembersVerified': True}, indent=2)+'\n')

paragraph = '''固定C10 f76d5e9/treee5fc7/build187dのCI37927467219は764/81単体・270production・全20step成功。元Standard各30回とLarge実入力開始8851.90000000596ms/検索489.3999999910593msは局所数値内、元88,003件＋実72MiBの完全new/clone/cold復元も一致した。一方、同じ元Largeに長い分岐を追加した独立N05では初回進捗12498.9ms/取消pointer19653.4msで2秒条件を超えた。実7200秒は未開始、元116全体passed0としてcandidate-10へ封印する。\n\nC11は固定版/世界hash検証と同じ実行器の解析をWorkerへ接続し、時間8ms目安と128状態のyieldをfanout/continueにも接続。準備時間を元30秒に含め、100,000状態/10,000遷移・原子性・ID/形式を維持する。同じ元Large全88,522件/72MiBの取消/unknown/結果保持/不正JSON再開/全27native内容不変、3browser×2通常と全770/82単体がdirty準備で成功。最初のviewStates比較位置差とChromium設定漏れ2件の失敗を保持し、clean最終30回/復元/実7200秒/原116/33境界を別実行する。実機/実権限/専用現行費用の不足と公開gate保留は維持する。'''
progress = root / 'docs/implementation/PROGRESS.md'; text = progress.read_text(); marker = '\n\n[104要件の現在照合]'; assert marker in text
text = text.replace(marker, '\n\n'+paragraph+marker, 1)
first, rest = text.split('\n',1)
first = first.replace('PR #18〜#21', 'PR #18〜#22').replace('449de9b469792b8778a7340b8ae27585d9d31e3a', '4bd437153aa29e8ecc3024f139db9fea97a47474').replace('45726131d7f818d07b57aa8a26a9b7293b7cc129', '1822ac96925fa765068a6339c5e828fe24f3e998').replace('PR #21、2026-10-09T09:34:51Z', 'PR #22、2026-10-09T10:30頃Z')
progress.write_text(first+'\n'+rest)
guide = root / 'docs/implementation/RB10_COMPLETION_CANDIDATE.md'; guide.write_text(guide.read_text()+'\n## C10の元Large未達とC11の応答補修\n\n'+paragraph+'\n')
compat = root / 'docs/implementation/EXPORT_COMPATIBILITY.md'; assert str(compat.relative_to(root)) not in {r['path'] for r in prior['original_documents']}
compat.write_text(compat.read_text()+'\n## C11の分岐解析Worker\n\nブラウザー分岐検査は同じ固定版/共通世界のhash検証と実行規則をWorkerで実行する。完全ファイル/requiredFeatures/DBv7/公開投影/素材bytes/ID対応/6出力profileは不変。準備時間を含む30秒・100,000状態・一経路10,000遷移を保持し、取消/未探索/未知を全経路安全へ換算しない。キャッシュ対象に生成Workerを含む。Worker起動拒否は入力と保存済み内容を保ってエラーを表示する。\n')

path = root / 'docs/quality/current-review/current-implementation.json'; audit = json.loads(path.read_text()); before = copy.deepcopy(audit)
assert [r['original_requirement'] for r in audit['requirements']] == json.loads((root / 'docs/data/requirements.json').read_text())
assert [r['original_case'] for r in audit['acceptance_cases']] == json.loads((root / 'docs/data/acceptance_cases.json').read_text())
assert tuple(len(audit[k]) for k in ['requirements','work_packages','acceptance_cases','regression_groups']) == (104,24,116,6)
historical = {'candidate': 'C10', 'commit': prior['commit'], 'tree': prior['tree'], 'evidence': 'evidence/rb10-candidate/candidate-10/summary.json', 'result': 'CI20/764/270, original Standard/Large30 and recovery passed locally; originalLarge N05 progress/cancel failed; real7200 not_started; original116 whole0; release blocked'}
audit['historical_audit_bindings'].append(copy.deepcopy(historical)); audit['historical_verification'].append(copy.deepcopy(historical))
audit['checked_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat(); audit['candidate_branch'] = 'feat/rb10-responsive-analysis'
audit['target_binding'] = 'C11 preparation on C10f76d5e9 stacked above latestmain4bd4371: originalLarge N05 main-thread progress/cancel failed on C10; browser Worker preserves verified edition/world bytes, shared execution, original limits and cancelled unknown. Dirty770 units/small6 and same1ca2 Large cancel/full27-native byte equality pass; clean CI/formal30/recovery/actual7200/full116+33 remain separate.'
audit['historical_main_rechecks'].append(copy.deepcopy(audit['latest_main_recheck']))
audit['latest_main_recheck'].update({'checked_at': audit['checked_at'], 'commit': '4bd437153aa29e8ecc3024f139db9fea97a47474', 'tree': '1822ac96925fa765068a6339c5e828fe24f3e998', 'pr23_head': prior['commit'], 'pr23_ci_run': 37927467219, 'pr23_ci_conclusion': 'success', 'pr23_state': 'open draft / mergeable clean / unmerged', 'root_main_merge': False})
for row in audit['requirements']:
    rid = row['original_requirement']['id']
    if rid in ['REQ-N05','REQ-N18','REQ-B16','REQ-F15','REQ-F17']:
        row.setdefault('historical_implementation_audits', []).append({'checked_at': before['checked_at'], 'target_binding': before['target_binding'], 'observed': row['current_implementation_observed'], 'remaining': row['current_remaining_conditions'], 'source_files': copy.deepcopy(row['source_files'])})
        row['current_implementation_observed'] += ' C11: C10元Large進捗/取消2秒未達を別保存。同じ固定版/世界hashと実行器の解析Worker、captured signal/callback、fanout/continue yield、準備込み30秒/100k/10kを保持。同じ88,522件+実72MiB取消/unknown/結果・不正入力再開/全27native不変、3browser×2と770単体がdirty成功。clean最終/全探索/実2時間/原116と実環境は別判定。'
        row['implementation_assessment'] = 'additional_integration_present_final_unverified'
        for f in ['src/ui/flowAnalysis.ts','src/domain/analysis.worker.ts','src/domain/runtime.ts','src/ui/Reader.tsx','src/ui/flowAnalysis.test.ts','tests/rb10/large-analysis.spec.ts','tests/fixtures/rb10-large-analysis/metadata.json']:
            if not any(v['path'] == f for v in row['source_files']): row['source_files'].append({'path': f, 'sha256': ''})
    row['audit_scope'] = 'Original104/116 literal conditions and historical evidence retained; C10 Large responsiveness failed; dirty C11 observations are preparation, not clean final/physical/live certification.'
audit['additional_current_findings'].append({'id': 'RB10-N05-large-analysis-response', 'source_candidate': prior['commit'], 'state': 'working_fix_verified_clean_final_unverified', 'requirement_ids': ['REQ-N05','REQ-N18','REQ-B16'], 'finding': summary['historical_failure']+' '+summary['source_change'], 'evidence': ['evidence/rb10-candidate/candidate-10/summary.json','evidence/rb10-candidate/working-responsive-analysis/summary.json'], 'claim_limit': 'Same originalLarge cancellation/retention/bytes supports only observed clauses. Actual7200 and clean116/33/physical/live independent.'})
for f in audit['review_findings']:
    if f['id'] in ['RV27','RV29','RV30']: f['current_behavior'] += ' C10原LargeN05応答未達を保持。C11同じ検証済み実行器Workerと元上限/準備30秒でdirty元Large取消/全native27不変を通過。clean最終・全116/33・実7200秒・実環境は別実行。'
selectors = ['src','scripts','tests','examples','supabase','.github','package.json','package-lock.json','vite.config.ts','playwright.config.ts','vitest.config.ts','index.html']
files = subprocess.check_output(['git','ls-files','--',*selectors],cwd=root,text=True).splitlines() + subprocess.check_output(['git','ls-files','--others','--exclude-standard','--',*selectors],cwd=root,text=True).splitlines()
audit['source_manifest'] = [{'path': f, 'sha256': sha(root/f)} for f in sorted(set(files)) if (root/f).is_file()]
cell = lambda s: str(s).replace('|','\\|').replace('\n',' ')
lines = ['# 104要件の現在実装照合（最終受入は未完了）','','2026-10-09。原104/24/116/6と26原文hash不変。固定C10のCI/各30回/完全復元局所成功と元LargeN05応答未達を分離保存。C11の同じ元Large取消/全27native不変・通常6・770単体はdirty準備。clean最終/実7200/116全体/実環境は別判定。','','| 要件 | 工程/担当 | 現在の実装観察 | 残る確認 | 原ケース最終結果 |','| --- | --- | --- | --- | --- |']
for row in audit['requirements']:
    req = row['original_requirement']; lines.append('| '+' | '.join(cell(v) for v in [req['id']+' '+req['title'],req['package_id']+'/'+row['owner_batch'],row['current_implementation_observed'],row['current_remaining_conditions'],row['final_acceptance_result']])+' |')
(root/'docs/quality/current-review/CURRENT_REQUIREMENTS.md').write_text('\n'.join(lines)+'\n')
for row in audit['requirements']:
    for f in row['source_files']: f['sha256'] = sha(root/f['path'])
for row in prior['original_documents']: assert sha(root/row['path']) == row['sha256']
path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive': str(archive_path), 'members': len(manifest), 'archiveBytes': archive_path.stat().st_size, 'all104sourceHashesUpdated': True, 'sourceFiles': len(audit['source_manifest']), 'originalCounts': [104,24,116,6], 'cleanFinal': 'not_run'},ensure_ascii=False))
