//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __esmMin = (fn, res, err) => () => {
	if (err) throw err[0];
	try {
		return fn && (res = fn(fn = 0)), res;
	} catch (e) {
		throw err = [e], e;
	}
};
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) {
		__defProp(target, name, {
			get: all[name],
			enumerable: true
		});
	}
	if (!no_symbols) {
		__defProp(target, Symbol.toStringTag, { value: "Module" });
	}
	return target;
};

//#endregion
//#region src/storage/errors.ts
function checkCancelled(signal) {
	if (signal?.aborted) throw new StorageError("CANCELLED", "処理を取り消しました。既存の作品は変更していません。");
}
var StorageError;
var init_errors = __esmMin((() => {
	StorageError = class extends Error {
		code;
		path;
		constructor(code, message, path, options) {
			super(message, options);
			this.name = "StorageError";
			this.code = code;
			this.path = path;
		}
	};
}));

//#endregion
//#region src/storage/json.ts
/** Tests may lower limits; callers cannot silently raise the v1 safety contract. */
function resolveLimits(overrides = {}) {
	const result = { ...ARCHIVE_LIMITS };
	for (const [key, value] of Object.entries(overrides)) {
		if (!(key in result) || !Number.isSafeInteger(value) || value < 1 || value > result[key]) throw new StorageError("LIMIT_EXCEEDED", "v1の安全上限は引き上げられません。", key);
		result[key] = value;
	}
	return result;
}
function isValidUnicode(value) {
	for (let i = 0; i < value.length; i++) {
		const code = value.charCodeAt(i);
		if (code >= 55296 && code <= 56319) {
			const next = value.charCodeAt(++i);
			if (!(next >= 56320 && next <= 57343)) return false;
		} else if (code >= 56320 && code <= 57343) return false;
	}
	return true;
}
function parseStrictJson(bytes, path, limits = ARCHIVE_LIMITS, budget = { objects: 0 }) {
	if (bytes.byteLength > limits.jsonBytes) throw new StorageError("LIMIT_EXCEEDED", "JSONファイルが上限を超えています。", path);
	if (bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191) throw new StorageError("ARCHIVE_INVALID", "JSONのBOMは使用できません。", path);
	let source;
	try {
		source = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
	} catch (error) {
		throw new StorageError("ARCHIVE_INVALID", "JSONは有効なUTF-8である必要があります。", path, { cause: error });
	}
	let offset = 0;
	const invalid = (message) => {
		throw new StorageError("ARCHIVE_INVALID", `${message}（位置 ${offset}）`, path);
	};
	const whitespace = () => {
		while (/[ \t\n\r]/.test(source[offset] ?? "") && offset < source.length) offset++;
	};
	function string() {
		const begin = offset++;
		while (offset < source.length) {
			const char = source[offset++];
			if (char === "\"") {
				let value;
				try {
					value = JSON.parse(source.slice(begin, offset));
				} catch {
					return invalid("文字列が不正です。");
				}
				if (!isValidUnicode(value)) return invalid("Unicodeのサロゲートが不正です。");
				return value;
			}
			if (char === "\\") offset++;
		}
		return invalid("文字列が閉じられていません。");
	}
	function value(depth) {
		whitespace();
		const char = source[offset];
		if (char === "\"") return string();
		if (char === "{" || char === "[") {
			if (depth > limits.depth || ++budget.objects > limits.objects) throw new StorageError("LIMIT_EXCEEDED", "JSONの構造が安全上限を超えています。", path);
			const object = char === "{";
			offset++;
			whitespace();
			const end = object ? "}" : "]";
			const result = object ? Object.create(null) : [];
			const keys = /* @__PURE__ */ new Set();
			if (source[offset] === end) {
				offset++;
				return result;
			}
			while (offset < source.length) {
				whitespace();
				if (object) {
					if (source[offset] !== "\"") return invalid("オブジェクトのkeyが不正です。");
					const key = string();
					if (keys.has(key)) return invalid(`key「${key}」が重複しています。`);
					keys.add(key);
					whitespace();
					if (source[offset++] !== ":") return invalid("keyの後にコロンが必要です。");
					result[key] = value(depth + 1);
				} else result.push(value(depth + 1));
				whitespace();
				const delimiter = source[offset++];
				if (delimiter === end) return result;
				if (delimiter !== ",") return invalid("区切り文字が不正です。");
			}
			return invalid("JSONが閉じられていません。");
		}
		for (const [token, literal] of [
			["true", true],
			["false", false],
			["null", null]
		]) if (source.startsWith(token, offset)) {
			offset += token.length;
			return literal;
		}
		const token = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(source.slice(offset));
		if (!token) return invalid("値が不正です。");
		offset += token[0].length;
		const number = Number(token[0]);
		if (!Number.isFinite(number)) return invalid("有限でない数値は保存できません。");
		return number;
	}
	const result = value(1);
	whitespace();
	if (offset !== source.length) invalid("JSONの末尾に余分なデータがあります。");
	return result;
}
/** Keys are canonicalized, but all arrays retain their semantic order. */
function canonicalJson$1(value) {
	const active = /* @__PURE__ */ new Set();
	function encode(input) {
		if (input === null) return "null";
		if (typeof input === "string") {
			if (!isValidUnicode(input)) throw new StorageError("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return JSON.stringify(input);
		}
		if (typeof input === "boolean") return String(input);
		if (typeof input === "number") {
			if (!Number.isFinite(input)) throw new StorageError("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return JSON.stringify(input);
		}
		if (typeof input !== "object") throw new StorageError("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (active.has(input)) throw new StorageError("VALIDATION_FAILED", "循環したJSONは保存できません。");
		active.add(input);
		const encoded = Array.isArray(input) ? `[${input.map(encode).join(",")}]` : `{${Object.keys(input).filter((key) => input[key] !== void 0).sort().map((key) => `${JSON.stringify(key)}:${encode(input[key])}`).join(",")}}`;
		active.delete(input);
		return encoded;
	}
	return encode(value);
}
async function sha256(bytes) {
	const digest = await crypto.subtle.digest("SHA-256", bytes.slice().buffer);
	return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
}
function safeArchivePath(path) {
	if (!path || path.includes("\0") || path.includes("\\") || path.startsWith("/") || /^[a-z]:/i.test(path) || path.split("/").some((part) => !part || part === "." || part === "..") || !isValidUnicode(path)) throw new StorageError("UNSAFE_PATH", "危険なファイルパスです。", path);
}
var FORMAT_VERSION$1, ARCHIVE_LIMITS, jsonBytes, equalJson;
var init_json = __esmMin((() => {
	init_errors();
	FORMAT_VERSION$1 = "1.0.0";
	ARCHIVE_LIMITS = Object.freeze({
		compressedBytes: 67108864,
		expandedBytes: 268435456,
		jsonBytes: 67108864,
		assetBytes: 33554432,
		files: 5e3,
		records: 1e5,
		depth: 32,
		objects: 5e5,
		conditionDepth: 16,
		conditionNodes: 256,
		fieldBytes: 1048576
	});
	jsonBytes = (value) => new TextEncoder().encode(canonicalJson$1(value));
	equalJson = (left, right) => canonicalJson$1(left) === canonicalJson$1(right);
}));

//#endregion
//#region src/domain/pinnedWorlds.ts
function createPinnedWorldDigestCache() {
	return {
		hashes: /* @__PURE__ */ new WeakMap(),
		registryClones: /* @__PURE__ */ new WeakMap(),
		stableRegistries: /* @__PURE__ */ new WeakSet()
	};
}
/** Clone a caller-owned registry once for a durable validation run, then reuse that frozen image. */
function freezePinnedWorldRegistry(snapshots, cache) {
	const existing = cache.registryClones.get(snapshots);
	if (existing) return existing;
	const frozen = structuredClone(snapshots);
	cache.registryClones.set(snapshots, frozen);
	cache.stableRegistries.add(frozen);
	return frozen;
}
/** One active immutable version per world project, including transitive dependencies. */
function resolvePinnedWorlds(project, snapshots) {
	const worlds = [], references = [], errors = [];
	const visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set(), projects = /* @__PURE__ */ new Map(), expectedHashes = /* @__PURE__ */ new Map();
	const pending = [...project.worldReferences].reverse().map((reference) => ({ reference }));
	let steps = 0;
	while (pending.length) {
		if (++steps > 2e5) {
			errors.push("共通世界の依存数が安全上限を超えています。");
			break;
		}
		const frame = pending.pop();
		if ("exit" in frame) {
			active.delete(frame.exit);
			continue;
		}
		const reference = frame.reference, id = reference.immutableSnapshotId;
		if (active.has(id)) {
			errors.push("共通世界の固定版参照が循環しています。");
			continue;
		}
		const expectedHash = expectedHashes.get(id);
		if (expectedHash && expectedHash !== reference.contentHash) {
			errors.push("同じ共通世界の固定版に異なる内容ハッシュが指定されています。");
			continue;
		}
		expectedHashes.set(id, reference.contentHash);
		const previous = projects.get(reference.projectId);
		if (previous && previous !== id) {
			errors.push("同じ共通世界の異なる版が同時に参照されています。");
			continue;
		}
		projects.set(reference.projectId, id);
		if (visited.has(id)) continue;
		const world = snapshots[id];
		if (!world || world.projectId !== reference.projectId) {
			errors.push("参照した共通世界の固定版がありません。");
			continue;
		}
		visited.add(id);
		active.add(id);
		references.push(reference);
		worlds.push(world);
		pending.push({ exit: id });
		if (!Array.isArray(world.worldReferences)) {
			errors.push("共通世界の依存参照が不正です。");
			continue;
		}
		for (const child of [...world.worldReferences].reverse()) pending.push({ reference: child });
	}
	return {
		worlds,
		references,
		errors
	};
}
/** Verify the exact immutable world images used by validation and runtime capture. */
async function verifyPinnedWorlds(project, snapshots, path = "worldReferences", cache) {
	const closure = resolvePinnedWorlds(project, snapshots);
	const issues = closure.errors.map((message) => ({
		code: "REFERENCE_INVALID",
		path,
		message
	}));
	for (const reference of closure.references) {
		const world = snapshots[reference.immutableSnapshotId];
		if (!world) continue;
		const key = `${reference.immutableSnapshotId}\0${reference.contentHash}`;
		let digests = cache?.hashes.get(world);
		if (cache && !digests) {
			digests = /* @__PURE__ */ new Map();
			cache.hashes.set(world, digests);
		}
		let digest = digests?.get(key);
		if (!digest) {
			digest = sha256(jsonBytes(world));
			digests?.set(key, digest);
		}
		if (await digest !== reference.contentHash) issues.push({
			code: "INTEGRITY_FAILED",
			path: `${path}.${reference.projectId}.${reference.immutableSnapshotId}.contentHash`,
			message: "共通世界の固定版内容ハッシュが一致しません。"
		});
	}
	return issues;
}
var init_pinnedWorlds = __esmMin((() => {
	init_json();
}));

//#endregion
//#region src/domain/adoption.ts
/** A draft may be shown to its author without contributing a current fact. */
function adoptedRecord(record) {
	return !record.deletedAt && record.status !== "rejected" && record.status !== "alternate";
}
var init_adoption = __esmMin((() => {}));

//#endregion
//#region src/domain/reuse.ts
function fixedReferenceVersion(record, path) {
	let current = record;
	for (const key of path.replace(/\[(\d+)\]/g, ".$1").split(".")) {
		if (!current || typeof current !== "object") return;
		if ("sourceVersionId" in current && typeof current.sourceVersionId === "string") return current.sourceVersionId;
		current = current[key];
	}
}
function fail$3(message) {
	throw Object.assign(/* @__PURE__ */ new Error(`REFERENCE_INVALID: ${message}`), { issues: [{
		code: "REFERENCE_INVALID",
		path: "reuse",
		message
	}] });
}
function ownedContentIds(value) {
	if (Array.isArray(value)) return value.flatMap(ownedContentIds);
	if (!value || typeof value !== "object") return [];
	const record = value;
	return [...typeof record.id === "string" && ("text" in record && "kind" in record || "audienceHolderIds" in record || "eventKey" in record || "x" in record && "y" in record) ? [record.id] : [], ...Object.values(record).flatMap(ownedContentIds)];
}
function moduleRecords(content, sourceId, versionId) {
	const byId = new Map(content.entities.filter(adoptedRecord).map((entity) => [entity.id, entity]));
	const blocks = new Map(content.entities.flatMap((entity) => ownedContentIds(entity.data).map((id) => [id, entity.id])));
	const disclosures = /* @__PURE__ */ new Map();
	for (const entity of byId.values()) if (entity.kind === "disclosure") disclosures.set(entity.data.anchor.entityId, [...disclosures.get(entity.data.anchor.entityId) ?? [], entity]);
	const queue = [sourceId], visited = /* @__PURE__ */ new Set(), result = [];
	for (let offset = 0; offset < queue.length; offset++) {
		const id = queue[offset];
		if (visited.has(id)) continue;
		visited.add(id);
		const record = byId.get(id);
		if (!record) fail$3("共通元の依存情報が存在しないか、不採用です。");
		result.push(record);
		for (const disclosure of disclosures.get(id) ?? []) queue.push(disclosure.id);
		for (const reference of collectReferences(record)) {
			if (record.kind === "scene" && reference.path === "data.chapterId") continue;
			if (fixedReferenceVersion(record, reference.path)) continue;
			if (![
				"entity",
				"record",
				"presentation",
				"block"
			].includes(reference.scope)) continue;
			const dependency = byId.has(reference.id) ? reference.id : blocks.get(reference.id);
			if (dependency) queue.push(dependency);
		}
		if (result.length > 1e5) fail$3("共通元の依存情報が100,000件を超えています。");
	}
	return result;
}
function compatibleShared(source, target, bindings) {
	return !!target && [
		"variable",
		"item",
		"character",
		"place",
		"group",
		"assertion",
		"external_contract"
	].includes(source.kind) && target.kind === source.kind && adoptedRecord(target) && source.status === target.status && source.name === target.name && same(rewriteEntityReferences(source, bindings).data, target.data);
}
function rewriteEmbeddedIds(value, bindings) {
	if (Array.isArray(value)) {
		value.forEach((item) => rewriteEmbeddedIds(item, bindings));
		return;
	}
	if (!value || typeof value !== "object") return;
	const record = value;
	if (typeof record.id === "string" && ("text" in record && "kind" in record || "audienceHolderIds" in record || "eventKey" in record || "x" in record && "y" in record)) record.id = bindings[record.id] ?? record.id;
	Object.values(record).forEach((item) => rewriteEmbeddedIds(item, bindings));
}
function mapRecord(record, bindings, projectId, versionId) {
	const copy = rewriteEntityReferences(record, bindings);
	copy.id = bindings[record.id] ?? record.id;
	copy.projectId = projectId;
	rewriteEmbeddedIds(copy.data, bindings);
	for (const reference of collectReferences(record)) if (fixedReferenceVersion(record, reference.path)) {
		const parts = reference.path.replace(/\[(\d+)\]/g, ".$1").split(".");
		let current = copy;
		for (const key of parts.slice(0, -1)) current = current[key];
		current[parts.at(-1)] = reference.id;
	}
	return copy;
}
/** A derived execution view. Its namespace is persisted in the reuse declaration,
* but borrowed records are never appended to the author's document or snapshots. */
function resolveReuseContent(project, snapshots, ancestors = []) {
	if (origins.has(project) || !project.entities.some((entity) => adoptedRecord(entity) && reusable(entity) && entity.data.reuse && entity.data.reuse.mode !== "clone")) return project;
	const entities = new Map(project.entities.map((entity) => [entity.id, entity])), metadata = /* @__PURE__ */ new Map();
	const authorIds = /* @__PURE__ */ new Set([
		...project.entities.flatMap((entity) => [entity.id, ...ownedContentIds(entity.data)]),
		...project.relations.map((relation) => relation.id),
		...project.views.map((view) => view.id),
		project.projectId
	]);
	const worlds = new Map(project.worldReferences.map((reference) => [reference.projectId, reference]));
	for (const owner of project.entities) {
		if (!adoptedRecord(owner) || !reusable(owner) || !owner.data.reuse || owner.data.reuse.mode === "clone") continue;
		const reuse = owner.data.reuse, snapshot = snapshots.find((item) => item.id === reuse.pinnedSnapshotId);
		if (!snapshot || snapshot.content.projectId !== project.projectId) fail$3("共通元の固定版がありません。");
		if (ancestors.includes(snapshot.id) || ancestors.length >= 32) fail$3("共通元の固定参照が循環しているか、32段を超えています。");
		const sourceContent = resolveReuseContent(snapshot.content, snapshots, [...ancestors, snapshot.id]);
		const source = sourceContent.entities.find((entity) => entity.id === reuse.sourceId && adoptedRecord(entity));
		if (!source || source.kind !== owner.kind || !reusable(source)) fail$3("共通元の種類が一致しないか、固定版で不採用です。");
		const records = moduleRecords(sourceContent, source.id, snapshot.id), sourceIds = idsOf(records), bindings = reuse.bindings;
		if (!bindings || bindings[source.id] !== owner.id || sourceIds.length !== Object.keys(bindings).length || sourceIds.some((id) => !bindings[id]) || new Set(Object.values(bindings)).size !== sourceIds.length) fail$3("共通元のID対応が欠落・重複しています。対象版を確認して再設定してください。");
		for (const [original, useId] of Object.entries(bindings)) if (useId !== owner.id && authorIds.has(useId)) {
			const declaration = records.find((record) => record.id === original);
			if (original !== useId || !declaration || !compatibleShared(declaration, entities.get(useId), bindings)) fail$3("共通元の実行用IDが現在稿のレコード・段落・関係と衝突しています。ID対応を確認し直してください。");
		}
		const allowed = new Set(Object.keys(source.data).filter((field) => !["reuse", "chapterId"].includes(field)));
		if (reuse.mode === "reference" && reuse.overrideFields.length || reuse.overrideFields.some((field) => !allowed.has(field))) fail$3("上書き対象が不正です。宣言したフィールドだけを上書きしてください。");
		for (const reference of sourceContent.worldReferences) {
			const old = worlds.get(reference.projectId);
			if (old && !same(old, reference)) fail$3("共通元と使用先が同じ世界の異なる固定版を要求しています。適用する版を明示して揃えてください。");
			worlds.set(reference.projectId, reference);
		}
		const sourceGraph = sourceContent.entities.find((entity) => entity.kind === "flow_graph" && source.kind === "flow_node" && entity.data.nodeIds.includes(source.id));
		const sourceScene = source.kind === "scene" ? source : sourceContent.entities.find((entity) => source.kind === "flow_node" && entity.id === source.data.sceneId && entity.kind === "scene");
		for (const record of records) {
			const mapped = mapRecord(record, bindings, project.projectId, snapshot.id), id = mapped.id, existing = entities.get(id);
			if (id !== owner.id && existing) {
				if (record.id !== id || !compatibleShared(record, existing, bindings)) fail$3("共通元の実行用IDが現在稿と衝突しています。対応を再確認してください。");
				continue;
			}
			const priorOrigin = reuseOrigin(sourceContent, record.id);
			const originBindings = priorOrigin ? Object.fromEntries(Object.entries(priorOrigin.bindings).flatMap(([original, intermediate]) => bindings[intermediate] ? [[original, bindings[intermediate]]] : [])) : bindings;
			metadata.set(id, {
				entityId: priorOrigin?.entityId ?? record.id,
				sourceVersionId: priorOrigin?.sourceVersionId ?? snapshot.id,
				ownerId: owner.id,
				bindings: originBindings,
				graphId: sourceGraph ? bindings[sourceGraph.id] ?? sourceGraph.id : void 0,
				chapterId: sourceScene?.kind === "scene" && sourceScene.data.chapterId ? bindings[sourceScene.data.chapterId] ?? sourceScene.data.chapterId : void 0
			});
			if (id === owner.id) {
				const data = { ...mapped.data };
				delete data.reuse;
				for (const field of reuse.overrideFields) if (Object.hasOwn(owner.data, field)) data[field] = structuredClone(owner.data[field]);
				else delete data[field];
				if (owner.kind === "scene") data.chapterId = owner.data.chapterId ?? null;
				entities.set(id, {
					...owner,
					data
				});
			} else entities.set(id, mapped);
		}
		if (entities.size > 1e5) fail$3("再利用を解決した実行情報が100,000件を超えています。");
	}
	const allIds = /* @__PURE__ */ new Set();
	for (const id of [...entities.values()].flatMap((entity) => [entity.id, ...ownedContentIds(entity.data)]).concat(project.relations.map((relation) => relation.id), project.views.map((view) => view.id))) {
		if (allIds.has(id)) fail$3("再利用先どうしでレコード・段落等のIDが衝突しています。ID対応を確認し直してください。");
		allIds.add(id);
	}
	const view = {
		...project,
		entities: [...entities.values()],
		worldReferences: [...worlds.values()]
	};
	origins.set(view, metadata);
	canonical.set(view, project);
	return view;
}
function reuseTargetAnchor(project, anchor) {
	if (anchor.sourceVersionId) return anchor;
	const origin = reuseOrigin(project, anchor.entityId);
	if (!origin) return anchor;
	const owner = reuseAuthorContent(project).entities.find((entity) => entity.id === anchor.entityId);
	if (!anchor.blockId && !anchor.lineId && owner && reusable(owner) && owner.data.reuse?.mode === "override" && owner.data.reuse.overrideFields.includes("body")) return anchor;
	const reverse = new Map(Object.entries(origin.bindings).map(([source, use]) => [use, source]));
	if (anchor.blockId && !reverse.has(anchor.blockId) || anchor.lineId && !reverse.has(anchor.lineId)) return anchor;
	return {
		...anchor,
		entityId: origin.entityId,
		sourceVersionId: origin.sourceVersionId,
		...anchor.blockId ? { blockId: reverse.get(anchor.blockId) ?? anchor.blockId } : {},
		...anchor.lineId ? { lineId: reverse.get(anchor.lineId) ?? anchor.lineId } : {}
	};
}
function reuseRuleContexts(project, base) {
	return Object.fromEntries([...origins.get(project) ?? []].map(([id, origin]) => [id, {
		...base,
		graphId: base.graphId ? origin.bindings[base.graphId] ?? base.graphId : void 0,
		chapterId: base.chapterId ? origin.bindings[base.chapterId] ?? base.chapterId : void 0,
		sourceVersionId: origin.sourceVersionId,
		anchorBindings: origin.bindings
	}]));
}
/** Fixed author anchors keep their real namespace. Only the originating borrowed
* declaration translates them while evaluating an occurrence of that module. */
function reuseExecutionAnchor(project, anchor, declarationId) {
	const origin = reuseOrigin(project, declarationId);
	if (!origin || anchor.sourceVersionId !== origin.sourceVersionId) return anchor;
	return {
		...anchor,
		entityId: origin.bindings[anchor.entityId] ?? anchor.entityId,
		...anchor.blockId ? { blockId: origin.bindings[anchor.blockId] ?? anchor.blockId } : {},
		...anchor.lineId ? { lineId: origin.bindings[anchor.lineId] ?? anchor.lineId } : {}
	};
}
function reuseValidationIssues(project, snapshots, path) {
	if (!project.entities.some((entity) => reusable(entity) && entity.data.reuse?.bindings)) return [];
	try {
		resolveReuseContent(project, snapshots);
		return [];
	} catch (error) {
		return [{
			code: "REFERENCE_INVALID",
			path: `${path}.reuse`,
			message: error.message
		}];
	}
}
var origins, canonical, reuseOrigin, reuseAuthorContent, reusable, idsOf, same;
var init_reuse = __esmMin((() => {
	init_model();
	init_adoption();
	init_json();
	origins = /* @__PURE__ */ new WeakMap();
	canonical = /* @__PURE__ */ new WeakMap();
	reuseOrigin = (project, id) => origins.get(project)?.get(id);
	reuseAuthorContent = (project) => canonical.get(project) ?? project;
	reusable = (entity) => entity.kind === "scene" || entity.kind === "flow_node";
	idsOf = (records) => [...new Set(records.flatMap((entity) => [entity.id, ...ownedContentIds(entity.data)]))];
	same = (left, right) => canonicalJson$1(left) === canonicalJson$1(right);
}));

//#endregion
//#region src/domain/types.ts
var FORMAT_VERSION;
var init_types = __esmMin((() => {
	FORMAT_VERSION = "1.0.0";
}));

//#endregion
//#region src/domain/time.ts
function isTick(value) {
	return typeof value === "string" && TICK_PATTERN.test(value);
}
function parseTick(value) {
	if (!isTick(value)) throw new RangeError("tickは38桁以内の正規整数文字列で指定してください。");
	return BigInt(value);
}
function toTick(value) {
	if (value < -MAX_TICK || value > MAX_TICK) throw new RangeError("tickが38桁の範囲を超えています。");
	return value.toString();
}
function addTicks(a, b) {
	return toTick(parseTick(a) + parseTick(b));
}
function compareTicks(a, b) {
	const x = parseTick(a), y = parseTick(b);
	return x < y ? -1 : x > y ? 1 : 0;
}
function validateCalendar(input, path = "calendar") {
	const fail = (message, field = path) => ({
		ok: false,
		issues: [{
			code: "VALIDATION_FAILED",
			path: field,
			message
		}]
	});
	if (!input || typeof input !== "object" || Array.isArray(input)) return fail("暦はオブジェクトです。");
	const cal = input;
	const allowed = cal.kind === "repeating" ? [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay",
		"years"
	] : [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay"
	];
	if (Object.keys(cal).some((key) => !allowed.includes(key))) return fail("暦に未知の項目があります。");
	if (typeof cal.id !== "string" || !cal.id || typeof cal.name !== "string" || !cal.name || typeof cal.originLabel !== "string") return fail("暦のID・名称・原点ラベルが必要です。");
	if (!isTick(cal.ticksPerDay) || parseTick(cal.ticksPerDay) <= 0n) return fail("1日のtick数は正の整数です。", `${path}.ticksPerDay`);
	if (cal.kind === "gregorian") {
		if (cal.ticksPerDay !== "86400") return fail("標準暦は1日86400tickです。", `${path}.ticksPerDay`);
		return {
			ok: true,
			value: input
		};
	}
	if (cal.kind !== "repeating" || !Array.isArray(cal.years) || cal.years.length < 1 || cal.years.length > 400) return fail("繰返し暦は1〜400年の周期が必要です。");
	for (let i = 0; i < cal.years.length; i++) {
		const year = cal.years[i];
		if (!year || typeof year !== "object" || Object.keys(year).some((key) => key !== "months") || !Array.isArray(year.months) || year.months.length < 1 || year.months.length > 24) return fail("1年の月数は1〜24です。", `${path}.years[${i}]`);
		for (let j = 0; j < year.months.length; j++) {
			const month = year.months[j];
			if (!month || typeof month !== "object" || Object.keys(month).some((key) => !["name", "days"].includes(key)) || typeof month.name !== "string" || !month.name || !Number.isInteger(month.days) || month.days < 1 || month.days > 400) return fail("月名と1〜400の日数が必要です。", `${path}.years[${i}].months[${j}]`);
		}
	}
	return {
		ok: true,
		value: input
	};
}
function absoluteResolution(time, path) {
	try {
		if (time.mode === "unknown") return {
			status: "unknown",
			reason: time.reason || "日時が未定です。",
			path
		};
		if (time.mode === "instant") {
			parseTick(time.at);
			return {
				status: "resolved",
				earliest: time.at,
				latest: time.at,
				endEarliest: time.at,
				endLatest: time.at,
				calendarId: time.calendarId,
				mode: time.mode
			};
		}
		if (time.mode === "interval") {
			if (compareTicks(time.start, time.end) >= 0) return {
				status: "conflict",
				reason: "期間は開始より後に終了してください。",
				path
			};
			return {
				status: "resolved",
				earliest: time.start,
				latest: time.start,
				endEarliest: time.end,
				endLatest: time.end,
				calendarId: time.calendarId,
				mode: time.mode
			};
		}
		if (compareTicks(time.earliest, time.latest) > 0) return {
			status: "conflict",
			reason: "概算範囲が逆転しています。",
			path
		};
		return {
			status: "resolved",
			earliest: time.earliest,
			latest: time.latest,
			endEarliest: time.earliest,
			endLatest: time.latest,
			calendarId: time.calendarId,
			mode: time.mode
		};
	} catch (error) {
		return {
			status: "conflict",
			reason: error instanceof Error ? error.message : "日時を解決できません。",
			path
		};
	}
}
function relativeValue(time, anchor, path, prefixUnknown) {
	try {
		if (compareTicks(time.minOffset, time.maxOffset) > 0) return {
			status: "conflict",
			reason: "相対日時の範囲が逆転しています。",
			path: path()
		};
		if (anchor.status !== "resolved") return prefixUnknown ? {
			...anchor,
			path: [...path(), ...anchor.path].slice(0, 64)
		} : anchor;
		const earliest = addTicks(time.anchorPoint === "start" ? anchor.earliest : anchor.endEarliest, time.minOffset), latest = addTicks(time.anchorPoint === "start" ? anchor.latest : anchor.endLatest, time.maxOffset);
		return {
			status: "resolved",
			earliest,
			latest,
			endEarliest: earliest,
			endLatest: latest,
			calendarId: anchor.calendarId,
			mode: "relative"
		};
	} catch (error) {
		return {
			status: "conflict",
			reason: error instanceof Error ? error.message : "日時を解決できません。",
			path: path()
		};
	}
}
/** One relative-time evaluator shared by validation, previews and character lifetimes. */
function resolveRelativeTime(time, anchor, path = []) {
	return relativeValue(time, anchor, () => path, true);
}
function eventIndex(events) {
	const index = /* @__PURE__ */ new Map();
	for (const event of events) if (!event.deletedAt && !index.has(event.id)) index.set(event.id, event);
	return index;
}
/** Public arbitrary-TimeSpec wrapper. The supplied chain remains a set of forbidden ancestor IDs. */
function resolveTime(time, events = [], chain = []) {
	if (time.mode !== "relative") return absoluteResolution(time, chain);
	const index = eventIndex(events), path = [...chain], visited = new Set(chain), frames = [];
	let cursor = time;
	while (cursor.mode === "relative") {
		if (visited.has(cursor.anchorEventId)) return {
			status: "conflict",
			reason: "相対日時の参照が循環しています。",
			path: [...path, cursor.anchorEventId]
		};
		try {
			if (compareTicks(cursor.minOffset, cursor.maxOffset) > 0) return {
				status: "conflict",
				reason: "相対日時の範囲が逆転しています。",
				path: [...path]
			};
		} catch (error) {
			return {
				status: "conflict",
				reason: error instanceof Error ? error.message : "日時を解決できません。",
				path: [...path]
			};
		}
		const anchor = index.get(cursor.anchorEventId);
		if (!anchor) return {
			status: "unknown",
			reason: "基準となる出来事がありません。",
			path: [...path, cursor.anchorEventId]
		};
		frames.push({
			time: cursor,
			pathLength: path.length
		});
		visited.add(anchor.id);
		path.push(anchor.id);
		cursor = anchor.data.time;
	}
	let resolved = absoluteResolution(cursor, path);
	for (let i = frames.length - 1; i >= 0 && resolved.status === "resolved"; i--) {
		const frame = frames[i];
		resolved = relativeValue(frame.time, resolved, () => path.slice(0, frame.pathLength), false);
	}
	return resolved;
}
/** Indexed and iterative O(events + anchors). Diagnostic paths are bounded for cyclic imported graphs. */
function resolveEventTimes(events) {
	const index = eventIndex(events), resolved = /* @__PURE__ */ new Map();
	for (const event of index.values()) {
		if (resolved.has(event.id)) continue;
		const path = [], visiting = /* @__PURE__ */ new Map();
		let cursor = event.id;
		while (!resolved.has(cursor)) {
			const current = index.get(cursor);
			if (!current) {
				resolved.set(cursor, {
					status: "unknown",
					reason: "基準となる出来事がありません。",
					path: [cursor]
				});
				break;
			}
			const cycleStart = visiting.get(cursor);
			if (cycleStart !== void 0) {
				const cycle = path.slice(cycleStart);
				for (let i = 0; i < cycle.length; i++) resolved.set(cycle[i], {
					status: "conflict",
					reason: "相対日時の参照が循環しています。",
					path: Array.from({ length: Math.min(cycle.length + 1, 64) }, (_, offset) => cycle[(i + offset) % cycle.length])
				});
				break;
			}
			if (current.data.time.mode !== "relative") {
				resolved.set(cursor, absoluteResolution(current.data.time, [cursor]));
				break;
			}
			const relative = current.data.time;
			if (!visiting.has(relative.anchorEventId) && relative.anchorEventId !== cursor) try {
				if (compareTicks(relative.minOffset, relative.maxOffset) > 0) {
					resolved.set(cursor, {
						status: "conflict",
						reason: "相対日時の範囲が逆転しています。",
						path: [cursor]
					});
					break;
				}
			} catch (error) {
				resolved.set(cursor, {
					status: "conflict",
					reason: error instanceof Error ? error.message : "日時を解決できません。",
					path: [cursor]
				});
				break;
			}
			visiting.set(cursor, path.length);
			path.push(cursor);
			cursor = relative.anchorEventId;
		}
		for (let i = path.length - 1; i >= 0; i--) {
			const id = path[i], current = index.get(id);
			if (!resolved.has(id) && current.data.time.mode === "relative") resolved.set(id, resolveRelativeTime(current.data.time, resolved.get(current.data.time.anchorEventId), [id]));
		}
	}
	return resolved;
}
function validateEventTimes(events) {
	const issues = [], index = eventIndex(events), times = resolveEventTimes(events);
	for (const event of index.values()) {
		const time = times.get(event.id);
		if (time.status === "conflict") issues.push({
			code: "TIME_CONSTRAINT_CONFLICT",
			path: `entities.${event.id}.data.time`,
			message: time.reason
		});
		for (const constraint of event.data.constraints ?? []) {
			const target = index.get(constraint.targetEventId);
			if (!target || time.status !== "resolved") continue;
			const other = times.get(target.id);
			if (other.status !== "resolved") continue;
			let conflict = time.calendarId !== other.calendarId;
			if (constraint.type === "before") conflict ||= time.mode === "interval" ? compareTicks(time.endEarliest, other.latest) > 0 : compareTicks(time.endEarliest, other.latest) >= 0;
			else if (constraint.type === "same_start") conflict ||= compareTicks(time.earliest, other.latest) > 0 || compareTicks(other.earliest, time.latest) > 0;
			else {
				const minGap = parseTick(other.earliest) - parseTick(time.endLatest), maxGap = parseTick(other.latest) - parseTick(time.endEarliest);
				conflict ||= maxGap < parseTick(constraint.minimumTicks) || minGap > parseTick(constraint.maximumTicks);
			}
			if (conflict) issues.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${event.id}.data.constraints`,
				message: "指定した出来事の日時制約と矛盾しています。"
			});
		}
	}
	const colors = /* @__PURE__ */ new Map(), dependencies = /* @__PURE__ */ new Map();
	for (const event of index.values()) dependencies.set(event.id, (event.data.constraints ?? []).map((constraint) => constraint.targetEventId));
	for (const event of index.values()) if (event.data.time.mode === "relative" && index.has(event.data.time.anchorEventId)) dependencies.get(event.data.time.anchorEventId).push(event.id);
	for (const event of index.values()) {
		if (colors.get(event.id)) continue;
		const stack = [{
			id: event.id,
			targets: dependencies.get(event.id),
			cursor: 0
		}];
		colors.set(event.id, 1);
		while (stack.length) {
			const current = stack[stack.length - 1];
			if (current.cursor === current.targets.length) {
				colors.set(current.id, 2);
				stack.pop();
				continue;
			}
			const targetId = current.targets[current.cursor++], target = index.get(targetId);
			if (!target) continue;
			if (colors.get(targetId) === 1) issues.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${current.id}.data.constraints`,
				message: "日時制約の依存が循環しています。"
			});
			else if (!colors.has(targetId)) {
				colors.set(targetId, 1);
				stack.push({
					id: targetId,
					targets: dependencies.get(target.id),
					cursor: 0
				});
			}
		}
	}
	return issues;
}
/** Shared IDs are safe only when the complete calendar definition is unchanged. */
function sameCalendarDefinition(left, right) {
	if (left.id !== right.id || left.kind !== right.kind || left.name !== right.name || left.originLabel !== right.originLabel || left.ticksPerDay !== right.ticksPerDay) return false;
	if (left.kind === "gregorian" || right.kind === "gregorian") return left.kind === right.kind;
	return left.years.length === right.years.length && left.years.every((year, i) => year.months.length === right.years[i].months.length && year.months.every((month, j) => month.name === right.years[i].months[j].name && month.days === right.years[i].months[j].days));
}
var TICK_PATTERN, MAX_TICK, GREGORIAN_CALENDAR;
var init_time = __esmMin((() => {
	TICK_PATTERN = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/;
	MAX_TICK = 10n ** 38n - 1n;
	GREGORIAN_CALENDAR = {
		id: "proleptic-gregorian-second",
		name: "先発グレゴリオ暦",
		kind: "gregorian",
		originLabel: "0000-01-01 00:00:00",
		ticksPerDay: "86400"
	};
}));

//#endregion
//#region src/domain/templates.ts
function isEditableFieldDefinition(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const field = value;
	return typeof field.key === "string" && typeof field.label === "string" && FIELD_TYPES.includes(field.type) && typeof field.required === "boolean" && typeof field.nullable === "boolean" && (field.help == null || typeof field.help === "string") && (field.allowedValues == null || Array.isArray(field.allowedValues) && field.allowedValues.every((value) => typeof value === "string")) && (field.targetKinds == null || Array.isArray(field.targetKinds) && field.targetKinds.every((kind) => Object.hasOwn(ENTITY_SCHEMAS, kind)));
}
function standardFieldKeys(kind) {
	const schema = ENTITY_SCHEMAS[kind];
	return [...COMMON_KEYS, ...schema?.type === "object" ? Object.keys(schema.fields) : []];
}
/** The same value checks serve previews, normal forms, saves and file imports. */
function validateCustomFieldValue(field, value, path, entities) {
	if (value === void 0) return field.required ? [problem$1(path, `「${field.label}」は必須項目です。`)] : [];
	if (value === null) return field.nullable ? [] : [problem$1(path, `「${field.label}」は空欄を許可していません。`)];
	let matches = false;
	if (field.type === "text") matches = typeof value === "string" && (!field.required || value.trim().length > 0);
	if (field.type === "number") matches = typeof value === "number" && Number.isFinite(value);
	if (field.type === "boolean") matches = typeof value === "boolean";
	if (field.type === "enum") matches = typeof value === "string" && !!field.allowedValues?.includes(value);
	if (field.type === "date" || field.type === "ref") {
		const typed = value && typeof value === "object" && !Array.isArray(value) ? value : void 0;
		matches = typed?.type === field.type && typeof typed.value === "string";
		if (matches && field.type === "date") {
			const date = typed.value;
			const parsed = /^\d{4}-\d{2}-\d{2}$/.test(date) ? /* @__PURE__ */ new Date(`${date}T00:00:00.000Z`) : /* @__PURE__ */ new Date(NaN);
			matches = Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === date;
		}
		if (matches && field.type === "ref") {
			const id = typed.value;
			if (!ID_PATTERN.test(id)) matches = false;
			else if (entities) {
				const target = "get" in entities ? entities.get(id) : entities.find((entity) => entity.id === id);
				if (!target || target.deletedAt || field.targetKinds?.length && !field.targetKinds.includes(target.kind)) return [problem$1(path, `「${field.label}」の参照先が存在しないか、許可された種類ではありません。`, "REFERENCE_INVALID")];
			}
		}
	}
	return matches ? [] : [problem$1(path, `「${field.label}」の値が宣言した${field.type}型または選択候補と一致しません。`)];
}
function validateTemplateDefinition(data, path = "data", entities) {
	const issues = [];
	if (!data || !Array.isArray(data.fields)) return [problem$1(`${path}.fields`, "項目定義は配列で入力してください。")];
	if (!Object.hasOwn(ENTITY_SCHEMAS, data.targetKind)) issues.push(problem$1(`${path}.targetKind`, "対象の情報の種類を選んでください。"));
	if (data.defaults != null && (typeof data.defaults !== "object" || Array.isArray(data.defaults))) issues.push(problem$1(`${path}.defaults`, "初期値は項目キーごとの辞書で指定してください。"));
	const keys = /* @__PURE__ */ new Set(), standards = new Set(standardFieldKeys(data.targetKind));
	for (const [index, field] of data.fields.entries()) {
		const fieldPath = `${path}.fields[${index}]`;
		if (!isEditableFieldDefinition(field)) {
			issues.push(problem$1(fieldPath, "項目定義のキー・表示名・型・必須・空欄・説明・候補・参照先の形式を確認してください。"));
			continue;
		}
		if (!field.key.trim() || keys.has(field.key) || standards.has(field.key) || RESERVED_KEYS.includes(field.key)) issues.push(problem$1(`${fieldPath}.key`, "キーが空欄・重複・予約済み、または標準項目と衝突しています。"));
		keys.add(field.key);
		if (field.type === "enum" && (!Array.isArray(field.allowedValues) || !field.allowedValues.length || field.allowedValues.some((value) => typeof value !== "string" || !value.trim()) || new Set(field.allowedValues).size !== field.allowedValues.length)) issues.push(problem$1(`${fieldPath}.allowedValues`, "選択型には空欄と重複のない候補を指定してください。"));
		if (field.type !== "enum" && field.allowedValues?.length) issues.push(problem$1(`${fieldPath}.allowedValues`, "選択候補はenum型だけに設定できます。"));
		if (field.type !== "ref" && field.targetKinds?.length) issues.push(problem$1(`${fieldPath}.targetKinds`, "参照先の種類はref型だけに設定できます。"));
		if (!Object.hasOwn(field, "default")) issues.push(problem$1(`${fieldPath}.default`, "項目の初期値を指定してください。"));
		else issues.push(...validateCustomFieldValue(field, field.default, `${fieldPath}.default`, entities));
	}
	const declared = data.fields.filter(isEditableFieldDefinition);
	const defaults = data.defaults && typeof data.defaults === "object" && !Array.isArray(data.defaults) ? data.defaults : {};
	for (const [key, value] of Object.entries(defaults)) {
		const field = declared.find((field) => field.key === key);
		if (!field) issues.push(problem$1(`${path}.defaults.${key}`, "初期値のキーを項目定義へ追加してください。"));
		else issues.push(...validateCustomFieldValue(field, value, `${path}.defaults.${key}`, entities));
	}
	return issues;
}
function validateTemplateAssignments(project, path = "project", referenceEntities = project.entities) {
	const templates = new Map(referenceEntities.filter((entity) => entity.kind === "template").map((template) => [template.id, template]));
	const issues = [];
	const referenceIndex = new Map(referenceEntities.map((entity) => [entity.id, entity]));
	project.entities.forEach((entity, index) => {
		const bound = entity;
		if (entity.deletedAt || !bound.templateId) return;
		const location = `${path}.entities[${index}]`, template = templates.get(bound.templateId);
		if (!template || template.deletedAt || template.status === "rejected" || template.data.targetKind !== entity.kind) {
			issues.push(problem$1(`${location}.templateId`, "適用した雛形が存在しない・不採用・削除済み、または対象の種類が異なります。", "REFERENCE_INVALID"));
			return;
		}
		for (const field of template.data.fields) issues.push(...validateCustomFieldValue(field, entity.customValues[field.key], `${location}.customValues.${field.key}`, referenceIndex));
	});
	return issues;
}
var problem$1, COMMON_KEYS, RESERVED_KEYS, FIELD_TYPES;
var init_templates = __esmMin((() => {
	init_model();
	problem$1 = (path, message, code = "VALIDATION_FAILED") => ({
		path,
		message,
		code
	});
	COMMON_KEYS = [
		"id",
		"projectId",
		"kind",
		"revision",
		"name",
		"status",
		"visibility",
		"retainIfUnreferenced",
		"projectionProfileId",
		"templateId",
		"createdAt",
		"updatedAt",
		"deletedAt",
		"deletionOperationId",
		"customValues",
		"data"
	];
	RESERVED_KEYS = [
		"__proto__",
		"prototype",
		"constructor"
	];
	FIELD_TYPES = [
		"text",
		"number",
		"boolean",
		"enum",
		"date",
		"ref"
	];
}));

//#endregion
//#region src/domain/model.ts
function textToRichText(text) {
	return text === "" ? [] : text.split("\n").map((line) => ({
		id: newId(),
		kind: "paragraph",
		text: line
	}));
}
function richTextToPlainText(text) {
	return (text ?? []).map((block) => block.text).join("\n");
}
function getEntity$2(project, id) {
	return project.entities.find((entity) => entity.id === id && !entity.deletedAt);
}
function getEntitiesByKind(project, kind) {
	return project.entities.filter((entity) => entity.kind === kind && !entity.deletedAt);
}
function defaultData(kind) {
	const unknown = {
		type: "unknown",
		value: null,
		reason: "未入力"
	};
	const data = {
		character: {
			reading: "",
			aliases: [],
			summary: [],
			body: [],
			authorNotes: [],
			goals: [],
			voiceRules: []
		},
		group: {
			groupType: "display",
			members: [],
			parentId: null,
			summary: []
		},
		event: {
			summary: [],
			time: {
				mode: "unknown",
				reason: ""
			},
			laneRole: "common",
			participants: [],
			locationId: null,
			itemIds: [],
			authorNotes: [],
			constraints: []
		},
		place: {
			parentId: null,
			reading: "",
			aliases: [],
			body: [],
			mapIds: [],
			changes: []
		},
		item: {
			itemMode: "type",
			typeId: null,
			body: [],
			properties: null,
			changes: []
		},
		note: {
			body: [],
			attachmentIds: [],
			convertedToIds: [],
			originNoteId: null
		},
		chapter: {
			sceneIds: [],
			summary: [],
			authorNotes: [],
			structureRole: ""
		},
		scene: {
			summary: [],
			body: [],
			authorNotes: [],
			eventIds: [],
			chapterId: null,
			threadIds: [],
			povId: null,
			goals: [],
			conflicts: [],
			results: [],
			newInformation: [],
			tension: null,
			importance: null,
			blockIds: []
		},
		goal: {
			ownerId: null,
			description: [],
			changes: [],
			evidenceSceneIds: [],
			validity: emptyValidity()
		},
		flow_node: {
			nodeType: "choice",
			sceneId: null,
			childGraphId: null,
			terminalReason: "",
			gate: {
				op: "constant",
				value: true
			},
			executionPolicy: "manual_choice",
			fallbackId: null
		},
		flow_edge: {
			fromId: null,
			toId: { unresolved: {
				label: "",
				reason: "未完成"
			} },
			edgeType: "choice",
			label: "",
			condition: {
				op: "constant",
				value: true
			},
			effectIds: [],
			priority: 0,
			choiceLineId: null
		},
		flow_graph: {
			nodeIds: [],
			edgeIds: [],
			entryIds: [],
			exitIds: [],
			parentGraphId: null,
			parameters: []
		},
		dialogue_line: {
			text: [],
			speakerId: null,
			choiceEdgeId: null,
			cueIds: [],
			originLineIds: []
		},
		quest: {
			key: "",
			stateVariableId: null,
			description: [],
			flowIds: [],
			transitionRules: [],
			gameplaySpecIds: []
		},
		lore: {
			body: [],
			assertionIds: [],
			sourceIds: [],
			reading: "",
			aliases: []
		},
		variable: {
			key: "",
			valueType: "boolean",
			scope: "run",
			initial: unknown,
			allowed: { values: [false, true] },
			description: [],
			ownerId: null,
			externalContractId: null,
			resetRules: [],
			transitionRules: [],
			externalUseDeclared: false
		},
		effect: {
			operation: "set",
			targetId: null,
			value: unknown,
			condition: {
				op: "constant",
				value: true
			},
			instanceId: null,
			reason: ""
		},
		assertion: {
			subjectId: null,
			predicate: "",
			value: unknown,
			truthKind: "author_truth",
			holderId: null,
			sourceIds: [],
			evidenceLocation: null,
			validity: emptyValidity(),
			reason: ""
		},
		foreshadow: {
			question: [],
			intent: [],
			resolutionPolicy: "undecided",
			truthAssertionIds: [],
			clueIds: [],
			payoffIds: [],
			requiredInfo: [],
			deadline: null,
			exceptions: []
		},
		disclosure: {
			foreshadowId: null,
			anchor: { entityId: null },
			stage: "hint",
			role: "clue",
			condition: {
				op: "constant",
				value: true
			},
			knowledgeEffects: [],
			targetScope: null
		},
		checkpoint: {
			contentVersionId: null,
			runtimeState: emptyRuntimeState(""),
			origin: "partial",
			traceId: null
		},
		trace: {
			contentVersionId: null,
			startCheckpointId: null,
			steps: [],
			seed: "",
			engineVersion: "1.0.0",
			externalMode: "stub"
		},
		attachment: {
			mediaType: "",
			contentHash: "",
			byteSize: 0,
			assetPath: "",
			displayName: "",
			stage: "reference",
			revisionHistory: []
		},
		source: {
			sourceType: "web",
			locator: "",
			accessedAt: null,
			excerptLocation: "",
			interpretation: [],
			attachmentId: null,
			redistributionAllowed: false
		},
		cue: {
			anchor: { entityId: null },
			cueType: "",
			attachmentId: null,
			speakerId: null,
			expression: "",
			waitMs: null,
			camera: null,
			mediaTime: null,
			stage: ""
		},
		storyboard_frame: {
			anchor: { entityId: null },
			mediaStartMs: 0,
			mediaEndMs: null,
			referenceAssetId: null,
			finalAssetId: null,
			cueIds: [],
			caption: []
		},
		localization: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			text: [],
			stage: "draft",
			reviewedBy: null,
			recordingIds: []
		},
		recording: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			translationId: null,
			attachmentId: null,
			notes: [],
			stage: "planned",
			reviewedBy: null
		},
		terminology: {
			canonical: "",
			reading: "",
			variants: [],
			language: null,
			usageNotes: [],
			validity: emptyValidity(),
			exceptions: [],
			voiceOwnerId: null
		},
		map: {
			placeId: null,
			coordinateSystem: "normalized",
			attachmentId: null,
			parentMapId: null,
			pins: []
		},
		travel_route: {
			fromPlaceId: null,
			toPlaceId: null,
			direction: "one_way",
			method: "",
			minimumTicks: null,
			maximumTicks: null,
			evidence: [],
			validity: emptyValidity()
		},
		template: {
			targetKind: "character",
			fields: [],
			description: "",
			version: "0",
			defaults: {}
		},
		collection: {
			mode: "fixed",
			memberIds: [],
			query: null,
			sort: {
				field: "name",
				direction: "asc"
			}
		},
		review: {
			target: null,
			targetVersionId: null,
			body: [],
			stage: "open",
			assigneeId: null,
			quotedText: "",
			resolution: []
		},
		creative_brief: {
			targetAudience: [],
			experience: [],
			theme: [],
			tone: [],
			scope: [],
			deliverableIds: [],
			decisionIds: []
		},
		decision: {
			subject: "",
			reason: [],
			targetVersionId: null,
			outcome: "deferred",
			priority: "",
			requirementIds: [],
			reviewIds: []
		},
		gameplay_spec: {
			sceneId: null,
			action: [],
			mechanic: "",
			tutorial: [],
			reward: null,
			questId: null,
			taskIds: [],
			intentionalDifference: ""
		},
		production_task: {
			targetIds: [],
			stage: "writing",
			progress: "todo",
			assigneeId: null,
			deadline: null,
			dependsOn: [],
			estimate: null,
			blockingReason: ""
		},
		media_variant: {
			medium: "novel",
			baseSnapshotId: null,
			body: [],
			releaseAt: null,
			projectionProfileId: null,
			sourceIds: [],
			needsReview: false
		},
		voice_rule: {
			characterId: null,
			validity: emptyValidity(),
			firstPerson: "",
			addressing: "",
			phrasing: "",
			examples: [],
			exceptions: []
		},
		external_contract: {
			key: "",
			owner: "tool",
			inputType: "boolean",
			outputType: "boolean",
			missingPolicy: "unknown",
			description: [],
			stubValues: [],
			adapterProfileIds: [],
			version: "1.0.0"
		},
		snapshot: {
			versionLabel: "",
			contentHash: "",
			immutable: true,
			parentVersionIds: [],
			releasedAt: null,
			referencedWorldVersionIds: []
		},
		projection_profile: {
			audience: "",
			includedIds: [],
			namePolicy: { mode: "exclude" },
			allowedKinds: [],
			excludedFields: ["authorNotes"],
			routeScope: null,
			includeAuthorNotes: false,
			publicTitle: "",
			publicTexts: {},
			allowedRelationIds: [],
			idPolicy: "remap"
		}
	};
	if (!(kind in data)) throw new RangeError("未対応の情報種別です。");
	return data[kind];
}
function createEntity(projectId, kind, name = "", data) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: newId(),
		projectId,
		kind,
		revision: "0",
		name,
		status: "provisional",
		visibility: "private",
		createdAt: now,
		updatedAt: now,
		customValues: {},
		data: {
			...defaultData(kind),
			...data
		}
	};
}
function createProject(name = "新しい作品") {
	return {
		projectId: newId(),
		name,
		formatVersion: FORMAT_VERSION,
		revision: "0",
		calendarId: GREGORIAN_CALENDAR.id,
		mainStart: "0",
		calendars: [structuredClone(GREGORIAN_CALENDAR)],
		worldReferences: [],
		entities: [],
		relations: [],
		snapshots: [],
		history: [],
		views: []
	};
}
function emptyRuntimeState(contentVersionId) {
	return {
		contentVersionId,
		variableValues: {},
		itemInstances: [],
		assertions: [],
		seenIds: [],
		visitCounts: {},
		onceTriggers: [],
		rngSeed: "scenario-1",
		rngPosition: 0,
		callStack: [],
		presentationPosition: null,
		loopNumber: 0,
		provenance: "full_play"
	};
}
function codePointLength(value) {
	let count = 0;
	for (let i = 0; i < value.length; i++, count++) {
		const code = value.charCodeAt(i), next = value.charCodeAt(i + 1);
		if (code >= 55296 && code <= 56319 && next >= 56320 && next <= 57343) i++;
	}
	return count;
}
function validUnicode(value) {
	for (let i = 0; i < value.length; i++) {
		const code = value.charCodeAt(i);
		if (code >= 55296 && code <= 56319) {
			const next = value.charCodeAt(++i);
			if (!(next >= 56320 && next <= 57343)) return false;
		} else if (code >= 56320 && code <= 57343) return false;
	}
	return true;
}
function addIssue(issues, path, message, code = "VALIDATION_FAILED") {
	if (issues.length < 256) issues.push({
		code,
		path,
		message
	});
}
function validDate(value) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
	const date = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
	return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function conditionSchema(value) {
	switch (value.op) {
		case "constant": return obj({
			op: req(en("constant")),
			value: req(bool)
		});
		case "all":
		case "any": return obj({
			op: req(en("all", "any")),
			children: req(arr(cond, false, 1, 256))
		});
		case "not": return obj({
			op: req(en("not")),
			child: req(cond)
		});
		case "compare": return obj({
			op: req(en("compare")),
			variableId: req(ref$1("variable")),
			comparator: req(en("eq", "ne", "lt", "le", "gt", "ge", "in")),
			value: req(value.comparator === "in" ? arr(typed$1, false, 1, 256) : typed$1)
		});
		case "item": return obj({
			op: req(en("item")),
			itemId: req(ref$1("item")),
			quantity: req(num(1, void 0, true))
		});
		case "known": return obj({
			op: req(en("known")),
			assertionId: req(ref$1("assertion")),
			holderId: req(ref$1("character"))
		});
		case "visited": return obj({
			op: req(en("visited")),
			entityId: req(ref$1()),
			count: req(num(1, void 0, true))
		});
		case "external": return obj({
			op: req(en("external")),
			contractId: req(ref$1("external_contract"))
		});
		default: return;
	}
}
function expressionSchema(value) {
	const expression = { type: "expression" };
	switch (value.op) {
		case "value": return obj({
			op: req(en("value")),
			value: req(typed$1)
		});
		case "variable": return obj({
			op: req(en("variable")),
			variableId: req(ref$1("variable"))
		});
		case "add":
		case "subtract":
		case "multiply": return obj({
			op: req(en("add", "subtract", "multiply")),
			left: req(expression),
			right: req(expression)
		});
		case "if": return obj({
			op: req(en("if")),
			condition: req(cond),
			then: req(expression),
			else: req(expression)
		});
		default: return conditionSchema(value);
	}
}
function timeSchema(value) {
	const calendarId = req(scopedRef("calendar"));
	switch (value.mode) {
		case "instant": return obj({
			mode: req(en("instant")),
			at: req(tick),
			calendarId
		});
		case "interval": return obj({
			mode: req(en("interval")),
			start: req(tick),
			end: req(tick),
			calendarId
		});
		case "uncertain": return obj({
			mode: req(en("uncertain")),
			earliest: req(tick),
			latest: req(tick),
			calendarId,
			precision: req(txt())
		});
		case "relative": return obj({
			mode: req(en("relative")),
			anchorEventId: req(ref$1("event")),
			anchorPoint: req(en("start", "end")),
			minOffset: req(tick),
			maxOffset: req(tick)
		});
		case "unknown": return obj({
			mode: req(en("unknown")),
			reason: req(txt())
		});
		default: return;
	}
}
function querySchema(value) {
	switch (value.op) {
		case "all":
		case "any": return obj({
			op: req(en("all", "any")),
			children: req(arr({ type: "query" }, false, 1, 256))
		});
		case "kind": return obj({
			op: req(en("kind")),
			value: req(en(...ENTITY_KINDS))
		});
		case "text": return obj({
			op: req(en("text")),
			value: req(txt())
		});
		case "status": return obj({
			op: req(en("status")),
			value: req(en(...STATUSES))
		});
		case "participant": return obj({
			op: req(en("participant")),
			characterId: req(ref$1("character"))
		});
		case "production": return obj({
			op: req(en("production")),
			value: req(en("todo", "doing", "done", "needs_review"))
		});
		case "chapter": return obj({
			op: req(en("chapter")),
			chapterId: req(ref$1("chapter"))
		});
		case "foreshadow": return obj({
			op: req(en("foreshadow")),
			foreshadowId: optionalValue(ref$1("foreshadow")),
			resolutionPolicy: optionalValue(en("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
			role: optionalValue(en("clue", "payoff")),
			stage: optionalValue(en("hint", "suspicion", "reinforce", "reveal", "alternative"))
		});
		default: return;
	}
}
function namePolicySchema(value) {
	if (!("mode" in value)) {
		const policy = union(...[
			"alias",
			"replace",
			"exclude",
			"anonymize"
		].map((mode) => namePolicySchema({ mode })));
		return obj({
			defaultPolicy: opt(policy),
			byEntityId: opt(record$1(policy, ref$1()))
		});
	}
	switch (value.mode) {
		case "alias": return obj({
			mode: req(en("alias")),
			aliasId: req(scopedRef("alias"))
		});
		case "replace": return obj({
			mode: req(en("replace")),
			replacement: req(txt(1, 128))
		});
		case "exclude": return obj({ mode: req(en("exclude")) });
		case "anonymize": return obj({
			mode: req(en("anonymize")),
			publicId: req(idSchema),
			publicName: req(txt(1, 128))
		});
		default: return;
	}
}
function walk(schema, value, path, issues, references, depth = 0, ast) {
	if (issues.length >= 256) return;
	if (depth > 32) {
		addIssue(issues, path, "構造の深さが上限32を超えています。", "IMPORT_LIMIT");
		return;
	}
	const fail = (message) => addIssue(issues, path, message);
	switch (schema.type) {
		case "json": {
			const visit = (item, itemPath, level, seen) => {
				if (level > 100) {
					addIssue(issues, itemPath, "JSON階層の上限を超えています。", "IMPORT_LIMIT");
					return;
				}
				if (item === null || typeof item === "string" || typeof item === "boolean") return;
				if (typeof item === "number" && Number.isFinite(item)) return;
				if (!item || typeof item !== "object" || seen.has(item)) {
					addIssue(issues, itemPath, "通常のJSON値を指定してください。");
					return;
				}
				seen.add(item);
				if (Array.isArray(item)) item.forEach((child, index) => visit(child, `${itemPath}[${index}]`, level + 1, seen));
				else if (Object.getPrototypeOf(item) === Object.prototype || Object.getPrototypeOf(item) === null) for (const [key, child] of Object.entries(item)) if ([
					"__proto__",
					"prototype",
					"constructor"
				].includes(key)) addIssue(issues, `${itemPath}.${key}`, "予約済みのキーは使えません。");
				else visit(child, `${itemPath}.${key}`, level + 1, seen);
				else addIssue(issues, itemPath, "通常のJSONオブジェクトを指定してください。");
				seen.delete(item);
			};
			visit(value, path, 0, /* @__PURE__ */ new Set());
			return;
		}
		case "text": {
			if (typeof value !== "string") {
				fail("文字列を入力してください。");
				return;
			}
			if (!validUnicode(value)) fail("文字列に不正なUnicodeがあります。");
			const count = codePointLength(value);
			if (schema.min !== void 0 && count < schema.min) fail(`${schema.min}文字以上で入力してください。`);
			if (schema.max !== void 0 && count > schema.max) fail(`${schema.max}文字以内で入力してください。`);
			if (schema.maxBytes !== void 0 && utf8Bytes(value) > schema.maxBytes) fail("本文が1 MiBの上限を超えています。");
			return;
		}
		case "number":
			if (typeof value !== "number" || !Number.isFinite(value) || schema.integer && !Number.isSafeInteger(value)) fail(schema.integer ? "安全な範囲の整数を入力してください。" : "有限の数値を入力してください。");
			else if (schema.min !== void 0 && value < schema.min || schema.max !== void 0 && value > schema.max) fail("数値が許容範囲外です。");
			return;
		case "boolean":
			if (typeof value !== "boolean") fail("真偽値を指定してください。");
			return;
		case "enum":
			if (!schema.values.includes(value)) fail("宣言された値を選んでください。");
			return;
		case "id":
			if (typeof value !== "string" || !ID_PATTERN.test(value)) fail("小文字のUUIDを指定してください。");
			return;
		case "ref":
			if (!(typeof value === "string" && (schema.scope === "calendar" ? value.length > 0 : ID_PATTERN.test(value)))) fail(schema.scope === "calendar" ? "暦IDが必要です。" : "参照先は小文字UUIDです。");
			if (typeof value === "string") references.push({
				id: value,
				path,
				kinds: schema.kinds,
				scope: schema.scope ?? "entity"
			});
			return;
		case "tick":
			if (!isTick(value)) fail("tickは38桁以内の正規整数文字列です。");
			return;
		case "revision":
			if (typeof value !== "string" || !REVISION_PATTERN.test(value)) fail("revisionは0以上の整数文字列です。");
			return;
		case "datetime":
			if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.\d+)?(?:Z|\+00:00)$/.test(value) || !Number.isFinite(Date.parse(value)) || !validDate(value.slice(0, 10))) fail("UTCのRFC 3339日時を指定してください。");
			return;
		case "date":
			if (typeof value !== "string" || !validDate(value)) fail("実在するYYYY-MM-DD形式の日付を指定してください。");
			return;
		case "hash":
			if (typeof value !== "string" || !/^[0-9a-f]{64}$/.test(value)) fail("SHA-256は小文字16進数64文字です。");
			return;
		case "safe_path":
			if (typeof value !== "string" || !value || value.startsWith("/") || value.includes("\\") || value.includes("\0") || /^[a-zA-Z]:/.test(value) || value.split("/").some((part) => !part || part === "." || part === "..") || /[\u0000-\u001f\u007f]/.test(value)) fail("安全な相対パスを指定してください。");
			return;
		case "array":
			if (!Array.isArray(value)) {
				fail("配列を指定してください。");
				return;
			}
			if (value.length > (schema.max ?? 1e5) || schema.min !== void 0 && value.length < schema.min) {
				fail("配列の件数が許容範囲外です。");
				return;
			}
			if (schema.unique && new Set(value.map((item) => typeof item === "object" ? JSON.stringify(item) : item)).size !== value.length) fail("同じ値を集合内で重複保存できません。");
			value.forEach((item, i) => walk(schema.item, item, `${path}[${i}]`, issues, references, depth + 1, ast));
			return;
		case "object":
			if (!isObject(value)) {
				fail("オブジェクトを指定してください。");
				return;
			}
			for (const field of Object.keys(value)) if (!Object.hasOwn(schema.fields, field)) addIssue(issues, `${path}.${field}`, "未知の項目は保存できません。");
			for (const field of Object.keys(schema.fields)) {
				const definition = schema.fields[field];
				const item = value[field], fieldPath = `${path}.${field}`;
				if (item === void 0) {
					if (definition.required) addIssue(issues, fieldPath, "必須項目です。");
					continue;
				}
				if (item === null && definition.nullable) continue;
				walk(definition.schema, item, fieldPath, issues, references, depth + 1, ast);
			}
			return;
		case "record":
			if (!isObject(value)) {
				fail("項目の辞書を指定してください。");
				return;
			}
			for (const [field, item] of Object.entries(value)) {
				if ([
					"__proto__",
					"prototype",
					"constructor"
				].includes(field)) {
					addIssue(issues, `${path}.${field}`, "予約済みのキーは使えません。");
					continue;
				}
				if (schema.key) walk(schema.key, field, `${path}.${field}.$key`, issues, references, depth + 1, ast);
				walk(schema.value, item, `${path}.${field}`, issues, references, depth + 1, ast);
			}
			return;
		case "union": {
			let shortest;
			for (const choice of schema.choices) {
				const branchIssues = [], branchRefs = [];
				walk(choice, value, path, branchIssues, branchRefs, depth + 1, ast);
				if (!branchIssues.length) {
					references.push(...branchRefs);
					return;
				}
				if (!shortest || branchIssues.length < shortest.length) shortest = branchIssues;
			}
			issues.push(...shortest ?? [{
				code: "VALIDATION_FAILED",
				path,
				message: "対応する型ではありません。"
			}]);
			return;
		}
		case "typed": {
			if (!isObject(value)) {
				fail("型と値を指定してください。");
				return;
			}
			let valueSchema;
			switch (value.type) {
				case "boolean":
					valueSchema = bool;
					break;
				case "integer":
					valueSchema = num(void 0, void 0, true);
					break;
				case "enum":
				case "text":
					valueSchema = txt();
					break;
				case "ref":
					valueSchema = ref$1();
					break;
				case "unknown":
					walk(obj({
						type: req(en("unknown")),
						value: {
							schema: txt(),
							required: true,
							nullable: true
						},
						reason: req(txt())
					}), value, path, issues, references, depth + 1, ast);
					if (value.value !== null) fail("未定値のvalueはnullです。");
					return;
				default:
					fail("未知の値型です。");
					return;
			}
			walk(obj({
				type: req(en(value.type)),
				value: req(valueSchema)
			}), value, path, issues, references, depth + 1, ast);
			return;
		}
		case "custom":
			if (value === null) return;
			if (typeof value === "string") walk(txt(), value, path, issues, references, depth, ast);
			else if (typeof value === "number") walk(num(), value, path, issues, references, depth, ast);
			else if (typeof value === "boolean") return;
			else if (isObject(value) && value.type === "ref") walk(obj({
				type: req(en("ref")),
				value: req(ref$1())
			}), value, path, issues, references, depth + 1, ast);
			else if (isObject(value) && value.type === "date") walk(obj({
				type: req(en("date")),
				value: req({ type: "date" })
			}), value, path, issues, references, depth + 1, ast);
			else fail("カスタム値は文字列・数値・真偽・日付・参照またはnullです。");
			return;
		case "richtext": {
			walk(richTextBlocks, value, path, issues, references, depth + 1, ast);
			if (!Array.isArray(value)) return;
			let bytes = 0, chars = 0;
			const blockIds = /* @__PURE__ */ new Set();
			value.forEach((block, i) => {
				if (!isObject(block) || typeof block.text !== "string") return;
				const length = codePointLength(block.text);
				bytes += utf8Bytes(block.text);
				chars += length;
				if (typeof block.id === "string") {
					if (blockIds.has(block.id)) addIssue(issues, `${path}[${i}].id`, "段落IDが重複しています。");
					blockIds.add(block.id);
				}
				if (Array.isArray(block.unresolvedAnnotations)) {
					for (const annotation of block.unresolvedAnnotations) if (isObject(annotation)) {
						for (const field of [
							"originalText",
							"reason",
							"reading"
						]) if (typeof annotation[field] === "string") bytes += utf8Bytes(annotation[field]);
					}
				}
				for (const field of ["ruby", "links"]) if (Array.isArray(block[field])) block[field].forEach((range, j) => {
					if (!isObject(range)) return;
					if (typeof range.start === "number" && typeof range.end === "number" && (range.start >= range.end || range.end > length)) addIssue(issues, `${path}[${i}].${field}[${j}]`, "文字範囲はコードポイントで数え、本文内の半開区間を指定してください。");
					if (typeof range.text === "string") bytes += utf8Bytes(range.text);
				});
			});
			if (bytes > 1048576) fail("本文フィールドが1 MiBを超えています。");
			if (schema.max !== void 0 && chars > schema.max) fail(`要約は${schema.max}文字以内です。`);
			return;
		}
		case "condition":
		case "expression": {
			const budget = ast ?? {
				counter: { count: 0 },
				depth: 0
			};
			budget.counter.count++;
			if (budget.counter.count > 256 || budget.depth >= 16) {
				fail("条件・式は深さ16、ノード256までです。");
				return;
			}
			if (!isObject(value)) {
				fail("条件・式は型付きASTで指定してください。");
				return;
			}
			const definition = schema.type === "condition" ? conditionSchema(value) : expressionSchema(value);
			if (!definition) {
				fail("未知の条件・式opです。");
				return;
			}
			walk(definition, value, path, issues, references, 0, {
				counter: budget.counter,
				depth: budget.depth + 1
			});
			return;
		}
		case "time": {
			if (!isObject(value)) {
				fail("日時はTimeSpecで指定してください。");
				return;
			}
			const definition = timeSchema(value);
			if (!definition) {
				fail("未知の日時modeです。");
				return;
			}
			const before = issues.length;
			walk(definition, value, path, issues, references, depth + 1, ast);
			if (issues.length === before) {
				if (value.mode === "interval" && compareTicks(value.start, value.end) >= 0) fail("期間はstart < endの半開区間です。");
				if (value.mode === "uncertain" && compareTicks(value.earliest, value.latest) > 0) fail("earliestはlatest以下です。");
				if (value.mode === "relative" && compareTicks(value.minOffset, value.maxOffset) > 0) fail("minOffsetはmaxOffset以下です。");
			}
			return;
		}
		case "query":
		case "name_policy": {
			if (!isObject(value)) {
				fail("型付きのオブジェクトを指定してください。");
				return;
			}
			const definition = schema.type === "query" ? querySchema(value) : namePolicySchema(value);
			if (!definition) {
				fail("未知の規則です。");
				return;
			}
			const before = issues.length;
			walk(definition, value, path, issues, references, depth + 1, ast);
			if (schema.type === "query" && value.op === "foreshadow" && issues.length === before && ![
				"foreshadowId",
				"resolutionPolicy",
				"role",
				"stage"
			].some((field) => value[field] !== void 0 && value[field] !== null)) addIssue(issues, path, "伏線検索には対象・回収方針・開示役割・段階のいずれかを指定してください。");
			return;
		}
	}
}
function entitySchema(kind) {
	const data = ENTITY_SCHEMAS[kind], cached = entityRecordSchemas.get(kind);
	if (cached?.data === data) return cached.record;
	const record = obj({
		...commonFields,
		kind: req(en(kind)),
		data: req(data)
	});
	entityRecordSchemas.set(kind, {
		data,
		record
	});
	return record;
}
function simpleValidate(schema, value, path, references = []) {
	const issues = [];
	walk(schema, value, path, issues, references);
	return issues.length ? {
		ok: false,
		issues
	} : {
		ok: true,
		value
	};
}
function validateCondition(input, path = "condition") {
	return simpleValidate(cond, input, path);
}
function validateTypedValue(input, path = "value") {
	return simpleValidate(typed$1, input, path);
}
function validateRuntimeState(input, path = "runtimeState") {
	const result = simpleValidate(runtime, input, path);
	if (!result.ok) return result;
	const issues = [], ids = /* @__PURE__ */ new Set(), assertions = /* @__PURE__ */ new Set();
	result.value.itemInstances.forEach((item, i) => {
		if (ids.has(item.instanceId)) addIssue(issues, `${path}.itemInstances[${i}].instanceId`, "物品個体のIDが重複しています。");
		ids.add(item.instanceId);
		if (item.ownerId && item.locationId || item.consumed && item.quantity !== 0 || !item.consumed && item.quantity < 1) addIssue(issues, `${path}.itemInstances[${i}]`, "物品の所在・所有・消費状態・数量が不整合です。");
	});
	result.value.assertions.forEach((assertion, i) => {
		const key = `${assertion.assertionId}/${assertion.holderId}`;
		if (assertions.has(key)) addIssue(issues, `${path}.assertions[${i}]`, "同じ人物・事実の認識が重複しています。");
		assertions.add(key);
	});
	return issues.length ? {
		ok: false,
		issues
	} : result;
}
/** Optional legacy evidence may be absent; supplied initial evidence must be complete and consistent. */
function validateInitialPresentationResults(state, input, entities, path = "presentationResults") {
	const checked = simpleValidate(arr(presentationResult), input, path);
	if (!checked.ok) return checked.issues;
	const issues = [], seen = new Set(state.seenIds), observed = /* @__PURE__ */ new Set();
	const node = entities.find((entity) => entity.kind === "flow_node" && entity.id === state.presentationPosition && !entity.deletedAt && entity.status !== "rejected");
	const eligible = entities.filter((entity) => {
		if (entity.kind !== "disclosure" || entity.deletedAt || entity.status === "rejected" || !node || !seen.has(node.id)) return false;
		const anchor = entity.data.anchor;
		return anchor.positionStatus !== "unresolved" && (anchor.entityId === node.id || anchor.entityId === node.data.sceneId) && (!anchor.blockId || seen.has(anchor.blockId)) && (!anchor.lineId || seen.has(anchor.lineId));
	});
	const targets = new Set(eligible.map((disclosure) => disclosure.id));
	checked.value.forEach((result, index) => {
		const location = `${path}[${index}]`;
		if (observed.has(result.targetId)) addIssue(issues, `${location}.targetId`, "初期提示の条件結果が重複しています。");
		observed.add(result.targetId);
		if (!targets.has(result.targetId)) addIssue(issues, `${location}.targetId`, "初期提示の対象ではない開示の条件結果です。", "REFERENCE_INVALID");
		if (result.value === "unknown") addIssue(issues, `${location}.value`, "未確認の開示条件では初期提示を完了できません。");
		if (result.value === "true" && !seen.has(result.targetId)) addIssue(issues, `${location}.value`, "提示した条件結果と既読の証跡が一致しません。");
		if (result.value === "false" && seen.has(result.targetId) && state.provenance === "full_play") addIssue(issues, `${location}.value`, "提示済みの開示を初期条件のfalseで取り消すことはできません。");
	});
	for (const disclosure of eligible) if (!observed.has(disclosure.id)) addIssue(issues, path, "初期提示の開示条件結果が不足しています。");
	return issues;
}
function validateEffectData(input, path = "effect") {
	return simpleValidate(ENTITY_SCHEMAS.effect, input, path);
}
function validateEntityRecord(input, path, references) {
	if (!isObject(input) || !ENTITY_KINDS.includes(input.kind)) return {
		ok: false,
		issues: [{
			code: "VALIDATION_FAILED",
			path: `${path}.kind`,
			message: "未対応の情報種別です。"
		}]
	};
	const result = simpleValidate(entitySchema(input.kind), input, path, references);
	if (!result.ok) return result;
	const issues = [];
	validateLocalRules(result.value, path, issues);
	return issues.length ? {
		ok: false,
		issues
	} : result;
}
function validateVariableValue(variable, value, path = "value", allowUnknown = true) {
	const issues = [], data = variable.data;
	if (value.type === "unknown") {
		if (!allowUnknown) addIssue(issues, path, "未定の値はこの操作で使えません。", "CONDITION_UNKNOWN");
		return issues;
	}
	if (value.type !== data.valueType) {
		addIssue(issues, path, "状態変数の宣言型と値の型が一致しません。");
		return issues;
	}
	if (value.type === "integer") {
		const min = data.allowed.min ?? -2147483647, max = data.allowed.max ?? 2147483647;
		if (!Number.isSafeInteger(value.value) || value.value < min || value.value > max) addIssue(issues, path, "状態変数の値が宣言した整数範囲外です。");
	}
	if ((value.type === "enum" || value.type === "boolean") && data.allowed.values && !data.allowed.values.includes(value.value)) addIssue(issues, path, "状態変数の値が許容集合にありません。");
	return issues;
}
function validateLocalRules(entity, path, issues) {
	const issue = (field, message) => addIssue(issues, `${path}.${field}`, message);
	if (![
		"dialogue_line",
		"effect",
		"assertion",
		"disclosure",
		"cue",
		"storyboard_frame",
		"localization",
		"recording",
		"checkpoint",
		"trace"
	].includes(entity.kind) && !entity.name.trim()) issue("name", "名称を入力してください。");
	if (entity.visibility === "projection" && !entity.projectionProfileId) issue("projectionProfileId", "公開投影の対象プロファイルを指定してください。");
	if (entity.deletedAt && !entity.deletionOperationId) issue("deletionOperationId", "削除には削除操作IDが必要です。");
	if (!entity.deletedAt && entity.deletionOperationId) issue("deletionOperationId", "削除されていない情報に削除操作IDは保存できません。");
	for (const customKey of Object.keys(entity.customValues)) {
		const schema = ENTITY_SCHEMAS[entity.kind];
		if (Object.hasOwn(commonFields, customKey) || schema.type === "object" && Object.hasOwn(schema.fields, customKey)) issue(`customValues.${customKey}`, "標準項目とカスタム項目のキーが衝突しています。");
	}
	switch (entity.kind) {
		case "event":
			for (const [index, constraint] of (entity.data.constraints ?? []).entries()) if (constraint.type === "end_gap" && compareTicks(constraint.minimumTicks, constraint.maximumTicks) > 0) issue(`data.constraints[${index}]`, "日時差の最小値は最大値以下です。");
			break;
		case "item":
			if (entity.data.itemMode === "instance" && !entity.data.typeId) issue("data.typeId", "物品の個体には種類への参照が必要です。");
			break;
		case "flow_node":
			if (entity.data.nodeType === "terminal" && !entity.data.terminalReason?.trim()) issue("data.terminalReason", "意図した終端には終了理由が必要です。");
			if (entity.data.nodeType === "call" && !entity.data.childGraphId) issue("data.childGraphId", "呼出ノードには子分岐図が必要です。");
			break;
		case "variable": {
			const data = entity.data;
			if (data.scope === "character" && !data.ownerId) issue("data.ownerId", "人物scopeには所有人物が必要です。");
			if (data.valueType === "integer") {
				if (data.allowed.values) issue("data.allowed.values", "整数には集合ではなくmin/maxを指定してください。");
				if ((data.allowed.min ?? -2147483647) > (data.allowed.max ?? 2147483647)) issue("data.allowed", "整数の最小値は最大値以下です。");
			} else {
				if (data.allowed.min != null || data.allowed.max != null) issue("data.allowed", "この型に数値範囲は設定できません。");
				if (data.valueType === "enum" && (!data.allowed.values?.length || data.allowed.values.some((value) => typeof value !== "string" || !value))) issue("data.allowed.values", "enumには空でない文字列の候補集合が必要です。");
				if (data.valueType === "boolean" && data.allowed.values?.some((value) => typeof value !== "boolean")) issue("data.allowed.values", "booleanの候補は真偽値です。");
			}
			issues.push(...validateVariableValue(entity, data.initial, `${path}.data.initial`));
			for (const [i, rule] of (data.resetRules ?? []).entries()) issues.push(...validateVariableValue(entity, rule.value, `${path}.data.resetRules[${i}].value`));
			if (new Set((data.resetRules ?? []).map((rule) => rule.on)).size !== (data.resetRules ?? []).length) issue("data.resetRules", "同じ終了時点の初期化規則は一つにしてください。");
			for (const [i, rule] of (data.transitionRules ?? []).entries()) {
				issues.push(...validateVariableValue(entity, rule.from, `${path}.data.transitionRules[${i}].from`, false), ...validateVariableValue(entity, rule.to, `${path}.data.transitionRules[${i}].to`, false));
				if (rule.exception && !rule.reason?.trim()) issue(`data.transitionRules[${i}].reason`, "例外遷移には理由が必要です。");
			}
			for (const [i, rule] of (data.exclusions ?? []).entries()) {
				issues.push(...validateVariableValue(entity, rule.value, `${path}.data.exclusions[${i}].value`, false));
				if (!rule.reason.trim()) issue(`data.exclusions[${i}].reason`, "相互排他には理由が必要です。");
			}
			break;
		}
		case "effect":
			if ([
				"set",
				"add",
				"move"
			].includes(entity.data.operation) && (!entity.data.value || entity.data.value.type === "unknown")) issue("data.value", "この効果には既知の入力値が必要です。");
			if (entity.data.operation === "add" && entity.data.value?.type !== "integer") issue("data.value", "addはinteger値だけを使えます。");
			if (entity.data.operation === "move" && entity.data.value?.type !== "ref") issue("data.value", "moveには所在・所有先のref値が必要です。");
			if (entity.data.operation === "consume" && !entity.data.reason?.trim()) issue("data.reason", "消費・破壊には理由が必要です。");
			if (["grant", "consume"].includes(entity.data.operation) && entity.data.value != null && (entity.data.value.type !== "integer" || entity.data.value.value < 1)) issue("data.value", "物品数量は正のintegerです。");
			if (entity.data.operation === "assert" && entity.data.value != null && entity.data.value.type !== "boolean") issue("data.value", "assertの真偽入力はbooleanです。");
			break;
		case "assertion":
			if (entity.data.truthKind === "belief" && !entity.data.holderId) issue("data.holderId", "beliefには認識を持つ人物が必要です。");
			if (entity.data.truthKind === "testimony" && !entity.data.sourceIds?.length) issue("data.sourceIds", "testimonyには出所が必要です。");
			break;
		case "storyboard_frame":
			if (entity.data.mediaEndMs != null && entity.data.mediaEndMs < entity.data.mediaStartMs) issue("data.mediaEndMs", "演出の終了は開始以上です。");
			break;
		case "travel_route":
			if (entity.data.minimumTicks != null && parseTick(entity.data.minimumTicks) < 0n || entity.data.maximumTicks != null && parseTick(entity.data.maximumTicks) < 0n) issue("data", "移動所要時間は0以上です。");
			if (entity.data.minimumTicks != null && entity.data.maximumTicks != null && compareTicks(entity.data.minimumTicks, entity.data.maximumTicks) > 0) issue("data.maximumTicks", "最大所要時間は最小以上です。");
			break;
		case "collection":
			if (entity.data.purpose === "regression" && entity.data.mode !== "fixed") issue("data.mode", "回帰経路集合は宣言した固定経路の集合です。");
			if (entity.data.mode === "dynamic" && !entity.data.query) issue("data.query", "動的一覧には型付き検索条件が必要です。");
			if (entity.data.mode === "fixed" && !Array.isArray(entity.data.memberIds)) issue("data.memberIds", "固定一覧にはID配列が必要です。");
			break;
		case "template":
			issues.push(...validateTemplateDefinition(entity.data, `${path}.data`));
			break;
		case "production_task":
			if (entity.data.deadline) try {
				new Intl.DateTimeFormat("ja", { timeZone: entity.data.deadline.timeZone });
			} catch {
				issue("data.deadline.timeZone", "有効なタイムゾーンを指定してください。");
			}
			if (entity.data.estimate) {
				const estimate = entity.data.estimate;
				if (estimate.value == null === (estimate.range == null)) issue("data.estimate", "見積もりはvalueまたはrangeの一つです。");
				if (estimate.range && estimate.range.min > estimate.range.max) issue("data.estimate.range", "見積範囲が逆転しています。");
				if (["reading_minutes", "playing_minutes"].includes(estimate.unit) && !estimate.speed) issue("data.estimate.speed", "本文量からの時間見積もりには速度が必要です。");
			}
			break;
		case "review": {
			const source = entity.data.sharedSource;
			if (!source) break;
			try {
				const url = new URL(source.connection);
				if (url.origin !== source.connection || url.username || url.password || !["https:", "http:"].includes(url.protocol) || url.protocol === "http:" && ![
					"localhost",
					"127.0.0.1",
					"[::1]"
				].includes(url.hostname)) issue("data.sharedSource.connection", "指摘の専用接続先のoriginを確認してください。");
			} catch {
				issue("data.sharedSource.connection", "指摘の接続先が不正です。");
			}
			if (!ID_PATTERN.test(source.sharedSnapshot) || !ID_PATTERN.test(source.comment) || !source.publicVersion || !/^([a-f0-9]{64})$/.test(source.projectionHash) || !/^([a-f0-9]{64})$/.test(source.commentBodyHash)) issue("data.sharedSource", "元の公開版・指摘・hashが不正です。");
			if (!!source.publicEntity === !!source.publicRelation || source.publicRelation && (source.publicBlock !== void 0 || source.startCp !== void 0 || source.endCp !== void 0) || source.publicBlock !== void 0 && (source.startCp === void 0 || source.endCp === void 0 || source.endCp <= source.startCp) || source.publicBlock === void 0 && (source.startCp !== void 0 || source.endCp !== void 0)) issue("data.sharedSource", "元指摘の対象とUnicode位置の組合せを確認してください。");
			break;
		}
		case "localization":
		case "recording": if (!/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(entity.data.language)) issue("data.language", "言語コードを指定してください（例: ja、en-US）。");
	}
	validateNestedRanges(entity.data, `${path}.data`, issues);
}
function validateNestedRanges(value, path, issues, depth = 0) {
	if (depth > 32 || !value || typeof value !== "object") return;
	if (Array.isArray(value)) {
		value.forEach((item, i) => validateNestedRanges(item, `${path}[${i}]`, issues, depth + 1));
		return;
	}
	const object = value;
	if ("worldRange" in object && isObject(object.worldRange)) {
		const range = object.worldRange;
		if (isTick(range.start) && isTick(range.end) && compareTicks(range.start, range.end) >= 0) addIssue(issues, `${path}.worldRange`, "有効期間はstart < endの半開区間です。");
	}
	if ("entityId" in object && typeof object.start === "number" && typeof object.end === "number" && object.start >= object.end) addIssue(issues, path, "位置の文字範囲はstart < endです。");
	for (const [field, item] of Object.entries(object)) validateNestedRanges(item, `${path}.${field}`, issues, depth + 1);
}
function collectReferences(entity) {
	const references = [];
	walk(entitySchema(entity.kind), entity, "", [], references);
	return references.map((reference) => ({
		...reference,
		path: reference.path.replace(/^\./, "")
	}));
}
function collectRelationReferences(relation) {
	const references = [];
	walk(relationSchema, relation, "", [], references);
	return references.map((reference) => ({
		...reference,
		path: reference.path.replace(/^\./, "")
	}));
}
function pathParts(path) {
	return path.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
}
function rewritePaths(source, references, idMap) {
	const copy = structuredClone(source), lookup = (id) => idMap instanceof Map ? idMap.get(id) : Object.hasOwn(idMap, id) ? idMap[id] : void 0;
	const ordered = [...references].sort((a, b) => {
		const aKey = a.path.endsWith(".$key"), bKey = b.path.endsWith(".$key");
		return Number(aKey) - Number(bKey) || (aKey ? pathParts(b.path).length - pathParts(a.path).length : 0);
	});
	for (const reference of ordered) {
		const replacement = lookup(reference.id);
		if (!replacement) continue;
		const parts = pathParts(reference.path), dictionaryKey = parts.at(-1) === "$key";
		if (dictionaryKey) parts.pop();
		const field = parts.pop();
		if (!field) continue;
		let cursor = copy;
		for (const part of parts) cursor = cursor[part];
		if (dictionaryKey) {
			if (replacement === field) continue;
			if (Object.hasOwn(cursor, replacement)) throw new Error("REFERENCE_INVALID: 参照の統合で辞書キーが衝突します。保持する内容を選んでください。");
			cursor[replacement] = cursor[field];
			delete cursor[field];
		} else cursor[field] = replacement;
	}
	return copy;
}
function rewriteEntityReferences(entity, idMap) {
	const copy = rewritePaths(entity, collectReferences(entity), idMap), lookup = (id) => (idMap instanceof Map ? idMap.get(id) : idMap[id]) ?? id;
	if ((entity.kind === "scene" || entity.kind === "flow_node") && entity.data.reuse?.bindings && (copy.kind === "scene" || copy.kind === "flow_node") && copy.data.reuse) copy.data.reuse.bindings = Object.fromEntries(Object.entries(entity.data.reuse.bindings).map(([source, target]) => [lookup(source), lookup(target)]));
	return copy;
}
function validateActiveRecordNamespace(project, worlds, path, issues) {
	const pinnedProjects = /* @__PURE__ */ new Set(), activeProjects = /* @__PURE__ */ new Set([project.projectId]), ids = /* @__PURE__ */ new Set();
	project.worldReferences.forEach((reference, index) => {
		if (pinnedProjects.has(reference.projectId)) addIssue(issues, `${path}.worldReferences[${index}]`, "同じ世界の複数の版を同時に参照すると、IDの参照先が曖昧になります。一つの固定版を選んでください。", "REFERENCE_INVALID");
		pinnedProjects.add(reference.projectId);
	});
	const contexts = [{
		content: project,
		location: path
	}, ...worlds.map((world) => {
		return {
			content: world,
			location: `${path}.worldReferences[${project.worldReferences.findIndex((reference) => reference.projectId === world.projectId)}]`
		};
	})];
	const calendars = /* @__PURE__ */ new Map();
	for (const [index, { content, location }] of contexts.entries()) {
		if (index > 0) {
			if (activeProjects.has(content.projectId)) addIssue(issues, location, "同じ作品・世界の複数の内容が現在の参照範囲に含まれています。固定版を一つにしてください。", "REFERENCE_INVALID");
			activeProjects.add(content.projectId);
		}
		for (const [calendarIndex, calendar] of content.calendars.entries()) {
			const previous = calendars.get(calendar.id);
			if (previous && !sameCalendarDefinition(previous, calendar)) addIssue(issues, `${location}.calendars[${calendarIndex}].id`, "同じ暦IDに異なる定義があります。固定版の日時を読み替えず、暦IDを明示して対応付けてください。", "REFERENCE_INVALID");
			calendars.set(calendar.id, calendar);
		}
		for (const [collection, records] of [["entities", content.entities], ["relations", content.relations]]) records.forEach((record, recordIndex) => {
			const recordPath = `${location}.${collection}[${recordIndex}]`;
			if (ids.has(record.id)) addIssue(issues, `${recordPath}.id`, "現在の作品と参照中の共通世界でentity・relationのIDが衝突しています。曖昧な参照は保存できません。", "REFERENCE_INVALID");
			ids.add(record.id);
			if (record.projectId !== content.projectId) addIssue(issues, `${recordPath}.projectId`, "参照範囲のレコードが所属する作品・世界と一致しません。", "REFERENCE_INVALID");
		});
	}
}
function validateContent(input, path, options, snapshotIds, versionContents = /* @__PURE__ */ new Map(), reuse) {
	const issues = [];
	if (!isObject(input)) return {
		ok: false,
		issues: [{
			code: "VALIDATION_FAILED",
			path,
			message: "作品はオブジェクトです。"
		}]
	};
	for (const field of Object.keys(input)) if (!projectContentKeys.includes(field)) addIssue(issues, `${path}.${field}`, "作品に未知の項目があります。");
	const header = Object.fromEntries(Object.keys(projectHeaderFields).filter((field) => Object.hasOwn(input, field)).map((field) => [field, input[field]]));
	walk(obj(projectHeaderFields), header, path, issues, []);
	if (input.formatVersion !== "1.0.0") addIssue(issues, `${path}.formatVersion`, "対応していない形式版です。", "FORMAT_UNSUPPORTED");
	for (const field of [
		"entities",
		"relations",
		"calendars",
		"views"
	]) if (!Array.isArray(input[field])) addIssue(issues, `${path}.${field}`, "必須の配列です。");
	if (issues.length) return {
		ok: false,
		issues
	};
	const entities = input.entities, relations = input.relations, calendars = input.calendars;
	if (entities.length + relations.length > 1e5) return {
		ok: false,
		issues: [{
			code: "IMPORT_LIMIT",
			path,
			message: "entityとrelationの合計は100,000件までです。"
		}]
	};
	const previousEntities = new Map(reuse?.previous.entities.map((entity) => [entity.id, entity])), previousRelations = new Map(reuse?.previous.relations.map((relation) => [relation.id, relation]));
	const entityReferences = /* @__PURE__ */ new WeakMap(), relationReferences = /* @__PURE__ */ new WeakMap();
	const relative = (references, prefix) => references.map((reference) => ({
		...reference,
		path: reference.path.slice(prefix.length + 1)
	}));
	entities.forEach((entity, i) => {
		if (reuse && isObject(entity) && previousEntities.get(entity.id) === entity) return;
		const prefix = `${path}.entities[${i}]`, references = [];
		const result = validateEntityRecord(entity, prefix, references);
		if (!result.ok) issues.push(...result.issues);
		else entityReferences.set(result.value, relative(references, prefix));
	});
	relations.forEach((relation, i) => {
		if (reuse && isObject(relation) && Object.is(previousRelations.get(relation.id), relation)) return;
		const prefix = `${path}.relations[${i}]`, references = [];
		const result = simpleValidate(relationSchema, relation, prefix, references);
		if (!result.ok) issues.push(...result.issues);
		else relationReferences.set(result.value, relative(references, prefix));
	});
	calendars.forEach((calendar, i) => {
		const result = validateCalendar(calendar, `${path}.calendars[${i}]`);
		if (!result.ok) issues.push(...result.issues);
	});
	const viewRefs = [];
	walk(arr(viewSchema), input.views, `${path}.views`, issues, viewRefs);
	if (issues.length) return {
		ok: false,
		issues: issues.slice(0, 256)
	};
	const project = input;
	const reusableSnapshots = [...versionContents].map(([id, content]) => ({
		id,
		content,
		contentHash: "",
		createdAt: "",
		versionLabel: ""
	}));
	issues.push(...reuseValidationIssues(project, reusableSnapshots, path));
	if (issues.length) return {
		ok: false,
		issues: issues.slice(0, 256)
	};
	const executionProject = project.entities.some((entity) => (entity.kind === "scene" || entity.kind === "flow_node") && entity.data.reuse?.bindings) ? resolveReuseContent(project, reusableSnapshots) : project;
	const allowedWorldIds = new Set(executionProject.worldReferences.map((reference) => reference.projectId));
	const closure = options.worldSnapshots ? resolvePinnedWorlds(executionProject, options.worldSnapshots) : void 0;
	if (closure) for (const message of closure.errors) addIssue(issues, `${path}.worldReferences`, message, "REFERENCE_INVALID");
	const worlds = closure?.worlds ?? (options.worlds ?? []).filter((world) => allowedWorldIds.has(world.projectId));
	if (entities.length + relations.length + worlds.reduce((count, world) => count + world.entities.length + world.relations.length, 0) > 1e5) addIssue(issues, path, "参照世界を含むレコード数が100,000件を超えています。", "IMPORT_LIMIT");
	validateActiveRecordNamespace(project, worlds, path, issues);
	if (executionProject !== project) validateActiveRecordNamespace(executionProject, worlds, `${path}.reuse`, issues);
	if (issues.length) return {
		ok: false,
		issues: issues.slice(0, 256)
	};
	const allEntities = [...executionProject.entities, ...worlds.flatMap((world) => world.entities)], entityMap = new Map(allEntities.map((entity) => [entity.id, entity]));
	const relationMap = new Map([...project.relations, ...worlds.flatMap((world) => world.relations)].map((relation) => [relation.id, relation]));
	const allCalendarIds = new Set([...project.calendars, ...worlds.flatMap((world) => world.calendars)].map((calendar) => calendar.id));
	const ids = /* @__PURE__ */ new Set();
	for (const [collection, records] of [["entities", project.entities], ["relations", project.relations]]) records.forEach((record, i) => {
		if (ids.has(record.id)) addIssue(issues, `${path}.${collection}[${i}].id`, "entityとrelationのIDは作品内で一意です。");
		ids.add(record.id);
		if (record.projectId !== project.projectId) addIssue(issues, `${path}.${collection}[${i}].projectId`, "レコードが別の作品に属しています。", "REFERENCE_INVALID");
	});
	const calendarIds = project.calendars.map((calendar) => calendar.id);
	if (new Set(calendarIds).size !== calendarIds.length) addIssue(issues, `${path}.calendars`, "暦IDが重複しています。");
	if (!calendarIds.includes(project.calendarId)) addIssue(issues, `${path}.calendarId`, "作品の暦が定義されていません。", "REFERENCE_INVALID");
	const worldKeys = project.worldReferences.map((world) => `${world.projectId}/${world.immutableSnapshotId}`);
	if (new Set(worldKeys).size !== worldKeys.length || project.worldReferences.some((world) => world.projectId === project.projectId)) addIssue(issues, `${path}.worldReferences`, "共通世界参照の重複または自己参照があります。");
	const blocks = /* @__PURE__ */ new Map(), aliases = /* @__PURE__ */ new Map();
	for (const entity of allEntities) collectContentIds(entity.data, entity.id, blocks, aliases, issues, `${path}.entities.${entity.id}.data`);
	const projectionIds = /* @__PURE__ */ new Set([
		...entityMap.keys(),
		...relationMap.keys(),
		...blocks.keys()
	]);
	for (const entity of allEntities) {
		if (entity.kind === "flow_node" && entity.data.trigger?.id) projectionIds.add(entity.data.trigger.id);
		if (entity.kind === "projection_profile") {
			for (const publicFields of Object.values(entity.data.publicTexts ?? {})) for (const field of Object.values(publicFields)) if (Array.isArray(field)) {
				for (const block of field) if (isObject(block) && typeof block.id === "string") projectionIds.add(block.id);
			}
		}
	}
	const worldVersionDependencies = worlds.flatMap((world) => [...world.entities.flatMap(collectReferences), ...world.relations.flatMap(collectRelationReferences)]).filter((reference) => reference.scope === "snapshot" && options.worldSnapshots?.[reference.id] && worlds.some((world) => world.projectId === options.worldSnapshots?.[reference.id].projectId)).map((reference) => reference.id);
	const knownVersions = /* @__PURE__ */ new Set([
		...snapshotIds,
		...worldVersionDependencies,
		project.projectId,
		...allEntities.filter((entity) => entity.kind === "snapshot").map((entity) => entity.id),
		...(closure?.references ?? executionProject.worldReferences).map((world) => world.immutableSnapshotId)
	]);
	const currentIndex = {
		entities: entityMap,
		relations: relationMap,
		blocks,
		calendars: allCalendarIds,
		projects: /* @__PURE__ */ new Set([project.projectId, ...(closure?.references ?? executionProject.worldReferences).map((world) => world.projectId)]),
		projectionIds
	}, versionIndexes = /* @__PURE__ */ new Map();
	function versionIndex(versionId) {
		if (versionId === project.projectId && !project.entities.some((entity) => (entity.kind === "scene" || entity.kind === "flow_node") && entity.data.reuse?.bindings)) return currentIndex;
		const cached = versionIndexes.get(versionId);
		if (cached) return cached;
		const rawContent = versionId === project.projectId ? project : versionContents.get(versionId) ?? options.worldSnapshots?.[versionId];
		if (!rawContent) return void 0;
		let content = rawContent;
		try {
			if (content.entities.some((entity) => (entity.kind === "scene" || entity.kind === "flow_node") && entity.data.reuse?.bindings)) content = resolveReuseContent(content, reusableSnapshots);
		} catch {
			return;
		}
		const versionClosure = options.worldSnapshots ? resolvePinnedWorlds(content, options.worldSnapshots) : void 0;
		if (versionClosure) for (const message of versionClosure.errors) addIssue(issues, `${path}.versions.${versionId}.worldReferences`, message, "REFERENCE_INVALID");
		const pinnedWorlds = versionClosure?.worlds ?? (options.worlds ?? []).filter((world) => content.worldReferences.some((reference) => reference.projectId === world.projectId));
		const before = issues.length;
		validateActiveRecordNamespace(content, pinnedWorlds, `${path}.versions.${versionId}`, issues);
		if (issues.length !== before) return void 0;
		const records = [...content.entities, ...pinnedWorlds.flatMap((world) => world.entities)], versionBlocks = /* @__PURE__ */ new Map();
		for (const record of records) if (isObject(record)) collectContentIds(record.data, record.id, versionBlocks, /* @__PURE__ */ new Map(), [], "version");
		const versionProjectionIds = /* @__PURE__ */ new Set([
			...records.map((record) => record.id),
			...content.relations.map((relation) => relation.id),
			...pinnedWorlds.flatMap((world) => world.relations.map((relation) => relation.id)),
			...versionBlocks.keys()
		]);
		for (const entity of records) {
			if (entity.kind === "flow_node" && entity.data.trigger?.id) versionProjectionIds.add(entity.data.trigger.id);
			if (entity.kind === "projection_profile") {
				for (const fields of Object.values(entity.data.publicTexts ?? {})) for (const value of Object.values(fields)) if (Array.isArray(value)) {
					for (const block of value) if (isObject(block) && typeof block.id === "string") versionProjectionIds.add(block.id);
				}
			}
		}
		const index = {
			entities: new Map(records.filter((record) => isObject(record)).map((record) => [record.id, record])),
			relations: new Map([...content.relations, ...pinnedWorlds.flatMap((world) => world.relations)].filter((record) => isObject(record)).map((record) => [record.id, record])),
			blocks: versionBlocks,
			calendars: new Set([...content.calendars, ...pinnedWorlds.flatMap((world) => world.calendars)].map((calendar) => calendar.id)),
			projects: /* @__PURE__ */ new Set([content.projectId, ...pinnedWorlds.map((world) => world.projectId)]),
			projectionIds: versionProjectionIds
		};
		versionIndexes.set(versionId, index);
		return index;
	}
	function inspect(reference, prefix = "", index = currentIndex) {
		const location = prefix ? `${prefix}.${reference.path}` : reference.path;
		let exists = true;
		if (reference.scope === "entity") {
			const target = index.entities.get(reference.id);
			exists = !!target;
			if (target && reference.kinds && !reference.kinds.includes(target.kind)) addIssue(issues, location, `参照先の種類は${reference.kinds.map((kind) => KIND_LABELS[kind]).join(" / ")}です。`, "REFERENCE_INVALID");
			if (target && options.runtime && target.deletedAt) addIssue(issues, location, "削除済み情報は実行用出力で参照できません。", "REFERENCE_INVALID");
		} else if (reference.scope === "relation") exists = index.relations.has(reference.id);
		else if (reference.scope === "record") exists = index.entities.has(reference.id) || index.relations.has(reference.id);
		else if (reference.scope === "projection_record") exists = index.projectionIds.has(reference.id);
		else if (reference.scope === "presentation") exists = index.entities.has(reference.id) || index.blocks.has(reference.id);
		else if (reference.scope === "calendar") exists = index.calendars.has(reference.id);
		else if (reference.scope === "project") exists = index.projects.has(reference.id);
		else if (reference.scope === "snapshot") exists = knownVersions.has(reference.id);
		else if (reference.scope === "block") exists = index.blocks.has(reference.id);
		else if (reference.scope === "alias") exists = aliases.has(reference.id);
		if (!exists) addIssue(issues, location, "参照先が存在しないか、指定した作品・共通世界の範囲外です。", "REFERENCE_INVALID");
	}
	const referencesFor = (entity) => {
		const observed = entityReferences.get(entity);
		if (observed) return observed;
		if (!reuse || previousEntities.get(entity.id) !== entity) return collectReferences(entity);
		const cached = reuse.references.get(entity);
		if (cached) return cached;
		const references = collectReferences(entity);
		reuse.references.set(entity, references);
		return references;
	};
	project.entities.forEach((entity, i) => {
		const prefix = `${path}.entities[${i}]`;
		for (const reference of referencesFor(entity)) {
			const parts = pathParts(reference.path), parent = parts.slice(0, -1).reduce((object, field) => object && typeof object === "object" ? object[field] : void 0, entity);
			const reuseVersion = (entity.kind === "scene" || entity.kind === "flow_node") && entity.data.reuse && reference.path === "data.reuse.sourceId" ? entity.data.reuse.pinnedSnapshotId : void 0;
			const profileVersion = entity.kind === "projection_profile" && entity.data.sourceVersionId && /^data\.(?:includedIds|publicTexts|blockSources|publicIds|publicValues|namePolicy|allowedRelationIds|approvedAttachmentIds)(?:\.|\[)/.test(reference.path) ? entity.data.sourceVersionId : void 0;
			const anchorVersion = (entity.kind === "note" && reference.path === "data.handoffReceipt.profileId" ? entity.data.handoffReceipt?.profileVersionId : void 0) ?? reuseVersion ?? (isObject(parent) && typeof parent.entityId === "string" && typeof parent.sourceVersionId === "string" ? parent.sourceVersionId : entity.kind === "review" && reference.path.startsWith("data.target.") ? entity.data.targetVersionId : profileVersion);
			if (entity.kind === "projection_profile" && reference.scope === "projection_record" && reference.path.endsWith(".$key") && Object.values(entity.data.publicTexts ?? {}).some((fields) => Object.values(fields).some((value) => Array.isArray(value) && value.some((block) => block.id === reference.id)))) {
				inspect(reference, prefix);
				continue;
			}
			const usesVersion = entity.kind === "checkpoint" && (reference.path.startsWith("data.runtimeState.") || reference.path.startsWith("data.presentationState.") || reference.path.startsWith("data.presentationResults[")) || entity.kind === "trace" && (reference.path.startsWith("data.steps[") || reference.path.startsWith("data.initialExternalValues.") || reference.path.startsWith("data.initialStubValues.") || reference.path.startsWith("data.initialStubBaseState.") || reference.path.startsWith("data.readingPath."));
			if (anchorVersion || usesVersion && (entity.kind === "checkpoint" || entity.kind === "trace")) {
				const index = versionIndex(anchorVersion ?? (entity.kind === "checkpoint" || entity.kind === "trace" ? entity.data.contentVersionId : project.projectId));
				if (!index) {
					addIssue(issues, anchorVersion ? entity.kind === "review" ? `${prefix}.data.targetVersionId` : `${prefix}.${parts.slice(0, -1).join(".")}.sourceVersionId` : `${prefix}.data.contentVersionId`, "参照する固定版の本文がありません。", "REFERENCE_INVALID");
					continue;
				}
				inspect(reference, prefix, index);
			} else inspect(reference, prefix);
		}
	});
	project.relations.forEach((relation, i) => (relationReferences.get(relation) ?? collectRelationReferences(relation)).forEach((reference) => inspect(reference, `${path}.relations[${i}]`)));
	viewRefs.forEach((reference) => inspect(reference));
	const relationTypes = options.relationTypes ?? RELATION_TYPES;
	project.relations.forEach((relation, i) => {
		const location = `${path}.relations[${i}]`, type = relationTypes.find((candidate) => candidate.key === relation.relationType), from = entityMap.get(relation.fromId), to = entityMap.get(relation.toId);
		if (!type) addIssue(issues, `${location}.relationType`, "関係の種類が辞書に定義されていません。");
		else {
			if (from && !type.fromKinds.includes(from.kind)) addIssue(issues, `${location}.fromId`, "この関係で許されない始点種類です。", "REFERENCE_INVALID");
			if (to && !type.toKinds.includes(to.kind)) addIssue(issues, `${location}.toId`, "この関係で許されない終点種類です。", "REFERENCE_INVALID");
			if (relation.fromId === relation.toId && !type.allowSelf) addIssue(issues, location, "この関係は自己関係を許しません。");
			if (relation.direction === "symmetric" && !type.allowSymmetric) addIssue(issues, `${location}.direction`, "この関係は対称ではありません。");
		}
		if (relation.deletedAt && !relation.deletionOperationId) addIssue(issues, `${location}.deletionOperationId`, "削除には操作IDが必要です。");
		validateNestedRanges(relation.validity, `${location}.validity`, issues);
	});
	let affectedIds;
	if (reuse && JSON.stringify(project.worldReferences) === JSON.stringify(reuse.previous.worldReferences) && JSON.stringify(project.calendars) === JSON.stringify(reuse.previous.calendars)) {
		affectedIds = /* @__PURE__ */ new Set([...project.entities.filter((entity) => previousEntities.get(entity.id) !== entity).map((entity) => entity.id), ...project.relations.filter((relation) => previousRelations.get(relation.id) !== relation).map((relation) => relation.id)]);
		for (const id of previousEntities.keys()) if (!entityMap.has(id)) affectedIds.add(id);
		for (const id of previousRelations.keys()) if (!relationMap.has(id)) affectedIds.add(id);
	}
	validateCrossEntityRules(project, entityMap, aliases, knownVersions, blocks, issues, path, options, versionIndex, affectedIds ? (entity) => previousEntities.get(entity.id) !== entity || referencesFor(entity).some((reference) => affectedIds.has(reference.id)) : void 0);
	return issues.length ? {
		ok: false,
		issues: issues.slice(0, 256)
	} : {
		ok: true,
		value: project
	};
}
function collectContentIds(value, owner, blocks, aliases, issues, path, depth = 0) {
	if (depth > 32 || !value || typeof value !== "object") return;
	if (Array.isArray(value)) {
		value.forEach((child, i) => collectContentIds(child, owner, blocks, aliases, issues, `${path}[${i}]`, depth + 1));
		return;
	}
	const object = value;
	if (typeof object.id === "string" && typeof object.text === "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(object.kind)) {
		if (blocks.has(object.id)) addIssue(issues, `${path}.id`, "本文ブロックIDが重複しています。");
		blocks.set(object.id, {
			entityId: owner,
			text: object.text
		});
	}
	if (typeof object.id === "string" && "isPublicDefault" in object) {
		if (aliases.has(object.id)) addIssue(issues, `${path}.id`, "別名IDが重複しています。");
		aliases.set(object.id, {
			entityId: owner,
			alias: object
		});
	}
	for (const [key, child] of Object.entries(object)) {
		if ([
			"runtimeState",
			"before",
			"after",
			"publicTexts"
		].includes(key)) continue;
		collectContentIds(child, owner, blocks, aliases, issues, `${path}.${key}`, depth + 1);
	}
}
function cycleIssues(nodes, edges, issues, path, label) {
	const index = new Map(nodes.map((node) => [node.id, node])), colors = /* @__PURE__ */ new Map();
	for (const node of nodes) {
		if (colors.get(node.id)) continue;
		const stack = [{
			id: node.id,
			ids: edges(node),
			cursor: 0
		}];
		colors.set(node.id, 1);
		while (stack.length) {
			const current = stack[stack.length - 1];
			if (current.cursor >= current.ids.length) {
				colors.set(current.id, 2);
				stack.pop();
				continue;
			}
			const nextId = current.ids[current.cursor++], next = index.get(nextId);
			if (!next) continue;
			if (colors.get(nextId) === 1) {
				addIssue(issues, `${path}.entities.${current.id}.data`, `${label}に循環があります。`);
				continue;
			}
			if (!colors.get(nextId)) {
				colors.set(nextId, 1);
				stack.push({
					id: nextId,
					ids: edges(next),
					cursor: 0
				});
			}
		}
	}
}
function validateCrossEntityRules(project, entityMap, aliases, knownVersions, blocks, issues, path, options, resolveVersion, affected) {
	const keys = /* @__PURE__ */ new Map(), translationKeys = /* @__PURE__ */ new Set();
	if (project.entities.some((entity) => !!entity.templateId && !entity.deletedAt)) issues.push(...validateTemplateAssignments(project, path, [...entityMap.values()]));
	project.entities.forEach((entity, i) => {
		const location = `${path}.entities[${i}]`;
		if (entity.deletedAt) return;
		if (entity.kind === "variable" || entity.kind === "quest" || entity.kind === "external_contract") {
			const unique = `${entity.kind}/${entity.kind === "variable" ? `${entity.data.scope}/${entity.data.ownerId ?? ""}/` : ""}${entity.data.key}`;
			if (keys.has(unique)) addIssue(issues, `${location}.data.key`, "同じスコープでキーが重複しています。");
			keys.set(unique, entity.id);
		}
		if (entity.kind === "localization") {
			const unique = `${entity.data.sourceLineId}/${entity.data.language}/${entity.data.sourceHash}`;
			if (translationKeys.has(unique)) addIssue(issues, location, "同じ台詞・言語・原文版の翻訳が重複しています。");
			translationKeys.add(unique);
		}
		if (affected && !affected(entity) && entity.kind !== "checkpoint" && entity.kind !== "trace") return;
		if (entity.kind === "template") issues.push(...validateTemplateDefinition(entity.data, `${location}.data`, entityMap));
		if (entity.kind === "item" && entity.data.itemMode === "instance") {
			const type = entity.data.typeId ? entityMap.get(entity.data.typeId) : void 0;
			if (type?.kind === "item" && type.data.itemMode !== "type") addIssue(issues, `${location}.data.typeId`, "個体のtypeIdは物品種類を参照してください。", "REFERENCE_INVALID");
		}
		if (entity.kind === "quest") {
			const variable = entityMap.get(entity.data.stateVariableId);
			if (variable?.kind === "variable") for (const [j, rule] of (entity.data.transitionRules ?? []).entries()) issues.push(...validateVariableValue(variable, rule.from, `${location}.data.transitionRules[${j}].from`, false), ...validateVariableValue(variable, rule.to, `${location}.data.transitionRules[${j}].to`, false));
		}
		if (entity.kind === "variable") for (const [j, rule] of (entity.data.exclusions ?? []).entries()) {
			const other = entityMap.get(rule.variableId);
			if (other?.kind === "variable") issues.push(...validateVariableValue(other, rule.otherValue, `${location}.data.exclusions[${j}].otherValue`, false));
		}
		if (entity.kind === "collection" && entity.data.purpose === "regression") for (const [j, id] of (entity.data.memberIds ?? []).entries()) {
			const trace = entityMap.get(id);
			if (trace && trace.kind !== "trace") addIssue(issues, `${location}.data.memberIds[${j}]`, "回帰経路集合には保存した試読記録を指定してください。", "REFERENCE_INVALID");
		}
		if (entity.kind === "effect") {
			const target = entityMap.get(entity.data.targetId), operation = entity.data.operation;
			if (target && [
				"set",
				"add",
				"reset"
			].includes(operation)) {
				if (target.kind !== "variable") addIssue(issues, `${location}.data.targetId`, "状態更新効果は状態変数を参照してください。", "REFERENCE_INVALID");
				else {
					if (target.data.derived) addIssue(issues, `${location}.data.targetId`, "算出状態へ直接代入できません。");
					if (operation === "add" && target.data.valueType !== "integer") addIssue(issues, `${location}.data.targetId`, "addはinteger状態だけです。");
					if (entity.data.value && operation !== "add") issues.push(...validateVariableValue(target, entity.data.value, `${location}.data.value`));
				}
			}
			if (target && [
				"grant",
				"consume",
				"move"
			].includes(operation) && target.kind !== "item") addIssue(issues, `${location}.data.targetId`, "物品効果は物品を参照してください。", "REFERENCE_INVALID");
			if (target?.kind === "item" && [
				"grant",
				"consume",
				"move"
			].includes(operation) && entity.data.instanceId) {
				const instance = entityMap.get(entity.data.instanceId);
				if (instance?.kind === "item" && (instance.data.itemMode !== "instance" || (target.data.itemMode === "type" ? instance.data.typeId !== target.id : instance.id !== target.id))) addIssue(issues, `${location}.data.instanceId`, "指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
			}
			if (target && operation === "assert" && target.kind !== "assertion") addIssue(issues, `${location}.data.targetId`, "認識効果は事実・認識を参照してください。", "REFERENCE_INVALID");
			if (operation === "move" && entity.data.value?.type === "ref") {
				const destination = entityMap.get(entity.data.value.value);
				if (destination && ![
					"character",
					"group",
					"place"
				].includes(destination.kind)) addIssue(issues, `${location}.data.value`, "物品の移動先は人物・グループ・場所です。", "REFERENCE_INVALID");
			}
		}
		if (entity.kind === "flow_graph") {
			for (const entry of [...entity.data.entryIds, ...entity.data.exitIds]) if (!entity.data.nodeIds.includes(entry)) addIssue(issues, `${location}.data`, "入口・出口はその分岐図のノード集合に含めてください。");
			for (const edgeId of entity.data.edgeIds) {
				const edge = entityMap.get(edgeId);
				if (edge?.kind !== "flow_edge") continue;
				if (!entity.data.nodeIds.includes(edge.data.fromId) || typeof edge.data.toId === "string" && !entity.data.nodeIds.includes(edge.data.toId)) addIssue(issues, `${location}.data.edgeIds`, "進行線の始点・終点は同じ分岐図内に置いてください。");
			}
			const parameterKeys = (entity.data.parameters ?? []).map((parameter) => parameter.key);
			if (new Set(parameterKeys).size !== parameterKeys.length) addIssue(issues, `${location}.data.parameters`, "引数のキーが重複しています。");
		}
		if (entity.kind === "flow_edge" && options.runtime && typeof entity.data.toId !== "string") addIssue(issues, `${location}.data.toId`, "未完成の分岐先は実行用出力できません。", "EXPORT_UNSUPPORTED");
		if (entity.kind === "variable" && options.runtime && entity.data.initial.type === "unknown" && !entity.data.derived) addIssue(issues, `${location}.data.initial`, "初期値が未定です。", "CONDITION_UNKNOWN");
		validateConditionTypesInValue(entity.data, location, entityMap, issues);
		if (entity.kind === "review" && typeof entity.data.target === "object") {
			validateAnchors(entity.data.target, `${location}.data.target`, entityMap, blocks, issues, 0, resolveVersion, entity.data.targetVersionId);
			validateAnchors({
				...entity.data,
				target: null
			}, `${location}.data`, entityMap, blocks, issues, 0, resolveVersion);
		} else validateAnchors(entity.data, `${location}.data`, entityMap, blocks, issues, 0, resolveVersion);
		if (entity.kind === "projection_profile") {
			const policy = entity.data.namePolicy;
			if ("mode" in policy && policy.mode === "alias") {
				const alias = aliases.get(policy.aliasId);
				if (alias && !entity.data.includedIds.includes(alias.entityId)) addIssue(issues, `${location}.data.namePolicy`, "別名は投影対象の本体に属している必要があります。");
			} else if (!("mode" in policy)) {
				for (const [targetId, specific] of Object.entries(policy.byEntityId ?? {})) if (specific.mode === "alias" && aliases.get(specific.aliasId)?.entityId !== targetId) addIssue(issues, `${location}.data.namePolicy.byEntityId.${targetId}`, "別名が指定した本体に属していません。");
			}
		}
		if (entity.kind === "checkpoint" && (!knownVersions.has(entity.data.runtimeState.contentVersionId) || entity.data.runtimeState.contentVersionId !== entity.data.contentVersionId)) addIssue(issues, `${location}.data.runtimeState.contentVersionId`, "途中開始の状態と対象版が一致しません。");
		if (entity.kind === "checkpoint") {
			const result = validateRuntimeState(entity.data.runtimeState, `${location}.data.runtimeState`);
			if (!result.ok) issues.push(...result.issues);
			if (entity.data.presentationState && (entity.data.presentationState.contentVersionId !== entity.data.contentVersionId || entity.data.presentationState.presentationPosition !== entity.data.runtimeState.presentationPosition || entity.data.presentationState.provenance !== entity.data.runtimeState.provenance)) addIssue(issues, `${location}.data.presentationState`, "提示前の観測状態と開始点・対象版・由来が一致しません。");
			if (entity.data.presentationResults != null) {
				const version = resolveVersion(entity.data.contentVersionId);
				if (version) issues.push(...validateInitialPresentationResults({
					...entity.data.runtimeState,
					provenance: entity.data.origin ?? "partial"
				}, entity.data.presentationResults, [...version.entities.values()], `${location}.data.presentationResults`));
			}
		}
		if (entity.kind === "trace") {
			const trace = entity.data;
			if (trace.initialStubBaseState && !trace.initialStubValues) addIssue(issues, `${location}.data.initialStubBaseState`, "stub前の個別状態には初期stub入力の記録が必要です。");
			if (trace.mode === "chapters") {
				if (trace.initialStubValues || trace.initialStubBaseState) addIssue(issues, `${location}.data.initialStubValues`, "章経路の個別開始はcheckpointへ、外部仮値はinitialExternalValuesへ記録してください。");
				if (!trace.readingPath) addIssue(issues, `${location}.data.readingPath`, "章読み通しには提示経路が必要です。");
				if (trace.steps.length) addIssue(issues, `${location}.data.steps`, "章読み通しとフロー遷移を混在させられません。");
			} else if (trace.readingPath != null) addIssue(issues, `${location}.data.readingPath`, "提示経路はmode:chaptersの記録に指定してください。");
			trace.steps.forEach((step, index) => {
				for (const [field, state] of [["before", step.before], ["after", step.after]]) {
					const result = validateRuntimeState(state, `${location}.data.steps[${index}].${field}`);
					if (!result.ok) issues.push(...result.issues);
				}
				if (step.presentationState && (step.presentationState.contentVersionId !== trace.contentVersionId || step.presentationState.presentationPosition !== step.after.presentationPosition || step.presentationState.provenance !== step.after.provenance)) addIssue(issues, `${location}.data.steps[${index}].presentationState`, "提示前の観測状態と提示先・対象版・由来が一致しません。");
			});
			trace.readingPath?.occurrences.forEach((occurrence, index) => {
				for (const [field, state] of [["before", occurrence.before], ["after", occurrence.after]]) {
					const result = validateRuntimeState(state, `${location}.data.readingPath.occurrences[${index}].${field}`);
					if (!result.ok) issues.push(...result.issues);
				}
			});
		}
	});
	for (const kind of [
		"place",
		"group",
		"flow_graph",
		"map"
	]) cycleIssues(project.entities.filter((entity) => entity.kind === kind && !entity.deletedAt), (entity) => {
		if (entity.kind === "place" || entity.kind === "group") return entity.data.parentId ? [entity.data.parentId] : [];
		if (entity.kind === "flow_graph") return entity.data.parentGraphId ? [entity.data.parentGraphId] : [];
		if (entity.kind === "map") return entity.data.parentMapId ? [entity.data.parentMapId] : [];
		return [];
	}, issues, path, `${KIND_LABELS[kind]}の階層`);
	cycleIssues(project.entities.filter((entity) => entity.kind === "production_task" && !entity.deletedAt), (entity) => entity.kind === "production_task" ? entity.data.dependsOn ?? [] : [], issues, path, "制作依存");
	cycleIssues(project.entities.filter((entity) => entity.kind === "variable" && !entity.deletedAt), (entity) => entity.kind === "variable" && entity.data.derived ? expressionReferences(entity.data.derived) : [], issues, path, "算出状態");
	cycleIssues(project.entities.filter((entity) => entity.kind === "flow_graph" && !entity.deletedAt), (entity) => entity.kind === "flow_graph" ? entity.data.nodeIds.flatMap((nodeId) => {
		const node = entityMap.get(nodeId);
		return node?.kind === "flow_node" && node.data.childGraphId ? [node.data.childGraphId] : [];
	}) : [], issues, path, "分岐図の呼出階層");
	issues.push(...validateEventTimes([...entityMap.values()].filter((entity) => entity.kind === "event" && !entity.deletedAt)));
	const automaticPriority = /* @__PURE__ */ new Map();
	for (const entity of project.entities) if (entity.kind === "flow_edge" && entity.data.edgeType === "automatic" && !entity.deletedAt) {
		const priorityKey = `${entity.data.fromId}/${entity.data.priority ?? 0}`;
		if (automaticPriority.has(priorityKey)) addIssue(issues, `${path}.entities.${entity.id}.data.priority`, "同じ始点の自動候補で優先順位が重複しています。");
		automaticPriority.set(priorityKey, entity.id);
	}
}
function expressionReferences(expression) {
	const references = [];
	walk({ type: "expression" }, expression, "", [], references);
	return references.filter((reference) => reference.kinds?.includes("variable")).map((reference) => reference.id);
}
function validateConditionTypesInValue(value, path, entities, issues, depth = 0) {
	if (depth > 32 || !value || typeof value !== "object") return;
	if (Array.isArray(value)) {
		value.forEach((child, i) => validateConditionTypesInValue(child, `${path}[${i}]`, entities, issues, depth + 1));
		return;
	}
	const object = value;
	if (object.op === "compare") {
		const variable = entities.get(object.variableId);
		if (variable?.kind === "variable") {
			const comparator = object.comparator, values = Array.isArray(object.value) ? object.value : [object.value];
			if ([
				"lt",
				"le",
				"gt",
				"ge"
			].includes(comparator) && variable.data.valueType !== "integer") addIssue(issues, `${path}.comparator`, "順序比較はintegerにだけ使えます。");
			values.forEach((item, i) => {
				if (item.type !== "unknown" && item.type !== variable.data.valueType) addIssue(issues, `${path}.value${values.length > 1 ? `[${i}]` : ""}`, "比較値の型が状態変数と一致しません。");
			});
		}
	}
	for (const [field, child] of Object.entries(object)) validateConditionTypesInValue(child, `${path}.${field}`, entities, issues, depth + 1);
}
function validateAnchors(value, path, entities, blocks, issues, depth = 0, resolveVersion, defaultVersion) {
	if (depth > 32 || !value || typeof value !== "object") return;
	if (Array.isArray(value)) {
		value.forEach((child, i) => validateAnchors(child, `${path}[${i}]`, entities, blocks, issues, depth + 1, resolveVersion, defaultVersion));
		return;
	}
	const object = value;
	if (typeof object.entityId === "string") {
		if (object.positionStatus === "unresolved" && (!object.positionReason || object.start != null || object.end != null)) addIssue(issues, path, "位置不明には理由を付け、確定した文字範囲を外してください。");
		if (object.positionStatus !== "unresolved" && (object.positionReason != null || object.quotedText != null)) addIssue(issues, path, "位置不明の理由・引用は位置不明状態と一緒に保存してください。");
		const version = typeof object.sourceVersionId === "string" ? object.sourceVersionId : defaultVersion, index = version && resolveVersion ? resolveVersion(version) : void 0;
		const entityIndex = index?.entities ?? entities, blockIndex = index?.blocks ?? blocks;
		let targetText;
		if (typeof object.blockId === "string") {
			const block = blockIndex.get(object.blockId);
			if (block && block.entityId !== object.entityId) addIssue(issues, `${path}.blockId`, "段落は指定した情報に属していません。", "REFERENCE_INVALID");
			targetText = block?.text;
		}
		if (typeof object.lineId === "string") {
			const line = entityIndex.get(object.lineId);
			if (line?.kind === "dialogue_line") targetText = richTextToPlainText(line.data.text);
		}
		if (typeof object.start === "number" || typeof object.end === "number") {
			if (typeof object.start !== "number" || typeof object.end !== "number") addIssue(issues, path, "文字範囲はstart/endを対で指定してください。");
			if (targetText === void 0) addIssue(issues, path, "文字範囲には本文ブロックまたは台詞への参照が必要です。");
			else if (typeof object.end === "number" && object.end > codePointLength(targetText)) addIssue(issues, `${path}.end`, "文字範囲が参照元の本文を超えています。");
		}
	}
	for (const [field, child] of Object.entries(object)) if (![
		"publicTexts",
		"before",
		"after",
		"runtimeState"
	].includes(field)) validateAnchors(child, `${path}.${field}`, entities, blocks, issues, depth + 1, resolveVersion);
}
function validateProject(input, options = {}) {
	if (!isObject(input)) return {
		ok: false,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	const issues = [];
	for (const field of Object.keys(input)) if (![
		...projectKeys,
		"snapshots",
		"history"
	].includes(field)) addIssue(issues, `project.${field}`, "作品に未知の項目があります。");
	if (!Array.isArray(input.snapshots)) addIssue(issues, "project.snapshots", "必須の配列です。");
	if (!Array.isArray(input.history)) addIssue(issues, "project.history", "必須の配列です。");
	const snapshotIds = new Set((Array.isArray(input.snapshots) ? input.snapshots : []).flatMap((snapshot) => isObject(snapshot) && typeof snapshot.id === "string" ? [snapshot.id] : []));
	if (Object.hasOwn(input, "authorAlternatives")) walk(alternativesSchema, input.authorAlternatives, "project.authorAlternatives", issues, []);
	const validated = validateContent(Object.fromEntries(projectContentKeys.filter((field) => Object.hasOwn(input, field)).map((field) => [field, input[field]])), "project", options, snapshotIds, snapshotContentMap(input.snapshots));
	if (!validated.ok) issues.push(...validated.issues);
	if (issues.length) return {
		ok: false,
		issues: issues.slice(0, 256)
	};
	const project = input;
	validateSnapshotCollection(project.snapshots, "project.snapshots", project.projectId, options, issues);
	const historyIds = /* @__PURE__ */ new Set();
	project.history.forEach((command, i) => {
		const path = `project.history[${i}]`, raw = command;
		if (!isObject(raw)) {
			addIssue(issues, path, "履歴はコマンドです。");
			return;
		}
		const commandMeta = obj({
			operationId: req(idSchema),
			projectId: req(idSchema),
			baseRevision: req({ type: "revision" }),
			revision: req({ type: "revision" }),
			targetIds: req(arr(idSchema, true)),
			reason: req(txt()),
			createdAt: req({ type: "datetime" }),
			compensatesOperationId: opt(idSchema),
			idMap: opt(record$1(idSchema, idSchema)),
			importOrigin: opt(obj({
				sourceProjectId: req(idSchema),
				sourceOperationId: req(idSchema),
				importOperationId: req(idSchema)
			}))
		});
		for (const field of Object.keys(raw)) if (field !== "before" && field !== "after" && commandMeta.type === "object" && !Object.hasOwn(commandMeta.fields, field)) addIssue(issues, `${path}.${field}`, "コマンドに未知の項目があります。");
		walk(commandMeta, Object.fromEntries(Object.entries(raw).filter(([field]) => field !== "before" && field !== "after")), path, issues, []);
		if (historyIds.has(command.operationId)) addIssue(issues, `${path}.operationId`, "履歴の操作IDが重複しています。");
		historyIds.add(command.operationId);
		if (command.projectId !== project.projectId) addIssue(issues, `${path}.projectId`, "履歴が別の作品に属しています。");
		for (const field of ["before", "after"]) {
			if (!isObject(raw[field])) {
				addIssue(issues, `${path}.${field}`, "変更前後の内容を保持してください。");
				continue;
			}
			const state = raw[field];
			if (!Array.isArray(state.snapshots)) addIssue(issues, `${path}.${field}.snapshots`, "復元に必要な公開版配列が必要です。");
			if (Object.hasOwn(state, "authorAlternatives")) walk(alternativesSchema, state.authorAlternatives, `${path}.${field}.authorAlternatives`, issues, []);
			const historical = Object.fromEntries(Object.entries(state).filter(([key]) => key !== "snapshots" && key !== "authorAlternatives"));
			const historicalIds = new Set((Array.isArray(state.snapshots) ? state.snapshots : []).flatMap((item) => isObject(item) && typeof item.id === "string" ? [item.id] : []));
			const result = validateContent(historical, `${path}.${field}`, options, historicalIds, snapshotContentMap(state.snapshots));
			if (!result.ok) issues.push(...result.issues);
			else if (result.value.projectId !== project.projectId) addIssue(issues, `${path}.${field}.projectId`, "履歴の内容が別の作品に属しています。");
			if (Array.isArray(state.snapshots)) validateSnapshotCollection(state.snapshots, `${path}.${field}.snapshots`, project.projectId, options, issues);
		}
	});
	return issues.length ? {
		ok: false,
		issues: issues.slice(0, 256)
	} : {
		ok: true,
		value: project
	};
}
/** Current content for an edit of previously verified storage. Imports still use validateProject. */
function validateCurrentProject(input, options = {}, reuse) {
	const issues = [];
	for (const field of Object.keys(input)) if (![
		...projectKeys,
		"snapshots",
		"history"
	].includes(field)) addIssue(issues, `project.${field}`, "作品に未知の項目があります。");
	if (!Array.isArray(input.snapshots) || !Array.isArray(input.history)) addIssue(issues, "project", "公開版と履歴の配列が必要です。");
	if (Object.hasOwn(input, "authorAlternatives")) walk(alternativesSchema, input.authorAlternatives, "project.authorAlternatives", issues, []);
	if (issues.length) return {
		ok: false,
		issues
	};
	const ids = new Set(input.snapshots.map((snapshot) => snapshot.id));
	const result = validateContent(Object.fromEntries(projectContentKeys.filter((field) => Object.hasOwn(input, field)).map((field) => [field, input[field]])), "project", options, ids, snapshotContentMap(input.snapshots), reuse);
	return result.ok ? {
		ok: true,
		value: input
	} : result;
}
function validateSnapshotCollection(snapshots, path, projectId, options, issues) {
	const ids = new Set(snapshots.flatMap((snapshot) => isObject(snapshot) && typeof snapshot.id === "string" ? [snapshot.id] : [])), duplicates = /* @__PURE__ */ new Set(), contents = snapshotContentMap(snapshots);
	snapshots.forEach((snapshot, i) => {
		const location = `${path}[${i}]`;
		if (!isObject(snapshot)) {
			addIssue(issues, location, "公開版はオブジェクトです。");
			return;
		}
		const metadata = obj({
			id: req(idSchema),
			versionLabel: req(txt(1, 128)),
			contentHash: req({ type: "hash" }),
			createdAt: req({ type: "datetime" })
		});
		for (const field of Object.keys(snapshot)) if (![
			"id",
			"versionLabel",
			"contentHash",
			"createdAt",
			"content"
		].includes(field)) addIssue(issues, `${location}.${field}`, "公開版に未知の項目があります。");
		walk(metadata, Object.fromEntries(Object.entries(snapshot).filter(([field]) => field !== "content")), location, issues, []);
		if (typeof snapshot.id === "string") {
			if (duplicates.has(snapshot.id)) addIssue(issues, `${location}.id`, "公開版のIDが重複しています。");
			duplicates.add(snapshot.id);
			if (snapshot.id === projectId) addIssue(issues, `${location}.id`, "公開版IDは作品IDと別にしてください。");
		}
		const result = validateContent(snapshot.content, `${location}.content`, options, ids, contents);
		if (!result.ok) issues.push(...result.issues);
		else if (result.value.projectId !== projectId) addIssue(issues, `${location}.content.projectId`, "公開版が別の作品に属しています。");
	});
}
function snapshotContentMap(snapshots) {
	if (!Array.isArray(snapshots)) return /* @__PURE__ */ new Map();
	return new Map(snapshots.flatMap((snapshot) => isObject(snapshot) && typeof snapshot.id === "string" && isObject(snapshot.content) && [
		"entities",
		"relations",
		"calendars",
		"worldReferences"
	].every((key) => Array.isArray(snapshot.content[key]) && snapshot.content[key].every(isObject)) ? [[snapshot.id, snapshot.content]] : []));
}
var KIND_LABELS, ENTITY_KINDS, STATUSES, SCOPES, RELATION_TYPES, RELATION_LABELS, ID_PATTERN, REVISION_PATTERN, emptyValidity, newId, txt, short, key, num, bool, idSchema, tick, typed$1, en, ref$1, scopedRef, arr, refs$1, obj, req, opt, optionalValue, rich$1, summary, cond, time$1, record$1, union, anchor, unresolvedTextAnnotation, nullableValidity, targetScope, alias, exception, transition, resetRule, allowed, trigger, reuse, unresolved, runtimeItem, runtimeAssertion, presentationResult, callFrame, runtime, readingOccurrence, readingPath, groupCoverage, coverageCount, coverage, fieldDefinition, estimate, publicText, ENTITY_SCHEMAS, isObject, utf8Encoder, utf8Bytes, textSpan, richTextBlocks, commonFields, relationSchema, entityRecordSchemas, worldReferenceSchema, viewSchema, projectHeaderFields, projectContentKeys, projectKeys, alternativesSchema;
var init_model = __esmMin((() => {
	init_pinnedWorlds();
	init_reuse();
	init_types();
	init_time();
	init_templates();
	KIND_LABELS = {
		character: "人物",
		group: "グループ",
		event: "出来事",
		place: "場所",
		item: "物品",
		note: "メモ",
		chapter: "章",
		scene: "場面",
		goal: "目標",
		flow_node: "進行ノード",
		flow_edge: "進行線",
		flow_graph: "分岐図",
		dialogue_line: "台詞",
		quest: "クエスト",
		lore: "設定",
		variable: "状態変数",
		effect: "効果",
		assertion: "事実・認識",
		foreshadow: "伏線",
		disclosure: "手掛かり・回収",
		checkpoint: "途中開始点",
		trace: "試読記録",
		attachment: "添付素材",
		source: "資料・出所",
		cue: "演出",
		storyboard_frame: "絵コンテ",
		localization: "翻訳",
		recording: "収録",
		terminology: "用語",
		map: "地図",
		travel_route: "移動経路",
		template: "雛形",
		collection: "一覧",
		review: "レビュー",
		creative_brief: "企画",
		decision: "制作判断",
		gameplay_spec: "ゲーム仕様",
		production_task: "制作タスク",
		media_variant: "媒体版",
		voice_rule: "口調",
		external_contract: "外部契約",
		snapshot: "公開版",
		projection_profile: "公開投影"
	};
	ENTITY_KINDS = Object.keys(KIND_LABELS);
	STATUSES = [
		"confirmed",
		"provisional",
		"needs_review",
		"rejected",
		"alternate"
	];
	SCOPES = [
		"scene",
		"chapter",
		"character",
		"run",
		"across_runs"
	];
	RELATION_TYPES = [
		{
			key: "trust",
			label: "信頼",
			fromKinds: ["character"],
			toKinds: ["character"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "causes",
			label: "因果",
			fromKinds: ["event"],
			toKinds: ["event"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "requires",
			label: "前提",
			fromKinds: ENTITY_KINDS,
			toKinds: ENTITY_KINDS,
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "foreshadow_payoff",
			label: "手掛かり→回収",
			fromKinds: ["disclosure"],
			toKinds: ["disclosure"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "parent_of",
			label: "親子",
			fromKinds: ["character"],
			toKinds: ["character"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "event_foreshadow",
			label: "出来事の予告",
			fromKinds: ["event"],
			toKinds: ["event"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "event_payoff",
			label: "出来事の回収",
			fromKinds: ["event"],
			toKinds: ["event"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "mentor_of",
			label: "師弟",
			fromKinds: ["character"],
			toKinds: ["character"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "bloodline",
			label: "血統",
			fromKinds: ["character"],
			toKinds: ["character"],
			allowSelf: false,
			allowSymmetric: false
		},
		{
			key: "related",
			label: "関連",
			fromKinds: ENTITY_KINDS,
			toKinds: ENTITY_KINDS,
			allowSelf: false,
			allowSymmetric: true
		},
		{
			key: "reference",
			label: "参照",
			fromKinds: ENTITY_KINDS,
			toKinds: ENTITY_KINDS,
			allowSelf: true,
			allowSymmetric: false
		}
	];
	RELATION_LABELS = Object.fromEntries(RELATION_TYPES.map((type) => [type.key, type.label]));
	ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
	REVISION_PATTERN = /^(?:0|[1-9][0-9]*)$/;
	emptyValidity = () => ({
		worldRange: null,
		routeCondition: null,
		presentationAnchor: null
	});
	newId = () => crypto.randomUUID();
	txt = (min = 0, max) => ({
		type: "text",
		min,
		max,
		maxBytes: 1048576
	});
	short = txt(0, 128);
	key = txt(1, 128);
	num = (min, max, integer = false) => ({
		type: "number",
		min,
		max,
		integer
	});
	bool = { type: "boolean" };
	idSchema = { type: "id" };
	tick = { type: "tick" };
	typed$1 = { type: "typed" };
	en = (...values) => ({
		type: "enum",
		values
	});
	ref$1 = (...kinds) => ({
		type: "ref",
		kinds: kinds.length ? kinds : void 0,
		scope: "entity"
	});
	scopedRef = (scope) => ({
		type: "ref",
		scope
	});
	arr = (item, unique = false, min, max) => ({
		type: "array",
		item,
		unique,
		min,
		max
	});
	refs$1 = (...kinds) => arr(ref$1(...kinds), true);
	obj = (fields) => ({
		type: "object",
		fields
	});
	req = (schema) => ({
		schema,
		required: true
	});
	opt = (schema) => ({
		schema,
		nullable: true
	});
	optionalValue = (schema) => ({
		schema,
		nullable: false
	});
	rich$1 = { type: "richtext" };
	summary = {
		type: "richtext",
		max: 2048
	};
	cond = { type: "condition" };
	time$1 = { type: "time" };
	record$1 = (value, recordKey) => ({
		type: "record",
		value,
		key: recordKey
	});
	union = (...choices) => ({
		type: "union",
		choices
	});
	anchor = obj({
		entityId: req(ref$1()),
		blockId: opt(scopedRef("block")),
		lineId: opt(ref$1("dialogue_line")),
		start: opt(num(0, void 0, true)),
		end: opt(num(0, void 0, true)),
		sourceVersionId: opt(scopedRef("snapshot")),
		positionStatus: opt(en("unresolved")),
		positionReason: opt(txt(1)),
		quotedText: opt(txt())
	});
	unresolvedTextAnnotation = union(obj({
		kind: req(en("ruby")),
		originalText: req(txt()),
		reason: req(txt(1)),
		reading: req(txt())
	}), obj({
		kind: req(en("link")),
		originalText: req(txt()),
		reason: req(txt(1)),
		target: req(anchor)
	}));
	nullableValidity = obj({
		worldRange: {
			schema: obj({
				start: {
					schema: tick,
					required: true,
					nullable: true
				},
				end: {
					schema: tick,
					required: true,
					nullable: true
				}
			}),
			required: true,
			nullable: true
		},
		routeCondition: {
			schema: cond,
			required: true,
			nullable: true
		},
		presentationAnchor: {
			schema: anchor,
			required: true,
			nullable: true
		}
	});
	targetScope = obj({
		projectId: req(scopedRef("project")),
		graphId: opt(ref$1("flow_graph")),
		chapterId: opt(ref$1("chapter")),
		routeCondition: opt(cond),
		targetSnapshotId: opt(scopedRef("snapshot"))
	});
	alias = obj({
		id: req(idSchema),
		text: req(txt(1, 128)),
		reading: req(short),
		validity: req(nullableValidity),
		audienceHolderIds: req(refs$1("character")),
		isPublicDefault: req(bool)
	});
	exception = obj({
		reason: req(txt(1)),
		targetScope: req(targetScope),
		validity: req(nullableValidity),
		evidenceIds: req(refs$1())
	});
	transition = obj({
		from: req(typed$1),
		to: req(typed$1),
		reason: opt(txt()),
		exception: opt(bool),
		exceptionDetails: opt(exception)
	});
	resetRule = obj({
		on: req(en("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
		value: req(typed$1),
		reason: opt(txt())
	});
	allowed = obj({
		min: opt(num(void 0, void 0, true)),
		max: opt(num(void 0, void 0, true)),
		values: opt(arr(union(txt(), bool), true))
	});
	trigger = obj({
		id: opt(idSchema),
		event: req(en("enter", "talk", "battle_result", "manual", "custom")),
		eventKey: req(txt()),
		repeat: req(en("once", "repeatable")),
		scope: opt(en(...SCOPES)),
		deadline: opt(time$1)
	});
	reuse = obj({
		mode: req(en("reference", "clone", "override")),
		sourceId: req(ref$1()),
		pinnedSnapshotId: req(scopedRef("snapshot")),
		overrideFields: req(arr(txt(1), true)),
		bindings: opt(record$1(idSchema, idSchema))
	});
	unresolved = obj({ unresolved: req(obj({
		label: req(txt()),
		reason: req(txt(1))
	})) });
	runtimeItem = obj({
		instanceId: req(idSchema),
		typeId: req(ref$1("item")),
		quantity: req(num(0, void 0, true)),
		ownerId: opt(ref$1("character", "group")),
		locationId: opt(ref$1("place")),
		consumed: req(bool),
		reason: opt(txt())
	});
	runtimeAssertion = obj({
		assertionId: req(ref$1("assertion")),
		holderId: opt(ref$1("character")),
		truth: req(en("true", "false", "unknown")),
		sourceEffectId: opt(ref$1("effect"))
	});
	presentationResult = obj({
		targetId: req(ref$1("flow_node", "flow_edge", "disclosure")),
		value: req(en("true", "false", "unknown")),
		reasons: req(arr(txt()))
	});
	callFrame = obj({
		graphId: req(ref$1("flow_graph")),
		returnNodeId: req(ref$1("flow_node")),
		parameters: req(record$1(typed$1, key))
	});
	runtime = obj({
		contentVersionId: req(scopedRef("snapshot")),
		variableValues: req(record$1(typed$1, ref$1("variable"))),
		itemInstances: req(arr(runtimeItem)),
		assertions: req(arr(runtimeAssertion)),
		seenIds: req(arr(scopedRef("presentation"), true)),
		visitCounts: req(record$1(num(0, void 0, true), ref$1())),
		onceTriggers: req(arr(txt(1), true)),
		rngSeed: req(txt(1)),
		rngPosition: req(num(0, void 0, true)),
		callStack: req(arr(callFrame)),
		presentationPosition: opt(ref$1("flow_node")),
		loopNumber: req(num(0, void 0, true)),
		provenance: req(en("full_play", "partial", "imported", "stub")),
		resetCauses: opt(arr(obj({
			variableId: req(ref$1("variable")),
			on: req(en("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
			before: req(typed$1),
			after: req(typed$1),
			reason: req(txt())
		})))
	});
	readingOccurrence = obj({
		entityId: req(ref$1("scene")),
		occurrenceId: req(txt(1, 256)),
		before: req(runtime),
		after: req(runtime),
		presentationState: opt(runtime),
		conditionResults: req(arr(presentationResult)),
		externalValues: opt(record$1(typed$1, ref$1("external_contract"))),
		worldTick: opt(tick)
	});
	readingPath = obj({
		chapterIds: req(refs$1("chapter")),
		sceneIds: req(arr(ref$1("scene"))),
		selection: opt(en("chapters", "scenes")),
		occurrences: req(arr(readingOccurrence))
	});
	groupCoverage = obj({
		checked: req(num(0, void 0, true)),
		total: req(num(0, void 0, true))
	});
	coverageCount = obj({
		byProvenance: opt(record$1(groupCoverage, en("full_play", "partial", "imported", "stub"))),
		byExternalMode: opt(record$1(groupCoverage, en("internal", "stub", "actual", "mixed"))),
		checked: req(num(0, void 0, true)),
		total: req(num(0, void 0, true)),
		excluded: opt(num(0, void 0, true)),
		unknown: opt(num(0, void 0, true))
	});
	coverage = obj(Object.fromEntries([
		"scenes",
		"dialogue",
		"choices",
		"conditionTrue",
		"conditionFalse",
		"declaredTests"
	].map((field) => [field, req(coverageCount)])));
	fieldDefinition = obj({
		key: req(key),
		label: req(txt(1, 128)),
		type: req(en("text", "number", "boolean", "enum", "date", "ref")),
		required: req(bool),
		nullable: req(bool),
		default: {
			schema: { type: "custom" },
			required: true,
			nullable: true
		},
		allowedValues: opt(arr(txt(), true)),
		targetKinds: opt(arr(en(...ENTITY_KINDS), true)),
		help: opt(txt())
	});
	estimate = obj({
		value: opt(num(0)),
		range: opt(obj({
			min: req(num(0)),
			max: req(num(0))
		})),
		unit: req(txt(1)),
		assumptions: req(arr(txt())),
		scope: req(targetScope),
		unknownCount: req(num(0, void 0, true)),
		source: req(txt()),
		speed: opt(num(Number.MIN_VALUE))
	});
	publicText = obj({
		...Object.fromEntries([
			"summary",
			"body",
			"text",
			"description",
			"question",
			"intent",
			"caption",
			"usageNotes",
			"interpretation",
			"examples",
			"action",
			"tutorial"
		].map((field) => [field, opt(rich$1)])),
		...Object.fromEntries([
			"label",
			"reading",
			"terminalReason",
			"reason",
			"key",
			"canonical",
			"language",
			"locale",
			"sourceHash",
			"expression",
			"method",
			"locator",
			"predicate",
			"cueType",
			"precision",
			"displayName",
			"relationType",
			"eventKey",
			"resetReason",
			"exclusionReason",
			"exceptionReason",
			"camera",
			"parameters",
			"variants",
			"estimateAssumptions",
			"estimateSource",
			"blockingReason",
			"mechanic",
			"intentionalDifference",
			"excerptLocation",
			"estimateUnit",
			"firstPerson",
			"addressing",
			"phrasing"
		].map((field) => [field, opt(txt())]))
	});
	ENTITY_SCHEMAS = {
		character: obj({
			reading: opt(short),
			aliases: opt(arr(alias)),
			summary: opt(summary),
			body: opt(rich$1),
			authorNotes: opt(rich$1),
			birth: opt(time$1),
			death: opt(time$1),
			goals: opt(refs$1("goal")),
			voiceRules: opt(refs$1("voice_rule"))
		}),
		group: obj({
			groupType: req(en("display", "faction", "plot_thread", "category")),
			members: opt(refs$1()),
			parentId: opt(ref$1("group")),
			summary: opt(summary)
		}),
		event: obj({
			summary: req(summary),
			time: req(time$1),
			laneRole: req(en("common", "participants", "both")),
			participants: opt(arr(obj({
				characterId: req(ref$1("character")),
				role: req(en("actor", "witness", "mentioned", "informed", "custom")),
				evidenceIds: opt(refs$1()),
				knowledgeEffectIds: opt(refs$1("effect"))
			}))),
			locationId: opt(ref$1("place")),
			itemIds: opt(refs$1("item")),
			authorNotes: opt(rich$1),
			constraints: opt(arr(union(obj({
				type: req(en("before", "same_start")),
				targetEventId: req(ref$1("event"))
			}), obj({
				type: req(en("end_gap")),
				targetEventId: req(ref$1("event")),
				minimumTicks: req(tick),
				maximumTicks: req(tick)
			}))))
		}),
		place: obj({
			parentId: opt(ref$1("place")),
			reading: opt(short),
			aliases: opt(arr(alias)),
			body: opt(rich$1),
			mapIds: opt(refs$1("map")),
			changes: opt(refs$1("assertion"))
		}),
		item: obj({
			itemMode: req(en("type", "instance")),
			typeId: opt(ref$1("item")),
			body: opt(rich$1),
			properties: opt({ type: "custom" }),
			changes: opt(refs$1("assertion"))
		}),
		note: obj({
			handoffReceipt: opt(obj({
				approval: req(obj({
					entityId: req(scopedRef("entity")),
					sourceVersionId: req(scopedRef("snapshot"))
				})),
				sourceVersionId: req(scopedRef("snapshot")),
				verificationVersionId: req(scopedRef("snapshot")),
				profileVersionId: req(scopedRef("snapshot")),
				sourceRevision: req({ type: "revision" }),
				profileId: req(ref$1("projection_profile")),
				packageHash: req({ type: "hash" }),
				receiptHash: req({ type: "hash" }),
				mode: req(en("stub", "actual", "mixed")),
				rawJson: req(txt(1, 1048576)),
				idMappings: req(arr(obj({
					entityId: req(scopedRef("record")),
					sourceVersionId: req(scopedRef("snapshot")),
					publicId: req(txt(1, 256))
				}))),
				projectionBindings: req(arr(obj({
					entityId: req(scopedRef("projection_record")),
					sourceVersionId: req(scopedRef("snapshot")),
					editionVersionId: req(scopedRef("snapshot")),
					publicId: req(txt(1, 256))
				}))),
				citationBindings: req(arr(obj({
					sourceVersionId: req(scopedRef("snapshot")),
					publicVersionId: req(txt(1, 256))
				}))),
				worldVersions: req(arr(obj({
					sourceVersionId: req(scopedRef("snapshot")),
					contentHash: req({ type: "hash" })
				})))
			})),
			body: req(rich$1),
			attachmentIds: opt(refs$1("attachment")),
			convertedToIds: opt(refs$1()),
			originNoteId: opt(ref$1("note"))
		}),
		chapter: obj({
			sceneIds: req(refs$1("scene")),
			summary: opt(summary),
			authorNotes: opt(rich$1),
			structureRole: opt(short)
		}),
		scene: obj({
			summary: req(summary),
			body: req(rich$1),
			authorNotes: req(rich$1),
			eventIds: req(refs$1("event")),
			dialogueLineIds: opt(refs$1("dialogue_line")),
			chapterId: opt(ref$1("chapter")),
			threadIds: opt(refs$1("group")),
			povId: opt(ref$1("character")),
			goals: opt(rich$1),
			conflicts: opt(rich$1),
			results: opt(rich$1),
			newInformation: opt(rich$1),
			tension: opt(num(0, 10)),
			importance: opt(num(0, 10)),
			blockIds: opt(arr(scopedRef("block"), true)),
			reuse: opt(reuse)
		}),
		goal: obj({
			ownerId: req(ref$1("character", "group")),
			description: req(rich$1),
			changes: opt(refs$1("assertion")),
			evidenceSceneIds: opt(refs$1("scene")),
			validity: opt(nullableValidity)
		}),
		flow_node: obj({
			nodeType: req(en("scene", "choice", "automatic", "call", "entry", "exit", "terminal")),
			sceneId: opt(ref$1("scene")),
			childGraphId: opt(ref$1("flow_graph")),
			terminalReason: opt(txt()),
			trigger: opt(trigger),
			gate: opt(cond),
			executionPolicy: opt(en("manual_choice", "first_match", "all_match")),
			fallbackId: opt(ref$1("flow_node")),
			reuse: opt(reuse)
		}),
		flow_edge: obj({
			fromId: req(ref$1("flow_node")),
			toId: req(union(ref$1("flow_node"), unresolved)),
			edgeType: req(en("choice", "automatic", "call_return")),
			label: opt(txt()),
			condition: opt(cond),
			effectIds: opt(refs$1("effect")),
			priority: opt(num(void 0, void 0, true)),
			choiceLineId: opt(ref$1("dialogue_line"))
		}),
		flow_graph: obj({
			nodeIds: req(refs$1("flow_node")),
			edgeIds: req(refs$1("flow_edge")),
			entryIds: req(refs$1("flow_node")),
			exitIds: req(refs$1("flow_node")),
			parentGraphId: opt(ref$1("flow_graph")),
			parameters: opt(arr(obj({
				key: req(key),
				type: req(en("boolean", "integer", "enum")),
				default: opt(typed$1)
			})))
		}),
		dialogue_line: obj({
			text: req(rich$1),
			speakerId: opt(ref$1("character")),
			choiceEdgeId: opt(ref$1("flow_edge")),
			cueIds: opt(refs$1("cue")),
			originLineIds: opt(refs$1("dialogue_line")),
			replacedByLineIds: opt(refs$1("dialogue_line")),
			lineage: opt(obj({
				mode: req(en("split", "merge", "copy")),
				baseRevision: req({ type: "revision" }),
				reason: req(txt(1)),
				segments: req(arr(obj({
					source: req(anchor),
					target: req(anchor)
				}), false, 1))
			})),
			claimAssertionIds: opt(refs$1("assertion")),
			assertionIntent: opt(en("statement", "lie", "misunderstanding", "quotation")),
			assertionReason: opt(txt())
		}),
		quest: obj({
			key: req(key),
			stateVariableId: req(ref$1("variable")),
			description: opt(rich$1),
			flowIds: opt(refs$1("flow_graph")),
			transitionRules: opt(arr(transition)),
			gameplaySpecIds: opt(refs$1("gameplay_spec"))
		}),
		lore: obj({
			body: req(rich$1),
			assertionIds: opt(refs$1("assertion")),
			sourceIds: opt(refs$1("source")),
			reading: opt(short),
			aliases: opt(arr(alias))
		}),
		variable: obj({
			key: req(key),
			valueType: req(en("boolean", "integer", "enum")),
			scope: req(en(...SCOPES)),
			initial: req(typed$1),
			allowed: req(allowed),
			description: opt(rich$1),
			ownerId: opt(ref$1("character")),
			derived: opt({ type: "expression" }),
			externalContractId: opt(ref$1("external_contract")),
			resetRules: opt(arr(resetRule)),
			transitionRules: opt(arr(transition)),
			exclusions: opt(arr(obj({
				variableId: req(ref$1("variable")),
				value: req(typed$1),
				otherValue: req(typed$1),
				reason: req(txt(1)),
				exceptions: opt(arr(exception))
			}))),
			externalUseDeclared: opt(bool)
		}),
		effect: obj({
			operation: req(en("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset")),
			targetId: req(ref$1()),
			value: opt(typed$1),
			condition: opt(cond),
			instanceId: opt(ref$1("item")),
			reason: opt(txt()),
			exceptionDetails: opt(exception)
		}),
		assertion: obj({
			subjectId: req(ref$1()),
			predicate: req(txt(1, 128)),
			value: req(union(typed$1, ref$1())),
			truthKind: req(en("author_truth", "testimony", "belief", "hypothesis")),
			holderId: opt(ref$1("character")),
			sourceIds: opt(refs$1("source", "assertion", "event", "scene", "dialogue_line")),
			evidenceLocation: opt(anchor),
			validity: opt(nullableValidity),
			reason: opt(txt())
		}),
		foreshadow: obj({
			question: req(rich$1),
			intent: req(rich$1),
			resolutionPolicy: req(en("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
			truthAssertionIds: opt(refs$1("assertion")),
			clueIds: opt(refs$1("disclosure")),
			payoffIds: opt(refs$1("disclosure")),
			requiredInfo: opt(refs$1("disclosure", "assertion")),
			alternativeInfo: opt(record$1(refs$1("disclosure", "assertion"), ref$1("disclosure", "assertion"))),
			deadline: opt(targetScope),
			presentationDeadline: opt(anchor),
			exceptions: opt(arr(exception))
		}),
		disclosure: obj({
			foreshadowId: req(ref$1("foreshadow")),
			anchor: req(anchor),
			stage: req(en("hint", "suspicion", "reinforce", "reveal", "alternative")),
			role: req(en("clue", "payoff")),
			condition: opt(cond),
			knowledgeEffects: opt(refs$1("effect")),
			targetScope: opt(targetScope)
		}),
		checkpoint: obj({
			worldTick: opt(tick),
			contentVersionId: req(scopedRef("snapshot")),
			runtimeState: req(runtime),
			presentationState: opt(runtime),
			presentationResults: opt(arr(presentationResult)),
			contentRevision: opt({ type: "revision" }),
			origin: opt(en("full_play", "partial", "imported")),
			traceId: opt(ref$1("trace")),
			migration: opt(obj({
				sourceCheckpointId: req(ref$1("checkpoint")),
				sourceVersionId: req(scopedRef("snapshot")),
				baseRevision: req({ type: "revision" }),
				method: req(en("migrate", "recreate"))
			}))
		}),
		trace: obj({
			contentVersionId: req(scopedRef("snapshot")),
			startCheckpointId: req(ref$1("checkpoint")),
			steps: req(arr(obj({
				nodeId: req(ref$1("flow_node")),
				edgeIds: req(refs$1("flow_edge")),
				before: req(runtime),
				after: req(runtime),
				presentationState: opt(runtime),
				conditionResults: opt(arr(presentationResult)),
				operation: opt(en("advance", "stub")),
				occurrenceId: opt(txt()),
				worldTick: opt(tick),
				externalMode: opt(en("stub", "actual", "mixed")),
				externalValues: opt(record$1(typed$1, ref$1("external_contract")))
			}))),
			contentRevision: opt({ type: "revision" }),
			initialExternalValues: opt(record$1(typed$1, ref$1("external_contract"))),
			initialStubBaseState: opt(runtime),
			initialStubValues: opt(obj({
				variables: opt(record$1(typed$1, ref$1("variable"))),
				external: opt(record$1(typed$1, ref$1("external_contract")))
			})),
			initialWorldTick: opt(tick),
			seed: opt(txt()),
			engineVersion: opt(txt()),
			externalMode: opt(en("stub", "actual", "mixed")),
			coverage: opt(coverage),
			regressionDeclarations: opt(obj({
				projectRevision: req({ type: "revision" }),
				traceIds: req(refs$1("trace"))
			})),
			reconfirmation: opt(obj({
				sourceTraceId: req(ref$1("trace")),
				sourceVersionId: req(scopedRef("snapshot")),
				baseRevision: req({ type: "revision" }),
				startCheckpointId: opt(ref$1("checkpoint"))
			})),
			mode: opt(en("flow", "chapters", null)),
			readingPath: opt(union(readingPath, en(null)))
		}),
		attachment: obj({
			mediaType: req(txt(1, 128)),
			contentHash: req({ type: "hash" }),
			byteSize: req(num(0, 33554432, true)),
			assetPath: req({ type: "safe_path" }),
			displayName: opt(txt()),
			provenanceId: opt(ref$1("source")),
			licenseNote: opt(txt()),
			stage: opt(en("reference", "temporary", "final")),
			revisionHistory: opt(refs$1("attachment"))
		}),
		source: obj({
			sourceType: req(en("web", "file", "book", "observation")),
			locator: req(txt(1)),
			accessedAt: opt({ type: "datetime" }),
			excerptLocation: opt(txt()),
			interpretation: opt(rich$1),
			attachmentId: opt(ref$1("attachment")),
			redistributionAllowed: opt(bool)
		}),
		cue: obj({
			anchor: req(anchor),
			cueType: req(txt(1, 128)),
			attachmentId: opt(ref$1("attachment")),
			speakerId: opt(ref$1("character")),
			expression: opt(txt()),
			waitMs: opt(num(0, void 0, true)),
			camera: opt({ type: "custom" }),
			mediaTime: opt(num(0, void 0, true)),
			stage: opt(short)
		}),
		storyboard_frame: obj({
			anchor: req(anchor),
			mediaStartMs: req(num(0, void 0, true)),
			mediaEndMs: opt(num(0, void 0, true)),
			referenceAssetId: opt(ref$1("attachment")),
			finalAssetId: opt(ref$1("attachment")),
			cueIds: opt(refs$1("cue")),
			caption: opt(rich$1)
		}),
		localization: obj({
			sourceLineId: req(ref$1("dialogue_line")),
			language: req(txt(1, 128)),
			sourceHash: req({ type: "hash" }),
			text: req(rich$1),
			stage: opt(en("draft", "reviewed", "needs_review")),
			reviewedBy: opt(scopedRef("identity")),
			recordingIds: opt(refs$1("recording"))
		}),
		recording: obj({
			sourceLineId: req(ref$1("dialogue_line")),
			language: req(txt(1, 128)),
			sourceHash: req({ type: "hash" }),
			translationId: opt(ref$1("localization")),
			attachmentId: opt(ref$1("attachment")),
			notes: opt(rich$1),
			stage: opt(en("planned", "recorded", "reviewed", "needs_review")),
			reviewedBy: opt(scopedRef("identity"))
		}),
		terminology: obj({
			canonical: req(txt(1, 128)),
			reading: req(short),
			variants: opt(arr(short, true)),
			language: opt(short),
			usageNotes: opt(rich$1),
			validity: opt(nullableValidity),
			exceptions: opt(arr(exception)),
			voiceOwnerId: opt(ref$1("character"))
		}),
		map: obj({
			placeId: req(ref$1("place")),
			coordinateSystem: req(en("normalized")),
			attachmentId: opt(ref$1("attachment")),
			parentMapId: opt(ref$1("map")),
			pins: opt(arr(obj({
				id: req(idSchema),
				placeId: req(ref$1("place")),
				x: req(num(0, 1)),
				y: req(num(0, 1)),
				label: opt(txt())
			})))
		}),
		travel_route: obj({
			fromPlaceId: req(ref$1("place")),
			toPlaceId: req(ref$1("place")),
			direction: req(en("one_way", "two_way")),
			method: opt(txt()),
			minimumTicks: opt(tick),
			maximumTicks: opt(tick),
			evidence: opt(refs$1()),
			validity: opt(nullableValidity)
		}),
		template: obj({
			targetKind: req(en(...ENTITY_KINDS)),
			fields: req(arr(fieldDefinition)),
			description: opt(txt()),
			version: opt({ type: "revision" }),
			defaults: opt(record$1({ type: "custom" }, key))
		}),
		collection: obj({
			purpose: opt(en("regression")),
			mode: req(en("dynamic", "fixed")),
			query: opt({ type: "query" }),
			memberIds: opt(refs$1()),
			sort: opt(obj({
				field: req(en("name", "createdAt", "updatedAt", "kind")),
				direction: req(en("asc", "desc"))
			}))
		}),
		review: obj({
			target: req(union(anchor, ref$1())),
			targetVersionId: req(scopedRef("snapshot")),
			body: req(rich$1),
			stage: req(en("open", "fixed", "verified")),
			assigneeId: opt(scopedRef("identity")),
			quotedText: opt(txt()),
			resolution: opt(rich$1),
			sharedSource: opt(obj({
				connection: req(txt(1)),
				sharedSnapshot: req(txt(1)),
				comment: req(txt(1)),
				publicVersion: req(txt(1)),
				publicEntity: opt(txt(1)),
				publicRelation: opt(txt(1)),
				publicBlock: opt(txt(1)),
				startCp: opt(num(0, void 0, true)),
				endCp: opt(num(0, void 0, true)),
				projectionHash: req(txt(64, 64)),
				commentBodyHash: req(txt(64, 64)),
				quotedText: req(txt()),
				observedStage: req(en("open", "fixed", "verified"))
			}))
		}),
		creative_brief: obj({
			targetAudience: req(rich$1),
			experience: req(rich$1),
			theme: req(rich$1),
			tone: req(rich$1),
			scope: req(rich$1),
			deliverableIds: opt(refs$1()),
			decisionIds: opt(refs$1("decision"))
		}),
		decision: obj({
			subject: req(txt(1)),
			reason: req(rich$1),
			targetVersionId: req(scopedRef("snapshot")),
			outcome: req(en("accepted", "rejected", "deferred")),
			priority: opt(short),
			requirementIds: opt(arr(short, true)),
			reviewIds: opt(refs$1("review"))
		}),
		gameplay_spec: obj({
			sceneId: req(ref$1("scene")),
			action: req(rich$1),
			mechanic: opt(txt()),
			tutorial: opt(rich$1),
			reward: opt(typed$1),
			questId: opt(ref$1("quest")),
			taskIds: opt(refs$1("production_task")),
			intentionalDifference: opt(txt())
		}),
		production_task: obj({
			targetIds: req(refs$1()),
			stage: req(en("writing", "review", "implementation", "translation", "recording", "verification", "publication")),
			progress: req(en("todo", "doing", "done", "needs_review")),
			assigneeId: opt(scopedRef("identity")),
			deadline: opt(obj({
				date: req({ type: "date" }),
				timeZone: req(txt(1, 128))
			})),
			dependsOn: opt(refs$1("production_task")),
			estimate: opt(estimate),
			blockingReason: opt(txt())
		}),
		media_variant: obj({
			previousVariantId: opt(ref$1("media_variant")),
			confirmationRecipientIds: opt(arr(scopedRef("identity"), true)),
			medium: req(en("game", "novel", "video", "audio", "promotion", "custom")),
			baseSnapshotId: req(scopedRef("snapshot")),
			body: opt(rich$1),
			releaseAt: opt({ type: "datetime" }),
			projectionProfileId: opt(ref$1("projection_profile")),
			sourceIds: opt(refs$1()),
			needsReview: opt(bool)
		}),
		voice_rule: obj({
			characterId: req(ref$1("character")),
			validity: req(nullableValidity),
			firstPerson: opt(short),
			addressing: opt(txt()),
			phrasing: opt(txt()),
			examples: opt(rich$1),
			exceptions: opt(arr(exception))
		}),
		external_contract: obj({
			key: req(key),
			owner: req(en("tool", "game")),
			inputType: req(txt(1, 128)),
			outputType: req(txt(1, 128)),
			missingPolicy: req(en("unknown", "block")),
			description: opt(rich$1),
			stubValues: opt(arr(typed$1)),
			adapterProfileIds: opt(refs$1("projection_profile")),
			version: opt(short)
		}),
		snapshot: obj({
			versionLabel: req(txt(1, 128)),
			contentHash: req({ type: "hash" }),
			immutable: req(en(true)),
			parentVersionIds: opt(arr(scopedRef("snapshot"), true)),
			releasedAt: opt({ type: "datetime" }),
			referencedWorldVersionIds: opt(arr(scopedRef("snapshot"), true))
		}),
		projection_profile: obj({
			blockSources: opt(record$1(scopedRef("block"), scopedRef("projection_record"))),
			citedVersions: opt(arr(obj({
				sourceVersionId: req(scopedRef("snapshot")),
				profileId: req(ref$1("projection_profile")),
				publicVersionId: req(idSchema)
			}))),
			audience: req(txt(1, 128)),
			includedIds: req(refs$1()),
			namePolicy: req({ type: "name_policy" }),
			allowedKinds: opt(arr(en(...ENTITY_KINDS), true)),
			excludedFields: opt(arr(txt(1), true)),
			routeScope: opt(targetScope),
			includeAuthorNotes: opt(bool),
			publicTitle: opt(txt()),
			publicTexts: opt(record$1(publicText, scopedRef("record"))),
			allowedFields: opt(record$1(arr(txt(1), true), en(...ENTITY_KINDS))),
			allowedRelationIds: opt(arr(scopedRef("relation"), true)),
			idPolicy: opt(en("remap", "preserve")),
			publicIds: opt(record$1(idSchema, scopedRef("projection_record"))),
			sourceVersionId: opt(scopedRef("snapshot")),
			publicValues: opt(record$1(record$1(txt(), txt()), ref$1("variable", "external_contract", "assertion"))),
			includedStatuses: opt(arr(en(...STATUSES), true)),
			publicVersionLabel: opt(txt()),
			approvedAttachmentIds: opt(refs$1("attachment"))
		})
	};
	isObject = (value) => !!value && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
	utf8Encoder = new TextEncoder();
	utf8Bytes = (value) => utf8Encoder.encode(value).byteLength;
	textSpan = {
		start: req(num(0, void 0, true)),
		end: req(num(0, void 0, true))
	};
	richTextBlocks = arr(obj({
		id: req(idSchema),
		kind: req(en("paragraph", "heading", "list_item", "quote")),
		text: req(txt()),
		ruby: opt(arr(obj({
			...textSpan,
			text: req(txt())
		}))),
		links: opt(arr(obj({
			...textSpan,
			target: req(anchor)
		}))),
		unresolvedAnnotations: opt(arr(unresolvedTextAnnotation))
	}));
	commonFields = {
		id: req(idSchema),
		projectId: req(scopedRef("project")),
		kind: req(en(...ENTITY_KINDS)),
		revision: req({ type: "revision" }),
		name: req(short),
		status: req(en(...STATUSES)),
		visibility: req(en("private", "team", "projection")),
		retainIfUnreferenced: opt(bool),
		projectionProfileId: opt(ref$1("projection_profile")),
		templateId: opt(ref$1("template")),
		createdAt: req({ type: "datetime" }),
		updatedAt: req({ type: "datetime" }),
		deletedAt: opt({ type: "datetime" }),
		deletionOperationId: opt(idSchema),
		customValues: req(record$1({ type: "custom" }, key))
	};
	relationSchema = obj({
		id: req(idSchema),
		projectId: req(scopedRef("project")),
		revision: req({ type: "revision" }),
		fromId: req(ref$1()),
		toId: req(ref$1()),
		relationType: req(txt(1, 128)),
		direction: req(en("forward", "symmetric")),
		validity: req(nullableValidity),
		evidenceIds: req(refs$1()),
		status: req(en(...STATUSES)),
		visibility: req(en("private", "team", "projection")),
		projectionProfileId: opt(ref$1("projection_profile")),
		deletedAt: opt({ type: "datetime" }),
		deletionOperationId: opt(idSchema)
	});
	entityRecordSchemas = /* @__PURE__ */ new Map();
	worldReferenceSchema = obj({
		projectId: req(idSchema),
		immutableSnapshotId: req(idSchema),
		contentHash: req({ type: "hash" })
	});
	viewSchema = obj({
		id: req(idSchema),
		name: req(txt(1, 128)),
		view: req(txt(1)),
		entityIds: req(refs$1()),
		settings: req(record$1(union(txt(), num(), bool, en(null)), key))
	});
	projectHeaderFields = {
		projectId: req(idSchema),
		name: req(txt(1, 128)),
		formatVersion: req(en(FORMAT_VERSION)),
		revision: req({ type: "revision" }),
		calendarId: req(txt(1)),
		mainStart: req(tick),
		worldReferences: req(arr(worldReferenceSchema))
	};
	projectContentKeys = [
		...Object.keys(projectHeaderFields),
		"calendars",
		"entities",
		"relations",
		"views"
	];
	projectKeys = [...projectContentKeys, "authorAlternatives"];
	alternativesSchema = arr({ type: "json" }, false, 0, 100);
}));

//#endregion
//#region src/domain/writingWorkspace.ts
var init_writingWorkspace = __esmMin((() => {
	init_model();
}));

//#endregion
//#region src/domain/externalInputs.ts
/** Values retain their declared types. Missing or invalid external input is never coerced to false. */
function validateExternalInput(project, values, options, referenceEntities = []) {
	const issues = [];
	const entities = [...project.entities, ...referenceEntities].filter(adoptedRecord);
	if (options && (options.mode !== "actual" || !/^[0-9a-f]{64}$/.test(options.receiptHash))) issues.push({
		code: "INTEGRITY_FAILED",
		path: "receiptHash",
		message: "実際の外部入力には検証済み受信記録のSHA-256が必要です。"
	});
	for (const [id, value] of Object.entries(values)) {
		const path = `externalValues.${id}`, contract = entities.find((entity) => entity.id === id && entity.kind === "external_contract");
		if (!contract) {
			issues.push({
				code: "REFERENCE_INVALID",
				path,
				message: "入力先の外部契約が存在しないか、削除・不採用です。"
			});
			continue;
		}
		const valid = validateTypedValue(value);
		if (!valid.ok) {
			issues.push(...valid.issues.map((issue) => ({
				...issue,
				path
			})));
			continue;
		}
		if (value.type !== "unknown" && value.type !== contract.data.outputType) {
			issues.push({
				code: "VALIDATION_FAILED",
				path,
				message: "実際の外部値と契約の出力型が違います。"
			});
			continue;
		}
		if (value.type === "unknown" && contract.data.missingPolicy === "block") issues.push({
			code: "CONDITION_UNKNOWN",
			path,
			message: value.reason || "この外部契約は未確認値で進められません。"
		});
		for (const variable of entities) if (variable.kind === "variable" && variable.data.externalContractId === id) issues.push(...validateVariableValue(variable, value, path, true));
	}
	return issues;
}
var init_externalInputs = __esmMin((() => {
	init_model();
	init_adoption();
}));

//#endregion
//#region src/domain/regressionPaths.ts
function declaredRegressionPaths(project) {
	const ids = [...new Set(project.entities.filter((entity) => entity.kind === "collection" && adoptedRecord(entity) && entity.data.purpose === "regression").flatMap((collection) => collection.data.memberIds ?? []))];
	const paths = ids.map((id) => project.entities.find((entity) => entity.id === id && entity.kind === "trace" && adoptedRecord(entity))).filter((entity) => !!entity);
	return {
		ids,
		paths,
		missing: ids.filter((id) => !paths.some((path) => path.id === id))
	};
}
function regressionPathCoverage(project, candidate, start, executionStatus) {
	const declarations = declaredRegressionPaths(project);
	const equal = (left, right) => left === void 0 || right === void 0 ? left === right : canonicalJson$1(left) === canonicalJson$1(right);
	const observedUnknown = candidate.steps.some((step) => step.conditionResults?.some((result) => result.value === "unknown")) || candidate.readingPath?.occurrences.some((occurrence) => occurrence.conditionResults.some((result) => result.value === "unknown"));
	const lastPosition = candidate.steps.at(-1)?.after.presentationPosition ?? start.presentationPosition;
	const content = project.snapshots.find((snapshot) => snapshot.id === candidate.contentVersionId)?.content ?? project;
	const complete = executionStatus ? executionStatus === "terminal" : candidate.mode === "chapters" ? !!candidate.readingPath?.sceneIds.length && candidate.readingPath.occurrences.length === candidate.readingPath.sceneIds.length : content.entities.some((entity) => entity.id === lastPosition && entity.kind === "flow_node" && adoptedRecord(entity) && entity.data.nodeType === "terminal");
	const matchingPaths = declarations.paths.filter((path) => {
		if (path.data.contentVersionId !== candidate.contentVersionId || (path.data.mode ?? "flow") !== (candidate.mode ?? "flow")) return false;
		if ((path.data.externalMode ?? "internal") !== (candidate.externalMode ?? "internal") || ["actual", "mixed"].includes(candidate.externalMode ?? "internal")) return false;
		const checkpoint = project.entities.find((entity) => entity.id === path.data.startCheckpointId && entity.kind === "checkpoint");
		if (!checkpoint || !equal(checkpoint.data.runtimeState, start)) return false;
		if (checkpoint.data.presentationResults?.some((result) => result.value === "unknown")) return false;
		if (candidate.mode === "chapters") return equal(path.data.readingPath && {
			...path.data.readingPath,
			selection: path.data.readingPath.selection ?? "scenes"
		}, candidate.readingPath && {
			...candidate.readingPath,
			selection: candidate.readingPath.selection ?? "scenes",
			occurrences: candidate.readingPath.occurrences.map((occurrence, index) => {
				const expected = path.data.readingPath?.occurrences[index];
				const normalized = { ...occurrence };
				if (expected && expected.presentationState === void 0) delete normalized.presentationState;
				return normalized;
			})
		});
		return equal(path.data.steps, candidate.steps.map((step, index) => {
			const expected = path.data.steps[index];
			if (!expected) return step;
			const normalized = { ...step };
			for (const field of [
				"presentationState",
				"conditionResults",
				"operation",
				"externalValues"
			]) if (expected[field] === void 0) delete normalized[field];
			return normalized;
		}));
	});
	const matched = complete && !observedUnknown ? matchingPaths : [];
	const provenance = (path) => {
		return project.entities.find((entity) => entity.kind === "checkpoint" && entity.id === path.data.startCheckpointId)?.data.runtimeState.provenance ?? "partial";
	};
	const mode = (path) => path.data.externalMode ?? "internal";
	const byProvenance = Object.fromEntries([
		"full_play",
		"partial",
		"imported",
		"stub"
	].map((origin) => [origin, {
		checked: matched.filter((path) => provenance(path) === origin).length,
		total: declarations.paths.filter((path) => provenance(path) === origin).length
	}]));
	const byExternalMode = Object.fromEntries([
		"internal",
		"stub",
		"actual",
		"mixed"
	].map((external) => [external, {
		checked: external === "actual" || external === "mixed" ? 0 : matched.filter((path) => mode(path) === external).length,
		total: declarations.paths.filter((path) => mode(path) === external).length
	}]));
	const unknown = declarations.missing.length + declarations.paths.filter((path) => path.data.contentVersionId !== candidate.contentVersionId || ["actual", "mixed"].includes(mode(path)) || project.entities.some((entity) => entity.id === path.data.startCheckpointId && entity.kind === "checkpoint" && entity.data.presentationResults?.some((result) => result.value === "unknown")) || (!complete || observedUnknown) && matchingPaths.includes(path)).length;
	return {
		checked: matched.filter((path) => provenance(path) === "full_play" && mode(path) === "internal" && start.provenance === "full_play").length,
		total: declarations.ids.length,
		unknown,
		byProvenance,
		byExternalMode
	};
}
var init_regressionPaths = __esmMin((() => {
	init_adoption();
	init_json();
}));

//#endregion
//#region src/domain/maintenance.ts
var init_maintenance = __esmMin((() => {
	init_model();
}));

//#endregion
//#region src/domain/world.ts
var init_world = __esmMin((() => {
	init_model();
	init_maintenance();
	init_conditions();
	init_json();
}));

//#endregion
//#region src/domain/narrative.ts
/** The same pre-effect presentation evidence is used by chapters, branching paths and finite analysis. */
function checkPresentationForeshadows(project, states, startState, terminal, referenceEntities = [], issues = []) {
	const findings = [];
	const disclosures = activeKind$1(project, "disclosure");
	const seen = /* @__PURE__ */ new Set();
	const uncertain = /* @__PURE__ */ new Set();
	const found = /* @__PURE__ */ new Set();
	const path = [];
	const edgePath = [];
	for (const disclosure of disclosures) if (disclosure.data.anchor.positionStatus === "unresolved" && issues.some((failure) => failure.code === "CONDITION_UNKNOWN" && failure.path === `${disclosure.id}.anchor`)) {
		uncertain.add(disclosure.id);
		findings.push({
			status: "unknown",
			code: "CONDITION_UNKNOWN",
			message: "提示位置が不明です。本文へ再リンクしてから伏線を確認してください。",
			targetId: disclosure.id,
			path: states.at(-1)?.state.presentationPosition ? [states.at(-1).state.presentationPosition] : [],
			startState: clone$2(startState)
		});
	}
	for (const { state, observationState, conditions, edgeIds, worldTick, externalValues, target } of states) {
		const anchorIsPresented = (project, state, anchor, declarationId) => presentationAnchorApplies(project, state, anchor, target, declarationId);
		const anchorPrecedes = (project, _state, left, right) => presentationAnchorOrder(project, left, right, target);
		const position = target.nodeId ?? target.sceneId;
		if (!position || !state.seenIds.includes(position)) continue;
		path.push(position);
		if (edgeIds) edgePath.push([...edgeIds]);
		const recorded = new Map((conditions ?? []).map((condition) => [condition.targetId, condition]));
		for (const disclosure of disclosures) if (disclosure.data.anchor.positionStatus === "unresolved" && recorded.has(disclosure.id)) {
			uncertain.add(disclosure.id);
			findings.push({
				status: "unknown",
				code: "CONDITION_UNKNOWN",
				message: "提示位置が不明です。本文へ再リンクしてから伏線を確認してください。",
				targetId: disclosure.id,
				path: [...path],
				startState: clone$2(startState)
			});
		}
		const presentationCondition = (id) => recorded.get(id) ?? {
			targetId: id,
			value: state.seenIds.includes(id) ? "true" : "false",
			reasons: []
		};
		for (const id of state.seenIds) {
			const disclosure = disclosures.find((disclosure) => disclosure.id === id);
			if (disclosure?.data.anchor.positionStatus === "unresolved") {
				uncertain.add(id);
				continue;
			}
			if (!disclosure || !anchorIsPresented(project, state, reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id), disclosure.id)) seen.add(id);
		}
		const currentClues = disclosures.filter((disclosure) => disclosure.data.role === "clue" && anchorIsPresented(project, state, reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id), disclosure.id)).map((disclosure) => ({
			disclosure,
			condition: presentationCondition(disclosure.id)
		}));
		for (const payoff of disclosures.filter((disclosure) => disclosure.data.role === "payoff")) {
			if (!anchorIsPresented(project, state, reuseExecutionAnchor(project, payoff.data.anchor, payoff.id), payoff.id) || !state.seenIds.includes(payoff.id) || found.has(payoff.id)) continue;
			const observedCondition = presentationCondition(payoff.id);
			const condition = observedCondition.value === "false" ? {
				...observedCondition,
				value: "true"
			} : observedCondition;
			if (condition.value === "false") continue;
			const foreshadow = getEntity$1(project, payoff.data.foreshadowId);
			if (!foreshadow || foreshadow.kind !== "foreshadow" || !adoptedRecord(foreshadow)) continue;
			let uncertainOrder = false;
			const presentedBefore = (id) => {
				if (seen.has(id)) return true;
				const clue = currentClues.find((clue) => clue.disclosure.id === id);
				if (!clue || clue.condition.value === "false") return false;
				const before = anchorPrecedes(project, state, reuseExecutionAnchor(project, clue.disclosure.data.anchor, clue.disclosure.id), reuseExecutionAnchor(project, payoff.data.anchor, payoff.id));
				if (before === void 0 || before === true && clue.condition.value === "unknown") uncertainOrder = true;
				return before === true && clue.condition.value === "true";
			};
			const missing = (foreshadow.data.requiredInfo ?? []).filter((id) => ![id, ...foreshadow.data.alternativeInfo?.[id] ?? []].some(presentedBefore));
			const ruleContext = presentationRuleContext(project, {
				...target,
				worldTick
			});
			const contexts = reuseRuleContexts(project, ruleContext);
			const context = {
				state: observationState ?? state,
				variables: [...variables$1(project), ...referenceEntities.filter((entity) => entity.kind === "variable")],
				entities: runtimeEntities$1(project),
				referenceEntities,
				externalValues,
				ruleContext: contexts[foreshadow.id] ?? ruleContext,
				ruleContexts: contexts
			};
			const scope = foreshadow.data.deadline ? !observationState && foreshadow.data.deadline.routeCondition ? { value: "unknown" } : evaluateTargetScope(foreshadow.data.deadline, context) : { value: "true" };
			if (scope.value === "false") continue;
			found.add(payoff.id);
			const exceptions = (foreshadow.data.exceptions ?? []).map((exception) => !observationState && (exception.targetScope.routeCondition || exception.validity.routeCondition) ? { value: "unknown" } : evaluateScenarioException(exception, context));
			if (exceptions.some((exception) => exception.value === "true")) continue;
			if (missing.length === 0 && condition.value === "true") continue;
			const policy = foreshadow.data.resolutionPolicy;
			const intentional = policy === "sequel" || policy === "intentional_open" || policy === "red_herring" || policy === "rejected";
			const unknown = scope.value === "unknown" || exceptions.some((exception) => exception.value === "unknown") || condition.value === "unknown" || uncertainOrder || missing.some((id) => uncertain.has(id)) || state.provenance !== "full_play";
			findings.push({
				status: intentional ? "intentional" : unknown ? "unknown" : "candidate",
				code: condition.value === "unknown" ? "CONDITION_UNKNOWN" : "REQUIRED_INFO_MISSING",
				message: intentional ? `回収方針「${policy}」として区別した未提示情報があります。` : unknown ? "回収前の必須情報について未確認の値または途中開始・仮値があり、確認が必要です。" : "回収へ至るこの経路で、作者が必須にした情報の提示が不足しています。",
				targetId: foreshadow.id,
				payoffId: payoff.id,
				missingInfoIds: missing,
				path: [...path],
				edgePath: edgePath.map((ids) => [...ids]),
				startState: clone$2(startState)
			});
		}
		for (const { disclosure, condition } of currentClues) {
			if (condition.value === "true") seen.add(disclosure.id);
			if (condition.value === "unknown") uncertain.add(disclosure.id);
		}
	}
	return [...findings, ...unresolvedForeshadows(project, states, startState, terminal, referenceEntities)];
}
function occurrenceContext(project, occurrence, referenceEntities, declarationId) {
	const ruleContext = presentationRuleContext(project, {
		...occurrence.target,
		worldTick: occurrence.worldTick
	});
	const ruleContexts = reuseRuleContexts(project, ruleContext);
	return {
		state: occurrence.observationState ?? occurrence.state,
		variables: [...variables$1(project), ...referenceEntities.filter((entity) => entity.kind === "variable")],
		entities: runtimeEntities$1(project),
		referenceEntities,
		externalValues: occurrence.externalValues,
		ruleContext: declarationId ? ruleContexts[declarationId] ?? ruleContext : ruleContext,
		ruleContexts
	};
}
function unresolvedForeshadows(project, supplied, startState, terminal, referenceEntities) {
	const states = supplied.filter((occurrence) => {
		const id = occurrence.target.nodeId ?? occurrence.target.sceneId;
		return !!id && occurrence.state.seenIds.includes(id);
	});
	const findings = [], disclosures = activeKind$1(project, "disclosure");
	for (const foreshadow of activeKind$1(project, "foreshadow")) {
		const reported = /* @__PURE__ */ new Set();
		for (let index = 0; index < states.length; index++) {
			const occurrence = states[index], context = occurrenceContext(project, occurrence, referenceEntities, foreshadow.id), scope = foreshadow.data.deadline;
			const applies = scope ? evaluateTargetScope(scope, context) : {
				value: "true",
				reasons: []
			};
			if (applies.value === "false") continue;
			const next = states[index + 1], nextRule = next ? presentationRuleContext(project, next.target) : void 0;
			const explicit = foreshadow.data.presentationDeadline ? reuseExecutionAnchor(project, foreshadow.data.presentationDeadline, foreshadow.id) : void 0;
			const reached = !!explicit && presentationAnchorApplies(project, occurrence.state, explicit, occurrence.target, foreshadow.id);
			const chapterEnd = !!scope?.chapterId && context.ruleContext.chapterId === scope.chapterId && (nextRule ? nextRule.chapterId !== scope.chapterId : terminal && index === states.length - 1);
			const exit = occurrence.target.nodeId ? activeKind$1(project, "flow_node").find((node) => node.id === occurrence.target.nodeId)?.data.nodeType === "exit" : false;
			const graphEnd = !!scope?.graphId && context.ruleContext.graphId === scope.graphId && exit;
			const ending = terminal && index === states.length - 1;
			if (!reached && !chapterEnd && !graphEnd && !ending) continue;
			const boundary = reached ? "presentation" : chapterEnd ? `chapter:${scope.chapterId}` : graphEnd ? `graph:${scope.graphId}` : "terminal";
			if (reported.has(boundary)) continue;
			reported.add(boundary);
			let orderUnknown = !!explicit && (explicit.positionStatus === "unresolved" || !!explicit.sourceVersionId && ![
				project.projectId,
				occurrence.state.contentVersionId,
				context.ruleContext.sourceVersionId
			].includes(explicit.sourceVersionId));
			if (states.slice(0, index + 1).some((prior, offset) => disclosures.some((payoff) => {
				if (payoff.data.foreshadowId !== foreshadow.id || payoff.data.role !== "payoff" || !prior.state.seenIds.includes(payoff.id)) return false;
				const result = prior.conditions.find((result) => result.targetId === payoff.id);
				if (result?.value !== "true") {
					if (!result) orderUnknown = true;
					return false;
				}
				const anchor = reuseExecutionAnchor(project, payoff.data.anchor, payoff.id);
				if (!presentationAnchorApplies(project, prior.state, anchor, prior.target, payoff.id)) return false;
				if (reached && offset === index && explicit) {
					const before = presentationAnchorOrder(project, anchor, explicit, prior.target);
					if (before === void 0) orderUnknown = true;
					return before === true;
				}
				return true;
			})) && !orderUnknown) continue;
			const exceptions = (foreshadow.data.exceptions ?? []).map((exception) => evaluateScenarioException(exception, context));
			if (exceptions.some((exception) => exception.value === "true")) continue;
			const policy = foreshadow.data.resolutionPolicy, intentional = [
				"sequel",
				"intentional_open",
				"red_herring",
				"rejected"
			].includes(policy);
			const unknown = applies.value === "unknown" || exceptions.some((exception) => exception.value === "unknown") || orderUnknown || policy === "undecided" || startState.provenance !== "full_play" || occurrence.state.provenance !== "full_play";
			const seen = new Set(occurrence.state.seenIds), missing = (foreshadow.data.requiredInfo ?? []).filter((id) => ![id, ...foreshadow.data.alternativeInfo?.[id] ?? []].some((candidate) => seen.has(candidate)));
			findings.push({
				status: intentional ? "intentional" : unknown ? "unknown" : "candidate",
				code: "REQUIRED_INFO_MISSING",
				targetId: foreshadow.id,
				missingInfoIds: missing,
				message: intentional ? `回収方針「${policy}」により、この範囲での未回収を区別しました。` : unknown ? "期限・対象範囲または途中開始の未回収が未確認です。" : reached ? "体験上の指定提示位置までに回収が提示されていません。" : "対象の章・経路の終わりまでに、今作で予定した回収が提示されていません。",
				path: states.slice(0, index + 1).map((item) => item.target.nodeId ?? item.target.sceneId),
				edgePath: states.slice(0, index + 1).flatMap((item) => item.edgeIds ? [[...item.edgeIds]] : []),
				startState: clone$2(startState)
			});
		}
	}
	return findings;
}
var activeKind$1, getEntity$1, variables$1, runtimeEntities$1, clone$2;
var init_narrative = __esmMin((() => {
	init_adoption();
	init_presentation();
	init_reuse();
	init_stateRules();
	init_world();
	init_conditions();
	init_json();
	activeKind$1 = (project, kind) => project.entities.filter((entity) => entity.kind === kind && adoptedRecord(entity));
	getEntity$1 = (project, id) => project.entities.find((entity) => entity.id === id);
	variables$1 = (project) => activeKind$1(project, "variable");
	runtimeEntities$1 = (project) => project.entities.filter(adoptedRecord);
	clone$2 = structuredClone;
}));

//#endregion
//#region src/domain/presentation.ts
function presentationRuleContext(project, target) {
	const node = active$1(project, "flow_node").find((item) => item.id === target.nodeId);
	const scene = active$1(project, "scene").find((item) => item.id === (target.sceneId ?? node?.data.sceneId));
	return {
		projectId: project.projectId,
		worldTick: target.worldTick,
		graphId: node ? active$1(project, "flow_graph").find((graph) => graph.data.nodeIds.includes(node.id))?.id : void 0,
		chapterId: scene?.data.chapterId ?? (scene ? active$1(project, "chapter").find((chapter) => chapter.data.sceneIds.includes(scene.id))?.id : void 0)
	};
}
/** Choice text is presented only by a manual choice, including disabled candidates shown to the author. */
function presentationLineIds(project, target) {
	const node = active$1(project, "flow_node").find((item) => item.id === target.nodeId);
	const scene = active$1(project, "scene").find((item) => item.id === (target.sceneId ?? node?.data.sceneId));
	const policy = node?.data.executionPolicy ?? (node?.data.nodeType === "automatic" ? "first_match" : "manual_choice");
	return [.../* @__PURE__ */ new Set([...scene?.data.dialogueLineIds ?? [], ...node && policy === "manual_choice" ? active$1(project, "flow_edge").filter((edge) => edge.data.fromId === node.id).flatMap((edge) => edge.data.choiceLineId ? [edge.data.choiceLineId] : []) : []])];
}
function presentationAnchorApplies(project, state, anchor, target, declarationId) {
	if (anchor.positionStatus === "unresolved") return false;
	const declaration = declarationId ? reuseOrigin(project, declarationId) : void 0;
	if (anchor.sourceVersionId && ![
		project.projectId,
		state.contentVersionId,
		reuseOrigin(project, anchor.entityId)?.sourceVersionId,
		declaration?.sourceVersionId
	].includes(anchor.sourceVersionId)) return false;
	const node = active$1(project, "flow_node").find((item) => item.id === target.nodeId);
	const sceneId = target.sceneId ?? node?.data.sceneId;
	active$1(project, "scene").find((item) => item.id === sceneId);
	const lines = presentationLineIds(project, target);
	if (![
		target.nodeId,
		sceneId,
		...lines
	].includes(anchor.entityId)) return false;
	return [
		anchor.entityId,
		anchor.blockId,
		anchor.lineId
	].filter((id) => !!id).every((id) => state.seenIds.includes(id));
}
/** Reading order is block/line order and code-point position, never event/world-date order. */
function presentationAnchorOrder(project, left, right, target) {
	if (left.positionStatus === "unresolved" || right.positionStatus === "unresolved") return void 0;
	const node = active$1(project, "flow_node").find((item) => item.id === target.nodeId);
	const scene = active$1(project, "scene").find((item) => item.id === (target.sceneId ?? node?.data.sceneId));
	const lineIds = presentationLineIds(project, target);
	const positions = [...(scene?.data.body ?? []).map((block) => block.id)];
	for (const lineId of lineIds) positions.push(lineId, ...(active$1(project, "dialogue_line").find((line) => line.id === lineId)?.data.text ?? []).map((block) => block.id));
	const leftBlock = left.blockId ?? left.lineId ?? (lineIds.includes(left.entityId) ? left.entityId : void 0);
	const rightBlock = right.blockId ?? right.lineId ?? (lineIds.includes(right.entityId) ? right.entityId : void 0);
	const first = positions.indexOf(leftBlock ?? ""), second = positions.indexOf(rightBlock ?? "");
	if (first >= 0 && second >= 0 && first !== second) return first < second;
	if (leftBlock !== rightBlock || left.entityId !== right.entityId || left.start == null || right.start == null || left.start === right.start) return void 0;
	if (left.start < right.start && left.end != null && left.end > right.start || right.start < left.start && right.end != null && right.end > left.start) return void 0;
	return left.start < right.start;
}
/** Shared atomic arrival for flow and chapter presentation. Conditions precede every disclosure effect. */
function presentContent(project, state, target) {
	const checked = validateRuntimeState(state);
	if (!checked.ok) return {
		ok: false,
		issues: checked.issues
	};
	const externalIssues = validateExternalInput(project, target.externalValues ?? {}, void 0, target.referenceEntities);
	if (externalIssues.length) return {
		ok: false,
		issues: externalIssues
	};
	try {
		const node = target.nodeId ? active$1(project, "flow_node").find((item) => item.id === target.nodeId) : void 0;
		if (target.nodeId && !node) return problem("presentation.nodeId", "提示する分岐が存在しないか、削除・不採用です。");
		const sceneId = target.sceneId ?? node?.data.sceneId ?? void 0;
		if (!node && !sceneId) return problem("presentation", "提示する場面または分岐を指定してください。");
		const scene = sceneId ? active$1(project, "scene").find((item) => item.id === sceneId) : void 0;
		if (sceneId && !scene) return problem("presentation.sceneId", "提示する場面が存在しないか、削除・不採用です。");
		const initialContext = presentationRuleContext(project, {
			...target,
			sceneId
		});
		const initialIssues = runtimeExclusionIssues({
			state,
			entities: project.entities,
			referenceEntities: target.referenceEntities,
			externalValues: target.externalValues,
			ruleContext: initialContext,
			ruleContexts: reuseRuleContexts(project, initialContext)
		});
		if (initialIssues.length) return {
			ok: false,
			issues: initialIssues
		};
		const resolved = {
			...target,
			sceneId
		}, next = structuredClone(state), seen = new Set(next.seenIds);
		if (node) {
			next.presentationPosition = node.id;
			next.visitCounts[node.id] = (next.visitCounts[node.id] ?? 0) + 1;
			seen.add(node.id);
		}
		if (scene) {
			seen.add(scene.id);
			next.visitCounts[scene.id] = (next.visitCounts[scene.id] ?? 0) + 1;
			for (const id of scene.data.blockIds ?? []) seen.add(id);
			for (const block of scene.data.body) seen.add(block.id);
		}
		for (const lineId of presentationLineIds(project, resolved)) {
			const line = active$1(project, "dialogue_line").find((item) => item.id === lineId);
			if (!line) return problem(`${node?.id ?? scene?.id}.dialogueLineIds`, "提示する台詞が存在しないか、削除・不採用です。");
			seen.add(line.id);
			next.visitCounts[line.id] = (next.visitCounts[line.id] ?? 0) + 1;
			for (const block of line.data.text) seen.add(block.id);
		}
		next.seenIds = [...seen];
		const variables = [...active$1(project, "variable"), ...(target.referenceEntities ?? []).filter((entity) => entity.kind === "variable" && adoptedRecord(entity))], ruleContext = presentationRuleContext(project, resolved), context = {
			state: next,
			variables,
			entities: project.entities,
			referenceEntities: target.referenceEntities,
			externalValues: target.externalValues,
			ruleContext,
			ruleContexts: reuseRuleContexts(project, ruleContext)
		};
		const conditions = [], disclosures = [];
		for (const disclosure of active$1(project, "disclosure")) {
			const anchor = reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id);
			const scope = disclosure.data.targetScope;
			const disclosureContext = {
				...context,
				ruleContext: context.ruleContexts[disclosure.id] ?? context.ruleContext
			};
			const scopeResult = scope ? evaluateTargetScope(scope, disclosureContext) : { value: "true" };
			if (scopeResult.value === "false") continue;
			if (anchor.sourceVersionId && ![
				project.projectId,
				state.contentVersionId,
				reuseOrigin(project, anchor.entityId)?.sourceVersionId,
				reuseOrigin(project, disclosure.id)?.sourceVersionId
			].includes(anchor.sourceVersionId)) continue;
			const lineIds = presentationLineIds(project, resolved);
			if (![
				node?.id,
				scene?.id,
				...lineIds
			].includes(anchor.entityId)) continue;
			if (scopeResult.value === "unknown") return problem(`${disclosure.id}.targetScope`, "開示の対象範囲・経路を確認できません。", "CONDITION_UNKNOWN");
			if (anchor.positionStatus === "unresolved" && [
				node?.id,
				scene?.id,
				...lineIds
			].includes(anchor.entityId)) return problem(`${disclosure.id}.anchor`, anchor.positionReason || "提示位置が不明です。本文へ再リンクしてください。", "CONDITION_UNKNOWN");
			if (!presentationAnchorApplies(project, next, anchor, resolved, disclosure.id)) continue;
			const result = evaluateCondition({
				op: "all",
				children: [disclosure.data.condition ?? {
					op: "constant",
					value: true
				}, scope?.routeCondition ?? {
					op: "constant",
					value: true
				}]
			}, disclosureContext);
			conditions.push({
				targetId: disclosure.id,
				...result
			});
			if (result.value === "unknown") return problem(`${disclosure.id}.condition`, result.reasons.join("、") || "この場面の開示条件が未確認です。", "CONDITION_UNKNOWN");
			if (result.value === "true") disclosures.push(disclosure);
		}
		const ordered = disclosures.filter((disclosure) => (disclosure.data.knowledgeEffects?.length ?? 0) > 0);
		for (let i = 0; i < ordered.length; i++) for (let j = i + 1; j < ordered.length; j++) if (presentationAnchorOrder(project, reuseExecutionAnchor(project, ordered[i].data.anchor, ordered[i].id), reuseExecutionAnchor(project, ordered[j].data.anchor, ordered[j].id), resolved) === void 0) return problem(`${node?.id ?? scene?.id}.disclosures`, "複数の開示効果の提示順が確定していません。段落と文字位置を指定してください。", "CONDITION_UNKNOWN");
		ordered.sort((left, right) => presentationAnchorOrder(project, reuseExecutionAnchor(project, left.data.anchor, left.id), reuseExecutionAnchor(project, right.data.anchor, right.id), resolved) ? -1 : 1);
		const effects = [], effectPresentations = [];
		for (const disclosure of ordered) for (const effectId of disclosure.data.knowledgeEffects ?? []) {
			const effect = [...project.entities, ...target.referenceEntities ?? []].find((item) => item.kind === "effect" && item.id === effectId && adoptedRecord(item));
			if (!effect) return problem(`${disclosure.id}.knowledgeEffects`, "開示に指定した効果が存在しないか、削除・不採用です。");
			effects.push(effect);
			effectPresentations.push({
				project,
				target: resolved,
				anchor: reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id)
			});
		}
		const applied = applyEffectsAtomic(next, effects, {
			...context,
			effectPresentations
		});
		if (!applied.ok) return applied;
		applied.state.seenIds = [.../* @__PURE__ */ new Set([...applied.state.seenIds, ...disclosures.map((disclosure) => disclosure.id)])];
		return {
			ok: true,
			state: applied.state,
			observationState: structuredClone(next),
			conditions
		};
	} catch (error) {
		return {
			ok: false,
			issues: error instanceof DomainValidationError ? error.issues : [{
				code: "VALIDATION_FAILED",
				path: "presentation",
				message: error instanceof Error ? error.message : "提示を検証できません。"
			}]
		};
	}
}
function presentChapterOccurrence(content, state, target) {
	const { sceneId, previousSceneId } = target;
	const from = presentationRuleContext(content, { sceneId: previousSceneId }), to = presentationRuleContext(content, { sceneId });
	const events = previousSceneId && previousSceneId !== sceneId ? ["scene_end"] : [];
	if (from.chapterId && from.chapterId !== to.chapterId) events.push("chapter_end");
	const reset = resetRuntimeLifecycle({
		...state,
		...state.resetCauses ? { resetCauses: [] } : {}
	}, events, {
		state,
		entities: content.entities,
		referenceEntities: target.referenceEntities,
		externalValues: target.externalValues,
		ruleContext: presentationRuleContext(content, {
			sceneId: target.previousSceneId,
			worldTick: target.worldTick
		}),
		ruleContexts: reuseRuleContexts(content, presentationRuleContext(content, {
			sceneId: target.previousSceneId,
			worldTick: target.worldTick
		}))
	});
	if (!reset.ok) return reset;
	const result = presentContent(content, reset.state, target);
	if (!result.ok) return result;
	if (target.last) {
		const ended = resetRuntimeLifecycle(result.state, [
			"scene_end",
			"chapter_end",
			"run_end"
		], {
			state: result.state,
			entities: content.entities,
			referenceEntities: target.referenceEntities,
			externalValues: target.externalValues,
			ruleContext: presentationRuleContext(content, target),
			ruleContexts: reuseRuleContexts(content, presentationRuleContext(content, target))
		});
		if (!ended.ok) return ended;
		result.state = ended.state;
		if (reset.state.resetCauses || ended.state.resetCauses) result.state.resetCauses = [...reset.state.resetCauses ?? [], ...ended.state.resetCauses ?? []];
	}
	return result;
}
var active$1, problem;
var init_presentation = __esmMin((() => {
	init_model();
	init_conditions();
	init_writingWorkspace();
	init_runtimeVersions();
	init_json();
	init_externalInputs();
	init_pinnedWorlds();
	init_adoption();
	init_stateRules();
	init_regressionPaths();
	init_reuse();
	init_narrative();
	active$1 = (project, kind) => project.entities.filter((entity) => entity.kind === kind && adoptedRecord(entity));
	problem = (path, message, code = "REFERENCE_INVALID") => ({
		ok: false,
		issues: [{
			code,
			path,
			message
		}]
	});
}));

//#endregion
//#region src/domain/stateRules.ts
/** Fail closed when a restricted dimension is absent, rather than expanding its scope. */
function evaluateTargetScope(scope, context) {
	const rule = context.ruleContext;
	if (!rule) return {
		value: "unknown",
		reasons: ["対象作品・章・経路の実行情報がありません。"]
	};
	if (scope.projectId !== rule.projectId || scope.targetSnapshotId && ![
		rule.projectId,
		context.state.contentVersionId,
		rule.sourceVersionId
	].includes(scope.targetSnapshotId)) return {
		value: "false",
		reasons: ["対象作品版の範囲外です。"]
	};
	if (scope.graphId && rule.graphId && scope.graphId !== rule.graphId || scope.chapterId && rule.chapterId && scope.chapterId !== rule.chapterId) return {
		value: "false",
		reasons: ["対象グラフまたは章の範囲外です。"]
	};
	const route = evaluateCondition(scope.routeCondition, context);
	if (route.value === "false") return route;
	if (scope.graphId && !rule.graphId || scope.chapterId && !rule.chapterId) return {
		value: "unknown",
		reasons: ["対象グラフまたは章を確認できません。", ...route.reasons]
	};
	return route;
}
function evaluateScenarioException(exception, context) {
	const fail = (value, reason) => ({
		value,
		reasons: [reason]
	});
	if (!exception.reason.trim() || !exception.evidenceIds.length) return fail("false", "例外には理由と根拠が必要です。");
	const entities = [...context.entities ?? [], ...context.referenceEntities ?? []];
	if (exception.evidenceIds.some((id) => !entities.some((entity) => entity.id === id && !entity.deletedAt && entity.status === "confirmed"))) return fail("unknown", "例外の根拠が存在しないか、採用確定していません。");
	const scope = evaluateTargetScope(exception.targetScope, context);
	if (scope.value !== "true") return scope;
	const range = exception.validity.worldRange, at = context.ruleContext?.worldTick;
	if (!range || range.end === null) return fail("unknown", "例外の有効期限を指定してください。");
	if (!isTick(at)) return fail("unknown", "例外の期限を評価する現在の世界時点がありません。");
	if (range.start !== null && compareTicks(at, range.start) < 0 || compareTicks(at, range.end) >= 0) return fail("false", "例外の有効期間外です。");
	const route = evaluateCondition(exception.validity.routeCondition, context);
	if (route.value !== "true") return route;
	const original = exception.validity.presentationAnchor, bindings = context.ruleContext?.anchorBindings;
	const anchor = original && bindings && original.sourceVersionId === context.ruleContext?.sourceVersionId ? {
		...original,
		entityId: bindings[original.entityId] ?? original.entityId,
		...original.blockId ? { blockId: bindings[original.blockId] ?? original.blockId } : {},
		...original.lineId ? { lineId: bindings[original.lineId] ?? original.lineId } : {}
	} : original;
	if (anchor && (anchor.positionStatus === "unresolved" || anchor.sourceVersionId && ![
		context.ruleContext.projectId,
		context.state.contentVersionId,
		context.ruleContext.sourceVersionId
	].includes(anchor.sourceVersionId))) return fail("unknown", "例外の提示位置または版を確認できません。");
	if (anchor && ![
		anchor.entityId,
		anchor.blockId,
		anchor.lineId
	].filter(Boolean).every((id) => context.state.seenIds.includes(id))) return fail("false", "例外の提示位置に到達していません。");
	return {
		value: "true",
		reasons: []
	};
}
/** Knowing/believing is an authored acquisition with an explicit source and point, never presence alone. */
function knowledgeAcquisitionIssue(assertion, context) {
	if (!assertion.data.holderId) return;
	if (typeof assertion.data.value !== "string" && assertion.data.value.type === "unknown") return {
		code: "CONDITION_UNKNOWN",
		message: "人物が取得する認識の内容が未確定です。"
	};
	const sources = assertion.data.sourceIds ?? [], entities = [...context.entities ?? [], ...context.referenceEntities ?? []];
	if (!sources.length || sources.some((id) => !entities.some((entity) => entity.id === id && adoptedRecord(entity)))) return {
		code: "REFERENCE_INVALID",
		message: "人物の認識取得には採用中の出所が必要です。"
	};
	const validity = assertion.data.validity, original = assertion.data.evidenceLocation ?? validity?.presentationAnchor, rule = context.ruleContexts?.[assertion.id] ?? context.ruleContext;
	const bindings = rule?.anchorBindings;
	const anchor = original && bindings && original.sourceVersionId === rule?.sourceVersionId ? {
		...original,
		entityId: bindings[original.entityId] ?? original.entityId,
		...original.blockId ? { blockId: bindings[original.blockId] ?? original.blockId } : {},
		...original.lineId ? { lineId: bindings[original.lineId] ?? original.lineId } : {}
	} : original;
	const range = validity?.worldRange;
	if (!anchor && (!range || range.start === null)) return {
		code: "CONDITION_UNKNOWN",
		message: "人物の認識取得には本文位置または世界内の取得時点が必要です。"
	};
	if (anchor) {
		if (anchor.positionStatus === "unresolved" || anchor.sourceVersionId && ![
			rule?.projectId,
			rule?.sourceVersionId,
			context.state.contentVersionId
		].includes(anchor.sourceVersionId)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置または固定版が未確認です。"
		};
		if (![
			anchor.entityId,
			anchor.blockId,
			anchor.lineId
		].filter(Boolean).every((id) => context.state.seenIds.includes(id))) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置へ到達していません。"
		};
		const current = context.currentPresentation;
		if (current) {
			const samePoint = anchor.entityId === current.anchor.entityId && anchor.blockId === current.anchor.blockId && anchor.lineId === current.anchor.lineId && anchor.start === current.anchor.start;
			const before = presentationAnchorOrder(current.project, anchor, current.anchor, current.target);
			if (!samePoint && before !== true) return {
				code: before === false ? "TRANSITION_BLOCKED" : "CONDITION_UNKNOWN",
				message: "認識取得の位置が、この効果の提示位置より後か、順序を確認できません。"
			};
		}
	}
	if (range) {
		if (!isTick(rule?.worldTick)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識の取得時点を照合する世界内tickが未入力です。"
		};
		if (range.start !== null && compareTicks(rule.worldTick, range.start) < 0 || range.end !== null && compareTicks(rule.worldTick, range.end) >= 0) return {
			code: "TRANSITION_BLOCKED",
			message: "認識の取得時点が宣言した有効期間外です。"
		};
	}
	const route = evaluateCondition(validity?.routeCondition, {
		...context,
		ruleContext: rule
	});
	if (route.value !== "true") return {
		code: route.value === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED",
		message: "認識を取得する経路条件が成立していません。"
	};
}
var init_stateRules = __esmMin((() => {
	init_presentation();
	init_adoption();
	init_conditions();
	init_time();
}));

//#endregion
//#region src/domain/conditions.ts
function variableValue(variableId, context, stack) {
	const variable = defs(context).find((variable) => variable.id === variableId);
	if (!variable) {
		if (context.variables || context.entities) return unknown("状態変数が定義されていません。");
		const value = context.state.variableValues[variableId];
		if (!value) return unknown("状態変数の値がありません。");
		const validated = validateTypedValue(value);
		if (!validated.ok) throw new DomainValidationError(validated.issues);
		return value;
	}
	if (variable.data.derived) {
		if (stack.includes(variableId)) throw new DomainValidationError([issue$2("算出状態の参照が循環しています。", `variables.${variableId}.derived`)]);
		const value = expressionValue(variable.data.derived, context, [...stack, variableId]);
		const errors = validateVariableValue(variable, value, `variables.${variableId}.derived`);
		if (errors.length) throw new DomainValidationError(errors);
		return value;
	}
	if (variable.data.externalContractId) {
		const value = context.externalValues?.[variable.data.externalContractId];
		if (!value) return unknown("宣言した外部値をまだ取得していません。");
		const checked = validateTypedValue(value);
		if (!checked.ok) throw new DomainValidationError(checked.issues);
		const errors = validateVariableValue(variable, value);
		if (errors.length) throw new DomainValidationError(errors);
		return value;
	}
	const value = context.state.variableValues[variableId];
	if (!value) return unknown("状態変数の値がありません。");
	const checked = validateTypedValue(value);
	if (!checked.ok) throw new DomainValidationError(checked.issues);
	const errors = validateVariableValue(variable, value);
	if (errors.length) throw new DomainValidationError(errors);
	return value;
}
function compare(left, right, comparator) {
	if (left.type === "unknown" || right.type === "unknown") return result("unknown", [left.type === "unknown" ? left.reason : "", right.type === "unknown" ? right.reason : ""].filter(Boolean));
	if (left.type !== right.type) throw new DomainValidationError([issue$2("比較する値の型が一致しません。")]);
	if (![
		"eq",
		"ne",
		"lt",
		"le",
		"gt",
		"ge"
	].includes(comparator)) throw new DomainValidationError([issue$2("未知の比較演算です。")]);
	if (comparator === "eq" || comparator === "ne") return result((comparator === "eq" ? left.value === right.value : left.value !== right.value) ? "true" : "false");
	if (left.type !== "integer" || right.type !== "integer") throw new DomainValidationError([issue$2("順序比較はintegerにだけ使えます。")]);
	return result((comparator === "lt" ? left.value < right.value : comparator === "le" ? left.value <= right.value : comparator === "gt" ? left.value > right.value : left.value >= right.value) ? "true" : "false");
}
function evaluate(condition, context, stack) {
	switch (condition.op) {
		case "constant": return result(condition.value ? "true" : "false");
		case "all":
		case "any": {
			const children = condition.children.map((child) => evaluate(child, context, stack)), reasons = children.flatMap((child) => child.reasons);
			if (condition.op === "all") return result(children.some((child) => child.value === "false") ? "false" : children.every((child) => child.value === "true") ? "true" : "unknown", reasons);
			return result(children.some((child) => child.value === "true") ? "true" : children.every((child) => child.value === "false") ? "false" : "unknown", reasons);
		}
		case "not": {
			const child = evaluate(condition.child, context, stack);
			return result(child.value === "unknown" ? "unknown" : child.value === "true" ? "false" : "true", child.reasons);
		}
		case "compare": {
			const left = variableValue(condition.variableId, context, stack);
			if (condition.comparator !== "in") return compare(left, condition.value, condition.comparator);
			const values = condition.value.map((value) => compare(left, value, "eq"));
			return result(values.some((value) => value.value === "true") ? "true" : values.some((value) => value.value === "unknown") ? "unknown" : "false", values.flatMap((value) => value.reasons));
		}
		case "item": {
			if (context.entities && !contextEntities(context).some((entity) => entity.id === condition.itemId && entity.kind === "item")) return result("unknown", ["指定した物品が定義されていません。"]);
			const quantity = context.state.itemInstances.filter((item) => !item.consumed && (item.instanceId === condition.itemId || item.typeId === condition.itemId)).reduce((sum, item) => sum + item.quantity, 0);
			return result(quantity >= condition.quantity ? "true" : "false");
		}
		case "known": {
			if (context.entities && (!contextEntities(context).some((entity) => entity.id === condition.assertionId && entity.kind === "assertion") || !contextEntities(context).some((entity) => entity.id === condition.holderId && entity.kind === "character"))) return result("unknown", ["認識の対象または人物が定義されていません。"]);
			const knowledge = context.state.assertions.find((assertion) => assertion.assertionId === condition.assertionId && assertion.holderId === condition.holderId);
			return knowledge ? result(knowledge.truth, knowledge.truth === "unknown" ? ["人物の認識が未確定です。"] : []) : result("false");
		}
		case "visited":
			if (context.entities && !contextEntities(context).some((entity) => entity.id === condition.entityId)) return result("unknown", ["訪問先が定義されていません。"]);
			return result((context.state.visitCounts[condition.entityId] ?? 0) >= condition.count ? "true" : "false");
		case "external": {
			if (context.entities && !contextEntities(context).some((entity) => entity.id === condition.contractId && entity.kind === "external_contract")) return result("unknown", ["外部契約が定義されていません。"]);
			const value = context.externalValues?.[condition.contractId];
			if (!value) return result("unknown", ["外部値をまだ取得していません。"]);
			const checked = validateTypedValue(value);
			if (!checked.ok) throw new DomainValidationError(checked.issues);
			if (value.type === "unknown") return result("unknown", [value.reason]);
			if (value.type !== "boolean") throw new DomainValidationError([issue$2("外部条件はbooleanの結果が必要です。")]);
			return result(value.value ? "true" : "false");
		}
	}
}
function evaluateCondition(condition, context) {
	const checked = validateCondition(condition ?? {
		op: "constant",
		value: true
	});
	if (!checked.ok) throw new DomainValidationError(checked.issues);
	return evaluate(checked.value, context, []);
}
function expressionValue(expression, context, stack) {
	switch (expression.op) {
		case "value": return expression.value;
		case "variable": return variableValue(expression.variableId, context, stack);
		case "if": {
			const condition = evaluate(expression.condition, context, stack);
			return condition.value === "unknown" ? unknown(condition.reasons.join("、") || "分岐条件が未定です。") : expressionValue(condition.value === "true" ? expression.then : expression.else, context, stack);
		}
		case "add":
		case "subtract":
		case "multiply": {
			const left = expressionValue(expression.left, context, stack), right = expressionValue(expression.right, context, stack);
			if (left.type === "unknown" || right.type === "unknown") return unknown([left.type === "unknown" ? left.reason : "", right.type === "unknown" ? right.reason : ""].filter(Boolean).join("、"));
			if (left.type !== "integer" || right.type !== "integer") throw new DomainValidationError([issue$2("算術の入力はintegerです。", "expression")]);
			const value = expression.op === "add" ? left.value + right.value : expression.op === "subtract" ? left.value - right.value : left.value * right.value;
			if (!Number.isSafeInteger(value)) throw new DomainValidationError([issue$2("算術結果が安全な整数の範囲を超えています。", "expression")]);
			return {
				type: "integer",
				value
			};
		}
		default: {
			const condition = evaluate(expression, context, stack);
			return condition.value === "unknown" ? unknown(condition.reasons.join("、")) : {
				type: "boolean",
				value: condition.value === "true"
			};
		}
	}
}
function initializeRuntimeState(project, contentVersionId = project.projectId, referenceEntities = [], externalValues = {}) {
	const state = emptyRuntimeState(contentVersionId), variables = [...project.entities, ...referenceEntities].filter((entity) => entity.kind === "variable" && adoptedRecord(entity));
	for (const variable of variables) state.variableValues[variable.id] = structuredClone(variable.data.initial);
	for (const variable of variables) if (variable.data.derived || variable.data.externalContractId && externalValues[variable.data.externalContractId]) state.variableValues[variable.id] = variableValue(variable.id, {
		state,
		variables,
		entities: project.entities,
		referenceEntities,
		externalValues
	}, []);
	return state;
}
/** Exclusions are checked on the final working state so an atomic swap remains possible. */
function runtimeExclusionIssues(context) {
	const issues = [];
	for (const variable of defs(context)) for (const [index, rule] of (variable.data.exclusions ?? []).entries()) {
		const result = evaluateCondition({
			op: "all",
			children: [{
				op: "compare",
				variableId: variable.id,
				comparator: "eq",
				value: rule.value
			}, {
				op: "compare",
				variableId: rule.variableId,
				comparator: "eq",
				value: rule.otherValue
			}]
		}, context);
		if (result.value === "false") continue;
		const exceptions = (rule.exceptions ?? []).map((exception) => evaluateScenarioException(exception, {
			...context,
			ruleContext: context.ruleContexts?.[variable.id] ?? context.ruleContext
		}));
		if (result.value === "true" && exceptions.some((exception) => exception.value === "true")) continue;
		const unknown = result.value === "unknown" || exceptions.some((exception) => exception.value === "unknown");
		issues.push(issue$2(unknown ? `相互排他を評価できません。${rule.reason}` : `相互排他に反する状態です。${rule.reason}`, `${variable.id}.exclusions[${index}]`, unknown ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED"));
	}
	return issues;
}
function sameValue$1(a, b) {
	return a.type === b.type && a.value === b.value;
}
function transitionAllowed(variable, before, after, effect, context) {
	if (effect.operation === "reset" || sameValue$1(before, after)) return;
	const quests = contextEntities(context).filter((entity) => entity.kind === "quest" && entity.data.stateVariableId === variable.id);
	const rules = [...(variable.data.transitionRules ?? []).map((rule) => ({
		rule,
		ownerId: variable.id
	})), ...quests.flatMap((quest) => (quest.data.transitionRules ?? []).map((rule) => ({
		rule,
		ownerId: quest.id
	})))];
	if (!rules.length && !quests.length) return;
	if (before.type === "unknown") throw new DomainValidationError([issue$2("遷移前の状態が未定です。", `variables.${variable.id}`, "CONDITION_UNKNOWN")]);
	const matching = rules.filter(({ rule }) => sameValue$1(rule.from, before) && sameValue$1(rule.to, after));
	if (matching.some(({ rule }) => !rule.exception && !rule.exceptionDetails)) return;
	const checked = [...matching.flatMap(({ rule, ownerId }) => rule.exceptionDetails ? [evaluateScenarioException(rule.exceptionDetails, {
		...context,
		ruleContext: context.ruleContexts?.[ownerId] ?? context.ruleContext
	})] : []), ...effect.exceptionDetails ? [evaluateScenarioException(effect.exceptionDetails, context)] : []];
	if (checked.some((value) => value.value === "true")) return;
	throw new DomainValidationError([issue$2(checked.flatMap((value) => value.reasons).join("、") || "許容遷移表にない状態更新です。明示resetまたは対象・期限・根拠付きの例外が必要です。", `variables.${variable.id}`, checked.some((value) => value.value === "unknown") ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED")]);
}
function itemTargets(state, targetId, instanceId) {
	return state.itemInstances.filter((item) => instanceId ? item.instanceId === instanceId : item.instanceId === targetId || item.typeId === targetId);
}
function applyOne(state, effect, context, effectId) {
	const variables = defs(context), target = [...context.entities ?? [], ...context.referenceEntities ?? []].find((entity) => entity.id === effect.targetId && adoptedRecord(entity));
	const fail = (message, code = "TRANSITION_BLOCKED") => {
		throw new DomainValidationError([issue$2(message, `effects.${effectId ?? effect.targetId}`, code)]);
	};
	if ([
		"set",
		"add",
		"reset"
	].includes(effect.operation)) {
		const variable = variables.find((variable) => variable.id === effect.targetId);
		if (!variable) fail("更新先の状態変数がありません。", "REFERENCE_INVALID");
		if (variable.data.derived) fail("算出状態へ直接代入できません。", "VALIDATION_FAILED");
		const before = variableValue(variable.id, {
			...context,
			state
		}, []);
		let after = effect.operation === "reset" ? structuredClone(effect.value ?? variable.data.initial) : effect.value;
		if (!after) fail("状態更新の入力値がありません。", "VALIDATION_FAILED");
		if (effect.operation === "add") {
			if (before.type === "unknown") fail(before.reason || "加算元の状態が未定です。", "CONDITION_UNKNOWN");
			if (before.type !== "integer" || after.type !== "integer" || variable.data.valueType !== "integer") fail("addはinteger状態とinteger入力だけを使えます。", "VALIDATION_FAILED");
			after = {
				type: "integer",
				value: before.value + after.value
			};
		}
		const errors = validateVariableValue(variable, after, `effects.${effectId ?? effect.targetId}.value`, effect.operation === "reset");
		if (errors.length) throw new DomainValidationError(errors.map((error) => ({
			...error,
			code: error.code === "CONDITION_UNKNOWN" ? error.code : "TRANSITION_BLOCKED"
		})));
		transitionAllowed(variable, before, after, effect, context);
		state.variableValues[variable.id] = structuredClone(after);
		return;
	}
	if (effect.operation === "mark_seen") {
		if (context.entities && !target) fail("既読対象が定義されていません。", "REFERENCE_INVALID");
		if (!state.seenIds.includes(effect.targetId)) state.seenIds.push(effect.targetId);
		return;
	}
	if (effect.operation === "assert") {
		if (!target || target.kind !== "assertion") fail("認識効果の対象には事実・認識が必要です。", "REFERENCE_INVALID");
		if (effect.value && effect.value.type !== "boolean") fail("認識効果の入力はbooleanです。", "VALIDATION_FAILED");
		const truth = effect.value?.type === "boolean" && !effect.value.value ? "false" : "true", holderId = target.data.holderId ?? null;
		if (truth === "true") {
			const acquisition = knowledgeAcquisitionIssue(target, context);
			if (acquisition) fail(acquisition.message, acquisition.code);
		}
		const existing = state.assertions.find((assertion) => assertion.assertionId === target.id && assertion.holderId === holderId);
		if (existing) {
			existing.truth = truth;
			if (effectId) existing.sourceEffectId = effectId;
		} else state.assertions.push({
			assertionId: target.id,
			holderId,
			truth,
			...effectId ? { sourceEffectId: effectId } : {}
		});
		return;
	}
	if (!target || target.kind !== "item") fail("物品効果の対象には宣言済みの物品が必要です。", "REFERENCE_INVALID");
	if (effect.instanceId) {
		const individual = contextEntities(context).find((entity) => entity.id === effect.instanceId);
		if (!individual || individual.kind !== "item" || individual.data.itemMode !== "instance") fail("指定した物品個体が定義されていません。", "REFERENCE_INVALID");
		if (target.data.itemMode === "type" && individual.data.typeId !== target.id || target.data.itemMode === "instance" && individual.id !== target.id) fail("指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
	}
	const quantity = effect.value?.type === "integer" ? effect.value.value : 1;
	if (effect.operation === "grant") {
		if (effect.value && effect.value.type !== "integer") fail("取得数量はintegerです。", "VALIDATION_FAILED");
		if (!Number.isSafeInteger(quantity) || quantity < 1) fail("取得数量は正の安全な整数です。", "VALIDATION_FAILED");
		const individual = target.data.itemMode === "instance" ? target : effect.instanceId ? contextEntities(context).find((entity) => entity.id === effect.instanceId && entity.kind === "item" && entity.data.itemMode === "instance") : void 0;
		if (effect.instanceId && !individual) fail("指定した物品個体がありません。", "REFERENCE_INVALID");
		if (individual) {
			if (quantity !== 1) fail("物品個体の数量は1です。");
			if (target.data.itemMode === "type" && individual.data.typeId !== target.id) fail("個体が指定した物品種類に属していません。", "REFERENCE_INVALID");
			if (state.itemInstances.some((item) => item.instanceId === individual.id)) fail("同じ物品個体を二重取得・復活させられません。");
			const typeId = individual.data.typeId;
			if (!typeId) fail("物品個体の種類が未定義です。", "REFERENCE_INVALID");
			state.itemInstances.push({
				instanceId: individual.id,
				typeId,
				quantity: 1,
				ownerId: null,
				locationId: null,
				consumed: false
			});
		} else {
			const existing = state.itemInstances.find((item) => item.instanceId === target.id && item.typeId === target.id);
			if (existing) {
				if (!Number.isSafeInteger(existing.quantity + quantity)) fail("物品数量が安全な整数範囲を超えています。");
				existing.quantity += quantity;
				existing.consumed = false;
			} else state.itemInstances.push({
				instanceId: target.id,
				typeId: target.id,
				quantity,
				ownerId: null,
				locationId: null,
				consumed: false
			});
		}
		return;
	}
	const items = itemTargets(state, effect.targetId, effect.instanceId).filter((item) => !item.consumed && item.quantity > 0);
	if (items.some((item) => target.data.itemMode === "type" ? item.typeId !== target.id : item.instanceId !== target.id || item.typeId !== target.data.typeId)) fail("実行状態の個体と効果の対象物品が一致しません。", "REFERENCE_INVALID");
	if (effect.operation === "consume") {
		if (!effect.reason?.trim()) fail("消費・破壊の理由を記録してください。", "VALIDATION_FAILED");
		if (effect.value && effect.value.type !== "integer") fail("消費数量はintegerです。", "VALIDATION_FAILED");
		if (!Number.isSafeInteger(quantity) || quantity < 1 || items.reduce((total, item) => total + item.quantity, 0) < quantity) fail("物品が不足しています。");
		let remaining = quantity;
		for (const item of items) {
			const take = Math.min(item.quantity, remaining);
			item.quantity -= take;
			remaining -= take;
			item.reason = effect.reason;
			item.consumed = item.quantity === 0;
			if (remaining === 0) break;
		}
		return;
	}
	if (effect.operation === "move") {
		if (effect.value?.type !== "ref") fail("移動先には人物・グループ・場所のrefが必要です。", "VALIDATION_FAILED");
		const destination = contextEntities(context).find((entity) => entity.id === effect.value?.value);
		if (!destination || ![
			"character",
			"group",
			"place"
		].includes(destination.kind)) fail("物品の移動先がありません。", "REFERENCE_INVALID");
		if (items.length !== 1) fail("移動する現存物品を一個体に特定してください。");
		const item = items[0];
		item.ownerId = destination.kind === "place" ? null : destination.id;
		item.locationId = destination.kind === "place" ? destination.id : null;
		return;
	}
	fail("未対応の物品操作です。", "VALIDATION_FAILED");
}
function applyEffectsAtomic(state, effects, context = { state }) {
	const checked = validateRuntimeState(state);
	if (!checked.ok) return {
		ok: false,
		state,
		issues: checked.issues
	};
	const working = structuredClone(state);
	try {
		for (const [index, input] of effects.entries()) {
			if ("data" in input && !adoptedRecord(input)) throw new DomainValidationError([issue$2("削除・不採用・別案の効果は実行できません。", `effects[${index}]`, "REFERENCE_INVALID")]);
			const effect = "data" in input ? input.data : input;
			const checkedEffect = validateEffectData(effect, `effects[${index}]`);
			if (!checkedEffect.ok) throw new DomainValidationError(checkedEffect.issues);
		}
		for (const [index, input] of effects.entries()) {
			const effect = "data" in input ? input.data : input, effectId = "id" in input ? input.id : void 0;
			const effectContext = {
				...context,
				currentPresentation: context.effectPresentations?.[index] ?? context.currentPresentation,
				state: working,
				ruleContext: effectId && context.ruleContexts?.[effectId] || context.ruleContext
			};
			const condition = evaluateCondition(effect.condition, effectContext);
			if (condition.value === "unknown") throw new DomainValidationError([issue$2(condition.reasons.join("、") || "効果の条件が未定です。", `effects[${index}].condition`, "CONDITION_UNKNOWN")]);
			if (condition.value === "false") continue;
			applyOne(working, effect, effectContext, effectId);
		}
		const instanceIds = /* @__PURE__ */ new Set();
		for (const item of working.itemInstances) {
			if (instanceIds.has(item.instanceId) || item.ownerId && item.locationId || item.consumed && item.quantity !== 0 || !item.consumed && item.quantity < 1) throw new DomainValidationError([issue$2("物品の個体ID・所在・数量が不整合です。", "itemInstances", "TRANSITION_BLOCKED")]);
			instanceIds.add(item.instanceId);
		}
		for (const variable of defs(context)) if (variable.data.derived) working.variableValues[variable.id] = variableValue(variable.id, {
			...context,
			state: working
		}, []);
		const exclusions = runtimeExclusionIssues({
			...context,
			state: working
		});
		if (exclusions.length) throw new DomainValidationError(exclusions);
		return {
			ok: true,
			state: working
		};
	} catch (error) {
		return {
			ok: false,
			state,
			issues: error instanceof DomainValidationError ? error.issues : [issue$2(error instanceof Error ? error.message : "効果を適用できません。", "effects")]
		};
	}
}
/** Lifecycle resets are explicit effects with the same validation and atomicity as a choice. */
function resetRuntimeLifecycle(state, events, context) {
	if (!events.length) return {
		ok: true,
		state: structuredClone(state)
	};
	const working = structuredClone(state), effects = [];
	const causes = [];
	for (const on of events) for (const variable of defs(context)) {
		if (variable.data.derived || variable.data.externalContractId) continue;
		const rule = variable.data.resetRules?.find((rule) => rule.on === on);
		const resetScope = on === "full_reset" || on === "new_loop" && [
			"scene",
			"chapter",
			"run"
		].includes(variable.data.scope);
		if (!rule && !resetScope) continue;
		const value = rule?.value ?? variable.data.initial;
		effects.push({
			operation: "reset",
			targetId: variable.id,
			value
		});
		causes.push({
			variableId: variable.id,
			on,
			before: structuredClone(working.variableValues[variable.id] ?? {
				type: "unknown",
				value: null,
				reason: "途中開始時の値が未指定です。"
			}),
			after: structuredClone(value),
			reason: rule?.reason || (rule ? "宣言した初期化規則" : `有効範囲 ${variable.data.scope} の初期化`)
		});
		working.variableValues[variable.id] = structuredClone(value);
	}
	const applied = applyEffectsAtomic(state, effects, context);
	if (!applied.ok) return applied;
	if (events.length && (causes.length || state.resetCauses)) applied.state.resetCauses = causes;
	return applied;
}
var DomainValidationError, issue$2, unknown, result, contextEntities, defs;
var init_conditions = __esmMin((() => {
	init_model();
	init_adoption();
	init_stateRules();
	DomainValidationError = class extends Error {
		issues;
		constructor(issues) {
			super(issues.map((issue) => issue.message).join("、"));
			this.name = "DomainValidationError";
			this.issues = issues;
		}
	};
	issue$2 = (message, path = "condition", code = "VALIDATION_FAILED") => ({
		code,
		path,
		message
	});
	unknown = (reason) => ({
		type: "unknown",
		value: null,
		reason
	});
	result = (value, reasons = []) => ({
		value,
		reasons: [...new Set(reasons)]
	});
	contextEntities = (context) => [...context.entities ?? [], ...context.referenceEntities ?? []].filter(adoptedRecord);
	defs = (context) => (context.variables ?? [...context.entities ?? [], ...context.referenceEntities ?? []].filter((entity) => entity.kind === "variable")).filter(adoptedRecord);
}));

//#endregion
//#region src/domain/runtimeVersions.ts
/** Verify immutable bytes before interpreting any captured references or runtime state. */
async function captureRuntimeContent(project, contentVersionId = project.projectId, validationOptions = {}, digestCache) {
	const source = contentVersionId === project.projectId ? project : project.snapshots.find((snapshot) => snapshot.id === contentVersionId);
	if (!source) throw new DomainValidationError([{
		code: "REFERENCE_INVALID",
		path: "contentVersionId",
		message: "実行する固定版がありません。"
	}]);
	const worldSnapshots = validationOptions.worldSnapshots ? digestCache?.stableRegistries.has(validationOptions.worldSnapshots) ? validationOptions.worldSnapshots : digestCache ? freezePinnedWorldRegistry(validationOptions.worldSnapshots, digestCache) : structuredClone(validationOptions.worldSnapshots) : {};
	const worlds = validationOptions.worlds ? structuredClone(validationOptions.worlds) : void 0;
	const safeOptions = {
		...validationOptions,
		worldSnapshots,
		worlds
	};
	const isSnapshot = "content" in source;
	const sourceContent = structuredClone(isSnapshot ? source.content : source);
	const sourceHash = isSnapshot ? source.contentHash : void 0;
	const sourceId = "content" in source ? source.id : project.projectId;
	const snapshots = structuredClone(project.snapshots);
	const { authorAlternatives: _authorAlternatives, snapshots: _sourceSnapshots, history: _history, ...branchFreeContent } = sourceContent;
	const captured = {
		...branchFreeContent,
		snapshots,
		history: []
	};
	if (sourceHash && await sha256(jsonBytes(branchFreeContent)) !== sourceHash) throw new DomainValidationError([{
		code: "INTEGRITY_FAILED",
		path: `snapshots.${sourceId}.contentHash`,
		message: "固定版の内容ハッシュが一致しません。実行を停止しました。"
	}]);
	const pins = /* @__PURE__ */ new Set(), queue = [captured];
	for (let cursor = 0; cursor < queue.length; cursor++) for (const entity of queue[cursor].entities) if ((entity.kind === "scene" || entity.kind === "flow_node") && entity.data.reuse && entity.data.reuse.mode !== "clone") {
		const pin = entity.data.reuse.pinnedSnapshotId;
		if (pins.has(pin)) continue;
		pins.add(pin);
		const snapshot = snapshots.find((item) => item.id === pin);
		if (!snapshot || await sha256(jsonBytes(snapshot.content)) !== snapshot.contentHash) throw new DomainValidationError([{
			code: "INTEGRITY_FAILED",
			path: `snapshots.${pin}`,
			message: "共通元の固定版がないか、内容hashが一致しません。"
		}]);
		queue.push({
			...snapshot.content,
			snapshots,
			history: []
		});
	}
	const worldIssues = await verifyPinnedWorlds(resolveReuseContent(captured, snapshots), worldSnapshots, "worldReferences", digestCache);
	if (worldIssues.length) throw new DomainValidationError(worldIssues);
	const checked = validateProject(captured, safeOptions);
	if (!checked.ok) throw new DomainValidationError(checked.issues);
	return captured;
}
var init_runtimeVersions = __esmMin((() => {
	init_model();
	init_json();
	init_conditions();
	init_pinnedWorlds();
	init_reuse();
}));

//#endregion
//#region src/domain/sharedReviews.ts
init_model();
init_runtimeVersions();
init_reuse();
init_json();
function publicBlocks(entity) {
	return Object.values(entity.data).filter(Array.isArray).flat().filter((b) => !!b && typeof b === "object" && typeof b.id === "string" && typeof b.text === "string");
}
/** Private correspondence is generated from the same frozen publication view,
* stored atomically with publication, and never returned to a public reader. */
async function publicationReviewSources(captured, prepared, sourceVersionId, worlds) {
	captured = structuredClone(captured);
	prepared = structuredClone(prepared);
	worlds = structuredClone(worlds);
	const output = {};
	const sources = [{
		publicVersionId: "public-project",
		project: prepared.project,
		projection: prepared.projection,
		idMap: prepared.idMap,
		version: sourceVersionId
	}, ...prepared.citations.sources.map((s) => ({
		...s,
		version: Object.entries(prepared.citations.targets).find(([, target]) => target.publicVersionId === s.publicVersionId)?.[0] ?? ""
	}))];
	for (const source of sources) {
		if (!source.version) throw Error("REVIEW_SOURCE_UNKNOWN");
		const edition = await captureRuntimeContent(captured, source.version, { worldSnapshots: worlds }), view = resolveReuseContent(edition, edition.snapshots), reverse = new Map(Object.entries(source.idMap).map(([privateId, publicId]) => [publicId, privateId])), entities = {}, relations = {};
		const inWorld = (id) => view.worldReferences.flatMap((ref) => worlds[ref.immutableSnapshotId]?.entities.some((e) => e.id === id) || worlds[ref.immutableSnapshotId]?.relations.some((r) => r.id === id) ? [{ sourceVersionId: ref.immutableSnapshotId }] : []);
		for (const entity of source.projection.entities) {
			const id = reverse.get(entity.id);
			if (!id) continue;
			const local = view.entities.some((e) => e.id === id), world = inWorld(id);
			if (!local && world.length !== 1) continue;
			const resolve = (anchor) => {
				const original = local ? reuseTargetAnchor(view, anchor) : {
					...anchor,
					sourceVersionId: world[0].sourceVersionId
				};
				return {
					...original,
					sourceVersionId: original.sourceVersionId ?? source.version
				};
			};
			const blocks = {};
			for (const block of publicBlocks(entity)) {
				const original = reverse.get(block.id);
				if (original) blocks[block.id] = resolve({
					entityId: id,
					blockId: original
				});
			}
			entities[entity.id] = {
				target: resolve({ entityId: id }),
				blocks
			};
		}
		for (const relation of source.projection.relations) {
			const id = reverse.get(relation.id);
			if (!id) continue;
			const local = view.relations.some((r) => r.id === id), world = inWorld(id);
			if (local || world.length === 1) relations[relation.id] = {
				id,
				sourceVersionId: local ? source.version : world[0].sourceVersionId
			};
		}
		output[source.publicVersionId] = {
			entities,
			relations
		};
	}
	return output;
}

//#endregion
//#region src/domain/authorAlternativeIntegrity.ts
const HASH = /^[0-9a-f]{64}$/;
const REVISION = /^(0|[1-9][0-9]*)$/;
const BRANCH_STATUSES = /* @__PURE__ */ new Set([
	"active",
	"provisional",
	"needs_review",
	"rejected",
	"accepted"
]);
const RECEIPT_SCOPES = /* @__PURE__ */ new Set([
	"project",
	"entity",
	"relation",
	"presentation"
]);
const BLOCKED_KEYS = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]);
const DEFAULT_LIMITS = {
	alternatives: 100,
	versions: 500,
	branchBytes: 8e6,
	totalBytes: 16e6
};
function stableJson(value, ancestors = /* @__PURE__ */ new Set(), depth = 0) {
	if (depth > 100) throw new Error("内容の階層が上限を超えています。");
	if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
	if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
	if (!value || typeof value !== "object" || ancestors.has(value)) throw new Error("SHA-256対象が通常のJSON値ではありません。");
	const prototype = Object.getPrototypeOf(value);
	if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) throw new Error("SHA-256対象に未対応の値があります。");
	ancestors.add(value);
	const json = Array.isArray(value) ? `[${value.map((item) => stableJson(item, ancestors, depth + 1)).join(",")}]` : `{${Object.keys(value).sort().map((key) => {
		if (BLOCKED_KEYS.has(key)) throw new Error("JSONに未対応の項目名があります。");
		return `${JSON.stringify(key)}:${stableJson(value[key], ancestors, depth + 1)}`;
	}).join(",")}}`;
	ancestors.delete(value);
	return json;
}
async function authorAlternativeSha256(value) {
	const bytes = new TextEncoder().encode(stableJson(value));
	const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
	return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function branchPayload(alternative) {
	const { integrityHash: _integrityHash, ...payload } = alternative;
	return payload;
}
function isRecord(value) {
	return !!value && typeof value === "object" && !Array.isArray(value);
}
function dateIsValid(value) {
	return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function issue$1(issues, path, message) {
	issues.push({
		path,
		message
	});
}
function collectStructurePlanIssues(plan, content, path, issues) {
	if (typeof plan.templateId !== "string" || !plan.templateId.trim()) issue$1(issues, `${path}.templateId`, "構成雛形IDが必要です。");
	if (!Array.isArray(plan.beatLabels) || plan.beatLabels.length > 100 || plan.beatLabels.some((label) => typeof label !== "string" || !label.trim())) issue$1(issues, `${path}.beatLabels`, "構成の役割は空でない文章を100件以内で指定してください。");
	else if (new Set(plan.beatLabels).size !== plan.beatLabels.length) issue$1(issues, `${path}.beatLabels`, "構成の役割名は重複できません。");
	const chapter = content.entities.find((entity) => entity.kind === "chapter" && entity.id === plan.chapterId && !entity.deletedAt);
	if (!chapter) issue$1(issues, `${path}.chapterId`, "構成計画の章が別案に存在しません。");
	if (!isRecord(plan.assignments)) {
		issue$1(issues, `${path}.assignments`, "場面の割り当てが不正です。");
		return;
	}
	const labels = new Set(Array.isArray(plan.beatLabels) ? plan.beatLabels : []), assigned = /* @__PURE__ */ new Set();
	for (const [beat, sceneId] of Object.entries(plan.assignments)) {
		if (!labels.has(beat)) issue$1(issues, `${path}.assignments.${beat}`, "定義されていない構成の役割です。");
		if (typeof sceneId !== "string" || assigned.has(sceneId)) issue$1(issues, `${path}.assignments.${beat}`, "同じ場面を複数の役割へ割り当てられません。");
		assigned.add(sceneId);
		if (!content.entities.some((entity) => entity.kind === "scene" && entity.id === sceneId && !entity.deletedAt)) issue$1(issues, `${path}.assignments.${beat}`, "割り当てる場面が別案に存在しません。");
		if (chapter && typeof sceneId === "string" && !chapter.data.sceneIds.includes(sceneId)) issue$1(issues, `${path}.assignments.${beat}`, "場面は対象の章に所属していません。");
	}
}
function getPath(value, path) {
	return path.reduce((current, key) => current && typeof current === "object" ? current[key] : void 0, value);
}
function presentationSnapshot(content) {
	return {
		chapterOrder: content.entities.filter((entity) => entity.kind === "chapter" && !entity.deletedAt).map((chapter) => chapter.id),
		chapters: content.entities.filter((entity) => entity.kind === "chapter" && !entity.deletedAt).map((chapter) => ({
			id: chapter.id,
			sceneIds: [...chapter.data.sceneIds]
		})),
		scenes: content.entities.filter((entity) => entity.kind === "scene" && !entity.deletedAt).map((scene) => ({
			id: scene.id,
			chapterId: scene.data.chapterId ?? null
		}))
	};
}
function receiptPatchValue(content, receipt) {
	if (receipt.scope === "presentation") return presentationSnapshot(content);
	if (receipt.scope === "project") return getPath(content, receipt.path);
	const target = (receipt.scope === "entity" ? content.entities : content.relations).find((item) => item.id === receipt.itemId);
	if (!target || target.deletedAt) return void 0;
	return receipt.path.length ? getPath(target, receipt.path) : target;
}
function validateReceipt(receipt, versions, sourceSnapshotId, path, issues) {
	if (!receipt || typeof receipt !== "object") {
		issue$1(issues, path, "正本採用記録が不正です。");
		return;
	}
	if (!dateIsValid(receipt.createdAt)) issue$1(issues, `${path}.createdAt`, "採用日時が不正です。");
	const version = versions.get(receipt.alternativeVersionId ?? "");
	if (!version) issue$1(issues, `${path}.alternativeVersionId`, "採用元の別案版が見つかりません。");
	if ((receipt.sourceSnapshotId ?? null) !== (sourceSnapshotId ?? null)) issue$1(issues, `${path}.sourceSnapshotId`, "採用記録の分岐元固定版が別案と一致しません。");
	if (!REVISION.test(receipt.fromCanonicalRevision) || !receipt.appliedRevision || !REVISION.test(receipt.appliedRevision)) issue$1(issues, path, "採用元と採用先の正本版番号が必要です。");
	else if (BigInt(receipt.appliedRevision) <= BigInt(receipt.fromCanonicalRevision)) issue$1(issues, `${path}.appliedRevision`, "採用先の正本版は採用元より新しくなければなりません。");
	if (!Array.isArray(receipt.selectedChangeKeys) || !receipt.selectedChangeKeys.length || new Set(receipt.selectedChangeKeys).size !== receipt.selectedChangeKeys.length) issue$1(issues, `${path}.selectedChangeKeys`, "採用対象の差分キーが必要です。");
	if (!Array.isArray(receipt.patches) || !receipt.patches.length) {
		issue$1(issues, `${path}.patches`, "採用した差分がありません。");
		return;
	}
	const patchKeys = /* @__PURE__ */ new Set();
	receipt.patches.forEach((patch, index) => {
		const patchPath = `${path}.patches[${index}]`;
		if (!patch || typeof patch.key !== "string" || patchKeys.has(patch.key)) issue$1(issues, `${patchPath}.key`, "差分キーが不正または重複しています。");
		patchKeys.add(patch.key);
		if (!RECEIPT_SCOPES.has(patch.scope) || !Array.isArray(patch.path) || patch.path.some((part) => typeof part !== "string") || typeof patch.label !== "string") issue$1(issues, patchPath, "差分の対象が不正です。");
		if (typeof patch.before?.present !== "boolean" || typeof patch.after?.present !== "boolean") issue$1(issues, patchPath, "差分の前後値の有無が不正です。");
		const expectedKey = [
			patch.scope,
			patch.itemId ?? "",
			...patch.path ?? []
		].map((part) => encodeURIComponent(part)).join(":");
		if (patch.key !== expectedKey) issue$1(issues, `${patchPath}.key`, "差分キーが保存した範囲と一致しません。");
		if (patch.scope === "presentation" && (patch.itemId || patch.path?.length !== 1 || patch.path[0] !== "all")) issue$1(issues, patchPath, "提示順差分の範囲が不正です。");
		if (patch.before?.present === false && Object.hasOwn(patch.before, "value") || patch.after?.present === false && Object.hasOwn(patch.after, "value")) issue$1(issues, patchPath, "値がない差分に値を含められません。");
		if (patch.before?.present === true && !Object.hasOwn(patch.before, "value") || patch.after?.present === true && !Object.hasOwn(patch.after, "value")) issue$1(issues, patchPath, "値がある差分には値を含めてください。");
		if (version && patch.after && typeof patch.after.present === "boolean") {
			const expected = receiptPatchValue(version.content, patch);
			const expectedPresent = expected !== void 0;
			if (patch.after.present !== expectedPresent) issue$1(issues, `${patchPath}.after`, "採用後の有無が参照した別案版と一致しません。");
			else if (expectedPresent) try {
				if (stableJson(patch.after.value) !== stableJson(expected)) issue$1(issues, `${patchPath}.after.value`, "採用後の値が参照した別案版と一致しません。");
			} catch (error) {
				issue$1(issues, `${patchPath}.after.value`, error instanceof Error ? error.message : "採用後の値を別案版と比較できません。");
			}
		}
	});
	if (Array.isArray(receipt.selectedChangeKeys) && !sameStrings(receipt.selectedChangeKeys, [...patchKeys])) issue$1(issues, `${path}.selectedChangeKeys`, "採用対象キーと保存した差分内容が一致しません。");
}
function sameStrings(left, right) {
	return left.length === right.length && [...left].sort().every((value, index) => value === [...right].sort()[index]);
}
/**
* Checks branch metadata and each content image independently. `validateContent` must call the normal
* ProjectContent validator for every image so branch entities get a fresh, isolated ID/reference index.
*/
async function validateAuthorAlternatives(projectId, input, options) {
	const issues = [];
	const limits = {
		alternatives: options.maxAlternatives ?? DEFAULT_LIMITS.alternatives,
		versions: options.maxVersionsPerAlternative ?? DEFAULT_LIMITS.versions,
		branchBytes: options.maxBytesPerAlternative ?? DEFAULT_LIMITS.branchBytes,
		totalBytes: options.maxBytesTotal ?? DEFAULT_LIMITS.totalBytes
	};
	if (!Array.isArray(input)) return [{
		path: "authorAlternatives",
		message: "作者別案は配列で指定してください。"
	}];
	if (input.length > limits.alternatives) issue$1(issues, "authorAlternatives", `作者別案は${limits.alternatives}件までです。`);
	const globalIds = new Set(options.reservedIds ?? []), branchIds = /* @__PURE__ */ new Set();
	let totalBytes = 0;
	for (const [branchIndex, raw] of input.entries()) {
		const path = `authorAlternatives[${branchIndex}]`;
		if (!isRecord(raw)) {
			issue$1(issues, path, "作者別案の記録が不正です。");
			continue;
		}
		const alternative = raw;
		if (typeof alternative.id !== "string" || branchIds.has(alternative.id) || globalIds.has(alternative.id)) issue$1(issues, `${path}.id`, "別案IDが不正または重複しています。");
		if (typeof alternative.id === "string") {
			branchIds.add(alternative.id);
			globalIds.add(alternative.id);
		}
		if (alternative.projectId !== projectId) issue$1(issues, `${path}.projectId`, "別案が別の作品を参照しています。");
		if (typeof alternative.name !== "string" || !alternative.name.trim()) issue$1(issues, `${path}.name`, "別案名が必要です。");
		if (!BRANCH_STATUSES.has(alternative.status)) issue$1(issues, `${path}.status`, "別案の状態が不正です。");
		if (!dateIsValid(alternative.createdAt) || !dateIsValid(alternative.updatedAt)) issue$1(issues, path, "別案の作成日時または更新日時が不正です。");
		if (!REVISION.test(alternative.baseRevision)) issue$1(issues, `${path}.baseRevision`, "分岐元の版番号が不正です。");
		if (alternative.sourceSnapshotId != null && options.snapshotIds && !options.snapshotIds.has(alternative.sourceSnapshotId)) issue$1(issues, `${path}.sourceSnapshotId`, "分岐元の固定版が見つかりません。");
		if (!isRecord(alternative.baseContent) || alternative.baseContent.projectId !== projectId || alternative.baseContent.revision !== alternative.baseRevision) issue$1(issues, `${path}.baseContent`, "分岐元の内容・作品ID・版番号が一致しません。");
		if (isRecord(alternative.baseContent) && Object.hasOwn(alternative.baseContent, "authorAlternatives")) issue$1(issues, `${path}.baseContent.authorAlternatives`, "別案の内容へ別案一覧を再帰保存できません。");
		if (isRecord(alternative.baseContent)) {
			if (alternative.sourceSnapshotId) {
				const source = options.snapshots?.find((snapshot) => snapshot.id === alternative.sourceSnapshotId);
				if (!source) issue$1(issues, `${path}.sourceSnapshotId`, "分岐元の固定版本文がありません。");
				else try {
					if (stableJson(source.content) !== stableJson(alternative.baseContent)) issue$1(issues, `${path}.baseContent`, "固定版から分岐した別案は、固定版本文をそのまま保持してください。");
				} catch (error) {
					issue$1(issues, `${path}.baseContent`, error instanceof Error ? error.message : "固定版本文と分岐元を比較できません。");
				}
			}
			const result = await options.validateContent(alternative.baseContent);
			if (!result.ok) (result.issues ?? []).forEach((detail) => issue$1(issues, `${path}.baseContent${detail.path ? `.${detail.path}` : ""}`, detail.message));
			if (HASH.test(alternative.baseContentHash ?? "")) try {
				if (await authorAlternativeSha256(alternative.baseContent) !== alternative.baseContentHash) issue$1(issues, `${path}.baseContentHash`, "分岐元の内容SHA-256が一致しません。");
			} catch (error) {
				issue$1(issues, `${path}.baseContentHash`, error instanceof Error ? error.message : "分岐元の内容hashを確認できません。");
			}
			else issue$1(issues, `${path}.baseContentHash`, "分岐元の内容SHA-256がありません。");
		}
		if (!Array.isArray(alternative.versions) || !alternative.versions.length || alternative.versions.length > limits.versions) {
			issue$1(issues, `${path}.versions`, `別案の版は1〜${limits.versions}件で指定してください。`);
			continue;
		}
		const versions = alternative.versions, versionById = /* @__PURE__ */ new Map(), versionIndex = /* @__PURE__ */ new Map();
		for (const [versionIndexValue, version] of versions.entries()) {
			const versionPath = `${path}.versions[${versionIndexValue}]`;
			if (!version || typeof version.id !== "string" || versionById.has(version.id) || globalIds.has(version.id)) issue$1(issues, `${versionPath}.id`, "別案版IDが不正または重複しています。");
			if (typeof version?.id === "string") {
				versionById.set(version.id, version);
				versionIndex.set(version.id, versionIndexValue);
				globalIds.add(version.id);
			}
			if (typeof version?.label !== "string" || !version.label.trim() || !dateIsValid(version.createdAt)) issue$1(issues, versionPath, "別案版の名前または作成日時が不正です。");
			if (!isRecord(version?.content) || version.content.projectId !== projectId) {
				issue$1(issues, `${versionPath}.content`, "別案版の作品IDが一致しません。");
				continue;
			}
			if (Object.hasOwn(version.content, "authorAlternatives")) issue$1(issues, `${versionPath}.content.authorAlternatives`, "別案版へ別案一覧を再帰保存できません。");
			const result = await options.validateContent(version.content);
			if (!result.ok) (result.issues ?? []).forEach((detail) => issue$1(issues, `${versionPath}.content${detail.path ? `.${detail.path}` : ""}`, detail.message));
			if (version.structurePlan) collectStructurePlanIssues(version.structurePlan, version.content, `${versionPath}.structurePlan`, issues);
			try {
				const digest = await authorAlternativeSha256({
					content: version.content,
					structurePlan: version.structurePlan ?? null
				});
				if (!HASH.test(version.contentHash ?? "") || version.contentHash !== digest) issue$1(issues, `${versionPath}.contentHash`, "別案版の内容SHA-256がありません、または一致しません。");
			} catch (error) {
				issue$1(issues, `${versionPath}.contentHash`, error instanceof Error ? error.message : "別案版の内容hashを確認できません。");
			}
		}
		const roots = versions.filter((version) => version.parentVersionId === null);
		if (roots.length !== 1) issue$1(issues, `${path}.versions`, "別案履歴には親のない開始版が一つ必要です。");
		if (roots[0]) try {
			if (stableJson(roots[0].content) !== stableJson(alternative.baseContent)) issue$1(issues, `${path}.versions`, "開始版は分岐元の内容を保持してください。");
		} catch (error) {
			issue$1(issues, `${path}.versions`, error instanceof Error ? error.message : "開始版と分岐元の内容を比較できません。");
		}
		let lastTime = Number.NEGATIVE_INFINITY;
		for (const [versionIndexValue, version] of versions.entries()) {
			const versionPath = `${path}.versions[${versionIndexValue}]`, time = Date.parse(version.createdAt);
			if (Number.isFinite(time) && time < lastTime) issue$1(issues, `${versionPath}.createdAt`, "別案の版は作成順に並べてください。");
			if (Number.isFinite(time)) lastTime = time;
			if (version.parentVersionId !== null) {
				const parentPosition = versionIndex.get(version.parentVersionId ?? "");
				if (parentPosition === void 0 || parentPosition >= versionIndexValue) issue$1(issues, `${versionPath}.parentVersionId`, "別案版の親が存在しないか、作成順の後にあります。");
			}
		}
		const visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set();
		const checkCycle = (id) => {
			if (active.has(id)) {
				issue$1(issues, `${path}.versions`, "別案版の親子関係に循環があります。");
				return;
			}
			if (visited.has(id)) return;
			active.add(id);
			const parent = versionById.get(id)?.parentVersionId;
			if (parent) checkCycle(parent);
			active.delete(id);
			visited.add(id);
		};
		versionById.forEach((_version, id) => checkCycle(id));
		if (alternative.headVersionId !== versions.at(-1)?.id) issue$1(issues, `${path}.headVersionId`, "別案の現在版は履歴の最後の版でなければなりません。");
		if (!Array.isArray(alternative.applyReceipts)) issue$1(issues, `${path}.applyReceipts`, "正本採用履歴が不正です.");
		else {
			const receiptIds = /* @__PURE__ */ new Set();
			let priorRevision = -1n;
			alternative.applyReceipts.forEach((receipt, index) => {
				const receiptPath = `${path}.applyReceipts[${index}]`;
				if (receiptIds.has(receipt.id) || globalIds.has(receipt.id)) issue$1(issues, `${receiptPath}.id`, "採用記録IDが重複しています。");
				receiptIds.add(receipt.id);
				globalIds.add(receipt.id);
				validateReceipt(receipt, versionById, alternative.sourceSnapshotId, receiptPath, issues);
				if (REVISION.test(receipt.appliedRevision ?? "")) {
					const revision = BigInt(receipt.appliedRevision);
					if (revision <= priorRevision) issue$1(issues, `${receiptPath}.appliedRevision`, "正本採用履歴は版の昇順で並べてください。");
					priorRevision = revision;
				}
			});
		}
		try {
			const payload = branchPayload(alternative);
			if (!HASH.test(alternative.integrityHash ?? "") || await authorAlternativeSha256(payload) !== alternative.integrityHash) issue$1(issues, `${path}.integrityHash`, "作者別案全体のSHA-256がありません、または一致しません。");
		} catch (error) {
			issue$1(issues, `${path}.integrityHash`, error instanceof Error ? error.message : "作者別案のhashを確認できません。");
		}
		try {
			const bytes = new TextEncoder().encode(stableJson(alternative)).byteLength;
			totalBytes += bytes;
			if (bytes > limits.branchBytes) issue$1(issues, path, `別案は${limits.branchBytes} bytesまでです。`);
		} catch (error) {
			issue$1(issues, path, error instanceof Error ? error.message : "別案をJSON化できません。");
		}
	}
	if (totalBytes > limits.totalBytes) issue$1(issues, "authorAlternatives", `作者別案全体は${limits.totalBytes} bytesまでです。`);
	return issues;
}

//#endregion
//#region src/domain/runtimeRecordValidation.ts
init_presentation();
init_json();
init_externalInputs();
init_pinnedWorlds();
init_reuse();
/** Model/import hook: chapter evidence is verified by the same shared presentation engine. */
function validateReadingTraceRecord(content, trace, checkpoint, path = "trace", options = {}) {
	try {
		content = resolveReuseContent(content, content.snapshots);
	} catch (error) {
		return [{
			code: "REFERENCE_INVALID",
			path,
			message: error.message
		}];
	}
	const issues = [];
	const fail = (field, message, code = "VALIDATION_FAILED") => issues.push({
		code,
		path: `${path}.${field}`,
		message
	});
	if (trace.mode !== "chapters") {
		if (trace.readingPath) fail("readingPath", "章の提示経路はmode:chaptersの記録に指定してください。");
		return issues;
	}
	const reading = trace.readingPath;
	if (!reading) {
		fail("readingPath", "章読み通し記録に提示経路がありません。");
		return issues;
	}
	const closure = resolvePinnedWorlds(content, options.worldSnapshots ?? {});
	if (closure.errors.length) fail("worldReferences", closure.errors[0], "REFERENCE_INVALID");
	const referenceEntities = closure.worlds.flatMap((world) => world.entities);
	issues.push(...validateExternalInput(content, trace.initialExternalValues ?? {}, void 0, referenceEntities).map((issue) => ({
		...issue,
		path: `${path}.initialExternalValues.${issue.path}`
	})));
	if (trace.initialWorldTick != null && checkpoint.worldTick != null && trace.initialWorldTick !== checkpoint.worldTick) fail("initialWorldTick", "保存した開始時点と章経路の提示時点が一致しません。", "INTEGRITY_FAILED");
	if (trace.steps.length) fail("steps", "章読み通しにフロー遷移を混在させられません。");
	if (trace.contentVersionId !== checkpoint.contentVersionId || checkpoint.runtimeState.contentVersionId !== trace.contentVersionId) fail("contentVersionId", "開始状態と読み通しの固定版が一致しません。");
	if (trace.contentRevision !== content.revision || checkpoint.contentRevision !== content.revision) fail("contentRevision", "章読み通しには開始状態と内容版に一致する更新番号が必要です。");
	if (checkpoint.origin !== "partial" || checkpoint.runtimeState.presentationPosition !== null) fail("startCheckpointId", "章読み通しの開始状態はフロー位置を持たない途中開始です。");
	if (reading.occurrences.length > reading.sceneIds.length) fail("readingPath.occurrences", "実際の提示数が計画した場面数を超えています。");
	const occurrenceIds = /* @__PURE__ */ new Set();
	let expected = checkpoint.runtimeState;
	for (const [index, occurrence] of reading.occurrences.entries()) {
		const current = `readingPath.occurrences[${index}]`;
		if (!occurrence.occurrenceId.trim() || occurrenceIds.has(occurrence.occurrenceId)) fail(`${current}.occurrenceId`, "提示の識別子が空か重複しています。");
		occurrenceIds.add(occurrence.occurrenceId);
		if (occurrence.entityId !== reading.sceneIds[index]) fail(`${current}.entityId`, "提示した場面が計画した場面の順序と一致しません。");
		if (occurrence.before.contentVersionId !== trace.contentVersionId || occurrence.after.contentVersionId !== trace.contentVersionId || occurrence.before.presentationPosition !== null || occurrence.after.presentationPosition !== null) fail(current, "提示状態の内容版またはフロー位置が不正です。");
		if (canonicalJson$1(occurrence.before) !== canonicalJson$1(expected)) fail(`${current}.before`, "提示状態が開始状態または直前の提示とつながりません。", "INTEGRITY_FAILED");
		if (canonicalJson$1(occurrence.externalValues ?? {}) !== canonicalJson$1(trace.initialExternalValues ?? {})) fail(`${current}.externalValues`, "章読み通し中に、記録した外部入力を未記録の操作で変更できません。", "INTEGRITY_FAILED");
		const replay = presentChapterOccurrence(content, occurrence.before, {
			sceneId: occurrence.entityId,
			worldTick: trace.initialWorldTick ?? checkpoint.worldTick ?? void 0,
			previousSceneId: reading.occurrences[index - 1]?.entityId,
			last: index + 1 === reading.sceneIds.length,
			externalValues: occurrence.externalValues ?? trace.initialExternalValues ?? {},
			referenceEntities
		});
		if (!replay.ok) for (const issue of replay.issues) issues.push({
			...issue,
			path: `${path}.${current}.${issue.path}`
		});
		else {
			if (canonicalJson$1(replay.state) !== canonicalJson$1(occurrence.after)) fail(`${current}.after`, "記録した提示後の状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED");
			if (occurrence.presentationState && canonicalJson$1(replay.observationState) !== canonicalJson$1(occurrence.presentationState)) fail(`${current}.presentationState`, "提示前の観測状態と共通エンジンの結果が一致しません。", "INTEGRITY_FAILED");
			if (canonicalJson$1(replay.conditions) !== canonicalJson$1(occurrence.conditionResults)) fail(`${current}.conditionResults`, "提示時の条件根拠が不足・重複・矛盾しています。", "INTEGRITY_FAILED");
		}
		expected = occurrence.after;
	}
	return issues;
}

//#endregion
//#region src/domain/runtime.ts
var runtime_exports = /* @__PURE__ */ __exportAll({
	analyzeFlow: () => analyzeFlow,
	analyzeFlowAsync: () => analyzeFlowAsync,
	backTrial: () => backTrial,
	checkTrialForeshadows: () => checkTrialForeshadows,
	declaredEntrypoints: () => declaredEntrypoints,
	diffRuntimeStates: () => diffRuntimeStates,
	getTrialChoices: () => getTrialChoices,
	getTrialContent: () => getTrialContent,
	getTrialNode: () => getTrialNode,
	pinTrialRecord: () => pinTrialRecord,
	replaySavedTrace: () => replaySavedTrace,
	replayTrial: () => replayTrial,
	restartTrial: () => restartTrial,
	sampleRuntime: () => sampleRuntime,
	setTrialStubValues: () => setTrialStubValues,
	startTrial: () => startTrial,
	stepTrial: () => stepTrial,
	trialCoverage: () => trialCoverage,
	trialCoverageByProvenance: () => trialCoverageByProvenance,
	trialNarrativeOccurrences: () => trialNarrativeOccurrences,
	trialRecordData: () => trialRecordData
});
/** Runtime records cross canonical JSON boundaries; object insertion order is not state. */
function canonicalRuntimeValue(value) {
	if (value === void 0) return "undefined";
	if (value === null || typeof value !== "object") return JSON.stringify(value);
	if (Array.isArray(value)) return `[${value.map(canonicalRuntimeValue).join(",")}]`;
	const record = value;
	return `{${Object.keys(record).filter((key) => record[key] !== void 0).sort().map((key) => `${JSON.stringify(key)}:${canonicalRuntimeValue(record[key])}`).join(",")}}`;
}
function versionContent(project, version) {
	if (version === project.projectId) return project;
	const snapshot = project.snapshots.find((snapshot) => snapshot.id === version);
	return snapshot ? {
		...snapshot.content,
		snapshots: project.snapshots,
		history: []
	} : void 0;
}
function captureContent(project, references = []) {
	const { authorAlternatives: _authorAlternatives, ...branchFree } = project;
	const raw = {
		...clone$1({
			...branchFree,
			history: [],
			snapshots: []
		}),
		snapshots: project.snapshots
	};
	const captured = resolveReuseContent(raw, project.snapshots);
	const index = {
		byId: /* @__PURE__ */ new Map(),
		activeByKind: /* @__PURE__ */ new Map(),
		edgesFrom: /* @__PURE__ */ new Map()
	};
	capturedReferences.set(captured, clone$1(references));
	for (const entity of [...captured.entities, ...capturedReferences.get(captured) ?? []]) {
		if (entity.deletedAt) continue;
		index.byId.set(entity.id, entity);
		if (!adoptedRecord(entity)) continue;
		const kind = index.activeByKind.get(entity.kind) ?? [];
		kind.push(entity);
		index.activeByKind.set(entity.kind, kind);
		if (entity.kind === "flow_edge") {
			const from = index.edgesFrom.get(entity.data.fromId) ?? [];
			from.push(entity);
			index.edgesFrom.set(entity.data.fromId, from);
		}
	}
	capturedIndices.set(captured, index);
	return captured;
}
function getTrialContent(project, session) {
	return session.content ?? versionContent(project, session.state.contentVersionId) ?? project;
}
function getTrialNode(project, session) {
	return findNode(getTrialContent(project, session), session.nodeId);
}
function reuseIssue(node) {
	return node?.data.reuse && node.data.reuse.mode !== "clone" ? issue("VALIDATION_FAILED", "共通元を固定版から解決する参照・上書き試読は未対応です。実行を停止しています。", `${node.id}.reuse`) : void 0;
}
function errorIssues(error) {
	if (error && typeof error === "object" && "issues" in error && Array.isArray(error.issues)) return error.issues;
	return [issue("VALIDATION_FAILED", error instanceof Error ? error.message : "試読の入力を検証できません。")];
}
function declaredEntrypoints(project) {
	project = reuseAuthorContent(project);
	const roots = graphs(project).filter((graph) => graph.projectId === project.projectId && !graph.data.parentGraphId);
	if (roots.length > 0) return [...new Set(roots.flatMap((graph) => graph.data.entryIds))];
	return nodes(project).filter((node) => node.projectId === project.projectId && node.data.nodeType === "entry").map((node) => node.id);
}
function declaredEntry(project) {
	const entries = declaredEntrypoints(project);
	return entries.length === 1 ? entries[0] : void 0;
}
/** Flow and chapter readers use one atomic presentation contract. */
function present(project, state, nodeId, externalValues, worldTick) {
	return presentContent(project, state, {
		nodeId,
		externalValues,
		referenceEntities: capturedReferences.get(project),
		worldTick
	});
}
function getTrialChoices(project, session) {
	try {
		return trialChoicesInternal(project, session);
	} catch {
		return [];
	}
}
function trialChoicesInternal(project, session) {
	const content = session.content ?? versionContent(project, session.state.contentVersionId);
	if (!content) return [];
	project = content;
	const node = findNode(project, session.nodeId);
	if (!node || node.data.nodeType === "terminal") return [];
	const gate = evalAt(project, session.state, node.data.gate, session.externalValues);
	return nodeEdges(project, node.id).map((edge) => {
		const condition = evalAt(project, session.state, edge.data.condition, session.externalValues);
		const result = gate.value === "false" || condition.value === "false" ? "false" : gate.value === "unknown" || condition.value === "unknown" ? "unknown" : "true";
		return {
			edgeId: edge.id,
			label: edge.data.label || edge.name || "次へ",
			toId: typeof edge.data.toId === "string" ? edge.data.toId : null,
			result,
			reasons: [...gate.reasons, ...condition.reasons],
			priority: edge.data.priority ?? 0
		};
	}).sort((a, b) => a.priority - b.priority);
}
function inspect(project, session) {
	const node = findNode(project, session.nodeId);
	if (!node) return resultSession(session, "error", [issue("REFERENCE_INVALID", "現在の分岐が存在しません。")]);
	const unsupportedReuse = reuseIssue(node);
	if (unsupportedReuse) return resultSession(session, "error", [unsupportedReuse]);
	if (node.data.nodeType === "terminal") return node.data.terminalReason?.trim() ? resultSession(session, "terminal", []) : resultSession(session, "error", [issue("VALIDATION_FAILED", "終端には終了理由が必要です。", `${node.id}.terminalReason`)]);
	const gate = evalAt(project, session.state, node.data.gate, session.externalValues);
	if (gate.value === "unknown") return resultSession(session, "unknown", [issue("CONDITION_UNKNOWN", gate.reasons.join("、") || "発火条件の値が不足しています。", `${node.id}.gate`)]);
	if (gate.value === "false") return node.data.fallbackId ? resultSession(session, "ready", []) : resultSession(session, "blocked", [issue("TRANSITION_BLOCKED", "発火条件を満たさず、代替の進行先もありません。", `${node.id}.gate`)]);
	if (node.data.nodeType === "call" || node.data.nodeType === "exit" && session.state.callStack.length > 0) return resultSession(session, "ready", []);
	const policy = node.data.executionPolicy ?? (node.data.nodeType === "automatic" ? "first_match" : "manual_choice");
	const choices = trialChoicesInternal(project, session);
	if (choices.some((choice) => !Number.isSafeInteger(choice.priority))) return resultSession(session, "error", [issue("VALIDATION_FAILED", "優先値には安全な整数が必要です。", `${node.id}.priority`)]);
	if (policy !== "manual_choice" && new Set(choices.map((choice) => choice.priority)).size !== choices.length) return resultSession(session, "error", [issue("VALIDATION_FAILED", "自動分岐の優先値が重複しています。", `${node.id}.priority`)]);
	const unknown = choices.filter((choice) => choice.result === "unknown");
	const enabled = choices.filter((choice) => choice.result === "true");
	if (unknown.length > 0 && (policy !== "manual_choice" || enabled.length === 0)) return resultSession(session, "unknown", [issue("CONDITION_UNKNOWN", "未確認の条件があり、進行先を確定できません。", node.id)]);
	if (enabled.length === 0 && !node.data.fallbackId) return resultSession(session, "blocked", [issue("TRANSITION_BLOCKED", "有効な選択肢がありません。意図した終端とは別の行き止まりです。", node.id)]);
	return resultSession(session, "ready", []);
}
function startTrial(project, options = {}) {
	try {
		return startTrialInternal(project, options);
	} catch (error) {
		const state = options.state ? clone$1(options.state) : emptyRuntimeState(options.contentVersionId ?? project.projectId);
		return {
			content: project,
			state,
			nodeId: state.presentationPosition,
			contentRevision: project.revision,
			startState: clone$1(state),
			startConditionResults: [],
			status: "error",
			history: [],
			trace: [],
			issues: errorIssues(error),
			lastDiff: [],
			externalValues: {},
			startExternalValues: {}
		};
	}
}
function startTrialInternal(project, options = {}, alreadyCaptured = false) {
	const source = project;
	const requestedCheckpoint = options.checkpointId ? source.entities.find((entity) => entity.id === options.checkpointId && entity.kind === "checkpoint") : void 0;
	if (options.worldTick === void 0 && requestedCheckpoint?.data.worldTick != null) options = {
		...options,
		worldTick: requestedCheckpoint.data.worldTick
	};
	const version = options.contentVersionId ?? project.projectId;
	const content = alreadyCaptured ? project : versionContent(project, version);
	if (content) project = content;
	if (!alreadyCaptured) project = captureContent(project, options.referenceEntities);
	let state = initializeRuntimeState(project, version, options.referenceEntities, options.externalValues);
	let startConditionResults = clone$1(options.presentationResults ?? []);
	let startPresentationState = options.presentationState ? clone$1(options.presentationState) : void 0;
	let checkpointId;
	let presentationIssues;
	let pendingPresentation;
	let failure = content && (!project.worldReferences.length || options.referenceEntities) ? void 0 : issue("REFERENCE_INVALID", "指定した不変作品版が見つかりません。", "contentVersionId");
	for (const [id, value] of Object.entries(options.externalValues ?? {})) {
		const contract = project.entities.find((entity) => entity.id === id && entity.kind === "external_contract" && adoptedRecord(entity));
		if (!contract || contract.kind !== "external_contract" || value.type !== contract.data.outputType || value.type === "integer" && !Number.isSafeInteger(value.value) || value.type === "enum" && typeof value.value !== "string" || value.type === "boolean" && typeof value.value !== "boolean") failure = issue("VALIDATION_FAILED", "外部管理値の契約・型・範囲が不正です。", id);
	}
	if (options.worldTick !== void 0 && !isTick(options.worldTick)) failure = issue("VALIDATION_FAILED", "提示時点には整数の世界内tickを入力してください。", "worldTick");
	if (options.checkpointId) {
		const checkpoint = getEntity(source, options.checkpointId);
		if (!checkpoint || checkpoint.kind !== "checkpoint" || checkpoint.deletedAt) failure = issue("REFERENCE_INVALID", "指定した途中開始の記録が存在しません。", "checkpointId");
		else if (checkpoint.data.contentVersionId !== version || checkpoint.data.runtimeState.contentVersionId !== version || checkpoint.data.contentRevision != null && checkpoint.data.contentRevision !== project.revision) failure = issue("VALIDATION_FAILED", "開始状態と作品版が違います。移行または再作成が必要です。", `${checkpoint.id}.contentVersionId`);
		else {
			state = clone$1(checkpoint.data.runtimeState);
			startConditionResults = clone$1(checkpoint.data.presentationResults ?? []);
			startPresentationState = checkpoint.data.presentationState ? clone$1(checkpoint.data.presentationState) : void 0;
			state.provenance = state.provenance === "stub" ? "stub" : state.provenance === "imported" || checkpoint.data.origin === "imported" ? "imported" : state.provenance === "partial" || checkpoint.data.origin !== "full_play" ? "partial" : "full_play";
			checkpointId = checkpoint.id;
			if (checkpoint.data.presentationResults != null) failure = validateInitialPresentationResults(state, checkpoint.data.presentationResults, project.entities, `${checkpoint.id}.presentationResults`)[0];
		}
	} else if (options.state) {
		if (options.state.contentVersionId !== version) failure = issue("VALIDATION_FAILED", "指定した開始状態と作品版が違います。", "state.contentVersionId");
		else {
			state = clone$1(options.state);
			if (options.presentationResults != null) failure = validateInitialPresentationResults(state, options.presentationResults, project.entities)[0];
			if (state.provenance === "full_play") state.provenance = "partial";
		}
	}
	if (options.seed !== void 0) state.rngSeed = options.seed;
	const entry = options.entryId ?? state.presentationPosition ?? declaredEntry(project);
	if (!failure) {
		const shape = validateRuntimeState(state);
		if (!shape.ok) failure = shape.issues[0];
		for (const [id, value] of Object.entries(state.variableValues)) {
			const variable = variables(project).find((variable) => variable.id === id);
			const errors = variable ? validateVariableValue(variable, value, `${id}.value`) : [issue("REFERENCE_INVALID", "開始状態に対象版の宣言がない状態値があります。", id)];
			if (errors.length) {
				failure = errors[0];
				break;
			}
		}
		const ruleContext = presentationRuleContext(project, {
			nodeId: entry ?? void 0,
			worldTick: options.worldTick
		});
		if (!failure) failure = runtimeExclusionIssues({
			state,
			variables: variables(project),
			entities: runtimeEntities(project),
			externalValues: options.externalValues,
			ruleContext,
			ruleContexts: reuseRuleContexts(project, ruleContext)
		})[0];
	}
	if (checkpointId && state.provenance === "full_play") {
		const fresh = entry && declaredEntrypoints(project).includes(entry) ? startTrialInternal(source, {
			contentVersionId: version,
			entryId: entry,
			seed: state.rngSeed,
			externalValues: options.externalValues,
			worldTick: options.worldTick,
			referenceEntities: capturedReferences.get(project)
		}) : void 0;
		if (!fresh || fresh.status === "error" || !sameRuntimeValue(fresh.startState, state)) state.provenance = "partial";
	}
	if (options.entryId && !declaredEntrypoints(project).includes(options.entryId) && !checkpointId) state.provenance = "partial";
	if (!failure && !entry) failure = issue("VALIDATION_FAILED", "開始点が一つに決まりません。入口を指定してください。", "entryId");
	if (!failure && !findNode(project, entry ?? null)) failure = issue("REFERENCE_INVALID", "指定した開始点が存在しません。", "entryId");
	if (!failure) failure = reuseIssue(findNode(project, entry ?? null));
	if (!failure && entry) {
		if ((checkpointId || options.state) && state.presentationPosition && entry !== state.presentationPosition && state.provenance !== "stub") state.provenance = "partial";
		if (!(checkpointId || options.state) || entry !== state.presentationPosition || (state.visitCounts[entry] ?? 0) === 0 && !state.seenIds.includes(entry)) {
			const arrival = present(project, state, entry, options.externalValues, options.worldTick);
			if (arrival.ok) {
				state = arrival.state;
				startConditionResults = arrival.conditions;
				startPresentationState = arrival.observationState;
				const target = findNode(project, entry);
				if (target?.data.nodeType === "terminal") {
					const ended = resetRuntimeLifecycle(state, [
						...target.data.sceneId ? ["scene_end"] : [],
						...presentationRuleContext(project, { nodeId: entry }).chapterId ? ["chapter_end"] : [],
						"run_end"
					], {
						state,
						variables: variables(project),
						entities: runtimeEntities(project),
						ruleContext: presentationRuleContext(project, {
							nodeId: entry,
							worldTick: options.worldTick
						}),
						ruleContexts: reuseRuleContexts(project, presentationRuleContext(project, {
							nodeId: entry,
							worldTick: options.worldTick
						}))
					});
					if (ended.ok) state = ended.state;
					else presentationIssues = ended.issues;
				}
			} else {
				presentationIssues = arrival.issues;
				pendingPresentation = entry;
				state = {
					...state,
					presentationPosition: entry
				};
			}
		} else state.presentationPosition = entry;
		if (options.entryId && !declaredEntrypoints(project).includes(options.entryId) && !checkpointId) state.provenance = "partial";
	}
	if (startPresentationState) startPresentationState.provenance = state.provenance;
	const session = {
		content: project,
		referenceEntities: clone$1(capturedReferences.get(project) ?? []),
		initialWorldTick: options.worldTick,
		declarationProject: clone$1({
			...source,
			history: [],
			snapshots: [],
			authorAlternatives: void 0,
			entities: source.entities.filter((entity) => [
				"collection",
				"trace",
				"checkpoint"
			].includes(entity.kind))
		}),
		state,
		nodeId: state.presentationPosition,
		contentRevision: project.revision,
		startState: clone$1(state),
		startConditionResults,
		startPresentationState,
		startCheckpointId: checkpointId,
		status: "ready",
		history: [],
		trace: [],
		issues: [],
		lastDiff: [],
		externalValues: clone$1(options.externalValues ?? {}),
		startExternalValues: clone$1(options.externalValues ?? {}),
		pendingPresentation
	};
	if (failure) return resultSession(session, failure.code === "CONDITION_UNKNOWN" ? "unknown" : "error", [failure]);
	if (options.stub) {
		const stub = setTrialStubValues(project, session, options.stub);
		const observation = stub.trace.at(-1)?.presentationState ?? startPresentationState;
		return {
			...stub,
			history: [],
			trace: [],
			startState: clone$1(stub.state),
			startStubValues: clone$1(options.stub),
			...options.state || options.checkpointId ? { startStubBaseState: clone$1(session.state) } : {},
			startPresentationState: observation ? {
				...clone$1(observation),
				provenance: stub.state.provenance
			} : void 0,
			startConditionResults: stub.trace.at(-1)?.conditionResults.length ? clone$1(stub.trace.at(-1).conditionResults) : startConditionResults,
			startExternalValues: clone$1(stub.externalValues)
		};
	}
	if (presentationIssues) return resultSession(session, presentationIssues.some((value) => value.code === "CONDITION_UNKNOWN") ? "unknown" : "error", presentationIssues);
	return inspect(project, session);
}
/** All RuntimeState fields participate in comparisons, including stack and random position. */
function diffRuntimeStates(before, after) {
	const changes = [];
	for (const key of /* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)])) {
		const a = before[key];
		const b = after[key];
		if (sameRuntimeValue(a, b)) continue;
		if ((key === "variableValues" || key === "visitCounts") && a && b) {
			const first = a;
			const second = b;
			for (const id of /* @__PURE__ */ new Set([...Object.keys(first), ...Object.keys(second)])) if (!sameRuntimeValue(first[id], second[id])) changes.push({
				path: `${key}.${id}`,
				before: clone$1(first[id]),
				after: clone$1(second[id])
			});
		} else changes.push({
			path: key,
			before: clone$1(a),
			after: clone$1(b)
		});
	}
	return changes;
}
/** The seed and cursor alone determine this sample. No global randomness is used. */
function sampleRuntime(state, length) {
	if (!Number.isSafeInteger(length) || length <= 0) throw new RangeError("抽選候補は1件以上必要です。");
	if (!Number.isSafeInteger(state.rngPosition) || state.rngPosition < 0 || !Number.isSafeInteger(state.rngPosition + 1)) throw new RangeError("抽選位置が許容範囲を超えます。");
	let hash = 2166136261;
	const input = `${state.rngSeed}\u0000${state.rngPosition}`;
	for (let i = 0; i < input.length; i++) hash = Math.imul(hash ^ input.charCodeAt(i), 16777619) >>> 0;
	hash ^= hash >>> 16;
	hash = Math.imul(hash, 2246822507) >>> 0;
	hash ^= hash >>> 13;
	return {
		index: (hash >>> 0) % length,
		state: {
			...clone$1(state),
			rngPosition: state.rngPosition + 1
		}
	};
}
function triggerKeys(node, state, request) {
	const trigger = node.data.trigger;
	if (!trigger) return {
		once: void 0,
		occurrence: void 0
	};
	const id = trigger.id ?? node.id;
	const scope = trigger.scope ?? "run";
	const scopeKey = scope === "across_runs" ? scope : `${scope}:${state.loopNumber}`;
	return {
		once: trigger.repeat === "once" ? `trigger:${scopeKey}:${id}` : void 0,
		occurrence: request.event ? `occurrence:${scopeKey}:${id}:${request.event.occurrenceId}` : void 0
	};
}
function checkTrigger(project, node, state, request) {
	const trigger = node.data.trigger;
	if (!trigger) return void 0;
	const keys = triggerKeys(node, state, request);
	if (keys.once && state.onceTriggers.includes(keys.once)) return issue("TRANSITION_BLOCKED", "この一回限りの発火は実行済みです。", `${node.id}.trigger`);
	if (!request.event || request.event.event !== trigger.event || request.event.eventKey !== trigger.eventKey || request.event.triggerId && request.event.triggerId !== (trigger.id ?? node.id)) return issue("TRANSITION_BLOCKED", "宣言したきっかけの入力が必要です。条件の成立だけでは実行しません。", `${node.id}.trigger`);
	if (trigger.deadline) {
		const resolved = resolveTime(trigger.deadline, activeKind(project, "event"));
		if (resolved.status === "conflict") return issue("TIME_CONSTRAINT_CONFLICT", resolved.reason, `${node.id}.trigger.deadline`);
		if (resolved.status !== "resolved" || !isTick(request.worldTick) || resolved.calendarId !== project.calendarId) return issue("CONDITION_UNKNOWN", "期限または現在の世界時点を確定できません。", `${node.id}.trigger.deadline`);
		const current = BigInt(request.worldTick), earliest = BigInt(resolved.endEarliest), latest = BigInt(resolved.endLatest);
		if (current > latest || trigger.deadline.mode === "interval" && current === latest) return issue("TRANSITION_BLOCKED", "発火期限を過ぎています。", `${node.id}.trigger.deadline`);
		if (current > earliest) return issue("CONDITION_UNKNOWN", "期限の範囲内に現在時点があり、期限切れか確定できません。", `${node.id}.trigger.deadline`);
	}
}
function observations(project, session, node) {
	const result = [];
	if (node.data.gate) result.push({
		targetId: node.id,
		...evalAt(project, session.state, node.data.gate, session.externalValues)
	});
	for (const edge of nodeEdges(project, node.id)) if (edge.data.condition) result.push({
		targetId: edge.id,
		...evalAt(project, session.state, edge.data.condition, session.externalValues)
	});
	return result;
}
function commitStep(project, session, next, toId, selected, request, conditions) {
	const from = findNode(project, session.nodeId), to = findNode(project, toId);
	const fromScope = presentationRuleContext(project, { nodeId: from?.id }), toScope = presentationRuleContext(project, { nodeId: toId });
	const events = [];
	if (from?.data.sceneId && from.data.sceneId !== to?.data.sceneId) events.push("scene_end");
	if (fromScope.chapterId && fromScope.chapterId !== toScope.chapterId) events.push("chapter_end");
	const reset = resetRuntimeLifecycle({
		...next,
		...next.resetCauses ? { resetCauses: [] } : {}
	}, events, {
		state: next,
		variables: variables(project),
		entities: runtimeEntities(project),
		externalValues: session.externalValues,
		ruleContext: presentationRuleContext(project, {
			nodeId: from?.id,
			worldTick: request.worldTick
		}),
		ruleContexts: reuseRuleContexts(project, presentationRuleContext(project, {
			nodeId: from?.id,
			worldTick: request.worldTick
		}))
	});
	if (!reset.ok) return resultSession(session, "error", reset.issues);
	const arrival = present(project, reset.state, toId, session.externalValues, request.worldTick);
	if (!arrival.ok) return resultSession(session, arrival.issues.some((value) => value.code === "CONDITION_UNKNOWN") ? "unknown" : "error", arrival.issues);
	const ending = [];
	if (to?.data.nodeType === "terminal") {
		if (to.data.sceneId) ending.push("scene_end");
		if (toScope.chapterId) ending.push("chapter_end");
		ending.push("run_end");
	}
	const endReset = resetRuntimeLifecycle(arrival.state, ending, {
		state: arrival.state,
		variables: variables(project),
		entities: runtimeEntities(project),
		externalValues: session.externalValues,
		ruleContext: presentationRuleContext(project, {
			nodeId: toId,
			worldTick: request.worldTick
		}),
		ruleContexts: reuseRuleContexts(project, presentationRuleContext(project, {
			nodeId: toId,
			worldTick: request.worldTick
		}))
	});
	if (!endReset.ok) return resultSession(session, "error", endReset.issues);
	const state = endReset.state;
	if (to?.data.nodeType === "terminal" && (reset.state.resetCauses || endReset.state.resetCauses)) state.resetCauses = [...reset.state.resetCauses ?? [], ...endReset.state.resetCauses ?? []];
	conditions = [...conditions, ...arrival.conditions];
	const changes = diffRuntimeStates(session.state, state).map((change) => ({
		...change,
		edgeIds: selected
	}));
	const traceStep = {
		fromId: session.nodeId,
		toId,
		edgeIds: selected,
		before: clone$1(session.state),
		after: clone$1(state),
		changes,
		request: clone$1(request),
		conditionResults: conditions,
		presentationState: arrival.observationState,
		triggerId: findNode(project, session.nodeId)?.data.trigger?.id ?? (findNode(project, session.nodeId)?.data.trigger ? session.nodeId : void 0),
		externalValuesBefore: clone$1(session.externalValues),
		externalValuesAfter: clone$1(session.externalValues)
	};
	return inspect(project, {
		...session,
		state,
		nodeId: toId,
		status: "ready",
		issues: [],
		lastDiff: changes,
		history: [...session.history, {
			state: clone$1(session.state),
			status: session.status,
			issues: clone$1(session.issues),
			lastDiff: clone$1(session.lastDiff),
			traceLength: session.trace.length,
			externalValues: clone$1(session.externalValues),
			pendingPresentation: session.pendingPresentation
		}],
		trace: [...session.trace, traceStep]
	});
}
function stepTrial(project, session, request = {}) {
	if (session.status === "error" && session.nodeId === null) return session;
	try {
		return stepTrialInternal(project, session, request);
	} catch (error) {
		return resultSession(session, "error", errorIssues(error));
	}
}
function stepTrialInternal(project, session, request = {}) {
	if (request.stub) return setTrialStubValues(project, session, request.stub);
	const content = versionContent(project, session.state.contentVersionId);
	if (!content) return resultSession(session, "error", [issue("REFERENCE_INVALID", "固定した作品版が存在しません。", "contentVersionId")]);
	project = content;
	if (session.contentRevision !== project.revision) return resultSession(session, "error", [issue("VALIDATION_FAILED", "作品が変更されました。この記録は再確認待ちです。試読を開始し直してください。", "contentRevision")]);
	project = session.content;
	if (session.pendingPresentation) return resultSession(session, "unknown", session.issues.length ? session.issues : [issue("CONDITION_UNKNOWN", "場面の提示条件を先に確認してください。", session.pendingPresentation)]);
	if (session.state.contentVersionId !== session.startState.contentVersionId) return resultSession(session, "error", [issue("VALIDATION_FAILED", "試読中に作品版が変わりました。", "contentVersionId")]);
	const eventTriggerId = request.event?.triggerId ?? findNode(project, session.nodeId)?.data.trigger?.id ?? (findNode(project, session.nodeId)?.data.trigger ? session.nodeId : void 0);
	if (request.event && eventTriggerId && session.trace.some((step) => step.triggerId === eventTriggerId && step.request.event?.occurrenceId === request.event?.occurrenceId)) return session;
	const triggerNode = findNode(project, session.nodeId);
	if (triggerNode && request.event) {
		const occurrence = triggerKeys(triggerNode, session.state, request).occurrence;
		if (occurrence && session.state.onceTriggers.includes(occurrence)) return session;
	}
	const current = inspect(project, session);
	if (current.status !== "ready") return current;
	const node = findNode(project, session.nodeId);
	const triggerProblem = checkTrigger(project, node, session.state, request);
	if (triggerProblem) return resultSession(session, triggerProblem.code === "CONDITION_UNKNOWN" ? "unknown" : triggerProblem.code === "TIME_CONSTRAINT_CONFLICT" ? "error" : "blocked", [triggerProblem]);
	const gate = evalAt(project, session.state, node.data.gate, session.externalValues);
	const conditions = observations(project, session, node);
	let next = clone$1(session.state);
	let selected = [];
	let toId;
	if (gate.value === "false") toId = node.data.fallbackId ?? void 0;
	else if (node.data.nodeType === "exit" && next.callStack.length > 0) {
		const child = getEntity(project, next.callStack.at(-1).graphId);
		if (!child || child.kind !== "flow_graph" || !child.data.exitIds.includes(node.id)) return resultSession(session, "error", [issue("REFERENCE_INVALID", "現在の出口が呼出中グラフの宣言した出口に含まれていません。", node.id)]);
		toId = next.callStack.pop().returnNodeId;
	} else if (node.data.nodeType === "call") {
		const child = node.data.childGraphId ? getEntity(project, node.data.childGraphId) : void 0;
		if (!child || child.kind !== "flow_graph" || child.data.entryIds.length !== 1) return resultSession(session, "error", [issue("REFERENCE_INVALID", "呼出先に一つの入口を持つ子グラフが必要です。", `${node.id}.childGraphId`)]);
		const returns = nodeEdges(project, node.id).filter((edge) => edge.data.edgeType === "call_return");
		if (returns.length !== 1 || typeof returns[0].data.toId !== "string") return resultSession(session, "error", [issue("REFERENCE_INVALID", "呼出には一つの確定した戻り先が必要です。", node.id)]);
		const returnCondition = evalAt(project, session.state, returns[0].data.condition, session.externalValues);
		if (returnCondition.value === "unknown") return resultSession(session, "unknown", [issue("CONDITION_UNKNOWN", returnCondition.reasons.join("、") || "呼出の戻り先条件が未確認です。", returns[0].id)]);
		if (returnCondition.value === "false") {
			if (!node.data.fallbackId) return resultSession(session, "blocked", [issue("TRANSITION_BLOCKED", "呼出の戻り先条件を満たしていません。", returns[0].id)]);
			toId = node.data.fallbackId;
		} else {
			selected = returns;
			toId = child.data.entryIds[0];
			const parameters = {};
			for (const parameter of child.data.parameters ?? []) parameters[parameter.key] = clone$1(parameter.default ?? {
				type: "unknown",
				value: null,
				reason: "呼出引数が未設定です。"
			});
			next.callStack.push({
				graphId: child.id,
				returnNodeId: returns[0].data.toId,
				parameters
			});
		}
	} else {
		const policy = node.data.executionPolicy ?? (node.data.nodeType === "automatic" ? "first_match" : "manual_choice");
		const choices = getTrialChoices(project, session);
		const enabled = choices.filter((choice) => choice.result === "true");
		if (enabled.length === 0) toId = node.data.fallbackId ?? void 0;
		else if (policy === "manual_choice") {
			let choice;
			if (request.random) {
				if (choices.some((candidate) => candidate.result === "unknown")) return resultSession(session, "unknown", [issue("CONDITION_UNKNOWN", "未確認の抽選候補が残っています。", node.id)]);
				let sample;
				try {
					sample = sampleRuntime(next, enabled.length);
				} catch {
					return resultSession(session, "error", [issue("TRANSITION_BLOCKED", "抽選位置が許容範囲を超えます。", "rngPosition")]);
				}
				next = sample.state;
				choice = enabled[sample.index];
			} else choice = choices.find((candidate) => candidate.edgeId === request.edgeId);
			if (!choice) return resultSession(session, "blocked", [issue("TRANSITION_BLOCKED", "進む選択肢を指定してください。", node.id)]);
			if (choice.result !== "true") return resultSession(session, choice.result === "unknown" ? "unknown" : "blocked", [issue(choice.result === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED", choice.reasons.join("、") || "この選択肢の条件は成立していません。", choice.edgeId)]);
			selected = nodeEdges(project, node.id).filter((edge) => edge.id === choice.edgeId);
		} else selected = (policy === "first_match" ? enabled.slice(0, 1) : enabled).map((choice) => choice.edgeId).map((id) => nodeEdges(project, node.id).find((edge) => edge.id === id));
		if (selected.length > 0) {
			if (new Set(selected.map((edge) => typeof edge.data.toId === "string" ? edge.data.toId : null)).size !== 1) return resultSession(session, "error", [issue("VALIDATION_FAILED", "all_matchの進行先が異なります。同じ進行先を指定してください。", node.id)]);
			const target = selected[0].data.toId;
			if (typeof target === "string") toId = target;
		}
	}
	if (!toId || !findNode(project, toId)) return resultSession(session, "error", [issue("REFERENCE_INVALID", "進行先が未完成、または存在しません。", node.id)]);
	const unsupportedTarget = reuseIssue(findNode(project, toId));
	if (unsupportedTarget) return resultSession(session, "error", [unsupportedTarget]);
	const effects = [];
	for (const edge of selected) for (const effectId of edge.data.effectIds ?? []) {
		const effect = getEntity(project, effectId);
		if (!effect || effect.kind !== "effect" || effect.deletedAt || effect.status === "rejected") return resultSession(session, "error", [issue("REFERENCE_INVALID", effect?.status === "rejected" ? "分岐に不採用の効果が指定されています。" : "分岐に指定した効果が存在しないか、削除済みです。", `${edge.id}.effectIds`)]);
		effects.push(effect);
	}
	const applied = applyEffectsAtomic(next, effects, {
		state: next,
		variables: variables(project),
		entities: runtimeEntities(project),
		externalValues: session.externalValues,
		ruleContext: presentationRuleContext(project, {
			nodeId: node.id,
			worldTick: request.worldTick
		}),
		ruleContexts: reuseRuleContexts(project, presentationRuleContext(project, {
			nodeId: node.id,
			worldTick: request.worldTick
		}))
	});
	if (!applied.ok) return resultSession(session, applied.issues.some((value) => value.code === "CONDITION_UNKNOWN") ? "unknown" : "error", applied.issues);
	next = applied.state;
	const keys = triggerKeys(node, session.state, request);
	next.onceTriggers = [.../* @__PURE__ */ new Set([...next.onceTriggers, ...[keys.once, keys.occurrence].filter((key) => key !== void 0)])];
	return commitStep(project, current, next, toId, selected.map((edge) => edge.id), request, conditions);
}
function backTrial(session) {
	const previous = session.history.at(-1);
	if (!previous) return session;
	return {
		...session,
		state: clone$1(previous.state),
		nodeId: previous.state.presentationPosition,
		status: previous.status,
		issues: clone$1(previous.issues),
		lastDiff: clone$1(previous.lastDiff),
		externalValues: clone$1(previous.externalValues),
		pendingPresentation: previous.pendingPresentation,
		history: session.history.slice(0, -1),
		trace: session.trace.slice(0, previous.traceLength)
	};
}
/** Explicit author assumptions form stub evidence and can be undone with the same Back action. */
function setTrialStubValues(project, session, values) {
	try {
		return setTrialStubValuesInternal(project, session, values);
	} catch (error) {
		return resultSession(session, "error", errorIssues(error));
	}
}
function setTrialStubValuesInternal(project, session, values) {
	const content = versionContent(project, session.state.contentVersionId);
	if (!content || content.revision !== session.contentRevision) return resultSession(session, "error", [issue("VALIDATION_FAILED", "作品版が変わりました。仮値を適用する前に開始し直してください。", "contentRevision")]);
	project = session.content;
	const external = clone$1(session.externalValues);
	for (const [id, value] of Object.entries(values.external ?? {})) {
		const contract = getEntity(project, id);
		if (!contract || contract.kind !== "external_contract") return resultSession(session, "error", [issue("REFERENCE_INVALID", "仮の外部値には宣言した外部契約が必要です。", id)]);
		if (contract.data.outputType !== value.type && value.type !== "unknown") return resultSession(session, "error", [issue("VALIDATION_FAILED", "仮の外部値と宣言した出力型が違います。", id)]);
		external[id] = clone$1(value);
	}
	const effects = Object.entries(values.variables ?? {}).map(([targetId, value]) => ({
		operation: "set",
		targetId,
		value
	}));
	const applied = applyEffectsAtomic(session.state, effects, {
		state: session.state,
		variables: variables(project),
		entities: runtimeEntities(project),
		externalValues: external
	});
	if (!applied.ok) return resultSession(session, applied.issues.some((value) => value.code === "CONDITION_UNKNOWN") ? "unknown" : "error", applied.issues);
	let state = {
		...applied.state,
		provenance: "stub"
	};
	let pendingPresentation = session.pendingPresentation;
	let presentationConditions = [];
	let presentationState;
	if (pendingPresentation) {
		const arrival = present(project, state, pendingPresentation, external, session.initialWorldTick);
		if (!arrival.ok) return resultSession(session, arrival.issues.some((value) => value.code === "CONDITION_UNKNOWN") ? "unknown" : "error", arrival.issues);
		state = {
			...arrival.state,
			provenance: "stub"
		};
		presentationConditions = arrival.conditions;
		presentationState = arrival.observationState;
		pendingPresentation = void 0;
	}
	const changes = diffRuntimeStates(session.state, state);
	for (const id of /* @__PURE__ */ new Set([...Object.keys(session.externalValues), ...Object.keys(external)])) if (!sameRuntimeValue(session.externalValues[id], external[id])) changes.push({
		path: `externalValues.${id}`,
		before: clone$1(session.externalValues[id]),
		after: clone$1(external[id])
	});
	const next = {
		...session,
		state,
		externalValues: external,
		issues: [],
		lastDiff: changes,
		pendingPresentation,
		history: [...session.history, {
			state: clone$1(session.state),
			externalValues: clone$1(session.externalValues),
			status: session.status,
			issues: clone$1(session.issues),
			lastDiff: clone$1(session.lastDiff),
			traceLength: session.trace.length,
			pendingPresentation: session.pendingPresentation
		}],
		trace: [...session.trace, {
			fromId: session.nodeId,
			toId: session.nodeId,
			edgeIds: [],
			before: clone$1(session.state),
			after: clone$1(state),
			conditionResults: presentationConditions,
			...presentationState ? { presentationState } : {},
			changes,
			request: { stub: clone$1(values) },
			externalValuesBefore: clone$1(session.externalValues),
			externalValuesAfter: clone$1(external)
		}]
	};
	return inspect(project, next);
}
/** New run and total reset are separate explicit operations. */
function restartTrial(project, session, mode, entryId, contextOptions) {
	const content = getTrialContent(project, session);
	const context = {
		state: session.state,
		variables: variables(content),
		entities: runtimeEntities(content),
		externalValues: session.externalValues,
		ruleContext: presentationRuleContext(content, {
			nodeId: session.nodeId ?? void 0,
			worldTick: contextOptions ? contextOptions.worldTick : session.initialWorldTick
		}),
		ruleContexts: reuseRuleContexts(content, presentationRuleContext(content, {
			nodeId: session.nodeId ?? void 0,
			worldTick: contextOptions ? contextOptions.worldTick : session.initialWorldTick
		}))
	};
	const reset = resetRuntimeLifecycle(session.state, mode === "next_run" ? ["run_end", "new_loop"] : ["full_reset"], context);
	if (!reset.ok) return resultSession(session, reset.issues.some((value) => value.code === "CONDITION_UNKNOWN") ? "unknown" : "error", reset.issues);
	const initial = initializeRuntimeState(content, session.state.contentVersionId, session.referenceEntities, session.startExternalValues);
	initial.variableValues = reset.state.variableValues;
	if (reset.state.resetCauses) initial.resetCauses = reset.state.resetCauses;
	if (mode === "next_run") {
		initial.onceTriggers = session.state.onceTriggers.filter((key) => key.startsWith("trigger:across_runs:") || key.startsWith("occurrence:across_runs:"));
		initial.loopNumber = session.state.loopNumber + 1;
	}
	initial.rngSeed = session.state.rngSeed;
	initial.provenance = session.state.provenance;
	const restarted = startTrial(project, {
		state: initial,
		contentVersionId: initial.contentVersionId,
		entryId,
		externalValues: session.startExternalValues,
		referenceEntities: session.referenceEntities,
		worldTick: contextOptions ? contextOptions.worldTick : session.initialWorldTick
	});
	restarted.state.provenance = initial.provenance;
	restarted.startState.provenance = initial.provenance;
	return restarted;
}
function trialCoverage(project, sessions) {
	const trials = Array.isArray(sessions) ? sessions : [sessions];
	if (new Set(trials.map((trial) => `${trial.state.contentVersionId}:${trial.contentRevision}:${trial.state.provenance}`)).size > 1) throw new RangeError("版・開始由来・stubの異なる証跡は別々に集計してください。");
	project = trials[0]?.content ?? project;
	const seen = new Set(trials.flatMap((trial) => trial.state.seenIds));
	const traversed = new Set(trials.flatMap((trial) => trial.trace.flatMap((step) => step.edgeIds)));
	const observed = trialObservations(trials);
	const provenance = trials[0]?.state.provenance ?? "full_play";
	return coverageFromEvidence(project, seen, traversed, observed, provenance);
}
function trialObservations(trials) {
	const result = trials.flatMap((trial) => trial.trace.flatMap((step) => step.conditionResults));
	for (const trial of trials) {
		const node = findNode(trial.content, trial.nodeId);
		if (!node || trial.status === "error") continue;
		try {
			result.push(...observations(trial.content, trial, node));
		} catch {}
	}
	return result;
}
function trialCoverageByProvenance(project, sessions) {
	const result = {};
	for (const provenance of [
		"full_play",
		"partial",
		"imported",
		"stub"
	]) {
		const matching = sessions.filter((session) => session.state.provenance === provenance);
		if (matching.length > 0) result[provenance] = trialCoverage(project, matching);
	}
	return result;
}
function coverageFromEvidence(project, seen, traversed, observed, provenance) {
	const conditionTargets = [...nodes(project).filter((node) => node.data.gate).map((node) => node.id), ...edges(project).filter((edge) => edge.data.condition).map((edge) => edge.id)];
	const targets = new Set(conditionTargets);
	observed = observed.filter((result) => targets.has(result.targetId));
	const conditionIds = new Set(observed.filter((result) => result.value !== "unknown").map((result) => `${result.targetId}:${result.value}`));
	const metric = (kind, selected, predicate) => {
		const all = getEntitiesByKind(project, kind).filter((entity) => !entity.deletedAt && (!predicate || predicate(entity)));
		const eligible = active(all);
		const ids = eligible.filter((entity) => selected.has(entity.id)).map((entity) => entity.id);
		return {
			reached: ids.length,
			total: eligible.length,
			ids,
			excluded: all.length - eligible.length,
			unknown: 0
		};
	};
	return {
		scenes: metric("scene", seen),
		dialogue: metric("dialogue_line", seen),
		choices: metric("flow_edge", traversed, (entity) => entity.kind === "flow_edge" && entity.data.edgeType === "choice"),
		conditions: {
			reached: conditionIds.size,
			total: conditionTargets.length * 2,
			ids: [...conditionIds],
			excluded: 0,
			unknown: new Set(observed.filter((result) => result.value === "unknown").map((result) => result.targetId)).size
		},
		provenance,
		scope: "指定した作品版の場面、台詞、choice edge、明示gate/edge条件の真偽。途中開始とstubは別集計が必要です。"
	};
}
function replayTrial(project, recorded) {
	const content = versionContent(project, recorded.state.contentVersionId);
	if (!content || recorded.contentRevision !== content.revision) return resultSession(recorded, "error", [issue("VALIDATION_FAILED", "記録後に作品が変更されました。再確認が必要です。", "contentRevision")]);
	let replay = startTrial(project, {
		state: recorded.startState,
		contentVersionId: recorded.startState.contentVersionId,
		referenceEntities: recorded.referenceEntities,
		worldTick: recorded.initialWorldTick,
		presentationState: recorded.startPresentationState,
		...recorded.startConditionResults.length ? { presentationResults: recorded.startConditionResults } : {}
	});
	replay.state.provenance = recorded.startState.provenance;
	replay.startState.provenance = recorded.startState.provenance;
	replay.externalValues = clone$1(recorded.startExternalValues);
	replay.startExternalValues = clone$1(recorded.startExternalValues);
	replay.startStubValues = recorded.startStubValues ? clone$1(recorded.startStubValues) : void 0;
	replay.startStubBaseState = recorded.startStubBaseState ? clone$1(recorded.startStubBaseState) : void 0;
	for (const step of recorded.trace) {
		replay = stepTrial(project, replay, step.request);
		if (replay.status === "error") return replay;
		if (!sameRuntimeValue(replay.state, step.after)) return resultSession(replay, "error", [issue("VALIDATION_FAILED", "経路記録と再実行の状態が一致しません。", step.fromId)]);
	}
	return replay;
}
function replaySavedTrace(project, traceId, referenceEntities) {
	const trace = getEntity(project, traceId);
	if (!trace || trace.kind !== "trace") return resultSession(startTrial(project), "error", [issue("REFERENCE_INVALID", "保存した経路記録が存在しません。", traceId)]);
	let replay = startTrial(project, {
		checkpointId: trace.data.startCheckpointId,
		contentVersionId: trace.data.contentVersionId,
		referenceEntities,
		worldTick: trace.data.initialWorldTick ?? void 0
	});
	const content = getTrialContent(project, replay);
	if (trace.data.contentRevision != null && trace.data.contentRevision !== content.revision) return resultSession(replay, "error", [issue("VALIDATION_FAILED", "経路記録の作品版が変更されました。再確認が必要です。", `${traceId}.contentRevision`)]);
	if (replay.status === "error") return replay;
	const checkpoint = project.entities.find((entity) => entity.id === trace.data.startCheckpointId && entity.kind === "checkpoint");
	if (trace.data.initialWorldTick != null && checkpoint?.data.worldTick != null && trace.data.initialWorldTick !== checkpoint.data.worldTick) return resultSession(replay, "error", [issue("INTEGRITY_FAILED", "保存した開始時点と経路の初期提示時点が一致しません。", `${traceId}.initialWorldTick`)]);
	if (trace.data.initialStubValues) {
		const fresh = startTrial(project, {
			...trace.data.initialStubBaseState ? { state: clone$1(trace.data.initialStubBaseState) } : {},
			entryId: replay.startState.presentationPosition ?? void 0,
			contentVersionId: trace.data.contentVersionId,
			referenceEntities,
			seed: replay.startState.rngSeed,
			worldTick: trace.data.initialWorldTick ?? checkpoint?.data.worldTick ?? void 0,
			stub: clone$1(trace.data.initialStubValues)
		});
		if (fresh.status === "error" || !sameRuntimeValue(fresh.startState, replay.startState) || !sameRuntimeValue(fresh.startExternalValues, trace.data.initialExternalValues ?? {})) return resultSession(replay, "error", [issue("INTEGRITY_FAILED", "保存した初期stub入力と固定版の開始状態が一致しません。", `${traceId}.initialStubValues`)]);
	}
	replay.externalValues = clone$1(trace.data.initialExternalValues ?? {});
	replay.startExternalValues = clone$1(replay.externalValues);
	replay.startStubValues = trace.data.initialStubValues ? clone$1(trace.data.initialStubValues) : void 0;
	replay.startStubBaseState = trace.data.initialStubBaseState ? clone$1(trace.data.initialStubBaseState) : void 0;
	for (const [index, step] of trace.data.steps.entries()) {
		if (!sameRuntimeValue(replay.state, step.before)) return resultSession(replay, "error", [issue("VALIDATION_FAILED", "保存した開始状態と経路の直前状態が一致しません。", `${traceId}.steps[${index}].before`)]);
		let request = {};
		if (step.operation === "stub" || step.operation === void 0 && step.edgeIds.length === 0 && step.before.presentationPosition === step.after.presentationPosition && sameRuntimeValue(step.before.visitCounts, step.after.visitCounts) && step.after.provenance === "stub") {
			const changed = {};
			for (const variable of variables(content)) if (!variable.data.derived && !sameRuntimeValue(step.before.variableValues[variable.id], step.after.variableValues[variable.id])) changed[variable.id] = clone$1(step.after.variableValues[variable.id]);
			request = { stub: {
				variables: changed,
				external: step.externalValues ?? replay.externalValues
			} };
		} else {
			replay.externalValues = clone$1(step.externalValues ?? replay.externalValues);
			const node = findNode(content, replay.nodeId);
			request.edgeId = step.edgeIds[0];
			if (step.after.rngPosition === step.before.rngPosition + 1) request.random = true;
			if (node?.data.trigger) request.event = {
				triggerId: node.data.trigger.id ?? node.id,
				event: node.data.trigger.event,
				eventKey: node.data.trigger.eventKey,
				occurrenceId: step.occurrenceId ?? `replay:${index}`
			};
			request.worldTick = step.worldTick;
		}
		replay = stepTrial(project, replay, request);
		if (replay.status === "error") return replay;
		if (step.conditionResults && !sameRuntimeValue(replay.trace.at(-1)?.conditionResults, step.conditionResults)) return resultSession(replay, "error", [issue("VALIDATION_FAILED", "保存した提示時の条件結果と再実行が一致しません。", `${traceId}.steps[${index}].conditionResults`)]);
		if (step.presentationState && !sameRuntimeValue(step.presentationState, replay.trace.at(-1)?.presentationState)) return resultSession(replay, "error", [issue("INTEGRITY_FAILED", "保存した提示前の観測状態と再実行が一致しません。", `${traceId}.steps[${index}].presentationState`)]);
		if (!sameRuntimeValue(replay.state, step.after)) return resultSession(replay, "error", [issue("VALIDATION_FAILED", "保存した経路と再実行の状態が一致しません。", `${traceId}.steps[${index}].after`)]);
	}
	return replay;
}
/** Data for a single author save command; the caller assigns a new checkpoint/trace ID. */
function trialRecordData(project, session, checkpointId, pinnedVersionId) {
	const coverage = trialCoverage(project, session);
	const flowConditions = /* @__PURE__ */ new Set([...nodes(session.content).filter((node) => node.data.gate).map((node) => node.id), ...edges(session.content).filter((edge) => edge.data.condition).map((edge) => edge.id)]);
	const observed = trialObservations([session]).filter((result) => flowConditions.has(result.targetId));
	const denominator = coverage.conditions.total / 2;
	const count = (value) => new Set(observed.filter((result) => result.value === value).map((result) => result.targetId)).size;
	const version = pinnedVersionId ?? session.state.contentVersionId;
	const stateForRecord = (state) => ({
		...clone$1(state),
		contentVersionId: version
	});
	const record = {
		checkpoint: {
			contentVersionId: version,
			contentRevision: session.contentRevision,
			runtimeState: stateForRecord(session.startState),
			...session.startConditionResults.length ? { presentationResults: clone$1(session.startConditionResults) } : {},
			...session.startPresentationState ? { presentationState: stateForRecord(session.startPresentationState) } : {},
			...session.initialWorldTick !== void 0 ? { worldTick: session.initialWorldTick } : {},
			origin: session.startState.provenance === "stub" ? "partial" : session.startState.provenance
		},
		trace: {
			contentVersionId: version,
			startCheckpointId: pinnedVersionId ? checkpointId : session.startCheckpointId ?? checkpointId,
			contentRevision: session.contentRevision,
			initialExternalValues: clone$1(session.startExternalValues),
			...session.startStubValues ? { initialStubValues: clone$1(session.startStubValues) } : {},
			...session.startStubBaseState ? { initialStubBaseState: stateForRecord(session.startStubBaseState) } : {},
			...session.initialWorldTick !== void 0 ? { initialWorldTick: session.initialWorldTick } : {},
			seed: session.startState.rngSeed,
			engineVersion: "1.0.0",
			externalMode: session.state.provenance === "stub" ? "stub" : null,
			steps: session.trace.map((step) => ({
				nodeId: step.fromId,
				edgeIds: [...step.edgeIds],
				before: stateForRecord(step.before),
				after: stateForRecord(step.after),
				conditionResults: clone$1(step.conditionResults),
				...step.presentationState ? { presentationState: stateForRecord(step.presentationState) } : {},
				operation: step.request.stub ? "stub" : "advance",
				externalValues: clone$1(step.externalValuesAfter),
				...step.request.worldTick ? { worldTick: step.request.worldTick } : {},
				...step.request.event ? { occurrenceId: step.request.event.occurrenceId } : {},
				...step.after.provenance === "stub" ? { externalMode: "stub" } : {}
			})),
			coverage: {
				scenes: {
					checked: coverage.scenes.reached,
					total: coverage.scenes.total,
					excluded: coverage.scenes.excluded
				},
				dialogue: {
					checked: coverage.dialogue.reached,
					total: coverage.dialogue.total,
					excluded: coverage.dialogue.excluded
				},
				choices: {
					checked: coverage.choices.reached,
					total: coverage.choices.total,
					excluded: coverage.choices.excluded
				},
				conditionTrue: {
					checked: count("true"),
					total: denominator,
					unknown: coverage.conditions.unknown
				},
				conditionFalse: {
					checked: count("false"),
					total: denominator,
					unknown: coverage.conditions.unknown
				},
				declaredTests: {
					checked: 0,
					total: 0
				}
			}
		}
	};
	record.trace.coverage.declaredTests = regressionPathCoverage(project, {
		...record.trace,
		contentVersionId: session.state.contentVersionId,
		steps: record.trace.steps.map((step) => ({
			...step,
			before: {
				...step.before,
				contentVersionId: session.state.contentVersionId
			},
			after: {
				...step.after,
				contentVersionId: session.state.contentVersionId
			},
			...step.presentationState ? { presentationState: {
				...step.presentationState,
				contentVersionId: session.state.contentVersionId
			} } : {}
		}))
	}, session.startState, session.status);
	const declarations = declaredRegressionPaths(project);
	if (declarations.ids.length) record.trace.regressionDeclarations = {
		projectRevision: project.revision,
		traceIds: declarations.ids
	};
	return record;
}
/** Prepare snapshot content and its evidence for one transaction. IDs and timestamps belong to the caller. */
function pinTrialRecord(session, ids, declarationProject = session.declarationProject ?? session.content) {
	const { history: _history, snapshots: _snapshots, authorAlternatives: _authorAlternatives, ...content } = reuseAuthorContent(session.content);
	return {
		...trialRecordData(declarationProject, session, ids.checkpointId, ids.snapshotId),
		content: clone$1(content)
	};
}
function anchorIsPresented(project, state, anchor, declarationId) {
	return presentationAnchorApplies(project, state, anchor, { nodeId: state.presentationPosition ?? void 0 }, declarationId);
}
/** Required author-declared information is checked in reading order, never world-date order. */
function checkTrialForeshadows(project, session) {
	try {
		return checkTrialForeshadowsInternal(project, session);
	} catch (error) {
		return errorIssues(error).map((failure) => ({
			status: "confirmed_issue",
			code: failure.code,
			message: failure.message,
			path: session.nodeId ? [session.nodeId] : [],
			startState: clone$1(session.startState)
		}));
	}
}
function trialNarrativeOccurrences(session) {
	return [{
		state: session.startState,
		observationState: session.startPresentationState,
		conditions: session.startConditionResults,
		target: { nodeId: session.startState.presentationPosition ?? void 0 },
		worldTick: session.initialWorldTick,
		externalValues: session.startExternalValues
	}, ...session.trace.filter((step) => !step.request.stub || !sameRuntimeValue(step.before.visitCounts, step.after.visitCounts)).map((step) => ({
		state: step.after,
		observationState: step.presentationState,
		conditions: step.conditionResults,
		edgeIds: step.request.stub ? void 0 : step.edgeIds,
		target: { nodeId: step.after.presentationPosition ?? void 0 },
		worldTick: step.request.worldTick,
		externalValues: step.externalValuesAfter
	}))];
}
function checkTrialForeshadowsInternal(project, session) {
	return checkPresentationForeshadows(getTrialContent(project, session), trialNarrativeOccurrences(session), session.startState, session.status === "terminal", session.referenceEntities, session.issues);
}
function flowReferences(project) {
	const failures = [];
	const nodeIds = new Set(nodes(project).map((node) => node.id));
	const check = (id, value, kind, field) => {
		if (!value) return;
		const target = getEntity(project, value);
		if (!target || target.kind !== kind || target.deletedAt) failures.push({
			targetId: id,
			issue: issue("REFERENCE_INVALID", `${field}の参照先が存在しないか種類が違います。`, `${id}.${field}`)
		});
	};
	for (const node of nodes(project)) {
		const unsupportedReuse = reuseIssue(node);
		if (unsupportedReuse) failures.push({
			targetId: node.id,
			issue: unsupportedReuse
		});
		check(node.id, node.data.sceneId, "scene", "sceneId");
		check(node.id, node.data.childGraphId, "flow_graph", "childGraphId");
		check(node.id, node.data.fallbackId, "flow_node", "fallbackId");
		if (node.data.nodeType === "terminal" && !node.data.terminalReason?.trim()) failures.push({
			targetId: node.id,
			issue: issue("VALIDATION_FAILED", "終端に終了理由がありません。", `${node.id}.terminalReason`)
		});
	}
	for (const edge of edges(project)) {
		if (!nodeIds.has(edge.data.fromId) || typeof edge.data.toId !== "string" || !nodeIds.has(edge.data.toId)) failures.push({
			targetId: edge.id,
			issue: issue("REFERENCE_INVALID", "未完成または存在しない分岐先があります。", `${edge.id}.toId`)
		});
		for (const effectId of edge.data.effectIds ?? []) check(edge.id, effectId, "effect", "effectIds");
	}
	for (const graph of graphs(project)) {
		for (const id of [
			...graph.data.nodeIds,
			...graph.data.entryIds,
			...graph.data.exitIds
		]) check(graph.id, id, "flow_node", "nodeIds");
		for (const id of graph.data.edgeIds) check(graph.id, id, "flow_edge", "edgeIds");
		for (const id of [...graph.data.entryIds, ...graph.data.exitIds]) if (!graph.data.nodeIds.includes(id)) failures.push({
			targetId: graph.id,
			issue: issue("REFERENCE_INVALID", "入口または出口がグラフのnodeIdsに含まれていません。", `${graph.id}.entryIds`)
		});
	}
	return failures;
}
function visitThresholds(project) {
	const thresholds = {};
	const scan = (condition) => {
		if (!condition) return;
		if (condition.op === "visited") thresholds[condition.entityId] = Math.max(thresholds[condition.entityId] ?? 0, condition.count);
		if (condition.op === "all" || condition.op === "any") condition.children.forEach(scan);
		if (condition.op === "not") scan(condition.child);
	};
	nodes(project).forEach((node) => scan(node.data.gate));
	edges(project).forEach((edge) => scan(edge.data.condition));
	declaredEffects(project).forEach((effect) => scan(effect.data.condition));
	const scanExpression = (expression) => {
		if (!expression) return;
		if (expression.op === "visited") scan(expression);
		if ("children" in expression) expression.children.forEach(scanExpression);
		if ("child" in expression) scanExpression(expression.child);
		if ("left" in expression) {
			scanExpression(expression.left);
			scanExpression(expression.right);
		}
		if ("condition" in expression) {
			scan(expression.condition);
			scanExpression(expression.then);
			scanExpression(expression.else);
		}
	};
	variables(project).forEach((variable) => scanExpression(variable.data.derived));
	const scanData = (value, depth = 0) => {
		if (depth > 32 || !value || typeof value !== "object") return;
		if ("op" in value && value.op === "visited") scan(value);
		for (const child of Object.values(value)) scanData(child, depth + 1);
	};
	runtimeEntities(project).filter(adoptedRecord).forEach((entity) => scanData(entity.data));
	return thresholds;
}
function stateKey(state, thresholds) {
	const visits = Object.fromEntries(Object.keys(thresholds).sort().map((id) => [id, Math.min(state.visitCounts[id] ?? 0, thresholds[id])]));
	return canonicalRuntimeValue({
		values: Object.fromEntries(Object.entries(state.variableValues).sort(([a], [b]) => a.localeCompare(b))),
		items: [...state.itemInstances].sort((a, b) => a.instanceId.localeCompare(b.instanceId)),
		assertions: [...state.assertions].sort((a, b) => `${a.assertionId}:${a.holderId}`.localeCompare(`${b.assertionId}:${b.holderId}`)),
		seen: [...state.seenIds].sort(),
		visits,
		once: state.onceTriggers.filter((key) => !key.startsWith("occurrence:")).sort(),
		seed: state.rngSeed,
		rng: state.rngPosition,
		stack: state.callStack,
		position: state.presentationPosition,
		loop: state.loopNumber
	});
}
function* analysisIterator(project, options) {
	const limits = {
		maxStates: options.maxStates ?? 1e5,
		maxTransitions: options.maxTransitions ?? 1e4,
		maxMs: options.maxMs ?? 3e4
	};
	const now = options.now ?? (() => performance.now());
	const started = now();
	const selected = versionContent(project, options.contentVersionId ?? project.projectId);
	const declared = selected ? declaredEntrypoints(selected) : [];
	const entryIds = options.entryId || options.state || options.checkpointId ? options.entryId ? [options.entryId] : [] : declared;
	const first = startTrial(project, entryIds.length ? {
		...options,
		entryId: entryIds[0]
	} : options);
	const exploredEntries = first.nodeId ? [first.nodeId] : [];
	project = first.content;
	const findings = [];
	const unique = /* @__PURE__ */ new Set();
	let activeStart = first.startState;
	const add = (status, code, message, targetId, path = [], edgePath) => {
		const key = `${status}:${code}:${targetId ?? ""}`;
		if (!unique.has(key)) {
			unique.add(key);
			findings.push({
				status,
				code,
				message,
				targetId,
				path,
				edgePath,
				startState: clone$1(activeStart)
			});
		}
	};
	for (const failure of flowReferences(project)) add("confirmed_issue", failure.issue.code, failure.issue.message, failure.targetId);
	const structural = validateProject(project, { worldSnapshots: options.worldSnapshots });
	if (!structural.ok) for (const failure of structural.issues) {
		const entityIndex = /(?:^|\.)entities\[(\d+)\]/.exec(failure.path)?.[1];
		add("confirmed_issue", failure.code, failure.message, entityIndex ? project.entities[Number(entityIndex)]?.id : void 0);
	}
	const invalidLimits = Object.values(limits).some((value) => !Number.isSafeInteger(value) || value <= 0) || limits.maxStates > 1e5 || limits.maxTransitions > 1e4 || limits.maxMs > 3e4;
	if (invalidLimits) add("confirmed_issue", "VALIDATION_FAILED", "探索上限は正の安全な整数で、100,000状態・10,000遷移・30秒以内にしてください。");
	const queue = invalidLimits ? [] : [{
		session: first,
		parent: null,
		depth: 0
	}];
	let nextEntry = invalidLimits ? entryIds.length : 1;
	const witness = (index) => {
		const path = [];
		let current = index;
		while (current !== null) {
			const record = queue[current];
			if (record.session.nodeId) path.push(record.session.nodeId);
			current = record.parent;
		}
		return path.reverse();
	};
	const edgeWitness = (index) => {
		const path = [];
		let current = index;
		while (current !== null && queue[current].parent !== null) {
			path.push([...queue[current].session.trace.at(-1).edgeIds]);
			current = queue[current].parent;
		}
		return path.reverse();
	};
	const pathSession = (index) => {
		const trace = [];
		let current = index;
		while (queue[current].parent !== null) {
			trace.push(queue[current].session.trace.at(-1));
			current = queue[current].parent;
		}
		return {
			...queue[index].session,
			startState: queue[current].session.startState,
			startPresentationState: queue[current].session.startPresentationState,
			startConditionResults: queue[current].session.startConditionResults,
			trace: trace.reverse()
		};
	};
	const thresholds = structural.ok ? visitThresholds(project) : {};
	const checked = /* @__PURE__ */ new Set();
	const reached = /* @__PURE__ */ new Set();
	const seen = /* @__PURE__ */ new Set();
	const traversed = /* @__PURE__ */ new Set();
	const observed = /* @__PURE__ */ new Map();
	let checkedStates = 0;
	let cursor = 0;
	let truncated = false;
	while (cursor < queue.length || nextEntry < entryIds.length) {
		if (options.signal?.aborted || checkedStates >= limits.maxStates || now() - started >= limits.maxMs) {
			truncated = true;
			add("unknown", "ANALYSIS_LIMIT", options.signal?.aborted ? "解析を取り消しました。確認済み範囲だけを表示します。" : "探索上限に達しました。残りの経路は未確認です。");
			break;
		}
		if (cursor === queue.length && nextEntry < entryIds.length) {
			const entryId = entryIds[nextEntry++];
			queue.push({
				session: startTrialInternal(project, {
					...options,
					entryId
				}, true),
				parent: null,
				depth: 0
			});
			exploredEntries.push(entryId);
		}
		const recordIndex = cursor++;
		const record = queue[recordIndex];
		const { session, depth } = record;
		activeStart = session.startState;
		const lastStep = session.trace.at(-1), oldChapter = lastStep ? presentationRuleContext(project, { nodeId: lastStep.before.presentationPosition ?? void 0 }).chapterId : void 0;
		const currentChapter = presentationRuleContext(project, { nodeId: session.nodeId ?? void 0 }).chapterId;
		if (session.status === "terminal" || getTrialNode(project, session)?.data.nodeType === "exit" || oldChapter && oldChapter !== currentChapter || activeKind(project, "foreshadow").some((foreshadow) => foreshadow.data.presentationDeadline && anchorIsPresented(project, session.state, reuseExecutionAnchor(project, foreshadow.data.presentationDeadline, foreshadow.id), foreshadow.id)) || activeKind(project, "disclosure").some((disclosure) => disclosure.data.role === "payoff" && anchorIsPresented(project, session.state, reuseExecutionAnchor(project, disclosure.data.anchor, disclosure.id), disclosure.id))) for (const finding of checkTrialForeshadows(project, pathSession(recordIndex))) {
			const key = `${finding.status}:${finding.code}:${finding.targetId}:${finding.payoffId}:${finding.missingInfoIds?.join(",")}`;
			if (!unique.has(key)) {
				unique.add(key);
				findings.push(finding);
			}
		}
		const signature = stateKey(session.state, thresholds);
		record.signature = signature;
		if (checked.has(signature)) {
			let ancestor = record.parent;
			while (ancestor !== null) {
				if (queue[ancestor].signature === signature) {
					add("unknown", "UNBOUNDED_LOOP", "同じ状態へ戻る経路があります。無制限の反復は未確認です。", session.nodeId ?? void 0, witness(recordIndex), edgeWitness(recordIndex));
					break;
				}
				ancestor = queue[ancestor].parent;
			}
			continue;
		}
		checked.add(signature);
		checkedStates++;
		if (session.nodeId) reached.add(session.nodeId);
		session.state.seenIds.forEach((id) => seen.add(id));
		session.trace.forEach((step) => {
			step.edgeIds.forEach((id) => traversed.add(id));
			step.conditionResults.forEach((result) => observed.set(`${result.targetId}:${result.value}`, result));
		});
		if (structural.ok) for (const result of trialObservations([session])) observed.set(`${result.targetId}:${result.value}`, result);
		const path = () => witness(recordIndex);
		if (session.status === "terminal") add("intentional", "TERMINAL", findNode(project, session.nodeId)?.data.terminalReason || "意図した終端", session.nodeId ?? void 0, path(), edgeWitness(recordIndex));
		else if (session.status === "unknown") add("unknown", "CONDITION_UNKNOWN", session.issues.map((value) => value.message).join("、"), session.nodeId ?? void 0, path(), edgeWitness(recordIndex));
		else if (session.status === "blocked" || session.status === "error") add(session.status === "error" ? "confirmed_issue" : "candidate", session.issues[0]?.code ?? "TRANSITION_BLOCKED", session.issues.map((value) => value.message).join("、"), session.nodeId ?? void 0, path(), edgeWitness(recordIndex));
		else if (depth >= limits.maxTransitions) {
			truncated = true;
			add("unknown", "ANALYSIS_LIMIT", "一経路の遷移数上限に達しました。続きは未確認です。", session.nodeId ?? void 0, path(), edgeWitness(recordIndex));
		} else {
			const node = findNode(project, session.nodeId);
			const policy = node.data.executionPolicy ?? (node.data.nodeType === "automatic" ? "first_match" : "manual_choice");
			const choices = getTrialChoices(project, session);
			for (const choice of choices) if (choice.result === "unknown") add("unknown", "CONDITION_UNKNOWN", choice.reasons.join("、") || "未確認の候補があります。", choice.edgeId, path(), edgeWitness(recordIndex));
			const requests = node.data.nodeType === "call" || node.data.nodeType === "exit" || policy !== "manual_choice" ? [{}] : choices.filter((choice) => choice.result === "true").map((choice) => ({ edgeId: choice.edgeId }));
			if (requests.length === 0 && node.data.fallbackId) requests.push({});
			for (const request of requests) {
				if (queue.length >= limits.maxStates || options.signal?.aborted || now() - started >= limits.maxMs) {
					truncated = true;
					add("unknown", "ANALYSIS_LIMIT", "探索の上限または取消により、残る経路は未確認です。");
					break;
				}
				request.worldTick = options.worldTick;
				if (node.data.trigger) request.event = {
					event: node.data.trigger.event,
					eventKey: node.data.trigger.eventKey,
					occurrenceId: `analysis:${checkedStates}:${request.edgeId ?? "auto"}`
				};
				const next = stepTrial(project, session, request);
				if (next.state === session.state || next.trace.length === session.trace.length) add(next.status === "unknown" ? "unknown" : next.status === "error" ? "confirmed_issue" : "candidate", next.issues[0]?.code ?? "TRANSITION_BLOCKED", next.issues.map((value) => value.message).join("、") || "進行できません。", node.id, path(), edgeWitness(recordIndex));
				else queue.push({
					session: {
						...next,
						history: [],
						trace: next.trace.slice(-1)
					},
					parent: recordIndex,
					depth: depth + 1
				});
			}
		}
		if (checkedStates % 128 === 0) yield {
			checkedStates,
			pendingStates: queue.length - cursor,
			elapsedMs: now() - started,
			limits
		};
	}
	for (const node of nodes(project)) if (!reached.has(node.id)) add("candidate", "NOT_REACHED_IN_CHECKED_SCOPE", "指定した開始状態と確認範囲では到達を見つけていません。到達不能の断定ではありません。", node.id);
	return {
		status: findings.some((finding) => finding.status === "confirmed_issue") ? "confirmed_issue" : findings.some((finding) => finding.status === "unknown") || truncated ? "unknown" : findings.some((finding) => finding.status === "candidate") ? "candidate" : "passed_for_checked_scope",
		findings,
		coverage: coverageFromEvidence(project, seen, traversed, [...observed.values()], first.state.provenance),
		checkedStates,
		limits,
		truncated,
		contentVersionId: first.state.contentVersionId,
		contentRevision: project.revision,
		targetIds: nodes(project).map((node) => node.id),
		entryIds: exploredEntries,
		declaredEntryIds: declared,
		assumptions: [
			options.entryId || options.state || options.checkpointId ? "指定した開始状態の有限探索。未到達は到達不能の証明ではありません。" : "全宣言入口の初期状態からの有限探索。未到達は到達不能の証明ではありません。",
			"外部値を補いません。明示トリガーは宣言した入力が与えられる場合だけを確認します。",
			"visitedは宣言した閾値まで状態に含めます。同状態の無制限ループは未確認です。"
		]
	};
}
function analyzeFlow(project, options = {}) {
	const iterator = analysisIterator(project, options);
	let result = iterator.next();
	while (!result.done) {
		options.onProgress?.(result.value);
		result = iterator.next();
	}
	return result.value;
}
/** Yield between batches so progress and AbortSignal cancellation remain usable in a browser. */
async function analyzeFlowAsync(project, options = {}) {
	const iterator = analysisIterator(project, options);
	let result = iterator.next();
	while (!result.done) {
		options.onProgress?.(result.value);
		await new Promise((resolve) => setTimeout(resolve, 0));
		result = iterator.next();
	}
	return result.value;
}
var clone$1, sameRuntimeValue, issue, active, capturedIndices, capturedReferences, runtimeEntities, activeKind, getEntity, nodes, edges, variables, graphs, declaredEffects, findNode, nodeEdges, evalAt, resultSession;
var init_runtime = __esmMin((() => {
	init_model();
	init_conditions();
	init_time();
	init_presentation();
	init_regressionPaths();
	init_reuse();
	init_adoption();
	init_narrative();
	clone$1 = (value) => structuredClone(value);
	sameRuntimeValue = (left, right) => canonicalRuntimeValue(left) === canonicalRuntimeValue(right);
	issue = (code, message, path = "runtime") => ({
		code,
		message,
		path
	});
	active = (entities) => entities.filter(adoptedRecord);
	capturedIndices = /* @__PURE__ */ new WeakMap();
	capturedReferences = /* @__PURE__ */ new WeakMap();
	runtimeEntities = (project) => [...project.entities, ...capturedReferences.get(project) ?? []];
	activeKind = (project, kind) => {
		const index = capturedIndices.get(project);
		return index ? index.activeByKind.get(kind) ?? [] : active(getEntitiesByKind(project, kind));
	};
	getEntity = (project, id) => {
		const index = capturedIndices.get(project);
		return index ? index.byId.get(id) : getEntity$2(project, id);
	};
	nodes = (project) => activeKind(project, "flow_node");
	edges = (project) => activeKind(project, "flow_edge");
	variables = (project) => activeKind(project, "variable");
	graphs = (project) => activeKind(project, "flow_graph");
	declaredEffects = (project) => activeKind(project, "effect");
	findNode = (project, id) => {
		const node = id === null ? void 0 : getEntity(project, id);
		return node?.kind === "flow_node" && node.status !== "rejected" ? node : void 0;
	};
	nodeEdges = (project, id) => {
		const index = capturedIndices.get(project);
		return index ? index.edgesFrom.get(id) ?? [] : edges(project).filter((edge) => edge.data.fromId === id);
	};
	evalAt = (project, state, condition, externalValues) => evaluateCondition(condition ?? {
		op: "constant",
		value: true
	}, {
		state,
		variables: variables(project),
		entities: runtimeEntities(project),
		externalValues
	});
	resultSession = (session, status, issues) => ({
		...session,
		nodeId: session.state.presentationPosition,
		status,
		issues
	});
}));

//#endregion
//#region src/domain/runtimeVerified.ts
/** The author document and registry are captured before hashing. Borrowed records stay separate. */
async function captured(project, version, worldSnapshots) {
	const source = structuredClone(project), registry = structuredClone(worldSnapshots);
	const content = await captureRuntimeContent(source, version, { worldSnapshots: registry });
	return {
		source,
		content,
		registry,
		referenceEntities: resolvePinnedWorlds(resolveReuseContent(content, content.snapshots), registry).worlds.flatMap((world) => world.entities)
	};
}
async function startTrialVerified(project, options = {}, worldSnapshots = {}) {
	const requested = structuredClone(options);
	const input = await captured(project, requested.contentVersionId ?? project.projectId, worldSnapshots);
	return startTrial(input.source, {
		...requested,
		referenceEntities: input.referenceEntities
	});
}
var init_runtimeVerified = __esmMin((() => {
	init_runtimeVersions();
	init_pinnedWorlds();
	init_runtime();
	init_reuse();
}));

//#endregion
//#region src/domain/portableRuntimeProject.ts
/** Internal UUIDs derive exclusively from public IDs, including independently approved citations. */
async function portableRuntimeProject(projection) {
	const contentHash = await sha256(jsonBytes(projection)), toUuid = (hash) => `${hash.slice(0, 8)}-${hash.slice(8, 12)}-4${hash.slice(13, 16)}-a${hash.slice(17, 20)}-${hash.slice(20, 32)}`, projectId = toUuid(contentHash), versions = projection.versions ?? [];
	if (versions.length > 128 || new Set(versions.map((pin) => pin.id)).size !== versions.length || versions.some((pin) => pin.projection.versions?.length)) throw Error("EXPORT_UNSUPPORTED: 公開引用版の上限・重複・依存形式が不正です。");
	const editions = [projection, ...versions.map((pin) => pin.projection)], ids = new Set(editions.flatMap((edition) => [...edition.entities.map((entity) => entity.id), ...edition.relations.map((relation) => relation.id)]));
	versions.forEach((pin) => ids.add(pin.id));
	function embedded(value) {
		if (Array.isArray(value)) {
			value.forEach(embedded);
			return;
		}
		if (!value || typeof value !== "object") return;
		const object = value;
		if (typeof object.id === "string" && typeof object.text === "string" && typeof object.kind === "string") ids.add(object.id);
		if (typeof object.id === "string" && typeof object.eventKey === "string") ids.add(object.id);
		Object.values(object).forEach(embedded);
	}
	editions.forEach((edition) => edition.entities.forEach((entity) => embedded(entity.data)));
	const mapping = { "public-project": projectId };
	for (const id of ids) mapping[id] = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(id) ? id : toUuid(await sha256(new TextEncoder().encode(`scenario-runtime-1:${id}`)));
	function native(value, versionId) {
		if (Array.isArray(value)) return value.map((item) => native(item, versionId));
		if (!value || typeof value !== "object") return value;
		const object = value, output = Object.fromEntries(Object.entries(object).map(([key, item]) => [key, ["sourceVersionId", "targetSnapshotId"].includes(key) && item === "public-project" ? versionId : native(item, versionId)]));
		if (typeof object.id === "string" && ids.has(object.id)) output.id = mapping[object.id];
		if (Array.isArray(object.links)) output.links = object.links.map((raw) => {
			const link = raw;
			return {
				start: link.start,
				end: link.end,
				target: {
					entityId: link.targetId,
					...link.blockId ? { blockId: link.blockId } : {},
					...link.lineId ? { lineId: link.lineId } : {},
					...link.sourceVersionId ? { sourceVersionId: link.sourceVersionId === "public-project" ? versionId : link.sourceVersionId } : {},
					...link.targetStart !== void 0 ? {
						start: link.targetStart,
						end: link.targetEnd
					} : {}
				}
			};
		});
		return output;
	}
	function convert(edition, versionId) {
		const project = createProject(edition.title);
		project.projectId = projectId;
		project.mainStart = edition.mainStart ?? "0";
		project.calendars[0].id = project.calendarId = "public-calendar-default";
		const fixedAt = "1970-01-01T00:00:00.000Z";
		project.entities = edition.entities.map((publicEntity) => {
			const data = native(publicEntity.data, versionId);
			delete data.bytesIncluded;
			const entity = createEntity(projectId, publicEntity.kind, publicEntity.name, data);
			entity.id = mapping[publicEntity.id];
			entity.createdAt = entity.updatedAt = fixedAt;
			entity.status = "confirmed";
			return rewriteEntityReferences(entity, mapping);
		});
		project.views = [];
		project.relations = edition.relations.map((relation) => ({
			...relation,
			id: mapping[relation.id],
			projectId,
			fromId: mapping[relation.fromId],
			toId: mapping[relation.toId],
			evidenceIds: relation.evidenceIds.map((id) => mapping[id]),
			revision: "0",
			status: "confirmed",
			visibility: "projection",
			validity: rewriteEntityReferences(createEntity(projectId, "assertion", "公開関係の期間", {
				subjectId: mapping[relation.fromId],
				predicate: "relation",
				validity: native(relation.validity, versionId) ?? {
					worldRange: null,
					routeCondition: null,
					presentationAnchor: null
				}
			}), mapping).data.validity
		}));
		project.worldReferences = [];
		project.snapshots = [];
		project.history = [];
		if (edition.calendars.length) {
			const defaults = project.calendars[0];
			project.calendars = edition.calendars.map((calendar) => calendar.kind === "repeating" ? {
				id: calendar.id,
				name: calendar.name,
				kind: "repeating",
				originLabel: calendar.originLabel,
				ticksPerDay: calendar.ticksPerDay,
				years: calendar.years ?? []
			} : {
				...defaults,
				id: calendar.id,
				name: calendar.name,
				kind: "gregorian",
				ticksPerDay: calendar.ticksPerDay
			});
			project.calendarId = project.calendars[0].id;
		}
		return project;
	}
	const project = convert(projection, projectId);
	for (const pin of versions) {
		const { history: _history, snapshots: _snapshots, authorAlternatives: _alternatives, ...content } = convert(pin.projection, mapping[pin.id]);
		project.snapshots.push({
			id: mapping[pin.id],
			versionLabel: pin.projection.title,
			createdAt: "1970-01-01T00:00:00.000Z",
			content,
			contentHash: await sha256(jsonBytes(content))
		});
	}
	const checked = validateProject(project);
	if (!checked.ok) throw Object.assign(/* @__PURE__ */ new Error("EXPORT_UNSUPPORTED: 公開実行内容を同じstrict契約へ対応できません。"), { issues: checked.issues });
	return {
		project,
		publicToRuntime: mapping
	};
}
var init_portableRuntimeProject = __esmMin((() => {
	init_model();
	init_json();
}));

//#endregion
//#region src/domain/attachments.ts
function ascii(bytes, offset, text) {
	return [...text].every((char, i) => bytes[offset + i] === char.charCodeAt(0));
}
function detectAsset(bytes, declaredType) {
	if (bytes.length >= 8 && [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	].every((v, i) => bytes[i] === v)) return {
		kind: "png",
		mediaType: "image/png",
		preview: "image"
	};
	if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return {
		kind: "jpg",
		mediaType: "image/jpeg",
		preview: "image"
	};
	if (ascii(bytes, 0, "GIF87a") || ascii(bytes, 0, "GIF89a")) return {
		kind: "gif",
		mediaType: "image/gif",
		preview: "image"
	};
	if (ascii(bytes, 0, "RIFF") && ascii(bytes, 8, "WEBP")) return {
		kind: "webp",
		mediaType: "image/webp",
		preview: "image"
	};
	if (ascii(bytes, 0, "RIFF") && ascii(bytes, 8, "WAVE")) return {
		kind: "wav",
		mediaType: "audio/wav",
		preview: "audio"
	};
	if (ascii(bytes, 0, "ID3") || bytes.length >= 2 && bytes[0] === 255 && (bytes[1] & 224) === 224) return {
		kind: "mp3",
		mediaType: "audio/mpeg",
		preview: "audio"
	};
	if (ascii(bytes, 0, "OggS")) return {
		kind: "ogg",
		mediaType: "audio/ogg",
		preview: "audio"
	};
	if (ascii(bytes, 4, "ftyp")) return {
		kind: "mp4",
		mediaType: "video/mp4",
		preview: "video"
	};
	if ([
		26,
		69,
		223,
		163
	].every((value, index) => bytes[index] === value)) return {
		kind: "webm",
		mediaType: "video/webm",
		preview: "video"
	};
	if (ascii(bytes, 0, "%PDF-")) return {
		kind: "pdf",
		mediaType: "application/pdf",
		preview: "download_only"
	};
	if (declaredType === "text/plain" || declaredType === "application/json") {
		const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
		if (declaredType === "application/json") JSON.parse(text);
		return {
			kind: declaredType === "application/json" ? "json" : "txt",
			mediaType: declaredType,
			preview: "download_only"
		};
	}
	if (declaredType === "application/octet-stream" && !ascii(bytes, 0, "MZ") && !ascii(bytes, 0, "ELF") && !ascii(bytes, 0, "#!") && !/^\s*<(?:!doctype\s+html|html|script|svg)\b/i.test(new TextDecoder().decode(bytes.slice(0, 512)))) return {
		kind: "bin",
		mediaType: "application/octet-stream",
		preview: "download_only"
	};
	throw new Error("VALIDATION_FAILED: この素材形式は安全な表示の対象外です。HTML・SVG・実行ファイルは添付できません。");
}
async function prepareAsset(input, displayName, declaredType) {
	if (!input.length || input.length > MAX) throw new Error("IMPORT_LIMIT: 添付は1 byte〜32 MiBです。");
	const bytes = new Uint8Array(input);
	const type = detectAsset(bytes, declaredType);
	const digest = await crypto.subtle.digest("SHA-256", bytes);
	const contentHash = [...new Uint8Array(digest)].map((v) => v.toString(16).padStart(2, "0")).join("");
	return {
		bytes,
		contentHash,
		byteSize: bytes.length,
		mediaType: type.mediaType,
		assetPath: `assets/${contentHash}.${type.kind}`,
		displayName,
		preview: type.preview
	};
}
var MAX;
var init_attachments = __esmMin((() => {
	MAX = 33554432;
}));

//#endregion
//#region src/domain/projection.ts
/** Pure, fail-closed projection. Public prose is supplied by the author; this is not a text redactor. */
function createProjection(project, profileId, options = {}) {
	const issues = [], omissions = [];
	if (!project || !Array.isArray(project.entities) || !Array.isArray(project.relations) || project.entities.some((entity) => !entity || typeof entity.id !== "string" || !object$3(entity.data))) return {
		ok: false,
		issues: [{
			code: "VALIDATION_FAILED",
			message: "作品の公開元データが不正です。"
		}],
		omissions
	};
	const fail = (code, message, entityId, field) => {
		issues.push({
			code,
			message,
			...entityId ? { entityId } : {},
			...field ? { field } : {}
		});
	};
	const omit = (entityId, reason, field) => {
		omissions.push({
			entityId,
			reason,
			...field ? { field } : {}
		});
	};
	const source = /* @__PURE__ */ new Map();
	for (const entity of project.entities) {
		if (source.has(entity.id)) fail("VALIDATION_FAILED", "同じIDの情報が重複しています。", entity.id);
		source.set(entity.id, entity);
	}
	const profile = source.get(profileId);
	if (!profile || profile.kind !== "projection_profile" || profile.projectId !== project.projectId || profile.deletedAt) return {
		ok: false,
		issues: [{
			code: "REFERENCE_INVALID",
			message: "この作品の公開範囲を選んでください。",
			entityId: profileId
		}],
		omissions
	};
	const policy = profile.data;
	if (policy.sourceVersionId != null && policy.sourceVersionId !== options.targetVersionId && policy.sourceVersionId !== project.revision) fail("VALIDATION_FAILED", "公開範囲が固定された版と出力元の版が一致しません。", profileId, "sourceVersionId");
	if (object$3(policy.routeScope)?.targetSnapshotId != null && object$3(policy.routeScope).targetSnapshotId !== options.targetVersionId) fail("VALIDATION_FAILED", "公開範囲の対象snapshotを読み込んでください。", profileId, "routeScope.targetSnapshotId");
	if (policy.idPolicy != null && !["remap", "preserve"].includes(String(policy.idPolicy))) fail("VALIDATION_FAILED", "公開IDの方式が不正です。", profileId, "idPolicy");
	if (policy.includeAuthorNotes === true) fail("FORBIDDEN", "公開用出力に作者メモは含められません。", profileId, "includeAuthorNotes");
	const title = own(policy, "publicTitle");
	if (typeof title !== "string" || !title.trim()) fail("PUBLIC_TEXT_REQUIRED", "作者が確認した公開用の作品名を指定してください。", profileId, "publicTitle");
	const includedIds = own(policy, "includedIds"), allowedKinds = own(policy, "allowedKinds");
	if (!Array.isArray(includedIds) || includedIds.some((id) => typeof id !== "string") || new Set(includedIds).size !== includedIds.length) fail("VALIDATION_FAILED", "公開するIDを重複のない一覧で指定してください。", profileId, "includedIds");
	if (!Array.isArray(allowedKinds) || allowedKinds.length === 0 || allowedKinds.some((kind) => typeof kind !== "string" || !hasOwn(PROJECTION_FIELDS, kind))) fail("EXPORT_UNSUPPORTED", "公開可能な種類だけを明示的に選んでください。", profileId, "allowedKinds");
	const publicTexts = object$3(own(policy, "publicTexts")) ?? {};
	const publicIds = object$3(own(policy, "publicIds")) ?? {};
	const namePolicies = object$3(own(policy, "namePolicy"));
	const scopeIds = scopedEntityIds(source, policy, project.projectId, publicTexts, fail);
	const statuses = Array.isArray(policy.includedStatuses) ? policy.includedStatuses : ["confirmed"];
	if (statuses.some((status) => ![
		"confirmed",
		"provisional",
		"needs_review"
	].includes(String(status)))) fail("FORBIDDEN", "没案と作者別案は公開対象にできません。", profileId, "includedStatuses");
	const selected = [];
	const names = /* @__PURE__ */ new Map();
	const explicitPublicIds = /* @__PURE__ */ new Map();
	const included = new Set(Array.isArray(includedIds) ? includedIds : []);
	const orderedIds = [...source.keys()].filter((id) => included.has(id));
	for (const id of included) if (!source.has(id)) orderedIds.push(id);
	for (const id of orderedIds) {
		const entity = source.get(id);
		if (!entity || entity.projectId !== project.projectId) {
			fail("REFERENCE_INVALID", "作品内にない情報が公開範囲に含まれています。", id);
			continue;
		}
		if (scopeIds && !scopeIds.has(id)) {
			omit(id, "指定した章またはグラフの範囲外");
			continue;
		}
		if (entity.deletedAt || !statuses.includes(entity.status) || options.confirmedOnly && entity.status !== "confirmed") {
			omit(id, "削除済み、未確定、没案または別案");
			continue;
		}
		if (!Array.isArray(allowedKinds) || !allowedKinds.includes(entity.kind)) {
			omit(id, "許可されていない種類");
			continue;
		}
		if (!hasOwn(PROJECTION_FIELDS, entity.kind)) {
			fail("EXPORT_UNSUPPORTED", "この種類の安全な投影は未対応です。", id);
			continue;
		}
		if (["scene", "flow_node"].includes(entity.kind) && object$3(entity.data.reuse)?.mode !== void 0 && object$3(entity.data.reuse)?.mode !== "clone") {
			fail("EXPORT_UNSUPPORTED", "固定共通元と使用先を合わせた公開範囲・公開名・本文を確認する出力は未対応です。再利用を省略した出力は作成できません。", id, "reuse");
			continue;
		}
		const byEntityId = object$3(own(namePolicies, "byEntityId"));
		const namePolicy = object$3(own(byEntityId, id)) ?? object$3(own(namePolicies, "defaultPolicy")) ?? (typeof namePolicies?.mode === "string" ? namePolicies : void 0);
		if (namePolicy?.mode === "exclude") {
			omit(id, "作者が非公開を選択");
			continue;
		}
		let publicName;
		if (namePolicy?.mode === "replace") publicName = namePolicy.replacement;
		else if (namePolicy?.mode === "anonymize") {
			publicName = namePolicy.publicName;
			if (typeof namePolicy.publicId === "string") explicitPublicIds.set(id, namePolicy.publicId);
		} else if (namePolicy?.mode === "alias") publicName = (Array.isArray(entity.data.aliases) ? entity.data.aliases : []).map(object$3).find((value) => value?.id === namePolicy.aliasId)?.text;
		else if (entity.name === "") publicName = "";
		if (typeof publicName !== "string" || entity.name !== "" && !publicName.trim()) {
			fail("PUBLIC_TEXT_REQUIRED", "この情報の公開名または公開別名を指定してください。", id, "namePolicy");
			continue;
		}
		names.set(id, publicName);
		selected.push(entity);
	}
	const idMap = Object.create(null);
	const emittedIds = /* @__PURE__ */ new Set();
	let sequence = 0;
	const addId = (id) => {
		if (Object.prototype.hasOwnProperty.call(idMap, id)) return;
		const candidate = explicitPublicIds.get(id) ?? own(publicIds, id) ?? (policy.idPolicy === "preserve" ? id : `public-${String(++sequence).padStart(6, "0")}`);
		if (typeof candidate !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(candidate) || emittedIds.has(candidate)) {
			fail("VALIDATION_FAILED", "公開IDが不正、または重複しています。", id, "publicIds");
			return;
		}
		idMap[id] = candidate;
		emittedIds.add(candidate);
	};
	selected.forEach((entity) => addId(entity.id));
	const allowedFields = object$3(own(policy, "allowedFields"));
	const excludedFields = Array.isArray(policy.excludedFields) ? policy.excludedFields : [];
	const publicBlockIds = /* @__PURE__ */ new Set();
	const publicBlockOwners = /* @__PURE__ */ new Map(), sourceBlockOwners = /* @__PURE__ */ new Map();
	for (const entity of selected) {
		for (const value of Object.values(entity.data)) if (Array.isArray(value)) for (const raw of value) {
			const block = object$3(raw);
			if (typeof block?.id === "string" && typeof block.text === "string") sourceBlockOwners.set(block.id, entity.id);
		}
		const fields = object$3(own(publicTexts, entity.id));
		const schema = PROJECTION_FIELDS[entity.kind];
		const explicit = own(allowedFields, entity.kind);
		for (const [field, rule] of Object.entries(schema)) if (rule.type === "rich" && (!Array.isArray(explicit) || explicit.includes(field)) && !excludedFields.includes(field) && !excludedFields.includes(`${entity.kind}.${field}`) && Array.isArray(own(fields, field))) for (const block of fields[field]) {
			const record = object$3(block);
			if (typeof record?.id === "string") {
				if (source.has(record.id) || publicBlockIds.has(record.id)) fail("VALIDATION_FAILED", "公開文の段落IDが他の情報と重複しています。", entity.id, field);
				else {
					publicBlockIds.add(record.id);
					publicBlockOwners.set(record.id, entity.id);
					addId(record.id);
				}
			}
		}
		const trigger = object$3(entity.data.trigger);
		if (entity.kind === "flow_node" && typeof trigger?.id === "string") addId(trigger.id);
	}
	const selectedIds = new Set(selected.map((entity) => entity.id));
	const blockSources = object$3(policy.blockSources) ?? {};
	for (const [publicBlock, sourceBlock] of Object.entries(blockSources)) {
		if (typeof sourceBlock !== "string" || !publicBlockIds.has(publicBlock) || !idMap[publicBlock] || sourceBlockOwners.get(sourceBlock) !== publicBlockOwners.get(publicBlock)) {
			fail("REFERENCE_INVALID", "公開段落の元ID対応が不正です。", profileId, "blockSources");
			continue;
		}
		if (idMap[sourceBlock] && idMap[sourceBlock] !== idMap[publicBlock]) {
			fail("REFERENCE_INVALID", "同じ原段落に複数の公開位置が指定されています。", profileId, "blockSources");
			continue;
		}
		idMap[sourceBlock] = idMap[publicBlock];
	}
	const calendars = [], calendarIds = /* @__PURE__ */ new Map();
	const publicCalendarId = (value, entity, field) => {
		if (typeof value !== "string") {
			fail("REFERENCE_INVALID", "日時が使う暦を指定してください。", entity.id, field);
			return;
		}
		if (calendarIds.has(value)) return calendarIds.get(value);
		const sourceCalendar = project.calendars.find((calendar) => calendar.id === value);
		if (!sourceCalendar || !["gregorian", "repeating"].includes(sourceCalendar.kind) || !TICK.test(sourceCalendar.ticksPerDay) || BigInt(sourceCalendar.ticksPerDay) <= 0n) {
			fail("REFERENCE_INVALID", "日時が使う暦を安全に出力できません。", entity.id, field);
			return;
		}
		let publicId = `public-calendar-${calendars.length + 1}`;
		while (emittedIds.has(publicId)) publicId += "-calendar";
		emittedIds.add(publicId);
		const calendar = {
			id: publicId,
			name: `暦${calendars.length + 1}`,
			kind: sourceCalendar.kind,
			originLabel: "原点",
			ticksPerDay: sourceCalendar.ticksPerDay
		};
		if (sourceCalendar.kind === "repeating") {
			if (!Array.isArray(sourceCalendar.years) || !sourceCalendar.years.length || sourceCalendar.years.length > 400) {
				fail("EXPORT_UNSUPPORTED", "繰り返し暦の周期を安全に出力できません。", entity.id, field);
				return;
			}
			calendar.years = [];
			for (const year of sourceCalendar.years) {
				if (!Array.isArray(year.months) || !year.months.length || year.months.length > 24 || year.months.some((month) => !integer(month.days) || month.days < 1 || month.days > 400)) {
					fail("EXPORT_UNSUPPORTED", "繰り返し暦の月を安全に出力できません。", entity.id, field);
					return;
				}
				calendar.years.push({ months: year.months.map((month, index) => ({
					name: `月${index + 1}`,
					days: month.days
				})) });
			}
		}
		calendarIds.set(value, publicId);
		calendars.push(calendar);
		return publicId;
	};
	const reference = (value, entity, field, mandatory = false) => {
		if (value == null) return void 0;
		if (typeof value === "string" && selectedIds.has(value) && Object.prototype.hasOwnProperty.call(idMap, value)) return idMap[value];
		if (typeof value === "string" && Object.prototype.hasOwnProperty.call(idMap, value) && field.includes("block")) return idMap[value];
		if (mandatory || options.strictReferences) fail("REFERENCE_INVALID", "公開範囲にない参照先が必要です。範囲または代替文を見直してください。", entity.id, field);
		else omit(entity.id, "公開範囲にない参照を除外", field);
	};
	const mapEnum = (value, variableId, entity, field) => {
		const replacements = object$3(own(object$3(own(policy, "publicValues")), variableId));
		const replacement = typeof value === "string" ? own(replacements, value) : void 0;
		if (typeof replacement !== "string") {
			fail("PUBLIC_TEXT_REQUIRED", "列挙値の公開用表記を指定してください。", entity.id, field);
			return;
		}
		return replacement;
	};
	const typedValue = (value, variableId, entity, field) => {
		if (typeof value === "string" && entity.kind === "assertion") return reference(value, entity, field, true);
		const input = object$3(value);
		if (!input) {
			fail("VALIDATION_FAILED", "型付きの値が必要です。", entity.id, field);
			return;
		}
		if (input.type === "boolean" && typeof input.value === "boolean") return {
			type: "boolean",
			value: input.value
		};
		if (input.type === "integer" && integer(input.value)) return {
			type: "integer",
			value: input.value
		};
		if (input.type === "enum") {
			const mapped = mapEnum(input.value, variableId, entity, field);
			return mapped === void 0 ? void 0 : {
				type: "enum",
				value: mapped
			};
		}
		if (input.type === "ref") {
			const mapped = reference(input.value, entity, field, true);
			return mapped ? {
				type: "ref",
				value: mapped
			} : void 0;
		}
		fail("EXPORT_UNSUPPORTED", "未確定値や自由文字列の値は安全な制作出力に対応していません。", entity.id, field);
	};
	const conditionValue = (input, entity, field) => {
		let nodes = 0;
		const visit = (value, depth) => {
			const ast = object$3(value);
			if (!ast || depth > 16 || ++nodes > 256) {
				fail("EXPORT_UNSUPPORTED", "条件の形または深さが対応範囲を超えています。", entity.id, field);
				return;
			}
			const requiredRef = (key) => reference(ast[key], entity, `${field}.${key}`, true);
			switch (ast.op) {
				case "constant":
					if (typeof ast.value === "boolean") return {
						op: "constant",
						value: ast.value
					};
					break;
				case "all":
				case "any": {
					if (!Array.isArray(ast.children) || ast.children.length === 0) break;
					const children = ast.children.map((child) => visit(child, depth + 1));
					return children.every((child) => child !== void 0) ? {
						op: ast.op,
						children
					} : void 0;
				}
				case "not": {
					const child = visit(ast.child, depth + 1);
					return child === void 0 ? void 0 : {
						op: "not",
						child
					};
				}
				case "compare": {
					const variableId = requiredRef("variableId");
					const variable = typeof ast.variableId === "string" ? source.get(ast.variableId) : void 0;
					const comparator = ast.comparator;
					if (!variable || variable.kind !== "variable" || ![
						"eq",
						"ne",
						"lt",
						"le",
						"gt",
						"ge",
						"in"
					].includes(String(comparator))) break;
					let compared;
					if (comparator === "in" && Array.isArray(ast.value)) {
						const values = ast.value.map((item) => typedValue(item, variable.id, entity, field));
						if (values.every((item) => item !== void 0)) compared = values;
					} else compared = typedValue(ast.value, variable.id, entity, field);
					if (variableId && compared !== void 0) return {
						op: "compare",
						variableId,
						comparator: String(comparator),
						value: compared
					};
					return;
				}
				case "item": {
					const itemId = requiredRef("itemId");
					if (itemId && integer(ast.quantity) && ast.quantity >= 0) return {
						op: "item",
						itemId,
						quantity: ast.quantity
					};
					break;
				}
				case "known": {
					const assertionId = requiredRef("assertionId"), holderId = requiredRef("holderId");
					if (assertionId && holderId) return {
						op: "known",
						assertionId,
						holderId
					};
					return;
				}
				case "visited": {
					const entityId = requiredRef("entityId");
					if (entityId && integer(ast.count) && ast.count >= 0) return {
						op: "visited",
						entityId,
						count: ast.count
					};
					break;
				}
				case "external": {
					const contractId = requiredRef("contractId");
					if (contractId) return {
						op: "external",
						contractId
					};
					return;
				}
			}
			fail("EXPORT_UNSUPPORTED", "この条件は対応先で安全に表せません。", entity.id, field);
		};
		return visit(input, 1);
	};
	const publicField = (entity, field) => own(object$3(own(publicTexts, entity.id)), field);
	const textValue = (entity, field) => {
		const value = publicField(entity, field);
		if (typeof value === "string") return value;
		if (!empty(entity.data[field])) fail("PUBLIC_TEXT_REQUIRED", "原文の安全性は自動判定できません。公開用の文面を指定するか、この項目を除外してください。", entity.id, field);
	};
	const anchorValue = (value, entity, field) => {
		const input = object$3(value);
		if (!input) {
			fail("VALIDATION_FAILED", "本文位置が不正です。", entity.id, field);
			return;
		}
		if (input.positionStatus === "unresolved") {
			if (options.strictReferences) fail("REFERENCE_INVALID", "公開する本文位置の再リンクが必要です。", entity.id, field);
			else omit(entity.id, "位置不明の本文参照を除外", field);
			return;
		}
		const fixed = input.sourceVersionId && input.sourceVersionId !== project.projectId && input.sourceVersionId !== options.targetVersionId ? options.versionTargets?.[String(input.sourceVersionId)] : void 0;
		if (input.sourceVersionId && input.sourceVersionId !== project.projectId && input.sourceVersionId !== options.targetVersionId && !fixed) {
			fail("EXPORT_UNSUPPORTED", "別の固定版を指す位置には、その版の公開範囲確認が必要です。黙って現在位置へ移しません。", entity.id, field);
			return;
		}
		const targetMap = fixed?.idMap ?? idMap, targetId = fixed ? targetMap[String(input.entityId)] : reference(input.entityId, entity, field, true);
		if (!targetId) {
			fail("REFERENCE_INVALID", "引用固定版の公開対象がありません。", entity.id, field);
			return;
		}
		const output = {
			entityId: targetId,
			...fixed ? { sourceVersionId: fixed.publicVersionId } : {}
		};
		for (const key of ["blockId", "lineId"]) if (input[key] != null) {
			const sourceId = input[key];
			if (typeof sourceId !== "string" || !Object.prototype.hasOwnProperty.call(targetMap, sourceId)) {
				if (options.strictReferences) fail("REFERENCE_INVALID", "公開文に存在しない位置への参照です。", entity.id, field);
				else omit(entity.id, "非公開の本文位置を除外", field);
				return;
			}
			output[key] = targetMap[sourceId];
		}
		if (integer(input.start) && integer(input.end) && input.start >= 0 && input.end >= input.start) {
			output.start = input.start;
			output.end = input.end;
		}
		return output;
	};
	const richValue = (entity, field) => {
		const input = publicField(entity, field);
		if (typeof input === "string") return [{
			id: `${idMap[entity.id]}.${field}`,
			kind: "paragraph",
			text: input
		}];
		if (!Array.isArray(input)) {
			if (!empty(entity.data[field])) fail("PUBLIC_TEXT_REQUIRED", "公開用の本文を指定してください。原文の秘密は自動で除けません。", entity.id, field);
			return;
		}
		const output = [];
		for (const raw of input) {
			const block = object$3(raw);
			if (!block || typeof block.id !== "string" || !idMap[block.id] || !BLOCK_KINDS.has(String(block.kind)) || typeof block.text !== "string") {
				fail("VALIDATION_FAILED", "公開文の段落が不正です。", entity.id, field);
				continue;
			}
			const projected = {
				id: idMap[block.id],
				kind: String(block.kind),
				text: block.text
			};
			if (Array.isArray(block.unresolvedAnnotations) && block.unresolvedAnnotations.length) omit(entity.id, "再リンク待ちの本文注記を除外", field);
			const length = [...block.text].length;
			const validRange = (range) => integer(range.start) && integer(range.end) && range.start >= 0 && range.end > range.start && range.end <= length;
			if (Array.isArray(block.ruby)) {
				const ruby = [];
				for (const rawRuby of block.ruby) {
					const range = object$3(rawRuby);
					if (!range || !validRange(range) || typeof range.text !== "string") {
						fail("VALIDATION_FAILED", "公開文のルビ範囲が不正です。", entity.id, field);
						continue;
					}
					ruby.push({
						start: range.start,
						end: range.end,
						text: range.text
					});
				}
				projected.ruby = ruby;
			}
			if (Array.isArray(block.links)) {
				const links = [];
				for (const rawLink of block.links) {
					const range = object$3(rawLink);
					if (!range || !validRange(range)) {
						fail("VALIDATION_FAILED", "公開文のリンク範囲が不正です。", entity.id, field);
						continue;
					}
					const target = object$3(range.target) ?? range;
					if (target.positionStatus === "unresolved") {
						if (options.strictReferences) fail("REFERENCE_INVALID", "公開文のリンク先位置の再リンクが必要です。", entity.id, field);
						else omit(entity.id, "位置不明のリンクを除外", field);
						continue;
					}
					const fixed = target.sourceVersionId && target.sourceVersionId !== project.projectId && target.sourceVersionId !== options.targetVersionId ? options.versionTargets?.[String(target.sourceVersionId)] : void 0, targetMap = fixed?.idMap ?? idMap;
					if (target.sourceVersionId && target.sourceVersionId !== project.projectId && target.sourceVersionId !== options.targetVersionId && !fixed) {
						fail("EXPORT_UNSUPPORTED", "公開リンクには別の固定版の公開確認が必要です。現在位置へ代用しません。", entity.id, field);
						continue;
					}
					const targetId = fixed ? targetMap[String(target.targetId ?? target.entityId)] : reference(target.targetId ?? target.entityId, entity, `${field}.links`);
					if (!targetId) continue;
					const link = {
						start: range.start,
						end: range.end,
						targetId
					};
					if (target.sourceVersionId) link.sourceVersionId = fixed?.publicVersionId ?? "public-project";
					if (integer(target.start) && integer(target.end)) {
						link.targetStart = target.start;
						link.targetEnd = target.end;
					}
					let valid = true;
					for (const key of ["blockId", "lineId"]) if (target[key] != null) {
						const origin = target[key];
						if (typeof origin !== "string" || !Object.prototype.hasOwnProperty.call(targetMap, origin)) {
							if (options.strictReferences) fail("REFERENCE_INVALID", "公開文に存在しない位置へのリンクです。", entity.id, field);
							else omit(entity.id, "非公開の位置へのリンクを除外", field);
							valid = false;
							break;
						}
						link[key] = targetMap[origin];
					}
					if (valid) links.push(link);
				}
				if (links.length) projected.links = links;
			}
			output.push(projected);
		}
		return output;
	};
	const behaviorText = (entity, field) => {
		return textValue(entity, field) ?? "";
	};
	const scopeValue = (value, entity, field) => {
		const input = object$3(value);
		if (!input || input.projectId !== project.projectId) {
			fail("REFERENCE_INVALID", "対象作品の範囲を公開先へ対応できません。", entity.id, field);
			return;
		}
		const output = { projectId: "public-project" };
		for (const key of ["graphId", "chapterId"]) if (input[key] != null) {
			const mapped = reference(input[key], entity, field, true);
			if (!mapped) return;
			output[key] = mapped;
		}
		if (input.targetSnapshotId != null) {
			if (input.targetSnapshotId !== project.projectId && input.targetSnapshotId !== options.targetVersionId) {
				fail("EXPORT_UNSUPPORTED", "別版限定の範囲を現在版へ代用しません。", entity.id, field);
				return;
			}
			output.targetSnapshotId = "public-project";
		}
		if (input.routeCondition != null) {
			const mapped = conditionValue(input.routeCondition, entity, field);
			if (!mapped) return;
			output.routeCondition = mapped;
		}
		return output;
	};
	const validityValue = (value, entity, field) => {
		const input = object$3(value);
		if (!input) return;
		let range = null;
		if (input.worldRange != null) {
			const raw = object$3(input.worldRange);
			if (!raw || ["start", "end"].some((key) => raw[key] !== null && (typeof raw[key] !== "string" || !TICK.test(String(raw[key]))))) {
				fail("VALIDATION_FAILED", "期間の整数tickが不正です。", entity.id, field);
				return;
			}
			range = {
				start: raw.start,
				end: raw.end
			};
		}
		const route = input.routeCondition == null ? null : conditionValue(input.routeCondition, entity, field), anchor = input.presentationAnchor == null ? null : anchorValue(input.presentationAnchor, entity, field);
		if (route === void 0 || anchor === void 0) return;
		return {
			worldRange: range,
			routeCondition: route,
			presentationAnchor: anchor
		};
	};
	const exceptionValue = (value, entity, field) => {
		const input = object$3(value);
		if (!input) return;
		const target = scopeValue(input.targetScope, entity, field), validity = validityValue(input.validity, entity, field);
		if (!target || !validity || !Array.isArray(input.evidenceIds)) return;
		const evidence = input.evidenceIds.map((id) => reference(id, entity, field, true));
		if (evidence.some((id) => !id)) return;
		const reason = behaviorText(entity, "exceptionReason");
		if (!reason.trim()) {
			fail("PUBLIC_TEXT_REQUIRED", "有限例外の公開用理由を指定してください。", entity.id, field);
			return;
		}
		return {
			reason,
			targetScope: target,
			validity,
			evidenceIds: evidence
		};
	};
	const expressionValue = (value, entity, field, depth = 0) => {
		if (depth > 64) {
			fail("EXPORT_UNSUPPORTED", "算出式の上限を超えています。", entity.id, field);
			return;
		}
		const input = object$3(value);
		if (!input) return;
		if (input.op === "value") {
			const mapped = typedValue(input.value, entity.id, entity, field);
			return mapped ? {
				op: "value",
				value: mapped
			} : void 0;
		}
		if (input.op === "variable") {
			const id = reference(input.variableId, entity, field, true);
			return id ? {
				op: "variable",
				variableId: id
			} : void 0;
		}
		if ([
			"add",
			"subtract",
			"multiply"
		].includes(String(input.op))) {
			const left = expressionValue(input.left, entity, field, depth + 1), right = expressionValue(input.right, entity, field, depth + 1);
			return left && right ? {
				op: String(input.op),
				left,
				right
			} : void 0;
		}
		if (input.op === "if") {
			const condition = conditionValue(input.condition, entity, field), yes = expressionValue(input.then, entity, field, depth + 1), no = expressionValue(input.else, entity, field, depth + 1);
			return condition && yes && no ? {
				op: "if",
				condition,
				then: yes,
				else: no
			} : void 0;
		}
		return conditionValue(input, entity, field);
	};
	const serialize = (entity, field, rule) => {
		const value = entity.data[field];
		if (rule.type === "text") return textValue(entity, field);
		if (rule.type === "rich") return richValue(entity, field);
		if (value == null) return void 0;
		switch (rule.type) {
			case "public_strings": {
				if (Array.isArray(value) && !value.length) return [];
				let approved;
				try {
					approved = JSON.parse(String(publicField(entity, field)));
				} catch {}
				if (Array.isArray(approved) && approved.every((item) => typeof item === "string")) return approved;
				fail("PUBLIC_TEXT_REQUIRED", "公開用の文字列一覧をJSON文章で指定してください。", entity.id, field);
				return;
			}
			case "real_date": {
				const input = object$3(value);
				if (input && typeof input.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(input.date) && typeof input.timeZone === "string") return {
					date: input.date,
					timeZone: input.timeZone
				};
				break;
			}
			case "estimate": {
				const input = object$3(value);
				let assumptions;
				try {
					assumptions = JSON.parse(String(publicField(entity, "estimateAssumptions")));
				} catch {}
				const source = publicField(entity, "estimateSource"), unit = publicField(entity, "estimateUnit");
				if (!input || !Array.isArray(assumptions) || assumptions.some((item) => typeof item !== "string") || typeof source !== "string" || typeof unit !== "string") {
					fail("PUBLIC_TEXT_REQUIRED", "見積の公開用仮定と出所を指定してください。", entity.id, field);
					return;
				}
				const scope = scopeValue(input.scope, entity, field);
				if (!scope) return;
				return {
					unit,
					assumptions,
					source,
					unknownCount: Number(input.unknownCount),
					scope,
					...input.value != null ? { value: Number(input.value) } : {},
					...input.range ? { range: input.range } : {},
					...input.speed != null ? { speed: Number(input.speed) } : {}
				};
			}
			case "parameters": {
				if (!Array.isArray(value)) break;
				const approved = publicField(entity, "parameters");
				let names;
				try {
					names = typeof approved === "string" ? JSON.parse(approved) : void 0;
				} catch {}
				if (value.length && !object$3(names)) {
					fail("PUBLIC_TEXT_REQUIRED", "公開用の引数名をkey→公開keyのJSON文章で指定してください。", entity.id, field);
					return;
				}
				const output = [];
				for (const raw of value) {
					const input = object$3(raw), key = input && own(object$3(names), String(input.key));
					if (!input || typeof key !== "string" || !/^[-_.a-zA-Z0-9]{1,128}$/.test(key) || ![
						"boolean",
						"integer",
						"enum"
					].includes(String(input.type))) {
						fail("PUBLIC_TEXT_REQUIRED", "引数の公開名と型を確認してください。", entity.id, field);
						return;
					}
					const initial = input.default == null ? void 0 : typedValue(input.default, entity.id, entity, field);
					if (input.default != null && !initial) return;
					output.push({
						key,
						type: String(input.type),
						...initial ? { default: initial } : {}
					});
				}
				return output;
			}
			case "expression": return expressionValue(value, entity, field);
			case "scope": return scopeValue(value, entity, field);
			case "validity": return validityValue(value, entity, field);
			case "exception": return exceptionValue(value, entity, field);
			case "exceptions": {
				if (!Array.isArray(value)) break;
				const mapped = value.map((item) => exceptionValue(item, entity, field));
				return mapped.every((item) => item !== void 0) ? mapped : void 0;
			}
			case "resets": {
				if (!Array.isArray(value)) break;
				const output = [];
				for (const raw of value) {
					const input = object$3(raw);
					if (!input || ![
						"scene_end",
						"chapter_end",
						"run_end",
						"new_loop",
						"full_reset"
					].includes(String(input.on))) break;
					const mapped = typedValue(input.value, entity.id, entity, field);
					if (!mapped) return;
					output.push({
						on: String(input.on),
						value: mapped,
						reason: behaviorText(entity, "resetReason")
					});
				}
				if (output.length !== value.length) break;
				return output;
			}
			case "exclusions": {
				if (!Array.isArray(value)) break;
				const output = [];
				for (const raw of value) {
					const input = object$3(raw);
					if (!input) return;
					const variableId = reference(input.variableId, entity, field, true), current = typedValue(input.value, entity.id, entity, field), other = typedValue(input.otherValue, String(input.variableId), entity, field), exceptions = input.exceptions == null ? [] : Array.isArray(input.exceptions) ? input.exceptions.map((item) => exceptionValue(item, entity, field)) : void 0;
					if (!variableId || !current || !other || !exceptions || exceptions.some((item) => !item)) return;
					const reason = behaviorText(entity, "exclusionReason");
					if (!reason.trim()) {
						fail("PUBLIC_TEXT_REQUIRED", "相互排他の公開用理由を指定してください。", entity.id, field);
						return;
					}
					output.push({
						variableId,
						value: current,
						otherValue: other,
						reason,
						exceptions
					});
				}
				return output;
			}
			case "alternatives": {
				const input = object$3(value);
				if (!input) break;
				const output = {};
				for (const [key, ids] of Object.entries(input)) {
					const id = reference(key, entity, field, true);
					if (!id || !Array.isArray(ids)) return;
					const mapped = ids.map((item) => reference(item, entity, field, true));
					if (mapped.some((item) => !item)) return;
					output[id] = mapped;
				}
				return output;
			}
			case "camera": {
				const approved = publicField(entity, field);
				let input;
				try {
					input = typeof approved === "string" ? JSON.parse(approved) : void 0;
				} catch {
					break;
				}
				const camera = object$3(input);
				if (!camera) {
					fail("PUBLIC_TEXT_REQUIRED", "公開用カメラ指定をJSON文章で指定してください。", entity.id, field);
					return;
				}
				const output = {};
				for (const [key, item] of Object.entries(camera)) {
					if (![
						"shot",
						"angle",
						"movement",
						"durationMs"
					].includes(key) || !(typeof item === "string" || typeof item === "number" && Number.isFinite(item) && item >= 0)) {
						fail("EXPORT_UNSUPPORTED", "カメラの指定項目を安全に表せません。", entity.id, field);
						return;
					}
					output[key] = item;
				}
				return output;
			}
			case "ref": return reference(value, entity, field, BEHAVIOR_REFS.has(field));
			case "refs":
				if (!Array.isArray(value)) break;
				return value.map((id) => reference(id, entity, field, options.strictReferences && BEHAVIOR_REFS.has(field))).filter((id) => id !== void 0);
			case "number":
				if (typeof value === "number" && Number.isFinite(value)) return value;
				break;
			case "boolean":
				if (typeof value === "boolean") return value;
				break;
			case "enum":
				if (typeof value === "string" && rule.values.includes(value)) return value;
				break;
			case "condition": return conditionValue(value, entity, field);
			case "typed": return typedValue(value, entity.kind === "effect" && typeof entity.data.targetId === "string" ? entity.data.targetId : entity.id, entity, field);
			case "typeds": {
				if (!Array.isArray(value)) break;
				const output = value.map((item) => typedValue(item, entity.id, entity, field));
				return output.every((item) => item !== void 0) ? output : void 0;
			}
			case "semver":
				if (typeof value === "string" && /^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/.test(value)) return value;
				break;
			case "allowed": {
				const input = object$3(value);
				if (!input) break;
				const output = {};
				if (input.min !== void 0 || input.max !== void 0) {
					if (!integer(input.min) || !integer(input.max) || input.min > input.max) break;
					output.min = input.min;
					output.max = input.max;
				}
				if (Array.isArray(input.values)) {
					const values = input.values.map((item) => typeof item === "string" ? mapEnum(item, entity.id, entity, field) : typeof item === "boolean" || integer(item) ? item : void 0);
					if (values.some((item) => item === void 0)) break;
					if (new Set(values).size !== values.length) {
						fail("VALIDATION_FAILED", "公開列挙値が重複しています。", entity.id, field);
						return;
					}
					output.values = values;
				}
				return output;
			}
			case "time": {
				const input = object$3(value);
				if (!input) break;
				const output = { mode: String(input.mode) };
				if ([
					"instant",
					"interval",
					"uncertain"
				].includes(String(input.mode))) {
					const fields = input.mode === "instant" ? ["at"] : input.mode === "interval" ? ["start", "end"] : ["earliest", "latest"];
					for (const key of fields) {
						if (typeof input[key] !== "string" || !TICK.test(input[key])) {
							fail("VALIDATION_FAILED", "世界日時のtickが不正です。", entity.id, field);
							return;
						}
						output[key] = input[key];
					}
					const calendarId = publicCalendarId(input.calendarId, entity, field);
					if (!calendarId) return void 0;
					output.calendarId = calendarId;
					if (input.mode === "uncertain") output.precision = textValue(entity, "precision") ?? "";
					return output;
				}
				if (input.mode === "unknown") {
					const reason = publicField(entity, "reason");
					return {
						mode: "unknown",
						reason: typeof reason === "string" ? reason : ""
					};
				}
				if (input.mode === "relative") {
					const anchorEventId = reference(input.anchorEventId, entity, field, true);
					if (anchorEventId && ["start", "end"].includes(String(input.anchorPoint)) && typeof input.minOffset === "string" && TICK.test(input.minOffset) && typeof input.maxOffset === "string" && TICK.test(input.maxOffset)) return {
						mode: "relative",
						anchorEventId,
						anchorPoint: String(input.anchorPoint),
						minOffset: input.minOffset,
						maxOffset: input.maxOffset
					};
				}
				break;
			}
			case "participants": {
				if (!Array.isArray(value)) break;
				const output = [];
				for (const raw of value) {
					const participant = object$3(raw);
					if (!participant) continue;
					const characterId = reference(participant.characterId, entity, field);
					if (!characterId) continue;
					if (![
						"actor",
						"witness",
						"mentioned",
						"informed",
						"custom"
					].includes(String(participant.role))) {
						fail("VALIDATION_FAILED", "参加役割が不正です。", entity.id, field);
						continue;
					}
					output.push({
						characterId,
						role: String(participant.role)
					});
				}
				return output;
			}
			case "pins": {
				if (!Array.isArray(value)) break;
				const output = [];
				for (const raw of value) {
					const pin = object$3(raw);
					if (!pin) continue;
					const placeId = reference(pin.placeId, entity, field);
					if (!placeId) continue;
					if (typeof pin.x !== "number" || typeof pin.y !== "number" || pin.x < 0 || pin.x > 1 || pin.y < 0 || pin.y > 1) {
						fail("VALIDATION_FAILED", "地図座標が不正です。", entity.id, field);
						continue;
					}
					output.push({
						placeId,
						x: pin.x,
						y: pin.y
					});
				}
				return output;
			}
			case "datetime":
				if (typeof value === "string" && Number.isFinite(Date.parse(value))) return value;
				break;
			case "version_ref": {
				const fixed = options.versionTargets?.[String(value)];
				if (!fixed) {
					fail("EXPORT_UNSUPPORTED", "媒体の元固定版の公開範囲を確認してください。", entity.id, field);
					return;
				}
				return fixed.publicVersionId;
			}
			case "anchor": return anchorValue(value, entity, field);
			case "trigger": {
				const input = object$3(value);
				if (!input || ![
					"enter",
					"talk",
					"battle_result",
					"manual",
					"custom"
				].includes(String(input.event)) || !["once", "repeatable"].includes(String(input.repeat))) break;
				const eventKey = textValue(entity, "eventKey");
				if (typeof input.eventKey === "string" && input.eventKey && eventKey === void 0) {
					fail("PUBLIC_TEXT_REQUIRED", "外部イベント名の公開表記を指定してください。", entity.id, "eventKey");
					return;
				}
				const deadline = input.deadline != null ? serialize({
					...entity,
					data: {
						...entity.data,
						deadline: input.deadline
					}
				}, "deadline", time) : void 0;
				if (input.deadline != null && deadline === void 0) return void 0;
				const output = {
					event: String(input.event),
					repeat: String(input.repeat),
					eventKey: eventKey ?? ""
				};
				if (typeof input.id === "string" && idMap[input.id]) output.id = idMap[input.id];
				if (input.scope != null) {
					if (![
						"scene",
						"chapter",
						"character",
						"run",
						"across_runs"
					].includes(String(input.scope))) break;
					output.scope = String(input.scope);
				}
				if (deadline !== void 0) output.deadline = deadline;
				return output;
			}
			case "transitions": {
				if (!Array.isArray(value)) break;
				const output = [];
				const variableId = entity.kind === "quest" && typeof entity.data.stateVariableId === "string" ? entity.data.stateVariableId : entity.id;
				for (const raw of value) {
					const transition = object$3(raw);
					if (!transition) {
						fail("VALIDATION_FAILED", "状態遷移の形が不正です。", entity.id, field);
						continue;
					}
					const from = typedValue(transition.from, variableId, entity, field), to = typedValue(transition.to, variableId, entity, field);
					const details = transition.exceptionDetails ? exceptionValue(transition.exceptionDetails, entity, field) : void 0;
					if (transition.exception === true && !details) {
						fail("EXPORT_UNSUPPORTED", "理由・範囲・期限・根拠のある例外を公開範囲へ含めてください。", entity.id, field);
						continue;
					}
					if (from !== void 0 && to !== void 0) output.push({
						from,
						to,
						...details ? {
							exception: true,
							exceptionDetails: details
						} : {}
					});
				}
				return output;
			}
		}
		fail("EXPORT_UNSUPPORTED", "この項目は対応先で安全に表せません。", entity.id, field);
	};
	const entities = [];
	for (const entity of selected) {
		const schema = PROJECTION_FIELDS[entity.kind];
		const explicit = own(allowedFields, entity.kind);
		const fields = Array.isArray(explicit) ? explicit : Object.keys(schema);
		const output = {};
		for (const field of fields) {
			if (typeof field !== "string" || FORBIDDEN_FIELDS.has(field) || !hasOwn(schema, field)) {
				fail("FORBIDDEN", "許可されていない項目を公開しようとしています。", entity.id, String(field));
				continue;
			}
			if (excludedFields.includes(field) || excludedFields.includes(`${entity.kind}.${field}`)) {
				omit(entity.id, "作者が項目を除外", field);
				continue;
			}
			const value = serialize(entity, field, schema[field]);
			if (value !== void 0) output[field] = value;
		}
		for (const field of Object.keys(entity.data)) if (!fields.includes(field) || !hasOwn(schema, field)) omit(entity.id, FORBIDDEN_FIELDS.has(field) ? "作者情報・秘密の項目を除外" : "公開を許可していない項目を除外", field);
		if (entity.kind === "attachment") {
			const approved = Array.isArray(policy.approvedAttachmentIds) && policy.approvedAttachmentIds.includes(entity.id);
			const provenance = typeof entity.data.provenanceId === "string" ? source.get(entity.data.provenanceId) : void 0;
			if (!approved || provenance && provenance.data.redistributionAllowed !== true) fail("FORBIDDEN", "添付の再配布許可を確認してください。", entity.id);
			const mediaType = entity.data.mediaType;
			if (typeof mediaType !== "string" || !ASSET_TYPES[mediaType]) fail("EXPORT_UNSUPPORTED", "この素材形式は公開出力に対応していません。", entity.id, "mediaType");
			else {
				output.mediaType = mediaType;
				output.assetPath = `assets/${idMap[entity.id]}.${ASSET_TYPES[mediaType]}`;
			}
			if (typeof entity.data.contentHash !== "string" || !/^[a-f0-9]{64}$/.test(entity.data.contentHash) || !integer(entity.data.byteSize) || entity.data.byteSize < 0) fail("VALIDATION_FAILED", "素材のhashとサイズが不正です。", entity.id);
			else {
				output.contentHash = entity.data.contentHash;
				output.byteSize = entity.data.byteSize;
				output.bytesIncluded = false;
			}
		}
		if (entity.kind === "source" && entity.data.sourceType === "web" && typeof output.locator === "string") try {
			const url = new URL(output.locator);
			if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) throw new Error();
		} catch {
			fail("FORBIDDEN", "公開資料のURLは認証情報を含まないHTTP/HTTPSにしてください。", entity.id, "locator");
		}
		entities.push({
			id: idMap[entity.id],
			kind: entity.kind,
			name: names.get(entity.id),
			status: entity.status,
			data: output
		});
	}
	const relations = [];
	const relationIds = Array.isArray(policy.allowedRelationIds) ? policy.allowedRelationIds : [];
	const relationSource = new Map(project.relations.map((relation) => [relation.id, relation]));
	for (const rawId of relationIds) {
		if (typeof rawId !== "string") {
			fail("VALIDATION_FAILED", "関係の公開IDが不正です。", profileId, "allowedRelationIds");
			continue;
		}
		const relation = relationSource.get(rawId);
		if (!relation || relation.projectId !== project.projectId) {
			fail("REFERENCE_INVALID", "作品内にない関係が公開範囲に含まれています。", rawId);
			continue;
		}
		if (!selectedIds.has(relation.fromId) || !selectedIds.has(relation.toId) || relation.status !== "confirmed" || relation.deletedAt) {
			omit(rawId, "非公開の始点・終点、削除済みまたは未確定の関係");
			continue;
		}
		const publicRelationType = own(object$3(own(publicTexts, rawId)), "relationType");
		if (typeof publicRelationType !== "string" || !publicRelationType) {
			fail("PUBLIC_TEXT_REQUIRED", "公開用の関係名を指定してください。", rawId, "relationType");
			continue;
		}
		addId(rawId);
		const validity = validityValue(relation.validity, {
			id: rawId,
			projectId: project.projectId,
			kind: "note",
			name: "",
			status: relation.status,
			data: {}
		}, "validity");
		relations.push({
			...validity ? { validity } : {},
			id: idMap[rawId],
			fromId: idMap[relation.fromId],
			toId: idMap[relation.toId],
			relationType: publicRelationType,
			direction: relation.direction,
			evidenceIds: relation.evidenceIds.filter((id) => selectedIds.has(id)).map((id) => idMap[id])
		});
	}
	if (issues.length) return {
		ok: false,
		issues,
		omissions
	};
	const projection = {
		format: "scenario-projection",
		formatVersion: "1.0.0",
		title,
		mainStart: project.mainStart,
		calendars,
		entities,
		relations,
		searchIndex: []
	};
	projection.searchIndex = buildProjectionSearchIndex(projection);
	return {
		ok: true,
		projection,
		omissions,
		idMap
	};
}
/** A scope can narrow an ID allowlist; it never adds an ID the author did not approve. */
function scopedEntityIds(source, policy, projectId, publicTexts, fail) {
	const scope = object$3(policy.routeScope);
	if (!scope) return void 0;
	if (scope.projectId !== projectId) {
		fail("REFERENCE_INVALID", "公開範囲が別の作品を参照しています。", void 0, "routeScope");
		return /* @__PURE__ */ new Set();
	}
	if (scope.routeCondition != null) {
		fail("EXPORT_UNSUPPORTED", "条件付き経路の安全な公開範囲は未対応です。IDまたは章・グラフで限定してください。", void 0, "routeScope.routeCondition");
		return /* @__PURE__ */ new Set();
	}
	if (scope.chapterId != null && scope.graphId != null) {
		fail("EXPORT_UNSUPPORTED", "章とグラフの範囲は一度に一つ選んでください。", void 0, "routeScope");
		return /* @__PURE__ */ new Set();
	}
	if (scope.chapterId == null && scope.graphId == null) return void 0;
	const rootId = scope.chapterId ?? scope.graphId;
	const root = typeof rootId === "string" ? source.get(rootId) : void 0;
	if (!root || root.projectId !== projectId || root.kind !== (scope.chapterId != null ? "chapter" : "flow_graph") || root.deletedAt) {
		fail("REFERENCE_INVALID", "公開範囲の章またはグラフが見つかりません。", typeof rootId === "string" ? rootId : void 0, "routeScope");
		return /* @__PURE__ */ new Set();
	}
	const approved = new Set(Array.isArray(policy.includedIds) ? policy.includedIds.filter((id) => typeof id === "string") : []);
	const narrative = /* @__PURE__ */ new Set();
	const scenes = /* @__PURE__ */ new Set();
	if (root.kind === "chapter") {
		narrative.add(root.id);
		for (const entity of source.values()) if (entity.kind === "scene" && (entity.data.chapterId === root.id || Array.isArray(root.data.sceneIds) && root.data.sceneIds.includes(entity.id))) scenes.add(entity.id);
	} else {
		const graphs = [root], visitedGraphs = /* @__PURE__ */ new Set();
		while (graphs.length) {
			const graph = graphs.pop();
			if (visitedGraphs.has(graph.id)) continue;
			visitedGraphs.add(graph.id);
			narrative.add(graph.id);
			for (const value of [...Array.isArray(graph.data.nodeIds) ? graph.data.nodeIds : [], ...Array.isArray(graph.data.edgeIds) ? graph.data.edgeIds : []]) if (typeof value === "string") narrative.add(value);
			for (const value of Array.isArray(graph.data.nodeIds) ? graph.data.nodeIds : []) {
				const node = typeof value === "string" ? source.get(value) : void 0;
				if (!node || node.kind !== "flow_node") continue;
				if (typeof node.data.sceneId === "string") scenes.add(node.data.sceneId);
				const child = typeof node.data.childGraphId === "string" ? source.get(node.data.childGraphId) : void 0;
				if (child?.kind === "flow_graph" && approved.has(child.id)) graphs.push(child);
			}
		}
	}
	const eligible = (entity) => {
		if (entity.kind === "scene") return scenes.has(entity.id);
		if ([
			"flow_graph",
			"flow_node",
			"flow_edge"
		].includes(entity.kind)) return root.kind === "flow_graph" && narrative.has(entity.id);
		if (entity.kind === "chapter") return root.kind === "chapter" ? entity.id === root.id : [...scenes].some((id) => source.get(id)?.data.chapterId === entity.id);
		return true;
	};
	const result = /* @__PURE__ */ new Set(), queue = [...narrative, ...scenes];
	const enqueue = (value) => {
		if (typeof value === "string" && approved.has(value)) queue.push(value);
	};
	const conditionRefs = (value, depth = 1) => {
		const ast = object$3(value);
		if (!ast || depth > 16) return;
		for (const field of [
			"variableId",
			"itemId",
			"assertionId",
			"holderId",
			"entityId",
			"contractId"
		]) enqueue(ast[field]);
		if (Array.isArray(ast.children)) ast.children.forEach((child) => conditionRefs(child, depth + 1));
		if (ast.child) conditionRefs(ast.child, depth + 1);
	};
	while (queue.length) {
		const id = queue.pop();
		if (result.has(id) || !approved.has(id)) continue;
		const entity = source.get(id);
		if (!entity || !eligible(entity)) continue;
		result.add(id);
		for (const [field, rule] of Object.entries(PROJECTION_FIELDS[entity.kind] ?? {})) {
			if (field === "parentId" || field === "parentGraphId") continue;
			const value = entity.data[field];
			if (rule.type === "ref") enqueue(value);
			else if (rule.type === "refs" && Array.isArray(value)) value.forEach(enqueue);
			else if (rule.type === "condition") conditionRefs(value);
			else if (rule.type === "typed" && object$3(value)?.type === "ref") enqueue(object$3(value)?.value);
			else if (rule.type === "time") enqueue(object$3(value)?.anchorEventId);
			else if (rule.type === "anchor") {
				enqueue(object$3(value)?.entityId);
				enqueue(object$3(value)?.lineId);
			} else if (rule.type === "participants" && Array.isArray(value)) value.forEach((value) => enqueue(object$3(value)?.characterId));
			else if (rule.type === "pins" && Array.isArray(value)) value.forEach((value) => enqueue(object$3(value)?.placeId));
			else if (rule.type === "rich") {
				const document = own(object$3(own(publicTexts, entity.id)), field);
				if (Array.isArray(document)) {
					for (const block of document) if (Array.isArray(object$3(block)?.links)) for (const link of object$3(block).links) {
						const target = object$3(object$3(link)?.target) ?? object$3(link);
						enqueue(target?.entityId ?? target?.targetId);
						enqueue(target?.lineId);
					}
				}
			}
		}
	}
	return result;
}
function publicStrings(value) {
	if (typeof value === "string") return [value];
	if (Array.isArray(value)) return value.flatMap(publicStrings);
	if (value && typeof value === "object") return Object.entries(value).filter(([key]) => [
		"text",
		"reading",
		"summary",
		"body",
		"description",
		"label",
		"canonical"
	].includes(key)).flatMap(([, child]) => publicStrings(child));
	return [];
}
function buildProjectionSearchIndex(projection) {
	return projection.entities.map((entity) => {
		const text = [entity.name, ...publicStrings(entity.data)].join("\n");
		return {
			entityId: entity.id,
			kind: entity.kind,
			name: entity.name,
			text,
			normalized: text.normalize("NFKC").toLocaleLowerCase("ja")
		};
	});
}
var text, rich, ref, refs, number, boolean, time, condition, typed, oneOf, PROJECTION_FIELDS, PROJECTABLE_KINDS, BEHAVIOR_REFS, FORBIDDEN_FIELDS, BLOCK_KINDS, ASSET_TYPES, TICK, object$3, own, hasOwn, empty, integer;
var init_projection = __esmMin((() => {
	text = { type: "text" };
	rich = { type: "rich" };
	ref = { type: "ref" };
	refs = { type: "refs" };
	number = { type: "number" };
	boolean = { type: "boolean" };
	time = { type: "time" };
	condition = { type: "condition" };
	typed = { type: "typed" };
	oneOf = (...values) => ({
		type: "enum",
		values
	});
	PROJECTION_FIELDS = Object.freeze({
		character: {
			reading: text,
			summary: rich,
			body: rich,
			birth: time,
			death: time
		},
		group: {
			groupType: oneOf("display", "faction", "plot_thread", "category"),
			members: refs,
			parentId: ref,
			summary: rich
		},
		event: {
			summary: rich,
			time,
			laneRole: oneOf("common", "participants", "both"),
			participants: { type: "participants" },
			locationId: ref,
			itemIds: refs
		},
		place: {
			parentId: ref,
			reading: text,
			body: rich,
			mapIds: refs
		},
		item: {
			itemMode: oneOf("type", "instance"),
			typeId: ref,
			body: rich
		},
		note: {
			body: rich,
			attachmentIds: refs
		},
		chapter: {
			sceneIds: refs,
			summary: rich
		},
		scene: {
			summary: rich,
			body: rich,
			eventIds: refs,
			dialogueLineIds: refs,
			chapterId: ref,
			threadIds: refs,
			povId: ref,
			blockIds: refs,
			tension: number,
			importance: number
		},
		goal: {
			ownerId: ref,
			description: rich,
			changes: refs,
			evidenceSceneIds: refs
		},
		flow_node: {
			nodeType: oneOf("scene", "choice", "automatic", "call", "entry", "exit", "terminal"),
			sceneId: ref,
			childGraphId: ref,
			terminalReason: text,
			trigger: { type: "trigger" },
			gate: condition,
			executionPolicy: oneOf("manual_choice", "first_match", "all_match"),
			fallbackId: ref,
			shownInformationIds: refs
		},
		flow_edge: {
			fromId: ref,
			toId: ref,
			edgeType: oneOf("choice", "automatic", "call_return"),
			label: text,
			condition,
			effectIds: refs,
			priority: number,
			choiceLineId: ref
		},
		flow_graph: {
			nodeIds: refs,
			edgeIds: refs,
			entryIds: refs,
			exitIds: refs,
			parentGraphId: ref,
			parameters: { type: "parameters" }
		},
		dialogue_line: {
			text: rich,
			speakerId: ref,
			choiceEdgeId: ref,
			cueIds: refs
		},
		quest: {
			key: text,
			stateVariableId: ref,
			description: rich,
			flowIds: refs,
			transitionRules: { type: "transitions" }
		},
		lore: {
			body: rich,
			assertionIds: refs,
			reading: text
		},
		variable: {
			key: text,
			valueType: oneOf("boolean", "integer", "enum"),
			scope: oneOf("scene", "chapter", "character", "run", "across_runs"),
			initial: typed,
			allowed: { type: "allowed" },
			ownerId: ref,
			externalContractId: ref,
			externalUseDeclared: boolean,
			description: rich,
			derived: { type: "expression" },
			resetRules: { type: "resets" },
			exclusions: { type: "exclusions" },
			transitionRules: { type: "transitions" }
		},
		effect: {
			operation: oneOf("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset"),
			targetId: ref,
			value: typed,
			condition,
			instanceId: ref,
			reason: text,
			exceptionDetails: { type: "exception" }
		},
		assertion: {
			subjectId: ref,
			predicate: text,
			value: typed,
			truthKind: oneOf("author_truth", "testimony", "belief", "hypothesis"),
			holderId: ref,
			sourceIds: refs,
			evidenceLocation: { type: "anchor" },
			reason: text,
			validity: { type: "validity" }
		},
		foreshadow: {
			question: rich,
			intent: rich,
			truthAssertionIds: refs,
			clueIds: refs,
			payoffIds: refs,
			requiredInfo: refs,
			alternativeInfo: { type: "alternatives" },
			deadline: { type: "scope" },
			exceptions: { type: "exceptions" },
			presentationDeadline: { type: "anchor" },
			resolutionPolicy: oneOf("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")
		},
		disclosure: {
			foreshadowId: ref,
			anchor: { type: "anchor" },
			stage: oneOf("hint", "suspicion", "reinforce", "reveal", "alternative"),
			role: oneOf("clue", "payoff"),
			targetScope: { type: "scope" },
			condition,
			knowledgeEffects: refs
		},
		attachment: { displayName: text },
		source: {
			accessedAt: { type: "datetime" },
			excerptLocation: text,
			attachmentId: ref,
			sourceType: oneOf("web", "file", "book", "observation"),
			locator: text,
			interpretation: rich,
			redistributionAllowed: boolean
		},
		cue: {
			anchor: { type: "anchor" },
			cueType: text,
			attachmentId: ref,
			speakerId: ref,
			expression: text,
			waitMs: number,
			mediaTime: number,
			camera: { type: "camera" }
		},
		storyboard_frame: {
			anchor: { type: "anchor" },
			mediaStartMs: number,
			mediaEndMs: number,
			referenceAssetId: ref,
			finalAssetId: ref,
			cueIds: refs,
			caption: rich
		},
		localization: {
			sourceLineId: ref,
			language: text,
			text: rich,
			stage: oneOf("draft", "reviewed", "needs_review"),
			recordingIds: refs
		},
		recording: {
			sourceLineId: ref,
			language: text,
			translationId: ref,
			attachmentId: ref,
			stage: oneOf("planned", "recorded", "reviewed", "needs_review")
		},
		terminology: {
			canonical: text,
			reading: text,
			variants: { type: "public_strings" },
			validity: { type: "validity" },
			exceptions: { type: "exceptions" },
			language: text,
			usageNotes: rich,
			voiceOwnerId: ref
		},
		voice_rule: {
			characterId: ref,
			validity: { type: "validity" },
			firstPerson: text,
			addressing: text,
			phrasing: text,
			examples: rich,
			exceptions: { type: "exceptions" }
		},
		map: {
			placeId: ref,
			coordinateSystem: oneOf("normalized"),
			attachmentId: ref,
			parentMapId: ref,
			pins: { type: "pins" }
		},
		travel_route: {
			fromPlaceId: ref,
			toPlaceId: ref,
			direction: oneOf("one_way", "two_way"),
			method: text
		},
		collection: {
			mode: oneOf("fixed"),
			memberIds: refs
		},
		gameplay_spec: {
			sceneId: ref,
			action: rich,
			mechanic: text,
			tutorial: rich,
			reward: typed,
			questId: ref,
			taskIds: refs,
			intentionalDifference: text
		},
		production_task: {
			deadline: { type: "real_date" },
			estimate: { type: "estimate" },
			blockingReason: text,
			targetIds: refs,
			stage: oneOf("writing", "review", "implementation", "translation", "recording", "verification", "publication"),
			progress: oneOf("todo", "doing", "done", "needs_review"),
			dependsOn: refs
		},
		media_variant: {
			medium: oneOf("game", "novel", "video", "audio", "promotion", "custom"),
			baseSnapshotId: { type: "version_ref" },
			previousVariantId: ref,
			releaseAt: { type: "datetime" },
			body: rich,
			sourceIds: refs,
			needsReview: boolean
		},
		external_contract: {
			key: text,
			owner: oneOf("tool", "game"),
			inputType: oneOf("boolean", "integer", "enum"),
			outputType: oneOf("boolean", "integer", "enum"),
			missingPolicy: oneOf("unknown", "block"),
			description: rich,
			version: { type: "semver" },
			stubValues: { type: "typeds" }
		}
	});
	PROJECTABLE_KINDS = Object.freeze(Object.keys(PROJECTION_FIELDS));
	BEHAVIOR_REFS = /* @__PURE__ */ new Set([
		"fromId",
		"toId",
		"effectIds",
		"nodeIds",
		"edgeIds",
		"entryIds",
		"exitIds",
		"childGraphId",
		"fallbackId",
		"targetId",
		"instanceId",
		"stateVariableId",
		"externalContractId",
		"shownInformationIds",
		"knowledgeEffects"
	]);
	FORBIDDEN_FIELDS = /* @__PURE__ */ new Set([
		"handoffReceipt",
		"authorNotes",
		"aliases",
		"quotedText",
		"originLineIds",
		"replacedByLineIds",
		"lineage",
		"customValues",
		"assetPath",
		"licenseNote",
		"history",
		"query",
		"sourceHash"
	]);
	BLOCK_KINDS = /* @__PURE__ */ new Set([
		"paragraph",
		"heading",
		"list_item",
		"quote"
	]);
	ASSET_TYPES = {
		"image/png": "png",
		"image/jpeg": "jpg",
		"image/gif": "gif",
		"image/webp": "webp",
		"audio/wav": "wav",
		"audio/mpeg": "mp3",
		"application/pdf": "pdf",
		"video/mp4": "mp4",
		"video/webm": "webm",
		"video/ogg": "ogv",
		"audio/ogg": "ogg",
		"text/plain": "txt",
		"application/json": "json",
		"application/octet-stream": "bin"
	};
	TICK = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/;
	object$3 = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : void 0;
	own = (value, key) => value && Object.prototype.hasOwnProperty.call(value, key) ? value[key] : void 0;
	hasOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
	empty = (value) => value == null || value === "" || Array.isArray(value) && value.length === 0;
	integer = (value) => typeof value === "number" && Number.isSafeInteger(value);
}));

//#endregion
//#region src/domain/exportPreparation.ts
function blocks(value) {
	return Array.isArray(value) ? value : [];
}
function entityDocuments(entity) {
	return [
		"body",
		"text",
		"summary",
		"description",
		"usageNotes",
		"caption",
		"action",
		"tutorial",
		"interpretation",
		"targetAudience",
		"experience",
		"theme",
		"tone",
		"scope"
	].filter((field) => blocks(entity.data[field]).length).map((field) => [field, blocks(entity.data[field])]);
}
async function selectExportSource(project, options) {
	if (options.targetRevision === void 0 === (options.targetVersionId === void 0)) return {
		ok: false,
		issues: [{
			code: "VALIDATION_FAILED",
			message: "出力する正本の版を一つ指定してください。"
		}]
	};
	if (options.targetRevision !== void 0) {
		if (!revisionPattern.test(options.targetRevision) || options.targetRevision !== project.revision) return {
			ok: false,
			issues: [{
				code: "VALIDATION_FAILED",
				message: "選択した版と出力元の版が一致しません。対象版を読み直してください。"
			}]
		};
		return {
			ok: true,
			project
		};
	}
	const snapshot = project.snapshots.find((snapshot) => snapshot.id === options.targetVersionId);
	if (!snapshot || snapshot.content.projectId !== project.projectId) return {
		ok: false,
		issues: [{
			code: "REFERENCE_INVALID",
			message: "選択した公開版の保存内容が見つかりません。",
			entityId: options.targetVersionId
		}]
	};
	const dependencies = [];
	const pending = [snapshot], visited = /* @__PURE__ */ new Set();
	while (pending.length) {
		const dependency = pending.pop();
		if (visited.has(dependency.id)) continue;
		visited.add(dependency.id);
		if (project.snapshots.filter((candidate) => candidate.id === dependency.id).length !== 1 || dependency.content.projectId !== project.projectId) return {
			ok: false,
			issues: [{
				code: "REFERENCE_INVALID",
				message: "保存版の依存内容を一意に確認できません。",
				entityId: dependency.id
			}]
		};
		if (await hash(dependency.content) !== dependency.contentHash) return {
			ok: false,
			issues: [{
				code: "VALIDATION_FAILED",
				message: "保存版の内容hashが一致しないため出力を停止しました。",
				entityId: dependency.id
			}]
		};
		dependencies.push(dependency);
		for (const entity of dependency.content.entities) for (const reference of collectReferences(entity)) if (reference.scope === "snapshot") {
			const target = project.snapshots.find((candidate) => candidate.id === reference.id);
			if (target && !visited.has(target.id)) pending.push(target);
		}
	}
	return {
		ok: true,
		project: {
			...structuredClone(snapshot.content),
			snapshots: dependencies,
			history: []
		}
	};
}
/** Resolve fixed pins in an output view, without copying borrowed data into the author's canonical document. */
async function executionExportView(captured, selected, options) {
	const edition = await captureRuntimeContent(captured, options.targetVersionId ?? captured.projectId, { worldSnapshots: options.worldSnapshots ?? {} }), view = resolveReuseContent(edition, edition.snapshots);
	function normalize(value, entityId, path = []) {
		const origin = reuseOrigin(view, entityId);
		if (Array.isArray(value)) return value.map((item, index) => normalize(item, entityId, [...path, String(index)]));
		if (!value || typeof value !== "object") return value;
		const object = value, editionId = options.targetVersionId ?? view.projectId;
		if (path.includes("links") && path.at(-1) === "target" && typeof object.sourceVersionId === "string") return structuredClone(object);
		const mapped = Object.fromEntries(Object.entries(object).filter(([key]) => key !== "reuse").map(([key, item]) => [key, origin && ["sourceVersionId", "targetSnapshotId"].includes(key) && item === origin.sourceVersionId ? editionId : normalize(item, entityId, [...path, key])]));
		if (origin && typeof object.entityId === "string" && object.sourceVersionId === origin.sourceVersionId) {
			for (const key of [
				"entityId",
				"blockId",
				"lineId"
			]) if (typeof object[key] === "string") mapped[key] = origin.bindings[object[key]] ?? object[key];
		}
		return mapped;
	}
	const worlds = resolvePinnedWorlds(view, options.worldSnapshots ?? {}).worlds, entities = view.entities.map((entity) => ({
		...entity,
		data: normalize(entity.data, entity.id)
	})), ids = new Set(entities.map((e) => e.id)), relations = [...view.relations], relationIds = new Set(relations.map((r) => r.id)), calendars = [...view.calendars];
	for (const world of worlds) {
		for (const entity of world.entities) {
			if (ids.has(entity.id)) throw Error("REFERENCE_INVALID: 固定世界と出力元のIDが衝突しています。");
			ids.add(entity.id);
			entities.push({
				...structuredClone(entity),
				projectId: view.projectId
			});
		}
		for (const relation of world.relations) {
			if (relationIds.has(relation.id)) throw Error("REFERENCE_INVALID: 固定世界の関係IDが衝突しています。");
			relationIds.add(relation.id);
			relations.push({
				...structuredClone(relation),
				projectId: view.projectId
			});
		}
		for (const calendar of world.calendars) if (!calendars.some((c) => c.id === calendar.id)) calendars.push(structuredClone(calendar));
	}
	if (!entities.find((e) => e.id === options.projectionProfileId) && options.targetVersionId) {
		const approved = captured.entities.find((e) => e.id === options.projectionProfileId && e.kind === "projection_profile" && e.data.sourceVersionId === options.targetVersionId);
		if (approved) entities.push(structuredClone(approved));
	}
	return {
		...selected,
		entities,
		relations,
		calendars
	};
}
function validatePublicPositions(projection) {
	const editions = new Map([["public-project", projection], ...(projection.versions ?? []).map((version) => [version.id, version.projection])]), issues = [];
	for (const [version, edition] of editions) {
		const inspect = (value) => {
			if (Array.isArray(value)) {
				value.forEach(inspect);
				return;
			}
			if (!value || typeof value !== "object") return;
			const object = value, entityId = object.entityId ?? object.targetId, start = object.targetId ? object.targetStart : object.start, end = object.targetId ? object.targetEnd : object.end;
			if (typeof entityId === "string" && (object.blockId != null || object.lineId != null || start != null || end != null)) {
				const target = editions.get(typeof object.sourceVersionId === "string" ? object.sourceVersionId : version), record = target?.entities.find((entity) => entity.id === entityId), line = typeof object.lineId === "string" ? target?.entities.find((entity) => entity.id === object.lineId && entity.kind === "dialogue_line") : void 0, block = typeof object.blockId === "string" ? record && entityDocuments(record).flatMap(([, document]) => document).find((block) => block.id === object.blockId) : void 0, text = block?.text ?? (line ? blocks(line.data.text).map((block) => block.text).join("\n") : void 0);
				const missing = !record || object.blockId != null && !block || object.lineId != null && !line, invalidRange = (start != null || end != null) && (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || Number(start) < 0 || Number(end) < Number(start) || text === void 0 || Number(end) > [...text].length);
				if (missing || invalidRange) issues.push({
					code: "REFERENCE_INVALID",
					message: "公開した固定版の本文位置を確認できません。公開文と文字範囲を再確認してください。",
					entityId
				});
			}
			Object.values(object).forEach(inspect);
		};
		edition.entities.forEach((entity) => inspect(entity.data));
	}
	return issues;
}
/** Each historical citation has its own approved policy and immutable bytes. */
async function prepareExportCitations(captured, selected, options, strictReferences) {
	const targets = {}, versions = [], sources = [], active = /* @__PURE__ */ new Set(), owners = /* @__PURE__ */ new Map(), publicOwners = /* @__PURE__ */ new Map();
	async function visit(edition, profileId, depth) {
		if (depth > 64) throw Error("IMPORT_LIMIT: 引用固定版の依存が64段階を超えています。");
		const policy = edition.entities.find((entity) => entity.id === profileId && entity.kind === "projection_profile" && entity.status === "confirmed" && !entity.deletedAt);
		if (!policy) throw Error("REFERENCE_INVALID: 引用固定版の公開範囲が未確認です。");
		for (const declaration of policy.data.citedVersions ?? []) {
			const id = declaration.sourceVersionId, prior = targets[id];
			if (active.has(id)) throw Error("REFERENCE_INVALID: 引用固定版の公開依存が循環しています。");
			if (prior) {
				if (prior.publicVersionId !== declaration.publicVersionId || owners.get(id) !== declaration.profileId) throw Error("REFERENCE_INVALID: 同じ引用版に異なる公開範囲が指定されています。");
				continue;
			}
			if (versions.length + active.size >= 128 || publicOwners.has(declaration.publicVersionId) || !declaration.publicVersionId) throw Error("IMPORT_LIMIT: 引用固定版の上限または公開版IDが不正です。");
			publicOwners.set(declaration.publicVersionId, id);
			active.add(id);
			const own = captured.snapshots.find((pin) => pin.id === id), world = (options.worldPins ?? []).find((pin) => pin.id === id), pin = own ?? world, registry = options.worldSnapshots ?? {};
			if (!pin || await sha256(jsonBytes(pin.content)) !== pin.contentHash || world && (!registry[id] || await sha256(jsonBytes(registry[id])) !== pin.contentHash)) throw Error("INTEGRITY_FAILED: 引用版の期待hashまたは内容が一致しません。");
			const library = pin.content.projectId === captured.projectId ? captured.snapshots : [...(options.worldPins ?? []).filter((item) => item.content.projectId === pin.content.projectId).map((item) => ({
				...item,
				createdAt: "1970-01-01T00:00:00.000Z",
				versionLabel: "引用する固定世界"
			}))];
			const original = {
				...structuredClone(pin.content),
				snapshots: structuredClone(library),
				history: []
			}, inside = original.entities.find((entity) => entity.id === declaration.profileId && entity.kind === "projection_profile"), outside = captured.entities.find((entity) => entity.id === declaration.profileId && entity.kind === "projection_profile" && entity.data.sourceVersionId === id);
			if (!inside && !outside) throw Error("REFERENCE_INVALID: 引用対象版の公開文を確認した範囲がありません。");
			const view = await executionExportView(original, original, {
				...options,
				projectionProfileId: declaration.profileId,
				targetVersionId: id,
				targetRevision: void 0
			});
			if (!inside && outside) view.entities.push({
				...structuredClone(outside),
				projectId: view.projectId
			});
			await visit(view, declaration.profileId, depth + 1);
			const result = createProjection(view, declaration.profileId, {
				strictReferences,
				confirmedOnly: true,
				targetVersionId: id,
				versionTargets: targets
			});
			if (!result.ok) throw Object.assign(Error("EXPORT_UNSUPPORTED: 引用版の公開名・本文・必要参照が未確認です。"), { issues: result.issues });
			targets[id] = {
				publicVersionId: declaration.publicVersionId,
				idMap: result.idMap
			};
			owners.set(id, declaration.profileId);
			versions.push({
				id: declaration.publicVersionId,
				projection: result.projection
			});
			sources.push({
				publicVersionId: declaration.publicVersionId,
				profileId: declaration.profileId,
				project: view,
				projection: result.projection,
				idMap: result.idMap
			});
			active.delete(id);
		}
	}
	await visit(selected, options.projectionProfileId, 0);
	return {
		targets,
		versions,
		sources
	};
}
/** Shared preparation contains no browser bundle or asset bytes. Stored evidence reuses the exact publication rules. */
async function preparePublicExecution(input, inputOptions) {
	const captured = structuredClone(input), options = structuredClone(inputOptions), selected = await selectExportSource(captured, options);
	if (!selected.ok) throw Object.assign(Error("REFERENCE_INVALID: 出力対象版を確認できません。"), { issues: selected.issues });
	const checked = validateProject(selected.project, { worldSnapshots: options.worldSnapshots ?? {} });
	if (!checked.ok) throw Object.assign(Error("REFERENCE_INVALID: 出力対象版の参照が不正です。"), { issues: checked.issues });
	const project = await executionExportView(captured, selected.project, options), citations = await prepareExportCitations(captured, project, options, true), result = createProjection(project, options.projectionProfileId, {
		strictReferences: true,
		confirmedOnly: true,
		targetVersionId: options.targetVersionId,
		versionTargets: citations.targets
	});
	if (!result.ok) throw Object.assign(Error("EXPORT_UNSUPPORTED: 固定した公開範囲を再構成できません。"), { issues: result.issues });
	if (citations.versions.length) result.projection.versions = citations.versions;
	const positions = validatePublicPositions(result.projection);
	if (positions.length) throw Object.assign(Error("REFERENCE_INVALID: 固定した公開本文位置が不正です。"), { issues: positions });
	return {
		project,
		projection: result.projection,
		idMap: result.idMap,
		citations
	};
}
var revisionPattern, hash;
var init_exportPreparation = __esmMin((() => {
	init_runtimeVersions();
	init_reuse();
	init_pinnedWorlds();
	init_json();
	init_model();
	init_projection();
	revisionPattern = /^(?:0|[1-9][0-9]*)$/;
	hash = (value) => sha256(jsonBytes(value));
}));

//#endregion
//#region src/domain/gameEvidence.ts
/** Rebuild from the original immutable author approval, using stable public IDs after native clone ID rewrites. */
async function rebuildGameExecution(input, evidence, inputWorlds) {
	evidence = structuredClone(evidence);
	const project = structuredClone(input), worlds = structuredClone(inputWorlds), pin = project.snapshots.find((pin) => pin.id === evidence.verificationVersionId);
	if (!pin || await sha256(jsonBytes(pin.content)) !== pin.contentHash) fail$2("保存したゲーム受領の公開確認版を検証できません。");
	const approval = pin.content.entities.find((entity) => entity.id === evidence.approval.entityId);
	if (evidence.approval.sourceVersionId !== pin.id || approval?.kind !== "note" || approval.visibility !== "private" || approval.status !== "confirmed" || approval.customValues.gamePackageHash !== evidence.packageHash || approval.customValues.gameReceiptHash !== evidence.receiptHash) fail$2("保存したゲーム受領hashが固定承認と一致しません。");
	const source = project.snapshots.find((pin) => pin.id === evidence.sourceVersionId)?.content;
	if (!source || source.revision !== evidence.sourceRevision) fail$2("保存したゲーム受領の対象revisionが一致しません。");
	const captured = {
		...structuredClone(pin.content),
		snapshots: project.snapshots,
		history: []
	};
	const byEdition = /* @__PURE__ */ new Map();
	for (const mapping of evidence.projectionBindings) {
		let values = byEdition.get(mapping.editionVersionId);
		if (!values) {
			values = {};
			byEdition.set(mapping.editionVersionId, values);
		}
		if (values[mapping.entityId] && values[mapping.entityId] !== mapping.publicId) fail$2("保存した公開ID対応が重複しています。");
		values[mapping.entityId] = mapping.publicId;
	}
	const cited = new Map(evidence.citationBindings.map((item) => [item.sourceVersionId, item.publicVersionId]));
	if (cited.size !== evidence.citationBindings.length) fail$2("保存した引用版対応が重複しています。");
	const restorePolicy = (entity, editionVersionId) => {
		if (entity.kind !== "projection_profile") return entity;
		const edition = entity.id === evidence.profileId ? evidence.sourceVersionId : entity.data.sourceVersionId ?? editionVersionId, publicIds = byEdition.get(edition) ?? {}, names = structuredClone(entity.data.namePolicy);
		for (const [id, policy] of Object.entries(names.byEntityId ?? {})) if (policy.mode === "anonymize" && publicIds[id]) policy.publicId = publicIds[id];
		return {
			...entity,
			data: {
				...entity.data,
				publicIds: {
					...entity.data.publicIds,
					...publicIds
				},
				namePolicy: names,
				citedVersions: entity.data.citedVersions?.map((declaration) => ({
					...declaration,
					publicVersionId: cited.get(declaration.sourceVersionId) ?? declaration.publicVersionId
				}))
			}
		};
	};
	captured.entities = captured.entities.map((e) => restorePolicy(e, evidence.sourceVersionId));
	captured.snapshots = await Promise.all(captured.snapshots.map(async (snapshot) => {
		if (await sha256(jsonBytes(snapshot.content)) !== snapshot.contentHash) fail$2("保存したゲーム受領の元版hashが一致しません。");
		const content = {
			...snapshot.content,
			entities: snapshot.content.entities.map((e) => restorePolicy(e, snapshot.id))
		};
		return {
			...snapshot,
			content,
			contentHash: await sha256(jsonBytes(content))
		};
	}));
	const worldPins = [];
	for (const expected of evidence.worldVersions) {
		const content = worlds[expected.sourceVersionId];
		if (!content || await sha256(jsonBytes(content)) !== expected.contentHash) fail$2("保存したゲーム受領の固定世界hashが一致しません。");
		worldPins.push({
			id: expected.sourceVersionId,
			content,
			contentHash: expected.contentHash
		});
	}
	const current = evidence.sourceVersionId === evidence.verificationVersionId;
	const prepared = await preparePublicExecution(captured, {
		profile: "runtime_json",
		projectionProfileId: evidence.profileId,
		...current ? { targetRevision: captured.revision } : { targetVersionId: evidence.sourceVersionId },
		worldSnapshots: worlds,
		worldPins
	});
	const expectedRecords = Object.entries(prepared.idMap).filter(([, publicId]) => prepared.projection.entities.some((entity) => entity.id === publicId));
	if (expectedRecords.length !== evidence.idMappings.length || expectedRecords.some(([entityId, publicId]) => !evidence.idMappings.some((mapping) => mapping.entityId === entityId && mapping.publicId === publicId && mapping.sourceVersionId === evidence.sourceVersionId))) fail$2("保存したゲーム受領の元ID・公開ID対応が一致しません。");
	for (const edition of [prepared.projection, ...prepared.projection.versions?.map((version) => version.projection) ?? []]) for (const entity of edition.entities) if (entity.kind === "attachment") entity.data.bytesIncluded = true;
	const portable = await portableRuntimeProject(prepared.projection);
	return {
		publicProjection: prepared.projection,
		runtimeProject: portable.project,
		publicToRuntime: portable.publicToRuntime,
		runtimeProjectHash: await sha256(jsonBytes(portable.project)),
		entities: prepared.projection.entities
	};
}
var fail$2;
var init_gameEvidence = __esmMin((() => {
	init_exportPreparation();
	init_json();
	init_portableRuntimeProject();
	fail$2 = (message) => {
		throw Error(`INTEGRITY_FAILED: ${message}`);
	};
}));

//#endregion
//#region src/domain/gameProtocol.ts
var gameProtocol_exports = /* @__PURE__ */ __exportAll({
	GAME_FEATURES: () => GAME_FEATURES,
	GAME_SPEC: () => GAME_SPEC,
	appendGameAction: () => appendGameAction,
	buildGameReceipt: () => buildGameReceipt,
	gameMode: () => gameMode,
	gameResult: () => gameResult,
	gameValues: () => gameValues,
	packageAssets: () => packageAssets,
	parseGameReceipt: () => parseGameReceipt,
	receiveGamePackage: () => receiveGamePackage,
	verifyGameReceipt: () => verifyGameReceipt,
	verifyStoredGameEvidence: () => verifyStoredGameEvidence
});
function checkedReceiptShape(input) {
	const raw = input, allowed = [
		"format",
		"formatVersion",
		"specification",
		"receiverId",
		"sessionId",
		"receivedAt",
		"packageHash",
		"runtimeProjectHash",
		"entryId",
		"worldTick",
		"actions",
		"requests",
		"finalState",
		"status",
		"mode",
		"dialogueIds",
		"assets",
		"receiptHash"
	], digest = /^[a-f0-9]{64}$/;
	if (!raw || typeof raw !== "object" || Array.isArray(raw) || Object.keys(raw).some((key) => !allowed.includes(key)) || raw.format !== "scenario-game-receipt" || raw.formatVersion !== "1.0.0" || raw.specification !== "scenario-browser-game/1.0.0" || raw.receiverId !== "independent-browser-game" || typeof raw.sessionId !== "string" || !uuid$3.test(raw.sessionId) || typeof raw.entryId !== "string" || !uuid$3.test(raw.entryId) || typeof raw.receivedAt !== "string" || !Number.isFinite(Date.parse(raw.receivedAt)) || ![
		raw.packageHash,
		raw.runtimeProjectHash,
		raw.receiptHash
	].every((value) => typeof value === "string" && digest.test(value)) || ![
		"stub",
		"actual",
		"mixed"
	].includes(raw.mode) || ![
		"ready",
		"terminal",
		"blocked",
		"unknown",
		"error"
	].includes(raw.status) || !raw.finalState || typeof raw.finalState !== "object" || Array.isArray(raw.finalState) || raw.worldTick != null && (typeof raw.worldTick !== "string" || !/^(?:0|-[1-9][0-9]*|[1-9][0-9]*)$/.test(raw.worldTick)) || !Array.isArray(raw.actions) || raw.actions.length > 1e4 || !Array.isArray(raw.requests) || raw.requests.length > 1e4 || !Array.isArray(raw.dialogueIds) || raw.dialogueIds.some((id) => typeof id !== "string") || new Set(raw.dialogueIds).size !== raw.dialogueIds.length || !Array.isArray(raw.assets) || raw.assets.some((asset) => !asset || Object.keys(asset).some((key) => !["id", "contentHash"].includes(key)) || typeof asset.id !== "string" || !digest.test(asset.contentHash)) || new Set(raw.assets.map((asset) => asset.id)).size !== raw.assets.length || jsonBytes(raw).byteLength > 1048576) failure("受領証跡の仕様・構造・上限が不正です。");
	for (const event of raw.actions) if (!event || typeof event !== "object" || Array.isArray(event) || Object.keys(event).some((key) => ![
		"sequence",
		"id",
		"contractId",
		"action",
		"stubIndex",
		"score",
		"value",
		"executedAt",
		"previousHash",
		"hash"
	].includes(key)) || typeof event.id !== "string" || !uuid$3.test(event.id) || typeof event.contractId !== "string" || typeof event.executedAt !== "string" || !Number.isFinite(Date.parse(event.executedAt)) || ![
		"win",
		"lose",
		"collect",
		"stub"
	].includes(event.action) || !Number.isSafeInteger(event.score) || !Number.isSafeInteger(event.sequence) || !digest.test(event.previousHash) || !digest.test(event.hash)) failure("ゲーム実行記録のID・日時・構造が不正です。");
	for (const request of raw.requests) if (!request || typeof request !== "object" || Array.isArray(request) || Object.keys(request).some((key) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(key))) failure("受領証跡の進行要求が未対応です。");
	return raw;
}
function packageAssets(pkg) {
	return [...pkg.publicProjection.entities.filter((e) => e.kind === "attachment").map((e) => ({
		id: e.id,
		data: e.data
	})), ...(pkg.publicProjection.versions ?? []).flatMap((version) => version.projection.entities.filter((e) => e.kind === "attachment").map((e) => ({
		id: `${version.id}:${e.id}`,
		data: e.data
	})))];
}
function contract(pkg, id) {
	const record = pkg.runtimeProject.entities.find((e) => e.kind === "external_contract" && e.id === pkg.publicToRuntime[id]);
	if (!record) failure("受取パッケージに外部契約がありません。");
	return record;
}
/** Example game mechanics produce measurements; a hand-entered actual label is never an input. */
function gameResult(pkg, id, action, oldScore, stubIndex) {
	const c = contract(pkg, id);
	if (action === "stub") {
		const value = c.data.stubValues?.[stubIndex ?? -1];
		if (!value) failure("宣言済み仮値がありません。");
		return {
			score: oldScore,
			value: structuredClone(value)
		};
	}
	if (c.data.owner !== "game") failure("ゲーム管理以外の外部契約を実測にできません。");
	const score = action === "win" ? oldScore + 3 : action === "collect" ? oldScore + 1 : Math.max(0, oldScore - 1);
	let value;
	if (c.data.outputType === "boolean") value = {
		type: "boolean",
		value: action !== "lose"
	};
	else if (c.data.outputType === "integer") value = {
		type: "integer",
		value: score
	};
	else if (c.data.outputType === "enum") {
		const values = (c.data.stubValues ?? []).filter((v) => v.type === "enum");
		if (!values.length) failure("列挙結果の宣言がありません。");
		value = structuredClone(values[action === "lose" ? values.length - 1 : action === "win" ? 0 : Math.min(1, values.length - 1)]);
	} else return failure("受取例が未対応の結果型です。");
	return {
		score,
		value
	};
}
async function receiveGamePackage(input) {
	const p = structuredClone(input);
	if (p?.format !== "scenario-runtime" || p.formatVersion !== "1.0.0" || p.profile?.profileId !== "scenario-runtime" || p.profile.profileVersion !== "1.1.0" || !p.runtimeProject || !p.publicToRuntime || !Array.isArray(p.entities) || !p.publicProjection || !Array.isArray(p.requiredFeatures) || p.requiredFeatures.length !== GAME_FEATURES.length || new Set(p.requiredFeatures).size !== p.requiredFeatures.length || p.requiredFeatures.some((feature) => !GAME_FEATURES.includes(feature))) failure("受取仕様版または必須機能に対応していません。");
	if (await sha256(jsonBytes(p.runtimeProject)) !== p.runtimeProjectHash || p.contentVersionId !== `sha256:${await sha256(jsonBytes(p.publicProjection))}` || canonicalJson$1(p.entities) !== canonicalJson$1(p.publicProjection.entities)) failure("受領内容hashまたは公開内容が一致しません。");
	const expected = await portableRuntimeProject(p.publicProjection);
	if (canonicalJson$1(expected.project) !== canonicalJson$1(p.runtimeProject) || canonicalJson$1(expected.publicToRuntime) !== canonicalJson$1(p.publicToRuntime)) failure("公開内容・実行内容・ID対応が一致しません。");
	const assets = packageAssets(p), known = new Set(assets.map((e) => e.id));
	if (known.size !== assets.length || new Set(p.entities.map((e) => e.id)).size !== p.entities.length || Object.keys(p.assetData ?? {}).some((id) => !known.has(id))) failure("素材または公開ID対応が重複・範囲外です。");
	for (const entity of assets) {
		const payload = p.assetData?.[entity.id];
		if (!payload || payload.mediaType !== entity.data.mediaType || typeof payload.base64 !== "string" || payload.base64.length > Math.ceil(33554432 / 3) * 4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(payload.base64)) failure("受取素材bytesがないか形式・上限が不正です。");
		const bytes = Uint8Array.from(atob(payload.base64), (char) => char.charCodeAt(0)), asset = await prepareAsset(bytes, "受取素材", payload.mediaType);
		if (asset.contentHash !== entity.data.contentHash || asset.byteSize !== entity.data.byteSize || asset.mediaType !== payload.mediaType || entity.data.bytesIncluded !== true) failure("受取素材の署名・hash・サイズが一致しません。");
	}
	return p;
}
async function appendGameAction(pkg, actions, id, action, stubIndex) {
	if (actions.length >= 1e4) failure("実行記録の上限10,000回に到達しました。");
	const result = gameResult(pkg, id, action, actions.filter((event) => event.contractId === id).at(-1)?.score ?? 0, stubIndex), record = {
		sequence: actions.length + 1,
		id: crypto.randomUUID(),
		contractId: id,
		action,
		...stubIndex !== void 0 ? { stubIndex } : {},
		...result,
		executedAt: (/* @__PURE__ */ new Date()).toISOString(),
		previousHash: actions.at(-1)?.hash ?? await sha256(jsonBytes(pkg))
	};
	return {
		...record,
		hash: await sha256(jsonBytes(record))
	};
}
function gameMode(actions) {
	const stub = actions.some((e) => e.action === "stub");
	return actions.some((e) => e.action !== "stub") ? stub ? "mixed" : "actual" : "stub";
}
function gameValues(pkg, actions) {
	return Object.fromEntries(actions.map((event) => [pkg.publicToRuntime[event.contractId], event.value]));
}
async function buildGameReceipt(pkg, input) {
	const capturedInput = structuredClone(input);
	pkg = await receiveGamePackage(pkg);
	input = capturedInput;
	let session = await startTrialVerified(pkg.runtimeProject, {
		entryId: input.entryId,
		worldTick: input.worldTick,
		externalValues: gameValues(pkg, input.actions)
	});
	for (const request of input.requests) session = stepTrial(pkg.runtimeProject, session, request);
	const payload = {
		format: "scenario-game-receipt",
		formatVersion: "1.0.0",
		specification: GAME_SPEC,
		receiverId: "independent-browser-game",
		sessionId: input.sessionId ?? crypto.randomUUID(),
		receivedAt: (/* @__PURE__ */ new Date()).toISOString(),
		packageHash: await sha256(jsonBytes(pkg)),
		runtimeProjectHash: pkg.runtimeProjectHash,
		entryId: input.entryId,
		...input.worldTick ? { worldTick: input.worldTick } : {},
		actions: input.actions,
		requests: input.requests,
		finalState: session.state,
		status: session.status,
		mode: gameMode(input.actions),
		dialogueIds: pkg.entities.filter((e) => e.kind === "dialogue_line").map((e) => e.id),
		assets: packageAssets(pkg).map((e) => ({
			id: e.id,
			contentHash: String(e.data.contentHash)
		}))
	};
	const receipt = {
		...payload,
		receiptHash: await sha256(jsonBytes(payload))
	};
	await verifyGameReceipt(pkg, receipt);
	return receipt;
}
async function verifyGameReceipt(pkg, input) {
	const raw = checkedReceiptShape(structuredClone(input));
	pkg = await receiveGamePackage(pkg);
	if (!raw || raw.format !== "scenario-game-receipt" || raw.formatVersion !== "1.0.0" || raw.specification !== "scenario-browser-game/1.0.0" || raw.receiverId !== "independent-browser-game" || typeof raw.sessionId !== "string" || !uuid$3.test(raw.sessionId) || typeof raw.receivedAt !== "string" || !Number.isFinite(Date.parse(raw.receivedAt)) || !Array.isArray(raw.actions) || raw.actions.length > 1e4 || !Array.isArray(raw.requests) || raw.requests.length > 1e4) failure("受領証跡の仕様・構造・上限が不正です。");
	const allowed = [
		"format",
		"formatVersion",
		"specification",
		"receiverId",
		"sessionId",
		"receivedAt",
		"packageHash",
		"runtimeProjectHash",
		"entryId",
		"worldTick",
		"actions",
		"requests",
		"finalState",
		"status",
		"mode",
		"dialogueIds",
		"assets",
		"receiptHash"
	];
	if (Object.keys(raw).some((key) => !allowed.includes(key))) failure("未対応の受領証跡項目があります。");
	const { receiptHash, ...payload } = raw;
	if (await sha256(jsonBytes(payload)) !== receiptHash || raw.packageHash !== await sha256(jsonBytes(pkg)) || raw.runtimeProjectHash !== pkg.runtimeProjectHash) failure("受領証跡または受取パッケージのhashが一致しません。");
	await verifyExecutionReceipt(pkg, raw);
	return raw;
}
async function verifyExecutionReceipt(pkg, raw) {
	let previousHash = raw.packageHash;
	const scores = /* @__PURE__ */ new Map(), ids = /* @__PURE__ */ new Set();
	for (const [index, event] of raw.actions.entries()) {
		if (!event || typeof event.id !== "string" || !uuid$3.test(event.id) || ids.has(event.id) || event.sequence !== index + 1 || event.previousHash !== previousHash || typeof event.executedAt !== "string" || !Number.isFinite(Date.parse(event.executedAt)) || ![
			"win",
			"lose",
			"collect",
			"stub"
		].includes(event.action)) failure("ゲーム実行記録の順序・ID・日時が不正です。");
		ids.add(event.id);
		if (Object.keys(event).some((key) => ![
			"sequence",
			"id",
			"contractId",
			"action",
			"stubIndex",
			"score",
			"value",
			"executedAt",
			"previousHash",
			"hash"
		].includes(key))) failure("未対応のゲーム実行項目があります。");
		const expected = gameResult(pkg, event.contractId, event.action, scores.get(event.contractId) ?? 0, event.stubIndex), { hash, ...action } = event;
		if (canonicalJson$1(expected.value) !== canonicalJson$1(event.value) || expected.score !== event.score || await sha256(jsonBytes(action)) !== hash) failure("ゲーム処理の実結果・hashが一致しません。");
		scores.set(event.contractId, event.score);
		previousHash = hash;
	}
	if (raw.mode !== gameMode(raw.actions)) failure("stub/actual/mixedの表示が実行証跡と一致しません。");
	if (canonicalJson$1(raw.dialogueIds) !== canonicalJson$1(pkg.entities.filter((e) => e.kind === "dialogue_line").map((e) => e.id)) || canonicalJson$1(raw.assets) !== canonicalJson$1(packageAssets(pkg).map((e) => ({
		id: e.id,
		contentHash: String(e.data.contentHash)
	})))) failure("台詞・素材ID対応または素材hashが一致しません。");
	let session = await startTrialVerified(pkg.runtimeProject, {
		entryId: raw.entryId,
		worldTick: raw.worldTick,
		externalValues: gameValues(pkg, raw.actions)
	});
	for (const request of raw.requests) {
		if (!request || Object.keys(request).some((key) => ![
			"edgeId",
			"event",
			"random",
			"worldTick"
		].includes(key))) failure("受領証跡の進行要求が未対応です。");
		session = stepTrial(pkg.runtimeProject, session, request);
	}
	if (canonicalJson$1(session.state) !== canonicalJson$1(raw.finalState) || session.status !== raw.status) failure("受取ゲームの経路・最終結果を再生できません。");
}
function parseGameReceipt(bytes) {
	return parseStrictJson(bytes, "game-receipt.json", {
		...ARCHIVE_LIMITS,
		jsonBytes: 1048576
	});
}
/** Durable records replay from an immutable private approval, including stable public IDs and pinned citations. */
async function verifyStoredGameEvidence(input, inputWorlds = {}) {
	const imagesFor = (p) => [
		p,
		...p.snapshots.map((pin) => pin.content),
		...p.history.flatMap((command) => [command.before, command.after]),
		...p.authorAlternatives?.flatMap((alternative) => [alternative.baseContent, ...alternative.versions.map((version) => version.content)]) ?? []
	];
	if (!imagesFor(input).some((image) => image.entities.some((note) => note.kind === "note" && note.data.handoffReceipt))) return;
	const project = structuredClone(input), worldSnapshots = structuredClone(inputWorlds);
	const images = imagesFor(project), seen = /* @__PURE__ */ new Set();
	for (const image of images) for (const note of image.entities) {
		if (note.kind !== "note" || !note.data.handoffReceipt) continue;
		const identity = canonicalJson$1(note.data.handoffReceipt);
		if (seen.has(identity)) continue;
		seen.add(identity);
		const evidence = note.data.handoffReceipt, receipt = checkedReceiptShape(parseGameReceipt(new TextEncoder().encode(evidence.rawJson))), { receiptHash, ...payload } = receipt;
		if (await sha256(jsonBytes(payload)) !== receiptHash || receiptHash !== evidence.receiptHash || receipt.packageHash !== evidence.packageHash || receipt.mode !== evidence.mode || gameMode(receipt.actions) !== evidence.mode) failure("保存したゲーム受領のhash・実行分類が元証跡と一致しません。");
		const execution = await rebuildGameExecution(project, evidence, worldSnapshots), pkg = execution;
		if (receipt.runtimeProjectHash !== execution.runtimeProjectHash) failure("保存したゲーム受領の実行内容が元の固定公開版と一致しません。");
		await verifyExecutionReceipt(pkg, receipt);
	}
}
var GAME_SPEC, GAME_FEATURES, uuid$3, failure;
var init_gameProtocol = __esmMin((() => {
	init_runtimeVerified();
	init_runtime();
	init_json();
	init_portableRuntimeProject();
	init_attachments();
	init_gameEvidence();
	GAME_SPEC = "scenario-browser-game/1.0.0";
	GAME_FEATURES = [
		"runtime-project-1",
		"lifecycle-1",
		"presentation-1",
		"reuse-flattening-1",
		"finite-exceptions-1"
	];
	uuid$3 = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
	failure = (message) => {
		throw Error(`INTEGRITY_FAILED: ${message}`);
	};
}));

//#endregion
//#region src/domain/projectRecordValidation.ts
init_model();
init_runtimeVersions();
init_reuse();
init_json();
init_pinnedWorlds();
function projectFromState(state) {
	return {
		...state,
		history: []
	};
}
function samePrefix(previous, next) {
	return next.length >= previous.length && previous.every((item, index) => canonicalJson$1(item) === canonicalJson$1(next[index]));
}
/** Immutable branch evidence must remain byte-for-byte stable in every retained history image. */
function checkAlternativeHistory(project) {
	const issues = [];
	const versionById = /* @__PURE__ */ new Map(), receiptById = /* @__PURE__ */ new Map();
	const branchIdentityById = /* @__PURE__ */ new Map();
	const timelines = /* @__PURE__ */ new Map();
	const timelineFor = (key) => {
		let timeline = timelines.get(key);
		if (!timeline) {
			timeline = [];
			timelines.set(key, timeline);
		}
		return timeline;
	};
	const local = timelineFor("local");
	const firstLocal = project.history.findIndex((command) => !command.importOrigin);
	if (firstLocal >= 0) local.push({
		label: `project.history[${firstLocal}].before`,
		state: project.history[firstLocal].before
	});
	for (const [index, command] of project.history.entries()) {
		const importOrigin = command.importOrigin;
		const timeline = timelineFor(importOrigin ? `import:${importOrigin.importOperationId}` : "local");
		if (importOrigin && !timeline.length) timeline.push({
			label: `project.history[${index}].before`,
			state: command.before
		});
		timeline.push({
			label: `project.history[${index}].after`,
			state: command.after
		});
	}
	const current = project;
	if (!local.length || local.at(-1)?.state.revision !== project.revision) local.push({
		label: "project",
		state: current
	});
	for (const timeline of timelines.values()) {
		let previousById = /* @__PURE__ */ new Map();
		for (const { label, state } of timeline) {
			const currentById = new Map((state.authorAlternatives ?? []).map((alternative) => [alternative.id, alternative]));
			for (const [id, previous] of previousById) {
				const next = currentById.get(id);
				if (!next) {
					issues.push({
						code: "INTEGRITY_FAILED",
						path: `${label}.authorAlternatives`,
						message: `過去に保存した別案「${id}」が履歴から失われています。`
					});
					continue;
				}
				if (!samePrefix(previous.versions, next.versions)) issues.push({
					code: "INTEGRITY_FAILED",
					path: `${label}.authorAlternatives.${id}.versions`,
					message: "別案版の履歴は削除・書換えできません。"
				});
				if (!samePrefix(previous.applyReceipts, next.applyReceipts)) issues.push({
					code: "INTEGRITY_FAILED",
					path: `${label}.authorAlternatives.${id}.applyReceipts`,
					message: "正本採用記録は削除・書換えできません。"
				});
			}
			for (const alternative of currentById.values()) {
				const identity = canonicalJson$1({
					projectId: alternative.projectId,
					baseRevision: alternative.baseRevision,
					sourceSnapshotId: alternative.sourceSnapshotId ?? null,
					baseContent: alternative.baseContent,
					baseContentHash: alternative.baseContentHash,
					createdAt: alternative.createdAt
				});
				const priorIdentity = branchIdentityById.get(alternative.id);
				if (priorIdentity !== void 0 && priorIdentity !== identity) issues.push({
					code: "INTEGRITY_FAILED",
					path: `${label}.authorAlternatives.${alternative.id}`,
					message: "別案IDが異なる分岐元の内容に再利用されています。"
				});
				else branchIdentityById.set(alternative.id, identity);
				for (const version of alternative.versions) {
					const old = versionById.get(version.id);
					if (old && canonicalJson$1(old) !== canonicalJson$1(version)) issues.push({
						code: "INTEGRITY_FAILED",
						path: `${label}.authorAlternatives.${alternative.id}.versions.${version.id}`,
						message: "不変の別案版IDが異なる内容へ再利用されています。"
					});
					else versionById.set(version.id, version);
				}
				for (const receipt of alternative.applyReceipts) {
					const old = receiptById.get(receipt.id);
					if (old && canonicalJson$1(old) !== canonicalJson$1(receipt)) issues.push({
						code: "INTEGRITY_FAILED",
						path: `${label}.authorAlternatives.${alternative.id}.applyReceipts.${receipt.id}`,
						message: "不変の正本採用記録IDが異なる内容へ再利用されています。"
					});
					else receiptById.set(receipt.id, receipt);
				}
			}
			previousById = currentById;
		}
	}
	return issues;
}
function reservedIds(project) {
	const ids = /* @__PURE__ */ new Set([project.projectId]);
	for (const item of [...project.entities, ...project.relations]) ids.add(item.id);
	for (const snapshot of project.snapshots) {
		ids.add(snapshot.id);
		for (const entity of project.entities) if (entity.kind === "snapshot" && entity.id === snapshot.id) ids.add(entity.id);
	}
	for (const command of project.history) ids.add(command.operationId);
	return ids;
}
async function checkAlternatives(project, validationOptions, path, digestCache) {
	const issues = [];
	const snapshots = project.snapshots;
	const branchIssues = await validateAuthorAlternatives(project.projectId, project.authorAlternatives ?? [], {
		snapshotIds: new Set(snapshots.map((snapshot) => snapshot.id)),
		snapshots,
		reservedIds: reservedIds(project),
		validateContent: async (content) => {
			const pinIssues = await verifyPinnedWorlds(content, validationOptions.worldSnapshots ?? {}, `${path}.authorAlternatives.worldReferences`, digestCache);
			const result = validateProject({
				...content,
				snapshots,
				history: []
			}, validationOptions);
			return result.ok && !pinIssues.length ? { ok: true } : {
				ok: false,
				issues: [...pinIssues, ...!result.ok ? result.issues : []]
			};
		}
	});
	for (const issue of branchIssues) issues.push({
		code: "INTEGRITY_FAILED",
		path: `${path}.${issue.path}`,
		message: issue.message
	});
	return issues;
}
async function checkChapterTraces(project, validationOptions, digestCache) {
	const issues = [];
	for (const [index, entity] of project.entities.entries()) {
		if (entity.kind !== "trace") continue;
		const location = `project.entities[${index}].data`;
		const checkpoint = project.entities.find((candidate) => candidate.id === entity.data.startCheckpointId && candidate.kind === "checkpoint");
		if (!checkpoint || checkpoint.kind !== "checkpoint") {
			issues.push({
				code: "REFERENCE_INVALID",
				path: `${location}.startCheckpointId`,
				message: "経路の開始状態が見つかりません。"
			});
			continue;
		}
		try {
			const content = await captureRuntimeContent(project, entity.data.contentVersionId, validationOptions, digestCache);
			if (entity.data.mode === "chapters") issues.push(...validateReadingTraceRecord(content, entity.data, checkpoint.data, location, validationOptions));
			else {
				const { replaySavedTrace } = await Promise.resolve().then(() => (init_runtime(), runtime_exports));
				const closure = resolvePinnedWorlds(resolveReuseContent(content, content.snapshots), validationOptions.worldSnapshots ?? {});
				const replay = replaySavedTrace(project, entity.id, closure.worlds.flatMap((world) => world.entities));
				if (replay.status === "error") issues.push(...replay.issues.map((issue) => ({
					...issue,
					path: `${location}.${issue.path}`
				})));
			}
		} catch (error) {
			const inner = error.issues;
			if (inner?.length) issues.push(...inner.map((issue) => ({
				...issue,
				path: `${location}.${issue.path}`
			})));
			else issues.push({
				code: "INTEGRITY_FAILED",
				path: `${location}.contentVersionId`,
				message: error instanceof Error ? error.message : "章読み通しの固定版本文を確認できません。"
			});
		}
	}
	return issues;
}
/** Async durable-boundary checks for hashes, isolated branch contents, and replayable chapter evidence. */
async function validateProjectIntegrity(input, options = {}, requireReceiptHistory = input.history.length > 0, verifiedStorage) {
	try {
		const { verifyStoredGameEvidence } = await Promise.resolve().then(() => (init_gameProtocol(), gameProtocol_exports));
		await verifyStoredGameEvidence(input, options.worldSnapshots ?? {});
	} catch (error) {
		return [{
			code: "INTEGRITY_FAILED",
			path: "project.entities.handoffReceipt",
			message: error.message
		}];
	}
	const digestCache = createPinnedWorldDigestCache();
	const validationOptions = {
		...options,
		worldSnapshots: freezePinnedWorldRegistry(options.worldSnapshots ?? {}, digestCache),
		worlds: options.worlds ? structuredClone(options.worlds) : void 0
	};
	const structural = verifiedStorage && !requireReceiptHistory && !input.history.length ? validateCurrentProject(input, validationOptions, verifiedStorage) : validateProject(input, validationOptions);
	if (!structural.ok) return structural.issues;
	const issues = [];
	const reviewChanges = (before, after, path) => {
		const old = new Map(before.filter((e) => e.kind === "review" && e.data.sharedSource).map((e) => [e.id, e]));
		for (const entity of after) {
			const prior = old.get(entity.id);
			if (entity.kind !== "review" || prior?.kind !== "review") continue;
			if (canonicalJson$1(prior.data.sharedSource) !== canonicalJson$1(entity.data.sharedSource ?? null)) issues.push({
				code: "INTEGRITY_FAILED",
				path: `${path}.${entity.id}.data.sharedSource`,
				message: "元の共有指摘・公開版・位置・引用の記録は変更できません。解決文を別に保存してください。"
			});
			if (canonicalJson$1([
				prior.data.target,
				prior.data.targetVersionId,
				prior.data.quotedText ?? null
			]) !== canonicalJson$1([
				entity.data.target,
				entity.data.targetVersionId,
				entity.data.quotedText ?? null
			])) issues.push({
				code: "INTEGRITY_FAILED",
				path: `${path}.${entity.id}.data.target`,
				message: "元の共有指摘の私的固定版と引用は変更できません。現在稿の修正は別に保存してください。"
			});
			if (prior.data.stage === "open" && entity.data.stage === "verified") issues.push({
				code: "INTEGRITY_FAILED",
				path: `${path}.${entity.id}.data.stage`,
				message: "共有指摘は修正済みを保存してから再確認してください。"
			});
		}
	};
	if (verifiedStorage) reviewChanges(verifiedStorage.previous.entities, input.entities, "project.entities");
	for (const [index, command] of input.history.entries()) reviewChanges(command.before.entities, command.after.entities, `project.history[${index}].after.entities`);
	issues.push(...await verifyPinnedWorlds(input, validationOptions.worldSnapshots, "project.worldReferences", digestCache));
	for (const [index, snapshot] of input.snapshots.entries()) issues.push(...await verifyPinnedWorlds(snapshot.content, validationOptions.worldSnapshots, `project.snapshots[${index}].content.worldReferences`, digestCache));
	issues.push(...await checkAlternatives(input, validationOptions, "project", digestCache));
	issues.push(...await checkChapterTraces(input, validationOptions, digestCache));
	issues.push(...checkAlternativeHistory(input));
	if (requireReceiptHistory) for (const [branchIndex, alternative] of (input.authorAlternatives ?? []).entries()) for (const [receiptIndex, receipt] of alternative.applyReceipts.entries()) {
		const receiptPath = `project.authorAlternatives[${branchIndex}].applyReceipts[${receiptIndex}]`;
		const command = input.history.find((item) => item.revision === receipt.appliedRevision && item.before.revision === receipt.fromCanonicalRevision && receipt.patches.every((patch) => {
			const before = receiptPatchValue(item.before, patch), after = receiptPatchValue(item.after, patch);
			const beforeExpected = patch.before.present ? patch.before.value : void 0, afterExpected = patch.after.present ? patch.after.value : void 0;
			return canonicalJson$1(before ?? null) === canonicalJson$1(beforeExpected ?? null) && before === void 0 === !patch.before.present && canonicalJson$1(after ?? null) === canonicalJson$1(afterExpected ?? null) && after === void 0 === !patch.after.present;
		}));
		if (!command) {
			issues.push({
				code: "INTEGRITY_FAILED",
				path: receiptPath,
				message: "正本採用記録に対応する不変の変更履歴がありません。"
			});
			continue;
		}
		for (const [patchIndex, patch] of receipt.patches.entries()) {
			const before = receiptPatchValue(command.before, patch), after = receiptPatchValue(command.after, patch);
			const beforeExpected = patch.before.present ? patch.before.value : void 0, afterExpected = patch.after.present ? patch.after.value : void 0;
			if (canonicalJson$1(before ?? null) !== canonicalJson$1(beforeExpected ?? null) || before === void 0 !== !patch.before.present) issues.push({
				code: "INTEGRITY_FAILED",
				path: `${receiptPath}.patches[${patchIndex}].before`,
				message: "採用前の正本値が対応する変更履歴と一致しません。"
			});
			if (canonicalJson$1(after ?? null) !== canonicalJson$1(afterExpected ?? null) || after === void 0 !== !patch.after.present) issues.push({
				code: "INTEGRITY_FAILED",
				path: `${receiptPath}.patches[${patchIndex}].after`,
				message: "採用後の正本値が対応する変更履歴と一致しません。"
			});
		}
	}
	for (const [index, command] of input.history.entries()) for (const side of ["before", "after"]) {
		const state = command[side];
		const historical = projectFromState(state);
		issues.push(...await verifyPinnedWorlds(historical, validationOptions.worldSnapshots, `project.history[${index}].${side}.worldReferences`, digestCache));
		for (const [snapshotIndex, snapshot] of historical.snapshots.entries()) issues.push(...await verifyPinnedWorlds(snapshot.content, validationOptions.worldSnapshots, `project.history[${index}].${side}.snapshots[${snapshotIndex}].content.worldReferences`, digestCache));
		if (state.authorAlternatives?.length) issues.push(...await checkAlternatives(historical, validationOptions, `project.history[${index}].${side}`, digestCache));
		issues.push(...await checkChapterTraces(historical, validationOptions, digestCache));
	}
	return issues.slice(0, 256);
}

//#endregion
//#region src/sync/protocol.ts
/** Only codes are surfaced; transport error bodies can contain author text or credentials. */
var SyncProtocolError = class extends Error {
	code;
	constructor(code) {
		super(code);
		this.code = code;
		this.name = "SyncProtocolError";
	}
};
const TOMBSTONE_FIELD = "$tombstone";
const uuid$2 = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const blockedKeys = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]);
function invalid() {
	throw new SyncProtocolError("PROTOCOL_INVALID");
}
function isRevision(value) {
	return typeof value === "string" && /^(0|[1-9][0-9]*)$/.test(value) && value.length <= 128;
}
function assertScope(scope) {
	if (!scope || typeof scope.accountId !== "string" || !scope.accountId.trim() || scope.accountId.length > 256 || !uuid$2.test(scope.projectId)) invalid();
}
function sameScope(a, b) {
	return a.accountId === b.accountId && a.projectId === b.projectId;
}
function clone(value) {
	return structuredClone(value);
}
/** Deterministic JSON, with objects sorted and array order preserved. Missing differs from null. */
function canonicalJson(value) {
	const ancestors = /* @__PURE__ */ new Set();
	function encode(current, depth) {
		if (depth > 100) return invalid();
		if (current === null || typeof current === "boolean" || typeof current === "string") return JSON.stringify(current);
		if (typeof current === "number" && Number.isFinite(current)) return JSON.stringify(current);
		if (!current || typeof current !== "object" || ancestors.has(current)) return invalid();
		const prototype = Object.getPrototypeOf(current);
		if (!Array.isArray(current) && prototype !== Object.prototype && prototype !== null) return invalid();
		ancestors.add(current);
		let result;
		if (Array.isArray(current)) {
			if (Object.keys(current).length !== current.length) return invalid();
			result = "[" + current.map((item) => encode(item, depth + 1)).join(",") + "]";
		} else result = "{" + Object.keys(current).sort().map((key) => {
			if (blockedKeys.has(key)) return invalid();
			return JSON.stringify(key) + ":" + encode(current[key], depth + 1);
		}).join(",") + "}";
		ancestors.delete(current);
		return result;
	}
	return encode(value, 0);
}
function sameValue(a, b) {
	return canonicalJson(a) === canonicalJson(b);
}
async function valueHash(value) {
	const bytes = new TextEncoder().encode(canonicalJson(value));
	const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
	return "sha256:" + Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function fieldSlot(document, field) {
	if (field === "$tombstone") return {
		present: true,
		value: document?.tombstone ? {
			deletedAt: document.tombstone.deletedAt,
			operationId: document.tombstone.operationId
		} : null
	};
	return document && Object.hasOwn(document.fields, field) ? {
		present: true,
		value: clone(document.fields[field])
	} : { present: false };
}
function assertDocument(document) {
	if (!document || !uuid$2.test(document.id) || !uuid$2.test(document.projectId) || !isRevision(document.revision) || !document.fields || Array.isArray(document.fields) || typeof document.fields !== "object" || Object.keys(document.fields).some((field) => field === "$tombstone" || blockedKeys.has(field) || !field)) invalid();
	canonicalJson(document.fields);
	if (document.tombstone !== null && (!document.tombstone || !uuid$2.test(document.tombstone.operationId) || typeof document.tombstone.deletedAt !== "string" || !/^\d{4}-\d{2}-\d{2}T/.test(document.tombstone.deletedAt) || !Number.isFinite(Date.parse(document.tombstone.deletedAt)))) invalid();
}
function assertDocumentTarget(document, scope, targetId) {
	assertDocument(document);
	if (document.projectId !== scope.projectId || document.id !== targetId) invalid();
}
async function changesBetween(base, local) {
	const fields = [.../* @__PURE__ */ new Set([
		...Object.keys(base?.fields ?? {}),
		...Object.keys(local.fields),
		TOMBSTONE_FIELD
	])].sort();
	const changes = [];
	for (const field of fields) {
		const before = fieldSlot(base, field);
		const after = fieldSlot(local, field);
		if (!sameValue(before, after)) changes.push({
			field,
			oldValueHash: await valueHash(before),
			value: after
		});
	}
	return changes;
}
async function createSyncOperation(input) {
	input = clone(input);
	assertScope(input.scope);
	if (!uuid$2.test(input.operationId) || !isRevision(input.baseRevision) || !input.targets.length || input.targets.length > 1e4 || input.reason !== void 0 && typeof input.reason !== "string" || input.resolvesOperationId !== void 0 && (!uuid$2.test(input.resolvesOperationId) || input.resolvesOperationId === input.operationId)) invalid();
	const ids = /* @__PURE__ */ new Set();
	const targets = [];
	for (const target of input.targets) {
		const local = clone(target.local);
		assertDocumentTarget(local, input.scope, local.id);
		if (ids.has(local.id)) invalid();
		ids.add(local.id);
		if (target.base) {
			assertDocumentTarget(target.base, input.scope, local.id);
			if (BigInt(target.base.revision) > BigInt(input.baseRevision)) invalid();
		}
		targets.push({
			targetId: local.id,
			base: clone(target.base),
			local,
			changes: await changesBetween(target.base, local)
		});
	}
	return {
		schemaVersion: 1,
		operationId: input.operationId,
		scope: clone(input.scope),
		baseRevision: input.baseRevision,
		targets,
		reason: input.reason ?? "",
		...input.resolvesOperationId ? { resolvesOperationId: input.resolvesOperationId } : {}
	};
}
async function assertOperation(operation) {
	if (!operation || operation.schemaVersion !== 1 || !Array.isArray(operation.targets)) invalid();
	if (!sameValue(operation, await createSyncOperation({
		...operation,
		targets: operation.targets.map((target) => ({
			base: target.base,
			local: target.local
		}))
	}))) invalid();
}
async function assertAckEnvelope(operation, ack) {
	if (ack?.authorizationExpiresAt !== void 0 && ack.authorizationExpiresAt !== null && (typeof ack.authorizationExpiresAt !== "string" || !Number.isFinite(Date.parse(ack.authorizationExpiresAt)))) invalid();
	if (ack?.authorizationRevision !== void 0 && !isRevision(ack.authorizationRevision)) invalid();
	if (!ack || ack.schemaVersion !== 1 || ack.operationId !== operation.operationId || !sameScope(ack.scope, operation.scope) || ack.operationHash !== await valueHash(operation) || !isRevision(ack.serverRevision) || BigInt(ack.serverRevision) < BigInt(operation.baseRevision) || !Array.isArray(ack.documents) || ack.documents.length !== operation.targets.length || !Array.isArray(ack.conflicts)) invalid();
	for (const [index, document] of ack.documents.entries()) if (document) {
		assertDocumentTarget(document, operation.scope, operation.targets[index].targetId);
		if (BigInt(document.revision) > BigInt(ack.serverRevision)) invalid();
	}
	if (ack.confirmedDocuments !== void 0) {
		if (!Array.isArray(ack.confirmedDocuments) || ack.confirmedDocuments.length > 100001) invalid();
		const confirmed = /* @__PURE__ */ new Map();
		for (const doc of ack.confirmedDocuments) {
			assertDocumentTarget(doc, operation.scope, doc.id);
			if (confirmed.has(doc.id) || BigInt(doc.revision) > BigInt(ack.serverRevision)) invalid();
			confirmed.set(doc.id, doc);
		}
		for (const [index, doc] of ack.documents.entries()) if (!sameValue(doc, confirmed.get(operation.targets[index].targetId) ?? null)) invalid();
	}
	if (ack.status === "applied") {
		if (ack.conflicts.length || ack.documents.some((document) => !document)) invalid();
		if (operation.targets.some((target) => target.changes.length) && BigInt(ack.serverRevision) <= BigInt(operation.baseRevision)) invalid();
		for (const [index, target] of operation.targets.entries()) {
			const document = ack.documents[index];
			if ((!target.base || !sameValue({
				fields: target.base.fields,
				tombstone: target.base.tombstone
			}, {
				fields: document.fields,
				tombstone: document.tombstone
			})) && BigInt(document.revision) <= BigInt(operation.baseRevision)) invalid();
		}
	} else if (ack.status === "conflict") {
		if (!ack.conflicts.length) invalid();
		const conflictIds = /* @__PURE__ */ new Set();
		for (const conflict of ack.conflicts) {
			const index = operation.targets.findIndex((target) => target.targetId === conflict.targetId);
			if (index < 0 || conflictIds.has(conflict.targetId) || !sameValue(conflict.base, operation.targets[index].base) || !sameValue(conflict.local, operation.targets[index].local) || !sameValue(conflict.server, ack.documents[index])) invalid();
			conflictIds.add(conflict.targetId);
		}
	} else invalid();
}

//#endregion
//#region src/sync/merge.ts
function content(document) {
	return document ? {
		fields: document.fields,
		tombstone: document.tombstone
	} : null;
}
function put(fields, field, slot) {
	if (slot.present) fields[field] = clone(slot.value);
}
function conflict(base, local, server, reasons) {
	return {
		targetId: local.id,
		base: clone(base),
		local: clone(local),
		server: clone(server),
		reasons,
		fields: [],
		automaticFields: {}
	};
}
/** Never chooses a winner by timestamps. Inputs and returned alternatives do not alias. */
function threeWayMerge(base, local, server) {
	assertDocument(local);
	for (const document of [base, server]) if (document) {
		assertDocument(document);
		if (document.id !== local.id || document.projectId !== local.projectId) throw new SyncProtocolError("PROTOCOL_INVALID");
	}
	if (!base) {
		if (!server || sameValue(content(local), content(server))) return {
			status: "merged",
			document: clone(server ?? local)
		};
		return {
			status: "conflict",
			conflict: conflict(base, local, server, ["concurrent-create"])
		};
	}
	if (!server) return {
		status: "conflict",
		conflict: conflict(base, local, server, ["missing-server-record"])
	};
	const localChanged = !sameValue(content(base), content(local));
	const serverChanged = !sameValue(content(base), content(server));
	if (!localChanged) return {
		status: "merged",
		document: clone(server)
	};
	if (!serverChanged) return {
		status: "merged",
		document: clone(local)
	};
	if (sameValue(content(local), content(server))) return {
		status: "merged",
		document: clone(server)
	};
	const localDeleted = local.tombstone !== null;
	const serverDeleted = server.tombstone !== null;
	const localLifecycleChange = !sameValue(base.tombstone, local.tombstone);
	const serverLifecycleChange = !sameValue(base.tombstone, server.tombstone);
	if (localDeleted !== serverDeleted && (localLifecycleChange || serverLifecycleChange)) return {
		status: "conflict",
		conflict: conflict(base, local, server, ["delete-versus-edit"])
	};
	if (localDeleted || serverDeleted) {
		if (localDeleted && serverDeleted && sameValue(local.fields, server.fields)) return {
			status: "merged",
			document: clone(server)
		};
		return {
			status: "conflict",
			conflict: conflict(base, local, server, ["delete-versus-edit"])
		};
	}
	const result = clone(server);
	result.fields = {};
	const unresolved = conflict(base, local, server, ["same-field"]);
	const fields = [.../* @__PURE__ */ new Set([
		...Object.keys(base.fields),
		...Object.keys(local.fields),
		...Object.keys(server.fields)
	])].sort();
	for (const field of fields) {
		const before = fieldSlot(base, field);
		const a = fieldSlot(local, field);
		const b = fieldSlot(server, field);
		let chosen;
		if (sameValue(a, b)) chosen = a;
		else if (sameValue(a, before)) chosen = b;
		else if (sameValue(b, before)) chosen = a;
		else {
			unresolved.fields.push({
				field,
				base: before,
				local: a,
				server: b
			});
			continue;
		}
		unresolved.automaticFields[field] = clone(chosen);
		put(result.fields, field, chosen);
	}
	return unresolved.fields.length ? {
		status: "conflict",
		conflict: unresolved
	} : {
		status: "merged",
		document: result
	};
}
/** Flatten one data level: separate rich-text fields merge independently, each document remains atomic. */
function flattenFields(record) {
	const fields = {};
	for (const [field, value] of Object.entries(record)) {
		if ([
			"id",
			"projectId",
			"revision",
			"createdAt",
			"updatedAt",
			"deletedAt",
			"deleteOperationId",
			"deletionOperationId"
		].includes(field)) continue;
		if (field === "$tombstone" || field.startsWith("data.")) throw new SyncProtocolError("PROTOCOL_INVALID");
		if (field === "data" && value && typeof value === "object" && !Array.isArray(value)) for (const [key, nested] of Object.entries(value)) {
			if (key.includes(".")) throw new SyncProtocolError("PROTOCOL_INVALID");
			if (nested !== void 0) fields["data." + key] = clone(nested);
		}
		else if (value !== void 0) fields[field] = clone(value);
	}
	return fields;
}

//#endregion
//#region src/sync/validation.ts
/** An HTTP success or a matching operation ID alone is never evidence that an edit was applied. */
async function assertAck(operation, ack) {
	await assertAckEnvelope(operation, ack);
	const expectedConflicts = [];
	for (const [index, target] of operation.targets.entries()) {
		const document = ack.documents[index];
		const merged = threeWayMerge(target.base, target.local, document);
		if (ack.status === "applied") {
			if (merged.status !== "merged" || !document || !sameValue({
				fields: merged.document.fields,
				tombstone: merged.document.tombstone
			}, {
				fields: document.fields,
				tombstone: document.tombstone
			})) throw new SyncProtocolError("PROTOCOL_INVALID");
		} else if (merged.status === "conflict") expectedConflicts.push(merged.conflict);
	}
	if (ack.status === "conflict" && !sameValue(ack.conflicts, expectedConflicts)) throw new SyncProtocolError("PROTOCOL_INVALID");
}

//#endregion
//#region src/sync/adapter.ts
/** Caller selects a confirmed server record for a common base, or a local record for a candidate. */
function toSyncDocument(record) {
	if (record.deletedAt && !record.deletionOperationId) throw new SyncProtocolError("PROTOCOL_INVALID");
	const document = {
		id: record.id,
		projectId: record.projectId,
		revision: record.revision,
		fields: flattenFields(record),
		tombstone: record.deletedAt ? {
			deletedAt: record.deletedAt,
			operationId: record.deletionOperationId
		} : null
	};
	assertDocument(document);
	return document;
}

//#endregion
//#region src/sync/nativeBridge.ts
init_model();
/** Server record revisions and local save revisions have different meanings. */
function nativeDocuments(project, revision) {
	const { entities, relations, history: _history, ...header } = project;
	return [
		toSyncDocument({
			...header,
			id: project.projectId,
			kind: "project",
			visibility: "private",
			revision,
			entityIds: entities.map((e) => e.id),
			relationIds: relations.map((r) => r.id)
		}),
		...entities.map((e) => {
			const doc = toSyncDocument({
				...e,
				revision
			});
			doc.fields.createdAt = e.createdAt;
			return doc;
		}),
		...relations.map((r) => toSyncDocument({
			...r,
			revision
		}))
	];
}
function sameDocumentContent(a, b) {
	return sameValue(a ? {
		fields: a.fields,
		tombstone: a.tombstone
	} : null, b ? {
		fields: b.fields,
		tombstone: b.tombstone
	} : null);
}
function inflate(doc) {
	const result = {
		id: doc.id,
		projectId: doc.projectId,
		revision: doc.revision
	};
	for (const [key, value] of Object.entries(doc.fields)) if (key.startsWith("data.")) {
		const nested = key.slice(5);
		if (!nested || nested.includes(".") || [
			"__proto__",
			"prototype",
			"constructor"
		].includes(nested)) throw new SyncProtocolError("PROTOCOL_INVALID");
		result.data ??= {};
		result.data[nested] = clone(value);
	} else {
		if ([
			"id",
			"projectId",
			"revision",
			"updatedAt",
			"deletedAt",
			"deletionOperationId",
			"__proto__",
			"prototype",
			"constructor"
		].includes(key)) throw new SyncProtocolError("PROTOCOL_INVALID");
		result[key] = clone(value);
	}
	if (doc.tombstone) {
		result.deletedAt = doc.tombstone.deletedAt;
		result.deletionOperationId = doc.tombstone.operationId;
	}
	return result;
}
/** Construct a native candidate; validation and durable integrity are performed before the transaction. */
function nativeFromDocuments(previous, documents, now) {
	const byId = new Map(documents.map((doc) => [doc.id, doc]));
	if (byId.size !== documents.length) throw new SyncProtocolError("PROTOCOL_INVALID");
	const head = byId.get(previous.projectId);
	if (!head || head.fields.kind !== "project" || head.tombstone) throw new SyncProtocolError("PROTOCOL_INVALID");
	const { id: _id, kind: _kind, visibility: _visibility, entityIds, relationIds, ...header } = inflate(head);
	if (!Array.isArray(entityIds) || !Array.isArray(relationIds) || [...entityIds, ...relationIds].some((id) => typeof id !== "string") || (/* @__PURE__ */ new Set([
		...entityIds,
		...relationIds,
		head.id
	])).size !== documents.length) throw new SyncProtocolError("PROTOCOL_INVALID");
	const records = new Map([...previous.entities, ...previous.relations].map((record) => [record.id, record]));
	const get = (id, entity) => {
		const doc = byId.get(id);
		if (!doc || doc.projectId !== previous.projectId) throw new SyncProtocolError("PROTOCOL_INVALID");
		const record = inflate(doc), old = records.get(doc.id);
		if (entity) {
			record.createdAt = record.createdAt ?? (old && "createdAt" in old ? old.createdAt : now);
			if (old && "createdAt" in old && old.createdAt !== record.createdAt) throw new SyncProtocolError("PROTOCOL_INVALID");
			record.updatedAt = old && "updatedAt" in old ? old.updatedAt : now;
		}
		record.revision = old?.revision ?? "0";
		if (!doc.tombstone) {
			delete record.deletedAt;
			delete record.deletionOperationId;
		}
		return record;
	};
	return {
		...header,
		projectId: previous.projectId,
		revision: previous.revision,
		entities: entityIds.map((id) => get(id, true)),
		relations: relationIds.map((id) => get(id, false)),
		history: previous.history
	};
}

//#endregion
//#region src/storage/syncRecovery.ts
init_model();
init_errors();
/** Historical protocol IDs and hashes are preserved verbatim across clone and ID-mapped import. */
function syncRecoveryImages(items = []) {
	return items.flatMap((item) => {
		const all = [];
		if (item.base) all.push(item.base.documents);
		for (const p of item.prepared) all.push(p.localDocuments);
		for (const c of item.conflicts) {
			all.push(c.prepared.localDocuments);
			if (c.ack.confirmedDocuments) all.push(c.ack.confirmedDocuments);
		}
		for (const a of item.acknowledgements) if (a.ack.confirmedDocuments) all.push(a.ack.confirmedDocuments);
		return [clone(item.origin), ...all.map((d) => nativeFromDocuments(item.origin, d, "1970-01-01T00:00:00.000Z"))].map((p) => ({
			...p,
			history: []
		}));
	});
}
async function validateSyncRecovery(input, worlds, signal) {
	if (!Array.isArray(input) || input.length > 1e5) throw new StorageError("VALIDATION_FAILED", "同期復元証跡の形式・件数が不正です。");
	const captured = clone(input), seen = /* @__PURE__ */ new Set();
	try {
		for (const item of captured) {
			checkCancelled(signal);
			if (!item || item.format !== "scenario-sync-recovery" || item.version !== 1 || item.state !== "needs_reconnect" || !item.origin || !ID_PATTERN.test(item.origin.projectId) || !Array.isArray(item.prepared) || !Array.isArray(item.conflicts) || !Array.isArray(item.acknowledgements) || Object.keys(item).some((k) => ![
				"format",
				"version",
				"state",
				"origin",
				"base",
				"prepared",
				"conflicts",
				"acknowledgements",
				"assetAcknowledgements",
				"contentHash"
			].includes(k))) throw new SyncProtocolError("PROTOCOL_INVALID");
			const { contentHash, ...payload } = item;
			if (await valueHash(payload) !== contentHash || seen.has(contentHash)) throw new SyncProtocolError("PROTOCOL_INVALID");
			seen.add(contentHash);
			if (item.base && (!isRevision(item.base.serverRevision) || !Array.isArray(item.base.documents) || item.base.documents.length > 100001 || item.base.projectId !== item.origin.projectId || await valueHash(item.base.documents) !== item.base.contentHash)) throw new SyncProtocolError("PROTOCOL_INVALID");
			if (item.base) for (const doc of item.base.documents) assertDocumentTarget(doc, {
				accountId: "00000000-0000-4000-8000-000000000001",
				projectId: item.origin.projectId
			}, doc.id);
			if (item.assetAcknowledgements) {
				if (!Array.isArray(item.assetAcknowledgements)) throw new SyncProtocolError("PROTOCOL_INVALID");
				for (const a of item.assetAcknowledgements) if (a.projectId !== item.origin.projectId || a.key !== `${a.projectId}:${a.contentHash}` || !/^[0-9a-f]{64}$/.test(a.contentHash) || !Number.isSafeInteger(a.byteSize) || a.byteSize < 0 || a.byteSize > 33554432 || typeof a.mediaType !== "string") throw new SyncProtocolError("PROTOCOL_INVALID");
			}
			for (const p of [...item.prepared, ...item.conflicts.map((c) => c.prepared)]) {
				await assertOperation(p.operation);
				if (p.operationId !== p.operation.operationId || p.projectId !== item.origin.projectId || p.operation.scope.projectId !== p.projectId || !isRevision(p.localRevision) || !Array.isArray(p.localDocuments) || p.localDocuments.length > 100001 || !Array.isArray(p.outboxIds) || p.outboxIds.length > 1e5 || new Set(p.outboxIds).size !== p.outboxIds.length || p.outboxIds.some((id) => !ID_PATTERN.test(id)) || !Number.isFinite(Date.parse(p.createdAt))) throw new SyncProtocolError("PROTOCOL_INVALID");
				if (p.origin !== void 0 && !["prepared_operation", "received_image"].includes(p.origin)) throw new SyncProtocolError("PROTOCOL_INVALID");
				for (const d of p.localDocuments) assertDocumentTarget(d, p.operation.scope, d.id);
				for (const t of p.operation.targets) if (!sameValue(t.local, p.localDocuments.find((d) => d.id === t.targetId))) throw new SyncProtocolError("PROTOCOL_INVALID");
			}
			for (const c of item.conflicts) {
				if (c.operationId !== c.prepared.operationId || c.projectId !== item.origin.projectId) throw new SyncProtocolError("PROTOCOL_INVALID");
				await assertAck(c.prepared.operation, c.ack);
				if (!Array.isArray(c.conflicts) || c.conflicts.some((conflict) => {
					const merged = threeWayMerge(conflict.base, conflict.local, conflict.server);
					return merged.status !== "conflict" || !sameValue(merged.conflict, conflict);
				})) throw new SyncProtocolError("PROTOCOL_INVALID");
				if (c.ack.status === "conflict" && JSON.stringify(c.conflicts) !== JSON.stringify(c.ack.conflicts)) throw new SyncProtocolError("PROTOCOL_INVALID");
			}
			for (const a of item.acknowledgements) {
				if (a.origin !== void 0 && !["prepared_operation", "received_image"].includes(a.origin)) throw new SyncProtocolError("PROTOCOL_INVALID");
				if (a.projectId !== item.origin.projectId || a.operationId !== a.operation.operationId) throw new SyncProtocolError("PROTOCOL_INVALID");
				await assertOperation(a.operation);
				await assertAck(a.operation, a.ack);
			}
			for (const image of syncRecoveryImages([item])) {
				checkCancelled(signal);
				if (!validateProject(image, { worldSnapshots: worlds }).ok || (await validateProjectIntegrity(image, { worldSnapshots: worlds }, false)).length) throw new SyncProtocolError("PROTOCOL_INVALID");
			}
		}
	} catch (cause) {
		if (signal?.aborted) checkCancelled(signal);
		throw new StorageError("VALIDATION_FAILED", "同期の共通元・二案・ACK・hashの整合性を確認できません。");
	}
	return captured;
}

//#endregion
//#region src/storage/recordDictionary.ts
init_json();
init_errors();
/** Lossless archive encoding. Positions, IDs, all historic variants and protocol
* hashes are unchanged after decoding; the dictionary is never an active image. */
const RECORD_DICTIONARY_FEATURE = "shared-records-v1";
const object$2 = (v) => !!v && typeof v === "object" && !Array.isArray(v);
const record = (v) => object$2(v) && typeof v.id === "string" && typeof v.projectId === "string" && (typeof v.kind === "string" && object$2(v.data) || typeof v.relationType === "string" && typeof v.fromId === "string" && typeof v.toId === "string" || typeof v.revision === "string" && object$2(v.fields) && Object.hasOwn(v, "tombstone"));
var RecordDictionaryReader = class {
	pool;
	limits;
	references = 0;
	depths;
	records;
	arrays;
	arrayCache = /* @__PURE__ */ new Map();
	recordIds = /* @__PURE__ */ new Map();
	usedRecords = /* @__PURE__ */ new Set();
	constructor(pool, limits) {
		this.pool = pool;
		this.limits = limits;
		if (!object$2(pool) || Object.keys(pool).some((key) => !["records", "arrays"].includes(key)) || !Array.isArray(pool.records) || !Array.isArray(pool.arrays) || pool.records.length > limits.objects || pool.arrays.length > limits.objects || pool.records.some((item) => !record(item))) throw new StorageError("ARCHIVE_INVALID", "共有レコード辞書の形式が不正です。", "data/records.json");
		this.records = pool.records;
		this.arrays = pool.arrays;
		this.records.forEach((value, index) => this.recordIds.set(value, index));
		const depth = (v) => {
			if (!v || typeof v !== "object") return 0;
			let maximum = 0;
			for (const child of Object.values(v)) maximum = Math.max(maximum, depth(child));
			return maximum + 1;
		};
		this.depths = this.records.map(depth);
		const freeze = (v) => {
			if (v && typeof v === "object" && !Object.isFrozen(v)) {
				Object.values(v).forEach(freeze);
				Object.freeze(v);
			}
		};
		this.records.forEach(freeze);
		for (const [index, array] of this.arrays.entries()) if (!object$2(array) || ("values" in array ? Object.keys(array).some((key) => key !== "values") || !Array.isArray(array.values) : Object.keys(array).some((key) => ![
			"base",
			"length",
			"changes"
		].includes(key)) || !Number.isSafeInteger(array.base) || array.base < 0 || array.base >= index || !Number.isSafeInteger(array.length) || array.length < 0 || !Array.isArray(array.changes))) throw new StorageError("ARCHIVE_INVALID", "共有レコード配列の基底・形式が不正です。");
	}
	values(id) {
		const invalid = () => {
			throw new StorageError("ARCHIVE_INVALID", "共有レコード配列の索引・差分が不正です。");
		};
		if (!Number.isSafeInteger(id) || Number(id) < 0 || Number(id) >= this.arrays.length) return invalid();
		const index = Number(id), ready = this.arrayCache.get(index);
		if (ready) return ready;
		const chain = [];
		let at = index;
		while (!this.arrayCache.has(at)) {
			chain.push(at);
			const array = this.arrays[at];
			if ("values" in array) break;
			at = array.base;
		}
		const resolve = (recordId) => {
			if (!Number.isSafeInteger(recordId) || Number(recordId) < 0 || Number(recordId) >= this.records.length) return invalid();
			return this.records[Number(recordId)];
		};
		for (const current of chain.reverse()) {
			const array = this.arrays[current];
			let values;
			if ("values" in array) values = array.values.map(resolve);
			else {
				values = this.arrayCache.get(array.base).slice();
				if (values.length !== array.length) return invalid();
				const seen = /* @__PURE__ */ new Set();
				for (const change of array.changes) {
					if (!Array.isArray(change) || change.length !== 2 || !Number.isSafeInteger(change[0]) || change[0] < 0 || change[0] >= values.length || seen.has(change[0])) return invalid();
					seen.add(change[0]);
					values[change[0]] = resolve(change[1]);
				}
			}
			if (values.length > this.limits.records) return invalid();
			this.references += values.length;
			if (this.references > Math.floor(this.limits.expandedBytes / 8)) throw new StorageError("LIMIT_EXCEEDED", "共有レコード参照の展開が安全上限を超えています。");
			Object.freeze(values);
			this.arrayCache.set(current, values);
		}
		return this.arrayCache.get(index);
	}
	decode(input, path) {
		const invalid = () => {
			throw new StorageError("ARCHIVE_INVALID", "共有レコードの位置・索引・重複が不正です。", path);
		};
		if (!object$2(input) || input.version !== 1 || Object.keys(input).some((k) => ![
			"version",
			"value",
			"arrays",
			"records"
		].includes(k)) || !Object.hasOwn(input, "value") || !Array.isArray(input.arrays) || !Array.isArray(input.records)) return invalid();
		const paths = [...input.arrays, ...input.records];
		if (paths.length > this.limits.objects) return invalid();
		const seen = /* @__PURE__ */ new Set(), writes = [];
		let root = input.value;
		for (const [index, raw] of paths.entries()) {
			if (!Array.isArray(raw) || raw.length > this.limits.depth || raw.some((key) => !(typeof key === "string" && ![
				"__proto__",
				"prototype",
				"constructor"
			].includes(key) || Number.isSafeInteger(key) && Number(key) >= 0))) return invalid();
			const keys = raw, keyText = JSON.stringify(keys);
			if (seen.has(keyText)) return invalid();
			seen.add(keyText);
			let parent = root;
			for (const key of keys.slice(0, -1)) {
				if (!parent || typeof parent !== "object" || !Object.hasOwn(parent, key)) return invalid();
				parent = parent[key];
			}
			const key = keys.at(-1), value = key === void 0 ? root : parent && typeof parent === "object" && Object.hasOwn(parent, key) ? parent[key] : void 0;
			const isArray = index < input.arrays.length, values = isArray ? this.values(value) : Number.isSafeInteger(value) && Number(value) >= 0 && Number(value) < this.records.length ? [this.records[Number(value)]] : invalid();
			if (!isArray) {
				this.references++;
				if (this.references > Math.floor(this.limits.expandedBytes / 8)) throw new StorageError("LIMIT_EXCEEDED", "共有レコード参照の展開が安全上限を超えています。", path);
			}
			for (const record of values) {
				const id = this.recordIds.get(record);
				if (keys.length + this.depths[id] > this.limits.depth) throw new StorageError("LIMIT_EXCEEDED", "共有レコードの展開深さが安全上限を超えています。", path);
				this.usedRecords.add(id);
			}
			const decoded = isArray ? values : values[0];
			if (key === void 0) {
				if (paths.length !== 1) return invalid();
				root = decoded;
			} else {
				if (!parent || typeof parent !== "object" || Array.isArray(parent) && typeof key !== "number" || !Array.isArray(parent) && typeof key !== "string") return invalid();
				writes.push({
					parent,
					key,
					value: decoded
				});
			}
		}
		for (const keys of paths) for (let i = 0; i < keys.length; i++) if (seen.has(JSON.stringify(keys.slice(0, i)))) return invalid();
		for (const write of writes) write.parent[write.key] = write.value;
		return root;
	}
	assertComplete() {
		if (this.usedRecords.size !== this.records.length || this.arrayCache.size !== this.arrays.length) throw new StorageError("ARCHIVE_INVALID", "未使用の共有レコード・配列が含まれています。", "data/records.json");
	}
};

//#endregion
//#region ../shinariokanri/node_modules/fflate/esm/browser.js
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
	var x = (i & 43690) >> 1 | (i & 21845) << 1;
	x = (x & 52428) >> 2 | (x & 13107) << 2;
	x = (x & 61680) >> 4 | (x & 3855) << 4;
	rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i = 0; i < 144; ++i) flt[i] = 8;
for (var i = 144; i < 256; ++i) flt[i] = 9;
for (var i = 256; i < 280; ++i) flt[i] = 7;
for (var i = 280; i < 288; ++i) flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i) fdt[i] = 5;
var flrm = /*#__PURE__*/ hMap(flt, 9, 1);
var fdrm = /*#__PURE__*/ hMap(fdt, 5, 1);
var max = function(a) {
	var m = a[0];
	for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
	return m;
};
var bits = function(d, p, m) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
var ec = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
];
var err = function(ind, msg, nt) {
	var e = new Error(msg || ec[ind]);
	e.code = ind;
	if (Error.captureStackTrace) Error.captureStackTrace(e, err);
	if (!nt) throw e;
	return e;
};
var inflt = function(dat, st, buf, dict) {
	var sl = dat.length, dl = dict ? dict.length : 0;
	if (!sl || st.f && !st.l) return buf || new u8(0);
	var noBuf = !buf;
	var resize = noBuf || st.i != 2;
	var noSt = st.i;
	if (noBuf) buf = new u8(sl * 3);
	var cbuf = function(l) {
		var bl = buf.length;
		if (l > bl) {
			var nbuf = new u8(Math.max(bl * 2, l));
			nbuf.set(buf);
			buf = nbuf;
		}
	};
	var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
	var tbts = sl * 8;
	do {
		if (!lm) {
			final = bits(dat, pos, 1);
			var type = bits(dat, pos + 1, 3);
			pos += 3;
			if (!type) {
				var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
				if (t > sl) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + l);
				buf.set(dat.subarray(s, t), bt);
				st.b = bt += l, st.p = pos = t * 8, st.f = final;
				continue;
			} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
			else if (type == 2) {
				var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
				var tl = hLit + bits(dat, pos + 5, 31) + 1;
				pos += 14;
				var ldt = new u8(tl);
				var clt = new u8(19);
				for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
				pos += hcLen * 3;
				var clb = max(clt), clbmsk = (1 << clb) - 1;
				var clm = hMap(clt, clb, 1);
				for (var i = 0; i < tl;) {
					var r = clm[bits(dat, pos, clbmsk)];
					pos += r & 15;
					var s = r >> 4;
					if (s < 16) ldt[i++] = s;
					else {
						var c = 0, n = 0;
						if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
						else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
						else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
						while (n--) ldt[i++] = c;
					}
				}
				var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
				lbt = max(lt);
				dbt = max(dt);
				lm = hMap(lt, lbt, 1);
				dm = hMap(dt, dbt, 1);
			} else err(1);
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
		}
		if (resize) cbuf(bt + 131072);
		var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
		var lpos = pos;
		for (;; lpos = pos) {
			var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
			pos += c & 15;
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
			if (!c) err(2);
			if (sym < 256) buf[bt++] = sym;
			else if (sym == 256) {
				lpos = pos, lm = null;
				break;
			} else {
				var add = sym - 254;
				if (sym > 264) {
					var i = sym - 257, b = fleb[i];
					add = bits(dat, pos, (1 << b) - 1) + fl[i];
					pos += b;
				}
				var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
				if (!d) err(3);
				pos += d & 15;
				var dt = fd[dsym];
				if (dsym > 3) {
					var b = fdeb[dsym];
					dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
				}
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + 131072);
				var end = bt + add;
				if (bt < dt) {
					var shift = dl - dt, dend = Math.min(dt, end);
					if (shift + bt < 0) err(3);
					for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
				}
				for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
			}
		}
		st.l = lm, st.p = lpos, st.b = bt, st.f = final;
		if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
	} while (!final);
	return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var et = /*#__PURE__*/ new u8(0);
/**
* Streaming DEFLATE decompression
*/
var Inflate = /* @__PURE__ */ function() {
	function Inflate(opts, cb) {
		if (typeof opts == "function") cb = opts, opts = {};
		this.ondata = cb;
		var dict = opts && opts.dictionary && opts.dictionary.subarray(-32768);
		this.s = {
			i: 0,
			b: dict ? dict.length : 0
		};
		this.o = new u8(32768);
		this.p = new u8(0);
		if (dict) this.o.set(dict);
	}
	Inflate.prototype.e = function(c) {
		if (!this.ondata) err(5);
		if (this.d) err(4);
		if (!this.p.length) this.p = c;
		else if (c.length) {
			var n = new u8(this.p.length + c.length);
			n.set(this.p), n.set(c, this.p.length), this.p = n;
		}
	};
	Inflate.prototype.c = function(final) {
		this.s.i = +(this.d = final || false);
		var bts = this.s.b;
		var dt = inflt(this.p, this.s, this.o);
		this.ondata(slc(dt, bts, this.s.b), this.d);
		this.o = slc(dt, this.s.b - 32768), this.s.b = this.o.length;
		this.p = slc(this.p, this.s.p / 8 | 0), this.s.p &= 7;
	};
	/**
	* Pushes a chunk to be inflated
	* @param chunk The chunk to push
	* @param final Whether this is the final chunk
	*/
	Inflate.prototype.push = function(chunk, final) {
		this.e(chunk), this.c(final);
	};
	return Inflate;
}();
var td = typeof TextDecoder != "undefined" && /*#__PURE__*/ new TextDecoder();
var tds = 0;
try {
	td.decode(et, { stream: true });
	tds = 1;
} catch (e) {}

//#endregion
//#region src/storage/recovery.ts
init_model();
init_json();
init_errors();
function recoveryImages(recovery) {
	return recovery?.pending.flatMap((item) => [item.command.before, item.command.after].map((state) => ({
		...state,
		history: []
	}))) ?? [];
}
function projectWithRecoveryHistory(project, recovery) {
	const history = new Map(project.history.map((command) => [command.operationId, command]));
	for (const item of recovery?.pending ?? []) {
		const previous = history.get(item.operationId);
		if (previous && !equalJson(previous, item.command)) throw new StorageError("OPERATION_CONFLICT", "送信待ちの内容が保存履歴と一致しません。", item.operationId);
		history.set(item.operationId, item.command);
	}
	return {
		...project,
		history: [...history.values()]
	};
}
async function validateRecovery(input, project, worlds, signal) {
	const invalid = (message, path = "data/recovery.json") => {
		throw new StorageError("VALIDATION_FAILED", message, path);
	};
	if (!input || typeof input !== "object" || Array.isArray(input)) return invalid("送信待ち復元情報はオブジェクトです。");
	const raw = input;
	if (Object.keys(raw).some((key) => ![
		"version",
		"projectId",
		"sourceRevision",
		"serverRevision",
		"pending"
	].includes(key)) || raw.version !== 1 || raw.projectId !== project.projectId || raw.sourceRevision !== project.revision || typeof raw.serverRevision !== "string" || !/^(0|[1-9]\d*)$/.test(raw.serverRevision) || !Array.isArray(raw.pending) || raw.pending.length > 1e5) return invalid("送信待ち復元情報の版・作品・基底版・件数が不正です。");
	const recovery = structuredClone(input), seen = /* @__PURE__ */ new Set();
	for (const item of recovery.pending) {
		checkCancelled(signal);
		if (!item || typeof item !== "object" || Object.keys(item).some((key) => ![
			"operationId",
			"command",
			"commandHash",
			"origin"
		].includes(key)) || !ID_PATTERN.test(item.operationId) || seen.has(item.operationId) || typeof item.commandHash !== "string" || !/^[0-9a-f]{64}$/.test(item.commandHash)) return invalid("送信待ちの操作IDまたはhashが不正・重複しています。");
		if ("origin" in item && (!item.origin || typeof item.origin !== "object" || Array.isArray(item.origin) || Object.keys(item.origin).some((key) => ![
			"projectId",
			"operationId",
			"serverRevision"
		].includes(key)) || !ID_PATTERN.test(item.origin.projectId) || !ID_PATTERN.test(item.origin.operationId) || !/^(0|[1-9]\d*)$/.test(item.origin.serverRevision))) return invalid("送信待ちの元操作の記録が不正です。");
		seen.add(item.operationId);
		if (!item.command || item.command.operationId !== item.operationId || item.command.projectId !== project.projectId || await sha256(jsonBytes(item.command)) !== item.commandHash) return invalid("送信待ち操作の内容が固定したhashと一致しません。");
		const recordProject = {
			...item.command.after,
			history: [item.command]
		};
		const validation = validateProject(recordProject, { worldSnapshots: worlds });
		if (!validation.ok) return invalid(validation.issues.map((issue) => `${issue.path}: ${issue.message}`).join("\n"));
		for (const image of recoveryImages({
			...recovery,
			pending: [item]
		})) {
			const issues = await validateProjectIntegrity(image, { worldSnapshots: worlds }, false);
			if (issues.length) return invalid(issues.map((issue) => issue.message).join("\n"));
		}
	}
	projectWithRecoveryHistory(project, recovery);
	return recovery;
}

//#endregion
//#region src/storage/archiveData.ts
init_model();
init_errors();
init_json();
const uuid$1 = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const hashPattern = /^[0-9a-f]{64}$/;
const pathPattern = /^(?:manifest\.json|data\/(?:project|recovery|sync-recovery|records)\.json|worlds\/[0-9a-f-]{36}\.json|assets\/[0-9a-f]{64}\.[a-z0-9]{1,8})$/;
const mimeExtensions = {
	"image/png": ["png"],
	"image/jpeg": ["jpg", "jpeg"],
	"image/gif": ["gif"],
	"image/webp": ["webp"],
	"audio/mpeg": ["mp3"],
	"audio/wav": ["wav"],
	"audio/x-wav": ["wav"],
	"audio/ogg": ["ogg"],
	"video/mp4": ["mp4"],
	"video/webm": ["webm"],
	"application/pdf": ["pdf"],
	"text/plain": ["txt"],
	"application/json": ["json"],
	"application/octet-stream": ["bin"]
};
function assetPath(contentHash, mediaType = "application/octet-stream") {
	const extensions = mimeExtensions[mediaType];
	if (!hashPattern.test(contentHash) || !extensions) throw new StorageError("ASSET_INVALID", "素材のhashまたは種類が未対応です。");
	return `assets/${contentHash}.${extensions[0]}`;
}
function validateAsset(path, mediaType, bytes) {
	safeArchivePath(path);
	const match = /^assets\/([0-9a-f]{64})\.([a-z0-9]{1,8})$/.exec(path);
	if (!match || !mimeExtensions[mediaType]?.includes(match[2])) throw new StorageError("ASSET_INVALID", "素材パス・種類・拡張子が一致しません。", path);
	if (bytes) {
		const starts = (values) => values.every((value, index) => bytes[index] === value);
		const ascii = (offset, text) => [...text].every((char, index) => bytes[offset + index] === char.charCodeAt(0));
		let valid = true;
		switch (mediaType) {
			case "image/png":
				valid = starts([
					137,
					80,
					78,
					71,
					13,
					10,
					26,
					10
				]);
				break;
			case "image/jpeg":
				valid = starts([
					255,
					216,
					255
				]);
				break;
			case "image/gif":
				valid = ascii(0, "GIF87a") || ascii(0, "GIF89a");
				break;
			case "image/webp":
				valid = ascii(0, "RIFF") && ascii(8, "WEBP");
				break;
			case "audio/mpeg":
				valid = ascii(0, "ID3") || bytes[0] === 255 && (bytes[1] & 224) === 224;
				break;
			case "audio/wav":
			case "audio/x-wav":
				valid = ascii(0, "RIFF") && ascii(8, "WAVE");
				break;
			case "audio/ogg":
				valid = ascii(0, "OggS");
				break;
			case "video/mp4":
				valid = ascii(4, "ftyp");
				break;
			case "video/webm":
				valid = starts([
					26,
					69,
					223,
					163
				]);
				break;
			case "application/pdf":
				valid = ascii(0, "%PDF-");
				break;
			case "application/json":
				parseStrictJson(bytes, path);
				break;
			case "text/plain": try {
				new TextDecoder("utf-8", { fatal: true }).decode(bytes);
			} catch {
				valid = false;
			}
		}
		if (!valid) throw new StorageError("ASSET_INVALID", "素材bytesが宣言した種類と一致しません。", path);
	}
	return match[1];
}
function zipEntries(bytes, limits) {
	if (bytes.byteLength > limits.compressedBytes) throw new StorageError("LIMIT_EXCEEDED", "圧縮ファイルが64 MiBの上限を超えています。");
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	const invalid = (message, path) => {
		throw new StorageError("ARCHIVE_INVALID", message, path);
	};
	const u16 = (offset) => offset >= 0 && offset + 2 <= bytes.length ? view.getUint16(offset, true) : invalid("ZIPヘッダーが途中で切れています。");
	const u32 = (offset) => offset >= 0 && offset + 4 <= bytes.length ? view.getUint32(offset, true) : invalid("ZIPヘッダーが途中で切れています。");
	if (bytes.length < 22 || u32(0) !== 67324752) return invalid("専用ZIPコンテナーのヘッダーがありません。");
	let end = -1;
	for (let offset = bytes.length - 22; offset >= Math.max(0, bytes.length - 65557); offset--) if (u32(offset) === 101010256 && offset + 22 + u16(offset + 20) === bytes.length) {
		end = offset;
		break;
	}
	if (end < 0) return invalid("ZIPの終端が不正です。");
	const count = u16(end + 10), directorySize = u32(end + 12), directoryStart = u32(end + 16);
	if (u16(end + 4) || u16(end + 6) || u16(end + 8) !== count || count === 65535 || directorySize === 4294967295 || directoryStart === 4294967295) return invalid("分割ZIPとZIP64は未対応です。");
	if (count > limits.files) throw new StorageError("LIMIT_EXCEEDED", "ZIPのファイル数が上限を超えています。");
	if (!count || directoryStart + directorySize !== end) return invalid("ZIPの中央ディレクトリが不正です。");
	let position = directoryStart, total = 0;
	const entries = [], paths = /* @__PURE__ */ new Set();
	function decodeName(start, size) {
		if (start + size > bytes.length) return invalid("ZIPのファイル名が途中で切れています。");
		try {
			return new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(start, start + size));
		} catch {
			return invalid("ZIPのファイル名がUTF-8ではありません。");
		}
	}
	function checkExtra(start, size, path) {
		const finish = start + size;
		if (finish > bytes.length) return invalid("ZIP追加情報が途中で切れています。", path);
		for (let offset = start; offset < finish;) {
			if (offset + 4 > finish) return invalid("ZIP追加情報が不正です。", path);
			const type = u16(offset), length = u16(offset + 2);
			if (type === 1) return invalid("ZIP64は未対応です。", path);
			offset += 4 + length;
			if (offset > finish) return invalid("ZIP追加情報の長さが不正です。", path);
		}
	}
	for (let index = 0; index < count; index++) {
		if (position + 46 > end || u32(position) !== 33639248) return invalid("ZIPの中央ヘッダーが不正です。");
		const flags = u16(position + 8), method = u16(position + 10), crc = u32(position + 16);
		const compressedSize = u32(position + 20), expandedSize = u32(position + 24);
		const nameLength = u16(position + 28), extraLength = u16(position + 30), commentLength = u16(position + 32);
		const localStart = u32(position + 42), attrs = u32(position + 38), path = decodeName(position + 46, nameLength);
		safeArchivePath(path);
		if (!pathPattern.test(path)) return invalid("専用形式に未定義のファイルがあります。", path);
		if (paths.has(path)) return invalid("ZIP内のファイル名が重複しています。", path);
		paths.add(path);
		if (flags & 8257 || method !== 0 && method !== 8) return invalid("暗号化ZIPまたは未対応の圧縮方式です。", path);
		if ((attrs >>> 16 & 61440) === 40960 || attrs & 16) return invalid("symlinkとディレクトリは読み込めません。", path);
		if (u16(position + 34) || compressedSize === 4294967295 || expandedSize === 4294967295 || localStart === 4294967295) return invalid("分割ZIPとZIP64は未対応です。", path);
		if (expandedSize > (path.startsWith("assets/") ? limits.assetBytes : limits.jsonBytes) || (total += expandedSize) > limits.expandedBytes) throw new StorageError("LIMIT_EXCEEDED", "展開サイズが安全上限を超えています。", path);
		checkExtra(position + 46 + nameLength, extraLength, path);
		if (localStart + 30 > directoryStart || u32(localStart) !== 67324752) return invalid("ZIPのローカルヘッダーが不正です。", path);
		const localNameLength = u16(localStart + 26), localExtraLength = u16(localStart + 28);
		if (u16(localStart + 6) !== flags || u16(localStart + 8) !== method || decodeName(localStart + 30, localNameLength) !== path) return invalid("ZIPのローカル/中央ヘッダーが一致しません。", path);
		checkExtra(localStart + 30 + localNameLength, localExtraLength, path);
		const dataStart = localStart + 30 + localNameLength + localExtraLength;
		let localEnd = dataStart + compressedSize;
		if (localEnd > directoryStart) return invalid("ZIPの圧縮データが範囲外です。", path);
		if (flags & 8) {
			let descriptor = localEnd;
			if (u32(descriptor) === 134695760) descriptor += 4;
			if (u32(descriptor) !== crc || u32(descriptor + 4) !== compressedSize || u32(descriptor + 8) !== expandedSize) return invalid("ZIPのdata descriptorが一致しません。", path);
			localEnd = descriptor + 12;
		} else if (u32(localStart + 14) !== crc || u32(localStart + 18) !== compressedSize || u32(localStart + 22) !== expandedSize) return invalid("ZIPのサイズ/CRC宣言が一致しません。", path);
		entries.push({
			path,
			compressedSize,
			expandedSize,
			dataStart,
			method,
			crc,
			localStart,
			localEnd
		});
		position += 46 + nameLength + extraLength + commentLength;
	}
	if (position !== directoryStart + directorySize) return invalid("ZIPの中央ディレクトリ長が不正です。");
	let expected = 0;
	for (const entry of [...entries].sort((left, right) => left.localStart - right.localStart)) {
		if (entry.localStart !== expected) return invalid("ZIPに未列挙データまたは重複した領域があります。", entry.path);
		expected = entry.localEnd;
	}
	if (expected !== directoryStart) return invalid("ZIPに未列挙データがあります。");
	if (!paths.has("manifest.json") || !paths.has("data/project.json")) return invalid("manifestまたは作品データがありません。");
	return entries;
}
const crcTable = Uint32Array.from({ length: 256 }, (_, index) => {
	let value = index;
	for (let bit = 0; bit < 8; bit++) value = value & 1 ? value >>> 1 ^ 3988292384 : value >>> 1;
	return value >>> 0;
});
const yieldTask = () => new Promise((resolve) => setTimeout(resolve, 0));
async function expand(bytes, entries, options, limits) {
	const files = /* @__PURE__ */ new Map();
	let total = 0, completed = 0, pushes = 0;
	for (const entry of entries) {
		checkCancelled(options.signal);
		let size = 0, crc = 4294967295;
		const chunks = [];
		const consume = (chunk) => {
			size += chunk.byteLength;
			total += chunk.byteLength;
			if (size > entry.expandedSize || size > (entry.path.startsWith("assets/") ? limits.assetBytes : limits.jsonBytes) || total > limits.expandedBytes) throw new StorageError("LIMIT_EXCEEDED", "実際の展開bytesが安全上限または宣言サイズを超えました。", entry.path);
			for (const byte of chunk) crc = crcTable[(crc ^ byte) & 255] ^ crc >>> 8;
			chunks.push(chunk.slice());
		};
		try {
			if (entry.method === 0) consume(bytes.subarray(entry.dataStart, entry.dataStart + entry.compressedSize));
			else {
				const inflater = new Inflate(consume);
				for (let offset = 0; offset < entry.compressedSize; offset += 4096) {
					checkCancelled(options.signal);
					const end = Math.min(entry.compressedSize, offset + 4096);
					inflater.push(bytes.subarray(entry.dataStart + offset, entry.dataStart + end), end === entry.compressedSize);
					if (++pushes % 32 === 0) await yieldTask();
				}
				if (!entry.compressedSize) inflater.push(/* @__PURE__ */ new Uint8Array(), true);
			}
		} catch (error) {
			if (error instanceof StorageError) throw error;
			throw new StorageError("ARCHIVE_INVALID", "素材またはJSONの展開に失敗しました。", entry.path, { cause: error });
		}
		if (size !== entry.expandedSize || (crc ^ 4294967295) >>> 0 !== entry.crc) throw new StorageError("ARCHIVE_INVALID", "ZIPの実サイズまたはCRCが一致しません。", entry.path);
		const file = new Uint8Array(size);
		let offset = 0;
		for (const chunk of chunks) {
			file.set(chunk, offset);
			offset += chunk.byteLength;
		}
		files.set(entry.path, file);
		options.onProgress?.({
			stage: "expanding",
			completed: ++completed,
			total: entries.length,
			path: entry.path
		});
		if (completed % 32 === 0) await yieldTask();
	}
	return files;
}
function object$1(value, path) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new StorageError("ARCHIVE_INVALID", "オブジェクトが必要です。", path);
	return value;
}
function parseManifest(value) {
	const data = object$1(value, "manifest.json");
	if (data.format !== "scenario-package" || data.formatVersion !== "1.0.0") throw new StorageError("FORMAT_UNSUPPORTED", "この専用形式の版には対応していません。元のファイルを保持してください。", "manifest.json");
	const minimum = typeof data.minimumReaderVersion === "string" && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(data.minimumReaderVersion) ? data.minimumReaderVersion.split(".").map(Number) : void 0;
	if (!minimum || minimum[0] > 1 || minimum[0] === 1 && (minimum[1] > 0 || minimum[2] > 0)) throw new StorageError("FORMAT_UNSUPPORTED", "読み込みに新しいアプリが必要です。", "manifest.json/minimumReaderVersion");
	if (data.requiredFeatures !== void 0 && (!Array.isArray(data.requiredFeatures) || data.requiredFeatures.some((feature) => ![
		"portable-recovery-v1",
		"native-sync-recovery-v1",
		"shared-review-source-v1",
		"shared-records-v1"
	].includes(feature)))) throw new StorageError("FORMAT_UNSUPPORTED", "未知の必須機能が宣言されています。", "manifest.json/requiredFeatures");
	if (typeof data.projectId !== "string" || !uuid$1.test(data.projectId) || typeof data.snapshotId !== "string" || !uuid$1.test(data.snapshotId) || typeof data.exportedAt !== "string" || !Number.isFinite(Date.parse(data.exportedAt)) || !data.exportedAt.endsWith("Z") || !["embedded", "metadata_only"].includes(data.assetMode) || !Array.isArray(data.files)) throw new StorageError("ARCHIVE_INVALID", "manifestの必須項目が不正です。", "manifest.json");
	const paths = /* @__PURE__ */ new Set();
	for (const [index, file] of data.files.entries()) {
		const item = object$1(file, `manifest.json/files/${index}`);
		if (typeof item.path !== "string") throw new StorageError("ARCHIVE_INVALID", "manifestのpathが不正です。", `manifest.json/files/${index}`);
		safeArchivePath(item.path);
		if (item.path === "manifest.json" || !pathPattern.test(item.path) || paths.has(item.path) || !Number.isSafeInteger(item.byteSize) || item.byteSize < 0 || typeof item.sha256 !== "string" || !hashPattern.test(item.sha256) || item.role !== (item.path === "data/project.json" ? "project" : item.path === "data/recovery.json" ? "recovery" : item.path === "data/sync-recovery.json" ? "sync_recovery" : item.path === "data/records.json" ? "record_dictionary" : item.path.startsWith("worlds/") ? "world" : "asset")) throw new StorageError("ARCHIVE_INVALID", "manifestのファイル宣言が不正または重複しています。", item.path);
		paths.add(item.path);
	}
	return data;
}
function checkedProject(value, path, limits, worldSnapshots = {}) {
	let validation;
	try {
		validation = validateProject(value, { worldSnapshots });
	} catch (error) {
		throw new StorageError("VALIDATION_FAILED", "共通世界または作品の構造が不正です。", path, { cause: error });
	}
	if (!validation.ok) throw new StorageError("VALIDATION_FAILED", validation.issues.map((issue) => `${issue.path}: ${issue.message}`).join("\n"), path);
	const project = validation.value;
	if (project.entities.length + project.relations.length > limits.records) throw new StorageError("LIMIT_EXCEEDED", "entityとrelationの件数が上限を超えています。", path);
	enforceFieldLimits(project, path, limits);
	return project;
}
async function checkedProjectIntegrity(project, path, worldSnapshots = {}) {
	const issues = await validateProjectIntegrity(project, { worldSnapshots }, true);
	if (issues.length) throw new StorageError("VALIDATION_FAILED", issues.map((issue) => `${issue.path}: ${issue.message}`).join("\n"), path);
}
function enforceFieldLimits(value, path, limits) {
	if (typeof value === "string") {
		if (new TextEncoder().encode(value).byteLength > limits.fieldBytes) throw new StorageError("LIMIT_EXCEEDED", "本文フィールドが1 MiBの上限を超えています。", path);
	} else if (Array.isArray(value)) value.forEach((item, index) => enforceFieldLimits(item, `${path}/${index}`, limits));
	else if (value && typeof value === "object") for (const [key, item] of Object.entries(value)) enforceFieldLimits(item, `${path}/${key}`, limits);
}
function attachmentMetadata(project) {
	const result = /* @__PURE__ */ new Map();
	const visited = /* @__PURE__ */ new WeakSet();
	function walk(value) {
		if (value && typeof value === "object") {
			if (visited.has(value)) return;
			visited.add(value);
		}
		if (Array.isArray(value)) {
			value.forEach(walk);
			return;
		}
		if (!value || typeof value !== "object") return;
		const data = value;
		if (data.kind === "attachment") {
			const attachment = object$1(data.data, "attachment/data");
			const hash = validateAsset(attachment.assetPath, attachment.mediaType);
			if (hash !== attachment.contentHash || !Number.isSafeInteger(attachment.byteSize) || attachment.byteSize < 0) throw new StorageError("ASSET_INVALID", "素材のhashまたはサイズが不正です。", attachment.assetPath);
			const existing = result.get(hash);
			if (existing && (existing.assetPath !== attachment.assetPath || existing.byteSize !== attachment.byteSize || existing.mediaType !== attachment.mediaType)) throw new StorageError("ASSET_INVALID", "同じhashの素材に異なるメタデータがあります。", attachment.assetPath);
			result.set(hash, attachment);
		}
		for (const item of Object.values(data)) walk(item);
	}
	walk(project);
	return [...result.values()];
}
function allAttachmentMetadata(projects) {
	const byHash = /* @__PURE__ */ new Map();
	for (const project of projects) for (const metadata of attachmentMetadata(project)) {
		const old = byHash.get(metadata.contentHash);
		if (old && (old.assetPath !== metadata.assetPath || old.mediaType !== metadata.mediaType || old.byteSize !== metadata.byteSize)) throw new StorageError("ASSET_INVALID", "作品間の素材メタデータが一致しません。", metadata.assetPath);
		byHash.set(metadata.contentHash, metadata);
	}
	return [...byHash.values()];
}
/** Complete backups need pinned worlds referenced by old history and immutable versions too. */
function referencedWorlds(projects, availableWorlds = {}) {
	const fixed = /* @__PURE__ */ new Map();
	for (const world of Object.values(availableWorlds)) for (const pin of world.snapshots) {
		const existing = fixed.get(pin.id);
		if (existing && existing.reference.contentHash !== pin.contentHash) throw new StorageError("IMMUTABLE_SNAPSHOT", "固定世界の期待hashが同じIDで異なります。", pin.id);
		fixed.set(pin.id, {
			world,
			reference: {
				projectId: world.projectId,
				immutableSnapshotId: pin.id,
				contentHash: pin.contentHash
			}
		});
	}
	const references = /* @__PURE__ */ new Map();
	const visited = /* @__PURE__ */ new WeakSet();
	function walk(value) {
		if (value && typeof value === "object") {
			if (visited.has(value)) return;
			visited.add(value);
		}
		if (Array.isArray(value)) {
			value.forEach(walk);
			return;
		}
		if (!value || typeof value !== "object") return;
		const data = value;
		if (Array.isArray(data.worldReferences)) for (const reference of data.worldReferences) {
			const old = references.get(reference.immutableSnapshotId);
			if (old && (old.projectId !== reference.projectId || old.contentHash !== reference.contentHash)) throw new StorageError("VALIDATION_FAILED", "同じ共通世界snapshot IDの参照内容が一致しません。", reference.immutableSnapshotId);
			references.set(reference.immutableSnapshotId, reference);
		}
		const typedReferences = !fixed.size ? [] : typeof data.kind === "string" && ENTITY_KINDS.includes(data.kind) && typeof data.projectId === "string" && data.data && typeof data.data === "object" ? collectReferences(data) : typeof data.relationType === "string" && typeof data.projectId === "string" && typeof data.fromId === "string" && typeof data.toId === "string" ? collectRelationReferences(data) : [];
		for (const reference of typedReferences) if (reference.scope === "snapshot") {
			const pin = fixed.get(reference.id);
			if (pin && pin.world.projectId !== data.projectId) {
				const existing = references.get(reference.id);
				if (existing && existing.contentHash !== pin.reference.contentHash) throw new StorageError("IMMUTABLE_SNAPSHOT", "引用世界の期待hashが採用版と異なります。", reference.id);
				references.set(reference.id, pin.reference);
			}
		}
		for (const item of Object.values(data)) walk(item);
	}
	projects.forEach(walk);
	return [...references.values()];
}
function worldSnapshotContents(worlds) {
	const contents = Object.create(null);
	for (const [id, raw] of Object.entries(worlds)) {
		if (!raw || typeof raw !== "object" || !Array.isArray(raw.snapshots)) continue;
		const snapshot = raw.snapshots.find((item) => item && item.id === id);
		if (!snapshot?.content || typeof snapshot.content !== "object" || !Array.isArray(snapshot.content.entities) || !Array.isArray(snapshot.content.relations) || !Array.isArray(snapshot.content.calendars)) continue;
		if (contents[id] && !equalJson(contents[id], snapshot.content)) throw new StorageError("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", id);
		contents[id] = snapshot.content;
		for (const dependency of raw.snapshots) if (dependency?.content?.projectId === raw.projectId) {
			if (contents[dependency.id] && !equalJson(contents[dependency.id], dependency.content)) throw new StorageError("IMMUTABLE_SNAPSHOT", "同じ固定版IDに異なる内容があります。", dependency.id);
			contents[dependency.id] = dependency.content;
		}
	}
	return contents;
}
function verifyWorlds(projects, worlds) {
	for (const [id, world] of Object.entries(worlds)) if (!world.snapshots.some((item) => item.id === id)) throw new StorageError("VALIDATION_FAILED", "共通世界ファイルに指定した不変snapshotがありません。", `worlds/${id}.json`);
	for (const reference of referencedWorlds(projects)) {
		const world = worlds[reference.immutableSnapshotId];
		const snapshot = world?.snapshots.find((item) => item.id === reference.immutableSnapshotId);
		if (!world || world.projectId !== reference.projectId || !snapshot || snapshot.contentHash !== reference.contentHash) throw new StorageError("VALIDATION_FAILED", "参照した共通世界の不変snapshotが不足または不一致です。", `worlds/${reference.immutableSnapshotId}.json`);
	}
}
async function verifySnapshotHashes(projects) {
	const snapshots = /* @__PURE__ */ new Map();
	function walk(value) {
		if (Array.isArray(value)) {
			value.forEach(walk);
			return;
		}
		if (!value || typeof value !== "object") return;
		const data = value;
		if (Array.isArray(data.snapshots)) for (const snapshot of data.snapshots) {
			const previous = snapshots.get(snapshot.id);
			if (previous && !equalJson(previous, snapshot)) throw new StorageError("IMMUTABLE_SNAPSHOT", "同じ不変snapshot IDに異なる内容があります。", snapshot.id);
			snapshots.set(snapshot.id, snapshot);
		}
		for (const item of Object.values(data)) walk(item);
	}
	projects.forEach(walk);
	for (const snapshot of snapshots.values()) if (await sha256(jsonBytes(snapshot.content)) !== snapshot.contentHash) throw new StorageError("HASH_MISMATCH", "不変snapshotの内容hashが一致しません。", `snapshots/${snapshot.id}`);
}
/** Internal entry point also used by the dedicated worker; it never changes IndexedDB. */
async function inspectScenarioData(bytes, options = {}) {
	checkCancelled(options.signal);
	const limits = resolveLimits(options.limits);
	const entries = zipEntries(bytes, limits);
	options.onProgress?.({
		stage: "container",
		completed: entries.length,
		total: entries.length
	});
	const files = await expand(bytes, entries, options, limits);
	const budget = { objects: 0 };
	const manifest = parseManifest(parseStrictJson(files.get("manifest.json"), "manifest.json", limits, budget));
	if (manifest.files.length !== files.size - 1) throw new StorageError("ARCHIVE_INVALID", "ZIPとmanifestのファイル数が一致しません。", "manifest.json");
	const declared = new Set(manifest.files.map((file) => file.path));
	for (const path of files.keys()) if (path !== "manifest.json" && !declared.has(path)) throw new StorageError("ARCHIVE_INVALID", "manifestに列挙されていないファイルがあります。", path);
	for (const [index, file] of manifest.files.entries()) {
		checkCancelled(options.signal);
		const data = files.get(file.path);
		if (!data) throw new StorageError("ARCHIVE_INVALID", "manifestで列挙したファイルがありません。", file.path);
		if (data.byteLength !== file.byteSize || await sha256(data) !== file.sha256) throw new StorageError("HASH_MISMATCH", "ファイルサイズまたはSHA-256が一致しません。", file.path);
		options.onProgress?.({
			stage: "hashes",
			completed: index + 1,
			total: manifest.files.length,
			path: file.path
		});
	}
	const hasDictionary = manifest.requiredFeatures?.includes("shared-records-v1") ?? false;
	if (hasDictionary !== files.has("data/records.json")) throw new StorageError("FORMAT_UNSUPPORTED", "共有レコード辞書には対応する必須機能の宣言が必要です。");
	const dictionary = hasDictionary ? new RecordDictionaryReader(parseStrictJson(files.get("data/records.json"), "data/records.json", limits, budget), limits) : void 0;
	const read = (path) => {
		const value = parseStrictJson(files.get(path), path, limits, budget);
		return dictionary ? dictionary.decode(value, path) : value;
	};
	const rawWorlds = Object.create(null);
	for (const file of manifest.files.filter((item) => item.role === "world")) rawWorlds[file.path.slice(7, -5)] = read(file.path);
	const worldContents = worldSnapshotContents(rawWorlds);
	const project = checkedProject(read("data/project.json"), "data/project.json", limits, worldContents);
	if (project.projectId !== manifest.projectId) throw new StorageError("VALIDATION_FAILED", "manifestと作品のprojectIdが一致しません。", "data/project.json/projectId");
	const worlds = Object.create(null);
	let records = project.entities.length + project.relations.length;
	for (const file of manifest.files.filter((item) => item.role === "world")) {
		const world = checkedProject(rawWorlds[file.path.slice(7, -5)], file.path, limits, worldContents);
		worlds[file.path.slice(7, -5)] = world;
		records += world.entities.length + world.relations.length;
		if (records > limits.records) throw new StorageError("LIMIT_EXCEEDED", "参照世界を含むentityとrelationの件数が上限を超えています。", file.path);
	}
	const declaredRecovery = manifest.requiredFeatures?.includes("portable-recovery-v1") ?? false;
	if (declaredRecovery !== files.has("data/recovery.json")) throw new StorageError("FORMAT_UNSUPPORTED", "送信待ち復元情報には対応する必須機能の宣言が必要です。");
	const recovery = declaredRecovery ? await validateRecovery(read("data/recovery.json"), project, worldContents, options.signal) : void 0;
	const declaredSync = manifest.requiredFeatures?.includes("native-sync-recovery-v1") ?? false;
	if (declaredSync !== files.has("data/sync-recovery.json")) throw new StorageError("FORMAT_UNSUPPORTED", "同期復元証跡には必須機能宣言が必要です。");
	const syncRecovery = declaredSync ? await validateSyncRecovery(read("data/sync-recovery.json"), worldContents, options.signal) : void 0;
	dictionary?.assertComplete();
	const operationalImages = [...recoveryImages(recovery), ...syncRecoveryImages(syncRecovery)];
	if (hasSharedReviewSource([
		project,
		...operationalImages,
		...Object.values(worlds)
	]) !== (manifest.requiredFeatures?.includes("shared-review-source-v1") ?? false)) throw new StorageError("FORMAT_UNSUPPORTED", "共有指摘の出所には対応する必須機能宣言が必要です。");
	verifyWorlds([
		project,
		...operationalImages,
		...Object.values(worlds)
	], worlds);
	await verifySnapshotHashes([
		project,
		...operationalImages,
		...Object.values(worlds)
	]);
	await checkedProjectIntegrity(project, "data/project.json", worldContents);
	for (const [id, world] of Object.entries(worlds)) await checkedProjectIntegrity(world, `worlds/${id}.json`, worldContents);
	const attachments = new Map(allAttachmentMetadata([
		project,
		...operationalImages,
		...Object.values(worlds)
	]).map((item) => [item.assetPath, item]));
	const assets = [];
	for (const file of manifest.files.filter((item) => item.role === "asset")) {
		const metadata = attachments.get(file.path), data = files.get(file.path);
		if (!metadata || manifest.assetMode === "metadata_only") throw new StorageError("ASSET_INVALID", "未参照または軽量保存に不適切な素材ファイルです。", file.path);
		validateAsset(file.path, metadata.mediaType, data);
		if (data.byteLength !== metadata.byteSize || await sha256(data) !== metadata.contentHash) throw new StorageError("HASH_MISMATCH", "添付素材の原hashまたはサイズが一致しません。", file.path);
		assets.push({
			path: file.path,
			contentHash: metadata.contentHash,
			mediaType: metadata.mediaType,
			bytes: data
		});
	}
	const missing = [...attachments.keys()].filter((path) => !files.has(path));
	if (manifest.assetMode === "embedded" && missing.length) throw new StorageError("ASSET_MISSING", "完全保存に必要な添付bytesが不足しています。", missing[0]);
	checkCancelled(options.signal);
	options.onProgress?.({
		stage: "validating",
		completed: 1,
		total: 1
	});
	return {
		manifest,
		project,
		worlds,
		assets,
		...recovery ? { recovery } : {},
		...syncRecovery ? { syncRecovery } : {},
		warnings: [...manifest.assetMode === "metadata_only" ? [`軽量保存です。${missing.length}件の添付bytesを含まず、完全バックアップとして復元できません。`] : [], ...recovery?.pending.length ? [`${recovery.pending.length}件の送信待ち意図を保持します。接続先・権限・サーバー共通元を確認するまで自動送信しません。`] : []],
		summary: {
			name: project.name,
			entities: project.entities.length,
			relations: project.relations.length,
			assetBytes: assets.reduce((sum, item) => sum + item.bytes.byteLength, 0),
			missingAssets: missing.length,
			history: project.history.length
		}
	};
}
function hasSharedReviewSource(projects) {
	const seen = /* @__PURE__ */ new WeakSet();
	const walk = (value) => {
		if (!value || typeof value !== "object" || seen.has(value)) return false;
		seen.add(value);
		const item = value;
		if (item.kind === "review" && item.data && typeof item.data === "object" && item.data.sharedSource) return true;
		return Object.values(value).some(walk);
	};
	return projects.some(walk);
}

//#endregion
//#region src/storage/archive.ts
init_json();

//#endregion
//#region src/sync/archiveTransfer.ts
/** Full recovery bytes are accepted only for the confirmed image; local history revisions are independent. */
async function inspectConfirmedArchive(bytes, projectId, documents, signal) {
	if (bytes.byteLength > 67108864) throw new SyncProtocolError("PROTOCOL_INVALID");
	const result = await inspectScenarioData(bytes, { signal });
	const content = (items) => items.map(({ revision: _revision, ...doc }) => doc).sort((a, b) => a.id.localeCompare(b.id));
	if (result.manifest.assetMode !== "embedded" || result.summary.missingAssets || result.project.projectId !== projectId || !sameValue(content(nativeDocuments(result.project, "0")), content(documents))) throw new SyncProtocolError("REVISION_CHANGED");
	return result;
}

//#endregion
//#region src/domain/text.ts
init_model();
const OVERLAP_REASON = "本文の置換・削除・段落分割が注記に重なり、元の文字を特定できません。";
const plain = (blocks) => blocks.map((block) => block.text).join("\n");
const editOrigins = /* @__PURE__ */ new WeakMap();
/** Character origins use Unicode code points, including the paragraph separators. */
function characterOrigins(before, after, replacement) {
	const origins = new Array(before.length);
	let prefix = 0, suffix = 0;
	if (replacement && replacement.start >= 0 && replacement.end >= replacement.start && replacement.end <= before.length) {
		const insertedLength = after.length - (before.length - (replacement.end - replacement.start));
		if (insertedLength >= 0 && before.slice(0, replacement.start).join("") === after.slice(0, replacement.start).join("") && before.slice(replacement.end).join("") === after.slice(replacement.start + insertedLength).join("")) {
			for (let i = 0; i < replacement.start; i++) origins[i] = i;
			for (let i = replacement.end; i < before.length; i++) origins[i] = i + insertedLength - (replacement.end - replacement.start);
			return origins;
		}
	}
	while (prefix < before.length && prefix < after.length && before[prefix] === after[prefix]) {
		origins[prefix] = prefix;
		prefix++;
	}
	while (suffix < before.length - prefix && suffix < after.length - prefix && before[before.length - suffix - 1] === after[after.length - suffix - 1]) {
		origins[before.length - suffix - 1] = after.length - suffix - 1;
		suffix++;
	}
	const n = before.length - prefix - suffix, m = after.length - prefix - suffix;
	if (!n || !m || n * m > 25e4) return origins;
	const width = m + 1, lcs = new Uint32Array((n + 1) * width);
	for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) lcs[i * width + j] = before[prefix + i] === after[prefix + j] ? lcs[(i + 1) * width + j + 1] + 1 : Math.max(lcs[(i + 1) * width + j], lcs[i * width + j + 1]);
	let i = 0, j = 0;
	while (i < n && j < m) if (before[prefix + i] === after[prefix + j]) {
		origins[prefix + i] = prefix + j;
		i++;
		j++;
	} else if (lcs[(i + 1) * width + j] > lcs[i * width + j + 1]) i++;
	else j++;
	return origins;
}
function startsOf(blocks) {
	let offset = 0;
	return blocks.map((block) => {
		const start = offset;
		offset += Array.from(block.text).length + 1;
		return start;
	});
}
/** Build a mapping without modifying the supplied blocks or their fixed IDs. */
function buildTextTransform(before, after, replacement) {
	const beforeText = plain(before), afterText = plain(after), oldChars = Array.from(beforeText), newChars = Array.from(afterText), oldStarts = startsOf(before), newStarts = startsOf(after);
	const origins = characterOrigins(oldChars, newChars, replacement);
	const oldByText = /* @__PURE__ */ new Map(), newByText = /* @__PURE__ */ new Map();
	before.forEach((block, i) => oldByText.set(block.text, [...oldByText.get(block.text) ?? [], i]));
	after.forEach((block, i) => newByText.set(block.text, [...newByText.get(block.text) ?? [], i]));
	const exact = /* @__PURE__ */ new Map(), reserved = /* @__PURE__ */ new Set();
	before.forEach((block, oldIndex) => {
		if (!replacement && oldByText.get(block.text)?.length !== newByText.get(block.text)?.length) return;
		const newIndex = after.findIndex((candidate) => candidate.id === block.id && candidate.text === block.text);
		if (newIndex < 0) return;
		exact.set(oldIndex, newIndex);
		for (let j = 0; j < Array.from(block.text).length; j++) reserved.add(newStarts[newIndex] + j);
	});
	for (const [text, oldIndexes] of oldByText) {
		const newIndexes = newByText.get(text);
		if (!newIndexes || oldIndexes.length !== 1 || newIndexes.length !== 1) continue;
		oldIndexes.forEach((oldIndex, i) => {
			if (exact.has(oldIndex)) return;
			const newIndex = newIndexes[i];
			exact.set(oldIndex, newIndex);
			for (let j = 0; j < Array.from(text).length; j++) reserved.add(newStarts[newIndex] + j);
		});
	}
	before.forEach((block, i) => {
		const exactIndex = exact.get(i);
		for (let j = 0; j < Array.from(block.text).length; j++) {
			const index = oldStarts[i] + j;
			if (exactIndex !== void 0) origins[index] = newStarts[exactIndex] + j;
			else if (origins[index] !== void 0 && reserved.has(origins[index])) origins[index] = void 0;
			if (!replacement && !exact.has(i) && (oldByText.get(block.text)?.length ?? 0) > 1 && oldByText.get(block.text)?.length !== newByText.get(block.text)?.length) origins[index] = void 0;
		}
	});
	const positions = /* @__PURE__ */ new Map();
	after.forEach((block, i) => {
		for (let j = 0; j < Array.from(block.text).length; j++) positions.set(newStarts[i] + j, {
			block: i,
			offset: j
		});
	});
	const oldIndexes = new Map(before.map((block, i) => [block.id, i]));
	const wholeTextPreserved = oldChars.every((_, i) => origins[i] !== void 0 && origins[i] === origins[0] + i);
	const countOccurrences = (text, quote) => {
		let count = 0, offset = 0;
		while (quote && (offset = text.indexOf(quote, offset)) >= 0) {
			count++;
			offset++;
		}
		return count;
	};
	const ambiguousInsertion = (quote) => !replacement && quote && countOccurrences(afterText, quote) > 1 && countOccurrences(beforeText, quote) !== countOccurrences(afterText, quote);
	const owners = /* @__PURE__ */ new Map();
	before.forEach((block, i) => {
		if (exact.has(i)) {
			owners.set(i, exact.get(i));
			return;
		}
		const counts = /* @__PURE__ */ new Map();
		for (let j = 0; j < Array.from(block.text).length; j++) {
			const mapped = origins[oldStarts[i] + j], position = mapped === void 0 ? void 0 : positions.get(mapped);
			if (position) counts.set(position.block, (counts.get(position.block) ?? 0) + 1);
		}
		const first = [...counts].sort((a, b) => a[0] - b[0])[0];
		if (first) owners.set(i, first[0]);
		else if (after.some((b) => b.id === block.id)) owners.set(i, after.findIndex((b) => b.id === block.id));
	});
	const contiguous = (start, end) => {
		if (start < 0 || end < start || end > oldChars.length) return void 0;
		if (start === end) {
			if (origins[start] !== void 0) return {
				start: origins[start],
				end: origins[start]
			};
			if (start > 0 && origins[start - 1] !== void 0) return {
				start: origins[start - 1] + 1,
				end: origins[start - 1] + 1
			};
			return;
		}
		const first = origins[start];
		if (first === void 0) return void 0;
		for (let i = start + 1; i < end; i++) if (origins[i] !== first + i - start) return void 0;
		return {
			start: first,
			end: first + end - start
		};
	};
	return {
		blocks: after,
		block: (blockId) => {
			const i = oldIndexes.get(blockId), owner = i === void 0 ? void 0 : owners.get(i);
			return owner === void 0 ? void 0 : after[owner]?.id;
		},
		lineRange: (start, end) => {
			const quoted = oldChars.slice(start, end).join("");
			if (ambiguousInsertion(quoted)) return void 0;
			if (!replacement && quoted && beforeText !== afterText && afterText.indexOf(quoted, afterText.indexOf(quoted) + 1) >= 0 && beforeText.indexOf(quoted, beforeText.indexOf(quoted) + 1) < 0) return void 0;
			if (!replacement && !wholeTextPreserved && quoted && beforeText.indexOf(quoted, beforeText.indexOf(quoted) + 1) >= 0) return void 0;
			return contiguous(start, end);
		},
		range: (blockId, start, end) => {
			const i = oldIndexes.get(blockId);
			if (i === void 0 || end > Array.from(before[i].text).length) return void 0;
			const quoted = Array.from(before[i].text).slice(start, end).join("");
			if (!exact.has(i) && ambiguousInsertion(quoted)) return void 0;
			if (!replacement && !exact.has(i) && quoted && beforeText !== afterText && afterText.indexOf(quoted, afterText.indexOf(quoted) + 1) >= 0 && beforeText.indexOf(quoted, beforeText.indexOf(quoted) + 1) < 0) return void 0;
			if (!replacement && !wholeTextPreserved && !exact.has(i) && quoted && beforeText.indexOf(quoted, beforeText.indexOf(quoted) + 1) >= 0) return void 0;
			const result = contiguous(oldStarts[i] + start, oldStarts[i] + end);
			if (!result) return void 0;
			const first = positions.get(result.start) ?? (start === end ? positions.get(result.start - 1) : void 0);
			const last = positions.get(result.end - 1) ?? first;
			if (!first || !last || first.block !== last.block) return void 0;
			const offset = result.start - newStarts[first.block];
			return {
				blockId: after[first.block].id,
				start: offset,
				end: offset + end - start
			};
		}
	};
}
function transformAnchor(anchor, entityId, before, transform, currentVersionId) {
	if (anchor.entityId !== entityId || anchor.sourceVersionId && anchor.sourceVersionId !== currentVersionId || anchor.positionStatus === "unresolved") return anchor;
	const oldBlock = before.find((block) => block.id === anchor.blockId);
	if (!oldBlock && anchor.lineId !== entityId) return anchor;
	const hasRange = typeof anchor.start === "number" && typeof anchor.end === "number";
	if (hasRange) {
		const range = oldBlock ? transform.range(oldBlock.id, anchor.start, anchor.end) : transform.lineRange(anchor.start, anchor.end);
		if (range) {
			if (range.start === anchor.start && range.end === anchor.end && (!oldBlock || "blockId" in range && range.blockId === anchor.blockId)) return anchor;
			return {
				...anchor,
				...oldBlock ? range : {
					start: range.start,
					end: range.end
				}
			};
		}
	} else if (oldBlock) {
		const blockId = transform.block(oldBlock.id);
		if (blockId) return blockId === anchor.blockId ? anchor : {
			...anchor,
			blockId
		};
	} else return anchor;
	const result = {
		...anchor,
		positionStatus: "unresolved",
		positionReason: OVERLAP_REASON,
		quotedText: hasRange ? Array.from(oldBlock?.text ?? plain(before)).slice(anchor.start, anchor.end).join("") : oldBlock?.text ?? ""
	};
	delete result.start;
	delete result.end;
	if (oldBlock) {
		const blockId = transform.block(oldBlock.id);
		if (blockId) result.blockId = blockId;
		else delete result.blockId;
	}
	return result;
}
function isRichText(value) {
	return Array.isArray(value) && value.length > 0 && value.every((block) => block && typeof block === "object" && typeof block.id === "string" && typeof block.text === "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(block.kind));
}
/** Current references change in the same save command as their source text. Pinned versions stay fixed. */
function editedTextRemapper(beforeEntity, afterEntity) {
	const beforeData = beforeEntity.data, afterData = afterEntity.data;
	const edits = Object.entries(beforeData).flatMap(([key, before]) => {
		const after = afterData[key];
		if (!isRichText(before) || !Array.isArray(after) || JSON.stringify(before) === JSON.stringify(after)) return [];
		const chain = [];
		let cursor = after;
		for (let i = 0; i < 64; i++) {
			const edit = editOrigins.get(cursor);
			if (!edit) break;
			chain.unshift({
				before: edit.before,
				transform: edit.transform
			});
			if (JSON.stringify(edit.before) === JSON.stringify(before)) return chain;
			cursor = edit.before;
		}
		return [{
			before,
			transform: buildTextTransform(before, after)
		}];
	});
	if (!edits.length) return void 0;
	const walk = (value) => {
		if (Array.isArray(value)) {
			const changed = value.map(walk);
			return changed.some((child, i) => child !== value[i]) ? changed : value;
		}
		if (!value || typeof value !== "object") return value;
		const object = value;
		let result = value;
		if (typeof object.entityId === "string") for (const edit of edits) result = transformAnchor(result, beforeEntity.id, edit.before, edit.transform, beforeEntity.projectId);
		const next = result, changes = Object.entries(next).map(([key, child]) => [key, walk(child)]);
		return changes.some(([key, child]) => child !== next[key]) ? Object.fromEntries(changes) : result;
	};
	return walk;
}
function remapEditedTextReferences(entities, beforeEntity, afterEntity) {
	const walk = editedTextRemapper(beforeEntity, afterEntity);
	if (!walk) return entities;
	const textEdits = Object.entries(beforeEntity.data).flatMap(([key, before]) => {
		const after = afterEntity.data[key];
		return isRichText(before) && Array.isArray(after) && JSON.stringify(before) !== JSON.stringify(after) ? [{
			before,
			transform: buildTextTransform(before, after)
		}] : [];
	});
	return entities.map((entity) => {
		const historicalReview = entity.kind === "review" && entity.data.targetVersionId !== beforeEntity.projectId;
		const data = entity.data;
		const fields = historicalReview ? Object.entries(data).map(([key, value]) => [key, key === "target" ? value : walk(value)]) : void 0;
		let changed = fields ? fields.some(([key, value]) => value !== data[key]) ? Object.fromEntries(fields) : data : walk(data);
		if (entity.id === beforeEntity.id && entity.kind === "scene" && entity.data.blockIds?.length) {
			const blockIds = [...new Set(entity.data.blockIds.map((blockId) => {
				return walk({
					entityId: entity.id,
					blockId
				}).blockId ?? blockId;
			}))];
			if (blockIds.some((id, index) => id !== entity.data.blockIds[index]) || blockIds.length !== entity.data.blockIds.length) changed = {
				...changed,
				blockIds
			};
		}
		if (entity.kind === "projection_profile" && (!entity.data.sourceVersionId || entity.data.sourceVersionId === beforeEntity.projectId)) {
			const sources = { ...entity.data.blockSources };
			let affected = false;
			for (const [publicBlock, sourceBlock] of Object.entries(sources)) for (const edit of textEdits) if (edit.before.some((block) => block.id === sourceBlock)) {
				affected = true;
				const next = edit.transform.block(sourceBlock);
				if (next) sources[publicBlock] = next;
				else delete sources[publicBlock];
			}
			if (affected) return {
				...entity,
				status: "needs_review",
				data: {
					...changed,
					blockSources: sources
				}
			};
		}
		return changed === data ? entity : {
			...entity,
			data: changed
		};
	});
}
function remapEditedTextRelationReferences(relations, beforeEntity, afterEntity) {
	const walk = editedTextRemapper(beforeEntity, afterEntity);
	if (!walk) return relations;
	return relations.map((relation) => {
		const validity = walk(relation.validity);
		return validity === relation.validity ? relation : {
			...relation,
			validity
		};
	});
}

//#endregion
//#region src/domain/production.ts
init_model();
function stable$1(value) {
	if (value === null || typeof value !== "object") return JSON.stringify(value);
	if (Array.isArray(value)) return "[" + value.map(stable$1).join(",") + "]";
	return "{" + Object.entries(value).filter(([, v]) => v !== void 0).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([k, v]) => JSON.stringify(k) + ":" + stable$1(v)).join(",") + "}";
}
/** IDs/order/author notes do not change a line's content hash. Ruby/speaker/cues do. */
async function dialogueContentHash(project, line) {
	const cues = (line.data.cueIds ?? []).map((id) => project.entities.find((e) => e.id === id && e.kind === "cue" && !e.deletedAt));
	if (cues.some((cue) => !cue)) throw new Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
	const content = {
		text: line.data.text.map((block) => ({
			kind: block.kind,
			text: block.text,
			ruby: block.ruby ?? []
		})),
		speakerId: line.data.speakerId ?? null,
		cues: cues.map((cue) => cue.data)
	};
	const bytes = new TextEncoder().encode(stable$1(content));
	return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((v) => v.toString(16).padStart(2, "0")).join("");
}
/** Called on the candidate before commit: all changed deliverables join the same transaction. */
async function reconcileDeliverables(before, candidate) {
	const previous = new Map(before.entities.map((entity) => [entity.id, entity]));
	const current = new Map(candidate.entities.map((entity) => [entity.id, entity]));
	const changed = /* @__PURE__ */ new Set();
	const changedData = /* @__PURE__ */ new Set();
	for (const [id, entity] of current) {
		const old = previous.get(id);
		if (old === entity) continue;
		if (!old || Boolean(old.deletedAt) !== Boolean(entity.deletedAt) || stable$1(old.data) !== stable$1(entity.data)) changedData.add(id);
	}
	for (const id of previous.keys()) if (!current.has(id)) changedData.add(id);
	const content = (line, index) => stable$1({
		text: line.data.text.map((block) => ({
			kind: block.kind,
			text: block.text,
			ruby: block.ruby ?? []
		})),
		speakerId: line.data.speakerId ?? null,
		cues: (line.data.cueIds ?? []).map((id) => {
			const cue = index.get(id);
			if (!cue || cue.kind !== "cue" || cue.deletedAt) throw new Error("REFERENCE_INVALID: 台詞の演出参照が見つかりません。");
			return cue.data;
		})
	});
	for (const entity of candidate.entities) {
		if (entity.kind !== "dialogue_line" || entity.deletedAt) continue;
		const old = previous.get(entity.id);
		if (!old || old.kind !== "dialogue_line" || old.deletedAt || ["rejected", "alternate"].includes(old.status) !== ["rejected", "alternate"].includes(entity.status)) changed.add(entity.id);
		else if ((changedData.has(entity.id) || (entity.data.cueIds ?? []).some((id) => changedData.has(id))) && content(old, previous) !== content(entity, current)) changed.add(entity.id);
	}
	for (const old of before.entities) if (old.kind === "dialogue_line" && !old.deletedAt) {
		const line = current.get(old.id);
		if (!line || line.deletedAt || line.kind !== "dialogue_line") changed.add(old.id);
	}
	const staleApprovals = /* @__PURE__ */ new Set();
	for (const entity of candidate.entities) if (!entity.deletedAt && (entity.kind === "localization" || entity.kind === "recording") && ["reviewed", "recorded"].includes(entity.data.stage ?? "") && !changed.has(entity.data.sourceLineId) && changedData.has(entity.id)) {
		const line = current.get(entity.data.sourceLineId);
		if (!line || line.kind !== "dialogue_line" || line.deletedAt || ["rejected", "alternate"].includes(line.status) || entity.data.sourceHash !== await dialogueContentHash(candidate, line)) staleApprovals.add(entity.id);
	}
	if (!changedData.size && !changed.size && !staleApprovals.size) return candidate;
	const entities = candidate.entities.map((entity) => {
		if (entity.deletedAt) return entity;
		if ((entity.kind === "localization" || entity.kind === "recording") && (changed.has(entity.data.sourceLineId) || staleApprovals.has(entity.id)) && entity.data.stage !== "needs_review") return {
			...entity,
			data: {
				...entity.data,
				stage: "needs_review"
			}
		};
		if (entity.kind === "media_variant" && (entity.data.sourceIds ?? []).some((id) => changedData.has(id)) && !entity.data.needsReview) return {
			...entity,
			data: {
				...entity.data,
				needsReview: true
			}
		};
		return entity;
	});
	const liveReference = (entity, path) => {
		let value = entity;
		for (const part of path.split(/[.\[\]]+/).filter(Boolean)) if (value && typeof value === "object") {
			const object = value, version = object.sourceVersionId ?? object.targetSnapshotId ?? (entity.kind === "trace" || entity.kind === "checkpoint" ? object.contentVersionId : void 0);
			if (typeof version === "string" && version !== candidate.projectId) return false;
			value = object[part];
		} else return true;
		return true;
	};
	const reverse = /* @__PURE__ */ new Map();
	for (const entity of entities) if (!entity.deletedAt && !["rejected", "alternate"].includes(entity.status)) {
		for (const reference of collectReferences(entity)) if (!reference.path.startsWith("data.lineage") && !reference.path.startsWith("data.originLineIds") && liveReference(entity, reference.path)) {
			const uses = reverse.get(reference.id);
			if (uses) uses.push(entity.id);
			else reverse.set(reference.id, [entity.id]);
		}
	}
	const affected = new Set(changedData), queue = [...affected];
	for (let at = 0; at < queue.length; at++) for (const id of reverse.get(queue[at]) ?? []) if (!affected.has(id)) {
		affected.add(id);
		queue.push(id);
	}
	return {
		...candidate,
		entities: entities.map((entity) => {
			if (!affected.has(entity.id) || entity.deletedAt || ["rejected", "alternate"].includes(entity.status)) return entity;
			if (entity.kind === "storyboard_frame" && previous.has(entity.id)) return {
				...entity,
				status: "needs_review"
			};
			if (entity.kind === "media_variant" && previous.has(entity.id)) return {
				...entity,
				data: {
					...entity.data,
					needsReview: true
				}
			};
			if (entity.kind === "production_task" && previous.has(entity.id) && entity.data.progress === "done") return {
				...entity,
				data: {
					...entity.data,
					progress: "needs_review"
				}
			};
			return entity;
		})
	};
}

//#endregion
//#region src/sync/server.ts
init_model();
function fail$1(code) {
	throw new SyncProtocolError(code);
}
async function reconcileServerReferences(previous, candidate) {
	let next = candidate;
	for (const changed of candidate.entities) {
		const old = previous.entities.find((e) => e.id === changed.id);
		if (old && JSON.stringify(old.data) !== JSON.stringify(changed.data)) next = {
			...next,
			entities: remapEditedTextReferences(next.entities, old, changed),
			relations: remapEditedTextRelationReferences(next.relations, old, changed)
		};
	}
	return reconcileDeliverables(previous, next);
}
async function validateServerImage(project, worlds) {
	const contents = worldSnapshotContents(worlds);
	if (!validateProject(project, { worldSnapshots: contents }).ok) fail$1("PROTOCOL_INVALID");
	await verifySnapshotHashes([project, ...Object.values(worlds)]);
	verifyWorlds([project], worlds);
	if ((await validateProjectIntegrity(project, { worldSnapshots: contents }, false)).length) fail$1("PROTOCOL_INVALID");
}
async function bootstrapNativeProject(repository, identity, input) {
	const submitted = clone(input), actor = clone(identity);
	submitted.project.history = [];
	await validateServerImage(submitted.project, submitted.worlds);
	const documents = nativeDocuments(submitted.project, "1"), result = await repository.bootstrap(actor, {
		...submitted,
		documents
	});
	if (result.projectId !== submitted.project.projectId || result.serverRevision !== "1" || !sameValue(result.documents, documents)) fail$1("PROTOCOL_INVALID");
	return {
		...result,
		contentHash: await valueHash(documents)
	};
}
/** The same merge/typed/native/replay rules run before PostgreSQL's optimistic atomic commit. */
async function applyNativeOperation(repository, identity, input) {
	const operation = clone(input), actor = clone(identity);
	if (operation.scope.accountId !== actor.accountId) fail$1("FORBIDDEN");
	await assertOperation(operation);
	const state = await repository.read(actor, operation.scope.projectId, operation.baseRevision, operation.operationId), hash = await valueHash(operation);
	if (state.role !== "owner") fail$1("FORBIDDEN");
	if (state.previousAck) {
		if (state.previousAck.operationHash !== hash) throw new SyncProtocolError("OPERATION_REUSED");
		return clone(state.previousAck);
	}
	if (!state.baseDocuments) fail$1("BASE_UNAVAILABLE");
	const base = new Map(state.baseDocuments.map((doc) => [doc.id, doc])), current = new Map(state.documents.map((doc) => [doc.id, doc])), candidates = [], conflicts = [];
	for (const target of operation.targets) {
		const before = base.get(target.targetId) ?? null, server = current.get(target.targetId) ?? null;
		if (!sameValue(before, target.base) || before?.fields.kind !== void 0 && !sameValue(before.fields.kind, target.local.fields.kind) || before?.fields.createdAt !== void 0 && !sameValue(before.fields.createdAt, target.local.fields.createdAt)) fail$1("PROTOCOL_INVALID");
		const merged = threeWayMerge(before, target.local, server);
		if (merged.status === "conflict") conflicts.push(merged.conflict);
		else candidates.push(merged.document);
	}
	const common = {
		schemaVersion: 1,
		operationId: operation.operationId,
		scope: clone(operation.scope),
		operationHash: hash
	};
	let ack, image = clone(state.nativeImage), documents = clone(state.documents);
	if (conflicts.length) ack = {
		...common,
		status: "conflict",
		serverRevision: state.serverRevision,
		documents: operation.targets.map((target) => clone(current.get(target.targetId) ?? null)),
		confirmedDocuments: documents,
		conflicts
	};
	else {
		const revision = candidates.some((doc) => !sameDocumentContent(current.get(doc.id), doc)) ? (BigInt(state.serverRevision) + 1n).toString() : state.serverRevision;
		for (const candidate of candidates) {
			if (!sameDocumentContent(current.get(candidate.id), candidate)) candidate.revision = revision;
			current.set(candidate.id, clone(candidate));
		}
		documents = [...current.values()];
		image = nativeFromDocuments(image, documents, (/* @__PURE__ */ new Date()).toISOString());
		image.history = [];
		image = await reconcileServerReferences(state.nativeImage, image);
		documents = nativeDocuments(image, revision).map((d) => sameDocumentContent(state.documents.find((old) => old.id === d.id), d) ? state.documents.find((old) => old.id === d.id) : d);
		for (const d of documents) current.set(d.id, d);
		await validateServerImage(image, state.worlds);
		ack = {
			...common,
			status: "applied",
			serverRevision: revision,
			documents: operation.targets.map((target) => clone(current.get(target.targetId))),
			confirmedDocuments: documents,
			conflicts: []
		};
	}
	return repository.commit(actor, {
		projectId: operation.scope.projectId,
		expectedRevision: state.serverRevision,
		operation,
		operationHash: hash,
		ack,
		documents,
		image,
		derivedIds: documents.filter((d) => !sameDocumentContent(state.documents.find((old) => old.id === d.id), d) && !operation.targets.some((t) => t.targetId === d.id)).map((d) => d.id)
	});
}

//#endregion
//#region src/domain/changeReviews.ts
init_model();
const GENERATED_BY_KEY = "changeReview.generatedBy";
const GENERATED_KEY = "changeReview.key";
const GENERATED_SOURCE_IDS_KEY = "changeReview.sourceIds";
const GENERATED_SOURCE_REVISIONS_KEY = "changeReview.sourceRevisions";
const GENERATED_PROJECT_REVISION_KEY = "changeReview.projectRevision";
const GENERATED_PATHS_KEY = "changeReview.paths";
const GENERATED_BY = "semantic-change-review/v1";
const NON_CONTENT_KINDS = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]);
const NON_REVIEW_TARGET_KINDS = /* @__PURE__ */ new Set([
	"collection",
	"review",
	"snapshot",
	"checkpoint",
	"trace",
	"projection_profile",
	"production_task",
	"template"
]);
const NON_MEANINGFUL_RELATION_TYPES = /* @__PURE__ */ new Set(["reference"]);
function nextRevision(revision) {
	try {
		return (BigInt(revision) + 1n).toString();
	} catch {
		return revision;
	}
}
function stable(value) {
	if (value === null || typeof value !== "object") return JSON.stringify(value);
	if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
	return `{${Object.entries(value).filter(([, item]) => item !== void 0).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stable(item)}`).join(",")}}`;
}
function semanticState(entity, deleted) {
	if (NON_CONTENT_KINDS.has(entity.kind)) return void 0;
	if (entity.kind === "group" && entity.data.groupType === "category") return void 0;
	const data = { ...entity.data };
	if (entity.kind === "character" || entity.kind === "place" || entity.kind === "lore") {
		delete data.reading;
		delete data.aliases;
	}
	if (entity.kind === "localization" || entity.kind === "recording") {
		delete data.stage;
		delete data.reviewedBy;
	}
	if (entity.kind === "media_variant") delete data.needsReview;
	if (entity.kind === "attachment") {
		delete data.displayName;
		delete data.licenseNote;
		delete data.byteSize;
	}
	if (entity.kind === "source") delete data.accessedAt;
	return stable({
		deleted,
		data,
		customValues: entity.customValues
	});
}
function detectSourceChanges(before, candidate) {
	const nextById = new Map(candidate.entities.map((entity) => [entity.id, entity]));
	const result = [];
	for (const previous of before.entities) {
		const next = nextById.get(previous.id);
		if (previous.deletedAt && (!next || next.deletedAt)) continue;
		if (next === previous) continue;
		if (next && next.kind !== previous.kind) continue;
		const oldState = semanticState(previous, !!previous.deletedAt);
		const newState = next ? semanticState(next, !!next.deletedAt) : semanticState(previous, true);
		if (!oldState || !newState || oldState === newState) continue;
		result.push({
			source: next ?? previous,
			sourceRevision: nextRevision(previous.revision)
		});
	}
	return result;
}
function reviewableTarget(entity) {
	if (entity.deletedAt || NON_REVIEW_TARGET_KINDS.has(entity.kind)) return false;
	return !(entity.kind === "group" && entity.data.groupType === "category");
}
function pinnedReferencePaths(value, projectId, path = "data") {
	if (!value || typeof value !== "object") return [];
	if (Array.isArray(value)) return value.flatMap((item, index) => pinnedReferencePaths(item, projectId, `${path}[${index}]`));
	const record = value;
	if (typeof record.entityId === "string" && typeof record.sourceVersionId === "string" && record.sourceVersionId !== projectId) return [path];
	return Object.entries(record).flatMap(([key, item]) => pinnedReferencePaths(item, projectId, `${path}.${key}`));
}
function generatedKey(targetId, impacts) {
	return stable({
		targetId,
		sources: impacts.map((impact) => ({
			id: impact.source.id,
			revision: impact.sourceRevision,
			directPaths: [...new Set(impact.directPaths)].sort(),
			relationLabels: [...new Set(impact.relationLabels)].sort()
		})).sort((a, b) => a.id.localeCompare(b.id))
	});
}
function sourceText(impact) {
	const { source, sourceRevision, directPaths, relationLabels } = impact;
	const causes = [];
	if (directPaths.length) causes.push(`IDで直接参照しています（${[...new Set(directPaths)].sort().join("、")}）`);
	if (relationLabels.length) causes.push(`作者が設定した関係「${[...new Set(relationLabels)].sort().join("・")}」でつながっています`);
	return `変更元: ${KIND_LABELS[source.kind]}「${source.name || "無題"}」 (${source.id})。改訂 ${source.revision} → ${sourceRevision}。${causes.join("。")}`;
}
function existingGeneratedKeys(project) {
	return new Set(project.entities.flatMap((entity) => entity.kind === "review" && !entity.deletedAt && entity.customValues[GENERATED_BY_KEY] === GENERATED_BY && typeof entity.customValues[GENERATED_KEY] === "string" ? [entity.customValues[GENERATED_KEY]] : []));
}
/**
* Adds private, open review records for semantic changes that touch existing content.
* The records cite direct ID references separately from author-declared relation edges;
* they suggest a human check and never rewrite the affected content.
*/
function addChangeReviews(before, candidate) {
	if (before.projectId !== candidate.projectId) return candidate;
	const changes = detectSourceChanges(before, candidate);
	if (!changes.length) return candidate;
	const targets = candidate.entities.filter(reviewableTarget);
	const targetById = new Map(targets.map((entity) => [entity.id, entity]));
	const impactsByTarget = /* @__PURE__ */ new Map();
	const changesById = new Map(changes.map((change) => [change.source.id, change]));
	for (const target of targets) {
		const directPathsBySource = /* @__PURE__ */ new Map();
		const pinnedPaths = pinnedReferencePaths(target.data, candidate.projectId);
		for (const reference of collectReferences(target)) {
			if (pinnedPaths.some((path) => reference.path === path || reference.path.startsWith(path + "."))) continue;
			const change = changesById.get(reference.id);
			if (!change || target.id === change.source.id) continue;
			const paths = directPathsBySource.get(reference.id) ?? /* @__PURE__ */ new Set();
			paths.add(reference.path);
			directPathsBySource.set(reference.id, paths);
		}
		if (!directPathsBySource.size) continue;
		const bySource = impactsByTarget.get(target.id) ?? /* @__PURE__ */ new Map();
		for (const [sourceId, directPaths] of directPathsBySource) {
			const change = changesById.get(sourceId);
			bySource.set(sourceId, {
				...change,
				directPaths: [...directPaths],
				relationLabels: []
			});
		}
		impactsByTarget.set(target.id, bySource);
	}
	for (const relation of candidate.relations) {
		if (relation.deletedAt || relation.status === "rejected" || NON_MEANINGFUL_RELATION_TYPES.has(relation.relationType)) continue;
		for (const sourceId of new Set([relation.fromId, relation.toId].filter((id) => changesById.has(id)))) {
			const targetId = relation.fromId === sourceId ? relation.toId : relation.fromId;
			const target = targetById.get(targetId), change = changesById.get(sourceId);
			if (!target || !change || target.id === sourceId) continue;
			const bySource = impactsByTarget.get(target.id) ?? /* @__PURE__ */ new Map();
			const impact = bySource.get(sourceId) ?? {
				...change,
				directPaths: [],
				relationLabels: []
			};
			impact.relationLabels.push(RELATION_LABELS[relation.relationType] ?? relation.relationType);
			bySource.set(sourceId, impact);
			impactsByTarget.set(target.id, bySource);
		}
	}
	const knownKeys = existingGeneratedKeys(candidate);
	const nextProjectRevision = nextRevision(candidate.revision);
	const reviews = [];
	for (const [targetId, sources] of impactsByTarget) {
		const target = targetById.get(targetId);
		if (!target) continue;
		const impacts = [...sources.values()].sort((a, b) => a.source.id.localeCompare(b.source.id));
		const key = generatedKey(target.id, impacts);
		if (knownKeys.has(key)) continue;
		knownKeys.add(key);
		const details = impacts.map(sourceText);
		const body = [
			`「${target.name || KIND_LABELS[target.kind]}」に関係する情報が変更されました。内容への影響を確認してください。`,
			...details,
			`確認対象の作品改訂: ${candidate.revision} → ${nextProjectRevision}。候補は人による確認用です。本文や設定は自動変更していません。`
		].join("\n");
		const review = createEntity(candidate.projectId, "review", `変更確認: ${target.name || KIND_LABELS[target.kind]}`, {
			target: target.id,
			targetVersionId: candidate.projectId,
			body: textToRichText(body),
			stage: "open",
			quotedText: null,
			resolution: []
		});
		review.status = "needs_review";
		review.visibility = "private";
		review.customValues = {
			...review.customValues,
			[GENERATED_BY_KEY]: GENERATED_BY,
			[GENERATED_KEY]: key,
			[GENERATED_SOURCE_IDS_KEY]: JSON.stringify(impacts.map((impact) => impact.source.id)),
			[GENERATED_SOURCE_REVISIONS_KEY]: JSON.stringify(Object.fromEntries(impacts.map((impact) => [impact.source.id, impact.sourceRevision]))),
			[GENERATED_PROJECT_REVISION_KEY]: nextProjectRevision,
			[GENERATED_PATHS_KEY]: JSON.stringify(Object.fromEntries(impacts.map((impact) => [impact.source.id, {
				directPaths: [...new Set(impact.directPaths)].sort(),
				relationLabels: [...new Set(impact.relationLabels)].sort()
			}])))
		};
		reviews.push(review);
	}
	return reviews.length ? {
		...candidate,
		entities: [...candidate.entities, ...reviews]
	} : candidate;
}

//#endregion
//#region src/sync/editor.ts
const immutable = /* @__PURE__ */ new Set([
	"kind",
	"visibility",
	"createdAt"
]);
function fieldsFor(scopes, id) {
	const scope = scopes.find((s) => s.id === id);
	return scope ? /* @__PURE__ */ new Set([...scope.fields, ...immutable]) : null;
}
function scopedDocuments(state, documents = state.documents) {
	const allowed = new Set(state.scopes.map((s) => s.id));
	return documents.filter((doc) => allowed.has(doc.id) && doc.fields.visibility === "team" && doc.fields.kind !== "project").map((doc) => {
		const names = fieldsFor(state.scopes, doc.id);
		const fields = Object.fromEntries(Object.entries(doc.fields).filter(([key]) => names.has(key)));
		const localIds = new Set(allowed);
		const collect = (v) => {
			if (Array.isArray(v)) v.forEach(collect);
			else if (v && typeof v === "object") {
				const o = v;
				if (typeof o.id === "string") localIds.add(o.id);
				Object.values(o).forEach(collect);
			}
		};
		Object.values(fields).forEach(collect);
		const inspect = (value) => typeof value === "string" ? /^[0-9a-f]{8}-[0-9a-f-]{27}$/.test(value) ? localIds.has(value) : true : Array.isArray(value) ? value.every(inspect) : value && typeof value === "object" ? Object.values(value).every(inspect) : true;
		if (!Object.values(fields).every(inspect)) throw new SyncProtocolError("FORBIDDEN");
		return {
			...clone(doc),
			fields: clone(fields)
		};
	});
}
/** The engine image remains private. Every returned conflict and ack uses the same field grant. */
function editorAck(state, ack) {
	if (state.authorizationExpiresAt !== null && (typeof state.authorizationExpiresAt !== "string" || !Number.isFinite(Date.parse(state.authorizationExpiresAt)) || Date.parse(state.authorizationExpiresAt) <= Date.now())) throw new SyncProtocolError("FORBIDDEN");
	if (!/^(0|[1-9]\d*)$/.test(state.authorizationRevision ?? "")) throw new SyncProtocolError("PROTOCOL_INVALID");
	const trim = (doc) => {
		if (!doc) return null;
		const result = scopedDocuments(state, [doc])[0];
		if (!result) throw new SyncProtocolError("FORBIDDEN");
		return result;
	};
	const conflicts = ack.conflicts.map((row) => {
		const base = trim(row.base), local = trim(row.local), server = trim(row.server);
		if (!local) throw new SyncProtocolError("FORBIDDEN");
		const merged = threeWayMerge(base, local, server);
		if (merged.status !== "conflict") throw new SyncProtocolError("PROTOCOL_INVALID");
		return merged.conflict;
	});
	return {
		...clone(ack),
		authorizationRevision: state.authorizationRevision,
		authorizationExpiresAt: state.authorizationExpiresAt,
		documents: ack.documents.map(trim),
		confirmedDocuments: scopedDocuments(state, ack.confirmedDocuments ?? state.documents),
		conflicts
	};
}
async function readEditorImage(repository, identity, projectId) {
	const state = await repository.read(clone(identity), projectId, null, null);
	if (state.role !== "editor" || !Array.isArray(state.scopes)) throw new SyncProtocolError("FORBIDDEN");
	if (state.authorizationExpiresAt !== null && (typeof state.authorizationExpiresAt !== "string" || !Number.isFinite(Date.parse(state.authorizationExpiresAt)) || Date.parse(state.authorizationExpiresAt) <= Date.now())) throw new SyncProtocolError("FORBIDDEN");
	if (!/^(0|[1-9]\d*)$/.test(state.authorizationRevision ?? "")) throw new SyncProtocolError("PROTOCOL_INVALID");
	const documents = scopedDocuments(state);
	return {
		projectId,
		serverRevision: state.serverRevision,
		authorizationRevision: state.authorizationRevision,
		authorizationExpiresAt: state.authorizationExpiresAt,
		documents,
		contentHash: await valueHash(documents)
	};
}
async function applyEditorOperation(repository, identity, input) {
	const op = clone(input), actor = clone(identity);
	if (op.scope.accountId !== actor.accountId) throw new SyncProtocolError("FORBIDDEN");
	await assertOperation(op);
	const state = await repository.read(actor, op.scope.projectId, op.baseRevision, op.operationId), hash = await valueHash(op);
	if (state.role !== "editor" || !Array.isArray(state.scopes)) throw new SyncProtocolError("FORBIDDEN");
	for (const target of op.targets) {
		const currentFields = fieldsFor(state.scopes, target.targetId);
		if (!currentFields || Object.keys(target.local.fields).some((key) => !currentFields.has(key))) throw new SyncProtocolError("FORBIDDEN");
	}
	if (state.previousAck) {
		if (state.previousAck.operationHash !== hash) throw new SyncProtocolError("OPERATION_REUSED");
		return editorAck(state, state.previousAck);
	}
	if (!state.baseDocuments) throw new SyncProtocolError("BASE_UNAVAILABLE");
	const base = new Map(state.baseDocuments.map((d) => [d.id, d])), current = new Map(state.documents.map((d) => [d.id, d])), visibleBase = new Map(scopedDocuments(state, state.baseDocuments).map((d) => [d.id, d])), visibleCurrent = new Map(scopedDocuments(state).map((d) => [d.id, d])), candidates = [], conflicts = [], fullTargets = [];
	for (const target of op.targets) {
		const before = base.get(target.targetId), remote = current.get(target.targetId), names = fieldsFor(state.scopes, target.targetId);
		if (!before || !remote || !names || !sameValue(visibleBase.get(target.targetId) ?? null, target.base) || Object.keys(target.local.fields).some((k) => !names.has(k)) || [...immutable].some((k) => !sameValue(fieldSlot(before, k), fieldSlot(target.local, k)))) throw new SyncProtocolError("FORBIDDEN");
		const merged = threeWayMerge(target.base, target.local, visibleCurrent.get(target.targetId) ?? null);
		if (merged.status === "conflict") conflicts.push(merged.conflict);
		else {
			const full = clone(remote);
			for (const key of names) {
				if (immutable.has(key)) continue;
				if (Object.hasOwn(merged.document.fields, key)) full.fields[key] = clone(merged.document.fields[key]);
				else delete full.fields[key];
			}
			full.tombstone = clone(merged.document.tombstone);
			candidates.push(full);
		}
		const expanded = clone(before);
		for (const key of names) {
			if (immutable.has(key)) continue;
			if (Object.hasOwn(target.local.fields, key)) expanded.fields[key] = clone(target.local.fields[key]);
			else delete expanded.fields[key];
		}
		expanded.tombstone = clone(target.local.tombstone);
		fullTargets.push({
			base: before,
			local: expanded
		});
	}
	const expanded = await createSyncOperation({
		...op,
		targets: fullTargets
	}), common = {
		schemaVersion: 1,
		operationId: op.operationId,
		scope: clone(op.scope),
		operationHash: hash,
		authorizationRevision: state.authorizationRevision,
		authorizationExpiresAt: state.authorizationExpiresAt
	};
	let ack, image = clone(state.nativeImage), documents = clone(state.documents);
	if (conflicts.length) {
		const rows = expanded.targets.map((t) => threeWayMerge(t.base, t.local, current.get(t.targetId) ?? null)).filter((r) => r.status === "conflict").map((r) => r.conflict);
		ack = {
			...common,
			status: "conflict",
			serverRevision: state.serverRevision,
			documents: expanded.targets.map((t) => clone(current.get(t.targetId))),
			confirmedDocuments: documents,
			conflicts: rows
		};
	} else {
		const revision = candidates.some((d) => !sameDocumentContent(current.get(d.id), d)) ? (BigInt(state.serverRevision) + 1n).toString() : state.serverRevision;
		for (const d of candidates) {
			if (!sameDocumentContent(current.get(d.id), d)) d.revision = revision;
			current.set(d.id, d);
		}
		documents = [...current.values()];
		image = nativeFromDocuments(image, documents, (/* @__PURE__ */ new Date()).toISOString());
		image.history = [];
		image = addChangeReviews(state.nativeImage, await reconcileServerReferences(state.nativeImage, image));
		documents = nativeDocuments(image, revision).map((d) => sameDocumentContent(state.documents.find((old) => old.id === d.id), d) ? state.documents.find((old) => old.id === d.id) : d);
		for (const d of documents) current.set(d.id, d);
		await validateServerImage(image, state.worlds);
		ack = {
			...common,
			status: "applied",
			serverRevision: revision,
			documents: op.targets.map((t) => clone(current.get(t.targetId))),
			confirmedDocuments: documents,
			conflicts: []
		};
	}
	const committed = await repository.commit(actor, {
		projectId: op.scope.projectId,
		expectedRevision: state.serverRevision,
		operation: expanded,
		operationHash: hash,
		ack,
		documents,
		image,
		derivedIds: documents.filter((d) => !sameDocumentContent(state.documents.find((old) => old.id === d.id), d) && !op.targets.some((t) => t.targetId === d.id)).map((d) => d.id)
	});
	const latestState = await repository.read(actor, op.scope.projectId, null, null);
	if (latestState.role !== "editor") throw new SyncProtocolError("FORBIDDEN");
	for (const target of op.targets) {
		const fields = fieldsFor(latestState.scopes, target.targetId);
		if (!fields || Object.keys(target.local.fields).some((key) => !fields.has(key))) throw new SyncProtocolError("FORBIDDEN");
	}
	return editorAck(latestState, committed);
}

//#endregion
//#region src/sync/edgeEntry.ts
init_model();
init_exportPreparation();
init_json();
const fail = (code) => {
	throw new SyncProtocolError(code);
};
function object(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) fail("PROTOCOL_INVALID");
	return value;
}
function uuid(value) {
	if (typeof value !== "string" || !ID_PATTERN.test(value)) fail("PROTOCOL_INVALID");
	return value;
}
function jwtClaims(token) {
	try {
		return object(JSON.parse(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))));
	} catch {
		return fail("AUTH_REQUIRED");
	}
}
/** The verified Auth identity is still checked against live sessions/membership inside every RPC. */
function createSyncEdgeHandler(env, fetcher = fetch) {
	const captured = clone(env), url = new URL(captured.url);
	if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) throw Error("DEDICATED_ENDPOINT_REQUIRED");
	const serviceHeaders = {
		apikey: captured.serviceRoleKey,
		Authorization: `Bearer ${captured.serviceRoleKey}`,
		"Content-Type": "application/json"
	};
	const rpc = async (name, args) => {
		const response = await fetcher(`${url.origin}/rest/v1/rpc/${name}`, {
			method: "POST",
			headers: serviceHeaders,
			body: JSON.stringify(args)
		});
		if (!response.ok) {
			const raw = await response.json().catch(() => ({})), message = String(raw.message ?? "");
			if (message.includes("AUTH_REQUIRED")) fail("AUTH_REQUIRED");
			if (response.status === 403 || message.includes("FORBIDDEN")) fail("FORBIDDEN");
			if (message.includes("REVISION_CHANGED")) fail("REVISION_CHANGED");
			fail("PROTOCOL_INVALID");
		}
		return response.status === 204 ? null : response.json();
	};
	const repository = {
		read: async (i, project, base, operation) => await rpc("scenario_sync_engine_context", {
			p_actor: i.accountId,
			p_session: i.sessionId,
			p_project: project,
			p_base: base,
			p_operation: operation
		}),
		bootstrap: async (i, input) => await rpc("scenario_sync_bootstrap", {
			actor: i.accountId,
			session: i.sessionId,
			project: input.project.projectId,
			image: input.project,
			documents: input.documents,
			worlds: input.worlds
		}),
		commit: async (i, input) => await rpc("scenario_sync_commit_prepared", {
			actor: i.accountId,
			session: i.sessionId,
			project: input.projectId,
			expected_revision: input.expectedRevision,
			operation: input.operation,
			operation_hash: input.operationHash,
			ack: input.ack,
			documents: input.documents,
			image: input.image,
			derived_ids: input.derivedIds ?? []
		})
	};
	const identity = async (request) => {
		const bearer = request.headers.get("Authorization");
		if (!bearer?.startsWith("Bearer ")) fail("AUTH_REQUIRED");
		const token = bearer.slice(7), response = await fetcher(`${url.origin}/auth/v1/user`, { headers: {
			apikey: captured.publishableKey,
			Authorization: `Bearer ${token}`
		} });
		if (!response.ok) fail("AUTH_REQUIRED");
		const user = object(await response.json()), claims = jwtClaims(token);
		if (user.id !== claims.sub || typeof claims.exp !== "number" || claims.exp * 1e3 <= Date.now()) fail("AUTH_REQUIRED");
		return {
			accountId: uuid(user.id),
			sessionId: uuid(claims.session_id)
		};
	};
	const apiArgs = (i, projectId) => ({
		p_actor: i.accountId,
		p_session: i.sessionId,
		p_project: projectId
	});
	async function owner(i, id, expected) {
		const state = await repository.read(i, id, null, null);
		if (state.role !== "owner") fail("FORBIDDEN");
		if (expected !== void 0 && state.serverRevision !== expected) fail("REVISION_CHANGED");
		return state;
	}
	return async (request) => {
		const origin = request.headers.get("Origin"), cors = origin && captured.allowedOrigins.includes(origin) ? {
			"Access-Control-Allow-Origin": origin,
			Vary: "Origin"
		} : {};
		const json = (data, status = 200) => new Response(JSON.stringify(data), {
			status,
			headers: {
				...cors,
				"Content-Type": "application/json",
				"Cache-Control": "no-store"
			}
		});
		try {
			if (origin && !captured.allowedOrigins.includes(origin)) fail("FORBIDDEN");
			if (request.method === "OPTIONS") return new Response(null, {
				status: 204,
				headers: {
					...cors,
					"Access-Control-Allow-Methods": "POST, OPTIONS",
					"Access-Control-Allow-Headers": "authorization, apikey, content-type"
				}
			});
			if (request.method !== "POST") fail("PROTOCOL_INVALID");
			const actor = await identity(request);
			if (Number(request.headers.get("Content-Length")) > 134217728) fail("PROTOCOL_INVALID");
			const text = await request.text();
			if (new TextEncoder().encode(text).byteLength > 134217728) fail("PROTOCOL_INVALID");
			const envelope = object(JSON.parse(text));
			if (envelope.specification !== "scenario-sync-native/1.0.0") fail("PROTOCOL_INVALID");
			const input = object(envelope.input), action = envelope.action;
			let result;
			if (action === "bootstrap") result = await bootstrapNativeProject(repository, actor, input);
			else if (action === "apply") {
				const op = input;
				result = (await repository.read(actor, uuid(op.scope?.projectId), null, null)).role === "owner" ? await applyNativeOperation(repository, actor, op) : await applyEditorOperation(repository, actor, op);
			} else if (action === "pull") {
				const state = await owner(actor, uuid(input.projectId));
				result = {
					project: state.nativeImage,
					worlds: state.worlds,
					serverRevision: state.serverRevision,
					documents: state.documents,
					contentHash: await valueHash(state.documents)
				};
			} else if (action === "team_read") result = await readEditorImage(repository, actor, uuid(input.projectId));
			else if (action === "projects") result = await rpc("scenario_owned_projects", {
				p_actor: actor.accountId,
				p_session: actor.sessionId
			});
			else if (action === "shared_snapshot") result = await rpc("scenario_shared_snapshot", {
				p_actor: actor.accountId,
				p_session: actor.sessionId,
				p_snapshot: uuid(input.snapshotId)
			});
			else if (action === "review_source") result = await rpc("scenario_review_source", {
				...apiArgs(actor, uuid(input.projectId)),
				p_snapshot: uuid(input.snapshotId)
			});
			else if (action === "shares") result = await rpc("scenario_project_shares", apiArgs(actor, uuid(input.projectId)));
			else if (action === "members") result = await rpc("scenario_project_members", apiArgs(actor, uuid(input.projectId)));
			else if (action === "membership") {
				const project = uuid(input.projectId);
				await rpc("scenario_membership", {
					actor: actor.accountId,
					session: actor.sessionId,
					project,
					account: uuid(input.accountId),
					new_role: input.role,
					expires_at: input.expiresAt ?? null,
					revoked: input.revoked === true,
					snapshots: input.snapshotIds ?? [],
					expected_membership: input.membershipRevision
				});
				result = { saved: true };
			} else if (action === "editor_grants") {
				const project = uuid(input.projectId), state = await owner(actor, project, input.serverRevision), scopes = clone(input.scopes);
				scopedDocuments({
					documents: state.documents,
					scopes
				});
				await rpc("scenario_editor_grants", {
					...apiArgs(actor, project),
					p_account: uuid(input.accountId),
					p_scopes: scopes,
					p_expected: state.serverRevision,
					p_membership: input.membershipRevision
				});
				result = { saved: true };
			} else if (action === "publish") {
				const project = uuid(input.projectId), state = await owner(actor, project, input.serverRevision), sourceVersionId = uuid(input.sourceVersionId), pin = state.nativeImage.snapshots.find((s) => s.id === sourceVersionId);
				if (!pin) fail("PROTOCOL_INVALID");
				const prepared = await preparePublicExecution(state.nativeImage, {
					profile: "reader",
					projectionProfileId: uuid(input.profileId),
					targetVersionId: sourceVersionId,
					worldSnapshots: worldSnapshotContents(state.worlds),
					worldPins: Object.values(state.worlds).flatMap((w) => w.snapshots)
				}), hash = await sha256(jsonBytes(prepared.projection)), assets = [{
					id: "public-project",
					projection: prepared.projection
				}, ...prepared.projection.versions ?? []].flatMap((v) => v.projection.entities.filter((e) => e.kind === "attachment").map((e) => ({
					publicId: v.id === "public-project" ? e.id : v.id + ":" + e.id,
					hash: e.data.contentHash
				})));
				if (input.projectionHash !== hash) fail("REVISION_CHANGED");
				result = await rpc("scenario_publish_with_review_sources", {
					...apiArgs(actor, project),
					p_expected: state.serverRevision,
					p_snapshot: crypto.randomUUID(),
					p_public_project: "public-project",
					p_source: sourceVersionId,
					p_source_hash: pin.contentHash,
					p_projection: prepared.projection,
					p_hash: hash,
					p_expires: input.expiresAt ?? null,
					p_assets: assets,
					p_review_sources: await publicationReviewSources(state.nativeImage, prepared, sourceVersionId, worldSnapshotContents(state.worlds))
				});
			} else if (action === "withdraw") {
				await rpc("scenario_withdraw", {
					...apiArgs(actor, uuid(input.projectId)),
					p_snapshot: uuid(input.snapshotId)
				});
				result = { withdrawn: true };
			} else if (action === "upload_asset") {
				const project = uuid(input.projectId), state = await owner(actor, project), hash = String(input.contentHash), meta = [state.nativeImage, ...Object.values(state.worlds)].flatMap(attachmentMetadata).find((m) => m.contentHash === hash);
				if (!meta || typeof input.base64 !== "string") fail("PROTOCOL_INVALID");
				if (input.base64.length > Math.ceil(33554432 / 3) * 4) fail("PROTOCOL_INVALID");
				const bytes = Uint8Array.from(atob(input.base64), (ch) => ch.charCodeAt(0));
				if (bytes.byteLength !== meta.byteSize || await sha256(bytes) !== hash) fail("PROTOCOL_INVALID");
				validateAsset(assetPath(hash, meta.mediaType), meta.mediaType, bytes);
				const path = `${project}/${hash}`, storageURL = `${url.origin}/storage/v1/object/scenario-private/${path}`;
				if (!(await fetcher(storageURL, {
					method: "POST",
					headers: {
						...serviceHeaders,
						"Content-Type": meta.mediaType,
						"x-upsert": "false"
					},
					body: bytes
				})).ok) {
					const prior = await fetcher(storageURL, { headers: serviceHeaders });
					if (!prior.ok || await sha256(new Uint8Array(await prior.arrayBuffer())) !== hash) fail("TRANSPORT_UNAVAILABLE");
				}
				await owner(actor, project);
				const item = state.nativeImage.entities.find((e) => e.kind === "attachment" && e.data.contentHash === hash);
				await rpc("scenario_asset_complete", {
					...apiArgs(actor, project),
					p_hash: hash,
					p_size: bytes.byteLength,
					p_type: meta.mediaType,
					p_path: path,
					p_visibility: item?.visibility ?? "private"
				});
				result = {
					contentHash: hash,
					bytes: bytes.byteLength
				};
			} else if (action === "upload_archive") {
				const project = uuid(input.projectId), state = await owner(actor, project, input.serverRevision);
				if (typeof input.base64 !== "string" || input.base64.length > Math.ceil(67108864 / 3) * 4) fail("PROTOCOL_INVALID");
				const bytes = Uint8Array.from(atob(input.base64), (ch) => ch.charCodeAt(0));
				await inspectConfirmedArchive(bytes, project, state.documents);
				const hash = await sha256(bytes);
				if (hash !== input.contentHash) fail("PROTOCOL_INVALID");
				const path = `${project}/${state.serverRevision}/${hash}`, storageURL = `${url.origin}/storage/v1/object/scenario-backups/${path}`;
				if (!(await fetcher(storageURL, {
					method: "POST",
					headers: {
						...serviceHeaders,
						"Content-Type": "application/octet-stream",
						"x-upsert": "false"
					},
					body: bytes
				})).ok) {
					const old = await fetcher(storageURL, { headers: serviceHeaders });
					if (!old.ok || await sha256(new Uint8Array(await old.arrayBuffer())) !== hash) fail("TRANSPORT_UNAVAILABLE");
				}
				await owner(actor, project, state.serverRevision);
				await rpc("scenario_archive_complete", {
					...apiArgs(actor, project),
					p_revision: state.serverRevision,
					p_hash: hash,
					p_size: bytes.byteLength,
					p_path: path
				});
				result = {
					contentHash: hash,
					bytes: bytes.byteLength,
					serverRevision: state.serverRevision
				};
			} else if (action === "download_archive") {
				const args = {
					...apiArgs(actor, uuid(input.projectId)),
					p_revision: input.serverRevision ?? null
				}, access = object(await rpc("scenario_archive_access", args)), response = await fetcher(`${url.origin}/storage/v1/object/scenario-backups/${access.path}`, { headers: serviceHeaders });
				if (!response.ok) fail("TRANSPORT_UNAVAILABLE");
				if (Number(response.headers.get("Content-Length")) > 67108864) fail("PROTOCOL_INVALID");
				const bytes = new Uint8Array(await response.arrayBuffer());
				if (bytes.byteLength > 67108864 || bytes.byteLength !== access.byteSize || await sha256(bytes) !== access.contentHash) fail("PROTOCOL_INVALID");
				await rpc("scenario_archive_access", args);
				return new Response(bytes, { headers: {
					...cors,
					"Content-Type": "application/octet-stream",
					"Cache-Control": "no-store",
					"X-Content-Type-Options": "nosniff"
				} });
			} else if (action === "download_asset") {
				const publicRequest = input.snapshotId !== void 0, name = publicRequest ? "scenario_public_asset_access" : "scenario_asset_access", args = publicRequest ? {
					p_actor: actor.accountId,
					p_session: actor.sessionId,
					p_snapshot: uuid(input.snapshotId),
					p_public_id: String(input.publicAssetId)
				} : {
					...apiArgs(actor, uuid(input.projectId)),
					p_hash: String(input.contentHash),
					p_snapshot: null,
					p_public_id: null
				}, access = object(await rpc(name, args));
				const response = await fetcher(`${url.origin}/storage/v1/object/scenario-private/${access.path}`, { headers: serviceHeaders });
				if (!response.ok) fail("TRANSPORT_UNAVAILABLE");
				const bytes = new Uint8Array(await response.arrayBuffer());
				if (bytes.byteLength !== access.byteSize || await sha256(bytes) !== access.contentHash) fail("PROTOCOL_INVALID");
				await rpc(name, args);
				return new Response(bytes, { headers: {
					...cors,
					"Content-Type": String(access.mediaType),
					"Cache-Control": "no-store",
					"X-Content-Type-Options": "nosniff"
				} });
			} else fail("PROTOCOL_INVALID");
			return json(result);
		} catch (cause) {
			const code = cause instanceof SyncProtocolError ? cause.code : "PROTOCOL_INVALID";
			return json({ code }, code === "AUTH_REQUIRED" ? 401 : code === "FORBIDDEN" ? 403 : code === "REVISION_CHANGED" ? 409 : 400);
		}
	};
}

//#endregion
export { createSyncEdgeHandler };