import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {release,cpus} from 'node:os';
const root=dirname(fileURLToPath(import.meta.url)),run=process.env.REVIEW_RUN,mode=process.argv[2],sha=b=>createHash('sha256').update(b).digest('hex');
if(process.env.REVIEW_EXECUTION_WINDOW!=='open'||!run||!/^[a-z0-9-]+$/.test(run)||!['type','browser'].includes(mode))throw Error('Explicit own review window/run/mode required.');
const binding=JSON.parse(await readFile(resolve(root,'candidate-binding.json'),'utf8'));
const inputFiles=[...binding.sourceFiles,...binding.originalDocuments??[],...binding.distFiles,...binding.generatedInputs??[]];
async function verify(){for(const entry of inputFiles)if(sha(await readFile(resolve(root,'candidate',entry.file)))!==entry.sha256)throw Error('Candidate changed '+entry.file);}
await verify();await mkdir(resolve(root,'results'),{recursive:true});const out=resolve(root,'results',run);await mkdir(out,{recursive:false});await mkdir(resolve(out,'input-source'));
const files=['run.mjs','server.mjs','tsconfig.json','playwright.config.ts','ORIGINAL_CONTRACTS.json','candidate-binding.json',...(await readdir(resolve(root,'harness'))).map(n=>'harness/'+n)];
const harness=[];for(const file of files){const bytes=await readFile(resolve(root,file)),path=resolve(out,'input-source',file);await mkdir(dirname(path),{recursive:true});await writeFile(path,bytes);harness.push({file,bytes:bytes.length,sha256:sha(bytes)});}
if(mode==='browser'){
 const success=JSON.parse(await readFile(resolve(root,process.env.REVIEW_TYPE_BINDING??'type-success.json'),'utf8'));
 if(success.commit!==binding.commit||success.tree!==binding.tree||success.exitCode!==0)throw Error('Current candidate compiler binding missing.');
 for(const file of success.harnessFiles)if(sha(await readFile(resolve(root,file.file)))!==file.sha256)throw Error('Harness changed after compile '+file.file);
}
const command=mode==='type'?[resolve(root,'node_modules/.bin/tsc'),'--project',resolve(root,'tsconfig.json'),'--noEmit']:[resolve(root,'node_modules/.bin/playwright'),'test','--config',resolve(root,'playwright.config.ts')];
const startedAt=new Date().toISOString(),browser=process.env.CHROMIUM_PATH;
const input={commit:binding.commit,tree:binding.tree,buildVersion:binding.buildInfo?.version??'2503d3e7976b1e7d1643',candidateBindingSHA256:sha(await readFile(resolve(root,'candidate-binding.json'))),mode,startedAt,command,harnessFiles:harness,environment:{node:process.version,platform:process.platform,os:release(),cpu:cpus()[0]?.model,browserPath:mode==='browser'?browser:null,browserBinarySHA256:mode==='browser'?sha(await readFile(browser)):null,physical:'not_run',actualAuth:'not_run'},originalAcceptanceCase:'AT-F58',candidateInputFileCount:inputFiles.length,oldCandidatePassesInferred:0};
await writeFile(resolve(out,'INPUTS.json'),JSON.stringify(input,null,2)+'\n');
const rawStream=createWriteStream(resolve(out,'raw.in-progress.log')),child=spawn(command[0],command.slice(1),{cwd:root,env:process.env,stdio:'pipe'});let raw='';
for(const channel of[child.stdout,child.stderr])channel.on('data',b=>{raw+=b.toString();rawStream.write(b);process.stdout.write(b);});
const exitCode=await new Promise((done,reject)=>{child.on('error',reject);child.on('close',done);});await new Promise(done=>rawStream.end(done));
await writeFile(resolve(out,'raw.log'),raw);await verify();for(const file of harness)if(sha(await readFile(resolve(root,file.file)))!==file.sha256)throw Error('Harness changed during execution '+file.file);
const result={...input,finishedAt:new Date().toISOString(),exitCode:Number(exitCode??1),rawSHA256:sha(raw),sealedCandidateUnchanged:true,acceptancePassesInferred:0,proofLayer:mode==='type'?'TypeScript/import only':'Production Chromium ordinary UI; explicit original graph expectation; not physical or actual Auth'};
await writeFile(resolve(out,'EXECUTION_BINDING.json'),JSON.stringify(result,null,2)+'\n');
if(mode==='type'&&exitCode===0)await writeFile(resolve(root,'type-success.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
process.exitCode=Number(exitCode??1);
