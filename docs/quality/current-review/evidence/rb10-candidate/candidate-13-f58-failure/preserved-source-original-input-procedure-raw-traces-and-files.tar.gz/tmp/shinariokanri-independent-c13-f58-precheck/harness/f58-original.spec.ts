import {test,expect,type Page} from '@playwright/test';
import {createEntity,createProject,textToRichText,validateProject} from '../candidate/src/domain/model';
import {evaluateCollection} from '../candidate/src/domain/catalog';
import type {ProjectData,Entity,EntityKind} from '../candidate/src/domain/types';
import {seed,nav,backup,durable,evidence,digest,injectQuota} from './common';
import {editData,saveEditor,freshRoundtrip} from './extended-support';

async function catalog(page:Page){await nav(page,/^検索/);await expect(page.locator('.search-page')).toBeVisible();}
async function closeDetail(page:Page){const close=page.locator('.detail-panel').getByRole('button',{name:'詳細を閉じる',exact:true});if(await close.isVisible())await close.click();}
async function add(page:Page,kind:EntityKind,name:string){
 await nav(page,/^資料/);await page.getByLabel('情報の種類',{exact:true}).selectOption(kind);
 await page.locator('.workspace-heading').getByRole('button',{name:/を追加$/}).click();
 const modal=page.getByRole('dialog',{name:'情報を追加',exact:true});await modal.getByLabel('名前',{exact:true}).fill(name);await modal.getByRole('button',{name:'編集を始める',exact:true}).click();
 await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
}
async function list(page:Page,name:string,count:number){
 await catalog(page);await page.getByLabel('保存した一覧を再表示',{exact:true}).selectOption({label:name});
 await expect(page.locator('.search-page .list-heading')).toContainText(count+'件');
}
function fixture(){
 const p=createProject('原 F58 人物Aの未実装一覧と固定ID'),a=createEntity(p.projectId,'character','人物A'),b=createEntity(p.projectId,'character','人物B');
 const ea=createEntity(p.projectId,'event','人物Aが出る出来事',{summary:textToRichText('人物Aが参加する。'),participants:[{characterId:a.id,role:'actor'}]}),eb=createEntity(p.projectId,'event','人物Bが出る出来事',{summary:textToRichText('人物Bが参加する。'),participants:[{characterId:b.id,role:'actor'}]});
 const first=createEntity(p.projectId,'scene','Aの未実装場面',{eventIds:[ea.id],body:textToRichText('人物Aの未実装の本文😀。')}),done=createEntity(p.projectId,'scene','Aの実装済み場面',{eventIds:[ea.id],body:textToRichText('この実装済み場面は結果に含めない。')}),other=createEntity(p.projectId,'scene','Bの未実装場面',{eventIds:[eb.id],body:textToRichText('人物Bのみ。')});
 const tasks=[createEntity(p.projectId,'production_task','A未実装',{targetIds:[first.id],stage:'implementation',progress:'todo'}),createEntity(p.projectId,'production_task','A実装済み',{targetIds:[done.id],stage:'implementation',progress:'done'}),createEntity(p.projectId,'production_task','B未実装',{targetIds:[other.id],stage:'implementation',progress:'todo'})];
 p.entities=[a,b,ea,eb,first,done,other,...tasks];expect(validateProject(p).ok).toBe(true);return {p,a,ea,first,done,other};
}
function collections(p:ProjectData){return p.entities.filter((e):e is Entity<'collection'>=>e.kind==='collection'&&!e.deletedAt);}
function assertCollections(p:ProjectData,firstName:string,newName:string){
 const dynamic=collections(p).find(e=>e.name==='人物Aかつ未実装・動的')!,fixed=collections(p).find(e=>e.name==='人物Aかつ未実装・固定')!;
 expect(dynamic.data.mode).toBe('dynamic');expect(dynamic.data.memberIds??[]).toEqual([]);expect(dynamic.data.query).toMatchObject({op:'all',children:expect.arrayContaining([{op:'kind',value:'scene'},{op:'participant',characterId:p.entities.find(e=>e.kind==='character'&&e.name==='人物A')!.id},{op:'production',value:'todo'}])});
 expect(fixed.data.mode).toBe('fixed');expect(fixed.data.query).toBeNull();
 expect(evaluateCollection(p,dynamic).entities.map(e=>e.name).sort()).toEqual([firstName,newName].sort());
 expect(evaluateCollection(p,fixed).entities.map(e=>e.name)).toEqual([firstName]);return {dynamic,fixed};
}

test('原 AT-F58 動的・固定一覧の同じ結果をカード・表・図で使い原子一括を取り消す',async({page,browser},info)=>{
 const f=fixture();const input=await seed(page,f.p);await closeDetail(page);await catalog(page);
 await page.locator('.search-page .kind-select').selectOption('scene');await page.getByLabel('参加人物で絞り込む',{exact:true}).selectOption(f.a.id);await page.getByLabel('制作進捗で絞り込む',{exact:true}).selectOption('todo');
 await expect(page.locator('.search-page .list-heading')).toContainText('1件');await expect(page.locator('.search-page .entity-card')).toContainText(f.first.name);
 await page.getByLabel('一覧の名前',{exact:true}).fill('人物Aかつ未実装・動的');await page.getByLabel('保存する内容',{exact:true}).selectOption('dynamic');await page.getByRole('button',{name:'一覧を保存',exact:true}).click();await expect(page.locator('.search-page [role=status]').first()).toContainText('一覧を保存しました');
 await page.getByLabel('一覧の名前',{exact:true}).fill('人物Aかつ未実装・固定');await page.getByLabel('保存する内容',{exact:true}).selectOption('fixed');await page.getByRole('button',{name:'一覧を保存',exact:true}).click();await expect(page.locator('.search-page [role=status]').first()).toContainText('一覧を保存しました');
 const initial=await backup(page);expect(collections(initial.parsed.project)).toHaveLength(2);
 await add(page,'scene','新しいAの未実装場面');await editData(page,data=>{data.eventIds=[f.ea.id];data.body=textToRichText('追加しても動的一覧だけが追従する😀。');});await saveEditor(page);await closeDetail(page);
 const afterScene=await backup(page),added=afterScene.parsed.project.entities.find(e=>e.kind==='scene'&&e.name==='新しいAの未実装場面')!;expect(added).toBeTruthy();
 await add(page,'production_task','新しいAの実装タスク');await editData(page,data=>{data.targetIds=[added.id];data.stage='implementation';data.progress='todo';});await saveEditor(page);await closeDetail(page);
 const afterAdd=await backup(page);const c=assertCollections(afterAdd.parsed.project,f.first.name,added.name);
 await list(page,c.fixed.name,1);await expect(page.locator('.search-page .entity-card')).toHaveCount(1);
 await list(page,c.dynamic.name,2);await expect(page.locator('.search-page .entity-card')).toHaveCount(2);
 const beforeViews=await durable(page),view=page.locator('.filter-pills[aria-label="検索結果の表示"]');
 await view.getByRole('button',{name:'表',exact:true}).click();await expect(page.getByRole('table',{name:'同じ検索結果の一覧'}).locator('tbody tr')).toHaveCount(2);
 await view.getByRole('button',{name:'カード',exact:true}).click();await expect(page.locator('.search-page .entity-card')).toHaveCount(2);expect(await durable(page)).toEqual(beforeViews);
 const beforeCancel=await durable(page);await page.getByText('結果をまとめて編集',{exact:true}).click();await page.getByRole('button',{name:'結果をすべて選択',exact:true}).click();await page.getByLabel('まとめて設定する状態',{exact:true}).selectOption('needs_review');await page.getByRole('button',{name:'変更差分を確認',exact:true}).click();
 let modal=page.getByRole('dialog',{name:'変更差分の確認',exact:true});await expect(modal).toContainText(f.first.name);await expect(modal).toContainText(added.name);await expect(modal).toContainText('下書き → 確認待ち');await modal.getByRole('button',{name:'中止',exact:true}).click();expect(await durable(page)).toEqual(beforeCancel);
 await page.getByRole('button',{name:'変更差分を確認',exact:true}).click();modal=page.getByRole('dialog',{name:'変更差分の確認',exact:true});const beforeFailure=await durable(page);await injectQuota(page,'原F58 一部書込失敗の原子拒否');await modal.getByRole('button',{name:'差分を確定して保存',exact:true}).click();await expect(page.locator('.search-page').getByRole('alert')).toBeVisible();expect(await durable(page)).toEqual(beforeFailure);await expect(modal).toBeVisible();
 const failureText=await page.locator('.search-page').getByRole('alert').innerText();await modal.getByRole('button',{name:'差分を確定して保存',exact:true}).click();await expect(modal).toHaveCount(0);await expect(page.locator('.search-page [role=status]').first()).toContainText('一括変更を保存しました');
 const bulk=await backup(page);for(const id of [f.first.id,added.id])expect(bulk.parsed.project.entities.find(e=>e.id===id)!.status).toBe('needs_review');expect(bulk.parsed.project.entities.find(e=>e.id===f.done.id)!.status).toBe('provisional');
 await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'変更履歴',exact:true}).click();await page.getByRole('button',{name:'この変更を取り消す',exact:true}).click();await expect(page.locator('.history-page [role=status]').last()).toContainText('復元し、保存した版を確認');
 const undone=await backup(page);for(const id of [f.first.id,added.id]){const restored=undone.parsed.project.entities.find(e=>e.id===id)!;expect(restored.status).toBe('provisional');expect(restored.data).toEqual(afterAdd.parsed.project.entities.find(e=>e.id===id)!.data);}expect(undone.parsed.project.history.length).toBeGreaterThan(bulk.parsed.project.history.length);
 await page.reload();await list(page,c.dynamic.name,2);await list(page,c.fixed.name,1);const cold=await backup(page);assertCollections(cold.parsed.project,f.first.name,added.name);
 const fresh=await freshRoundtrip(browser,cold.bytes,'new'),clone=await freshRoundtrip(browser,cold.bytes,'clone');assertCollections(fresh.parsed.project,f.first.name,added.name);assertCollections(clone.parsed.project,f.first.name,added.name);expect(clone.parsed.project.projectId).not.toBe(cold.parsed.project.projectId);
 await list(page,c.dynamic.name,2);await view.getByRole('button',{name:'カード',exact:true}).click();const observedButtons=await view.getByRole('button').allTextContents();
 await evidence(info,'F58-actual-before-required-graph',{candidate:'18bc668b409ffe3ef8614a5a852daefca162d7ea',tree:'ec3ed81dfba5b2f19d59a3a62f1d5d7ba564e3a2',build:'2503d3e7976b1e7d1643',original:{given:'未実装かつ人物Aが出る動的一覧と固定ID一覧',when:'場面を追加し各一覧を再度開き、カード/表/図を切替え一括編集を取り消す',then:'表示を変えても別のデータができない。検索を再実行する一覧と、固定した選択の一覧を区別する。',negative_or_edge:'動的条件一覧と固定ID集合の一覧を区別する。一括編集は変更前後を確認し、一部だけ失敗した更新を確定しない。'},inputSHA256:digest(input),archives:{initial:digest(initial.bytes),added:digest(afterAdd.bytes),bulk:digest(bulk.bytes),undo:digest(undone.bytes),cold:digest(cold.bytes),freshNew:digest(fresh.bytes),freshClone:digest(clone.bytes)},normalObserved:{queryPersonA:true,implementationTodo:true,dynamicBefore:1,fixedBefore:1,dynamicAfterAddedScene:2,fixedAfterAddedScene:1,cardsAndTableSameTwo:true,switchingDidNotWriteNativeData:true,previewShowedBothBeforeAfter:true,previewCancelNativeUnchanged:true,failedBatchNativeUnchanged:true,retryBothApplied:true,historyUndoBothAndBodyIds:true,coldAndFreshNewAndClone:true},failureText,nativeSHA:{beforeViews:digest(JSON.stringify(beforeViews)),beforeCancel:digest(JSON.stringify(beforeCancel)),beforeFailure:digest(JSON.stringify(beforeFailure))},displayButtons:observedButtons,requiredGraphExpected:'図',actualGraphButtonCount:await view.getByRole('button',{name:'図',exact:true}).count(),wholeCasePass:false,physical:'not_run',actualAuth:'not_run'});
 await page.screenshot({path:info.outputPath('F58-missing-graph.png'),fullPage:true});
 // This positive original expectation intentionally remains failing until the same-result graph exists.
 await expect(view.getByRole('button',{name:'図',exact:true})).toBeVisible();
});
