import {defineConfig,devices} from '@playwright/test';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),run=process.env.REVIEW_RUN;
if(!run||!/^[a-z0-9-]+$/.test(run)||!process.env.CHROMIUM_PATH)throw Error('Bound run and explicit Chromium153 required.');
export default defineConfig({
 testDir:resolve(root,'harness'),testMatch:'f58-original.spec.ts',workers:1,fullyParallel:false,retries:0,timeout:180000,expect:{timeout:10000},
 outputDir:resolve('/workspace/shinariokanri-independent-artifacts/c13-f58-precheck',run,'artifacts'),
 reporter:[['list'],['json',{outputFile:resolve(root,'results',run,'playwright.json')}]],
 use:{baseURL:'http://127.0.0.1:5310/shinariokanri/',trace:'on',screenshot:'only-on-failure',...devices['Desktop Chrome'],launchOptions:{executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']}},
 webServer:{command:'node server.mjs --port 5310',cwd:root,url:'http://127.0.0.1:5310/shinariokanri/build-info.json',reuseExistingServer:false},
});
