# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: f58-original.spec.ts >> 原 AT-F58 動的・固定一覧の同じ結果をカード・表・図で使い原子一括を取り消す
- Location: harness/f58-original.spec.ts:36:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.filter-pills[aria-label="検索結果の表示"]').getByRole('button', { name: '図', exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.filter-pills[aria-label="検索結果の表示"]').getByRole('button', { name: '図', exact: true }) with timeout 10000ms
  - waiting for locator('.filter-pills[aria-label="検索結果の表示"]').getByRole('button', { name: '図', exact: true })

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- link "本文へ移動":
  - /url: "#main-content"
- complementary "主要ナビゲーション":
  - text: S シナリオ管理
  - button "原 F58 人物Aの未実装一覧と固定ID 作品一覧へ ⌄":
    - strong: 原 F58 人物Aの未実装一覧と固定ID
    - text: 作品一覧へ ⌄
  - text: WORKSPACE
  - navigation:
    - button "年表"
    - button "構成"
    - button "資料 2"
    - button "検索"
  - text: QUICK NOTE
  - button "アイデアを残す"
  - button "作品・保存"
  - strong: この端末に保存
  - text: 同期接続先は未設定
  - button "暗い配色にする"
- banner:
  - text: 原 F58 人物Aの未実装一覧と固定ID / 検索
  - status: 端末内保存済み LOCAL
- main:
  - text: FIND IN YOUR STORY
  - heading "検索" [level=1]
  - paragraph: 本文も、設定も。作品の中から見つける。
  - button "追加"
  - group: 最近開いた情報・お気に入り
  - tablist "検索と整理":
    - tab "複合検索・一覧" [selected]
    - tab "五十音・分類索引"
    - tab "見直しと統合"
  - text: 作品内を検索
  - textbox "作品内を検索":
    - /placeholder: 名前・読み・別名・本文
  - combobox "情報の種類":
    - option "すべての種類"
  - combobox "情報の状態で絞り込む":
    - option "すべての状態" [selected]
    - option "確定"
    - option "下書き"
    - option "確認待ち"
    - option "不採用"
    - option "別案"
  - text: 参加人物で絞り込む
  - searchbox "参加人物で絞り込むを検索"
  - combobox "参加人物で絞り込む":
    - option "すべての参加人物" [selected]
    - option "人物A"
    - option "人物B"
  - combobox "制作進捗で絞り込む":
    - option "すべての制作進捗" [selected]
    - option "未着手"
    - option "作業中"
    - option "完了"
    - option "確認待ち"
  - text: 章で絞り込む
  - searchbox "章で絞り込むを検索"
  - combobox "章で絞り込む":
    - option "すべての章" [selected]
  - text: 伏線で絞り込む
  - searchbox "伏線で絞り込むを検索"
  - combobox "伏線で絞り込む":
    - option "すべての伏線" [selected]
  - combobox "伏線の回収方針":
    - option "すべての回収方針" [selected]
    - option "本作で回収"
    - option "続編で回収"
    - option "意図的に未回収"
    - option "ミスリード"
    - option "未決定"
    - option "不採用"
  - combobox "手掛かり・回収の役割":
    - option "すべての役割" [selected]
    - option "手掛かり"
    - option "回収"
  - combobox "提示段階で絞り込む":
    - option "すべての提示段階" [selected]
    - option "示唆"
    - option "疑念"
    - option "補強"
    - option "開示"
    - option "別案"
  - text: 保存した一覧を再表示
  - searchbox "保存した一覧を再表示を検索"
  - combobox "保存した一覧を再表示":
    - option "現在の検索条件"
    - option "人物Aかつ未実装・動的" [selected]
    - option "人物Aかつ未実装・固定"
  - text: 一覧の名前
  - textbox "一覧の名前"
  - text: 保存する内容
  - combobox "保存する内容":
    - option "条件に合わせて変わる一覧" [selected]
    - option "今の結果を固定した一覧"
  - button "一覧を保存" [disabled]
  - heading "検索結果" [level=2]
  - text: 2件
  - group: 結果をまとめて編集
  - button "カード"
  - button "表"
  - button "01 Aの未実装場面 下書き 人物Aの未実装の本文😀。 場面":
    - text: "01"
    - heading "Aの未実装場面" [level=3]
    - text: 下書き
    - paragraph: 人物Aの未実装の本文😀。
    - text: 場面
  - button "02 新しいAの未実装場面 下書き 追加しても動的一覧だけが追従する😀。 場面":
    - text: "02"
    - heading "新しいAの未実装場面" [level=3]
    - text: 下書き
    - paragraph: 追加しても動的一覧だけが追従する😀。
    - text: 場面
- contentinfo: 端末内の作品 · 版 8 14件の情報 · 0件の関係
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {createEntity,createProject,textToRichText,validateProject} from '../candidate/src/domain/model';
  3  | import {evaluateCollection} from '../candidate/src/domain/catalog';
  4  | import type {ProjectData,Entity,EntityKind} from '../candidate/src/domain/types';
  5  | import {seed,nav,backup,durable,evidence,digest,injectQuota} from './common';
  6  | import {editData,saveEditor,freshRoundtrip} from './extended-support';
  7  | 
  8  | async function catalog(page:Page){await nav(page,/^検索/);await expect(page.locator('.search-page')).toBeVisible();}
  9  | async function closeDetail(page:Page){const close=page.locator('.detail-panel').getByRole('button',{name:'詳細を閉じる',exact:true});if(await close.isVisible())await close.click();}
  10 | async function add(page:Page,kind:EntityKind,name:string){
  11 |  await nav(page,/^資料/);await page.getByLabel('情報の種類',{exact:true}).selectOption(kind);
  12 |  await page.locator('.workspace-heading').getByRole('button',{name:/を追加$/}).click();
  13 |  const modal=page.getByRole('dialog',{name:'情報を追加',exact:true});await modal.getByLabel('名前',{exact:true}).fill(name);await modal.getByRole('button',{name:'編集を始める',exact:true}).click();
  14 |  await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
  15 | }
  16 | async function list(page:Page,name:string,count:number){
  17 |  await catalog(page);await page.getByLabel('保存した一覧を再表示',{exact:true}).selectOption({label:name});
  18 |  await expect(page.locator('.search-page .list-heading')).toContainText(count+'件');
  19 | }
  20 | function fixture(){
  21 |  const p=createProject('原 F58 人物Aの未実装一覧と固定ID'),a=createEntity(p.projectId,'character','人物A'),b=createEntity(p.projectId,'character','人物B');
  22 |  const ea=createEntity(p.projectId,'event','人物Aが出る出来事',{summary:textToRichText('人物Aが参加する。'),participants:[{characterId:a.id,role:'actor'}]}),eb=createEntity(p.projectId,'event','人物Bが出る出来事',{summary:textToRichText('人物Bが参加する。'),participants:[{characterId:b.id,role:'actor'}]});
  23 |  const first=createEntity(p.projectId,'scene','Aの未実装場面',{eventIds:[ea.id],body:textToRichText('人物Aの未実装の本文😀。')}),done=createEntity(p.projectId,'scene','Aの実装済み場面',{eventIds:[ea.id],body:textToRichText('この実装済み場面は結果に含めない。')}),other=createEntity(p.projectId,'scene','Bの未実装場面',{eventIds:[eb.id],body:textToRichText('人物Bのみ。')});
  24 |  const tasks=[createEntity(p.projectId,'production_task','A未実装',{targetIds:[first.id],stage:'implementation',progress:'todo'}),createEntity(p.projectId,'production_task','A実装済み',{targetIds:[done.id],stage:'implementation',progress:'done'}),createEntity(p.projectId,'production_task','B未実装',{targetIds:[other.id],stage:'implementation',progress:'todo'})];
  25 |  p.entities=[a,b,ea,eb,first,done,other,...tasks];expect(validateProject(p).ok).toBe(true);return {p,a,ea,first,done,other};
  26 | }
  27 | function collections(p:ProjectData){return p.entities.filter((e):e is Entity<'collection'>=>e.kind==='collection'&&!e.deletedAt);}
  28 | function assertCollections(p:ProjectData,firstName:string,newName:string){
  29 |  const dynamic=collections(p).find(e=>e.name==='人物Aかつ未実装・動的')!,fixed=collections(p).find(e=>e.name==='人物Aかつ未実装・固定')!;
  30 |  expect(dynamic.data.mode).toBe('dynamic');expect(dynamic.data.memberIds??[]).toEqual([]);expect(dynamic.data.query).toMatchObject({op:'all',children:expect.arrayContaining([{op:'kind',value:'scene'},{op:'participant',characterId:p.entities.find(e=>e.kind==='character'&&e.name==='人物A')!.id},{op:'production',value:'todo'}])});
  31 |  expect(fixed.data.mode).toBe('fixed');expect(fixed.data.query).toBeNull();
  32 |  expect(evaluateCollection(p,dynamic).entities.map(e=>e.name).sort()).toEqual([firstName,newName].sort());
  33 |  expect(evaluateCollection(p,fixed).entities.map(e=>e.name)).toEqual([firstName]);return {dynamic,fixed};
  34 | }
  35 | 
  36 | test('原 AT-F58 動的・固定一覧の同じ結果をカード・表・図で使い原子一括を取り消す',async({page,browser},info)=>{
  37 |  const f=fixture();const input=await seed(page,f.p);await closeDetail(page);await catalog(page);
  38 |  await page.locator('.search-page .kind-select').selectOption('scene');await page.getByLabel('参加人物で絞り込む',{exact:true}).selectOption(f.a.id);await page.getByLabel('制作進捗で絞り込む',{exact:true}).selectOption('todo');
  39 |  await expect(page.locator('.search-page .list-heading')).toContainText('1件');await expect(page.locator('.search-page .entity-card')).toContainText(f.first.name);
  40 |  await page.getByLabel('一覧の名前',{exact:true}).fill('人物Aかつ未実装・動的');await page.getByLabel('保存する内容',{exact:true}).selectOption('dynamic');await page.getByRole('button',{name:'一覧を保存',exact:true}).click();await expect(page.locator('.search-page [role=status]').first()).toContainText('一覧を保存しました');
  41 |  await page.getByLabel('一覧の名前',{exact:true}).fill('人物Aかつ未実装・固定');await page.getByLabel('保存する内容',{exact:true}).selectOption('fixed');await page.getByRole('button',{name:'一覧を保存',exact:true}).click();await expect(page.locator('.search-page [role=status]').first()).toContainText('一覧を保存しました');
  42 |  const initial=await backup(page);expect(collections(initial.parsed.project)).toHaveLength(2);
  43 |  await add(page,'scene','新しいAの未実装場面');await editData(page,data=>{data.eventIds=[f.ea.id];data.body=textToRichText('追加しても動的一覧だけが追従する😀。');});await saveEditor(page);await closeDetail(page);
  44 |  const afterScene=await backup(page),added=afterScene.parsed.project.entities.find(e=>e.kind==='scene'&&e.name==='新しいAの未実装場面')!;expect(added).toBeTruthy();
  45 |  await add(page,'production_task','新しいAの実装タスク');await editData(page,data=>{data.targetIds=[added.id];data.stage='implementation';data.progress='todo';});await saveEditor(page);await closeDetail(page);
  46 |  const afterAdd=await backup(page);const c=assertCollections(afterAdd.parsed.project,f.first.name,added.name);
  47 |  await list(page,c.fixed.name,1);await expect(page.locator('.search-page .entity-card')).toHaveCount(1);
  48 |  await list(page,c.dynamic.name,2);await expect(page.locator('.search-page .entity-card')).toHaveCount(2);
  49 |  const beforeViews=await durable(page),view=page.locator('.filter-pills[aria-label="検索結果の表示"]');
  50 |  await view.getByRole('button',{name:'表',exact:true}).click();await expect(page.getByRole('table',{name:'同じ検索結果の一覧'}).locator('tbody tr')).toHaveCount(2);
  51 |  await view.getByRole('button',{name:'カード',exact:true}).click();await expect(page.locator('.search-page .entity-card')).toHaveCount(2);expect(await durable(page)).toEqual(beforeViews);
  52 |  const beforeCancel=await durable(page);await page.getByText('結果をまとめて編集',{exact:true}).click();await page.getByRole('button',{name:'結果をすべて選択',exact:true}).click();await page.getByLabel('まとめて設定する状態',{exact:true}).selectOption('needs_review');await page.getByRole('button',{name:'変更差分を確認',exact:true}).click();
  53 |  let modal=page.getByRole('dialog',{name:'変更差分の確認',exact:true});await expect(modal).toContainText(f.first.name);await expect(modal).toContainText(added.name);await expect(modal).toContainText('下書き → 確認待ち');await modal.getByRole('button',{name:'中止',exact:true}).click();expect(await durable(page)).toEqual(beforeCancel);
  54 |  await page.getByRole('button',{name:'変更差分を確認',exact:true}).click();modal=page.getByRole('dialog',{name:'変更差分の確認',exact:true});const beforeFailure=await durable(page);await injectQuota(page,'原F58 一部書込失敗の原子拒否');await modal.getByRole('button',{name:'差分を確定して保存',exact:true}).click();await expect(page.locator('.search-page').getByRole('alert')).toBeVisible();expect(await durable(page)).toEqual(beforeFailure);await expect(modal).toBeVisible();
  55 |  const failureText=await page.locator('.search-page').getByRole('alert').innerText();await modal.getByRole('button',{name:'差分を確定して保存',exact:true}).click();await expect(modal).toHaveCount(0);await expect(page.locator('.search-page [role=status]').first()).toContainText('一括変更を保存しました');
  56 |  const bulk=await backup(page);for(const id of [f.first.id,added.id])expect(bulk.parsed.project.entities.find(e=>e.id===id)!.status).toBe('needs_review');expect(bulk.parsed.project.entities.find(e=>e.id===f.done.id)!.status).toBe('provisional');
  57 |  await nav(page,/^作品・保存/);await page.getByRole('tab',{name:'変更履歴',exact:true}).click();await page.getByRole('button',{name:'この変更を取り消す',exact:true}).click();await expect(page.locator('.history-page [role=status]').last()).toContainText('復元し、保存した版を確認');
  58 |  const undone=await backup(page);for(const id of [f.first.id,added.id]){const restored=undone.parsed.project.entities.find(e=>e.id===id)!;expect(restored.status).toBe('provisional');expect(restored.data).toEqual(afterAdd.parsed.project.entities.find(e=>e.id===id)!.data);}expect(undone.parsed.project.history.length).toBeGreaterThan(bulk.parsed.project.history.length);
  59 |  await page.reload();await list(page,c.dynamic.name,2);await list(page,c.fixed.name,1);const cold=await backup(page);assertCollections(cold.parsed.project,f.first.name,added.name);
  60 |  const fresh=await freshRoundtrip(browser,cold.bytes,'new'),clone=await freshRoundtrip(browser,cold.bytes,'clone');assertCollections(fresh.parsed.project,f.first.name,added.name);assertCollections(clone.parsed.project,f.first.name,added.name);expect(clone.parsed.project.projectId).not.toBe(cold.parsed.project.projectId);
  61 |  await list(page,c.dynamic.name,2);await view.getByRole('button',{name:'カード',exact:true}).click();const observedButtons=await view.getByRole('button').allTextContents();
  62 |  await evidence(info,'F58-actual-before-required-graph',{candidate:'18bc668b409ffe3ef8614a5a852daefca162d7ea',tree:'ec3ed81dfba5b2f19d59a3a62f1d5d7ba564e3a2',build:'2503d3e7976b1e7d1643',original:{given:'未実装かつ人物Aが出る動的一覧と固定ID一覧',when:'場面を追加し各一覧を再度開き、カード/表/図を切替え一括編集を取り消す',then:'表示を変えても別のデータができない。検索を再実行する一覧と、固定した選択の一覧を区別する。',negative_or_edge:'動的条件一覧と固定ID集合の一覧を区別する。一括編集は変更前後を確認し、一部だけ失敗した更新を確定しない。'},inputSHA256:digest(input),archives:{initial:digest(initial.bytes),added:digest(afterAdd.bytes),bulk:digest(bulk.bytes),undo:digest(undone.bytes),cold:digest(cold.bytes),freshNew:digest(fresh.bytes),freshClone:digest(clone.bytes)},normalObserved:{queryPersonA:true,implementationTodo:true,dynamicBefore:1,fixedBefore:1,dynamicAfterAddedScene:2,fixedAfterAddedScene:1,cardsAndTableSameTwo:true,switchingDidNotWriteNativeData:true,previewShowedBothBeforeAfter:true,previewCancelNativeUnchanged:true,failedBatchNativeUnchanged:true,retryBothApplied:true,historyUndoBothAndBodyIds:true,coldAndFreshNewAndClone:true},failureText,nativeSHA:{beforeViews:digest(JSON.stringify(beforeViews)),beforeCancel:digest(JSON.stringify(beforeCancel)),beforeFailure:digest(JSON.stringify(beforeFailure))},displayButtons:observedButtons,requiredGraphExpected:'図',actualGraphButtonCount:await view.getByRole('button',{name:'図',exact:true}).count(),wholeCasePass:false,physical:'not_run',actualAuth:'not_run'});
  63 |  await page.screenshot({path:info.outputPath('F58-missing-graph.png'),fullPage:true});
  64 |  // This positive original expectation intentionally remains failing until the same-result graph exists.
> 65 |  await expect(view.getByRole('button',{name:'図',exact:true})).toBeVisible();
     |                                                               ^ Error: expect(locator).toBeVisible() failed
  66 | });
  67 | 
```