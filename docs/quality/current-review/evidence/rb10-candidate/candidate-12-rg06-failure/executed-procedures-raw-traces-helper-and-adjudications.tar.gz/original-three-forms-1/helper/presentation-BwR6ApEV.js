//#region ../shinariokanri-rb10-basic-registration/src/storage/errors.ts
var e = class extends Error {
	code;
	path;
	constructor(e, t, n, r) {
		super(t, r), this.name = "StorageError", this.code = e, this.path = n;
	}
};
function t(t) {
	if (t?.aborted) throw new e("CANCELLED", "処理を取り消しました。既存の作品は変更していません。");
}
function n(t) {
	if (t instanceof e) return t;
	let n = t instanceof Error && /quota/i.test(t.name + t.message);
	return new e(n ? "QUOTA_EXCEEDED" : "SAVE_FAILED", n ? "保存容量が不足しています。入力を保持して完全ファイルへ書き出すか、容量を確保して再試行してください。" : "端末内への保存に失敗しました。入力を保持して再試行してください。", void 0, { cause: t });
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/storage/json.ts
var r = "1.0.0", i = Object.freeze({
	compressedBytes: 67108864,
	expandedBytes: 268435456,
	jsonBytes: 67108864,
	assetBytes: 33554432,
	files: 5e3,
	records: 1e5,
	depth: 32,
	objects: 5e5,
	conditionDepth: 16,
	conditionNodes: 256,
	fieldBytes: 1048576
});
function a(e) {
	for (let t = 0; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(++t);
			if (!(n >= 56320 && n <= 57343)) return !1;
		} else if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function o(t, n, r = i, o = { objects: 0 }) {
	if (t.byteLength > r.jsonBytes) throw new e("LIMIT_EXCEEDED", "JSONファイルが上限を超えています。", n);
	if (t[0] === 239 && t[1] === 187 && t[2] === 191) throw new e("ARCHIVE_INVALID", "JSONのBOMは使用できません。", n);
	let s;
	try {
		s = new TextDecoder("utf-8", { fatal: !0 }).decode(t);
	} catch (t) {
		throw new e("ARCHIVE_INVALID", "JSONは有効なUTF-8である必要があります。", n, { cause: t });
	}
	let c = 0, l = (t) => {
		throw new e("ARCHIVE_INVALID", `${t}（位置 ${c}）`, n);
	}, u = () => {
		for (; /[ \t\n\r]/.test(s[c] ?? "") && c < s.length;) c++;
	};
	function d() {
		let e = c++;
		for (; c < s.length;) {
			let t = s[c++];
			if (t === "\"") {
				let t;
				try {
					t = JSON.parse(s.slice(e, c));
				} catch {
					return l("文字列が不正です。");
				}
				return a(t) ? t : l("Unicodeのサロゲートが不正です。");
			}
			t === "\\" && c++;
		}
		return l("文字列が閉じられていません。");
	}
	function f(t) {
		u();
		let i = s[c];
		if (i === "\"") return d();
		if (i === "{" || i === "[") {
			if (t > r.depth || ++o.objects > r.objects) throw new e("LIMIT_EXCEEDED", "JSONの構造が安全上限を超えています。", n);
			let a = i === "{";
			c++, u();
			let p = a ? "}" : "]", m = a ? Object.create(null) : [], h = /* @__PURE__ */ new Set();
			if (s[c] === p) return c++, m;
			for (; c < s.length;) {
				if (u(), a) {
					if (s[c] !== "\"") return l("オブジェクトのkeyが不正です。");
					let e = d();
					if (h.has(e)) return l(`key「${e}」が重複しています。`);
					if (h.add(e), u(), s[c++] !== ":") return l("keyの後にコロンが必要です。");
					m[e] = f(t + 1);
				} else m.push(f(t + 1));
				u();
				let e = s[c++];
				if (e === p) return m;
				if (e !== ",") return l("区切り文字が不正です。");
			}
			return l("JSONが閉じられていません。");
		}
		for (let [e, t] of [
			["true", !0],
			["false", !1],
			["null", null]
		]) if (s.startsWith(e, c)) return c += e.length, t;
		let a = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(s.slice(c));
		if (!a) return l("値が不正です。");
		c += a[0].length;
		let p = Number(a[0]);
		return Number.isFinite(p) ? p : l("有限でない数値は保存できません。");
	}
	let p = f(1);
	return u(), c !== s.length && l("JSONの末尾に余分なデータがあります。"), p;
}
function s(t) {
	let n = /* @__PURE__ */ new Set();
	function r(t) {
		if (t !== null && typeof t != "boolean") {
			if (typeof t == "string") {
				if (!a(t)) throw new e("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
				return;
			}
			if (typeof t == "number") {
				if (!Number.isFinite(t)) throw new e("VALIDATION_FAILED", "有限でない数値は保存できません。");
				return;
			}
			if (typeof t != "object") throw new e("VALIDATION_FAILED", "JSONに保存できない値があります。");
			if (n.has(t)) throw new e("VALIDATION_FAILED", "循環したJSONは保存できません。");
			if (n.add(t), Array.isArray(t)) t.forEach(r);
			else for (let e of Object.keys(t)) {
				let n = t[e];
				n !== void 0 && r(n);
			}
			n.delete(t);
		}
	}
	r(t);
}
function c(t) {
	let n = /* @__PURE__ */ new Set();
	function r(t) {
		if (t === null) return "null";
		if (typeof t == "string") {
			if (!a(t)) throw new e("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return JSON.stringify(t);
		}
		if (typeof t == "boolean") return String(t);
		if (typeof t == "number") {
			if (!Number.isFinite(t)) throw new e("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return JSON.stringify(t);
		}
		if (typeof t != "object") throw new e("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (n.has(t)) throw new e("VALIDATION_FAILED", "循環したJSONは保存できません。");
		n.add(t);
		let i = Array.isArray(t) ? `[${t.map(r).join(",")}]` : `{${Object.keys(t).filter((e) => t[e] !== void 0).sort().map((e) => `${JSON.stringify(e)}:${r(t[e])}`).join(",")}}`;
		return n.delete(t), i;
	}
	return r(t);
}
var l = (e) => new TextEncoder().encode(c(e)), u = (e, t) => c(e) === c(t);
async function d(e) {
	let t = await crypto.subtle.digest("SHA-256", e.slice().buffer);
	return [...new Uint8Array(t)].map((e) => e.toString(16).padStart(2, "0")).join("");
}
function f(t) {
	if (!t || t.includes("\0") || t.includes("\\") || t.startsWith("/") || /^[a-z]:/i.test(t) || t.split("/").some((e) => !e || e === "." || e === "..") || !a(t)) throw new e("UNSAFE_PATH", "危険なファイルパスです。", t);
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/pinnedWorlds.ts
function p() {
	return {
		hashes: /* @__PURE__ */ new WeakMap(),
		registryClones: /* @__PURE__ */ new WeakMap(),
		stableRegistries: /* @__PURE__ */ new WeakSet()
	};
}
function m(e, t) {
	let n = t.registryClones.get(e);
	if (n) return n;
	let r = structuredClone(e);
	return t.registryClones.set(e, r), t.stableRegistries.add(r), r;
}
function h(e, t) {
	let n = [], r = [], i = [], a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = [...e.worldReferences].reverse().map((e) => ({ reference: e })), u = 0;
	for (; l.length;) {
		if (++u > 2e5) {
			i.push("共通世界の依存数が安全上限を超えています。");
			break;
		}
		let e = l.pop();
		if ("exit" in e) {
			o.delete(e.exit);
			continue;
		}
		let d = e.reference, f = d.immutableSnapshotId;
		if (o.has(f)) {
			i.push("共通世界の固定版参照が循環しています。");
			continue;
		}
		let p = c.get(f);
		if (p && p !== d.contentHash) {
			i.push("同じ共通世界の固定版に異なる内容ハッシュが指定されています。");
			continue;
		}
		c.set(f, d.contentHash);
		let m = s.get(d.projectId);
		if (m && m !== f) {
			i.push("同じ共通世界の異なる版が同時に参照されています。");
			continue;
		}
		if (s.set(d.projectId, f), a.has(f)) continue;
		let h = t[f];
		if (!h || h.projectId !== d.projectId) {
			i.push("参照した共通世界の固定版がありません。");
			continue;
		}
		if (a.add(f), o.add(f), r.push(d), n.push(h), l.push({ exit: f }), !Array.isArray(h.worldReferences)) {
			i.push("共通世界の依存参照が不正です。");
			continue;
		}
		for (let e of [...h.worldReferences].reverse()) l.push({ reference: e });
	}
	return {
		worlds: n,
		references: r,
		errors: i
	};
}
async function g(e, t, n = "worldReferences", r) {
	let i = h(e, t), a = i.errors.map((e) => ({
		code: "REFERENCE_INVALID",
		path: n,
		message: e
	}));
	for (let e of i.references) {
		let i = t[e.immutableSnapshotId];
		if (!i) continue;
		let o = `${e.immutableSnapshotId}\0${e.contentHash}`, s = r?.hashes.get(i);
		r && !s && (s = /* @__PURE__ */ new Map(), r.hashes.set(i, s));
		let c = s?.get(o);
		c || (c = d(l(i)), s?.set(o, c)), await c !== e.contentHash && a.push({
			code: "INTEGRITY_FAILED",
			path: `${n}.${e.projectId}.${e.immutableSnapshotId}.contentHash`,
			message: "共通世界の固定版内容ハッシュが一致しません。"
		});
	}
	return a;
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/adoption.ts
function _(e) {
	return !e.deletedAt && e.status !== "rejected" && e.status !== "alternate";
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/reuse.ts
var v = /* @__PURE__ */ new WeakMap(), ee = /* @__PURE__ */ new WeakMap(), y = (e, t) => v.get(e)?.get(t), te = (e) => ee.get(e) ?? e, b = (e) => e.kind === "scene" || e.kind === "flow_node";
function x(e, t) {
	let n = e;
	for (let e of t.replace(/\[(\d+)\]/g, ".$1").split(".")) {
		if (!n || typeof n != "object") return;
		if ("sourceVersionId" in n && typeof n.sourceVersionId == "string") return n.sourceVersionId;
		n = n[e];
	}
}
function S(e) {
	throw Object.assign(/* @__PURE__ */ Error(`REFERENCE_INVALID: ${e}`), { issues: [{
		code: "REFERENCE_INVALID",
		path: "reuse",
		message: e
	}] });
}
function C(e) {
	if (Array.isArray(e)) return e.flatMap(C);
	if (!e || typeof e != "object") return [];
	let t = e;
	return [...typeof t.id == "string" && ("text" in t && "kind" in t || "audienceHolderIds" in t || "eventKey" in t || "x" in t && "y" in t) ? [t.id] : [], ...Object.values(t).flatMap(C)];
}
function ne(e, t, n) {
	let r = new Map(e.entities.filter(_).map((e) => [e.id, e])), i = new Map(e.entities.flatMap((e) => C(e.data).map((t) => [t, e.id]))), a = /* @__PURE__ */ new Map();
	for (let e of r.values()) e.kind === "disclosure" && a.set(e.data.anchor.entityId, [...a.get(e.data.anchor.entityId) ?? [], e]);
	let o = [t], s = /* @__PURE__ */ new Set(), c = [];
	for (let e = 0; e < o.length; e++) {
		let t = o[e];
		if (s.has(t)) continue;
		s.add(t);
		let n = r.get(t);
		n || S("共通元の依存情報が存在しないか、不採用です。"), c.push(n);
		for (let e of a.get(t) ?? []) o.push(e.id);
		for (let e of tn(n)) {
			if (n.kind === "scene" && e.path === "data.chapterId" || x(n, e.path) || ![
				"entity",
				"record",
				"presentation",
				"block"
			].includes(e.scope)) continue;
			let t = r.has(e.id) ? e.id : i.get(e.id);
			t && o.push(t);
		}
		c.length > 1e5 && S("共通元の依存情報が100,000件を超えています。");
	}
	return c;
}
var re = (e) => [...new Set(e.flatMap((e) => [e.id, ...C(e.data)]))], ie = (e, t) => c(e) === c(t);
function ae(e, t, n) {
	return !!t && [
		"variable",
		"item",
		"character",
		"place",
		"group",
		"assertion",
		"external_contract"
	].includes(e.kind) && t.kind === e.kind && _(t) && e.status === t.status && e.name === t.name && ie(on(e, n).data, t.data);
}
function oe(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => oe(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	typeof n.id == "string" && ("text" in n && "kind" in n || "audienceHolderIds" in n || "eventKey" in n || "x" in n && "y" in n) && (n.id = t[n.id] ?? n.id), Object.values(n).forEach((e) => oe(e, t));
}
function se(e, t, n, r) {
	let i = on(e, t);
	i.id = t[e.id] ?? e.id, i.projectId = n, oe(i.data, t);
	for (let t of tn(e)) if (x(e, t.path)) {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split("."), n = i;
		for (let t of e.slice(0, -1)) n = n[t];
		n[e.at(-1)] = t.id;
	}
	return i;
}
function ce(e, t, n = []) {
	if (v.has(e) || !e.entities.some((e) => _(e) && b(e) && e.data.reuse && e.data.reuse.mode !== "clone")) return e;
	let r = new Map(e.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Set([
		...e.entities.flatMap((e) => [e.id, ...C(e.data)]),
		...e.relations.map((e) => e.id),
		...e.views.map((e) => e.id),
		e.projectId
	]), o = new Map(e.worldReferences.map((e) => [e.projectId, e]));
	for (let s of e.entities) {
		if (!_(s) || !b(s) || !s.data.reuse || s.data.reuse.mode === "clone") continue;
		let c = s.data.reuse, l = t.find((e) => e.id === c.pinnedSnapshotId);
		(!l || l.content.projectId !== e.projectId) && S("共通元の固定版がありません。"), (n.includes(l.id) || n.length >= 32) && S("共通元の固定参照が循環しているか、32段を超えています。");
		let u = ce(l.content, t, [...n, l.id]), d = u.entities.find((e) => e.id === c.sourceId && _(e));
		(!d || d.kind !== s.kind || !b(d)) && S("共通元の種類が一致しないか、固定版で不採用です。");
		let f = ne(u, d.id, l.id), p = re(f), m = c.bindings;
		(!m || m[d.id] !== s.id || p.length !== Object.keys(m).length || p.some((e) => !m[e]) || new Set(Object.values(m)).size !== p.length) && S("共通元のID対応が欠落・重複しています。対象版を確認して再設定してください。");
		for (let [e, t] of Object.entries(m)) if (t !== s.id && a.has(t)) {
			let n = f.find((t) => t.id === e);
			(e !== t || !n || !ae(n, r.get(t), m)) && S("共通元の実行用IDが現在稿のレコード・段落・関係と衝突しています。ID対応を確認し直してください。");
		}
		let h = new Set(Object.keys(d.data).filter((e) => !["reuse", "chapterId"].includes(e)));
		(c.mode === "reference" && c.overrideFields.length || c.overrideFields.some((e) => !h.has(e))) && S("上書き対象が不正です。宣言したフィールドだけを上書きしてください。");
		for (let e of u.worldReferences) {
			let t = o.get(e.projectId);
			t && !ie(t, e) && S("共通元と使用先が同じ世界の異なる固定版を要求しています。適用する版を明示して揃えてください。"), o.set(e.projectId, e);
		}
		let g = u.entities.find((e) => e.kind === "flow_graph" && d.kind === "flow_node" && e.data.nodeIds.includes(d.id)), v = d.kind === "scene" ? d : u.entities.find((e) => d.kind === "flow_node" && e.id === d.data.sceneId && e.kind === "scene");
		for (let t of f) {
			let n = se(t, m, e.projectId, l.id), a = n.id, o = r.get(a);
			if (a !== s.id && o) {
				(t.id !== a || !ae(t, o, m)) && S("共通元の実行用IDが現在稿と衝突しています。対応を再確認してください。");
				continue;
			}
			let d = y(u, t.id), f = d ? Object.fromEntries(Object.entries(d.bindings).flatMap(([e, t]) => m[t] ? [[e, m[t]]] : [])) : m;
			if (i.set(a, {
				entityId: d?.entityId ?? t.id,
				sourceVersionId: d?.sourceVersionId ?? l.id,
				ownerId: s.id,
				bindings: f,
				graphId: g ? m[g.id] ?? g.id : void 0,
				chapterId: v?.kind === "scene" && v.data.chapterId ? m[v.data.chapterId] ?? v.data.chapterId : void 0
			}), a === s.id) {
				let e = { ...n.data };
				delete e.reuse;
				for (let t of c.overrideFields) Object.hasOwn(s.data, t) ? e[t] = structuredClone(s.data[t]) : delete e[t];
				s.kind === "scene" && (e.chapterId = s.data.chapterId ?? null), r.set(a, {
					...s,
					data: e
				});
			} else r.set(a, n);
		}
		r.size > 1e5 && S("再利用を解決した実行情報が100,000件を超えています。");
	}
	let s = /* @__PURE__ */ new Set();
	for (let t of [...r.values()].flatMap((e) => [e.id, ...C(e.data)]).concat(e.relations.map((e) => e.id), e.views.map((e) => e.id))) s.has(t) && S("再利用先どうしでレコード・段落等のIDが衝突しています。ID対応を確認し直してください。"), s.add(t);
	let c = {
		...e,
		entities: [...r.values()],
		worldReferences: [...o.values()]
	};
	return v.set(c, i), ee.set(c, e), c;
}
function le(e, t) {
	return Object.fromEntries([...v.get(e) ?? []].map(([e, n]) => [e, {
		...t,
		graphId: t.graphId ? n.bindings[t.graphId] ?? t.graphId : void 0,
		chapterId: t.chapterId ? n.bindings[t.chapterId] ?? t.chapterId : void 0,
		sourceVersionId: n.sourceVersionId,
		anchorBindings: n.bindings
	}]));
}
function ue(e, t, n) {
	let r = y(e, n);
	return !r || t.sourceVersionId !== r.sourceVersionId ? t : {
		...t,
		entityId: r.bindings[t.entityId] ?? t.entityId,
		...t.blockId ? { blockId: r.bindings[t.blockId] ?? t.blockId } : {},
		...t.lineId ? { lineId: r.bindings[t.lineId] ?? t.lineId } : {}
	};
}
function de(e, t, n) {
	if (!e.entities.some((e) => b(e) && e.data.reuse?.bindings)) return [];
	try {
		return ce(e, t), [];
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: `${n}.reuse`,
			message: e.message
		}];
	}
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/types.ts
var fe = "1.0.0", pe = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/, me = 10n ** 38n - 1n, he = {
	id: "proleptic-gregorian-second",
	name: "先発グレゴリオ暦",
	kind: "gregorian",
	originLabel: "0000-01-01 00:00:00",
	ticksPerDay: "86400"
};
function ge(e) {
	return typeof e == "string" && pe.test(e);
}
function w(e) {
	if (!ge(e)) throw RangeError("tickは38桁以内の正規整数文字列で指定してください。");
	return BigInt(e);
}
function _e(e) {
	if (e < -me || e > me) throw RangeError("tickが38桁の範囲を超えています。");
	return e.toString();
}
function ve(e, t) {
	return _e(w(e) + w(t));
}
function T(e, t) {
	let n = w(e), r = w(t);
	return n < r ? -1 : +(n > r);
}
function ye(e, t = "calendar") {
	let n = (e, n = t) => ({
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: n,
			message: e
		}]
	});
	if (!e || typeof e != "object" || Array.isArray(e)) return n("暦はオブジェクトです。");
	let r = e, i = r.kind === "repeating" ? [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay",
		"years"
	] : [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay"
	];
	if (Object.keys(r).some((e) => !i.includes(e))) return n("暦に未知の項目があります。");
	if (typeof r.id != "string" || !r.id || typeof r.name != "string" || !r.name || typeof r.originLabel != "string") return n("暦のID・名称・原点ラベルが必要です。");
	if (!ge(r.ticksPerDay) || w(r.ticksPerDay) <= 0n) return n("1日のtick数は正の整数です。", `${t}.ticksPerDay`);
	if (r.kind === "gregorian") return r.ticksPerDay === "86400" ? {
		ok: !0,
		value: e
	} : n("標準暦は1日86400tickです。", `${t}.ticksPerDay`);
	if (r.kind !== "repeating" || !Array.isArray(r.years) || r.years.length < 1 || r.years.length > 400) return n("繰返し暦は1〜400年の周期が必要です。");
	for (let e = 0; e < r.years.length; e++) {
		let i = r.years[e];
		if (!i || typeof i != "object" || Object.keys(i).some((e) => e !== "months") || !Array.isArray(i.months) || i.months.length < 1 || i.months.length > 24) return n("1年の月数は1〜24です。", `${t}.years[${e}]`);
		for (let r = 0; r < i.months.length; r++) {
			let a = i.months[r];
			if (!a || typeof a != "object" || Object.keys(a).some((e) => !["name", "days"].includes(e)) || typeof a.name != "string" || !a.name || !Number.isInteger(a.days) || a.days < 1 || a.days > 400) return n("月名と1〜400の日数が必要です。", `${t}.years[${e}].months[${r}]`);
		}
	}
	return {
		ok: !0,
		value: e
	};
}
function be(e, t) {
	try {
		return e.mode === "unknown" ? {
			status: "unknown",
			reason: e.reason || "日時が未定です。",
			path: t
		} : e.mode === "instant" ? (w(e.at), {
			status: "resolved",
			earliest: e.at,
			latest: e.at,
			endEarliest: e.at,
			endLatest: e.at,
			calendarId: e.calendarId,
			mode: e.mode
		}) : e.mode === "interval" ? T(e.start, e.end) >= 0 ? {
			status: "conflict",
			reason: "期間は開始より後に終了してください。",
			path: t
		} : {
			status: "resolved",
			earliest: e.start,
			latest: e.start,
			endEarliest: e.end,
			endLatest: e.end,
			calendarId: e.calendarId,
			mode: e.mode
		} : T(e.earliest, e.latest) > 0 ? {
			status: "conflict",
			reason: "概算範囲が逆転しています。",
			path: t
		} : {
			status: "resolved",
			earliest: e.earliest,
			latest: e.latest,
			endEarliest: e.earliest,
			endLatest: e.latest,
			calendarId: e.calendarId,
			mode: e.mode
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: t
		};
	}
}
function xe(e, t, n, r) {
	try {
		if (T(e.minOffset, e.maxOffset) > 0) return {
			status: "conflict",
			reason: "相対日時の範囲が逆転しています。",
			path: n()
		};
		if (t.status !== "resolved") return r ? {
			...t,
			path: [...n(), ...t.path].slice(0, 64)
		} : t;
		let i = ve(e.anchorPoint === "start" ? t.earliest : t.endEarliest, e.minOffset), a = ve(e.anchorPoint === "start" ? t.latest : t.endLatest, e.maxOffset);
		return {
			status: "resolved",
			earliest: i,
			latest: a,
			endEarliest: i,
			endLatest: a,
			calendarId: t.calendarId,
			mode: "relative"
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: n()
		};
	}
}
function Se(e, t, n = []) {
	return xe(e, t, () => n, !0);
}
function Ce(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) !n.deletedAt && !t.has(n.id) && t.set(n.id, n);
	return t;
}
function we(e, t = [], n = []) {
	if (e.mode !== "relative") return be(e, n);
	let r = Ce(t), i = [...n], a = new Set(n), o = [], s = e;
	for (; s.mode === "relative";) {
		if (a.has(s.anchorEventId)) return {
			status: "conflict",
			reason: "相対日時の参照が循環しています。",
			path: [...i, s.anchorEventId]
		};
		try {
			if (T(s.minOffset, s.maxOffset) > 0) return {
				status: "conflict",
				reason: "相対日時の範囲が逆転しています。",
				path: [...i]
			};
		} catch (e) {
			return {
				status: "conflict",
				reason: e instanceof Error ? e.message : "日時を解決できません。",
				path: [...i]
			};
		}
		let e = r.get(s.anchorEventId);
		if (!e) return {
			status: "unknown",
			reason: "基準となる出来事がありません。",
			path: [...i, s.anchorEventId]
		};
		o.push({
			time: s,
			pathLength: i.length
		}), a.add(e.id), i.push(e.id), s = e.data.time;
	}
	let c = be(s, i);
	for (let e = o.length - 1; e >= 0 && c.status === "resolved"; e--) {
		let t = o[e];
		c = xe(t.time, c, () => i.slice(0, t.pathLength), !1);
	}
	return c;
}
function Te(e) {
	let t = Ce(e), n = /* @__PURE__ */ new Map();
	for (let e of t.values()) {
		if (n.has(e.id)) continue;
		let r = [], i = /* @__PURE__ */ new Map(), a = e.id;
		for (; !n.has(a);) {
			let e = t.get(a);
			if (!e) {
				n.set(a, {
					status: "unknown",
					reason: "基準となる出来事がありません。",
					path: [a]
				});
				break;
			}
			let o = i.get(a);
			if (o !== void 0) {
				let e = r.slice(o);
				for (let t = 0; t < e.length; t++) n.set(e[t], {
					status: "conflict",
					reason: "相対日時の参照が循環しています。",
					path: Array.from({ length: Math.min(e.length + 1, 64) }, (n, r) => e[(t + r) % e.length])
				});
				break;
			}
			if (e.data.time.mode !== "relative") {
				n.set(a, be(e.data.time, [a]));
				break;
			}
			let s = e.data.time;
			if (!i.has(s.anchorEventId) && s.anchorEventId !== a) try {
				if (T(s.minOffset, s.maxOffset) > 0) {
					n.set(a, {
						status: "conflict",
						reason: "相対日時の範囲が逆転しています。",
						path: [a]
					});
					break;
				}
			} catch (e) {
				n.set(a, {
					status: "conflict",
					reason: e instanceof Error ? e.message : "日時を解決できません。",
					path: [a]
				});
				break;
			}
			i.set(a, r.length), r.push(a), a = s.anchorEventId;
		}
		for (let e = r.length - 1; e >= 0; e--) {
			let i = r[e], a = t.get(i);
			!n.has(i) && a.data.time.mode === "relative" && n.set(i, Se(a.data.time, n.get(a.data.time.anchorEventId), [i]));
		}
	}
	return n;
}
function Ee(e) {
	let t = [], n = Ce(e), r = Te(e);
	for (let e of n.values()) {
		let i = r.get(e.id);
		i.status === "conflict" && t.push({
			code: "TIME_CONSTRAINT_CONFLICT",
			path: `entities.${e.id}.data.time`,
			message: i.reason
		});
		for (let a of e.data.constraints ?? []) {
			let o = n.get(a.targetEventId);
			if (!o || i.status !== "resolved") continue;
			let s = r.get(o.id);
			if (s.status !== "resolved") continue;
			let c = i.calendarId !== s.calendarId;
			if (a.type === "before") c ||= i.mode === "interval" ? T(i.endEarliest, s.latest) > 0 : T(i.endEarliest, s.latest) >= 0;
			else if (a.type === "same_start") c ||= T(i.earliest, s.latest) > 0 || T(s.earliest, i.latest) > 0;
			else {
				let e = w(s.earliest) - w(i.endLatest), t = w(s.latest) - w(i.endEarliest);
				c ||= t < w(a.minimumTicks) || e > w(a.maximumTicks);
			}
			c && t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "指定した出来事の日時制約と矛盾しています。"
			});
		}
	}
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
	for (let e of n.values()) a.set(e.id, (e.data.constraints ?? []).map((e) => e.targetEventId));
	for (let e of n.values()) e.data.time.mode === "relative" && n.has(e.data.time.anchorEventId) && a.get(e.data.time.anchorEventId).push(e.id);
	for (let e of n.values()) {
		if (i.get(e.id)) continue;
		let r = [{
			id: e.id,
			targets: a.get(e.id),
			cursor: 0
		}];
		for (i.set(e.id, 1); r.length;) {
			let e = r[r.length - 1];
			if (e.cursor === e.targets.length) {
				i.set(e.id, 2), r.pop();
				continue;
			}
			let o = e.targets[e.cursor++], s = n.get(o);
			s && (i.get(o) === 1 ? t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "日時制約の依存が循環しています。"
			}) : i.has(o) || (i.set(o, 1), r.push({
				id: o,
				targets: a.get(s.id),
				cursor: 0
			})));
		}
	}
	return t;
}
function De(e, t) {
	return e.id !== t.id || e.kind !== t.kind || e.name !== t.name || e.originLabel !== t.originLabel || e.ticksPerDay !== t.ticksPerDay ? !1 : e.kind === "gregorian" || t.kind === "gregorian" ? e.kind === t.kind : e.years.length === t.years.length && e.years.every((e, n) => e.months.length === t.years[n].months.length && e.months.every((e, r) => e.name === t.years[n].months[r].name && e.days === t.years[n].months[r].days));
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/templates.ts
var E = (e, t, n = "VALIDATION_FAILED") => ({
	path: e,
	message: t,
	code: n
}), Oe = [
	"id",
	"projectId",
	"kind",
	"revision",
	"name",
	"status",
	"visibility",
	"retainIfUnreferenced",
	"projectionProfileId",
	"templateId",
	"createdAt",
	"updatedAt",
	"deletedAt",
	"deletionOperationId",
	"customValues",
	"data"
], ke = [
	"__proto__",
	"prototype",
	"constructor"
], Ae = [
	"text",
	"number",
	"boolean",
	"enum",
	"date",
	"ref"
];
function je(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = e;
	return typeof t.key == "string" && typeof t.label == "string" && Ae.includes(t.type) && typeof t.required == "boolean" && typeof t.nullable == "boolean" && (t.help == null || typeof t.help == "string") && (t.allowedValues == null || Array.isArray(t.allowedValues) && t.allowedValues.every((e) => typeof e == "string")) && (t.targetKinds == null || Array.isArray(t.targetKinds) && t.targetKinds.every((e) => Object.hasOwn(kt, e)));
}
function Me(e) {
	let t = kt[e];
	return [...Oe, ...t?.type === "object" ? Object.keys(t.fields) : []];
}
function Ne(e, t, n, r) {
	if (t === void 0) return e.required ? [E(n, `「${e.label}」は必須項目です。`)] : [];
	if (t === null) return e.nullable ? [] : [E(n, `「${e.label}」は空欄を許可していません。`)];
	let i = !1;
	if (e.type === "text" && (i = typeof t == "string" && (!e.required || t.trim().length > 0)), e.type === "number" && (i = typeof t == "number" && Number.isFinite(t)), e.type === "boolean" && (i = typeof t == "boolean"), e.type === "enum" && (i = typeof t == "string" && !!e.allowedValues?.includes(t)), e.type === "date" || e.type === "ref") {
		let a = t && typeof t == "object" && !Array.isArray(t) ? t : void 0;
		if (i = a?.type === e.type && typeof a.value == "string", i && e.type === "date") {
			let e = a.value, t = /^\d{4}-\d{2}-\d{2}$/.test(e) ? /* @__PURE__ */ new Date(`${e}T00:00:00.000Z`) : /* @__PURE__ */ new Date(NaN);
			i = Number.isFinite(t.getTime()) && t.toISOString().slice(0, 10) === e;
		}
		if (i && e.type === "ref") {
			let t = a.value;
			if (!Ve.test(t)) i = !1;
			else if (r) {
				let i = "get" in r ? r.get(t) : r.find((e) => e.id === t);
				if (!i || i.deletedAt || e.targetKinds?.length && !e.targetKinds.includes(i.kind)) return [E(n, `「${e.label}」の参照先が存在しないか、許可された種類ではありません。`, "REFERENCE_INVALID")];
			}
		}
	}
	return i ? [] : [E(n, `「${e.label}」の値が宣言した${e.type}型または選択候補と一致しません。`)];
}
function Pe(e, t = "data", n) {
	let r = [];
	if (!e || !Array.isArray(e.fields)) return [E(`${t}.fields`, "項目定義は配列で入力してください。")];
	Object.hasOwn(kt, e.targetKind) || r.push(E(`${t}.targetKind`, "対象の情報の種類を選んでください。")), e.defaults != null && (typeof e.defaults != "object" || Array.isArray(e.defaults)) && r.push(E(`${t}.defaults`, "初期値は項目キーごとの辞書で指定してください。"));
	let i = /* @__PURE__ */ new Set(), a = new Set(Me(e.targetKind));
	for (let [o, s] of e.fields.entries()) {
		let e = `${t}.fields[${o}]`;
		if (!je(s)) {
			r.push(E(e, "項目定義のキー・表示名・型・必須・空欄・説明・候補・参照先の形式を確認してください。"));
			continue;
		}
		(!s.key.trim() || i.has(s.key) || a.has(s.key) || ke.includes(s.key)) && r.push(E(`${e}.key`, "キーが空欄・重複・予約済み、または標準項目と衝突しています。")), i.add(s.key), s.type === "enum" && (!Array.isArray(s.allowedValues) || !s.allowedValues.length || s.allowedValues.some((e) => typeof e != "string" || !e.trim()) || new Set(s.allowedValues).size !== s.allowedValues.length) && r.push(E(`${e}.allowedValues`, "選択型には空欄と重複のない候補を指定してください。")), s.type !== "enum" && s.allowedValues?.length && r.push(E(`${e}.allowedValues`, "選択候補はenum型だけに設定できます。")), s.type !== "ref" && s.targetKinds?.length && r.push(E(`${e}.targetKinds`, "参照先の種類はref型だけに設定できます。")), Object.hasOwn(s, "default") ? r.push(...Ne(s, s.default, `${e}.default`, n)) : r.push(E(`${e}.default`, "項目の初期値を指定してください。"));
	}
	let o = e.fields.filter(je), s = e.defaults && typeof e.defaults == "object" && !Array.isArray(e.defaults) ? e.defaults : {};
	for (let [e, i] of Object.entries(s)) {
		let a = o.find((t) => t.key === e);
		a ? r.push(...Ne(a, i, `${t}.defaults.${e}`, n)) : r.push(E(`${t}.defaults.${e}`, "初期値のキーを項目定義へ追加してください。"));
	}
	return r;
}
function Fe(e, t = "project", n = e.entities) {
	let r = new Map(n.filter((e) => e.kind === "template").map((e) => [e.id, e])), i = [], a = new Map(n.map((e) => [e.id, e]));
	return e.entities.forEach((e, n) => {
		let o = e;
		if (e.deletedAt || !o.templateId) return;
		let s = `${t}.entities[${n}]`, c = r.get(o.templateId);
		if (!c || c.deletedAt || c.status === "rejected" || c.data.targetKind !== e.kind) {
			i.push(E(`${s}.templateId`, "適用した雛形が存在しない・不採用・削除済み、または対象の種類が異なります。", "REFERENCE_INVALID"));
			return;
		}
		for (let t of c.data.fields) i.push(...Ne(t, e.customValues[t.key], `${s}.customValues.${t.key}`, a));
	}), i;
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/model.ts
var Ie = {
	character: "人物",
	group: "グループ",
	event: "出来事",
	place: "場所",
	item: "物品",
	note: "メモ",
	chapter: "章",
	scene: "場面",
	goal: "目標",
	flow_node: "進行ノード",
	flow_edge: "進行線",
	flow_graph: "分岐図",
	dialogue_line: "台詞",
	quest: "クエスト",
	lore: "設定",
	variable: "状態変数",
	effect: "効果",
	assertion: "事実・認識",
	foreshadow: "伏線",
	disclosure: "手掛かり・回収",
	checkpoint: "途中開始点",
	trace: "試読記録",
	attachment: "添付素材",
	source: "資料・出所",
	cue: "演出",
	storyboard_frame: "絵コンテ",
	localization: "翻訳",
	recording: "収録",
	terminology: "用語",
	map: "地図",
	travel_route: "移動経路",
	template: "雛形",
	collection: "一覧",
	review: "レビュー",
	creative_brief: "企画",
	decision: "制作判断",
	gameplay_spec: "ゲーム仕様",
	production_task: "制作タスク",
	media_variant: "媒体版",
	voice_rule: "口調",
	external_contract: "外部契約",
	snapshot: "公開版",
	projection_profile: "公開投影"
}, D = Object.keys(Ie), Le = [
	"confirmed",
	"provisional",
	"needs_review",
	"rejected",
	"alternate"
], Re = [
	"scene",
	"chapter",
	"character",
	"run",
	"across_runs"
], ze = [
	{
		key: "trust",
		label: "信頼",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "causes",
		label: "因果",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "requires",
		label: "前提",
		fromKinds: D,
		toKinds: D,
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "foreshadow_payoff",
		label: "手掛かり→回収",
		fromKinds: ["disclosure"],
		toKinds: ["disclosure"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "parent_of",
		label: "親子",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_foreshadow",
		label: "出来事の予告",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_payoff",
		label: "出来事の回収",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "mentor_of",
		label: "師弟",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "bloodline",
		label: "血統",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "related",
		label: "関連",
		fromKinds: D,
		toKinds: D,
		allowSelf: !1,
		allowSymmetric: !0
	},
	{
		key: "reference",
		label: "参照",
		fromKinds: D,
		toKinds: D,
		allowSelf: !0,
		allowSymmetric: !1
	}
], Be = Object.fromEntries(ze.map((e) => [e.key, e.label])), Ve = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, He = /^(?:0|[1-9][0-9]*)$/, Ue = () => ({
	worldRange: null,
	routeCondition: null,
	presentationAnchor: null
}), We = () => crypto.randomUUID();
function Ge(e) {
	return e === "" ? [] : e.split("\n").map((e) => ({
		id: We(),
		kind: "paragraph",
		text: e
	}));
}
function Ke(e) {
	return (e ?? []).map((e) => e.text).join("\n");
}
function qe(e, t) {
	return e.entities.find((e) => e.id === t && !e.deletedAt);
}
function Je(e, t) {
	return e.entities.filter((e) => e.kind === t && !e.deletedAt);
}
function Ye(e) {
	let t = {
		type: "unknown",
		value: null,
		reason: "未入力"
	}, n = {
		character: {
			reading: "",
			aliases: [],
			summary: [],
			body: [],
			authorNotes: [],
			goals: [],
			voiceRules: []
		},
		group: {
			groupType: "display",
			members: [],
			parentId: null,
			summary: []
		},
		event: {
			summary: [],
			time: {
				mode: "unknown",
				reason: ""
			},
			laneRole: "common",
			participants: [],
			locationId: null,
			itemIds: [],
			authorNotes: [],
			constraints: []
		},
		place: {
			parentId: null,
			reading: "",
			aliases: [],
			body: [],
			mapIds: [],
			changes: []
		},
		item: {
			itemMode: "type",
			typeId: null,
			body: [],
			properties: null,
			changes: []
		},
		note: {
			body: [],
			attachmentIds: [],
			convertedToIds: [],
			originNoteId: null
		},
		chapter: {
			sceneIds: [],
			summary: [],
			authorNotes: [],
			structureRole: ""
		},
		scene: {
			summary: [],
			body: [],
			authorNotes: [],
			eventIds: [],
			chapterId: null,
			threadIds: [],
			povId: null,
			goals: [],
			conflicts: [],
			results: [],
			newInformation: [],
			tension: null,
			importance: null,
			blockIds: []
		},
		goal: {
			ownerId: null,
			description: [],
			changes: [],
			evidenceSceneIds: [],
			validity: Ue()
		},
		flow_node: {
			nodeType: "choice",
			sceneId: null,
			childGraphId: null,
			terminalReason: "",
			gate: {
				op: "constant",
				value: !0
			},
			executionPolicy: "manual_choice",
			fallbackId: null
		},
		flow_edge: {
			fromId: null,
			toId: { unresolved: {
				label: "",
				reason: "未完成"
			} },
			edgeType: "choice",
			label: "",
			condition: {
				op: "constant",
				value: !0
			},
			effectIds: [],
			priority: 0,
			choiceLineId: null
		},
		flow_graph: {
			nodeIds: [],
			edgeIds: [],
			entryIds: [],
			exitIds: [],
			parentGraphId: null,
			parameters: []
		},
		dialogue_line: {
			text: [],
			speakerId: null,
			choiceEdgeId: null,
			cueIds: [],
			originLineIds: []
		},
		quest: {
			key: "",
			stateVariableId: null,
			description: [],
			flowIds: [],
			transitionRules: [],
			gameplaySpecIds: []
		},
		lore: {
			body: [],
			assertionIds: [],
			sourceIds: [],
			reading: "",
			aliases: []
		},
		variable: {
			key: "",
			valueType: "boolean",
			scope: "run",
			initial: t,
			allowed: { values: [!1, !0] },
			description: [],
			ownerId: null,
			externalContractId: null,
			resetRules: [],
			transitionRules: [],
			externalUseDeclared: !1
		},
		effect: {
			operation: "set",
			targetId: null,
			value: t,
			condition: {
				op: "constant",
				value: !0
			},
			instanceId: null,
			reason: ""
		},
		assertion: {
			subjectId: null,
			predicate: "",
			value: t,
			truthKind: "author_truth",
			holderId: null,
			sourceIds: [],
			evidenceLocation: null,
			validity: Ue(),
			reason: ""
		},
		foreshadow: {
			question: [],
			intent: [],
			resolutionPolicy: "undecided",
			truthAssertionIds: [],
			clueIds: [],
			payoffIds: [],
			requiredInfo: [],
			deadline: null,
			exceptions: []
		},
		disclosure: {
			foreshadowId: null,
			anchor: { entityId: null },
			stage: "hint",
			role: "clue",
			condition: {
				op: "constant",
				value: !0
			},
			knowledgeEffects: [],
			targetScope: null
		},
		checkpoint: {
			contentVersionId: null,
			runtimeState: Qe(""),
			origin: "partial",
			traceId: null
		},
		trace: {
			contentVersionId: null,
			startCheckpointId: null,
			steps: [],
			seed: "",
			engineVersion: "1.0.0",
			externalMode: "stub"
		},
		attachment: {
			mediaType: "",
			contentHash: "",
			byteSize: 0,
			assetPath: "",
			displayName: "",
			stage: "reference",
			revisionHistory: []
		},
		source: {
			sourceType: "web",
			locator: "",
			accessedAt: null,
			excerptLocation: "",
			interpretation: [],
			attachmentId: null,
			redistributionAllowed: !1
		},
		cue: {
			anchor: { entityId: null },
			cueType: "",
			attachmentId: null,
			speakerId: null,
			expression: "",
			waitMs: null,
			camera: null,
			mediaTime: null,
			stage: ""
		},
		storyboard_frame: {
			anchor: { entityId: null },
			mediaStartMs: 0,
			mediaEndMs: null,
			referenceAssetId: null,
			finalAssetId: null,
			cueIds: [],
			caption: []
		},
		localization: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			text: [],
			stage: "draft",
			reviewedBy: null,
			recordingIds: []
		},
		recording: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			translationId: null,
			attachmentId: null,
			notes: [],
			stage: "planned",
			reviewedBy: null
		},
		terminology: {
			canonical: "",
			reading: "",
			variants: [],
			language: null,
			usageNotes: [],
			validity: Ue(),
			exceptions: [],
			voiceOwnerId: null
		},
		map: {
			placeId: null,
			coordinateSystem: "normalized",
			attachmentId: null,
			parentMapId: null,
			pins: []
		},
		travel_route: {
			fromPlaceId: null,
			toPlaceId: null,
			direction: "one_way",
			method: "",
			minimumTicks: null,
			maximumTicks: null,
			evidence: [],
			validity: Ue()
		},
		template: {
			targetKind: "character",
			fields: [],
			description: "",
			version: "0",
			defaults: {}
		},
		collection: {
			mode: "fixed",
			memberIds: [],
			query: null,
			sort: {
				field: "name",
				direction: "asc"
			}
		},
		review: {
			target: null,
			targetVersionId: null,
			body: [],
			stage: "open",
			assigneeId: null,
			quotedText: "",
			resolution: []
		},
		creative_brief: {
			targetAudience: [],
			experience: [],
			theme: [],
			tone: [],
			scope: [],
			deliverableIds: [],
			decisionIds: []
		},
		decision: {
			subject: "",
			reason: [],
			targetVersionId: null,
			outcome: "deferred",
			priority: "",
			requirementIds: [],
			reviewIds: []
		},
		gameplay_spec: {
			sceneId: null,
			action: [],
			mechanic: "",
			tutorial: [],
			reward: null,
			questId: null,
			taskIds: [],
			intentionalDifference: ""
		},
		production_task: {
			targetIds: [],
			stage: "writing",
			progress: "todo",
			assigneeId: null,
			deadline: null,
			dependsOn: [],
			estimate: null,
			blockingReason: ""
		},
		media_variant: {
			medium: "novel",
			baseSnapshotId: null,
			body: [],
			releaseAt: null,
			projectionProfileId: null,
			sourceIds: [],
			needsReview: !1
		},
		voice_rule: {
			characterId: null,
			validity: Ue(),
			firstPerson: "",
			addressing: "",
			phrasing: "",
			examples: [],
			exceptions: []
		},
		external_contract: {
			key: "",
			owner: "tool",
			inputType: "boolean",
			outputType: "boolean",
			missingPolicy: "unknown",
			description: [],
			stubValues: [],
			adapterProfileIds: [],
			version: "1.0.0"
		},
		snapshot: {
			versionLabel: "",
			contentHash: "",
			immutable: !0,
			parentVersionIds: [],
			releasedAt: null,
			referencedWorldVersionIds: []
		},
		projection_profile: {
			audience: "",
			includedIds: [],
			namePolicy: { mode: "exclude" },
			allowedKinds: [],
			excludedFields: ["authorNotes"],
			routeScope: null,
			includeAuthorNotes: !1,
			publicTitle: "",
			publicTexts: {},
			allowedRelationIds: [],
			idPolicy: "remap"
		}
	};
	if (!(e in n)) throw RangeError("未対応の情報種別です。");
	return n[e];
}
function Xe(e, t, n = "", r) {
	let i = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: We(),
		projectId: e,
		kind: t,
		revision: "0",
		name: n,
		status: "provisional",
		visibility: "private",
		createdAt: i,
		updatedAt: i,
		customValues: {},
		data: {
			...Ye(t),
			...r
		}
	};
}
function Ze(e = "新しい作品") {
	return {
		projectId: We(),
		name: e,
		formatVersion: fe,
		revision: "0",
		calendarId: he.id,
		mainStart: "0",
		calendars: [structuredClone(he)],
		worldReferences: [],
		entities: [],
		relations: [],
		snapshots: [],
		history: [],
		views: []
	};
}
function Qe(e) {
	return {
		contentVersionId: e,
		variableValues: {},
		itemInstances: [],
		assertions: [],
		seenIds: [],
		visitCounts: {},
		onceTriggers: [],
		rngSeed: "scenario-1",
		rngPosition: 0,
		callStack: [],
		presentationPosition: null,
		loopNumber: 0,
		provenance: "full_play"
	};
}
var O = (e = 0, t) => ({
	type: "text",
	min: e,
	max: t,
	maxBytes: 1048576
}), k = O(0, 128), $e = O(1, 128), A = (e, t, n = !1) => ({
	type: "number",
	min: e,
	max: t,
	integer: n
}), j = { type: "boolean" }, M = { type: "id" }, N = { type: "tick" }, P = { type: "typed" }, F = (...e) => ({
	type: "enum",
	values: e
}), I = (...e) => ({
	type: "ref",
	kinds: e.length ? e : void 0,
	scope: "entity"
}), L = (e) => ({
	type: "ref",
	scope: e
}), R = (e, t = !1, n, r) => ({
	type: "array",
	item: e,
	unique: t,
	min: n,
	max: r
}), z = (...e) => R(I(...e), !0), B = (e) => ({
	type: "object",
	fields: e
}), V = (e) => ({
	schema: e,
	required: !0
}), H = (e) => ({
	schema: e,
	nullable: !0
}), et = (e) => ({
	schema: e,
	nullable: !1
}), U = { type: "richtext" }, tt = {
	type: "richtext",
	max: 2048
}, nt = { type: "condition" }, rt = { type: "time" }, W = (e, t) => ({
	type: "record",
	value: e,
	key: t
}), it = (...e) => ({
	type: "union",
	choices: e
}), G = B({
	entityId: V(I()),
	blockId: H(L("block")),
	lineId: H(I("dialogue_line")),
	start: H(A(0, void 0, !0)),
	end: H(A(0, void 0, !0)),
	sourceVersionId: H(L("snapshot")),
	positionStatus: H(F("unresolved")),
	positionReason: H(O(1)),
	quotedText: H(O())
}), at = it(B({
	kind: V(F("ruby")),
	originalText: V(O()),
	reason: V(O(1)),
	reading: V(O())
}), B({
	kind: V(F("link")),
	originalText: V(O()),
	reason: V(O(1)),
	target: V(G)
})), ot = B({
	worldRange: {
		schema: B({
			start: {
				schema: N,
				required: !0,
				nullable: !0
			},
			end: {
				schema: N,
				required: !0,
				nullable: !0
			}
		}),
		required: !0,
		nullable: !0
	},
	routeCondition: {
		schema: nt,
		required: !0,
		nullable: !0
	},
	presentationAnchor: {
		schema: G,
		required: !0,
		nullable: !0
	}
}), st = B({
	projectId: V(L("project")),
	graphId: H(I("flow_graph")),
	chapterId: H(I("chapter")),
	routeCondition: H(nt),
	targetSnapshotId: H(L("snapshot"))
}), ct = B({
	id: V(M),
	text: V(O(1, 128)),
	reading: V(k),
	validity: V(ot),
	audienceHolderIds: V(z("character")),
	isPublicDefault: V(j)
}), lt = B({
	reason: V(O(1)),
	targetScope: V(st),
	validity: V(ot),
	evidenceIds: V(z())
}), ut = B({
	from: V(P),
	to: V(P),
	reason: H(O()),
	exception: H(j),
	exceptionDetails: H(lt)
}), dt = B({
	on: V(F("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
	value: V(P),
	reason: H(O())
}), ft = B({
	min: H(A(void 0, void 0, !0)),
	max: H(A(void 0, void 0, !0)),
	values: H(R(it(O(), j), !0))
}), pt = B({
	id: H(M),
	event: V(F("enter", "talk", "battle_result", "manual", "custom")),
	eventKey: V(O()),
	repeat: V(F("once", "repeatable")),
	scope: H(F(...Re)),
	deadline: H(rt)
}), mt = B({
	mode: V(F("reference", "clone", "override")),
	sourceId: V(I()),
	pinnedSnapshotId: V(L("snapshot")),
	overrideFields: V(R(O(1), !0)),
	bindings: H(W(M, M))
}), ht = B({ unresolved: V(B({
	label: V(O()),
	reason: V(O(1))
})) }), gt = B({
	instanceId: V(M),
	typeId: V(I("item")),
	quantity: V(A(0, void 0, !0)),
	ownerId: H(I("character", "group")),
	locationId: H(I("place")),
	consumed: V(j),
	reason: H(O())
}), _t = B({
	assertionId: V(I("assertion")),
	holderId: H(I("character")),
	truth: V(F("true", "false", "unknown")),
	sourceEffectId: H(I("effect"))
}), vt = B({
	targetId: V(I("flow_node", "flow_edge", "disclosure")),
	value: V(F("true", "false", "unknown")),
	reasons: V(R(O()))
}), yt = B({
	graphId: V(I("flow_graph")),
	returnNodeId: V(I("flow_node")),
	parameters: V(W(P, $e))
}), bt = B({
	contentVersionId: V(L("snapshot")),
	variableValues: V(W(P, I("variable"))),
	itemInstances: V(R(gt)),
	assertions: V(R(_t)),
	seenIds: V(R(L("presentation"), !0)),
	visitCounts: V(W(A(0, void 0, !0), I())),
	onceTriggers: V(R(O(1), !0)),
	rngSeed: V(O(1)),
	rngPosition: V(A(0, void 0, !0)),
	callStack: V(R(yt)),
	presentationPosition: H(I("flow_node")),
	loopNumber: V(A(0, void 0, !0)),
	provenance: V(F("full_play", "partial", "imported", "stub")),
	resetCauses: H(R(B({
		variableId: V(I("variable")),
		on: V(F("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
		before: V(P),
		after: V(P),
		reason: V(O())
	})))
}), xt = B({
	entityId: V(I("scene")),
	occurrenceId: V(O(1, 256)),
	before: V(bt),
	after: V(bt),
	presentationState: H(bt),
	conditionResults: V(R(vt)),
	externalValues: H(W(P, I("external_contract"))),
	worldTick: H(N)
}), St = B({
	chapterIds: V(z("chapter")),
	sceneIds: V(R(I("scene"))),
	selection: H(F("chapters", "scenes")),
	occurrences: V(R(xt))
}), Ct = B({
	checked: V(A(0, void 0, !0)),
	total: V(A(0, void 0, !0))
}), wt = B({
	byProvenance: H(W(Ct, F("full_play", "partial", "imported", "stub"))),
	byExternalMode: H(W(Ct, F("internal", "stub", "actual", "mixed"))),
	checked: V(A(0, void 0, !0)),
	total: V(A(0, void 0, !0)),
	excluded: H(A(0, void 0, !0)),
	unknown: H(A(0, void 0, !0))
}), Tt = B(Object.fromEntries([
	"scenes",
	"dialogue",
	"choices",
	"conditionTrue",
	"conditionFalse",
	"declaredTests"
].map((e) => [e, V(wt)]))), Et = B({
	key: V($e),
	label: V(O(1, 128)),
	type: V(F("text", "number", "boolean", "enum", "date", "ref")),
	required: V(j),
	nullable: V(j),
	default: {
		schema: { type: "custom" },
		required: !0,
		nullable: !0
	},
	allowedValues: H(R(O(), !0)),
	targetKinds: H(R(F(...D), !0)),
	help: H(O())
}), Dt = B({
	value: H(A(0)),
	range: H(B({
		min: V(A(0)),
		max: V(A(0))
	})),
	unit: V(O(1)),
	assumptions: V(R(O())),
	scope: V(st),
	unknownCount: V(A(0, void 0, !0)),
	source: V(O()),
	speed: H(A(Number.MIN_VALUE))
}), Ot = B({
	...Object.fromEntries([
		"summary",
		"body",
		"text",
		"description",
		"question",
		"intent",
		"caption",
		"usageNotes",
		"interpretation",
		"examples",
		"action",
		"tutorial"
	].map((e) => [e, H(U)])),
	...Object.fromEntries((/* @__PURE__ */ "label.reading.terminalReason.reason.key.canonical.language.locale.sourceHash.expression.method.locator.predicate.cueType.precision.displayName.relationType.eventKey.resetReason.exclusionReason.exceptionReason.camera.parameters.variants.estimateAssumptions.estimateSource.blockingReason.mechanic.intentionalDifference.excerptLocation.estimateUnit.firstPerson.addressing.phrasing".split(".")).map((e) => [e, H(O())]))
}), kt = {
	character: B({
		reading: H(k),
		aliases: H(R(ct)),
		summary: H(tt),
		body: H(U),
		authorNotes: H(U),
		birth: H(rt),
		death: H(rt),
		goals: H(z("goal")),
		voiceRules: H(z("voice_rule"))
	}),
	group: B({
		groupType: V(F("display", "faction", "plot_thread", "category")),
		members: H(z()),
		parentId: H(I("group")),
		summary: H(tt)
	}),
	event: B({
		summary: V(tt),
		time: V(rt),
		laneRole: V(F("common", "participants", "both")),
		participants: H(R(B({
			characterId: V(I("character")),
			role: V(F("actor", "witness", "mentioned", "informed", "custom")),
			evidenceIds: H(z()),
			knowledgeEffectIds: H(z("effect"))
		}))),
		locationId: H(I("place")),
		itemIds: H(z("item")),
		authorNotes: H(U),
		constraints: H(R(it(B({
			type: V(F("before", "same_start")),
			targetEventId: V(I("event"))
		}), B({
			type: V(F("end_gap")),
			targetEventId: V(I("event")),
			minimumTicks: V(N),
			maximumTicks: V(N)
		}))))
	}),
	place: B({
		parentId: H(I("place")),
		reading: H(k),
		aliases: H(R(ct)),
		body: H(U),
		mapIds: H(z("map")),
		changes: H(z("assertion"))
	}),
	item: B({
		itemMode: V(F("type", "instance")),
		typeId: H(I("item")),
		body: H(U),
		properties: H({ type: "custom" }),
		changes: H(z("assertion"))
	}),
	note: B({
		handoffReceipt: H(B({
			approval: V(B({
				entityId: V(L("entity")),
				sourceVersionId: V(L("snapshot"))
			})),
			sourceVersionId: V(L("snapshot")),
			verificationVersionId: V(L("snapshot")),
			profileVersionId: V(L("snapshot")),
			sourceRevision: V({ type: "revision" }),
			profileId: V(I("projection_profile")),
			packageHash: V({ type: "hash" }),
			receiptHash: V({ type: "hash" }),
			mode: V(F("stub", "actual", "mixed")),
			rawJson: V(O(1, 1048576)),
			idMappings: V(R(B({
				entityId: V(L("record")),
				sourceVersionId: V(L("snapshot")),
				publicId: V(O(1, 256))
			}))),
			projectionBindings: V(R(B({
				entityId: V(L("projection_record")),
				sourceVersionId: V(L("snapshot")),
				editionVersionId: V(L("snapshot")),
				publicId: V(O(1, 256))
			}))),
			citationBindings: V(R(B({
				sourceVersionId: V(L("snapshot")),
				publicVersionId: V(O(1, 256))
			}))),
			worldVersions: V(R(B({
				sourceVersionId: V(L("snapshot")),
				contentHash: V({ type: "hash" })
			})))
		})),
		body: V(U),
		attachmentIds: H(z("attachment")),
		convertedToIds: H(z()),
		originNoteId: H(I("note"))
	}),
	chapter: B({
		sceneIds: V(z("scene")),
		summary: H(tt),
		authorNotes: H(U),
		structureRole: H(k)
	}),
	scene: B({
		summary: V(tt),
		body: V(U),
		authorNotes: V(U),
		eventIds: V(z("event")),
		dialogueLineIds: H(z("dialogue_line")),
		chapterId: H(I("chapter")),
		threadIds: H(z("group")),
		povId: H(I("character")),
		goals: H(U),
		conflicts: H(U),
		results: H(U),
		newInformation: H(U),
		tension: H(A(0, 10)),
		importance: H(A(0, 10)),
		blockIds: H(R(L("block"), !0)),
		reuse: H(mt)
	}),
	goal: B({
		ownerId: V(I("character", "group")),
		description: V(U),
		changes: H(z("assertion")),
		evidenceSceneIds: H(z("scene")),
		validity: H(ot)
	}),
	flow_node: B({
		nodeType: V(F("scene", "choice", "automatic", "call", "entry", "exit", "terminal")),
		sceneId: H(I("scene")),
		childGraphId: H(I("flow_graph")),
		terminalReason: H(O()),
		trigger: H(pt),
		gate: H(nt),
		executionPolicy: H(F("manual_choice", "first_match", "all_match")),
		fallbackId: H(I("flow_node")),
		reuse: H(mt)
	}),
	flow_edge: B({
		fromId: V(I("flow_node")),
		toId: V(it(I("flow_node"), ht)),
		edgeType: V(F("choice", "automatic", "call_return")),
		label: H(O()),
		condition: H(nt),
		effectIds: H(z("effect")),
		priority: H(A(void 0, void 0, !0)),
		choiceLineId: H(I("dialogue_line"))
	}),
	flow_graph: B({
		nodeIds: V(z("flow_node")),
		edgeIds: V(z("flow_edge")),
		entryIds: V(z("flow_node")),
		exitIds: V(z("flow_node")),
		parentGraphId: H(I("flow_graph")),
		parameters: H(R(B({
			key: V($e),
			type: V(F("boolean", "integer", "enum")),
			default: H(P)
		})))
	}),
	dialogue_line: B({
		text: V(U),
		speakerId: H(I("character")),
		choiceEdgeId: H(I("flow_edge")),
		cueIds: H(z("cue")),
		originLineIds: H(z("dialogue_line")),
		replacedByLineIds: H(z("dialogue_line")),
		lineage: H(B({
			mode: V(F("split", "merge", "copy")),
			baseRevision: V({ type: "revision" }),
			reason: V(O(1)),
			segments: V(R(B({
				source: V(G),
				target: V(G)
			}), !1, 1))
		})),
		claimAssertionIds: H(z("assertion")),
		assertionIntent: H(F("statement", "lie", "misunderstanding", "quotation")),
		assertionReason: H(O())
	}),
	quest: B({
		key: V($e),
		stateVariableId: V(I("variable")),
		description: H(U),
		flowIds: H(z("flow_graph")),
		transitionRules: H(R(ut)),
		gameplaySpecIds: H(z("gameplay_spec"))
	}),
	lore: B({
		body: V(U),
		assertionIds: H(z("assertion")),
		sourceIds: H(z("source")),
		reading: H(k),
		aliases: H(R(ct))
	}),
	variable: B({
		key: V($e),
		valueType: V(F("boolean", "integer", "enum")),
		scope: V(F(...Re)),
		initial: V(P),
		allowed: V(ft),
		description: H(U),
		ownerId: H(I("character")),
		derived: H({ type: "expression" }),
		externalContractId: H(I("external_contract")),
		resetRules: H(R(dt)),
		transitionRules: H(R(ut)),
		exclusions: H(R(B({
			variableId: V(I("variable")),
			value: V(P),
			otherValue: V(P),
			reason: V(O(1)),
			exceptions: H(R(lt))
		}))),
		externalUseDeclared: H(j)
	}),
	effect: B({
		operation: V(F("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset")),
		targetId: V(I()),
		value: H(P),
		condition: H(nt),
		instanceId: H(I("item")),
		reason: H(O()),
		exceptionDetails: H(lt)
	}),
	assertion: B({
		subjectId: V(I()),
		predicate: V(O(1, 128)),
		value: V(it(P, I())),
		truthKind: V(F("author_truth", "testimony", "belief", "hypothesis")),
		holderId: H(I("character")),
		sourceIds: H(z("source", "assertion", "event", "scene", "dialogue_line")),
		evidenceLocation: H(G),
		validity: H(ot),
		reason: H(O())
	}),
	foreshadow: B({
		question: V(U),
		intent: V(U),
		resolutionPolicy: V(F("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
		truthAssertionIds: H(z("assertion")),
		clueIds: H(z("disclosure")),
		payoffIds: H(z("disclosure")),
		requiredInfo: H(z("disclosure", "assertion")),
		alternativeInfo: H(W(z("disclosure", "assertion"), I("disclosure", "assertion"))),
		deadline: H(st),
		presentationDeadline: H(G),
		exceptions: H(R(lt))
	}),
	disclosure: B({
		foreshadowId: V(I("foreshadow")),
		anchor: V(G),
		stage: V(F("hint", "suspicion", "reinforce", "reveal", "alternative")),
		role: V(F("clue", "payoff")),
		condition: H(nt),
		knowledgeEffects: H(z("effect")),
		targetScope: H(st)
	}),
	checkpoint: B({
		worldTick: H(N),
		contentVersionId: V(L("snapshot")),
		runtimeState: V(bt),
		presentationState: H(bt),
		presentationResults: H(R(vt)),
		contentRevision: H({ type: "revision" }),
		origin: H(F("full_play", "partial", "imported")),
		traceId: H(I("trace")),
		migration: H(B({
			sourceCheckpointId: V(I("checkpoint")),
			sourceVersionId: V(L("snapshot")),
			baseRevision: V({ type: "revision" }),
			method: V(F("migrate", "recreate"))
		}))
	}),
	trace: B({
		contentVersionId: V(L("snapshot")),
		startCheckpointId: V(I("checkpoint")),
		steps: V(R(B({
			nodeId: V(I("flow_node")),
			edgeIds: V(z("flow_edge")),
			before: V(bt),
			after: V(bt),
			presentationState: H(bt),
			conditionResults: H(R(vt)),
			operation: H(F("advance", "stub")),
			occurrenceId: H(O()),
			worldTick: H(N),
			externalMode: H(F("stub", "actual", "mixed")),
			externalValues: H(W(P, I("external_contract")))
		}))),
		contentRevision: H({ type: "revision" }),
		initialExternalValues: H(W(P, I("external_contract"))),
		initialStubBaseState: H(bt),
		initialStubValues: H(B({
			variables: H(W(P, I("variable"))),
			external: H(W(P, I("external_contract")))
		})),
		initialWorldTick: H(N),
		seed: H(O()),
		engineVersion: H(O()),
		externalMode: H(F("stub", "actual", "mixed")),
		coverage: H(Tt),
		regressionDeclarations: H(B({
			projectRevision: V({ type: "revision" }),
			traceIds: V(z("trace"))
		})),
		reconfirmation: H(B({
			sourceTraceId: V(I("trace")),
			sourceVersionId: V(L("snapshot")),
			baseRevision: V({ type: "revision" }),
			startCheckpointId: H(I("checkpoint"))
		})),
		mode: H(F("flow", "chapters", null)),
		readingPath: H(it(St, F(null)))
	}),
	attachment: B({
		mediaType: V(O(1, 128)),
		contentHash: V({ type: "hash" }),
		byteSize: V(A(0, 33554432, !0)),
		assetPath: V({ type: "safe_path" }),
		displayName: H(O()),
		provenanceId: H(I("source")),
		licenseNote: H(O()),
		stage: H(F("reference", "temporary", "final")),
		revisionHistory: H(z("attachment"))
	}),
	source: B({
		sourceType: V(F("web", "file", "book", "observation")),
		locator: V(O(1)),
		accessedAt: H({ type: "datetime" }),
		excerptLocation: H(O()),
		interpretation: H(U),
		attachmentId: H(I("attachment")),
		redistributionAllowed: H(j)
	}),
	cue: B({
		anchor: V(G),
		cueType: V(O(1, 128)),
		attachmentId: H(I("attachment")),
		speakerId: H(I("character")),
		expression: H(O()),
		waitMs: H(A(0, void 0, !0)),
		camera: H({ type: "custom" }),
		mediaTime: H(A(0, void 0, !0)),
		stage: H(k)
	}),
	storyboard_frame: B({
		anchor: V(G),
		mediaStartMs: V(A(0, void 0, !0)),
		mediaEndMs: H(A(0, void 0, !0)),
		referenceAssetId: H(I("attachment")),
		finalAssetId: H(I("attachment")),
		cueIds: H(z("cue")),
		caption: H(U)
	}),
	localization: B({
		sourceLineId: V(I("dialogue_line")),
		language: V(O(1, 128)),
		sourceHash: V({ type: "hash" }),
		text: V(U),
		stage: H(F("draft", "reviewed", "needs_review")),
		reviewedBy: H(L("identity")),
		recordingIds: H(z("recording"))
	}),
	recording: B({
		sourceLineId: V(I("dialogue_line")),
		language: V(O(1, 128)),
		sourceHash: V({ type: "hash" }),
		translationId: H(I("localization")),
		attachmentId: H(I("attachment")),
		notes: H(U),
		stage: H(F("planned", "recorded", "reviewed", "needs_review")),
		reviewedBy: H(L("identity"))
	}),
	terminology: B({
		canonical: V(O(1, 128)),
		reading: V(k),
		variants: H(R(k, !0)),
		language: H(k),
		usageNotes: H(U),
		validity: H(ot),
		exceptions: H(R(lt)),
		voiceOwnerId: H(I("character"))
	}),
	map: B({
		placeId: V(I("place")),
		coordinateSystem: V(F("normalized")),
		attachmentId: H(I("attachment")),
		parentMapId: H(I("map")),
		pins: H(R(B({
			id: V(M),
			placeId: V(I("place")),
			x: V(A(0, 1)),
			y: V(A(0, 1)),
			label: H(O())
		})))
	}),
	travel_route: B({
		fromPlaceId: V(I("place")),
		toPlaceId: V(I("place")),
		direction: V(F("one_way", "two_way")),
		method: H(O()),
		minimumTicks: H(N),
		maximumTicks: H(N),
		evidence: H(z()),
		validity: H(ot)
	}),
	template: B({
		targetKind: V(F(...D)),
		fields: V(R(Et)),
		description: H(O()),
		version: H({ type: "revision" }),
		defaults: H(W({ type: "custom" }, $e))
	}),
	collection: B({
		purpose: H(F("regression")),
		mode: V(F("dynamic", "fixed")),
		query: H({ type: "query" }),
		memberIds: H(z()),
		sort: H(B({
			field: V(F("name", "createdAt", "updatedAt", "kind")),
			direction: V(F("asc", "desc"))
		}))
	}),
	review: B({
		target: V(it(G, I())),
		targetVersionId: V(L("snapshot")),
		body: V(U),
		stage: V(F("open", "fixed", "verified")),
		assigneeId: H(L("identity")),
		quotedText: H(O()),
		resolution: H(U),
		sharedSource: H(B({
			connection: V(O(1)),
			sharedSnapshot: V(O(1)),
			comment: V(O(1)),
			publicVersion: V(O(1)),
			publicEntity: H(O(1)),
			publicRelation: H(O(1)),
			publicBlock: H(O(1)),
			startCp: H(A(0, void 0, !0)),
			endCp: H(A(0, void 0, !0)),
			projectionHash: V(O(64, 64)),
			commentBodyHash: V(O(64, 64)),
			quotedText: V(O()),
			observedStage: V(F("open", "fixed", "verified"))
		}))
	}),
	creative_brief: B({
		targetAudience: V(U),
		experience: V(U),
		theme: V(U),
		tone: V(U),
		scope: V(U),
		deliverableIds: H(z()),
		decisionIds: H(z("decision"))
	}),
	decision: B({
		subject: V(O(1)),
		reason: V(U),
		targetVersionId: V(L("snapshot")),
		outcome: V(F("accepted", "rejected", "deferred")),
		priority: H(k),
		requirementIds: H(R(k, !0)),
		reviewIds: H(z("review"))
	}),
	gameplay_spec: B({
		sceneId: V(I("scene")),
		action: V(U),
		mechanic: H(O()),
		tutorial: H(U),
		reward: H(P),
		questId: H(I("quest")),
		taskIds: H(z("production_task")),
		intentionalDifference: H(O())
	}),
	production_task: B({
		targetIds: V(z()),
		stage: V(F("writing", "review", "implementation", "translation", "recording", "verification", "publication")),
		progress: V(F("todo", "doing", "done", "needs_review")),
		assigneeId: H(L("identity")),
		deadline: H(B({
			date: V({ type: "date" }),
			timeZone: V(O(1, 128))
		})),
		dependsOn: H(z("production_task")),
		estimate: H(Dt),
		blockingReason: H(O())
	}),
	media_variant: B({
		previousVariantId: H(I("media_variant")),
		confirmationRecipientIds: H(R(L("identity"), !0)),
		medium: V(F("game", "novel", "video", "audio", "promotion", "custom")),
		baseSnapshotId: V(L("snapshot")),
		body: H(U),
		releaseAt: H({ type: "datetime" }),
		projectionProfileId: H(I("projection_profile")),
		sourceIds: H(z()),
		needsReview: H(j)
	}),
	voice_rule: B({
		characterId: V(I("character")),
		validity: V(ot),
		firstPerson: H(k),
		addressing: H(O()),
		phrasing: H(O()),
		examples: H(U),
		exceptions: H(R(lt))
	}),
	external_contract: B({
		key: V($e),
		owner: V(F("tool", "game")),
		inputType: V(O(1, 128)),
		outputType: V(O(1, 128)),
		missingPolicy: V(F("unknown", "block")),
		description: H(U),
		stubValues: H(R(P)),
		adapterProfileIds: H(z("projection_profile")),
		version: H(k)
	}),
	snapshot: B({
		versionLabel: V(O(1, 128)),
		contentHash: V({ type: "hash" }),
		immutable: V(F(!0)),
		parentVersionIds: H(R(L("snapshot"), !0)),
		releasedAt: H({ type: "datetime" }),
		referencedWorldVersionIds: H(R(L("snapshot"), !0))
	}),
	projection_profile: B({
		blockSources: H(W(L("block"), L("projection_record"))),
		citedVersions: H(R(B({
			sourceVersionId: V(L("snapshot")),
			profileId: V(I("projection_profile")),
			publicVersionId: V(M)
		}))),
		audience: V(O(1, 128)),
		includedIds: V(z()),
		namePolicy: V({ type: "name_policy" }),
		allowedKinds: H(R(F(...D), !0)),
		excludedFields: H(R(O(1), !0)),
		routeScope: H(st),
		includeAuthorNotes: H(j),
		publicTitle: H(O()),
		publicTexts: H(W(Ot, L("record"))),
		allowedFields: H(W(R(O(1), !0), F(...D))),
		allowedRelationIds: H(R(L("relation"), !0)),
		idPolicy: H(F("remap", "preserve")),
		publicIds: H(W(M, L("projection_record"))),
		sourceVersionId: H(L("snapshot")),
		publicValues: H(W(W(O(), O()), I("variable", "external_contract", "assertion"))),
		includedStatuses: H(R(F(...Le), !0)),
		publicVersionLabel: H(O()),
		approvedAttachmentIds: H(z("attachment"))
	})
}, K = (e) => !!e && typeof e == "object" && !Array.isArray(e) && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null), At = new TextEncoder(), jt = (e) => At.encode(e).byteLength;
function Mt(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++, t++) {
		let t = e.charCodeAt(n), r = e.charCodeAt(n + 1);
		t >= 55296 && t <= 56319 && r >= 56320 && r <= 57343 && n++;
	}
	return t;
}
function Nt(e) {
	for (let t = 0; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(++t);
			if (!(n >= 56320 && n <= 57343)) return !1;
		} else if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function q(e, t, n, r = "VALIDATION_FAILED") {
	e.length < 256 && e.push({
		code: r,
		path: t,
		message: n
	});
}
function Pt(e) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(e)) return !1;
	let t = /* @__PURE__ */ new Date(`${e}T00:00:00Z`);
	return Number.isFinite(t.getTime()) && t.toISOString().slice(0, 10) === e;
}
function Ft(e) {
	switch (e.op) {
		case "constant": return B({
			op: V(F("constant")),
			value: V(j)
		});
		case "all":
		case "any": return B({
			op: V(F("all", "any")),
			children: V(R(nt, !1, 1, 256))
		});
		case "not": return B({
			op: V(F("not")),
			child: V(nt)
		});
		case "compare": return B({
			op: V(F("compare")),
			variableId: V(I("variable")),
			comparator: V(F("eq", "ne", "lt", "le", "gt", "ge", "in")),
			value: V(e.comparator === "in" ? R(P, !1, 1, 256) : P)
		});
		case "item": return B({
			op: V(F("item")),
			itemId: V(I("item")),
			quantity: V(A(1, void 0, !0))
		});
		case "known": return B({
			op: V(F("known")),
			assertionId: V(I("assertion")),
			holderId: V(I("character"))
		});
		case "visited": return B({
			op: V(F("visited")),
			entityId: V(I()),
			count: V(A(1, void 0, !0))
		});
		case "external": return B({
			op: V(F("external")),
			contractId: V(I("external_contract"))
		});
		default: return;
	}
}
function It(e) {
	let t = { type: "expression" };
	switch (e.op) {
		case "value": return B({
			op: V(F("value")),
			value: V(P)
		});
		case "variable": return B({
			op: V(F("variable")),
			variableId: V(I("variable"))
		});
		case "add":
		case "subtract":
		case "multiply": return B({
			op: V(F("add", "subtract", "multiply")),
			left: V(t),
			right: V(t)
		});
		case "if": return B({
			op: V(F("if")),
			condition: V(nt),
			then: V(t),
			else: V(t)
		});
		default: return Ft(e);
	}
}
function Lt(e) {
	let t = V(L("calendar"));
	switch (e.mode) {
		case "instant": return B({
			mode: V(F("instant")),
			at: V(N),
			calendarId: t
		});
		case "interval": return B({
			mode: V(F("interval")),
			start: V(N),
			end: V(N),
			calendarId: t
		});
		case "uncertain": return B({
			mode: V(F("uncertain")),
			earliest: V(N),
			latest: V(N),
			calendarId: t,
			precision: V(O())
		});
		case "relative": return B({
			mode: V(F("relative")),
			anchorEventId: V(I("event")),
			anchorPoint: V(F("start", "end")),
			minOffset: V(N),
			maxOffset: V(N)
		});
		case "unknown": return B({
			mode: V(F("unknown")),
			reason: V(O())
		});
		default: return;
	}
}
function Rt(e) {
	switch (e.op) {
		case "all":
		case "any": return B({
			op: V(F("all", "any")),
			children: V(R({ type: "query" }, !1, 1, 256))
		});
		case "kind": return B({
			op: V(F("kind")),
			value: V(F(...D))
		});
		case "text": return B({
			op: V(F("text")),
			value: V(O())
		});
		case "status": return B({
			op: V(F("status")),
			value: V(F(...Le))
		});
		case "participant": return B({
			op: V(F("participant")),
			characterId: V(I("character"))
		});
		case "production": return B({
			op: V(F("production")),
			value: V(F("todo", "doing", "done", "needs_review"))
		});
		case "chapter": return B({
			op: V(F("chapter")),
			chapterId: V(I("chapter"))
		});
		case "foreshadow": return B({
			op: V(F("foreshadow")),
			foreshadowId: et(I("foreshadow")),
			resolutionPolicy: et(F("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
			role: et(F("clue", "payoff")),
			stage: et(F("hint", "suspicion", "reinforce", "reveal", "alternative"))
		});
		default: return;
	}
}
function zt(e) {
	if (!("mode" in e)) {
		let e = it(...[
			"alias",
			"replace",
			"exclude",
			"anonymize"
		].map((e) => zt({ mode: e })));
		return B({
			defaultPolicy: H(e),
			byEntityId: H(W(e, I()))
		});
	}
	switch (e.mode) {
		case "alias": return B({
			mode: V(F("alias")),
			aliasId: V(L("alias"))
		});
		case "replace": return B({
			mode: V(F("replace")),
			replacement: V(O(1, 128))
		});
		case "exclude": return B({ mode: V(F("exclude")) });
		case "anonymize": return B({
			mode: V(F("anonymize")),
			publicId: V(M),
			publicName: V(O(1, 128))
		});
		default: return;
	}
}
var Bt = {
	start: V(A(0, void 0, !0)),
	end: V(A(0, void 0, !0))
}, Vt = R(B({
	id: V(M),
	kind: V(F("paragraph", "heading", "list_item", "quote")),
	text: V(O()),
	ruby: H(R(B({
		...Bt,
		text: V(O())
	}))),
	links: H(R(B({
		...Bt,
		target: V(G)
	}))),
	unresolvedAnnotations: H(R(at))
}));
function J(e, t, n, r, i, a = 0, o) {
	if (r.length >= 256) return;
	if (a > 32) {
		q(r, n, "構造の深さが上限32を超えています。", "IMPORT_LIMIT");
		return;
	}
	let s = (e) => q(r, n, e);
	switch (e.type) {
		case "json": {
			let e = (t, n, i, a) => {
				if (i > 100) {
					q(r, n, "JSON階層の上限を超えています。", "IMPORT_LIMIT");
					return;
				}
				if (t !== null && typeof t != "string" && typeof t != "boolean" && !(typeof t == "number" && Number.isFinite(t))) {
					if (!t || typeof t != "object" || a.has(t)) {
						q(r, n, "通常のJSON値を指定してください。");
						return;
					}
					if (a.add(t), Array.isArray(t)) t.forEach((t, r) => e(t, `${n}[${r}]`, i + 1, a));
					else if (Object.getPrototypeOf(t) === Object.prototype || Object.getPrototypeOf(t) === null) for (let [o, s] of Object.entries(t)) [
						"__proto__",
						"prototype",
						"constructor"
					].includes(o) ? q(r, `${n}.${o}`, "予約済みのキーは使えません。") : e(s, `${n}.${o}`, i + 1, a);
					else q(r, n, "通常のJSONオブジェクトを指定してください。");
					a.delete(t);
				}
			};
			e(t, n, 0, /* @__PURE__ */ new Set());
			return;
		}
		case "text": {
			if (typeof t != "string") {
				s("文字列を入力してください。");
				return;
			}
			Nt(t) || s("文字列に不正なUnicodeがあります。");
			let n = Mt(t);
			e.min !== void 0 && n < e.min && s(`${e.min}文字以上で入力してください。`), e.max !== void 0 && n > e.max && s(`${e.max}文字以内で入力してください。`), e.maxBytes !== void 0 && jt(t) > e.maxBytes && s("本文が1 MiBの上限を超えています。");
			return;
		}
		case "number":
			typeof t != "number" || !Number.isFinite(t) || e.integer && !Number.isSafeInteger(t) ? s(e.integer ? "安全な範囲の整数を入力してください。" : "有限の数値を入力してください。") : (e.min !== void 0 && t < e.min || e.max !== void 0 && t > e.max) && s("数値が許容範囲外です。");
			return;
		case "boolean":
			typeof t != "boolean" && s("真偽値を指定してください。");
			return;
		case "enum":
			e.values.includes(t) || s("宣言された値を選んでください。");
			return;
		case "id":
			(typeof t != "string" || !Ve.test(t)) && s("小文字のUUIDを指定してください。");
			return;
		case "ref":
			typeof t == "string" && (e.scope === "calendar" ? t.length > 0 : Ve.test(t)) || s(e.scope === "calendar" ? "暦IDが必要です。" : "参照先は小文字UUIDです。"), typeof t == "string" && i.push({
				id: t,
				path: n,
				kinds: e.kinds,
				scope: e.scope ?? "entity"
			});
			return;
		case "tick":
			ge(t) || s("tickは38桁以内の正規整数文字列です。");
			return;
		case "revision":
			(typeof t != "string" || !He.test(t)) && s("revisionは0以上の整数文字列です。");
			return;
		case "datetime":
			(typeof t != "string" || !/^\d{4}-\d{2}-\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.\d+)?(?:Z|\+00:00)$/.test(t) || !Number.isFinite(Date.parse(t)) || !Pt(t.slice(0, 10))) && s("UTCのRFC 3339日時を指定してください。");
			return;
		case "date":
			(typeof t != "string" || !Pt(t)) && s("実在するYYYY-MM-DD形式の日付を指定してください。");
			return;
		case "hash":
			(typeof t != "string" || !/^[0-9a-f]{64}$/.test(t)) && s("SHA-256は小文字16進数64文字です。");
			return;
		case "safe_path":
			(typeof t != "string" || !t || t.startsWith("/") || t.includes("\\") || t.includes("\0") || /^[a-zA-Z]:/.test(t) || t.split("/").some((e) => !e || e === "." || e === "..") || /[\u0000-\u001f\u007f]/.test(t)) && s("安全な相対パスを指定してください。");
			return;
		case "array":
			if (!Array.isArray(t)) {
				s("配列を指定してください。");
				return;
			}
			if (t.length > (e.max ?? 1e5) || e.min !== void 0 && t.length < e.min) {
				s("配列の件数が許容範囲外です。");
				return;
			}
			e.unique && new Set(t.map((e) => typeof e == "object" ? JSON.stringify(e) : e)).size !== t.length && s("同じ値を集合内で重複保存できません。"), t.forEach((t, s) => J(e.item, t, `${n}[${s}]`, r, i, a + 1, o));
			return;
		case "object":
			if (!K(t)) {
				s("オブジェクトを指定してください。");
				return;
			}
			for (let i of Object.keys(t)) Object.hasOwn(e.fields, i) || q(r, `${n}.${i}`, "未知の項目は保存できません。");
			for (let s of Object.keys(e.fields)) {
				let c = e.fields[s], l = t[s], u = `${n}.${s}`;
				if (l === void 0) {
					c.required && q(r, u, "必須項目です。");
					continue;
				}
				l === null && c.nullable || J(c.schema, l, u, r, i, a + 1, o);
			}
			return;
		case "record":
			if (!K(t)) {
				s("項目の辞書を指定してください。");
				return;
			}
			for (let [s, c] of Object.entries(t)) {
				if ([
					"__proto__",
					"prototype",
					"constructor"
				].includes(s)) {
					q(r, `${n}.${s}`, "予約済みのキーは使えません。");
					continue;
				}
				e.key && J(e.key, s, `${n}.${s}.$key`, r, i, a + 1, o), J(e.value, c, `${n}.${s}`, r, i, a + 1, o);
			}
			return;
		case "union": {
			let s;
			for (let r of e.choices) {
				let e = [], c = [];
				if (J(r, t, n, e, c, a + 1, o), !e.length) {
					i.push(...c);
					return;
				}
				(!s || e.length < s.length) && (s = e);
			}
			r.push(...s ?? [{
				code: "VALIDATION_FAILED",
				path: n,
				message: "対応する型ではありません。"
			}]);
			return;
		}
		case "typed": {
			if (!K(t)) {
				s("型と値を指定してください。");
				return;
			}
			let e;
			switch (t.type) {
				case "boolean":
					e = j;
					break;
				case "integer":
					e = A(void 0, void 0, !0);
					break;
				case "enum":
				case "text":
					e = O();
					break;
				case "ref":
					e = I();
					break;
				case "unknown":
					J(B({
						type: V(F("unknown")),
						value: {
							schema: O(),
							required: !0,
							nullable: !0
						},
						reason: V(O())
					}), t, n, r, i, a + 1, o), t.value !== null && s("未定値のvalueはnullです。");
					return;
				default:
					s("未知の値型です。");
					return;
			}
			J(B({
				type: V(F(t.type)),
				value: V(e)
			}), t, n, r, i, a + 1, o);
			return;
		}
		case "custom":
			if (t === null) return;
			if (typeof t == "string") J(O(), t, n, r, i, a, o);
			else if (typeof t == "number") J(A(), t, n, r, i, a, o);
			else if (typeof t == "boolean") return;
			else K(t) && t.type === "ref" ? J(B({
				type: V(F("ref")),
				value: V(I())
			}), t, n, r, i, a + 1, o) : K(t) && t.type === "date" ? J(B({
				type: V(F("date")),
				value: V({ type: "date" })
			}), t, n, r, i, a + 1, o) : s("カスタム値は文字列・数値・真偽・日付・参照またはnullです。");
			return;
		case "richtext": {
			if (J(Vt, t, n, r, i, a + 1, o), !Array.isArray(t)) return;
			let c = 0, l = 0, u = /* @__PURE__ */ new Set();
			t.forEach((e, t) => {
				if (!K(e) || typeof e.text != "string") return;
				let i = Mt(e.text);
				if (c += jt(e.text), l += i, typeof e.id == "string" && (u.has(e.id) && q(r, `${n}[${t}].id`, "段落IDが重複しています。"), u.add(e.id)), Array.isArray(e.unresolvedAnnotations)) {
					for (let t of e.unresolvedAnnotations) if (K(t)) for (let e of [
						"originalText",
						"reason",
						"reading"
					]) typeof t[e] == "string" && (c += jt(t[e]));
				}
				for (let a of ["ruby", "links"]) Array.isArray(e[a]) && e[a].forEach((e, o) => {
					K(e) && (typeof e.start == "number" && typeof e.end == "number" && (e.start >= e.end || e.end > i) && q(r, `${n}[${t}].${a}[${o}]`, "文字範囲はコードポイントで数え、本文内の半開区間を指定してください。"), typeof e.text == "string" && (c += jt(e.text)));
				});
			}), c > 1048576 && s("本文フィールドが1 MiBを超えています。"), e.max !== void 0 && l > e.max && s(`要約は${e.max}文字以内です。`);
			return;
		}
		case "condition":
		case "expression": {
			let a = o ?? {
				counter: { count: 0 },
				depth: 0
			};
			if (a.counter.count++, a.counter.count > 256 || a.depth >= 16) {
				s("条件・式は深さ16、ノード256までです。");
				return;
			}
			if (!K(t)) {
				s("条件・式は型付きASTで指定してください。");
				return;
			}
			let c = e.type === "condition" ? Ft(t) : It(t);
			if (!c) {
				s("未知の条件・式opです。");
				return;
			}
			J(c, t, n, r, i, 0, {
				counter: a.counter,
				depth: a.depth + 1
			});
			return;
		}
		case "time": {
			if (!K(t)) {
				s("日時はTimeSpecで指定してください。");
				return;
			}
			let e = Lt(t);
			if (!e) {
				s("未知の日時modeです。");
				return;
			}
			let c = r.length;
			J(e, t, n, r, i, a + 1, o), r.length === c && (t.mode === "interval" && T(t.start, t.end) >= 0 && s("期間はstart < endの半開区間です。"), t.mode === "uncertain" && T(t.earliest, t.latest) > 0 && s("earliestはlatest以下です。"), t.mode === "relative" && T(t.minOffset, t.maxOffset) > 0 && s("minOffsetはmaxOffset以下です。"));
			return;
		}
		case "query":
		case "name_policy": {
			if (!K(t)) {
				s("型付きのオブジェクトを指定してください。");
				return;
			}
			let c = e.type === "query" ? Rt(t) : zt(t);
			if (!c) {
				s("未知の規則です。");
				return;
			}
			let l = r.length;
			J(c, t, n, r, i, a + 1, o), e.type === "query" && t.op === "foreshadow" && r.length === l && ![
				"foreshadowId",
				"resolutionPolicy",
				"role",
				"stage"
			].some((e) => t[e] !== void 0 && t[e] !== null) && q(r, n, "伏線検索には対象・回収方針・開示役割・段階のいずれかを指定してください。");
			return;
		}
	}
}
var Ht = {
	id: V(M),
	projectId: V(L("project")),
	kind: V(F(...D)),
	revision: V({ type: "revision" }),
	name: V(k),
	status: V(F(...Le)),
	visibility: V(F("private", "team", "projection")),
	retainIfUnreferenced: H(j),
	projectionProfileId: H(I("projection_profile")),
	templateId: H(I("template")),
	createdAt: V({ type: "datetime" }),
	updatedAt: V({ type: "datetime" }),
	deletedAt: H({ type: "datetime" }),
	deletionOperationId: H(M),
	customValues: V(W({ type: "custom" }, $e))
}, Ut = B({
	id: V(M),
	projectId: V(L("project")),
	revision: V({ type: "revision" }),
	fromId: V(I()),
	toId: V(I()),
	relationType: V(O(1, 128)),
	direction: V(F("forward", "symmetric")),
	validity: V(ot),
	evidenceIds: V(z()),
	status: V(F(...Le)),
	visibility: V(F("private", "team", "projection")),
	projectionProfileId: H(I("projection_profile")),
	deletedAt: H({ type: "datetime" }),
	deletionOperationId: H(M)
}), Wt = /* @__PURE__ */ new Map();
function Gt(e) {
	let t = kt[e], n = Wt.get(e);
	if (n?.data === t) return n.record;
	let r = B({
		...Ht,
		kind: V(F(e)),
		data: V(t)
	});
	return Wt.set(e, {
		data: t,
		record: r
	}), r;
}
function Kt(e, t, n, r = []) {
	let i = [];
	return J(e, t, n, i, r), i.length ? {
		ok: !1,
		issues: i
	} : {
		ok: !0,
		value: t
	};
}
function qt(e, t = "condition") {
	return Kt(nt, e, t);
}
function Jt(e, t = "value") {
	return Kt(P, e, t);
}
function Yt(e, t = "runtimeState") {
	let n = Kt(bt, e, t);
	if (!n.ok) return n;
	let r = [], i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	return n.value.itemInstances.forEach((e, n) => {
		i.has(e.instanceId) && q(r, `${t}.itemInstances[${n}].instanceId`, "物品個体のIDが重複しています。"), i.add(e.instanceId), (e.ownerId && e.locationId || e.consumed && e.quantity !== 0 || !e.consumed && e.quantity < 1) && q(r, `${t}.itemInstances[${n}]`, "物品の所在・所有・消費状態・数量が不整合です。");
	}), n.value.assertions.forEach((e, n) => {
		let i = `${e.assertionId}/${e.holderId}`;
		a.has(i) && q(r, `${t}.assertions[${n}]`, "同じ人物・事実の認識が重複しています。"), a.add(i);
	}), r.length ? {
		ok: !1,
		issues: r
	} : n;
}
function Xt(e, t, n, r = "presentationResults") {
	let i = Kt(R(vt), t, r);
	if (!i.ok) return i.issues;
	let a = [], o = new Set(e.seenIds), s = /* @__PURE__ */ new Set(), c = n.find((t) => t.kind === "flow_node" && t.id === e.presentationPosition && !t.deletedAt && t.status !== "rejected"), l = n.filter((e) => {
		if (e.kind !== "disclosure" || e.deletedAt || e.status === "rejected" || !c || !o.has(c.id)) return !1;
		let t = e.data.anchor;
		return t.positionStatus !== "unresolved" && (t.entityId === c.id || t.entityId === c.data.sceneId) && (!t.blockId || o.has(t.blockId)) && (!t.lineId || o.has(t.lineId));
	}), u = new Set(l.map((e) => e.id));
	i.value.forEach((t, n) => {
		let i = `${r}[${n}]`;
		s.has(t.targetId) && q(a, `${i}.targetId`, "初期提示の条件結果が重複しています。"), s.add(t.targetId), u.has(t.targetId) || q(a, `${i}.targetId`, "初期提示の対象ではない開示の条件結果です。", "REFERENCE_INVALID"), t.value === "unknown" && q(a, `${i}.value`, "未確認の開示条件では初期提示を完了できません。"), t.value === "true" && !o.has(t.targetId) && q(a, `${i}.value`, "提示した条件結果と既読の証跡が一致しません。"), t.value === "false" && o.has(t.targetId) && e.provenance === "full_play" && q(a, `${i}.value`, "提示済みの開示を初期条件のfalseで取り消すことはできません。");
	});
	for (let e of l) s.has(e.id) || q(a, r, "初期提示の開示条件結果が不足しています。");
	return a;
}
function Zt(e, t = "effect") {
	return Kt(kt.effect, e, t);
}
function Qt(e, t, n) {
	if (!K(e) || !D.includes(e.kind)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: `${t}.kind`,
			message: "未対応の情報種別です。"
		}]
	};
	let r = Kt(Gt(e.kind), e, t, n);
	if (!r.ok) return r;
	let i = [];
	return $t(r.value, t, i), i.length ? {
		ok: !1,
		issues: i
	} : r;
}
function Y(e, t, n = "value", r = !0) {
	let i = [], a = e.data;
	if (t.type === "unknown") return r || q(i, n, "未定の値はこの操作で使えません。", "CONDITION_UNKNOWN"), i;
	if (t.type !== a.valueType) return q(i, n, "状態変数の宣言型と値の型が一致しません。"), i;
	if (t.type === "integer") {
		let e = a.allowed.min ?? -2147483647, r = a.allowed.max ?? 2147483647;
		(!Number.isSafeInteger(t.value) || t.value < e || t.value > r) && q(i, n, "状態変数の値が宣言した整数範囲外です。");
	}
	return (t.type === "enum" || t.type === "boolean") && a.allowed.values && !a.allowed.values.includes(t.value) && q(i, n, "状態変数の値が許容集合にありません。"), i;
}
function $t(e, t, n) {
	let r = (e, r) => q(n, `${t}.${e}`, r);
	![
		"dialogue_line",
		"effect",
		"assertion",
		"disclosure",
		"cue",
		"storyboard_frame",
		"localization",
		"recording",
		"checkpoint",
		"trace"
	].includes(e.kind) && !e.name.trim() && (e.kind === "event" ? Ke(e.data.summary).trim() || r("data.summary", "名称または要約を入力してください。") : r("name", "名称を入力してください。")), e.visibility === "projection" && !e.projectionProfileId && r("projectionProfileId", "公開投影の対象プロファイルを指定してください。"), e.deletedAt && !e.deletionOperationId && r("deletionOperationId", "削除には削除操作IDが必要です。"), !e.deletedAt && e.deletionOperationId && r("deletionOperationId", "削除されていない情報に削除操作IDは保存できません。");
	for (let t of Object.keys(e.customValues)) {
		let n = kt[e.kind];
		(Object.hasOwn(Ht, t) || n.type === "object" && Object.hasOwn(n.fields, t)) && r(`customValues.${t}`, "標準項目とカスタム項目のキーが衝突しています。");
	}
	switch (e.kind) {
		case "event":
			for (let [t, n] of (e.data.constraints ?? []).entries()) n.type === "end_gap" && T(n.minimumTicks, n.maximumTicks) > 0 && r(`data.constraints[${t}]`, "日時差の最小値は最大値以下です。");
			break;
		case "item":
			e.data.itemMode === "instance" && !e.data.typeId && r("data.typeId", "物品の個体には種類への参照が必要です。");
			break;
		case "flow_node":
			e.data.nodeType === "terminal" && !e.data.terminalReason?.trim() && r("data.terminalReason", "意図した終端には終了理由が必要です。"), e.data.nodeType === "call" && !e.data.childGraphId && r("data.childGraphId", "呼出ノードには子分岐図が必要です。");
			break;
		case "variable": {
			let i = e.data;
			i.scope === "character" && !i.ownerId && r("data.ownerId", "人物scopeには所有人物が必要です。"), i.valueType === "integer" ? (i.allowed.values && r("data.allowed.values", "整数には集合ではなくmin/maxを指定してください。"), (i.allowed.min ?? -2147483647) > (i.allowed.max ?? 2147483647) && r("data.allowed", "整数の最小値は最大値以下です。")) : ((i.allowed.min != null || i.allowed.max != null) && r("data.allowed", "この型に数値範囲は設定できません。"), i.valueType === "enum" && (!i.allowed.values?.length || i.allowed.values.some((e) => typeof e != "string" || !e)) && r("data.allowed.values", "enumには空でない文字列の候補集合が必要です。"), i.valueType === "boolean" && i.allowed.values?.some((e) => typeof e != "boolean") && r("data.allowed.values", "booleanの候補は真偽値です。")), n.push(...Y(e, i.initial, `${t}.data.initial`));
			for (let [r, a] of (i.resetRules ?? []).entries()) n.push(...Y(e, a.value, `${t}.data.resetRules[${r}].value`));
			new Set((i.resetRules ?? []).map((e) => e.on)).size !== (i.resetRules ?? []).length && r("data.resetRules", "同じ終了時点の初期化規則は一つにしてください。");
			for (let [a, o] of (i.transitionRules ?? []).entries()) n.push(...Y(e, o.from, `${t}.data.transitionRules[${a}].from`, !1), ...Y(e, o.to, `${t}.data.transitionRules[${a}].to`, !1)), o.exception && !o.reason?.trim() && r(`data.transitionRules[${a}].reason`, "例外遷移には理由が必要です。");
			for (let [a, o] of (i.exclusions ?? []).entries()) n.push(...Y(e, o.value, `${t}.data.exclusions[${a}].value`, !1)), o.reason.trim() || r(`data.exclusions[${a}].reason`, "相互排他には理由が必要です。");
			break;
		}
		case "effect":
			[
				"set",
				"add",
				"move"
			].includes(e.data.operation) && (!e.data.value || e.data.value.type === "unknown") && r("data.value", "この効果には既知の入力値が必要です。"), e.data.operation === "add" && e.data.value?.type !== "integer" && r("data.value", "addはinteger値だけを使えます。"), e.data.operation === "move" && e.data.value?.type !== "ref" && r("data.value", "moveには所在・所有先のref値が必要です。"), e.data.operation === "consume" && !e.data.reason?.trim() && r("data.reason", "消費・破壊には理由が必要です。"), ["grant", "consume"].includes(e.data.operation) && e.data.value != null && (e.data.value.type !== "integer" || e.data.value.value < 1) && r("data.value", "物品数量は正のintegerです。"), e.data.operation === "assert" && e.data.value != null && e.data.value.type !== "boolean" && r("data.value", "assertの真偽入力はbooleanです。");
			break;
		case "assertion":
			e.data.truthKind === "belief" && !e.data.holderId && r("data.holderId", "beliefには認識を持つ人物が必要です。"), e.data.truthKind === "testimony" && !e.data.sourceIds?.length && r("data.sourceIds", "testimonyには出所が必要です。");
			break;
		case "storyboard_frame":
			e.data.mediaEndMs != null && e.data.mediaEndMs < e.data.mediaStartMs && r("data.mediaEndMs", "演出の終了は開始以上です。");
			break;
		case "travel_route":
			(e.data.minimumTicks != null && w(e.data.minimumTicks) < 0n || e.data.maximumTicks != null && w(e.data.maximumTicks) < 0n) && r("data", "移動所要時間は0以上です。"), e.data.minimumTicks != null && e.data.maximumTicks != null && T(e.data.minimumTicks, e.data.maximumTicks) > 0 && r("data.maximumTicks", "最大所要時間は最小以上です。");
			break;
		case "collection":
			e.data.purpose === "regression" && e.data.mode !== "fixed" && r("data.mode", "回帰経路集合は宣言した固定経路の集合です。"), e.data.mode === "dynamic" && !e.data.query && r("data.query", "動的一覧には型付き検索条件が必要です。"), e.data.mode === "fixed" && !Array.isArray(e.data.memberIds) && r("data.memberIds", "固定一覧にはID配列が必要です。");
			break;
		case "template":
			n.push(...Pe(e.data, `${t}.data`));
			break;
		case "production_task":
			if (e.data.deadline) try {
				new Intl.DateTimeFormat("ja", { timeZone: e.data.deadline.timeZone });
			} catch {
				r("data.deadline.timeZone", "有効なタイムゾーンを指定してください。");
			}
			if (e.data.estimate) {
				let t = e.data.estimate;
				t.value == null == (t.range == null) && r("data.estimate", "見積もりはvalueまたはrangeの一つです。"), t.range && t.range.min > t.range.max && r("data.estimate.range", "見積範囲が逆転しています。"), ["reading_minutes", "playing_minutes"].includes(t.unit) && !t.speed && r("data.estimate.speed", "本文量からの時間見積もりには速度が必要です。");
			}
			break;
		case "review": {
			let t = e.data.sharedSource;
			if (!t) break;
			try {
				let e = new URL(t.connection);
				(e.origin !== t.connection || e.username || e.password || !["https:", "http:"].includes(e.protocol) || e.protocol === "http:" && ![
					"localhost",
					"127.0.0.1",
					"[::1]"
				].includes(e.hostname)) && r("data.sharedSource.connection", "指摘の専用接続先のoriginを確認してください。");
			} catch {
				r("data.sharedSource.connection", "指摘の接続先が不正です。");
			}
			(!Ve.test(t.sharedSnapshot) || !Ve.test(t.comment) || !t.publicVersion || !/^([a-f0-9]{64})$/.test(t.projectionHash) || !/^([a-f0-9]{64})$/.test(t.commentBodyHash)) && r("data.sharedSource", "元の公開版・指摘・hashが不正です。"), (!!t.publicEntity == !!t.publicRelation || t.publicRelation && (t.publicBlock !== void 0 || t.startCp !== void 0 || t.endCp !== void 0) || t.publicBlock !== void 0 && (t.startCp === void 0 || t.endCp === void 0 || t.endCp <= t.startCp) || t.publicBlock === void 0 && (t.startCp !== void 0 || t.endCp !== void 0)) && r("data.sharedSource", "元指摘の対象とUnicode位置の組合せを確認してください。");
			break;
		}
		case "localization":
		case "recording": /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(e.data.language) || r("data.language", "言語コードを指定してください（例: ja、en-US）。");
	}
	en(e.data, `${t}.data`, n);
}
function en(e, t, n, r = 0) {
	if (r > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, i) => en(e, `${t}[${i}]`, n, r + 1));
		return;
	}
	let i = e;
	if ("worldRange" in i && K(i.worldRange)) {
		let e = i.worldRange;
		ge(e.start) && ge(e.end) && T(e.start, e.end) >= 0 && q(n, `${t}.worldRange`, "有効期間はstart < endの半開区間です。");
	}
	"entityId" in i && typeof i.start == "number" && typeof i.end == "number" && i.start >= i.end && q(n, t, "位置の文字範囲はstart < endです。");
	for (let [e, a] of Object.entries(i)) en(a, `${t}.${e}`, n, r + 1);
}
function tn(e) {
	let t = [];
	return J(Gt(e.kind), e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function nn(e) {
	let t = [];
	return J(Ut, e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function rn(e) {
	return e.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
}
function an(e, t, n) {
	let r = structuredClone(e), i = (e) => n instanceof Map ? n.get(e) : Object.hasOwn(n, e) ? n[e] : void 0, a = [...t].sort((e, t) => {
		let n = e.path.endsWith(".$key"), r = t.path.endsWith(".$key");
		return Number(n) - Number(r) || (n ? rn(t.path).length - rn(e.path).length : 0);
	});
	for (let e of a) {
		let t = i(e.id);
		if (!t) continue;
		let n = rn(e.path), a = n.at(-1) === "$key";
		a && n.pop();
		let o = n.pop();
		if (!o) continue;
		let s = r;
		for (let e of n) s = s[e];
		if (a) {
			if (t === o) continue;
			if (Object.hasOwn(s, t)) throw Error("REFERENCE_INVALID: 参照の統合で辞書キーが衝突します。保持する内容を選んでください。");
			s[t] = s[o], delete s[o];
		} else s[o] = t;
	}
	return r;
}
function on(e, t) {
	let n = an(e, tn(e), t), r = (e) => (t instanceof Map ? t.get(e) : t[e]) ?? e;
	return (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings && (n.kind === "scene" || n.kind === "flow_node") && n.data.reuse && (n.data.reuse.bindings = Object.fromEntries(Object.entries(e.data.reuse.bindings).map(([e, t]) => [r(e), r(t)]))), n;
}
function sn(e, t) {
	return an(e, nn(e), t);
}
var cn = B({
	projectId: V(M),
	immutableSnapshotId: V(M),
	contentHash: V({ type: "hash" })
}), ln = B({
	id: V(M),
	name: V(O(1, 128)),
	view: V(O(1)),
	entityIds: V(z()),
	settings: V(W(it(O(), A(), j, F(null)), $e))
}), un = {
	projectId: V(M),
	name: V(O(1, 128)),
	formatVersion: V(F(fe)),
	revision: V({ type: "revision" }),
	calendarId: V(O(1)),
	mainStart: V(N),
	worldReferences: V(R(cn))
}, dn = [
	...Object.keys(un),
	"calendars",
	"entities",
	"relations",
	"views"
], fn = [...dn, "authorAlternatives"], pn = R({ type: "json" }, !1, 0, 100);
function mn(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set([e.projectId]), o = /* @__PURE__ */ new Set();
	e.worldReferences.forEach((e, t) => {
		i.has(e.projectId) && q(r, `${n}.worldReferences[${t}]`, "同じ世界の複数の版を同時に参照すると、IDの参照先が曖昧になります。一つの固定版を選んでください。", "REFERENCE_INVALID"), i.add(e.projectId);
	});
	let s = [{
		content: e,
		location: n
	}, ...t.map((t) => ({
		content: t,
		location: `${n}.worldReferences[${e.worldReferences.findIndex((e) => e.projectId === t.projectId)}]`
	}))], c = /* @__PURE__ */ new Map();
	for (let [e, { content: t, location: n }] of s.entries()) {
		e > 0 && (a.has(t.projectId) && q(r, n, "同じ作品・世界の複数の内容が現在の参照範囲に含まれています。固定版を一つにしてください。", "REFERENCE_INVALID"), a.add(t.projectId));
		for (let [e, i] of t.calendars.entries()) {
			let t = c.get(i.id);
			t && !De(t, i) && q(r, `${n}.calendars[${e}].id`, "同じ暦IDに異なる定義があります。固定版の日時を読み替えず、暦IDを明示して対応付けてください。", "REFERENCE_INVALID"), c.set(i.id, i);
		}
		for (let [e, i] of [["entities", t.entities], ["relations", t.relations]]) i.forEach((i, a) => {
			let s = `${n}.${e}[${a}]`;
			o.has(i.id) && q(r, `${s}.id`, "現在の作品と参照中の共通世界でentity・relationのIDが衝突しています。曖昧な参照は保存できません。", "REFERENCE_INVALID"), o.add(i.id), i.projectId !== t.projectId && q(r, `${s}.projectId`, "参照範囲のレコードが所属する作品・世界と一致しません。", "REFERENCE_INVALID");
		});
	}
}
function hn(e, t, n, r, i = /* @__PURE__ */ new Map(), a) {
	let o = [];
	if (!K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: t,
			message: "作品はオブジェクトです。"
		}]
	};
	for (let n of Object.keys(e)) dn.includes(n) || q(o, `${t}.${n}`, "作品に未知の項目があります。");
	let s = Object.fromEntries(Object.keys(un).filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]]));
	J(B(un), s, t, o, []), e.formatVersion !== "1.0.0" && q(o, `${t}.formatVersion`, "対応していない形式版です。", "FORMAT_UNSUPPORTED");
	for (let n of [
		"entities",
		"relations",
		"calendars",
		"views"
	]) Array.isArray(e[n]) || q(o, `${t}.${n}`, "必須の配列です。");
	if (o.length) return {
		ok: !1,
		issues: o
	};
	let c = e.entities, l = e.relations, u = e.calendars;
	if (c.length + l.length > 1e5) return {
		ok: !1,
		issues: [{
			code: "IMPORT_LIMIT",
			path: t,
			message: "entityとrelationの合計は100,000件までです。"
		}]
	};
	let d = new Map(a?.previous.entities.map((e) => [e.id, e])), f = new Map(a?.previous.relations.map((e) => [e.id, e])), p = /* @__PURE__ */ new WeakMap(), m = /* @__PURE__ */ new WeakMap(), g = (e, t) => e.map((e) => ({
		...e,
		path: e.path.slice(t.length + 1)
	}));
	c.forEach((e, n) => {
		if (a && K(e) && d.get(e.id) === e) return;
		let r = `${t}.entities[${n}]`, i = [], s = Qt(e, r, i);
		s.ok ? p.set(s.value, g(i, r)) : o.push(...s.issues);
	}), l.forEach((e, n) => {
		if (a && K(e) && Object.is(f.get(e.id), e)) return;
		let r = `${t}.relations[${n}]`, i = [], s = Kt(Ut, e, r, i);
		s.ok ? m.set(s.value, g(i, r)) : o.push(...s.issues);
	}), u.forEach((e, n) => {
		let r = ye(e, `${t}.calendars[${n}]`);
		r.ok || o.push(...r.issues);
	});
	let _ = [];
	if (J(R(ln), e.views, `${t}.views`, o, _), o.length) return {
		ok: !1,
		issues: o.slice(0, 256)
	};
	let v = e, ee = [...i].map(([e, t]) => ({
		id: e,
		content: t,
		contentHash: "",
		createdAt: "",
		versionLabel: ""
	}));
	if (o.push(...de(v, ee, t)), o.length) return {
		ok: !1,
		issues: o.slice(0, 256)
	};
	let y = v.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) ? ce(v, ee) : v, te = new Set(y.worldReferences.map((e) => e.projectId)), b = n.worldSnapshots ? h(y, n.worldSnapshots) : void 0;
	if (b) for (let e of b.errors) q(o, `${t}.worldReferences`, e, "REFERENCE_INVALID");
	let x = b?.worlds ?? (n.worlds ?? []).filter((e) => te.has(e.projectId));
	if (c.length + l.length + x.reduce((e, t) => e + t.entities.length + t.relations.length, 0) > 1e5 && q(o, t, "参照世界を含むレコード数が100,000件を超えています。", "IMPORT_LIMIT"), mn(v, x, t, o), y !== v && mn(y, x, `${t}.reuse`, o), o.length) return {
		ok: !1,
		issues: o.slice(0, 256)
	};
	let S = [...y.entities, ...x.flatMap((e) => e.entities)], C = new Map(S.map((e) => [e.id, e])), ne = new Map([...v.relations, ...x.flatMap((e) => e.relations)].map((e) => [e.id, e])), re = new Set([...v.calendars, ...x.flatMap((e) => e.calendars)].map((e) => e.id)), ie = /* @__PURE__ */ new Set();
	for (let [e, n] of [["entities", v.entities], ["relations", v.relations]]) n.forEach((n, r) => {
		ie.has(n.id) && q(o, `${t}.${e}[${r}].id`, "entityとrelationのIDは作品内で一意です。"), ie.add(n.id), n.projectId !== v.projectId && q(o, `${t}.${e}[${r}].projectId`, "レコードが別の作品に属しています。", "REFERENCE_INVALID");
	});
	let ae = v.calendars.map((e) => e.id);
	new Set(ae).size !== ae.length && q(o, `${t}.calendars`, "暦IDが重複しています。"), ae.includes(v.calendarId) || q(o, `${t}.calendarId`, "作品の暦が定義されていません。", "REFERENCE_INVALID");
	let oe = v.worldReferences.map((e) => `${e.projectId}/${e.immutableSnapshotId}`);
	(new Set(oe).size !== oe.length || v.worldReferences.some((e) => e.projectId === v.projectId)) && q(o, `${t}.worldReferences`, "共通世界参照の重複または自己参照があります。");
	let se = /* @__PURE__ */ new Map(), le = /* @__PURE__ */ new Map();
	for (let e of S) gn(e.data, e.id, se, le, o, `${t}.entities.${e.id}.data`);
	let ue = /* @__PURE__ */ new Set([
		...C.keys(),
		...ne.keys(),
		...se.keys()
	]);
	for (let e of S) if (e.kind === "flow_node" && e.data.trigger?.id && ue.add(e.data.trigger.id), e.kind === "projection_profile") {
		for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) K(t) && typeof t.id == "string" && ue.add(t.id);
	}
	let fe = x.flatMap((e) => [...e.entities.flatMap(tn), ...e.relations.flatMap(nn)]).filter((e) => e.scope === "snapshot" && n.worldSnapshots?.[e.id] && x.some((t) => t.projectId === n.worldSnapshots?.[e.id].projectId)).map((e) => e.id), pe = /* @__PURE__ */ new Set([
		...r,
		...fe,
		v.projectId,
		...S.filter((e) => e.kind === "snapshot").map((e) => e.id),
		...(b?.references ?? y.worldReferences).map((e) => e.immutableSnapshotId)
	]), me = {
		entities: C,
		relations: ne,
		blocks: se,
		calendars: re,
		projects: /* @__PURE__ */ new Set([v.projectId, ...(b?.references ?? y.worldReferences).map((e) => e.projectId)]),
		projectionIds: ue
	}, he = /* @__PURE__ */ new Map();
	function ge(e) {
		if (e === v.projectId && !v.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings)) return me;
		let r = he.get(e);
		if (r) return r;
		let a = e === v.projectId ? v : i.get(e) ?? n.worldSnapshots?.[e];
		if (!a) return;
		let s = a;
		try {
			s.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) && (s = ce(s, ee));
		} catch {
			return;
		}
		let c = n.worldSnapshots ? h(s, n.worldSnapshots) : void 0;
		if (c) for (let n of c.errors) q(o, `${t}.versions.${e}.worldReferences`, n, "REFERENCE_INVALID");
		let l = c?.worlds ?? (n.worlds ?? []).filter((e) => s.worldReferences.some((t) => t.projectId === e.projectId)), u = o.length;
		if (mn(s, l, `${t}.versions.${e}`, o), o.length !== u) return;
		let d = [...s.entities, ...l.flatMap((e) => e.entities)], f = /* @__PURE__ */ new Map();
		for (let e of d) K(e) && gn(e.data, e.id, f, /* @__PURE__ */ new Map(), [], "version");
		let p = /* @__PURE__ */ new Set([
			...d.map((e) => e.id),
			...s.relations.map((e) => e.id),
			...l.flatMap((e) => e.relations.map((e) => e.id)),
			...f.keys()
		]);
		for (let e of d) if (e.kind === "flow_node" && e.data.trigger?.id && p.add(e.data.trigger.id), e.kind === "projection_profile") {
			for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) K(t) && typeof t.id == "string" && p.add(t.id);
		}
		let m = {
			entities: new Map(d.filter((e) => K(e)).map((e) => [e.id, e])),
			relations: new Map([...s.relations, ...l.flatMap((e) => e.relations)].filter((e) => K(e)).map((e) => [e.id, e])),
			blocks: f,
			calendars: new Set([...s.calendars, ...l.flatMap((e) => e.calendars)].map((e) => e.id)),
			projects: /* @__PURE__ */ new Set([s.projectId, ...l.map((e) => e.projectId)]),
			projectionIds: p
		};
		return he.set(e, m), m;
	}
	function w(e, t = "", r = me) {
		let i = t ? `${t}.${e.path}` : e.path, a = !0;
		if (e.scope === "entity") {
			let t = r.entities.get(e.id);
			a = !!t, t && e.kinds && !e.kinds.includes(t.kind) && q(o, i, `参照先の種類は${e.kinds.map((e) => Ie[e]).join(" / ")}です。`, "REFERENCE_INVALID"), t && n.runtime && t.deletedAt && q(o, i, "削除済み情報は実行用出力で参照できません。", "REFERENCE_INVALID");
		} else e.scope === "relation" ? a = r.relations.has(e.id) : e.scope === "record" ? a = r.entities.has(e.id) || r.relations.has(e.id) : e.scope === "projection_record" ? a = r.projectionIds.has(e.id) : e.scope === "presentation" ? a = r.entities.has(e.id) || r.blocks.has(e.id) : e.scope === "calendar" ? a = r.calendars.has(e.id) : e.scope === "project" ? a = r.projects.has(e.id) : e.scope === "snapshot" ? a = pe.has(e.id) : e.scope === "block" ? a = r.blocks.has(e.id) : e.scope === "alias" && (a = le.has(e.id));
		a || q(o, i, "参照先が存在しないか、指定した作品・共通世界の範囲外です。", "REFERENCE_INVALID");
	}
	let _e = (e) => {
		let t = p.get(e);
		if (t) return t;
		if (!a || d.get(e.id) !== e) return tn(e);
		let n = a.references.get(e);
		if (n) return n;
		let r = tn(e);
		return a.references.set(e, r), r;
	};
	v.entities.forEach((e, n) => {
		let r = `${t}.entities[${n}]`;
		for (let t of _e(e)) {
			let n = rn(t.path), i = n.slice(0, -1).reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), a = (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse && t.path === "data.reuse.sourceId" ? e.data.reuse.pinnedSnapshotId : void 0, s = e.kind === "projection_profile" && e.data.sourceVersionId && /^data\.(?:includedIds|publicTexts|blockSources|publicIds|publicValues|namePolicy|allowedRelationIds|approvedAttachmentIds)(?:\.|\[)/.test(t.path) ? e.data.sourceVersionId : void 0, c = (e.kind === "note" && t.path === "data.handoffReceipt.profileId" ? e.data.handoffReceipt?.profileVersionId : void 0) ?? a ?? (K(i) && typeof i.entityId == "string" && typeof i.sourceVersionId == "string" ? i.sourceVersionId : e.kind === "review" && t.path.startsWith("data.target.") ? e.data.targetVersionId : s);
			if (e.kind === "projection_profile" && t.scope === "projection_record" && t.path.endsWith(".$key") && Object.values(e.data.publicTexts ?? {}).some((e) => Object.values(e).some((e) => Array.isArray(e) && e.some((e) => e.id === t.id)))) {
				w(t, r);
				continue;
			}
			let l = e.kind === "checkpoint" && (t.path.startsWith("data.runtimeState.") || t.path.startsWith("data.presentationState.") || t.path.startsWith("data.presentationResults[")) || e.kind === "trace" && (t.path.startsWith("data.steps[") || t.path.startsWith("data.initialExternalValues.") || t.path.startsWith("data.initialStubValues.") || t.path.startsWith("data.initialStubBaseState.") || t.path.startsWith("data.readingPath."));
			if (c || l && (e.kind === "checkpoint" || e.kind === "trace")) {
				let i = ge(c ?? (e.kind === "checkpoint" || e.kind === "trace" ? e.data.contentVersionId : v.projectId));
				if (!i) {
					q(o, c ? e.kind === "review" ? `${r}.data.targetVersionId` : `${r}.${n.slice(0, -1).join(".")}.sourceVersionId` : `${r}.data.contentVersionId`, "参照する固定版の本文がありません。", "REFERENCE_INVALID");
					continue;
				}
				w(t, r, i);
			} else w(t, r);
		}
	}), v.relations.forEach((e, n) => (m.get(e) ?? nn(e)).forEach((e) => w(e, `${t}.relations[${n}]`))), _.forEach((e) => w(e));
	let ve = n.relationTypes ?? ze;
	v.relations.forEach((e, n) => {
		let r = `${t}.relations[${n}]`, i = ve.find((t) => t.key === e.relationType), a = C.get(e.fromId), s = C.get(e.toId);
		i ? (a && !i.fromKinds.includes(a.kind) && q(o, `${r}.fromId`, "この関係で許されない始点種類です。", "REFERENCE_INVALID"), s && !i.toKinds.includes(s.kind) && q(o, `${r}.toId`, "この関係で許されない終点種類です。", "REFERENCE_INVALID"), e.fromId === e.toId && !i.allowSelf && q(o, r, "この関係は自己関係を許しません。"), e.direction === "symmetric" && !i.allowSymmetric && q(o, `${r}.direction`, "この関係は対称ではありません。")) : q(o, `${r}.relationType`, "関係の種類が辞書に定義されていません。"), e.deletedAt && !e.deletionOperationId && q(o, `${r}.deletionOperationId`, "削除には操作IDが必要です。"), en(e.validity, `${r}.validity`, o);
	});
	let T;
	if (a && JSON.stringify(v.worldReferences) === JSON.stringify(a.previous.worldReferences) && JSON.stringify(v.calendars) === JSON.stringify(a.previous.calendars)) {
		T = /* @__PURE__ */ new Set([...v.entities.filter((e) => d.get(e.id) !== e).map((e) => e.id), ...v.relations.filter((e) => f.get(e.id) !== e).map((e) => e.id)]);
		for (let e of d.keys()) C.has(e) || T.add(e);
		for (let e of f.keys()) ne.has(e) || T.add(e);
	}
	return vn(v, C, le, pe, se, o, t, n, ge, T ? (e) => d.get(e.id) !== e || _e(e).some((e) => T.has(e.id)) : void 0), o.length ? {
		ok: !1,
		issues: o.slice(0, 256)
	} : {
		ok: !0,
		value: v
	};
}
function gn(e, t, n, r, i, a, o = 0) {
	if (o > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, s) => gn(e, t, n, r, i, `${a}[${s}]`, o + 1));
		return;
	}
	let s = e;
	typeof s.id == "string" && typeof s.text == "string" && [
		"paragraph",
		"heading",
		"list_item",
		"quote"
	].includes(s.kind) && (n.has(s.id) && q(i, `${a}.id`, "本文ブロックIDが重複しています。"), n.set(s.id, {
		entityId: t,
		text: s.text
	})), typeof s.id == "string" && "isPublicDefault" in s && (r.has(s.id) && q(i, `${a}.id`, "別名IDが重複しています。"), r.set(s.id, {
		entityId: t,
		alias: s
	}));
	for (let [e, c] of Object.entries(s)) [
		"runtimeState",
		"before",
		"after",
		"publicTexts"
	].includes(e) || gn(c, t, n, r, i, `${a}.${e}`, o + 1);
}
function _n(e, t, n, r, i) {
	let a = new Map(e.map((e) => [e.id, e])), o = /* @__PURE__ */ new Map();
	for (let s of e) {
		if (o.get(s.id)) continue;
		let e = [{
			id: s.id,
			ids: t(s),
			cursor: 0
		}];
		for (o.set(s.id, 1); e.length;) {
			let s = e[e.length - 1];
			if (s.cursor >= s.ids.length) {
				o.set(s.id, 2), e.pop();
				continue;
			}
			let c = s.ids[s.cursor++], l = a.get(c);
			if (l) {
				if (o.get(c) === 1) {
					q(n, `${r}.entities.${s.id}.data`, `${i}に循環があります。`);
					continue;
				}
				o.get(c) || (o.set(c, 1), e.push({
					id: c,
					ids: t(l),
					cursor: 0
				}));
			}
		}
	}
}
function vn(e, t, n, r, i, a, o, s, c, l) {
	let u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set();
	e.entities.some((e) => !!e.templateId && !e.deletedAt) && a.push(...Fe(e, o, [...t.values()])), e.entities.forEach((e, f) => {
		let p = `${o}.entities[${f}]`;
		if (!e.deletedAt) {
			if (e.kind === "variable" || e.kind === "quest" || e.kind === "external_contract") {
				let t = `${e.kind}/${e.kind === "variable" ? `${e.data.scope}/${e.data.ownerId ?? ""}/` : ""}${e.data.key}`;
				u.has(t) && q(a, `${p}.data.key`, "同じスコープでキーが重複しています。"), u.set(t, e.id);
			}
			if (e.kind === "localization") {
				let t = `${e.data.sourceLineId}/${e.data.language}/${e.data.sourceHash}`;
				d.has(t) && q(a, p, "同じ台詞・言語・原文版の翻訳が重複しています。"), d.add(t);
			}
			if (!l || l(e) || e.kind === "checkpoint" || e.kind === "trace") {
				if (e.kind === "template" && a.push(...Pe(e.data, `${p}.data`, t)), e.kind === "item" && e.data.itemMode === "instance") {
					let n = e.data.typeId ? t.get(e.data.typeId) : void 0;
					n?.kind === "item" && n.data.itemMode !== "type" && q(a, `${p}.data.typeId`, "個体のtypeIdは物品種類を参照してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "quest") {
					let n = t.get(e.data.stateVariableId);
					if (n?.kind === "variable") for (let [t, r] of (e.data.transitionRules ?? []).entries()) a.push(...Y(n, r.from, `${p}.data.transitionRules[${t}].from`, !1), ...Y(n, r.to, `${p}.data.transitionRules[${t}].to`, !1));
				}
				if (e.kind === "variable") for (let [n, r] of (e.data.exclusions ?? []).entries()) {
					let e = t.get(r.variableId);
					e?.kind === "variable" && a.push(...Y(e, r.otherValue, `${p}.data.exclusions[${n}].otherValue`, !1));
				}
				if (e.kind === "collection" && e.data.purpose === "regression") for (let [n, r] of (e.data.memberIds ?? []).entries()) {
					let e = t.get(r);
					e && e.kind !== "trace" && q(a, `${p}.data.memberIds[${n}]`, "回帰経路集合には保存した試読記録を指定してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "effect") {
					let n = t.get(e.data.targetId), r = e.data.operation;
					if (n && [
						"set",
						"add",
						"reset"
					].includes(r) && (n.kind === "variable" ? (n.data.derived && q(a, `${p}.data.targetId`, "算出状態へ直接代入できません。"), r === "add" && n.data.valueType !== "integer" && q(a, `${p}.data.targetId`, "addはinteger状態だけです。"), e.data.value && r !== "add" && a.push(...Y(n, e.data.value, `${p}.data.value`))) : q(a, `${p}.data.targetId`, "状態更新効果は状態変数を参照してください。", "REFERENCE_INVALID")), n && [
						"grant",
						"consume",
						"move"
					].includes(r) && n.kind !== "item" && q(a, `${p}.data.targetId`, "物品効果は物品を参照してください。", "REFERENCE_INVALID"), n?.kind === "item" && [
						"grant",
						"consume",
						"move"
					].includes(r) && e.data.instanceId) {
						let r = t.get(e.data.instanceId);
						r?.kind === "item" && (r.data.itemMode !== "instance" || (n.data.itemMode === "type" ? r.data.typeId !== n.id : r.id !== n.id)) && q(a, `${p}.data.instanceId`, "指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
					}
					if (n && r === "assert" && n.kind !== "assertion" && q(a, `${p}.data.targetId`, "認識効果は事実・認識を参照してください。", "REFERENCE_INVALID"), r === "move" && e.data.value?.type === "ref") {
						let n = t.get(e.data.value.value);
						n && ![
							"character",
							"group",
							"place"
						].includes(n.kind) && q(a, `${p}.data.value`, "物品の移動先は人物・グループ・場所です。", "REFERENCE_INVALID");
					}
				}
				if (e.kind === "flow_graph") {
					for (let t of [...e.data.entryIds, ...e.data.exitIds]) e.data.nodeIds.includes(t) || q(a, `${p}.data`, "入口・出口はその分岐図のノード集合に含めてください。");
					for (let n of e.data.edgeIds) {
						let r = t.get(n);
						r?.kind === "flow_edge" && (!e.data.nodeIds.includes(r.data.fromId) || typeof r.data.toId == "string" && !e.data.nodeIds.includes(r.data.toId)) && q(a, `${p}.data.edgeIds`, "進行線の始点・終点は同じ分岐図内に置いてください。");
					}
					let n = (e.data.parameters ?? []).map((e) => e.key);
					new Set(n).size !== n.length && q(a, `${p}.data.parameters`, "引数のキーが重複しています。");
				}
				if (e.kind === "flow_edge" && s.runtime && typeof e.data.toId != "string" && q(a, `${p}.data.toId`, "未完成の分岐先は実行用出力できません。", "EXPORT_UNSUPPORTED"), e.kind === "variable" && s.runtime && e.data.initial.type === "unknown" && !e.data.derived && q(a, `${p}.data.initial`, "初期値が未定です。", "CONDITION_UNKNOWN"), bn(e.data, p, t, a), e.kind === "review" && typeof e.data.target == "object" ? (xn(e.data.target, `${p}.data.target`, t, i, a, 0, c, e.data.targetVersionId), xn({
					...e.data,
					target: null
				}, `${p}.data`, t, i, a, 0, c)) : xn(e.data, `${p}.data`, t, i, a, 0, c), e.kind === "projection_profile") {
					let t = e.data.namePolicy;
					if ("mode" in t && t.mode === "alias") {
						let r = n.get(t.aliasId);
						r && !e.data.includedIds.includes(r.entityId) && q(a, `${p}.data.namePolicy`, "別名は投影対象の本体に属している必要があります。");
					} else if (!("mode" in t)) for (let [e, r] of Object.entries(t.byEntityId ?? {})) r.mode === "alias" && n.get(r.aliasId)?.entityId !== e && q(a, `${p}.data.namePolicy.byEntityId.${e}`, "別名が指定した本体に属していません。");
				}
				if (e.kind === "checkpoint" && (!r.has(e.data.runtimeState.contentVersionId) || e.data.runtimeState.contentVersionId !== e.data.contentVersionId) && q(a, `${p}.data.runtimeState.contentVersionId`, "途中開始の状態と対象版が一致しません。"), e.kind === "checkpoint") {
					let t = Yt(e.data.runtimeState, `${p}.data.runtimeState`);
					if (t.ok || a.push(...t.issues), e.data.presentationState && (e.data.presentationState.contentVersionId !== e.data.contentVersionId || e.data.presentationState.presentationPosition !== e.data.runtimeState.presentationPosition || e.data.presentationState.provenance !== e.data.runtimeState.provenance) && q(a, `${p}.data.presentationState`, "提示前の観測状態と開始点・対象版・由来が一致しません。"), e.data.presentationResults != null) {
						let t = c(e.data.contentVersionId);
						t && a.push(...Xt({
							...e.data.runtimeState,
							provenance: e.data.origin ?? "partial"
						}, e.data.presentationResults, [...t.entities.values()], `${p}.data.presentationResults`));
					}
				}
				if (e.kind === "trace") {
					let t = e.data;
					t.initialStubBaseState && !t.initialStubValues && q(a, `${p}.data.initialStubBaseState`, "stub前の個別状態には初期stub入力の記録が必要です。"), t.mode === "chapters" ? ((t.initialStubValues || t.initialStubBaseState) && q(a, `${p}.data.initialStubValues`, "章経路の個別開始はcheckpointへ、外部仮値はinitialExternalValuesへ記録してください。"), t.readingPath || q(a, `${p}.data.readingPath`, "章読み通しには提示経路が必要です。"), t.steps.length && q(a, `${p}.data.steps`, "章読み通しとフロー遷移を混在させられません。")) : t.readingPath != null && q(a, `${p}.data.readingPath`, "提示経路はmode:chaptersの記録に指定してください。"), t.steps.forEach((e, n) => {
						for (let [t, r] of [["before", e.before], ["after", e.after]]) {
							let e = Yt(r, `${p}.data.steps[${n}].${t}`);
							e.ok || a.push(...e.issues);
						}
						e.presentationState && (e.presentationState.contentVersionId !== t.contentVersionId || e.presentationState.presentationPosition !== e.after.presentationPosition || e.presentationState.provenance !== e.after.provenance) && q(a, `${p}.data.steps[${n}].presentationState`, "提示前の観測状態と提示先・対象版・由来が一致しません。");
					}), t.readingPath?.occurrences.forEach((e, t) => {
						for (let [n, r] of [["before", e.before], ["after", e.after]]) {
							let e = Yt(r, `${p}.data.readingPath.occurrences[${t}].${n}`);
							e.ok || a.push(...e.issues);
						}
					});
				}
			}
		}
	});
	for (let t of [
		"place",
		"group",
		"flow_graph",
		"map"
	]) _n(e.entities.filter((e) => e.kind === t && !e.deletedAt), (e) => e.kind === "place" || e.kind === "group" ? e.data.parentId ? [e.data.parentId] : [] : e.kind === "flow_graph" ? e.data.parentGraphId ? [e.data.parentGraphId] : [] : e.kind === "map" && e.data.parentMapId ? [e.data.parentMapId] : [], a, o, `${Ie[t]}の階層`);
	_n(e.entities.filter((e) => e.kind === "production_task" && !e.deletedAt), (e) => e.kind === "production_task" ? e.data.dependsOn ?? [] : [], a, o, "制作依存"), _n(e.entities.filter((e) => e.kind === "variable" && !e.deletedAt), (e) => e.kind === "variable" && e.data.derived ? yn(e.data.derived) : [], a, o, "算出状態"), _n(e.entities.filter((e) => e.kind === "flow_graph" && !e.deletedAt), (e) => e.kind === "flow_graph" ? e.data.nodeIds.flatMap((e) => {
		let n = t.get(e);
		return n?.kind === "flow_node" && n.data.childGraphId ? [n.data.childGraphId] : [];
	}) : [], a, o, "分岐図の呼出階層"), a.push(...Ee([...t.values()].filter((e) => e.kind === "event" && !e.deletedAt)));
	let f = /* @__PURE__ */ new Map();
	for (let t of e.entities) if (t.kind === "flow_edge" && t.data.edgeType === "automatic" && !t.deletedAt) {
		let e = `${t.data.fromId}/${t.data.priority ?? 0}`;
		f.has(e) && q(a, `${o}.entities.${t.id}.data.priority`, "同じ始点の自動候補で優先順位が重複しています。"), f.set(e, t.id);
	}
}
function yn(e) {
	let t = [];
	return J({ type: "expression" }, e, "", [], t), t.filter((e) => e.kinds?.includes("variable")).map((e) => e.id);
}
function bn(e, t, n, r, i = 0) {
	if (i > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, a) => bn(e, `${t}[${a}]`, n, r, i + 1));
		return;
	}
	let a = e;
	if (a.op === "compare") {
		let e = n.get(a.variableId);
		if (e?.kind === "variable") {
			let n = a.comparator, i = Array.isArray(a.value) ? a.value : [a.value];
			[
				"lt",
				"le",
				"gt",
				"ge"
			].includes(n) && e.data.valueType !== "integer" && q(r, `${t}.comparator`, "順序比較はintegerにだけ使えます。"), i.forEach((n, a) => {
				n.type !== "unknown" && n.type !== e.data.valueType && q(r, `${t}.value${i.length > 1 ? `[${a}]` : ""}`, "比較値の型が状態変数と一致しません。");
			});
		}
	}
	for (let [e, o] of Object.entries(a)) bn(o, `${t}.${e}`, n, r, i + 1);
}
function xn(e, t, n, r, i, a = 0, o, s) {
	if (a > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, c) => xn(e, `${t}[${c}]`, n, r, i, a + 1, o, s));
		return;
	}
	let c = e;
	if (typeof c.entityId == "string") {
		c.positionStatus === "unresolved" && (!c.positionReason || c.start != null || c.end != null) && q(i, t, "位置不明には理由を付け、確定した文字範囲を外してください。"), c.positionStatus !== "unresolved" && (c.positionReason != null || c.quotedText != null) && q(i, t, "位置不明の理由・引用は位置不明状態と一緒に保存してください。");
		let e = typeof c.sourceVersionId == "string" ? c.sourceVersionId : s, a = e && o ? o(e) : void 0, l = a?.entities ?? n, u = a?.blocks ?? r, d;
		if (typeof c.blockId == "string") {
			let e = u.get(c.blockId);
			e && e.entityId !== c.entityId && q(i, `${t}.blockId`, "段落は指定した情報に属していません。", "REFERENCE_INVALID"), d = e?.text;
		}
		if (typeof c.lineId == "string") {
			let e = l.get(c.lineId);
			e?.kind === "dialogue_line" && (d = Ke(e.data.text));
		}
		(typeof c.start == "number" || typeof c.end == "number") && ((typeof c.start != "number" || typeof c.end != "number") && q(i, t, "文字範囲はstart/endを対で指定してください。"), d === void 0 ? q(i, t, "文字範囲には本文ブロックまたは台詞への参照が必要です。") : typeof c.end == "number" && c.end > Mt(d) && q(i, `${t}.end`, "文字範囲が参照元の本文を超えています。"));
	}
	for (let [e, s] of Object.entries(c)) [
		"publicTexts",
		"before",
		"after",
		"runtimeState"
	].includes(e) || xn(s, `${t}.${e}`, n, r, i, a + 1, o);
}
function Sn(e, t = {}) {
	if (!K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	let n = [];
	for (let t of Object.keys(e)) [
		...fn,
		"snapshots",
		"history"
	].includes(t) || q(n, `project.${t}`, "作品に未知の項目があります。");
	Array.isArray(e.snapshots) || q(n, "project.snapshots", "必須の配列です。"), Array.isArray(e.history) || q(n, "project.history", "必須の配列です。");
	let r = new Set((Array.isArray(e.snapshots) ? e.snapshots : []).flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : []));
	Object.hasOwn(e, "authorAlternatives") && J(pn, e.authorAlternatives, "project.authorAlternatives", n, []);
	let i = hn(Object.fromEntries(dn.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, r, Tn(e.snapshots));
	if (i.ok || n.push(...i.issues), n.length) return {
		ok: !1,
		issues: n.slice(0, 256)
	};
	let a = e;
	wn(a.snapshots, "project.snapshots", a.projectId, t, n);
	let o = /* @__PURE__ */ new Set();
	return a.history.forEach((e, r) => {
		let i = `project.history[${r}]`, s = e;
		if (!K(s)) {
			q(n, i, "履歴はコマンドです。");
			return;
		}
		let c = B({
			operationId: V(M),
			projectId: V(M),
			baseRevision: V({ type: "revision" }),
			revision: V({ type: "revision" }),
			targetIds: V(R(M, !0)),
			reason: V(O()),
			createdAt: V({ type: "datetime" }),
			compensatesOperationId: H(M),
			idMap: H(W(M, M)),
			importOrigin: H(B({
				sourceProjectId: V(M),
				sourceOperationId: V(M),
				importOperationId: V(M)
			}))
		});
		for (let e of Object.keys(s)) e !== "before" && e !== "after" && c.type === "object" && !Object.hasOwn(c.fields, e) && q(n, `${i}.${e}`, "コマンドに未知の項目があります。");
		J(c, Object.fromEntries(Object.entries(s).filter(([e]) => e !== "before" && e !== "after")), i, n, []), o.has(e.operationId) && q(n, `${i}.operationId`, "履歴の操作IDが重複しています。"), o.add(e.operationId), e.projectId !== a.projectId && q(n, `${i}.projectId`, "履歴が別の作品に属しています。");
		for (let e of ["before", "after"]) {
			if (!K(s[e])) {
				q(n, `${i}.${e}`, "変更前後の内容を保持してください。");
				continue;
			}
			let r = s[e];
			Array.isArray(r.snapshots) || q(n, `${i}.${e}.snapshots`, "復元に必要な公開版配列が必要です。"), Object.hasOwn(r, "authorAlternatives") && J(pn, r.authorAlternatives, `${i}.${e}.authorAlternatives`, n, []);
			let o = Object.fromEntries(Object.entries(r).filter(([e]) => e !== "snapshots" && e !== "authorAlternatives")), c = new Set((Array.isArray(r.snapshots) ? r.snapshots : []).flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : [])), l = hn(o, `${i}.${e}`, t, c, Tn(r.snapshots));
			l.ok ? l.value.projectId !== a.projectId && q(n, `${i}.${e}.projectId`, "履歴の内容が別の作品に属しています。") : n.push(...l.issues), Array.isArray(r.snapshots) && wn(r.snapshots, `${i}.${e}.snapshots`, a.projectId, t, n);
		}
	}), n.length ? {
		ok: !1,
		issues: n.slice(0, 256)
	} : {
		ok: !0,
		value: a
	};
}
function Cn(e, t = {}, n) {
	let r = [];
	for (let t of Object.keys(e)) [
		...fn,
		"snapshots",
		"history"
	].includes(t) || q(r, `project.${t}`, "作品に未知の項目があります。");
	if ((!Array.isArray(e.snapshots) || !Array.isArray(e.history)) && q(r, "project", "公開版と履歴の配列が必要です。"), Object.hasOwn(e, "authorAlternatives") && J(pn, e.authorAlternatives, "project.authorAlternatives", r, []), r.length) return {
		ok: !1,
		issues: r
	};
	let i = new Set(e.snapshots.map((e) => e.id)), a = hn(Object.fromEntries(dn.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, i, Tn(e.snapshots), n);
	return a.ok ? {
		ok: !0,
		value: e
	} : a;
}
function wn(e, t, n, r, i) {
	let a = new Set(e.flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : [])), o = /* @__PURE__ */ new Set(), s = Tn(e);
	e.forEach((e, c) => {
		let l = `${t}[${c}]`;
		if (!K(e)) {
			q(i, l, "公開版はオブジェクトです。");
			return;
		}
		let u = B({
			id: V(M),
			versionLabel: V(O(1, 128)),
			contentHash: V({ type: "hash" }),
			createdAt: V({ type: "datetime" })
		});
		for (let t of Object.keys(e)) [
			"id",
			"versionLabel",
			"contentHash",
			"createdAt",
			"content"
		].includes(t) || q(i, `${l}.${t}`, "公開版に未知の項目があります。");
		J(u, Object.fromEntries(Object.entries(e).filter(([e]) => e !== "content")), l, i, []), typeof e.id == "string" && (o.has(e.id) && q(i, `${l}.id`, "公開版のIDが重複しています。"), o.add(e.id), e.id === n && q(i, `${l}.id`, "公開版IDは作品IDと別にしてください。"));
		let d = hn(e.content, `${l}.content`, r, a, s);
		d.ok ? d.value.projectId !== n && q(i, `${l}.content.projectId`, "公開版が別の作品に属しています。") : i.push(...d.issues);
	});
}
function Tn(e) {
	return Array.isArray(e) ? new Map(e.flatMap((e) => K(e) && typeof e.id == "string" && K(e.content) && [
		"entities",
		"relations",
		"calendars",
		"worldReferences"
	].every((t) => Array.isArray(e.content[t]) && e.content[t].every(K)) ? [[e.id, e.content]] : [])) : /* @__PURE__ */ new Map();
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/stateRules.ts
function En(e, t) {
	let n = t.ruleContext;
	if (!n) return {
		value: "unknown",
		reasons: ["対象作品・章・経路の実行情報がありません。"]
	};
	if (e.projectId !== n.projectId || e.targetSnapshotId && ![
		n.projectId,
		t.state.contentVersionId,
		n.sourceVersionId
	].includes(e.targetSnapshotId)) return {
		value: "false",
		reasons: ["対象作品版の範囲外です。"]
	};
	if (e.graphId && n.graphId && e.graphId !== n.graphId || e.chapterId && n.chapterId && e.chapterId !== n.chapterId) return {
		value: "false",
		reasons: ["対象グラフまたは章の範囲外です。"]
	};
	let r = Fn(e.routeCondition, t);
	return r.value === "false" ? r : e.graphId && !n.graphId || e.chapterId && !n.chapterId ? {
		value: "unknown",
		reasons: ["対象グラフまたは章を確認できません。", ...r.reasons]
	} : r;
}
function Dn(e, t) {
	let n = (e, t) => ({
		value: e,
		reasons: [t]
	});
	if (!e.reason.trim() || !e.evidenceIds.length) return n("false", "例外には理由と根拠が必要です。");
	let r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (e.evidenceIds.some((e) => !r.some((t) => t.id === e && !t.deletedAt && t.status === "confirmed"))) return n("unknown", "例外の根拠が存在しないか、採用確定していません。");
	let i = En(e.targetScope, t);
	if (i.value !== "true") return i;
	let a = e.validity.worldRange, o = t.ruleContext?.worldTick;
	if (!a || a.end === null) return n("unknown", "例外の有効期限を指定してください。");
	if (!ge(o)) return n("unknown", "例外の期限を評価する現在の世界時点がありません。");
	if (a.start !== null && T(o, a.start) < 0 || T(o, a.end) >= 0) return n("false", "例外の有効期間外です。");
	let s = Fn(e.validity.routeCondition, t);
	if (s.value !== "true") return s;
	let c = e.validity.presentationAnchor, l = t.ruleContext?.anchorBindings, u = c && l && c.sourceVersionId === t.ruleContext?.sourceVersionId ? {
		...c,
		entityId: l[c.entityId] ?? c.entityId,
		...c.blockId ? { blockId: l[c.blockId] ?? c.blockId } : {},
		...c.lineId ? { lineId: l[c.lineId] ?? c.lineId } : {}
	} : c;
	return u && (u.positionStatus === "unresolved" || u.sourceVersionId && ![
		t.ruleContext.projectId,
		t.state.contentVersionId,
		t.ruleContext.sourceVersionId
	].includes(u.sourceVersionId)) ? n("unknown", "例外の提示位置または版を確認できません。") : u && ![
		u.entityId,
		u.blockId,
		u.lineId
	].filter(Boolean).every((e) => t.state.seenIds.includes(e)) ? n("false", "例外の提示位置に到達していません。") : {
		value: "true",
		reasons: []
	};
}
function On(e, t) {
	if (!e.data.holderId) return;
	if (typeof e.data.value != "string" && e.data.value.type === "unknown") return {
		code: "CONDITION_UNKNOWN",
		message: "人物が取得する認識の内容が未確定です。"
	};
	let n = e.data.sourceIds ?? [], r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (!n.length || n.some((e) => !r.some((t) => t.id === e && _(t)))) return {
		code: "REFERENCE_INVALID",
		message: "人物の認識取得には採用中の出所が必要です。"
	};
	let i = e.data.validity, a = e.data.evidenceLocation ?? i?.presentationAnchor, o = t.ruleContexts?.[e.id] ?? t.ruleContext, s = o?.anchorBindings, c = a && s && a.sourceVersionId === o?.sourceVersionId ? {
		...a,
		entityId: s[a.entityId] ?? a.entityId,
		...a.blockId ? { blockId: s[a.blockId] ?? a.blockId } : {},
		...a.lineId ? { lineId: s[a.lineId] ?? a.lineId } : {}
	} : a, l = i?.worldRange;
	if (!c && (!l || l.start === null)) return {
		code: "CONDITION_UNKNOWN",
		message: "人物の認識取得には本文位置または世界内の取得時点が必要です。"
	};
	if (c) {
		if (c.positionStatus === "unresolved" || c.sourceVersionId && ![
			o?.projectId,
			o?.sourceVersionId,
			t.state.contentVersionId
		].includes(c.sourceVersionId)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置または固定版が未確認です。"
		};
		if (![
			c.entityId,
			c.blockId,
			c.lineId
		].filter(Boolean).every((e) => t.state.seenIds.includes(e))) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置へ到達していません。"
		};
		let e = t.currentPresentation;
		if (e) {
			let t = c.entityId === e.anchor.entityId && c.blockId === e.anchor.blockId && c.lineId === e.anchor.lineId && c.start === e.anchor.start, n = dr(e.project, c, e.anchor, e.target);
			if (!t && n !== !0) return {
				code: n === !1 ? "TRANSITION_BLOCKED" : "CONDITION_UNKNOWN",
				message: "認識取得の位置が、この効果の提示位置より後か、順序を確認できません。"
			};
		}
	}
	if (l) {
		if (!ge(o?.worldTick)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識の取得時点を照合する世界内tickが未入力です。"
		};
		if (l.start !== null && T(o.worldTick, l.start) < 0 || l.end !== null && T(o.worldTick, l.end) >= 0) return {
			code: "TRANSITION_BLOCKED",
			message: "認識の取得時点が宣言した有効期間外です。"
		};
	}
	let u = Fn(i?.routeCondition, {
		...t,
		ruleContext: o
	});
	if (u.value !== "true") return {
		code: u.value === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED",
		message: "認識を取得する経路条件が成立していません。"
	};
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/conditions.ts
var X = class extends Error {
	issues;
	constructor(e) {
		super(e.map((e) => e.message).join("、")), this.name = "DomainValidationError", this.issues = e;
	}
}, Z = (e, t = "condition", n = "VALIDATION_FAILED") => ({
	code: n,
	path: t,
	message: e
}), kn = (e) => ({
	type: "unknown",
	value: null,
	reason: e
}), Q = (e, t = []) => ({
	value: e,
	reasons: [...new Set(t)]
}), An = (e) => [...e.entities ?? [], ...e.referenceEntities ?? []].filter(_), jn = (e) => (e.variables ?? [...e.entities ?? [], ...e.referenceEntities ?? []].filter((e) => e.kind === "variable")).filter(_);
function Mn(e, t, n) {
	let r = jn(t).find((t) => t.id === e);
	if (!r) {
		if (t.variables || t.entities) return kn("状態変数が定義されていません。");
		let n = t.state.variableValues[e];
		if (!n) return kn("状態変数の値がありません。");
		let r = Jt(n);
		if (!r.ok) throw new X(r.issues);
		return n;
	}
	if (r.data.derived) {
		if (n.includes(e)) throw new X([Z("算出状態の参照が循環しています。", `variables.${e}.derived`)]);
		let i = In(r.data.derived, t, [...n, e]), a = Y(r, i, `variables.${e}.derived`);
		if (a.length) throw new X(a);
		return i;
	}
	if (r.data.externalContractId) {
		let e = t.externalValues?.[r.data.externalContractId];
		if (!e) return kn("宣言した外部値をまだ取得していません。");
		let n = Jt(e);
		if (!n.ok) throw new X(n.issues);
		let i = Y(r, e);
		if (i.length) throw new X(i);
		return e;
	}
	let i = t.state.variableValues[e];
	if (!i) return kn("状態変数の値がありません。");
	let a = Jt(i);
	if (!a.ok) throw new X(a.issues);
	let o = Y(r, i);
	if (o.length) throw new X(o);
	return i;
}
function Nn(e, t, n) {
	if (e.type === "unknown" || t.type === "unknown") return Q("unknown", [e.type === "unknown" ? e.reason : "", t.type === "unknown" ? t.reason : ""].filter(Boolean));
	if (e.type !== t.type) throw new X([Z("比較する値の型が一致しません。")]);
	if (![
		"eq",
		"ne",
		"lt",
		"le",
		"gt",
		"ge"
	].includes(n)) throw new X([Z("未知の比較演算です。")]);
	if (n === "eq" || n === "ne") return Q((n === "eq" ? e.value === t.value : e.value !== t.value) ? "true" : "false");
	if (e.type !== "integer" || t.type !== "integer") throw new X([Z("順序比較はintegerにだけ使えます。")]);
	return Q((n === "lt" ? e.value < t.value : n === "le" ? e.value <= t.value : n === "gt" ? e.value > t.value : e.value >= t.value) ? "true" : "false");
}
function Pn(e, t, n) {
	switch (e.op) {
		case "constant": return Q(e.value ? "true" : "false");
		case "all":
		case "any": {
			let r = e.children.map((e) => Pn(e, t, n)), i = r.flatMap((e) => e.reasons);
			return e.op === "all" ? Q(r.some((e) => e.value === "false") ? "false" : r.every((e) => e.value === "true") ? "true" : "unknown", i) : Q(r.some((e) => e.value === "true") ? "true" : r.every((e) => e.value === "false") ? "false" : "unknown", i);
		}
		case "not": {
			let r = Pn(e.child, t, n);
			return Q(r.value === "unknown" ? "unknown" : r.value === "true" ? "false" : "true", r.reasons);
		}
		case "compare": {
			let r = Mn(e.variableId, t, n);
			if (e.comparator !== "in") return Nn(r, e.value, e.comparator);
			let i = e.value.map((e) => Nn(r, e, "eq"));
			return Q(i.some((e) => e.value === "true") ? "true" : i.some((e) => e.value === "unknown") ? "unknown" : "false", i.flatMap((e) => e.reasons));
		}
		case "item": return t.entities && !An(t).some((t) => t.id === e.itemId && t.kind === "item") ? Q("unknown", ["指定した物品が定義されていません。"]) : Q(t.state.itemInstances.filter((t) => !t.consumed && (t.instanceId === e.itemId || t.typeId === e.itemId)).reduce((e, t) => e + t.quantity, 0) >= e.quantity ? "true" : "false");
		case "known": {
			if (t.entities && (!An(t).some((t) => t.id === e.assertionId && t.kind === "assertion") || !An(t).some((t) => t.id === e.holderId && t.kind === "character"))) return Q("unknown", ["認識の対象または人物が定義されていません。"]);
			let n = t.state.assertions.find((t) => t.assertionId === e.assertionId && t.holderId === e.holderId);
			return n ? Q(n.truth, n.truth === "unknown" ? ["人物の認識が未確定です。"] : []) : Q("false");
		}
		case "visited": return t.entities && !An(t).some((t) => t.id === e.entityId) ? Q("unknown", ["訪問先が定義されていません。"]) : Q((t.state.visitCounts[e.entityId] ?? 0) >= e.count ? "true" : "false");
		case "external": {
			if (t.entities && !An(t).some((t) => t.id === e.contractId && t.kind === "external_contract")) return Q("unknown", ["外部契約が定義されていません。"]);
			let n = t.externalValues?.[e.contractId];
			if (!n) return Q("unknown", ["外部値をまだ取得していません。"]);
			let r = Jt(n);
			if (!r.ok) throw new X(r.issues);
			if (n.type === "unknown") return Q("unknown", [n.reason]);
			if (n.type !== "boolean") throw new X([Z("外部条件はbooleanの結果が必要です。")]);
			return Q(n.value ? "true" : "false");
		}
	}
}
function Fn(e, t) {
	let n = qt(e ?? {
		op: "constant",
		value: !0
	});
	if (!n.ok) throw new X(n.issues);
	return Pn(n.value, t, []);
}
function In(e, t, n) {
	switch (e.op) {
		case "value": return e.value;
		case "variable": return Mn(e.variableId, t, n);
		case "if": {
			let r = Pn(e.condition, t, n);
			return r.value === "unknown" ? kn(r.reasons.join("、") || "分岐条件が未定です。") : In(r.value === "true" ? e.then : e.else, t, n);
		}
		case "add":
		case "subtract":
		case "multiply": {
			let r = In(e.left, t, n), i = In(e.right, t, n);
			if (r.type === "unknown" || i.type === "unknown") return kn([r.type === "unknown" ? r.reason : "", i.type === "unknown" ? i.reason : ""].filter(Boolean).join("、"));
			if (r.type !== "integer" || i.type !== "integer") throw new X([Z("算術の入力はintegerです。", "expression")]);
			let a = e.op === "add" ? r.value + i.value : e.op === "subtract" ? r.value - i.value : r.value * i.value;
			if (!Number.isSafeInteger(a)) throw new X([Z("算術結果が安全な整数の範囲を超えています。", "expression")]);
			return {
				type: "integer",
				value: a
			};
		}
		default: {
			let r = Pn(e, t, n);
			return r.value === "unknown" ? kn(r.reasons.join("、")) : {
				type: "boolean",
				value: r.value === "true"
			};
		}
	}
}
function Ln(e, t = e.projectId, n = [], r = {}) {
	let i = Qe(t), a = [...e.entities, ...n].filter((e) => e.kind === "variable" && _(e));
	for (let e of a) i.variableValues[e.id] = structuredClone(e.data.initial);
	for (let t of a) (t.data.derived || t.data.externalContractId && r[t.data.externalContractId]) && (i.variableValues[t.id] = Mn(t.id, {
		state: i,
		variables: a,
		entities: e.entities,
		referenceEntities: n,
		externalValues: r
	}, []));
	return i;
}
function Rn(e) {
	let t = [];
	for (let n of jn(e)) for (let [r, i] of (n.data.exclusions ?? []).entries()) {
		let a = Fn({
			op: "all",
			children: [{
				op: "compare",
				variableId: n.id,
				comparator: "eq",
				value: i.value
			}, {
				op: "compare",
				variableId: i.variableId,
				comparator: "eq",
				value: i.otherValue
			}]
		}, e);
		if (a.value === "false") continue;
		let o = (i.exceptions ?? []).map((t) => Dn(t, {
			...e,
			ruleContext: e.ruleContexts?.[n.id] ?? e.ruleContext
		}));
		if (a.value === "true" && o.some((e) => e.value === "true")) continue;
		let s = a.value === "unknown" || o.some((e) => e.value === "unknown");
		t.push(Z(s ? `相互排他を評価できません。${i.reason}` : `相互排他に反する状態です。${i.reason}`, `${n.id}.exclusions[${r}]`, s ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED"));
	}
	return t;
}
function zn(e, t) {
	return e.type === t.type && e.value === t.value;
}
function Bn(e, t, n, r, i) {
	if (r.operation === "reset" || zn(t, n)) return;
	let a = An(i).filter((t) => t.kind === "quest" && t.data.stateVariableId === e.id), o = [...(e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})), ...a.flatMap((e) => (e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})))];
	if (!o.length && !a.length) return;
	if (t.type === "unknown") throw new X([Z("遷移前の状態が未定です。", `variables.${e.id}`, "CONDITION_UNKNOWN")]);
	let s = o.filter(({ rule: e }) => zn(e.from, t) && zn(e.to, n));
	if (s.some(({ rule: e }) => !e.exception && !e.exceptionDetails)) return;
	let c = [...s.flatMap(({ rule: e, ownerId: t }) => e.exceptionDetails ? [Dn(e.exceptionDetails, {
		...i,
		ruleContext: i.ruleContexts?.[t] ?? i.ruleContext
	})] : []), ...r.exceptionDetails ? [Dn(r.exceptionDetails, i)] : []];
	if (!c.some((e) => e.value === "true")) throw new X([Z(c.flatMap((e) => e.reasons).join("、") || "許容遷移表にない状態更新です。明示resetまたは対象・期限・根拠付きの例外が必要です。", `variables.${e.id}`, c.some((e) => e.value === "unknown") ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED")]);
}
function Vn(e, t, n) {
	return e.itemInstances.filter((e) => n ? e.instanceId === n : e.instanceId === t || e.typeId === t);
}
function Hn(e, t, n, r) {
	let i = jn(n), a = [...n.entities ?? [], ...n.referenceEntities ?? []].find((e) => e.id === t.targetId && _(e)), o = (e, n = "TRANSITION_BLOCKED") => {
		throw new X([Z(e, `effects.${r ?? t.targetId}`, n)]);
	};
	if ([
		"set",
		"add",
		"reset"
	].includes(t.operation)) {
		let a = i.find((e) => e.id === t.targetId);
		a || o("更新先の状態変数がありません。", "REFERENCE_INVALID"), a.data.derived && o("算出状態へ直接代入できません。", "VALIDATION_FAILED");
		let s = Mn(a.id, {
			...n,
			state: e
		}, []), c = t.operation === "reset" ? structuredClone(t.value ?? a.data.initial) : t.value;
		c || o("状態更新の入力値がありません。", "VALIDATION_FAILED"), t.operation === "add" && (s.type === "unknown" && o(s.reason || "加算元の状態が未定です。", "CONDITION_UNKNOWN"), (s.type !== "integer" || c.type !== "integer" || a.data.valueType !== "integer") && o("addはinteger状態とinteger入力だけを使えます。", "VALIDATION_FAILED"), c = {
			type: "integer",
			value: s.value + c.value
		});
		let l = Y(a, c, `effects.${r ?? t.targetId}.value`, t.operation === "reset");
		if (l.length) throw new X(l.map((e) => ({
			...e,
			code: e.code === "CONDITION_UNKNOWN" ? e.code : "TRANSITION_BLOCKED"
		})));
		Bn(a, s, c, t, n), e.variableValues[a.id] = structuredClone(c);
		return;
	}
	if (t.operation === "mark_seen") {
		n.entities && !a && o("既読対象が定義されていません。", "REFERENCE_INVALID"), e.seenIds.includes(t.targetId) || e.seenIds.push(t.targetId);
		return;
	}
	if (t.operation === "assert") {
		(!a || a.kind !== "assertion") && o("認識効果の対象には事実・認識が必要です。", "REFERENCE_INVALID"), t.value && t.value.type !== "boolean" && o("認識効果の入力はbooleanです。", "VALIDATION_FAILED");
		let i = t.value?.type === "boolean" && !t.value.value ? "false" : "true", s = a.data.holderId ?? null;
		if (i === "true") {
			let e = On(a, n);
			e && o(e.message, e.code);
		}
		let c = e.assertions.find((e) => e.assertionId === a.id && e.holderId === s);
		c ? (c.truth = i, r && (c.sourceEffectId = r)) : e.assertions.push({
			assertionId: a.id,
			holderId: s,
			truth: i,
			...r ? { sourceEffectId: r } : {}
		});
		return;
	}
	if ((!a || a.kind !== "item") && o("物品効果の対象には宣言済みの物品が必要です。", "REFERENCE_INVALID"), t.instanceId) {
		let e = An(n).find((e) => e.id === t.instanceId);
		(!e || e.kind !== "item" || e.data.itemMode !== "instance") && o("指定した物品個体が定義されていません。", "REFERENCE_INVALID"), (a.data.itemMode === "type" && e.data.typeId !== a.id || a.data.itemMode === "instance" && e.id !== a.id) && o("指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
	}
	let s = t.value?.type === "integer" ? t.value.value : 1;
	if (t.operation === "grant") {
		t.value && t.value.type !== "integer" && o("取得数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(s) || s < 1) && o("取得数量は正の安全な整数です。", "VALIDATION_FAILED");
		let r = a.data.itemMode === "instance" ? a : t.instanceId ? An(n).find((e) => e.id === t.instanceId && e.kind === "item" && e.data.itemMode === "instance") : void 0;
		if (t.instanceId && !r && o("指定した物品個体がありません。", "REFERENCE_INVALID"), r) {
			s !== 1 && o("物品個体の数量は1です。"), a.data.itemMode === "type" && r.data.typeId !== a.id && o("個体が指定した物品種類に属していません。", "REFERENCE_INVALID"), e.itemInstances.some((e) => e.instanceId === r.id) && o("同じ物品個体を二重取得・復活させられません。");
			let t = r.data.typeId;
			t || o("物品個体の種類が未定義です。", "REFERENCE_INVALID"), e.itemInstances.push({
				instanceId: r.id,
				typeId: t,
				quantity: 1,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		} else {
			let t = e.itemInstances.find((e) => e.instanceId === a.id && e.typeId === a.id);
			t ? (Number.isSafeInteger(t.quantity + s) || o("物品数量が安全な整数範囲を超えています。"), t.quantity += s, t.consumed = !1) : e.itemInstances.push({
				instanceId: a.id,
				typeId: a.id,
				quantity: s,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		}
		return;
	}
	let c = Vn(e, t.targetId, t.instanceId).filter((e) => !e.consumed && e.quantity > 0);
	if (c.some((e) => a.data.itemMode === "type" ? e.typeId !== a.id : e.instanceId !== a.id || e.typeId !== a.data.typeId) && o("実行状態の個体と効果の対象物品が一致しません。", "REFERENCE_INVALID"), t.operation === "consume") {
		t.reason?.trim() || o("消費・破壊の理由を記録してください。", "VALIDATION_FAILED"), t.value && t.value.type !== "integer" && o("消費数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(s) || s < 1 || c.reduce((e, t) => e + t.quantity, 0) < s) && o("物品が不足しています。");
		let e = s;
		for (let n of c) {
			let r = Math.min(n.quantity, e);
			if (n.quantity -= r, e -= r, n.reason = t.reason, n.consumed = n.quantity === 0, e === 0) break;
		}
		return;
	}
	if (t.operation === "move") {
		t.value?.type !== "ref" && o("移動先には人物・グループ・場所のrefが必要です。", "VALIDATION_FAILED");
		let e = An(n).find((e) => e.id === t.value?.value);
		(!e || ![
			"character",
			"group",
			"place"
		].includes(e.kind)) && o("物品の移動先がありません。", "REFERENCE_INVALID"), c.length !== 1 && o("移動する現存物品を一個体に特定してください。");
		let r = c[0];
		r.ownerId = e.kind === "place" ? null : e.id, r.locationId = e.kind === "place" ? e.id : null;
		return;
	}
	o("未対応の物品操作です。", "VALIDATION_FAILED");
}
function Un(e, t, n = { state: e }) {
	let r = Yt(e);
	if (!r.ok) return {
		ok: !1,
		state: e,
		issues: r.issues
	};
	let i = structuredClone(e);
	try {
		for (let [e, n] of t.entries()) {
			if ("data" in n && !_(n)) throw new X([Z("削除・不採用・別案の効果は実行できません。", `effects[${e}]`, "REFERENCE_INVALID")]);
			let t = Zt("data" in n ? n.data : n, `effects[${e}]`);
			if (!t.ok) throw new X(t.issues);
		}
		for (let [e, r] of t.entries()) {
			let t = "data" in r ? r.data : r, a = "id" in r ? r.id : void 0, o = {
				...n,
				currentPresentation: n.effectPresentations?.[e] ?? n.currentPresentation,
				state: i,
				ruleContext: a && n.ruleContexts?.[a] || n.ruleContext
			}, s = Fn(t.condition, o);
			if (s.value === "unknown") throw new X([Z(s.reasons.join("、") || "効果の条件が未定です。", `effects[${e}].condition`, "CONDITION_UNKNOWN")]);
			s.value !== "false" && Hn(i, t, o, a);
		}
		let e = /* @__PURE__ */ new Set();
		for (let t of i.itemInstances) {
			if (e.has(t.instanceId) || t.ownerId && t.locationId || t.consumed && t.quantity !== 0 || !t.consumed && t.quantity < 1) throw new X([Z("物品の個体ID・所在・数量が不整合です。", "itemInstances", "TRANSITION_BLOCKED")]);
			e.add(t.instanceId);
		}
		for (let e of jn(n)) e.data.derived && (i.variableValues[e.id] = Mn(e.id, {
			...n,
			state: i
		}, []));
		let r = Rn({
			...n,
			state: i
		});
		if (r.length) throw new X(r);
		return {
			ok: !0,
			state: i
		};
	} catch (t) {
		return {
			ok: !1,
			state: e,
			issues: t instanceof X ? t.issues : [Z(t instanceof Error ? t.message : "効果を適用できません。", "effects")]
		};
	}
}
function Wn(e, t, n) {
	if (!t.length) return {
		ok: !0,
		state: structuredClone(e)
	};
	let r = structuredClone(e), i = [], a = [];
	for (let e of t) for (let t of jn(n)) {
		if (t.data.derived || t.data.externalContractId) continue;
		let n = t.data.resetRules?.find((t) => t.on === e), o = e === "full_reset" || e === "new_loop" && [
			"scene",
			"chapter",
			"run"
		].includes(t.data.scope);
		if (!n && !o) continue;
		let s = n?.value ?? t.data.initial;
		i.push({
			operation: "reset",
			targetId: t.id,
			value: s
		}), a.push({
			variableId: t.id,
			on: e,
			before: structuredClone(r.variableValues[t.id] ?? {
				type: "unknown",
				value: null,
				reason: "途中開始時の値が未指定です。"
			}),
			after: structuredClone(s),
			reason: n?.reason || (n ? "宣言した初期化規則" : `有効範囲 ${t.data.scope} の初期化`)
		}), r.variableValues[t.id] = structuredClone(s);
	}
	let o = Un(e, i, n);
	return o.ok && t.length && (a.length || e.resetCauses) && (o.state.resetCauses = a), o;
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/writingWorkspace.ts
function Gn(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function Kn(e) {
	let { history: t, snapshots: n, ...r } = e, i = structuredClone(r);
	return delete i.authorAlternatives, i;
}
function qn(e) {
	let t = e.versions.find((t) => t.id === e.headVersionId);
	if (!t) throw Error("別案の現在版が見つかりません。");
	return structuredClone(t.content);
}
function Jn(e, t, n = "別案の編集", r = (/* @__PURE__ */ new Date()).toISOString(), i = globalThis.crypto.randomUUID(), a) {
	let o = Kn(t);
	if (o.projectId !== e.projectId) throw Error("別の作品の内容をこの別案へ保存できません。");
	if (!e.versions.some((t) => t.id === e.headVersionId)) throw Error("別案の現在版が見つかりません。");
	let s = {
		id: i,
		parentVersionId: e.headVersionId,
		label: n.trim() || "別案の編集",
		createdAt: r,
		content: o,
		...a ? { structurePlan: structuredClone(a) } : {}
	};
	return {
		...structuredClone(e),
		versions: [...e.versions, s],
		headVersionId: s.id,
		updatedAt: r
	};
}
function Yn(e, t) {
	return JSON.stringify(e) === JSON.stringify(t);
}
function Xn(e, t, n) {
	return [
		e,
		t ?? "",
		...n
	].map((e) => encodeURIComponent(e)).join(":");
}
function Zn(e, t, n, r) {
	if (e === "presentation") return Gn(t);
	if (e === "project") return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, t);
	let i = (e === "entity" ? t.entities : t.relations).find((e) => e.id === n);
	if (i) return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, i);
}
function Qn(e, t, n, r, i, a, o, s) {
	if (Yn(a, s) || Yn(o, s)) return;
	let c = a === void 0 ? "add" : s === void 0 ? "remove" : "replace";
	e.push({
		key: Xn(t, n, r),
		scope: t,
		...n ? { itemId: n } : {},
		path: r,
		label: i,
		kind: c,
		baseValue: structuredClone(a),
		canonicalValue: structuredClone(o),
		alternativeValue: structuredClone(s),
		conflict: !Yn(o, a) && !Yn(o, s)
	});
}
function $n(e) {
	return new Map(e.entities.map((e) => [e.id, e]));
}
function er(e, t) {
	if (t.projectId !== e.projectId) throw Error("別の作品とは比較できません。");
	let n = e.baseContent, r = qn(e), i = Kn(t), a = [];
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) Qn(a, "project", void 0, [e], {
		name: "作品名",
		calendarId: "標準暦",
		mainStart: "本編開始時点",
		calendars: "暦の定義",
		worldReferences: "参照する世界版"
	}[e], n[e], i[e], r[e]);
	let o = $n(n), s = $n(r), c = $n(i), l = /* @__PURE__ */ new Set([
		"id",
		"projectId",
		"kind",
		"revision",
		"createdAt",
		"updatedAt"
	]);
	for (let e of /* @__PURE__ */ new Set([...o.keys(), ...s.keys()])) {
		let t = o.get(e), n = s.get(e), r = c.get(e);
		if (!t || !n) {
			Qn(a, "entity", e, [], `${t?.name ?? n?.name ?? "情報"} · 情報全体`, t, r, n);
			continue;
		}
		let i = /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)]);
		for (let o of i) {
			if (l.has(o) || o === "data" || o === "customValues") continue;
			let i = t[o], s = n[o], c = r && r[o];
			Qn(a, "entity", e, [o], `${n.name} · ${o}`, i, c, s);
		}
		let u = t.data, d = n.data, f = r?.data;
		for (let r of /* @__PURE__ */ new Set([...Object.keys(u), ...Object.keys(d)])) t.kind === "chapter" && r === "sceneIds" || t.kind === "scene" && r === "chapterId" || Qn(a, "entity", e, ["data", r], `${n.name} · ${r}`, u[r], f?.[r], d[r]);
		let p = t.customValues, m = n.customValues, h = r?.customValues;
		for (let t of /* @__PURE__ */ new Set([...Object.keys(p), ...Object.keys(m)])) Qn(a, "entity", e, ["customValues", t], `${n.name} · 独自項目 ${t}`, p[t], h?.[t], m[t]);
	}
	let u = new Map(n.relations.map((e) => [e.id, e])), d = new Map(r.relations.map((e) => [e.id, e])), f = new Map(i.relations.map((e) => [e.id, e]));
	for (let e of /* @__PURE__ */ new Set([...u.keys(), ...d.keys()])) {
		let t = u.get(e), n = d.get(e), r = f.get(e);
		if (!t || !n) {
			Qn(a, "relation", e, [], "関係 · 全体", t, r, n);
			continue;
		}
		for (let i of /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)])) {
			if ([
				"id",
				"projectId",
				"revision"
			].includes(i)) continue;
			let o = t[i], s = n[i], c = r && r[i];
			Qn(a, "relation", e, [i], `関係 ${t.fromId.slice(-6)} → ${t.toId.slice(-6)} · ${i}`, o, c, s);
		}
	}
	let p = Gn(n), m = Gn(r), h = Gn(i);
	return !Yn(p, m) && !Yn(h, m) && a.push({
		key: Xn("presentation", void 0, ["all"]),
		scope: "presentation",
		path: ["all"],
		label: "章と場面の提示順",
		kind: "replace",
		baseValue: p,
		canonicalValue: h,
		alternativeValue: m,
		conflict: !Yn(h, p)
	}), a.sort((e, t) => e.label.localeCompare(t.label) || e.key.localeCompare(t.key));
}
function tr(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	return t.length && (n === void 0 ? delete i[t[t.length - 1]] : i[t[t.length - 1]] = structuredClone(n)), r;
}
function nr(e, t) {
	let n = structuredClone(e), r = new Map(n.entities.filter((e) => e.kind === "chapter").map((e) => [e.id, e]));
	for (let e of r.values()) e.data.sceneIds = t.chapters.find((t) => t.id === e.id)?.sceneIds.filter((e) => n.entities.some((t) => t.kind === "scene" && t.id === e)) ?? [];
	for (let e of n.entities) e.kind === "scene" && (e.data.chapterId = t.scenes.find((t) => t.id === e.id)?.chapterId ?? null);
	let i = t.chapterOrder.flatMap((e) => {
		let t = r.get(e);
		return t ? [t] : [];
	});
	return n.entities.flatMap((e, t) => e.kind === "chapter" && !e.deletedAt ? [t] : []).forEach((e, t) => {
		i[t] && (n.entities[e] = i[t]);
	}), n;
}
function rr(e, t, n) {
	if (t.scope === "presentation") return nr(e, n);
	if (t.scope === "project") return tr(e, t.path, n);
	let r = t.scope === "entity" ? "entities" : "relations", i = [...e[r]], a = i.findIndex((e) => e.id === t.itemId);
	if (!t.path.length) n === void 0 ? a >= 0 && i.splice(a, 1) : a < 0 ? i.push(structuredClone(n)) : i[a] = structuredClone(n);
	else if (a >= 0) i[a] = tr(i[a], t.path, n);
	else if (n !== void 0) throw Error(`差分の対象が見つかりません: ${t.itemId}`);
	return {
		...e,
		[r]: i
	};
}
function ir(e, t, n, r, i = (/* @__PURE__ */ new Date()).toISOString(), a = globalThis.crypto.randomUUID()) {
	let o = er(t, e);
	if ([...r].some((e) => !o.some((t) => t.key === e))) throw Error("選択した差分は現在の別案・正本から確認できません。内容を比較し直してください。");
	let s = o.filter((e) => r.has(e.key));
	if (!s.length) throw Error("採用する変更を選んでください。");
	if (s.some((e) => e.conflict)) throw Error("分岐元の後に正本が更新された項目があります。競合を確認し、別案の最新内容へ取り込んでください。");
	let c = Kn(e), l = [];
	for (let e of [...s].sort((e, t) => +(e.scope === "presentation") - (t.scope === "presentation"))) {
		let t = Zn(e.scope, c, e.itemId, e.path), n = e.alternativeValue;
		l.push({
			key: e.key,
			scope: e.scope,
			...e.itemId ? { itemId: e.itemId } : {},
			path: [...e.path],
			label: e.label,
			before: t === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(t)
			},
			after: n === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(n)
			}
		}), c = rr(c, e, e.alternativeValue);
	}
	if (c.projectId !== e.projectId) throw Error("別案のprojectIdは変更できません。");
	let { history: u, ...d } = e;
	return {
		project: {
			...structuredClone(d),
			...c,
			snapshots: e.snapshots,
			history: e.history
		},
		receipt: {
			id: a,
			createdAt: i,
			alternativeVersionId: t.headVersionId,
			sourceSnapshotId: t.sourceSnapshotId ?? null,
			selectedChangeKeys: [...r].sort(),
			fromCanonicalRevision: e.revision,
			patches: l
		}
	};
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/runtimeVersions.ts
async function ar(e, t = e.projectId, n = {}, r) {
	let i = t === e.projectId ? e : e.snapshots.find((e) => e.id === t);
	if (!i) throw new X([{
		code: "REFERENCE_INVALID",
		path: "contentVersionId",
		message: "実行する固定版がありません。"
	}]);
	let a = n.worldSnapshots ? r?.stableRegistries.has(n.worldSnapshots) ? n.worldSnapshots : r ? m(n.worldSnapshots, r) : structuredClone(n.worldSnapshots) : {}, o = n.worlds ? structuredClone(n.worlds) : void 0, s = {
		...n,
		worldSnapshots: a,
		worlds: o
	}, c = "content" in i, u = structuredClone(c ? i.content : i), f = c ? i.contentHash : void 0, p = "content" in i ? i.id : e.projectId, h = structuredClone(e.snapshots), { authorAlternatives: _, snapshots: v, history: ee, ...y } = u, te = {
		...y,
		snapshots: h,
		history: []
	};
	if (f && await d(l(y)) !== f) throw new X([{
		code: "INTEGRITY_FAILED",
		path: `snapshots.${p}.contentHash`,
		message: "固定版の内容ハッシュが一致しません。実行を停止しました。"
	}]);
	let b = /* @__PURE__ */ new Set(), x = [te];
	for (let e = 0; e < x.length; e++) for (let t of x[e].entities) if ((t.kind === "scene" || t.kind === "flow_node") && t.data.reuse && t.data.reuse.mode !== "clone") {
		let e = t.data.reuse.pinnedSnapshotId;
		if (b.has(e)) continue;
		b.add(e);
		let n = h.find((t) => t.id === e);
		if (!n || await d(l(n.content)) !== n.contentHash) throw new X([{
			code: "INTEGRITY_FAILED",
			path: `snapshots.${e}`,
			message: "共通元の固定版がないか、内容hashが一致しません。"
		}]);
		x.push({
			...n.content,
			snapshots: h,
			history: []
		});
	}
	let S = await g(ce(te, h), a, "worldReferences", r);
	if (S.length) throw new X(S);
	let C = Sn(te, s);
	if (!C.ok) throw new X(C.issues);
	return te;
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/externalInputs.ts
function or(e, t, n, r = []) {
	let i = [], a = [...e.entities, ...r].filter(_);
	n && (n.mode !== "actual" || !/^[0-9a-f]{64}$/.test(n.receiptHash)) && i.push({
		code: "INTEGRITY_FAILED",
		path: "receiptHash",
		message: "実際の外部入力には検証済み受信記録のSHA-256が必要です。"
	});
	for (let [e, n] of Object.entries(t)) {
		let t = `externalValues.${e}`, r = a.find((t) => t.id === e && t.kind === "external_contract");
		if (!r) {
			i.push({
				code: "REFERENCE_INVALID",
				path: t,
				message: "入力先の外部契約が存在しないか、削除・不採用です。"
			});
			continue;
		}
		let o = Jt(n);
		if (!o.ok) {
			i.push(...o.issues.map((e) => ({
				...e,
				path: t
			})));
			continue;
		}
		if (n.type !== "unknown" && n.type !== r.data.outputType) {
			i.push({
				code: "VALIDATION_FAILED",
				path: t,
				message: "実際の外部値と契約の出力型が違います。"
			});
			continue;
		}
		n.type === "unknown" && r.data.missingPolicy === "block" && i.push({
			code: "CONDITION_UNKNOWN",
			path: t,
			message: n.reason || "この外部契約は未確認値で進められません。"
		});
		for (let r of a) r.kind === "variable" && r.data.externalContractId === e && i.push(...Y(r, n, t, !0));
	}
	return i;
}
structuredClone;
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/presentation.ts
var $ = (e, t) => e.entities.filter((e) => e.kind === t && _(e)), sr = (e, t, n = "REFERENCE_INVALID") => ({
	ok: !1,
	issues: [{
		code: n,
		path: e,
		message: t
	}]
});
function cr(e, t) {
	let n = $(e, "flow_node").find((e) => e.id === t.nodeId), r = $(e, "scene").find((e) => e.id === (t.sceneId ?? n?.data.sceneId));
	return {
		projectId: e.projectId,
		worldTick: t.worldTick,
		graphId: n ? $(e, "flow_graph").find((e) => e.data.nodeIds.includes(n.id))?.id : void 0,
		chapterId: r?.data.chapterId ?? (r ? $(e, "chapter").find((e) => e.data.sceneIds.includes(r.id))?.id : void 0)
	};
}
function lr(e, t) {
	let n = $(e, "flow_node").find((e) => e.id === t.nodeId), r = $(e, "scene").find((e) => e.id === (t.sceneId ?? n?.data.sceneId)), i = n?.data.executionPolicy ?? (n?.data.nodeType === "automatic" ? "first_match" : "manual_choice");
	return [.../* @__PURE__ */ new Set([...r?.data.dialogueLineIds ?? [], ...n && i === "manual_choice" ? $(e, "flow_edge").filter((e) => e.data.fromId === n.id).flatMap((e) => e.data.choiceLineId ? [e.data.choiceLineId] : []) : []])];
}
function ur(e, t, n, r, i) {
	if (n.positionStatus === "unresolved") return !1;
	let a = i ? y(e, i) : void 0;
	if (n.sourceVersionId && ![
		e.projectId,
		t.contentVersionId,
		y(e, n.entityId)?.sourceVersionId,
		a?.sourceVersionId
	].includes(n.sourceVersionId)) return !1;
	let o = $(e, "flow_node").find((e) => e.id === r.nodeId), s = r.sceneId ?? o?.data.sceneId;
	$(e, "scene").find((e) => e.id === s);
	let c = lr(e, r);
	return [
		r.nodeId,
		s,
		...c
	].includes(n.entityId) ? [
		n.entityId,
		n.blockId,
		n.lineId
	].filter((e) => !!e).every((e) => t.seenIds.includes(e)) : !1;
}
function dr(e, t, n, r) {
	if (t.positionStatus === "unresolved" || n.positionStatus === "unresolved") return;
	let i = $(e, "flow_node").find((e) => e.id === r.nodeId), a = $(e, "scene").find((e) => e.id === (r.sceneId ?? i?.data.sceneId)), o = lr(e, r), s = [...(a?.data.body ?? []).map((e) => e.id)];
	for (let t of o) s.push(t, ...($(e, "dialogue_line").find((e) => e.id === t)?.data.text ?? []).map((e) => e.id));
	let c = t.blockId ?? t.lineId ?? (o.includes(t.entityId) ? t.entityId : void 0), l = n.blockId ?? n.lineId ?? (o.includes(n.entityId) ? n.entityId : void 0), u = s.indexOf(c ?? ""), d = s.indexOf(l ?? "");
	if (u >= 0 && d >= 0 && u !== d) return u < d;
	if (c === l && t.entityId === n.entityId && t.start != null && n.start != null && t.start !== n.start && !(t.start < n.start && t.end != null && t.end > n.start || n.start < t.start && n.end != null && n.end > t.start)) return t.start < n.start;
}
function fr(e, t, n) {
	let r = Yt(t);
	if (!r.ok) return {
		ok: !1,
		issues: r.issues
	};
	let i = or(e, n.externalValues ?? {}, void 0, n.referenceEntities);
	if (i.length) return {
		ok: !1,
		issues: i
	};
	try {
		let r = n.nodeId ? $(e, "flow_node").find((e) => e.id === n.nodeId) : void 0;
		if (n.nodeId && !r) return sr("presentation.nodeId", "提示する分岐が存在しないか、削除・不採用です。");
		let i = n.sceneId ?? r?.data.sceneId ?? void 0;
		if (!r && !i) return sr("presentation", "提示する場面または分岐を指定してください。");
		let a = i ? $(e, "scene").find((e) => e.id === i) : void 0;
		if (i && !a) return sr("presentation.sceneId", "提示する場面が存在しないか、削除・不採用です。");
		let o = cr(e, {
			...n,
			sceneId: i
		}), s = Rn({
			state: t,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: o,
			ruleContexts: le(e, o)
		});
		if (s.length) return {
			ok: !1,
			issues: s
		};
		let c = {
			...n,
			sceneId: i
		}, l = structuredClone(t), u = new Set(l.seenIds);
		if (r && (l.presentationPosition = r.id, l.visitCounts[r.id] = (l.visitCounts[r.id] ?? 0) + 1, u.add(r.id)), a) {
			u.add(a.id), l.visitCounts[a.id] = (l.visitCounts[a.id] ?? 0) + 1;
			for (let e of a.data.blockIds ?? []) u.add(e);
			for (let e of a.data.body) u.add(e.id);
		}
		for (let t of lr(e, c)) {
			let n = $(e, "dialogue_line").find((e) => e.id === t);
			if (!n) return sr(`${r?.id ?? a?.id}.dialogueLineIds`, "提示する台詞が存在しないか、削除・不採用です。");
			u.add(n.id), l.visitCounts[n.id] = (l.visitCounts[n.id] ?? 0) + 1;
			for (let e of n.data.text) u.add(e.id);
		}
		l.seenIds = [...u];
		let d = [...$(e, "variable"), ...(n.referenceEntities ?? []).filter((e) => e.kind === "variable" && _(e))], f = cr(e, c), p = {
			state: l,
			variables: d,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: f,
			ruleContexts: le(e, f)
		}, m = [], h = [];
		for (let n of $(e, "disclosure")) {
			let i = ue(e, n.data.anchor, n.id), o = n.data.targetScope, s = {
				...p,
				ruleContext: p.ruleContexts[n.id] ?? p.ruleContext
			}, u = o ? En(o, s) : { value: "true" };
			if (u.value === "false" || i.sourceVersionId && ![
				e.projectId,
				t.contentVersionId,
				y(e, i.entityId)?.sourceVersionId,
				y(e, n.id)?.sourceVersionId
			].includes(i.sourceVersionId)) continue;
			let d = lr(e, c);
			if (![
				r?.id,
				a?.id,
				...d
			].includes(i.entityId)) continue;
			if (u.value === "unknown") return sr(`${n.id}.targetScope`, "開示の対象範囲・経路を確認できません。", "CONDITION_UNKNOWN");
			if (i.positionStatus === "unresolved" && [
				r?.id,
				a?.id,
				...d
			].includes(i.entityId)) return sr(`${n.id}.anchor`, i.positionReason || "提示位置が不明です。本文へ再リンクしてください。", "CONDITION_UNKNOWN");
			if (!ur(e, l, i, c, n.id)) continue;
			let f = Fn({
				op: "all",
				children: [n.data.condition ?? {
					op: "constant",
					value: !0
				}, o?.routeCondition ?? {
					op: "constant",
					value: !0
				}]
			}, s);
			if (m.push({
				targetId: n.id,
				...f
			}), f.value === "unknown") return sr(`${n.id}.condition`, f.reasons.join("、") || "この場面の開示条件が未確認です。", "CONDITION_UNKNOWN");
			f.value === "true" && h.push(n);
		}
		let g = h.filter((e) => (e.data.knowledgeEffects?.length ?? 0) > 0);
		for (let t = 0; t < g.length; t++) for (let n = t + 1; n < g.length; n++) if (dr(e, ue(e, g[t].data.anchor, g[t].id), ue(e, g[n].data.anchor, g[n].id), c) === void 0) return sr(`${r?.id ?? a?.id}.disclosures`, "複数の開示効果の提示順が確定していません。段落と文字位置を指定してください。", "CONDITION_UNKNOWN");
		g.sort((t, n) => dr(e, ue(e, t.data.anchor, t.id), ue(e, n.data.anchor, n.id), c) ? -1 : 1);
		let v = [], ee = [];
		for (let t of g) for (let r of t.data.knowledgeEffects ?? []) {
			let i = [...e.entities, ...n.referenceEntities ?? []].find((e) => e.kind === "effect" && e.id === r && _(e));
			if (!i) return sr(`${t.id}.knowledgeEffects`, "開示に指定した効果が存在しないか、削除・不採用です。");
			v.push(i), ee.push({
				project: e,
				target: c,
				anchor: ue(e, t.data.anchor, t.id)
			});
		}
		let te = Un(l, v, {
			...p,
			effectPresentations: ee
		});
		return te.ok ? (te.state.seenIds = [.../* @__PURE__ */ new Set([...te.state.seenIds, ...h.map((e) => e.id)])], {
			ok: !0,
			state: te.state,
			observationState: structuredClone(l),
			conditions: m
		}) : te;
	} catch (e) {
		return {
			ok: !1,
			issues: e instanceof X ? e.issues : [{
				code: "VALIDATION_FAILED",
				path: "presentation",
				message: e instanceof Error ? e.message : "提示を検証できません。"
			}]
		};
	}
}
function pr(e, t, n) {
	let { sceneId: r, previousSceneId: i } = n, a = cr(e, { sceneId: i }), o = cr(e, { sceneId: r }), s = i && i !== r ? ["scene_end"] : [];
	a.chapterId && a.chapterId !== o.chapterId && s.push("chapter_end");
	let c = Wn({
		...t,
		...t.resetCauses ? { resetCauses: [] } : {}
	}, s, {
		state: t,
		entities: e.entities,
		referenceEntities: n.referenceEntities,
		externalValues: n.externalValues,
		ruleContext: cr(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick
		}),
		ruleContexts: le(e, cr(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick
		}))
	});
	if (!c.ok) return c;
	let l = fr(e, c.state, n);
	if (!l.ok) return l;
	if (n.last) {
		let t = Wn(l.state, [
			"scene_end",
			"chapter_end",
			"run_end"
		], {
			state: l.state,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: cr(e, n),
			ruleContexts: le(e, cr(e, n))
		});
		if (!t.ok) return t;
		l.state = t.state, (c.state.resetCauses || t.state.resetCauses) && (l.state.resetCauses = [...c.state.resetCauses ?? [], ...t.state.resetCauses ?? []]);
	}
	return l;
}
//#endregion
export { d as $, Cn as A, le as B, Ue as C, on as D, We as E, ge as F, g as G, p as H, we as I, c as J, i as K, ce as L, Sn as M, Yt as N, sn as O, Y as P, f as Q, te as R, Qe as S, qe as T, m as U, _ as V, h as W, l as X, u as Y, o as Z, Be as _, ar as a, Xe as b, Kn as c, Ln as d, s as et, Wn as f, Ie as g, Ve as h, or as i, Xt as j, Ge as k, Un as l, D as m, fr as n, t as nt, Jn as o, Rn as p, r as q, cr as r, n as rt, ir as s, pr as t, e as tt, Fn as u, tn as v, Je as w, Ze as x, nn as y, y as z };
