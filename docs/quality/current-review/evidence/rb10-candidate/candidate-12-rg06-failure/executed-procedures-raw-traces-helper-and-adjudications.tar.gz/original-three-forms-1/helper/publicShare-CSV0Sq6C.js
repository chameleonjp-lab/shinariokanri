import { $ as e, X as t, Z as n } from "./presentation-BwR6ApEV.js";
import { t as r } from "./protocol-BqfH7ABH.js";
import { n as i, r as a } from "./exportPreparation-1BCYwa_v.js";
//#region ../shinariokanri-rb10-basic-registration/src/sync/publicShare.ts
var o = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
async function s(s) {
	let c = n(t(s), "shared-snapshot.json");
	if (!c || Object.keys(c).some((e) => ![
		"id",
		"projection",
		"contentHash",
		"createdAt",
		"accessExpiresAt",
		"role"
	].includes(e)) || typeof c.id != "string" || ![
		"owner",
		"editor",
		"reviewer",
		"reader"
	].includes(c.role) || typeof c.createdAt != "string" || !Number.isFinite(Date.parse(c.createdAt)) || c.accessExpiresAt !== null && !Number.isFinite(Date.parse(c.accessExpiresAt)) || await e(t(c.projection)) !== c.contentHash) throw new r("PROTOCOL_INVALID");
	function l(e, t = !0) {
		if (!e || e.format !== "scenario-projection" || e.formatVersion !== "1.0.0" || typeof e.title != "string" || !Array.isArray(e.entities) || !Array.isArray(e.relations) || !Array.isArray(e.searchIndex) || !Array.isArray(e.calendars) || Object.keys(e).some((e) => ![
			"format",
			"formatVersion",
			"title",
			"mainStart",
			"calendars",
			"entities",
			"relations",
			"searchIndex",
			"versions"
		].includes(e))) throw new r("PROTOCOL_INVALID");
		let n = /* @__PURE__ */ new Set();
		for (let t of e.entities) {
			if (!t || !o.test(t.id) || n.has(t.id) || !a[t.kind] || t.status !== "confirmed" || typeof t.name != "string" || !t.data || Object.keys(t).some((e) => ![
				"id",
				"kind",
				"name",
				"status",
				"data"
			].includes(e))) throw new r("PROTOCOL_INVALID");
			n.add(t.id);
			let e = /* @__PURE__ */ new Set([...Object.keys(a[t.kind]), ...t.kind === "attachment" ? [
				"mediaType",
				"assetPath",
				"contentHash",
				"byteSize",
				"bytesIncluded"
			] : []]);
			if (Object.keys(t.data).some((t) => !e.has(t))) throw new r("PROTOCOL_INVALID");
			for (let [e, n] of Object.entries(t.data)) if (a[t.kind]?.[e]?.type === "rich" && (!Array.isArray(n) || n.some((e) => {
				let t = e;
				return !t || Object.keys(t).some((e) => ![
					"id",
					"kind",
					"text",
					"ruby",
					"links"
				].includes(e)) || !o.test(t.id) || typeof t.text != "string" || t.links?.some((e) => Object.keys(e).some((e) => ![
					"start",
					"end",
					"targetId",
					"blockId",
					"lineId",
					"sourceVersionId",
					"targetStart",
					"targetEnd"
				].includes(e))) || t.ruby?.some((e) => Object.keys(e).some((e) => ![
					"start",
					"end",
					"text"
				].includes(e)));
			}))) throw new r("PROTOCOL_INVALID");
		}
		for (let t of e.relations) if (Object.keys(t).some((e) => ![
			"id",
			"fromId",
			"toId",
			"relationType",
			"direction",
			"evidenceIds",
			"validity"
		].includes(e)) || !o.test(t.id) || !n.has(t.fromId) || !n.has(t.toId) || !Array.isArray(t.evidenceIds) || t.evidenceIds.some((e) => !n.has(e))) throw new r("PROTOCOL_INVALID");
		if (e.searchIndex.some((e) => Object.keys(e).some((e) => ![
			"entityId",
			"kind",
			"name",
			"text",
			"normalized"
		].includes(e)) || !n.has(e.entityId) || typeof e.text != "string" || typeof e.name != "string") || !t && e.versions?.length || (e.versions?.length ?? 0) > 128 || new Set(e.versions?.map((e) => e.id)).size !== (e.versions?.length ?? 0)) throw new r("PROTOCOL_INVALID");
		for (let t of e.versions ?? []) {
			if (Object.keys(t).some((e) => !["id", "projection"].includes(e)) || !o.test(t.id)) throw new r("PROTOCOL_INVALID");
			l(t.projection, !1);
		}
	}
	if (l(c.projection), i(c.projection).length) throw new r("PROTOCOL_INVALID");
	return c;
}
//#endregion
export { s as validateSharedSnapshot };
