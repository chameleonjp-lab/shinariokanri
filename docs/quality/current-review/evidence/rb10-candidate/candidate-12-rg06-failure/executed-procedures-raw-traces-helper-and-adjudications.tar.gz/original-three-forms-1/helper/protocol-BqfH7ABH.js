//#region ../shinariokanri-rb10-basic-registration/src/sync/protocol.ts
var e = class extends Error {
	code;
	constructor(e) {
		super(e), this.code = e, this.name = "SyncProtocolError";
	}
}, t = "$tombstone", n = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/, r = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]);
function i() {
	throw new e("PROTOCOL_INVALID");
}
function a(e) {
	return typeof e == "string" && /^(0|[1-9][0-9]*)$/.test(e) && e.length <= 128;
}
function o(e) {
	(!e || typeof e.accountId != "string" || !e.accountId.trim() || e.accountId.length > 256 || !n.test(e.projectId)) && i();
}
function s(e, t) {
	return e.accountId === t.accountId && e.projectId === t.projectId;
}
function c(e) {
	return structuredClone(e);
}
function l(e) {
	let t = /* @__PURE__ */ new Set();
	function n(e, a) {
		if (a > 100) return i();
		if (e === null || typeof e == "boolean" || typeof e == "string" || typeof e == "number" && Number.isFinite(e)) return JSON.stringify(e);
		if (!e || typeof e != "object" || t.has(e)) return i();
		let o = Object.getPrototypeOf(e);
		if (!Array.isArray(e) && o !== Object.prototype && o !== null) return i();
		t.add(e);
		let s;
		if (Array.isArray(e)) {
			if (Object.keys(e).length !== e.length) return i();
			s = "[" + e.map((e) => n(e, a + 1)).join(",") + "]";
		} else s = "{" + Object.keys(e).sort().map((t) => r.has(t) ? i() : JSON.stringify(t) + ":" + n(e[t], a + 1)).join(",") + "}";
		return t.delete(e), s;
	}
	return n(e, 0);
}
function u(e, t) {
	return l(e) === l(t);
}
async function d(e) {
	let t = new TextEncoder().encode(l(e)), n = await globalThis.crypto.subtle.digest("SHA-256", t);
	return "sha256:" + Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("");
}
function f(e, t) {
	return t === "$tombstone" ? {
		present: !0,
		value: e?.tombstone ? {
			deletedAt: e.tombstone.deletedAt,
			operationId: e.tombstone.operationId
		} : null
	} : e && Object.hasOwn(e.fields, t) ? {
		present: !0,
		value: c(e.fields[t])
	} : { present: !1 };
}
function p(e) {
	(!e || !n.test(e.id) || !n.test(e.projectId) || !a(e.revision) || !e.fields || Array.isArray(e.fields) || typeof e.fields != "object" || Object.keys(e.fields).some((e) => e === "$tombstone" || r.has(e) || !e)) && i(), l(e.fields), e.tombstone !== null && (!e.tombstone || !n.test(e.tombstone.operationId) || typeof e.tombstone.deletedAt != "string" || !/^\d{4}-\d{2}-\d{2}T/.test(e.tombstone.deletedAt) || !Number.isFinite(Date.parse(e.tombstone.deletedAt))) && i();
}
function m(e, t, n) {
	p(e), (e.projectId !== t.projectId || e.id !== n) && i();
}
async function h(e, n) {
	let r = [.../* @__PURE__ */ new Set([
		...Object.keys(e?.fields ?? {}),
		...Object.keys(n.fields),
		t
	])].sort(), i = [];
	for (let t of r) {
		let r = f(e, t), a = f(n, t);
		u(r, a) || i.push({
			field: t,
			oldValueHash: await d(r),
			value: a
		});
	}
	return i;
}
async function g(e) {
	e = c(e), o(e.scope), (!n.test(e.operationId) || !a(e.baseRevision) || !e.targets.length || e.targets.length > 1e4 || e.reason !== void 0 && typeof e.reason != "string" || e.resolvesOperationId !== void 0 && (!n.test(e.resolvesOperationId) || e.resolvesOperationId === e.operationId)) && i();
	let t = /* @__PURE__ */ new Set(), r = [];
	for (let n of e.targets) {
		let a = c(n.local);
		m(a, e.scope, a.id), t.has(a.id) && i(), t.add(a.id), n.base && (m(n.base, e.scope, a.id), BigInt(n.base.revision) > BigInt(e.baseRevision) && i()), r.push({
			targetId: a.id,
			base: c(n.base),
			local: a,
			changes: await h(n.base, a)
		});
	}
	return {
		schemaVersion: 1,
		operationId: e.operationId,
		scope: c(e.scope),
		baseRevision: e.baseRevision,
		targets: r,
		reason: e.reason ?? "",
		...e.resolvesOperationId ? { resolvesOperationId: e.resolvesOperationId } : {}
	};
}
async function _(e) {
	(!e || e.schemaVersion !== 1 || !Array.isArray(e.targets)) && i(), u(e, await g({
		...e,
		targets: e.targets.map((e) => ({
			base: e.base,
			local: e.local
		}))
	})) || i();
}
async function v(e, t) {
	t?.authorizationExpiresAt !== void 0 && t.authorizationExpiresAt !== null && (typeof t.authorizationExpiresAt != "string" || !Number.isFinite(Date.parse(t.authorizationExpiresAt))) && i(), t?.authorizationRevision !== void 0 && !a(t.authorizationRevision) && i(), (!t || t.schemaVersion !== 1 || t.operationId !== e.operationId || !s(t.scope, e.scope) || t.operationHash !== await d(e) || !a(t.serverRevision) || BigInt(t.serverRevision) < BigInt(e.baseRevision) || !Array.isArray(t.documents) || t.documents.length !== e.targets.length || !Array.isArray(t.conflicts)) && i();
	for (let [n, r] of t.documents.entries()) r && (m(r, e.scope, e.targets[n].targetId), BigInt(r.revision) > BigInt(t.serverRevision) && i());
	if (t.confirmedDocuments !== void 0) {
		(!Array.isArray(t.confirmedDocuments) || t.confirmedDocuments.length > 100001) && i();
		let n = /* @__PURE__ */ new Map();
		for (let r of t.confirmedDocuments) m(r, e.scope, r.id), (n.has(r.id) || BigInt(r.revision) > BigInt(t.serverRevision)) && i(), n.set(r.id, r);
		for (let [r, a] of t.documents.entries()) u(a, n.get(e.targets[r].targetId) ?? null) || i();
	}
	if (t.status === "applied") {
		(t.conflicts.length || t.documents.some((e) => !e)) && i(), e.targets.some((e) => e.changes.length) && BigInt(t.serverRevision) <= BigInt(e.baseRevision) && i();
		for (let [n, r] of e.targets.entries()) {
			let a = t.documents[n];
			(!r.base || !u({
				fields: r.base.fields,
				tombstone: r.base.tombstone
			}, {
				fields: a.fields,
				tombstone: a.tombstone
			})) && BigInt(a.revision) <= BigInt(e.baseRevision) && i();
		}
	} else if (t.status === "conflict") {
		t.conflicts.length || i();
		let n = /* @__PURE__ */ new Set();
		for (let r of t.conflicts) {
			let a = e.targets.findIndex((e) => e.targetId === r.targetId);
			(a < 0 || n.has(r.targetId) || !u(r.base, e.targets[a].base) || !u(r.local, e.targets[a].local) || !u(r.server, t.documents[a])) && i(), n.add(r.targetId);
		}
	} else i();
}
//#endregion
export { m as a, g as c, u as d, d as f, p as i, f as l, t as n, _ as o, v as r, c as s, e as t, a as u };
