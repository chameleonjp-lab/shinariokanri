import { $ as e, L as t, M as n, W as r, X as i, a, v as o, z as s } from "./presentation-BwR6ApEV.js";
//#region ../shinariokanri-rb10-basic-registration/src/domain/projection.ts
var c = { type: "text" }, l = { type: "rich" }, u = { type: "ref" }, d = { type: "refs" }, f = { type: "number" }, p = { type: "boolean" }, m = { type: "time" }, h = { type: "condition" }, g = { type: "typed" }, _ = (...e) => ({
	type: "enum",
	values: e
}), v = Object.freeze({
	character: {
		reading: c,
		summary: l,
		body: l,
		birth: m,
		death: m
	},
	group: {
		groupType: _("display", "faction", "plot_thread", "category"),
		members: d,
		parentId: u,
		summary: l
	},
	event: {
		summary: l,
		time: m,
		laneRole: _("common", "participants", "both"),
		participants: { type: "participants" },
		locationId: u,
		itemIds: d
	},
	place: {
		parentId: u,
		reading: c,
		body: l,
		mapIds: d
	},
	item: {
		itemMode: _("type", "instance"),
		typeId: u,
		body: l
	},
	note: {
		body: l,
		attachmentIds: d
	},
	chapter: {
		sceneIds: d,
		summary: l
	},
	scene: {
		summary: l,
		body: l,
		eventIds: d,
		dialogueLineIds: d,
		chapterId: u,
		threadIds: d,
		povId: u,
		blockIds: d,
		tension: f,
		importance: f
	},
	goal: {
		ownerId: u,
		description: l,
		changes: d,
		evidenceSceneIds: d
	},
	flow_node: {
		nodeType: _("scene", "choice", "automatic", "call", "entry", "exit", "terminal"),
		sceneId: u,
		childGraphId: u,
		terminalReason: c,
		trigger: { type: "trigger" },
		gate: h,
		executionPolicy: _("manual_choice", "first_match", "all_match"),
		fallbackId: u,
		shownInformationIds: d
	},
	flow_edge: {
		fromId: u,
		toId: u,
		edgeType: _("choice", "automatic", "call_return"),
		label: c,
		condition: h,
		effectIds: d,
		priority: f,
		choiceLineId: u
	},
	flow_graph: {
		nodeIds: d,
		edgeIds: d,
		entryIds: d,
		exitIds: d,
		parentGraphId: u,
		parameters: { type: "parameters" }
	},
	dialogue_line: {
		text: l,
		speakerId: u,
		choiceEdgeId: u,
		cueIds: d
	},
	quest: {
		key: c,
		stateVariableId: u,
		description: l,
		flowIds: d,
		transitionRules: { type: "transitions" }
	},
	lore: {
		body: l,
		assertionIds: d,
		reading: c
	},
	variable: {
		key: c,
		valueType: _("boolean", "integer", "enum"),
		scope: _("scene", "chapter", "character", "run", "across_runs"),
		initial: g,
		allowed: { type: "allowed" },
		ownerId: u,
		externalContractId: u,
		externalUseDeclared: p,
		description: l,
		derived: { type: "expression" },
		resetRules: { type: "resets" },
		exclusions: { type: "exclusions" },
		transitionRules: { type: "transitions" }
	},
	effect: {
		operation: _("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset"),
		targetId: u,
		value: g,
		condition: h,
		instanceId: u,
		reason: c,
		exceptionDetails: { type: "exception" }
	},
	assertion: {
		subjectId: u,
		predicate: c,
		value: g,
		truthKind: _("author_truth", "testimony", "belief", "hypothesis"),
		holderId: u,
		sourceIds: d,
		evidenceLocation: { type: "anchor" },
		reason: c,
		validity: { type: "validity" }
	},
	foreshadow: {
		question: l,
		intent: l,
		truthAssertionIds: d,
		clueIds: d,
		payoffIds: d,
		requiredInfo: d,
		alternativeInfo: { type: "alternatives" },
		deadline: { type: "scope" },
		exceptions: { type: "exceptions" },
		presentationDeadline: { type: "anchor" },
		resolutionPolicy: _("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")
	},
	disclosure: {
		foreshadowId: u,
		anchor: { type: "anchor" },
		stage: _("hint", "suspicion", "reinforce", "reveal", "alternative"),
		role: _("clue", "payoff"),
		targetScope: { type: "scope" },
		condition: h,
		knowledgeEffects: d
	},
	attachment: { displayName: c },
	source: {
		accessedAt: { type: "datetime" },
		excerptLocation: c,
		attachmentId: u,
		sourceType: _("web", "file", "book", "observation"),
		locator: c,
		interpretation: l,
		redistributionAllowed: p
	},
	cue: {
		anchor: { type: "anchor" },
		cueType: c,
		attachmentId: u,
		speakerId: u,
		expression: c,
		waitMs: f,
		mediaTime: f,
		camera: { type: "camera" }
	},
	storyboard_frame: {
		anchor: { type: "anchor" },
		mediaStartMs: f,
		mediaEndMs: f,
		referenceAssetId: u,
		finalAssetId: u,
		cueIds: d,
		caption: l
	},
	localization: {
		sourceLineId: u,
		language: c,
		text: l,
		stage: _("draft", "reviewed", "needs_review"),
		recordingIds: d
	},
	recording: {
		sourceLineId: u,
		language: c,
		translationId: u,
		attachmentId: u,
		stage: _("planned", "recorded", "reviewed", "needs_review")
	},
	terminology: {
		canonical: c,
		reading: c,
		variants: { type: "public_strings" },
		validity: { type: "validity" },
		exceptions: { type: "exceptions" },
		language: c,
		usageNotes: l,
		voiceOwnerId: u
	},
	voice_rule: {
		characterId: u,
		validity: { type: "validity" },
		firstPerson: c,
		addressing: c,
		phrasing: c,
		examples: l,
		exceptions: { type: "exceptions" }
	},
	map: {
		placeId: u,
		coordinateSystem: _("normalized"),
		attachmentId: u,
		parentMapId: u,
		pins: { type: "pins" }
	},
	travel_route: {
		fromPlaceId: u,
		toPlaceId: u,
		direction: _("one_way", "two_way"),
		method: c
	},
	collection: {
		mode: _("fixed"),
		memberIds: d
	},
	gameplay_spec: {
		sceneId: u,
		action: l,
		mechanic: c,
		tutorial: l,
		reward: g,
		questId: u,
		taskIds: d,
		intentionalDifference: c
	},
	production_task: {
		deadline: { type: "real_date" },
		estimate: { type: "estimate" },
		blockingReason: c,
		targetIds: d,
		stage: _("writing", "review", "implementation", "translation", "recording", "verification", "publication"),
		progress: _("todo", "doing", "done", "needs_review"),
		dependsOn: d
	},
	media_variant: {
		medium: _("game", "novel", "video", "audio", "promotion", "custom"),
		baseSnapshotId: { type: "version_ref" },
		previousVariantId: u,
		releaseAt: { type: "datetime" },
		body: l,
		sourceIds: d,
		needsReview: p
	},
	external_contract: {
		key: c,
		owner: _("tool", "game"),
		inputType: _("boolean", "integer", "enum"),
		outputType: _("boolean", "integer", "enum"),
		missingPolicy: _("unknown", "block"),
		description: l,
		version: { type: "semver" },
		stubValues: { type: "typeds" }
	}
});
Object.freeze(Object.keys(v));
var y = /* @__PURE__ */ new Set([
	"fromId",
	"toId",
	"effectIds",
	"nodeIds",
	"edgeIds",
	"entryIds",
	"exitIds",
	"childGraphId",
	"fallbackId",
	"targetId",
	"instanceId",
	"stateVariableId",
	"externalContractId",
	"shownInformationIds",
	"knowledgeEffects"
]), b = /* @__PURE__ */ new Set([
	"handoffReceipt",
	"authorNotes",
	"aliases",
	"quotedText",
	"originLineIds",
	"replacedByLineIds",
	"lineage",
	"customValues",
	"assetPath",
	"licenseNote",
	"history",
	"query",
	"sourceHash"
]), x = /* @__PURE__ */ new Set([
	"paragraph",
	"heading",
	"list_item",
	"quote"
]), S = {
	"image/png": "png",
	"image/jpeg": "jpg",
	"image/gif": "gif",
	"image/webp": "webp",
	"audio/wav": "wav",
	"audio/mpeg": "mp3",
	"application/pdf": "pdf",
	"video/mp4": "mp4",
	"video/webm": "webm",
	"video/ogg": "ogv",
	"audio/ogg": "ogg",
	"text/plain": "txt",
	"application/json": "json",
	"application/octet-stream": "bin"
}, C = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/, w = (e) => typeof e == "object" && e && !Array.isArray(e) ? e : void 0, T = (e, t) => e && Object.prototype.hasOwnProperty.call(e, t) ? e[t] : void 0, E = (e, t) => Object.prototype.hasOwnProperty.call(e, t), ee = (e) => e == null || e === "" || Array.isArray(e) && e.length === 0, D = (e) => typeof e == "number" && Number.isSafeInteger(e);
function O(e, t, n = {}) {
	let r = [], i = [];
	if (!e || !Array.isArray(e.entities) || !Array.isArray(e.relations) || e.entities.some((e) => !e || typeof e.id != "string" || !w(e.data))) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			message: "作品の公開元データが不正です。"
		}],
		omissions: i
	};
	let a = (e, t, n, i) => {
		r.push({
			code: e,
			message: t,
			...n ? { entityId: n } : {},
			...i ? { field: i } : {}
		});
	}, o = (e, t, n) => {
		i.push({
			entityId: e,
			reason: t,
			...n ? { field: n } : {}
		});
	}, s = /* @__PURE__ */ new Map();
	for (let t of e.entities) s.has(t.id) && a("VALIDATION_FAILED", "同じIDの情報が重複しています。", t.id), s.set(t.id, t);
	let c = s.get(t);
	if (!c || c.kind !== "projection_profile" || c.projectId !== e.projectId || c.deletedAt) return {
		ok: !1,
		issues: [{
			code: "REFERENCE_INVALID",
			message: "この作品の公開範囲を選んでください。",
			entityId: t
		}],
		omissions: i
	};
	let l = c.data;
	l.sourceVersionId != null && l.sourceVersionId !== n.targetVersionId && l.sourceVersionId !== e.revision && a("VALIDATION_FAILED", "公開範囲が固定された版と出力元の版が一致しません。", t, "sourceVersionId"), w(l.routeScope)?.targetSnapshotId != null && w(l.routeScope).targetSnapshotId !== n.targetVersionId && a("VALIDATION_FAILED", "公開範囲の対象snapshotを読み込んでください。", t, "routeScope.targetSnapshotId"), l.idPolicy != null && !["remap", "preserve"].includes(String(l.idPolicy)) && a("VALIDATION_FAILED", "公開IDの方式が不正です。", t, "idPolicy"), l.includeAuthorNotes === !0 && a("FORBIDDEN", "公開用出力に作者メモは含められません。", t, "includeAuthorNotes");
	let u = T(l, "publicTitle");
	(typeof u != "string" || !u.trim()) && a("PUBLIC_TEXT_REQUIRED", "作者が確認した公開用の作品名を指定してください。", t, "publicTitle");
	let d = T(l, "includedIds"), f = T(l, "allowedKinds");
	(!Array.isArray(d) || d.some((e) => typeof e != "string") || new Set(d).size !== d.length) && a("VALIDATION_FAILED", "公開するIDを重複のない一覧で指定してください。", t, "includedIds"), (!Array.isArray(f) || f.length === 0 || f.some((e) => typeof e != "string" || !E(v, e))) && a("EXPORT_UNSUPPORTED", "公開可能な種類だけを明示的に選んでください。", t, "allowedKinds");
	let p = w(T(l, "publicTexts")) ?? {}, h = w(T(l, "publicIds")) ?? {}, g = w(T(l, "namePolicy")), _ = te(s, l, e.projectId, p, a), O = Array.isArray(l.includedStatuses) ? l.includedStatuses : ["confirmed"];
	O.some((e) => ![
		"confirmed",
		"provisional",
		"needs_review"
	].includes(String(e))) && a("FORBIDDEN", "没案と作者別案は公開対象にできません。", t, "includedStatuses");
	let k = [], A = /* @__PURE__ */ new Map(), j = /* @__PURE__ */ new Map(), M = new Set(Array.isArray(d) ? d : []), N = [...s.keys()].filter((e) => M.has(e));
	for (let e of M) s.has(e) || N.push(e);
	for (let t of N) {
		let r = s.get(t);
		if (!r || r.projectId !== e.projectId) {
			a("REFERENCE_INVALID", "作品内にない情報が公開範囲に含まれています。", t);
			continue;
		}
		if (_ && !_.has(t)) {
			o(t, "指定した章またはグラフの範囲外");
			continue;
		}
		if (r.deletedAt || !O.includes(r.status) || n.confirmedOnly && r.status !== "confirmed") {
			o(t, "削除済み、未確定、没案または別案");
			continue;
		}
		if (!Array.isArray(f) || !f.includes(r.kind)) {
			o(t, "許可されていない種類");
			continue;
		}
		if (!E(v, r.kind)) {
			a("EXPORT_UNSUPPORTED", "この種類の安全な投影は未対応です。", t);
			continue;
		}
		if (["scene", "flow_node"].includes(r.kind) && w(r.data.reuse)?.mode !== void 0 && w(r.data.reuse)?.mode !== "clone") {
			a("EXPORT_UNSUPPORTED", "固定共通元と使用先を合わせた公開範囲・公開名・本文を確認する出力は未対応です。再利用を省略した出力は作成できません。", t, "reuse");
			continue;
		}
		let i = w(T(w(T(g, "byEntityId")), t)) ?? w(T(g, "defaultPolicy")) ?? (typeof g?.mode == "string" ? g : void 0);
		if (i?.mode === "exclude") {
			o(t, "作者が非公開を選択");
			continue;
		}
		let c;
		if (i?.mode === "replace" ? c = i.replacement : i?.mode === "anonymize" ? (c = i.publicName, typeof i.publicId == "string" && j.set(t, i.publicId)) : i?.mode === "alias" ? c = (Array.isArray(r.data.aliases) ? r.data.aliases : []).map(w).find((e) => e?.id === i.aliasId)?.text : r.name === "" && (c = ""), typeof c != "string" || r.name !== "" && !c.trim()) {
			a("PUBLIC_TEXT_REQUIRED", "この情報の公開名または公開別名を指定してください。", t, "namePolicy");
			continue;
		}
		A.set(t, c), k.push(r);
	}
	let P = Object.create(null), F = /* @__PURE__ */ new Set(), I = 0, L = (e) => {
		if (Object.prototype.hasOwnProperty.call(P, e)) return;
		let t = j.get(e) ?? T(h, e) ?? (l.idPolicy === "preserve" ? e : `public-${String(++I).padStart(6, "0")}`);
		if (typeof t != "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(t) || F.has(t)) {
			a("VALIDATION_FAILED", "公開IDが不正、または重複しています。", e, "publicIds");
			return;
		}
		P[e] = t, F.add(t);
	};
	k.forEach((e) => L(e.id));
	let R = w(T(l, "allowedFields")), z = Array.isArray(l.excludedFields) ? l.excludedFields : [], B = /* @__PURE__ */ new Set(), re = /* @__PURE__ */ new Map(), ie = /* @__PURE__ */ new Map();
	for (let e of k) {
		for (let t of Object.values(e.data)) if (Array.isArray(t)) for (let n of t) {
			let t = w(n);
			typeof t?.id == "string" && typeof t.text == "string" && ie.set(t.id, e.id);
		}
		let t = w(T(p, e.id)), n = v[e.kind], r = T(R, e.kind);
		for (let [i, o] of Object.entries(n)) if (o.type === "rich" && (!Array.isArray(r) || r.includes(i)) && !z.includes(i) && !z.includes(`${e.kind}.${i}`) && Array.isArray(T(t, i))) for (let n of t[i]) {
			let t = w(n);
			typeof t?.id == "string" && (s.has(t.id) || B.has(t.id) ? a("VALIDATION_FAILED", "公開文の段落IDが他の情報と重複しています。", e.id, i) : (B.add(t.id), re.set(t.id, e.id), L(t.id)));
		}
		let i = w(e.data.trigger);
		e.kind === "flow_node" && typeof i?.id == "string" && L(i.id);
	}
	let V = new Set(k.map((e) => e.id)), ae = w(l.blockSources) ?? {};
	for (let [e, n] of Object.entries(ae)) {
		if (typeof n != "string" || !B.has(e) || !P[e] || ie.get(n) !== re.get(e)) {
			a("REFERENCE_INVALID", "公開段落の元ID対応が不正です。", t, "blockSources");
			continue;
		}
		if (P[n] && P[n] !== P[e]) {
			a("REFERENCE_INVALID", "同じ原段落に複数の公開位置が指定されています。", t, "blockSources");
			continue;
		}
		P[n] = P[e];
	}
	let H = [], U = /* @__PURE__ */ new Map(), oe = (t, n, r) => {
		if (typeof t != "string") {
			a("REFERENCE_INVALID", "日時が使う暦を指定してください。", n.id, r);
			return;
		}
		if (U.has(t)) return U.get(t);
		let i = e.calendars.find((e) => e.id === t);
		if (!i || !["gregorian", "repeating"].includes(i.kind) || !C.test(i.ticksPerDay) || BigInt(i.ticksPerDay) <= 0n) {
			a("REFERENCE_INVALID", "日時が使う暦を安全に出力できません。", n.id, r);
			return;
		}
		let o = `public-calendar-${H.length + 1}`;
		for (; F.has(o);) o += "-calendar";
		F.add(o);
		let s = {
			id: o,
			name: `暦${H.length + 1}`,
			kind: i.kind,
			originLabel: "原点",
			ticksPerDay: i.ticksPerDay
		};
		if (i.kind === "repeating") {
			if (!Array.isArray(i.years) || !i.years.length || i.years.length > 400) {
				a("EXPORT_UNSUPPORTED", "繰り返し暦の周期を安全に出力できません。", n.id, r);
				return;
			}
			s.years = [];
			for (let e of i.years) {
				if (!Array.isArray(e.months) || !e.months.length || e.months.length > 24 || e.months.some((e) => !D(e.days) || e.days < 1 || e.days > 400)) {
					a("EXPORT_UNSUPPORTED", "繰り返し暦の月を安全に出力できません。", n.id, r);
					return;
				}
				s.years.push({ months: e.months.map((e, t) => ({
					name: `月${t + 1}`,
					days: e.days
				})) });
			}
		}
		return U.set(t, o), H.push(s), o;
	}, W = (e, t, r, i = !1) => {
		if (e != null) {
			if (typeof e == "string" && V.has(e) && Object.prototype.hasOwnProperty.call(P, e) || typeof e == "string" && Object.prototype.hasOwnProperty.call(P, e) && r.includes("block")) return P[e];
			i || n.strictReferences ? a("REFERENCE_INVALID", "公開範囲にない参照先が必要です。範囲または代替文を見直してください。", t.id, r) : o(t.id, "公開範囲にない参照を除外", r);
		}
	}, se = (e, t, n, r) => {
		let i = w(T(w(T(l, "publicValues")), t)), o = typeof e == "string" ? T(i, e) : void 0;
		if (typeof o != "string") {
			a("PUBLIC_TEXT_REQUIRED", "列挙値の公開用表記を指定してください。", n.id, r);
			return;
		}
		return o;
	}, G = (e, t, n, r) => {
		if (typeof e == "string" && n.kind === "assertion") return W(e, n, r, !0);
		let i = w(e);
		if (!i) {
			a("VALIDATION_FAILED", "型付きの値が必要です。", n.id, r);
			return;
		}
		if (i.type === "boolean" && typeof i.value == "boolean") return {
			type: "boolean",
			value: i.value
		};
		if (i.type === "integer" && D(i.value)) return {
			type: "integer",
			value: i.value
		};
		if (i.type === "enum") {
			let e = se(i.value, t, n, r);
			return e === void 0 ? void 0 : {
				type: "enum",
				value: e
			};
		}
		if (i.type === "ref") {
			let e = W(i.value, n, r, !0);
			return e ? {
				type: "ref",
				value: e
			} : void 0;
		}
		a("EXPORT_UNSUPPORTED", "未確定値や自由文字列の値は安全な制作出力に対応していません。", n.id, r);
	}, K = (e, t, n) => {
		let r = 0, i = (e, o) => {
			let c = w(e);
			if (!c || o > 16 || ++r > 256) {
				a("EXPORT_UNSUPPORTED", "条件の形または深さが対応範囲を超えています。", t.id, n);
				return;
			}
			let l = (e) => W(c[e], t, `${n}.${e}`, !0);
			switch (c.op) {
				case "constant":
					if (typeof c.value == "boolean") return {
						op: "constant",
						value: c.value
					};
					break;
				case "all":
				case "any": {
					if (!Array.isArray(c.children) || c.children.length === 0) break;
					let e = c.children.map((e) => i(e, o + 1));
					return e.every((e) => e !== void 0) ? {
						op: c.op,
						children: e
					} : void 0;
				}
				case "not": {
					let e = i(c.child, o + 1);
					return e === void 0 ? void 0 : {
						op: "not",
						child: e
					};
				}
				case "compare": {
					let e = l("variableId"), r = typeof c.variableId == "string" ? s.get(c.variableId) : void 0, i = c.comparator;
					if (!r || r.kind !== "variable" || ![
						"eq",
						"ne",
						"lt",
						"le",
						"gt",
						"ge",
						"in"
					].includes(String(i))) break;
					let a;
					if (i === "in" && Array.isArray(c.value)) {
						let e = c.value.map((e) => G(e, r.id, t, n));
						e.every((e) => e !== void 0) && (a = e);
					} else a = G(c.value, r.id, t, n);
					return e && a !== void 0 ? {
						op: "compare",
						variableId: e,
						comparator: String(i),
						value: a
					} : void 0;
				}
				case "item": {
					let e = l("itemId");
					if (e && D(c.quantity) && c.quantity >= 0) return {
						op: "item",
						itemId: e,
						quantity: c.quantity
					};
					break;
				}
				case "known": {
					let e = l("assertionId"), t = l("holderId");
					return e && t ? {
						op: "known",
						assertionId: e,
						holderId: t
					} : void 0;
				}
				case "visited": {
					let e = l("entityId");
					if (e && D(c.count) && c.count >= 0) return {
						op: "visited",
						entityId: e,
						count: c.count
					};
					break;
				}
				case "external": {
					let e = l("contractId");
					return e ? {
						op: "external",
						contractId: e
					} : void 0;
				}
			}
			a("EXPORT_UNSUPPORTED", "この条件は対応先で安全に表せません。", t.id, n);
		};
		return i(e, 1);
	}, q = (e, t) => T(w(T(p, e.id)), t), J = (e, t) => {
		let n = q(e, t);
		if (typeof n == "string") return n;
		ee(e.data[t]) || a("PUBLIC_TEXT_REQUIRED", "原文の安全性は自動判定できません。公開用の文面を指定するか、この項目を除外してください。", e.id, t);
	}, ce = (t, r, i) => {
		let s = w(t);
		if (!s) {
			a("VALIDATION_FAILED", "本文位置が不正です。", r.id, i);
			return;
		}
		if (s.positionStatus === "unresolved") {
			n.strictReferences ? a("REFERENCE_INVALID", "公開する本文位置の再リンクが必要です。", r.id, i) : o(r.id, "位置不明の本文参照を除外", i);
			return;
		}
		let c = s.sourceVersionId && s.sourceVersionId !== e.projectId && s.sourceVersionId !== n.targetVersionId ? n.versionTargets?.[String(s.sourceVersionId)] : void 0;
		if (s.sourceVersionId && s.sourceVersionId !== e.projectId && s.sourceVersionId !== n.targetVersionId && !c) {
			a("EXPORT_UNSUPPORTED", "別の固定版を指す位置には、その版の公開範囲確認が必要です。黙って現在位置へ移しません。", r.id, i);
			return;
		}
		let l = c?.idMap ?? P, u = c ? l[String(s.entityId)] : W(s.entityId, r, i, !0);
		if (!u) {
			a("REFERENCE_INVALID", "引用固定版の公開対象がありません。", r.id, i);
			return;
		}
		let d = {
			entityId: u,
			...c ? { sourceVersionId: c.publicVersionId } : {}
		};
		for (let e of ["blockId", "lineId"]) if (s[e] != null) {
			let t = s[e];
			if (typeof t != "string" || !Object.prototype.hasOwnProperty.call(l, t)) {
				n.strictReferences ? a("REFERENCE_INVALID", "公開文に存在しない位置への参照です。", r.id, i) : o(r.id, "非公開の本文位置を除外", i);
				return;
			}
			d[e] = l[t];
		}
		return D(s.start) && D(s.end) && s.start >= 0 && s.end >= s.start && (d.start = s.start, d.end = s.end), d;
	}, le = (t, r) => {
		let i = q(t, r);
		if (typeof i == "string") return [{
			id: `${P[t.id]}.${r}`,
			kind: "paragraph",
			text: i
		}];
		if (!Array.isArray(i)) {
			ee(t.data[r]) || a("PUBLIC_TEXT_REQUIRED", "公開用の本文を指定してください。原文の秘密は自動で除けません。", t.id, r);
			return;
		}
		let s = [];
		for (let c of i) {
			let i = w(c);
			if (!i || typeof i.id != "string" || !P[i.id] || !x.has(String(i.kind)) || typeof i.text != "string") {
				a("VALIDATION_FAILED", "公開文の段落が不正です。", t.id, r);
				continue;
			}
			let l = {
				id: P[i.id],
				kind: String(i.kind),
				text: i.text
			};
			Array.isArray(i.unresolvedAnnotations) && i.unresolvedAnnotations.length && o(t.id, "再リンク待ちの本文注記を除外", r);
			let u = [...i.text].length, d = (e) => D(e.start) && D(e.end) && e.start >= 0 && e.end > e.start && e.end <= u;
			if (Array.isArray(i.ruby)) {
				let e = [];
				for (let n of i.ruby) {
					let i = w(n);
					if (!i || !d(i) || typeof i.text != "string") {
						a("VALIDATION_FAILED", "公開文のルビ範囲が不正です。", t.id, r);
						continue;
					}
					e.push({
						start: i.start,
						end: i.end,
						text: i.text
					});
				}
				l.ruby = e;
			}
			if (Array.isArray(i.links)) {
				let s = [];
				for (let c of i.links) {
					let i = w(c);
					if (!i || !d(i)) {
						a("VALIDATION_FAILED", "公開文のリンク範囲が不正です。", t.id, r);
						continue;
					}
					let l = w(i.target) ?? i;
					if (l.positionStatus === "unresolved") {
						n.strictReferences ? a("REFERENCE_INVALID", "公開文のリンク先位置の再リンクが必要です。", t.id, r) : o(t.id, "位置不明のリンクを除外", r);
						continue;
					}
					let u = l.sourceVersionId && l.sourceVersionId !== e.projectId && l.sourceVersionId !== n.targetVersionId ? n.versionTargets?.[String(l.sourceVersionId)] : void 0, f = u?.idMap ?? P;
					if (l.sourceVersionId && l.sourceVersionId !== e.projectId && l.sourceVersionId !== n.targetVersionId && !u) {
						a("EXPORT_UNSUPPORTED", "公開リンクには別の固定版の公開確認が必要です。現在位置へ代用しません。", t.id, r);
						continue;
					}
					let p = u ? f[String(l.targetId ?? l.entityId)] : W(l.targetId ?? l.entityId, t, `${r}.links`);
					if (!p) continue;
					let m = {
						start: i.start,
						end: i.end,
						targetId: p
					};
					l.sourceVersionId && (m.sourceVersionId = u?.publicVersionId ?? "public-project"), D(l.start) && D(l.end) && (m.targetStart = l.start, m.targetEnd = l.end);
					let h = !0;
					for (let e of ["blockId", "lineId"]) if (l[e] != null) {
						let i = l[e];
						if (typeof i != "string" || !Object.prototype.hasOwnProperty.call(f, i)) {
							n.strictReferences ? a("REFERENCE_INVALID", "公開文に存在しない位置へのリンクです。", t.id, r) : o(t.id, "非公開の位置へのリンクを除外", r), h = !1;
							break;
						}
						m[e] = f[i];
					}
					h && s.push(m);
				}
				s.length && (l.links = s);
			}
			s.push(l);
		}
		return s;
	}, Y = (e, t) => J(e, t) ?? "", X = (t, r, i) => {
		let o = w(t);
		if (!o || o.projectId !== e.projectId) {
			a("REFERENCE_INVALID", "対象作品の範囲を公開先へ対応できません。", r.id, i);
			return;
		}
		let s = { projectId: "public-project" };
		for (let e of ["graphId", "chapterId"]) if (o[e] != null) {
			let t = W(o[e], r, i, !0);
			if (!t) return;
			s[e] = t;
		}
		if (o.targetSnapshotId != null) {
			if (o.targetSnapshotId !== e.projectId && o.targetSnapshotId !== n.targetVersionId) {
				a("EXPORT_UNSUPPORTED", "別版限定の範囲を現在版へ代用しません。", r.id, i);
				return;
			}
			s.targetSnapshotId = "public-project";
		}
		if (o.routeCondition != null) {
			let e = K(o.routeCondition, r, i);
			if (!e) return;
			s.routeCondition = e;
		}
		return s;
	}, Z = (e, t, n) => {
		let r = w(e);
		if (!r) return;
		let i = null;
		if (r.worldRange != null) {
			let e = w(r.worldRange);
			if (!e || ["start", "end"].some((t) => e[t] !== null && (typeof e[t] != "string" || !C.test(String(e[t]))))) {
				a("VALIDATION_FAILED", "期間の整数tickが不正です。", t.id, n);
				return;
			}
			i = {
				start: e.start,
				end: e.end
			};
		}
		let o = r.routeCondition == null ? null : K(r.routeCondition, t, n), s = r.presentationAnchor == null ? null : ce(r.presentationAnchor, t, n);
		if (o !== void 0 && s !== void 0) return {
			worldRange: i,
			routeCondition: o,
			presentationAnchor: s
		};
	}, Q = (e, t, n) => {
		let r = w(e);
		if (!r) return;
		let i = X(r.targetScope, t, n), o = Z(r.validity, t, n);
		if (!i || !o || !Array.isArray(r.evidenceIds)) return;
		let s = r.evidenceIds.map((e) => W(e, t, n, !0));
		if (s.some((e) => !e)) return;
		let c = Y(t, "exceptionReason");
		if (!c.trim()) {
			a("PUBLIC_TEXT_REQUIRED", "有限例外の公開用理由を指定してください。", t.id, n);
			return;
		}
		return {
			reason: c,
			targetScope: i,
			validity: o,
			evidenceIds: s
		};
	}, $ = (e, t, n, r = 0) => {
		if (r > 64) {
			a("EXPORT_UNSUPPORTED", "算出式の上限を超えています。", t.id, n);
			return;
		}
		let i = w(e);
		if (i) {
			if (i.op === "value") {
				let e = G(i.value, t.id, t, n);
				return e ? {
					op: "value",
					value: e
				} : void 0;
			}
			if (i.op === "variable") {
				let e = W(i.variableId, t, n, !0);
				return e ? {
					op: "variable",
					variableId: e
				} : void 0;
			}
			if ([
				"add",
				"subtract",
				"multiply"
			].includes(String(i.op))) {
				let e = $(i.left, t, n, r + 1), a = $(i.right, t, n, r + 1);
				return e && a ? {
					op: String(i.op),
					left: e,
					right: a
				} : void 0;
			}
			if (i.op === "if") {
				let e = K(i.condition, t, n), a = $(i.then, t, n, r + 1), o = $(i.else, t, n, r + 1);
				return e && a && o ? {
					op: "if",
					condition: e,
					then: a,
					else: o
				} : void 0;
			}
			return K(i, t, n);
		}
	}, ue = (e, t, r) => {
		let i = e.data[t];
		if (r.type === "text") return J(e, t);
		if (r.type === "rich") return le(e, t);
		if (i != null) {
			switch (r.type) {
				case "public_strings": {
					if (Array.isArray(i) && !i.length) return [];
					let n;
					try {
						n = JSON.parse(String(q(e, t)));
					} catch {}
					if (Array.isArray(n) && n.every((e) => typeof e == "string")) return n;
					a("PUBLIC_TEXT_REQUIRED", "公開用の文字列一覧をJSON文章で指定してください。", e.id, t);
					return;
				}
				case "real_date": {
					let e = w(i);
					if (e && typeof e.date == "string" && /^\d{4}-\d{2}-\d{2}$/.test(e.date) && typeof e.timeZone == "string") return {
						date: e.date,
						timeZone: e.timeZone
					};
					break;
				}
				case "estimate": {
					let n = w(i), r;
					try {
						r = JSON.parse(String(q(e, "estimateAssumptions")));
					} catch {}
					let o = q(e, "estimateSource"), s = q(e, "estimateUnit");
					if (!n || !Array.isArray(r) || r.some((e) => typeof e != "string") || typeof o != "string" || typeof s != "string") {
						a("PUBLIC_TEXT_REQUIRED", "見積の公開用仮定と出所を指定してください。", e.id, t);
						return;
					}
					let c = X(n.scope, e, t);
					return c ? {
						unit: s,
						assumptions: r,
						source: o,
						unknownCount: Number(n.unknownCount),
						scope: c,
						...n.value == null ? {} : { value: Number(n.value) },
						...n.range ? { range: n.range } : {},
						...n.speed == null ? {} : { speed: Number(n.speed) }
					} : void 0;
				}
				case "parameters": {
					if (!Array.isArray(i)) break;
					let n = q(e, "parameters"), r;
					try {
						r = typeof n == "string" ? JSON.parse(n) : void 0;
					} catch {}
					if (i.length && !w(r)) {
						a("PUBLIC_TEXT_REQUIRED", "公開用の引数名をkey→公開keyのJSON文章で指定してください。", e.id, t);
						return;
					}
					let o = [];
					for (let n of i) {
						let i = w(n), s = i && T(w(r), String(i.key));
						if (!i || typeof s != "string" || !/^[-_.a-zA-Z0-9]{1,128}$/.test(s) || ![
							"boolean",
							"integer",
							"enum"
						].includes(String(i.type))) {
							a("PUBLIC_TEXT_REQUIRED", "引数の公開名と型を確認してください。", e.id, t);
							return;
						}
						let c = i.default == null ? void 0 : G(i.default, e.id, e, t);
						if (i.default != null && !c) return;
						o.push({
							key: s,
							type: String(i.type),
							...c ? { default: c } : {}
						});
					}
					return o;
				}
				case "expression": return $(i, e, t);
				case "scope": return X(i, e, t);
				case "validity": return Z(i, e, t);
				case "exception": return Q(i, e, t);
				case "exceptions": {
					if (!Array.isArray(i)) break;
					let n = i.map((n) => Q(n, e, t));
					return n.every((e) => e !== void 0) ? n : void 0;
				}
				case "resets": {
					if (!Array.isArray(i)) break;
					let n = [];
					for (let r of i) {
						let i = w(r);
						if (!i || ![
							"scene_end",
							"chapter_end",
							"run_end",
							"new_loop",
							"full_reset"
						].includes(String(i.on))) break;
						let a = G(i.value, e.id, e, t);
						if (!a) return;
						n.push({
							on: String(i.on),
							value: a,
							reason: Y(e, "resetReason")
						});
					}
					if (n.length !== i.length) break;
					return n;
				}
				case "exclusions": {
					if (!Array.isArray(i)) break;
					let n = [];
					for (let r of i) {
						let i = w(r);
						if (!i) return;
						let o = W(i.variableId, e, t, !0), s = G(i.value, e.id, e, t), c = G(i.otherValue, String(i.variableId), e, t), l = i.exceptions == null ? [] : Array.isArray(i.exceptions) ? i.exceptions.map((n) => Q(n, e, t)) : void 0;
						if (!o || !s || !c || !l || l.some((e) => !e)) return;
						let u = Y(e, "exclusionReason");
						if (!u.trim()) {
							a("PUBLIC_TEXT_REQUIRED", "相互排他の公開用理由を指定してください。", e.id, t);
							return;
						}
						n.push({
							variableId: o,
							value: s,
							otherValue: c,
							reason: u,
							exceptions: l
						});
					}
					return n;
				}
				case "alternatives": {
					let n = w(i);
					if (!n) break;
					let r = {};
					for (let [i, a] of Object.entries(n)) {
						let n = W(i, e, t, !0);
						if (!n || !Array.isArray(a)) return;
						let o = a.map((n) => W(n, e, t, !0));
						if (o.some((e) => !e)) return;
						r[n] = o;
					}
					return r;
				}
				case "camera": {
					let n = q(e, t), r;
					try {
						r = typeof n == "string" ? JSON.parse(n) : void 0;
					} catch {
						break;
					}
					let i = w(r);
					if (!i) {
						a("PUBLIC_TEXT_REQUIRED", "公開用カメラ指定をJSON文章で指定してください。", e.id, t);
						return;
					}
					let o = {};
					for (let [n, r] of Object.entries(i)) {
						if (![
							"shot",
							"angle",
							"movement",
							"durationMs"
						].includes(n) || !(typeof r == "string" || typeof r == "number" && Number.isFinite(r) && r >= 0)) {
							a("EXPORT_UNSUPPORTED", "カメラの指定項目を安全に表せません。", e.id, t);
							return;
						}
						o[n] = r;
					}
					return o;
				}
				case "ref": return W(i, e, t, y.has(t));
				case "refs":
					if (!Array.isArray(i)) break;
					return i.map((r) => W(r, e, t, n.strictReferences && y.has(t))).filter((e) => e !== void 0);
				case "number":
					if (typeof i == "number" && Number.isFinite(i)) return i;
					break;
				case "boolean":
					if (typeof i == "boolean") return i;
					break;
				case "enum":
					if (typeof i == "string" && r.values.includes(i)) return i;
					break;
				case "condition": return K(i, e, t);
				case "typed": return G(i, e.kind === "effect" && typeof e.data.targetId == "string" ? e.data.targetId : e.id, e, t);
				case "typeds": {
					if (!Array.isArray(i)) break;
					let n = i.map((n) => G(n, e.id, e, t));
					return n.every((e) => e !== void 0) ? n : void 0;
				}
				case "semver":
					if (typeof i == "string" && /^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/.test(i)) return i;
					break;
				case "allowed": {
					let n = w(i);
					if (!n) break;
					let r = {};
					if (n.min !== void 0 || n.max !== void 0) {
						if (!D(n.min) || !D(n.max) || n.min > n.max) break;
						r.min = n.min, r.max = n.max;
					}
					if (Array.isArray(n.values)) {
						let i = n.values.map((n) => typeof n == "string" ? se(n, e.id, e, t) : typeof n == "boolean" || D(n) ? n : void 0);
						if (i.some((e) => e === void 0)) break;
						if (new Set(i).size !== i.length) {
							a("VALIDATION_FAILED", "公開列挙値が重複しています。", e.id, t);
							return;
						}
						r.values = i;
					}
					return r;
				}
				case "time": {
					let n = w(i);
					if (!n) break;
					let r = { mode: String(n.mode) };
					if ([
						"instant",
						"interval",
						"uncertain"
					].includes(String(n.mode))) {
						let i = n.mode === "instant" ? ["at"] : n.mode === "interval" ? ["start", "end"] : ["earliest", "latest"];
						for (let o of i) {
							if (typeof n[o] != "string" || !C.test(n[o])) {
								a("VALIDATION_FAILED", "世界日時のtickが不正です。", e.id, t);
								return;
							}
							r[o] = n[o];
						}
						let o = oe(n.calendarId, e, t);
						return o ? (r.calendarId = o, n.mode === "uncertain" && (r.precision = J(e, "precision") ?? ""), r) : void 0;
					}
					if (n.mode === "unknown") {
						let t = q(e, "reason");
						return {
							mode: "unknown",
							reason: typeof t == "string" ? t : ""
						};
					}
					if (n.mode === "relative") {
						let r = W(n.anchorEventId, e, t, !0);
						if (r && ["start", "end"].includes(String(n.anchorPoint)) && typeof n.minOffset == "string" && C.test(n.minOffset) && typeof n.maxOffset == "string" && C.test(n.maxOffset)) return {
							mode: "relative",
							anchorEventId: r,
							anchorPoint: String(n.anchorPoint),
							minOffset: n.minOffset,
							maxOffset: n.maxOffset
						};
					}
					break;
				}
				case "participants": {
					if (!Array.isArray(i)) break;
					let n = [];
					for (let r of i) {
						let i = w(r);
						if (!i) continue;
						let o = W(i.characterId, e, t);
						if (o) {
							if (![
								"actor",
								"witness",
								"mentioned",
								"informed",
								"custom"
							].includes(String(i.role))) {
								a("VALIDATION_FAILED", "参加役割が不正です。", e.id, t);
								continue;
							}
							n.push({
								characterId: o,
								role: String(i.role)
							});
						}
					}
					return n;
				}
				case "pins": {
					if (!Array.isArray(i)) break;
					let n = [];
					for (let r of i) {
						let i = w(r);
						if (!i) continue;
						let o = W(i.placeId, e, t);
						if (o) {
							if (typeof i.x != "number" || typeof i.y != "number" || i.x < 0 || i.x > 1 || i.y < 0 || i.y > 1) {
								a("VALIDATION_FAILED", "地図座標が不正です。", e.id, t);
								continue;
							}
							n.push({
								placeId: o,
								x: i.x,
								y: i.y
							});
						}
					}
					return n;
				}
				case "datetime":
					if (typeof i == "string" && Number.isFinite(Date.parse(i))) return i;
					break;
				case "version_ref": {
					let r = n.versionTargets?.[String(i)];
					if (!r) {
						a("EXPORT_UNSUPPORTED", "媒体の元固定版の公開範囲を確認してください。", e.id, t);
						return;
					}
					return r.publicVersionId;
				}
				case "anchor": return ce(i, e, t);
				case "trigger": {
					let t = w(i);
					if (!t || ![
						"enter",
						"talk",
						"battle_result",
						"manual",
						"custom"
					].includes(String(t.event)) || !["once", "repeatable"].includes(String(t.repeat))) break;
					let n = J(e, "eventKey");
					if (typeof t.eventKey == "string" && t.eventKey && n === void 0) {
						a("PUBLIC_TEXT_REQUIRED", "外部イベント名の公開表記を指定してください。", e.id, "eventKey");
						return;
					}
					let r = t.deadline == null ? void 0 : ue({
						...e,
						data: {
							...e.data,
							deadline: t.deadline
						}
					}, "deadline", m);
					if (t.deadline != null && r === void 0) return;
					let o = {
						event: String(t.event),
						repeat: String(t.repeat),
						eventKey: n ?? ""
					};
					if (typeof t.id == "string" && P[t.id] && (o.id = P[t.id]), t.scope != null) {
						if (![
							"scene",
							"chapter",
							"character",
							"run",
							"across_runs"
						].includes(String(t.scope))) break;
						o.scope = String(t.scope);
					}
					return r !== void 0 && (o.deadline = r), o;
				}
				case "transitions": {
					if (!Array.isArray(i)) break;
					let n = [], r = e.kind === "quest" && typeof e.data.stateVariableId == "string" ? e.data.stateVariableId : e.id;
					for (let o of i) {
						let i = w(o);
						if (!i) {
							a("VALIDATION_FAILED", "状態遷移の形が不正です。", e.id, t);
							continue;
						}
						let s = G(i.from, r, e, t), c = G(i.to, r, e, t), l = i.exceptionDetails ? Q(i.exceptionDetails, e, t) : void 0;
						if (i.exception === !0 && !l) {
							a("EXPORT_UNSUPPORTED", "理由・範囲・期限・根拠のある例外を公開範囲へ含めてください。", e.id, t);
							continue;
						}
						s !== void 0 && c !== void 0 && n.push({
							from: s,
							to: c,
							...l ? {
								exception: !0,
								exceptionDetails: l
							} : {}
						});
					}
					return n;
				}
			}
			a("EXPORT_UNSUPPORTED", "この項目は対応先で安全に表せません。", e.id, t);
		}
	}, de = [];
	for (let e of k) {
		let t = v[e.kind], n = T(R, e.kind), r = Array.isArray(n) ? n : Object.keys(t), i = {};
		for (let n of r) {
			if (typeof n != "string" || b.has(n) || !E(t, n)) {
				a("FORBIDDEN", "許可されていない項目を公開しようとしています。", e.id, String(n));
				continue;
			}
			if (z.includes(n) || z.includes(`${e.kind}.${n}`)) {
				o(e.id, "作者が項目を除外", n);
				continue;
			}
			let r = ue(e, n, t[n]);
			r !== void 0 && (i[n] = r);
		}
		for (let n of Object.keys(e.data)) (!r.includes(n) || !E(t, n)) && o(e.id, b.has(n) ? "作者情報・秘密の項目を除外" : "公開を許可していない項目を除外", n);
		if (e.kind === "attachment") {
			let t = Array.isArray(l.approvedAttachmentIds) && l.approvedAttachmentIds.includes(e.id), n = typeof e.data.provenanceId == "string" ? s.get(e.data.provenanceId) : void 0;
			(!t || n && n.data.redistributionAllowed !== !0) && a("FORBIDDEN", "添付の再配布許可を確認してください。", e.id);
			let r = e.data.mediaType;
			typeof r != "string" || !S[r] ? a("EXPORT_UNSUPPORTED", "この素材形式は公開出力に対応していません。", e.id, "mediaType") : (i.mediaType = r, i.assetPath = `assets/${P[e.id]}.${S[r]}`), typeof e.data.contentHash != "string" || !/^[a-f0-9]{64}$/.test(e.data.contentHash) || !D(e.data.byteSize) || e.data.byteSize < 0 ? a("VALIDATION_FAILED", "素材のhashとサイズが不正です。", e.id) : (i.contentHash = e.data.contentHash, i.byteSize = e.data.byteSize, i.bytesIncluded = !1);
		}
		if (e.kind === "source" && e.data.sourceType === "web" && typeof i.locator == "string") try {
			let e = new URL(i.locator);
			if (!["http:", "https:"].includes(e.protocol) || e.username || e.password) throw Error();
		} catch {
			a("FORBIDDEN", "公開資料のURLは認証情報を含まないHTTP/HTTPSにしてください。", e.id, "locator");
		}
		de.push({
			id: P[e.id],
			kind: e.kind,
			name: A.get(e.id),
			status: e.status,
			data: i
		});
	}
	let fe = [], pe = Array.isArray(l.allowedRelationIds) ? l.allowedRelationIds : [], me = new Map(e.relations.map((e) => [e.id, e]));
	for (let n of pe) {
		if (typeof n != "string") {
			a("VALIDATION_FAILED", "関係の公開IDが不正です。", t, "allowedRelationIds");
			continue;
		}
		let r = me.get(n);
		if (!r || r.projectId !== e.projectId) {
			a("REFERENCE_INVALID", "作品内にない関係が公開範囲に含まれています。", n);
			continue;
		}
		if (!V.has(r.fromId) || !V.has(r.toId) || r.status !== "confirmed" || r.deletedAt) {
			o(n, "非公開の始点・終点、削除済みまたは未確定の関係");
			continue;
		}
		let i = T(w(T(p, n)), "relationType");
		if (typeof i != "string" || !i) {
			a("PUBLIC_TEXT_REQUIRED", "公開用の関係名を指定してください。", n, "relationType");
			continue;
		}
		L(n);
		let s = Z(r.validity, {
			id: n,
			projectId: e.projectId,
			kind: "note",
			name: "",
			status: r.status,
			data: {}
		}, "validity");
		fe.push({
			...s ? { validity: s } : {},
			id: P[n],
			fromId: P[r.fromId],
			toId: P[r.toId],
			relationType: i,
			direction: r.direction,
			evidenceIds: r.evidenceIds.filter((e) => V.has(e)).map((e) => P[e])
		});
	}
	if (r.length) return {
		ok: !1,
		issues: r,
		omissions: i
	};
	let he = {
		format: "scenario-projection",
		formatVersion: "1.0.0",
		title: u,
		mainStart: e.mainStart,
		calendars: H,
		entities: de,
		relations: fe,
		searchIndex: []
	};
	return he.searchIndex = ne(he), {
		ok: !0,
		projection: he,
		omissions: i,
		idMap: P
	};
}
function te(e, t, n, r, i) {
	let a = w(t.routeScope);
	if (!a) return;
	if (a.projectId !== n) return i("REFERENCE_INVALID", "公開範囲が別の作品を参照しています。", void 0, "routeScope"), /* @__PURE__ */ new Set();
	if (a.routeCondition != null) return i("EXPORT_UNSUPPORTED", "条件付き経路の安全な公開範囲は未対応です。IDまたは章・グラフで限定してください。", void 0, "routeScope.routeCondition"), /* @__PURE__ */ new Set();
	if (a.chapterId != null && a.graphId != null) return i("EXPORT_UNSUPPORTED", "章とグラフの範囲は一度に一つ選んでください。", void 0, "routeScope"), /* @__PURE__ */ new Set();
	if (a.chapterId == null && a.graphId == null) return;
	let o = a.chapterId ?? a.graphId, s = typeof o == "string" ? e.get(o) : void 0;
	if (!s || s.projectId !== n || s.kind !== (a.chapterId == null ? "flow_graph" : "chapter") || s.deletedAt) return i("REFERENCE_INVALID", "公開範囲の章またはグラフが見つかりません。", typeof o == "string" ? o : void 0, "routeScope"), /* @__PURE__ */ new Set();
	let c = new Set(Array.isArray(t.includedIds) ? t.includedIds.filter((e) => typeof e == "string") : []), l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Set();
	if (s.kind === "chapter") {
		l.add(s.id);
		for (let t of e.values()) t.kind === "scene" && (t.data.chapterId === s.id || Array.isArray(s.data.sceneIds) && s.data.sceneIds.includes(t.id)) && u.add(t.id);
	} else {
		let t = [s], n = /* @__PURE__ */ new Set();
		for (; t.length;) {
			let r = t.pop();
			if (!n.has(r.id)) {
				n.add(r.id), l.add(r.id);
				for (let e of [...Array.isArray(r.data.nodeIds) ? r.data.nodeIds : [], ...Array.isArray(r.data.edgeIds) ? r.data.edgeIds : []]) typeof e == "string" && l.add(e);
				for (let n of Array.isArray(r.data.nodeIds) ? r.data.nodeIds : []) {
					let r = typeof n == "string" ? e.get(n) : void 0;
					if (!r || r.kind !== "flow_node") continue;
					typeof r.data.sceneId == "string" && u.add(r.data.sceneId);
					let i = typeof r.data.childGraphId == "string" ? e.get(r.data.childGraphId) : void 0;
					i?.kind === "flow_graph" && c.has(i.id) && t.push(i);
				}
			}
		}
	}
	let d = (t) => t.kind === "scene" ? u.has(t.id) : [
		"flow_graph",
		"flow_node",
		"flow_edge"
	].includes(t.kind) ? s.kind === "flow_graph" && l.has(t.id) : t.kind === "chapter" ? s.kind === "chapter" ? t.id === s.id : [...u].some((n) => e.get(n)?.data.chapterId === t.id) : !0, f = /* @__PURE__ */ new Set(), p = [...l, ...u], m = (e) => {
		typeof e == "string" && c.has(e) && p.push(e);
	}, h = (e, t = 1) => {
		let n = w(e);
		if (!(!n || t > 16)) {
			for (let e of [
				"variableId",
				"itemId",
				"assertionId",
				"holderId",
				"entityId",
				"contractId"
			]) m(n[e]);
			Array.isArray(n.children) && n.children.forEach((e) => h(e, t + 1)), n.child && h(n.child, t + 1);
		}
	};
	for (; p.length;) {
		let t = p.pop();
		if (f.has(t) || !c.has(t)) continue;
		let n = e.get(t);
		if (n && d(n)) {
			f.add(t);
			for (let [e, t] of Object.entries(v[n.kind] ?? {})) {
				if (e === "parentId" || e === "parentGraphId") continue;
				let i = n.data[e];
				if (t.type === "ref") m(i);
				else if (t.type === "refs" && Array.isArray(i)) i.forEach(m);
				else if (t.type === "condition") h(i);
				else if (t.type === "typed" && w(i)?.type === "ref") m(w(i)?.value);
				else if (t.type === "time") m(w(i)?.anchorEventId);
				else if (t.type === "anchor") m(w(i)?.entityId), m(w(i)?.lineId);
				else if (t.type === "participants" && Array.isArray(i)) i.forEach((e) => m(w(e)?.characterId));
				else if (t.type === "pins" && Array.isArray(i)) i.forEach((e) => m(w(e)?.placeId));
				else if (t.type === "rich") {
					let t = T(w(T(r, n.id)), e);
					if (Array.isArray(t)) {
						for (let e of t) if (Array.isArray(w(e)?.links)) for (let t of w(e).links) {
							let e = w(w(t)?.target) ?? w(t);
							m(e?.entityId ?? e?.targetId), m(e?.lineId);
						}
					}
				}
			}
		}
	}
	return f;
}
function k(e) {
	return typeof e == "string" ? [e] : Array.isArray(e) ? e.flatMap(k) : e && typeof e == "object" ? Object.entries(e).filter(([e]) => [
		"text",
		"reading",
		"summary",
		"body",
		"description",
		"label",
		"canonical"
	].includes(e)).flatMap(([, e]) => k(e)) : [];
}
function ne(e) {
	return e.entities.map((e) => {
		let t = [e.name, ...k(e.data)].join("\n");
		return {
			entityId: e.id,
			kind: e.kind,
			name: e.name,
			text: t,
			normalized: t.normalize("NFKC").toLocaleLowerCase("ja")
		};
	});
}
//#endregion
//#region ../shinariokanri-rb10-basic-registration/src/domain/exportPreparation.ts
var A = /^(?:0|[1-9][0-9]*)$/, j = (t) => e(i(t));
function M(e) {
	return Array.isArray(e) ? e : [];
}
function N(e) {
	return [
		"body",
		"text",
		"summary",
		"description",
		"usageNotes",
		"caption",
		"action",
		"tutorial",
		"interpretation",
		"targetAudience",
		"experience",
		"theme",
		"tone",
		"scope"
	].filter((t) => M(e.data[t]).length).map((t) => [t, M(e.data[t])]);
}
async function P(e, t) {
	if (t.targetRevision === void 0 == (t.targetVersionId === void 0)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			message: "出力する正本の版を一つ指定してください。"
		}]
	};
	if (t.targetRevision !== void 0) return !A.test(t.targetRevision) || t.targetRevision !== e.revision ? {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			message: "選択した版と出力元の版が一致しません。対象版を読み直してください。"
		}]
	} : {
		ok: !0,
		project: e
	};
	let n = e.snapshots.find((e) => e.id === t.targetVersionId);
	if (!n || n.content.projectId !== e.projectId) return {
		ok: !1,
		issues: [{
			code: "REFERENCE_INVALID",
			message: "選択した公開版の保存内容が見つかりません。",
			entityId: t.targetVersionId
		}]
	};
	let r = [], i = [n], a = /* @__PURE__ */ new Set();
	for (; i.length;) {
		let t = i.pop();
		if (!a.has(t.id)) {
			if (a.add(t.id), e.snapshots.filter((e) => e.id === t.id).length !== 1 || t.content.projectId !== e.projectId) return {
				ok: !1,
				issues: [{
					code: "REFERENCE_INVALID",
					message: "保存版の依存内容を一意に確認できません。",
					entityId: t.id
				}]
			};
			if (await j(t.content) !== t.contentHash) return {
				ok: !1,
				issues: [{
					code: "VALIDATION_FAILED",
					message: "保存版の内容hashが一致しないため出力を停止しました。",
					entityId: t.id
				}]
			};
			r.push(t);
			for (let n of t.content.entities) for (let t of o(n)) if (t.scope === "snapshot") {
				let n = e.snapshots.find((e) => e.id === t.id);
				n && !a.has(n.id) && i.push(n);
			}
		}
	}
	return {
		ok: !0,
		project: {
			...structuredClone(n.content),
			snapshots: r,
			history: []
		}
	};
}
async function F(e, n, i) {
	let o = await a(e, i.targetVersionId ?? e.projectId, { worldSnapshots: i.worldSnapshots ?? {} }), c = t(o, o.snapshots);
	function l(e, t, n = []) {
		let r = s(c, t);
		if (Array.isArray(e)) return e.map((e, r) => l(e, t, [...n, String(r)]));
		if (!e || typeof e != "object") return e;
		let a = e, o = i.targetVersionId ?? c.projectId;
		if (n.includes("links") && n.at(-1) === "target" && typeof a.sourceVersionId == "string") return structuredClone(a);
		let u = Object.fromEntries(Object.entries(a).filter(([e]) => e !== "reuse").map(([e, i]) => [e, r && ["sourceVersionId", "targetSnapshotId"].includes(e) && i === r.sourceVersionId ? o : l(i, t, [...n, e])]));
		if (r && typeof a.entityId == "string" && a.sourceVersionId === r.sourceVersionId) for (let e of [
			"entityId",
			"blockId",
			"lineId"
		]) typeof a[e] == "string" && (u[e] = r.bindings[a[e]] ?? a[e]);
		return u;
	}
	let u = r(c, i.worldSnapshots ?? {}).worlds, d = c.entities.map((e) => ({
		...e,
		data: l(e.data, e.id)
	})), f = new Set(d.map((e) => e.id)), p = [...c.relations], m = new Set(p.map((e) => e.id)), h = [...c.calendars];
	for (let e of u) {
		for (let t of e.entities) {
			if (f.has(t.id)) throw Error("REFERENCE_INVALID: 固定世界と出力元のIDが衝突しています。");
			f.add(t.id), d.push({
				...structuredClone(t),
				projectId: c.projectId
			});
		}
		for (let t of e.relations) {
			if (m.has(t.id)) throw Error("REFERENCE_INVALID: 固定世界の関係IDが衝突しています。");
			m.add(t.id), p.push({
				...structuredClone(t),
				projectId: c.projectId
			});
		}
		for (let t of e.calendars) h.some((e) => e.id === t.id) || h.push(structuredClone(t));
	}
	if (!d.find((e) => e.id === i.projectionProfileId) && i.targetVersionId) {
		let t = e.entities.find((e) => e.id === i.projectionProfileId && e.kind === "projection_profile" && e.data.sourceVersionId === i.targetVersionId);
		t && d.push(structuredClone(t));
	}
	return {
		...n,
		entities: d,
		relations: p,
		calendars: h
	};
}
function I(e) {
	let t = new Map([["public-project", e], ...(e.versions ?? []).map((e) => [e.id, e.projection])]), n = [];
	for (let [e, r] of t) {
		let i = (r) => {
			if (Array.isArray(r)) {
				r.forEach(i);
				return;
			}
			if (!r || typeof r != "object") return;
			let a = r, o = a.entityId ?? a.targetId, s = a.targetId ? a.targetStart : a.start, c = a.targetId ? a.targetEnd : a.end;
			if (typeof o == "string" && (a.blockId != null || a.lineId != null || s != null || c != null)) {
				let r = t.get(typeof a.sourceVersionId == "string" ? a.sourceVersionId : e), i = r?.entities.find((e) => e.id === o), l = typeof a.lineId == "string" ? r?.entities.find((e) => e.id === a.lineId && e.kind === "dialogue_line") : void 0, u = typeof a.blockId == "string" ? i && N(i).flatMap(([, e]) => e).find((e) => e.id === a.blockId) : void 0, d = u?.text ?? (l ? M(l.data.text).map((e) => e.text).join("\n") : void 0), f = !i || a.blockId != null && !u || a.lineId != null && !l, p = (s != null || c != null) && (!Number.isSafeInteger(s) || !Number.isSafeInteger(c) || Number(s) < 0 || Number(c) < Number(s) || d === void 0 || Number(c) > [...d].length);
				(f || p) && n.push({
					code: "REFERENCE_INVALID",
					message: "公開した固定版の本文位置を確認できません。公開文と文字範囲を再確認してください。",
					entityId: o
				});
			}
			Object.values(a).forEach(i);
		};
		r.entities.forEach((e) => i(e.data));
	}
	return n;
}
async function L(t, n, r, a) {
	let o = {}, s = [], c = [], l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map();
	async function f(n, p, m) {
		if (m > 64) throw Error("IMPORT_LIMIT: 引用固定版の依存が64段階を超えています。");
		let h = n.entities.find((e) => e.id === p && e.kind === "projection_profile" && e.status === "confirmed" && !e.deletedAt);
		if (!h) throw Error("REFERENCE_INVALID: 引用固定版の公開範囲が未確認です。");
		for (let n of h.data.citedVersions ?? []) {
			let p = n.sourceVersionId, h = o[p];
			if (l.has(p)) throw Error("REFERENCE_INVALID: 引用固定版の公開依存が循環しています。");
			if (h) {
				if (h.publicVersionId !== n.publicVersionId || u.get(p) !== n.profileId) throw Error("REFERENCE_INVALID: 同じ引用版に異なる公開範囲が指定されています。");
				continue;
			}
			if (s.length + l.size >= 128 || d.has(n.publicVersionId) || !n.publicVersionId) throw Error("IMPORT_LIMIT: 引用固定版の上限または公開版IDが不正です。");
			d.set(n.publicVersionId, p), l.add(p);
			let g = t.snapshots.find((e) => e.id === p), _ = (r.worldPins ?? []).find((e) => e.id === p), v = g ?? _, y = r.worldSnapshots ?? {};
			if (!v || await e(i(v.content)) !== v.contentHash || _ && (!y[p] || await e(i(y[p])) !== v.contentHash)) throw Error("INTEGRITY_FAILED: 引用版の期待hashまたは内容が一致しません。");
			let b = v.content.projectId === t.projectId ? t.snapshots : [...(r.worldPins ?? []).filter((e) => e.content.projectId === v.content.projectId).map((e) => ({
				...e,
				createdAt: "1970-01-01T00:00:00.000Z",
				versionLabel: "引用する固定世界"
			}))], x = {
				...structuredClone(v.content),
				snapshots: structuredClone(b),
				history: []
			}, S = x.entities.find((e) => e.id === n.profileId && e.kind === "projection_profile"), C = t.entities.find((e) => e.id === n.profileId && e.kind === "projection_profile" && e.data.sourceVersionId === p);
			if (!S && !C) throw Error("REFERENCE_INVALID: 引用対象版の公開文を確認した範囲がありません。");
			let w = await F(x, x, {
				...r,
				projectionProfileId: n.profileId,
				targetVersionId: p,
				targetRevision: void 0
			});
			!S && C && w.entities.push({
				...structuredClone(C),
				projectId: w.projectId
			}), await f(w, n.profileId, m + 1);
			let T = O(w, n.profileId, {
				strictReferences: a,
				confirmedOnly: !0,
				targetVersionId: p,
				versionTargets: o
			});
			if (!T.ok) throw Object.assign(Error("EXPORT_UNSUPPORTED: 引用版の公開名・本文・必要参照が未確認です。"), { issues: T.issues });
			o[p] = {
				publicVersionId: n.publicVersionId,
				idMap: T.idMap
			}, u.set(p, n.profileId), s.push({
				id: n.publicVersionId,
				projection: T.projection
			}), c.push({
				publicVersionId: n.publicVersionId,
				profileId: n.profileId,
				project: w,
				projection: T.projection,
				idMap: T.idMap
			}), l.delete(p);
		}
	}
	return await f(n, r.projectionProfileId, 0), {
		targets: o,
		versions: s,
		sources: c
	};
}
async function R(e, t) {
	let r = structuredClone(e), i = structuredClone(t), a = await P(r, i);
	if (!a.ok) throw Object.assign(Error("REFERENCE_INVALID: 出力対象版を確認できません。"), { issues: a.issues });
	let o = n(a.project, { worldSnapshots: i.worldSnapshots ?? {} });
	if (!o.ok) throw Object.assign(Error("REFERENCE_INVALID: 出力対象版の参照が不正です。"), { issues: o.issues });
	let s = await F(r, a.project, i), c = await L(r, s, i, !0), l = O(s, i.projectionProfileId, {
		strictReferences: !0,
		confirmedOnly: !0,
		targetVersionId: i.targetVersionId,
		versionTargets: c.targets
	});
	if (!l.ok) throw Object.assign(Error("EXPORT_UNSUPPORTED: 固定した公開範囲を再構成できません。"), { issues: l.issues });
	c.versions.length && (l.projection.versions = c.versions);
	let u = I(l.projection);
	if (u.length) throw Object.assign(Error("REFERENCE_INVALID: 固定した公開本文位置が不正です。"), { issues: u });
	return {
		project: s,
		projection: l.projection,
		idMap: l.idMap,
		citations: c
	};
}
//#endregion
export { I as n, v as r, R as t };
