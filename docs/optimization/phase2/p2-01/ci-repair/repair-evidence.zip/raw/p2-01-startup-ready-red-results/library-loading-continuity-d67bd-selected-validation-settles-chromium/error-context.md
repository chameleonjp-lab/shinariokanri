# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library-loading-continuity.spec.ts >> remembered startup exposes readiness only after selected validation settles
- Location: tests/e2e/library-loading-continuity.spec.ts:40:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.library-page,.app-shell')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.library-page,.app-shell') with timeout 5000ms
  - waiting for locator('.library-page,.app-shell')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - generic [ref=f1e4]:
    - generic [ref=f1e5]:
      - button "アカウント・専用同期" [ref=f1e6] [cursor=pointer]
      - generic [ref=f1e7]: この端末の作品
    - group "任意持出し診断" [ref=f1e8]:
      - generic "この作業の診断を確認・持出し" [ref=f1e9]
  - generic [ref=f1e11]:
    - banner [ref=f1e12]:
      - link "本文へ移動" [ref=f1e13] [cursor=pointer]:
        - /url: "#main-content"
      - generic [ref=f1e14]:
        - generic [ref=f1e15]: S
        - generic [ref=f1e16]: シナリオ管理
      - button "配色を切り替え" [ref=f1e17] [cursor=pointer]
    - main [ref=f1e18]:
      - generic [ref=f1e19]:
        - generic [ref=f1e20]: YOUR STORY, CONNECTED.
        - heading "物語をつなぐ。 次の一行へ。" [level=1] [ref=f1e21]: 物語をつなぐ。次の一行へ。
        - paragraph [ref=f1e22]: 人物、出来事、本文、分岐。作品のすべてを、ひとつのノートに。
      - generic [ref=f1e23]:
        - generic [ref=f1e24]:
          - heading "新しい作品をはじめる" [level=2] [ref=f1e29]
          - paragraph [ref=f1e30]: まずはタイトルだけ。詳細はあとから。
          - generic [ref=f1e31]:
            - generic [ref=f1e32]: 作品名
            - textbox "作品名" [ref=f1e33]:
              - /placeholder: あなたの物語のタイトル
            - button "作品を作成" [disabled] [ref=f1e34]
          - generic [ref=f1e35]:
            - button "サンプルで試す" [ref=f1e36] [cursor=pointer]
            - button "保存ファイルを読み込む" [ref=f1e37] [cursor=pointer]
        - generic [ref=f1e38]:
          - generic [ref=f1e39]:
            - heading "あなたの作品" [level=2] [ref=f1e40]
            - generic [ref=f1e41]: "1"
          - button "起動時の選択を検査 0件の情報 · 端末内保存" [ref=f1e43] [cursor=pointer]:
            - generic [ref=f1e45]:
              - strong [ref=f1e46]: 起動時の選択を検査
              - generic [ref=f1e47]: 0件の情報 · 端末内保存
      - status [ref=f1e48]:
        - text: 選択した作品を読み込んでいます
        - button "作品の読み込みを中止" [ref=f1e49] [cursor=pointer]
      - generic [ref=f1e50]:
        - generic [ref=f1e51]: 作品はこのブラウザーに保存されます
        - generic [ref=f1e53]: 端末内の作品 · 同期はアカウント欄から設定できます
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {createProject} from '../../src/domain/model';
  3  | import {exportScenario,inspectScenario} from '../../src/storage/archive';
  4  | import {seed} from './ap04-original-helpers';
  5  | import {exerciseF35Replacement} from './ap04-original-f35-replace-helper';
  6  | 
  7  | async function holdEditorHash(page:Page,afterImport=false){
  8  |  await page.evaluate(afterImport=>{
  9  |   const state={armed:!afterImport,entered:false,release:()=>{}};
  10 |   (window as unknown as {editorGate:typeof state}).editorGate=state;
  11 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  12 |   if(afterImport){const add=IDBObjectStore.prototype.add;IDBObjectStore.prototype.add=function(...args:Parameters<IDBObjectStore['add']>){const request=add.apply(this,args);if(this.name==='importLogs')request.addEventListener('success',()=>{state.armed=true;});return request;};}
  13 |   crypto.subtle.digest=async(...args)=>{if(state.armed&&!state.entered){state.entered=true;await held;}return digest(...args);};
  14 |  },afterImport);
  15 | }
  16 | const entered=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{entered:boolean}}).editorGate.entered);
  17 | const release=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{release:()=>void}}).editorGate.release());
  18 | 
  19 | test('reload during selected validation resumes the requested work without publishing an unvalidated editor',async({page})=>{
  20 |  const project=createProject('読み込み中の選択を再開');await seed(page,await exportScenario(project));await page.locator('.project-switch').click();
  21 |  await page.evaluate(()=>{localStorage.removeItem('scenario-last-project:guest');localStorage.removeItem('scenario-last-project');});
  22 |  await holdEditorHash(page);await page.locator('.project-card').filter({hasText:project.name}).click();await expect.poll(()=>entered(page)).toBe(true);
  23 |  await expect(page.locator('.app-shell')).toHaveCount(0);await page.reload();await expect(page.locator('.project-switch')).toContainText(project.name);
  24 | });
  25 | 
  26 | test('clone completion remains visible after its delayed selected editor is published',async({page})=>{
  27 |  const project=createProject('複製の完了を保持');const bytes=await exportScenario(project);await seed(page,bytes);
  28 |  await page.locator('.sidebar').getByRole('button',{name:/^作品・保存/}).click();await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
  29 |  await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles({name:'clone.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});await page.getByLabel('復元方法',{exact:true}).selectOption('clone');await page.getByLabel('復元方法と対象への影響を確認しました').check();
  30 |  await holdEditorHash(page,true);await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>entered(page)).toBe(true);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await release(page);
  31 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).not.toBe(project.projectId);
  32 |  await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。',{exact:true})).toBeVisible();
  33 | });
  34 | 
  35 | test('confirmed authenticated bootstrap permits the original replacement and rollback workflow',async({browser},info)=>{
  36 |  const bytes=new Uint8Array(await exportScenario(createProject('登録直後の復元対象')));
  37 |  await exerciseF35Replacement(browser,info,{bytes,...await inspectScenario(bytes,{worker:false})});
  38 | });
  39 | 
  40 | test('remembered startup exposes readiness only after selected validation settles',async({page})=>{
  41 |  const project=createProject('起動時の選択を検査');await seed(page,await exportScenario(project));
  42 |  await page.addInitScript(projectId=>{
  43 |   const state={entered:false,release:()=>{},headers:0};(window as unknown as {editorGate:typeof state}).editorGate=state;
  44 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  45 |   crypto.subtle.digest=async(...args)=>{let header=false;try{const value=JSON.parse(new TextDecoder().decode(args[1]));header=value.projectId===projectId&&Array.isArray(value.entityIds);}catch{}if(header&&++state.headers===2){state.entered=true;await held;}return digest(...args);};
  46 |  },project.projectId);
> 47 |  await page.reload();await expect.poll(()=>entered(page)).toBe(true);await expect(page.locator('.library-page,.app-shell')).toHaveCount(0);await release(page);await expect(page.locator('.project-switch')).toContainText(project.name);
     |                                                                                                                             ^ Error: expect(locator).toHaveCount(expected) failed
  48 | });
  49 | 
  50 | for(const boundary of ['cancel','newer selection','error'] as const)test(`pending selection ${boundary} preserves the last validated work and cannot restore older intent`,async({page})=>{
  51 |  const a=createProject('遅延または失敗する作品A');await seed(page,await exportScenario(a));await page.locator('.project-switch').click();await page.getByLabel('作品名',{exact:true}).fill('最後に検査した作品B');await page.getByRole('button',{name:'作品を作成',exact:true}).click();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');
  52 |  const b=await page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'));await page.locator('.project-switch').click();
  53 |  if(boundary==='error')await page.evaluate(async id=>{const db=await new Promise<IDBDatabase>(resolve=>{const request=indexedDB.open('scenario-manager-local-v1');request.onsuccess=()=>resolve(request.result);});await new Promise<void>((resolve,reject)=>{const tx=db.transaction('projects','readwrite'),table=tx.objectStore('projects'),request=table.get(id);request.onsuccess=()=>table.put({...request.result,schemaVersion:'999.0'});tx.oncomplete=()=>resolve();tx.onabort=()=>reject(tx.error);});db.close();},a.projectId);
  54 |  else await holdEditorHash(page);
  55 |  await page.locator('.project-card').filter({hasText:a.name}).click();
  56 |  if(boundary==='error')await expect(page.getByRole('alert')).toBeVisible();
  57 |  else{await expect.poll(()=>entered(page)).toBe(true);if(boundary==='cancel')await page.getByRole('button',{name:'作品の読み込みを中止',exact:true}).click();else{await page.locator('.project-card').filter({hasText:'最後に検査した作品B'}).click();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');}await release(page);}
  58 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-opening-project:guest'))).toBe('');expect(await page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).toBe(b);await page.reload();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');
  59 | });
  60 | 
```