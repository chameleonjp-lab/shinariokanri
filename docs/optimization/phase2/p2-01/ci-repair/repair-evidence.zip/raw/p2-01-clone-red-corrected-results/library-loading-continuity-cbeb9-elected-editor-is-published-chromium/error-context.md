# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library-loading-continuity.spec.ts >> clone completion remains visible after its delayed selected editor is published
- Location: tests/e2e/library-loading-continuity.spec.ts:26:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('検査した作品を端末内に復元しました。保存した版を確認しました。', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('検査した作品を端末内に復元しました。保存した版を確認しました。', { exact: true }) with timeout 5000ms
  - waiting for getByText('検査した作品を端末内に復元しました。保存した版を確認しました。', { exact: true })

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- link "本文へ移動":
  - /url: "#main-content"
- complementary "主要ナビゲーション":
  - text: S シナリオ管理
  - button "複製の完了を保持 作品一覧へ ⌄":
    - strong: 複製の完了を保持
    - text: 作品一覧へ ⌄
  - text: WORKSPACE
  - navigation:
    - button "年表"
    - button "構成"
    - button "資料 0"
    - button "検索"
  - text: QUICK NOTE
  - button "アイデアを残す"
  - button "作品・保存"
  - strong: この端末に保存
  - text: 同期接続先は未設定
  - button "暗い配色にする"
- banner:
  - text: 複製の完了を保持 / 年表
  - status: 端末内保存済み LOCAL
- main:
  - text: STORY TIMELINE
  - heading "年表" [level=1]
  - paragraph: 物語の時間と、そこで起きたこと。
  - button "出来事を追加"
  - tablist "年表と関係":
    - tab "世界内年表" [selected]
    - tab "関係表・図"
    - tab "世界・地図・履歴"
  - group: 最近開いた情報・お気に入り
  - button "年表"
  - button "出来事一覧"
  - text: 年表の暦
  - combobox "年表の暦":
    - option "選択してください"
    - option "先発グレゴリオ暦" [selected]
  - text: 表示単位
  - combobox "年表の表示単位":
    - option "tick" [selected]
    - option "時"
    - option "日"
    - option "月"
    - option "年"
    - option "独自表示単位"
  - button "年表を縮小": −
  - text: 1倍
  - button "年表を拡大": ＋
  - button "全体へ戻る"
  - button "本編開始へ"
  - text: 先発グレゴリオ暦 本編開始 0 tick 表示 -60 〜 60 tick 中心の本編基準 0 tick
  - button "グループ・人物レーン"
  - button "選択した出来事の日時・制約" [disabled]
  - button "本編開始の基準を変更"
  - button "全出来事の日時を移動"
  - button "前回の日時変更を一括取消" [disabled]
  - heading "物語の時間を並べましょう" [level=3]
  - paragraph: 日時が未定でも、要約から出来事を残せます。
  - button "出来事を追加"
  - button "前の期間"
  - textbox "移動先の世界内tick":
    - /placeholder: tickへ移動
  - button "移動"
  - button "次の期間"
  - group: 暦の日付へ移動する
  - heading "出来事間の関係" [level=3]
  - text: "0"
  - combobox "年表の関係を種類で絞り込む":
    - option "すべての出来事間の関係" [selected]
    - option "因果"
    - option "前提"
    - option "出来事の予告"
    - option "出来事の回収"
    - option "関連"
    - option "参照"
  - checkbox "選択した出来事に関係する線"
  - text: 選択した出来事に関係する線
  - button "始点 → 終点をタップで結ぶ"
  - button "一覧から関係を追加"
- contentinfo: 端末内の作品 · 版 1 0件の情報 · 0件の関係
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {createProject} from '../../src/domain/model';
  3  | import {exportScenario,inspectScenario} from '../../src/storage/archive';
  4  | import {seed} from './ap04-original-helpers';
  5  | import {exerciseF35Replacement} from './ap04-original-f35-replace-helper';
  6  | 
  7  | async function holdEditorHash(page:Page,afterImport=false){
  8  |  await page.evaluate(afterImport=>{
  9  |   const state={armed:!afterImport,entered:false,release:()=>{}};
  10 |   (window as unknown as {editorGate:typeof state}).editorGate=state;
  11 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  12 |   if(afterImport){const add=IDBObjectStore.prototype.add;IDBObjectStore.prototype.add=function(...args:Parameters<IDBObjectStore['add']>){const request=add.apply(this,args);if(this.name==='importLogs')request.addEventListener('success',()=>{state.armed=true;});return request;};}
  13 |   crypto.subtle.digest=async(...args)=>{if(state.armed&&!state.entered){state.entered=true;await held;}return digest(...args);};
  14 |  },afterImport);
  15 | }
  16 | const entered=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{entered:boolean}}).editorGate.entered);
  17 | const release=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{release:()=>void}}).editorGate.release());
  18 | 
  19 | test('reload during selected validation resumes the requested work without publishing an unvalidated editor',async({page})=>{
  20 |  const project=createProject('読み込み中の選択を再開');await seed(page,await exportScenario(project));await page.locator('.project-switch').click();
  21 |  await page.evaluate(()=>{localStorage.removeItem('scenario-last-project:guest');localStorage.removeItem('scenario-last-project');});
  22 |  await holdEditorHash(page);await page.locator('.project-card').filter({hasText:project.name}).click();await expect.poll(()=>entered(page)).toBe(true);
  23 |  await expect(page.locator('.app-shell')).toHaveCount(0);await page.reload();await expect(page.locator('.project-switch')).toContainText(project.name);
  24 | });
  25 | 
  26 | test('clone completion remains visible after its delayed selected editor is published',async({page})=>{
  27 |  const project=createProject('複製の完了を保持');const bytes=await exportScenario(project);await seed(page,bytes);
  28 |  await page.locator('.sidebar').getByRole('button',{name:/^作品・保存/}).click();await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
  29 |  await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles({name:'clone.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});await page.getByLabel('復元方法',{exact:true}).selectOption('clone');await page.getByLabel('復元方法と対象への影響を確認しました').check();
  30 |  await holdEditorHash(page,true);await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>entered(page)).toBe(true);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await release(page);
  31 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).not.toBe(project.projectId);
> 32 |  await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。',{exact:true})).toBeVisible();
     |                                                                               ^ Error: expect(locator).toBeVisible() failed
  33 | });
  34 | 
  35 | test('confirmed authenticated bootstrap permits the original replacement and rollback workflow',async({browser},info)=>{
  36 |  const bytes=await exportScenario(createProject('登録直後の復元対象'));
  37 |  await exerciseF35Replacement(browser,info,{bytes,...await inspectScenario(bytes,{worker:false})});
  38 | });
  39 | 
```