# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library-loading-continuity.spec.ts >> pending selection cancel preserves the last validated work and cannot restore older intent
- Location: tests/e2e/library-loading-continuity.spec.ts:50:69

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '作品の読み込みを中止', exact: true })
    - locator resolved to <button class="text-button">作品の読み込みを中止</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - button "アカウント・専用同期" [ref=e6] [cursor=pointer]
      - generic [ref=e7]: この端末の作品
    - group "任意持出し診断" [ref=e8]:
      - generic "この作業の診断を確認・持出し" [ref=e9]
  - generic [ref=e11]:
    - link "本文へ移動" [ref=e12] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "主要ナビゲーション" [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]: S
        - generic [ref=e16]: シナリオ管理
      - button "遅延または失敗する作品A 作品一覧へ ⌄" [ref=e17] [cursor=pointer]:
        - generic [ref=e19]:
          - strong [ref=e20]: 遅延または失敗する作品A
          - generic [ref=e21]: 作品一覧へ
        - generic [ref=e22]: ⌄
      - generic [ref=e23]: WORKSPACE
      - navigation [ref=e24]:
        - button "年表" [ref=e25] [cursor=pointer]
        - button "構成" [ref=e26] [cursor=pointer]
        - button "資料 0" [ref=e27] [cursor=pointer]:
          - text: 資料
          - generic [ref=e28]: "0"
        - button "検索" [ref=e29] [cursor=pointer]
      - generic [ref=e30]:
        - generic [ref=e31]: QUICK NOTE
        - button "アイデアを残す" [ref=e32] [cursor=pointer]
      - generic [ref=e34]:
        - button "作品・保存" [ref=e35] [cursor=pointer]
        - generic [ref=e38]:
          - strong [ref=e39]: この端末に保存
          - generic [ref=e40]: 同期接続先は未設定
        - button "暗い配色にする" [ref=e41] [cursor=pointer]
    - generic [ref=e42]:
      - banner [ref=e43]:
        - generic [ref=e44]:
          - generic "遅延または失敗する作品A" [ref=e45]
          - generic [ref=e46]: /
          - generic [ref=e47]: 年表
        - status [ref=e48]:
          - generic [ref=e50]: 端末内保存済み
          - generic [ref=e51]: LOCAL
      - main [ref=e52]:
        - generic [ref=e53]:
          - generic [ref=e54]:
            - generic [ref=e55]: STORY TIMELINE
            - heading "年表" [level=1] [ref=e56]
            - paragraph [ref=e57]: 物語の時間と、そこで起きたこと。
          - button "出来事を追加" [ref=e58] [cursor=pointer]
        - tablist "年表と関係" [ref=e59]:
          - tab "世界内年表" [selected] [ref=e60] [cursor=pointer]
          - tab "関係表・図" [ref=e61] [cursor=pointer]
          - tab "世界・地図・履歴" [ref=e62] [cursor=pointer]
        - group [ref=e63]:
          - generic "最近開いた情報・お気に入り" [ref=e64] [cursor=pointer]
        - generic [ref=e67]:
          - generic "年表の表示" [ref=e68]:
            - button "年表" [ref=e69] [cursor=pointer]
            - button "出来事一覧" [ref=e70] [cursor=pointer]
          - generic [ref=e71]:
            - generic [ref=e72]:
              - generic [ref=e74]:
                - text: 年表の暦
                - combobox "年表の暦" [ref=e75]:
                  - option "選択してください"
                  - option "先発グレゴリオ暦" [selected]
              - generic [ref=e76]:
                - text: 表示単位
                - combobox "年表の表示単位" [ref=e77]:
                  - option "tick" [selected]
                  - option "時"
                  - option "日"
                  - option "月"
                  - option "年"
                  - option "独自表示単位"
              - generic [ref=e78]:
                - button "年表を縮小" [ref=e79] [cursor=pointer]: −
                - generic [ref=e80]: 1倍
                - button "年表を拡大" [ref=e81] [cursor=pointer]: ＋
            - generic [ref=e82]:
              - button "全体へ戻る" [ref=e83] [cursor=pointer]
              - button "本編開始へ" [ref=e84] [cursor=pointer]
          - generic [ref=e85]:
            - generic [ref=e86]: 先発グレゴリオ暦
            - generic [ref=e88]: 本編開始 0 tick
            - generic [ref=e89]: 表示 -60 〜 60 tick
            - generic [ref=e90]: 中心の本編基準 0 tick
          - generic [ref=e91]:
            - button "グループ・人物レーン" [ref=e92] [cursor=pointer]
            - button "選択した出来事の日時・制約" [disabled] [ref=e93]
            - button "本編開始の基準を変更" [ref=e94] [cursor=pointer]
            - button "全出来事の日時を移動" [ref=e95] [cursor=pointer]
            - button "前回の日時変更を一括取消" [disabled] [ref=e96]
          - generic [ref=e97]:
            - heading "物語の時間を並べましょう" [level=3] [ref=e102]
            - paragraph [ref=e103]: 日時が未定でも、要約から出来事を残せます。
            - button "出来事を追加" [ref=e104] [cursor=pointer]
          - generic [ref=e105]:
            - button "前の期間" [ref=e106] [cursor=pointer]
            - generic [ref=e107]:
              - textbox "移動先の世界内tick" [ref=e108]:
                - /placeholder: tickへ移動
              - button "移動" [ref=e109] [cursor=pointer]
            - button "次の期間" [ref=e110] [cursor=pointer]
          - group [ref=e111]:
            - generic "暦の日付へ移動する" [ref=e112] [cursor=pointer]
          - generic [ref=e113]:
            - generic [ref=e114]:
              - heading "出来事間の関係" [level=3] [ref=e115]
              - generic [ref=e116]: "0"
            - generic [ref=e117]:
              - combobox "年表の関係を種類で絞り込む" [ref=e118]:
                - option "すべての出来事間の関係" [selected]
                - option "因果"
                - option "前提"
                - option "出来事の予告"
                - option "出来事の回収"
                - option "関連"
                - option "参照"
              - generic [ref=e119]:
                - checkbox "選択した出来事に関係する線" [ref=e120]
                - text: 選択した出来事に関係する線
              - button "始点 → 終点をタップで結ぶ" [ref=e121] [cursor=pointer]
              - button "一覧から関係を追加" [ref=e122] [cursor=pointer]
      - contentinfo [ref=e123]:
        - generic [ref=e124]: 端末内の作品 · 版 0
        - generic [ref=e125]: 0件の情報 · 0件の関係
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {createProject} from '../../src/domain/model';
  3  | import {exportScenario,inspectScenario} from '../../src/storage/archive';
  4  | import {seed} from './ap04-original-helpers';
  5  | import {exerciseF35Replacement} from './ap04-original-f35-replace-helper';
  6  | 
  7  | async function holdEditorHash(page:Page,afterImport=false){
  8  |  await page.evaluate(afterImport=>{
  9  |   const state={armed:!afterImport,entered:false,release:()=>{}};
  10 |   (window as unknown as {editorGate:typeof state}).editorGate=state;
  11 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  12 |   if(afterImport){const add=IDBObjectStore.prototype.add;IDBObjectStore.prototype.add=function(...args:Parameters<IDBObjectStore['add']>){const request=add.apply(this,args);if(this.name==='importLogs')request.addEventListener('success',()=>{state.armed=true;});return request;};}
  13 |   crypto.subtle.digest=async(...args)=>{if(state.armed&&!state.entered){state.entered=true;await held;}return digest(...args);};
  14 |  },afterImport);
  15 | }
  16 | const entered=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{entered:boolean}}).editorGate.entered);
  17 | const release=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{release:()=>void}}).editorGate.release());
  18 | 
  19 | test('reload during selected validation resumes the requested work without publishing an unvalidated editor',async({page})=>{
  20 |  const project=createProject('読み込み中の選択を再開');await seed(page,await exportScenario(project));await page.locator('.project-switch').click();
  21 |  await page.evaluate(()=>{localStorage.removeItem('scenario-last-project:guest');localStorage.removeItem('scenario-last-project');});
  22 |  await holdEditorHash(page);await page.locator('.project-card').filter({hasText:project.name}).click();await expect.poll(()=>entered(page)).toBe(true);
  23 |  await expect(page.locator('.app-shell')).toHaveCount(0);await page.reload();await expect(page.locator('.project-switch')).toContainText(project.name);
  24 | });
  25 | 
  26 | test('clone completion remains visible after its delayed selected editor is published',async({page})=>{
  27 |  const project=createProject('複製の完了を保持');const bytes=await exportScenario(project);await seed(page,bytes);
  28 |  await page.locator('.sidebar').getByRole('button',{name:/^作品・保存/}).click();await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
  29 |  await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles({name:'clone.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});await page.getByLabel('復元方法',{exact:true}).selectOption('clone');await page.getByLabel('復元方法と対象への影響を確認しました').check();
  30 |  await holdEditorHash(page,true);await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>entered(page)).toBe(true);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await release(page);
  31 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).not.toBe(project.projectId);
  32 |  await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。',{exact:true})).toBeVisible();
  33 | });
  34 | 
  35 | test('confirmed authenticated bootstrap permits the original replacement and rollback workflow',async({browser},info)=>{
  36 |  const bytes=new Uint8Array(await exportScenario(createProject('登録直後の復元対象')));
  37 |  await exerciseF35Replacement(browser,info,{bytes,...await inspectScenario(bytes,{worker:false})});
  38 | });
  39 | 
  40 | test('remembered startup exposes readiness only after selected validation settles',async({page})=>{
  41 |  const project=createProject('起動時の選択を検査');await seed(page,await exportScenario(project));
  42 |  await page.addInitScript(projectId=>{
  43 |   const state={entered:false,release:()=>{},headers:0};(window as unknown as {editorGate:typeof state}).editorGate=state;
  44 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  45 |   crypto.subtle.digest=async(...args)=>{let header=false;try{const value=JSON.parse(new TextDecoder().decode(args[1]));header=value.projectId===projectId&&Array.isArray(value.entityIds);}catch{}if(header&&++state.headers===2){state.entered=true;await held;}return digest(...args);};
  46 |  },project.projectId);
  47 |  await page.reload();await expect.poll(()=>entered(page)).toBe(true);await expect(page.locator('.library-page,.app-shell')).toHaveCount(0);await release(page);await expect(page.locator('.project-switch')).toContainText(project.name);
  48 | });
  49 | 
  50 | for(const boundary of ['cancel','newer selection','error'] as const)test(`pending selection ${boundary} preserves the last validated work and cannot restore older intent`,async({page})=>{
  51 |  const a=createProject('遅延または失敗する作品A');await seed(page,await exportScenario(a));await page.locator('.project-switch').click();await page.getByLabel('作品名',{exact:true}).fill('最後に検査した作品B');await page.getByRole('button',{name:'作品を作成',exact:true}).click();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');
  52 |  const b=await page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'));await page.locator('.project-switch').click();
  53 |  if(boundary==='error')await page.evaluate(async id=>{const db=await new Promise<IDBDatabase>(resolve=>{const request=indexedDB.open('scenario-manager-local-v1');request.onsuccess=()=>resolve(request.result);});await new Promise<void>((resolve,reject)=>{const tx=db.transaction('projects','readwrite'),table=tx.objectStore('projects'),request=table.get(id);request.onsuccess=()=>table.put({...request.result,schemaVersion:'999.0'});tx.oncomplete=()=>resolve();tx.onabort=()=>reject(tx.error);});db.close();},a.projectId);
  54 |  else await holdEditorHash(page);
  55 |  await page.locator('.project-card').filter({hasText:a.name}).click();
  56 |  if(boundary==='error')await expect(page.getByRole('alert')).toBeVisible();
> 57 |  else{await expect.poll(()=>entered(page)).toBe(true);if(boundary==='cancel')await page.getByRole('button',{name:'作品の読み込みを中止',exact:true}).click();else{await page.locator('.project-card').filter({hasText:'最後に検査した作品B'}).click();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');}await release(page);}
     |                                                                                                                                            ^ Error: locator.click: Test timeout of 30000ms exceeded.
  58 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-opening-project:guest'))).toBe('');expect(await page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).toBe(b);await page.reload();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');
  59 | });
  60 | 
```