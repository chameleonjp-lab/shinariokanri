# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library-loading-continuity.spec.ts >> confirmed logout erases only the matching account pending selection
- Location: tests/e2e/library-loading-continuity.spec.ts:63:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.library-page')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.library-page') with timeout 5000ms
  - waiting for locator('.library-page')

```

```yaml
- button "アカウント・専用同期"
- text: アカウント領域 00000000-0000-4000-8000-000000000002
- button "端末内の作品を開く"
- region "アカウントと専用接続先":
  - heading "専用接続先とアカウント" [level=2]
  - paragraph: 端末内の作品はログインせず使えます。アカウント領域への移動は完全保存の「新規／複製復元」で明示します。同名の作品を自動統合しません。
  - group:
    - text: 専用Supabase URL
    - textbox "専用Supabase URL": http://127.0.0.1:38741
    - text: 公開用APIキー
    - textbox "公開用APIキー": sb_publishable_logout_fixture
    - button "接続設定を保持" [disabled]
    - text: メール
    - textbox "メール": logout@example.invalid
    - text: パスワード
    - textbox "パスワード"
    - button "認証してアカウント領域を開く" [disabled]
    - button "認証中の領域を開く"
  - button "ログアウト前の保存待ち・入力を確認"
  - button "未保存入力をファイルに持出す"
  - text: 同じアカウントの入力を復元
  - button "同じアカウントの入力を復元"
  - alert: Failed to fetch
  - status: 認証したアカウントの領域を開きました。
- group "任意持出し診断": この作業の診断を確認・持出し
- button "自分の作品"
- button "接続先から取得"
- button "限定版の閲覧・指摘"
- status: 現在の権限を確認しています。端末キャッシュと入力は保持しています。
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {createProject} from '../../src/domain/model';
  3  | import {exportScenario,inspectScenario} from '../../src/storage/archive';
  4  | import {seed} from './ap04-original-helpers';
  5  | import {exerciseF35Replacement} from './ap04-original-f35-replace-helper';
  6  | import {createHttpContract} from './httpContract';
  7  | 
  8  | async function holdEditorHash(page:Page,afterImport=false,projectId?:string){
  9  |  await page.evaluate(({afterImport,projectId})=>{
  10 |   const state={armed:!afterImport,entered:false,release:()=>{}};
  11 |   (window as unknown as {editorGate:typeof state}).editorGate=state;
  12 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  13 |   if(afterImport){const add=IDBObjectStore.prototype.add;IDBObjectStore.prototype.add=function(...args:Parameters<IDBObjectStore['add']>){const request=add.apply(this,args);if(this.name==='importLogs')request.addEventListener('success',()=>{state.armed=true;});return request;};}
  14 |   crypto.subtle.digest=async(...args)=>{let matches=!projectId;try{const value=JSON.parse(new TextDecoder().decode(args[1]));if(projectId)matches=value.projectId===projectId&&Array.isArray(value.entityIds);}catch{}if(state.armed&&matches&&(projectId||!state.entered)){state.entered=true;await held;}return digest(...args);};
  15 |  },{afterImport,projectId});
  16 | }
  17 | const entered=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{entered:boolean}}).editorGate.entered);
  18 | const release=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{release:()=>void}}).editorGate.release());
  19 | 
  20 | test('reload during selected validation resumes the requested work without publishing an unvalidated editor',async({page})=>{
  21 |  const project=createProject('読み込み中の選択を再開');await seed(page,await exportScenario(project));await page.locator('.project-switch').click();
  22 |  await page.evaluate(()=>{localStorage.removeItem('scenario-last-project:guest');localStorage.removeItem('scenario-last-project');});
  23 |  await holdEditorHash(page);await page.locator('.project-card').filter({hasText:project.name}).click();await expect.poll(()=>entered(page)).toBe(true);
  24 |  await expect(page.locator('.app-shell')).toHaveCount(0);await page.reload();await expect(page.locator('.project-switch')).toContainText(project.name);
  25 | });
  26 | 
  27 | test('clone completion remains visible after its delayed selected editor is published',async({page})=>{
  28 |  const project=createProject('複製の完了を保持');const bytes=await exportScenario(project);await seed(page,bytes);
  29 |  await page.locator('.sidebar').getByRole('button',{name:/^作品・保存/}).click();await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
  30 |  await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles({name:'clone.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});await page.getByLabel('復元方法',{exact:true}).selectOption('clone');await page.getByLabel('復元方法と対象への影響を確認しました').check();
  31 |  await holdEditorHash(page,true);await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>entered(page)).toBe(true);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await release(page);
  32 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).not.toBe(project.projectId);
  33 |  await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。',{exact:true})).toBeVisible();
  34 | });
  35 | 
  36 | test('confirmed authenticated bootstrap permits the original replacement and rollback workflow',async({browser},info)=>{
  37 |  const bytes=new Uint8Array(await exportScenario(createProject('登録直後の復元対象')));
  38 |  await exerciseF35Replacement(browser,info,{bytes,...await inspectScenario(bytes,{worker:false})});
  39 | });
  40 | 
  41 | test('remembered startup exposes readiness only after selected validation settles',async({page})=>{
  42 |  const project=createProject('起動時の選択を検査');await seed(page,await exportScenario(project));
  43 |  await page.addInitScript(projectId=>{
  44 |   const state={entered:false,release:()=>{},headers:0};(window as unknown as {editorGate:typeof state}).editorGate=state;
  45 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  46 |   crypto.subtle.digest=async(...args)=>{let header=false;try{const value=JSON.parse(new TextDecoder().decode(args[1]));header=value.projectId===projectId&&Array.isArray(value.entityIds);}catch{}if(header&&++state.headers===2){state.entered=true;await held;}return digest(...args);};
  47 |  },project.projectId);
  48 |  await page.reload();await expect.poll(()=>entered(page)).toBe(true);await expect(page.locator('.library-page,.app-shell')).toHaveCount(0);await release(page);await expect(page.locator('.project-switch')).toContainText(project.name);
  49 | });
  50 | 
  51 | for(const boundary of ['cancel','newer selection','error'] as const)test(`pending selection ${boundary} preserves the last validated work and cannot restore older intent`,async({page})=>{
  52 |  const a=createProject('遅延または失敗する作品A');await seed(page,await exportScenario(a));await page.locator('.project-switch').click();await page.getByLabel('作品名',{exact:true}).fill('最後に検査した作品B');await page.getByRole('button',{name:'作品を作成',exact:true}).click();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');
  53 |  const b=await page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'));await page.locator('.project-switch').click();
  54 |  if(boundary==='error')await page.evaluate(async id=>{const db=await new Promise<IDBDatabase>(resolve=>{const request=indexedDB.open('scenario-manager-local-v1');request.onsuccess=()=>resolve(request.result);});await new Promise<void>((resolve,reject)=>{const tx=db.transaction('projects','readwrite'),table=tx.objectStore('projects'),request=table.get(id);request.onsuccess=()=>table.put({...request.result,schemaVersion:'999.0'});tx.oncomplete=()=>resolve();tx.onabort=()=>reject(tx.error);});db.close();},a.projectId);
  55 |  else await holdEditorHash(page,false,a.projectId);
  56 |  await page.locator('.project-card').filter({hasText:a.name}).click();
  57 |  if(boundary==='error')await expect(page.getByRole('alert')).toBeVisible();
  58 |  else{await expect.poll(()=>entered(page)).toBe(true);if(boundary==='cancel')await page.getByRole('button',{name:'作品の読み込みを中止',exact:true}).click();else{await page.locator('.project-card').filter({hasText:'最後に検査した作品B'}).click();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');}await release(page);}
  59 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-opening-project:guest'))).toBe('');expect(await page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).toBe(b);await page.reload();await expect(page.locator('.project-switch')).toContainText('最後に検査した作品B');
  60 | });
  61 | 
  62 | 
  63 | test('confirmed logout erases only the matching account pending selection',async({page})=>{
  64 |  const account='00000000-0000-4000-8000-000000000002',other='00000000-0000-4000-8000-000000000003';
  65 |  const contract=await createHttpContract(async route=>{
  66 |   const request=route.request(),url=new URL(request.url());
  67 |   if(url.pathname.includes('/auth/v1/token'))return route.fulfill({json:{access_token:'logout-fixture-memory-token',user:{id:account},expires_in:3600}});
  68 |   if(url.pathname.includes('/auth/v1/logout'))return route.fulfill({status:204});
  69 |   if((request.postDataJSON() as {action?:string}|null)?.action==='projects')return route.fulfill({json:[]});
  70 |   return route.fulfill({status:500,json:{code:'UNEXPECTED_CONTRACT_ACTION'}});
  71 |  });
  72 |  try{
> 73 |   await page.goto('');await page.getByRole('button',{name:'アカウント・専用同期',exact:true}).click();await page.getByLabel('専用Supabase URL',{exact:true}).fill(contract.url);await page.getByLabel('公開用APIキー',{exact:true}).fill('sb_publishable_logout_fixture');await page.getByRole('button',{name:'接続設定を保持',exact:true}).click();await page.getByLabel('メール',{exact:true}).fill('logout@example.invalid');await page.getByLabel('パスワード',{exact:true}).fill('fixture-only');await page.getByRole('button',{name:'認証してアカウント領域を開く',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'認証したアカウントの領域を開きました。'})).toBeVisible();await expect(page.locator('.library-page')).toBeVisible();
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ^ Error: expect(locator).toBeVisible() failed
  74 |   const keys=[`scenario-opening-project:${account}`,`scenario-last-project:${account}`,'scenario-opening-project:guest','scenario-last-project:guest',`scenario-opening-project:${other}`,`scenario-last-project:${other}`];
  75 |   await page.evaluate(keys=>keys.forEach((key,index)=>localStorage.setItem(key,`retained-selection-${index}`)),keys);
  76 |   await page.getByRole('button',{name:'ログアウト前の保存待ち・入力を確認',exact:true}).click();await page.getByLabel('キャッシュ消去対象のアカウントID',{exact:true}).fill(account);await page.getByRole('button',{name:'確認した残りを破棄してログアウト',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'このアカウントの認証と端末内作者キャッシュを消去しました。'})).toBeVisible();
  77 |   expect(await page.evaluate(keys=>keys.map(key=>localStorage.getItem(key)),keys)).toEqual([null,null,'retained-selection-2','retained-selection-3','retained-selection-4','retained-selection-5']);
  78 |  }finally{await contract.close();}
  79 | });
  80 | 
```