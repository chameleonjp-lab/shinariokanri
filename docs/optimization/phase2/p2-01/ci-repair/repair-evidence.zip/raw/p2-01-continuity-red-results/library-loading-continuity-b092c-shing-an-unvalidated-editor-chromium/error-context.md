# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library-loading-continuity.spec.ts >> reload during selected validation resumes the requested work without publishing an unvalidated editor
- Location: tests/e2e/library-loading-continuity.spec.ts:19:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.project-switch')
Expected substring: "読み込み中の選択を再開"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('.project-switch') with timeout 5000ms
  - waiting for locator('.project-switch')

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- banner:
  - link "本文へ移動":
    - /url: "#main-content"
  - text: S シナリオ管理
  - button "配色を切り替え"
- main:
  - text: YOUR STORY, CONNECTED.
  - heading "物語をつなぐ。 次の一行へ。" [level=1]
  - paragraph: 人物、出来事、本文、分岐。 作品のすべてを、ひとつのノートに。
  - heading "新しい作品をはじめる" [level=2]
  - paragraph: まずはタイトルだけ。詳細はあとから。
  - text: 作品名
  - textbox "作品名":
    - /placeholder: あなたの物語のタイトル
  - button "作品を作成" [disabled]
  - button "サンプルで試す"
  - button "保存ファイルを読み込む"
  - heading "あなたの作品" [level=2]
  - text: "1"
  - button "読み込み中の選択を再開 0件の情報 · 端末内保存":
    - strong: 読み込み中の選択を再開
    - text: 0件の情報 · 端末内保存
  - text: 作品はこのブラウザーに保存されます 端末内の作品 · 同期はアカウント欄から設定できます
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {createProject} from '../../src/domain/model';
  3  | import {exportScenario,inspectScenario} from '../../src/storage/archive';
  4  | import {seed} from './ap04-original-helpers';
  5  | import {exerciseF35Replacement} from './ap04-original-f35-replace-helper';
  6  | 
  7  | async function holdEditorHash(page:Page,afterImport=false){
  8  |  await page.evaluate(afterImport=>{
  9  |   const state={armed:!afterImport,entered:false,release:()=>{}};
  10 |   (window as unknown as {editorGate:typeof state}).editorGate=state;
  11 |   const held=new Promise<void>(resolve=>state.release=resolve),digest=crypto.subtle.digest.bind(crypto.subtle);
  12 |   if(afterImport){const transaction=IDBDatabase.prototype.transaction;IDBDatabase.prototype.transaction=function(...args:Parameters<IDBDatabase['transaction']>){const tx=transaction.apply(this,args);if(args[1]==='readwrite'&&tx.objectStoreNames.contains('importLogs'))tx.addEventListener('complete',()=>{state.armed=true;});return tx;};}
  13 |   crypto.subtle.digest=async(...args)=>{if(state.armed&&!state.entered){state.entered=true;await held;}return digest(...args);};
  14 |  },afterImport);
  15 | }
  16 | const entered=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{entered:boolean}}).editorGate.entered);
  17 | const release=(page:Page)=>page.evaluate(()=>(window as unknown as {editorGate:{release:()=>void}}).editorGate.release());
  18 | 
  19 | test('reload during selected validation resumes the requested work without publishing an unvalidated editor',async({page})=>{
  20 |  const project=createProject('読み込み中の選択を再開');await seed(page,await exportScenario(project));await page.locator('.project-switch').click();
  21 |  await page.evaluate(()=>{localStorage.removeItem('scenario-last-project:guest');localStorage.removeItem('scenario-last-project');});
  22 |  await holdEditorHash(page);await page.locator('.project-card').filter({hasText:project.name}).click();await expect.poll(()=>entered(page)).toBe(true);
> 23 |  await expect(page.locator('.app-shell')).toHaveCount(0);await page.reload();await expect(page.locator('.project-switch')).toContainText(project.name);
     |                                                                                                                            ^ Error: expect(locator).toContainText(expected) failed
  24 | });
  25 | 
  26 | test('clone completion remains visible after its delayed selected editor is published',async({page})=>{
  27 |  const project=createProject('複製の完了を保持');const bytes=await exportScenario(project);await seed(page,bytes);
  28 |  await page.locator('.sidebar').getByRole('button',{name:/^作品・保存/}).click();await page.getByRole('tab',{name:'完全保存・復元',exact:true}).click();
  29 |  await page.getByLabel('保存ファイルを選ぶ',{exact:true}).setInputFiles({name:'clone.scenario',mimeType:'application/zip',buffer:Buffer.from(bytes)});await page.getByLabel('復元方法',{exact:true}).selectOption('clone');await page.getByLabel('復元方法と対象への影響を確認しました').check();
  30 |  await holdEditorHash(page,true);await page.getByRole('button',{name:'この内容で復元する',exact:true}).click();await expect.poll(()=>entered(page)).toBe(true);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await release(page);
  31 |  await expect.poll(()=>page.evaluate(()=>localStorage.getItem('scenario-last-project:guest'))).not.toBe(project.projectId);
  32 |  await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。',{exact:true})).toBeVisible();
  33 | });
  34 | 
  35 | test('confirmed authenticated bootstrap permits the original replacement and rollback workflow',async({browser},info)=>{
  36 |  const bytes=await exportScenario(createProject('登録直後の復元対象'));
  37 |  await exerciseF35Replacement(browser,info,{bytes,...await inspectScenario(bytes,{worker:false})});
  38 | });
  39 | 
```