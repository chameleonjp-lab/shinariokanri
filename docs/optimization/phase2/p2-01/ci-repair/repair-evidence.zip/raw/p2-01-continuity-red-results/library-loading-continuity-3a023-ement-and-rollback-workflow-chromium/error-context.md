# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library-loading-continuity.spec.ts >> confirmed authenticated bootstrap permits the original replacement and rollback workflow
- Location: tests/e2e/library-loading-continuity.spec.ts:35:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - button "アカウント・専用同期" [ref=e6] [cursor=pointer]
      - generic [ref=e7]: アカウント領域 a3500000-0000-4000-8000-000000000001
      - button "端末内の作品を開く" [ref=e8] [cursor=pointer]
    - region "アカウントと専用接続先" [ref=e9]:
      - heading "専用接続先とアカウント" [level=2] [ref=e10]
      - paragraph [ref=e11]: 端末内の作品はログインせず使えます。アカウント領域への移動は完全保存の「新規／複製復元」で明示します。同名の作品を自動統合しません。
      - group [ref=e12]:
        - generic [ref=e13]:
          - text: 専用Supabase URL
          - textbox "専用Supabase URL" [ref=e14]: http://127.0.0.1:42119
        - generic [ref=e15]:
          - text: 公開用APIキー
          - textbox "公開用APIキー" [ref=e16]: sb_publishable_f35_fixture
        - button "接続設定を保持" [disabled] [ref=e17]
        - generic [ref=e18]:
          - text: メール
          - textbox "メール" [ref=e19]: f35@example.invalid
        - generic [ref=e20]:
          - text: パスワード
          - textbox "パスワード" [ref=e21]
        - button "認証してアカウント領域を開く" [disabled] [ref=e22]
        - button "認証中の領域を開く" [ref=e23] [cursor=pointer]
      - button "ログアウト前の保存待ち・入力を確認" [ref=e24] [cursor=pointer]
      - button "未保存入力をファイルに持出す" [ref=e25] [cursor=pointer]
      - generic [ref=e26]:
        - text: 同じアカウントの入力を復元
        - button "同じアカウントの入力を復元" [ref=e27]
      - status [ref=e28]: 認証したアカウントの領域を開きました。
    - group "任意持出し診断" [ref=e29]:
      - generic "この作業の診断を確認・持出し" [ref=e30]
    - generic [ref=e31]:
      - button "自分の作品" [ref=e32] [cursor=pointer]
      - button "接続先から取得" [ref=e33] [cursor=pointer]
      - button "限定版の閲覧・指摘" [ref=e34] [cursor=pointer]
  - generic [ref=e36]:
    - link "本文へ移動" [ref=e37] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "主要ナビゲーション" [ref=e38]:
      - generic [ref=e39]:
        - generic [ref=e40]: S
        - generic [ref=e41]: シナリオ管理
      - button "登録直後の復元対象 作品一覧へ ⌄" [ref=e42] [cursor=pointer]:
        - generic [ref=e44]:
          - strong [ref=e45]: 登録直後の復元対象
          - generic [ref=e46]: 作品一覧へ
        - generic [ref=e47]: ⌄
      - generic [ref=e48]: WORKSPACE
      - navigation [ref=e49]:
        - button "年表" [ref=e50] [cursor=pointer]
        - button "構成" [ref=e51] [cursor=pointer]
        - button "資料 0" [ref=e52] [cursor=pointer]:
          - text: 資料
          - generic [ref=e53]: "0"
        - button "検索" [ref=e54] [cursor=pointer]
      - generic [ref=e55]:
        - generic [ref=e56]: QUICK NOTE
        - button "アイデアを残す" [ref=e57] [cursor=pointer]
      - generic [ref=e59]:
        - button "作品・保存" [ref=e60] [cursor=pointer]
        - generic [ref=e63]:
          - strong [ref=e64]: この端末に保存
          - generic [ref=e65]: 同期接続先は未設定
        - button "暗い配色にする" [ref=e66] [cursor=pointer]
    - generic [ref=e67]:
      - banner [ref=e68]:
        - generic [ref=e69]:
          - generic "登録直後の復元対象" [ref=e70]
          - generic [ref=e71]: /
          - generic [ref=e72]: 作品
        - status [ref=e73]:
          - generic [ref=e75]: 端末内保存済み
          - generic [ref=e76]: LOCAL
      - main [ref=e77]:
        - generic [ref=e79]:
          - generic [ref=e80]: YOUR PROJECT
          - heading "作品" [level=1] [ref=e81]
          - paragraph [ref=e82]: 作品を保存し、いつでも続きを書けるように。
        - tablist "作品の管理" [ref=e83]:
          - tab "完全保存・復元" [selected] [ref=e84] [cursor=pointer]
          - tab "目的別出力" [ref=e85] [cursor=pointer]
          - tab "変更履歴" [ref=e86] [cursor=pointer]
          - tab "作品の設定" [ref=e87] [cursor=pointer]
          - tab "同期・限定共有" [ref=e88] [cursor=pointer]
        - group [ref=e89]:
          - generic "最近開いた情報・お気に入り" [ref=e90] [cursor=pointer]
        - generic [ref=e93]:
          - generic [ref=e97]:
            - heading "作品を完全保存" [level=3] [ref=e98]
            - paragraph [ref=e99]: 本文・状態・固定世界・履歴・送信待ち・添付を .scenario ファイルに保存します。
            - button "完全保存ファイルを作成" [ref=e100] [cursor=pointer]
            - button "素材bytesを除いて保存" [ref=e101] [cursor=pointer]
          - generic [ref=e105]:
            - heading "ファイルから復元" [level=3] [ref=e106]
            - paragraph [ref=e107]: 元ファイルと対応の入力を端末内に保持し、影響を確認してから復元します。
            - generic [ref=e108] [cursor=pointer]:
              - text: 保存ファイルを選ぶ
              - button "保存ファイルを選ぶ" [ref=e109]
          - generic [ref=e110]:
            - heading "検査済みの作品 · 登録直後の復元対象" [level=3] [ref=e111]
            - paragraph [ref=e112]: 0件の情報 · 0件の履歴 · 0 bytesの素材
            - generic [ref=e113]:
              - text: 復元方法
              - combobox "復元方法" [ref=e114]:
                - option "保存IDを維持して新規復元"
                - option "新しいIDへ複製して追加"
                - option "同じ作品を置換" [selected]
                - option "同じ作品へ統合"
                - option "別作品へ明示ID対応で統合"
            - generic [ref=e116]:
              - text: 復元する対象作品
              - combobox "復元する対象作品" [ref=e117]:
                - option "選択してください"
                - option "登録直後の復元対象 · 版 0" [selected]
            - alert [ref=e118]: この作品を編集する権限がありません。
            - button "復元の影響を確認" [ref=e119] [cursor=pointer]
            - alert [ref=e120]: 確認後に対象作品が更新されました。入力を保持して影響を再確認してください。
            - paragraph [ref=e121]: 確認した対象版 0 · 追加 0件 · 差分 0件
            - generic [ref=e122] [cursor=pointer]:
              - checkbox "復元方法と対象への影響を確認しました" [disabled] [ref=e123]
              - text: 復元方法と対象への影響を確認しました
            - generic [ref=e124]:
              - button "中止" [ref=e125] [cursor=pointer]
              - button "この内容で復元する" [disabled] [ref=e126]
      - contentinfo [ref=e127]:
        - generic [ref=e128]: 端末内の作品 · 版 0
        - generic [ref=e129]: 0件の情報 · 0件の関係
```