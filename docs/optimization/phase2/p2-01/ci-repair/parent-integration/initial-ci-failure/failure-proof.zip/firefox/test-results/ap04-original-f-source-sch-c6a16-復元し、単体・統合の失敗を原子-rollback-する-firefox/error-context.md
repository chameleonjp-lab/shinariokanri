# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ap04-original-f-source-schema.spec.ts >> AT-F35 条件・線・実素材・巨大 tick・通常保存履歴を完全 new/clone 復元し、単体・統合の失敗を原子 rollback する
- Location: tests/e2e/ap04-original-f-source-schema.spec.ts:330:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('検査した作品を端末内に復元しました。保存した版を確認しました。')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('検査した作品を端末内に復元しました。保存した版を確認しました。') with timeout 5000ms
  - waiting for getByText('検査した作品を端末内に復元しました。保存した版を確認しました。')

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- link "本文へ移動":
  - /url: "#main-content"
- complementary "主要ナビゲーション":
  - text: S シナリオ管理
  - button "AT-F35 全対応を保持する完全保存 作品一覧へ ⌄":
    - strong: AT-F35 全対応を保持する完全保存
    - text: 作品一覧へ ⌄
  - text: WORKSPACE
  - navigation:
    - button "年表"
    - button "構成"
    - button "資料 2"
    - button "検索"
  - text: QUICK NOTE
  - button "アイデアを残す"
  - button "作品・保存"
  - strong: この端末に保存
  - text: 同期接続先は未設定
  - button "暗い配色にする"
- banner:
  - text: AT-F35 全対応を保持する完全保存 / 年表
  - status: 端末内保存済み LOCAL
- main:
  - text: STORY TIMELINE
  - heading "年表" [level=1]
  - paragraph: 物語の時間と、そこで起きたこと。
  - button "出来事を追加"
  - tablist "年表と関係":
    - tab "世界内年表" [selected]
    - tab "関係表・図"
    - tab "世界・地図・履歴"
  - group: 最近開いた情報・お気に入り
  - button "年表"
  - button "出来事一覧"
  - text: 年表の暦
  - combobox "年表の暦":
    - option "選択してください"
    - option "先発グレゴリオ暦" [selected]
  - text: 表示単位
  - combobox "年表の表示単位":
    - option "tick" [selected]
    - option "時"
    - option "日"
    - option "月"
    - option "年"
    - option "独自表示単位"
  - button "年表を縮小": −
  - text: 1倍
  - button "年表を拡大": ＋
  - button "全体へ戻る"
  - button "本編開始へ"
  - text: 先発グレゴリオ暦 本編開始 0 tick 表示 -60 〜 60 tick 中心の本編基準 0 tick
  - button "グループ・人物レーン"
  - button "選択した出来事の日時・制約" [disabled]
  - button "本編開始の基準を変更"
  - button "全出来事の日時を移動"
  - button "前回の日時変更を一括取消" [disabled]
  - text: 人物・グループ -60 -40 -20 0 20 40 60 共通 共通の出来事 0件
  - button "巨大日時を知る人物A"
  - text: 0件
  - button "矢印の人物B"
  - text: 0件
  - img "出来事間の意味付き矢印"
  - text: 瞬間 期間 不確定な範囲 相対日時は基準から解決して表示 0 / 1件 · レーン上の表示 0件
  - button "前の期間"
  - textbox "移動先の世界内tick":
    - /placeholder: tickへ移動
  - button "移動"
  - button "次の期間"
  - group: 暦の日付へ移動する
  - heading "出来事間の関係" [level=3]
  - text: "0"
  - combobox "年表の関係を種類で絞り込む":
    - option "すべての出来事間の関係" [selected]
    - option "因果"
    - option "前提"
    - option "出来事の予告"
    - option "出来事の回収"
    - option "関連"
    - option "参照"
  - checkbox "選択した出来事に関係する線"
  - text: 選択した出来事に関係する線
  - button "始点 → 終点をタップで結ぶ"
  - button "一覧から関係を追加"
- contentinfo: 端末内の作品 · 版 3 15件の情報 · 1件の関係
```

# Test source

```ts
  325 |     relations: p.relations.map(relation => ({ id: relation.id, fromId: relation.fromId, toId: relation.toId, direction: relation.direction, relationType: relation.relationType, validity: relation.validity, evidenceIds: relation.evidenceIds })),
  326 |     calendars: p.calendars, mainStart: p.mainStart,
  327 |   };
  328 | }
  329 | 
  330 | test('AT-F35 条件・線・実素材・巨大 tick・通常保存履歴を完全 new/clone 復元し、単体・統合の失敗を原子 rollback する', async ({ page, browser, baseURL }, info) => {
  331 |   const p = createProject('AT-F35 全対応を保持する完全保存');
  332 |   const a = createEntity(p.projectId, 'character', '巨大日時を知る人物A');
  333 |   const b = createEntity(p.projectId, 'character', '矢印の人物B');
  334 |   const hugeTick = '12345678901234567890123456789012345678';
  335 |   const event = createEntity(p.projectId, 'event', '数値丸めを許さない出来事', { time: { mode: 'instant', at: hugeTick, calendarId: p.calendarId }, participants: [{ characterId: a.id, role: 'witness' }, { characterId: b.id, role: 'actor' }] });
  336 |   const scene = createEntity(p.projectId, 'scene', '単体履歴を持つ場面', { body: textToRichText('初期の本文😀'), eventIds: [event.id] });
  337 |   const chapter = createEntity(p.projectId, 'chapter', '番号と段落を保持する章', { sceneIds: [scene.id] });
  338 |   scene.data.chapterId = chapter.id;
  339 |   const variable = createEntity(p.projectId, 'variable', '保存する条件の状態', { key: 'portable-key', scope: 'run', initial: { type: 'boolean', value: true } });
  340 |   const entry = createEntity(p.projectId, 'flow_node', '復元する入口', { nodeType: 'entry', sceneId: scene.id });
  341 |   const end = createEntity(p.projectId, 'flow_node', '復元する終端', { nodeType: 'terminal', terminalReason: '条件とIDを保持して終了' });
  342 |   const edge = createEntity(p.projectId, 'flow_edge', '条件と矢印を復元する接続', { fromId: entry.id, toId: end.id, label: '条件を満たして次へ', condition: { op: 'compare', variableId: variable.id, comparator: 'eq', value: { type: 'boolean', value: true } } });
  343 |   const graph = createEntity(p.projectId, 'flow_graph', '完全復元する分岐', { nodeIds: [entry.id, end.id], edgeIds: [edge.id], entryIds: [entry.id], exitIds: [end.id] });
  344 |   const prepared = await prepareAsset(new Uint8Array(await readFile('tests/fixtures/media/fixture-tone.wav')), '対応を保持する実音声.wav');
  345 |   const { bytes: assetBytes, preview: _assetPreview, ...metadata } = prepared;
  346 |   const asset = createEntity(p.projectId, 'attachment', '完全復元する実音声', metadata);
  347 |   p.entities.push(a, b, event, scene, chapter, variable, entry, end, edge, graph, asset);
  348 |   p.entities.forEach(entity => { entity.status = 'confirmed'; });
  349 |   p.relations.push({ id: newId(), projectId: p.projectId, revision: '0', fromId: a.id, toId: b.id, relationType: 'trust', direction: 'forward', validity: emptyValidity(), evidenceIds: [event.id], status: 'confirmed', visibility: 'private' });
  350 |   await seed(page, await exportScenario(p, { loadAsset: hash => hash === prepared.contentHash ? assetBytes : undefined }));
  351 | 
  352 |   // Construct the original given's unit history through genuine ordinary saves.
  353 |   // The given attached below is the downloaded native image after those saves.
  354 |   await openEntity(page, 'scene', scene.name);
  355 |   await page.getByRole('tab', { name: '本文', exact: true }).click();
  356 |   const body = page.locator('.detail-panel').getByRole('textbox', { name: '本文', exact: true });
  357 |   const historicalBody = '初期の本文😀 単体復元する版1';
  358 |   const currentBody = '初期の本文😀 全体復元する最新版2';
  359 |   const initialBlockId = scene.data.body[0].id;
  360 |   expect(initialBlockId).toMatch(ID_PATTERN);
  361 |   await body.fill(historicalBody); await saveEditor(page);
  362 |   const firstSaved = await backup(page);
  363 |   const historicalScene = record(firstSaved.project, scene.id, 'scene');
  364 |   expect(historicalScene.id).toBe(scene.id);
  365 |   expect(historicalScene.data.body).toHaveLength(1);
  366 |   const historicalBlockId = historicalScene.data.body[0].id;
  367 |   expect(historicalBlockId).toMatch(ID_PATTERN);
  368 |   expect(historicalBlockId).not.toBe(initialBlockId);
  369 |   expect(historicalScene.data).toEqual({ ...scene.data, body: [{ ...scene.data.body[0], id: historicalBlockId, text: historicalBody }] });
  370 |   const unitOperation = firstSaved.project.history.find(command => command.after.entities.some(entity => entity.id === scene.id && entity.kind === 'scene' && entity.data.body[0]?.text === historicalBody));
  371 |   if (!unitOperation) throw new Error('通常保存から版1の単体履歴を取得できません');
  372 |   expect(record(unitOperation.before, scene.id, 'scene').data).toEqual(scene.data);
  373 |   expect(record(unitOperation.after, scene.id, 'scene').data).toEqual(historicalScene.data);
  374 |   await openEntity(page, 'scene', scene.name);
  375 |   await page.getByRole('tab', { name: '本文', exact: true }).click();
  376 |   await body.fill(currentBody); await saveEditor(page);
  377 |   const given = await backup(page);
  378 |   const currentScene = record(given.project, scene.id, 'scene');
  379 |   expect(currentScene.id).toBe(scene.id);
  380 |   expect(currentScene.data.body).toHaveLength(1);
  381 |   const currentBlockId = currentScene.data.body[0].id;
  382 |   expect(currentBlockId).toMatch(ID_PATTERN);
  383 |   expect(new Set([initialBlockId, historicalBlockId, currentBlockId]).size).toBe(3);
  384 |   expect(currentScene.data).toEqual({ ...scene.data, body: [{ ...scene.data.body[0], id: currentBlockId, text: currentBody }] });
  385 |   const currentOperation = given.project.history.find(command => command.after.entities.some(entity => entity.id === scene.id && entity.kind === 'scene' && entity.data.body[0]?.id === currentBlockId));
  386 |   if (!currentOperation) throw new Error('通常保存から最新版2の段落対応を取得できません');
  387 |   expect(record(currentOperation.before, scene.id, 'scene').data).toEqual(historicalScene.data);
  388 |   expect(record(currentOperation.after, scene.id, 'scene').data).toEqual(currentScene.data);
  389 |   expect(given.project.history.slice(0, firstSaved.project.history.length)).toEqual(firstSaved.project.history);
  390 |   await attachGiven(info, 'AT-F35', given.bytes, { projectId: p.projectId, unitOperationId: unitOperation.operationId, currentOperationId: currentOperation.operationId, sceneId: scene.id, initialBlockId, historicalBlockId, bodyBlockId: currentBlockId, hugeTick, condition: edge.data.condition, relation: p.relations[0], assetId: asset.id, assetHash: prepared.contentHash, assetBytes: assetBytes.length, givenConstructedBy: 'normal UI saves followed by actual full download' });
  391 |   expect(given.assets).toHaveLength(1);
  392 |   expect(given.assets[0].bytes).toEqual(assetBytes);
  393 | 
  394 |   // Full restore in an independent origin/context with no native project rows.
  395 |   const cleanContext = await browser.newContext({ baseURL });
  396 |   try {
  397 |     const restoredPage = await cleanContext.newPage();
  398 |     await restoredPage.goto('./');
  399 |     await expect(restoredPage.locator('.library-projects')).toContainText('はじめての作品');
  400 |     await seed(restoredPage, given.bytes);
  401 |     await restoredPage.reload();
  402 |     const restored = await backup(restoredPage);
  403 |     expect(restored.project).toEqual(given.project);
  404 |     expect(portableMeaning(restored.project)).toEqual(portableMeaning(given.project));
  405 |     expect(restored.assets[0].contentHash).toBe(prepared.contentHash);
  406 |     expect(restored.assets[0].bytes).toEqual(assetBytes);
  407 |     await openEntity(restoredPage, 'event', event.name);
  408 |     await expect(restoredPage.getByLabel('世界内tick', { exact: true })).toHaveValue(hugeTick);
  409 |     await restoredPage.getByRole('button', { name: '詳細を閉じる', exact: true }).click();
  410 | 
  411 |     // Selecting replacement shows its real pending-operation constraint. It
  412 |     // cannot silently destroy pending author work merely to make this test pass.
  413 |     await selectRestoreFile(restoredPage, given.bytes, 'replace', p.projectId);
  414 |     const beforeReplace = await authorFingerprint(restoredPage);
  415 |     await expect(restoredPage.locator('.import-preview').getByRole('alert')).toContainText('未送信の変更');
  416 |     await expect(restoredPage.getByLabel('復元方法と対象への影響を確認しました')).toBeDisabled();
  417 |     expect(await authorFingerprint(restoredPage)).toBe(beforeReplace);
  418 |     await restoredPage.locator('.import-preview').getByRole('button', { name: '中止', exact: true }).click();
  419 | 
  420 |     // Addition applies a new ID map to every reference and paragraph, while
  421 |     // asset identity remains the SHA-256 of the real unchanged bytes.
  422 |     await selectRestoreFile(restoredPage, given.bytes, 'clone');
  423 |     await restoredPage.getByLabel('復元方法と対象への影響を確認しました').check();
  424 |     await restoredPage.getByRole('button', { name: 'この内容で復元する', exact: true }).click();
> 425 |     await expect(restoredPage.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。')).toBeVisible();
      |                                                                             ^ Error: expect(locator).toBeVisible() failed
  426 |     await restoredPage.reload();
  427 |     const clone = await backup(restoredPage);
  428 |     const cloneCommand = [...clone.project.history].reverse().find(command => command.reason === '専用ファイルをcloneで復元');
  429 |     if (!cloneCommand?.idMap) throw new Error('複製時の全ID対応がありません');
  430 |     const idMap = cloneCommand.idMap;
  431 |     expect(clone.project.projectId).toBe(idMap[p.projectId]);
  432 |     expect(clone.project.projectId).not.toBe(p.projectId);
  433 |     for (const original of given.project.entities) expect(idMap[original.id]).not.toBe(original.id);
  434 |     const clonedScene = record(clone.project, idMap[scene.id], 'scene');
  435 |     for (const blockId of [initialBlockId, historicalBlockId, currentBlockId]) {
  436 |       expect(idMap[blockId]).toMatch(ID_PATTERN);
  437 |       expect(idMap[blockId]).not.toBe(blockId);
  438 |     }
  439 |     expect(new Set([initialBlockId, historicalBlockId, currentBlockId].map(id => idMap[id])).size).toBe(3);
  440 |     expect(clonedScene.data.body).toEqual([{ ...currentScene.data.body[0], id: idMap[currentBlockId] }]);
  441 |     const clonedUnitOperation = clone.project.history.find(command => command.operationId === idMap[unitOperation.operationId]);
  442 |     const clonedCurrentOperation = clone.project.history.find(command => command.operationId === idMap[currentOperation.operationId]);
  443 |     if (!clonedUnitOperation || !clonedCurrentOperation) throw new Error('複製後の初期・単体履歴・最新版の対応がありません');
  444 |     expect(record(clonedUnitOperation.before, clonedScene.id, 'scene').data.body).toEqual([{ ...scene.data.body[0], id: idMap[initialBlockId] }]);
  445 |     expect(record(clonedUnitOperation.after, clonedScene.id, 'scene').data.body).toEqual([{ ...historicalScene.data.body[0], id: idMap[historicalBlockId] }]);
  446 |     expect(record(clonedCurrentOperation.before, clonedScene.id, 'scene').data.body).toEqual([{ ...historicalScene.data.body[0], id: idMap[historicalBlockId] }]);
  447 |     expect(record(clonedCurrentOperation.after, clonedScene.id, 'scene').data.body).toEqual(clonedScene.data.body);
  448 |     expect(clonedScene.data.chapterId).toBe(idMap[chapter.id]);
  449 |     expect(clonedScene.data.eventIds).toEqual([idMap[event.id]]);
  450 |     expect(record(clone.project, idMap[chapter.id], 'chapter').data.sceneIds).toEqual([clonedScene.id]);
  451 |     expect(record(clone.project, idMap[event.id], 'event').data.time).toEqual(event.data.time);
  452 |     expect(record(clone.project, idMap[event.id], 'event').data.participants).toEqual([{ characterId: idMap[a.id], role: 'witness' }, { characterId: idMap[b.id], role: 'actor' }]);
  453 |     expect(record(clone.project, idMap[edge.id], 'flow_edge').data).toMatchObject({ fromId: idMap[entry.id], toId: idMap[end.id], condition: { ...edge.data.condition, variableId: idMap[variable.id] } });
  454 |     expect(clone.project.relations[0]).toMatchObject({ id: idMap[p.relations[0].id], fromId: idMap[a.id], toId: idMap[b.id], direction: 'forward', evidenceIds: [idMap[event.id]] });
  455 |     expect(clone.project.history.some(command => command.operationId === idMap[unitOperation.operationId])).toBe(true);
  456 |     expect(clone.assets[0].contentHash).toBe(prepared.contentHash);
  457 |     expect(clone.assets[0].bytes).toEqual(assetBytes);
  458 |     await attachObservation(info, 'AT-F35-new-clone-observed', { sourceProjectId: p.projectId, restoredProjectId: restored.project.projectId, cloneProjectId: clone.project.projectId, idMap, hugeTick, assetHash: prepared.contentHash, successfulReplacement: 'not_run: pending operations require real synchronization first' });
  459 |   } finally { await cleanContext.close(); }
  460 | 
  461 |   // Unit restoration presents current referrers, then rolls back every author
  462 |   // store on a declared native quota failure while retaining the review input.
  463 |   await work(page, '変更履歴');
  464 |   const history = page.locator('.history-page');
  465 |   await history.getByLabel('履歴を検索', { exact: true }).fill(unitOperation.operationId);
  466 |   await history.locator('.history-list').getByRole('button', { name: new RegExp(unitOperation.operationId) }).click();
  467 |   await history.getByLabel('単体復元する対象', { exact: true }).selectOption(scene.id);
  468 |   await history.getByRole('button', { name: 'この情報だけの復元を確認', exact: true }).click();
  469 |   const unitPreview = history.getByRole('region', { name: '確認した復元差分', exact: true });
  470 |   await expect(unitPreview).toContainText('件の参照があります');
  471 |   await expect(unitPreview).toContainText(historicalBody);
  472 |   const beforeUnit = await durableRecoveryImage(page);
  473 |   await injectOneAtomicQuotaFailure(page);
  474 |   await unitPreview.getByRole('button', { name: 'この内容へ復元する', exact: true }).click();
  475 |   await expect(history.getByRole('alert')).toContainText('容量');
  476 |   expect(await durableRecoveryImage(page)).toBe(beforeUnit);
  477 |   await expect(unitPreview).toContainText(historicalBody);
  478 |   await unitPreview.getByRole('button', { name: 'この内容へ復元する', exact: true }).click();
  479 |   await expect(history.getByRole('status').filter({ hasText: '保存した版を確認' })).toBeVisible();
  480 |   const unitSaved = await backup(page);
  481 |   expect(record(unitSaved.project, scene.id, 'scene').data).toEqual(historicalScene.data);
  482 |   for (const original of given.project.entities.filter(entity => entity.id !== scene.id)) expect(record(unitSaved.project, original.id, original.kind).data).toEqual(original.data);
  483 |   expect(unitSaved.project.relations).toEqual(given.project.relations);
  484 |   expect(unitSaved.assets[0].bytes).toEqual(assetBytes);
  485 |   expect(unitSaved.project.history.slice(0, given.project.history.length)).toEqual(given.project.history);
  486 | 
  487 |   // Same-project merge keeps IDs and requires the real differing scene choice.
  488 |   await selectRestoreFile(page, given.bytes, 'merge', p.projectId);
  489 |   const conflicts = page.locator('.import-preview details').filter({ has: page.getByLabel(`${scene.id}の統合方法`, { exact: true }) });
  490 |   await conflicts.locator('summary').click();
  491 |   await expect(conflicts).toContainText(historicalBody);
  492 |   await expect(conflicts).toContainText(currentBody);
  493 |   await conflicts.getByLabel(`${scene.id}の統合方法`, { exact: true }).selectOption('incoming');
  494 |   await page.getByRole('button', { name: '復元の影響を確認', exact: true }).click();
  495 |   await page.getByLabel('復元方法と対象への影響を確認しました').check();
  496 |   const beforeMerge = await durableRecoveryImage(page);
  497 |   await injectOneAtomicQuotaFailure(page);
  498 |   await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click();
  499 |   await expect(page.locator('.backup-page').getByRole('alert')).toContainText('容量');
  500 |   expect(await durableRecoveryImage(page)).toBe(beforeMerge);
  501 |   await expect(page.getByLabel('復元方法', { exact: true })).toHaveValue('merge');
  502 |   await expect(page.getByLabel('復元方法と対象への影響を確認しました')).toBeChecked();
  503 |   await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click();
  504 |   await expect(page.getByText('検査した作品を端末内に復元しました。保存した版を確認しました。')).toBeVisible();
  505 |   await page.reload();
  506 |   const merged = await backup(page);
  507 |   expect(merged.project.projectId).toBe(given.project.projectId);
  508 |   expect(portableMeaning(merged.project)).toEqual(portableMeaning(given.project));
  509 |   expect(merged.project.history.slice(0, unitSaved.project.history.length)).toEqual(unitSaved.project.history);
  510 |   expect([...merged.project.history].reverse().find(command => command.reason === '専用ファイルをmergeで復元')?.targetIds).toContain(scene.id);
  511 |   expect(merged.assets[0].contentHash).toBe(prepared.contentHash);
  512 |   expect(merged.assets[0].bytes).toEqual(assetBytes);
  513 |   await attachObservation(info, 'AT-F35-unit-merge-observed', { unitOperationId: unitOperation.operationId, retainedHistoryIds: unitSaved.project.history.map(command => command.operationId), mergedHistoryIds: merged.project.history.map(command => command.operationId), unitRollback: true, mergeRollback: true, hugeTick: record(merged.project, event.id, 'event').data.time, finalCondition: record(merged.project, edge.id, 'flow_edge').data.condition, finalRelationId: merged.project.relations[0].id, assetHash: merged.assets[0].contentHash, successfulReplacement: 'not_run: pending operations require real synchronization first' });
  514 |   await exerciseF35Replacement(browser,info,given);
  515 | });
  516 | 
  517 | async function expectOriginalReviewQuote(page: Page, originalBody: string, quote: string) {
  518 |   await page.getByRole('region', { name: '指摘の修正と確認', exact: true })
  519 |     .getByRole('button', { name: '指摘した元の固定版を開く', exact: true }).click();
  520 |   const dialog = page.getByRole('dialog', { name: '固定版の参照先', exact: true });
  521 |   await expect(dialog).toContainText('固定版: 版1');
  522 |   await expect(dialog).toContainText(originalBody);
  523 |   await expect(dialog.locator('.referenced-quote mark')).toHaveText(quote);
  524 |   await page.keyboard.press('Escape');
  525 |   await expect(dialog).toBeHidden();
```