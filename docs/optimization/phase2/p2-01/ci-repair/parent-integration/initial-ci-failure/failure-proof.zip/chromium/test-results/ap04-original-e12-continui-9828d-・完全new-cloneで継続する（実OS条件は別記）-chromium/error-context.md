# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ap04-original-e12-continuity.spec.ts >> AT-E12 キャッシュ済み未送信作品をoffline・容量拒否・実waiting-worker・移行retry・完全new/cloneで継続する（実OS条件は別記）
- Location: tests/e2e/ap04-original-e12-continuity.spec.ts:135:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.project-switch')
Expected substring: "Historical successful trace"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('.project-switch') with timeout 5000ms
  - waiting for locator('.project-switch')

```

```yaml
- button "アカウント・専用同期"
- text: この端末の作品
- group "任意持出し診断": この作業の診断を確認・持出し
- banner:
  - link "本文へ移動":
    - /url: "#main-content"
  - text: S シナリオ管理
  - button "配色を切り替え"
- main:
  - text: YOUR STORY, CONNECTED.
  - heading "物語をつなぐ。 次の一行へ。" [level=1]
  - paragraph: 人物、出来事、本文、分岐。 作品のすべてを、ひとつのノートに。
  - heading "新しい作品をはじめる" [level=2]
  - paragraph: まずはタイトルだけ。詳細はあとから。
  - text: 作品名
  - textbox "作品名":
    - /placeholder: あなたの物語のタイトル
  - button "作品を作成" [disabled]
  - button "サンプルで試す"
  - button "保存ファイルを読み込む"
  - heading "あなたの作品" [level=2]
  - text: "1"
  - button "Historical successful trace 8件の情報 · 端末内保存":
    - strong: Historical successful trace
    - text: 8件の情報 · 端末内保存
  - text: 作品はこのブラウザーに保存されます 端末内の作品 · 同期はアカウント欄から設定できます
```

# Test source

```ts
  180 |     const initialName = `${scene.name}・未送信の編集😀`;
  181 |     await page.locator('.detail-panel').getByLabel('名前', { exact: true }).fill(initialName);
  182 |     await page.locator('.editor-footer').getByRole('button', { name: '保存する', exact: true }).click();
  183 |     await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
  184 |     const pendingImage = await nativeImage(page);
  185 |     expect(pendingImage.tables.outbox.length).toBeGreaterThan(0);
  186 |     const cachedEntries = await page.evaluate(async ({ cacheName, pathnames }) => {
  187 |       if (!(await caches.keys()).includes(cacheName)) throw new Error('E12 fixed active-worker cache unavailable');
  188 |       const cache = await caches.open(cacheName);
  189 |       return Promise.all(pathnames.map(async pathname => {
  190 |         const response = await cache.match(pathname, { ignoreVary: true });
  191 |         if (!response || !response.ok) throw new Error(`E12 cached resource unavailable: ${pathname}`);
  192 |         const bytes = await response.arrayBuffer(), digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  193 |         return { pathname, bytes: bytes.byteLength, sha256: [...digest].map(byte => byte.toString(16).padStart(2, '0')).join('') };
  194 |       }));
  195 |     }, { cacheName: originalCache, pathnames: cachedURLs });
  196 |     expect(cachedEntries).toEqual(expectedCacheEntries);
  197 |     await attachGiven(info, 'AT-E12', bytes, { originalGiven: 'キャッシュ済みアプリと未送信作品', cachedController: true,
  198 |       initialFixtureIsGenuineLegacy: true, pendingOperationIds: pendingImage.tables.outbox.map(row => (row as { operationId: string }).operationId), build,
  199 |       originalCache, cachedEntries });
  200 |     const otherTab = await page.context().newPage(); await otherTab.goto(url); await expect(otherTab.locator('.app-shell')).toBeVisible();
  201 |     updateAvailable = true;
  202 |     await page.evaluate(async () => { const registration = await navigator.serviceWorker.getRegistration(); if (!registration) throw new Error('No cached registration'); await registration.update(); });
  203 |     await expect.poll(() => page.evaluate(async () => (await navigator.serviceWorker.getRegistration())?.waiting?.state)).toBe('installed');
  204 |     const beforeCold = await nativeImage(page);
  205 |     expect(durableImage(beforeCold)).toEqual(durableImage(pendingImage));
  206 |     const beforeDocumentNonce = await page.evaluate(() => { const value: unknown = Reflect.get(window, '__ap04E12DocumentNonce'); if (typeof value !== 'string') throw new Error('E12 document nonce unavailable'); return value; });
  207 |     expect(beforeDocumentNonce).toEqual(expect.any(String));
  208 |     await page.context().setOffline(true);
  209 |     await expect.poll(() => page.evaluate(() => navigator.onLine)).toBe(false);
  210 |     // A cached reload must create a new document while the context stays offline.
  211 |     // The nonce and complete durable image verify actual cold startup.
  212 |     const coldURL = new URL(url);
  213 |     await page.reload(); await expect(page.locator('.project-switch')).toContainText(given.project.name);
  214 |     const offlineDocumentNonce = await page.evaluate(() => { const value: unknown = Reflect.get(window, '__ap04E12DocumentNonce'); if (typeof value !== 'string') throw new Error('E12 document nonce unavailable'); return value; });
  215 |     expect(offlineDocumentNonce).toEqual(expect.any(String)); expect(offlineDocumentNonce).not.toBe(beforeDocumentNonce);
  216 |     await expect.poll(() => page.evaluate(() => navigator.onLine)).toBe(false);
  217 |     await expect.poll(() => page.evaluate(() => {
  218 |       const controller = navigator.serviceWorker.controller;
  219 |       return controller && { scriptURL: controller.scriptURL, state: controller.state };
  220 |     })).toEqual({ scriptURL: new URL('sw.js', url).href, state: 'activated' });
  221 |     expect(await page.evaluate(async () => (await navigator.serviceWorker.getRegistration())?.waiting?.state)).toBe('installed');
  222 |     expect(durableImage(await nativeImage(page))).toEqual(durableImage(beforeCold));
  223 |     await openEntity(page, 'scene', initialName);
  224 |     const beforeRefusal = await nativeImage(page), failedName = `${initialName}・容量不足でも残す入力`;
  225 |     await page.evaluate(() => {
  226 |       const put = IDBObjectStore.prototype.put; let armed = true;
  227 |       IDBObjectStore.prototype.put = function (...args: Parameters<IDBObjectStore['put']>) {
  228 |         if (armed && this.name === 'projects') { armed = false; throw new DOMException('E12 native quota fixture', 'QuotaExceededError'); }
  229 |         return put.apply(this, args);
  230 |       };
  231 |     });
  232 |     await page.locator('.detail-panel').getByLabel('名前', { exact: true }).fill(failedName);
  233 |     await expect(page.locator('.detail-panel').getByRole('alert')).toContainText('容量');
  234 |     await expect(page.locator('.editor-save-state')).toContainText('未保存');
  235 |     await expect(page.locator('.detail-panel').getByLabel('名前', { exact: true })).toHaveValue(failedName);
  236 |     expect(durableImage(await nativeImage(page))).toEqual(durableImage(beforeRefusal));
  237 |     expect(await page.evaluate(async () => (await navigator.serviceWorker.getRegistration())?.waiting?.state)).toBe('installed');
  238 |     await page.locator('.editor-footer').getByRole('button', { name: '保存を再試行', exact: true }).click();
  239 |     await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
  240 |     const saved = await backup(page), savedImage = await nativeImage(page);
  241 |     expect(saved.project.entities.find(e => e.id === scene.id)?.name).toBe(failedName);
  242 |     expect(saved.project.history.length).toBe(given.project.history.length + 2);
  243 |     expect(saved.recovery?.pending.length).toBeGreaterThanOrEqual(2);
  244 |     expect(await page.evaluate(async () => (await navigator.serviceWorker.getRegistration())?.waiting?.state)).toBe('installed');
  245 |     await info.attach('AT-E12-offline-complete.scenario', { body: Buffer.from(saved.bytes), contentType: 'application/zip' });
  246 |     // The real waiting worker can activate only after both controlled documents
  247 |     // leave the scope. No skipWaiting or privileged product API is called.
  248 |     await otherTab.close(); await page.context().setOffline(false);
  249 |     await page.goto(new URL('/e12-safe-point', url).href);
  250 |     await expect.poll(() => page.evaluate(async scope => Boolean((await navigator.serviceWorker.getRegistration(scope))?.waiting), url)).toBe(false);
  251 |     await page.goto(url);
  252 |     await expect(page.locator('.project-switch')).toContainText(given.project.name);
  253 |     await expect.poll(() => page.evaluate(async expected => (await caches.keys()).includes(expected), newCache)).toBe(true);
  254 |     await expect.poll(() => page.evaluate(async () => Boolean((await navigator.serviceWorker.getRegistration())?.waiting))).toBe(false);
  255 |     const afterUpdate = await backup(page); expect(afterUpdate.project).toEqual(saved.project);
  256 |     expect((await nativeImage(page)).tables.outbox).toEqual(savedImage.tables.outbox);
  257 |     const uncachedContext = await browser.newContext({ offline: true });
  258 |     try {
  259 |       const uncachedPage = await uncachedContext.newPage();
  260 |       const rejected = await uncachedPage.goto(url).then(() => false, () => true);
  261 |       expect(rejected).toBe(true);
  262 |     } finally { await uncachedContext.close(); }
  263 |     const recovery = await fullNewClone(browser, url, saved.bytes, saved.project, info);
  264 | 
  265 |     const migrationContext = await browser.newContext();
  266 |     try {
  267 |       const migratedPage = await migrationContext.newPage(); await seedVersionOne(migratedPage, url, saved.project, savedImage.tables.outbox);
  268 |       const oldImage = await nativeImage(migratedPage); expect(oldImage.version).toBe(10);
  269 |       await migratedPage.addInitScript(name => {
  270 |         const create = IDBDatabase.prototype.createObjectStore; let armed = true;
  271 |         IDBDatabase.prototype.createObjectStore = function (...args: Parameters<IDBDatabase['createObjectStore']>) {
  272 |           if (armed && this.name === name && args[0] === 'importDrafts') { armed = false; throw new DOMException('E12 copied native migration quota fixture', 'QuotaExceededError'); }
  273 |           return create.apply(this, args);
  274 |         };
  275 |       }, databaseName);
  276 |       await migratedPage.goto(url); await expect(migratedPage.getByRole('alert').filter({ hasText: /quota|Quota/ })).toBeVisible();
  277 |       expect(await nativeImage(migratedPage)).toEqual(oldImage);
  278 |       await migratedPage.getByRole('button', { name: '読み込みを再試行', exact: true }).click();
  279 |       await migratedPage.locator('.project-card').filter({ hasText: saved.project.name }).click();
> 280 |       await migratedPage.reload(); await expect(migratedPage.locator('.project-switch')).toContainText(saved.project.name);
      |                                                                                          ^ Error: expect(locator).toContainText(expected) failed
  281 |       const migrated = await backup(migratedPage); expect(migrated.project).toEqual(saved.project);
  282 |       expect((await nativeImage(migratedPage)).tables.outbox).toEqual(savedImage.tables.outbox);
  283 |       await info.attach('AT-E12-migration-retry-complete.scenario', { body: Buffer.from(migrated.bytes), contentType: 'application/zip' });
  284 |     } finally { await migrationContext.close(); }
  285 |     await attachObservation(info, 'AT-E12-local-observed', { build, browserVersion: browser.version(), completeSHA256: sha256(saved.bytes), recovery,
  286 |       cachedOfflineCold: true, realPendingOutbox: true, quotaRejectedDurableEditionUnchanged: true, unsavedInputAndFailureVisible: true,
  287 |       offlineColdNavigation: { url: coldURL.href, beforeDocumentNonce, offlineDocumentNonce, originalCache, cachedEntries, entireDurableImageUnchanged: true },
  288 |       normalSaveRetry: true, actualWaitingWorkerStayedInstalledUntilAllTabsLeft: true, copiedNativeMigrationRefusalAtomicAndNormalRetry: true,
  289 |       firstUncachedOfflineNavigationRejected: true,
  290 |       workerFixture: { originalSHA256: sha256(originalWorker), updatedSHA256: sha256(updatedWorker), changedOnlyCacheIdentity: true, applicationBytesChanged: false },
  291 |       blockedConditions: ['real old-application-build upgrade', 'physical-device flight mode', 'real OS Files save-location cancellation', 'unfetched material via its actual product control'],
  292 |       physicalDevice: false, realOSFilesVerified: false, originalWholeAcceptancePromotion: false });
  293 |   } finally { await page.context().setOffline(false); server.closeAllConnections(); await new Promise<void>(done => server.close(() => done())); }
  294 | });
  295 | 
```