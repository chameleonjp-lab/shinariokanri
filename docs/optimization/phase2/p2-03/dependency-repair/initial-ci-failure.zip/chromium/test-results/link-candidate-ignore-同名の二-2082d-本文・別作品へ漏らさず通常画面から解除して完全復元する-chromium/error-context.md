# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: link-candidate-ignore.spec.ts >> 同名の二人への確定リンクを保ち、候補除外を別本文・別作品へ漏らさず通常画面から解除して完全復元する
- Location: tests/e2e/link-candidate-ignore.spec.ts:118:1

# Error details

```
Test timeout of 240000ms exceeded.
```

```
Error: locator.click: Test timeout of 240000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '保存ファイルを読み込む', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - generic [ref=f1e4]:
    - generic [ref=f1e5]:
      - button "アカウント・専用同期" [ref=f1e6] [cursor=pointer]
      - generic [ref=f1e7]: この端末の作品
    - group "任意持出し診断" [ref=f1e8]:
      - generic "この作業の診断を確認・持出し" [ref=f1e9]
  - generic [ref=f1e11]:
    - link "本文へ移動" [ref=f1e12] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "主要ナビゲーション" [ref=f1e13]:
      - generic [ref=f1e14]:
        - generic [ref=f1e15]: S
        - generic [ref=f1e16]: シナリオ管理
      - button "候補除外を解除する作品A 作品一覧へ ⌄" [ref=f1e17] [cursor=pointer]:
        - generic [ref=f1e19]:
          - strong [ref=f1e20]: 候補除外を解除する作品A
          - generic [ref=f1e21]: 作品一覧へ
        - generic [ref=f1e22]: ⌄
      - generic [ref=f1e23]: WORKSPACE
      - navigation [ref=f1e24]:
        - button "年表" [ref=f1e25] [cursor=pointer]
        - button "構成" [ref=f1e26] [cursor=pointer]
        - button "資料 2" [ref=f1e27] [cursor=pointer]:
          - text: 資料
          - generic [ref=f1e28]: "2"
        - button "検索" [ref=f1e29] [cursor=pointer]
      - generic [ref=f1e30]:
        - generic [ref=f1e31]: QUICK NOTE
        - button "アイデアを残す" [ref=f1e32] [cursor=pointer]
      - generic [ref=f1e34]:
        - button "作品・保存" [ref=f1e35] [cursor=pointer]
        - generic [ref=f1e38]:
          - strong [ref=f1e39]: この端末に保存
          - generic [ref=f1e40]: 同期接続先は未設定
        - button "暗い配色にする" [ref=f1e41] [cursor=pointer]
    - generic [ref=f1e42]:
      - banner [ref=f1e43]:
        - generic [ref=f1e44]:
          - generic "候補除外を解除する作品A" [ref=f1e45]
          - generic [ref=f1e46]: /
          - generic [ref=f1e47]: 資料
        - status [ref=f1e48]:
          - generic [ref=f1e50]: 端末内保存済み
          - generic [ref=f1e51]: LOCAL
      - main [ref=f1e52]:
        - generic [ref=f1e53]:
          - generic [ref=f1e54]:
            - generic [ref=f1e55]: STORY ELEMENTS
            - heading "資料" [level=1] [ref=f1e56]
            - paragraph [ref=f1e57]: 人物と世界の情報を、ひとつの作品に。
          - button "場面を追加" [ref=f1e58] [cursor=pointer]
        - generic [ref=f1e59]:
          - generic [ref=f1e60]:
            - button "人物 2" [ref=f1e61] [cursor=pointer]:
              - text: 人物
              - generic [ref=f1e62]: "2"
            - button "グループ 0" [ref=f1e63] [cursor=pointer]:
              - text: グループ
              - generic [ref=f1e64]: "0"
            - button "場所 0" [ref=f1e65] [cursor=pointer]:
              - text: 場所
              - generic [ref=f1e66]: "0"
            - button "物品 0" [ref=f1e67] [cursor=pointer]:
              - text: 物品
              - generic [ref=f1e68]: "0"
            - button "設定 0" [ref=f1e69] [cursor=pointer]:
              - text: 設定
              - generic [ref=f1e70]: "0"
            - button "メモ 0" [ref=f1e71] [cursor=pointer]:
              - text: メモ
              - generic [ref=f1e72]: "0"
          - combobox "情報の種類" [ref=f1e73]:
            - option "人物"
            - option "グループ"
            - option "場所"
            - option "物品"
            - option "設定"
            - option "メモ"
            - option "目標"
            - option "地図"
            - option "移動経路"
            - option "口調"
            - option "用語"
            - option "章"
            - option "場面" [selected]
            - option "台詞"
            - option "出来事"
            - option "分岐図"
            - option "進行ノード"
            - option "進行線"
            - option "クエスト"
            - option "状態変数"
            - option "効果"
            - option "事実・認識"
            - option "伏線"
            - option "手掛かり・回収"
            - option "途中開始点"
            - option "試読記録"
            - option "外部契約"
            - option "制作タスク"
            - option "企画"
            - option "制作判断"
            - option "ゲーム仕様"
            - option "媒体版"
            - option "資料・出所"
            - option "添付素材"
            - option "演出"
            - option "絵コンテ"
            - option "翻訳"
            - option "収録"
            - option "レビュー"
            - option "一覧"
            - option "雛形"
            - option "公開版"
            - option "公開投影"
        - group [ref=f1e74]:
          - generic "最近開いた情報・お気に入り" [ref=f1e75] [cursor=pointer]
        - generic [ref=f1e76]:
          - generic [ref=f1e77]:
            - generic [ref=f1e78]:
              - heading "場面" [level=2] [ref=f1e79]
              - generic [ref=f1e80]: 2件
            - generic [ref=f1e81]:
              - button "01 二人のリンクと一般語 確定 😀葵と葵が歩く。葵の花。 場面" [ref=f1e82] [cursor=pointer]:
                - generic [ref=f1e83]: "01"
                - generic [ref=f1e85]:
                  - generic [ref=f1e86]:
                    - heading "二人のリンクと一般語" [level=3] [ref=f1e87]
                    - generic [ref=f1e88]: 確定
                  - paragraph [ref=f1e89]: 😀葵と葵が歩く。葵の花。
                  - generic [ref=f1e90]: 場面
              - button "02 別本文の同じ候補 確定 😀葵と葵が歩く。葵の花。 場面" [ref=f1e93] [cursor=pointer]:
                - generic [ref=f1e94]: "02"
                - generic [ref=f1e96]:
                  - generic [ref=f1e97]:
                    - heading "別本文の同じ候補" [level=3] [ref=f1e98]
                    - generic [ref=f1e99]: 確定
                  - paragraph [ref=f1e100]: 😀葵と葵が歩く。葵の花。
                  - generic [ref=f1e101]: 場面
          - complementary "場面の詳細" [ref=f1e104]:
            - generic [ref=f1e105]:
              - generic [ref=f1e106]:
                - generic [ref=f1e107]: 場面
                - heading "別本文の同じ候補" [level=2] [ref=f1e108]
              - button "詳細を閉じる" [ref=f1e109] [cursor=pointer]
            - status [ref=f1e110]:
              - text: 端末内保存済み
              - generic [ref=f1e112]: 版 0
            - group [ref=f1e114]:
              - generic [ref=f1e115]:
                - generic [ref=f1e116]: 名前
                - textbox "名前" [ref=f1e117]:
                  - /placeholder: 場面の名前
                  - text: 別本文の同じ候補
              - generic [ref=f1e118]:
                - generic [ref=f1e119]:
                  - generic [ref=f1e120]: 情報の状態
                  - combobox "情報の状態" [ref=f1e121]:
                    - option "確定" [selected]
                    - option "下書き"
                    - option "確認待ち"
                    - option "不採用"
                    - option "別案"
                - generic [ref=f1e122]:
                  - generic [ref=f1e123]: 公開範囲
                  - combobox "公開範囲" [ref=f1e124]:
                    - option "自分だけ" [selected]
                    - option "作品の編集者"
                    - option "投影プロファイル"
              - generic [ref=f1e125]:
                - generic [ref=f1e126] [cursor=pointer]:
                  - checkbox "未参照でも保持する" [ref=f1e127]
                  - text: 未参照でも保持する
                - generic [ref=f1e128]: 背景設定など、参照がなくても残す情報を指定できます。確認候補からの除外は保存後に反映します。
              - group [ref=f1e129]:
                - generic "共通元の固定参照・複製・部分上書き" [ref=f1e130]
                - option "現在稿を新しい固定版にする" [selected]
                - option "固定版を参照" [selected]
                - option "独立した複製"
                - option "指定項目だけ上書き"
              - tablist "編集内容" [ref=f1e131]:
                - tab "要約" [ref=f1e132] [cursor=pointer]
                - tab "本文" [selected] [ref=f1e133] [cursor=pointer]
                - tab "作者メモ" [ref=f1e134] [cursor=pointer]
                - tab "詳細" [ref=f1e135] [cursor=pointer]
                - tab "確認表示" [ref=f1e136] [cursor=pointer]
              - group [ref=f1e137]:
                - generic [ref=f1e138]:
                  - generic [ref=f1e139]: 本文
                  - generic [ref=f1e140]:
                    - textbox "本文" [ref=f1e141]:
                      - /placeholder: あとから詳しく書くこともできます
                      - text: 😀葵と葵が歩く。葵の花。
                    - region "本文のルビとリンク" [ref=f1e142]:
                      - generic [ref=f1e143]:
                        - heading "本文のルビ・リンク" [level=3] [ref=f1e144]
                        - generic [ref=f1e145]: 段落と語句を選んで追加
                      - generic [ref=f1e146]:
                        - generic [ref=f1e147]: 注記する段落
                        - generic [ref=f1e149]:
                          - text: 注記する段落
                          - combobox "注記する段落" [ref=f1e150]:
                            - option "選択してください"
                            - option "1. 😀葵と葵が歩く。葵の花。" [selected]
                      - paragraph [ref=f1e151]: 😀葵と葵が歩く。葵の花。
                      - generic [ref=f1e152]:
                        - generic [ref=f1e153]: 本文に見つかった候補
                        - generic [ref=f1e155]:
                          - text: 本文に見つかった候補
                          - combobox "本文に見つかった候補" [ref=f1e156]:
                            - option "候補を選ぶ（手入力もできます）" [selected]
                            - option "葵 · 人物 · 1b9e6f · 「葵」 · 2〜2文字目"
                            - option "葵 · 人物 · b6a4fd · 「葵」 · 2〜2文字目"
                            - option "葵 · 人物 · 1b9e6f · 「葵」 · 4〜4文字目"
                            - option "葵 · 人物 · b6a4fd · 「葵」 · 4〜4文字目"
                            - option "葵 · 人物 · 1b9e6f · 「葵」 · 9〜9文字目"
                            - option "葵 · 人物 · b6a4fd · 「葵」 · 9〜9文字目"
                      - generic [ref=f1e157]:
                        - generic [ref=f1e158]: リンクまたはルビを付ける語句
                        - textbox "リンクまたはルビを付ける語句" [ref=f1e159]:
                          - /placeholder: 本文にある語句を入力
                      - generic [ref=f1e160]:
                        - generic [ref=f1e161]: 本文での出現位置
                        - generic [ref=f1e163]:
                          - text: 本文での出現位置
                          - combobox "本文での出現位置" [disabled] [ref=f1e164]:
                            - option "語句と一致する位置がありません" [selected]
                      - generic [ref=f1e165]:
                        - generic [ref=f1e166]: 注記の種類
                        - combobox "注記の種類" [ref=f1e167]:
                          - option "用語・人物へのリンク" [selected]
                          - option "ルビ"
                      - generic [ref=f1e168]:
                        - generic [ref=f1e169]: リンク先
                        - generic [ref=f1e171]:
                          - text: リンク先
                          - combobox "リンク先" [ref=f1e172]:
                            - option "対象を選択" [selected]
                            - option "葵 · 人物 · b6a4fd"
                            - option "葵 · 人物 · 1b9e6f"
                            - option "二人のリンクと一般語 · 場面 · 4f85d0"
                      - button "リンクを付ける" [disabled] [ref=f1e173]
                      - generic [ref=f1e174]:
                        - strong [ref=f1e175]: 段落の操作
                        - paragraph [ref=f1e176]: 本文の編集後も注記範囲を追跡し、位置が曖昧な注記は再リンク待ちとして残します。
                        - generic [ref=f1e177]:
                          - generic [ref=f1e178]: 分割位置
                          - textbox "分割位置" [ref=f1e179]: "1"
                          - generic [ref=f1e180]: Unicodeコードポイントで1〜11文字目の後を指定します。 「😀｜葵と葵が歩く。葵の花。」
                        - generic [ref=f1e181]:
                          - button "この位置で段落を分割" [ref=f1e182] [cursor=pointer]
                          - button "次の段落と結合" [disabled] [ref=f1e183]
                          - button "前へ移動" [disabled] [ref=f1e184]
                          - button "後へ移動" [disabled] [ref=f1e185]
                      - generic [ref=f1e186]:
                        - strong [ref=f1e187]: 設定済みの注記
                        - paragraph [ref=f1e188]: まだありません。
              - group [ref=f1e189]:
                - generic "› この端末での項目と画面の表示" [ref=f1e190] [cursor=pointer]
              - generic [ref=f1e193]:
                - text: 使用する雛形
                - combobox "使用する雛形" [ref=f1e194]:
                  - option "雛形を適用しない" [selected]
              - group [ref=f1e195]:
                - generic "› 詳細データ・ルビ・本文リンクを編集" [ref=f1e196] [cursor=pointer]
              - group [ref=f1e197]:
                - generic "› カスタム項目を編集" [ref=f1e198] [cursor=pointer]
              - group [ref=f1e199]:
                - generic "› IDと履歴情報" [ref=f1e200] [cursor=pointer]
            - generic [ref=f1e201]:
              - button "アーカイブ" [ref=f1e202] [cursor=pointer]
              - button "保存する" [ref=f1e203] [cursor=pointer]
      - contentinfo [ref=f1e204]:
        - generic [ref=f1e205]: 端末内の作品 · 版 2
        - generic [ref=f1e206]: 4件の情報 · 0件の関係
```

# Test source

```ts
  1   | import { expect, test, type Browser, type Page } from '@playwright/test';
  2   | import { readFile } from 'node:fs/promises';
  3   | import { createEntity, createProject, newId, textToRichText } from '../../src/domain/model';
  4   | import { createWorldSnapshot } from '../../src/domain/world';
  5   | import { exportScenario, inspectScenario } from '../../src/storage/archive';
  6   | import type { Entity, ProjectData } from '../../src/domain/types';
  7   | 
  8   | async function nav(page: Page, name: RegExp) {
  9   |   await expect(page.locator('.app-shell')).toBeVisible();
  10  |   const menu = page.getByRole('button', { name: 'メニューを開く', exact: true });
  11  |   if (await menu.isVisible()) await menu.click();
  12  |   await page.locator('.sidebar').getByRole('button', { name }).first().click();
  13  | }
  14  | async function seed(page: Page, bytes: Uint8Array, mode: 'new' | 'clone' = 'new') {
  15  |   await page.goto('./');
  16  |   await expect(page.locator('.library-page, .app-shell')).toBeVisible();
  17  |   if (await page.locator('.project-switch').isVisible()) await page.locator('.project-switch').click();
> 18  |   await page.getByRole('button', { name: '保存ファイルを読み込む', exact: true }).click();
      |                                                                        ^ Error: locator.click: Test timeout of 240000ms exceeded.
  19  |   await page.locator('input[type=file]').setInputFiles({ name: 'candidate-ignore.scenario', mimeType: 'application/zip', buffer: Buffer.from(bytes) });
  20  |   if (mode === 'clone') await page.getByLabel('復元方法', { exact: true }).selectOption('clone');
  21  |   await page.getByLabel('復元方法と対象への影響を確認しました').check();
  22  |   await page.getByRole('button', { name: 'この内容で復元する', exact: true }).click();
  23  |   await expect(page.locator('.import-preview')).toBeHidden();
  24  |   await expect(page.locator('.app-shell')).toBeVisible();
  25  | }
  26  | async function openScene(page: Page, name: string) {
  27  |   await nav(page, /^資料/);
  28  |   await page.getByLabel('情報の種類', { exact: true }).selectOption('scene');
  29  |   await page.locator('.entity-card').filter({ has: page.getByRole('heading', { name, exact: true }) }).click();
  30  |   await page.getByRole('tab', { name: '本文', exact: true }).click();
  31  | }
  32  | async function backup(page: Page) {
  33  |   await nav(page, /^作品・保存/);
  34  |   await page.getByRole('tab', { name: '完全保存・復元', exact: true }).click();
  35  |   const pending = page.waitForEvent('download');
  36  |   await page.getByRole('button', { name: '完全保存ファイルを作成', exact: true }).click();
  37  |   const bytes = new Uint8Array(await readFile((await (await pending).path())!));
  38  |   await test.info().attach('candidate-ignore-complete.scenario', { body: Buffer.from(bytes), contentType: 'application/zip' });
  39  |   return { bytes, project: (await inspectScenario(bytes, { worker: false })).project };
  40  | }
  41  | async function fresh(browser: Browser, bytes: Uint8Array, mode: 'new' | 'clone') {
  42  |   const context = await browser.newContext();
  43  |   try {
  44  |     const page = await context.newPage(); await seed(page, bytes, mode); await page.reload();
  45  |     return (await backup(page)).project;
  46  |   } finally { await context.close(); }
  47  | }
  48  | 
  49  | test('通常本文で同名人物と一般語を選び分け、候補の除外をcold保持して実リンクと旧版を完全復元する', async ({ page, browser, browserName }) => {
  50  |   test.setTimeout(240000);
  51  |   await test.info().attach('browser-environment.json', { body: JSON.stringify({ browserName, actualVersion: browser.version(), viewport: page.viewportSize(), physicalDevice: false, actualAuthRlsStorage: false }), contentType: 'application/json' });
  52  |   let project = createProject('原B10/F27 二人の葵と一般語');
  53  |   const first = createEntity(project.projectId, 'character', '葵', { reading: 'あおい', summary: textToRichText('門番の葵'), aliases: [{ id: newId(), text: '青い子', reading: 'あおいこ', validity: { worldRange: null, routeCondition: null, presentationAnchor: null }, audienceHolderIds: [], isPublicDefault: false }] });
  54  |   const second = createEntity(project.projectId, 'character', '葵', { reading: 'あおい', summary: textToRichText('旅人の葵') });
  55  |   const body = textToRichText('😀葵が葵の花を持ち、青い子と会う。');
  56  |   const scene = createEntity(project.projectId, 'scene', '葵と普通の葵を選び分ける本文', { body });
  57  |   const quotation = createEntity(project.projectId, 'source', '引用資料の原文', {
  58  |     sourceType: 'book', locator: '引用元の書籍・第1章', excerptLocation: '12頁「葵の花と青い子」',
  59  |     interpretation: textToRichText('引用「葵の花を持つ青い子」。原文の表記を置き換えない。'), redistributionAllowed: false,
  60  |   });
  61  |   scene.customValues.citation = { type: 'ref', value: quotation.id };
  62  |   project.entities.push(first, second, scene, quotation); project.entities.forEach(entity => { entity.status = 'confirmed'; });
  63  |   project = await createWorldSnapshot(project, 'リンク前の固定版');
  64  |   const pin = project.snapshots.at(-1)!, input = await exportScenario(project);
  65  |   await test.info().attach('candidate-ignore-fixture.scenario', { body: Buffer.from(input), contentType: 'application/zip' });
  66  |   await seed(page, input); await openScene(page, scene.name);
  67  |   const annotations = page.getByRole('region', { name: '本文のルビとリンク', exact: true });
  68  |   const candidates = annotations.getByLabel('本文に見つかった候補', { exact: true });
  69  |   const options = () => candidates.locator('option').evaluateAll(nodes => nodes.map(node => ({ value: (node as HTMLOptionElement).value, label: node.textContent ?? '' })));
  70  |   const initial = await options(), aoi = initial.filter(option => option.label.includes('「葵」'));
  71  |   expect(aoi.length).toBeGreaterThanOrEqual(4);
  72  |   for (const person of [first, second]) expect(aoi.some(option => option.label.includes(person.id.slice(-6)))).toBe(true);
  73  |   const unlinked = await backup(page);
  74  |   expect((unlinked.project.entities.find(entity => entity.id === scene.id) as Entity<'scene'>).data.body[0].links ?? []).toEqual([]);
  75  |   await openScene(page, scene.name);
  76  |   const selected = aoi.find(option => option.label.includes(first.id.slice(-6)) && option.label.includes('2〜2文字目'))!;
  77  |   expect(selected).toBeTruthy(); await candidates.selectOption(selected.value);
  78  |   await annotations.getByRole('button', { name: 'リンクを付ける', exact: true }).click();
  79  |   await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
  80  |   const alias = (await options()).find(option => option.label.includes('「青い子」'))!;
  81  |   expect(alias).toBeTruthy(); await candidates.selectOption(alias.value);
  82  |   await annotations.getByRole('button', { name: 'リンクを付ける', exact: true }).click();
  83  |   await expect(page.locator('.editor-save-state')).toContainText('端末内保存済み');
  84  |   for (const person of [first, second]) {
  85  |     const common = (await options()).find(option => option.label.includes(person.id.slice(-6)) && option.label.includes('「葵」') && option.label.includes('4〜4文字目'))!;
  86  |     expect(common).toBeTruthy(); await candidates.selectOption(common.value);
  87  |     await annotations.getByRole('button', { name: 'この語句とリンク先の候補を表示しない', exact: true }).click();
  88  |   }
  89  |   await annotations.getByRole('button', { name: /参照元/ }).first().click();
  90  |   await expect(page.getByRole('dialog')).toContainText(scene.name);
  91  |   await page.getByRole('dialog').getByRole('button', { name: /閉じる/ }).first().click();
  92  |   await page.reload(); await openScene(page, scene.name);
  93  |   const coldOptions = await options();
  94  |   expect(coldOptions.some(option => option.label.includes('「葵」'))).toBe(false);
  95  |   expect(coldOptions.some(option => option.label.includes('「青い子」'))).toBe(true);
  96  |   const cold = await backup(page), saved = cold.project.entities.find((entity): entity is Entity<'scene'> => entity.id === scene.id && entity.kind === 'scene')!;
  97  |   expect(saved.data.body[0].id).toBe(body[0].id); expect(saved.data.body[0].text).toBe(body[0].text);
  98  |   expect(saved.data.body[0].links?.map(link => ({ start: link.start, end: link.end, entityId: link.target.entityId }))).toEqual([{ start: 1, end: 2, entityId: first.id }, { start: 10, end: 13, entityId: first.id }]);
  99  |   expect(cold.project.entities.find(entity => entity.id === quotation.id)?.data).toEqual(quotation.data);
  100 |   expect(saved.customValues.citation).toEqual({ type: 'ref', value: quotation.id });
  101 |   expect(cold.project.snapshots.find(snapshot => snapshot.id === pin.id)).toEqual(pin);
  102 |   expect(await fresh(browser, cold.bytes, 'new')).toEqual(cold.project);
  103 |   const clone = await fresh(browser, cold.bytes, 'clone'), people = clone.entities.filter((entity): entity is Entity<'character'> => entity.kind === 'character');
  104 |   expect(people).toHaveLength(2); expect(clone.projectId).not.toBe(cold.project.projectId);
  105 |   const clonedFirst = people.find(person => person.data.summary?.[0].text === '門番の葵')!, clonedScene = clone.entities.find((entity): entity is Entity<'scene'> => entity.kind === 'scene')!;
  106 |   expect(clonedFirst.id).not.toBe(first.id); expect(clonedScene.data.body[0].text).toBe(body[0].text);
  107 |   expect(clonedScene.data.body[0].links?.map(link => link.target.entityId)).toEqual([clonedFirst.id, clonedFirst.id]);
  108 |   const clonedQuotation = clone.entities.find((entity): entity is Entity<'source'> => entity.kind === 'source' && entity.name === quotation.name)!;
  109 |   expect(clonedQuotation.id).not.toBe(quotation.id);
  110 |   expect(clonedQuotation.data).toMatchObject({ sourceType: quotation.data.sourceType, locator: quotation.data.locator,
  111 |     excerptLocation: quotation.data.excerptLocation, redistributionAllowed: false });
  112 |   expect(clonedQuotation.data.interpretation?.map(block => block.text)).toEqual(quotation.data.interpretation?.map(block => block.text));
  113 |   expect(clonedQuotation.data.interpretation?.every(block => !(block.links?.length))).toBe(true);
  114 |   expect(clonedScene.customValues.citation).toEqual({ type: 'ref', value: clonedQuotation.id });
  115 |   await test.info().attach('candidate-ignore-observations.json', { body: JSON.stringify({ initialCandidates: initial, coldCandidates: coldOptions, selectedID: first.id, blockID: body[0].id, authoredLinks: saved.data.body[0].links, oldPinID: pin.id, quotation: { sourceId: quotation.id, clonedSourceId: clonedQuotation.id, original: quotation.data, cold: cold.project.entities.find(entity => entity.id === quotation.id)?.data, cloned: clonedQuotation.data }, preferenceScope: 'Same local account/project/source on this device. No transfer of local preferences through the complete file or actual Auth claim.' }), contentType: 'application/json' });
  116 | });
  117 | 
  118 | test('同名の二人への確定リンクを保ち、候補除外を別本文・別作品へ漏らさず通常画面から解除して完全復元する', async ({ page, browser, browserName }) => {
```