# P2-04 corrected driver: independent incremental specification review

**PASS — exact driver source `547ab05dd38fe36c939a94c80c236582d3d8ef77`, tree `f9206f05e37bb5fddda13f3975537986989779c3`.** D1 and D2 are closed for the specified evidence-retention boundary. No remaining driver specification correction is required by this review.

I verified both the requested immutable identity and the checkout HEAD/tree. The fixed freeze manifest records a clean state. Product `0479d4eedae9b51fbc6fd785265bbbc2de870e78` and literal repaired baseline `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa` remain unchanged. Prior CHANGES REQUIRED reports/manifests and their original identities remain preserved.

This review examined only the incremental immutable Git diff from `94db29d562cd4fc0c8c9951913ebd0ace9e4529b`, retained correction evidence and provenance. I did not run measurements, builds or tests, edit repository source, access live/external environments, spawn helpers, push, merge or publish. Only this review file was written.

## Finding closure

**D1 closed: rejected OFF elapsed survives.** The extracted observer captures its ending clock in the API try/catch/finally boundary for both fulfilled and rejected calls. The operation row therefore retains actual OFF milliseconds plus the original rejection. Pre-invocation checkpoint writes happen before the starting clock; settlement, end checkpoint writes and cleanup happen after the ending clock. ON and check modes do not call this interval clock or emit milliseconds.

ON failure now attempts native probe settlement outside any latency interval. The API outcome and original error are recorded before that observation wait. A settlement/checkpoint failure adds a separate observation error, preserves raw partial probe data and pendingTransactions, and marks completeness UNKNOWN. Derived history counters remain UNKNOWN for incomplete snapshots rather than synthesizing zeroes. If abort settlement succeeds, its settled native counts are retained. The original API rejection is rethrown even when observation also fails.

**D2 closed: interrupted API context survives without invented completion.** Before invoking each API, the observer persists its label, mode, probe phase and explicit pre-invocation intent. The persisted checkpoint states invocation/completion UNKNOWN because interruption in the following gap cannot establish that invocation occurred. This uncertainty is retained rather than falsely claiming an actual start timestamp or completed API duration.

After an ON API settles, its fulfilled/rejected boundary, original error where applicable, raw partial snapshot and probe-settling phase are checkpointed before waiting for settlement. Outer watchdog/pageerror formatting preserves that latest active context and the previous operation rows, while keeping interruption duration UNKNOWN and separate from actual rejected-OFF elapsed. No unmeasured lower bound or ON/outer duration is presented as API latency. This approval does not assign a duration to an unfinished API or claim invocation in the pre-invocation gap.

The runner races page errors with the operation/watchdog, serializes checkpoint writes, and blocks late browser checkpoints after shutdown begins. Its main guard permits pure interruption-formatter testing without starting the runner. Successful completion clears the active marker. These changes preserve the previous timing/counter/input definitions.

## Inspected failure evidence

- `driver-failure-red.log` preserves the three intended failures: missing rejected-OFF elapsed, failed ON not settling, and no active checkpoint. Two existing new-driver tests passed in that same run.
- `driver-failure-green2.log` records **two files / 11 tests PASS**. I inspected the committed tests: fake clocks prove rejected OFF retains 7 units while excluding 100-unit checkpoint work; injected probes distinguish settled abort counts from interrupted partial counts; pending-operation tests cover both before the first completion and after an earlier completion; watchdog/pageerror formatter tests retain uncertainty and prior rows; check-mode rejection forbids clocks/probes.
- The earlier GREEN1 result is honestly limited because its new `.test.mjs` formatter file was outside the existing test include. The renamed `.test.ts` is included in the final 11-test result. Original inventory/configuration and timeouts were not changed.
- The retained final TypeScript log has no diagnostic, and document validation passes. Reported syntax/diff checks are exit 0. These are inspected implementation records, not reviewer-executed checks or performance captures.

## Source and check-build attribution

The incremental diff contains only driver/core/new-driver-test changes plus additive DESIGN text; product/existing tests/original fixtures are unaffected. I independently calculated the byte length/SHA256 of every one of the **seven** committed overlay files and matched them to `p2-04-driver-fixed-freeze-manifest.json` and both retained check results. The corrected baseline/candidate overlays match each other exactly.

Both retained HTTP Chromium runs are **check mode**, original direct100, status `ok`, with empty errors. Each has six fulfilled operations, no milliseconds/probe field on any completed row, no leftover active marker, all 100 rows inline and zero canonical. Both use the identical original **59,736-byte** input / SHA256 `86bf759c4431bc041c3b2bc3c6bc3f9260c9cfd32971b011ed2a6d8eae38a3ea`.

Their actual checkout/product identities remain recorded honestly: candidate check checkout 94db plus the corrected dirty overlay, requested product0479; baseline check checkout/product17a plus the same seven-file overlay. These runs are not relabelled clean547ab builds.

I rehashed each actual retained ZIP and all **12** actual members per ZIP against its result manifest:

| Build | Actual bytes | SHA256 |
| --- | --- | --- |
| Candidate check | 598,641 | `7c4a8c5f266aa899cba1fcaf89d48f887f456c600e78eea0ea48d127dd8ea6c2` |
| Baseline check | 596,632 | `1e3854063cea5f96f9c0049986f2f6272b833a893fe8a7a420c5690bfa81e76e` |

All archive/member hashes match. Prior heavy-fixture/body-parity and Git-failure evidence stays under its original source identity; this report does not claim those were rerun after the observer correction.

## Remaining controller gates

The prior review's conforming boundaries still apply: literal repaired baseline; unchanged original 100/1000/10000 and Standard/Large generators; actual three24MiB materials; distinct extra heavy fixture; OFF/ON separation; correctness/native hashing outside intervals; complete-reader oracle label; unsupported/incomplete counters UNKNOWN; honest capacity, recoveredPending/worker/keepalive and separate body-table-alternative UNKNOWN.

This PASS clears the incremental specification gate for exact547ab. Independent quality approval for the same source and the controller's exclusive capture slot remain required before capture. Heavy capture, performance benefit/adoption, full P2-04 CI and original final acceptance remain separate pending decisions. No 30/180/7200, actual72MiB/600000ms/2000ms, device/service or release status is promoted. Original requirements, acceptance counts and RELEASE BLOCKED remain unchanged.
