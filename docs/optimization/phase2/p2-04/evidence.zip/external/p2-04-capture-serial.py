import pathlib,subprocess,json,datetime,sys
root=pathlib.Path('/workspace/phase2-progress');batch=root/'p2-04-capture-547ab05-20261017';batch.mkdir(exist_ok=False)
plan=[(suite,variant) for suite in ['legacy100','legacy1000','legacy10000','standard','large','added-heavy'] for variant in ['baseline','candidate']]
records=[]
for suite,variant in plan:
 label=variant+'-'+suite;cwd='/workspace/p2-04-driver-baseline' if variant=='baseline' else '/workspace/phase2';head='17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa' if variant=='baseline' else '0479d4eedae9b51fbc6fd785265bbbc2de870e78'
 argv=['node','scripts/optimization/measure-history-metadata.mjs','--mode','capture','--suite',suite,'--product-head',head,'--output',str(batch/label)]
 item={'suite':suite,'variant':variant,'cwd':cwd,'argv':argv,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};records.append(item);(batch/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print('START '+label,flush=True)
 with (batch/(label+'.log')).open('w') as log:code=subprocess.run(argv,cwd=cwd,stdout=log,stderr=subprocess.STDOUT).returncode
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());(batch/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print('DONE '+label+' exit='+str(code),flush=True)
 if code:print('STOPPED for failure inspection; no automatic retry/source change',flush=True);sys.exit(code)
print('ALL 12 SERIAL RUNS FINISHED',flush=True)
