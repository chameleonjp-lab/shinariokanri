# P2-04 independent specification review

**Checkpoint verdict: CHANGES REQUIRED. Final-source approval and measurement permission are pending.**

- Reviewed checkpoint: `c0db326937611f6d609bc3366192ce387784398d`.
- Verified checkpoint tree: `2d97b389b158d9765b70af830fdd2d9cdbf88881`.
- Dependency/comparison base: repaired PR63/P2-01 `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`.
- Verified base tree: `0ce90a1ea4300d9dd1ebc5d4f98a4663b6866457`.
- Review method: static inspection of immutable Git blobs and checkpoint/base diffs only. No live working-tree source was treated as frozen. I did not edit the repository, run tests/builds/timings, access external/live environments, push, merge, publish, or delegate.
- Binding material read at the checkpoint: `docs/implementation/codex-three-phase-2026-10-17/PHASE_2_OPTIMIZATION.md`, phase-1 `DESIGN.md` D04 and API boundary, phase-1 `HANDOFF.md`, and P2-04 `DESIGN.md`/requirement correspondence. The controller's explicit approved D04B boundary governs the canonical representation.

## Required checkpoint corrections

### S1: Object.values alone does not establish a plain string record

`src/storage/historyMetadata.ts:43-46` accepts any non-array object for `idMap` if `Object.values(value).every(...)` succeeds. Native structured cloning preserves built-ins such as Map and Date. Empty/opaque built-ins have no enumerable values, so they pass this predicate even though they are not string-valued records. The existing `canonicalJson` at `src/storage/json.ts:193-196` serializes their enumerable own keys and ignores their internal state.

Concrete static counterexample: start from a valid canonical command with `metadata.idMap = {}`. Change the native canonical metadata to `idMap = new Map([['unexpected','entry']])` or a Date. Its canonical JSON and existing seal remain identical to those of `{}`. The metadata-only reader accepts the malformed shape. On full decoding, the original body still contains `{}`, but `verifyDecodedHistory` at lines 88-91 compares both through `equalJson`; it can therefore also accept this header/body shape mismatch. Boxed strings create the same class of collision with numbered plain keys; this is not limited to empty objects.

Required correction: establish an actual plain string record before canonical sealing and before validating recognized metadata. Preserve compatible ordinary/null-prototype records. Apply that shared gate to both `idMap` and `importOrigin`; the latter's three required own names already block ordinary native built-ins, but should use the same declared record shape. Metadata's root additionally requires six own string fields and matching IDs, so ordinary cloned built-ins do not meet that root shape.

Required added negatives: valid plain-map control; writer fallback/error behavior for unsupported shapes; native recognized Map/Date and other representative built-ins with unchanged canonical bytes/digest; page and actual full/selected rejection without modifying native rows. This closes a declared-shape hole. It does not require eager body reads, a new serializer, or authentication claims.

### S2: Sparse arrays can evade the declared dense-array checks

At `src/storage/historyMetadata.ts:41`, equal key-count and array length plus `Array.every` does not prove density: a missing numeric index can be balanced by an extra enumerable property, while `every` skips the hole. The part descriptor at lines 56-63 uses `parts.every` without a density check at all. Its later `parts.map` existence checks at lines 98-102 also skip holes.

A native, self-consistent malformed recognized envelope can consequently pass these shape gates while retaining sparse targets or an incomplete part-key list. This contradicts the documented dense target array and exact descriptor shape; it is separate from the approved deferral of unread body bytes. Canonical JSON also ignores non-index array properties, so count-only checks cannot establish exact correspondence.

Required correction: check every numeric position is an own element and reject extra array keys for `targetIds` and descriptor `parts`. Unsupported writer metadata must retain the original fallback/error semantics; recognized malformed native metadata/descriptors must reject. Add negatives that recompute the seal where needed so validation reaches the shape gate rather than failing only on an old checksum. Keep all original fallback behavior and tests unchanged.

Both findings were sent promptly to the controller, who forwarded them to the implementer. They remain unresolved in the reviewed immutable checkpoint; subsequent working-tree fixes are not implicitly approved by this report.

## Architecture that conforms at this checkpoint

- The candidate adds no store, DB version, schema upgrade, eager migration, or external archive/native-format revision. Only already-packed command rows in explicitly bound store writers gain canonical metadata. Complete original v1 body parts are retained. Oversized, unknown-field, and own-undefined metadata use the existing representation.
- `historyPage` reads the project header, every history ID, canonical metadata, and every referenced part key in the same native transaction. It retains order, normalization, bounds, all-ID/project checks, and off-page missing-row/key failures. It remains O(N metadata), not O(page).
- The metadata read capability is the exact private `DBCoreGetManyRequest` object, not an IDB transaction flag. The request has a copied ID list and is unregistered in `finally`. Ordinary get/bulkGet/query/cursor readers and reading hooks continue through full decoding, including when nested requests share a parent r/rw transaction.
- Normal save, local ACK merge, confirmed conflict resolution, and imported command batches all bind canonical packing. Existing command/part mutation and transaction-abort machinery remains shared; direct/legacy writes do not automatically gain canonical metadata.
- Legacy/unrecognized envelopes retain complete body decoding and existing errors. Recognized canonical selected/full readers still validate original part hashes/graph/index correspondence before comparing metadata. Parent traversal and checkpoint reconstruction are not replaced by the lightweight page path.
- The documentation correctly distinguishes descriptor/metadata checksums from unread-body integrity or authentication. The retained negative explicitly permits a coordinated, recomputed valid canonical header to affect a page and requires actual selected/full/cold/export decoding to reject mismatch with the preserved body. Intact-key corrupt body bytes are likewise deferred only for recognized canonical page reads.
- Rollback is accurately scoped: retain the compatible decoder with metadata reads disabled, or perform a fully validated atomic rewrite before using a literal old decoder. The old binary is not falsely claimed to read the extra header. No delete/downgrade rollback is proposed.
- Probe additions are numeric, in memory, and default OFF. Inline legacy rows are counted in the synchronous getMany loop; original direct `historySeries(100/1000/10000)` remain fallback rather than invented canonical-scale evidence.
- The base-to-checkpoint diff contains only four product files and four added P2-04 documentation/test files. It does not modify the locked original files, fixtures, generator, seed, assertions, timeouts, retries, or skips. Requirement correspondence retains 104 requirements, 116 cases, 464 clauses, 24 packages, six groups, 68 supplemental checks, 73 locked originals, and the original 94 local/22 external/RELEASE BLOCKED state.

## Evidence inspected and remaining final gates

The added tests statically cover all-page/full-oracle comparison, literal ordering, query normalization/bounds, off-page corruption/missing rows/parts, deferred body corruption, coordinated recomputed metadata corruption, exact fallback values, ordinary reader isolation in parent r/rw transactions, reading hooks, all four writers, mixed history/checkpoints/cycles, import/clone/cold/export, production packing threshold/exact v1 bytes, own undefined, cancellation, and final quota rollback. These are meaningful supplemental cases; they do not promote or replace original acceptance. The controller reported a c0 focused result of 13 files/193 tests (156 existing, 37 new), but I did not execute or independently inspect a run here.

Final approval must name the final immutable source HEAD/tree and inspect the incremental diff from c0. In particular:

1. Resolve S1/S2 and inspect source plus red/green evidence for the new shape counterexamples. Confirm full-body comparison cannot reintroduce a canonical-JSON shape collision.
2. Inspect the pending numeric writer counters: actual canonical/fallback rows, metadata/envelope size, and seal/hash overhead must be separately observable without false zeroes, retained data, extra legacy asynchronous waits, or timing claims from probe-ON runs. Preserve fallback counting in the synchronous loop.
3. Inspect the pending real-browser HTTP/IndexedDB E2E source and attributable baseline RED/candidate GREEN evidence. The controller's planned normal-UI import uses a valid heavy archive above the unchanged production threshold, then checks native canonical rows, page/query values, cold selected/full/export equality and downloaded content. Its intact-key native-body corruption must allow only the explicitly unverified metadata boundary and reject actual cold selected/full decoding without changing native source rows. This is browser automation, not an actual-device or real-service pass. A low focused-test threshold is not substitute evidence.
4. Final focused checks, TypeScript/build/document checks, and required original full CI/three-browser inventory remain attributable evidence gates. The controller owns final PR62/63 CI status. Neither their upstream pass nor this static review is a final P2-04 full-CI pass.
5. Obtain both final independent specification and quality reviews on the same frozen source before timings. The additional counters/browser work and the required shape fixes invalidate treating c0 as the final approved source.
6. Measurement must retain literal repaired baseline `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`, identical immutable inputs/definitions, original fallback historySeries 100/1000/10000, actual Standard/Large bytes and production packing threshold. Any extra store-owned heavy diagnostic must be separately named and frozen; do not invent an all-canonical 10000-history input or share bodies to simulate it. Record writer overhead/fallback separately, all unfavorable results, and missing capacity/scope honestly. Probe-OFF timing and probe-ON work counts must remain separate, under the controller's exclusive measurement slot.

No performance benefit, adoption, final 30-run/180-save/7200-second acceptance, actual 72MiB/600000ms/2000ms acceptance, external condition, production/auth/billing/cloud change, merge, or publication is approved by this checkpoint review. Original acceptance and RELEASE BLOCKED remain unchanged.
