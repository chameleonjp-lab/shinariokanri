# P2-04 source freeze for independent reviews

Status: focused correctness green, product source FROZEN, awaiting controller spec/quality reviews. No performance/adoption/full-CI claim.

Dependency base `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`. Rebased initial WIP `13e27aa804c715eb5f340c951b9c490ebe9f4690` / tree `db83aca52f671be90ebda829f91ef1f2dfe7c9bf`.
Frozen head `c0db326937611f6d609bc3366192ce387784398d`, tree `2d97b389b158d9765b70af830fdd2d9cdbf88881`; clean worktree. Source bytes/SHA and all raw-log hashes: `p2-04-sourcefreeze-manifest.json`. Original fixtures and requirements equal exact repaired base bytes.
Historical pre-rebase base `ae757fbb389f0d77e9a9737cd9acd461692bf72e`, WIP `6e34b698116b5bf4e2c807938a395c6e452bbaf4`, tree `b78bd21dd0102c47509dcaaaff6b9240b2176ca6` are preserved in `p2-04-wip-hashes.json` and `task-4-report-paused-preserved.md`. Never relabel old tests/source as repaired dependency results.

## Selection and verification boundary

Prototype registered D04 B through existing commands+recordParts: only already-packed, store-owned command writes gain canonical metadata. Unchanged native schema v8, packing threshold, complete v1 body parts and external formats. No mandatory migration; exact legacy/direct rows and oversized/unknown metadata shapes use full-reader fallback. No derived metadata table adopted; unchecked source fingerprint rejected as body-integrity proof.

Seal covers exact accepted metadata shape, indices and descriptor; page verifies ALL header IDs and every part key in one transaction, with O(Nmeta) plus part-key visits. Canonical byte payload is explicitly UNLOADED. Intact-key body corruption is detected during actual selected/full/export decoding; coordinated metadata+recomputed seal is not authenticated and is detected against original body at actual decode. Cold full/export negative tests pass; warm cached project reads are not claimed to inspect native changes.

Metadata-only capability is the identity of ONE private, uncached DBCore getMany request, copied keys, finally-cleaned. It does not brand the native transaction or pass through reading hooks. Concurrent get/bulkGet/query/cursor inside the same parent r/rw retain complete rows. Unsupported request-cloning middleware loses the optimization, never grants another full reader partial data. Own undefined/unknown optional metadata use complete-body fallback; canonical shape checks plus full decoded shape/equality keep exact accepted metadata correspondence.

Rollback requires compatible full decoder/page fallback or validated atomic unbound rewrite before any old binary. Old binary alone rejects extra metadata. No DB delete/downgrade. Partial rewrite/quota/cancel preserve native rows and parts. Extra canonical seal wait is limited to commands; other tables retain original header construction.

## Actual commands and exits

- Resume RED `npx vitest run tests/optimization/history-metadata.test.ts -t 'same parent|own undefined|unchanged direct'`: exit1, 9 intended failures (r/rw capability leakage, ownundefined x4, inline counts100/1000/10000). Raw `p2-04-logs/resume-red.log`.
- Resume new suite: exit0,34/34; `resume-green1.log`.
- Focused existing+new: exit0,13files193tests (156existing +37new at that run); `resume-focused.log`. Command includes newhistory, originalprobe/librarysummary, recordParts/storage/performance/rb06Recovery/rb09Sync/outboxHistorySharing/sharedHistoryClone/sharedHistoryRestore/worldPins/immutableCommandHash.
- Final new suite after explicit accepted importOrigin/cancel and cold/full/export boundary additions: exit0,38/38; `resume-final-new.log`. Union with original focused run is194unique tests; not a full-unit claim.
- `npx tsc --noEmit`: final exit0; `resume-final-typecheck.log` (earlier resume typechecks also0).
- `git diff --check`: exit0. `python3 scripts/check_docs.py`: exit0; `resume-final-docs.log`.
- No build or timing capture yet. Parent owns original full unit/build/3-engine/downstream CI. No live service or device test.

## Coverage for review

| Boundary | Supplemental and unchanged original evidence |
| --- | --- |
| All pages/query/Japanese/invalid bounds/order | Frozen exact ae757 page oracle + literal new tests; separately encoded100canonical at test threshold; original100/1000/10000 direct fixtures and exact counters |
| Off-page ID/project/missing metadata/body part, stale seal/descriptor | New native corruption/no-mutation tests; original naive-slice counterexample retained |
| Body-unloaded vs full verification | Canonical intact-key corruption, recomputed header seal vs old body, selected/coldfull/export rejection; legacy packed body still rejects page |
| Full readers / no partial leakage | get/bulkGet/indexedquery/cursor, same-parent r/rw concurrency, reading hook exclusion; original outbox/hash/replay/storage tests |
| Normal save / import / local ACK / sync resolution | Explicit canonical native-row assertions for all4writer families; contract server only, no service |
| Checkpoint64 / parent cycle / importOrigin | New mixed100 history traversal/cycle; exact optional importOrigin; unchanged performance/outbox/rb06 recovery tests |
| Full export / import new+clone / cold / retained pending | New archive equivalence and clone operation count; unchanged sharedHistoryClone/Restore + storage/rb06/outbox originals |
| Atomicity / quota / cancellation / rollback adapter | Finalquota all native projects/commands/parts/outbox equality; interrupted/quota optional rewrite; aborted-signal rewrite; compatible decoder and unbound legacy rewrite |
| Native bounds / exact part bytes | Default production8MiB threshold, >4MiB string input, every original encoded byte/descriptor/metadata equality, oversized metadata fallback; no threshold/timeout change |

## Comparison and metric definitions

Detailed pre-measurement driver plan and metrics are committed in `docs/optimization/phase2/p2-04/DESIGN.md`. Literal repaired17a baseline/candidate clean builds, identical measurement harness, regenerated portable runtime and all build/source/fixture/material byte hashes are required. Original historySeries stays directinline fallback. Production-threshold Standard/Large store writes are primary representation examples; large targetIds may force fallback. If needed, a separately frozen valid heavy store-owned fixture supplements but never replaces originals. A production-scale10000heavybody run may be capacity-prohibitive and must remain UNKNOWN; no part sharing or threshold lowering to fake scale. Frozen original function on candidate decoder is explicitly common-store oracle, not literal base.

Probe OFF latency vs separate ON work. Header decoded estimate distinct from canonical envelope/inline fallback estimates, command body actual part bytes distinct from project header parts, all-row visits and requested/returned part keys distinct. Metadata seals do not verify unloaded bodies. All30 samples retained if any30comparison is chosen. No original180/7200/final restore acceptance run or promotion.

## Original crosswalk and retained failures

Committed `requirement-correspondence.json` retains original B12/B23/F35/N06/N09/N11/N14 case/clause/procedure pointers. Original104requirements/116cases/464clauses/24packages/6groups/68supplemental/73locked/94local/22external/RELEASE BLOCKED unchanged.

All initial failures and logs remain: first RED; setup coldopen correction; incorrect project-header part attribution; clone fourth-operation expectation; deep typed-array matcher timeout (fixed with exact length+every-byte comparison, no timeout increase); test-only spycast; resume9RED findings. No source/fixture/CI contract changed to hide failures. Build/timing/independent approvals/fullCI still UNKNOWN/pending. Final raw/evidence archive will include these failures and current source bindings after measurements.
