# P2-04 driver-only independent specification review

**CHANGES REQUIRED before capture.** Reviewed exact immutable driver commit `94db29d562cd4fc0c8c9951913ebd0ace9e4529b`, tree `80b4b09fb5b1ea6995a720d82453f2981189b114`.

The two required corrections concern failed/interrupted measurement evidence. The product specification PASS for `0479d4eedae9b51fbc6fd785265bbbc2de870e78` / tree `39f527c17e3d753719f789d835919dd9f4e50843` remains unchanged. No capture is approved by this report. Literal comparison base remains repaired `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa` / tree `0ce90a1ea4300d9dd1ebc5d4f98a4663b6866457`.

I inspected immutable Git blobs/diffs, the driver handoff/freeze manifest, retained check-mode results/logs and actual build ZIP/member bytes. I did not run measurements, tests or builds, edit repository source, access live/external environments, spawn helpers, push, merge or publish. This report is the only file written by this review.

## Required corrections

### D1 — Rejected OFF APIs discard their measured elapsed value

`tests/optimization/history-measurement-core.ts:58` starts the OFF clock. Successful completion at line 60 calculates milliseconds, but the catch at line 63 records only label/status/error and drops elapsed time. A Standard/Large save/read that rejects after substantial work consequently loses its failed measured duration. Retaining only its error does not retain the failed raw timing value required by the stage-2/HANDOFF failure-evidence contract.

Required change: retain the actual elapsed API value on rejected OFF operation rows, together with their error/status. Capture it at rejection before probe settling, persistence or cleanup. ON operation rows must continue to have no API-latency value. Preserve partial probe data honestly; if transaction work is not settled on failure, settle outside the interval where possible or identify incomplete/UNKNOWN counts rather than treating them as complete work.

A focused failure-path check should prove rejected OFF calls retain elapsed and error, while ON rejects remain counters-only and check mode still has no interval/probe fields. This need not execute a heavy fixture or produce performance evidence.

### D2 — Watchdog/pageerror interruption has no persisted active-API record

`observe` appends and checkpoints an operation only after it completes (core lines 60-65). The previous fixture/run checkpoint can therefore be the last persisted observation while the first save/import is pending, with no active API label or start fact. The outer runner starts the page evaluation and watchdog at `scripts/optimization/measure-history-metadata.mjs:70-71`; pageerror handling at line 67 and final error persistence at lines 74-75 retain a generic error and the last completed checkpoint, but cannot identify the interrupted API or its OFF/ON phase from an explicit active record.

Required change: retain active-operation/start information and its OFF/ON/check phase without including checkpoint I/O in the API timing interval. A watchdog/pageerror interruption must preserve that incomplete state and clearly distinguish its evidence from an API that actually returned a rejection. An incomplete API duration can remain UNKNOWN with separately labelled outer watchdog elapsed, or a defensible measured lower bound. Do not invent a completion duration or present ON/whole-harness elapsed as OFF API latency. Preserve any partial counters with their incomplete status.

Inspect/focus-check an interruption before the first API completes, as well as interruption after earlier successful rows, to establish that the original completed rows, current active label and error all survive. A new immutable driver head is required for incremental rereview after D1/D2; timing remains unauthorized.

Both findings were sent promptly to the controller. The controller confirmed D1 requires correction and requested the D2 watchdog/pageerror audit; both are recorded here for the implementer.

## Conforming driver scope and measurement boundaries

- The Git diff from approved 0479 contains exactly six new measurement files and additive P2-04 DESIGN text. Product code, existing tests, original fixtures/seeds, thresholds, timeouts, retries/skips, schemas and CI configuration are unchanged. Independently calculated bytes/SHA256 of all six committed overlays match the freeze manifest.
- The runner verifies tracked runtime source, build/config/lock files and the original history fixture definition against the requested literal product Git blobs, records checkout HEAD/tree/status/diff and overlay hashes, regenerates portable inputs before bundling, and retains actual build members plus a ZIP. Unexpected dirty paths and existing output directories are refused. The baseline product is literal repaired 17a with an explicit measurement-only overlay.
- Default check mode starts neither interval clocks nor numeric probes and produces no latency/probe fields. Capture mode explicitly separates a freshly seeded OFF store from a freshly seeded ON store. Only OFF records successful API elapsed; the successful path stops that interval before probe settling, checkpoint writes, hashes, native inventory and independent oracle comparisons. ON elapsed is not reported as latency.
- Initial writer/import, rename/dialogue writers, first/last/query pages, cold full command rows, cold selected command, valid store-owned cold full project and common-store complete-reader page oracle have separate labels. Reopening creates a fresh application store and is not claimed to evict OS/IndexedDB caches. The timed full-reader oracle has its own explicit label; correctness oracles following the other operations are outside their intervals/probes.
- Original `historySeries(100/1000/10000)` is imported unchanged and remains direct inline fallback. Original Standard and actual-material Large generators are imported unchanged. The original Large generator creates three actual 24MiB byte arrays; the driver separately records each actual byte length/hash and enforces 72MiB. These heavy suites remain unexecuted/UNKNOWN in this driver handoff.
- The added two-command fixture is explicitly supplemental and bound to 9,012,384 canonical bytes / SHA256 `46364d941e3f72ef793d31525bbf58b9c7384037b67eb9f94e55efaaade7e0fe`. No low threshold, shared body parts, substituted Standard/Large fixture or invented canonical 10000 scale is used. Input preparation/actual archive hashes are outside the import interval; writer cost is separately visible.
- The independent page oracle uses complete command readers, all-ID/project checks, original normalization/filter/order/bounds semantics and literal boundary expectations. Selected/full correspondence and full command-row shape checks supplement the already approved correctness suite.
- Native inventory records canonical/packed-fallback/inline proportions, serialized UTF-8 envelope/metadata/descriptor sizes, actual independent body/header part bytes and actual hashes. Body hashes are compared to descriptor declarations outside page intervals; this does not become a claim that metadata pages verify unread bodies. Serialized estimates are not physical IDB disk measurements.
- Successful candidate history counters use the approved numeric probe, and unsupported baseline history metrics are explicitly UNKNOWN. Inline rows remain visible through legacy envelope/DB counters. Writer preparation/fallback/seal metrics remain separate from verification and committed writes. Worker hashing, keepalive, the uncovered recoveredPending scheduling difference and unavailable capacity/scales are labelled UNKNOWN.
- The all-command separate metadata/body-table alternative remains unimplemented/unmeasured UNKNOWN with atomicity/migration/rollback tradeoffs documented. It is not ranked as slower or inferior. The driver does not assert that the narrow existing-parts prototype is a universal optimum.

## Independently inspected retained evidence

All four supplied HTTP check-mode results have status `ok`, empty errors and no operation milliseconds/probe data. They are correctness evidence only:

| Input | Baseline | Candidate | Independent retained checks |
| --- | --- | --- | --- |
| Original direct 100 | 100 inline, 0 canonical | 100 inline, 0 canonical | Same 59,736 bytes / SHA256 `86bf759c4431bc041c3b2bc3c6bc3f9260c9cfd32971b011ed2a6d8eae38a3ea`; six successful API/oracle rows |
| Added heavy | 1 inline + 1 packed fallback | 1 inline + 1 canonical | Same canonical fixture bytes/hash; eight successful API/oracle rows; all 20 body parts match in actual length/SHA256, total 4,503,988 bytes |

I independently compared the heavy body-part length/hash lists between products. Scope keys differ and no cross-command key sharing is permitted. Prepared ZIP metadata varies per run and each actual archive hash is retained.

The final heavy baseline/candidate six-file overlays exactly match each other and the reviewed committed overlay. The earlier candidate direct100 check uses the prior inventory-clarification overlay hash and is honestly retained under that identity; it is not relabelled as a clean 94db run. The baseline direct100 overlay matches the final frozen files.

For each of the four check results, I rehashed the actual `actual-build.zip` and all 12 actual ZIP members; every archive/member matches the recorded result manifest. Their dirty source status and original HEAD/tree are retained rather than overwritten with final freeze identity. The intentional bad-product-head result retains status `error`, Git exit 128, stdout/stderr, with no generator or build falsely recorded as successful.

Recorded driver unit log reports 2/2 PASS, TypeScript log has no diagnostic, and document validation passes. These are inspected implementation records, not reviewer-run checks. They do not exercise the missing D1/D2 capture-failure paths, so they do not close those findings.

The original 104 requirements, 116 cases, 464 clauses, 24 packages, six groups, 68 supplemental checks, 73 locked files, 94 local/22 external classifications and RELEASE BLOCKED remain unchanged. No original 30/180/7200, actual 72MiB final acceptance, 600000ms/2000ms acceptance, device/service, full-CI or adoption result is promoted. Correct the two driver evidence gaps, obtain exact-head independent rereviews and the controller's exclusive slot before capture.
