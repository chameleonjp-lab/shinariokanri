# P2-04 WIP pause for upstream CI repair

Status: PAUSED by controller, NOT complete/reviewed/adopted. No final performance comparison.
Base ae757fbb389f0d77e9a9737cd9acd461692bf72e.
WIP checkpoint head 6e34b698116b5bf4e2c807938a395c6e452bbaf4, tree b78bd21dd0102c47509dcaaaff6b9240b2176ca6. Clean worktree after checkpoint.

Design in docs/optimization/phase2/p2-04/DESIGN.md, written before implementation. Canonical metadata only on already-packed store-authored command rows; unchanged v8 schema/threshold/v1 body bytes. New canonical envelopes seal metadata+full descriptor+indices; page checks all IDs and every body-part key in one transaction, body bytes explicitly unloaded. Legacy/direct/unknown read full/decode/reject. Normal save/import/local ACK/sync resolution bind writers. Existing readers materialize exact bodies and compare metadata against decoded original. Rollback requires compatible full decoder or atomic validated unbound rewrite; old binary alone rejects new envelope extras. Oversized metadata retains old representation.

Changed paths: src/storage/{store.ts,recordPartsDatabase.ts,historyMetadata.ts}, src/observability/probe.ts, tests/optimization/{history-metadata.test.ts,history-page-oracle.ts}, docs/optimization/phase2/p2-04/DESIGN.md.

Raw logs: /workspace/phase2-progress/p2-04-logs.
RED red.log exit1: 7/11 failed (six intended new representation/deferred-byte behavior, one cold reopen test setup failure). green-attempt1 exit1: 10/11 pass; remaining assertion incorrectly included packed PROJECT header parts in command-body metric; corrected actual-key attribution. green-attempt2 exit1: 50/51 pass across seven files; clone adds original fourth operation, so literal new test expectation corrected from3 to4. green-attempt3 exit1: 138/140 pass across ten files; both new production-threshold 4MiB string cases exceeded default5s (11.5/10.8s); original tests all passed. New tests need explicit appropriate timeout or less expensive byte oracle (original test limits unchanged). green-attempt4 still running when checkpoint created; controller will receive completion.
Typecheck1 exit0 before latest test additions. Typecheck2 exit1: new test history-metadata.test.ts:31 contexts object unknown needs IDBObjectStore cast. Product typecheck had no other reported errors. git diff --check exit0.

No source/build/fixture performance archive yet; no timing run. Original full CI parent-owned, no pass claim. Required original104/116/464/24/6/68 and94local/22external/RELEASE BLOCKED unchanged. Requirements crosswalk/evidence archive/driver still pending. Resume only after controller provides exact upstream dependency fix.

Latest run green-attempt4 completed exit1:25new cases,23pass,2same default5s production-threshold timeouts; new localACK/syncresolution case passed. All processes stopped before controller handoff. WIP source hashes in p2-04-wip-hashes.json. Read-only requirement crosswalk draft p2-04-requirement-crosswalk-draft.json retains original clause pointers/procedures.
