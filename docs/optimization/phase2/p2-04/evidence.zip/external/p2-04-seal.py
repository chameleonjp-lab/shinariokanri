import pathlib,subprocess,json,hashlib,zipfile,os
repo=pathlib.Path('/workspace/phase2');external=pathlib.Path('/workspace/phase2-progress');dest=repo/'docs/optimization/phase2/p2-04';entries={};audit=[]
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def add(name,data):
 assert name not in entries,name
 entries[name]=data
# Preserve each ephemeral worktree's otherwise untracked generated/build/overlay
# bytes and symlink metadata. Do not follow shared node_modules.
for root in [pathlib.Path('/workspace/p2-04-browser-baseline'),pathlib.Path('/workspace/p2-04-driver-baseline')]:
 paths=set(filter(None,(git(root,'ls-files','--others','--exclude-standard')+'\n'+git(root,'ls-files','--others','--ignored','--exclude-standard')).splitlines()));items=[]
 for name in sorted(paths):
  p=root/name
  if p.is_symlink():items.append({'path':name,'kind':'symlink','target':os.readlink(p)});continue
  if p.is_file():
   b=p.read_bytes();member=f'worktrees/{root.name}/{name}';add(member,b);items.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archiveMember':member})
 audit.append({'worktree':str(root),'head':git(root,'rev-parse','HEAD'),'status':git(root,'status','--short','--untracked-files=all'),'uniqueUntrackedOrIgnored':items,'trackedFilesRecoverableFromGit':True,'cleanupDisposition':'All non-symlink untracked/ignored file bytes archived; shared node_modules target not owned by this worktree. Parent may remove worktree after archive verification.'})
(external/'p2-04-ephemeral-worktree-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
# Retain exact runtime source bytes for both measured products and driver.
for label,run in [('baseline','baseline-standard'),('candidate','candidate-standard')]:
 d=json.loads((external/'p2-04-capture-547ab05-20261017'/run/'result.json').read_text());head=d['productHead']
 for row in d['source']['productFiles']:
  data=subprocess.check_output(['git','-C',str(repo),'show',f"{head}:{row['path']}"]);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];add(f'source-snapshots/{head}/{row["path"]}',data)
 for row in d['generatedFiles']:
  root=repo if label=='candidate' else pathlib.Path('/workspace/p2-04-driver-baseline');data=(root/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];add(f'generated-snapshots/{label}/{row["path"]}',data)
 if label=='candidate':
  for row in d['source']['overlays']:
   data=(repo/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];add('driver-snapshot/547ab05/'+row['path'],data)
# Preserve available earlier checkpoints' changed source/test/doc blobs too.
owned=['src/storage/store.ts','src/storage/recordPartsDatabase.ts','src/storage/historyMetadata.ts','src/observability/probe.ts','tests/optimization/history-metadata.test.ts','tests/optimization/history-page-oracle.ts','docs/optimization/phase2/p2-04/DESIGN.md']
for ref in ['6e34b698116b5bf4e2c807938a395c6e452bbaf4','13e27aa','c0db326','94db29d']:
 head=git(repo,'rev-parse',ref)
 for name in owned:
  exists=subprocess.run(['git','-C',str(repo),'cat-file','-e',f'{head}:{name}'],capture_output=True).returncode==0
  if exists:add(f'historical-source/{head}/{name}',subprocess.check_output(['git','-C',str(repo),'show',f'{head}:{name}']))
for p in sorted(external.rglob('*')):
 rel=str(p.relative_to(external))
 if p.is_file() and (rel.startswith('p2-04') or rel.startswith('task-4') or rel == 'verify-p204-captures.py'):add('external/'+rel,p.read_bytes())
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
manifest={'scope':'Immutable P204 evidence seal. Historical sources/runs retain their actual identities; later documentation HEAD is not capture source.','productHead':'0479d4eedae9b51fbc6fd785265bbbc2de870e78','captureHead':'547ab05dd38fe36c939a94c80c236582d3d8ef77','baselineHead':'17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa','archive':{'path':'evidence.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'members':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())],'ephemeralWorktrees':audit}
(dest/'evidence-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for row in manifest['members']:
  b=z.read(row['path']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'members':len(entries),'archive':manifest['archive'],'worktreeFiles':[(a['worktree'],len(a['uniqueUntrackedOrIgnored'])) for a in audit]},indent=2))
