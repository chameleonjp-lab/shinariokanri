# P2-04 failed/interrupted evidence correction

Frozen clean driver **547ab05dd38fe36c939a94c80c236582d3d8ef77**, tree **f9206f05e37bb5fddda13f3975537986989779c3**. Product and existing tests remain exact approved0479. Literal baseline17a unchanged. Both94db CHANGES REQUIRED review reports were read fully and are retained. **No timing capture performed**; controlled unit failures use only injected fake clocks/probes.

## Review changes

- OFF rejection captures actual elapsed at API settlement, before observation/persistence/cleanup, retaining the original error. Success and error use the same interval. No elapsed is emitted by ON/check modes.
- ON rejection now attempts `probe.settle()` after an API-boundary checkpoint. If settlement succeeds, final native transaction counts are retained. If settlement fails, the original API error and separate observation error survive, raw snapshot/pendingTransactions remain, counterCompleteness is UNKNOWN/partial and derived history counters are UNKNOWN rather than synthesized zeroes. An outer interruption during settlement retains the earlier partial snapshot/API error; no completed latency is fabricated.
- An active label/mode/OFF-ON/check phase is checkpointed before starting the interval/probe/API. This is explicitly **pre-invocation intent**, not proof that the API was invoked in the tiny following gap. Interrupted completion remains UNKNOWN. Checkpoint I/O is outside the API interval. API settlement is separately recorded before potentially pending ON observation settlement.
- Runner watchdog/pageerror preserves the latest active checkpoint and earlier rows, labels outer interruption separately from actual API rejection and never manufactures a duration/lower bound. Existing actual completed OFF rows remain untouched. Checkpoint writes are serialized, and late browser checkpoints are ignored after shutdown begins.
- Runner main is guarded so its pure interruption formatter can be independently tested without launching a benchmark. The new failure test uses the existing `.test.ts` inventory; original Vitest/Playwright/config/timeouts unchanged.

## Actual checks, raw evidence and failures

- `driver-failure-red.log`: exit1,3 intended failures/2 passes after behavior-preserving observer extraction from94db with injectable dependencies: missing failed OFF duration, failed ON never settling, no active checkpoint. Product unchanged. No benchmark was run.
- `driver-failure-green1.log`: exit0,5/5; the new outer formatter test was initially `.test.mjs`, which the unchanged existing Vitest include excludes. That run is not claimed to cover the formatter. File renamed `.test.ts` and all checks rerun.
- `driver-failure-green2.log`: exit0,**2files11/11**. Independent literals cover OFF rejected7 fake clock units excluding100-unit checkpoint work; successful native abort settlement; interrupted settlement with original error plus observation error/pending1/UNKNOWN; check-mode clock/probe forbidden; interruption before first API completion and after earlier completion; watchdog/pageerror pre-invocation uncertainty; pending ON settlement preserving earlier rows without latency.
- `driver-fixed-final-typecheck.log`: `npx tsc --noEmit` exit0. `node --check scripts/optimization/measure-history-metadata.mjs` exit0.
- `driver-fixed-final-docs.log`: original check_docs exit0; `git diff --check` exit0.
- Candidate and literal baseline HTTP Chromium check mode original direct100 both exit0: `driver-fixed-check-{candidate,baseline}.log`. Six completed operations each; no milliseconds/probe observations. Same59,736-byte original input and all100 inline; all-ID/oracle/literal selected/full equality preserved.

Exact candidate argv: `node scripts/optimization/measure-history-metadata.mjs --mode check --suite legacy100 --product-head 0479d4eedae9b51fbc6fd785265bbbc2de870e78 --output /workspace/phase2-progress/p2-04-driver-fixed-check-candidate`. Baseline uses the same seven overlays in `/workspace/p2-04-driver-baseline`, product-head17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa and unique `p2-04-driver-fixed-check-baseline` output. No previous result is overwritten.

## Binding

`p2-04-driver-fixed-freeze-manifest.json` rehashes all303 tracked product files and7 overlays at final547ab; product0479 and existing tests have no diff. Baseline/candidate seven overlay byte hashes match each other and final source. Each retained check result records its real precommit dirty source HEAD/tree/status, generator hashes, actual build members/ZIP, argv and observations. They are not relabelled clean547ab builds.

- Candidate `p2-04-driver-fixed-check-candidate/actual-build.zip`:598641 bytes, SHA2567c4a8c5f266aa899cba1fcaf89d48f887f456c600e78eea0ea48d127dd8ea6c2.
- Baseline `p2-04-driver-fixed-check-baseline/actual-build.zip`:596632 bytes, SHA2561e3854063cea5f96f9c0049986f2f6272b833a893fe8a7a420c5690bfa81e76e.

Prior94db reports/manifests/checks, added-heavy20part byte parity, intentional Git failure, all product logs and failed attempts remain retained under their original identities. Standard/Large/legacy1000/10000 capture remains unexecuted, not promoted. Existing-parts optimization remains narrow to already-packed bounded-metadata store-owned rows; original direct10000 fallback and separate body-table alternative UNKNOWN remain unchanged. Waiting for exact547ab specification/quality rereviews and parent exclusive capture slot; no source command remains running.
