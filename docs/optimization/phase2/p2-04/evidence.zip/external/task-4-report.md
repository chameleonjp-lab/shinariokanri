# P2-04 final source freeze — review handoff

Final source **0479d4eedae9b51fbc6fd785265bbbc2de870e78**, tree **39f527c17e3d753719f789d835919dd9f4e50843**, clean branch `codex/phase2-history-metadata-20261017`. Dependency/literal comparison base remains **17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa**. Prior c0 checkpoint and its CHANGES REQUIRED review are retained, not relabelled as this source. No push, PR, timing capture, full CI, devices/services or acceptance promotion by this implementer.

## Final corrections and evidence

S1 now uses a shared plain-record string-field gate for idMap/importOrigin, also validating metadata/descriptor/part records. S2 explicitly checks every own array index and exact enumerable-key count for targetIds and parts. Writer unsupported shapes fall back; recognized malformed native shapes reject. The six new RED cases (Map/Date/Set/empty typed array plus both sparse arrays) are preserved in `p2-04-logs/review-shape-red.log` (exit1, including the malformed sparse-parts timeout). `review-shape-green.log` is exit0,45/45. A further importOrigin same-digest Date-with-own-fields check brings final new suite to46. No eager body read, original serializer or original test changed.

Writer counters distinguish candidate preparation, shape/size fallback, canonical outcome and actual writer seal calls/bytes. They do not count page/full-reader seal work as writer cost or attempts as commits. Writer RED missing-counter failure and GREEN39/39 retained. Original inline/fallback counters and all request-specific isolation remain intact.

Final commands and actual exits:

- Full requested focused command (same13file list below): `final-focused.log`, exit0, **202/202 =156 unchanged originals +46 new**.
- `npx tsc --noEmit`: `final-typecheck.log`, exit0.
- `python3 scripts/check_docs.py`: `final-docs.log`, exit0; `git diff --check`: exit0.
- Original `npm run build`: initial dirty candidate `browser-candidate-build.log` exit1 (type narrowing cast after plain-record guard); corrected `browser-candidate-build2.log` exit0. Final clean source original build `frozen-build.log` exit0, runtime **f16e69117e1d7d2550d1**. Existing chunk/dynamic-import warnings retained.
- New real HTTP/IndexedDB Chromium test: baseline exact17a plus test-only overlay `browser-red.log` exit1 at missing canonical marker after successful normal import. Candidate first `browser-green.log` exit1 because new expectation said 破損 while existing Worker deliberately returns 大きな履歴を処理できません。既存データを保持しています。; product error unchanged. Candidate `browser-green2.log` exit0; final added no-target/preview checks `browser-final.log` exit0. Final **clean source/build** `browser-frozen.log` exit0, **1/1**. These test runtimes are not performance observations. Firefox/WebKit original inventory remains parent CI scope/UNKNOWN locally.

The HTTP test uses deterministic canonical fixture bytes **9,012,384**, SHA256 **46364d941e3f72ef793d31525bbf58b9c7384037b67eb9f94e55efaaade7e0fe**, historical text4,500,031 bytes, unchanged production8,388,608-byte estimate threshold. Its two valid operations leave empty current state but preserve heavy old body. It verifies actual native canonical marker operationid2, metadata page/query, independent selected sentinel, exact cold downloaded full history, then intact-key corruption: page succeeds, selected target/preview absent, existing error shown, export errors/no download, native commands+parts hashes unchanged. Generated archive ZIP timestamps/export metadata vary between runs; each actual archive byte count/hash is retained, while canonical fixture hash is identical in baseline/candidate. This is supplemental, not original Standard/Large/10000 or formal final acceptance.

## Source/build/evidence bindings

- `p2-04-final-source-build-manifest.json`: final clean HEAD/tree/status, all tracked+new source paths, exact bytes/SHA256 and all build members.
- `p2-04-frozen-dist.zip`: actual clean build archive, **1,099,254 bytes**, SHA256 **7827f772b60810ef91339f1d6c26442e4bf57a1cc6bdca00e79aa46281fad040**. `p2-04-frozen-dist-manifest.json` records every member byte/hash.
- `p2-04-browser-baseline-original-manifest.json` and `p2-04-baseline-dist.zip`/manifest bind original baseline+test-only overlay. Baseline ZIP **1,096,804 bytes**, SHA256 **38fc2878e680debb7d2d0ac90926d50591e96a139da67d46049888d1251bf008**.
- `p2-04-browser-candidate-dirty-manifest.json` retains actual dirty source diff/status/file hashes and dirty build2 member hashes. That pre-freeze build is not relabelled as final clean build; only its member hashes were retained before rebuilding, not a separate complete dirty ZIP.
- `p2-04-browser-{red,green}` retains original failed traces/error contexts; `p2-04-retained-trace-attachments` extracts their actual fixture manifests. `p2-04-browser-final.json` and `p2-04-browser-frozen.json` retain JSON attachments; extracted actual cold-download archive bytes/manifests live in matching `-attachments` directories.
- `p2-04-final-evidence-inventory.json` lists retained P204 evidence bytes/hashes. Previous WIP/c0 source manifests/reports and all failed attempts remain present.

Final source is released to parent review. Spec rereview requested on exact0479; quality and timing slot pending. Architecture/comparison plan, original case/clause/procedure crosswalk, four-writer/full-reader/rollback/cancel/native-bound/capability coverage remain as recorded below and in committed DESIGN/correspondence. Driver implementation/timing is not yet executed, and no benefit/adoption or original final acceptance is claimed. Original RELEASE BLOCKED unchanged.

---

## Preserved c0 report (historical checkpoint; superseded status above)

# P2-04 source freeze for independent reviews

Status: focused correctness green, product source FROZEN, awaiting controller spec/quality reviews. No performance/adoption/full-CI claim.

Dependency base `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`. Rebased initial WIP `13e27aa804c715eb5f340c951b9c490ebe9f4690` / tree `db83aca52f671be90ebda829f91ef1f2dfe7c9bf`.
Frozen head `c0db326937611f6d609bc3366192ce387784398d`, tree `2d97b389b158d9765b70af830fdd2d9cdbf88881`; clean worktree. Source bytes/SHA and all raw-log hashes: `p2-04-sourcefreeze-manifest.json`. Original fixtures and requirements equal exact repaired base bytes.
Historical pre-rebase base `ae757fbb389f0d77e9a9737cd9acd461692bf72e`, WIP `6e34b698116b5bf4e2c807938a395c6e452bbaf4`, tree `b78bd21dd0102c47509dcaaaff6b9240b2176ca6` are preserved in `p2-04-wip-hashes.json` and `task-4-report-paused-preserved.md`. Never relabel old tests/source as repaired dependency results.

## Selection and verification boundary

Prototype registered D04 B through existing commands+recordParts: only already-packed, store-owned command writes gain canonical metadata. Unchanged native schema v8, packing threshold, complete v1 body parts and external formats. No mandatory migration; exact legacy/direct rows and oversized/unknown metadata shapes use full-reader fallback. No derived metadata table adopted; unchecked source fingerprint rejected as body-integrity proof.

Seal covers exact accepted metadata shape, indices and descriptor; page verifies ALL header IDs and every part key in one transaction, with O(Nmeta) plus part-key visits. Canonical byte payload is explicitly UNLOADED. Intact-key body corruption is detected during actual selected/full/export decoding; coordinated metadata+recomputed seal is not authenticated and is detected against original body at actual decode. Cold full/export negative tests pass; warm cached project reads are not claimed to inspect native changes.

Metadata-only capability is the identity of ONE private, uncached DBCore getMany request, copied keys, finally-cleaned. It does not brand the native transaction or pass through reading hooks. Concurrent get/bulkGet/query/cursor inside the same parent r/rw retain complete rows. Unsupported request-cloning middleware loses the optimization, never grants another full reader partial data. Own undefined/unknown optional metadata use complete-body fallback; canonical shape checks plus full decoded shape/equality keep exact accepted metadata correspondence.

Rollback requires compatible full decoder/page fallback or validated atomic unbound rewrite before any old binary. Old binary alone rejects extra metadata. No DB delete/downgrade. Partial rewrite/quota/cancel preserve native rows and parts. Extra canonical seal wait is limited to commands; other tables retain original header construction.

## Actual commands and exits

- Resume RED `npx vitest run tests/optimization/history-metadata.test.ts -t 'same parent|own undefined|unchanged direct'`: exit1, 9 intended failures (r/rw capability leakage, ownundefined x4, inline counts100/1000/10000). Raw `p2-04-logs/resume-red.log`.
- Resume new suite: exit0,34/34; `resume-green1.log`.
- Focused existing+new: exit0,13files193tests (156existing +37new at that run); `resume-focused.log`. Command includes newhistory, originalprobe/librarysummary, recordParts/storage/performance/rb06Recovery/rb09Sync/outboxHistorySharing/sharedHistoryClone/sharedHistoryRestore/worldPins/immutableCommandHash.
- Final new suite after explicit accepted importOrigin/cancel and cold/full/export boundary additions: exit0,38/38; `resume-final-new.log`. Union with original focused run is194unique tests; not a full-unit claim.
- `npx tsc --noEmit`: final exit0; `resume-final-typecheck.log` (earlier resume typechecks also0).
- `git diff --check`: exit0. `python3 scripts/check_docs.py`: exit0; `resume-final-docs.log`.
- No build or timing capture yet. Parent owns original full unit/build/3-engine/downstream CI. No live service or device test.

## Coverage for review

| Boundary | Supplemental and unchanged original evidence |
| --- | --- |
| All pages/query/Japanese/invalid bounds/order | Frozen exact ae757 page oracle + literal new tests; separately encoded100canonical at test threshold; original100/1000/10000 direct fixtures and exact counters |
| Off-page ID/project/missing metadata/body part, stale seal/descriptor | New native corruption/no-mutation tests; original naive-slice counterexample retained |
| Body-unloaded vs full verification | Canonical intact-key corruption, recomputed header seal vs old body, selected/coldfull/export rejection; legacy packed body still rejects page |
| Full readers / no partial leakage | get/bulkGet/indexedquery/cursor, same-parent r/rw concurrency, reading hook exclusion; original outbox/hash/replay/storage tests |
| Normal save / import / local ACK / sync resolution | Explicit canonical native-row assertions for all4writer families; contract server only, no service |
| Checkpoint64 / parent cycle / importOrigin | New mixed100 history traversal/cycle; exact optional importOrigin; unchanged performance/outbox/rb06 recovery tests |
| Full export / import new+clone / cold / retained pending | New archive equivalence and clone operation count; unchanged sharedHistoryClone/Restore + storage/rb06/outbox originals |
| Atomicity / quota / cancellation / rollback adapter | Finalquota all native projects/commands/parts/outbox equality; interrupted/quota optional rewrite; aborted-signal rewrite; compatible decoder and unbound legacy rewrite |
| Native bounds / exact part bytes | Default production8MiB threshold, >4MiB string input, every original encoded byte/descriptor/metadata equality, oversized metadata fallback; no threshold/timeout change |

## Comparison and metric definitions

Detailed pre-measurement driver plan and metrics are committed in `docs/optimization/phase2/p2-04/DESIGN.md`. Literal repaired17a baseline/candidate clean builds, identical measurement harness, regenerated portable runtime and all build/source/fixture/material byte hashes are required. Original historySeries stays directinline fallback. Production-threshold Standard/Large store writes are primary representation examples; large targetIds may force fallback. If needed, a separately frozen valid heavy store-owned fixture supplements but never replaces originals. A production-scale10000heavybody run may be capacity-prohibitive and must remain UNKNOWN; no part sharing or threshold lowering to fake scale. Frozen original function on candidate decoder is explicitly common-store oracle, not literal base.

Probe OFF latency vs separate ON work. Header decoded estimate distinct from canonical envelope/inline fallback estimates, command body actual part bytes distinct from project header parts, all-row visits and requested/returned part keys distinct. Metadata seals do not verify unloaded bodies. All30 samples retained if any30comparison is chosen. No original180/7200/final restore acceptance run or promotion.

## Original crosswalk and retained failures

Committed `requirement-correspondence.json` retains original B12/B23/F35/N06/N09/N11/N14 case/clause/procedure pointers. Original104requirements/116cases/464clauses/24packages/6groups/68supplemental/73locked/94local/22external/RELEASE BLOCKED unchanged.

All initial failures and logs remain: first RED; setup coldopen correction; incorrect project-header part attribution; clone fourth-operation expectation; deep typed-array matcher timeout (fixed with exact length+every-byte comparison, no timeout increase); test-only spycast; resume9RED findings. No source/fixture/CI contract changed to hide failures. Build/timing/independent approvals/fullCI still UNKNOWN/pending. Final raw/evidence archive will include these failures and current source bindings after measurements.

## Subsequent driver-only freeze

See `task-4-driver-report.md` and `p2-04-driver-freeze-manifest.json`: driver-only94db29d/tree80b4b09, reviewed product0479 unchanged, same overlay baseline/candidate check modes pass, no timing capture. Additional complete-body-table alternative and recoveredPending scheduling limitation are recorded there for the final comparison, without product changes or unsupported rankings. Incremental driver reviews and parent exclusive capture slot remain pending.

Driver failure-evidence rereview candidate is now547ab05/treef9206f0; see task-4-driver-fixed-report.md. Failed OFF elapsed, ON settlement/partial counts and interrupted active checkpoints are covered by11 fake-failure/correctness tests and paired real-browser check mode. Product0479 remains unchanged. Capture still unauthorized pending rereviews/slot.

## Completed captures and limited adoption

All12 serial captures on frozen547ab/literal17a+same7overlay exited0 with all equality checks. Exclusive slot released. Parent accepted narrow existing-parts canonical path on Standard/added-heavy; Large and originalinline10000 remain fallback. All15 unfavorable paired observations and writer/full-read costs retained without neutral-latency claim. See task-4-final-report.md and committed P204 README/measurements; source0479/driver547ab unchanged, final changes documentation/evidence only.
