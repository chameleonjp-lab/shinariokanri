# P2-04 corrected driver quality review

**APPROVE — exact driver `547ab05dd38fe36c939a94c80c236582d3d8ef77`, tree `f9206f05e37bb5fddda13f3975537986989779c3`.** Both prior quality findings are closed. No further blocking issue was found in the incremental correction.

The historical CHANGES REQUIRED review of `94db29d562cd4fc0c8c9951913ebd0ace9e4529b` remains unchanged in `task-4-driver-quality-review.md`; this approval applies only to the newly named source. Approved product/tests remain `0479d4eedae9b51fbc6fd785265bbbc2de870e78`, tree `39f527c17e3d753719f789d835919dd9f4e50843`. The literal baseline remains repaired `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`, tree `0ce90a1ea4300d9dd1ebc5d4f98a4663b6866457`.

I verified exact current HEAD/tree and clean status, read the immutable 94db-to-547ab diff and changed blobs, and inspected the fixed report, manifest, retained logs and actual artifacts. I ran no measurements, builds or tests, changed no repository source, delegated no work and accessed no external/live environment. This report is the only write.

## Closure of the prior findings

**R1 closed.** `history-measurement-core.ts:60-66` now uses the same OFF-only start/end clock for successful and rejected operations. The end is captured in finally immediately after the operation settles, before checkpoint persistence, probe settlement or database cleanup. A failed row retains both milliseconds and the original operation error. ON and check modes do not call that interval clock or emit a latency value.

The new controlled OFF test advances its injected clock by seven units inside the rejected API and by 100 units in checkpoint work. It requires the recorded failure duration to remain exactly seven and retains the literal rejection. This checks the boundary independently without running a timing capture.

**R2 closed.** Lines 67-78 persist the actual API outcome and a clearly partial probe snapshot before observation settlement, then attempt `probe.settle()` on both success and failure before taking the final stopped snapshot. The original API error remains separate from an observation error and is rethrown after the evidence is retained. A final snapshot is called settled only when no observation error exists and pendingTransactions is zero. Otherwise counterCompleteness remains UNKNOWN/partial, raw counts and pendingTransactions survive, and derived history counters are UNKNOWN instead of fabricated final zeroes. Native DB counters in such a snapshot are raw partial evidence under that completeness label.

Controlled tests cover both a rejected ON API whose native-abort counters finish settling and a rejected ON API whose observation settlement fails. The latter retains the original rejection, separate observation error, pending=1 and UNKNOWN completeness, without a latency field.

## Interruption and persistence review

The new observer persists pre-invocation intent before starting the probe/clock/API. Its checkpoint deliberately cannot prove invocation in the following gap. The in-memory running phase does not falsely promote that durable intent to completed work. ON API fulfillment/rejection is checkpointed before a potentially pending settle, preserving an actual outcome even if observation is later interrupted.

The runner's pure interruption formatter distinguishes watchdog/pageerror from an API rejection, preserves earlier rows and the latest active checkpoint, and reports unfinished completion/duration and counter completeness as UNKNOWN. It does not convert outer elapsed time or a timeout into API latency or a lower bound. The source guard permits testing that formatter without invoking the runner.

Serialized checkpoint writes prevent overlapping writes from leaving a late stale result after final persistence. The closing guard prevents browser callbacks that arrive after shutdown begins from replacing the retained interruption. The implementation keeps checkpoint I/O outside the OFF interval and introduces no product transaction, timeout or probe change.

The retained test source has meaningful literals for pre-first-completion and after-earlier-completion interruption, watchdog/pageerror uncertainty, interrupted ON settlement, settled native abort counts, and forbidden check-mode clock/probe access. The prior source/fixture/inventory/build/output-isolation audit remains applicable: the incremental diff changes only DESIGN, runner, observer and supplemental tests, with no product or original fixture/config change.

## Evidence and byte continuity

- The fixed manifest's 303 product entries are identical to the previously reviewed manifest, and the exact Git diff from product0479 contains only the seven driver files plus DESIGN. All seven fixed overlay byte lengths/SHA256 independently match exact547ab Git blobs.
- Both newly retained HTTP direct100 checks use those exact seven overlay hashes. Candidate retains its real precommit dirty94db identity; baseline retains literal17a plus its overlay. Neither build is relabelled as a clean547ab build.
- I independently hashed both actual new ZIPs and checked all 12 members of each against their result manifests and retained build-directory bytes. Candidate: **598641 bytes**, SHA256 `7c4a8c5f266aa899cba1fcaf89d48f887f456c600e78eea0ea48d127dd8ea6c2`. Baseline: **596632 bytes**, SHA256 `1e3854063cea5f96f9c0049986f2f6272b833a893fe8a7a420c5690bfa81e76e`.
- Both result files are successful check-mode runs with six completed operations, no active operation left, and no milliseconds/probe observation fields. Their unchanged direct100 input is 59736 bytes/SHA256 `86bf759c4431bc041c3b2bc3c6bc3f9260c9cfd32971b011ed2a6d8eae38a3ea`; paired first/last/query, full-command and selected-command hashes match exactly.
- I inspected `driver-failure-green2.log`, reporting two files and **11/11** tests passed, plus final typecheck/document-check evidence and the fixed implementer report. These are recorded implementer runs, not reviewer-run commands. The report accurately retains the earlier RED and the initially excluded `.test.mjs` formatter attempt before the final `.test.ts` run.
- The separately retained earlier heavy-input/body parity evidence remains under its prior identity. This correction does not change fixtures, part encoding or the prior independently checked 20-part/4503988-byte equality; I did not rerun that scenario.

## Approval scope

The corrected driver is suitable for the controller's next separately authorized, exclusive diagnostic capture after final specification continuity on this exact head. This review itself executes or approves no timing result, performance adoption, full CI, original acceptance, release, merge or publication. Standard/Large and legacy1000/10000 capture remain unexecuted in the inspected evidence; original fixtures, thresholds, budgets, classifications and RELEASE BLOCKED status remain unchanged.
