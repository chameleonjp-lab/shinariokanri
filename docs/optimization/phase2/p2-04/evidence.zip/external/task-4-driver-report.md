# P2-04 driver-only freeze

Driver HEAD `94db29d562cd4fc0c8c9951913ebd0ace9e4529b`, tree `80b4b09fb5b1ea6995a720d82453f2981189b114`, clean. Product and existing tests remain byte-identical to independently approved `0479d4eedae9b51fbc6fd785265bbbc2de870e78`; no product or original fixture edits. Six new files plus additive DESIGN only. Parent owns exact-head incremental reviews and exclusive capture slot. **No capture mode/timing performed.**

## Runner and argv

`node scripts/optimization/measure-history-metadata.mjs --mode check --suite legacy100 --product-head 0479d4eedae9b51fbc6fd785265bbbc2de870e78 --output /workspace/phase2-progress/p2-04-driver-check-candidate-1`

The same argv with `--suite added-heavy` and unique output `p2-04-driver-check-candidate-heavy` tested the final identical overlay. Literal baseline product uses isolated `/workspace/p2-04-driver-baseline` at repaired17a, same six explicit driver overlay files, `--product-head 17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`, unique outputs `p2-04-driver-check-baseline-1` and `p2-04-driver-check-baseline-heavy`. All four commands exit0. Original candidate direct100 check predates the inventory descriptor-hash clarification; retain its source hashes as-is. Final candidate-heavy/baseline-heavy six overlay hashes exactly match each other and final94db committed files.

Supported later suites are legacy100/1000/10000, standard, large, added-heavy. Default mode check never calls harness interval clocks/startProbe and outputs no milliseconds/probe fields. The reviewed later invocation will explicitly use `--mode capture` plus one suite/product-head/unique output; it has not been run. Default timeout1200000ms is only the new driver lifecycle, not an original test/acceptance timeout. Default output is a unique timestamp+UUID directory. Existing directories are refused. No original Playwright/CI settings changed.

## Correctness and actual exits

- `node --check scripts/optimization/measure-history-metadata.mjs`: exit0.
- `npx vitest run tests/optimization/history-measurement.test.ts`: final exit0,2/2, `p2-04-logs/driver-final-unit.log`. Independently checks added fixture canonical bytes/hash/literal content and original direct100 correctness with no probe/latency fields.
- `npx tsc --noEmit`: final exit0, `driver-final-typecheck.log`. Initial `driver-typecheck1.log` exit1 for new harness recursive inference/implicit-any, fixed via explicit ProjectData annotations; typecheck2/3/final0.
- `python3 scripts/check_docs.py`: final exit0, `driver-final-docs.log`; `git diff --check`: exit0.
- Actual HTTP Chromium check-mode baseline and candidate both pass original direct100 all-ID/oracle/literal/cold-full-command/selected checks. Exact original direct fixture59,736 bytes SHA25686bf759c4431bc041c3b2bc3c6bc3f9260c9cfd32971b011ed2a6d8eae38a3ea; all100 remain inline, zero canonical. No timed observation.
- Actual HTTP Chromium check-mode baseline and candidate both pass the added two-command fixture, initial normal import, all page/query/order and cold selected/full comparisons. Exact canonical fixture9,012,384 bytes SHA25646364d941e3f72ef793d31525bbf58b9c7384037b67eb9f94e55efaaade7e0fe. Baseline1inline+1packedfallback; candidate1inline+1canonical. All20 retained packed body parts have identical byte lengths and SHA256 between products, total4,503,988 bytes. Part scope keys differ naturally; no shared/fake bodies.
- Intentional invalid product-head000... preflight: exit1, `driver-git-failure.log` and `p2-04-driver-git-failure/result.json` retain Git128 error; no build/browser launched. Git/setup failure does not yield a success result.

`p2-04-driver-freeze-manifest.json` rehashes every tracked product file and overlay at final94db and binds their prior checks/builds without relabelling dirty builds as clean94db runs. Every check output directory retains `result.json` (source HEAD/tree/status, all product Git blobs/byte hashes, overlay hashes, generator hash files, build member hashes, observations), actual `build/`, `actual-build.zip`, generator stdout; external raw stdout/error logs remain in p2-04-logs. Final freeze has no running commands.

## Intervals, costs and limitations

Capture when later authorized uses separately seeded OFF then ON stores. Only OFF records elapsed API time; ON records default probe counters without presenting ON latency. Input construction/hash, native inventory, oracle comparison and probe settling are outside intervals. Initial save/import, rename/dialogue saves, first/last/query pages, cold full command bulkGet, cold selected command, valid store-owned cold full project and a separately labelled cold full-reader page oracle have distinct operation records. Reopening the store clears application caches; it does not claim cold OS/IndexedDB disk caches. Native inventory occurs before these reads in both products and is explicitly outside intervals.

Original Standard/Large generators and seeds are imported unchanged. Large supplies three actual24MiB assets, hashes actual bytes and asserts72MiB total. Those heavy suites have not yet been executed by this driver; their runtime/capacity/success remains UNKNOWN. Initial writer and subsequent actual input hashes are retained; product-generated timestamps/part scope identities can differ, with exact output bytes retained. Large initial metadata targetIds may exceed threshold and fall back, and its complete cost/proportion must remain in results.

Candidate history counters reflect metadata/legacy envelope estimates, actual command body part bytes, packed project header costs and requested/returned keys separately. Full native inventory records serialized UTF-8 envelope/metadata/descriptor lengths (not physical IDB disk sizes), actual byte/hash correspondence and complete independent body part hashes; it does not decode body content or turn page checksums into body/authentication proof. Selected/full APIs perform actual original decode. Baseline missing new history counters are explicitly UNKNOWN, not zero; generic DB/hash counters remain supported. Worker-internal hashing and native keepalive costs UNKNOWN.

Writer candidate/shape-fallback/size-fallback/canonical and seal calls/bytes remain distinct from verification and committed writes. The import-pair recoveredPending path has a source-derived additional resolved-value await inside unchanged bounded batch/keepalive; these inputs contain no recoveredPending so that scheduling cost is UNKNOWN. No assertion of zero extra awaits across every non-command path.

## Design comparison to retain in final decision

| Alternative | Coverage and tradeoffs | Measured status / adoption limit |
| --- | --- | --- |
| Literal existing full command reader | All direct/legacy/packed rows fully read; exact original decoder/error semantics. Original direct100/1000/10000 are inline and keep their O(N) full-row cost. | Baseline correctness checked; timing pending. |
| Derived metadata cache with fingerprint | Needs authoritative invalidation across all writers plus complete body-correspondence/integrity handling. A metadata checksum cannot prove unread source bytes. | Rejected as an integrity shortcut; no unsupported speed ranking. |
| Canonical metadata reusing existing commands+v1 parts (current prototype) | Only already-packed store-owned heavy commands with bounded accepted metadata benefit. Keeps original full body bytes/atomic part machinery and fallback; O(Nmeta)+every referenced part key. Inline rows and oversized metadata continue full fallback. Rollback requires compatible decoder or atomic validated rewrite. | Correctness/reviews approved for product0479; speed/writer cost/adoption pending. Not a universal optimum and does not remove original inline10000 cost. |
| Separate canonical metadata/body table for every command | Could cover inline rows too, but entails old-row/migration policy, atomic correspondence across two stores/all writers, all body-key completeness, added selected/full joins, write overhead and compatible rollback. Existing-parts design avoids this additional representation while applying narrowly. | Not implemented/measured: performance UNKNOWN. Not adopted in this unit because it expands representation/atomic/migration/rollback scope before evidence warrants it; do not call it slower/inferior or universally unnecessary. |

Original10000 unresolved full-row/all-ID/query work and every unfavorable result remain in the final decision. No threshold lowering, shared parts, substitute fixtures or fake canonical10000 scale. Large canonical scale unavailable due real capacity must remain UNKNOWN with bytes/reason. No formal30/180/7200, original final acceptance, devices, services, or RELEASE BLOCKED promotion.

## Superseding error-evidence freeze

The94db driver received CHANGES REQUIRED for failed/interrupted observations. `task-4-driver-fixed-report.md` and `p2-04-driver-fixed-freeze-manifest.json` bind corrected547ab05/treef9206f0,11/11 focused fake-failure checks and new paired HTTP check-mode runs. Product0479 unchanged; no capture performed. The earlier94db evidence above retains its original identity.
