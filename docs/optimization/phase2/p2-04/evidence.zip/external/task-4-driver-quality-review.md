# P2-04 driver-only quality review

**CHANGES REQUIRED — exact driver head `94db29d562cd4fc0c8c9951913ebd0ace9e4529b`, tree `80b4b09fb5b1ea6995a720d82453f2981189b114`.** Preserve failed OFF durations and make failed ON counter completeness explicit before capture. No other blocking issue was found in this incremental review.

The already approved product/test checkpoint remains `0479d4eedae9b51fbc6fd785265bbbc2de870e78`, tree `39f527c17e3d753719f789d835919dd9f4e50843`; its product approval is unchanged. The literal baseline remains repaired `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`, tree `0ce90a1ea4300d9dd1ebc5d4f98a4663b6866457`.

I verified the named tree and clean status, inspected immutable Git blobs/diff, and read the driver report and freeze manifest. The incremental diff contains exactly six new driver/harness/unit files and ten additive DESIGN lines. I ran no measurement, build or test, changed no repository source, accessed no external/live environment and delegated no work. Artifact hashing and ZIP inspection below were read-only. This review file is the only write.

## Required corrections

**R1 — failed OFF observations lose their elapsed duration.** `tests/optimization/history-measurement-core.ts:58-63` starts the OFF clock but calculates/pushes milliseconds only after a successful operation. The catch row contains an error but no elapsed value, even though a slow failed operation is an unfavorable observation that must remain visible. The separate specification review has independently identified this issue, and the controller has stated that a driver-only correction is planned.

Calculate elapsed time at the operation's failure boundary too, using the same OFF-only clock and definition. Persist the duration together with the error before propagating it; retain earlier operation records. Check mode must continue omitting latency fields, and ON mode must continue omitting latency measurements. Verify the failure shape with a lightweight controlled rejection rather than running a capture.

**R2 — failed ON snapshots can be stopped before native transaction counters settle.** The success path at line 61 waits `probe.settle()` before stopping. The catch path at line 63 immediately calls `probe.stop()`. The existing `databaseProbe.ts:33-38` deliberately binds transaction counts to native complete/abort listeners, and its source explains that Dexie's public promise can settle before later native listeners. The same ordering can matter after a rejected writer. If a failed ON row is captured with pendingTransactions greater than zero, stopping the capture prevents its later completion/abort counters from entering that snapshot; an absent counter must not be read as final zero work.

Settle the failed capture before taking its final snapshot when possible, preserving the original operation error if observation settlement also fails. If a terminal failure/timeout prevents settlement, retain the partial snapshot and explicitly label its counts incomplete/UNKNOWN, including its pending count and observation error. Do not present an unqualified final writer/abort count from that partial snapshot. This is an error-evidence issue, not a request to change product transactions or original budgets.

## Remaining implementation review

- OFF API intervals exclude input construction/hashing, native inventory, independent oracle comparison, output serialization and checkpoint persistence. ON uses a separately seeded database, starts the numeric probe without starting the harness latency clock, and does not expose ON durations as latency. Check mode uses neither timer nor startProbe. Product-internal existing clocks are correctly distinguished from returned harness measurements.
- Initial save/import, rename/dialogue writers, first/last/query pages, cold full command rows, selected command, valid store-owned full project and the complete-reader page oracle have separate operation labels. Reopening clears application caches; the report accurately avoids claiming cold OS/IndexedDB disk caches. The native inventory warms native data before those reads and is explicitly outside intervals in both products.
- Original direct history fixtures remain unmodified inline fallback; the driver asserts all IDs, count/uniqueness, exact full rows and literal selected reconstruction. The extra heavy fixture has its own frozen hash and independent literal sentinel. Standard/Large import unchanged generator/seed definitions, preserve the production threshold, and construct/hash actual material bytes. Those heavy suites' success, capacity and runtime are still unexecuted/UNKNOWN in the inspected evidence.
- Native envelope/metadata/descriptor UTF-8 estimates are separate from actual part byte lengths/hashes and physical IDB size. The inventory verifies body part bytes against their descriptors and rejects shared part keys; it does not turn that outside-interval work into a page integrity claim. Selected/full readers perform actual original decoding. Baseline missing history metrics are explicitly UNKNOWN, while supported zero counters remain numeric zero. Worker-internal hashing, keepalive requests and recoveredPending scheduling cost remain UNKNOWN.
- Product verification compares tracked runtime/build/config/original fixture bytes against the requested immutable product commit, rejects unexpected dirty overlays, records checkout identity/status/diff and all six overlay hashes, regenerates ignored portable inputs before bundling, and rechecks product/overlay bytes after build. The Vite harness build configuration is recorded separately from the original product build. Old dirty check builds retain their actual source attribution rather than being renamed clean 94db runs.
- The runner refuses an existing output directory and uses timestamp/UUID defaults. Child processes use structured argv, and the HTTP server binds loopback and confines files to its build directory. The browser gets a fresh context; test databases use the generated unique run ID and are deleted in finally. I found no credential enumeration, remote API/auth operation, secret logging path or production database target in this driver.
- Git/generator/build/browser failures set nonzero status and preserve errors and previously checkpointed observations. The invalid-product-head evidence confirms Git exit 128 with no build or browser success. The required error-observation corrections above concern missing/incomplete data within that preserved result, not a false-success setup result.

Generated command timestamps/operation IDs and part scopes can differ in the save-produced Standard/Large outputs and subsequent writer inputs. The driver retains their actual input/result hashes and the report discloses this. The original deterministic fixture input identity is separate from those generated values; do not describe all save-produced native rows as byte-identical across runs. The additional import-pair resolved-value await note from product review is accurately retained as unmeasured for these inputs.

## Independently checked retained bytes and results

I compared all **303** product entries in `p2-04-driver-freeze-manifest.json` with actual exact-94db Git blobs, byte lengths and SHA256, and independently confirmed equality to product0479 for each. All **six** overlay entries match the exact-94db blobs too.

I read each retained `result.json`, hashed all four actual `actual-build.zip` archives, and checked all **12 members per archive** against both recorded byte/hash manifests and retained build-directory bytes:

| Check | ZIP bytes | SHA256 |
| --- | ---: | --- |
| candidate-1 | 598231 | cac0fd53b0e81ed8801bc889815f759826976f70c2f39b1f04915bee1586b535 |
| baseline-1 | 596274 | 690bb6998ce02f339afa261b23ac96e7849bf71c3cf0da04f461215bd6445bb3 |
| candidate-heavy | 598291 | 05c74d785bcf3a1583660026a6ce468ec5112562492515123170a87ce27a6959 |
| baseline-heavy | 596274 | 42f7a53a25e6f36a1b40c3cf0d709479fbc5ce5bc69272544994b244fd7a22b1 |

The final baseline-1 and both heavy overlays equal frozen94db's six overlay hashes. Candidate-1 correctly retains an earlier inventory revision and is not falsely attributed to the final overlay.

Both direct100 runs have identical 59,736-byte input hash `86bf759c4431bc041c3b2bc3c6bc3f9260c9cfd32971b011ed2a6d8eae38a3ea`, 100 inline rows and no canonical rows. Both heavy runs have identical 9,012,384-byte input hash `46364d941e3f72ef793d31525bbf58b9c7384037b67eb9f94e55efaaade7e0fe`. Baseline has one inline plus one packed fallback row; candidate has one inline plus one canonical row. The ordered lengths and SHA256 of all **20 actual heavy body parts, 4,503,988 total bytes**, match across products. Paired first/last/query, selected-command and full-command result hashes also match exactly for these inspected inputs.

All four results are check-mode status ok and contain no milliseconds/probe observations. I inspected the retained final 2/2 driver-unit log, typecheck/document logs and intentional Git failure log; these are prior implementer runs, not reviewer-run tests. The source and artifact checks here do not turn check mode into performance evidence.

## Status after correction

Freeze the driver-only correction and obtain incremental review on its new exact HEAD/tree. Do not start timing on 94db. Both the controller's final specification/quality continuity and exclusive slot remain required. No full-CI, performance adoption, original 30/180/7200 acceptance, 72MiB acceptance, device/service, release, merge or publication approval follows from this review. All original requirements, fixtures, budgets and RELEASE BLOCKED classifications remain unchanged.
