import pathlib,json,hashlib,zipfile,csv
root=pathlib.Path('/workspace/phase2-progress/p2-04-capture-547ab05-20261017');out=pathlib.Path('/workspace/phase2/docs/optimization/phase2/p2-04');rows=[];suites=[];verification=[];overlay=None
for suite in ['legacy100','legacy1000','legacy10000','standard','large','added-heavy']:
 pair={}
 for variant in ['baseline','candidate']:
  directory=root/f'{variant}-{suite}';d=json.loads((directory/'result.json').read_text());assert d['status']=='ok' and not d['errors'] and d['mode']=='capture';o=d['observations'];assert o['status']=='ok'
  assert all(x['status']=='ok' for x in o['operations']);assert all(x.get('counterCompleteness')=='settled capture' and x['probe']['pendingTransactions']==0 and 'milliseconds' not in x for x in o['operations'] if x['probeEnabled'])
  assert d['source']['head']==('17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa' if variant=='baseline' else '547ab05dd38fe36c939a94c80c236582d3d8ef77')
  if variant=='candidate':assert d['source']['status']==''
  if overlay is None:overlay=d['source']['overlays']
  assert overlay==d['source']['overlays']
  archive=(directory/'actual-build.zip').read_bytes();assert len(archive)==d['build']['zip']['bytes'] and hashlib.sha256(archive).hexdigest()==d['build']['zip']['sha256']
  with zipfile.ZipFile(directory/'actual-build.zip') as z:
   assert set(z.namelist())=={x['path'] for x in d['build']['files']}
   for row in d['build']['files']:
    b=z.read(row['path']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert b==(directory/'build'/row['path']).read_bytes()
  verification.append({'run':f'{variant}-{suite}','exit':0,'sourceHead':d['source']['head'],'sourceTree':d['source']['tree'],'sourceStatus':d['source']['status'],'allBuildZipMembersVerified':True,'build':d['build'],'fixture':o['fixture'],'operations':o['operations'],'nativeRuns':[{'enabled':r['enabled'],'native':r['native']} for r in o['runs']]})
  pair[variant]=d
 a=pair['baseline']['observations'];b=pair['candidate']['observations'];assert a['fixture']['input']==b['fixture']['input'];assert a['fixture']['assetManifests']==b['fixture']['assetManifests']
 before={r['label']:r for r in a['operations'] if not r['probeEnabled']};after={r['label']:r for r in b['operations'] if not r['probeEnabled']};assert before.keys()==after.keys()
 for label,x in before.items():
  y=after[label];rows.append({'suite':suite,'operation':label,'baseline_ms':x['milliseconds'],'candidate_ms':y['milliseconds'],'candidate_minus_baseline_ms':y['milliseconds']-x['milliseconds'],'candidate_over_baseline':y['milliseconds']/x['milliseconds'],'candidate_slower_in_single_observation':y['milliseconds']>x['milliseconds']})
 suites.append({'suite':suite,'fixture':a['fixture'],'baselineRepresentation':a['runs'][0]['native']['representations'],'candidateRepresentation':b['runs'][0]['native']['representations'],'actualBodyBytesBaseline':a['runs'][0]['native']['bodyBytes'],'actualBodyBytesCandidate':b['runs'][0]['native']['bodyBytes'],'actualHeaderPartBytesBaseline':a['runs'][0]['native']['headerBytes'],'actualHeaderPartBytesCandidate':b['runs'][0]['native']['headerBytes']})
summary={'scope':'One OFF observation per API/product/suite; separate ON work, fixed baseline then candidate ordering. Not distribution/significance/formal acceptance. All unfavorable observations retained.','productHead':'0479d4eedae9b51fbc6fd785265bbbc2de870e78','captureHead':'547ab05dd38fe36c939a94c80c236582d3d8ef77','baselineHead':'17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa','all12RunsExit0':True,'suites':suites,'latencyPairs':rows,'unfavorableSingleObservations':[r for r in rows if r['candidate_slower_in_single_observation']],'verifiedRuns':verification}
(out/'measurements.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (out/'latency-observations.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('verified runs',len(verification),'pairs',len(rows),'unfavorable',sum(r['candidate_slower_in_single_observation'] for r in rows))
print('UNFAVORABLE')
for r in rows:
 if r['candidate_slower_in_single_observation']:print(r['suite'],r['operation'],round(r['baseline_ms'],1),round(r['candidate_ms'],1))
