# P2-04 final immutable specification review

**PASS — specification/correctness review of exact final source `0479d4eedae9b51fbc6fd785265bbbc2de870e78`, tree `39f527c17e3d753719f789d835919dd9f4e50843`.** No remaining specification change is required by this review.

This is the independent final specification gate before measurements, not performance/adoption/full-CI or release approval. The controller must still obtain the independent quality review on this same source and authorize an exclusive measurement slot. The original RELEASE BLOCKED status remains.

## Scope and source identity

- Literal repaired comparison/dependency base remains `17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa`, tree `0ce90a1ea4300d9dd1ebc5d4f98a4663b6866457`.
- Incremental review starts from the previously reviewed checkpoint `c0db326937611f6d609bc3366192ce387784398d`, tree `2d97b389b158d9765b70af830fdd2d9cdbf88881`.
- The earlier `task-4-spec-review.md` remains intact with its historical CHANGES REQUIRED verdict. This report approves the named final source, not that earlier checkpoint or an unspecified working tree.
- I read final source through immutable Git blobs/diffs and inspected retained logs, JSON reports, manifests and archive bytes. I did not run tests, builds or timing; edit the repository; access live/external environments; delegate; push; merge; or publish.
- Independently computed byte lengths/SHA256 for all nine base-to-final changed Git blobs match `p2-04-final-source-build-manifest.json`. Its final HEAD/tree match the Git identity above and its recorded status is clean.

Binding specifications remain the stage-2 request, phase-1 D04/HANDOFF, and the controller's approved D04B boundary: all-history canonical metadata remains validated O(Nmeta), while selected/full readers validate deferred heavy bodies. No requirement to eagerly decode every canonical command body has been added by this review.

## Closure of the two checkpoint findings

**S1 closed.** `src/storage/historyMetadata.ts:25` establishes ordinary/null-prototype plain records. The shared string-record predicate at line 49 applies to both `idMap` and `importOrigin`, and the metadata, descriptor and individual part shapes are checked too. Consequently Map/Date/Set/empty typed-array state cannot enter recognized canonical metadata merely because its enumerable JSON equals `{}`. Both the recognized header and decoded body metadata must satisfy the shape before canonical equality is used. Unsupported writer metadata falls back to the unchanged old header.

The added Map/Date/Set/typed-array cases preserve the actual same-canonical-bytes/digest collision, require writer fallback, native page rejection and actual selected-command rejection. The further importOrigin test covers a Date with the three required own fields before structured clone, with the same canonical bytes. It checks the shared gate directly. These changes close the declared-shape collision without changing the serializer or eagerly reading body parts.

**S2 closed.** `denseArray` at lines 26-29 checks both the exact enumerable-key count and every own numeric index. Its use for `targetIds` and descriptor `parts` rejects a hole balanced by an extra enumerable property, including before the part-key map. Descriptor entries must also be plain records. The added negatives recompute the seal to reach the shape gate; sparse target metadata also checks writer fallback.

Retained `review-shape-red.log` records six failing new cases before the correction: writer acceptance mismatches for the target/map cases and the malformed sparse-parts timeout. That timeout has not been hidden or relaxed. `review-shape-green.log` records 45/45 passing after correction, and the later final focused result includes the additional importOrigin case. Targeted RED selection's skipped cases are not changes to original test skips.

## Writer instrumentation and unchanged boundaries

The added writer metrics count packed-command preparation candidates, shape/size fallbacks, canonical preparation outcomes, and the actual bytes/calls entering the writer seal. The writer flag is used only by canonical header creation; page/full-read verification cannot inflate writer seal counts. Attempts are explicitly distinguished from committed persistence in DESIGN; existing transaction counters retain the commit/abort evidence.

All counters remain numeric, in memory and default OFF. The new metrics and shape checks add no asynchronous step to legacy/inline fallback loops. The existing synchronous getMany inline-row accounting remains unchanged, so original direct 100/1000/10000 histories do not become false-zero canonical results. Inline writes never enter packed candidate preparation; native inline/packed-fallback/canonical proportions and total writer/hash work must therefore be reported together.

`writer-metrics-red.log` preserves the missing-counter failure. Its GREEN records 39/39, and the final test asserts that three writer seals stay three even after metadata page and full-reader verification.

The rest of the c0-approved architecture is unchanged: private exact-request read capability; all IDs and referenced keys in the same native transaction; complete ordinary get/bulkGet/query/cursor/hook readers; four explicit writer families; original complete v1 parts; no new table/schema/version/eager migration; exact legacy/unknown/oversized/own-undefined fallback; existing transaction/rollback/cancel behavior. Metadata seals remain checksums of metadata/descriptor correspondence, not authentication or integrity verification of unread bytes. Coordinated recomputed valid metadata and intact-key corrupt bodies retain their documented selected/full/cold/export verification boundary.

## Real HTTP / IndexedDB evidence

The committed new test `tests/e2e/history-canonical-metadata.spec.ts` uses normal UI import/export and real browser IndexedDB at the unchanged production packing threshold. It does not install the focused-test low threshold. The deterministic supplemental fixture has two operations, an empty current revision, nine distinct 500000-byte historical texts and a literal 31-byte UTF-8 sentinel. Its canonical size is **9,012,384 bytes**, SHA256 **46364d941e3f72ef793d31525bbf58b9c7384037b67eb9f94e55efaaade7e0fe**; historical text totals **4,500,031 bytes**. It supplements rather than replaces original Standard/Large or historySeries inputs.

The test verifies an actual canonical native row for fixed operation 2 and actual body-part bytes, normalized query, selected sentinel preview, and exact history equality after a cold full UI download. It then flips an actual body byte while retaining its key, reloads, permits only the metadata page boundary, rejects the selected body with the existing Worker error, checks that no target section or preview appears, rejects full export without download, and compares all native command/part hashes with the post-corruption snapshot.

Inspected retained evidence:

- `browser-red.log`: literal repaired 17a plus isolated test-only overlay successfully imports, then fails at the missing canonical marker. The overlay is preserved as an earlier test version; its source hash is not falsely identified as the final test hash. The relevant line-52 marker assertion is unchanged.
- `browser-green.log`: first candidate attempt fails because the new assertion expected the word 破損 while the unchanged Worker actually returns `大きな履歴を処理できません。既存データを保持しています。`. The failure and trace remain. The correction changes the new test to the existing exact error and strengthens absence-of-partial-result assertions; it does not weaken original behavior.
- `browser-green2.log`/`browser-final.log`: intermediate successful candidate runs, separately retained from final clean-build evidence.
- **`browser-frozen.log` and `p2-04-browser-frozen.json`: final clean source/build Chromium 1/1 PASS, retry 0, skipped 0, flaky 0, no reported errors.** Its HTTP webServer is the local preview on `127.0.0.1:4173/shinariokanri/`.

The new file's own 120-second UI import/export budget does not alter original tests or Playwright configuration. Existing configuration includes the file through `tests/e2e` for each selected browser project, with retries still zero. Local Chromium success is not Firefox/WebKit, actual-device, real-auth or real-service success.

## Final build/artifact attribution

I inspected the actual retained `p2-04-frozen-dist.zip`: **1,099,254 bytes**, SHA256 **7827f772b60810ef91339f1d6c26442e4bf57a1cc6bdca00e79aa46281fad040**. All **13** actual ZIP members match their byte lengths/SHA256 in the final source/build manifest. `dist/build-info.json` inside that ZIP names the exact approved final commit/tree, `dirty: false`, and runtime **f16e69117e1d7d2550d1**. The retained `frozen-build.log` reports successful original build; existing chunk/dynamic-import warnings remain visible.

I also inspected the actual cold-download attachment from the clean browser report: **15,586 bytes**, SHA256 **87f2a2ee82de09a3cb0019a26de4fdb9a20252f4b6c2e979d0dc7198a68e3265**. Its project JSON contains zero current entities, the two fixed operations with 0→10 and 10→0 historical entity counts, all nine 500000-byte strings and `本文一致の独立期待😀`. Archive bytes vary with ZIP/export metadata; the report retains per-run archive hashes and does not mistake them for canonical fixture instability.

The earlier dirty build's member hashes were retained but its complete ZIP was not. This is disclosed in the implementer report and is not relabelled as the clean final build; the final clean ZIP is fully retained and verified above.

## Verification limits and remaining controller gates

I inspected `final-focused.log` reporting **13 files / 202 tests passed** (156 unchanged originals plus 46 new), the retained TypeScript log, successful document-check output, clean-source manifest and build/browser results. The implementer/controller report exit 0 for TypeScript and diff checks. These are inspected recorded results, not reviewer-run commands, and are not a full-unit/full-CI claim.

The base-to-final changed-path set still contains no locked original file, fixture/seed/generator, original assertion/timeout/retry/skip, schema version, production/auth/billing/cloud or CI configuration change. The 104 requirements, 116 cases, 464 clauses, 24 packages, six regression groups, 68 supplemental checks, 73 locked originals, 94 local and 22 external classifications remain unchanged.

Before any heavy capture, the controller must obtain independent quality PASS for this exact final source and allocate the exclusive slot. Required full P2-04 unit/build/three-browser/downstream CI remains a separate gate; upstream PR62/63 unit/build status does not substitute for that evidence. Performance/adoption review remains pending actual measurements against literal repaired 17a with identical definitions/input bytes, original fallback 100/1000/10000 and Standard/Large production inputs, separately frozen additional heavy diagnostics, visible writer costs/fallback proportions, probe-OFF timings separate from probe-ON counts, and all unfavorable or unavailable results retained.

No original 30-run distribution, 180-save, 7200-second, actual 72MiB, 600000ms, 2000ms or external acceptance is promoted by this PASS. No merge, publication or release is approved.
