"""Recheck frozen P204 capture provenance without rerunning a benchmark."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('/workspace/phase2-progress/p2-04-capture-547ab05-20261017')
REPO = Path('/workspace/phase2')
PRODUCT = '0479d4eedae9b51fbc6fd785265bbbc2de870e78'
BASE = '17a4cfb9dad2c20eb5adb369b7951a3f5a85c1aa'
DRIVER = '547ab05dd38fe36c939a94c80c236582d3d8ef77'
WHITELIST = {'package.json','package-lock.json','vite.config.ts','tsconfig.json','tsconfig.app.json','tsconfig.node.json','tests/optimization/fixtures.ts'}
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def committed(head):
    paths = git('ls-tree','-r','--name-only',head).decode().splitlines()
    paths = [p for p in paths if p.startswith(('src/','scripts/build/')) or p in WHITELIST]
    command = ['git','cat-file','--batch']
    data = subprocess.run(command, cwd=REPO, input=''.join(f'{head}:{p}\n' for p in paths).encode(), stdout=subprocess.PIPE, check=True).stdout
    stream = io.BytesIO(data)
    result = {}
    for path in paths:
        blob, kind, length = stream.readline().decode().strip().split()
        assert kind == 'blob'
        raw = stream.read(int(length)); assert stream.read(1) == b'\n'
        result[path] = {'bytes':len(raw),'sha256':sha(raw),'gitBlob':blob}
    assert not stream.read()
    return result

products = {head:committed(head) for head in (BASE, PRODUCT)}
runs = json.loads((ROOT/'runs.json').read_text())
assert len(runs) == 12 and len({(r['variant'],r['suite']) for r in runs}) == 12
records = {}; summaries = []; expected_overlay = None; previous_finish = None
for run in runs:
    assert run['exitCode'] == 0
    if previous_finish: assert run['startedAt'] >= previous_finish
    previous_finish = run['finishedAt']
    output = Path(run['argv'][run['argv'].index('--output')+1])
    value = json.loads((output/'result.json').read_text()); source = value['source']; obs = value['observations']
    head = BASE if run['variant']=='baseline' else PRODUCT
    assert value['status']=='ok' and obs['status']=='ok' and not value['errors']
    assert value['mode']=='capture' and value['suite']==run['suite'] and value['argv']==run['argv'][2:]
    assert source['productHead']==head and source['productTree']==git('rev-parse',head+'^{tree}').decode().strip()
    assert source['head']==(BASE if run['variant']=='baseline' else DRIVER)
    if run['variant']=='candidate': assert source['status']==''
    files = source['productFiles']; assert {r['path'] for r in files} == set(products[head])
    for row in files:
        assert all(row[k]==products[head][row['path']][k] for k in ('bytes','sha256','gitBlob'))
        assert row['matchesProductCommit'] is True
    overlay = {r['path']:(r['bytes'],r['sha256']) for r in source['overlays']}
    if expected_overlay is None: expected_overlay=overlay
    assert overlay==expected_overlay and len(overlay)==7
    for path, pair in overlay.items():
        raw=git('show',DRIVER+':'+path); assert (len(raw),sha(raw))==pair
    assert value['generator']['exitCode']==0
    archive=output/value['build']['zip']['path']; raw=archive.read_bytes()
    assert len(raw)==value['build']['zip']['bytes'] and sha(raw)==value['build']['zip']['sha256']
    with zipfile.ZipFile(archive) as z:
        names=z.namelist(); members=value['build']['files']
        assert len(set(names))==len(names) and z.testzip() is None and set(names)=={r['path'] for r in members}
        for row in members:
            data=z.read(row['path']); assert len(data)==row['bytes'] and sha(data)==row['sha256']
            assert (output/'build'/row['path']).read_bytes()==data
    assert len(obs['runs'])==2 and [r['enabled'] for r in obs['runs']]==[False,True]
    assert all(r['status']=='ok' and r['native']['bodyHashesComparedWithDescriptors'] for r in obs['runs'])
    for operation in obs['operations']:
        assert operation['status']=='ok' and operation['apiCompletion']=='fulfilled'
        if operation['probeEnabled']:
            assert 'milliseconds' not in operation and 'probe' in operation
        else: assert operation['milliseconds']>=0 and 'probe' not in operation
    assert not obs.get('activeOperation')
    if run['suite'].startswith('legacy'):
        n=int(run['suite'][6:]); assert all(r['historyCount']==n and r['native']['representations']=={'inline':n,'packedFallback':0,'canonical':0} for r in obs['runs'])
    if run['suite']=='large':
        fixture=obs['fixture']; assert fixture['originalAssetBytes']==72*1024*1024
        assert len(fixture['assetManifests'])==3 and sum(r['bytes'] for r in fixture['assetManifests'])==72*1024*1024
    records[(run['suite'],run['variant'])]=value
    summaries.append({'suite':run['suite'],'variant':run['variant'],'sourceHead':source['head'],'productHead':head,'productFiles':len(files),'overlayFiles':len(overlay),'buildZipBytes':len(raw),'buildZipSHA256':sha(raw),'buildMembers':len(members),'operations':len(obs['operations']),'fixture':obs['fixture'],'representations':[r['native']['representations'] for r in obs['runs']]})
for suite in {r['suite'] for r in runs}:
    a=records[(suite,'baseline')]['observations']; b=records[(suite,'candidate')]['observations']
    # The separately exported preparation ZIP is an actual per-product output,
    # not the deterministic decoded fixture. Preserve both byte hashes without
    # asserting binary envelope equality. All original input/asset fields match.
    assert {k:v for k,v in a['fixture'].items() if k!='actualPreparedArchive'}=={k:v for k,v in b['fixture'].items() if k!='actualPreparedArchive'}
    if suite.startswith('legacy') or suite=='added-heavy':
        for left,right in zip(a['runs'],b['runs']):
            for key in ('historyIDs','page-first','page-last','page-query','fullCommands','selected'):
                assert left[key]==right[key],(suite,key)
    if suite=='added-heavy':
        for left,right in zip(a['runs'],b['runs']):
            parts=lambda r:[(p['bytes'],p['sha256']) for p in r['native']['bodyParts']]
            assert parts(left)==parts(right) and len(parts(left))==20
            assert left['native']['bodyBytes']==right['native']['bodyBytes']==4503988
receipt={'scope':'Independent stored source/build bytes and paired recorded observations; no benchmark rerun or deleted DB reopening; generated-input hashes are recorded rather than re-labelled as retained raw inputs. Separately exported preparation ZIP bytes are retained as recorded per-product hashes, not assumed equal; decoded input and actual assets match.','runs':summaries,'serialRuns':12,'allExitZero':True,'sameSevenOverlays':True,'pairedFixtureAndStableOracleHashes':True,'heavyBodyParts':20,'heavyBodyBytes':4503988,'acceptancePromoted':False}
(ROOT/'parent-reverification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'serialRuns':12,'buildMembers':sum(r['buildMembers'] for r in summaries),'sameSevenOverlays':True,'pairedFixtureAndStableOracleHashes':True,'acceptancePromoted':False}))
