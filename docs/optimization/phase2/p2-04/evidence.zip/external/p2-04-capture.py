import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);dest=pathlib.Path(sys.argv[2])
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def item(p):
 b=p.read_bytes();return {'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
paths=set(git('ls-files').splitlines());paths.update(git('ls-files','--others','--exclude-standard').splitlines())
d={'root':str(root),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--short'),'diff':git('diff','--binary'),'files':[item(root/p) for p in sorted(paths) if (root/p).is_file()],'build':[item(p) for p in sorted((root/'dist').rglob('*')) if p.is_file()]}
dest.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
