# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase1-observability.spec.ts >> numeric capture observes native committed rows in the browser without changing one-record saves
- Location: tests/e2e/phase1-observability.spec.ts:22:1

# Error details

```
Error: page.evaluate: Error: Independent phase1 expectation failed
    at DT (http://127.0.0.1:40091/assets/harness-DIpj08Su.js:75:53136)
    at Object.MT [as profile] (http://127.0.0.1:40091/assets/harness-DIpj08Su.js:75:56722)
    at async <anonymous>:396:30
```