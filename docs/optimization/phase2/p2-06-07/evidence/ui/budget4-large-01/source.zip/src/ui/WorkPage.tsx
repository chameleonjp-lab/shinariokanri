import {useScenarioStore,useAuthorScope} from './StoreContext';
import { useAuthorField, useAuthorInput, authorField, flushAuthorDraft, AuthorDraftNotice } from './authorOperation';
import { PagedSelect } from './PagedSelect';
import { WindowedList } from './WindowedList';
import {ExportCitationTools} from './ExportCitationTools';
import { ConsultationContext, EMPTY_CONSULTATION_DRAFT, hasConsultationContext, hasInvalidConsultationInteger, type ConsultationDraft } from './ConsultationContext';
import {PROJECTABLE_KINDS} from '../domain/projection';
import { resolveReuseContent } from '../domain/reuse';
import { resolvePinnedWorlds } from '../domain/pinnedWorlds';
import { projectSettingsDraft, acknowledgeSettingsDraft, settingsDraftChanged, type ProjectSettingsDraft } from './projectSettingsDraft';
import { useEffect, useRef, useState } from 'react';
import type { Entity, ProjectContent, ProjectData, ProjectSnapshot } from '../domain/types';
import { createEntity, newId, textToRichText } from '../domain/model';
import { exportProject as createExport, GENERIC_RUNTIME_PROFILE, RUNTIME_EXPORT_TARGETS, runtimeExportProfileForTarget, type ExportProfile, type ExportResult } from '../domain/exports';
import { jsonBytes, sha256, type AssetInput } from '../storage';
import { prepareAsset } from '../domain/attachments';
import { EmptyState, Icon, Modal, downloadBytes, safeFileName } from './components';
import { dataOf, labelOf, JsonField, RefList } from './Fields';

export { BackupPanel } from './BackupPanel';
export { HistoryPanel } from './HistoryPanel';

export function ExportPanel({ project, onSave, onOpen, worldSnapshots = {} }: { project: ProjectData; worldSnapshots?:Record<string,ProjectContent>; onSave: (entity: Entity) => Promise<Entity>; onOpen: (id: string) => void }) {
  const scenarioStore=useScenarioStore();
  const key=useAuthorScope(`export:${project.projectId}`),alive=useRef(true);useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[project.projectId]);
  const [worldPins,setWorldPins]=useState<ProjectSnapshot[]>([]);useEffect(()=>{let alive=true;void scenarioStore.listWorldSnapshots().then(worlds=>{if(alive)setWorldPins(Object.values(worlds).flatMap(world=>world.snapshots));});return()=>{alive=false;};},[project.projectId,worldSnapshots]);
  const editionPins=[...project.snapshots,...worldPins];
  const profiles = project.entities.filter(e => e.kind === 'projection_profile' && !e.deletedAt);
  const [profileId, setProfileId] = useAuthorInput(key,'profileId',profiles[0]?.id || '',project.projectId,project.revision);
  const [profile, setProfile] = useAuthorInput<ExportProfile>(key,'profile','reader',project.projectId,project.revision);
  const [runtimeTarget, setRuntimeTarget] = useAuthorInput(key,'runtimeTarget',GENERIC_RUNTIME_PROFILE.profileId,project.projectId,project.revision);
  const [version, setVersion] = useAuthorInput(key,'version','',project.projectId,project.revision);
  const [assigneeId, setAssigneeId] = useAuthorInput(key,'assigneeId','',project.projectId,project.revision);
  const assignees = [...new Set(project.entities.flatMap(entity => entity.kind === 'production_task' && !entity.deletedAt && entity.data.assigneeId ? [entity.data.assigneeId] : []))];
  const [format, setFormat] = useAuthorInput<'markdown' | 'html'>(key,'format','markdown',project.projectId,project.revision);
  const [result, setResult] = useAuthorField<ExportResult | null>(key,'result',null);
  const [busy, setBusy] = useAuthorField(key,'busy',false);
  const [error, setError] = useAuthorField(key,'error','');
  const [newProfile, setNewProfile] = useAuthorField(key,'newProfile',false);
  const [included, setIncluded] = useAuthorInput<string[]>(key,'included',[],project.projectId,project.revision);
  const [publicTitle, setPublicTitle] = useAuthorInput(key,'publicTitle',project.name,project.projectId,project.revision);
  const [copyText, setCopyText] = useAuthorInput(key,'copyText',false,project.projectId,project.revision);
  const [approvedAssets,setApprovedAssets]=useAuthorInput(key,'approvedAssets',false,project.projectId,project.revision);
  const [consultationDrafts, setConsultationDrafts] = useAuthorInput<Record<string, ConsultationDraft>>(key, 'consultationDrafts', {}, project.projectId, project.revision);
  useEffect(() => { setResult(null); }, [project.revision, profileId, profile, version, format, runtimeTarget, consultationDrafts]);
  const selectedEdition=version?editionPins.find(snapshot=>snapshot.id===version)?.content:project;
  let choicesProject={...project,entities:[] as Entity[]};try{if(!selectedEdition)throw Error('参照先なし');const view=resolveReuseContent({...selectedEdition,snapshots:editionPins,history:[]} as ProjectData,editionPins),worlds=resolvePinnedWorlds(view,worldSnapshots).worlds;choicesProject={...view,entities:[...view.entities,...worlds.flatMap(world=>world.entities)]};}catch{}
  const outputProfiles=version?[...(selectedEdition?.entities??[]).filter(e=>e.kind==='projection_profile'&&!e.deletedAt),...profiles.filter(e=>e.kind==='projection_profile'&&e.data.sourceVersionId===version&&!selectedEdition?.entities.some(old=>old.id===e.id))]:profiles;
  const consultationKey = `${version || project.projectId}:${profileId}`;
  const consultationDraft = consultationDrafts[consultationKey] ?? EMPTY_CONSULTATION_DRAFT;
  const selectedPolicy = outputProfiles.find((entity): entity is Entity<'projection_profile'> => entity.kind === 'projection_profile' && entity.id === profileId);
  const consultationBinding = `${consultationKey}:${project.revision}:${selectedEdition?.revision ?? 'missing'}:${selectedPolicy?.revision ?? 'missing'}`;
  const changeConsultationDraft = (draft: ConsultationDraft) => setConsultationDrafts(previous => ({ ...previous, [consultationKey]: draft }));
  const preview = async () => {
    if (authorField<boolean>(key, 'busy')) return;
    setBusy(true); setError('');
    const submitted = structuredClone(project), registry = structuredClone(worldSnapshots), context = structuredClone(consultationDraft);
    const request = { profile, projectionProfileId: profileId, ...(version ? { targetVersionId: version } : { targetRevision: project.revision }), readerFormat: format,
      ...(['runtime_json', 'playable_preview'].includes(profile) ? { runtimeProfile: runtimeExportProfileForTarget(runtimeTarget) } : {}),
      ...(['production', 'localization'].includes(profile) && assigneeId ? { assigneeId } : {}),
      ...(profile === 'consultation' && hasConsultationContext(context) ? { consultationContext: { focusIds: context.focusIds, beforeValues: context.beforeValues, afterValues: context.afterValues } } : {}) };
    try {
      if (profile === 'consultation' && hasInvalidConsultationInteger(context)) throw Error('整数の入力途中です。文字を保持したので、入力を完成してから再確認してください。');
      if (profile === 'consultation' && hasConsultationContext(context) && context.confirmedBinding !== consultationBinding) throw Error('選択した版・公開範囲の前後状態を再確認してください。入力は保持しています。');
      await flushAuthorDraft(key);
      const worldPins = Object.values(await scenarioStore.listWorldSnapshots()).flatMap(world => world.snapshots), assetBytes: Record<string, Uint8Array> = {};
      if (['runtime_json', 'playable_preview', 'production', 'localization'].includes(request.profile)) {
        const editions = [submitted, ...submitted.snapshots.map(pin => pin.content), ...Object.values(registry)], policies = editions.flatMap(edition => edition.entities.filter((entity): entity is Entity<'projection_profile'> => entity.kind === 'projection_profile' && !entity.deletedAt)), approved = new Set(policies.flatMap(policy => policy.data.includedIds));
        for (const entity of editions.flatMap(edition => edition.entities)) if (entity.kind === 'attachment' && approved.has(entity.id) && !assetBytes[entity.data.contentHash]) { const bytes = await scenarioStore.getAsset(entity.data.contentHash); if (bytes) assetBytes[entity.data.contentHash] = bytes; }
      }
      const exported = await createExport(submitted, { ...request, worldSnapshots: registry, worldPins, assetBytes });
      const latestContext = authorField<Record<string, ConsultationDraft>>(key, 'consultationDrafts')?.[consultationKey] ?? EMPTY_CONSULTATION_DRAFT;
      if (profile === 'consultation' && JSON.stringify(latestContext) !== JSON.stringify(context)) throw Error('出力中に相談の入力が変わりました。新しい入力を保持したので、内容を再確認して出力してください。');
      setResult(exported);
    } catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  };
  const createProfile = async () => {
    if(authorField<boolean>(key,'busy'))return;setBusy(true); setError('');const sourceChoices=structuredClone(choicesProject),sourceIds=[...included],sourceTitle=publicTitle,sourceCopy=copyText,sourceAssetApproval=approvedAssets,sourceVersion=version,sourceProjectId=project.projectId;
    try {
      await flushAuthorDraft(key);
      const byEntityId: Record<string, { mode: 'replace'; replacement: string }> = {}, publicTexts: Record<string, any> = {},blockSources:Record<string,string>={},publicValues:Record<string,Record<string,string>>={},embeddedPublicIds:string[]=[];
      sourceIds.forEach(id => { const e = sourceChoices.entities.find(v => v.id === id); if (!e) return; byEntityId[id] = { mode: 'replace', replacement: e.name };if(e.kind==='flow_node'&&e.data.trigger?.id)embeddedPublicIds.push(e.data.trigger.id); if (sourceCopy) { const data = dataOf(e), output: Record<string, unknown> = {}; ['summary', 'body', 'text', 'description', 'question', 'intent', 'caption', 'usageNotes', 'interpretation', 'label', 'reading', 'terminalReason', 'reason', 'key', 'canonical', 'language', 'locale', 'sourceHash', 'expression', 'method', 'locator', 'predicate', 'cueType', 'precision', 'displayName', 'relationType', 'eventKey','blockingReason','mechanic','action','tutorial','intentionalDifference','excerptLocation','firstPerson','addressing','phrasing','examples'].forEach(k => { if(data[k]!=null){const value=structuredClone(data[k]);if(Array.isArray(value))for(const block of value)if(block&&typeof block.id==='string'&&typeof block.text==='string'){const origin=block.id;block.id=newId();blockSources[block.id]=origin;}output[k]=value;} });if(data.variants)output.variants=JSON.stringify(data.variants);if(data.estimate){output.estimateAssumptions=JSON.stringify(data.estimate.assumptions);output.estimateSource=data.estimate.source;output.estimateUnit=data.estimate.unit;}if(data.camera)output.camera=JSON.stringify(data.camera);if(data.parameters?.length)output.parameters=JSON.stringify(Object.fromEntries(data.parameters.map((param:any)=>[param.key,param.key])));if(data.resetRules?.length)output.resetReason=data.resetRules.map((rule:any)=>rule.reason||'宣言した初期化').join(' / ');if(data.exclusions?.length)output.exclusionReason=data.exclusions.map((rule:any)=>rule.reason).join(' / ');if(data.exceptionDetails||data.exceptions?.length||data.transitionRules?.some((rule:any)=>rule.exceptionDetails))output.exceptionReason='作者が確認した範囲・期限・根拠付き例外';publicTexts[id] = output;const values=e.kind==='variable'?e.data.allowed.values:e.kind==='external_contract'?e.data.stubValues?.flatMap(value=>value.type==='enum'?[value.value]:[]):e.kind==='assertion'&&typeof e.data.value==='object'&&e.data.value.type==='enum'?[e.data.value.value]:[];if(values?.length)publicValues[e.id]=Object.fromEntries(values.filter(value=>typeof value==='string').map(value=>[String(value),String(value)])); } });
      const entity = createEntity(sourceProjectId, 'projection_profile', `${sourceTitle} · 公開範囲`, { audience: '読者', includedIds: sourceIds, allowedKinds: [...new Set(sourceIds.map(id => sourceChoices.entities.find(e => e.id === id)!.kind))], publicTitle:sourceTitle, namePolicy: { defaultPolicy: { mode: 'exclude' }, byEntityId }, publicTexts,blockSources,publicValues, publicIds:Object.fromEntries([...sourceIds,...Object.keys(blockSources),...embeddedPublicIds].map(id=>[id,newId()])), ...(sourceVersion?{sourceVersionId:sourceVersion}:{}),includeAuthorNotes: false,approvedAttachmentIds:sourceAssetApproval?sourceIds.filter(id=>sourceChoices.entities.find(entity=>entity.id===id)?.kind==='attachment'):[] });
      const saved = await onSave(entity); setProfileId(saved.id); setNewProfile(false); if(alive.current)onOpen(saved.id);
    } catch (e) { setError((e as Error).message); }
    finally { setBusy(false); }
  };
  const runtimeTargetControls = ['runtime_json', 'playable_preview'].includes(profile) && <section aria-label="制作対応先の宣言">
    <label>制作の対応先<select aria-label="制作の対応先" value={runtimeTarget} onChange={event => { setRuntimeTarget(event.target.value); setResult(null); }}>{RUNTIME_EXPORT_TARGETS.map(target => <option key={target.id} value={target.id}>{target.label}{target.implemented ? '（実装済み）' : '（未対応：互換検査のみ）'}</option>)}</select></label>
    <div className="table-scroll"><table className="runtime-target-compatibility"><caption>制作対応先の宣言</caption><thead><tr><th>対応先</th><th>変換</th><th>検証範囲</th></tr></thead><tbody>{RUNTIME_EXPORT_TARGETS.map(target => <tr key={target.id}><th scope="row">{target.label}</th><td>{target.implemented ? '実装済み' : '未対応'}</td><td>{target.verificationScope}</td></tr>)}</tbody></table></div>
    <p className="field-hint">汎用runtimeの形式は {GENERIC_RUNTIME_PROFILE.schemaVersion}、実行仕様は {GENERIC_RUNTIME_PROFILE.profileVersion} です。外部コマンドの実行を代行せず、未対応先へ自動変換しません。本文だけを持ち出す場合は、公開範囲を確認して読み手向け本文を選んでください。</p>
  </section>;
  return <section className="export-panel"><AuthorDraftNotice scope={key} revision={project.revision}/><div className="info-notice">公開・制作・相談用の出力は、選択した範囲と公開文を使って作成します。完全復元には「完全保存」を使用してください。</div>{!profiles.length && <EmptyState icon="folder" title="出力する範囲を選びましょう" action={<button className="button primary" onClick={() => setNewProfile(true)}><Icon name="plus"/>公開範囲を作成</button>}>対象と公開用の名前・文章を指定してから出力します。</EmptyState>}
    {profiles.length > 0 && <><fieldset disabled={busy} className="reader-setup-fields" style={{border:0,padding:0}}><PagedSelect label="出力する公開範囲" scope={`${key}:profiles`} items={outputProfiles.map(p=>({id:p.id,label:p.name}))} value={profileId} onChange={setProfileId}/><label>出力目的<select value={profile} aria-label="出力目的" onChange={e => setProfile(e.target.value as ExportProfile)}><option value="reader">読み手向け本文</option><option value="runtime_json">汎用ランタイムJSON</option><option value="localization">翻訳・収録</option><option value="production">制作の受渡し</option><option value="consultation">手動相談用</option><option value="playable_preview">単体の試遊出力</option></select></label>{runtimeTargetControls}<PagedSelect label="出力する作品版" scope={`${key}:versions`} items={editionPins.map(s=>({id:s.id,label:s.versionLabel}))} value={version} onChange={setVersion} emptyLabel={`編集稿の現在版 ${project.revision}`}/>{['production', 'localization'].includes(profile) && <PagedSelect label="制作の担当範囲" scope={`${key}:assignees`} value={assigneeId} onChange={id => { setAssigneeId(id); setResult(null); }} emptyLabel="公開範囲に含めた全担当" items={assignees.map(id => ({ id, label: id }))}/>}{profile === 'reader' && <label>ファイル形式<select value={format} aria-label="本文の出力形式" onChange={e => setFormat(e.target.value as 'markdown' | 'html')}><option value="markdown">Markdown</option><option value="html">HTML</option></select></label>}{profile === 'consultation' && <ConsultationContext project={choicesProject} policy={selectedPolicy} draft={consultationDraft} binding={consultationBinding} scope={`${key}:${consultationKey}`} onChange={changeConsultationDraft}/>}</fieldset><div className="backup-actions"><button className="button primary" disabled={!profileId || busy || !!version&&!project.snapshots.some(pin=>pin.id===version)} onClick={() => void preview()}>{busy ? '出力を検査中' : '内容を検査・プレビュー'}</button><button className="button secondary" onClick={() => onOpen(profileId)} disabled={busy||!profileId||!!version}>現在稿の範囲を編集</button><button className="text-button" disabled={busy} onClick={() => setNewProfile(true)}><Icon name="plus" size={16}/>新しい範囲</button></div></>}
    <ExportCitationTools project={project} profileId={profileId} pins={editionPins} onSave={onSave}/>{version&&!project.snapshots.some(pin=>pin.id===version)&&<p className="info-notice">世界の固定版を選択中です。その引用用公開範囲を作成してから、作品版の公開範囲へ引用承認を結び付けてください。</p>}
    {error && <div className="error-notice" role="alert">{error}</div>}{result && <div className="export-result">{result.preview?.runtimeTarget && <p className="info-notice runtime-target-result">検査した対応先：<code>{result.preview.runtimeTarget.profileId}</code> · {result.preview.runtimeTarget.implemented ? "実装済み" : "変換未対応"} · runtime仕様 {result.preview.runtimeTarget.profileVersion} / 形式 {result.preview.runtimeTarget.schemaVersion}<br/>{result.preview.runtimeTarget.verificationScope}</p>}{!result.ok ? <div className="error-notice" role="alert"><strong>出力を停止しました</strong><ul>{result.issues.map((issue, i) => <li key={i} className="export-issue"><code className="export-issue-code">{issue.code}</code> {issue.message}{issue.field && <> · 項目 <code className="export-issue-field">{issue.field}</code></>}{issue.entityId && <> · 対象ID <code className="export-issue-entity">{issue.entityId}</code></>}{issue.entityId && <button className="text-button" onClick={() => onOpen(issue.entityId!)}>対象を開く</button>}</li>)}</ul></div> : <><div className="section-heading"><h3>出力内容の確認</h3><span>{result.preview.includedCount}件 · {result.preview.profile} · 元の版 {result.preview.sourceRevision} / {result.preview.sourceVersionId}</span></div>{result.preview.sourceVersionId===project.projectId&&result.preview.sourceRevision!==project.revision&&<p role="alert">プレビュー取得後に現在稿が更新されました。このファイルは表示した元の版の内容です。現在稿の出力は再検査してください。</p>}{result.preview.warnings.map((w, i) => <p className="info-notice" key={i}>{w}</p>)}<details className="advanced-details"><summary>出力から除かれる内容（{result.preview.omissions.length}件）</summary>{result.preview.omissions.map((o, i) => <p className="field-hint" key={i}>{labelOf(project.entities.find(e => e.id === o.entityId))} {o.field || ''} · {o.reason}</p>)}</details>{result.artifacts.map(artifact => <div className="export-artifact" key={artifact.filename}><h4>{artifact.filename}</h4><pre className="export-preview-text">{artifact.content.slice(0, 6000)}{artifact.content.length > 6000 ? '\n… プレビューはここまで。保存ファイルには全内容を含みます。' : ''}</pre><button className="button primary" onClick={() => downloadBytes((artifact.bytes ?? artifact.content) as BlobPart, artifact.filename, artifact.mimeType)}><Icon name="download" size={18}/>この内容を保存</button></div>)}</>}</div>}
    {newProfile && <Modal title="公開する範囲を作成" wide onClose={() => {if(!busy)setNewProfile(false);}}><fieldset disabled={busy}><PagedSelect label="公開範囲の元作品版" scope={`${key}:profile-source`} items={editionPins.map(pin=>({id:pin.id,label:pin.versionLabel}))} value={version} onChange={id=>{setVersion(id);setIncluded([]);}} emptyLabel={`編集稿の現在版 ${project.revision}`}/><div className="form-field"><label htmlFor="new-export-public-title">公開用の作品名</label><input id="new-export-public-title" value={publicTitle} onChange={e => setPublicTitle(e.target.value)}/></div><div className="form-field"><label>出力する対象</label><RefList project={choicesProject} kinds={[...PROJECTABLE_KINDS]} value={included} onChange={setIncluded}/></div><label className="check-label"><input type="checkbox" checked={copyText} onChange={e => setCopyText(e.target.checked)}/>選んだ対象の本文・表記を公開文へコピーする</label><label className="check-label"><input type="checkbox" checked={approvedAssets} onChange={event=>setApprovedAssets(event.target.checked)}/>選択素材をこの公開範囲で再配布できることを確認した</label><p className="field-hint">名前は現在の表示名を公開名として登録します。コピー後、公開範囲の詳細で公開名と文章を確認・編集できます。作者メモはコピーしません。</p><div className="modal-actions"><button className="button secondary" onClick={() => setNewProfile(false)}>中止</button><button className="button primary" disabled={busy || !included.length || !publicTitle.trim()} onClick={() => void createProfile()}>範囲を作成して内容を確認</button></div></fieldset></Modal>}
  </section>;
}

export function ProjectInfo({ project, initialDraft, saving = false, onDraftChange, onDraftSaved, onSavingChange, onSaveProject, onSaveEntities, onOpen, theme, setTheme }: { project: ProjectData; initialDraft?: ProjectSettingsDraft; saving?: boolean; onDraftChange?: (draft: ProjectSettingsDraft) => void; onDraftSaved?: (submitted: ProjectSettingsDraft, saved: ProjectData, consumedSnapshotName?: string) => void; onSavingChange?: (saving: boolean) => void; onSaveProject: (project: ProjectData, reason: string) => Promise<ProjectData>; onSaveEntities: (entities: Entity[], reason: string, assets?: AssetInput[]) => Promise<void>; onOpen: (id: string) => void; theme: string; setTheme: (theme: string) => void }) {
  const scenarioStore=useScenarioStore();
  const [draft, setDraft] = useState(() => initialDraft ?? projectSettingsDraft(project));
  const draftRef = useRef(draft); draftRef.current = draft;
  const { name, mainStart, calendars: calendarJson, calendarValid, snapshotName } = draft;
  const change = (value: Partial<ProjectSettingsDraft>) => {
    const next = { ...draftRef.current, ...value }; draftRef.current = next; setDraft(next); onDraftChange?.(next);
  };
  const setName = (name: string) => change({ name }), setMainStart = (mainStart: string) => change({ mainStart }), setSnapshotName = (snapshotName: string) => change({ snapshotName });
  const setCalendarJson = (calendars: unknown) => change({ calendars }), setCalendarValid = (calendarValid: boolean) => { if (calendarValid !== draftRef.current.calendarValid) change({ calendarValid }); };
  const [error, setError] = useState(''); const [notice, setNotice] = useState(''); const [busy, setBusy] = useState(false);
  const previousInitial = useRef(initialDraft);
  const operation = useRef(false), stale = settingsDraftChanged(draft) && draft.base.revision !== project.revision;
  useEffect(() => {
    const prior = previousInitial.current; previousInitial.current = initialDraft;
    const next = initialDraft ?? (prior || !settingsDraftChanged(draftRef.current) ? projectSettingsDraft(project) : undefined);
    if (next && JSON.stringify(next) !== JSON.stringify(draftRef.current)) { draftRef.current = structuredClone(next); setDraft(draftRef.current); }
  }, [initialDraft, project.projectId, project.revision]);
  const save = async () => {
    if (operation.current || saving || stale) return;
    operation.current = true; setBusy(true); onSavingChange?.(true); setError(''); setNotice('');
    const submitted = structuredClone(draftRef.current);
    try {
      const saved = await onSaveProject({ ...project, revision: submitted.base.revision, name: submitted.name, mainStart: submitted.mainStart, calendars: submitted.calendars as ProjectData['calendars'] }, '作品名・時間の基準を変更');
      onDraftSaved?.(submitted, saved);
      const next = acknowledgeSettingsDraft(draftRef.current, submitted, saved); draftRef.current = next; setDraft(next);
      setNotice('作品の設定を端末内に保存しました。出来事の日時は維持されています。');
    } catch (e) { setError((e as Error).message); }
    finally { operation.current = false; setBusy(false); onSavingChange?.(false); }
  };
  const snapshot = async () => {
    if (operation.current || saving) return;
    operation.current = true; onSavingChange?.(true);
    const submitted = { ...projectSettingsDraft(project), snapshotName: draftRef.current.snapshotName };
    setBusy(true); setError(''); setNotice('');
    try { const { history: _history, snapshots: _snapshots, authorAlternatives: _authorAlternatives, ...content } = structuredClone(project); const id = newId(), hash = await sha256(jsonBytes(content)); const frozen: ProjectSnapshot = { id, contentHash: hash, versionLabel: snapshotName || `確定版 ${project.revision}`, createdAt: new Date().toISOString(), content }; const meta = { ...createEntity(project.projectId, 'snapshot', frozen.versionLabel, { versionLabel: frozen.versionLabel, contentHash: hash, immutable: true }), id }; const saved = await onSaveProject({ ...project, snapshots: [...project.snapshots, frozen], entities: [...project.entities, meta] }, '確定版を保存'); setNotice('本文と設定の確定版を不変の保存内容として記録しました。'); onDraftSaved?.(submitted, saved, submitted.snapshotName); const next = acknowledgeSettingsDraft(draftRef.current, submitted, saved, submitted.snapshotName); draftRef.current = next; setDraft(next); }
    catch (e) { setError((e as Error).message); }
    finally { operation.current = false; onSavingChange?.(false); setBusy(false); }
  };
  const addAsset = async (file: File) => {
    if (!file.size || file.size > 32 * 1024 * 1024) { setError('添付は1 byte〜32 MiBです。選択した素材は読み込まず、保存済みの作品を保持しています。'); return; }
    if (operation.current || saving) return; operation.current = true; onSavingChange?.(true);
    setBusy(true); setError(''); setNotice('');
    try { const prepared = await prepareAsset(new Uint8Array(await file.arrayBuffer()), file.name); const { bytes, preview: _preview, ...metadata } = prepared; const entity = createEntity(project.projectId, 'attachment', file.name, { ...metadata, stage: 'reference' }); await onSaveEntities([entity], '添付素材を追加', [{ ...prepared, bytes }]); setNotice('素材と内容を端末内に保存しました。'); onOpen(entity.id); }
    catch (e) { setError((e as Error).message); }
    finally { operation.current = false; onSavingChange?.(false); setBusy(false); }
  };
  return <section className="project-info">{settingsDraftChanged(draft) && <p className="info-notice" role="status">作品設定の未保存入力を保持しています。基底版 {draft.base.revision}</p>}{stale && <div className="error-notice" role="alert"><p>別の変更が保存されました。入力と現在版の差分を確認してください。</p><dl><dt>作品名（基底 → 現在 → 入力）</dt><dd>{draft.base.name} → {project.name} → {name}</dd><dt>本編開始</dt><dd>{draft.base.mainStart} → {project.mainStart} → {mainStart}</dd><dt>暦</dt><dd>基底 {draft.base.calendars.length}件・現在 {project.calendars.length}件</dd></dl><button type="button" className="button secondary" disabled={busy || saving} onClick={() => change({ base: projectSettingsDraft(project).base, name: name === draft.base.name ? project.name : name, mainStart: mainStart === draft.base.mainStart ? project.mainStart : mainStart, calendars: JSON.stringify(calendarJson) === JSON.stringify(draft.base.calendars) ? project.calendars : calendarJson })}>差分を確認して現在版を基底にする</button></div>}<div className="settings-card"><h3>作品の情報</h3><div className="form-field"><label htmlFor="project-name">作品名</label><input id="project-name" value={name} onChange={e => setName(e.target.value)}/></div><div className="form-field"><label htmlFor="project-start">本編開始の世界内tick</label><input id="project-start" inputMode="numeric" value={mainStart} onChange={e => setMainStart(e.target.value)}/><span className="field-hint">基準点だけを変更します。出来事の絶対日時は変わりません。</span></div><div className="form-field"><label>使用する暦</label><select value={project.calendarId} aria-label="作品の暦" disabled><option>{project.calendars.find(c => c.id === project.calendarId)?.name}</option></select></div><details className="advanced-details"><summary>暦の定義を編集</summary><p className="field-hint">独自暦を定義できます。現在のcalendarIdは維持し、日時のラベルだけを変更します。日時の換算・連動移動の操作は未対応です。</p><JsonField label="暦の定義" value={calendarJson} rawOverride={draft.calendarRaw} onInvalidRaw={calendarRaw => change({ calendarRaw })} onChange={setCalendarJson} onValid={setCalendarValid}/></details><button className="button primary" disabled={busy || saving || stale || !calendarValid} onClick={() => void save()}>作品の設定を保存</button></div>
    <div className="settings-card"><h3>確定版を残す</h3><p className="field-hint">現在の本文と設定を固定します。後の編集はこの内容を変更しません。</p><div className="form-field"><label>版の名称</label><input value={snapshotName} placeholder={`確定版 ${project.revision}`} onChange={e => setSnapshotName(e.target.value)} aria-label="確定版の名称"/></div><button className="button secondary" disabled={busy || saving} onClick={() => void snapshot()}>現在の内容を確定版として保存</button><WindowedList items={project.snapshots} scope={`${project.projectId}:settings:snapshots`} label="作品の確定版" searchText={s => `${s.versionLabel} ${s.createdAt}`} render={s => <div className="snapshot-item" key={s.id}><Icon name="folder"/><span><strong>{s.versionLabel}</strong><small>{new Date(s.createdAt).toLocaleString('ja-JP')}</small></span></div>}/></div>
    <div className="settings-card"><h3>素材を追加</h3><p className="field-hint">PNG・JPEG・GIF・WebP・WAV・MP3・PDFを作品へ添付します。種類と容量を検査して保存します。</p><label className="button secondary file-button"><Icon name="upload" size={18}/>素材ファイルを選ぶ<input type="file" disabled={busy || saving} onChange={e => { const file = e.target.files?.[0]; e.target.value = ''; if (file) void addAsset(file); }}/></label></div>
    <div className="settings-card"><h3>表示設定</h3><div className="theme-options">{[['light', '明るい配色'], ['dark', '暗い配色'], ['system', '端末に合わせる']].map(([v, label]) => <label className="check-label" key={v}><input type="radio" name="theme" checked={theme === v} onChange={() => setTheme(v)}/>{label}</label>)}</div></div>{error && <div className="error-notice" role="alert">{error}</div>}{notice && <div className="success-notice" role="status">{notice}</div>}
  </section>;
}

