import {ARCHIVE_LIMITS,canonicalJson,parseStrictJson,sha256} from './json';
import {StorageError,checkCancelled} from './errors';
// Nonnegative integers address objects; negative integers address strings.
// Authored numeric values use an explicit tag and cannot become references.
type Atom=null|boolean|number|{number:number}|{undefined:true};
type Node=(Atom|number)[];
export interface RecordPart{key:string;scope:string;sequence:number;kind:'strings'|'nodes';bytes:Uint8Array;sha256:string}
export interface PackedRecord{version:1;scope:string;root:Atom;nodes:number;strings:number;parts:{key:string;kind:RecordPart['kind'];bytes:number;sha256:string}[]}
const MAX_PART=8*1024*1024,MAX_TOTAL=256*1024*1024,MAX_NODES=4_000_000;
/** @internal The existing v1 total, also checked when repartitioning imports. */
export const RECORD_PART_TOTAL_LIMIT=MAX_TOTAL;
const invalid=():never=>{throw new StorageError('SAVE_FAILED','大きな履歴の分割記録が破損しています。既存データを保持しています。');};
const generatedStringify=JSON.stringify,generatedDescriptor=Object.getOwnPropertyDescriptor,generatedPrototype=Object.getPrototypeOf;
const generatedObjectPrototype=Object.prototype,generatedArrayPrototype=Array.prototype,generatedNumberPrototype=Number.prototype;
function nativeGeneratedJsonIsSafe():boolean{
 return JSON.stringify===generatedStringify
  && generatedPrototype(generatedObjectPrototype)===null
  && generatedPrototype(generatedArrayPrototype)===generatedObjectPrototype
  && generatedDescriptor(generatedObjectPrototype,'toJSON')===undefined
  && generatedDescriptor(generatedArrayPrototype,'toJSON')===undefined
  && generatedDescriptor(generatedNumberPrototype,'toJSON')===undefined;
}
/** Serialize only the private nodes emitted by atom(). Raw author strings live in the separate strings table. */
const canonicalGeneratedNode=(node:Node):string=>{
 const atomText=(value:Atom|number):string=>{
  if(value===null)return'null';
  if(typeof value==='boolean')return value?'true':'false';
  if(typeof value==='number')return Number.isFinite(value)?JSON.stringify(value)!:canonicalJson(value);
  if(value&&typeof value==='object'&&!Array.isArray(value)){
   const keys=Object.keys(value),tag=value as {number?:unknown;undefined?:unknown};
   if(keys.length===1&&keys[0]==='undefined'&&Object.hasOwn(value,'undefined')&&tag.undefined===true)return'{"undefined":true}';
   if(keys.length===1&&keys[0]==='number'&&Object.hasOwn(value,'number')&&typeof tag.number==='number'&&Number.isFinite(tag.number))return'{"number":'+JSON.stringify(tag.number)!+'}';
  }
  return canonicalJson(value);
 };
 const values:string[]=[];
 for(let index=0;index<node.length;index++)values.push(atomText(node[index]!));
 return'['+values.join(',')+']';
};
/** Local clone graph with shared strings. Complete values, identity aliases,
 * array order and present undefined are retained; no history is summarized. */
async function packRecordDataInternal(value:unknown,scope:string,signal:AbortSignal|undefined,workerPlainData:boolean):Promise<{packed:PackedRecord;parts:RecordPart[]}>{
 checkCancelled(signal);const nodes:Node[]=[],ids=new WeakMap<object,number>(),active=new WeakSet<object>(),strings:string[]=[],stringIds=new Map<string,number>();
 const string=(v:string)=>{let id=stringIds.get(v);if(id===undefined){id=strings.length;strings.push(v);stringIds.set(v,id);}return id;};
 const atom=(v:unknown):Atom=>{if(v===undefined)return{undefined:true};if(typeof v==='string')return-string(v)-1;if(typeof v==='number'){if(!Number.isFinite(v))return invalid();return{number:v};}if(v===null||typeof v==='boolean')return v;if(!v||typeof v!=='object'||!Array.isArray(v)&&Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null)return invalid();const known=ids.get(v);if(known!==undefined){if(active.has(v))return invalid();return known;}const id=nodes.length;if(id>=MAX_NODES)return invalid();ids.set(v,id);active.add(v);const node:Node=[Array.isArray(v)?0:1];nodes.push(node);if(Array.isArray(v)){if(Object.keys(v).length!==v.length)return invalid();if(workerPlainData){for(let index=0;index<v.length;index++)node.push(atom(v[index]));}else for(const item of v)node.push(atom(item));}else if(workerPlainData){for(const key of Object.keys(v))node.push(string(key),atom((v as Record<string,unknown>)[key]));}else for(const [key,item]of Object.entries(v))node.push(string(key),atom(item));active.delete(v);return id;};
 const root=atom(value),parts:RecordPart[]=[];let total=0;const encoder=new TextEncoder();
 // Generated nodes contain only indices, booleans, null and our one-key
 // numeric/undefined tags. Raw author strings still use canonicalJson. Check
 // inherited hooks and the intrinsic again after every asynchronous digest.
 let nativeGeneratedJson=workerPlainData&&nativeGeneratedJsonIsSafe();
 for(const [kind,items]of [['strings',strings],['nodes',nodes]] as const){let itemTexts:string[]=[],size=0;const emit=async()=>{if(!itemTexts.length)return;checkCancelled(signal);const bytes=encoder.encode(`[${itemTexts.join(',')}]`);total+=bytes.byteLength;if(bytes.byteLength>MAX_PART||total>MAX_TOTAL)throw new StorageError('LIMIT_EXCEEDED','履歴の分割記録が端末の安全上限を超えています。');const sequence=parts.length;parts.push({key:`${scope}:${sequence}`,scope,sequence,kind,bytes,sha256:await sha256(bytes)});checkCancelled(signal);nativeGeneratedJson=workerPlainData&&nativeGeneratedJsonIsSafe();itemTexts=[];size=0;};for(const item of items){const text=kind==='nodes'?(nativeGeneratedJson?generatedStringify(item)!:canonicalGeneratedNode(item as Node)):canonicalJson(item),length=kind==='nodes'?text.length:workerPlainData?utf8Length(text):encoder.encode(text).byteLength;if(length>MAX_PART)return invalid();if(itemTexts.length&&size+length+itemTexts.length+2>MAX_PART/4)await emit();itemTexts.push(text);size+=length;}await emit();}
 checkCancelled(signal);return{packed:{version:1,scope,root,nodes:nodes.length,strings:strings.length,parts:parts.map(p=>({key:p.key,kind:p.kind,bytes:p.bytes.byteLength,sha256:p.sha256}))},parts};
}

// canonicalJson has already rejected isolated surrogates. Count the exact
// UTF-8 bytes without allocating one temporary Uint8Array per table string.
function utf8Length(text:string):number{
 let bytes=0;for(let index=0;index<text.length;index++){
  const unit=text.charCodeAt(index);
  if(unit<0x80)bytes++;else if(unit<0x800)bytes+=2;
  else if(unit>=0xd800&&unit<=0xdbff){bytes+=4;index++;}else bytes+=3;
 }return bytes;
}
/** Preserve public getter/iterator evaluation order on uncaptured inputs. */
export function packRecordData(value:unknown,scope:string,signal?:AbortSignal){return packRecordDataInternal(value,scope,signal,false);}
/** Internal: only a dedicated worker's structured-cloned message. No caller
 * getters, Proxy or custom iterators can cross that transport. Read each own
 * value in key order without allocating an entries pair per property. All
 * tags, node/string order, exact part boundaries, guards and v1 bytes stay the
 * same. This path is never selected for direct public/Node callers. */
export function packWorkerRecordData(value:unknown,scope:string,signal?:AbortSignal){return packRecordDataInternal(value,scope,signal,true);}
export async function unpackRecordData(packed:PackedRecord,parts:RecordPart[],signal?:AbortSignal):Promise<unknown>{
 checkCancelled(signal);if(packed.version!==1||typeof packed.scope!=='string'||!Number.isSafeInteger(packed.nodes)||packed.nodes<0||packed.nodes>MAX_NODES||!Number.isSafeInteger(packed.strings)||packed.strings<0||packed.strings>MAX_NODES||!Array.isArray(packed.parts)||packed.parts.length!==parts.length||new Set(parts.map(p=>p.key)).size!==parts.length)return invalid();
 // Hash and parse the same private bytes. Callers can retain and mutate their
 // inputs while the asynchronous digest is pending, including outside workers.
 let capturedBytes=0;for(const part of parts){if(!(part.bytes instanceof Uint8Array)||part.bytes.byteLength>MAX_PART)return invalid();capturedBytes+=part.bytes.byteLength;if(capturedBytes>MAX_TOTAL)return invalid();}
 packed=structuredClone(packed);parts=parts.map(part=>({...part,bytes:new Uint8Array(part.bytes)}));
 const nodes:Node[]=[],strings:string[]=[],index=new Map(parts.map(p=>[p.key,p]));let total=0;
 for(const [sequence,expected]of packed.parts.entries()){checkCancelled(signal);const part=index.get(expected.key);if(!part||part.scope!==packed.scope||part.sequence!==sequence||expected.key!==`${packed.scope}:${sequence}`||!['strings','nodes'].includes(expected.kind)||part.kind!==expected.kind||!(part.bytes instanceof Uint8Array)||part.bytes.byteLength!==expected.bytes||expected.bytes>MAX_PART||part.sha256!==expected.sha256||!/^([a-f0-9]{64})$/.test(expected.sha256)||await sha256(part.bytes)!==expected.sha256)return invalid();total+=expected.bytes;if(total>MAX_TOTAL)return invalid();const group=parseStrictJson(part.bytes,part.key,{...ARCHIVE_LIMITS,jsonBytes:MAX_PART,expandedBytes:MAX_TOTAL});if(!Array.isArray(group))return invalid();if(part.kind==='strings'){if(strings.length+group.length>packed.strings||group.some(v=>typeof v!=='string'))return invalid();for(const item of group)strings.push(item);}else{if(nodes.length+group.length>packed.nodes)return invalid();for(const node of group)nodes.push(node as Node);}}
 if(nodes.length!==packed.nodes||strings.length!==packed.strings||new Set(strings).size!==strings.length)return invalid();
 const usedStrings=new Set<number>(),string=(id:number)=>{if(!Number.isSafeInteger(id)||id<0||id>=strings.length)return invalid();usedStrings.add(id);return strings[id]!;};
 const ref=(v:Atom):number|undefined=>{if(v===null||typeof v==='boolean')return;if(typeof v==='number'){if(!Number.isSafeInteger(v))return invalid();if(v<0){string(-v-1);return;}if(v>=nodes.length)return invalid();return v;}if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==1)return invalid();if('undefined'in v&&v.undefined===true)return;if('number'in v&&typeof v.number==='number'&&Number.isFinite(v.number))return;return invalid();};
 const atoms=(node:Node):Atom[]=>{if(!Array.isArray(node)||node[0]!==0&&node[0]!==1)return invalid();if(node[0]===0)return node.slice(1);if(node.length%2!==1)return invalid();const keys=new Set<string>(),result:Atom[]=[];for(let i=1;i<node.length;i+=2){const key=string(node[i] as number);if(keys.has(key))return invalid();keys.add(key);result.push(node[i+1]!);}return result;};
 ref(packed.root);for(const node of nodes)for(const value of atoms(node))ref(value);
 const marks=new Uint8Array(nodes.length),root=ref(packed.root);let reachable=0;
 if(root!==undefined){const stack:{id:number;next:number}[]=[{id:root,next:1}];while(stack.length){const frame=stack.at(-1)!,node=nodes[frame.id]!;if(!marks[frame.id]){marks[frame.id]=1;reachable++;}if(frame.next>=node.length){marks[frame.id]=2;stack.pop();continue;}const position=frame.next+(node[0]===1?1:0);frame.next+=node[0]===1?2:1;const next=ref(node[position]!);if(next===undefined)continue;if(marks[next]===1||stack.length>64)return invalid();if(!marks[next])stack.push({id:next,next:1});}}
 if(reachable!==nodes.length||usedStrings.size!==strings.length)return invalid();const values:unknown[]=nodes.map(n=>n[0]===0?[]:{}),read=(v:Atom):unknown=>typeof v==='number'?v<0?string(-v-1):values[v]:v&&typeof v==='object'?'number'in v?v.number:undefined:v;
 for(const [id,node]of nodes.entries()){if(node[0]===0)for(let i=1;i<node.length;i++)(values[id] as unknown[]).push(read(node[i]!));else for(let i=1;i<node.length;i+=2)Object.defineProperty(values[id],string(node[i] as number),{value:read(node[i+1]!),enumerable:true,configurable:true,writable:true});}checkCancelled(signal);return read(packed.root);
}
/** Estimate clone size without serializing unchanged bodies on a small edit. */
export function needsRecordParts(value:unknown,limit=8*1024*1024){let size=0;const seen=new WeakSet<object>(),queue=[value];while(queue.length&&size<=limit){const v=queue.pop();if(typeof v==='string')size+=v.length*2+16;else if(v&&typeof v==='object'){if(seen.has(v))continue;seen.add(v);size+=32;for(const [key,item]of Object.entries(v)){size+=key.length*2+16;queue.push(item);}}else size+=16;}return size>limit;}
