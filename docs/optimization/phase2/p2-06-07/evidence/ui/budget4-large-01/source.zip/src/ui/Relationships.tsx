import { WindowedList } from './WindowedList';
import { memo, useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, type ReactElement, type RefObject } from 'react';
import type { CalendarDefinition, Entity, ID, ProjectData, Relation, SavedView, Tick, ViewState } from '../domain/types';
import { emptyValidity, newId, RELATION_TYPES, KIND_LABELS } from '../domain/model';
import { alignGraphPositions, buildRelationGraph, GRAPH_CATEGORY_LABELS, type GraphCategory, type GraphLine } from '../domain/relationGraph';
import { isTick } from '../domain/time';
import { labelOf } from './Fields';
import { EmptyState, Icon, Modal, StatusBadge } from './components';
import { EntityChoice, TimelinePagination, type TimelineSave, TIMELINE_PAGE_SIZE } from './TimelineEditors';
import { checkpointContext, ValidityEditor, WorldPointFields } from './WorldFields';
import { safeGraphPositions, useRelationView } from './useRelationView';
import { layoutRelationLabels, type RelationLabelPosition } from './relationGraphLabels';
import './World.css';

export interface RelationshipsProps {
  project: ProjectData; localProject?: ProjectData; onOpen: (id: ID, originProjectId?: ID) => void; onSave: (relation: Relation) => Promise<void>;
  referenceEntities?: Entity[]; referenceRelations?: Relation[]; referenceCalendars?: CalendarDefinition[];
  onSaveProject?: TimelineSave; selectedId?: ID | null; worldTick?: Tick | null;
  categoryPreset?: GraphCategory;
  checkpointId?: ID; onViewPointChange?: (at: Tick | null, checkpointId: ID) => void;
  onShowTimeline?: (entityId: ID, at?: Tick | null) => void;
}
export function EvidenceChoices({ project, value, onChange, onOpen, scope }: { scope: string; project: ProjectData; value: ID[]; onChange: (ids: ID[]) => void; onOpen?: (id: ID) => void }) {
  const index = useMemo(() => new Map(project.entities.map(entity => [entity.id, entity])), [project.entities]);
  const [revealed, setRevealed] = useState<{ scope: string; id: ID } | null>(null);
  return <div className="world-evidence"><WindowedList items={value.map(id => ({ id }))} scope={scope} label="選択済みの根拠" selectedId={revealed?.scope === scope ? revealed.id : null} searchText={({ id }) => labelOf(index.get(id))} as="ul" render={({ id }) => <li key={id}>{onOpen ? <button className="text-button" type="button" onClick={() => onOpen(id)}>{labelOf(index.get(id))}</button> : labelOf(index.get(id))}<button className="button subtle small" type="button" aria-label={`${labelOf(index.get(id))}を根拠から外す`} onClick={() => onChange(value.filter(item => item !== id))}>外す</button></li>}/><EntityChoice label="根拠として追加する情報" entities={project.entities.filter(entity => !value.includes(entity.id))} value="" onChange={id => { if (id) { onChange([...value, id]); setRevealed({ scope, id }); } }}/></div>;
}
export function RelationForm({ relation, project, onSave, onClose, onOpen }: { relation: Relation; project: ProjectData; onSave: RelationshipsProps['onSave']; onClose: () => void; onOpen: (id: ID) => void }) {
  const [draft, setDraft] = useState(() => structuredClone(relation)), [error, setError] = useState(''), [busy, setBusy] = useState(false), [valid, setValid] = useState(true);
  const definition = RELATION_TYPES.find(type => type.key === draft.relationType);
  const kindNames = (kinds: readonly Entity['kind'][]) => kinds.length > 5 ? '情報' : kinds.map(kind => KIND_LABELS[kind]).join('・');
  const source = project.entities.find(entity => entity.id === draft.fromId && !entity.deletedAt);
  const target = project.entities.find(entity => entity.id === draft.toId && !entity.deletedAt);
  const endpointReason = !definition ? 'この関係の種類は未対応です。' : !source || !definition.fromKinds.includes(source.kind)
    ? `この関係は${kindNames(definition.fromKinds)}から${kindNames(definition.toKinds)}へ結びます。存在する${kindNames(definition.fromKinds)}を始点に選んでください。`
    : !target || !definition.toKinds.includes(target.kind) ? `終点には存在する${kindNames(definition.toKinds)}を選んでください。`
    : source.id === target.id && !definition.allowSelf ? 'この関係は同じ情報同士を結べません。'
    : draft.direction === 'symmetric' && !definition.allowSymmetric ? 'この関係は一方向で指定してください。' : '';
  const update = (value: Partial<Relation>) => setDraft(previous => ({ ...previous, ...value }));
  const save = async (archived = false) => { setBusy(true); setError(''); try { await onSave(archived ? { ...draft, deletedAt: new Date().toISOString(), deletionOperationId: newId() } : draft); onClose(); } catch (cause) { setError((cause as Error).message); } finally { setBusy(false); } };
  return <Modal title="意味付きの関係を編集" onClose={() => { if (!busy) onClose(); }}><fieldset disabled={busy} className="world-save-fields"><p>始点・終点・向き・期間と経路・根拠を、この関係IDへ保存します。</p>{error && <p className="error-notice" role="alert">{error}</p>}{endpointReason && <p className="field-hint" role="status">{endpointReason}</p>}<div className="form-field"><label>関係の種類<select aria-label="関係の種類" value={draft.relationType} onChange={event => update({ relationType: event.target.value, fromId: '', toId: '', direction: 'forward' })}>{RELATION_TYPES.map(type => <option key={type.key} value={type.key}>{type.label}</option>)}</select></label></div><EntityChoice label="関係の始点" entities={project.entities.filter(entity => definition?.fromKinds.includes(entity.kind))} value={draft.fromId} onChange={fromId => update({ fromId })}/><EntityChoice label="関係の終点" entities={project.entities.filter(entity => definition?.toKinds.includes(entity.kind))} excludeId={definition?.allowSelf ? undefined : draft.fromId} value={draft.toId} onChange={toId => update({ toId })}/><label>向き<select aria-label="関係の向き" value={draft.direction} onChange={event => update({ direction: event.target.value as Relation['direction'] })}><option value="forward">始点 → 終点</option><option value="symmetric" disabled={!definition?.allowSymmetric}>対称 ←→</option></select></label><h3>有効な期間・経路</h3><ValidityEditor scope={`${project.projectId}:${draft.id}:validity`} project={project} value={draft.validity} onChange={validity => update({ validity })} onValid={setValid}/><h3>根拠</h3><EvidenceChoices scope={`${project.projectId}:${draft.id}:relation-evidence`} project={project} value={draft.evidenceIds} onChange={evidenceIds => update({ evidenceIds })} onOpen={onOpen}/><div className="modal-actions">{project.relations.some(item => item.id === draft.id) && <button className="button danger" disabled={busy} onClick={() => void save(true)}>この関係をアーカイブ</button>}<button className="button secondary" disabled={busy} onClick={onClose}>中止</button><button className="button primary" disabled={busy || !valid || !draft.fromId || !draft.toId} onClick={() => void save()}>{busy ? '保存中' : '関係を保存'}</button></div></fieldset></Modal>;
}
const bounded = (value: number) => Math.max(80, Math.min(10000, value));
function filterString(view: ViewState, key: string, fallback = '') { return typeof view.filters[key] === 'string' ? view.filters[key] as string : fallback; }
const noReferenceEntities: Entity[] = [], noReferenceRelations: Relation[] = [], noReferenceCalendars: CalendarDefinition[] = [];
type GraphDrag = { id: ID; pointer: number; originX: number; originY: number; x: number; y: number };
const GraphLineElement = memo(function GraphLineElement({ line, ax, ay, bx, by, fromLabel, toLabel, open, layer, pathId, labelX: x, labelY: y, labelWidth: width }: { line: GraphLine; ax: number; ay: number; bx: number; by: number; fromLabel: string; toLabel: string; open: (line: GraphLine) => void; layer: 'line' | 'label'; pathId: string; labelX: number; labelY: number; labelWidth: number }) {
  if (layer === 'line') return <><g id={pathId} aria-hidden="true" onClick={() => open(line)}>
    <line x1={ax} y1={ay} x2={bx} y2={by} stroke="transparent" strokeWidth="28"/><line x1={ax} y1={ay} x2={bx} y2={by} className={line.assessment.value === 'unknown' ? 'uncertain' : ''} stroke="currentColor" strokeWidth="2" strokeDasharray={line.origin === 'derived' ? '8 5' : undefined} markerEnd="url(#world-relation-arrow)" markerStart={line.direction === 'symmetric' ? 'url(#world-relation-arrow)' : undefined}/>
  </g>{(x !== (ax + bx) / 2 || y !== (ay + by) / 2 - 8) && <line x1={(ax + bx) / 2} y1={(ay + by) / 2} x2={x} y2={y - 6} stroke="currentColor" strokeWidth="1" strokeDasharray="2 3" opacity="0.45" aria-hidden="true" pointerEvents="none"/>}</>;
  const label = `${line.label}${line.assessment.value === 'unknown' ? ' · 未確認' : ''}`;
  return <g role="button" tabIndex={0} aria-controls={pathId} aria-label={`${fromLabel}から${toLabel}へ、${line.label}、${line.origin === 'manual' ? '関係を編集' : '元情報を確認'}`} onClick={() => open(line)} onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(line); } }}>
    <rect x={x - width / 2} y={y - 20} width={width} height="28" fill="transparent"/><text x={x} y={y} textAnchor="middle">{label}</text>
  </g>;
});
const GraphNodeElement = memo(function GraphNodeElement({ entity, x, y, selected, select, move, open, point, drag }: { entity: Entity; x: number; y: number; selected: boolean; select: (id: ID) => void; move: (id: ID, x: number, y: number) => void; open: (id: ID) => void; point: (x: number, y: number) => { x: number; y: number }; drag: RefObject<GraphDrag | null> }) {
  return <g role="button" tabIndex={0} aria-label={`${labelOf(entity)}を選択。矢印キーで配置を移動、Enterで詳細`} className={selected ? 'selected' : ''} onClick={() => select(entity.id)} onPointerDown={event => { if (event.button !== 0) return; select(entity.id); const at = point(event.clientX, event.clientY); drag.current = { id: entity.id, pointer: event.pointerId, originX: at.x, originY: at.y, x, y }; event.currentTarget.setPointerCapture(event.pointerId); }} onPointerMove={event => { const current = drag.current; if (!current || current.pointer !== event.pointerId || current.id !== entity.id) return; const at = point(event.clientX, event.clientY); move(entity.id, current.x + at.x - current.originX, current.y + at.y - current.originY); }} onPointerUp={() => { drag.current = null; }} onPointerCancel={() => { drag.current = null; }} onKeyDown={event => { const dx = event.key === 'ArrowLeft' ? -20 : event.key === 'ArrowRight' ? 20 : 0, dy = event.key === 'ArrowUp' ? -20 : event.key === 'ArrowDown' ? 20 : 0; if (dx || dy) { event.preventDefault(); move(entity.id, x + dx * (event.shiftKey ? 2 : 1), y + dy * (event.shiftKey ? 2 : 1)); } else if (event.key === 'Enter') { event.preventDefault(); open(entity.id); } else if (event.key === ' ') { event.preventDefault(); select(entity.id); } }}>
    <rect x={x - 80} y={y - 26} width="160" height="52" rx="10"/><text x={x} y={y + 5} textAnchor="middle">{labelOf(entity).slice(0, 14)}</text>
  </g>;
});
interface GraphEdgeRendering {
  line: GraphLine; a: { x: number; y: number }; b: { x: number; y: number };
  label: RelationLabelPosition; index: Map<ID, Entity>; open: (line: GraphLine) => void; graphId: string;
  lineElement: ReactElement; labelElement: ReactElement;
}
export function Relationships({ project: sourceProject, localProject, referenceEntities = noReferenceEntities, referenceRelations = noReferenceRelations, referenceCalendars = noReferenceCalendars, onOpen: openOrigin, onSave, onSaveProject, selectedId, worldTick, categoryPreset, checkpointId: externalCheckpoint, onViewPointChange, onShowTimeline }: RelationshipsProps) {
  const baseProject = localProject ?? sourceProject;
  const project = useMemo(() => { const entityIds = new Set(sourceProject.entities.map(entity => entity.id)), relationIds = new Set(sourceProject.relations.map(relation => relation.id)), calendarIds = new Set(sourceProject.calendars.map(calendar => calendar.id)); return { ...sourceProject, entities: [...sourceProject.entities, ...referenceEntities.filter(entity => !entityIds.has(entity.id))], relations: [...sourceProject.relations, ...referenceRelations.filter(relation => !relationIds.has(relation.id))], calendars: [...sourceProject.calendars, ...referenceCalendars.filter(calendar => !calendarIds.has(calendar.id))] }; }, [sourceProject, referenceEntities, referenceRelations, referenceCalendars]);
  const origins = useMemo(() => new Map([...project.entities, ...project.relations].map(record => [record.id, record.projectId])), [project.entities, project.relations]);
  const onOpen = useCallback((id: ID) => openOrigin(id, origins.get(id)), [openOrigin, origins]);
  const saveRelation = async (relation: Relation) => { if (relation.projectId !== baseProject.projectId) throw new Error('固定した世界版の関係は、共通世界の元情報から改訂してください。'); await onSave(relation); };
  const [stored, setStored] = useRelationView(baseProject), [editing, setEditing] = useState<Relation | null>(null), [derived, setDerived] = useState<GraphLine | null>(null), [page, setPage] = useState(0), [nodePage, setNodePage] = useState(0), [error, setError] = useState(''), [saveName, setSaveName] = useState(''), [viewBusy, setViewBusy] = useState(false), [selectedNodes, setSelectedNodes] = useState<ID[]>([]), [coordinates, setCoordinates] = useState({ x: '120', y: '100' });
  const graphId = useId();
  const graphElement = useRef<HTMLDivElement>(null), svg = useRef<SVGSVGElement>(null), drag = useRef<GraphDrag | null>(null);
  const categoryRaw = filterString(stored, 'category', 'all'), category: GraphCategory = categoryRaw in GRAPH_CATEGORY_LABELS ? categoryRaw as GraphCategory : 'all';
  const mode = filterString(stored, 'mode', 'table'), focusId = filterString(stored, 'focus'), atRaw = filterString(stored, 'at'), at = worldTick !== undefined ? worldTick : isTick(atRaw) ? atRaw : null, checkpointId = externalCheckpoint ?? filterString(stored, 'checkpoint'), hops = filterString(stored, 'hops', '1') === '2' ? 2 : 1;
  const context = useMemo(() => checkpointContext(project, checkpointId), [project, checkpointId]);
  const graph = useMemo(() => buildRelationGraph(project, { at, context, category, meaning: filterString(stored, 'meaning', 'all'), includeHierarchy: stored.filters.hierarchy !== false, includeUnknown: stored.filters.unknown !== false, focusId, hops, query: filterString(stored, 'query') }), [project, at, context, category, stored.filters, focusId, hops]);
  const index = useMemo(() => new Map(project.entities.map(entity => [entity.id, entity])), [project.entities]);
  const filter = useCallback((key: string, value: string | boolean) => { setStored(previous => ({ ...previous, filters: { ...previous.filters, [key]: value } })); setPage(0); setNodePage(0); }, [setStored]);
  const openedEvidence = useRef<{ projectId: ID; ids: ID[]; returnId: ID | null } | null>(null);
  const openEvidence = useCallback((id: ID) => {
    const previous = openedEvidence.current;
    openedEvidence.current = previous?.projectId === baseProject.projectId && selectedId && previous.ids.includes(selectedId)
      ? { ...previous, ids: [...new Set([...previous.ids, id])] }
      : { projectId: baseProject.projectId, ids: [id], returnId: selectedId ?? null };
    onOpen(id);
  }, [baseProject.projectId, selectedId, onOpen]);
  const openEntity = useCallback((id: ID) => { openedEvidence.current = null; onOpen(id); }, [onOpen]);
  useEffect(() => {
    const evidence = openedEvidence.current;
    if (evidence?.projectId === baseProject.projectId) {
      if (selectedId && evidence.ids.includes(selectedId)) return;
      if ((selectedId ?? null) === evidence.returnId) { openedEvidence.current = null; return; }
    }
    openedEvidence.current = null;
    if (selectedId) filter('focus', selectedId);
  }, [selectedId, baseProject.projectId]);
  useEffect(() => { if (worldTick !== undefined) filter('at', worldTick ?? ''); }, [worldTick, stored.deviceClass]);
  useEffect(() => { if (categoryPreset) filter('category', categoryPreset); }, [categoryPreset]);
  useEffect(() => { if (externalCheckpoint !== undefined) filter('checkpoint', externalCheckpoint); }, [externalCheckpoint, stored.deviceClass]);
  useEffect(() => { const element = graphElement.current; if (element) { element.scrollLeft = Number(filterString(stored, 'scrollX')) || 0; element.scrollTop = Number(filterString(stored, 'scrollY')) || 0; } }, [mode]);
  const safePage = Math.min(page, Math.max(0, Math.ceil(graph.lines.length / TIMELINE_PAGE_SIZE) - 1)), safeNodePage = Math.min(nodePage, Math.max(0, Math.ceil(graph.nodes.length / TIMELINE_PAGE_SIZE) - 1));
  const { nodes, lines } = useMemo(() => { const nodes = graph.nodes.slice(safeNodePage * TIMELINE_PAGE_SIZE, (safeNodePage + 1) * TIMELINE_PAGE_SIZE), shown = new Set(nodes.map(entity => entity.id)); return { nodes, lines: graph.lines.filter(line => shown.has(line.fromId) && shown.has(line.toId)) }; }, [graph.nodes, graph.lines, safeNodePage]);
  const defaultPositions = useMemo(() => new Map(graph.nodes.map((entity, i) => [entity.id, { x: 120 + i % 4 * 220, y: 100 + Math.floor(i % TIMELINE_PAGE_SIZE / 4) * 120 }])), [graph.nodes]);
  // A movement changes a sparse device layout. Look up only displayed points;
  // rebuilding positions for every project node would allocate during a drag.
  const positionOf = (id: ID) => { const fallback = defaultPositions.get(id); return fallback ? stored.positions[id] ?? fallback : undefined; };
  const labelLayout = useMemo(() => layoutRelationLabels(lines.map(line => {
    const a = positionOf(line.fromId)!, b = positionOf(line.toId)!, label = `${line.label}${line.assessment.value === 'unknown' ? ' · 未確認' : ''}`;
    return { id: line.id, x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 - 8, width: Math.max(44, [...label].length * 12 + 16) };
  }), nodes.map(entity => { const p = positionOf(entity.id)!; return { left: p.x - 80, top: p.y - 26, right: p.x + 80, bottom: p.y + 26 }; })), [lines, nodes, defaultPositions, stored.positions]);
  const canvasWidth = Math.max(940, ...nodes.map(entity => positionOf(entity.id)!.x + 100), labelLayout.width), canvasHeight = Math.max(340, ...nodes.map(entity => positionOf(entity.id)!.y + 60), labelLayout.height);
  const selected = stored.lastOpenedId, selectedPosition = selected ? positionOf(selected) : undefined;
  useEffect(() => { if (selectedPosition) setCoordinates(previous => {
    const x = String(Math.round(selectedPosition.x)), y = String(Math.round(selectedPosition.y));
    return previous.x === x && previous.y === y ? previous : { x, y };
  }); }, [selected, selectedPosition?.x, selectedPosition?.y]);
  const move = useCallback((id: ID, x: number, y: number) => {
    const position = { x: bounded(x), y: bounded(y) };
    setStored(previous => ({ ...previous, lastOpenedId: id, positions: { ...previous.positions, [id]: position } }));
    // React batches both changes in the same movement. The synchronization
    // effect above still covers selection, restored layouts and alignment.
    setCoordinates({ x: String(Math.round(position.x)), y: String(Math.round(position.y)) });
  }, [setStored]);
  const select = useCallback((id: ID) => setStored(previous => ({ ...previous, lastOpenedId: id })), [setStored]);
  const openLine = useCallback((line: GraphLine) => { setError(''); if (line.relation && line.relation.projectId === baseProject.projectId) setEditing(line.relation); else if (line.relation) openEntity(line.relation.id); else setDerived(line); }, [baseProject.projectId, openEntity]);
  const pointInSvg = useCallback((clientX: number, clientY: number) => { const matrix = svg.current?.getScreenCTM(); if (!matrix) return { x: clientX, y: clientY }; const point = new DOMPoint(clientX, clientY).matrixTransform(matrix.inverse()); return { x: point.x, y: point.y }; }, []);
  const committedEdges = useRef(new Map<ID, GraphEdgeRendering>());
  const renderedEdges = useMemo(() => {
    const cache = new Map<ID, GraphEdgeRendering>(), lineElements: ReactElement[] = [], labelElements: ReactElement[] = [];
    if (mode !== 'graph') return { cache, elements: [] };
    for (const line of lines) {
      const a = positionOf(line.fromId)!, b = positionOf(line.toId)!, label = labelLayout.labels.get(line.id)!;
      const previous = committedEdges.current.get(line.id);
      let entry: GraphEdgeRendering;
      if (previous && previous.line === line && previous.a === a && previous.b === b && previous.index === index && previous.open === openLine && previous.graphId === graphId && previous.label.x === label.x && previous.label.y === label.y && previous.label.width === label.width) {
        entry = previous;
      } else {
        const props = { line, ax: a.x, ay: a.y, bx: b.x, by: b.y, fromLabel: labelOf(index.get(line.fromId)), toLabel: labelOf(index.get(line.toId)), open: openLine, pathId: `${graphId}-line-${line.id}`, labelX: label.x, labelY: label.y, labelWidth: label.width };
        entry = { line, a, b, label, index, open: openLine, graphId,
          lineElement: <GraphLineElement key={`line:${line.id}`} {...props} layer="line"/>,
          labelElement: <GraphLineElement key={`label:${line.id}`} {...props} layer="label"/> };
      }
      cache.set(line.id, entry); lineElements.push(entry.lineElement); labelElements.push(entry.labelElement);
    }
    return { cache, elements: [...lineElements, ...labelElements] };
  }, [mode, lines, stored.positions, defaultPositions, labelLayout, index, openLine, graphId]);
  // Only committed, displayed entries are retained. Interrupted renders cannot
  // replace the cache, and every endpoint, label and interaction is compared.
  useLayoutEffect(() => { committedEdges.current = renderedEdges.cache; }, [renderedEdges]);
  const savedViews = baseProject.views.filter(view => view.view === 'relation_graph');
  const restore = (view: SavedView) => {
    try {
      const value = JSON.parse(String(view.settings.layout ?? '{}')) as Partial<ViewState>, filters: ViewState['filters'] = value.filters && typeof value.filters === 'object' ? Object.fromEntries(Object.entries(value.filters).filter(([, item]) => typeof item === 'string' || typeof item === 'boolean')) : {};
      const restoredAt = isTick(filters.at) ? filters.at : null, restoredCheckpoint = typeof filters.checkpoint === 'string' && project.entities.some(entity => entity.id === filters.checkpoint && entity.kind === 'checkpoint' && !entity.deletedAt) ? filters.checkpoint : '';
      filters.at = restoredAt ?? ''; filters.checkpoint = restoredCheckpoint;
      if (typeof filters.focus !== 'string' || !project.entities.some(entity => entity.id === filters.focus && !entity.deletedAt)) filters.focus = '';
      if (typeof filters.category !== 'string' || !(filters.category in GRAPH_CATEGORY_LABELS)) filters.category = 'all';
      if (typeof filters.meaning !== 'string' || filters.meaning !== 'all' && !graph.allLines.some(line => line.meaning === filters.meaning)) filters.meaning = 'all';
      if (typeof filters.query !== 'string') filters.query = '';
      for (const key of ['hierarchy', 'unknown']) if (typeof filters[key] !== 'boolean') delete filters[key];
      if (filters.hops !== '1' && filters.hops !== '2') filters.hops = '1';
      if (filters.mode !== 'table' && filters.mode !== 'graph') filters.mode = 'table';
      setStored(previous => ({ ...previous, positions: safeGraphPositions(value.positions), filters, zoom: typeof value.zoom === 'number' && value.zoom >= 0.25 && value.zoom <= 4 ? value.zoom : 1 }));
      onViewPointChange?.(restoredAt, restoredCheckpoint); setPage(0); setNodePage(0); setError('');
    } catch { setError('保存された配置を確認できません。'); }
  };
  // Position updates only change the canvas and coordinate controls. Keep the
  // independent filters, table and picker mounted with their existing inputs.
  const filterControls = useMemo(() => <><div className="list-toolbar"><div className="view-switch"><button type="button" className={mode === 'table' ? 'active' : ''} onClick={() => filter('mode', 'table')}>関係表</button><button type="button" className={mode === 'graph' ? 'active' : ''} onClick={() => filter('mode', 'graph')}>関係図</button></div><select aria-label="図の意味を選択" value={category} onChange={event => { filter('category', event.target.value); filter('meaning', 'all'); }}>{Object.entries(GRAPH_CATEGORY_LABELS).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select><button type="button" className="button primary small" onClick={() => setEditing({ id: newId(), projectId: project.projectId, revision: '0', fromId: '', toId: '', relationType: category === 'family' ? 'parent_of' : RELATION_TYPES[0]?.key ?? 'reference', direction: 'forward', validity: emptyValidity(), evidenceIds: [], status: 'provisional', visibility: 'private' })}><Icon name="plus" size={16}/>関係を追加</button></div>
    <div className="world-filters"><EntityChoice label="中心にする情報" entities={project.entities} value={focusId} onChange={id => filter('focus', id)}/><label>表示範囲<select aria-label="関係の表示範囲" value={hops} onChange={event => filter('hops', event.target.value)}><option value="1">一段</option><option value="2">二段</option></select></label><label>線の種類<select aria-label="線の種類" value={filterString(stored, 'meaning', 'all')} onChange={event => filter('meaning', event.target.value)}><option value="all">すべての種類</option>{[...new Map(graph.allLines.filter(line => category === 'all' || line.category === category || category === 'characters' && line.category === 'family').map(line => [line.meaning, line.label])).entries()].map(([meaning, label]) => <option key={meaning} value={meaning}>{label}</option>)}</select></label><label className="checkbox-label"><input type="checkbox" checked={stored.filters.hierarchy !== false} onChange={event => filter('hierarchy', event.target.checked)}/>階層を表示</label><label className="checkbox-label"><input type="checkbox" checked={stored.filters.unknown !== false} onChange={event => filter('unknown', event.target.checked)}/>未確認の時点・経路も表示</label><input type="search" aria-label="関係を検索" placeholder="始点・終点・意味を検索" value={filterString(stored, 'query')} onChange={event => filter('query', event.target.value)}/></div>
    <WorldPointFields project={project} at={at} checkpointId={checkpointId} onAtChange={tick => { filter('at', tick ?? ''); onViewPointChange?.(tick, checkpointId); }} onCheckpointChange={id => { filter('checkpoint', id); onViewPointChange?.(at, id); }}/></>, [project, mode, category, focusId, hops, graph.allLines, stored.filters, at, checkpointId, filter, onViewPointChange]);
  const nodePicker = useMemo(() => <div className="world-graph-node-picker">{nodes.map(entity => <label key={entity.id} className="checkbox-label"><input type="checkbox" checked={selectedNodes.includes(entity.id)} onChange={event => setSelectedNodes(event.target.checked ? [...selectedNodes, entity.id] : selectedNodes.filter(id => id !== entity.id))}/>{labelOf(entity)}</label>)}</div>, [nodes, selectedNodes]);
  const relationTable = useMemo(() => <>{graph.lines.length === 0 ? <EmptyState icon="link" title="この範囲の関係はありません">中心、時点、経路、線の種類を変えて確認できます。</EmptyState> : <div className="world-relation-table">{graph.lines.slice(safePage * TIMELINE_PAGE_SIZE, (safePage + 1) * TIMELINE_PAGE_SIZE).map(line => <article key={line.id} data-relation-id={line.origin === 'manual' ? line.id : undefined}><button type="button" className="text-button" onClick={() => openEntity(line.fromId)}>{labelOf(index.get(line.fromId))}</button><button type="button" className="world-relation-meaning" onClick={() => openLine(line)}><strong>{line.label}</strong><span>{line.direction === 'symmetric' ? '←→ 対称' : '→ 一方向'} · {line.origin === 'manual' ? '関係を編集' : '元情報からの参照'}</span><span>{line.assessment.value === 'unknown' ? '時点・経路が未確認' : '有効'} · 根拠{line.evidenceIds.length}件</span>{line.relation && <StatusBadge status={line.relation.status}/>}</button><button type="button" className="text-button" onClick={() => openEntity(line.toId)}>{labelOf(index.get(line.toId))}</button></article>)}</div>}<TimelinePagination page={safePage} total={graph.lines.length} onChange={setPage}/></>, [graph.lines, safePage, index, openEntity, openLine]);
  return <div className="world-panel relationships-view">{filterControls}<p className="world-graph-scope">表示 {graph.nodes.length}項目・{graph.lines.length}線 ／ 非表示 {graph.hiddenLines}線・範囲外 {graph.inactiveLines}線 ／ 未確認 {graph.uncertainLines}線 {graph.missingEndpoints > 0 && `／ 参照先未確認 ${graph.missingEndpoints}線`}</p><p className="world-graph-legend"><span>実線：保存された関係</span><span>破線：元情報からの参照</span><span>→ 一方向</span><span>←→ 対称</span><span>未確認：日時や経路の値が不足</span></p>
    {error && <p className="error-notice" role="alert">{error}</p>}
    {mode === 'graph' && graph.nodes.length > 0 && <><div className="world-graph-controls"><label>拡大率<input type="range" aria-label="関係図の拡大率" min="0.25" max="2" step="0.25" value={stored.zoom} onChange={event => setStored(previous => ({ ...previous, zoom: Number(event.target.value) }))}/></label>{selected && <><strong>{labelOf(index.get(selected))}</strong><button type="button" className="button secondary small" onClick={() => openEntity(selected)}>詳細を開く</button>{onShowTimeline && <button type="button" className="button secondary small" onClick={() => onShowTimeline(selected, at)}>この時点の年表へ</button>}<label>X<input aria-label="選択した項目の横位置" value={coordinates.x} inputMode="numeric" onChange={event => setCoordinates(previous => ({ ...previous, x: event.target.value }))}/></label><label>Y<input aria-label="選択した項目の縦位置" value={coordinates.y} inputMode="numeric" onChange={event => setCoordinates(previous => ({ ...previous, y: event.target.value }))}/></label><button type="button" className="button secondary small" disabled={![coordinates.x, coordinates.y].every(value => value.trim() && Number.isFinite(Number(value)) && Number(value) >= 80 && Number(value) <= 10000)} onClick={() => move(selected, Number(coordinates.x), Number(coordinates.y))}>座標を適用</button>{(['←', '↑', '↓', '→'] as const).map((label, i) => <button key={label} type="button" className="button secondary small" aria-label={`選択項目を${label}へ移動`} onClick={() => { const p = positionOf(selected); if (p) move(selected, p.x + (i === 0 ? -20 : i === 3 ? 20 : 0), p.y + (i === 1 ? -20 : i === 2 ? 20 : 0)); }}>{label}</button>)}</>}<button type="button" className="button subtle small" onClick={() => setSelectedNodes(nodes.map(entity => entity.id))}>表示項目を整列対象に</button>{(['row', 'column', 'grid'] as const).map(alignment => <button key={alignment} type="button" className="button secondary small" disabled={!selectedNodes.length} onClick={() => setStored(previous => ({ ...previous, positions: alignGraphPositions(selectedNodes, { ...Object.fromEntries(graph.nodes.map(entity => [entity.id, positionOf(entity.id)!])), ...previous.positions }, alignment) }))}>{{ row: '横に整列', column: '縦に整列', grid: '格子に整列' }[alignment]}</button>)}</div><p className="field-hint">項目はドラッグ、矢印キー、座標入力、移動ボタンで配置できます。配置はこの端末の表示設定です。</p>{nodePicker}<p className="field-hint">図は{nodes.length} / {graph.nodes.length}項目・{lines.length} / {graph.lines.length}線を表示中です。ページを替えるか、中心を選んで範囲を開いてください。すべての線は関係表から操作できます。</p><div ref={graphElement} className="world-relation-canvas" tabIndex={0} aria-label="関係図のスクロール領域" onScroll={event => { const { scrollLeft, scrollTop } = event.currentTarget; setStored(previous => ({ ...previous, filters: { ...previous.filters, scrollX: String(scrollLeft), scrollY: String(scrollTop) } })); }}><svg ref={svg} width={canvasWidth * stored.zoom} height={canvasHeight * stored.zoom} viewBox={`0 0 ${canvasWidth} ${canvasHeight}`} aria-label="意味と向き付きの関係図"><defs><marker id="world-relation-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor"/></marker></defs>{renderedEdges.elements}{nodes.map(entity => { const p = positionOf(entity.id)!; return <GraphNodeElement key={entity.id} entity={entity} x={p.x} y={p.y} selected={selected === entity.id} select={select} move={move} open={openEntity} point={pointInSvg} drag={drag}/>; })}</svg></div><TimelinePagination page={safeNodePage} total={graph.nodes.length} onChange={setNodePage}/></>}
    {relationTable}
    {onSaveProject && <details className="advanced-details"><summary>名前を付けた表示設定</summary><fieldset disabled={viewBusy} className="world-save-fields world-saved-views"><label>表示名<input aria-label="関係図の保存名" value={saveName} onChange={event => setSaveName(event.target.value)}/></label><button type="button" className="button secondary" disabled={viewBusy || !saveName.trim()} onClick={async () => { setViewBusy(true); try { const saved: SavedView = { id: newId(), name: saveName.trim(), view: 'relation_graph', entityIds: [...selectedNodes], settings: { layout: JSON.stringify({ positions: stored.positions, filters: stored.filters, zoom: stored.zoom }) } }; await onSaveProject({ ...baseProject, views: [...baseProject.views, saved] }, '関係図の表示設定を保存'); setSaveName(''); setError(''); } catch (cause) { setError((cause as Error).message); } finally { setViewBusy(false); } }}>表示設定を保存</button>{savedViews.map(view => <span key={view.id}><button type="button" className="button subtle" onClick={() => restore(view)}>{view.name}</button><button type="button" className="button subtle small" aria-label={`${view.name}の表示設定を削除`} onClick={async () => { setViewBusy(true); try { await onSaveProject({ ...baseProject, views: baseProject.views.filter(item => item.id !== view.id) }, '名前を付けた関係図の表示設定を削除'); setError(''); } catch (cause) { setError((cause as Error).message); } finally { setViewBusy(false); } }}>削除</button></span>)}</fieldset></details>}
    {editing && <RelationForm key={editing.id} relation={editing} project={project} onOpen={openEvidence} onSave={saveRelation} onClose={() => setEditing(null)}/>} {derived && <Modal title="元情報からの関係" onClose={() => setDerived(null)}><p>{labelOf(index.get(derived.fromId))} → {labelOf(index.get(derived.toId))} · {derived.label}</p><p>元情報：{labelOf(index.get(derived.sourceId))} · {derived.sourcePath}</p><p>この線は元情報の参照から表示しています。元情報で参照を直すと、同じ図と表に反映します。</p><WindowedList items={derived.evidenceIds.map(id => ({ id }))} scope={`${baseProject.projectId}:${derived.id}:derived-relation-evidence`} label="元情報の関係の根拠" searchText={({ id }) => labelOf(index.get(id))} as="ul" render={({ id }) => <li key={id}><button type="button" className="text-button" onClick={() => openEvidence(id)}>{labelOf(index.get(id))}</button></li>}/><div className="modal-actions"><button type="button" className="button primary" onClick={() => { const id = derived.sourceId; setDerived(null); openEntity(id); }}>{origins.get(derived.sourceId) === baseProject.projectId ? '元情報を編集' : '共通世界の元情報を開く'}</button></div></Modal>}
  </div>;
}
