import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import {afterEach,expect,it,vi} from 'vitest';
import {bindRecordPartsImport,installRecordPartsDatabase} from './recordPartsDatabase';
import {packRecordData,unpackRecordData} from './recordPartsCore';
import {newId} from '../domain/model';
const databases:Dexie[]=[];afterEach(async()=>{vi.restoreAllMocks();for(const db of databases.splice(0))await db.delete();});
function database(name='parts-'+newId()){const db=new Dexie(name);db.version(1).stores({commands:'operationId,projectId',recordParts:'key,scope'});installRecordPartsDatabase(db,512);databases.push(db);return db;}
it('packs at most two import rows together, writes only completed parts and reads every complete original in order',async()=>{
 const db=database(),records=Array.from({length:5},(_,i)=>({operationId:String(i),projectId:'work',body:'😀原文'.repeat(300)+i,present:undefined}));
 let release!:()=>void,active=0,maximum=0,arrivals=0,writesAtPairStart:number|undefined,missedPair=false;
 const gate=new Promise<void>(resolve=>{release=resolve;});
 const digest=crypto.subtle.digest.bind(crypto.subtle),nativeAdds=vi.spyOn(IDBObjectStore.prototype,'add');
 const spy=vi.spyOn(crypto.subtle,'digest').mockImplementation(async(...args)=>{
  active++;maximum=Math.max(maximum,active);
  try{if(++arrivals<=2){if(arrivals===2){writesAtPairStart=(nativeAdds.mock.contexts as IDBObjectStore[]).filter(store=>['commands','recordParts'].includes(store.name)).length;release();}await gate;}return await digest(...args);}finally{active--;}
 });
 const timer=setTimeout(()=>{missedPair=true;release();},1000);
 try{
  await db.transaction('rw','commands',async()=>{bindRecordPartsImport();await db.table('commands').bulkAdd(records);});
 }finally{clearTimeout(timer);release();spy.mockRestore();nativeAdds.mockRestore();}
 expect(missedPair).toBe(false);expect(writesAtPairStart).toBe(0);expect(maximum).toBe(2);expect(active).toBe(0);
 expect(await db.table('commands').where('projectId').equals('work').toArray()).toEqual(records);
 expect(await db.table('commands').bulkGet(['4','1','0','3','2'])).toEqual([records[4],records[1],records[0],records[3],records[2]]);
 expect(await db.table('recordParts').count()).toBeGreaterThan(0);
});
it('rolls back earlier complete row pairs and all parts when one later import pack fails',async()=>{
 const db=database(),old={operationId:'old',projectId:'work',body:'保持する旧稿'.repeat(300)};
 await db.table('commands').add(old);const parts=await db.table('recordParts').toArray();
 const records=Array.from({length:4},(_,i)=>({operationId:'new'+i,projectId:'work',body:'並行保存する全本文'.repeat(300)+i}));
 const digest=crypto.subtle.digest.bind(crypto.subtle);let fail=false;
 const spy=vi.spyOn(crypto.subtle,'digest').mockImplementation(async(...args)=>{if(fail){fail=false;throw Error('parallel pack failed');}return digest(...args);});
 try{await expect(db.transaction('rw','commands',async()=>{
  bindRecordPartsImport();await db.table('commands').bulkAdd(records.slice(0,2));
  fail=true;await db.table('commands').bulkAdd(records.slice(2));
 })).rejects.toThrow('parallel pack failed');}finally{spy.mockRestore();}
 expect(await db.table('commands').toArray()).toEqual([old]);expect(await db.table('recordParts').toArray()).toEqual(parts);
});
it('keeps the captured bytes and metadata when caller inputs change during a digest',async()=>{
 const original={body:'旧案'},encoded=await packRecordData(original,'captured-input'),changed=await packRecordData({body:'新案'},'captured-input');
 let hashed!:()=>void,resume!:()=>void;const ready=new Promise<void>(resolve=>{hashed=resolve;}),continueHash=new Promise<void>(resolve=>{resume=resolve;});
 const digest=crypto.subtle.digest.bind(crypto.subtle);
 vi.spyOn(crypto.subtle,'digest').mockImplementationOnce(async(...args)=>{const value=await digest(...args);hashed();await continueHash;return value;});
 const reading=unpackRecordData(encoded.packed,encoded.parts);await ready;
 expect(changed.parts[0]!.bytes.length).toBe(encoded.parts[0]!.bytes.length);encoded.parts[0]!.bytes.set(changed.parts[0]!.bytes);encoded.packed.scope='later-input';
 resume();expect(await reading).toEqual(original);
});
it('preserves Unicode, complete variants, shared record identities and present undefined separately from absence',async()=>{const record={id:newId(),text:'😀日本語',data:{before:'旧案',after:'新案'}},input={before:[record],after:[record,{...record,data:{before:'別案',after:'完成'}}],present:undefined};const encoded=await packRecordData(input,'immutable-operation'),decoded=await unpackRecordData(encoded.packed,encoded.parts) as typeof input;expect(decoded).toEqual(input);expect(decoded.before[0]).toBe(decoded.after[0]);expect(Object.hasOwn(decoded,'present')).toBe(true);expect(Object.hasOwn(decoded,'absent')).toBe(false);expect(decoded.after[1]).not.toBe(decoded.before[0]);});
it('refuses missing, altered, wrong-scope and repeated parts, cyclic graphs, sparse arrays and cancelled work',async()=>{const value={records:Array.from({length:140},(_,i)=>({id:i,body:'😀'.repeat(50000)+i}))},encoded=await packRecordData(value,'whole-history');expect(encoded.parts.length).toBeGreaterThan(1);expect(encoded.parts.every(p=>p.bytes.length<=8*1024*1024)).toBe(true);expect(await unpackRecordData(encoded.packed,encoded.parts)).toEqual(value);await expect(unpackRecordData(encoded.packed,encoded.parts.slice(1))).rejects.toThrow();const corrupt=structuredClone(encoded.parts);corrupt[0]!.bytes[0]^=1;await expect(unpackRecordData(encoded.packed,corrupt)).rejects.toThrow();await expect(unpackRecordData({...encoded.packed,scope:'other'},encoded.parts)).rejects.toThrow();await expect(unpackRecordData(encoded.packed,[encoded.parts[0]!,encoded.parts[0]!])).rejects.toThrow();const cycle:{child?:unknown}={};cycle.child=cycle;await expect(packRecordData(cycle,'cycle')).rejects.toThrow();await expect(packRecordData(new Array(2),'sparse')).rejects.toThrow();const controller=new AbortController();controller.abort();await expect(packRecordData(value,'cancel',controller.signal)).rejects.toMatchObject({code:'CANCELLED'});});
it('reads full rows through get, bulk get, indexed query and filtered cursor, keeps legacy rows and removes replaced parts',async()=>{const db=database(),record={operationId:'first',projectId:'work',history:{body:'本文'.repeat(100),before:{present:false},after:{present:true,value:undefined}}};await db.table('commands').add(record);expect(await db.table('recordParts').count()).toBeGreaterThan(0);expect(await db.table('commands').get('first')).toEqual(record);expect(await db.table('commands').bulkGet(['first'])).toEqual([record]);expect(await db.table('commands').where('projectId').equals('work').toArray()).toEqual([record]);expect(await db.table('commands').filter(v=>v.history.body.startsWith('本文')).toArray()).toEqual([record]);await db.table('commands').add({operationId:'legacy',projectId:'work'});expect(await db.table('commands').get('legacy')).toEqual({operationId:'legacy',projectId:'work'});await db.table('commands').put({operationId:'first',projectId:'work'});expect(await db.table('recordParts').count()).toBe(0);});
it('rolls back row and every part together on failure and refuses corruption instead of returning a summary',async()=>{const db=database(),original={operationId:'old',projectId:'work',body:'旧版'.repeat(100)};await db.table('commands').add(original);const before=await db.table('recordParts').toArray();await expect(db.transaction('rw','commands',async()=>{await db.table('commands').put({...original,body:'改稿'.repeat(100)});await db.table('commands').add({operationId:'new',projectId:'work',body:'新案'.repeat(100)});throw Error('simulated quota after parts');})).rejects.toThrow();expect(await db.table('commands').get('old')).toEqual(original);expect(await db.table('commands').get('new')).toBeUndefined();expect(await db.table('recordParts').toArray()).toEqual(before);const part=before[0];await db.table('recordParts').put({...part,bytes:new Uint8Array([1,2,3])});await expect(db.table('commands').get('old')).rejects.toThrow();});
it('keeps mixed plain and split rows in query/bulk order with absent slots, and rejects a corrupt late row without changing stored bytes',async()=>{
 const db=database(),plain0={operationId:'0',projectId:'work'},packed1={operationId:'1',projectId:'work',body:'😀旧版'.repeat(160),present:undefined},plain2={operationId:'2',projectId:'work'},packed3={operationId:'3',projectId:'work',body:'😀別案'.repeat(180)},plain4={operationId:'4',projectId:'work'};
 const records=[plain0,packed1,plain2,packed3,plain4];await db.table('commands').bulkAdd(records);
 const nativeRows=async()=>new Promise<Record<string,unknown[]>>((resolve,reject)=>{const tx=db.backendDB().transaction(['commands','recordParts'],'readonly'),result:Record<string,unknown[]>={};for(const table of ['commands','recordParts']){const read=tx.objectStore(table).getAll();read.onsuccess=()=>{result[table]=read.result;};}tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);});
 const raw=await nativeRows();expect(await db.table('commands').where('projectId').equals('work').toArray()).toEqual(records);
 expect(await db.table('commands').bulkGet(['4','3','absent','0','1','3'])).toEqual([plain4,packed3,undefined,plain0,packed1,packed3]);expect(await nativeRows()).toEqual(raw);
 const parts=await db.table('recordParts').toArray(),last=raw.commands.find(value=>(value as {operationId:string}).operationId==='3') as {__scenarioRecordParts:{parts:{key:string}[]}};
 const key=last.__scenarioRecordParts.parts[0]!.key,part=parts.find(p=>p.key===key)!;const bytes=new Uint8Array(part.bytes);bytes[0]^=1;await db.table('recordParts').put({...part,bytes});const corrupted=await nativeRows();
 await expect(db.table('commands').where('projectId').equals('work').toArray()).rejects.toThrow();await expect(db.table('commands').bulkGet(['0','1','3','absent'])).rejects.toThrow();expect(await nativeRows()).toEqual(corrupted);
 await db.table('recordParts').put(part);expect(await db.table('commands').where('projectId').equals('work').toArray()).toEqual(records);expect(await nativeRows()).toEqual(raw);
});
