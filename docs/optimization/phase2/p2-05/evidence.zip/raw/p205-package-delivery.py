"""Historical P205 delivery orchestration. No product/build/test/timing execution."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

PROGRESS = Path('/workspace/phase2-progress')
REPO = Path('/workspace/phase2')
OUT = REPO / 'docs/optimization/phase2/p2-05'
HEAD = '260957a9ec25f3afeda8bede6481ceb2e417685f'
BASE = '5b3949253937f1880bd426b39706c90a1db2e343'
FREEZE_SHA = '29916a48843abe712246d13a545bc5807b6b0a8895a04c59e4c469b609fa9062'
REPORT_SHA = '3832792b4247301d9658f3ea0d1e582c6cfbaac7b594f9f60e210d996c0a0a9b'
SUITES = ('standard', 'large', 'supplemental')
VARIANTS = ('baseline-5b', 'candidate-260')
EXPECTED_EXITS = {(s, v): 1 if (s, v) == ('supplemental', 'baseline-5b') else 0
                  for s in SUITES for v in VARIANTS}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load(path: Path):
    return json.loads(path.read_text())


def put(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def metadata(path: Path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def capture_name(suite, variant):
    return f'p205-capture-{variant}-{suite}-1'


def verify_build(directory: Path, declared: dict):
    zpath = directory / declared['zip']['path']
    data = zpath.read_bytes()
    assert len(data) == declared['zip']['bytes'] and sha(data) == declared['zip']['sha256']
    expected = {row['path']: row for row in declared['files']}
    members = []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(expected)
        assert set(archive.namelist()) == set(expected)
        for info in archive.infolist():
            payload = archive.read(info)
            row = expected[info.filename]
            assert len(payload) == row['bytes'] and sha(payload) == row['sha256']
            assert (directory / 'build' / info.filename).read_bytes() == payload
            members.append({**row, 'crc32': f'{info.CRC:08x}', 'compressedBytes': info.compress_size})
    return {'actualArchive': metadata(zpath), 'actualMembers': members,
            'memberCount': len(members), 'CRCAndExtractedAndDeclaredBytesVerified': True,
            'command': declared['command']}


def git_blobs(records):
    ids = list(dict.fromkeys(row['gitBlob'] for row in records))
    proc = subprocess.run(['git', 'cat-file', '--batch'], input=('\n'.join(ids) + '\n').encode(),
                          cwd=REPO, check=True, stdout=subprocess.PIPE)
    stream = io.BytesIO(proc.stdout)
    blobs = {}
    for oid in ids:
        header = stream.readline().decode().split()
        assert header[:2] == [oid, 'blob']
        data = stream.read(int(header[2])); assert stream.read(1) == b'\n'
        blobs[oid] = data
    assert stream.read() == b''
    for row in records:
        data = blobs[row['gitBlob']]
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    return blobs


def classify(name):
    labels = {
        'p205-pin-refresh-red-3210-overlay-1': 'INADEQUATE ORACLE PASS: old/new literal names identical; not behavioral GREEN',
        'p205-pin-refresh-red-3210-overlay-2': 'GENUINE UI RED: distinct newer-only literal showed old adopted edition',
        'p205-outer-selection-red-80da-overlay-1': 'GENUINE UI RED: current preview unusable after real import/editor-read failure',
        'p205-same-revision-red-651b-overlay-1': 'HARNESS SETUP FAILURE: ordinary idle sync also requested inert shares metadata',
        'p205-same-revision-red-651b-overlay-2': 'GENUINE UI RED: held ordinary same-revision idle refresh erased immutable preview',
        'p205-check-baseline-5b-final-overlay-supp-1': 'FINAL SHARED CHECK: genuine baseline pin UI failure; successful common prefix preserved',
        'p205-check-candidate-final-supp-1': 'FINAL EXACT260 SHARED HTTP UI CHECK GREEN',
    }
    if name in labels:
        return labels[name]
    if name.startswith('p205-capture-'):
        return 'FINAL REVIEWED CAPTURE: sole expected baseline supplemental pin UI failure retained' if 'baseline-5b-supplemental' in name else 'FINAL REVIEWED CAPTURE SUCCESS'
    if name in {f'p205-check-{v}-final-{s}-api-1' for s in ('standard', 'large') for v in ('candidate', 'baseline-5b')}:
        return 'FINAL EXACT260-OVERLAY API CORRECTNESS CHECK; no clocks/probes'
    return 'HISTORICAL CHECK/REPRODUCTION: actual source/overlay identity below; never relabelled final'


def analyze():
    freeze = load(PROGRESS / 'p205-freeze-manifest.json')
    assert sha((PROGRESS / 'p205-freeze-manifest.json').read_bytes()) == FREEZE_SHA
    assert sha((PROGRESS / 'task-5-report.md').read_bytes()) == REPORT_SHA
    gate = load(PROGRESS / 'p205-capture-gate.json')
    for row in gate['reviews']:
        assert sha((PROGRESS / row['path']).read_bytes()) == row['sha256']
    captures, off_pairs, on_pairs, raw_off = [], [], [], []
    for suite in SUITES:
        pair = {}
        for variant in VARIANTS:
            directory = PROGRESS / capture_name(suite, variant)
            r = load(directory / 'result.json')
            assert r['mode'] == 'capture' and r['suite'] == suite
            assert r['source']['head'] == (BASE if variant == 'baseline-5b' else HEAD)
            assert r['source']['overlays'] == freeze['identicalOverlay']
            for row in r['source']['overlays']:
                for root in (REPO, Path('/workspace/p2-02-validation')):
                    assert sha((root / row['path']).read_bytes()) == row['sha256']
            operations = r['observations']['operations']
            assert len(operations) == (44 if suite == 'supplemental' else 52)
            assert all(x['apiCompletion'] == 'fulfilled' and not x.get('error') and not x.get('observationError') for x in operations)
            assert all(x.get('counterCompleteness') == 'settled capture' and 'milliseconds' not in x for x in operations if x['probeEnabled'])
            assert all(x['probe']['pendingTransactions'] == 0 for x in operations if x['probeEnabled'])
            assert r['observations'].get('activeOperation') is None
            assert r['status'] == ('error' if EXPECTED_EXITS[suite, variant] else 'ok')
            if EXPECTED_EXITS[suite, variant]:
                assert len(r['errors']) == 1 and 'P205 newer-only place 0' in r['errors'][0]['message']
                assert 'P205 place 0' in r['errors'][0]['message'] and 'finishedAt' not in r
            else:
                assert not r['errors'] and r['finishedAt']
            off = [x for x in operations if not x['probeEnabled']]
            on = [x for x in operations if x['probeEnabled']]
            assert [x['label'] for x in off] == [x['label'] for x in on]
            build = verify_build(directory, r['build']); assert build['memberCount'] == 12
            captures.append({
                'name': directory.name, 'variant': variant, 'suite': suite,
                'originalDirectory': str(directory), 'rawResult': metadata(directory / 'result.json'),
                'rawLog': metadata(PROGRESS / f'{directory.name}.log'),
                'command': ['node', 'scripts/optimization/measure-world-ownership.mjs', *r['argv']],
                'root': r['root'], 'exitCode': EXPECTED_EXITS[suite, variant],
                'recordedAt': r['recordedAt'], 'finishedAt': r.get('finishedAt'),
                'finishedAtMeaning': 'ABSENT on genuine UI error by frozen runner; not a successful run' if EXPECTED_EXITS[suite, variant] else 'actual frozen runner completion',
                'status': r['status'], 'errors': r['errors'], 'source': r['source'],
                'build': build, 'generator': r['generator'], 'generatedFiles': r['generatedFiles'],
                'environment': r['environment'], 'fixture': r['observations']['fixture'],
                'worldCountersSupported': r['worldCountersSupported'], 'counterSupportEvidence': r['counterSupportEvidence'],
                'OFF': off, 'ON': on, 'runs': r['observations']['runs'],
                'sameRevisionUI': r.get('sameRevisionUI', {'status': 'NOT RUN'}),
                'ui': r.get('ui', {'status': 'FAILED: see error and partial checkpoints; final gauges UNKNOWN'}),
                'uiCheckpoints': r.get('uiCheckpoints', []), 'activeUIAction': r.get('activeUIAction'),
                'uiInterruption': r.get('uiInterruption'), 'heap': r.get('heap', {'status': 'NOT RUN after prior UI error'}),
            })
            pair[variant] = {'OFF': off, 'ON': on, 'raw': r}
            raw_off.extend({'suite': suite, 'variant': variant, **x} for x in off)
        assert pair['baseline-5b']['raw']['observations']['fixture'] == pair['candidate-260']['raw']['observations']['fixture']
        for before, after in zip(pair['baseline-5b']['OFF'], pair['candidate-260']['OFF'], strict=True):
            assert before['label'] == after['label']
            b, a = before['milliseconds'], after['milliseconds']
            off_pairs.append({'suite': suite, 'label': before['label'], 'baselineMilliseconds': b,
                              'candidateMilliseconds': a, 'deltaMilliseconds': a - b,
                              'candidateOverBaseline': a / b if b else None,
                              'candidateSlowerStrictRawFloat': a > b,
                              'sampleMeaning': 'one OFF API invocation per variant; no distribution or significance'})
        for before, after in zip(pair['baseline-5b']['ON'], pair['candidate-260']['ON'], strict=True):
            assert before['label'] == after['label']
            on_pairs.append({'suite': suite, 'label': before['label'], 'baseline': before, 'candidate': after})
    assert len(off_pairs) == len(on_pairs) == 74 and len(raw_off) == 148
    unfavorable = {s: sum(x['candidateSlowerStrictRawFloat'] for x in off_pairs if x['suite'] == s) for s in SUITES}
    assert unfavorable == {'standard': 13, 'large': 15, 'supplemental': 12}
    parent = load(PROGRESS / 'p205-capture-parent-verification.json')
    for ours, theirs in zip(off_pairs, parent['OFFComparisons'], strict=True):
        assert all(ours[k] == theirs[k] for k in ('label', 'baselineMilliseconds', 'candidateMilliseconds', 'deltaMilliseconds', 'candidateSlowerStrictRawFloat'))
        assert ours['suite'] == theirs['size']
    analysis = {
        'version': 1, 'purpose': 'Complete supplemental P205 observations, adverse results and limits; no original acceptance promotion',
        'frozenProductHead': HEAD, 'literalBaseline': BASE,
        'definitions': {
            'OFF': 'Single performance.now elapsed around actual awaited API. Pre-invocation checkpoint, fixture/input construction, oracle/hash checks and cleanup excluded. No numeric probe. Includes actual API wall wait, scheduling and worker/IDB latency. All raw float values preserved.',
            'ON': 'Separate newly seeded database and invocation sequence. Raw probe counters/events are instrumentation-affected work diagnostics, not OFF latency. API settled before numeric counter settlement. Every final ON row fulfilled with settled capture and zero pending native transactions.',
            'pairing': 'Identical suite, literal fixed input, seven overlay bytes, operation labels/order and API options; independent fresh databases. Supplemental successful API prefixes compare; failed baseline UI suffix never compared as equivalent successful latency.',
            'missingMetrics': 'Raw absent counter keys remain unrecorded, never filled with zero. Baseline lacks declared world/UI gauges: UNKNOWN. Gauge values are instantaneous last samples; counters sum instrumented calls/rows/bytes, not unique rows, physical IDB bytes or retained heap.',
            'storeRetention': 'Direct outside-interval cachedProjects/contentHeads/cachedHistoryIds/completeHistories/cacheEpochs sizes. records=sum entities+relations of cached graphs; canonicalBytes=sum UTF-8 JSON bytes of cached graphs including cached history. Caller-owned weak tokens, drafts, active save captures and canonical IDB/outbox/assets lie outside this inactive budget.',
            'UIRegistry': 'Separate actual ON UI gauge: registry object entries; unique project object identities; sum current entities+relations; serialized JSON payload. Shared/caller-owned other views may retain graphs. Unsupported baseline gauge UNKNOWN.',
            'heap': 'CDP Runtime.getHeapUsage instantaneous renderer/isolate values in separately fresh SMALL six-source fixture context, regardless of original suite flag. No forcedGC, peak, retained/reachable heap or release acceptance; original Large/72MiB memory UNKNOWN.',
            'strictUnfavorable': 'candidateMilliseconds > baselineMilliseconds on exact stored raw floats, including very small near-tie jitter. No rounded-value omission, statistical inference, p95 or threshold acceptance.',
        },
        'counts': {'captureRuns': 6, 'APIrows': 296, 'fulfilledAPIrows': 296, 'OFFpairs': 74, 'rawOFFvalues': 148,
                   'ONpairs': 74, 'ONrows': 148, 'unexpectedFailures': 0, 'expectedBaselinePinUIFailures': 1,
                   'strictRawUnfavorablePairs': sum(unfavorable.values()), 'strictRawUnfavorableBySuite': unfavorable},
        'OFFpairs': off_pairs, 'rawOFF': raw_off, 'ONpairs': on_pairs, 'captures': captures,
        'originalStage3': 'HELD: 8metrics x2sizes x30 /180 saves /7200 and113-history actual72MiB new/clone/cold only after human integration',
        'release': 'BLOCKED', 'acceptancePromoted': False,
    }
    put(OUT / 'measurements.json', analysis)
    with (OUT / 'latency-observations.csv').open('w', newline='') as f:
        cols = ['suite', 'label', 'baselineMilliseconds', 'candidateMilliseconds', 'deltaMilliseconds', 'candidateOverBaseline', 'candidateSlowerStrictRawFloat']
        writer = csv.DictWriter(f, cols, extrasaction='ignore', lineterminator='\n'); writer.writeheader(); writer.writerows(off_pairs)
    with (OUT / 'work-observations.csv').open('w', newline='') as f:
        writer = csv.writer(f, lineterminator='\n'); writer.writerow(['suite', 'label', 'counter', 'baselineRaw', 'candidateRaw', 'deltaWhenBothRecorded'])
        for row in on_pairs:
            b, a = row['baseline']['probe']['counters'], row['candidate']['probe']['counters']
            for key in sorted(set(b) | set(a)):
                writer.writerow([row['suite'], row['label'], key, b.get(key, 'UNRECORDED/UNKNOWN'), a.get(key, 'UNRECORDED/UNKNOWN'), a[key] - b[key] if key in a and key in b else 'UNKNOWN'])
    original_build = verify_build(PROGRESS / 'p205-product-final-build-1', freeze['originalProductBuild'])
    assert original_build['memberCount'] == 13
    provenance = {'version': 1, 'frozenReport': metadata(PROGRESS / 'task-5-report.md'),
                  'freezeManifest': metadata(PROGRESS / 'p205-freeze-manifest.json'),
                  'reviews': gate['reviews'], 'captureGate': metadata(PROGRESS / 'p205-capture-gate.json'),
                  'owned22Files': freeze['ownedFiles'], 'runtime305Files': freeze['runtimeProductFiles'],
                  'identical7Overlays': freeze['identicalOverlay'], 'sharedDriverDependencies': freeze['sharedDriverDependencies'],
                  'originalCleanProductBuild': freeze['originalProductBuild'],
                  'originalBuildActualByteVerification': original_build,
                  'captureSourceBuildInputBindings': [{k:v for k,v in row.items() if k not in ['OFF','ON','runs','ui','sameRevisionUI','uiCheckpoints','heap']} for row in captures],
                  'parentVerification': metadata(PROGRESS / 'p205-capture-parent-verification.json'),
                  'parentVerificationScript': metadata(PROGRESS / 'verify-p205-capture-parent.py'),
                  'controllerRemoteObservation': metadata(PROGRESS / 'remote-integration-observation-1024.json'),
                  'controllerRemoteObservationContents': load(PROGRESS / 'remote-integration-observation-1024.json'),
                  'orchestrationMeaning': 'Historical proof/packaging scripts and receipts, not new public CI commands or original acceptance procedures'}
    put(OUT / 'capture-provenance.json', provenance)
    cohorts = []
    for directory in sorted(PROGRESS.glob('p205-*')):
        if not directory.is_dir() or not (directory / 'result.json').is_file():
            continue
        r = load(directory / 'result.json'); ops = r.get('observations', {}).get('operations', [])
        cohorts.append({'directory': str(directory), 'classification': classify(directory.name),
                        'rawResult': metadata(directory / 'result.json'), 'mode': r.get('mode'), 'suite': r.get('suite'),
                        'status': r.get('status'), 'recordedAt': r.get('recordedAt'), 'finishedAt': r.get('finishedAt'),
                        'actualHead': r.get('source', {}).get('head'), 'actualProductHead': r.get('source', {}).get('productHead'),
                        'actualSourceStatus': r.get('source', {}).get('status'), 'actualOverlays': r.get('source', {}).get('overlays'),
                        'argv': r.get('argv'), 'root': r.get('root'), 'operationRows': len(ops),
                        'errors': r.get('errors'), 'activeUIAction': r.get('activeUIAction'),
                        'identityRule': 'Actual result.source/overlay is authoritative; no directory-label promotion. d68 folder suffix was a typo retained literally.'})
    log_causes = {
        'p205-cache-red.log': 'Genuine retention/save hydration behavioral RED; WIP source identity not frozen at invocation',
        'p205-closure-red1.log': 'Invalid newly authored fixture setup, not behavioral closure RED',
        'p205-closure-red2.log': 'Invalid newly authored fixture setup, not behavioral closure RED',
        'p205-closure-red3.log': 'Invalid newly authored fixture setup, not behavioral closure RED',
        'p205-closure-red4.log': 'Corrected valid fixture and full-registry/literal oracle behavioral RED',
        'p205-preview-red.log': 'Helper API absent before implementation; not actual HTTP preview-race proof',
        'p205-driver-red.log': 'Missing new module setup failure; no behavioral performance claim',
        'p205-cache-cancel-red.log': 'Genuine postcommit cache publication RED; canonical/API success preserved as expected',
        'p205-selected-corruption-red.log': 'Genuine selected direct outer corruption hidden by healthy retained copy; all4APIs wrongly fulfilled and save mutated',
        'p205-ack-collision-red.log': 'Genuine local ACK/rival retained-ID transaction race; all-native-image oracle',
        'p205-unit-full1.log': 'WIP fullsuite diagnostic1264pass/2exportlaunchEPERMfail; no at-start frozen source manifest, no final-head CI promotion',
        'p205-exports-network-classification.log': 'Permission-correct targeted unchanged2export tests: file:// ERR_BLOCKED_BY_ADMINISTRATOR;19CLI-unselected, no source skip/policy/timeout edit',
    }
    put(OUT / 'historical-cohorts.json', {'version': 1, 'runs': cohorts,
        'logCauses': [{**metadata(PROGRESS / name), 'classification': cause} for name, cause in log_causes.items()],
        'allOtherLogs': 'Every matching original P205 log including earlier GREEN, type/docs failures and prior source checkpoints is retained unmodified in evidence ZIP.',
        'commands': load(PROGRESS / 'p205-verification-commands.json'), 'acceptancePromoted': False})
    print(json.dumps({'action': 'analyze', 'OFFpairs': len(off_pairs), 'ONpairs': len(on_pairs), 'unfavorable': unfavorable, 'historicalRuns': len(cohorts)}, ensure_ascii=False))


def seal():
    freeze = load(PROGRESS / 'p205-freeze-manifest.json')
    assert sha((PROGRESS / 'p205-freeze-manifest.json').read_bytes()) == FREEZE_SHA
    assert sha((PROGRESS / 'task-5-report.md').read_bytes()) == REPORT_SHA
    assert not (OUT / 'evidence.zip').exists(), 'Unique sealed archive already exists; never silently replace'
    sources = []
    for variant in VARIANTS:
        r = load(PROGRESS / capture_name('standard', variant) / 'result.json')
        for row in r['source']['productFiles']:
            sources.append({**row, 'archiveMember': f'source/{variant}/{row["path"]}'})
    for row in freeze['ownedFiles']:
        sources.append({**row, 'archiveMember': f'source/candidate-260/{row["path"]}'})
    for row in freeze['sharedDriverDependencies']:
        sources.append({**row, 'archiveMember': f'source/shared-driver/{row["path"]}'})
    blobs = git_blobs(sources)
    entries = {}
    for row in sources:
        data = blobs[row['gitBlob']]
        if row['archiveMember'] in entries:
            assert entries[row['archiveMember']][0] == data
        entries[row['archiveMember']] = (data, {'kind': 'immutable Git blob', 'gitBlob': row['gitBlob'], 'originalPath': row['path']})
    raw_paths = []
    for top in sorted(PROGRESS.iterdir()):
        if not top.name.startswith(('p205', 'p2-05', 'task-5', 'task-4-driver')) and top.name not in ('verify-p205-capture-parent.py', 'remote-integration-observation-1024.json', 'remote-refs-observation-1024.txt'):
            continue
        if top.name.startswith(('p205-delivery-', 'task-5-capture-report', 'task-5-delivery-report', 'task-5-final-handoff')):
            continue
        for path in sorted(top.rglob('*')) if top.is_dir() else [top]:
            if not path.is_file():
                continue
            assert not path.is_symlink()
            relative = path.relative_to(PROGRESS).as_posix()
            data = path.read_bytes()
            entries[f'raw/{relative}'] = (data, {'kind': 'unmodified historical/raw evidence', 'originalPath': str(path)})
            raw_paths.append({'originalPath': str(path), 'archiveMember': f'raw/{relative}', 'bytes': len(data), 'sha256': sha(data)})
    for name in ['measurements.json', 'latency-observations.csv', 'work-observations.csv', 'capture-provenance.json', 'historical-cohorts.json']:
        entries[f'analysis/{name}'] = ((OUT / name).read_bytes(), {'kind': 'delivery analysis; no new runtime observation', 'originalPath': str(OUT / name)})
    archive_path = OUT / 'evidence.zip'
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for name, (data, _) in sorted(entries.items()):
            assert not name.startswith('/') and '..' not in PurePosixPath(name).parts
            info = zipfile.ZipInfo(name, (2026, 10, 17, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compresslevel=6)
    members = []
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == sorted(entries)
        for info in archive.infolist():
            data = archive.read(info)
            assert data == entries[info.filename][0]
            members.append({'path': info.filename, 'bytes': len(data), 'sha256': sha(data), 'crc32': f'{info.CRC:08x}',
                            'compressedBytes': info.compress_size, **entries[info.filename][1]})
    archive_meta = metadata(archive_path)
    assert archive_meta['bytes'] < 100 * 1024 * 1024, 'Archive needs lossless split before Git staging'
    put(OUT / 'evidence-manifest.json', {
        'version': 1, 'archive': {'path': 'evidence.zip', **{k:v for k,v in archive_meta.items() if k != 'path'}},
        'compression': 'ZIP deflate6; no raw input/evidence omitted; deterministic member metadata',
        'actualMemberCount': len(members), 'uncompressedBytes': sum(x['bytes'] for x in members),
        'fullCRCAndMemberBytesSHA256Verified': True, 'members': members, 'rawInputCount': len(raw_paths),
        'rawInputFiles': raw_paths, 'frozenProductHead': HEAD, 'literalBaseline': BASE,
        'frozenReportSHA256': REPORT_SHA, 'freezeManifestSHA256': FREEZE_SHA,
        'sourceSubsets': {'candidateRuntime': 305, 'baselineRuntime': 303, 'candidateOwned': 22, 'identicalOverlays': 7, 'sharedDriverDependencies': 1},
        'sourceSubsetOverlap': 'Runtime and owned candidate subsets overlap; identical archive paths stored once. Frozen22 docs reflect original260 bytes, delivery docs are a separate later commit.',
        'rootReceiptsMeaning': 'Independent historical source/build/capture validation, not a new public CI or execution promotion',
        'acceptancePromoted': False,
    })
    print(json.dumps({'action': 'seal', 'archive': archive_meta, 'members': len(members), 'rawInputs': len(raw_paths), 'uncompressedBytes': sum(x['bytes'] for x in members)}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('action', choices=['analyze', 'seal'])
    args = parser.parse_args()
    {'analyze': analyze, 'seal': seal}[args.action]()
