"""Historical documentation-only P205 orchestration, not a supported CI command."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/phase2/docs/optimization/phase2/p2-05')
P = Path('/workspace/phase2-progress')
H = '260957a9ec25f3afeda8bede6481ceb2e417685f'
B = '5b3949253937f1880bd426b39706c90a1db2e343'


def load(p):
    return json.loads(p.read_text())


def stamp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


mapping = load(P / 'p205-additional-clause-mapping.json')
cpath = ROOT / 'requirement-correspondence.json'
c = load(cpath)
for path in ('tests/optimization/world-selected-corruption.test.ts', 'tests/optimization/world-ack-collision.test.ts'):
    if path not in c['supplementalProcedures']:
        c['supplementalProcedures'].append(path)
bycase = {r['case']: r for r in mapping['cases']}
for row in c['cases']:
    if row['case'] in bycase:
        added = bycase[row['case']]
        row['additionalSupplementalProcedures'] = added['supplementalProcedures']
        row['additionalRelevantSupplementalClauses'] = added['relevantSupplementalClauses']
        row['additionalGuardOnlyScope'] = added['scope']
c['additionalGuardClauseMappings'] = mapping['cases']
c['additionalMappingProvenance'] = {
    'immutableExternalMap': stamp(P / 'p205-additional-clause-mapping.json'),
    'scope': 'F09/F54/N06/F35/N14/E12 then and negative_or_edge guard subsets only; original clauses/procedures/acceptance unchanged',
    'hashMeaning': 'Actual651 procedure hashes in the original map remain historical labels; original procedures are byte-identical at260 and exactP204. Historical clause-registry declared hashes remain separately labelled.'}
c['notRun'] = 'Formal Stage3, external/device/service/live Auth/production conditions remain NOT RUN; reviewed supplemental capture completed without acceptance promotion'
write(cpath, c)

a = load(ROOT / 'measurements.json')
f = load(P / 'p205-freeze-manifest.json')
m = load(ROOT / 'evidence-manifest.json')
prov = load(ROOT / 'capture-provenance.json')
history = load(ROOT / 'historical-cohorts.json')
lines = [
    '# P2-05 capture and delivery report', '',
    f'Frozen reviewed product/driver: `{H}`, tree `4f2527db1b42eaa3fa7d303c2f9abbadc48ce247`; literal P204 baseline: `{B}`, tree `c24e4391ac29a1e2ef9af3aecc65ae145b13b59a`. The later delivery commit changes documentation/evidence only. Original `task-5-report.md` and `p205-freeze-manifest.json` remain immutable, including their historical pre-capture STOP language. They are historical handoff records, not current NOT RUN claims.', '',
    'Six approved captures ran sequentially once after exact260 specification PASS and quality APPROVE, in the controller-allocated exclusive slot at 2026-10-17 09:56:09 UTC. Slot released after the last capture and bounded clean-source checks. No extra/repeated capture, timing-source change, timeout/assertion/retry/skip relaxation or competing team workload was authorized. Packaging reads, hashing and ZIP work occurred after release.', '',
    '**Outcome:** five overall successes plus the genuine expected literal-baseline pin-preview error. All 296 API rows fulfilled; all 148 ON rows settled with zero pending transactions and no API/observation error. Exact raw OFF comparison has 40 unfavorable pairs (13 Standard / 15 Large / 12 supplemental), including very small near-ties. No universal speed improvement, p95, significance or original acceptance claim. See [design disposition/rollback](DESIGN.md).', '',
    '## Definitions and comparison limits', '',
]
for key, value in a['definitions'].items():
    lines.extend([f'- **{key}:** {value}'])
lines.extend(['',
    '`db.read.*` counts instrumented read calls/requested or returned rows and serialized payload; repeated reads count repeatedly, not unique native rows. `hash.*`, `json.*`, normalization/validation/diff counters and worker message/byte counters describe the exact instrumented source work. Probe JSON payload estimates are not interchangeable with direct `storeRetention.canonicalBytes`. `probe.size.milliseconds` and phase events expose ON instrumentation/sizing cost, not OFF API latency. Every raw counter/event remains in [measurements.json](measurements.json); the [work CSV](work-observations.csv) includes the union of recorded keys with UNKNOWN for absent sides.', '',
    'The 26 original-size API operations include initial original save, original cold edit, one-character save and cold two-command full history, followed by the same 22 supplemental API operations. Six supplemental work/source iterations call current editing read, dependency listing and source preview; the first editor is retained across pressure, then saved, selected history materialized, cold full project read and fully exported. Fixture construction/setup, oracle validation, digesting and cleanup sit outside API intervals. Setup still changes cache state identically according to each product policy; it is not erased from retention observations.', '',
    'The API-only original-size pairs use identical `--ui false`. Separate identical actualApp UI captures retain baseline common-prefix observations and its later pin semantic failure; that failed suffix is not compared as an equivalent successful UI latency. UI proofs measure functionality and ON gauges, not UI wait distributions. The optional fresh-context CDP diagnostic is SMALL supplemental regardless of the outer `--suite standard` flag.', '',
    '## Actual commands, exits and raw captures', '',
    'All commands below used unchanged runner and permission-enabled local browser/HTTP-loopback child launch. Shell logs and generator logs are unmodified archive members under `raw/<directory-name>...`; [provenance](capture-provenance.json) gives full actual cwd/argv/source/build/input identities. Git directory labels are not source evidence.', '',
    '| Directory | Exit / overall | API rows | Actual recordedAt → finishedAt (UTC) |',
    '| --- | --- | ---: | --- |'])
for r in a['captures']:
    lines.append(f'| `{r["name"]}` | {r["exitCode"]} / {r["status"]} | {len(r["OFF"])+len(r["ON"])} | {r["recordedAt"]} → {r["finishedAt"] or "ABSENT: genuine UI error"} |')
lines.extend(['', 'Actual runner commands (each output was unique; baseline cwd `/workspace/p2-02-validation`, candidate cwd `/workspace/phase2`):', '', '```sh'])
for r in a['captures']:
    lines.append(' '.join(r['command']))
lines.extend(['```', '',
    'Baseline supplemental error requested literal `P205 newer-only place 0` after holding only the pin adopted-closure refresh while a real source revision triggered newer preview. Actual dialog displayed old `P205 place 0` / edition0. Its unchanged 5,000 ms assertion failed; overall stays error/CLI1 and has no fabricated `finishedAt`. All 44 API rows, ordinary same-revision PASS, failed-input check and six prior source retention boundaries survive in raw checkpoints. This is the pre-existing common-baseline UI behavior, not a successful whole-UI performance baseline.', '',
    '## Every OFF pair', '',
    'All 74 paired observations / 148 raw API elapsed values follow, unrounded. `candidate > baseline` uses stored raw floats; even tiny positive differences remain. No raw value is omitted or rerun. CSV preserves LF-only line endings and identical values: [latency-observations.csv](latency-observations.csv).', '',
    '| Suite | Operation | Baseline ms | Candidate ms | Candidate − baseline ms | Candidate > baseline |',
    '| --- | --- | ---: | ---: | ---: | --- |'])
for r in a['OFFpairs']:
    lines.append(f'| {r["suite"]} | `{r["label"]}` | {r["baselineMilliseconds"]!r} | {r["candidateMilliseconds"]!r} | {r["deltaMilliseconds"]!r} | {r["candidateSlowerStrictRawFloat"]} |')
lines.extend(['',
    'The unfavorable original cold edit/save/history observations are material: Standard 659.6→753.5, 480.5→592.5, 2422→2515 ms; Large 5902.5→7531.3, 5035.4→6632.5, 18097.1→21177.3 ms. Recorded corresponding project/record-part/decode/hash counts do not isolate a cause. Changed CPU/allocation work, host scheduling and GC/JIT explanations remain UNKNOWN. These are single observations, not regression probabilities, platform predictions or thresholds.', '',
    '## ON work, extra reads and retained full paths', '',
    'All 148 ON rows preserve every recorded counter, event, completeness label and zero-pending-transaction boundary in [measurements.json](measurements.json), with all union counter keys in [work-observations.csv](work-observations.csv). No ON top-level API latency is fabricated. Selected work0 can require cold body/world validation on the candidate because the four-entry policy evicted it; baseline retained it. Conversely, dependencies work0/full work0 avoid the unrelated full-registry body read on the known-owner path. The following selected raw work values illustrate this tradeoff without claiming they explain the original-size wait regressions.', '',
    '| Suite | Operation | Counter | Baseline raw | Candidate raw |',
    '| --- | --- | --- | ---: | ---: |'])
selected = {'select-work-0': ['db.read.rows.entities','db.read.rows.worlds'],
            'dependencies-work-0': ['db.read.rows.worlds','db.read.payloadBytes.worlds'],
            'cold-full-project': ['db.read.rows.worlds','db.read.payloadBytes.worlds'],
            'complete-export-with-history': ['db.read.rows.worlds','db.read.payloadBytes.worlds'],
            'original-save-one-amid-six-worlds': ['db.read.rows.recordParts','db.read.payloadBytes.recordParts','normalize.rows','hash.bytes'],
            'original-cold-full-history-amid-six-worlds': ['db.read.rows.recordParts','db.read.payloadBytes.recordParts','decode.rows']}
for r in a['ONpairs']:
    if r['label'] not in selected:
        continue
    b, c = r['baseline']['probe']['counters'], r['candidate']['probe']['counters']
    for key in selected[r['label']]:
        lines.append(f'| {r["suite"]} | `{r["label"]}` | `{key}` | {b.get(key,"UNRECORDED/UNKNOWN")} | {c.get(key,"UNRECORDED/UNKNOWN")} |')
lines.extend(['',
    'Absent keys above are not measured zeros. Baseline declares no P205 world-closure/UI metric support. Candidate unknown-shape/owner fallback remains a full registry scan, guarded by original validators. Unknown owner workload was correctness-tested but its broader performance is not isolated by these known fixtures. Complete export still reads six native world rows in each variant before selecting the one actual outer dependency. Selected output dependency keys match (one in each run); those keys are not the native registry inventory, full archive-byte equality or an independent full-registry oracle. The oracle separately receives every raw native world row and literal ID/hash expectations. Dynamic native writer timestamps/operation IDs can differ across fresh databases.', '',
    'The retained early ACK guard plus final native-transaction guard performs one extra mandatory full scan for nonempty applied ACK world input. ACK is outside this capture sequence, so cost is UNKNOWN/unmeasured. It must not be advertised as free. Canonical pin/import/export/recovery/hash/owner checks and complete immutable rows remain authoritative.', '',
    '## Store retention: all captured boundaries', '',
    'The complete OFF and ON `runs` objects include after-setup and all six source boundaries, final/released/closed tuples, graph record and canonical-byte counts. They are preserved without reduction in [measurements.json](measurements.json). Final/released/closed readings below are direct outside-interval observations, distinct from probe payload/heap.', '',
    '| Suite / variant / run | Boundary | projects / heads / histories / complete / epochs | records | JSON bytes |',
    '| --- | --- | --- | ---: | ---: |'])
for capture in a['captures']:
    for run in capture['runs']:
        for key in ('retention', 'released', 'closed'):
            r = run[key]
            tup = ' / '.join(str(r[k]) for k in ('projects','heads','histories','completeHistories','epochs'))
            lines.append(f'| {capture["suite"]} / {capture["variant"]} / {"ON" if run["enabled"] else "OFF"} | {key} | {tup} | {r["records"]} | {r["canonicalBytes"]} |')
lines.extend(['',
    'The original-sized graph is eventually evicted on the candidate during the six-source sequence; it is not deleted from native storage, caller-owned returned values, author input or history. All candidate final release/close collections and epochs are zero; baseline original-size release retains the original graph and close retains 13 epoch IDs. Weak read/history metadata is not enumerable and has no global boundedness proof. Caller-held drafts/details/history arrays and simultaneous active-save captures remain outside the inactive budget.', '',
    '## Actual HTTP App UI retention and failures', '',
    'The actual App ran through HTTP loopback, not a pure helper substitute. Both variants retain all six common-prefix checkpoints before the baseline pin error. Candidate full proof preserves all six picker choices and adopted edition, author input after failed source hash, held source2→3→2, preview pending before a real import/editor-read rejection, subsequent ABA detail resolution, held pin adopted-refresh/newer distinct detail and held ordinary idle SyncPanel same-revision refresh. The fixed local same-account session performs zero transport sends/downloads/unexpected network calls; shares/members are inert local metadata, not live Auth/service evidence.', '',
    '| Candidate boundary | Registry entries / unique project objects / records | Probe payload bytes | Store projects / heads / histories / complete / epochs | Store JSON bytes |',
    '| --- | --- | ---: | --- | ---: |'])
ui = next(r for r in a['captures'] if r['suite']=='supplemental' and r['variant']=='candidate-260')['ui']
for label, r in [*(('source '+str(i), x) for i,x in enumerate(ui['boundaries'])), ('final', ui['final'])]:
    counters = r['probe']['counters']; store = r['store']
    tup = ' / '.join(str(counters['ui.worldRegistry.'+k]) for k in ('entries','projects','records'))
    st = ' / '.join(str(store[k]) for k in ('projects','heads','histories','completeHistories','epochs'))
    lines.append(f'| {label} | {tup} | {counters["ui.worldRegistry.payloadBytes"]} | {st} | {store["canonicalBytes"]} |')
lines.extend(['',
    'Baseline UI registry entry/project/record/payload gauges are UNKNOWN because literal5b does not provide those metrics. Its six direct store checkpoints and raw supporting probe values remain archived; unavailable final UI output is not zero. Candidate final store has four records/6,351 canonical JSON bytes while registry has three records/4,424 probe payload bytes. Neither is heap or proof that every App graph is released.', '',
    '## All eight instantaneous CDP rows', '',
    'Actual capability `CDP Runtime.getHeapUsage` succeeded for both variants. Each used a separately fresh renderer/context and **SMALL added six-source fixture** after API work, outside all API/UI timing. `freshContext=true`, `forcedGC=false`. There was no snapshot/GC/peak/reachable-retained/release acceptance measurement, and original Large/72 MiB heap remains UNKNOWN/NOT RUN. JIT, GC, transient allocations, renderer/embedder/harness scope and asynchronous collection prevent interpreting after-release values as retained memory or proof of reclamation.', '',
    '| Variant | Boundary | usedSize bytes | totalSize bytes | embedderHeapUsedSize bytes | backingStorageSize bytes |',
    '| --- | --- | ---: | ---: | ---: | ---: |'])
for capture in a['captures']:
    if capture['suite'] != 'standard':
        continue
    heap = capture['heap']; assert heap['status']=='observed' and heap['forcedGC'] is False
    for r in heap['rows']:
        lines.append(f'| {capture["variant"]} | {r["boundary"]} | {r["usedSize"]} | {r["totalSize"]} | {r["embedderHeapUsedSize"]} | {r["backingStorageSize"]} |')
lines.extend(['', '## Provenance and sealed artifacts', '',
    f'The [sealed ZIP](evidence.zip) is {m["archive"]["bytes"]:,} bytes, SHA256 `{m["archive"]["sha256"]}`, with {m["actualMemberCount"]:,} actual members / {m["uncompressedBytes"]:,} uncompressed bytes. Every member was read and verified against original bytes plus SHA256 and ZIP CRC. Its [manifest](evidence-manifest.json) binds every member and all {m["rawInputCount"]} original input paths. No inputs were dropped and no Git blob reaches 100 MiB; lossless chunking was unnecessary.', '',
    'The archive retains raw historical directories/build ZIPs/extracted members/results/logs, exact immutable baseline303/candidate305 runtime source files, all22 owned candidate paths (overlapping runtime subsets stored once), seven common overlays and unchanged shared P204 observer. Frozen22 documentation is the original260 version; current delivery docs are a separately changed later commit. Full source Git blobs, generator commands, fresh generated outputs, environment, fixture hashes and actual build members are in [capture provenance](capture-provenance.json). The historical packaging/parent-verification scripts in the archive are evidence provenance, not newly advertised public CI commands.', '',
    '| Capture | Actual build ZIP bytes / SHA256 | Actual members |', '| --- | --- | ---: |'])
for r in a['captures']:
    b = r['build']; z = b['actualArchive']
    lines.append(f'| `{r["name"]}` | {z["bytes"]} / `{z["sha256"]}` | {b["memberCount"]} |')
z = f['originalProductBuild']['zip']
lines.extend(['',
    f'The separate unchanged original `npm run build` exited0 at clean260, with original base `/shinariokanri/`, build-info commit/tree/dirty=false and13 actual members: `{z["path"]}`, {z["bytes"]} bytes, SHA256 `{z["sha256"]}`. Its generator/build log/build-info/extracted bytes/member manifest and ZIP are archived, independently reverified against every member. Measurement builds are custom12-member Vite harness bundles and are not substituted for this production build.', '',
    '| Immutable record | Bytes / SHA256 |', '| --- | --- |'])
for p in [P/'task-5-report.md', P/'p205-freeze-manifest.json', P/'task-5-spec-final-review.md', P/'task-5-quality-final-review.md', P/'p205-capture-gate.json', P/'p205-capture-parent-verification.json', P/'verify-p205-capture-parent.py', P/'p205-retention-parent-extraction.json', P/'remote-integration-observation-1024.json']:
    s = stamp(p); lines.append(f'| `{p.name}` | {s["bytes"]} / `{s["sha256"]}` |')
lines.extend(['',
    'The frozen manifest additionally binds all22 owned paths, 305 runtime inputs, seven overlay hashes, generated output, six final correctness builds, original production build, verification commands and preserved logs. Root receipts preserve original276/274 procedure continuity, exact3 authorized v8 strict changes, original104/116/464/24/6/68/73 contract checks, and all296 P204-cumulative test/fixture/CI/config files byte-identical to exact5b with12 additive files. Receipts prove source continuity, not re-executed acceptance. The independent parent capture receipt verified six ZIPs/72members, Git source blobs/overlays/fixtures, all296 fulfilled rows, raw40-unfavorable count, baseline partial UI failure and eight SMALL CDP rows.', '',
    'Original Standard input: `standard-r06-v1`, 6,258,972 JSON bytes, SHA256 `a15eb7d1c10e6c008c9881cc215239a67fa80e28eef0f7627e4742a2de05c13e`,8,800records,0assets. Large: `large-material-rb10-v1`,59,407,368 JSON bytes, SHA256 `814daf96a6511cf47409f3497b03c7ba0309af250bfd87306c44a1dec5d5a917`,88,003records,actual75,497,472asset bytes (3×25,165,824); all three actual asset byte/hash fields match original declared hashes. Supplemental input18,858bytes SHA256 `70a0d99d2a89eb92a8e123676aea2043ba175443bfa874ec013c4e65c806d293`; UI-only distinct-edition input18,880bytes SHA256 `f0d6e5bd0b3bcc424d7b88a275b6116852d072106d5f28a846bb36b863be08a0`. All sizes/seeds/generated bytes are original or explicitly added supplemental inputs; no weakened original fixture.', '',
    '## Historical RED/GREEN and failed setup cohorts', '',
    'All32 runner result directories retain their actual status/source/overlay/argv/input/build identity in [historical-cohorts.json](historical-cohorts.json), with every raw byte archived. Old80da/3210/bd9d/651 checks are historical, not final260. A baseline directory suffix `d68` was a naming typo; actual `result.source` and overlay hashes remain authoritative.', '',
    '| Cohort | Actual distinction / retained GREEN |', '| --- | --- |',
    '| `p205-cache-red.log` | Five intended retention/hydrate/save failures; corrected36-test GREEN and final196-test store cohort. WIP RED has no at-start frozen source manifest. |',
    '| `p205-closure-red1/2/3.log` | Invalid new fixture setup (scope/body/default-note), not behavioral RED. |',
    '| `p205-closure-red4.log` | Corrected valid full-registry/literal oracle: three behavioral failures;48-test GREEN. |',
    '| `p205-preview-red.log` / `p205-driver-red.log` | Initial missing new helper API / missing new module; not HTTP-race or performance proof. |',
    '| `p205-outer-selection-red-80da-overlay-1` | Actual import then failed editor read leaves detail unresolved; final pending-preview/ABA HTTP GREEN. |',
    '| `p205-pin-refresh-red-3210-overlay-1` | Inadequate oracle PASS: identical old/new names allowed adopted fallback; not valid GREEN. |',
    '| `p205-pin-refresh-red-3210-overlay-2` | Genuine RED with distinct newer-only literal; final literal5b common-trigger RED and260 GREEN. |',
    '| `p205-cache-cancel-red.log` | Postcommit success/native rev2 but wrong new cache publication;11-test GREEN retains old tuple/native success. |',
    '| `p205-selected-corruption-red.log` | Four APIs wrongly fulfilled and save mutated;20-test GREEN rejects direct-copy conflict/all-native preservation. |',
    '| `p205-ack-collision-red.log` | Supported local ACK native barrier race wrongly commits;14-test GREEN incl originals, all native image preserved relative to rival. |',
    '| `p205-same-revision-red-651b-overlay-1` | Local harness setup failure for ordinary shares metadata; not preview-loss RED. |',
    '| `p205-same-revision-red-651b-overlay-2` | Genuine held ordinary idle refresh rev1/detail loss with send0/network0; exact260 HTTP and17-test helper/driver/library GREEN. |',
    '| Earlier type/docs/prototype checks | Initial new-test/driver errors and later corrections retained separately; no original assertion/fixture relaxed. |', '',
    'Actual successful focused commands and source limits are retained verbatim in `p205-verification-commands.json` under raw archive. The19-file explicit Vitest cohort exited0 with196tests at bd9d-era source; final store/closure/ACK bytes are identical, later UI helper change has separate17tests/5files exited0. `npx tsc --noEmit` and pre-freeze docs exited0; final original product build exited0. These are not an exact-final full-suite CI claim.', '',
    'The ordinary WIP `npm test` exited1:1,264passed/2failed tests,135passed/1failed files. Both unchanged exports tests failed child/browser launch EPERM/setsockopt under initial launch permissions. A permission-correct targeted `npx vitest run tests/exports.test.ts -t \'runs the exported HTML|rolls back every exported effect\'` exited1 with administrator-blocked `file://` navigation. The19 unselected tests were CLI filtering, not source skips. No browser policy/original test/timeout changed. WIP full run lacks an at-start frozen source manifest and remains diagnostic; no local all-green full-suite claim. P204/#64 CI success is not reassigned to P205; controller must collect unchanged full hosted CI for delivery.', '',
    '## Original requirement mapping and remaining gates', '',
    'The [correspondence](requirement-correspondence.json) adds the late selected-corruption and ACK procedures to the explicitly relevant **then / negative_or_edge** guard subsets of original F09(case32),F54(77),N06(89),F35(58),N14(97),E12(115). The archived immutable six-case external map preserves all four original clause texts/procedure paths and distinguishes actual651/current-unchanged procedure hashes from historical registry-declared hashes. These guards do not replace complete media/export/migration/physical-loss/real-Files/flight-mode/old-app workflows or promote entire original cases.', '',
    'Controller remote observation at 2026-10-17 10:24 UTC is archived with raw refs. Main `b32de9525c4acf5206ac3d6d1d23f5b90967ec95`, tree `83ae5006ead9c7e2a83316b95a0e643a2338167b`, equals repaired PR62 CI tree;62 merged into main09:26:44. PR63 merge `c06ff7becc75f6ed34b097e1ae5134074b1c50ad` at09:26:58 targeted the library-loading feature branch, not main. PR64 merge `559777cf1b5301483f2fbbd17014ffc190f7c2f3` at09:52:41 targeted the save-changeset feature branch, not main. Actual remote history-metadata branch remained exact5b. Actual Git parents/current remote refs are authoritative; normalized get_pr_info reported historical base SHAs are labelled as such in the receipt. No merge/rebase was performed by this agent or controller. P203/P204 have not thereby propagated into main; local P205 remains based on literal5b. Controller verifies actual base again before any Draft PR/push.', '',
    'Original104requirements/116cases/464clauses/24packages/6groups/68supplements/73locked inputs,94local/22external and **RELEASE BLOCKED** remain unchanged. Native formats/request hashes/canonical snapshots/history/assets/outbox/guards are not relaxed. Original600,000/2,000ms conditions and30/180/7,200 limits remain;1,200,000ms bounds only supplemental orchestration. Formal8metrics×2sizes×30/180save/7,200 and113-history actual72MiB new/clone/cold stay Stage3 after human integration. Real devices, production, live Auth/billing/cloud and external acceptance remain unperformed. Delivery review, original hosted full CI and any publication/merge are controller/human gates.', '',
    'Packaging/documentation validation commands and exact later delivery head/tree are recorded in the controller handoff after commit. No new test/build/benchmark was run to package this delivery.', '',
])
report = '\n'.join(lines)
(ROOT/'DELIVERY.md').write_text(report)
(P/'task-5-capture-report.md').write_text(report)
(P/'task-5-delivery-report.md').write_text('P205 documentation/evidence delivery. Frozen product/driver '+H+'; exact base '+B+'.\n\n'+report)
print(json.dumps({'action':'write-docs','OFFpairs':len(a['OFFpairs']),'reportBytes':len(report.encode()),'additionalCases':len(mapping['cases']),'archiveMembers':m['actualMemberCount']},ensure_ascii=False))
