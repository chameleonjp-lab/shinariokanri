from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/workspace/phase2');OUT=Path('/workspace/phase2-progress')
BASE='5b3949253937f1880bd426b39706c90a1db2e343';HEAD='260957a9ec25f3afeda8bede6481ceb2e417685f'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def entry(p,relative=None):
 b=p.read_bytes();return {'path':relative or str(p),'bytes':len(b),'sha256':sha(b)}
assert git('rev-parse','HEAD')==HEAD
assert not git('status','--porcelain')
changed=git('diff','--name-only',BASE,HEAD).splitlines()
owned=[]
for name in changed:
 p=ROOT/name;row=entry(p,name);row['gitBlob']=git('rev-parse',f'{HEAD}:{name}');owned.append(row)
name_status=git('diff','--name-status',BASE,HEAD)
assert all(line.split('\t')[1] in ['src/App.tsx','src/domain/worldSources.ts','src/observability/probe.ts','src/storage/store.ts','src/ui/WorldVersions.tsx'] for line in name_status.splitlines() if line.startswith('M\t'))
checks=[
 ('p205-check-candidate-final-supp-1','ok'),
 ('p205-check-baseline-5b-final-overlay-supp-1','error'),
 ('p205-check-candidate-final-standard-api-1','ok'),
 ('p205-check-baseline-5b-final-standard-api-1','ok'),
 ('p205-check-candidate-final-large-api-1','ok'),
 ('p205-check-baseline-5b-final-large-api-1','ok'),
]
rows=[];results={}
for name,expected in checks:
 folder=OUT/name;result_path=folder/'result.json';r=json.loads(result_path.read_text());results[name]=r
 assert r['mode']=='check' and r['status']==expected,(name,r['status'])
 assert r['observations']['status']=='ok'
 assert len(r['observations']['runs'])==1 and r['observations']['runs'][0]['enabled'] is False
 assert all('milliseconds' not in op and 'probe' not in op for op in r['observations']['operations'])
 for f in r['source']['productFiles']:assert f['matchesProductCommit']
 for overlay in r['source']['overlays']:
  assert entry(ROOT/overlay['path'],overlay['path'])==overlay
 zpath=folder/r['build']['zip']['path'];assert entry(zpath,r['build']['zip']['path'])==r['build']['zip']
 expected_members={f['path']:f for f in r['build']['files']}
 with zipfile.ZipFile(zpath) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(expected_members)==12
  assert set(z.namelist())==set(expected_members)
  for member in z.namelist():
   b=z.read(member);assert {'path':member,'bytes':len(b),'sha256':sha(b)}==expected_members[member]
   assert b==(folder/'build'/member).read_bytes()
 run=r['observations']['runs'][0]
 row={'directory':str(folder),'expectedOutcome':expected,'result':entry(result_path),'productHead':r['source']['productHead'],'productTree':r['source']['productTree'],'sourceStatus':r['source']['status'],'argv':r['argv'],'fixture':r['observations']['fixture'],'operations':len(r['observations']['operations']),'retention':run['retention'],'released':run['released'],'closed':run['closed'],'actualMeasurementBuild':r['build'],'ui':r.get('ui',{'status':'error','interruption':r.get('uiInterruption'),'errors':r['errors']}),'sameRevisionUI':r.get('sameRevisionUI'),'uiCheckpoints':r.get('uiCheckpoints',[]),'intervalClocksProbesHeap':'NOT RUN: check-only, operation fields verified absent'}
 rows.append(row)
for size in ['standard','large']:
 a=results[f'p205-check-candidate-final-{size}-api-1'];b=results[f'p205-check-baseline-5b-final-{size}-api-1']
 assert a['source']['overlays']==b['source']['overlays']
 assert a['observations']['fixture']==b['observations']['fixture']
 assert a['argv'][a['argv'].index('--ui')+1]==b['argv'][b['argv'].index('--ui')+1]=='false'
a=results['p205-check-candidate-final-supp-1'];b=results['p205-check-baseline-5b-final-overlay-supp-1']
assert a['source']['overlays']==b['source']['overlays']
assert a['observations']['fixture']==b['observations']['fixture']
assert a['uiCheckpoints'][0]['fixture']==b['uiCheckpoints'][0]['fixture']
assert a['ui']['final']['instrumentationStarts']==0
assert a['sameRevisionUI']['status']==b['sameRevisionUI']['status']=='ok'
assert a['sameRevisionUI']['state']['sendCalls']==b['sameRevisionUI']['state']['sendCalls']==0
assert b['uiInterruption']['action']=='pin adoption refresh preserves newer current preview'
assert 'P205 newer-only place 0' in b['errors'][0]['message'] and 'P205 edition 0' in b['errors'][0]['message']
product_dir=OUT/'p205-product-final-build-1';product=json.loads((product_dir/'manifest.json').read_text())
assert product['source']['head']==HEAD and product['source']['dirty'] is False
assert product['buildInfo']['commit']==HEAD and product['buildInfo']['tree']==git('rev-parse','HEAD^{tree}') and product['buildInfo']['dirty'] is False
assert len(product['files'])==13
with zipfile.ZipFile(product_dir/'actual-product-build.zip') as z:
 assert len(z.namelist())==13
 for f in product['files']:
  b=z.read(f['path']);assert {'path':f['path'],'bytes':len(b),'sha256':sha(b)}==f
logs=[entry(p) for p in sorted(OUT.glob('p205-*.log'))]
manifest={'version':1,'base':BASE,'baseTree':git('rev-parse',f'{BASE}^{{tree}}'),'head':HEAD,'tree':git('rev-parse','HEAD^{tree}'),'branch':git('branch','--show-current'),'status':git('status','--porcelain'),'commits':git('log','--format=%H %s',f'{BASE}..{HEAD}').splitlines(),'ownedFiles':owned,'sharedDriverDependencies':[dict(entry(ROOT/'tests/optimization/history-measurement-core.ts','tests/optimization/history-measurement-core.ts'),gitBlob=git('rev-parse',f'{HEAD}:tests/optimization/history-measurement-core.ts'),unchangedFromP204=git('rev-parse',f'{HEAD}:tests/optimization/history-measurement-core.ts')==git('rev-parse',f'{BASE}:tests/optimization/history-measurement-core.ts'))],'runtimeProductFiles':a['source']['productFiles'],'identicalOverlay':a['source']['overlays'],'generatedFiles':a['generatedFiles'],'environment':a['environment'],'checks':rows,'originalProductBuild':product,'controllerSourceOnlyReceipts':[entry(OUT/name) for name in ['p2-05-checkpoint260-original-procedure-continuity.json','p2-05-checkpoint260-original-contracts.log','p2-05-prior-stage-test-continuity.json'] if (OUT/name).exists()],'additionalClauseMapping':entry(OUT/'p205-additional-clause-mapping.json'),'verificationCommands':entry(OUT/'p205-verification-commands.json'),'logs':logs,'provenanceNotes':['Literal baseline is detached exact5b; exactly seven identical untracked measurement overlays.','Historical651 baseline supplemental output suffix d68 is an erroneous folder label; immutable result.source and overlay bytes remain authoritative. No evidence renamed or relabelled.','Old80da,3210,bd9d,651 and dirty-overlay RED cohorts remain separate and are not final260 evidence.','Canonical writer operation IDs/timestamps differ by independent DB run; only fixed fixture/generator hashes and literal results are parity contracts.','No timing/ON/heap capture before both independent exact-head approvals.','Original required CI, external/device conditions, Stage3 acceptance and performance benefit remain unclaimed.']}
p=OUT/'p205-freeze-manifest.json';assert not p.exists();p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(p),'head':HEAD,'tree':manifest['tree'],'ownedFiles':len(owned),'runtimeFiles':len(a['source']['productFiles']),'checks':len(rows),'actualProductMembers':13,'sha256':sha(p.read_bytes())}))
