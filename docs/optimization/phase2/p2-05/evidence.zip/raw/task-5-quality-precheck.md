# P2-05 independent quality precheck — immutable 80da03d

Status: **precheck only; final product/driver approval withheld**. The controller has separately reproduced the known failed outer-project-selection generation defect. This report records additional static findings and does not review any moving working-tree fix or driver overlay.

Reviewed checkpoint: `80da03deab4070aa0bfdae5d38c863392b49bf39`, tree `9ef747490abccb2e20e7e0b9ca38ae8097d21109`, parent/base `5b3949253937f1880bd426b39706c90a1db2e343`. The commit object's parent/tree were checked with `git cat-file -p`. Product and new correctness tests were read with immutable `git show`/`git diff`. No tests, builds, timing, ZIP processing, network, source edits or Git mutations were performed by this reviewer. This external report is the only written file.

Read scope: task-5 brief/readiness/controller audit; registered `PHASE_2_OPTIMIZATION.md`; Phase 1 DESIGN D05/API ownership and HANDOFF; P205 DESIGN/README; changed store/closure/registry/UI source and new correctness tests; unchanged validators, pin preparation and native writer/export/recovery boundaries. The final comparison driver remains for the later exact frozen checkpoint review.

## Q1 — blocker: an externally retained snapshot suppresses checking its conflicting selected native outer row

At checkpoint `src/storage/worldClosure.ts:18`, `provided` includes snapshots from every loaded world row as well as the operation's own root. Line 46 then skips any typed ID in this set before trying its native outer key. Because explicit editions are loaded first, a healthy new-edition row retaining an older snapshot can hide a conflicting native row keyed by that older snapshot, even when the current editor directly uses that older snapshot in a typed anchor.

Concrete literal shape for the sole coder's RED, with individually well-formed contents and real hashes:

| Meaning | Literal ID |
| --- | --- |
| Work W | `a2050000-0000-4000-8000-000000000001` |
| External world P | `a2050000-0000-4000-8000-000000000002` |
| Older snapshot O | `a2050000-0000-4000-8000-000000000010` |
| Newer snapshot N | `a2050000-0000-4000-8000-000000000011` |
| P's character C | `a2050000-0000-4000-8000-000000000020` |

- W has no local snapshots. It explicitly references `{projectId:P, immutableSnapshotId:N, contentHash:H_N}` and contains a note with a rich-text link target `{entityId:C, sourceVersionId:O}`.
- Native `worlds[N]` is a complete immutable row `{id:N, project:{...newEnvelopeOfP, snapshots:[newPinN, oldHealthyO], history:[]}}`. `oldHealthyO.id=O`, its content belongs to P and contains C, and its content hash is H1. N may itself quote O, as in the existing differently-keyed test, so the whole retained row is a realistic pin envelope.
- Native `worlds[O]` is another complete row `{id:O, project:{...oldConflictingEnvelopeOfP, snapshots:[oldConflictingO], history:[]}}`. `oldConflictingO.id=O`, same P/character ID, but a literal content field differs from `oldHealthyO` and its correctly recomputed hash H2 differs from H1. All other selected data is healthy. This is a native selected-ID corruption injection after valid seeding, not a request to permit conflicting guarded writes.

Checkpoint path: scan W queues explicit N and typed O; read N; scanning its complete row adds O to `provided`; typed O is skipped at line 46. Only `worlds[N]` reaches `worldSnapshotContents`, so that validator never compares the conflicting O row.

Exact baseline/full-oracle comparison was checked statically:

- Base `store.ts:883–888`: `pending` begins with explicit N; W's typed O is appended; `pop()` reads O before N. Both native rows reach unchanged `worldSnapshotContents`, whose `archiveData.ts:354–356` collision check throws `IMMUTABLE_SNAPSHOT` for the two different contents at O.
- Base non-selected `getProjectForEditing` uses the full registry at `store.ts:719`; base full read uses it at `:676`; base save at `:1005`. They also expose both copies to that unchanged validator.
- An independent oracle `worldSnapshotContents(allNativeRows)` or `validateColdRead(W, allNativeRows)` encounters the same collision irrespective of row iteration order. The first installs O; the other finds unequal O content and throws. The checkpoint's selected result omits the evidence required for this check.

This is distinct from ignoring unrelated corrupt bodies: O is the literal typed source used by W. It is also distinct from a root-local own snapshot: W has no local O. On a genuine direct-key miss, the complete external N row can still resolve O without fabricating absence or forcing an unrelated full scan. On a direct hit, the relevant outer O row must not be silently hidden by externally supplied `provided` membership. Keep complete rows and existing content/hash/owner/collision validators; do not weaken the valid old-under-new test or global guarded writers.

Runtime RED is **NOT RUN by reviewer**. The line-by-line baseline/oracle counterexample is sufficiently concrete to block quality approval pending the coder's independent reproduction and fix/proof.

## Q2 — blocker candidate: adoption refresh can erase a newer preview owned by the same editor revision

At checkpoint `App.tsx:254`, `applyProject` advances the work revision and resets preview ownership. `WorldVersions.tsx:35` now depends on `project.revision`, so it starts a fresh source load for that revision. Independently, `pinWorld` awaits the adopted-closure refresh and then calls `setWorldRegistryState(ownWorldRegistry(..., worlds))` at `App.tsx:257`. `ownWorldRegistry` always creates `preview:{}` (`worldSources.ts:5–6`).

Deterministic scheduling counterexample: a source B offers both an older edition B1 and a newer unadopted edition B2. Pin B1. Hold only `pinWorld`'s `listEditorWorldSnapshots(result.project)` result for the work ID after its real read completes. Let the revision-triggered WorldVersions B load finish and publish B2's source graph under the same new work ID/revision/generation. Release the held adopted-closure result. The unconditional `ownWorldRegistry` replacement discards that freshly published preview, while WorldVersions' `sourceLoad` stays loaded and still offers B2 in its snapshot picker. Opening a B2-only literal detail can no longer resolve through App's `worldSources`.

The expected ownership behavior is to update the adopted closure while preserving a current same-owner preview; a mismatched owner must still be rejected. This is independent of the known failed outer-selection generation defect. Runtime RED is **NOT RUN by reviewer**; the controller has sent this schedule to the sole coder before final freeze. Final review must check the actual outcome/fix, including immutable detail resolution rather than only registry Map keys.

## Q3 — scoped owned lifecycle gap: abort after durable commit still advances private cache state

The new `rememberProject(candidate, operationId, historyIds, saveCapture)` call at checkpoint `store.ts:1127` fences token identity, access and store lifetime, but does not inspect `options.signal`. Aborting after native commit and before this continuation leaves the token valid and still publishes the new revision into the four private cache collections.

Requirement source is the owned task-5 brief cache paragraph: “Handle account/role/lifetime/cancel/release and late completion without repopulation.” I have not found an original acceptance contract requiring a post-commit save to reject; this behavior existed in the baseline save path and must not be presented as a newly introduced API regression.

Precise RED scope: seed/cache revision 1, start a revision-2 save with an AbortSignal, hold only the already-committed save transaction result using the same barrier pattern as new ownership test lines 49–54, abort without calling release/close/access changes, then resume. Canonical header must remain revision 2, history/outbox gain exactly the one successful save, and the API may return that canonical success. The cancelled completion must not advance `cachedProjects` to revision 2 via `rememberProject`; a valid pre-existing revision-1 cache tuple may remain. Do not assert all caches are zero and do not throw/roll back an already committed save to satisfy a cache test. This concerns private cache publication only; it is not evidence of a UI publication bug. A skip-cache-on-aborted check can preserve the original post-commit return contract.

Runtime RED is **NOT RUN by reviewer**. Resolve or explicitly scope this owned cache-lifecycle expectation before final approval.

## Scoped clean observations

- The four graph/head/history/completeness collections are removed together. LRU capacity four is an internal retention policy, not a domain/input limit. Identity epochs are removed on release, cannot match a recreated identity, and unsuccessful/missing read paths have cleanup. Weak history tokens, caller drafts and active operation graph captures are not evicted with the cache.
- Save now captures cached previous/history IDs/head synchronously and uses the returned hydrated graph plus its `readBaselines` metadata when publication is refused. The parent operation comes from that same tuple rather than a later cache lookup. Ordinary pressure/release need not become a false revision conflict. The unchanged native revision/replay/atomic commit guards remain in place.
- Known roots walk current/snapshots/alternatives/history and preserve whole immutable rows; transitive discovery and unknown shape/owner fallback remain. Q1 limits approval of the collision case. Complete export/recovery still obtains the original full single registry capture, and selected history keeps P204 materialization.
- The diff does not edit original fixture/test/assertion/timeout/retry/skip files or numerical conditions. `archiveData`, `worldPins`, `pinnedWorlds`, `readValidationCore` and native export source are unchanged. Existing guarded native pin/ACK/import collision and canonical/outbox/asset code is retained; no canonical pruning was added.
- Store collection counts and canonical payload estimates are distinct from UI registry retention and browser heap reachability. No measurement or heap-release conclusion is made here. Parent-reported unit/HTTP/CI results were not rerun or independently reclassified.

Final approval requires the controller's subsequent exact clean product+driver freeze, reviewed resolution of these findings and the already known outer-selection defect, then the authorized evidence/review gates. No timing approval is granted by this precheck.
