"""Historical controller check of actual frozen P205 capture artifacts."""
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path('/workspace/phase2-progress')
REPO = Path('/workspace/phase2')
CANDIDATE = '260957a9ec25f3afeda8bede6481ceb2e417685f'
BASELINE = '5b3949253937f1880bd426b39706c90a1db2e343'
TREES = {CANDIDATE: '4f2527db1b42eaa3fa7d303c2f9abbadc48ce247', BASELINE: 'c24e4391ac29a1e2ef9af3aecc65ae145b13b59a'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check_blobs(head, rows):
    refs = ''.join(head + ':' + row['path'] + '\n' for row in rows).encode()
    out = subprocess.run(['git', '-C', str(REPO), 'cat-file', '--batch'], input=refs, check=True, capture_output=True).stdout
    position = 0
    for row in rows:
        end = out.index(b'\n', position)
        parts = out[position:end].split()
        assert len(parts) == 3 and parts[1] == b'blob', (head, row['path'])
        size = int(parts[2])
        data = out[end + 1:end + 1 + size]
        position = end + 2 + size
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], (head, row['path'])
        if 'gitBlob' in row:
            assert parts[0].decode() == row['gitBlob']
    assert position == len(out)

sources, overlays, records, pairs, heap = {}, None, [], {}, []
for size, count in [('standard', 26), ('large', 26), ('supplemental', 22)]:
    for variant, head in [('baseline-5b', BASELINE), ('candidate-260', CANDIDATE)]:
        name = f'p205-capture-{variant}-{size}-1'
        folder = ROOT / name
        result_bytes = (folder / 'result.json').read_bytes()
        data = json.loads(result_bytes)
        source, observation = data['source'], data['observations']
        expected_ui_failure = size == 'supplemental' and head == BASELINE
        assert data['mode'] == 'capture' and data['suite'] == size
        assert data['status'] == ('error' if expected_ui_failure else 'ok')
        assert source['head'] == source['productHead'] == head
        assert source['tree'] == source['productTree'] == TREES[head]
        if head not in sources:
            check_blobs(head, source['productFiles'])
            sources[head] = source['productFiles']
        else:
            assert source['productFiles'] == sources[head]
        current_overlays = [{k: row[k] for k in ('path', 'bytes', 'sha256')} for row in source['overlays']]
        assert len(current_overlays) == 7
        if overlays is None:
            overlays = current_overlays
            check_blobs(CANDIDATE, overlays)
        else:
            assert current_overlays == overlays
        if expected_ui_failure:
            assert len(data['errors']) == 1
            message = data['errors'][0]['message']
            assert 'P205 newer-only place 0' in message and 'P205 place 0' in message and 'Timeout: 5000ms' in message
            assert data.get('finishedAt') is None
        else:
            assert not data['errors'] and data['finishedAt']
        assert observation.get('activeOperation') is None
        off, on = {}, {}
        for row in observation['operations']:
            assert row['status'] == 'ok' and row['apiCompletion'] == 'fulfilled'
            assert not row.get('error') and not row.get('observationError')
            destination = on if row['probeEnabled'] else off
            assert row['label'] not in destination
            destination[row['label']] = row
            if row['probeEnabled']:
                assert row['counterCompleteness'] == 'settled capture' and isinstance(row['probe'], dict)
                assert 'milliseconds' not in row
            else:
                assert isinstance(row['milliseconds'], (int, float)) and math.isfinite(row['milliseconds']) and row['milliseconds'] >= 0
                assert 'probe' not in row
        assert len(off) == len(on) == count and off.keys() == on.keys()
        fixture_check = ROOT / (f'p205-check-{variant if head == BASELINE else "candidate"}-final-{size}-api-1' if size != 'supplemental' else ('p205-check-baseline-5b-final-overlay-supp-1' if head == BASELINE else 'p205-check-candidate-final-supp-1')) / 'result.json'
        fixture = observation['fixture']
        assert fixture == json.loads(fixture_check.read_text())['observations']['fixture']
        if size == 'large':
            original = fixture['original']
            assert original['input']['bytes'] == 59407368 and original['counts']['totalRecords'] == 88003
            assert original['assetBytes'] == 75497472 and len(original['assets']) == 3
            assert all(asset['bytes'] == 25165824 and asset['sha256'] == asset['declaredHash'] for asset in original['assets'])
        build = data['build']
        archive_bytes = (folder / build['zip']['path']).read_bytes()
        assert len(archive_bytes) == build['zip']['bytes'] and sha(archive_bytes) == build['zip']['sha256']
        with zipfile.ZipFile(folder / build['zip']['path']) as archive:
            names = archive.namelist()
            assert len(names) == len(set(names)) == 12 and archive.testzip() is None
            assert set(names) == {row['path'] for row in build['files']}
            for name in names:
                path = PurePosixPath(name)
                assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
            for row in build['files']:
                actual = archive.read(row['path'])
                assert len(actual) == row['bytes'] and sha(actual) == row['sha256']
        if size == 'standard':
            diagnostic = data['heap']
            assert diagnostic['status'] == 'observed' and diagnostic['facility'] == 'CDP Runtime.getHeapUsage'
            assert diagnostic['freshContext'] is True and diagnostic['forcedGC'] is False and len(diagnostic['rows']) == 4
            heap.append({'variant': variant, 'scope': 'SMALL supplemental six-world fresh context; not original-size/72MiB heap, peak or reachable-retained proof', 'rawDiagnostic': diagnostic})
        if size == 'supplemental':
            assert data['sameRevisionUI']['status'] == 'ok'
            boundaries = [row for row in data['uiCheckpoints'] if row['action'] == 'six-source UI retention boundary']
            assert len(boundaries) == 6
            if not expected_ui_failure:
                assert data['ui']['status'] == 'ok' and data['ui']['allSixPickerChoicesPreserved'] and data['ui']['adoptedEditionPreserved']
        else:
            assert data['ui']['status'] == 'NOT RUN' and '--ui' in data['argv'] and data['argv'][data['argv'].index('--ui') + 1] == 'false'
        pairs.setdefault(size, {})[variant] = off
        records.append({'path': name + '/result.json', 'resultBytes': len(result_bytes), 'resultSha256': sha(result_bytes), 'head': head, 'tree': TREES[head], 'status': data['status'], 'expectedUIFailure': expected_ui_failure, 'finishedAt': data.get('finishedAt'), 'OFF': count, 'ON': count, 'allAPIsFulfilled': True, 'allONSettled': True, 'actualBuildArchive': build['zip'], 'actualBuildMembers': 12, 'CRCAndAllMemberBytesSHA': True, 'sourceGitBlobsIndependentlyVerified': len(source['productFiles']), 'fixtureMetadataEqualsExactFinalCheck': True})

comparisons = []
for size, variants in pairs.items():
    base, candidate = variants['baseline-5b'], variants['candidate-260']
    assert base.keys() == candidate.keys()
    for label, row in base.items():
        before, after = row['milliseconds'], candidate[label]['milliseconds']
        comparisons.append({'size': size, 'label': label, 'baselineMilliseconds': before, 'candidateMilliseconds': after, 'deltaMilliseconds': after - before, 'candidateSlowerStrictRawFloat': after > before, 'scope': 'single OFF observation per variant; no distribution/significance/acceptance claim'})
assert len(comparisons) == 74
report = {'purpose': 'Independent actual P205 capture source/build/row/fixture-metadata verification; not acceptance promotion', 'candidate': CANDIDATE, 'baseline': BASELINE, 'runs': records, 'allSixActualBuildZIPsAnd72MembersVerified': True, 'sameSevenOverlayBlobs': overlays, 'fulfilledAPIRows': 296, 'OFFComparisons': comparisons, 'strictRawUnfavorablePairs': sum(row['candidateSlowerStrictRawFloat'] for row in comparisons), 'SMALLInstantaneousHeapOnly': heap, 'expectedBaselineUIFailurePreserved': True, 'originalSizeHeapPeakReachableRetainedMemory': 'UNKNOWN', 'scriptSHA256': sha(Path(__file__).read_bytes()), 'acceptancePromoted': False}
with (ROOT / 'p205-capture-parent-verification.json').open('x') as output:
    output.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'runs': len(records), 'buildMembers': 72, 'fulfilledAPIRows': 296, 'OFFPairs': len(comparisons), 'unfavorablePairs': report['strictRawUnfavorablePairs'], 'singleObservations': True, 'acceptancePromoted': False}))
