# P2-05 readiness — READ-ONLY preparation / implementation NOT STARTED

2026-10-17。親が通知した凍結点は product `0479d4eedae9b51fbc6fd785265bbbc2de870e78` + driver `547ab05dd38fe36c939a94c80c236582d3d8ef77`。Git照合はしていない。P204所有権を維持し、後続の正確な最終base/branchとactivateを待つ。source/Git/DB変更、test/build/benchmark/ZIP/hash/network、helper起動は一切実施していない。この外部ファイルだけを作成した。

読了: task-5-brief / p2-05-audit / phase1 DESIGN D05・API所有境界 / HANDOFF、および下記の現行source。以下は静的仮説とRED候補であり、失敗再現・実測結果ではない。

## 現状と設計比較

- **P201を再実装しない。** `store.ts:781–796`のloadEditor/releaseEditor、`App.tsx:311–327`のselection fenceと前editor解放は既存。selected current closureは`store.ts:879–890`。snapshot/alternativeを含むtyped参照も歩き、direct `worlds.get(id)`が見つからなければ安全なfull registryへ戻る。
- **owner discovery不足。** `projectSummary.ts:39–47`のStoredWorldSource v1は外側key・project/name/revisionだけで、内包する旧snapshot IDを列挙しない。`archiveData.ts:345–358`は内包snapshotをworldSnapshotContentsに展開するため、外側newにだけ保存されたoldをcurrentのtyped anchorが参照できる。direct key不在をabsentに変えてはいけない。
- **採用候補A:** operation別root集合を選び、immutable row全体を取得するclosure readerを共有する。高速経路は外側key直読、既知の内包ID→実際の外側owner探索。catalogの互換version/完全性を証明できない場合、未知の参照形・catalog drift・owner不明では元full registry取得＋元検証へ戻す。catalogは発見用で、owner/hash/schema/bodyの検証証拠にはしない。保存済みworld rowは切り詰めず、writerのglobal collision guardを残す。
- **棄却候補:** currentのworldReferencesだけを全operationへ流用、旧snapshotごとにnative rowを合成、常時全pin共有/refcount cache。前二者は履歴・引用・recoveryの欠落/形式変化、後者はD05で保留した複雑な寿命管理になる。

owner発見の静的代案（いずれも未実装）:

| 案 | 費用・完全性・全writer/失効・rollback |
| --- | --- |
| 現行direct＋不明時full scan、operation内だけowner map | 移行/永続metadataなし。unknown pathはO(registry rows＋内包snapshot)のまま。全rowを取得した同じimageから実際の外側keyを発見し元owner/hash検査。writer保守は不要、operation終了でmap解放、旧full readerへ即復帰可。まず比較する最小案。 |
| derived worldSources catalogをversion拡張し内包ID/hash/owner候補を列挙 | 通常pathのbody読込削減候補だがcatalog読込/保存bytesが増える。v1/欠損/不正/未知完全性はfullへ戻す。save pin追加・受信ACK・importの全guarded writerで同一transaction保守、再導出/失効が必要。catalog自体をbody検証にしない。読込側無効化→全scanへrollback、canonical rowは不変。 |
| canonical owner metadataの新設 | 新しい完全性契約・全writer/migration/recovery義務を増やす。derived discoveryで足りるか未確認のため現時点では選ばない。追加設計/比較なしにcanonical形式を変更しない。 |

| operation | 必要なrootと維持する検査 | 現行位置 |
| --- | --- | --- |
| current/editor | 完全current、保持snapshot、alternative、typed anchor/reuse/runtime由来。history本文を新たに読まない | store.ts:689–731,879–890 |
| save/current | captured draftとprevious、保護/追加snapshot・alternative履歴の保存制約、worldPin入力とその推移依存。request hash/owner/collision/atomic性は維持 | store.ts:985–1090、worldPins.ts:9–43 |
| selected history/restore | 選択commandのbefore/afterとcurrentへ戻す候補の依存。materializeの親/checkpoint検査はP204のまま | store.ts:838–842,1119–1169 |
| full read/export/recovery | 全command、snapshot、alternatives、pending/retained/sync recoveryの依存の和。単一native captureと全履歴/native完全性を維持 | store.ts:661–685,1424–1467 |

`referencedWorlds`はgraph全体を歩くがtyped参照のownerはavailable registry由来 (`archiveData.ts:318–342`)。未知ownerを含む計算をO(closure)と記述しない。exportでは全registryを単一captureしてからworkerがclosureを決めるため、先にcurrent closureへ縮める変更は不可。

## cache / UI所有案

- 4 collectionは`store.ts:496–500`、連動削除は538–541。inactive graphの容量上限を設ける場合、cachedProjects/contentHeads/cachedHistoryIds/completeHistoriesを一括で退避する。数値capacityは実装選択として証拠を付け、入力上限にしない。cacheEpochs等のmetadata件数も別に報告する。
- **save captureを先に修正する必要がある。** `saveProject:1002–1004`はhydrateの返却値を捨て、cacheに戻った前提でpreviousを取得し、1049ではcontentHeadsを再参照する。一方`rememberProject:549–559`は失効時に検証済み値をcacheせず返せる。hydrate後/await中の退避で偽REVISION_CONFLICTやparent消失が起こり得る。operationローカルの一貫した{previous, historyIds, contentHead} captureまたはactive-save leaseをawait前から保持し、通常退避と内容/アクセス失効を区別する。canonical commit側の再検査は残す。
- editingHistoriesはhistory配列をkeyに持つWeakMapでproject/revision/historyIdsのみ (`504,563–568,997–1017`)。通常の退避・選択解放で有効draftのtokenを無効化しない。account/access/lifetime/内容置換の失効は別のtoken/fenceで扱い、UIが保持するhistory tokenを容量圧力で捨てない。
- numeric epochを削除してdefault 0へ戻すと古いreadの0と一致するABAがある。候補はprojectごとの所有token identityをcaptureし、publication時に同一identity/access/lifetimeを照合する方式。tokenをMapから除去/再作成しても古いtokenは一致させない。active read/save所有とcache所有がなくなったmetadataは解放可能にするか、残すmetadataが非有界なら正直に別計上する。既存のnewer revision/late-read fenceは保持する。
- `WorldVersions.tsx:23–35`は選択sourceLoadを置換しcleanupでreleaseEditorするが、`App.tsx:407`は世界graphをworldRegistryへ累積mergeする。UI registryはstore cacheとは独立のretention owner。現在採用済みclosure＋現在preview owner/generation/revisionのgraphを保持し、preview終了/次source成功/selection交換で不要分を解放する案。pickerのregistryChoices (`App:63–65`) は全選択肢を保持し、preview失敗時のworldId/snapshotId/adopted等入力を変えない。pin保存の採用closure再取得fence (`App:247–255`) を維持する。

## activate後、REDで固定する具体反例

すべてvalid registryでの旧full-registry oracle一致と、独立したliteral ID/hash/history/row期待値を併用する。下記のREDはまだ未実行。

1. **外側new内のold:** oldだけにある人物をcurrentのtyped sourceVersionIdから参照、nativeにはnew rowだけ。oldとnewを正確に解決しwhole rowを保持。direct missで欠落にせず、未知catalogではfull fallbackを実際に通す。oldのowner/hashを変えたケースは拒否。
2. **closure差:** A→B→C推移pin、currentから消えたold pinをsnapshot/alternative/selected history/reuse/runtime/pending recoveryだけに残す。current用、save用、restore用、export用の期待集合を個別にliteral指定し、full export/import new/clone/coldで過去依存を失わない。
3. **衝突/破損:** 同ID異hash/異owner、二つの外側rowの内包ID衝突、cycle、missing/corrupt/unsupported selected row、catalog欠損/不正/旧version。元検証で拒否、canonical/outbox/assetsと入力は不変。無関係破損があってもP201のhealthy selected/current分離は保持。
4. **退避圧力:** N作品と複数world sourceを順に読む。4 collectionのkey整合・graph容量・epoch/discovery metadata件数を別々にassert。現在選択世界の依存と未保存draft/token、canonical/outbox/assetsは保持する。
5. **hydrate→save race:** save対象をcoldにし、getProjectForEditing/getProjectが返る直前をbarrierで保持。別previewの読込で容量圧力/通常releaseを発生させてから再開。妥当な保存はexactly revision+1、history/outbox各1追加、contentHead親は直前operation。偽REVISION_CONFLICTを起こさず入力を保持する。
6. **late read ABA:** epoch 0のcold readをvalidation後で停止→release/退避→同ID再取得→古いread再開。4 collectionすべてを旧graph/履歴へ戻さず、再作成tokenが旧tokenと一致しない。close→reopen、account/access/role取消も同様に照合する。
7. **late save publication:** 実commit後cache publication直前を停止→release/close/role変更→再開。既に成立したcanonical結果とcache/UI publicationを区別し、失効後の4 collection/UI graph再投入は0。通常退避中の有効active-save captureは保持する。
8. **weak history token:** 同じrevision/historyのclean/dirty editorを保持したまま他作品を巡回し退避→再保存。tokenをretentionだけで拒否しない。別project/revisionへ付け替えたtoken、実際の置換/権限失効は元契約で拒否する。
9. **UI preview retention:** 採用世界Aを保ったままB→C→失敗D。Aと現在必要previewだけのgraph保持、全registry-only選択肢不変、D失敗で選択/入力不変、遅いB結果はCや別editorへ公開しない。pin save完了時のA→B→A generation差も維持する。

再利用する元試験: `cacheConcurrency.test.ts` (cancel/close/old-read/replacement)、`worldPins.test.ts` (atomic/transitive/earlier snapshot/global collision/import race)、元pin/hash/atomic/import/export/recovery/coldおよびP201選択/clean-dirty alternative unload証拠。原fixture/seed/bytes/assert/timeout/retry/skipは変更しない。

## 残る確認と測定ゲート

- 正確なP204最終head/branch、最終metadata/materialize境界、P204 driverのfailure duration/active-operation evidence教訓をactivate後に再照合する。catalog拡張の全writer保守と旧版fallback、saveローカルcaptureとleaseどちらが最小変更かはREDで決める。
- product＋独立正確性試験＋比較driverを揃え、default check-modeでfixture/oracle確認→clean frozen headの独立spec/quality承認→親のexclusive slot通知までtiming captureを開始しない。
- 同一Standard/Large・multi-work/source順序でOFF waitとON rows/hash/bytesを分離。store4 collection/epoch/owner metadata、UI registryのentries/records/canonical payload estimateを別計上。unknown full fallbackの費用を残す。heapは別fresh-contextの実CDP能力結果/瞬間値とGC/JIT/browser範囲限界を記録し、Map減少をheap release合格にしない。
- 原104/116/464/24/6/68/73、94local/22external、RELEASE BLOCKEDを維持。正式8metrics×2sizes×30/180save/7200/113history72MiB new/clone/coldは人間統合後Stage3のみ。

Status: READ-ONLY preparation complete; stopped pending explicit activate. 性能/RED/GREENはすべてNOT RUN。
