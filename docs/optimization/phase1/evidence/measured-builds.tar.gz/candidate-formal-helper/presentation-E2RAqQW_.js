//#region src/observability/probe.ts
var e = /* @__PURE__ */ "store.list,store.read,store.fullRead,store.save,store.history,store.export,store.import,save.prepare,save.read,save.hash,save.reconcile,save.validate,save.diff,save.database,copy,capture,normalize,targetChanges,contentDelta,writeContent,hydrate,decode,validate.current,validate.integrity,validate.full,query.filter,query.index,reference.choices,ui.filter,ui.indices,worker.read,worker.parts,worker.archive,ui.startup,ui.save".split(","), t = /* @__PURE__ */ "db.read.calls,db.read.rows,db.read.keys,db.read.payloadBytes,db.read.requested,db.write.calls,db.write.attempted,db.write.succeeded,db.write.committed,db.write.aborted,db.write.payloadBytes,db.deleteRange.calls,db.transaction.committed,db.transaction.aborted,hash.calls,hash.bytes,json.calls,json.bytes,copy.calls,copy.payloadBytes,capture.calls,capture.payloadBytes,normalize.rows,targetChanges.rows,contentDelta.rows,writeContent.rows,hydrate.rows,decode.rows,decode.payloadBytes,validate.current.calls,validate.integrity.calls,validate.full.calls,query.index.builds,query.index.rows,query.text.rows,query.filter.rows,reference.choices.rows,reference.index.builds,reference.index.rows,ui.filter.rows,ui.indices.rows,worker.started,worker.terminated,worker.sent.messages,worker.sent.payloadBytes,worker.received.messages,worker.received.payloadBytes,cache.projects,cache.records,cache.payloadBytes,cache.invalidated,memo.hit,memo.miss,probe.size.unknown,probe.size.milliseconds".split(","), n = /* @__PURE__ */ "projects.entities.relations.blocks.snapshots.commands.outbox.assets.views.viewStates.syncMetadata.acks.restorePoints.worlds.importLogs.importDrafts.authorToolDrafts.workspaceInputs.recoveredPending.retainedSyncRecovery.syncAssetAcks.syncBases.preparedSync.syncConflicts.syncAckEvidence.sharedSnapshots.recordParts".split("."), r;
new Set(e);
var i = new Set(t), a = new Set(n), o = () => !1;
function s() {
	let e = d(), t;
	return new Promise((e) => {
		t = e;
	}), {
		count: e,
		finish() {
			t?.();
		}
	};
}
function c(e, t, n, r) {
	if (!e || !i.has(t) || r !== void 0 && !a.has(r) || !Number.isFinite(n) || n < 0) return;
	let o = r === void 0 ? t : `${t}.${r}`, s = (e.counters[o] ?? 0) + n;
	Number.isFinite(s) && (e.counters[o] = s);
}
function l(e, t = 1, n) {
	c(r, e, t, n);
}
function u(e, t) {}
function d() {
	let e = r;
	return (t, n = 1, r) => c(e, t, n, r);
}
function f(e, t, n = "ok") {}
function p(e) {
	return (e) => {};
}
function m(e, t) {
	return t();
}
function h(e, t, n) {}
function g(e) {
	let t = p(e), n = d();
	n("worker.started");
	let r = !1;
	return () => {
		r || (r = !0, n("worker.terminated"), t());
	};
}
function _() {
	return (e, t) => {};
}
//#endregion
//#region src/storage/errors.ts
var v = class extends Error {
	code;
	path;
	constructor(e, t, n, r) {
		super(t, r), this.name = "StorageError", this.code = e, this.path = n;
	}
};
function y(e) {
	if (e?.aborted) throw new v("CANCELLED", "処理を取り消しました。既存の作品は変更していません。");
}
function b(e) {
	if (e instanceof v) return e;
	let t = e instanceof Error && /quota/i.test(e.name + e.message);
	return new v(t ? "QUOTA_EXCEEDED" : "SAVE_FAILED", t ? "保存容量が不足しています。入力を保持して完全ファイルへ書き出すか、容量を確保して再試行してください。" : "端末内への保存に失敗しました。入力を保持して再試行してください。", void 0, { cause: e });
}
//#endregion
//#region src/storage/json.ts
var ee = "1.0.0", te = Object.freeze({
	compressedBytes: 67108864,
	expandedBytes: 268435456,
	jsonBytes: 67108864,
	assetBytes: 33554432,
	files: 5e3,
	records: 1e5,
	depth: 32,
	objects: 5e5,
	conditionDepth: 16,
	conditionNodes: 256,
	fieldBytes: 1048576
}), ne = /[\uD800-\uDFFF]/u;
function x(e) {
	return !ne.test(e);
}
function re(e, t, n = te, r = { objects: 0 }) {
	if (e.byteLength > n.jsonBytes) throw new v("LIMIT_EXCEEDED", "JSONファイルが上限を超えています。", t);
	if (e[0] === 239 && e[1] === 187 && e[2] === 191) throw new v("ARCHIVE_INVALID", "JSONのBOMは使用できません。", t);
	let i;
	try {
		i = new TextDecoder("utf-8", { fatal: !0 }).decode(e);
	} catch (e) {
		throw new v("ARCHIVE_INVALID", "JSONは有効なUTF-8である必要があります。", t, { cause: e });
	}
	let a = 0, o = (e) => {
		throw new v("ARCHIVE_INVALID", `${e}（位置 ${a}）`, t);
	}, s = () => {
		for (; /[ \t\n\r]/.test(i[a] ?? "") && a < i.length;) a++;
	};
	function c() {
		let e = a++;
		for (; a < i.length;) {
			let t = i[a++];
			if (t === "\"") {
				let t;
				try {
					t = JSON.parse(i.slice(e, a));
				} catch {
					return o("文字列が不正です。");
				}
				return x(t) ? t : o("Unicodeのサロゲートが不正です。");
			}
			t === "\\" && a++;
		}
		return o("文字列が閉じられていません。");
	}
	function l(e) {
		s();
		let u = i[a];
		if (u === "\"") return c();
		if (u === "{" || u === "[") {
			if (e > n.depth || ++r.objects > n.objects) throw new v("LIMIT_EXCEEDED", "JSONの構造が安全上限を超えています。", t);
			let d = u === "{";
			a++, s();
			let f = d ? "}" : "]", p = d ? Object.create(null) : [], m = /* @__PURE__ */ new Set();
			if (i[a] === f) return a++, p;
			for (; a < i.length;) {
				if (s(), d) {
					if (i[a] !== "\"") return o("オブジェクトのkeyが不正です。");
					let t = c();
					if (m.has(t)) return o(`key「${t}」が重複しています。`);
					if (m.add(t), s(), i[a++] !== ":") return o("keyの後にコロンが必要です。");
					p[t] = l(e + 1);
				} else p.push(l(e + 1));
				s();
				let t = i[a++];
				if (t === f) return p;
				if (t !== ",") return o("区切り文字が不正です。");
			}
			return o("JSONが閉じられていません。");
		}
		for (let [e, t] of [
			["true", !0],
			["false", !1],
			["null", null]
		]) if (i.startsWith(e, a)) return a += e.length, t;
		let d = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(i.slice(a));
		if (!d) return o("値が不正です。");
		a += d[0].length;
		let f = Number(d[0]);
		return Number.isFinite(f) ? f : o("有限でない数値は保存できません。");
	}
	let u = l(1);
	return s(), a !== i.length && o("JSONの末尾に余分なデータがあります。"), u;
}
function ie(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new WeakSet();
	function r(e) {
		if (e !== null && typeof e != "boolean") {
			if (typeof e == "string") {
				if (!x(e)) throw new v("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
				return;
			}
			if (typeof e == "number") {
				if (!Number.isFinite(e)) throw new v("VALIDATION_FAILED", "有限でない数値は保存できません。");
				return;
			}
			if (typeof e != "object") throw new v("VALIDATION_FAILED", "JSONに保存できない値があります。");
			if (t.has(e)) throw new v("VALIDATION_FAILED", "循環したJSONは保存できません。");
			if (!n.has(e)) {
				if (t.add(e), Array.isArray(e)) e.forEach(r);
				else for (let t of Object.keys(e)) {
					let n = e[t];
					n !== void 0 && r(n);
				}
				t.delete(e), n.add(e);
			}
		}
	}
	r(e);
}
function ae(e) {
	let t = /* @__PURE__ */ new WeakMap(), n = 0, r = 0;
	return {
		get: (e) => t.get(e),
		set(i, a) {
			if (!e(i) || Array.isArray(i)) return;
			let o = Object.getPrototypeOf(i);
			if (o !== Object.prototype && o !== null) return;
			let s = Object.getOwnPropertyDescriptors(i);
			if (typeof s.id?.value != "string" || typeof s.kind?.value != "string" || Object.values(s).some((e) => !("value" in e))) return;
			let c = a.length * 2;
			c > 65536 || ((r + 1 > 16384 || n + c > 33554432) && (t = /* @__PURE__ */ new WeakMap(), n = 0, r = 0), t.set(i, a), n += c, r++);
		}
	};
}
function oe(e, t) {
	let n = /* @__PURE__ */ new Set();
	function r(e) {
		if (e === null) return "null";
		if (typeof e == "string") {
			if (!x(e)) throw new v("VALIDATION_FAILED", "Unicodeのサロゲートが不正です。");
			return JSON.stringify(e);
		}
		if (typeof e == "boolean") return String(e);
		if (typeof e == "number") {
			if (!Number.isFinite(e)) throw new v("VALIDATION_FAILED", "有限でない数値は保存できません。");
			return JSON.stringify(e);
		}
		if (typeof e != "object") throw new v("VALIDATION_FAILED", "JSONに保存できない値があります。");
		if (n.has(e)) throw new v("VALIDATION_FAILED", "循環したJSONは保存できません。");
		let i = t?.get(e);
		if (i !== void 0) return i;
		n.add(e);
		let a = Array.isArray(e) ? `[${e.map(r).join(",")}]` : `{${Object.keys(e).filter((t) => e[t] !== void 0).sort().map((t) => `${JSON.stringify(t)}:${r(e[t])}`).join(",")}}`;
		return n.delete(e), t?.set(e, a), a;
	}
	return r(e);
}
var se = (e, t) => {
	let n = new TextEncoder().encode(oe(e, t));
	return l("json.calls"), l("json.bytes", n.byteLength), n;
}, ce = (e, t) => oe(e) === oe(t);
function le(e, t) {
	let n = /* @__PURE__ */ new WeakMap(), r = /* @__PURE__ */ new Set(), i = (e) => new TextEncoder().encode(oe(e)).byteLength, a = (e) => {
		if (!e || typeof e != "object") return Math.min(t + 1, i(e));
		if (r.has(e)) throw new v("VALIDATION_FAILED", "循環したJSONは保存できません。");
		let o = n.get(e);
		if (o !== void 0) return o;
		r.add(e);
		let s = 2;
		if (Array.isArray(e)) {
			s += Math.max(0, e.length - 1);
			for (let n = 0; n < e.length && s <= t; n++) Object.hasOwn(e, n) && (s += a(e[n]));
		} else {
			let n = !0;
			for (let r of Object.keys(e)) {
				let i = e[r];
				if (i !== void 0 && (s += +!n + new TextEncoder().encode(JSON.stringify(r)).byteLength + 1 + a(i), n = !1, s > t)) break;
			}
		}
		return r.delete(e), s = Math.min(s, t + 1), n.set(e, s), s;
	};
	return a(e) > t;
}
async function ue(e) {
	l("hash.calls"), l("hash.bytes", e.byteLength);
	let t = await crypto.subtle.digest("SHA-256", e.slice().buffer);
	return [...new Uint8Array(t)].map((e) => e.toString(16).padStart(2, "0")).join("");
}
function de(e) {
	if (!e || e.includes("\0") || e.includes("\\") || e.startsWith("/") || /^[a-z]:/i.test(e) || e.split("/").some((e) => !e || e === "." || e === "..") || !x(e)) throw new v("UNSAFE_PATH", "危険なファイルパスです。", e);
}
//#endregion
//#region src/domain/pinnedWorlds.ts
function fe() {
	return {
		hashes: /* @__PURE__ */ new WeakMap(),
		registryClones: /* @__PURE__ */ new WeakMap(),
		stableRegistries: /* @__PURE__ */ new WeakSet()
	};
}
function pe(e, t) {
	let n = t.registryClones.get(e);
	if (n) return n;
	let r = structuredClone(e);
	return t.registryClones.set(e, r), t.stableRegistries.add(r), r;
}
function me(e, t) {
	let n = [], r = [], i = [], a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = [...e.worldReferences].reverse().map((e) => ({ reference: e })), u = 0;
	for (; l.length;) {
		if (++u > 2e5) {
			i.push("共通世界の依存数が安全上限を超えています。");
			break;
		}
		let e = l.pop();
		if ("exit" in e) {
			o.delete(e.exit);
			continue;
		}
		let d = e.reference, f = d.immutableSnapshotId;
		if (o.has(f)) {
			i.push("共通世界の固定版参照が循環しています。");
			continue;
		}
		let p = c.get(f);
		if (p && p !== d.contentHash) {
			i.push("同じ共通世界の固定版に異なる内容ハッシュが指定されています。");
			continue;
		}
		c.set(f, d.contentHash);
		let m = s.get(d.projectId);
		if (m && m !== f) {
			i.push("同じ共通世界の異なる版が同時に参照されています。");
			continue;
		}
		if (s.set(d.projectId, f), a.has(f)) continue;
		let h = t[f];
		if (!h || h.projectId !== d.projectId) {
			i.push("参照した共通世界の固定版がありません。");
			continue;
		}
		if (a.add(f), o.add(f), r.push(d), n.push(h), l.push({ exit: f }), !Array.isArray(h.worldReferences)) {
			i.push("共通世界の依存参照が不正です。");
			continue;
		}
		for (let e of [...h.worldReferences].reverse()) l.push({ reference: e });
	}
	return {
		worlds: n,
		references: r,
		errors: i
	};
}
async function he(e, t, n = "worldReferences", r) {
	let i = me(e, t), a = i.errors.map((e) => ({
		code: "REFERENCE_INVALID",
		path: n,
		message: e
	}));
	for (let e of i.references) {
		let i = t[e.immutableSnapshotId];
		if (!i) continue;
		let o = `${e.immutableSnapshotId}\0${e.contentHash}`, s = r?.hashes.get(i);
		r && !s && (s = /* @__PURE__ */ new Map(), r.hashes.set(i, s));
		let c = s?.get(o);
		c || (c = ue(se(i)), s?.set(o, c)), await c !== e.contentHash && a.push({
			code: "INTEGRITY_FAILED",
			path: `${n}.${e.projectId}.${e.immutableSnapshotId}.contentHash`,
			message: "共通世界の固定版内容ハッシュが一致しません。"
		});
	}
	return a;
}
//#endregion
//#region src/domain/adoption.ts
function S(e) {
	return !e.deletedAt && e.status !== "rejected" && e.status !== "alternate";
}
//#endregion
//#region src/domain/reuse.ts
var ge = /* @__PURE__ */ new WeakMap(), _e = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), ye = (e, t) => ge.get(e)?.get(t), be = (e) => _e.get(e) ?? e, xe = (e) => e.kind === "scene" || e.kind === "flow_node";
function Se(e, t) {
	let n = e;
	for (let e of t.replace(/\[(\d+)\]/g, ".$1").split(".")) {
		if (!n || typeof n != "object") return;
		if ("sourceVersionId" in n && typeof n.sourceVersionId == "string") return n.sourceVersionId;
		n = n[e];
	}
}
function C(e) {
	throw Object.assign(/* @__PURE__ */ Error(`REFERENCE_INVALID: ${e}`), { issues: [{
		code: "REFERENCE_INVALID",
		path: "reuse",
		message: e
	}] });
}
function Ce(e) {
	if (Array.isArray(e)) return e.flatMap(Ce);
	if (!e || typeof e != "object") return [];
	let t = e;
	return [...typeof t.id == "string" && ("text" in t && "kind" in t || "audienceHolderIds" in t || "eventKey" in t || "x" in t && "y" in t) ? [t.id] : [], ...Object.values(t).flatMap(Ce)];
}
function we(e, t, n) {
	let r = new Map(e.entities.filter(S).map((e) => [e.id, e])), i = new Map(e.entities.flatMap((e) => Ce(e.data).map((t) => [t, e.id]))), a = /* @__PURE__ */ new Map();
	for (let e of r.values()) e.kind === "disclosure" && a.set(e.data.anchor.entityId, [...a.get(e.data.anchor.entityId) ?? [], e]);
	let o = [t], s = /* @__PURE__ */ new Set(), c = [];
	for (let e = 0; e < o.length; e++) {
		let t = o[e];
		if (s.has(t)) continue;
		s.add(t);
		let n = r.get(t);
		n || C("共通元の依存情報が存在しないか、不採用です。"), c.push(n);
		for (let e of a.get(t) ?? []) o.push(e.id);
		for (let e of Bn(n)) {
			if (n.kind === "scene" && e.path === "data.chapterId" || Se(n, e.path) || ![
				"entity",
				"record",
				"presentation",
				"block"
			].includes(e.scope)) continue;
			let t = r.has(e.id) ? e.id : i.get(e.id);
			t && o.push(t);
		}
		c.length > 1e5 && C("共通元の依存情報が100,000件を超えています。");
	}
	return c;
}
var Te = (e) => [...new Set(e.flatMap((e) => [e.id, ...Ce(e.data)]))], Ee = (e, t) => oe(e) === oe(t);
function De(e, t, n) {
	return !!t && [
		"variable",
		"item",
		"character",
		"place",
		"group",
		"assertion",
		"external_contract"
	].includes(e.kind) && t.kind === e.kind && S(t) && e.status === t.status && e.name === t.name && Ee(Wn(e, n).data, t.data);
}
function Oe(e, t) {
	if (Array.isArray(e)) {
		e.forEach((e) => Oe(e, t));
		return;
	}
	if (!e || typeof e != "object") return;
	let n = e;
	typeof n.id == "string" && ("text" in n && "kind" in n || "audienceHolderIds" in n || "eventKey" in n || "x" in n && "y" in n) && (n.id = t[n.id] ?? n.id), Object.values(n).forEach((e) => Oe(e, t));
}
function ke(e, t, n, r) {
	let i = Wn(e, t);
	i.id = t[e.id] ?? e.id, i.projectId = n, Oe(i.data, t);
	for (let t of Bn(e)) if (Se(e, t.path)) {
		let e = t.path.replace(/\[(\d+)\]/g, ".$1").split("."), n = i;
		for (let t of e.slice(0, -1)) n = n[t];
		n[e.at(-1)] = t.id;
	}
	return i;
}
function Ae(e, t, n = []) {
	if (ge.has(e) || !e.entities.some((e) => S(e) && xe(e) && e.data.reuse && e.data.reuse.mode !== "clone")) return e;
	let r = new Map(e.entities.map((e) => [e.id, e])), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set([
		...e.entities.flatMap((e) => [e.id, ...Ce(e.data)]),
		...e.relations.map((e) => e.id),
		...e.views.map((e) => e.id),
		e.projectId
	]), s = new Map(e.worldReferences.map((e) => [e.projectId, e]));
	for (let c of e.entities) {
		if (!S(c) || !xe(c) || !c.data.reuse || c.data.reuse.mode === "clone") continue;
		let l = c.data.reuse, u = t.find((e) => e.id === l.pinnedSnapshotId);
		(!u || u.content.projectId !== e.projectId) && C("共通元の固定版がありません。"), (n.includes(u.id) || n.length >= 32) && C("共通元の固定参照が循環しているか、32段を超えています。");
		let d = Ae(u.content, t, [...n, u.id]), f = d.entities.find((e) => e.id === l.sourceId && S(e));
		(!f || f.kind !== c.kind || !xe(f)) && C("共通元の種類が一致しないか、固定版で不採用です。");
		let p = we(d, f.id, u.id), m = Te(p), h = l.bindings;
		(!h || h[f.id] !== c.id || m.length !== Object.keys(h).length || m.some((e) => !h[e]) || new Set(Object.values(h)).size !== m.length) && C("共通元のID対応が欠落・重複しています。対象版を確認して再設定してください。");
		for (let [e, t] of Object.entries(h)) if (t !== c.id && o.has(t)) {
			let n = p.find((t) => t.id === e);
			(e !== t || !n || !De(n, r.get(t), h)) && C("共通元の実行用IDが現在稿のレコード・段落・関係と衝突しています。ID対応を確認し直してください。");
		}
		let g = new Set(Object.keys(f.data).filter((e) => !["reuse", "chapterId"].includes(e)));
		(l.mode === "reference" && l.overrideFields.length || l.overrideFields.some((e) => !g.has(e))) && C("上書き対象が不正です。宣言したフィールドだけを上書きしてください。");
		for (let e of d.worldReferences) {
			let t = s.get(e.projectId);
			t && !Ee(t, e) && C("共通元と使用先が同じ世界の異なる固定版を要求しています。適用する版を明示して揃えてください。"), s.set(e.projectId, e);
		}
		let _ = d.entities.find((e) => e.kind === "flow_graph" && f.kind === "flow_node" && e.data.nodeIds.includes(f.id)), v = f.kind === "scene" ? f : d.entities.find((e) => f.kind === "flow_node" && e.id === f.data.sceneId && e.kind === "scene");
		for (let t of p) {
			let n = ke(t, h, e.projectId, u.id), o = n.id, s = r.get(o);
			if (o !== c.id && s) {
				(t.id !== o || !De(t, s, h)) && C("共通元の実行用IDが現在稿と衝突しています。対応を再確認してください。");
				continue;
			}
			let f = ye(d, t.id), p = f ? Object.fromEntries(Object.entries(f.bindings).flatMap(([e, t]) => h[t] ? [[e, h[t]]] : [])) : h;
			i.set(o, {
				entityId: f?.entityId ?? t.id,
				sourceVersionId: f?.sourceVersionId ?? u.id,
				ownerId: c.id,
				bindings: p,
				graphId: _ ? h[_.id] ?? _.id : void 0,
				chapterId: v?.kind === "scene" && v.data.chapterId ? h[v.data.chapterId] ?? v.data.chapterId : void 0
			});
			let m = /* @__PURE__ */ new Map();
			for (let [e, n] of ve.get(d)?.get(t.id) ?? []) {
				let r = n ? Object.fromEntries(Object.entries(n.bindings).flatMap(([e, t]) => h[t] ? [[e, h[t]]] : [])) : h;
				m.set(e, {
					entityId: n?.entityId ?? t.id,
					sourceVersionId: n?.sourceVersionId ?? u.id,
					ownerId: c.id,
					bindings: r
				});
			}
			if (o === c.id) {
				for (let e of l.overrideFields) m.set(e, null);
				c.kind === "scene" && m.set("chapterId", null);
			}
			if (m.size && a.set(o, m), o === c.id) {
				let e = { ...n.data };
				delete e.reuse;
				for (let t of l.overrideFields) Object.hasOwn(c.data, t) ? e[t] = structuredClone(c.data[t]) : delete e[t];
				c.kind === "scene" && (e.chapterId = c.data.chapterId ?? null), r.set(o, {
					...c,
					data: e
				});
			} else r.set(o, n);
		}
		r.size > 1e5 && C("再利用を解決した実行情報が100,000件を超えています。");
	}
	let c = /* @__PURE__ */ new Set();
	for (let t of [...r.values()].flatMap((e) => [e.id, ...Ce(e.data)]).concat(e.relations.map((e) => e.id), e.views.map((e) => e.id))) c.has(t) && C("再利用先どうしでレコード・段落等のIDが衝突しています。ID対応を確認し直してください。"), c.add(t);
	let l = {
		...e,
		entities: [...r.values()],
		worldReferences: [...s.values()]
	};
	return ge.set(l, i), ve.set(l, a), _e.set(l, e), l;
}
function je(e, t) {
	return Object.fromEntries([...ge.get(e) ?? []].map(([e, n]) => [e, {
		...t,
		graphId: t.graphId ? n.bindings[t.graphId] ?? t.graphId : void 0,
		chapterId: t.chapterId ? n.bindings[t.chapterId] ?? t.chapterId : void 0,
		sourceVersionId: n.sourceVersionId,
		anchorBindings: n.bindings
	}]));
}
function Me(e, t, n) {
	let r = ye(e, n);
	return !r || t.sourceVersionId !== r.sourceVersionId ? t : {
		...t,
		entityId: r.bindings[t.entityId] ?? t.entityId,
		...t.blockId ? { blockId: r.bindings[t.blockId] ?? t.blockId } : {},
		...t.lineId ? { lineId: r.bindings[t.lineId] ?? t.lineId } : {}
	};
}
function Ne(e, t, n) {
	if (!e.entities.some((e) => xe(e) && e.data.reuse?.bindings)) return [];
	try {
		return Ae(e, t), [];
	} catch (e) {
		return [{
			code: "REFERENCE_INVALID",
			path: `${n}.reuse`,
			message: e.message
		}];
	}
}
//#endregion
//#region src/domain/types.ts
var Pe = "1.0.0", Fe = /^(?:0|-[1-9][0-9]{0,37}|[1-9][0-9]{0,37})$/, Ie = 10n ** 38n - 1n, Le = {
	id: "proleptic-gregorian-second",
	name: "先発グレゴリオ暦",
	kind: "gregorian",
	originLabel: "0000-01-01 00:00:00",
	ticksPerDay: "86400"
};
function Re(e) {
	return typeof e == "string" && Fe.test(e);
}
function w(e) {
	if (!Re(e)) throw RangeError("tickは38桁以内の正規整数文字列で指定してください。");
	return BigInt(e);
}
function ze(e) {
	if (e < -Ie || e > Ie) throw RangeError("tickが38桁の範囲を超えています。");
	return e.toString();
}
function Be(e, t) {
	return ze(w(e) + w(t));
}
function T(e, t) {
	let n = w(e), r = w(t);
	return n < r ? -1 : +(n > r);
}
function Ve(e, t = "calendar") {
	let n = (e, n = t) => ({
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: n,
			message: e
		}]
	});
	if (!e || typeof e != "object" || Array.isArray(e)) return n("暦はオブジェクトです。");
	let r = e, i = r.kind === "repeating" ? [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay",
		"years"
	] : [
		"id",
		"name",
		"kind",
		"originLabel",
		"ticksPerDay"
	];
	if (Object.keys(r).some((e) => !i.includes(e))) return n("暦に未知の項目があります。");
	if (typeof r.id != "string" || !r.id || typeof r.name != "string" || !r.name || typeof r.originLabel != "string") return n("暦のID・名称・原点ラベルが必要です。");
	if (!Re(r.ticksPerDay) || w(r.ticksPerDay) <= 0n) return n("1日のtick数は正の整数です。", `${t}.ticksPerDay`);
	if (r.kind === "gregorian") return r.ticksPerDay === "86400" ? {
		ok: !0,
		value: e
	} : n("標準暦は1日86400tickです。", `${t}.ticksPerDay`);
	if (r.kind !== "repeating" || !Array.isArray(r.years) || r.years.length < 1 || r.years.length > 400) return n("繰返し暦は1〜400年の周期が必要です。");
	for (let e = 0; e < r.years.length; e++) {
		let i = r.years[e];
		if (!i || typeof i != "object" || Object.keys(i).some((e) => e !== "months") || !Array.isArray(i.months) || i.months.length < 1 || i.months.length > 24) return n("1年の月数は1〜24です。", `${t}.years[${e}]`);
		for (let r = 0; r < i.months.length; r++) {
			let a = i.months[r];
			if (!a || typeof a != "object" || Object.keys(a).some((e) => !["name", "days"].includes(e)) || typeof a.name != "string" || !a.name || !Number.isInteger(a.days) || a.days < 1 || a.days > 400) return n("月名と1〜400の日数が必要です。", `${t}.years[${e}].months[${r}]`);
		}
	}
	return {
		ok: !0,
		value: e
	};
}
function He(e, t) {
	try {
		return e.mode === "unknown" ? {
			status: "unknown",
			reason: e.reason || "日時が未定です。",
			path: t
		} : e.mode === "instant" ? (w(e.at), {
			status: "resolved",
			earliest: e.at,
			latest: e.at,
			endEarliest: e.at,
			endLatest: e.at,
			calendarId: e.calendarId,
			mode: e.mode
		}) : e.mode === "interval" ? T(e.start, e.end) >= 0 ? {
			status: "conflict",
			reason: "期間は開始より後に終了してください。",
			path: t
		} : {
			status: "resolved",
			earliest: e.start,
			latest: e.start,
			endEarliest: e.end,
			endLatest: e.end,
			calendarId: e.calendarId,
			mode: e.mode
		} : T(e.earliest, e.latest) > 0 ? {
			status: "conflict",
			reason: "概算範囲が逆転しています。",
			path: t
		} : {
			status: "resolved",
			earliest: e.earliest,
			latest: e.latest,
			endEarliest: e.earliest,
			endLatest: e.latest,
			calendarId: e.calendarId,
			mode: e.mode
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: t
		};
	}
}
function Ue(e, t, n, r) {
	try {
		if (T(e.minOffset, e.maxOffset) > 0) return {
			status: "conflict",
			reason: "相対日時の範囲が逆転しています。",
			path: n()
		};
		if (t.status !== "resolved") return r ? {
			...t,
			path: [...n(), ...t.path].slice(0, 64)
		} : t;
		let i = Be(e.anchorPoint === "start" ? t.earliest : t.endEarliest, e.minOffset), a = Be(e.anchorPoint === "start" ? t.latest : t.endLatest, e.maxOffset);
		return {
			status: "resolved",
			earliest: i,
			latest: a,
			endEarliest: i,
			endLatest: a,
			calendarId: t.calendarId,
			mode: "relative"
		};
	} catch (e) {
		return {
			status: "conflict",
			reason: e instanceof Error ? e.message : "日時を解決できません。",
			path: n()
		};
	}
}
function We(e, t, n = []) {
	return Ue(e, t, () => n, !0);
}
function Ge(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) !n.deletedAt && !t.has(n.id) && t.set(n.id, n);
	return t;
}
function Ke(e, t = [], n = []) {
	if (e.mode !== "relative") return He(e, n);
	let r = Ge(t), i = [...n], a = new Set(n), o = [], s = e;
	for (; s.mode === "relative";) {
		if (a.has(s.anchorEventId)) return {
			status: "conflict",
			reason: "相対日時の参照が循環しています。",
			path: [...i, s.anchorEventId]
		};
		try {
			if (T(s.minOffset, s.maxOffset) > 0) return {
				status: "conflict",
				reason: "相対日時の範囲が逆転しています。",
				path: [...i]
			};
		} catch (e) {
			return {
				status: "conflict",
				reason: e instanceof Error ? e.message : "日時を解決できません。",
				path: [...i]
			};
		}
		let e = r.get(s.anchorEventId);
		if (!e) return {
			status: "unknown",
			reason: "基準となる出来事がありません。",
			path: [...i, s.anchorEventId]
		};
		o.push({
			time: s,
			pathLength: i.length
		}), a.add(e.id), i.push(e.id), s = e.data.time;
	}
	let c = He(s, i);
	for (let e = o.length - 1; e >= 0 && c.status === "resolved"; e--) {
		let t = o[e];
		c = Ue(t.time, c, () => i.slice(0, t.pathLength), !1);
	}
	return c;
}
function qe(e) {
	let t = Ge(e), n = /* @__PURE__ */ new Map();
	for (let e of t.values()) {
		if (n.has(e.id)) continue;
		let r = [], i = /* @__PURE__ */ new Map(), a = e.id;
		for (; !n.has(a);) {
			let e = t.get(a);
			if (!e) {
				n.set(a, {
					status: "unknown",
					reason: "基準となる出来事がありません。",
					path: [a]
				});
				break;
			}
			let o = i.get(a);
			if (o !== void 0) {
				let e = r.slice(o);
				for (let t = 0; t < e.length; t++) n.set(e[t], {
					status: "conflict",
					reason: "相対日時の参照が循環しています。",
					path: Array.from({ length: Math.min(e.length + 1, 64) }, (n, r) => e[(t + r) % e.length])
				});
				break;
			}
			if (e.data.time.mode !== "relative") {
				n.set(a, He(e.data.time, [a]));
				break;
			}
			let s = e.data.time;
			if (!i.has(s.anchorEventId) && s.anchorEventId !== a) try {
				if (T(s.minOffset, s.maxOffset) > 0) {
					n.set(a, {
						status: "conflict",
						reason: "相対日時の範囲が逆転しています。",
						path: [a]
					});
					break;
				}
			} catch (e) {
				n.set(a, {
					status: "conflict",
					reason: e instanceof Error ? e.message : "日時を解決できません。",
					path: [a]
				});
				break;
			}
			i.set(a, r.length), r.push(a), a = s.anchorEventId;
		}
		for (let e = r.length - 1; e >= 0; e--) {
			let i = r[e], a = t.get(i);
			!n.has(i) && a.data.time.mode === "relative" && n.set(i, We(a.data.time, n.get(a.data.time.anchorEventId), [i]));
		}
	}
	return n;
}
function Je(e) {
	let t = [], n = Ge(e), r = qe(e);
	for (let e of n.values()) {
		let i = r.get(e.id);
		i.status === "conflict" && t.push({
			code: "TIME_CONSTRAINT_CONFLICT",
			path: `entities.${e.id}.data.time`,
			message: i.reason
		});
		for (let a of e.data.constraints ?? []) {
			let o = n.get(a.targetEventId);
			if (!o || i.status !== "resolved") continue;
			let s = r.get(o.id);
			if (s.status !== "resolved") continue;
			let c = i.calendarId !== s.calendarId;
			if (a.type === "before") c ||= i.mode === "interval" ? T(i.endEarliest, s.latest) > 0 : T(i.endEarliest, s.latest) >= 0;
			else if (a.type === "same_start") c ||= T(i.earliest, s.latest) > 0 || T(s.earliest, i.latest) > 0;
			else {
				let e = w(s.earliest) - w(i.endLatest), t = w(s.latest) - w(i.endEarliest);
				c ||= t < w(a.minimumTicks) || e > w(a.maximumTicks);
			}
			c && t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "指定した出来事の日時制約と矛盾しています。"
			});
		}
	}
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
	for (let e of n.values()) a.set(e.id, (e.data.constraints ?? []).map((e) => e.targetEventId));
	for (let e of n.values()) e.data.time.mode === "relative" && n.has(e.data.time.anchorEventId) && a.get(e.data.time.anchorEventId).push(e.id);
	for (let e of n.values()) {
		if (i.get(e.id)) continue;
		let r = [{
			id: e.id,
			targets: a.get(e.id),
			cursor: 0
		}];
		for (i.set(e.id, 1); r.length;) {
			let e = r[r.length - 1];
			if (e.cursor === e.targets.length) {
				i.set(e.id, 2), r.pop();
				continue;
			}
			let o = e.targets[e.cursor++], s = n.get(o);
			s && (i.get(o) === 1 ? t.push({
				code: "TIME_CONSTRAINT_CONFLICT",
				path: `entities.${e.id}.data.constraints`,
				message: "日時制約の依存が循環しています。"
			}) : i.has(o) || (i.set(o, 1), r.push({
				id: o,
				targets: a.get(s.id),
				cursor: 0
			})));
		}
	}
	return t;
}
function Ye(e, t) {
	return e.id !== t.id || e.kind !== t.kind || e.name !== t.name || e.originLabel !== t.originLabel || e.ticksPerDay !== t.ticksPerDay ? !1 : e.kind === "gregorian" || t.kind === "gregorian" ? e.kind === t.kind : e.years.length === t.years.length && e.years.every((e, n) => e.months.length === t.years[n].months.length && e.months.every((e, r) => e.name === t.years[n].months[r].name && e.days === t.years[n].months[r].days));
}
//#endregion
//#region src/domain/templates.ts
var E = (e, t, n = "VALIDATION_FAILED") => ({
	path: e,
	message: t,
	code: n
}), Xe = [
	"id",
	"projectId",
	"kind",
	"revision",
	"name",
	"status",
	"visibility",
	"retainIfUnreferenced",
	"projectionProfileId",
	"templateId",
	"createdAt",
	"updatedAt",
	"deletedAt",
	"deletionOperationId",
	"customValues",
	"data"
], Ze = [
	"__proto__",
	"prototype",
	"constructor"
], Qe = [
	"text",
	"number",
	"boolean",
	"enum",
	"date",
	"ref"
];
function $e(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = e;
	return typeof t.key == "string" && typeof t.label == "string" && Qe.includes(t.type) && typeof t.required == "boolean" && typeof t.nullable == "boolean" && (t.help == null || typeof t.help == "string") && (t.allowedValues == null || Array.isArray(t.allowedValues) && t.allowedValues.every((e) => typeof e == "string")) && (t.targetKinds == null || Array.isArray(t.targetKinds) && t.targetKinds.every((e) => Object.hasOwn(dn, e)));
}
function et(e) {
	let t = dn[e];
	return [...Xe, ...t?.type === "object" ? Object.keys(t.fields) : []];
}
function tt(e, t, n, r) {
	if (t === void 0) return e.required ? [E(n, `「${e.label}」は必須項目です。`)] : [];
	if (t === null) return e.nullable ? [] : [E(n, `「${e.label}」は空欄を許可していません。`)];
	let i = !1;
	if (e.type === "text" && (i = typeof t == "string" && (!e.required || t.trim().length > 0)), e.type === "number" && (i = typeof t == "number" && Number.isFinite(t)), e.type === "boolean" && (i = typeof t == "boolean"), e.type === "enum" && (i = typeof t == "string" && !!e.allowedValues?.includes(t)), e.type === "date" || e.type === "ref") {
		let a = t && typeof t == "object" && !Array.isArray(t) ? t : void 0;
		if (i = a?.type === e.type && typeof a.value == "string", i && e.type === "date") {
			let e = a.value, t = /^\d{4}-\d{2}-\d{2}$/.test(e) ? /* @__PURE__ */ new Date(`${e}T00:00:00.000Z`) : /* @__PURE__ */ new Date(NaN);
			i = Number.isFinite(t.getTime()) && t.toISOString().slice(0, 10) === e;
		}
		if (i && e.type === "ref") {
			let t = a.value;
			if (!St.test(t)) i = !1;
			else if (r) {
				let i = "get" in r ? r.get(t) : r.find((e) => e.id === t);
				if (!i || i.deletedAt || e.targetKinds?.length && !e.targetKinds.includes(i.kind)) return [E(n, `「${e.label}」の参照先が存在しないか、許可された種類ではありません。`, "REFERENCE_INVALID")];
			}
		}
	}
	return i ? [] : [E(n, `「${e.label}」の値が宣言した${e.type}型または選択候補と一致しません。`)];
}
function nt(e, t = "data", n) {
	let r = [];
	if (!e || !Array.isArray(e.fields)) return [E(`${t}.fields`, "項目定義は配列で入力してください。")];
	Object.hasOwn(dn, e.targetKind) || r.push(E(`${t}.targetKind`, "対象の情報の種類を選んでください。")), e.defaults != null && (typeof e.defaults != "object" || Array.isArray(e.defaults)) && r.push(E(`${t}.defaults`, "初期値は項目キーごとの辞書で指定してください。"));
	let i = /* @__PURE__ */ new Set(), a = new Set(et(e.targetKind));
	for (let [o, s] of e.fields.entries()) {
		let e = `${t}.fields[${o}]`;
		if (!$e(s)) {
			r.push(E(e, "項目定義のキー・表示名・型・必須・空欄・説明・候補・参照先の形式を確認してください。"));
			continue;
		}
		(!s.key.trim() || i.has(s.key) || a.has(s.key) || Ze.includes(s.key)) && r.push(E(`${e}.key`, "キーが空欄・重複・予約済み、または標準項目と衝突しています。")), i.add(s.key), s.type === "enum" && (!Array.isArray(s.allowedValues) || !s.allowedValues.length || s.allowedValues.some((e) => typeof e != "string" || !e.trim()) || new Set(s.allowedValues).size !== s.allowedValues.length) && r.push(E(`${e}.allowedValues`, "選択型には空欄と重複のない候補を指定してください。")), s.type !== "enum" && s.allowedValues?.length && r.push(E(`${e}.allowedValues`, "選択候補はenum型だけに設定できます。")), s.type !== "ref" && s.targetKinds?.length && r.push(E(`${e}.targetKinds`, "参照先の種類はref型だけに設定できます。")), Object.hasOwn(s, "default") ? r.push(...tt(s, s.default, `${e}.default`, n)) : r.push(E(`${e}.default`, "項目の初期値を指定してください。"));
	}
	let o = e.fields.filter($e), s = e.defaults && typeof e.defaults == "object" && !Array.isArray(e.defaults) ? e.defaults : {};
	for (let [e, i] of Object.entries(s)) {
		let a = o.find((t) => t.key === e);
		a ? r.push(...tt(a, i, `${t}.defaults.${e}`, n)) : r.push(E(`${t}.defaults.${e}`, "初期値のキーを項目定義へ追加してください。"));
	}
	return r;
}
function rt(e, t = "project", n = e.entities) {
	let r = new Map(n.filter((e) => e.kind === "template").map((e) => [e.id, e])), i = [], a = new Map(n.map((e) => [e.id, e]));
	return e.entities.forEach((e, n) => {
		let o = e;
		if (e.deletedAt || !o.templateId) return;
		let s = `${t}.entities[${n}]`, c = r.get(o.templateId);
		if (!c || c.deletedAt || c.status === "rejected" || c.data.targetKind !== e.kind) {
			i.push(E(`${s}.templateId`, "適用した雛形が存在しない・不採用・削除済み、または対象の種類が異なります。", "REFERENCE_INVALID"));
			return;
		}
		for (let t of c.data.fields) i.push(...tt(t, e.customValues[t.key], `${s}.customValues.${t.key}`, a));
	}), i;
}
//#endregion
//#region src/domain/textMetrics.ts
var it = 512, at = 4096, ot = 1048576, st = /* @__PURE__ */ new Map(), ct = 0;
function lt(e) {
	let t = st.get(e);
	if (t) return t;
	let n = 0, r = 0, i = !0;
	for (let t = 0; t < e.length; t++, n++) {
		let n = e.charCodeAt(t);
		if (n < 128) r++;
		else if (n < 2048) r += 2;
		else if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			n >= 56320 && n <= 57343 ? (r += 4, t++) : (r += 3, i = !1);
		} else r += 3, n >= 56320 && n <= 57343 && (i = !1);
	}
	let a = Object.freeze({
		codePoints: n,
		utf8Bytes: r,
		validUnicode: i
	});
	if (e.length <= at) {
		let t = e.length * 2;
		for (; st.size >= it || ct + t > ot;) {
			let e = st.keys().next().value;
			ct -= e.length * 2, st.delete(e);
		}
		st.set(e, a), ct += t;
	}
	return a;
}
//#endregion
//#region src/domain/immutablePlainData.ts
var ut = /* @__PURE__ */ new WeakSet();
function dt(e, t, n = /* @__PURE__ */ new WeakSet(), r = /* @__PURE__ */ new WeakSet(), i = 0) {
	if (i > 128) return !1;
	if (typeof e != "object" || !e) return ![
		"function",
		"symbol",
		"bigint"
	].includes(typeof e);
	if (ut.has(e)) return !0;
	if (n.has(e)) return !1;
	if (r.has(e)) return !0;
	let a = Array.isArray(e), o = Object.getPrototypeOf(e);
	if ((a ? o !== Array.prototype : o !== Object.prototype && o !== null) || t && !Object.isFrozen(e)) return !1;
	let s = Object.getOwnPropertyDescriptors(e), c = Reflect.ownKeys(e);
	if (c.some((e) => typeof e != "string" || [
		"__proto__",
		"constructor",
		"prototype"
	].includes(e)) || a && (c.length !== e.length + 1 || c.some((t) => t !== "length" && (!/^(0|[1-9]\d*)$/.test(String(t)) || Number(t) >= e.length)))) return !1;
	n.add(e);
	for (let o of c) {
		if (a && o === "length") continue;
		let c = s[o];
		if (!c.enumerable || !Object.hasOwn(c, "value") || !dt(c.value, t, n, r, i + 1)) return n.delete(e), !1;
	}
	return n.delete(e), r.add(e), t && ut.add(e), !0;
}
function ft(e) {
	return dt(e, !0);
}
function pt(e) {
	let t = /* @__PURE__ */ new WeakSet(), n = /* @__PURE__ */ new WeakSet(), r = [], i = [], a = (e, i) => {
		if (i > 128) return !1;
		if (typeof e != "object" || !e) return ![
			"function",
			"symbol",
			"bigint"
		].includes(typeof e);
		if (ut.has(e)) return !0;
		if (t.has(e)) return !1;
		if (n.has(e)) return !0;
		let a = Array.isArray(e), o = Object.getPrototypeOf(e);
		if (a ? o !== Array.prototype : o !== Object.prototype && o !== null) return !1;
		let s = Reflect.ownKeys(e);
		return a && s.length !== e.length + 1 ? !1 : (t.add(e), r.push({
			value: e,
			keys: s,
			index: 0,
			depth: i,
			array: a
		}), !0);
	};
	if (!a(e, 0)) return !1;
	for (; r.length;) {
		let e = r.at(-1);
		if (e.index === e.keys.length) r.pop(), t.delete(e.value), n.add(e.value), i.push(e.value);
		else {
			let t = e.keys[e.index++];
			if (typeof t != "string" || [
				"__proto__",
				"constructor",
				"prototype"
			].includes(t)) return !1;
			if (e.array && t === "length") continue;
			if (e.array && (!/^(0|[1-9]\d*)$/.test(t) || Number(t) >= e.value.length)) return !1;
			let n = Object.getOwnPropertyDescriptor(e.value, t);
			if (!n?.enumerable || !Object.hasOwn(n, "value") || !a(n.value, e.depth + 1)) return !1;
		}
	}
	for (let e of i) Object.freeze(e), ut.add(e);
	return !0;
}
async function mt(e, t) {
	let n = /* @__PURE__ */ new WeakSet(), r = /* @__PURE__ */ new WeakSet(), i = [], a = [], o = performance.now() + 16, s = 0, c = () => ++s % 128 == 0 && performance.now() >= o, l = async () => {
		y(t), await new Promise((e) => setTimeout(e, 0)), y(t), o = performance.now() + 16;
	}, u = (e, t) => {
		if (t > 128) return !1;
		if (typeof e != "object" || !e) return ![
			"function",
			"symbol",
			"bigint"
		].includes(typeof e);
		if (ut.has(e)) return !0;
		if (n.has(e)) return !1;
		if (r.has(e)) return !0;
		let a = Array.isArray(e), o = Object.getPrototypeOf(e);
		if (a ? o !== Array.prototype : o !== Object.prototype && o !== null) return !1;
		let s = Reflect.ownKeys(e);
		return a && s.length !== e.length + 1 ? !1 : (n.add(e), i.push({
			value: e,
			keys: s,
			index: 0,
			depth: t,
			array: a
		}), !0);
	};
	if (y(t), !u(e, 0)) return !1;
	for (; i.length;) {
		let e = i.at(-1);
		if (e.index === e.keys.length) i.pop(), n.delete(e.value), r.add(e.value), a.push(e.value);
		else {
			let t = e.keys[e.index++];
			if (typeof t != "string" || [
				"__proto__",
				"constructor",
				"prototype"
			].includes(t)) return !1;
			if (e.array && t === "length") continue;
			if (e.array && (!/^(0|[1-9]\d*)$/.test(t) || Number(t) >= e.value.length)) return !1;
			let n = Object.getOwnPropertyDescriptor(e.value, t);
			if (!n?.enumerable || !Object.hasOwn(n, "value") || !u(n.value, e.depth + 1)) return !1;
		}
		c() && await l();
	}
	y(t);
	for (let e of a) Object.freeze(e), ut.add(e), c() && await l();
	return y(t), !0;
}
function ht(e) {
	if (ft(e)) return {
		value: e,
		captured: !0
	};
	if (!dt(e, !1)) return {
		value: e,
		captured: !1
	};
	let t = /* @__PURE__ */ new WeakMap(), n = (e) => {
		if (!e || typeof e != "object" || ut.has(e)) return e;
		let r = t.get(e);
		if (r) return r;
		let i = Array.isArray(e) ? Array(e.length) : Object.create(Object.getPrototypeOf(e));
		t.set(e, i);
		for (let [t, r] of Object.entries(Object.getOwnPropertyDescriptors(e))) Array.isArray(e) && t === "length" || Object.defineProperty(i, t, {
			value: n(r.value),
			enumerable: !0
		});
		return Object.freeze(i), ut.add(i), i;
	};
	return {
		value: n(e),
		captured: !0
	};
}
//#endregion
//#region src/domain/contentValidationMemo.ts
function gt(e, t, n) {
	if (!ft(e)) return;
	let r = ht(t);
	if (!r.captured) return;
	let i = ht({
		...r.value,
		relationTypes: r.value.relationTypes ?? n
	});
	if (!i.captured) return;
	let a = [], o = /* @__PURE__ */ new WeakMap(), s = 0, c = /* @__PURE__ */ new WeakMap(), u = /* @__PURE__ */ new WeakMap(), d = 0, f = (e, t, n) => {
		if (!ft(e)) return;
		let r = ht(t);
		r.captured && (d >= 1e5 && (c = /* @__PURE__ */ new WeakMap(), u = /* @__PURE__ */ new WeakMap(), d = 0), n ? c.set(e, r.value) : u.set(e, r.value), d++);
	}, p = (e, t) => e.length === t.length && e.every((e, n) => e === t[n]), m = (e, t, n, r) => {
		let i = e.content;
		return i.projectId === t.projectId && i.formatVersion === t.formatVersion && i.calendarId === t.calendarId && i.mainStart === t.mainStart && i.entities === t.entities && i.relations === t.relations && i.calendars === t.calendars && p(i.views, t.views) && p(i.worldReferences, t.worldReferences) && e.ids.size === n.size && [...n].every((t) => e.ids.has(t)) && e.versions.size === r.size && [...r].every(([t, n]) => e.versions.get(t) === n);
	}, h = (e, t, n, r) => {
		let i = e.content;
		return i.projectId === t.projectId && i.formatVersion === t.formatVersion && i.calendarId === t.calendarId && i.mainStart === t.mainStart && p(i.calendars, t.calendars) && p(i.worldReferences, t.worldReferences) && p(i.views, t.views) && e.ids.size === n.size && [...n].every((t) => e.ids.has(t)) && e.versions.size === r.size && [...r].every(([t, n]) => e.versions.get(t) === n);
	};
	return {
		options: i.value,
		memo: {
			contentIds: (e) => o.get(e),
			rememberContentIds(e, t) {
				ft(e) && (s >= 1e5 && (o = /* @__PURE__ */ new WeakMap(), s = 0), o.set(e, t), s++);
			},
			entityReferences: (e) => c.get(e),
			relationReferences: (e) => u.get(e),
			rememberEntity: (e, t) => f(e, t, !0),
			rememberRelation: (e, t) => f(e, t, !1),
			has: (e, t, n) => {
				let r = a.some((r) => m(r, e, t, n));
				return l(r ? "memo.hit" : "memo.miss"), r;
			},
			previousContent(e, t, n) {
				for (let r = a.length - 1; r >= 0; r--) {
					let i = a[r];
					if (h(i, e, t, n)) return i.content;
				}
			},
			remember(e, t, n) {
				let r = ht(e);
				r.captured && (a.length >= 256 && (a = []), a.push({
					content: r.value,
					ids: new Set(t),
					versions: new Map(n)
				}));
			}
		}
	};
}
//#endregion
//#region src/domain/model.ts
var _t = {
	character: "人物",
	group: "グループ",
	event: "出来事",
	place: "場所",
	item: "物品",
	note: "メモ",
	chapter: "章",
	scene: "場面",
	goal: "目標",
	flow_node: "進行ノード",
	flow_edge: "進行線",
	flow_graph: "分岐図",
	dialogue_line: "台詞",
	quest: "クエスト",
	lore: "設定",
	variable: "状態変数",
	effect: "効果",
	assertion: "事実・認識",
	foreshadow: "伏線",
	disclosure: "手掛かり・回収",
	checkpoint: "途中開始点",
	trace: "試読記録",
	attachment: "添付素材",
	source: "資料・出所",
	cue: "演出",
	storyboard_frame: "絵コンテ",
	localization: "翻訳",
	recording: "収録",
	terminology: "用語",
	map: "地図",
	travel_route: "移動経路",
	template: "雛形",
	collection: "一覧",
	review: "レビュー",
	creative_brief: "企画",
	decision: "制作判断",
	gameplay_spec: "ゲーム仕様",
	production_task: "制作タスク",
	media_variant: "媒体版",
	voice_rule: "口調",
	external_contract: "外部契約",
	snapshot: "公開版",
	projection_profile: "公開投影"
}, D = Object.keys(_t), vt = [
	"confirmed",
	"provisional",
	"needs_review",
	"rejected",
	"alternate"
], yt = [
	"scene",
	"chapter",
	"character",
	"run",
	"across_runs"
], bt = [
	{
		key: "trust",
		label: "信頼",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "causes",
		label: "因果",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "requires",
		label: "前提",
		fromKinds: D,
		toKinds: D,
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "foreshadow_payoff",
		label: "手掛かり→回収",
		fromKinds: ["disclosure"],
		toKinds: ["disclosure"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "parent_of",
		label: "親子",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_foreshadow",
		label: "出来事の予告",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "event_payoff",
		label: "出来事の回収",
		fromKinds: ["event"],
		toKinds: ["event"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "mentor_of",
		label: "師弟",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "bloodline",
		label: "血統",
		fromKinds: ["character"],
		toKinds: ["character"],
		allowSelf: !1,
		allowSymmetric: !1
	},
	{
		key: "related",
		label: "関連",
		fromKinds: D,
		toKinds: D,
		allowSelf: !1,
		allowSymmetric: !0
	},
	{
		key: "reference",
		label: "参照",
		fromKinds: D,
		toKinds: D,
		allowSelf: !0,
		allowSymmetric: !1
	}
], xt = Object.fromEntries(bt.map((e) => [e.key, e.label])), St = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, Ct = /^(?:0|[1-9][0-9]*)$/, wt = () => ({
	worldRange: null,
	routeCondition: null,
	presentationAnchor: null
}), Tt = () => crypto.randomUUID();
function Et(e) {
	return e === "" ? [] : e.split("\n").map((e) => ({
		id: Tt(),
		kind: "paragraph",
		text: e
	}));
}
function Dt(e) {
	return (e ?? []).map((e) => e.text).join("\n");
}
function Ot(e, t) {
	return e.entities.find((e) => e.id === t && !e.deletedAt);
}
function kt(e, t) {
	return e.entities.filter((e) => e.kind === t && !e.deletedAt);
}
function At(e) {
	let t = {
		type: "unknown",
		value: null,
		reason: "未入力"
	}, n = {
		character: {
			reading: "",
			aliases: [],
			summary: [],
			body: [],
			authorNotes: [],
			goals: [],
			voiceRules: []
		},
		group: {
			groupType: "display",
			members: [],
			parentId: null,
			summary: []
		},
		event: {
			summary: [],
			time: {
				mode: "unknown",
				reason: ""
			},
			laneRole: "common",
			participants: [],
			locationId: null,
			itemIds: [],
			authorNotes: [],
			constraints: []
		},
		place: {
			parentId: null,
			reading: "",
			aliases: [],
			body: [],
			mapIds: [],
			changes: []
		},
		item: {
			itemMode: "type",
			typeId: null,
			body: [],
			properties: null,
			changes: []
		},
		note: {
			body: [],
			attachmentIds: [],
			convertedToIds: [],
			originNoteId: null
		},
		chapter: {
			sceneIds: [],
			summary: [],
			authorNotes: [],
			structureRole: ""
		},
		scene: {
			summary: [],
			body: [],
			authorNotes: [],
			eventIds: [],
			chapterId: null,
			threadIds: [],
			povId: null,
			goals: [],
			conflicts: [],
			results: [],
			newInformation: [],
			tension: null,
			importance: null,
			blockIds: []
		},
		goal: {
			ownerId: null,
			description: [],
			changes: [],
			evidenceSceneIds: [],
			validity: wt()
		},
		flow_node: {
			nodeType: "choice",
			sceneId: null,
			childGraphId: null,
			terminalReason: "",
			gate: {
				op: "constant",
				value: !0
			},
			executionPolicy: "manual_choice",
			fallbackId: null
		},
		flow_edge: {
			fromId: null,
			toId: { unresolved: {
				label: "",
				reason: "未完成"
			} },
			edgeType: "choice",
			label: "",
			condition: {
				op: "constant",
				value: !0
			},
			effectIds: [],
			priority: 0,
			choiceLineId: null
		},
		flow_graph: {
			nodeIds: [],
			edgeIds: [],
			entryIds: [],
			exitIds: [],
			parentGraphId: null,
			parameters: []
		},
		dialogue_line: {
			text: [],
			speakerId: null,
			choiceEdgeId: null,
			cueIds: [],
			originLineIds: []
		},
		quest: {
			key: "",
			stateVariableId: null,
			description: [],
			flowIds: [],
			transitionRules: [],
			gameplaySpecIds: []
		},
		lore: {
			body: [],
			assertionIds: [],
			sourceIds: [],
			reading: "",
			aliases: []
		},
		variable: {
			key: "",
			valueType: "boolean",
			scope: "run",
			initial: t,
			allowed: { values: [!1, !0] },
			description: [],
			ownerId: null,
			externalContractId: null,
			resetRules: [],
			transitionRules: [],
			externalUseDeclared: !1
		},
		effect: {
			operation: "set",
			targetId: null,
			value: t,
			condition: {
				op: "constant",
				value: !0
			},
			instanceId: null,
			reason: ""
		},
		assertion: {
			subjectId: null,
			predicate: "",
			value: t,
			truthKind: "author_truth",
			holderId: null,
			sourceIds: [],
			evidenceLocation: null,
			validity: wt(),
			reason: ""
		},
		foreshadow: {
			question: [],
			intent: [],
			resolutionPolicy: "undecided",
			truthAssertionIds: [],
			clueIds: [],
			payoffIds: [],
			requiredInfo: [],
			deadline: null,
			exceptions: []
		},
		disclosure: {
			foreshadowId: null,
			anchor: { entityId: null },
			stage: "hint",
			role: "clue",
			condition: {
				op: "constant",
				value: !0
			},
			knowledgeEffects: [],
			targetScope: null
		},
		checkpoint: {
			contentVersionId: null,
			runtimeState: Nt(""),
			origin: "partial",
			traceId: null
		},
		trace: {
			contentVersionId: null,
			startCheckpointId: null,
			steps: [],
			seed: "",
			engineVersion: "1.0.0",
			externalMode: "stub"
		},
		attachment: {
			mediaType: "",
			contentHash: "",
			byteSize: 0,
			assetPath: "",
			displayName: "",
			stage: "reference",
			revisionHistory: []
		},
		source: {
			sourceType: "web",
			locator: "",
			accessedAt: null,
			excerptLocation: "",
			interpretation: [],
			attachmentId: null,
			redistributionAllowed: !1
		},
		cue: {
			anchor: { entityId: null },
			cueType: "",
			attachmentId: null,
			speakerId: null,
			expression: "",
			waitMs: null,
			camera: null,
			mediaTime: null,
			stage: ""
		},
		storyboard_frame: {
			anchor: { entityId: null },
			mediaStartMs: 0,
			mediaEndMs: null,
			referenceAssetId: null,
			finalAssetId: null,
			cueIds: [],
			caption: []
		},
		localization: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			text: [],
			stage: "draft",
			reviewedBy: null,
			recordingIds: []
		},
		recording: {
			sourceLineId: null,
			language: "",
			sourceHash: "",
			translationId: null,
			attachmentId: null,
			notes: [],
			stage: "planned",
			reviewedBy: null
		},
		terminology: {
			canonical: "",
			reading: "",
			variants: [],
			language: null,
			usageNotes: [],
			validity: wt(),
			exceptions: [],
			voiceOwnerId: null
		},
		map: {
			placeId: null,
			coordinateSystem: "normalized",
			attachmentId: null,
			parentMapId: null,
			pins: []
		},
		travel_route: {
			fromPlaceId: null,
			toPlaceId: null,
			direction: "one_way",
			method: "",
			minimumTicks: null,
			maximumTicks: null,
			evidence: [],
			validity: wt()
		},
		template: {
			targetKind: "character",
			fields: [],
			description: "",
			version: "0",
			defaults: {}
		},
		collection: {
			mode: "fixed",
			memberIds: [],
			query: null,
			sort: {
				field: "name",
				direction: "asc"
			}
		},
		review: {
			target: null,
			targetVersionId: null,
			body: [],
			stage: "open",
			assigneeId: null,
			quotedText: "",
			resolution: []
		},
		creative_brief: {
			targetAudience: [],
			experience: [],
			theme: [],
			tone: [],
			scope: [],
			deliverableIds: [],
			decisionIds: []
		},
		decision: {
			subject: "",
			reason: [],
			targetVersionId: null,
			outcome: "deferred",
			priority: "",
			requirementIds: [],
			reviewIds: []
		},
		gameplay_spec: {
			sceneId: null,
			action: [],
			mechanic: "",
			tutorial: [],
			reward: null,
			questId: null,
			taskIds: [],
			intentionalDifference: ""
		},
		production_task: {
			targetIds: [],
			stage: "writing",
			progress: "todo",
			assigneeId: null,
			deadline: null,
			dependsOn: [],
			estimate: null,
			blockingReason: ""
		},
		media_variant: {
			medium: "novel",
			baseSnapshotId: null,
			body: [],
			releaseAt: null,
			projectionProfileId: null,
			sourceIds: [],
			needsReview: !1
		},
		voice_rule: {
			characterId: null,
			validity: wt(),
			firstPerson: "",
			addressing: "",
			phrasing: "",
			examples: [],
			exceptions: []
		},
		external_contract: {
			key: "",
			owner: "tool",
			inputType: "boolean",
			outputType: "boolean",
			missingPolicy: "unknown",
			description: [],
			stubValues: [],
			adapterProfileIds: [],
			version: "1.0.0"
		},
		snapshot: {
			versionLabel: "",
			contentHash: "",
			immutable: !0,
			parentVersionIds: [],
			releasedAt: null,
			referencedWorldVersionIds: []
		},
		projection_profile: {
			audience: "",
			includedIds: [],
			namePolicy: { mode: "exclude" },
			allowedKinds: [],
			excludedFields: ["authorNotes"],
			routeScope: null,
			includeAuthorNotes: !1,
			publicTitle: "",
			publicTexts: {},
			allowedRelationIds: [],
			idPolicy: "remap"
		}
	};
	if (!(e in n)) throw RangeError("未対応の情報種別です。");
	return n[e];
}
function jt(e, t, n = "", r) {
	let i = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: Tt(),
		projectId: e,
		kind: t,
		revision: "0",
		name: n,
		status: "provisional",
		visibility: "private",
		createdAt: i,
		updatedAt: i,
		customValues: {},
		data: {
			...At(t),
			...r
		}
	};
}
function Mt(e = "新しい作品") {
	return {
		projectId: Tt(),
		name: e,
		formatVersion: Pe,
		revision: "0",
		calendarId: Le.id,
		mainStart: "0",
		calendars: [structuredClone(Le)],
		worldReferences: [],
		entities: [],
		relations: [],
		snapshots: [],
		history: [],
		views: []
	};
}
function Nt(e) {
	return {
		contentVersionId: e,
		variableValues: {},
		itemInstances: [],
		assertions: [],
		seenIds: [],
		visitCounts: {},
		onceTriggers: [],
		rngSeed: "scenario-1",
		rngPosition: 0,
		callStack: [],
		presentationPosition: null,
		loopNumber: 0,
		provenance: "full_play"
	};
}
var O = (e = 0, t) => ({
	type: "text",
	min: e,
	max: t,
	maxBytes: 1048576
}), k = O(0, 128), Pt = O(1, 128), A = (e, t, n = !1) => ({
	type: "number",
	min: e,
	max: t,
	integer: n
}), j = { type: "boolean" }, M = { type: "id" }, N = { type: "tick" }, P = { type: "typed" }, F = (...e) => ({
	type: "enum",
	values: e
}), I = (...e) => ({
	type: "ref",
	kinds: e.length ? e : void 0,
	scope: "entity"
}), L = (e) => ({
	type: "ref",
	scope: e
}), R = (e, t = !1, n, r) => ({
	type: "array",
	item: e,
	unique: t,
	min: n,
	max: r
}), z = (...e) => R(I(...e), !0), B = (e) => ({
	type: "object",
	fields: e
}), V = (e) => ({
	schema: e,
	required: !0
}), H = (e) => ({
	schema: e,
	nullable: !0
}), Ft = (e) => ({
	schema: e,
	nullable: !1
}), U = { type: "richtext" }, It = {
	type: "richtext",
	max: 2048
}, Lt = { type: "condition" }, Rt = { type: "time" }, W = (e, t) => ({
	type: "record",
	value: e,
	key: t
}), zt = (...e) => ({
	type: "union",
	choices: e
}), G = B({
	entityId: V(I()),
	blockId: H(L("block")),
	lineId: H(I("dialogue_line")),
	start: H(A(0, void 0, !0)),
	end: H(A(0, void 0, !0)),
	sourceVersionId: H(L("snapshot")),
	positionStatus: H(F("unresolved")),
	positionReason: H(O(1)),
	quotedText: H(O())
}), Bt = zt(B({
	kind: V(F("ruby")),
	originalText: V(O()),
	reason: V(O(1)),
	reading: V(O())
}), B({
	kind: V(F("link")),
	originalText: V(O()),
	reason: V(O(1)),
	target: V(G)
})), Vt = B({
	worldRange: {
		schema: B({
			start: {
				schema: N,
				required: !0,
				nullable: !0
			},
			end: {
				schema: N,
				required: !0,
				nullable: !0
			}
		}),
		required: !0,
		nullable: !0
	},
	routeCondition: {
		schema: Lt,
		required: !0,
		nullable: !0
	},
	presentationAnchor: {
		schema: G,
		required: !0,
		nullable: !0
	}
}), Ht = B({
	projectId: V(L("project")),
	graphId: H(I("flow_graph")),
	chapterId: H(I("chapter")),
	routeCondition: H(Lt),
	targetSnapshotId: H(L("snapshot"))
}), Ut = B({
	id: V(M),
	text: V(O(1, 128)),
	reading: V(k),
	validity: V(Vt),
	audienceHolderIds: V(z("character")),
	isPublicDefault: V(j)
}), Wt = B({
	reason: V(O(1)),
	targetScope: V(Ht),
	validity: V(Vt),
	evidenceIds: V(z())
}), Gt = B({
	from: V(P),
	to: V(P),
	reason: H(O()),
	exception: H(j),
	exceptionDetails: H(Wt)
}), Kt = B({
	on: V(F("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
	value: V(P),
	reason: H(O())
}), qt = B({
	min: H(A(void 0, void 0, !0)),
	max: H(A(void 0, void 0, !0)),
	values: H(R(zt(O(), j), !0))
}), Jt = B({
	id: H(M),
	event: V(F("enter", "talk", "battle_result", "manual", "custom")),
	eventKey: V(O()),
	repeat: V(F("once", "repeatable")),
	scope: H(F(...yt)),
	deadline: H(Rt)
}), Yt = B({
	mode: V(F("reference", "clone", "override")),
	sourceId: V(I()),
	pinnedSnapshotId: V(L("snapshot")),
	overrideFields: V(R(O(1), !0)),
	bindings: H(W(M, M))
}), Xt = B({ unresolved: V(B({
	label: V(O()),
	reason: V(O(1))
})) }), Zt = B({
	instanceId: V(M),
	typeId: V(I("item")),
	quantity: V(A(0, void 0, !0)),
	ownerId: H(I("character", "group")),
	locationId: H(I("place")),
	consumed: V(j),
	reason: H(O())
}), Qt = B({
	assertionId: V(I("assertion")),
	holderId: H(I("character")),
	truth: V(F("true", "false", "unknown")),
	sourceEffectId: H(I("effect"))
}), $t = B({
	targetId: V(I("flow_node", "flow_edge", "disclosure")),
	value: V(F("true", "false", "unknown")),
	reasons: V(R(O()))
}), en = B({
	graphId: V(I("flow_graph")),
	returnNodeId: V(I("flow_node")),
	parameters: V(W(P, Pt))
}), tn = B({
	contentVersionId: V(L("snapshot")),
	variableValues: V(W(P, I("variable"))),
	itemInstances: V(R(Zt)),
	assertions: V(R(Qt)),
	seenIds: V(R(L("presentation"), !0)),
	visitCounts: V(W(A(0, void 0, !0), I())),
	onceTriggers: V(R(O(1), !0)),
	rngSeed: V(O(1)),
	rngPosition: V(A(0, void 0, !0)),
	callStack: V(R(en)),
	presentationPosition: H(I("flow_node")),
	loopNumber: V(A(0, void 0, !0)),
	provenance: V(F("full_play", "partial", "imported", "stub")),
	resetCauses: H(R(B({
		variableId: V(I("variable")),
		on: V(F("scene_end", "chapter_end", "run_end", "new_loop", "full_reset")),
		before: V(P),
		after: V(P),
		reason: V(O())
	})))
}), nn = B({
	entityId: V(I("scene")),
	occurrenceId: V(O(1, 256)),
	before: V(tn),
	after: V(tn),
	presentationState: H(tn),
	conditionResults: V(R($t)),
	externalValues: H(W(P, I("external_contract"))),
	worldTick: H(N)
}), rn = B({
	chapterIds: V(z("chapter")),
	sceneIds: V(R(I("scene"))),
	selection: H(F("chapters", "scenes")),
	occurrences: V(R(nn))
}), an = B({
	checked: V(A(0, void 0, !0)),
	total: V(A(0, void 0, !0))
}), on = B({
	byProvenance: H(W(an, F("full_play", "partial", "imported", "stub"))),
	byExternalMode: H(W(an, F("internal", "stub", "actual", "mixed"))),
	checked: V(A(0, void 0, !0)),
	total: V(A(0, void 0, !0)),
	excluded: H(A(0, void 0, !0)),
	unknown: H(A(0, void 0, !0))
}), sn = B(Object.fromEntries([
	"scenes",
	"dialogue",
	"choices",
	"conditionTrue",
	"conditionFalse",
	"declaredTests"
].map((e) => [e, V(on)]))), cn = B({
	key: V(Pt),
	label: V(O(1, 128)),
	type: V(F("text", "number", "boolean", "enum", "date", "ref")),
	required: V(j),
	nullable: V(j),
	default: {
		schema: { type: "custom" },
		required: !0,
		nullable: !0
	},
	allowedValues: H(R(O(), !0)),
	targetKinds: H(R(F(...D), !0)),
	help: H(O())
}), ln = B({
	value: H(A(0)),
	range: H(B({
		min: V(A(0)),
		max: V(A(0))
	})),
	unit: V(O(1)),
	assumptions: V(R(O())),
	scope: V(Ht),
	unknownCount: V(A(0, void 0, !0)),
	source: V(O()),
	speed: H(A(Number.MIN_VALUE))
}), un = B({
	...Object.fromEntries([
		"summary",
		"body",
		"text",
		"description",
		"question",
		"intent",
		"caption",
		"usageNotes",
		"interpretation",
		"examples",
		"action",
		"tutorial"
	].map((e) => [e, H(U)])),
	...Object.fromEntries((/* @__PURE__ */ "label.reading.terminalReason.reason.key.canonical.language.locale.sourceHash.expression.method.locator.predicate.cueType.precision.displayName.relationType.eventKey.resetReason.exclusionReason.exceptionReason.camera.parameters.variants.estimateAssumptions.estimateSource.blockingReason.mechanic.intentionalDifference.excerptLocation.estimateUnit.firstPerson.addressing.phrasing".split(".")).map((e) => [e, H(O())]))
}), dn = {
	character: B({
		reading: H(k),
		aliases: H(R(Ut)),
		summary: H(It),
		body: H(U),
		authorNotes: H(U),
		birth: H(Rt),
		death: H(Rt),
		goals: H(z("goal")),
		voiceRules: H(z("voice_rule"))
	}),
	group: B({
		groupType: V(F("display", "faction", "plot_thread", "category")),
		members: H(z()),
		parentId: H(I("group")),
		summary: H(It)
	}),
	event: B({
		summary: V(It),
		time: V(Rt),
		laneRole: V(F("common", "participants", "both")),
		participants: H(R(B({
			characterId: V(I("character")),
			role: V(F("actor", "witness", "mentioned", "informed", "custom")),
			evidenceIds: H(z()),
			knowledgeEffectIds: H(z("effect"))
		}))),
		locationId: H(I("place")),
		itemIds: H(z("item")),
		authorNotes: H(U),
		constraints: H(R(zt(B({
			type: V(F("before", "same_start")),
			targetEventId: V(I("event"))
		}), B({
			type: V(F("end_gap")),
			targetEventId: V(I("event")),
			minimumTicks: V(N),
			maximumTicks: V(N)
		}))))
	}),
	place: B({
		parentId: H(I("place")),
		reading: H(k),
		aliases: H(R(Ut)),
		body: H(U),
		mapIds: H(z("map")),
		changes: H(z("assertion"))
	}),
	item: B({
		itemMode: V(F("type", "instance")),
		typeId: H(I("item")),
		body: H(U),
		properties: H({ type: "custom" }),
		changes: H(z("assertion"))
	}),
	note: B({
		handoffReceipt: H(B({
			approval: V(B({
				entityId: V(L("entity")),
				sourceVersionId: V(L("snapshot"))
			})),
			sourceVersionId: V(L("snapshot")),
			verificationVersionId: V(L("snapshot")),
			profileVersionId: V(L("snapshot")),
			sourceRevision: V({ type: "revision" }),
			profileId: V(I("projection_profile")),
			packageHash: V({ type: "hash" }),
			receiptHash: V({ type: "hash" }),
			mode: V(F("stub", "actual", "mixed")),
			rawJson: V(O(1, 1048576)),
			idMappings: V(R(B({
				entityId: V(L("record")),
				sourceVersionId: V(L("snapshot")),
				publicId: V(O(1, 256))
			}))),
			projectionBindings: V(R(B({
				entityId: V(L("projection_record")),
				sourceVersionId: V(L("snapshot")),
				editionVersionId: V(L("snapshot")),
				publicId: V(O(1, 256))
			}))),
			citationBindings: V(R(B({
				sourceVersionId: V(L("snapshot")),
				publicVersionId: V(O(1, 256))
			}))),
			worldVersions: V(R(B({
				sourceVersionId: V(L("snapshot")),
				contentHash: V({ type: "hash" })
			})))
		})),
		body: V(U),
		attachmentIds: H(z("attachment")),
		convertedToIds: H(z()),
		originNoteId: H(I("note"))
	}),
	chapter: B({
		sceneIds: V(z("scene")),
		summary: H(It),
		authorNotes: H(U),
		structureRole: H(k)
	}),
	scene: B({
		summary: V(It),
		body: V(U),
		authorNotes: V(U),
		eventIds: V(z("event")),
		dialogueLineIds: H(z("dialogue_line")),
		chapterId: H(I("chapter")),
		threadIds: H(z("group")),
		povId: H(I("character")),
		goals: H(U),
		conflicts: H(U),
		results: H(U),
		newInformation: H(U),
		tension: H(A(0, 10)),
		importance: H(A(0, 10)),
		blockIds: H(R(L("block"), !0)),
		reuse: H(Yt)
	}),
	goal: B({
		ownerId: V(I("character", "group")),
		description: V(U),
		changes: H(z("assertion")),
		evidenceSceneIds: H(z("scene")),
		validity: H(Vt)
	}),
	flow_node: B({
		nodeType: V(F("scene", "choice", "automatic", "call", "entry", "exit", "terminal")),
		sceneId: H(I("scene")),
		childGraphId: H(I("flow_graph")),
		terminalReason: H(O()),
		trigger: H(Jt),
		gate: H(Lt),
		executionPolicy: H(F("manual_choice", "first_match", "all_match")),
		fallbackId: H(I("flow_node")),
		reuse: H(Yt)
	}),
	flow_edge: B({
		fromId: V(I("flow_node")),
		toId: V(zt(I("flow_node"), Xt)),
		edgeType: V(F("choice", "automatic", "call_return")),
		label: H(O()),
		condition: H(Lt),
		effectIds: H(z("effect")),
		priority: H(A(void 0, void 0, !0)),
		choiceLineId: H(I("dialogue_line"))
	}),
	flow_graph: B({
		nodeIds: V(z("flow_node")),
		edgeIds: V(z("flow_edge")),
		entryIds: V(z("flow_node")),
		exitIds: V(z("flow_node")),
		parentGraphId: H(I("flow_graph")),
		parameters: H(R(B({
			key: V(Pt),
			type: V(F("boolean", "integer", "enum")),
			default: H(P)
		})))
	}),
	dialogue_line: B({
		text: V(U),
		speakerId: H(I("character")),
		choiceEdgeId: H(I("flow_edge")),
		cueIds: H(z("cue")),
		originLineIds: H(z("dialogue_line")),
		replacedByLineIds: H(z("dialogue_line")),
		lineage: H(B({
			mode: V(F("split", "merge", "copy")),
			baseRevision: V({ type: "revision" }),
			reason: V(O(1)),
			segments: V(R(B({
				source: V(G),
				target: V(G)
			}), !1, 1))
		})),
		claimAssertionIds: H(z("assertion")),
		assertionIntent: H(F("statement", "lie", "misunderstanding", "quotation")),
		assertionReason: H(O())
	}),
	quest: B({
		key: V(Pt),
		stateVariableId: V(I("variable")),
		description: H(U),
		flowIds: H(z("flow_graph")),
		transitionRules: H(R(Gt)),
		gameplaySpecIds: H(z("gameplay_spec"))
	}),
	lore: B({
		body: V(U),
		assertionIds: H(z("assertion")),
		sourceIds: H(z("source")),
		reading: H(k),
		aliases: H(R(Ut))
	}),
	variable: B({
		key: V(Pt),
		valueType: V(F("boolean", "integer", "enum")),
		scope: V(F(...yt)),
		initial: V(P),
		allowed: V(qt),
		description: H(U),
		ownerId: H(I("character")),
		derived: H({ type: "expression" }),
		externalContractId: H(I("external_contract")),
		resetRules: H(R(Kt)),
		transitionRules: H(R(Gt)),
		exclusions: H(R(B({
			variableId: V(I("variable")),
			value: V(P),
			otherValue: V(P),
			reason: V(O(1)),
			exceptions: H(R(Wt))
		}))),
		externalUseDeclared: H(j)
	}),
	effect: B({
		operation: V(F("set", "add", "grant", "consume", "move", "assert", "mark_seen", "reset")),
		targetId: V(I()),
		value: H(P),
		condition: H(Lt),
		instanceId: H(I("item")),
		reason: H(O()),
		exceptionDetails: H(Wt)
	}),
	assertion: B({
		subjectId: V(I()),
		predicate: V(O(1, 128)),
		value: V(zt(P, I())),
		truthKind: V(F("author_truth", "testimony", "belief", "hypothesis")),
		holderId: H(I("character")),
		sourceIds: H(z("source", "assertion", "event", "scene", "dialogue_line")),
		evidenceLocation: H(G),
		validity: H(Vt),
		reason: H(O())
	}),
	foreshadow: B({
		question: V(U),
		intent: V(U),
		resolutionPolicy: V(F("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
		truthAssertionIds: H(z("assertion")),
		clueIds: H(z("disclosure")),
		payoffIds: H(z("disclosure")),
		requiredInfo: H(z("disclosure", "assertion")),
		alternativeInfo: H(W(z("disclosure", "assertion"), I("disclosure", "assertion"))),
		deadline: H(Ht),
		presentationDeadline: H(G),
		exceptions: H(R(Wt))
	}),
	disclosure: B({
		foreshadowId: V(I("foreshadow")),
		anchor: V(G),
		stage: V(F("hint", "suspicion", "reinforce", "reveal", "alternative")),
		role: V(F("clue", "payoff")),
		condition: H(Lt),
		knowledgeEffects: H(z("effect")),
		targetScope: H(Ht)
	}),
	checkpoint: B({
		worldTick: H(N),
		contentVersionId: V(L("snapshot")),
		runtimeState: V(tn),
		presentationState: H(tn),
		presentationResults: H(R($t)),
		contentRevision: H({ type: "revision" }),
		origin: H(F("full_play", "partial", "imported")),
		traceId: H(I("trace")),
		migration: H(B({
			sourceCheckpointId: V(I("checkpoint")),
			sourceVersionId: V(L("snapshot")),
			baseRevision: V({ type: "revision" }),
			method: V(F("migrate", "recreate"))
		}))
	}),
	trace: B({
		contentVersionId: V(L("snapshot")),
		startCheckpointId: V(I("checkpoint")),
		steps: V(R(B({
			nodeId: V(I("flow_node")),
			edgeIds: V(z("flow_edge")),
			before: V(tn),
			after: V(tn),
			presentationState: H(tn),
			conditionResults: H(R($t)),
			operation: H(F("advance", "stub")),
			occurrenceId: H(O()),
			worldTick: H(N),
			externalMode: H(F("stub", "actual", "mixed")),
			externalValues: H(W(P, I("external_contract")))
		}))),
		contentRevision: H({ type: "revision" }),
		initialExternalValues: H(W(P, I("external_contract"))),
		initialStubBaseState: H(tn),
		initialStubValues: H(B({
			variables: H(W(P, I("variable"))),
			external: H(W(P, I("external_contract")))
		})),
		initialWorldTick: H(N),
		seed: H(O()),
		engineVersion: H(O()),
		externalMode: H(F("stub", "actual", "mixed")),
		coverage: H(sn),
		regressionDeclarations: H(B({
			projectRevision: V({ type: "revision" }),
			traceIds: V(z("trace"))
		})),
		reconfirmation: H(B({
			sourceTraceId: V(I("trace")),
			sourceVersionId: V(L("snapshot")),
			baseRevision: V({ type: "revision" }),
			startCheckpointId: H(I("checkpoint"))
		})),
		mode: H(F("flow", "chapters", null)),
		readingPath: H(zt(rn, F(null)))
	}),
	attachment: B({
		mediaType: V(O(1, 128)),
		contentHash: V({ type: "hash" }),
		byteSize: V(A(0, 33554432, !0)),
		assetPath: V({ type: "safe_path" }),
		displayName: H(O()),
		provenanceId: H(I("source")),
		licenseNote: H(O()),
		stage: H(F("reference", "temporary", "final")),
		revisionHistory: H(z("attachment"))
	}),
	source: B({
		sourceType: V(F("web", "file", "book", "observation")),
		locator: V(O(1)),
		accessedAt: H({ type: "datetime" }),
		excerptLocation: H(O()),
		interpretation: H(U),
		attachmentId: H(I("attachment")),
		redistributionAllowed: H(j)
	}),
	cue: B({
		anchor: V(G),
		cueType: V(O(1, 128)),
		attachmentId: H(I("attachment")),
		speakerId: H(I("character")),
		expression: H(O()),
		waitMs: H(A(0, void 0, !0)),
		camera: H({ type: "custom" }),
		mediaTime: H(A(0, void 0, !0)),
		stage: H(k)
	}),
	storyboard_frame: B({
		anchor: V(G),
		mediaStartMs: V(A(0, void 0, !0)),
		mediaEndMs: H(A(0, void 0, !0)),
		referenceAssetId: H(I("attachment")),
		finalAssetId: H(I("attachment")),
		cueIds: H(z("cue")),
		caption: H(U)
	}),
	localization: B({
		sourceLineId: V(I("dialogue_line")),
		language: V(O(1, 128)),
		sourceHash: V({ type: "hash" }),
		text: V(U),
		stage: H(F("draft", "reviewed", "needs_review")),
		reviewedBy: H(L("identity")),
		recordingIds: H(z("recording"))
	}),
	recording: B({
		sourceLineId: V(I("dialogue_line")),
		language: V(O(1, 128)),
		sourceHash: V({ type: "hash" }),
		translationId: H(I("localization")),
		attachmentId: H(I("attachment")),
		notes: H(U),
		stage: H(F("planned", "recorded", "reviewed", "needs_review")),
		reviewedBy: H(L("identity"))
	}),
	terminology: B({
		canonical: V(O(1, 128)),
		reading: V(k),
		variants: H(R(k, !0)),
		language: H(k),
		usageNotes: H(U),
		validity: H(Vt),
		exceptions: H(R(Wt)),
		voiceOwnerId: H(I("character"))
	}),
	map: B({
		placeId: V(I("place")),
		coordinateSystem: V(F("normalized")),
		attachmentId: H(I("attachment")),
		parentMapId: H(I("map")),
		pins: H(R(B({
			id: V(M),
			placeId: V(I("place")),
			x: V(A(0, 1)),
			y: V(A(0, 1)),
			label: H(O())
		})))
	}),
	travel_route: B({
		fromPlaceId: V(I("place")),
		toPlaceId: V(I("place")),
		direction: V(F("one_way", "two_way")),
		method: H(O()),
		minimumTicks: H(N),
		maximumTicks: H(N),
		evidence: H(z()),
		validity: H(Vt)
	}),
	template: B({
		targetKind: V(F(...D)),
		fields: V(R(cn)),
		description: H(O()),
		version: H({ type: "revision" }),
		defaults: H(W({ type: "custom" }, Pt))
	}),
	collection: B({
		purpose: H(F("regression")),
		mode: V(F("dynamic", "fixed")),
		query: H({ type: "query" }),
		memberIds: H(z()),
		sort: H(B({
			field: V(F("name", "createdAt", "updatedAt", "kind")),
			direction: V(F("asc", "desc"))
		}))
	}),
	review: B({
		target: V(zt(G, I())),
		targetVersionId: V(L("snapshot")),
		body: V(U),
		stage: V(F("open", "fixed", "verified")),
		assigneeId: H(L("identity")),
		quotedText: H(O()),
		resolution: H(U),
		sharedSource: H(B({
			connection: V(O(1)),
			sharedSnapshot: V(O(1)),
			comment: V(O(1)),
			publicVersion: V(O(1)),
			publicEntity: H(O(1)),
			publicRelation: H(O(1)),
			publicBlock: H(O(1)),
			startCp: H(A(0, void 0, !0)),
			endCp: H(A(0, void 0, !0)),
			projectionHash: V(O(64, 64)),
			commentBodyHash: V(O(64, 64)),
			quotedText: V(O()),
			observedStage: V(F("open", "fixed", "verified"))
		}))
	}),
	creative_brief: B({
		targetAudience: V(U),
		experience: V(U),
		theme: V(U),
		tone: V(U),
		scope: V(U),
		deliverableIds: H(z()),
		decisionIds: H(z("decision"))
	}),
	decision: B({
		subject: V(O(1)),
		reason: V(U),
		targetVersionId: V(L("snapshot")),
		outcome: V(F("accepted", "rejected", "deferred")),
		priority: H(k),
		requirementIds: H(R(k, !0)),
		reviewIds: H(z("review"))
	}),
	gameplay_spec: B({
		sceneId: V(I("scene")),
		action: V(U),
		mechanic: H(O()),
		tutorial: H(U),
		reward: H(P),
		questId: H(I("quest")),
		taskIds: H(z("production_task")),
		intentionalDifference: H(O())
	}),
	production_task: B({
		targetIds: V(z()),
		stage: V(F("writing", "review", "implementation", "translation", "recording", "verification", "publication")),
		progress: V(F("todo", "doing", "done", "needs_review")),
		assigneeId: H(L("identity")),
		deadline: H(B({
			date: V({ type: "date" }),
			timeZone: V(O(1, 128))
		})),
		dependsOn: H(z("production_task")),
		estimate: H(ln),
		blockingReason: H(O())
	}),
	media_variant: B({
		previousVariantId: H(I("media_variant")),
		confirmationRecipientIds: H(R(L("identity"), !0)),
		medium: V(F("game", "novel", "video", "audio", "promotion", "custom")),
		baseSnapshotId: V(L("snapshot")),
		body: H(U),
		releaseAt: H({ type: "datetime" }),
		projectionProfileId: H(I("projection_profile")),
		sourceIds: H(z()),
		needsReview: H(j)
	}),
	voice_rule: B({
		characterId: V(I("character")),
		validity: V(Vt),
		firstPerson: H(k),
		addressing: H(O()),
		phrasing: H(O()),
		examples: H(U),
		exceptions: H(R(Wt))
	}),
	external_contract: B({
		key: V(Pt),
		owner: V(F("tool", "game")),
		inputType: V(O(1, 128)),
		outputType: V(O(1, 128)),
		missingPolicy: V(F("unknown", "block")),
		description: H(U),
		stubValues: H(R(P)),
		adapterProfileIds: H(z("projection_profile")),
		version: H(k)
	}),
	snapshot: B({
		versionLabel: V(O(1, 128)),
		contentHash: V({ type: "hash" }),
		immutable: V(F(!0)),
		parentVersionIds: H(R(L("snapshot"), !0)),
		releasedAt: H({ type: "datetime" }),
		referencedWorldVersionIds: H(R(L("snapshot"), !0))
	}),
	projection_profile: B({
		blockSources: H(W(L("block"), L("projection_record"))),
		citedVersions: H(R(B({
			sourceVersionId: V(L("snapshot")),
			profileId: V(I("projection_profile")),
			publicVersionId: V(M)
		}))),
		audience: V(O(1, 128)),
		includedIds: V(z()),
		namePolicy: V({ type: "name_policy" }),
		allowedKinds: H(R(F(...D), !0)),
		excludedFields: H(R(O(1), !0)),
		routeScope: H(Ht),
		includeAuthorNotes: H(j),
		publicTitle: H(O()),
		publicTexts: H(W(un, L("record"))),
		allowedFields: H(W(R(O(1), !0), F(...D))),
		allowedRelationIds: H(R(L("relation"), !0)),
		idPolicy: H(F("remap", "preserve")),
		publicIds: H(W(M, L("projection_record"))),
		sourceVersionId: H(L("snapshot")),
		publicValues: H(W(W(O(), O()), I("variable", "external_contract", "assertion"))),
		includedStatuses: H(R(F(...vt), !0)),
		publicVersionLabel: H(O()),
		approvedAttachmentIds: H(z("attachment"))
	})
}, K = (e) => !!e && typeof e == "object" && !Array.isArray(e) && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null), fn = (e) => lt(e).utf8Bytes, pn = (e) => lt(e).codePoints, mn = (e) => lt(e).validUnicode;
function q(e, t, n, r = "VALIDATION_FAILED") {
	e.length < 256 && e.push({
		code: r,
		path: t,
		message: n
	});
}
function hn(e) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(e)) return !1;
	let t = gn.get(e);
	if (t !== void 0) return t;
	let n = /* @__PURE__ */ new Date(`${e}T00:00:00Z`), r = Number.isFinite(n.getTime()) && n.toISOString().slice(0, 10) === e;
	return gn.size >= 512 && gn.delete(gn.keys().next().value), gn.set(e, r), r;
}
var gn = /* @__PURE__ */ new Map(), _n = /* @__PURE__ */ new Map(), vn = /^\d{4}-\d{2}-\d{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.\d+)?(?:Z|\+00:00)$/;
function yn(e) {
	let t = e.length <= 64;
	if (t) {
		let t = _n.get(e);
		if (t !== void 0) return t;
	}
	let n = vn.test(e) && Number.isFinite(Date.parse(e)) && hn(e.slice(0, 10));
	return t && (_n.size >= 512 && _n.delete(_n.keys().next().value), _n.set(e, n)), n;
}
function bn(e) {
	switch (e.op) {
		case "constant": return B({
			op: V(F("constant")),
			value: V(j)
		});
		case "all":
		case "any": return B({
			op: V(F("all", "any")),
			children: V(R(Lt, !1, 1, 256))
		});
		case "not": return B({
			op: V(F("not")),
			child: V(Lt)
		});
		case "compare": return B({
			op: V(F("compare")),
			variableId: V(I("variable")),
			comparator: V(F("eq", "ne", "lt", "le", "gt", "ge", "in")),
			value: V(e.comparator === "in" ? R(P, !1, 1, 256) : P)
		});
		case "item": return B({
			op: V(F("item")),
			itemId: V(I("item")),
			quantity: V(A(1, void 0, !0))
		});
		case "known": return B({
			op: V(F("known")),
			assertionId: V(I("assertion")),
			holderId: V(I("character"))
		});
		case "visited": return B({
			op: V(F("visited")),
			entityId: V(I()),
			count: V(A(1, void 0, !0))
		});
		case "external": return B({
			op: V(F("external")),
			contractId: V(I("external_contract"))
		});
		default: return;
	}
}
function xn(e) {
	let t = { type: "expression" };
	switch (e.op) {
		case "value": return B({
			op: V(F("value")),
			value: V(P)
		});
		case "variable": return B({
			op: V(F("variable")),
			variableId: V(I("variable"))
		});
		case "add":
		case "subtract":
		case "multiply": return B({
			op: V(F("add", "subtract", "multiply")),
			left: V(t),
			right: V(t)
		});
		case "if": return B({
			op: V(F("if")),
			condition: V(Lt),
			then: V(t),
			else: V(t)
		});
		default: return bn(e);
	}
}
function Sn(e) {
	let t = V(L("calendar"));
	switch (e.mode) {
		case "instant": return B({
			mode: V(F("instant")),
			at: V(N),
			calendarId: t
		});
		case "interval": return B({
			mode: V(F("interval")),
			start: V(N),
			end: V(N),
			calendarId: t
		});
		case "uncertain": return B({
			mode: V(F("uncertain")),
			earliest: V(N),
			latest: V(N),
			calendarId: t,
			precision: V(O())
		});
		case "relative": return B({
			mode: V(F("relative")),
			anchorEventId: V(I("event")),
			anchorPoint: V(F("start", "end")),
			minOffset: V(N),
			maxOffset: V(N)
		});
		case "unknown": return B({
			mode: V(F("unknown")),
			reason: V(O())
		});
		default: return;
	}
}
function Cn(e) {
	switch (e.op) {
		case "all":
		case "any": return B({
			op: V(F("all", "any")),
			children: V(R({ type: "query" }, !1, 1, 256))
		});
		case "kind": return B({
			op: V(F("kind")),
			value: V(F(...D))
		});
		case "text": return B({
			op: V(F("text")),
			value: V(O())
		});
		case "status": return B({
			op: V(F("status")),
			value: V(F(...vt))
		});
		case "participant": return B({
			op: V(F("participant")),
			characterId: V(I("character"))
		});
		case "production": return B({
			op: V(F("production")),
			value: V(F("todo", "doing", "done", "needs_review"))
		});
		case "chapter": return B({
			op: V(F("chapter")),
			chapterId: V(I("chapter"))
		});
		case "foreshadow": return B({
			op: V(F("foreshadow")),
			foreshadowId: Ft(I("foreshadow")),
			resolutionPolicy: Ft(F("this_work", "sequel", "intentional_open", "red_herring", "undecided", "rejected")),
			role: Ft(F("clue", "payoff")),
			stage: Ft(F("hint", "suspicion", "reinforce", "reveal", "alternative"))
		});
		default: return;
	}
}
function wn(e) {
	if (!("mode" in e)) {
		let e = zt(...[
			"alias",
			"replace",
			"exclude",
			"anonymize"
		].map((e) => wn({ mode: e })));
		return B({
			defaultPolicy: H(e),
			byEntityId: H(W(e, I()))
		});
	}
	switch (e.mode) {
		case "alias": return B({
			mode: V(F("alias")),
			aliasId: V(L("alias"))
		});
		case "replace": return B({
			mode: V(F("replace")),
			replacement: V(O(1, 128))
		});
		case "exclude": return B({ mode: V(F("exclude")) });
		case "anonymize": return B({
			mode: V(F("anonymize")),
			publicId: V(M),
			publicName: V(O(1, 128))
		});
		default: return;
	}
}
var Tn = {
	start: V(A(0, void 0, !0)),
	end: V(A(0, void 0, !0))
}, En = R(B({
	id: V(M),
	kind: V(F("paragraph", "heading", "list_item", "quote")),
	text: V(O()),
	ruby: H(R(B({
		...Tn,
		text: V(O())
	}))),
	links: H(R(B({
		...Tn,
		target: V(G)
	}))),
	unresolvedAnnotations: H(R(Bt))
}));
function J(e, t, n, r, i, a = 0, o) {
	if (r.length >= 256) return;
	if (a > 32) {
		q(r, n, "構造の深さが上限32を超えています。", "IMPORT_LIMIT");
		return;
	}
	let s = (e) => q(r, n, e);
	switch (e.type) {
		case "json": {
			let e = (t, n, i, a) => {
				if (i > 100) {
					q(r, n, "JSON階層の上限を超えています。", "IMPORT_LIMIT");
					return;
				}
				if (t !== null && typeof t != "string" && typeof t != "boolean" && !(typeof t == "number" && Number.isFinite(t))) {
					if (!t || typeof t != "object" || a.has(t)) {
						q(r, n, "通常のJSON値を指定してください。");
						return;
					}
					if (a.add(t), Array.isArray(t)) t.forEach((t, r) => e(t, `${n}[${r}]`, i + 1, a));
					else if (Object.getPrototypeOf(t) === Object.prototype || Object.getPrototypeOf(t) === null) for (let [o, s] of Object.entries(t)) [
						"__proto__",
						"prototype",
						"constructor"
					].includes(o) ? q(r, `${n}.${o}`, "予約済みのキーは使えません。") : e(s, `${n}.${o}`, i + 1, a);
					else q(r, n, "通常のJSONオブジェクトを指定してください。");
					a.delete(t);
				}
			};
			e(t, n, 0, /* @__PURE__ */ new Set());
			return;
		}
		case "text": {
			if (typeof t != "string") {
				s("文字列を入力してください。");
				return;
			}
			mn(t) || s("文字列に不正なUnicodeがあります。");
			let n = pn(t);
			e.min !== void 0 && n < e.min && s(`${e.min}文字以上で入力してください。`), e.max !== void 0 && n > e.max && s(`${e.max}文字以内で入力してください。`), e.maxBytes !== void 0 && fn(t) > e.maxBytes && s("本文が1 MiBの上限を超えています。");
			return;
		}
		case "number":
			typeof t != "number" || !Number.isFinite(t) || e.integer && !Number.isSafeInteger(t) ? s(e.integer ? "安全な範囲の整数を入力してください。" : "有限の数値を入力してください。") : (e.min !== void 0 && t < e.min || e.max !== void 0 && t > e.max) && s("数値が許容範囲外です。");
			return;
		case "boolean":
			typeof t != "boolean" && s("真偽値を指定してください。");
			return;
		case "enum":
			e.values.includes(t) || s("宣言された値を選んでください。");
			return;
		case "id":
			(typeof t != "string" || !St.test(t)) && s("小文字のUUIDを指定してください。");
			return;
		case "ref":
			typeof t == "string" && (e.scope === "calendar" ? t.length > 0 : St.test(t)) || s(e.scope === "calendar" ? "暦IDが必要です。" : "参照先は小文字UUIDです。"), typeof t == "string" && i.push({
				id: t,
				path: n,
				kinds: e.kinds,
				scope: e.scope ?? "entity"
			});
			return;
		case "tick":
			Re(t) || s("tickは38桁以内の正規整数文字列です。");
			return;
		case "revision":
			(typeof t != "string" || !Ct.test(t)) && s("revisionは0以上の整数文字列です。");
			return;
		case "datetime":
			(typeof t != "string" || !yn(t)) && s("UTCのRFC 3339日時を指定してください。");
			return;
		case "date":
			(typeof t != "string" || !hn(t)) && s("実在するYYYY-MM-DD形式の日付を指定してください。");
			return;
		case "hash":
			(typeof t != "string" || !/^[0-9a-f]{64}$/.test(t)) && s("SHA-256は小文字16進数64文字です。");
			return;
		case "safe_path":
			(typeof t != "string" || !t || t.startsWith("/") || t.includes("\\") || t.includes("\0") || /^[a-zA-Z]:/.test(t) || t.split("/").some((e) => !e || e === "." || e === "..") || /[\u0000-\u001f\u007f]/.test(t)) && s("安全な相対パスを指定してください。");
			return;
		case "array":
			if (!Array.isArray(t)) {
				s("配列を指定してください。");
				return;
			}
			if (t.length > (e.max ?? 1e5) || e.min !== void 0 && t.length < e.min) {
				s("配列の件数が許容範囲外です。");
				return;
			}
			e.unique && new Set(t.map((e) => typeof e == "object" ? JSON.stringify(e) : e)).size !== t.length && s("同じ値を集合内で重複保存できません。"), t.forEach((t, s) => J(e.item, t, `${n}[${s}]`, r, i, a + 1, o));
			return;
		case "object":
			if (!K(t)) {
				s("オブジェクトを指定してください。");
				return;
			}
			for (let i of Object.keys(t)) Object.hasOwn(e.fields, i) || q(r, `${n}.${i}`, "未知の項目は保存できません。");
			for (let s of Object.keys(e.fields)) {
				let c = e.fields[s], l = t[s], u = `${n}.${s}`;
				if (l === void 0) {
					c.required && q(r, u, "必須項目です。");
					continue;
				}
				l === null && c.nullable || J(c.schema, l, u, r, i, a + 1, o);
			}
			return;
		case "record":
			if (!K(t)) {
				s("項目の辞書を指定してください。");
				return;
			}
			for (let [s, c] of Object.entries(t)) {
				if ([
					"__proto__",
					"prototype",
					"constructor"
				].includes(s)) {
					q(r, `${n}.${s}`, "予約済みのキーは使えません。");
					continue;
				}
				e.key && J(e.key, s, `${n}.${s}.$key`, r, i, a + 1, o), J(e.value, c, `${n}.${s}`, r, i, a + 1, o);
			}
			return;
		case "union": {
			let s;
			for (let r of e.choices) {
				let e = [], c = [];
				if (J(r, t, n, e, c, a + 1, o), !e.length) {
					i.push(...c);
					return;
				}
				(!s || e.length < s.length) && (s = e);
			}
			r.push(...s ?? [{
				code: "VALIDATION_FAILED",
				path: n,
				message: "対応する型ではありません。"
			}]);
			return;
		}
		case "typed": {
			if (!K(t)) {
				s("型と値を指定してください。");
				return;
			}
			let e;
			switch (t.type) {
				case "boolean":
					e = j;
					break;
				case "integer":
					e = A(void 0, void 0, !0);
					break;
				case "enum":
				case "text":
					e = O();
					break;
				case "ref":
					e = I();
					break;
				case "unknown":
					J(B({
						type: V(F("unknown")),
						value: {
							schema: O(),
							required: !0,
							nullable: !0
						},
						reason: V(O())
					}), t, n, r, i, a + 1, o), t.value !== null && s("未定値のvalueはnullです。");
					return;
				default:
					s("未知の値型です。");
					return;
			}
			J(B({
				type: V(F(t.type)),
				value: V(e)
			}), t, n, r, i, a + 1, o);
			return;
		}
		case "custom":
			if (t === null) return;
			if (typeof t == "string") J(O(), t, n, r, i, a, o);
			else if (typeof t == "number") J(A(), t, n, r, i, a, o);
			else if (typeof t == "boolean") return;
			else K(t) && t.type === "ref" ? J(B({
				type: V(F("ref")),
				value: V(I())
			}), t, n, r, i, a + 1, o) : K(t) && t.type === "date" ? J(B({
				type: V(F("date")),
				value: V({ type: "date" })
			}), t, n, r, i, a + 1, o) : s("カスタム値は文字列・数値・真偽・日付・参照またはnullです。");
			return;
		case "richtext": {
			if (J(En, t, n, r, i, a + 1, o), !Array.isArray(t)) return;
			let c = 0, l = 0, u = /* @__PURE__ */ new Set();
			t.forEach((e, t) => {
				if (!K(e) || typeof e.text != "string") return;
				let i = pn(e.text);
				if (c += fn(e.text), l += i, typeof e.id == "string" && (u.has(e.id) && q(r, `${n}[${t}].id`, "段落IDが重複しています。"), u.add(e.id)), Array.isArray(e.unresolvedAnnotations)) {
					for (let t of e.unresolvedAnnotations) if (K(t)) for (let e of [
						"originalText",
						"reason",
						"reading"
					]) typeof t[e] == "string" && (c += fn(t[e]));
				}
				for (let a of ["ruby", "links"]) Array.isArray(e[a]) && e[a].forEach((e, o) => {
					K(e) && (typeof e.start == "number" && typeof e.end == "number" && (e.start >= e.end || e.end > i) && q(r, `${n}[${t}].${a}[${o}]`, "文字範囲はコードポイントで数え、本文内の半開区間を指定してください。"), typeof e.text == "string" && (c += fn(e.text)));
				});
			}), c > 1048576 && s("本文フィールドが1 MiBを超えています。"), e.max !== void 0 && l > e.max && s(`要約は${e.max}文字以内です。`);
			return;
		}
		case "condition":
		case "expression": {
			let a = o ?? {
				counter: { count: 0 },
				depth: 0
			};
			if (a.counter.count++, a.counter.count > 256 || a.depth >= 16) {
				s("条件・式は深さ16、ノード256までです。");
				return;
			}
			if (!K(t)) {
				s("条件・式は型付きASTで指定してください。");
				return;
			}
			let c = e.type === "condition" ? bn(t) : xn(t);
			if (!c) {
				s("未知の条件・式opです。");
				return;
			}
			J(c, t, n, r, i, 0, {
				counter: a.counter,
				depth: a.depth + 1
			});
			return;
		}
		case "time": {
			if (!K(t)) {
				s("日時はTimeSpecで指定してください。");
				return;
			}
			let e = Sn(t);
			if (!e) {
				s("未知の日時modeです。");
				return;
			}
			let c = r.length;
			J(e, t, n, r, i, a + 1, o), r.length === c && (t.mode === "interval" && T(t.start, t.end) >= 0 && s("期間はstart < endの半開区間です。"), t.mode === "uncertain" && T(t.earliest, t.latest) > 0 && s("earliestはlatest以下です。"), t.mode === "relative" && T(t.minOffset, t.maxOffset) > 0 && s("minOffsetはmaxOffset以下です。"));
			return;
		}
		case "query":
		case "name_policy": {
			if (!K(t)) {
				s("型付きのオブジェクトを指定してください。");
				return;
			}
			let c = e.type === "query" ? Cn(t) : wn(t);
			if (!c) {
				s("未知の規則です。");
				return;
			}
			let l = r.length;
			J(c, t, n, r, i, a + 1, o), e.type === "query" && t.op === "foreshadow" && r.length === l && ![
				"foreshadowId",
				"resolutionPolicy",
				"role",
				"stage"
			].some((e) => t[e] !== void 0 && t[e] !== null) && q(r, n, "伏線検索には対象・回収方針・開示役割・段階のいずれかを指定してください。");
			return;
		}
	}
}
var Dn = {
	id: V(M),
	projectId: V(L("project")),
	kind: V(F(...D)),
	revision: V({ type: "revision" }),
	name: V(k),
	status: V(F(...vt)),
	visibility: V(F("private", "team", "projection")),
	retainIfUnreferenced: H(j),
	projectionProfileId: H(I("projection_profile")),
	templateId: H(I("template")),
	createdAt: V({ type: "datetime" }),
	updatedAt: V({ type: "datetime" }),
	deletedAt: H({ type: "datetime" }),
	deletionOperationId: H(M),
	customValues: V(W({ type: "custom" }, Pt))
}, On = B({
	id: V(M),
	projectId: V(L("project")),
	revision: V({ type: "revision" }),
	fromId: V(I()),
	toId: V(I()),
	relationType: V(O(1, 128)),
	direction: V(F("forward", "symmetric")),
	validity: V(Vt),
	evidenceIds: V(z()),
	status: V(F(...vt)),
	visibility: V(F("private", "team", "projection")),
	projectionProfileId: H(I("projection_profile")),
	deletedAt: H({ type: "datetime" }),
	deletionOperationId: H(M)
}), kn = /* @__PURE__ */ new Map();
function An(e) {
	let t = dn[e], n = kn.get(e);
	if (n?.data === t) return n.record;
	let r = B({
		...Dn,
		kind: V(F(e)),
		data: V(t)
	});
	return kn.set(e, {
		data: t,
		record: r
	}), r;
}
function jn(e, t, n, r = []) {
	let i = [];
	return J(e, t, n, i, r), i.length ? {
		ok: !1,
		issues: i
	} : {
		ok: !0,
		value: t
	};
}
function Mn(e, t = "condition") {
	return jn(Lt, e, t);
}
function Nn(e, t = "value") {
	return jn(P, e, t);
}
function Pn(e, t = "runtimeState") {
	let n = jn(tn, e, t);
	if (!n.ok) return n;
	let r = [], i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	return n.value.itemInstances.forEach((e, n) => {
		i.has(e.instanceId) && q(r, `${t}.itemInstances[${n}].instanceId`, "物品個体のIDが重複しています。"), i.add(e.instanceId), (e.ownerId && e.locationId || e.consumed && e.quantity !== 0 || !e.consumed && e.quantity < 1) && q(r, `${t}.itemInstances[${n}]`, "物品の所在・所有・消費状態・数量が不整合です。");
	}), n.value.assertions.forEach((e, n) => {
		let i = `${e.assertionId}/${e.holderId}`;
		a.has(i) && q(r, `${t}.assertions[${n}]`, "同じ人物・事実の認識が重複しています。"), a.add(i);
	}), r.length ? {
		ok: !1,
		issues: r
	} : n;
}
function Fn(e, t, n, r = "presentationResults") {
	let i = jn(R($t), t, r);
	if (!i.ok) return i.issues;
	let a = [], o = new Set(e.seenIds), s = /* @__PURE__ */ new Set(), c = n.find((t) => t.kind === "flow_node" && t.id === e.presentationPosition && !t.deletedAt && t.status !== "rejected"), l = n.filter((e) => {
		if (e.kind !== "disclosure" || e.deletedAt || e.status === "rejected" || !c || !o.has(c.id)) return !1;
		let t = e.data.anchor;
		return t.positionStatus !== "unresolved" && (t.entityId === c.id || t.entityId === c.data.sceneId) && (!t.blockId || o.has(t.blockId)) && (!t.lineId || o.has(t.lineId));
	}), u = new Set(l.map((e) => e.id));
	i.value.forEach((t, n) => {
		let i = `${r}[${n}]`;
		s.has(t.targetId) && q(a, `${i}.targetId`, "初期提示の条件結果が重複しています。"), s.add(t.targetId), u.has(t.targetId) || q(a, `${i}.targetId`, "初期提示の対象ではない開示の条件結果です。", "REFERENCE_INVALID"), t.value === "unknown" && q(a, `${i}.value`, "未確認の開示条件では初期提示を完了できません。"), t.value === "true" && !o.has(t.targetId) && q(a, `${i}.value`, "提示した条件結果と既読の証跡が一致しません。"), t.value === "false" && o.has(t.targetId) && e.provenance === "full_play" && q(a, `${i}.value`, "提示済みの開示を初期条件のfalseで取り消すことはできません。");
	});
	for (let e of l) s.has(e.id) || q(a, r, "初期提示の開示条件結果が不足しています。");
	return a;
}
function In(e, t = "effect") {
	return jn(dn.effect, e, t);
}
function Ln(e, t, n) {
	if (!K(e) || !D.includes(e.kind)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: `${t}.kind`,
			message: "未対応の情報種別です。"
		}]
	};
	let r = jn(An(e.kind), e, t, n);
	if (!r.ok) return r;
	let i = [];
	return Rn(r.value, t, i), i.length ? {
		ok: !1,
		issues: i
	} : r;
}
function Y(e, t, n = "value", r = !0) {
	let i = [], a = e.data;
	if (t.type === "unknown") return r || q(i, n, "未定の値はこの操作で使えません。", "CONDITION_UNKNOWN"), i;
	if (t.type !== a.valueType) return q(i, n, "状態変数の宣言型と値の型が一致しません。"), i;
	if (t.type === "integer") {
		let e = a.allowed.min ?? -2147483647, r = a.allowed.max ?? 2147483647;
		(!Number.isSafeInteger(t.value) || t.value < e || t.value > r) && q(i, n, "状態変数の値が宣言した整数範囲外です。");
	}
	return (t.type === "enum" || t.type === "boolean") && a.allowed.values && !a.allowed.values.includes(t.value) && q(i, n, "状態変数の値が許容集合にありません。"), i;
}
function Rn(e, t, n) {
	let r = (e, r) => q(n, `${t}.${e}`, r);
	![
		"dialogue_line",
		"effect",
		"assertion",
		"disclosure",
		"cue",
		"storyboard_frame",
		"localization",
		"recording",
		"checkpoint",
		"trace"
	].includes(e.kind) && !e.name.trim() && (e.kind === "event" ? Dt(e.data.summary).trim() || r("data.summary", "名称または要約を入力してください。") : r("name", "名称を入力してください。")), e.visibility === "projection" && !e.projectionProfileId && r("projectionProfileId", "公開投影の対象プロファイルを指定してください。"), e.deletedAt && !e.deletionOperationId && r("deletionOperationId", "削除には削除操作IDが必要です。"), !e.deletedAt && e.deletionOperationId && r("deletionOperationId", "削除されていない情報に削除操作IDは保存できません。");
	for (let t of Object.keys(e.customValues)) {
		let n = dn[e.kind];
		(Object.hasOwn(Dn, t) || n.type === "object" && Object.hasOwn(n.fields, t)) && r(`customValues.${t}`, "標準項目とカスタム項目のキーが衝突しています。");
	}
	switch (e.kind) {
		case "event":
			for (let [t, n] of (e.data.constraints ?? []).entries()) n.type === "end_gap" && T(n.minimumTicks, n.maximumTicks) > 0 && r(`data.constraints[${t}]`, "日時差の最小値は最大値以下です。");
			break;
		case "item":
			e.data.itemMode === "instance" && !e.data.typeId && r("data.typeId", "物品の個体には種類への参照が必要です。");
			break;
		case "flow_node":
			e.data.nodeType === "terminal" && !e.data.terminalReason?.trim() && r("data.terminalReason", "意図した終端には終了理由が必要です。"), e.data.nodeType === "call" && !e.data.childGraphId && r("data.childGraphId", "呼出ノードには子分岐図が必要です。");
			break;
		case "variable": {
			let i = e.data;
			i.scope === "character" && !i.ownerId && r("data.ownerId", "人物scopeには所有人物が必要です。"), i.valueType === "integer" ? (i.allowed.values && r("data.allowed.values", "整数には集合ではなくmin/maxを指定してください。"), (i.allowed.min ?? -2147483647) > (i.allowed.max ?? 2147483647) && r("data.allowed", "整数の最小値は最大値以下です。")) : ((i.allowed.min != null || i.allowed.max != null) && r("data.allowed", "この型に数値範囲は設定できません。"), i.valueType === "enum" && (!i.allowed.values?.length || i.allowed.values.some((e) => typeof e != "string" || !e)) && r("data.allowed.values", "enumには空でない文字列の候補集合が必要です。"), i.valueType === "boolean" && i.allowed.values?.some((e) => typeof e != "boolean") && r("data.allowed.values", "booleanの候補は真偽値です。")), n.push(...Y(e, i.initial, `${t}.data.initial`));
			for (let [r, a] of (i.resetRules ?? []).entries()) n.push(...Y(e, a.value, `${t}.data.resetRules[${r}].value`));
			new Set((i.resetRules ?? []).map((e) => e.on)).size !== (i.resetRules ?? []).length && r("data.resetRules", "同じ終了時点の初期化規則は一つにしてください。");
			for (let [a, o] of (i.transitionRules ?? []).entries()) n.push(...Y(e, o.from, `${t}.data.transitionRules[${a}].from`, !1), ...Y(e, o.to, `${t}.data.transitionRules[${a}].to`, !1)), o.exception && !o.reason?.trim() && r(`data.transitionRules[${a}].reason`, "例外遷移には理由が必要です。");
			for (let [a, o] of (i.exclusions ?? []).entries()) n.push(...Y(e, o.value, `${t}.data.exclusions[${a}].value`, !1)), o.reason.trim() || r(`data.exclusions[${a}].reason`, "相互排他には理由が必要です。");
			break;
		}
		case "effect":
			[
				"set",
				"add",
				"move"
			].includes(e.data.operation) && (!e.data.value || e.data.value.type === "unknown") && r("data.value", "この効果には既知の入力値が必要です。"), e.data.operation === "add" && e.data.value?.type !== "integer" && r("data.value", "addはinteger値だけを使えます。"), e.data.operation === "move" && e.data.value?.type !== "ref" && r("data.value", "moveには所在・所有先のref値が必要です。"), e.data.operation === "consume" && !e.data.reason?.trim() && r("data.reason", "消費・破壊には理由が必要です。"), ["grant", "consume"].includes(e.data.operation) && e.data.value != null && (e.data.value.type !== "integer" || e.data.value.value < 1) && r("data.value", "物品数量は正のintegerです。"), e.data.operation === "assert" && e.data.value != null && e.data.value.type !== "boolean" && r("data.value", "assertの真偽入力はbooleanです。");
			break;
		case "assertion":
			e.data.truthKind === "belief" && !e.data.holderId && r("data.holderId", "beliefには認識を持つ人物が必要です。"), e.data.truthKind === "testimony" && !e.data.sourceIds?.length && r("data.sourceIds", "testimonyには出所が必要です。");
			break;
		case "storyboard_frame":
			e.data.mediaEndMs != null && e.data.mediaEndMs < e.data.mediaStartMs && r("data.mediaEndMs", "演出の終了は開始以上です。");
			break;
		case "travel_route":
			(e.data.minimumTicks != null && w(e.data.minimumTicks) < 0n || e.data.maximumTicks != null && w(e.data.maximumTicks) < 0n) && r("data", "移動所要時間は0以上です。"), e.data.minimumTicks != null && e.data.maximumTicks != null && T(e.data.minimumTicks, e.data.maximumTicks) > 0 && r("data.maximumTicks", "最大所要時間は最小以上です。");
			break;
		case "collection":
			e.data.purpose === "regression" && e.data.mode !== "fixed" && r("data.mode", "回帰経路集合は宣言した固定経路の集合です。"), e.data.mode === "dynamic" && !e.data.query && r("data.query", "動的一覧には型付き検索条件が必要です。"), e.data.mode === "fixed" && !Array.isArray(e.data.memberIds) && r("data.memberIds", "固定一覧にはID配列が必要です。");
			break;
		case "template":
			n.push(...nt(e.data, `${t}.data`));
			break;
		case "production_task":
			if (e.data.deadline) try {
				new Intl.DateTimeFormat("ja", { timeZone: e.data.deadline.timeZone });
			} catch {
				r("data.deadline.timeZone", "有効なタイムゾーンを指定してください。");
			}
			if (e.data.estimate) {
				let t = e.data.estimate;
				t.value == null == (t.range == null) && r("data.estimate", "見積もりはvalueまたはrangeの一つです。"), t.range && t.range.min > t.range.max && r("data.estimate.range", "見積範囲が逆転しています。"), ["reading_minutes", "playing_minutes"].includes(t.unit) && !t.speed && r("data.estimate.speed", "本文量からの時間見積もりには速度が必要です。");
			}
			break;
		case "review": {
			let t = e.data.sharedSource;
			if (!t) break;
			try {
				let e = new URL(t.connection);
				(e.origin !== t.connection || e.username || e.password || !["https:", "http:"].includes(e.protocol) || e.protocol === "http:" && ![
					"localhost",
					"127.0.0.1",
					"[::1]"
				].includes(e.hostname)) && r("data.sharedSource.connection", "指摘の専用接続先のoriginを確認してください。");
			} catch {
				r("data.sharedSource.connection", "指摘の接続先が不正です。");
			}
			(!St.test(t.sharedSnapshot) || !St.test(t.comment) || !t.publicVersion || !/^([a-f0-9]{64})$/.test(t.projectionHash) || !/^([a-f0-9]{64})$/.test(t.commentBodyHash)) && r("data.sharedSource", "元の公開版・指摘・hashが不正です。"), (!!t.publicEntity == !!t.publicRelation || t.publicRelation && (t.publicBlock !== void 0 || t.startCp !== void 0 || t.endCp !== void 0) || t.publicBlock !== void 0 && (t.startCp === void 0 || t.endCp === void 0 || t.endCp <= t.startCp) || t.publicBlock === void 0 && (t.startCp !== void 0 || t.endCp !== void 0)) && r("data.sharedSource", "元指摘の対象とUnicode位置の組合せを確認してください。");
			break;
		}
		case "localization":
		case "recording": /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(e.data.language) || r("data.language", "言語コードを指定してください（例: ja、en-US）。");
	}
	zn(e.data, `${t}.data`, n);
}
function zn(e, t, n, r = 0) {
	if (r > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, i) => zn(e, `${t}[${i}]`, n, r + 1));
		return;
	}
	let i = e;
	if ("worldRange" in i && K(i.worldRange)) {
		let e = i.worldRange;
		Re(e.start) && Re(e.end) && T(e.start, e.end) >= 0 && q(n, `${t}.worldRange`, "有効期間はstart < endの半開区間です。");
	}
	"entityId" in i && typeof i.start == "number" && typeof i.end == "number" && i.start >= i.end && q(n, t, "位置の文字範囲はstart < endです。");
	for (let e of Object.keys(i)) {
		let a = i[e];
		a && typeof a == "object" && zn(a, `${t}.${e}`, n, r + 1);
	}
}
function Bn(e) {
	let t = [];
	return J(An(e.kind), e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function Vn(e) {
	let t = [];
	return J(On, e, "", [], t), t.map((e) => ({
		...e,
		path: e.path.replace(/^\./, "")
	}));
}
function Hn(e) {
	return e.replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
}
function Un(e, t, n) {
	let r = structuredClone(e), i = (e) => n instanceof Map ? n.get(e) : Object.hasOwn(n, e) ? n[e] : void 0, a = [...t].sort((e, t) => {
		let n = e.path.endsWith(".$key"), r = t.path.endsWith(".$key");
		return Number(n) - Number(r) || (n ? Hn(t.path).length - Hn(e.path).length : 0);
	});
	for (let e of a) {
		let t = i(e.id);
		if (!t) continue;
		let n = Hn(e.path), a = n.at(-1) === "$key";
		a && n.pop();
		let o = n.pop();
		if (!o) continue;
		let s = r;
		for (let e of n) s = s[e];
		if (a) {
			if (t === o) continue;
			if (Object.hasOwn(s, t)) throw Error("REFERENCE_INVALID: 参照の統合で辞書キーが衝突します。保持する内容を選んでください。");
			s[t] = s[o], delete s[o];
		} else s[o] = t;
	}
	return r;
}
function Wn(e, t) {
	let n = Un(e, Bn(e), t), r = (e) => (t instanceof Map ? t.get(e) : t[e]) ?? e;
	return (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings && (n.kind === "scene" || n.kind === "flow_node") && n.data.reuse && (n.data.reuse.bindings = Object.fromEntries(Object.entries(e.data.reuse.bindings).map(([e, t]) => [r(e), r(t)]))), n;
}
function Gn(e, t) {
	return Un(e, Vn(e), t);
}
var Kn = B({
	projectId: V(M),
	immutableSnapshotId: V(M),
	contentHash: V({ type: "hash" })
}), qn = B({
	id: V(M),
	name: V(O(1, 128)),
	view: V(O(1)),
	entityIds: V(z()),
	settings: V(W(zt(O(), A(), j, F(null)), Pt))
}), Jn = {
	projectId: V(M),
	name: V(O(1, 128)),
	formatVersion: V(F(Pe)),
	revision: V({ type: "revision" }),
	calendarId: V(O(1)),
	mainStart: V(N),
	worldReferences: V(R(Kn))
}, Yn = [
	...Object.keys(Jn),
	"calendars",
	"entities",
	"relations",
	"views"
], Xn = [...Yn, "authorAlternatives"], Zn = R({ type: "json" }, !1, 0, 100);
function Qn(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set([e.projectId]), o = /* @__PURE__ */ new Set();
	e.worldReferences.forEach((e, t) => {
		i.has(e.projectId) && q(r, `${n}.worldReferences[${t}]`, "同じ世界の複数の版を同時に参照すると、IDの参照先が曖昧になります。一つの固定版を選んでください。", "REFERENCE_INVALID"), i.add(e.projectId);
	});
	let s = [{
		content: e,
		location: n
	}, ...t.map((t) => ({
		content: t,
		location: `${n}.worldReferences[${e.worldReferences.findIndex((e) => e.projectId === t.projectId)}]`
	}))], c = /* @__PURE__ */ new Map();
	for (let [e, { content: t, location: n }] of s.entries()) {
		e > 0 && (a.has(t.projectId) && q(r, n, "同じ作品・世界の複数の内容が現在の参照範囲に含まれています。固定版を一つにしてください。", "REFERENCE_INVALID"), a.add(t.projectId));
		for (let [e, i] of t.calendars.entries()) {
			let t = c.get(i.id);
			t && !Ye(t, i) && q(r, `${n}.calendars[${e}].id`, "同じ暦IDに異なる定義があります。固定版の日時を読み替えず、暦IDを明示して対応付けてください。", "REFERENCE_INVALID"), c.set(i.id, i);
		}
		for (let [e, i] of [["entities", t.entities], ["relations", t.relations]]) i.forEach((i, a) => {
			let s = `${n}.${e}[${a}]`;
			o.has(i.id) && q(r, `${s}.id`, "現在の作品と参照中の共通世界でentity・relationのIDが衝突しています。曖昧な参照は保存できません。", "REFERENCE_INVALID"), o.add(i.id), i.projectId !== t.projectId && q(r, `${s}.projectId`, "参照範囲のレコードが所属する作品・世界と一致しません。", "REFERENCE_INVALID");
		});
	}
}
function $n(e, t, n, r, i = /* @__PURE__ */ new Map(), a, o) {
	let s = [];
	if (!K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: t,
			message: "作品はオブジェクトです。"
		}]
	};
	for (let n of Object.keys(e)) Yn.includes(n) || q(s, `${t}.${n}`, "作品に未知の項目があります。");
	let c = Object.fromEntries(Object.keys(Jn).filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]]));
	J(B(Jn), c, t, s, []), e.formatVersion !== "1.0.0" && q(s, `${t}.formatVersion`, "対応していない形式版です。", "FORMAT_UNSUPPORTED");
	for (let n of [
		"entities",
		"relations",
		"calendars",
		"views"
	]) Array.isArray(e[n]) || q(s, `${t}.${n}`, "必須の配列です。");
	if (s.length) return {
		ok: !1,
		issues: s
	};
	let l = e.entities, u = e.relations, d = e.calendars;
	if (l.length + u.length > 1e5) return {
		ok: !1,
		issues: [{
			code: "IMPORT_LIMIT",
			path: t,
			message: "entityとrelationの合計は100,000件までです。"
		}]
	};
	if (o?.has(e, r, i)) return {
		ok: !0,
		value: e
	};
	if (!a) {
		let t = o?.previousContent(e, r, i);
		t && (a = {
			previous: t,
			references: /* @__PURE__ */ new WeakMap()
		});
	}
	let f = new Map(a?.previous.entities.map((e) => [e.id, e])), p = new Map(a?.previous.relations.map((e) => [e.id, e])), m = /* @__PURE__ */ new WeakMap(), h = /* @__PURE__ */ new WeakMap(), g = (e, t) => e.map((e) => ({
		...e,
		path: e.path.slice(t.length + 1)
	}));
	l.forEach((e, n) => {
		let r = K(e) ? o?.entityReferences(e) : void 0;
		if (r) {
			m.set(e, r);
			return;
		}
		if (a && K(e) && f.get(e.id) === e) return;
		let i = `${t}.entities[${n}]`, c = [], l = Ln(e, i, c);
		if (!l.ok) s.push(...l.issues);
		else {
			let e = g(c, i);
			m.set(l.value, e), o?.rememberEntity(l.value, e);
		}
	}), u.forEach((e, n) => {
		let r = K(e) ? o?.relationReferences(e) : void 0;
		if (r) {
			h.set(e, r);
			return;
		}
		if (a && K(e) && Object.is(p.get(e.id), e)) return;
		let i = `${t}.relations[${n}]`, c = [], l = jn(On, e, i, c);
		if (!l.ok) s.push(...l.issues);
		else {
			let e = g(c, i);
			h.set(l.value, e), o?.rememberRelation(l.value, e);
		}
	}), d.forEach((e, n) => {
		let r = Ve(e, `${t}.calendars[${n}]`);
		r.ok || s.push(...r.issues);
	});
	let _ = [];
	if (J(R(qn), e.views, `${t}.views`, s, _), s.length) return {
		ok: !1,
		issues: s.slice(0, 256)
	};
	let v = e, y = [...i].map(([e, t]) => ({
		id: e,
		content: t,
		contentHash: "",
		createdAt: "",
		versionLabel: ""
	}));
	if (s.push(...Ne(v, y, t)), s.length) return {
		ok: !1,
		issues: s.slice(0, 256)
	};
	let b = v.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) ? Ae(v, y) : v, ee = new Set(b.worldReferences.map((e) => e.projectId)), te = n.worldSnapshots ? me(b, n.worldSnapshots) : void 0;
	if (te) for (let e of te.errors) q(s, `${t}.worldReferences`, e, "REFERENCE_INVALID");
	let ne = te?.worlds ?? (n.worlds ?? []).filter((e) => ee.has(e.projectId));
	if (l.length + u.length + ne.reduce((e, t) => e + t.entities.length + t.relations.length, 0) > 1e5 && q(s, t, "参照世界を含むレコード数が100,000件を超えています。", "IMPORT_LIMIT"), Qn(v, ne, t, s), b !== v && Qn(b, ne, `${t}.reuse`, s), s.length) return {
		ok: !1,
		issues: s.slice(0, 256)
	};
	let x = [...b.entities, ...ne.flatMap((e) => e.entities)], re = new Map(x.map((e) => [e.id, e])), ie = new Map([...v.relations, ...ne.flatMap((e) => e.relations)].map((e) => [e.id, e])), ae = new Set([...v.calendars, ...ne.flatMap((e) => e.calendars)].map((e) => e.id)), oe = /* @__PURE__ */ new Set();
	for (let [e, n] of [["entities", v.entities], ["relations", v.relations]]) n.forEach((n, r) => {
		oe.has(n.id) && q(s, `${t}.${e}[${r}].id`, "entityとrelationのIDは作品内で一意です。"), oe.add(n.id), n.projectId !== v.projectId && q(s, `${t}.${e}[${r}].projectId`, "レコードが別の作品に属しています。", "REFERENCE_INVALID");
	});
	let se = v.calendars.map((e) => e.id);
	new Set(se).size !== se.length && q(s, `${t}.calendars`, "暦IDが重複しています。"), se.includes(v.calendarId) || q(s, `${t}.calendarId`, "作品の暦が定義されていません。", "REFERENCE_INVALID");
	let ce = v.worldReferences.map((e) => `${e.projectId}/${e.immutableSnapshotId}`);
	(new Set(ce).size !== ce.length || v.worldReferences.some((e) => e.projectId === v.projectId)) && q(s, `${t}.worldReferences`, "共通世界参照の重複または自己参照があります。");
	let le = /* @__PURE__ */ new Map(), ue = /* @__PURE__ */ new Map();
	for (let e of x) tr(e.data, e.id, le, ue, s, `${t}.entities.${e.id}.data`, 0, o);
	let de = /* @__PURE__ */ new Set([
		...re.keys(),
		...ie.keys(),
		...le.keys()
	]);
	for (let e of x) if (e.kind === "flow_node" && e.data.trigger?.id && de.add(e.data.trigger.id), e.kind === "projection_profile") {
		for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) K(t) && typeof t.id == "string" && de.add(t.id);
	}
	let fe = ne.flatMap((e) => [...e.entities.flatMap(Bn), ...e.relations.flatMap(Vn)]).filter((e) => e.scope === "snapshot" && n.worldSnapshots?.[e.id] && ne.some((t) => t.projectId === n.worldSnapshots?.[e.id].projectId)).map((e) => e.id), pe = /* @__PURE__ */ new Set([
		...r,
		...fe,
		v.projectId,
		...x.filter((e) => e.kind === "snapshot").map((e) => e.id),
		...(te?.references ?? b.worldReferences).map((e) => e.immutableSnapshotId)
	]), he = {
		entities: re,
		relations: ie,
		blocks: le,
		calendars: ae,
		projects: /* @__PURE__ */ new Set([v.projectId, ...(te?.references ?? b.worldReferences).map((e) => e.projectId)]),
		projectionIds: de
	}, S = /* @__PURE__ */ new Map();
	function ge(e) {
		if (e === v.projectId && !v.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings)) return he;
		let r = S.get(e);
		if (r) return r;
		let a = e === v.projectId ? v : i.get(e) ?? n.worldSnapshots?.[e];
		if (!a) return;
		let c = a;
		try {
			c.entities.some((e) => (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse?.bindings) && (c = Ae(c, y));
		} catch {
			return;
		}
		let l = n.worldSnapshots ? me(c, n.worldSnapshots) : void 0;
		if (l) for (let n of l.errors) q(s, `${t}.versions.${e}.worldReferences`, n, "REFERENCE_INVALID");
		let u = l?.worlds ?? (n.worlds ?? []).filter((e) => c.worldReferences.some((t) => t.projectId === e.projectId)), d = s.length;
		if (Qn(c, u, `${t}.versions.${e}`, s), s.length !== d) return;
		let f = [...c.entities, ...u.flatMap((e) => e.entities)], p = /* @__PURE__ */ new Map();
		for (let e of f) K(e) && tr(e.data, e.id, p, /* @__PURE__ */ new Map(), [], "version", 0, o);
		let m = /* @__PURE__ */ new Set([
			...f.map((e) => e.id),
			...c.relations.map((e) => e.id),
			...u.flatMap((e) => e.relations.map((e) => e.id)),
			...p.keys()
		]);
		for (let e of f) if (e.kind === "flow_node" && e.data.trigger?.id && m.add(e.data.trigger.id), e.kind === "projection_profile") {
			for (let t of Object.values(e.data.publicTexts ?? {})) for (let e of Object.values(t)) if (Array.isArray(e)) for (let t of e) K(t) && typeof t.id == "string" && m.add(t.id);
		}
		let h = {
			entities: new Map(f.filter((e) => K(e)).map((e) => [e.id, e])),
			relations: new Map([...c.relations, ...u.flatMap((e) => e.relations)].filter((e) => K(e)).map((e) => [e.id, e])),
			blocks: p,
			calendars: new Set([...c.calendars, ...u.flatMap((e) => e.calendars)].map((e) => e.id)),
			projects: /* @__PURE__ */ new Set([c.projectId, ...u.map((e) => e.projectId)]),
			projectionIds: m
		};
		return S.set(e, h), h;
	}
	function _e(e, t = "", r = he) {
		let i = t ? `${t}.${e.path}` : e.path, a = !0;
		if (e.scope === "entity") {
			let t = r.entities.get(e.id);
			a = !!t, t && e.kinds && !e.kinds.includes(t.kind) && q(s, i, `参照先の種類は${e.kinds.map((e) => _t[e]).join(" / ")}です。`, "REFERENCE_INVALID"), t && n.runtime && t.deletedAt && q(s, i, "削除済み情報は実行用出力で参照できません。", "REFERENCE_INVALID");
		} else e.scope === "relation" ? a = r.relations.has(e.id) : e.scope === "record" ? a = r.entities.has(e.id) || r.relations.has(e.id) : e.scope === "projection_record" ? a = r.projectionIds.has(e.id) : e.scope === "presentation" ? a = r.entities.has(e.id) || r.blocks.has(e.id) : e.scope === "calendar" ? a = r.calendars.has(e.id) : e.scope === "project" ? a = r.projects.has(e.id) : e.scope === "snapshot" ? a = pe.has(e.id) : e.scope === "block" ? a = r.blocks.has(e.id) : e.scope === "alias" && (a = ue.has(e.id));
		a || q(s, i, "参照先が存在しないか、指定した作品・共通世界の範囲外です。", "REFERENCE_INVALID");
	}
	let ve = (e) => {
		let t = m.get(e);
		if (t) return t;
		if (!a || f.get(e.id) !== e) return Bn(e);
		let n = a.references.get(e);
		if (n) return n;
		let r = Bn(e);
		return a.references.set(e, r), r;
	};
	v.entities.forEach((e, n) => {
		let r = `${t}.entities[${n}]`;
		for (let t of ve(e)) {
			let n = Hn(t.path), i = n.slice(0, -1).reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e), a = (e.kind === "scene" || e.kind === "flow_node") && e.data.reuse && t.path === "data.reuse.sourceId" ? e.data.reuse.pinnedSnapshotId : void 0, o = e.kind === "projection_profile" && e.data.sourceVersionId && /^data\.(?:includedIds|publicTexts|blockSources|publicIds|publicValues|namePolicy|allowedRelationIds|approvedAttachmentIds)(?:\.|\[)/.test(t.path) ? e.data.sourceVersionId : void 0, c = (e.kind === "note" && t.path === "data.handoffReceipt.profileId" ? e.data.handoffReceipt?.profileVersionId : void 0) ?? a ?? (K(i) && typeof i.entityId == "string" && typeof i.sourceVersionId == "string" ? i.sourceVersionId : e.kind === "review" && t.path.startsWith("data.target.") ? e.data.targetVersionId : o);
			if (e.kind === "projection_profile" && t.scope === "projection_record" && t.path.endsWith(".$key") && Object.values(e.data.publicTexts ?? {}).some((e) => Object.values(e).some((e) => Array.isArray(e) && e.some((e) => e.id === t.id)))) {
				_e(t, r);
				continue;
			}
			let l = e.kind === "checkpoint" && (t.path.startsWith("data.runtimeState.") || t.path.startsWith("data.presentationState.") || t.path.startsWith("data.presentationResults[")) || e.kind === "trace" && (t.path.startsWith("data.steps[") || t.path.startsWith("data.initialExternalValues.") || t.path.startsWith("data.initialStubValues.") || t.path.startsWith("data.initialStubBaseState.") || t.path.startsWith("data.readingPath."));
			if (c || l && (e.kind === "checkpoint" || e.kind === "trace")) {
				let i = ge(c ?? (e.kind === "checkpoint" || e.kind === "trace" ? e.data.contentVersionId : v.projectId));
				if (!i) {
					q(s, c ? e.kind === "review" ? `${r}.data.targetVersionId` : `${r}.${n.slice(0, -1).join(".")}.sourceVersionId` : `${r}.data.contentVersionId`, "参照する固定版の本文がありません。", "REFERENCE_INVALID");
					continue;
				}
				_e(t, r, i);
			} else _e(t, r);
		}
	}), v.relations.forEach((e, n) => (h.get(e) ?? Vn(e)).forEach((e) => _e(e, `${t}.relations[${n}]`))), _.forEach((e) => _e(e));
	let ye = n.relationTypes ?? bt;
	v.relations.forEach((e, n) => {
		let r = `${t}.relations[${n}]`, i = ye.find((t) => t.key === e.relationType), a = re.get(e.fromId), o = re.get(e.toId);
		i ? (a && !i.fromKinds.includes(a.kind) && q(s, `${r}.fromId`, "この関係で許されない始点種類です。", "REFERENCE_INVALID"), o && !i.toKinds.includes(o.kind) && q(s, `${r}.toId`, "この関係で許されない終点種類です。", "REFERENCE_INVALID"), e.fromId === e.toId && !i.allowSelf && q(s, r, "この関係は自己関係を許しません。"), e.direction === "symmetric" && !i.allowSymmetric && q(s, `${r}.direction`, "この関係は対称ではありません。")) : q(s, `${r}.relationType`, "関係の種類が辞書に定義されていません。"), e.deletedAt && !e.deletionOperationId && q(s, `${r}.deletionOperationId`, "削除には操作IDが必要です。"), zn(e.validity, `${r}.validity`, s);
	});
	let be;
	if (a && JSON.stringify(v.worldReferences) === JSON.stringify(a.previous.worldReferences) && JSON.stringify(v.calendars) === JSON.stringify(a.previous.calendars)) {
		be = /* @__PURE__ */ new Set([...v.entities.filter((e) => f.get(e.id) !== e).map((e) => e.id), ...v.relations.filter((e) => p.get(e.id) !== e).map((e) => e.id)]);
		for (let e of f.keys()) re.has(e) || be.add(e);
		for (let e of p.keys()) ie.has(e) || be.add(e);
	}
	return rr(v, re, ue, pe, le, s, t, n, ge, be && !s.length ? (e) => f.get(e.id) !== e || ve(e).some((e) => be.has(e.id)) : void 0), s.length || o?.remember(v, r, i), s.length ? {
		ok: !1,
		issues: s.slice(0, 256)
	} : {
		ok: !0,
		value: v
	};
}
function er(e) {
	return e === "runtimeState" || e === "before" || e === "after" || e === "publicTexts";
}
function tr(e, t, n, r, i, a, o = 0, s) {
	if (o > 32 || !e || typeof e != "object") return;
	if (!s) {
		if (Array.isArray(e)) {
			e.forEach((e, s) => tr(e, t, n, r, i, `${a}[${s}]`, o + 1));
			return;
		}
		let s = e;
		typeof s.id == "string" && typeof s.text == "string" && [
			"paragraph",
			"heading",
			"list_item",
			"quote"
		].includes(s.kind) && (n.has(s.id) && q(i, `${a}.id`, "本文ブロックIDが重複しています。"), n.set(s.id, {
			entityId: t,
			text: s.text
		})), typeof s.id == "string" && "isPublicDefault" in s && (r.has(s.id) && q(i, `${a}.id`, "別名IDが重複しています。"), r.set(s.id, {
			entityId: t,
			alias: s
		}));
		for (let e of Object.keys(s)) {
			if (er(e)) continue;
			let c = s[e];
			c && typeof c == "object" && tr(c, t, n, r, i, `${a}.${e}`, o + 1);
		}
		return;
	}
	let c = o === 0 ? s?.contentIds(e) : void 0;
	if (!c) {
		c = [];
		let t = (e, n, r) => {
			if (r > 32 || !e || typeof e != "object") return;
			if (Array.isArray(e)) {
				e.forEach((e, i) => t(e, `${n}[${i}]`, r + 1));
				return;
			}
			let i = e;
			typeof i.id == "string" && typeof i.text == "string" && [
				"paragraph",
				"heading",
				"list_item",
				"quote"
			].includes(i.kind) && c.push({
				kind: "block",
				id: i.id,
				text: i.text,
				path: n
			}), typeof i.id == "string" && "isPublicDefault" in i && c.push({
				kind: "alias",
				id: i.id,
				alias: i,
				path: n
			});
			for (let e of Object.keys(i)) {
				if (er(e)) continue;
				let a = i[e];
				a && typeof a == "object" && t(a, `${n}.${e}`, r + 1);
			}
		};
		t(e, "", o), o === 0 && s?.rememberContentIds(e, c);
	}
	for (let e of c) {
		let o = a + e.path;
		e.kind === "block" ? (n.has(e.id) && q(i, `${o}.id`, "本文ブロックIDが重複しています。"), n.set(e.id, {
			entityId: t,
			text: e.text
		})) : (r.has(e.id) && q(i, `${o}.id`, "別名IDが重複しています。"), r.set(e.id, {
			entityId: t,
			alias: e.alias
		}));
	}
}
function nr(e, t, n, r, i) {
	let a = new Map(e.map((e) => [e.id, e])), o = /* @__PURE__ */ new Map();
	for (let s of e) {
		if (o.get(s.id)) continue;
		let e = [{
			id: s.id,
			ids: t(s),
			cursor: 0
		}];
		for (o.set(s.id, 1); e.length;) {
			let s = e[e.length - 1];
			if (s.cursor >= s.ids.length) {
				o.set(s.id, 2), e.pop();
				continue;
			}
			let c = s.ids[s.cursor++], l = a.get(c);
			if (l) {
				if (o.get(c) === 1) {
					q(n, `${r}.entities.${s.id}.data`, `${i}に循環があります。`);
					continue;
				}
				o.get(c) || (o.set(c, 1), e.push({
					id: c,
					ids: t(l),
					cursor: 0
				}));
			}
		}
	}
}
function rr(e, t, n, r, i, a, o, s, c, l) {
	let u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set();
	e.entities.some((e) => !!e.templateId && !e.deletedAt) && a.push(...rt(e, o, [...t.values()])), e.entities.forEach((e, f) => {
		let p = `${o}.entities[${f}]`;
		if (!e.deletedAt) {
			if (e.kind === "variable" || e.kind === "quest" || e.kind === "external_contract") {
				let t = `${e.kind}/${e.kind === "variable" ? `${e.data.scope}/${e.data.ownerId ?? ""}/` : ""}${e.data.key}`;
				u.has(t) && q(a, `${p}.data.key`, "同じスコープでキーが重複しています。"), u.set(t, e.id);
			}
			if (e.kind === "localization") {
				let t = `${e.data.sourceLineId}/${e.data.language}/${e.data.sourceHash}`;
				d.has(t) && q(a, p, "同じ台詞・言語・原文版の翻訳が重複しています。"), d.add(t);
			}
			if (!l || l(e) || e.kind === "checkpoint" || e.kind === "trace") {
				if (e.kind === "template" && a.push(...nt(e.data, `${p}.data`, t)), e.kind === "item" && e.data.itemMode === "instance") {
					let n = e.data.typeId ? t.get(e.data.typeId) : void 0;
					n?.kind === "item" && n.data.itemMode !== "type" && q(a, `${p}.data.typeId`, "個体のtypeIdは物品種類を参照してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "quest") {
					let n = t.get(e.data.stateVariableId);
					if (n?.kind === "variable") for (let [t, r] of (e.data.transitionRules ?? []).entries()) a.push(...Y(n, r.from, `${p}.data.transitionRules[${t}].from`, !1), ...Y(n, r.to, `${p}.data.transitionRules[${t}].to`, !1));
				}
				if (e.kind === "variable") for (let [n, r] of (e.data.exclusions ?? []).entries()) {
					let e = t.get(r.variableId);
					e?.kind === "variable" && a.push(...Y(e, r.otherValue, `${p}.data.exclusions[${n}].otherValue`, !1));
				}
				if (e.kind === "collection" && e.data.purpose === "regression") for (let [n, r] of (e.data.memberIds ?? []).entries()) {
					let e = t.get(r);
					e && e.kind !== "trace" && q(a, `${p}.data.memberIds[${n}]`, "回帰経路集合には保存した試読記録を指定してください。", "REFERENCE_INVALID");
				}
				if (e.kind === "effect") {
					let n = t.get(e.data.targetId), r = e.data.operation;
					if (n && [
						"set",
						"add",
						"reset"
					].includes(r) && (n.kind === "variable" ? (n.data.derived && q(a, `${p}.data.targetId`, "算出状態へ直接代入できません。"), r === "add" && n.data.valueType !== "integer" && q(a, `${p}.data.targetId`, "addはinteger状態だけです。"), e.data.value && r !== "add" && a.push(...Y(n, e.data.value, `${p}.data.value`))) : q(a, `${p}.data.targetId`, "状態更新効果は状態変数を参照してください。", "REFERENCE_INVALID")), n && [
						"grant",
						"consume",
						"move"
					].includes(r) && n.kind !== "item" && q(a, `${p}.data.targetId`, "物品効果は物品を参照してください。", "REFERENCE_INVALID"), n?.kind === "item" && [
						"grant",
						"consume",
						"move"
					].includes(r) && e.data.instanceId) {
						let r = t.get(e.data.instanceId);
						r?.kind === "item" && (r.data.itemMode !== "instance" || (n.data.itemMode === "type" ? r.data.typeId !== n.id : r.id !== n.id)) && q(a, `${p}.data.instanceId`, "指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
					}
					if (n && r === "assert" && n.kind !== "assertion" && q(a, `${p}.data.targetId`, "認識効果は事実・認識を参照してください。", "REFERENCE_INVALID"), r === "move" && e.data.value?.type === "ref") {
						let n = t.get(e.data.value.value);
						n && ![
							"character",
							"group",
							"place"
						].includes(n.kind) && q(a, `${p}.data.value`, "物品の移動先は人物・グループ・場所です。", "REFERENCE_INVALID");
					}
				}
				if (e.kind === "flow_graph") {
					for (let t of [...e.data.entryIds, ...e.data.exitIds]) e.data.nodeIds.includes(t) || q(a, `${p}.data`, "入口・出口はその分岐図のノード集合に含めてください。");
					for (let n of e.data.edgeIds) {
						let r = t.get(n);
						r?.kind === "flow_edge" && (!e.data.nodeIds.includes(r.data.fromId) || typeof r.data.toId == "string" && !e.data.nodeIds.includes(r.data.toId)) && q(a, `${p}.data.edgeIds`, "進行線の始点・終点は同じ分岐図内に置いてください。");
					}
					let n = (e.data.parameters ?? []).map((e) => e.key);
					new Set(n).size !== n.length && q(a, `${p}.data.parameters`, "引数のキーが重複しています。");
				}
				if (e.kind === "flow_edge" && s.runtime && typeof e.data.toId != "string" && q(a, `${p}.data.toId`, "未完成の分岐先は実行用出力できません。", "EXPORT_UNSUPPORTED"), e.kind === "variable" && s.runtime && e.data.initial.type === "unknown" && !e.data.derived && q(a, `${p}.data.initial`, "初期値が未定です。", "CONDITION_UNKNOWN"), ar(e.data, p, t, a), e.kind === "review" && typeof e.data.target == "object" ? (or(e.data.target, `${p}.data.target`, t, i, a, 0, c, e.data.targetVersionId), or({
					...e.data,
					target: null
				}, `${p}.data`, t, i, a, 0, c)) : or(e.data, `${p}.data`, t, i, a, 0, c), e.kind === "projection_profile") {
					let t = e.data.namePolicy;
					if ("mode" in t && t.mode === "alias") {
						let r = n.get(t.aliasId);
						r && !e.data.includedIds.includes(r.entityId) && q(a, `${p}.data.namePolicy`, "別名は投影対象の本体に属している必要があります。");
					} else if (!("mode" in t)) for (let [e, r] of Object.entries(t.byEntityId ?? {})) r.mode === "alias" && n.get(r.aliasId)?.entityId !== e && q(a, `${p}.data.namePolicy.byEntityId.${e}`, "別名が指定した本体に属していません。");
				}
				if (e.kind === "checkpoint" && (!r.has(e.data.runtimeState.contentVersionId) || e.data.runtimeState.contentVersionId !== e.data.contentVersionId) && q(a, `${p}.data.runtimeState.contentVersionId`, "途中開始の状態と対象版が一致しません。"), e.kind === "checkpoint") {
					let t = Pn(e.data.runtimeState, `${p}.data.runtimeState`);
					if (t.ok || a.push(...t.issues), e.data.presentationState && (e.data.presentationState.contentVersionId !== e.data.contentVersionId || e.data.presentationState.presentationPosition !== e.data.runtimeState.presentationPosition || e.data.presentationState.provenance !== e.data.runtimeState.provenance) && q(a, `${p}.data.presentationState`, "提示前の観測状態と開始点・対象版・由来が一致しません。"), e.data.presentationResults != null) {
						let t = c(e.data.contentVersionId);
						t && a.push(...Fn({
							...e.data.runtimeState,
							provenance: e.data.origin ?? "partial"
						}, e.data.presentationResults, [...t.entities.values()], `${p}.data.presentationResults`));
					}
				}
				if (e.kind === "trace") {
					let t = e.data;
					t.initialStubBaseState && !t.initialStubValues && q(a, `${p}.data.initialStubBaseState`, "stub前の個別状態には初期stub入力の記録が必要です。"), t.mode === "chapters" ? ((t.initialStubValues || t.initialStubBaseState) && q(a, `${p}.data.initialStubValues`, "章経路の個別開始はcheckpointへ、外部仮値はinitialExternalValuesへ記録してください。"), t.readingPath || q(a, `${p}.data.readingPath`, "章読み通しには提示経路が必要です。"), t.steps.length && q(a, `${p}.data.steps`, "章読み通しとフロー遷移を混在させられません。")) : t.readingPath != null && q(a, `${p}.data.readingPath`, "提示経路はmode:chaptersの記録に指定してください。"), t.steps.forEach((e, n) => {
						for (let [t, r] of [["before", e.before], ["after", e.after]]) {
							let e = Pn(r, `${p}.data.steps[${n}].${t}`);
							e.ok || a.push(...e.issues);
						}
						e.presentationState && (e.presentationState.contentVersionId !== t.contentVersionId || e.presentationState.presentationPosition !== e.after.presentationPosition || e.presentationState.provenance !== e.after.provenance) && q(a, `${p}.data.steps[${n}].presentationState`, "提示前の観測状態と提示先・対象版・由来が一致しません。");
					}), t.readingPath?.occurrences.forEach((e, t) => {
						for (let [n, r] of [["before", e.before], ["after", e.after]]) {
							let e = Pn(r, `${p}.data.readingPath.occurrences[${t}].${n}`);
							e.ok || a.push(...e.issues);
						}
					});
				}
			}
		}
	});
	for (let t of [
		"place",
		"group",
		"flow_graph",
		"map"
	]) nr(e.entities.filter((e) => e.kind === t && !e.deletedAt), (e) => e.kind === "place" || e.kind === "group" ? e.data.parentId ? [e.data.parentId] : [] : e.kind === "flow_graph" ? e.data.parentGraphId ? [e.data.parentGraphId] : [] : e.kind === "map" && e.data.parentMapId ? [e.data.parentMapId] : [], a, o, `${_t[t]}の階層`);
	nr(e.entities.filter((e) => e.kind === "production_task" && !e.deletedAt), (e) => e.kind === "production_task" ? e.data.dependsOn ?? [] : [], a, o, "制作依存"), nr(e.entities.filter((e) => e.kind === "variable" && !e.deletedAt), (e) => e.kind === "variable" && e.data.derived ? ir(e.data.derived) : [], a, o, "算出状態"), nr(e.entities.filter((e) => e.kind === "flow_graph" && !e.deletedAt), (e) => e.kind === "flow_graph" ? e.data.nodeIds.flatMap((e) => {
		let n = t.get(e);
		return n?.kind === "flow_node" && n.data.childGraphId ? [n.data.childGraphId] : [];
	}) : [], a, o, "分岐図の呼出階層"), a.push(...Je([...t.values()].filter((e) => e.kind === "event" && !e.deletedAt)));
	let f = /* @__PURE__ */ new Map();
	for (let t of e.entities) if (t.kind === "flow_edge" && t.data.edgeType === "automatic" && !t.deletedAt) {
		let e = `${t.data.fromId}/${t.data.priority ?? 0}`;
		f.has(e) && q(a, `${o}.entities.${t.id}.data.priority`, "同じ始点の自動候補で優先順位が重複しています。"), f.set(e, t.id);
	}
}
function ir(e) {
	let t = [];
	return J({ type: "expression" }, e, "", [], t), t.filter((e) => e.kinds?.includes("variable")).map((e) => e.id);
}
function ar(e, t, n, r, i = 0) {
	if (i > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, a) => ar(e, `${t}[${a}]`, n, r, i + 1));
		return;
	}
	let a = e;
	if (a.op === "compare") {
		let e = n.get(a.variableId);
		if (e?.kind === "variable") {
			let n = a.comparator, i = Array.isArray(a.value) ? a.value : [a.value];
			[
				"lt",
				"le",
				"gt",
				"ge"
			].includes(n) && e.data.valueType !== "integer" && q(r, `${t}.comparator`, "順序比較はintegerにだけ使えます。"), i.forEach((n, a) => {
				n.type !== "unknown" && n.type !== e.data.valueType && q(r, `${t}.value${i.length > 1 ? `[${a}]` : ""}`, "比較値の型が状態変数と一致しません。");
			});
		}
	}
	for (let e of Object.keys(a)) {
		let o = a[e];
		o && typeof o == "object" && ar(o, `${t}.${e}`, n, r, i + 1);
	}
}
function or(e, t, n, r, i, a = 0, o, s) {
	if (a > 32 || !e || typeof e != "object") return;
	if (Array.isArray(e)) {
		e.forEach((e, c) => or(e, `${t}[${c}]`, n, r, i, a + 1, o, s));
		return;
	}
	let c = e;
	if (typeof c.entityId == "string") {
		c.positionStatus === "unresolved" && (!c.positionReason || c.start != null || c.end != null) && q(i, t, "位置不明には理由を付け、確定した文字範囲を外してください。"), c.positionStatus !== "unresolved" && (c.positionReason != null || c.quotedText != null) && q(i, t, "位置不明の理由・引用は位置不明状態と一緒に保存してください。");
		let e = typeof c.sourceVersionId == "string" ? c.sourceVersionId : s, a = e && o ? o(e) : void 0, l = a?.entities ?? n, u = a?.blocks ?? r, d;
		if (typeof c.blockId == "string") {
			let e = u.get(c.blockId);
			e && e.entityId !== c.entityId && q(i, `${t}.blockId`, "段落は指定した情報に属していません。", "REFERENCE_INVALID"), d = e?.text;
		}
		if (typeof c.lineId == "string") {
			let e = l.get(c.lineId);
			e?.kind === "dialogue_line" && (d = Dt(e.data.text));
		}
		(typeof c.start == "number" || typeof c.end == "number") && ((typeof c.start != "number" || typeof c.end != "number") && q(i, t, "文字範囲はstart/endを対で指定してください。"), d === void 0 ? q(i, t, "文字範囲には本文ブロックまたは台詞への参照が必要です。") : typeof c.end == "number" && c.end > pn(d) && q(i, `${t}.end`, "文字範囲が参照元の本文を超えています。"));
	}
	for (let e of Object.keys(c)) {
		let s = c[e];
		s && typeof s == "object" && ![
			"publicTexts",
			"before",
			"after",
			"runtimeState"
		].includes(e) && or(s, `${t}.${e}`, n, r, i, a + 1, o);
	}
}
function sr(e, t = {}) {
	if (!K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	let n = cr() === void 0 ? void 0 : gt(e, t, bt), r = n?.memo;
	return t = n?.options ?? t, ur(e, t, r);
}
function cr() {
	let e = /* @__PURE__ */ new Map(), t = /* @__PURE__ */ new Set(), n = [], r = (i, a) => {
		if (a > 128) throw Error("Unsupported schema depth");
		if (i === void 0) return ["undefined"];
		if (typeof i == "string" && !x(i) || typeof i == "number" && !Number.isFinite(i)) throw Error("Unsupported schema scalar");
		if (i === null || [
			"string",
			"boolean",
			"number"
		].includes(typeof i)) return ["value", i];
		if (typeof i != "object" || t.has(i)) throw Error("Unsupported schema value");
		let o = i, s = e.get(o);
		if (s !== void 0) return ["reference", s];
		let c = Array.isArray(o), l = Object.getPrototypeOf(o);
		if (c ? l !== Array.prototype : l !== Object.prototype && l !== null) throw Error("Unsupported schema prototype");
		let u = Reflect.ownKeys(o);
		if (u.some((e) => typeof e != "string" || !x(e) || [
			"__proto__",
			"constructor",
			"prototype"
		].includes(e))) throw Error("Unsupported schema key");
		if (c && (u.length !== o.length + 1 || u.some((e) => e !== "length" && (!/^(0|[1-9]\d*)$/.test(String(e)) || Number(e) >= o.length)))) throw Error("Unsupported schema array");
		let d = n.length, f = [];
		e.set(o, d), t.add(o), n.push([c ? "array" : "object", f]);
		for (let e of u.sort()) {
			if (c && e === "length") continue;
			let t = Object.getOwnPropertyDescriptor(o, e);
			if (!t?.enumerable || !Object.hasOwn(t, "value")) throw Error("Unsupported schema descriptor");
			f.push([e, r(t.value, a + 1)]);
		}
		return t.delete(o), ["reference", d];
	};
	try {
		let e = r({
			schemas: dn,
			kinds: D,
			statuses: vt,
			scopes: yt
		}, 0);
		return JSON.stringify({
			root: e,
			nodes: n
		});
	} catch {
		return;
	}
}
function lr(e = {}) {
	let t = ht(e);
	if (!t.captured) return (t) => sr(t, e);
	let n = ht({
		...t.value,
		relationTypes: t.value.relationTypes ?? bt
	});
	if (!n.captured) return (t) => sr(t, e);
	let r, i;
	return (e) => {
		let t = cr();
		if (t === void 0) return sr(e, n.value);
		t !== i && (r = void 0, i = t);
		let a = ht(e);
		return !a.captured || !ft(a.value) ? sr(e, n.value) : (r ??= gt(a.value, n.value, bt), ur(a.value, r?.options ?? n.value, r?.memo));
	};
}
function ur(e, t, n) {
	if (l("validate.full.calls"), !K(e)) return {
		ok: !1,
		issues: [{
			code: "VALIDATION_FAILED",
			path: "project",
			message: "作品はオブジェクトです。"
		}]
	};
	let r = [];
	for (let t of Object.keys(e)) [
		...Xn,
		"snapshots",
		"history"
	].includes(t) || q(r, `project.${t}`, "作品に未知の項目があります。");
	Array.isArray(e.snapshots) || q(r, "project.snapshots", "必須の配列です。"), Array.isArray(e.history) || q(r, "project.history", "必須の配列です。");
	let i = new Set((Array.isArray(e.snapshots) ? e.snapshots : []).flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : []));
	Object.hasOwn(e, "authorAlternatives") && J(Zn, e.authorAlternatives, "project.authorAlternatives", r, []);
	let a = $n(Object.fromEntries(Yn.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, i, pr(e.snapshots), void 0, n);
	if (a.ok || r.push(...a.issues), r.length) return {
		ok: !1,
		issues: r.slice(0, 256)
	};
	let o = e;
	fr(o.snapshots, "project.snapshots", o.projectId, t, r, n);
	let s = /* @__PURE__ */ new Set();
	return o.history.forEach((e, i) => {
		let a = `project.history[${i}]`, c = e;
		if (!K(c)) {
			q(r, a, "履歴はコマンドです。");
			return;
		}
		let l = B({
			operationId: V(M),
			projectId: V(M),
			baseRevision: V({ type: "revision" }),
			revision: V({ type: "revision" }),
			targetIds: V(R(M, !0)),
			reason: V(O()),
			createdAt: V({ type: "datetime" }),
			compensatesOperationId: H(M),
			idMap: H(W(M, M)),
			importOrigin: H(B({
				sourceProjectId: V(M),
				sourceOperationId: V(M),
				importOperationId: V(M)
			}))
		});
		for (let e of Object.keys(c)) e !== "before" && e !== "after" && l.type === "object" && !Object.hasOwn(l.fields, e) && q(r, `${a}.${e}`, "コマンドに未知の項目があります。");
		J(l, Object.fromEntries(Object.entries(c).filter(([e]) => e !== "before" && e !== "after")), a, r, []), s.has(e.operationId) && q(r, `${a}.operationId`, "履歴の操作IDが重複しています。"), s.add(e.operationId), e.projectId !== o.projectId && q(r, `${a}.projectId`, "履歴が別の作品に属しています。");
		for (let e of ["before", "after"]) {
			if (!K(c[e])) {
				q(r, `${a}.${e}`, "変更前後の内容を保持してください。");
				continue;
			}
			let i = c[e];
			Array.isArray(i.snapshots) || q(r, `${a}.${e}.snapshots`, "復元に必要な公開版配列が必要です。"), Object.hasOwn(i, "authorAlternatives") && J(Zn, i.authorAlternatives, `${a}.${e}.authorAlternatives`, r, []);
			let s = Object.fromEntries(Object.entries(i).filter(([e]) => e !== "snapshots" && e !== "authorAlternatives")), l = new Set((Array.isArray(i.snapshots) ? i.snapshots : []).flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : [])), u = $n(s, `${a}.${e}`, t, l, pr(i.snapshots), void 0, n);
			u.ok ? u.value.projectId !== o.projectId && q(r, `${a}.${e}.projectId`, "履歴の内容が別の作品に属しています。") : r.push(...u.issues), Array.isArray(i.snapshots) && fr(i.snapshots, `${a}.${e}.snapshots`, o.projectId, t, r, n);
		}
	}), r.length ? {
		ok: !1,
		issues: r.slice(0, 256)
	} : {
		ok: !0,
		value: o
	};
}
function dr(e, t = {}, n) {
	l("validate.current.calls");
	let r = [];
	for (let t of Object.keys(e)) [
		...Xn,
		"snapshots",
		"history"
	].includes(t) || q(r, `project.${t}`, "作品に未知の項目があります。");
	if ((!Array.isArray(e.snapshots) || !Array.isArray(e.history)) && q(r, "project", "公開版と履歴の配列が必要です。"), Object.hasOwn(e, "authorAlternatives") && J(Zn, e.authorAlternatives, "project.authorAlternatives", r, []), r.length) return {
		ok: !1,
		issues: r
	};
	let i = new Set(e.snapshots.map((e) => e.id)), a = $n(Object.fromEntries(Yn.filter((t) => Object.hasOwn(e, t)).map((t) => [t, e[t]])), "project", t, i, pr(e.snapshots), n);
	return a.ok ? {
		ok: !0,
		value: e
	} : a;
}
function fr(e, t, n, r, i, a) {
	let o = new Set(e.flatMap((e) => K(e) && typeof e.id == "string" ? [e.id] : [])), s = /* @__PURE__ */ new Set(), c = pr(e);
	e.forEach((e, l) => {
		let u = `${t}[${l}]`;
		if (!K(e)) {
			q(i, u, "公開版はオブジェクトです。");
			return;
		}
		let d = B({
			id: V(M),
			versionLabel: V(O(1, 128)),
			contentHash: V({ type: "hash" }),
			createdAt: V({ type: "datetime" })
		});
		for (let t of Object.keys(e)) [
			"id",
			"versionLabel",
			"contentHash",
			"createdAt",
			"content"
		].includes(t) || q(i, `${u}.${t}`, "公開版に未知の項目があります。");
		J(d, Object.fromEntries(Object.entries(e).filter(([e]) => e !== "content")), u, i, []), typeof e.id == "string" && (s.has(e.id) && q(i, `${u}.id`, "公開版のIDが重複しています。"), s.add(e.id), e.id === n && q(i, `${u}.id`, "公開版IDは作品IDと別にしてください。"));
		let f = $n(e.content, `${u}.content`, r, o, c, void 0, a);
		f.ok ? f.value.projectId !== n && q(i, `${u}.content.projectId`, "公開版が別の作品に属しています。") : i.push(...f.issues);
	});
}
function pr(e) {
	return Array.isArray(e) ? new Map(e.flatMap((e) => K(e) && typeof e.id == "string" && K(e.content) && [
		"entities",
		"relations",
		"calendars",
		"worldReferences"
	].every((t) => Array.isArray(e.content[t]) && e.content[t].every(K)) ? [[e.id, e.content]] : [])) : /* @__PURE__ */ new Map();
}
//#endregion
//#region src/domain/stateRules.ts
function mr(e, t) {
	let n = t.ruleContext;
	if (!n) return {
		value: "unknown",
		reasons: ["対象作品・章・経路の実行情報がありません。"]
	};
	if (e.projectId !== n.projectId || e.targetSnapshotId && ![
		n.projectId,
		t.state.contentVersionId,
		n.sourceVersionId
	].includes(e.targetSnapshotId)) return {
		value: "false",
		reasons: ["対象作品版の範囲外です。"]
	};
	if (e.graphId && n.graphId && e.graphId !== n.graphId || e.chapterId && n.chapterId && e.chapterId !== n.chapterId) return {
		value: "false",
		reasons: ["対象グラフまたは章の範囲外です。"]
	};
	let r = Cr(e.routeCondition, t);
	return r.value === "false" ? r : e.graphId && !n.graphId || e.chapterId && !n.chapterId ? {
		value: "unknown",
		reasons: ["対象グラフまたは章を確認できません。", ...r.reasons]
	} : r;
}
function hr(e, t) {
	let n = (e, t) => ({
		value: e,
		reasons: [t]
	});
	if (!e.reason.trim() || !e.evidenceIds.length) return n("false", "例外には理由と根拠が必要です。");
	let r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (e.evidenceIds.some((e) => !r.some((t) => t.id === e && !t.deletedAt && t.status === "confirmed"))) return n("unknown", "例外の根拠が存在しないか、採用確定していません。");
	let i = mr(e.targetScope, t);
	if (i.value !== "true") return i;
	let a = e.validity.worldRange, o = t.ruleContext?.worldTick;
	if (!a || a.end === null) return n("unknown", "例外の有効期限を指定してください。");
	if (!Re(o)) return n("unknown", "例外の期限を評価する現在の世界時点がありません。");
	if (a.start !== null && T(o, a.start) < 0 || T(o, a.end) >= 0) return n("false", "例外の有効期間外です。");
	let s = Cr(e.validity.routeCondition, t);
	if (s.value !== "true") return s;
	let c = e.validity.presentationAnchor, l = t.ruleContext?.anchorBindings, u = c && l && c.sourceVersionId === t.ruleContext?.sourceVersionId ? {
		...c,
		entityId: l[c.entityId] ?? c.entityId,
		...c.blockId ? { blockId: l[c.blockId] ?? c.blockId } : {},
		...c.lineId ? { lineId: l[c.lineId] ?? c.lineId } : {}
	} : c;
	return u && (u.positionStatus === "unresolved" || u.sourceVersionId && ![
		t.ruleContext.projectId,
		t.state.contentVersionId,
		t.ruleContext.sourceVersionId
	].includes(u.sourceVersionId)) ? n("unknown", "例外の提示位置または版を確認できません。") : u && ![
		u.entityId,
		u.blockId,
		u.lineId
	].filter(Boolean).every((e) => t.state.seenIds.includes(e)) ? n("false", "例外の提示位置に到達していません。") : {
		value: "true",
		reasons: []
	};
}
function gr(e, t) {
	if (!e.data.holderId) return;
	if (typeof e.data.value != "string" && e.data.value.type === "unknown") return {
		code: "CONDITION_UNKNOWN",
		message: "人物が取得する認識の内容が未確定です。"
	};
	let n = e.data.sourceIds ?? [], r = [...t.entities ?? [], ...t.referenceEntities ?? []];
	if (!n.length || n.some((e) => !r.some((t) => t.id === e && S(t)))) return {
		code: "REFERENCE_INVALID",
		message: "人物の認識取得には採用中の出所が必要です。"
	};
	let i = e.data.validity, a = e.data.evidenceLocation ?? i?.presentationAnchor, o = t.ruleContexts?.[e.id] ?? t.ruleContext, s = o?.anchorBindings, c = a && s && a.sourceVersionId === o?.sourceVersionId ? {
		...a,
		entityId: s[a.entityId] ?? a.entityId,
		...a.blockId ? { blockId: s[a.blockId] ?? a.blockId } : {},
		...a.lineId ? { lineId: s[a.lineId] ?? a.lineId } : {}
	} : a, l = i?.worldRange;
	if (!c && (!l || l.start === null)) return {
		code: "CONDITION_UNKNOWN",
		message: "人物の認識取得には本文位置または世界内の取得時点が必要です。"
	};
	if (c) {
		if (c.positionStatus === "unresolved" || c.sourceVersionId && ![
			o?.projectId,
			o?.sourceVersionId,
			t.state.contentVersionId
		].includes(c.sourceVersionId)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置または固定版が未確認です。"
		};
		if (![
			c.entityId,
			c.blockId,
			c.lineId
		].filter(Boolean).every((e) => t.state.seenIds.includes(e))) return {
			code: "CONDITION_UNKNOWN",
			message: "認識を取得する本文位置へ到達していません。"
		};
		let e = t.currentPresentation;
		if (e) {
			let t = c.entityId === e.anchor.entityId && c.blockId === e.anchor.blockId && c.lineId === e.anchor.lineId && c.start === e.anchor.start, n = ii(e.project, c, e.anchor, e.target);
			if (!t && n !== !0) return {
				code: n === !1 ? "TRANSITION_BLOCKED" : "CONDITION_UNKNOWN",
				message: "認識取得の位置が、この効果の提示位置より後か、順序を確認できません。"
			};
		}
	}
	if (l) {
		if (!Re(o?.worldTick)) return {
			code: "CONDITION_UNKNOWN",
			message: "認識の取得時点を照合する世界内tickが未入力です。"
		};
		if (l.start !== null && T(o.worldTick, l.start) < 0 || l.end !== null && T(o.worldTick, l.end) >= 0) return {
			code: "TRANSITION_BLOCKED",
			message: "認識の取得時点が宣言した有効期間外です。"
		};
	}
	let u = Cr(i?.routeCondition, {
		...t,
		ruleContext: o
	});
	if (u.value !== "true") return {
		code: u.value === "unknown" ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED",
		message: "認識を取得する経路条件が成立していません。"
	};
}
//#endregion
//#region src/domain/conditions.ts
var X = class extends Error {
	issues;
	constructor(e) {
		super(e.map((e) => e.message).join("、")), this.name = "DomainValidationError", this.issues = e;
	}
}, Z = (e, t = "condition", n = "VALIDATION_FAILED") => ({
	code: n,
	path: t,
	message: e
}), _r = (e) => ({
	type: "unknown",
	value: null,
	reason: e
}), Q = (e, t = []) => ({
	value: e,
	reasons: [...new Set(t)]
}), vr = (e) => [...e.entities ?? [], ...e.referenceEntities ?? []].filter(S), yr = (e) => (e.variables ?? [...e.entities ?? [], ...e.referenceEntities ?? []].filter((e) => e.kind === "variable")).filter(S);
function br(e, t, n) {
	let r = yr(t).find((t) => t.id === e);
	if (!r) {
		if (t.variables || t.entities) return _r("状態変数が定義されていません。");
		let n = t.state.variableValues[e];
		if (!n) return _r("状態変数の値がありません。");
		let r = Nn(n);
		if (!r.ok) throw new X(r.issues);
		return n;
	}
	if (r.data.derived) {
		if (n.includes(e)) throw new X([Z("算出状態の参照が循環しています。", `variables.${e}.derived`)]);
		let i = wr(r.data.derived, t, [...n, e]), a = Y(r, i, `variables.${e}.derived`);
		if (a.length) throw new X(a);
		return i;
	}
	if (r.data.externalContractId) {
		let e = t.externalValues?.[r.data.externalContractId];
		if (!e) return _r("宣言した外部値をまだ取得していません。");
		let n = Nn(e);
		if (!n.ok) throw new X(n.issues);
		let i = Y(r, e);
		if (i.length) throw new X(i);
		return e;
	}
	let i = t.state.variableValues[e];
	if (!i) return _r("状態変数の値がありません。");
	let a = Nn(i);
	if (!a.ok) throw new X(a.issues);
	let o = Y(r, i);
	if (o.length) throw new X(o);
	return i;
}
function xr(e, t, n) {
	if (e.type === "unknown" || t.type === "unknown") return Q("unknown", [e.type === "unknown" ? e.reason : "", t.type === "unknown" ? t.reason : ""].filter(Boolean));
	if (e.type !== t.type) throw new X([Z("比較する値の型が一致しません。")]);
	if (![
		"eq",
		"ne",
		"lt",
		"le",
		"gt",
		"ge"
	].includes(n)) throw new X([Z("未知の比較演算です。")]);
	if (n === "eq" || n === "ne") return Q((n === "eq" ? e.value === t.value : e.value !== t.value) ? "true" : "false");
	if (e.type !== "integer" || t.type !== "integer") throw new X([Z("順序比較はintegerにだけ使えます。")]);
	return Q((n === "lt" ? e.value < t.value : n === "le" ? e.value <= t.value : n === "gt" ? e.value > t.value : e.value >= t.value) ? "true" : "false");
}
function Sr(e, t, n) {
	switch (e.op) {
		case "constant": return Q(e.value ? "true" : "false");
		case "all":
		case "any": {
			let r = e.children.map((e) => Sr(e, t, n)), i = r.flatMap((e) => e.reasons);
			return e.op === "all" ? Q(r.some((e) => e.value === "false") ? "false" : r.every((e) => e.value === "true") ? "true" : "unknown", i) : Q(r.some((e) => e.value === "true") ? "true" : r.every((e) => e.value === "false") ? "false" : "unknown", i);
		}
		case "not": {
			let r = Sr(e.child, t, n);
			return Q(r.value === "unknown" ? "unknown" : r.value === "true" ? "false" : "true", r.reasons);
		}
		case "compare": {
			let r = br(e.variableId, t, n);
			if (e.comparator !== "in") return xr(r, e.value, e.comparator);
			let i = e.value.map((e) => xr(r, e, "eq"));
			return Q(i.some((e) => e.value === "true") ? "true" : i.some((e) => e.value === "unknown") ? "unknown" : "false", i.flatMap((e) => e.reasons));
		}
		case "item": return t.entities && !vr(t).some((t) => t.id === e.itemId && t.kind === "item") ? Q("unknown", ["指定した物品が定義されていません。"]) : Q(t.state.itemInstances.filter((t) => !t.consumed && (t.instanceId === e.itemId || t.typeId === e.itemId)).reduce((e, t) => e + t.quantity, 0) >= e.quantity ? "true" : "false");
		case "known": {
			if (t.entities && (!vr(t).some((t) => t.id === e.assertionId && t.kind === "assertion") || !vr(t).some((t) => t.id === e.holderId && t.kind === "character"))) return Q("unknown", ["認識の対象または人物が定義されていません。"]);
			let n = t.state.assertions.find((t) => t.assertionId === e.assertionId && t.holderId === e.holderId);
			return n ? Q(n.truth, n.truth === "unknown" ? ["人物の認識が未確定です。"] : []) : Q("false");
		}
		case "visited": return t.entities && !vr(t).some((t) => t.id === e.entityId) ? Q("unknown", ["訪問先が定義されていません。"]) : Q((t.state.visitCounts[e.entityId] ?? 0) >= e.count ? "true" : "false");
		case "external": {
			if (t.entities && !vr(t).some((t) => t.id === e.contractId && t.kind === "external_contract")) return Q("unknown", ["外部契約が定義されていません。"]);
			let n = t.externalValues?.[e.contractId];
			if (!n) return Q("unknown", ["外部値をまだ取得していません。"]);
			let r = Nn(n);
			if (!r.ok) throw new X(r.issues);
			if (n.type === "unknown") return Q("unknown", [n.reason]);
			if (n.type !== "boolean") throw new X([Z("外部条件はbooleanの結果が必要です。")]);
			return Q(n.value ? "true" : "false");
		}
	}
}
function Cr(e, t) {
	let n = Mn(e ?? {
		op: "constant",
		value: !0
	});
	if (!n.ok) throw new X(n.issues);
	return Sr(n.value, t, []);
}
function wr(e, t, n) {
	switch (e.op) {
		case "value": return e.value;
		case "variable": return br(e.variableId, t, n);
		case "if": {
			let r = Sr(e.condition, t, n);
			return r.value === "unknown" ? _r(r.reasons.join("、") || "分岐条件が未定です。") : wr(r.value === "true" ? e.then : e.else, t, n);
		}
		case "add":
		case "subtract":
		case "multiply": {
			let r = wr(e.left, t, n), i = wr(e.right, t, n);
			if (r.type === "unknown" || i.type === "unknown") return _r([r.type === "unknown" ? r.reason : "", i.type === "unknown" ? i.reason : ""].filter(Boolean).join("、"));
			if (r.type !== "integer" || i.type !== "integer") throw new X([Z("算術の入力はintegerです。", "expression")]);
			let a = e.op === "add" ? r.value + i.value : e.op === "subtract" ? r.value - i.value : r.value * i.value;
			if (!Number.isSafeInteger(a)) throw new X([Z("算術結果が安全な整数の範囲を超えています。", "expression")]);
			return {
				type: "integer",
				value: a
			};
		}
		default: {
			let r = Sr(e, t, n);
			return r.value === "unknown" ? _r(r.reasons.join("、")) : {
				type: "boolean",
				value: r.value === "true"
			};
		}
	}
}
function Tr(e, t = e.projectId, n = [], r = {}) {
	let i = Nt(t), a = [...e.entities, ...n].filter((e) => e.kind === "variable" && S(e));
	for (let e of a) i.variableValues[e.id] = structuredClone(e.data.initial);
	for (let t of a) (t.data.derived || t.data.externalContractId && r[t.data.externalContractId]) && (i.variableValues[t.id] = br(t.id, {
		state: i,
		variables: a,
		entities: e.entities,
		referenceEntities: n,
		externalValues: r
	}, []));
	return i;
}
function Er(e) {
	let t = [];
	for (let n of yr(e)) for (let [r, i] of (n.data.exclusions ?? []).entries()) {
		let a = Cr({
			op: "all",
			children: [{
				op: "compare",
				variableId: n.id,
				comparator: "eq",
				value: i.value
			}, {
				op: "compare",
				variableId: i.variableId,
				comparator: "eq",
				value: i.otherValue
			}]
		}, e);
		if (a.value === "false") continue;
		let o = (i.exceptions ?? []).map((t) => hr(t, {
			...e,
			ruleContext: e.ruleContexts?.[n.id] ?? e.ruleContext
		}));
		if (a.value === "true" && o.some((e) => e.value === "true")) continue;
		let s = a.value === "unknown" || o.some((e) => e.value === "unknown");
		t.push(Z(s ? `相互排他を評価できません。${i.reason}` : `相互排他に反する状態です。${i.reason}`, `${n.id}.exclusions[${r}]`, s ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED"));
	}
	return t;
}
function Dr(e, t) {
	return e.type === t.type && e.value === t.value;
}
function Or(e, t, n, r, i) {
	if (r.operation === "reset" || Dr(t, n)) return;
	let a = vr(i).filter((t) => t.kind === "quest" && t.data.stateVariableId === e.id), o = [...(e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})), ...a.flatMap((e) => (e.data.transitionRules ?? []).map((t) => ({
		rule: t,
		ownerId: e.id
	})))];
	if (!o.length && !a.length) return;
	if (t.type === "unknown") throw new X([Z("遷移前の状態が未定です。", `variables.${e.id}`, "CONDITION_UNKNOWN")]);
	let s = o.filter(({ rule: e }) => Dr(e.from, t) && Dr(e.to, n));
	if (s.some(({ rule: e }) => !e.exception && !e.exceptionDetails)) return;
	let c = [...s.flatMap(({ rule: e, ownerId: t }) => e.exceptionDetails ? [hr(e.exceptionDetails, {
		...i,
		ruleContext: i.ruleContexts?.[t] ?? i.ruleContext
	})] : []), ...r.exceptionDetails ? [hr(r.exceptionDetails, i)] : []];
	if (!c.some((e) => e.value === "true")) throw new X([Z(c.flatMap((e) => e.reasons).join("、") || "許容遷移表にない状態更新です。明示resetまたは対象・期限・根拠付きの例外が必要です。", `variables.${e.id}`, c.some((e) => e.value === "unknown") ? "CONDITION_UNKNOWN" : "TRANSITION_BLOCKED")]);
}
function kr(e, t, n) {
	return e.itemInstances.filter((e) => n ? e.instanceId === n : e.instanceId === t || e.typeId === t);
}
function Ar(e, t, n, r) {
	let i = yr(n), a = [...n.entities ?? [], ...n.referenceEntities ?? []].find((e) => e.id === t.targetId && S(e)), o = (e, n = "TRANSITION_BLOCKED") => {
		throw new X([Z(e, `effects.${r ?? t.targetId}`, n)]);
	};
	if ([
		"set",
		"add",
		"reset"
	].includes(t.operation)) {
		let a = i.find((e) => e.id === t.targetId);
		a || o("更新先の状態変数がありません。", "REFERENCE_INVALID"), a.data.derived && o("算出状態へ直接代入できません。", "VALIDATION_FAILED");
		let s = br(a.id, {
			...n,
			state: e
		}, []), c = t.operation === "reset" ? structuredClone(t.value ?? a.data.initial) : t.value;
		c || o("状態更新の入力値がありません。", "VALIDATION_FAILED"), t.operation === "add" && (s.type === "unknown" && o(s.reason || "加算元の状態が未定です。", "CONDITION_UNKNOWN"), (s.type !== "integer" || c.type !== "integer" || a.data.valueType !== "integer") && o("addはinteger状態とinteger入力だけを使えます。", "VALIDATION_FAILED"), c = {
			type: "integer",
			value: s.value + c.value
		});
		let l = Y(a, c, `effects.${r ?? t.targetId}.value`, t.operation === "reset");
		if (l.length) throw new X(l.map((e) => ({
			...e,
			code: e.code === "CONDITION_UNKNOWN" ? e.code : "TRANSITION_BLOCKED"
		})));
		Or(a, s, c, t, n), e.variableValues[a.id] = structuredClone(c);
		return;
	}
	if (t.operation === "mark_seen") {
		n.entities && !a && o("既読対象が定義されていません。", "REFERENCE_INVALID"), e.seenIds.includes(t.targetId) || e.seenIds.push(t.targetId);
		return;
	}
	if (t.operation === "assert") {
		(!a || a.kind !== "assertion") && o("認識効果の対象には事実・認識が必要です。", "REFERENCE_INVALID"), t.value && t.value.type !== "boolean" && o("認識効果の入力はbooleanです。", "VALIDATION_FAILED");
		let i = t.value?.type === "boolean" && !t.value.value ? "false" : "true", s = a.data.holderId ?? null;
		if (i === "true") {
			let e = gr(a, n);
			e && o(e.message, e.code);
		}
		let c = e.assertions.find((e) => e.assertionId === a.id && e.holderId === s);
		c ? (c.truth = i, r && (c.sourceEffectId = r)) : e.assertions.push({
			assertionId: a.id,
			holderId: s,
			truth: i,
			...r ? { sourceEffectId: r } : {}
		});
		return;
	}
	if ((!a || a.kind !== "item") && o("物品効果の対象には宣言済みの物品が必要です。", "REFERENCE_INVALID"), t.instanceId) {
		let e = vr(n).find((e) => e.id === t.instanceId);
		(!e || e.kind !== "item" || e.data.itemMode !== "instance") && o("指定した物品個体が定義されていません。", "REFERENCE_INVALID"), (a.data.itemMode === "type" && e.data.typeId !== a.id || a.data.itemMode === "instance" && e.id !== a.id) && o("指定した個体が効果の対象物品に属していません。", "REFERENCE_INVALID");
	}
	let s = t.value?.type === "integer" ? t.value.value : 1;
	if (t.operation === "grant") {
		t.value && t.value.type !== "integer" && o("取得数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(s) || s < 1) && o("取得数量は正の安全な整数です。", "VALIDATION_FAILED");
		let r = a.data.itemMode === "instance" ? a : t.instanceId ? vr(n).find((e) => e.id === t.instanceId && e.kind === "item" && e.data.itemMode === "instance") : void 0;
		if (t.instanceId && !r && o("指定した物品個体がありません。", "REFERENCE_INVALID"), r) {
			s !== 1 && o("物品個体の数量は1です。"), a.data.itemMode === "type" && r.data.typeId !== a.id && o("個体が指定した物品種類に属していません。", "REFERENCE_INVALID"), e.itemInstances.some((e) => e.instanceId === r.id) && o("同じ物品個体を二重取得・復活させられません。");
			let t = r.data.typeId;
			t || o("物品個体の種類が未定義です。", "REFERENCE_INVALID"), e.itemInstances.push({
				instanceId: r.id,
				typeId: t,
				quantity: 1,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		} else {
			let t = e.itemInstances.find((e) => e.instanceId === a.id && e.typeId === a.id);
			t ? (Number.isSafeInteger(t.quantity + s) || o("物品数量が安全な整数範囲を超えています。"), t.quantity += s, t.consumed = !1) : e.itemInstances.push({
				instanceId: a.id,
				typeId: a.id,
				quantity: s,
				ownerId: null,
				locationId: null,
				consumed: !1
			});
		}
		return;
	}
	let c = kr(e, t.targetId, t.instanceId).filter((e) => !e.consumed && e.quantity > 0);
	if (c.some((e) => a.data.itemMode === "type" ? e.typeId !== a.id : e.instanceId !== a.id || e.typeId !== a.data.typeId) && o("実行状態の個体と効果の対象物品が一致しません。", "REFERENCE_INVALID"), t.operation === "consume") {
		t.reason?.trim() || o("消費・破壊の理由を記録してください。", "VALIDATION_FAILED"), t.value && t.value.type !== "integer" && o("消費数量はintegerです。", "VALIDATION_FAILED"), (!Number.isSafeInteger(s) || s < 1 || c.reduce((e, t) => e + t.quantity, 0) < s) && o("物品が不足しています。");
		let e = s;
		for (let n of c) {
			let r = Math.min(n.quantity, e);
			if (n.quantity -= r, e -= r, n.reason = t.reason, n.consumed = n.quantity === 0, e === 0) break;
		}
		return;
	}
	if (t.operation === "move") {
		t.value?.type !== "ref" && o("移動先には人物・グループ・場所のrefが必要です。", "VALIDATION_FAILED");
		let e = vr(n).find((e) => e.id === t.value?.value);
		(!e || ![
			"character",
			"group",
			"place"
		].includes(e.kind)) && o("物品の移動先がありません。", "REFERENCE_INVALID"), c.length !== 1 && o("移動する現存物品を一個体に特定してください。");
		let r = c[0];
		r.ownerId = e.kind === "place" ? null : e.id, r.locationId = e.kind === "place" ? e.id : null;
		return;
	}
	o("未対応の物品操作です。", "VALIDATION_FAILED");
}
function jr(e, t, n = { state: e }) {
	let r = Pn(e);
	if (!r.ok) return {
		ok: !1,
		state: e,
		issues: r.issues
	};
	let i = structuredClone(e);
	try {
		for (let [e, n] of t.entries()) {
			if ("data" in n && !S(n)) throw new X([Z("削除・不採用・別案の効果は実行できません。", `effects[${e}]`, "REFERENCE_INVALID")]);
			let t = In("data" in n ? n.data : n, `effects[${e}]`);
			if (!t.ok) throw new X(t.issues);
		}
		for (let [e, r] of t.entries()) {
			let t = "data" in r ? r.data : r, a = "id" in r ? r.id : void 0, o = {
				...n,
				currentPresentation: n.effectPresentations?.[e] ?? n.currentPresentation,
				state: i,
				ruleContext: a && n.ruleContexts?.[a] || n.ruleContext
			}, s = Cr(t.condition, o);
			if (s.value === "unknown") throw new X([Z(s.reasons.join("、") || "効果の条件が未定です。", `effects[${e}].condition`, "CONDITION_UNKNOWN")]);
			s.value !== "false" && Ar(i, t, o, a);
		}
		let e = /* @__PURE__ */ new Set();
		for (let t of i.itemInstances) {
			if (e.has(t.instanceId) || t.ownerId && t.locationId || t.consumed && t.quantity !== 0 || !t.consumed && t.quantity < 1) throw new X([Z("物品の個体ID・所在・数量が不整合です。", "itemInstances", "TRANSITION_BLOCKED")]);
			e.add(t.instanceId);
		}
		for (let e of yr(n)) e.data.derived && (i.variableValues[e.id] = br(e.id, {
			...n,
			state: i
		}, []));
		let r = Er({
			...n,
			state: i
		});
		if (r.length) throw new X(r);
		return {
			ok: !0,
			state: i
		};
	} catch (t) {
		return {
			ok: !1,
			state: e,
			issues: t instanceof X ? t.issues : [Z(t instanceof Error ? t.message : "効果を適用できません。", "effects")]
		};
	}
}
function Mr(e, t, n) {
	if (!t.length) return {
		ok: !0,
		state: structuredClone(e)
	};
	let r = structuredClone(e), i = [], a = [];
	for (let e of t) for (let t of yr(n)) {
		if (t.data.derived || t.data.externalContractId) continue;
		let n = t.data.resetRules?.find((t) => t.on === e), o = e === "full_reset" || e === "new_loop" && [
			"scene",
			"chapter",
			"run"
		].includes(t.data.scope);
		if (!n && !o) continue;
		let s = n?.value ?? t.data.initial;
		i.push({
			operation: "reset",
			targetId: t.id,
			value: s
		}), a.push({
			variableId: t.id,
			on: e,
			before: structuredClone(r.variableValues[t.id] ?? {
				type: "unknown",
				value: null,
				reason: "途中開始時の値が未指定です。"
			}),
			after: structuredClone(s),
			reason: n?.reason || (n ? "宣言した初期化規則" : `有効範囲 ${t.data.scope} の初期化`)
		}), r.variableValues[t.id] = structuredClone(s);
	}
	let o = jr(e, i, n);
	return o.ok && t.length && (a.length || e.resetCauses) && (o.state.resetCauses = a), o;
}
//#endregion
//#region src/domain/writingWorkspace.ts
function Nr(e) {
	return {
		chapterOrder: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => e.id),
		chapters: e.entities.filter((e) => e.kind === "chapter" && !e.deletedAt).map((e) => ({
			id: e.id,
			sceneIds: [...e.data.sceneIds]
		})),
		scenes: e.entities.filter((e) => e.kind === "scene" && !e.deletedAt).map((e) => ({
			id: e.id,
			chapterId: e.data.chapterId ?? null
		}))
	};
}
function Pr(e) {
	let { history: t, snapshots: n, ...r } = e, i = structuredClone(r);
	return delete i.authorAlternatives, i;
}
function Fr(e) {
	let t = e.versions.find((t) => t.id === e.headVersionId);
	if (!t) throw Error("別案の現在版が見つかりません。");
	return structuredClone(t.content);
}
function Ir(e, t, n = "別案の編集", r = (/* @__PURE__ */ new Date()).toISOString(), i = globalThis.crypto.randomUUID(), a) {
	let o = Pr(t);
	if (o.projectId !== e.projectId) throw Error("別の作品の内容をこの別案へ保存できません。");
	if (!e.versions.some((t) => t.id === e.headVersionId)) throw Error("別案の現在版が見つかりません。");
	let s = {
		id: i,
		parentVersionId: e.headVersionId,
		label: n.trim() || "別案の編集",
		createdAt: r,
		content: o,
		...a ? { structurePlan: structuredClone(a) } : {}
	};
	return {
		...structuredClone(e),
		versions: [...e.versions, s],
		headVersionId: s.id,
		updatedAt: r
	};
}
function Lr(e, t) {
	return JSON.stringify(e) === JSON.stringify(t);
}
function Rr(e, t, n) {
	return [
		e,
		t ?? "",
		...n
	].map((e) => encodeURIComponent(e)).join(":");
}
function zr(e, t, n, r) {
	if (e === "presentation") return Nr(t);
	if (e === "project") return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, t);
	let i = (e === "entity" ? t.entities : t.relations).find((e) => e.id === n);
	if (i) return r.reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, i);
}
function Br(e, t, n, r, i, a, o, s) {
	if (Lr(a, s) || Lr(o, s)) return;
	let c = a === void 0 ? "add" : s === void 0 ? "remove" : "replace";
	e.push({
		key: Rr(t, n, r),
		scope: t,
		...n ? { itemId: n } : {},
		path: r,
		label: i,
		kind: c,
		baseValue: structuredClone(a),
		canonicalValue: structuredClone(o),
		alternativeValue: structuredClone(s),
		conflict: !Lr(o, a) && !Lr(o, s)
	});
}
function Vr(e) {
	return new Map(e.entities.map((e) => [e.id, e]));
}
function Hr(e, t) {
	if (t.projectId !== e.projectId) throw Error("別の作品とは比較できません。");
	let n = e.baseContent, r = Fr(e), i = Pr(t), a = [];
	for (let e of [
		"name",
		"calendarId",
		"mainStart",
		"calendars",
		"worldReferences"
	]) Br(a, "project", void 0, [e], {
		name: "作品名",
		calendarId: "標準暦",
		mainStart: "本編開始時点",
		calendars: "暦の定義",
		worldReferences: "参照する世界版"
	}[e], n[e], i[e], r[e]);
	let o = Vr(n), s = Vr(r), c = Vr(i), l = /* @__PURE__ */ new Set([
		"id",
		"projectId",
		"kind",
		"revision",
		"createdAt",
		"updatedAt"
	]);
	for (let e of /* @__PURE__ */ new Set([...o.keys(), ...s.keys()])) {
		let t = o.get(e), n = s.get(e), r = c.get(e);
		if (!t || !n) {
			Br(a, "entity", e, [], `${t?.name ?? n?.name ?? "情報"} · 情報全体`, t, r, n);
			continue;
		}
		let i = /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)]);
		for (let o of i) {
			if (l.has(o) || o === "data" || o === "customValues") continue;
			let i = t[o], s = n[o], c = r && r[o];
			Br(a, "entity", e, [o], `${n.name} · ${o}`, i, c, s);
		}
		let u = t.data, d = n.data, f = r?.data;
		for (let r of /* @__PURE__ */ new Set([...Object.keys(u), ...Object.keys(d)])) t.kind === "chapter" && r === "sceneIds" || t.kind === "scene" && r === "chapterId" || Br(a, "entity", e, ["data", r], `${n.name} · ${r}`, u[r], f?.[r], d[r]);
		let p = t.customValues, m = n.customValues, h = r?.customValues;
		for (let t of /* @__PURE__ */ new Set([...Object.keys(p), ...Object.keys(m)])) Br(a, "entity", e, ["customValues", t], `${n.name} · 独自項目 ${t}`, p[t], h?.[t], m[t]);
	}
	let u = new Map(n.relations.map((e) => [e.id, e])), d = new Map(r.relations.map((e) => [e.id, e])), f = new Map(i.relations.map((e) => [e.id, e]));
	for (let e of /* @__PURE__ */ new Set([...u.keys(), ...d.keys()])) {
		let t = u.get(e), n = d.get(e), r = f.get(e);
		if (!t || !n) {
			Br(a, "relation", e, [], "関係 · 全体", t, r, n);
			continue;
		}
		for (let i of /* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)])) {
			if ([
				"id",
				"projectId",
				"revision"
			].includes(i)) continue;
			let o = t[i], s = n[i], c = r && r[i];
			Br(a, "relation", e, [i], `関係 ${t.fromId.slice(-6)} → ${t.toId.slice(-6)} · ${i}`, o, c, s);
		}
	}
	let p = Nr(n), m = Nr(r), h = Nr(i);
	return !Lr(p, m) && !Lr(h, m) && a.push({
		key: Rr("presentation", void 0, ["all"]),
		scope: "presentation",
		path: ["all"],
		label: "章と場面の提示順",
		kind: "replace",
		baseValue: p,
		canonicalValue: h,
		alternativeValue: m,
		conflict: !Lr(h, p)
	}), a.sort((e, t) => e.label.localeCompare(t.label) || e.key.localeCompare(t.key));
}
function Ur(e, t, n) {
	let r = structuredClone(e), i = r;
	for (let e of t.slice(0, -1)) (!i[e] || typeof i[e] != "object") && (i[e] = {}), i = i[e];
	return t.length && (n === void 0 ? delete i[t[t.length - 1]] : i[t[t.length - 1]] = structuredClone(n)), r;
}
function Wr(e, t) {
	let n = structuredClone(e), r = new Map(n.entities.filter((e) => e.kind === "chapter").map((e) => [e.id, e]));
	for (let e of r.values()) e.data.sceneIds = t.chapters.find((t) => t.id === e.id)?.sceneIds.filter((e) => n.entities.some((t) => t.kind === "scene" && t.id === e)) ?? [];
	for (let e of n.entities) e.kind === "scene" && (e.data.chapterId = t.scenes.find((t) => t.id === e.id)?.chapterId ?? null);
	let i = t.chapterOrder.flatMap((e) => {
		let t = r.get(e);
		return t ? [t] : [];
	});
	return n.entities.flatMap((e, t) => e.kind === "chapter" && !e.deletedAt ? [t] : []).forEach((e, t) => {
		i[t] && (n.entities[e] = i[t]);
	}), n;
}
function Gr(e, t, n) {
	if (t.scope === "presentation") return Wr(e, n);
	if (t.scope === "project") return Ur(e, t.path, n);
	let r = t.scope === "entity" ? "entities" : "relations", i = [...e[r]], a = i.findIndex((e) => e.id === t.itemId);
	if (!t.path.length) n === void 0 ? a >= 0 && i.splice(a, 1) : a < 0 ? i.push(structuredClone(n)) : i[a] = structuredClone(n);
	else if (a >= 0) i[a] = Ur(i[a], t.path, n);
	else if (n !== void 0) throw Error(`差分の対象が見つかりません: ${t.itemId}`);
	return {
		...e,
		[r]: i
	};
}
function Kr(e, t, n, r, i = (/* @__PURE__ */ new Date()).toISOString(), a = globalThis.crypto.randomUUID()) {
	let o = Hr(t, e);
	if ([...r].some((e) => !o.some((t) => t.key === e))) throw Error("選択した差分は現在の別案・正本から確認できません。内容を比較し直してください。");
	let s = o.filter((e) => r.has(e.key));
	if (!s.length) throw Error("採用する変更を選んでください。");
	if (s.some((e) => e.conflict)) throw Error("分岐元の後に正本が更新された項目があります。競合を確認し、別案の最新内容へ取り込んでください。");
	let c = Pr(e), l = [];
	for (let e of [...s].sort((e, t) => +(e.scope === "presentation") - (t.scope === "presentation"))) {
		let t = zr(e.scope, c, e.itemId, e.path), n = e.alternativeValue;
		l.push({
			key: e.key,
			scope: e.scope,
			...e.itemId ? { itemId: e.itemId } : {},
			path: [...e.path],
			label: e.label,
			before: t === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(t)
			},
			after: n === void 0 ? { present: !1 } : {
				present: !0,
				value: structuredClone(n)
			}
		}), c = Gr(c, e, e.alternativeValue);
	}
	if (c.projectId !== e.projectId) throw Error("別案のprojectIdは変更できません。");
	let { history: u, ...d } = e;
	return {
		project: {
			...structuredClone(d),
			...c,
			snapshots: e.snapshots,
			history: e.history
		},
		receipt: {
			id: a,
			createdAt: i,
			alternativeVersionId: t.headVersionId,
			sourceSnapshotId: t.sourceSnapshotId ?? null,
			selectedChangeKeys: [...r].sort(),
			fromCanonicalRevision: e.revision,
			patches: l
		}
	};
}
//#endregion
//#region src/domain/runtimeVersions.ts
async function qr(e, t = e.projectId, n = {}, r) {
	let i = t === e.projectId ? e : e.snapshots.find((e) => e.id === t);
	if (!i) throw new X([{
		code: "REFERENCE_INVALID",
		path: "contentVersionId",
		message: "実行する固定版がありません。"
	}]);
	let a = n.worldSnapshots ? r?.stableRegistries.has(n.worldSnapshots) ? n.worldSnapshots : r ? pe(n.worldSnapshots, r) : structuredClone(n.worldSnapshots) : {}, o = n.worlds ? structuredClone(n.worlds) : void 0, s = {
		...n,
		worldSnapshots: a,
		worlds: o
	}, c = "content" in i, l = structuredClone(c ? i.content : i), u = c ? i.contentHash : void 0, d = "content" in i ? i.id : e.projectId, f = structuredClone(e.snapshots), { authorAlternatives: p, snapshots: m, history: h, ...g } = l, _ = {
		...g,
		snapshots: f,
		history: []
	};
	if (u && await ue(se(g)) !== u) throw new X([{
		code: "INTEGRITY_FAILED",
		path: `snapshots.${d}.contentHash`,
		message: "固定版の内容ハッシュが一致しません。実行を停止しました。"
	}]);
	let v = /* @__PURE__ */ new Set(), y = [_];
	for (let e = 0; e < y.length; e++) for (let t of y[e].entities) if ((t.kind === "scene" || t.kind === "flow_node") && t.data.reuse && t.data.reuse.mode !== "clone") {
		let e = t.data.reuse.pinnedSnapshotId;
		if (v.has(e)) continue;
		v.add(e);
		let n = f.find((t) => t.id === e);
		if (!n || await ue(se(n.content)) !== n.contentHash) throw new X([{
			code: "INTEGRITY_FAILED",
			path: `snapshots.${e}`,
			message: "共通元の固定版がないか、内容hashが一致しません。"
		}]);
		y.push({
			...n.content,
			snapshots: f,
			history: []
		});
	}
	let b = await he(Ae(_, f), a, "worldReferences", r);
	if (b.length) throw new X(b);
	let ee = sr(_, s);
	if (!ee.ok) throw new X(ee.issues);
	return _;
}
//#endregion
//#region src/domain/externalInputs.ts
function Jr(e, t, n, r = []) {
	let i = [], a = [...e.entities, ...r].filter(S);
	n && (n.mode !== "actual" || !/^[0-9a-f]{64}$/.test(n.receiptHash)) && i.push({
		code: "INTEGRITY_FAILED",
		path: "receiptHash",
		message: "実際の外部入力には検証済み受信記録のSHA-256が必要です。"
	});
	for (let [e, n] of Object.entries(t)) {
		let t = `externalValues.${e}`, r = a.find((t) => t.id === e && t.kind === "external_contract");
		if (!r) {
			i.push({
				code: "REFERENCE_INVALID",
				path: t,
				message: "入力先の外部契約が存在しないか、削除・不採用です。"
			});
			continue;
		}
		let o = Nn(n);
		if (!o.ok) {
			i.push(...o.issues.map((e) => ({
				...e,
				path: t
			})));
			continue;
		}
		if (n.type !== "unknown" && n.type !== r.data.outputType) {
			i.push({
				code: "VALIDATION_FAILED",
				path: t,
				message: "実際の外部値と契約の出力型が違います。"
			});
			continue;
		}
		n.type === "unknown" && r.data.missingPolicy === "block" && i.push({
			code: "CONDITION_UNKNOWN",
			path: t,
			message: n.reason || "この外部契約は未確認値で進められません。"
		});
		for (let r of a) r.kind === "variable" && r.data.externalContractId === e && i.push(...Y(r, n, t, !0));
	}
	return i;
}
structuredClone;
//#endregion
//#region src/domain/presentation.ts
var $ = (e, t, n = []) => [...e.entities, ...n].filter((e) => e.kind === t && S(e)), Yr = (e, t, n = "REFERENCE_INVALID") => ({
	ok: !1,
	issues: [{
		code: n,
		path: e,
		message: t
	}]
}), Xr = /* @__PURE__ */ new WeakMap();
function Zr(e) {
	let t = [e], n = /* @__PURE__ */ new WeakSet();
	for (; t.length;) {
		let e = t.pop();
		if (e && typeof e == "object" && !n.has(e)) {
			n.add(e);
			for (let n of Object.values(e)) t.push(n);
			Object.freeze(e);
		}
	}
	return e;
}
function Qr(e) {
	let t = structuredClone(e), n = Xr.get(e);
	return n && (Zr(t), Xr.set(t, new Map(n))), t;
}
async function $r(e, t, n) {
	let r = { worldReferences: structuredClone(e.worldReferences) }, i = n?.stableRegistries.has(t) ? t : n ? pe(t, n) : structuredClone(t), a = await he(r, i, "worldReferences", n);
	if (a.length) throw new X(a);
	let o = me(r, i), s = structuredClone(o.worlds.flatMap((e) => e.entities)), c = /* @__PURE__ */ new Map();
	for (let e of o.references) for (let t of i[e.immutableSnapshotId].entities) c.set(t.id, e.immutableSnapshotId);
	return Zr(s), Xr.set(s, c), s;
}
function ei(e, t, n, r, i) {
	if (!n.sourceVersionId) return "match";
	if (r.referenceEntities?.some((e) => e.id === n.entityId)) {
		let e = Xr.get(r.referenceEntities)?.get(n.entityId);
		return e ? n.sourceVersionId === e ? "match" : "other_version" : "unknown";
	}
	let a = i ? ye(e, i) : void 0;
	return [
		e.projectId,
		t.contentVersionId,
		ye(e, n.entityId)?.sourceVersionId,
		a?.sourceVersionId
	].includes(n.sourceVersionId) ? "match" : "other_version";
}
function ti(e, t) {
	let n = $(e, "flow_node", t.referenceEntities).find((e) => e.id === t.nodeId), r = $(e, "scene", t.referenceEntities).find((e) => e.id === (t.sceneId ?? n?.data.sceneId));
	return {
		projectId: e.projectId,
		worldTick: t.worldTick,
		graphId: n ? $(e, "flow_graph", t.referenceEntities).find((e) => e.data.nodeIds.includes(n.id))?.id : void 0,
		chapterId: r?.data.chapterId ?? (r ? $(e, "chapter", t.referenceEntities).find((e) => e.data.sceneIds.includes(r.id))?.id : void 0)
	};
}
function ni(e, t) {
	let n = $(e, "flow_node", t.referenceEntities).find((e) => e.id === t.nodeId), r = $(e, "scene", t.referenceEntities).find((e) => e.id === (t.sceneId ?? n?.data.sceneId)), i = n?.data.executionPolicy ?? (n?.data.nodeType === "automatic" ? "first_match" : "manual_choice");
	return [.../* @__PURE__ */ new Set([...r?.data.dialogueLineIds ?? [], ...n && i === "manual_choice" ? $(e, "flow_edge", t.referenceEntities).filter((e) => e.data.fromId === n.id).flatMap((e) => e.data.choiceLineId ? [e.data.choiceLineId] : []) : []])];
}
function ri(e, t, n, r, i) {
	if (n.positionStatus === "unresolved" || ei(e, t, n, r, i) !== "match") return !1;
	let a = $(e, "flow_node", r.referenceEntities).find((e) => e.id === r.nodeId), o = r.sceneId ?? a?.data.sceneId;
	$(e, "scene", r.referenceEntities).find((e) => e.id === o);
	let s = ni(e, r);
	return [
		r.nodeId,
		o,
		...s
	].includes(n.entityId) ? [
		n.entityId,
		n.blockId,
		n.lineId
	].filter((e) => !!e).every((e) => t.seenIds.includes(e)) : !1;
}
function ii(e, t, n, r) {
	if (t.positionStatus === "unresolved" || n.positionStatus === "unresolved") return;
	let i = $(e, "flow_node", r.referenceEntities).find((e) => e.id === r.nodeId), a = $(e, "scene", r.referenceEntities).find((e) => e.id === (r.sceneId ?? i?.data.sceneId)), o = ni(e, r), s = [...(a?.data.body ?? []).map((e) => e.id)];
	for (let t of o) s.push(t, ...($(e, "dialogue_line", r.referenceEntities).find((e) => e.id === t)?.data.text ?? []).map((e) => e.id));
	let c = t.blockId ?? t.lineId ?? (o.includes(t.entityId) ? t.entityId : void 0), l = n.blockId ?? n.lineId ?? (o.includes(n.entityId) ? n.entityId : void 0), u = s.indexOf(c ?? ""), d = s.indexOf(l ?? "");
	if (u >= 0 && d >= 0 && u !== d) return u < d;
	if (c === l && t.entityId === n.entityId && t.start != null && n.start != null && t.start !== n.start && !(t.start < n.start && t.end != null && t.end > n.start || n.start < t.start && n.end != null && n.end > t.start)) return t.start < n.start;
}
function ai(e, t, n) {
	let r = Pn(t);
	if (!r.ok) return {
		ok: !1,
		issues: r.issues
	};
	let i = Jr(e, n.externalValues ?? {}, void 0, n.referenceEntities);
	if (i.length) return {
		ok: !1,
		issues: i
	};
	try {
		let r = n.nodeId ? $(e, "flow_node", n.referenceEntities).find((e) => e.id === n.nodeId) : void 0;
		if (n.nodeId && !r) return Yr("presentation.nodeId", "提示する分岐が存在しないか、削除・不採用です。");
		let i = n.sceneId ?? r?.data.sceneId ?? void 0;
		if (!r && !i) return Yr("presentation", "提示する場面または分岐を指定してください。");
		let a = i ? $(e, "scene", n.referenceEntities).find((e) => e.id === i) : void 0;
		if (i && !a) return Yr("presentation.sceneId", "提示する場面が存在しないか、削除・不採用です。");
		let o = ti(e, {
			...n,
			sceneId: i
		}), s = Er({
			state: t,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: o,
			ruleContexts: je(e, o)
		});
		if (s.length) return {
			ok: !1,
			issues: s
		};
		let c = {
			...n,
			sceneId: i
		}, l = structuredClone(t), u = new Set(l.seenIds);
		if (r && (l.presentationPosition = r.id, l.visitCounts[r.id] = (l.visitCounts[r.id] ?? 0) + 1, u.add(r.id)), a) {
			u.add(a.id), l.visitCounts[a.id] = (l.visitCounts[a.id] ?? 0) + 1;
			for (let e of a.data.blockIds ?? []) u.add(e);
			for (let e of a.data.body) u.add(e.id);
		}
		for (let t of ni(e, c)) {
			let i = $(e, "dialogue_line", n.referenceEntities).find((e) => e.id === t);
			if (!i) return Yr(`${r?.id ?? a?.id}.dialogueLineIds`, "提示する台詞が存在しないか、削除・不採用です。");
			u.add(i.id), l.visitCounts[i.id] = (l.visitCounts[i.id] ?? 0) + 1;
			for (let e of i.data.text) u.add(e.id);
		}
		l.seenIds = [...u];
		let d = $(e, "variable", n.referenceEntities), f = ti(e, c), p = {
			state: l,
			variables: d,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: f,
			ruleContexts: je(e, f)
		}, m = [], h = [];
		for (let i of $(e, "disclosure", n.referenceEntities)) {
			let n = Me(e, i.data.anchor, i.id), o = i.data.targetScope, s = {
				...p,
				ruleContext: p.ruleContexts[i.id] ?? p.ruleContext
			}, u = o ? mr(o, s) : { value: "true" };
			if (u.value === "false") continue;
			let d = ni(e, c);
			if (![
				r?.id,
				a?.id,
				...d
			].includes(n.entityId)) continue;
			let f = ei(e, t, n, c, i.id);
			if (f === "unknown") return Yr(`${i.id}.anchor.sourceVersionId`, "借用した提示位置の固定世界版を確認できません。", "CONDITION_UNKNOWN");
			if (f === "other_version") continue;
			if (u.value === "unknown") return Yr(`${i.id}.targetScope`, "開示の対象範囲・経路を確認できません。", "CONDITION_UNKNOWN");
			if (n.positionStatus === "unresolved" && [
				r?.id,
				a?.id,
				...d
			].includes(n.entityId)) return Yr(`${i.id}.anchor`, n.positionReason || "提示位置が不明です。本文へ再リンクしてください。", "CONDITION_UNKNOWN");
			if (!ri(e, l, n, c, i.id)) continue;
			let g = Cr({
				op: "all",
				children: [i.data.condition ?? {
					op: "constant",
					value: !0
				}, o?.routeCondition ?? {
					op: "constant",
					value: !0
				}]
			}, s);
			if (m.push({
				targetId: i.id,
				...g
			}), g.value === "unknown") return Yr(`${i.id}.condition`, g.reasons.join("、") || "この場面の開示条件が未確認です。", "CONDITION_UNKNOWN");
			g.value === "true" && h.push(i);
		}
		let g = h.filter((e) => (e.data.knowledgeEffects?.length ?? 0) > 0);
		for (let t = 0; t < g.length; t++) for (let n = t + 1; n < g.length; n++) if (ii(e, Me(e, g[t].data.anchor, g[t].id), Me(e, g[n].data.anchor, g[n].id), c) === void 0) return Yr(`${r?.id ?? a?.id}.disclosures`, "複数の開示効果の提示順が確定していません。段落と文字位置を指定してください。", "CONDITION_UNKNOWN");
		g.sort((t, n) => ii(e, Me(e, t.data.anchor, t.id), Me(e, n.data.anchor, n.id), c) ? -1 : 1);
		let _ = [], v = [];
		for (let t of g) for (let r of t.data.knowledgeEffects ?? []) {
			let i = [...e.entities, ...n.referenceEntities ?? []].find((e) => e.kind === "effect" && e.id === r && S(e));
			if (!i) return Yr(`${t.id}.knowledgeEffects`, "開示に指定した効果が存在しないか、削除・不採用です。");
			_.push(i), v.push({
				project: e,
				target: c,
				anchor: Me(e, t.data.anchor, t.id)
			});
		}
		let y = jr(l, _, {
			...p,
			effectPresentations: v
		});
		return y.ok ? (y.state.seenIds = [.../* @__PURE__ */ new Set([...y.state.seenIds, ...h.map((e) => e.id)])], {
			ok: !0,
			state: y.state,
			observationState: structuredClone(l),
			conditions: m
		}) : y;
	} catch (e) {
		return {
			ok: !1,
			issues: e instanceof X ? e.issues : [{
				code: "VALIDATION_FAILED",
				path: "presentation",
				message: e instanceof Error ? e.message : "提示を検証できません。"
			}]
		};
	}
}
function oi(e, t, n) {
	let { sceneId: r, previousSceneId: i } = n, a = ti(e, {
		sceneId: i,
		referenceEntities: n.referenceEntities
	}), o = ti(e, {
		sceneId: r,
		referenceEntities: n.referenceEntities
	}), s = i && i !== r ? ["scene_end"] : [];
	a.chapterId && a.chapterId !== o.chapterId && s.push("chapter_end");
	let c = Mr({
		...t,
		...t.resetCauses ? { resetCauses: [] } : {}
	}, s, {
		state: t,
		entities: e.entities,
		referenceEntities: n.referenceEntities,
		externalValues: n.externalValues,
		ruleContext: ti(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick,
			referenceEntities: n.referenceEntities
		}),
		ruleContexts: je(e, ti(e, {
			sceneId: n.previousSceneId,
			worldTick: n.worldTick,
			referenceEntities: n.referenceEntities
		}))
	});
	if (!c.ok) return c;
	let l = ai(e, c.state, n);
	if (!l.ok) return l;
	if (n.last) {
		let t = Mr(l.state, [
			"scene_end",
			"chapter_end",
			"run_end"
		], {
			state: l.state,
			entities: e.entities,
			referenceEntities: n.referenceEntities,
			externalValues: n.externalValues,
			ruleContext: ti(e, n),
			ruleContexts: je(e, ti(e, n))
		});
		if (!t.ok) return t;
		l.state = t.state, (c.state.resetCauses || t.state.resetCauses) && (l.state.resetCauses = [...c.state.resetCauses ?? [], ...t.state.resetCauses ?? []]);
	}
	return l;
}
//#endregion
export { me as $, er as A, ht as B, jt as C, p as Ct, wt as D, g as Dt, Nt as E, _ as Et, dr as F, Ke as G, mt as H, Fn as I, ye as J, Ae as K, sr as L, Wn as M, Gn as N, kt as O, Et as P, pe as Q, Pn as R, Vn as S, h as St, lr as T, s as Tt, ft as U, pt as V, Re as W, S as X, je as Y, fe as Z, St as _, l as _t, ti as a, ce as at, bt as b, o as bt, Ir as c, se as ct, jr as d, ue as dt, he as et, Cr as f, ie as ft, D as g, n as gt, Er as h, b as ht, ai as i, ae as it, Tt as j, Ot as k, Kr as l, re as lt, Mr as m, y as mt, Qr as n, ee as nt, Jr as o, le as ot, Tr as p, v as pt, be as q, oi as r, oe as rt, qr as s, x as st, $r as t, te as tt, Pr as u, de as ut, _t as v, d as vt, Mt as w, m as wt, Bn as x, u as xt, xt as y, f as yt, Y as z };
