import { C as e, K as t, L as n, M as r, Q as i, Z as a, ct as o, dt as s, lt as c, rt as l, s as u, t as d, tt as f, w as p } from "./presentation-E2RAqQW_.js";
import { startTrial as m, stepTrial as h } from "./runtime-CYII5YOX.js";
import { t as g } from "./exportPreparation-xms5q2ZX.js";
//#region src/domain/runtimeVerified.ts
async function _(e, n, r) {
	let o = structuredClone(e), s = a(), c = i(r, s), l = await u(o, n, { worldSnapshots: c }, s);
	return {
		source: o,
		content: l,
		registry: c,
		referenceEntities: await d(t(l, l.snapshots), c, s)
	};
}
async function v(e, t = {}, n = {}) {
	let r = structuredClone(t), i = await _(e, r.contentVersionId ?? e.projectId, n);
	return m(i.source, {
		...r,
		referenceEntities: i.referenceEntities
	});
}
//#endregion
//#region src/domain/portableRuntimeProject.ts
async function y(t) {
	let i = await s(o(t)), a = (e) => `${e.slice(0, 8)}-${e.slice(8, 12)}-4${e.slice(13, 16)}-a${e.slice(17, 20)}-${e.slice(20, 32)}`, c = a(i), l = t.versions ?? [];
	if (l.length > 128 || new Set(l.map((e) => e.id)).size !== l.length || l.some((e) => e.projection.versions?.length)) throw Error("EXPORT_UNSUPPORTED: 公開引用版の上限・重複・依存形式が不正です。");
	let u = [t, ...l.map((e) => e.projection)], d = new Set(u.flatMap((e) => [...e.entities.map((e) => e.id), ...e.relations.map((e) => e.id)]));
	l.forEach((e) => d.add(e.id));
	function f(e) {
		if (Array.isArray(e)) {
			e.forEach(f);
			return;
		}
		if (!e || typeof e != "object") return;
		let t = e;
		typeof t.id == "string" && typeof t.text == "string" && typeof t.kind == "string" && d.add(t.id), typeof t.id == "string" && typeof t.eventKey == "string" && d.add(t.id), Object.values(t).forEach(f);
	}
	u.forEach((e) => e.entities.forEach((e) => f(e.data)));
	let m = { "public-project": c };
	for (let e of d) m[e] = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(e) ? e : a(await s(new TextEncoder().encode(`scenario-runtime-1:${e}`)));
	function h(e, t) {
		if (Array.isArray(e)) return e.map((e) => h(e, t));
		if (!e || typeof e != "object") return e;
		let n = e, r = Object.fromEntries(Object.entries(n).map(([e, n]) => [e, ["sourceVersionId", "targetSnapshotId"].includes(e) && n === "public-project" ? t : h(n, t)]));
		return typeof n.id == "string" && d.has(n.id) && (r.id = m[n.id]), Array.isArray(n.links) && (r.links = n.links.map((e) => {
			let n = e;
			return {
				start: n.start,
				end: n.end,
				target: {
					entityId: n.targetId,
					...n.blockId ? { blockId: n.blockId } : {},
					...n.lineId ? { lineId: n.lineId } : {},
					...n.sourceVersionId ? { sourceVersionId: n.sourceVersionId === "public-project" ? t : n.sourceVersionId } : {},
					...n.targetStart === void 0 ? {} : {
						start: n.targetStart,
						end: n.targetEnd
					}
				}
			};
		})), r;
	}
	function g(t, n) {
		let i = p(t.title);
		if (i.projectId = c, i.mainStart = t.mainStart ?? "0", i.calendars[0].id = i.calendarId = "public-calendar-default", i.entities = t.entities.map((t) => {
			let i = h(t.data, n);
			delete i.bytesIncluded;
			let a = e(c, t.kind, t.name, i);
			return a.id = m[t.id], a.createdAt = a.updatedAt = "1970-01-01T00:00:00.000Z", a.status = "confirmed", r(a, m);
		}), i.views = [], i.relations = t.relations.map((t) => ({
			...t,
			id: m[t.id],
			projectId: c,
			fromId: m[t.fromId],
			toId: m[t.toId],
			evidenceIds: t.evidenceIds.map((e) => m[e]),
			revision: "0",
			status: "confirmed",
			visibility: "projection",
			validity: r(e(c, "assertion", "公開関係の期間", {
				subjectId: m[t.fromId],
				predicate: "relation",
				validity: h(t.validity, n) ?? {
					worldRange: null,
					routeCondition: null,
					presentationAnchor: null
				}
			}), m).data.validity
		})), i.worldReferences = [], i.snapshots = [], i.history = [], t.calendars.length) {
			let e = i.calendars[0];
			i.calendars = t.calendars.map((t) => t.kind === "repeating" ? {
				id: t.id,
				name: t.name,
				kind: "repeating",
				originLabel: t.originLabel,
				ticksPerDay: t.ticksPerDay,
				years: t.years ?? []
			} : {
				...e,
				id: t.id,
				name: t.name,
				kind: "gregorian",
				ticksPerDay: t.ticksPerDay
			}), i.calendarId = i.calendars[0].id;
		}
		return i;
	}
	let _ = g(t, c);
	for (let e of l) {
		let { history: t, snapshots: n, authorAlternatives: r, ...i } = g(e.projection, m[e.id]);
		_.snapshots.push({
			id: m[e.id],
			versionLabel: e.projection.title,
			createdAt: "1970-01-01T00:00:00.000Z",
			content: i,
			contentHash: await s(o(i))
		});
	}
	let v = n(_);
	if (!v.ok) throw Object.assign(/* @__PURE__ */ Error("EXPORT_UNSUPPORTED: 公開実行内容を同じstrict契約へ対応できません。"), { issues: v.issues });
	return {
		project: _,
		publicToRuntime: m
	};
}
//#endregion
//#region src/domain/gameEvidence.ts
var b = (e) => {
	throw Error(`INTEGRITY_FAILED: ${e}`);
};
async function x(e, t, n) {
	t = structuredClone(t);
	let r = structuredClone(e), i = structuredClone(n), a = r.snapshots.find((e) => e.id === t.verificationVersionId);
	(!a || await s(o(a.content)) !== a.contentHash) && b("保存したゲーム受領の公開確認版を検証できません。");
	let c = a.content.entities.find((e) => e.id === t.approval.entityId);
	(t.approval.sourceVersionId !== a.id || c?.kind !== "note" || c.visibility !== "private" || c.status !== "confirmed" || c.customValues.gamePackageHash !== t.packageHash || c.customValues.gameReceiptHash !== t.receiptHash) && b("保存したゲーム受領hashが固定承認と一致しません。");
	let l = r.snapshots.find((e) => e.id === t.sourceVersionId)?.content;
	(!l || l.revision !== t.sourceRevision) && b("保存したゲーム受領の対象revisionが一致しません。");
	let u = {
		...structuredClone(a.content),
		snapshots: r.snapshots,
		history: []
	}, d = /* @__PURE__ */ new Map();
	for (let e of t.projectionBindings) {
		let t = d.get(e.editionVersionId);
		t || (t = {}, d.set(e.editionVersionId, t)), t[e.entityId] && t[e.entityId] !== e.publicId && b("保存した公開ID対応が重複しています。"), t[e.entityId] = e.publicId;
	}
	let f = new Map(t.citationBindings.map((e) => [e.sourceVersionId, e.publicVersionId]));
	f.size !== t.citationBindings.length && b("保存した引用版対応が重複しています。");
	let p = (e, n) => {
		if (e.kind !== "projection_profile") return e;
		let r = e.id === t.profileId ? t.sourceVersionId : e.data.sourceVersionId ?? n, i = d.get(r) ?? {}, a = structuredClone(e.data.namePolicy);
		for (let [e, t] of Object.entries(a.byEntityId ?? {})) t.mode === "anonymize" && i[e] && (t.publicId = i[e]);
		return {
			...e,
			data: {
				...e.data,
				publicIds: {
					...e.data.publicIds,
					...i
				},
				namePolicy: a,
				citedVersions: e.data.citedVersions?.map((e) => ({
					...e,
					publicVersionId: f.get(e.sourceVersionId) ?? e.publicVersionId
				}))
			}
		};
	};
	u.entities = u.entities.map((e) => p(e, t.sourceVersionId)), u.snapshots = await Promise.all(u.snapshots.map(async (e) => {
		await s(o(e.content)) !== e.contentHash && b("保存したゲーム受領の元版hashが一致しません。");
		let t = {
			...e.content,
			entities: e.content.entities.map((t) => p(t, e.id))
		};
		return {
			...e,
			content: t,
			contentHash: await s(o(t))
		};
	}));
	let m = [];
	for (let e of t.worldVersions) {
		let t = i[e.sourceVersionId];
		(!t || await s(o(t)) !== e.contentHash) && b("保存したゲーム受領の固定世界hashが一致しません。"), m.push({
			id: e.sourceVersionId,
			content: t,
			contentHash: e.contentHash
		});
	}
	let h = t.sourceVersionId === t.verificationVersionId, _ = await g(u, {
		profile: "runtime_json",
		projectionProfileId: t.profileId,
		...h ? { targetRevision: u.revision } : { targetVersionId: t.sourceVersionId },
		worldSnapshots: i,
		worldPins: m
	}), v = Object.entries(_.idMap).filter(([, e]) => _.projection.entities.some((t) => t.id === e));
	(v.length !== t.idMappings.length || v.some(([e, n]) => !t.idMappings.some((r) => r.entityId === e && r.publicId === n && r.sourceVersionId === t.sourceVersionId))) && b("保存したゲーム受領の元ID・公開ID対応が一致しません。");
	for (let e of [_.projection, ..._.projection.versions?.map((e) => e.projection) ?? []]) for (let t of e.entities) t.kind === "attachment" && (t.data.bytesIncluded = !0);
	let x = await y(_.projection);
	return {
		publicProjection: _.projection,
		runtimeProject: x.project,
		publicToRuntime: x.publicToRuntime,
		runtimeProjectHash: await s(o(x.project)),
		entities: _.projection.entities
	};
}
var S = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/, C = (e) => {
	throw Error(`INTEGRITY_FAILED: ${e}`);
};
function w(e) {
	let t = e, n = [
		"format",
		"formatVersion",
		"specification",
		"receiverId",
		"sessionId",
		"receivedAt",
		"packageHash",
		"runtimeProjectHash",
		"entryId",
		"worldTick",
		"actions",
		"requests",
		"finalState",
		"status",
		"mode",
		"dialogueIds",
		"assets",
		"receiptHash"
	], r = /^[a-f0-9]{64}$/;
	(!t || typeof t != "object" || Array.isArray(t) || Object.keys(t).some((e) => !n.includes(e)) || t.format !== "scenario-game-receipt" || t.formatVersion !== "1.0.0" || t.specification !== "scenario-browser-game/1.0.0" || t.receiverId !== "independent-browser-game" || typeof t.sessionId != "string" || !S.test(t.sessionId) || typeof t.entryId != "string" || !S.test(t.entryId) || typeof t.receivedAt != "string" || !Number.isFinite(Date.parse(t.receivedAt)) || ![
		t.packageHash,
		t.runtimeProjectHash,
		t.receiptHash
	].every((e) => typeof e == "string" && r.test(e)) || ![
		"stub",
		"actual",
		"mixed"
	].includes(t.mode) || ![
		"ready",
		"terminal",
		"blocked",
		"unknown",
		"error"
	].includes(t.status) || !t.finalState || typeof t.finalState != "object" || Array.isArray(t.finalState) || t.worldTick != null && (typeof t.worldTick != "string" || !/^(?:0|-[1-9][0-9]*|[1-9][0-9]*)$/.test(t.worldTick)) || !Array.isArray(t.actions) || t.actions.length > 1e4 || !Array.isArray(t.requests) || t.requests.length > 1e4 || !Array.isArray(t.dialogueIds) || t.dialogueIds.some((e) => typeof e != "string") || new Set(t.dialogueIds).size !== t.dialogueIds.length || !Array.isArray(t.assets) || t.assets.some((e) => !e || Object.keys(e).some((e) => !["id", "contentHash"].includes(e)) || typeof e.id != "string" || !r.test(e.contentHash)) || new Set(t.assets.map((e) => e.id)).size !== t.assets.length || o(t).byteLength > 1048576) && C("受領証跡の仕様・構造・上限が不正です。");
	for (let e of t.actions) (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((e) => ![
		"sequence",
		"id",
		"contractId",
		"action",
		"stubIndex",
		"score",
		"value",
		"executedAt",
		"previousHash",
		"hash"
	].includes(e)) || typeof e.id != "string" || !S.test(e.id) || typeof e.contractId != "string" || typeof e.executedAt != "string" || !Number.isFinite(Date.parse(e.executedAt)) || ![
		"win",
		"lose",
		"collect",
		"stub"
	].includes(e.action) || !Number.isSafeInteger(e.score) || !Number.isSafeInteger(e.sequence) || !r.test(e.previousHash) || !r.test(e.hash)) && C("ゲーム実行記録のID・日時・構造が不正です。");
	for (let e of t.requests) (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((e) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(e))) && C("受領証跡の進行要求が未対応です。");
	return t;
}
function T(e) {
	return [...e.publicProjection.entities.filter((e) => e.kind === "attachment").map((e) => ({
		id: e.id,
		data: e.data
	})), ...(e.publicProjection.versions ?? []).flatMap((e) => e.projection.entities.filter((e) => e.kind === "attachment").map((t) => ({
		id: `${e.id}:${t.id}`,
		data: t.data
	})))];
}
function E(e, t) {
	let n = e.runtimeProject.entities.find((n) => n.kind === "external_contract" && n.id === e.publicToRuntime[t]);
	return n || C("受取パッケージに外部契約がありません。"), n;
}
function D(e, t, n, r, i) {
	let a = E(e, t);
	if (n === "stub") {
		let e = a.data.stubValues?.[i ?? -1];
		return e || C("宣言済み仮値がありません。"), {
			score: r,
			value: structuredClone(e)
		};
	}
	a.data.owner !== "game" && C("ゲーム管理以外の外部契約を実測にできません。");
	let o = n === "win" ? r + 3 : n === "collect" ? r + 1 : Math.max(0, r - 1), s;
	if (a.data.outputType === "boolean") s = {
		type: "boolean",
		value: n !== "lose"
	};
	else if (a.data.outputType === "integer") s = {
		type: "integer",
		value: o
	};
	else if (a.data.outputType === "enum") {
		let e = (a.data.stubValues ?? []).filter((e) => e.type === "enum");
		e.length || C("列挙結果の宣言がありません。"), s = structuredClone(e[n === "lose" ? e.length - 1 : n === "win" ? 0 : Math.min(1, e.length - 1)]);
	} else return C("受取例が未対応の結果型です。");
	return {
		score: o,
		value: s
	};
}
function O(e) {
	let t = e.some((e) => e.action === "stub");
	return e.some((e) => e.action !== "stub") ? t ? "mixed" : "actual" : "stub";
}
function k(e, t) {
	return Object.fromEntries(t.map((t) => [e.publicToRuntime[t.contractId], t.value]));
}
async function A(e, t) {
	let n = t.packageHash, r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set();
	for (let [a, c] of t.actions.entries()) {
		(!c || typeof c.id != "string" || !S.test(c.id) || i.has(c.id) || c.sequence !== a + 1 || c.previousHash !== n || typeof c.executedAt != "string" || !Number.isFinite(Date.parse(c.executedAt)) || ![
			"win",
			"lose",
			"collect",
			"stub"
		].includes(c.action)) && C("ゲーム実行記録の順序・ID・日時が不正です。"), i.add(c.id), Object.keys(c).some((e) => ![
			"sequence",
			"id",
			"contractId",
			"action",
			"stubIndex",
			"score",
			"value",
			"executedAt",
			"previousHash",
			"hash"
		].includes(e)) && C("未対応のゲーム実行項目があります。");
		let t = D(e, c.contractId, c.action, r.get(c.contractId) ?? 0, c.stubIndex), { hash: u, ...d } = c;
		(l(t.value) !== l(c.value) || t.score !== c.score || await s(o(d)) !== u) && C("ゲーム処理の実結果・hashが一致しません。"), r.set(c.contractId, c.score), n = u;
	}
	t.mode !== O(t.actions) && C("stub/actual/mixedの表示が実行証跡と一致しません。"), (l(t.dialogueIds) !== l(e.entities.filter((e) => e.kind === "dialogue_line").map((e) => e.id)) || l(t.assets) !== l(T(e).map((e) => ({
		id: e.id,
		contentHash: String(e.data.contentHash)
	})))) && C("台詞・素材ID対応または素材hashが一致しません。");
	let a = await v(e.runtimeProject, {
		entryId: t.entryId,
		worldTick: t.worldTick,
		externalValues: k(e, t.actions)
	});
	for (let n of t.requests) (!n || Object.keys(n).some((e) => ![
		"edgeId",
		"event",
		"random",
		"worldTick"
	].includes(e))) && C("受領証跡の進行要求が未対応です。"), a = h(e.runtimeProject, a, n);
	(l(a.state) !== l(t.finalState) || a.status !== t.status) && C("受取ゲームの経路・最終結果を再生できません。");
}
function j(e) {
	return c(e, "game-receipt.json", {
		...f,
		jsonBytes: 1048576
	});
}
async function M(e, t = {}) {
	let n = (e) => [
		e,
		...e.snapshots.map((e) => e.content),
		...e.history.flatMap((e) => [e.before, e.after]),
		...e.authorAlternatives?.flatMap((e) => [e.baseContent, ...e.versions.map((e) => e.content)]) ?? []
	];
	if (!n(e).some((e) => e.entities.some((e) => e.kind === "note" && e.data.handoffReceipt))) return;
	let r = structuredClone(e), i = structuredClone(t), a = n(r), c = /* @__PURE__ */ new Set();
	for (let e of a) for (let t of e.entities) {
		if (t.kind !== "note" || !t.data.handoffReceipt) continue;
		let e = l(t.data.handoffReceipt);
		if (c.has(e)) continue;
		c.add(e);
		let n = t.data.handoffReceipt, a = w(j(new TextEncoder().encode(n.rawJson))), { receiptHash: u, ...d } = a;
		(await s(o(d)) !== u || u !== n.receiptHash || a.packageHash !== n.packageHash || a.mode !== n.mode || O(a.actions) !== n.mode) && C("保存したゲーム受領のhash・実行分類が元証跡と一致しません。");
		let f = await x(r, n, i), p = f;
		a.runtimeProjectHash !== f.runtimeProjectHash && C("保存したゲーム受領の実行内容が元の固定公開版と一致しません。"), await A(p, a);
	}
}
//#endregion
export { M as verifyStoredGameEvidence };
